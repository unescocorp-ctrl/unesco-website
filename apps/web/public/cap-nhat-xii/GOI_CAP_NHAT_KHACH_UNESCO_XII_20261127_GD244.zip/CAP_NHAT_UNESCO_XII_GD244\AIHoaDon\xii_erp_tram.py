# -*- coding: utf-8 -*-
"""UNESCO XII - TRAM ERP_ANHMAI (phan CHI DOC, P1 cua BuildTools\\KE_HOACH_TRAM_ERP_XII.md).

Tram nhan lenh tu ERP_ANHMAI qua hop thu LENH\\ (khuon v1 + v1.1), lam cac buoc chi doc (kiem_tra, doi_chieu, hien_trang) tren SO SQL SERVER cua XII
va tra ket qua dung khuon. Tu XII tro di ERP chi dieu phoi XII (XI khong con tham gia): tram nay la tram duy nhat cua kenh LENH\\.

Khong viet lai logic: dung NGUYEN VAN erp_tram.py / erp_khuon.py / erp_thuc_hien.py / doi_chieu_100.py cua XI GD347-350 (chep nguyen, co chot bam). Chi thay
cho doc so: xii_so_sql.py dong vai jet_doc, so duoc doc qua BAN CHUP JSON (xii_chup_so.ps1, chi SELECT) thay cho tep .MDB.
  * "so" trong lenh = TEN CSDL XII (chu khong dau, so, gach duoi; BookFile.FileName cua ERP). Khong doan: ten khong co / khong mo duoc -> KHONG_THAY_SO.
  * ban chup truoc va sau phan tich: bam SHA-256 cua tep chup (F09: so doi trong luc kiem -> LOI, khong gui).
  * ban chup chua toan bo so -> xoa ngay sau lenh (va xoa tep chup bo quen > 60 phut khi tram khoi dong).
  * buoc can GHI so (tai_hd, phan_tich, ghi_trong_nguong, so_phu, phan_bo, trich_luong, tong_hop, gia_thanh, ket_chuyen, khoa_so, bao_cao): giao cho
    tram ghi trong UNESCO XII (Modules\\AiErpStation.vb + AiMonthChain.vb, V0095 chuoi nghiep vu thang); tram ghi tat -> BO_QUA co ly do,
    ERP khong bao gio coi la da lam.
  * sua_chung_tu (GD348a, chi doc, erp_tram nguyen van): da_sua[] lay tu so thuc hien ERP_THUCHIEN trong ban chup. TASK369: XII ghi bang nay
    (Modules\\AiErpLedger346.vb) khi ke toan tra loi viec ERP trong Hang doi viec (Da lam / Khong phai loi / Hen ky sau - AiErpWork348.vb,
    xii_erp_viec.py) va khi lap but toan de xuat. Viec chua ai tra loi -> KHONG_SUA voi ly do LY_DO_SUA (khong phai "tram ghi chua bat").

  python xii_erp_tram.py /cau_hinh:"<xii_erp_tram.json>"                 vong lap tram (Ctrl+C hoac /dung de dung an toan)
  python xii_erp_tram.py /cau_hinh:"<xii_erp_tram.json>" /mot_lan         quet mot luot roi thoat (Task Scheduler / kiem thu)
  python xii_erp_tram.py /cau_hinh:"<xii_erp_tram.json>" /dung            tao tep tram\\<tram>.dung -> tram dung sau lenh dang lam
  python xii_erp_tram.py /lenh:"<tep lenh.json>" /ra:"<tep ket qua>" /data:"<thu muc chup>" [/may_chu:".\\SQLEXPRESS"]   lam mot lenh, khong dung hop thu
  python xii_erp_tram.py /mot:"<TEN_CSDL>" /ra:"<kq.json>" [/may_chu:...]   phan tich mot so, ghi phan ket qua (kiem thu doc so)

xii_erp_tram.json: nhu erp_tram.json cua XI; "data" = thu muc dat ban chup tam (khong phai thu muc .MDB); them tuy chon "may_chu_sql" (mac dinh .\\SQLEXPRESS).
Tai khoan Windows chay tram can quyen doc cac so (db_datareader). Khong luu mat khau o dau ca; ket noi bang xac thuc cua Windows.
"""
import io
import json
import os
import re
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import xii_so_sql as _SQ  # noqa: E402

_SQ.cai_dat()                      # tu day `import jet_doc` cua cac module XI la doc ban chup SQL
import erp_khuon as KH  # noqa: E402
import erp_tram as T  # noqa: E402

CREATE_NO_WINDOW = 0x08000000
RE_DB = re.compile(r"^[A-Za-z0-9_]{1,100}$")
HAU_TO_CHUP = ".so_sql.json"
GIAY_TEP_CU = 3600
MAY_CHU = [os.environ.get("XII_TRAM_MAY_CHU") or ".\\SQLEXPRESS"]
SNAP = {}                          # duong tep chup -> ten CSDL
LY_DO_GHI = ("Bước này cần ghi sổ: trạm ghi của UNESCO XII chưa bật (cửa sổ Trạm ERP trong UNESCO XII) - cần người làm hoặc bật trạm ghi")
T.LY_DO_CHUA_HO_TRO = LY_DO_GHI


def _xoa(duong):
    try:
        if duong and os.path.isfile(duong):
            os.remove(duong)
    except OSError:
        pass
    SNAP.pop(duong, None)


def chup_so(ten_db, ra):
    """Chay xii_chup_so.ps1 (chi doc). -> (True, '') hoac (False, ly do)."""
    ps = os.path.join(HERE, "xii_chup_so.ps1")
    if not os.path.isfile(ps):
        return False, "thiếu xii_chup_so.ps1"
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", ps, "-Server", MAY_CHU[0], "-Database", ten_db, "-Out", ra],
                           capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=1800, creationflags=CREATE_NO_WINDOW)
    except (OSError, subprocess.TimeoutExpired) as e:
        return False, "không chạy được bộ chụp sổ: %s" % type(e).__name__
    if r.returncode != 0 or not os.path.isfile(ra):
        dong = [x for x in (r.stdout or "").splitlines() if x.strip()]
        return False, (dong[-1] if dong else "bộ chụp sổ lỗi mã %s" % r.returncode)[:300]
    return True, ""


def tim_so(data, so):
    """Thay cho erp_tram.tim_so: 'so' = ten CSDL XII. -> (duong tep chup, loi)."""
    ten = str(so or "").strip()
    if not ten:
        return None, "lệnh không có tên sổ"
    if not RE_DB.match(ten):
        return None, "tên sổ '%s' không phải tên CSDL XII (chỉ chữ không dấu, số, gạch dưới)" % ten[:60]
    os.makedirs(data, exist_ok=True)
    ra = os.path.join(data, ten + HAU_TO_CHUP)
    ok, loi = chup_so(ten, ra)
    if not ok:
        return None, "không mở được sổ '%s' trên máy chủ SQL: %s" % (ten, loi)
    SNAP[ra] = ten
    return ra, ""


_PHAN_TICH_GOC = T.PHAN_TICH
_LAM_LENH_GOC = T.lam_lenh


def _phan_tich_mot(duong, hom_nay, sau=3, tham_so=None):
    """Phan tich nhu XI (tren ban chup), roi chup LAN HAI de kiem 'so doi trong luc kiem' (F09)."""
    pt = _PHAN_TICH_GOC(duong, hom_nay, sau, tham_so)
    ten = SNAP.get(duong)
    if ten and pt.get("ban_chup"):
        tam = duong + ".sau"
        ok, _loi = chup_so(ten, tam)
        try:
            pt["ban_chup_sau"] = KH.sha256_tep(tam) if ok else "KHONG_CHUP_LAI_DUOC"
        finally:
            _xoa(tam)
    return pt


# TASK381: erp_tram.lam_lenh (XI, pinned) analyses the book ONCE (first read-only step) and builds hien_trang, chung_tu_sai,
# viec_can_nguoi and quy_tac at the end of the command from that same dict - also after a write step changed the book, so ERP
# received the state from BEFORE the write (e.g. "1 invoice not posted" after posting it). The dict handed to lam_lenh is kept
# here and refreshed IN PLACE after every write step, so everything lam_lenh reports later is read from the book as written.
PT_DANG_DUNG = {}                  # duong ban chup -> [pt dict cua lam_lenh, hom_nay, sau, tham_so]


def phan_tich(duong, hom_nay, sau=3, tham_so=None):
    pt = _phan_tich_mot(duong, hom_nay, sau, tham_so)
    PT_DANG_DUNG[duong] = [pt, hom_nay, sau, tham_so]
    return pt


def _pt_khong_doc_lai(ly_do):
    """Book could not be read again after a write: no figures (None, never 0) and ban_chup != ban_chup_sau, so the F09 check of
    lam_lenh turns the read-only steps into LOI ('chay lai') instead of sending the state from before the write."""
    loi = "không đọc lại được sổ sau bước ghi: %s" % ly_do
    return {"dh": None, "dc": None, "bt": None, "ct": {}, "tk": {}, "loi": {"dh": loi, "bt": loi, "dc": loi}, "quy_tac_ap_dung": [],
            "ban_chup": "TRUOC_GHI", "ban_chup_sau": "KHONG_DOC_LAI_DUOC_SAU_GHI"}


def doc_lai_sau_ghi(duong, chup_lai_duoc, ly_do=""):
    """After a write step: refresh the analysis lam_lenh is holding (only if a read-only step already analysed this book)."""
    cu = PT_DANG_DUNG.get(duong)
    if not cu:
        return
    pt, hom_nay, sau, tham_so = cu
    if not chup_lai_duoc:
        moi = _pt_khong_doc_lai(ly_do or "không chụp lại được sổ")
    else:
        try:
            moi = _phan_tich_mot(duong, hom_nay, sau, tham_so)
        except Exception as e:
            moi = _pt_khong_doc_lai(type(e).__name__)
    pt.clear()
    pt.update(moi)


LY_DO_SUA = ("Kế toán chưa trả lời việc này trong Hàng đợi việc của UNESCO XII (Mở nơi làm, sửa phiếu, rồi Đã làm / Không phải lỗi / "
             "Hẹn kỳ sau); việc ERP hiện trong hàng đợi sau lần Kiểm tra trước khoá sổ kế tiếp")


def _ly_do_sua(kq):
    """GD348a dung chung T.LY_DO_CHUA_HO_TRO cho viec chua co dong thuc hien; o XII hang so do la LY_DO_GHI ('tram ghi chua bat') - sai voi
    sua_chung_tu (buoc nay chi doc, khong can tram ghi). Doi ly do cua da_sua[], cua buoc sua_chung_tu va cua viec_can_nguoi BUOC:sua_chung_tu."""
    if not isinstance(kq, dict):
        return kq
    for x in kq.get("da_sua") or []:
        if isinstance(x, dict) and x.get("trang_thai") == "KHONG_SUA" and x.get("ly_do") == LY_DO_GHI:
            x["ly_do"] = LY_DO_SUA
    for b in kq.get("buoc") or []:
        if isinstance(b, dict) and b.get("ten") == "sua_chung_tu" and b.get("ly_do") == LY_DO_GHI:
            b["ly_do"] = LY_DO_SUA
    for v in kq.get("viec_can_nguoi") or []:
        if isinstance(v, dict) and v.get("buoc") == "sua_chung_tu" and v.get("mo_ta") == LY_DO_GHI:
            v["mo_ta"] = LY_DO_SUA
    return kq


def lam_lenh(ch, lenh, duong_so, hom_nay=None, bao=None, ho_so=None):
    try:
        return _ly_do_sua(_LAM_LENH_GOC(ch, lenh, duong_so, hom_nay, bao=bao, ho_so=ho_so))
    finally:
        PT_DANG_DUNG.pop(duong_so, None)
        _xoa(duong_so)                         # ban chup chua ca so: khong de lai


_YEU_CAU_VB_GOC = T.yeu_cau_vb

# KT_BOT (17/11/2026, kiem tra ROBOT, diem H3): tram ghi KHONG TRA LOI trong han, hoac TAT GIUA CHUNG, khong co nghia la buoc do that bai -
# so co the da ghi xong. erp_tram.py (tep XI, chot bam) bao hai truong hop nay la LOI; lenh LOI duoc lich dem cua ERP tao lai va chay lai
# ma khong ai xem so. O day doi thanh CAN_NGUOI "CHUA RO KET QUA" kem mot viec cho ke toan: lenh ket thuc XONG_CO_VIEC (khong tu chay lai),
# va cac buoc ghi con lai cua lenh bi bo qua.
_KHOA_CHUA_RO = "_chua_ro_ket_qua"
_DAU_CHUA_RO = ("Trạm VB6 không trả lời trong", "Trạm VB6 tắt giữa chừng")


def _chua_ro_ket_qua(lenh, buoc, ket_qua):
    b, viec = ket_qua
    if not isinstance(b, dict) or b.get("trang_thai") != "LOI" or not str(b.get("loi") or "").startswith(_DAU_CHUA_RO):
        return ket_qua
    ly_do = ("CHƯA RÕ KẾT QUẢ: %s. Sổ có thể đã ghi xong bước này. Kế toán mở sổ kiểm tra bước «%s» kỳ %s trước khi cho chạy lại."
             % (b["loi"], buoc, lenh.get("ky", "")))[:500]
    lenh[_KHOA_CHUA_RO] = buoc
    viec = list(viec or []) + [{"ma": KH.ma_sach("CHUA_RO:%s:%s" % (buoc, lenh.get("ky", "")), 100), "loai": "CHUA_RO_KET_QUA", "buoc": buoc,
                                "muc": "NANG", "mo_ta": ly_do}]
    return {"ten": buoc, "trang_thai": "CAN_NGUOI", "ly_do": ly_do}, viec


def don_lenh_do(ch):
    """KT_BOT (17/11/2026, diem H2): khi tram khoi dong, lenh con nam trong dang_lam\\ la lenh tram dang lam thi bi tat. Truoc day tep nam
    do mai (tram chi quet cho\\), ERP giu lenh o DANG_LAM va so do khong nhan duoc lenh moi. O day tra ket qua "chua ro ket qua, can nguoi"
    de ERP dong lenh va giao viec cho ke toan. Khong chay lai buoc nao. Lenh ma tram KHAC dang giu khoa so thi de nguyen. -> so lenh da dong."""
    n = 0
    try:
        teps = [p for p in os.listdir(ch.tm("dang_lam")) if p.lower().endswith(".json")]
    except OSError:
        return 0
    for ten in teps:
        duong = ch.tm("dang_lam", ten)
        ma = ten[:-5]
        try:
            if T._da_co_ket_qua(ch, ma):
                os.replace(duong, ch.tm("xong", ten))
                continue
            lenh = T.doc_json(duong)
            if not isinstance(lenh, dict) or KH.kiem_lenh(lenh) or lenh.get("lenh") != ma:
                T.ghi_log(ch, "%s: tệp lệnh dở không đọc được - để lại trong dang_lam" % ma)
                continue
            khoa = T._khoa_tep(ch, lenh["so"])
            if os.path.isfile(khoa):
                try:
                    with io.open(khoa, "r", encoding="utf-8") as f:
                        chu = (f.read().split() or [""])[0]
                    moi = time.time() - os.path.getmtime(khoa) < (ch.phut_moi_so + T.PHUT_KHOA_THEM) * 60
                except OSError:
                    chu, moi = "", True
                if chu != ch.tram and moi:
                    continue                               # tram khac dang lam so nay
                T.mo_khoa(ch, lenh["so"])
            ly_do = ("CHƯA RÕ KẾT QUẢ: trạm bị tắt khi đang làm lệnh này. Các bước ghi có thể đã ghi một phần hoặc đã xong. "
                     "Kế toán mở sổ kiểm tra kỳ %s rồi tạo lệnh mới nếu cần; máy không tự chạy lại." % lenh.get("ky", ""))[:500]
            gio = KH.gio_iso()
            kq = {"phien_ban_khuon": KH.PHIEN_BAN_KHUON, "lenh": ma, "tram": ch.tram, "bat_dau": gio, "ket_thuc": gio, "trang_thai": "XONG_CO_VIEC",
                  "buoc": [{"ten": b, "trang_thai": "CAN_NGUOI", "ly_do": ly_do} for b in lenh["buoc"]],
                  "viec_can_nguoi": [{"ma": KH.ma_sach("TRAM_TAT:%s" % ma, 100), "loai": "CHUA_RO_KET_QUA", "muc": "NANG", "mo_ta": ly_do}], "tep": []}
            T.ghi_ket_qua(ch, kq)
            os.replace(duong, ch.tm("xong", ten))
            T.ghi_log(ch, "%s: lệnh dở từ lần chạy trước của trạm - đã trả kết quả CHƯA RÕ KẾT QUẢ (cần người), không chạy lại" % ma)
            n += 1
        except Exception as e:
            T.ghi_log(ch, "%s: không dọn được lệnh dở (%s) - để lại" % (ma, type(e).__name__))
    return n


# 26/11/2026: lenh toi khi cua so XII /tram con o man dang nhap / man khac -> VB tu choi NGAY, TRUOC khi ghi
# ("UNESCO XII đang mở màn hình khác (frmSqlConnection) ..."). Truoc day ca chuoi bao LOI ngay (THANH_PHU_2026 22:22).
# Gui lai sau GIAY_CHO_MAN_KHAC giay, toi da PHUT_CHO_MAN_KHAC phut; tep dung tram -> thoi cho. Chi ap cho dung loi nay.
_DAU_MAN_KHAC = "đang mở màn hình khác"
GIAY_CHO_MAN_KHAC = 30
PHUT_CHO_MAN_KHAC = 15


def _gui_vb_cho_san_sang(ch, lenh, buoc, ten, bao=None, ngu=time.sleep, gio=time.time):
    het = gio() + PHUT_CHO_MAN_KHAC * 60
    lan = 0
    while True:
        ket_qua = _YEU_CAU_VB_GOC(ch, lenh, buoc, ten, bao)
        b = ket_qua[0]
        if not isinstance(b, dict) or b.get("trang_thai") != "LOI" or _DAU_MAN_KHAC not in str(b.get("loi") or ""):
            return ket_qua
        if gio() + GIAY_CHO_MAN_KHAC > het or os.path.isfile(ch.tm("tram", ch.tram + ".dung")):
            b["loi"] = ("%s Đã chờ %d lần, XII vẫn chưa sẵn sàng." % (b["loi"], lan))[:500]
            return ket_qua
        lan += 1
        if lan == 1:
            T.ghi_log(ch, "%s: %s - XII chưa sẵn sàng (đang ở màn hình khác), chờ %d giây rồi gửi lại (tối đa %d phút)"
                      % (lenh.get("lenh"), buoc, GIAY_CHO_MAN_KHAC, PHUT_CHO_MAN_KHAC))
        if bao:
            bao(buoc)
        ngu(GIAY_CHO_MAN_KHAC)


def yeu_cau_vb(ch, lenh, buoc, duong_so, bao=None):
    """P2: buoc can GHI so -> cua so "Tram ERP" trong UNESCO XII (Modules\\AiErpStation.vb, giao thuc LENH\\tram\\vb\\ nhu GD349).
    Tep yeu cau mang TEN CSDL (so=<CSDL>), khong phai duong dan ban chup tam. Ghi xong thi chup LAI so de cac buoc chi doc ve sau doc dung so
    da ghi (neu khong, ban chup truoc / sau cua phan_tich se khac nhau va F09 coi la 'so bi sua trong luc kiem')."""
    ten = SNAP.get(duong_so)
    if not ten:
        return {"ten": buoc, "trang_thai": "LOI", "loi": "không biết tên CSDL của sổ để giao cho trạm ghi"}, []
    # KT_BOT (17/11/2026, kiem tra ROBOT, diem H3): mot buoc ghi truoc do cua lenh nay CHUA RO KET QUA -> khong giao them buoc ghi nao nua
    if lenh.get(_KHOA_CHUA_RO) and buoc in BUOC_GHI_SO:
        return {"ten": buoc, "trang_thai": "BO_QUA", "ly_do": "Bước ghi trước của lệnh này chưa rõ kết quả (%s) - không ghi tiếp cho tới khi kế toán kiểm sổ" % lenh[_KHOA_CHUA_RO]}, []
    ket_qua = _chua_ro_ket_qua(lenh, buoc, _gui_vb_cho_san_sang(ch, lenh, buoc, ten, bao))
    if ket_qua[0] is not None and buoc in BUOC_GHI_SO:       # trạm ghi đã trả lời: sổ có thể đã đổi
        tam = duong_so + ".moi"
        ok, loi_chup = chup_so(ten, tam)
        try:
            if ok:
                os.replace(tam, duong_so)
        except OSError as e:
            ok, loi_chup = False, type(e).__name__
        finally:
            _xoa(tam)
            SNAP[duong_so] = ten
        doc_lai_sau_ghi(duong_so, ok, loi_chup)     # TASK381: report the book as written, not the analysis from before
    return ket_qua


T.tim_so = tim_so
T.PHAN_TICH = phan_tich
T.lam_lenh = lam_lenh
T.yeu_cau_vb = yeu_cau_vb

# V0095 - CHUOI NGHIEP VU THANG: khuon v1 cua ERP them 5 buoc ghi so (so_phu, phan_bo, trich_luong, gia_thanh, khoa_so); cung voi tai_hd,
# ket_chuyen, bao_cao deu giao cho tram ghi VB (AiMonthChain.vb). Them vao danh sach cua erp_khuon / erp_tram O DAY (cac tep XI giu nguyen
# chot bam). Thu tu chay = thu tu ERP luu trong lenh (usp_CreateCommand V0095).
# DOT1 17/11/2026 (kiem tra robot, diem B-4): them tong_hop (ERP V0103; AiMonthChain.vb da lam buoc nay). Truoc day lenh co tong_hop - vd "Chay tron
# thang" / "Tong hop lai" tren dien thoai - bi tu choi CA LENH (LENH_SAI_KHUON) vi buoc khong co trong khuon cua tram.
BUOC_CHUOI = ("so_phu", "phan_bo", "trich_luong", "tong_hop", "gia_thanh", "khoa_so")
KH.BUOC_V1 = tuple(KH.BUOC_V1) + tuple(b for b in BUOC_CHUOI if b not in KH.BUOC_V1)
T.BUOC_VB = tuple(T.BUOC_VB) + tuple(b for b in BUOC_CHUOI if b not in T.BUOC_VB)
BUOC_GHI_SO = ("tai_hd", "phan_tich", "ghi_trong_nguong", "ket_chuyen", "bao_cao") + BUOC_CHUOI   # sau cac buoc nay chup lai so


def don_chup_cu(data):
    """Tep chup bo quen (tram bi tat giua chung) cu hon GIAY_TEP_CU: xoa."""
    try:
        for f in os.listdir(data):
            if f.endswith(HAU_TO_CHUP) or f.endswith(HAU_TO_CHUP + ".sau") or f.endswith(HAU_TO_CHUP + ".tmp"):
                p = os.path.join(data, f)
                if time.time() - os.path.getmtime(p) > GIAY_TEP_CU:
                    os.remove(p)
    except OSError:
        pass


def _doc_cau_hinh_tho(duong):
    with io.open(duong, "r", encoding="utf-8-sig") as f:
        return json.load(f)


def lam_mot_lenh_host(t):
    """G2.1 (giao dien chung): host ghi UNESCO XII goi tram o che do mot lenh cho cac buoc CHI DOC (kiem_tra, doi_chieu, sua_chung_tu),
    kem HO SO so (/ho_so:"<tep>", khuon v1.1 nhu LENH\\ho_so) de doi chieu nam / che do va ap tham so quy tac ERP giao - dung lam_lenh
    nhu khi chay qua hop thu. Buoc ghi so khong bao gio di duong nay (host lam). Ket qua ghi vao /ra, ma thoat 0 = co ket qua dung khuon."""
    lenh = T.doc_json(t["lenh"])
    loi = KH.kiem_lenh(lenh)
    if loi:
        print("Lenh sai khuon: " + "; ".join(loi))
        return 2
    sai = [b for b in lenh.get("buoc") or [] if b not in ("kiem_tra", "doi_chieu", "sua_chung_tu")]
    if sai:
        print("Che do host chi lam buoc chi doc, lenh co: " + ", ".join(sai))
        return 2
    ho_so = None
    if t.get("ho_so"):
        try:
            ho_so = T.doc_json(t["ho_so"])
        except (OSError, ValueError) as e:
            print("Ho so khong doc duoc: %s" % type(e).__name__)
            return 2
    ch = T.CauHinh({"lenh": os.path.join(HERE, "ket-qua", "erp_tram_thu"), "data": t.get("data") or HERE, "tram": t.get("tram") or "HOST_XII"})
    duong, loi_so = tim_so(ch.data, lenh["so"])
    kq = lam_lenh(ch, lenh, duong, None, ho_so=ho_so)
    if loi_so:
        kq["viec_can_nguoi"].insert(0, {"loai": "KHONG_THAY_SO", "mo_ta": loi_so})
    loi = KH.kiem_ket_qua(kq)
    T.ghi_json_nguyen_tu(t["ra"], kq)
    print("Da ghi %s: trang_thai=%s loi_khuon=%s" % (t["ra"], kq["trang_thai"], loi or "khong"))
    return 0 if not loi else 3


def main(argv=None):
    argv = list(argv or sys.argv)
    t = T._ts(argv)
    if t.get("may_chu"):
        MAY_CHU[0] = t["may_chu"]
    if t.get("lenh") and t.get("ra") and t.get("che_do") == "host":
        return lam_mot_lenh_host(t)
    if t.get("cau_hinh"):
        try:
            tho = _doc_cau_hinh_tho(t["cau_hinh"])
        except (OSError, ValueError) as e:
            print("Cau hinh khong doc duoc: %s" % type(e).__name__)
            return 2
        if tho.get("may_chu_sql") and not t.get("may_chu") and not os.environ.get("XII_TRAM_MAY_CHU"):
            MAY_CHU[0] = str(tho["may_chu_sql"])
        try:
            ch = T.doc_cau_hinh(t["cau_hinh"])
        except (OSError, ValueError) as e:
            print("Cau hinh sai: %s" % e)
            return 2
        if t.get("dung"):
            T.tao_thu_muc(ch)
            with io.open(ch.tm("tram", ch.tram + ".dung"), "w", encoding="utf-8") as f:
                f.write("dung\n")
            print("Da tao %s - tram se dung sau lenh dang lam." % ch.tm("tram", ch.tram + ".dung"))
            return 0
        don_chup_cu(ch.data)
        if not t.get("mot"):
            try:
                T.tao_thu_muc(ch)
                don_lenh_do(ch)
            except Exception:
                pass
    if t.get("mot") and not os.path.isfile(t["mot"]):
        tam = os.path.join(HERE, "ket-qua", "tram_xii_chup")
        duong, loi = tim_so(tam, t["mot"])
        if loi:
            print(loi)
            return 2
        argv = [a for a in argv if not a.lower().startswith("/mot:")] + ['/mot:' + duong]
        try:
            return T.main(argv)
        finally:
            _xoa(duong)
    return T.main(argv)


if __name__ == "__main__":
    sys.exit(main())
