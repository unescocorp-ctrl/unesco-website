# -*- coding: utf-8 -*-
"""GD368 - KIEM SOAT NVL AM / DINH MUC / LAI LO GIA VON - GIA BAN (chi doc .MDB, khong ghi). Dung chung moi bo so san xuat.
Dua tren gia_thanh_phuong_an (GD350) chay 3 thang gan nhat:
  A. NVL am / xuat thieu -> tim nguon nhap bu: hoa don mua NVL da tai ve chua hach toan (HDDTTaiVe cung ma vat tu), ma cung ten
     con ton duong (de xuat gop), con lai -> ke hoach mua. Khong tu tao phieu; VB ghi khi tin cay >= 90 va bat tu ghi.
  B. Dinh muc thuc te: he so = xuat thuc (DM + tay) / nhu cau theo DM, chi thang 'sach' (co phieu, khong am, khong xuat thieu);
     lech > nguong 2 thang lien tiep -> DM_LECH kem he so de xuat (nguoi duyet). KCTP vuot NVL: nhu cau DM > xuat + ton dau -> KCTP_VUOT.
  C. Lai lo 3 gia: gia thanh thang, gia thanh BQ 3 thang, gia ban BQ 3 thang (Co 511 / so luong). Nhan LO_THANG (1 thang, do phan bo),
     LO_THAT (BQ 3 thang), GIA_CONG (gia thanh ~ gia ban +-2 %), so-level LO_CO_CAU (>= 60 % TP LO_THAT). Gia san = gia thanh BQ x
     (1 + chi phi 641/642 3 thang / doanh thu 3 thang). Khach mua duoi gia san (Co 511 theo MaKH).
Ra: ket-qua\\gia_thanh_kiem_soat.txt (TONG / NB / LL / GS / KH / DM / KV) + .html."""
import html
import io
import os
import re
from collections import defaultdict

import gia_thanh_phuong_an as G

TEP = "gia_thanh_kiem_soat"
NGUONG_GIA_CONG = 0.02
NGUONG_CO_CAU = 0.6
SO_THANG = 3


def _s(x):
    return str(x if x is not None else "").strip()


def doc_them(duong):
    import jet_doc
    m = jet_doc.Mdb(duong)
    try:
        bang = {b.lower(): b for b in m.bang()}

        def tb(t):
            k = bang.get(t.lower())
            return m.doc(k) if k else []
        hd = [{k: r.get(k) for k in ("MaCT", "MaVT", "SoLuong", "DonGia", "NgayLap", "MaCTKeToan", "MaSoLoaiCT", "SoHoaDon", "TenNguoiBanNguoiXuatHang", "TenHangHoaDichVu", "DonViTinh", "HDBanRa")}
              for r in tb("HDDTTaiVe")]
        return {"hd": hd, "kh": {r["MaSo"]: _s(r.get("SoHieu")) for r in tb("KhachHang")}}
    finally:
        try:
            m.dong()
        except Exception:
            pass


def _khoa(d, ten):
    try:
        import bang_luong_gd78 as B
        return B.khoa_ten(G._u(d, ten))
    except Exception:
        return re.sub(r"\s+", " ", G._u(d, ten)).upper().strip()


def _ton_thang(d, thang):
    ton = defaultdict(float)
    for r in d["ton"]:
        ton[G._i(r.get("MaVatTu"))] += G._f(r.get("Luong_%d" % thang)) if thang >= 1 else G._f(r.get("Luong_0"))
    return ton


# ------------------------------------------------------------------ A. nhap bu
def nhap_bu(d, dt, thang, kq):
    th_lich, nam = G.thang_lich(d, thang)
    out = []
    # ma cung ten con ton duong
    khoa_vt = defaultdict(list)
    for ma, v in d["vt"].items():
        khoa_vt[(_khoa(d, v.get("TenVattu")), _s(v.get("DonVi")).upper())].append(ma)
    ton = _ton_thang(d, thang)
    for x in kq["nvl"]:
        if not (x["am"] or x["tinh"] == "XUAT_THIEU"):
            continue
        thieu = max(-x["ton"], x["nhu_cau"] - x["xuat_dm"] if x["tinh"] == "XUAT_THIEU" else 0.0)
        if thieu <= 0:
            continue
        v = d["vt"].get(x["ma"]) or {}
        # 1. ma cung ten + DVT con ton duong -> gop ma
        anh_em = [m for m in khoa_vt.get((_khoa(d, v.get("TenVattu")), _s(v.get("DonVi")).upper()), []) if m != x["ma"] and ton.get(m, 0) > 0]
        if anh_em:
            m = anh_em[0]
            out.append({"sh": x["sh"], "thieu": thieu, "dvt": x["dvt"], "nguon": "GOP_MA", "sl": ton[m], "gia": 0.0, "so_hd": _s((d["vt"].get(m) or {}).get("SoHieu")),
                        "tin_cay": 85, "ghi": "ma %s cung ten + DVT con ton %s - gop ma truoc khi mua" % (_s((d["vt"].get(m) or {}).get("SoHieu")), G._sl(ton[m]))})
            continue
        # 2. hoa don mua NVL da tai ve, chua hach toan, cung ma vat tu, ngay trong thang nay / thang truoc / thang sau
        ung = []
        for h in dt["hd"]:
            if h.get("HDBanRa") or _s(h.get("MaSoLoaiCT")) == "8":
                continue
            if _s(h.get("MaVT")).upper() != x["sh"].upper():
                # chua ghep ma: so ten hang hoa don voi ten vat tu (khoa ten), cung DVT
                if _s(h.get("MaVT")) or _khoa(d, h.get("TenHangHoaDichVu")) != _khoa(d, v.get("TenVattu")) or _s(h.get("DonViTinh")).upper() != x["dvt"].upper():
                    continue
                h["_theo_ten"] = True
            if _s(h.get("MaCTKeToan")) not in ("", "0"):
                continue
            ng = G._dt.datetime.fromisoformat(str(h["NgayLap"])[:10]) if h.get("NgayLap") else None
            if ng is None or abs((ng.year - nam) * 12 + ng.month - th_lich) > 1:
                continue
            ung.append(h)
        if ung:
            sl = sum(G._f(h.get("SoLuong")) for h in ung)
            gia = G._f(sorted(ung, key=lambda h: str(h.get("NgayLap")))[-1].get("DonGia"))
            so_hd = ", ".join(sorted({_s(h.get("SoHoaDon")).lstrip("0") for h in ung})[:4])
            out.append({"sh": x["sh"], "thieu": thieu, "dvt": x["dvt"], "nguon": "HOA_DON", "sl": sl, "gia": gia, "so_hd": so_hd,
                        "tin_cay": (92 if sl >= thieu * 0.999 else 80) - (10 if any(h.get("_theo_ten") for h in ung) else 0),
                        "ghi": "%d hoa don mua %s %s chua hach toan (%s) - lap phieu nhap (hang ve truoc hoa don sau) roi hach toan" % (len(ung), G._sl(sl), x["dvt"], so_hd)})
            continue
        out.append({"sh": x["sh"], "thieu": thieu, "dvt": x["dvt"], "nguon": "MUA", "sl": 0.0, "gia": 0.0, "so_hd": "", "tin_cay": 0,
                    "ghi": "khong co hoa don mua chua hach toan - kiem phieu nhap / sai ma, hoac ke hoach mua"})
    return out


# ------------------------------------------------------------------ B. dinh muc thuc te + KCTP vuot
def kctp_vuot(d, thang, kq):
    """KCTP vuot NVL cua MOT thang: nhu cau DM > xuat thuc + ton dau thang (ton cuoi thang truoc)."""
    nguong = (G._f(d["tsgt"].get("NguongLechNVL")) or G.NGUONG_LECH_NVL) / 100.0
    ton_dau = _ton_thang(d, thang - 1)
    vuot = []
    for x in kq["nvl"]:
        co_the = x["xuat_dm"] + x["xuat_tay"] + max(0.0, ton_dau.get(x["ma"], 0.0))
        if x["nhu_cau"] > 0 and x["nhu_cau"] > co_the * (1 + nguong) + 1e-6:
            vuot.append({"thang": thang, "sh": x["sh"], "dvt": x["dvt"], "nhu_cau": x["nhu_cau"], "co_the": co_the, "thieu": x["nhu_cau"] - co_the})
    return vuot


def dinh_muc(d, thang, cache):
    nguong = (G._f(d["tsgt"].get("NguongLechNVL")) or G.NGUONG_LECH_NVL) / 100.0
    he_so = defaultdict(dict)          # nvl -> {thang: he so}
    sach = {}
    for t in range(max(1, thang - SO_THANG + 1), thang + 1):
        if t not in cache:
            continue
        kq = cache[t]
        s = bool(kq["tong"]["so_phieu"]) and not any(x["am"] or x["tinh"] == "XUAT_THIEU" for x in kq["nvl"])
        sach[t] = s
        if not s:
            continue
        for x in kq["nvl"]:
            if x["nhu_cau"] > 0:
                he_so[x["ma"]][t] = (x["xuat_dm"] + x["xuat_tay"]) / x["nhu_cau"]
    ds = []
    for ma, hs in he_so.items():
        ts = sorted(hs)
        lech = [t for t in ts if abs(hs[t] - 1.0) > nguong]
        # lech o thang nay va o thang sach lien truoc (2 thang lien tiep cung chieu)
        if thang in lech and len(ts) >= 2 and ts[-2] in lech and (hs[thang] - 1) * (hs[ts[-2]] - 1) > 0:
            sh, ten, dvt = G._ten_vt(d, ma)
            bq = sum(hs[t] for t in ts) / len(ts)
            ds.append({"sh": sh, "ten": ten, "he_so": bq, "thang": ",".join(str(G.thang_lich(d, t)[0]) for t in lech), "pct": (bq - 1) * 100,
                       "de_xuat": "nhan dinh muc cac TP dung %s voi %.3f (thuc te %+.1f%% so voi dinh muc, %d thang sach)" % (sh, bq, (bq - 1) * 100, len(ts))})
    return ds, kctp_vuot(d, thang, cache[thang]), sach


# ------------------------------------------------------------------ C. lai lo 3 gia + gia san
def lai_lo(d, dt, thang, cache):
    tk = d["tk"]
    thangs = [t for t in range(max(1, thang - SO_THANG + 1), thang + 1)]
    gom = defaultdict(lambda: {"gt": 0.0, "sl": 0.0, "dt": 0.0, "sl_ban": 0.0, "lo": 0, "co": 0, "gt_thang": 0.0, "gia_ban_thang": None, "sh": "", "ten": "", "dvt": "", "gc": []})
    for t in thangs:
        if t not in cache:
            continue
        for x in cache[t]["tp"]:
            g = gom[x["ma"]]
            g["gt"] += x["gt"]; g["sl"] += x["sl"]; g["dt"] += x["dt_thang"]; g["sl_ban"] += x["sl_ban"] or 0
            g["co"] += 1
            if x["nx"] == "LO":
                g["lo"] += 1
            g["gc"].append(x["gia_ban"] is not None and x["gt_dv"] > 0 and abs(x["gia_ban"] - x["gt_dv"]) <= NGUONG_GIA_CONG * x["gia_ban"])
            if t == thang:
                g["gt_thang"] = x["gt_dv"]; g["gia_ban_thang"] = x["gia_ban"]
            g["sh"], g["ten"], g["dvt"] = x["sh"], x["ten"], x["dvt"]
    # chi phi ban hang + QLDN va doanh thu 3 thang -> ty le gia san; gia ban theo khach
    cp, dt_tong = 0.0, 0.0
    ban_kh = defaultdict(lambda: [0.0, 0.0])
    for r in d["ct"]:
        t = G._i(r.get("ThangCT"))
        if t not in thangs:
            continue
        no, co = tk.get(r.get("MaTKNo"), ""), tk.get(r.get("MaTKCo"), "")
        if no.startswith(("641", "642", "6421", "6422")) and not co.startswith("911"):
            cp += G._f(r.get("SoPS"))
        if co.startswith("511") and not no.startswith("911"):
            dt_tong += G._f(r.get("SoPS"))
            mv = G._i(r.get("MaVattu")); kh = G._i(r.get("MaKH"))
            if mv and kh:
                b = ban_kh[(mv, kh)]
                b[0] += G._f(r.get("SoPS")); b[1] += G._f(r.get("SoPS2Co")) or G._f(r.get("SoPS2No"))
    ty_le_cp = (cp / dt_tong) if dt_tong > 0 else 0.0
    ds, n_lo_that, n_tp = [], 0, 0
    for ma, g in sorted(gom.items(), key=lambda kv: -kv[1]["gt"]):
        if g["sl"] <= 0:
            continue
        n_tp += 1
        gt_bq = g["gt"] / g["sl"]
        gia_ban_bq = (g["dt"] / g["sl_ban"]) if g["sl_ban"] > 0 else None
        gia_san = gt_bq * (1 + ty_le_cp)
        loai = ""
        if gia_ban_bq is None:
            loai = "CHUA_CO_GIA_BAN"
        elif g["co"] >= 3 and all(g["gc"]):
            loai = "GIA_CONG"          # gia thanh ~ gia ban moi thang lien tiep 3 thang: gia cong / chuyen gia, khong bao lo
        elif gia_ban_bq < gt_bq:
            loai = "LO_THAT"; n_lo_that += 1
        elif g["gia_ban_thang"] is not None and g["gt_thang"] > g["gia_ban_thang"]:
            loai = "LO_THANG"
        elif gia_ban_bq < gia_san:
            loai = "DUOI_GIA_SAN"
        ds.append({"ma": ma, "sh": g["sh"], "ten": g["ten"], "dvt": g["dvt"], "gt_thang": g["gt_thang"], "gt_bq": gt_bq, "gia_ban_bq": gia_ban_bq,
                   "gia_ban_thang": g["gia_ban_thang"], "gia_san": gia_san, "loai": loai, "thang_lo": g["lo"], "so_thang": g["co"], "sl_3t": g["sl"]})
    co_cau = n_tp > 0 and n_lo_that >= NGUONG_CO_CAU * n_tp and n_tp >= 5
    # khach mua duoi gia san (3 thang)
    gs = {x["ma"]: x for x in ds}
    kh_duoi = []
    for (mv, kh), (tien, sl) in ban_kh.items():
        if sl > 0 and mv in gs and gs[mv]["loai"] not in ("GIA_CONG", "CHUA_CO_GIA_BAN"):
            gia = tien / sl
            if gia < gs[mv]["gia_san"] * 0.999:
                kh_duoi.append({"sh": gs[mv]["sh"], "ma_kh": dt["kh"].get(kh, str(kh)), "gia_ban": gia, "gia_san": gs[mv]["gia_san"], "gia_von": gs[mv]["gt_bq"], "sl": sl, "tien": tien})
    kh_duoi.sort(key=lambda x: (x["gia_ban"] - x["gia_san"]) * x["sl"])
    return ds, {"ty_le_cp": ty_le_cp, "cp_3t": cp, "dt_3t": dt_tong, "lo_that": n_lo_that, "so_tp": n_tp, "co_cau": co_cau}, kh_duoi


# ------------------------------------------------------------------ chay / ghi
def phan_tich(duong, thang=0, tu=0):
    """thang = thang thu tu nam TC phan tich (0 = thang co phieu gan nhat); tu = tu thang (KCTP vuot kiem tung thang tu..thang cho AI_AUTO)."""
    d = G.doc(duong)
    dt = doc_them(duong)
    if not thang:
        thang = G.thang_moi_nhat(d)
    if not thang:
        return None
    dau = max(1, min(thang - SO_THANG + 1, tu or thang))
    cache = {t: G.phan_tich(d, t) for t in range(dau, thang + 1)}
    nb = nhap_bu(d, dt, thang, cache[thang])
    dm, vuot, sach = dinh_muc(d, thang, cache)
    if tu and tu < thang:
        vuot = [v for t in range(tu, thang + 1) for v in kctp_vuot(d, t, cache[t])]
    ll, tong_ll, kh = lai_lo(d, dt, thang, cache)
    kiem = []
    if tong_ll["co_cau"]:
        kiem = ["gia ban ghi so (Co 511 da tru VAT, chiet khau / giam gia 521?)", "gia NVL mua ky nay so ky truoc (bang NVL)", "dinh muc NVL / TP so voi thuc te (he so B)"]
    return {"so": os.path.basename(duong), "ten": G._u(d, d["lic"].get("TenCty")), "thang": thang, "thang_lich": G.thang_lich(d, thang)[0],
            "nhap_bu": nb, "dinh_muc": dm, "kctp_vuot": vuot, "sach": sach, "lai_lo": ll, "tong_ll": tong_ll, "kh_duoi": kh, "kiem_co_cau": kiem}


def _r(x):
    return "" if x is None else ("%.4f" % x).rstrip("0").rstrip(".")


def ghi(kq, thu_muc):
    os.makedirs(thu_muc, exist_ok=True)
    p = os.path.join(thu_muc, TEP + ".txt")
    L = ["TONG;%s;%d;%d;%d;%d;%d;%d;%d;%s" % (kq["so"], kq["thang"], len(kq["nhap_bu"]), kq["tong_ll"]["lo_that"], 1 if kq["tong_ll"]["co_cau"] else 0,
                                             len(kq["dinh_muc"]), len(kq["kctp_vuot"]), len(kq["kh_duoi"]), _r(kq["tong_ll"]["ty_le_cp"]))]
    for x in kq["nhap_bu"]:
        L.append("NB;%s;%s;%s;%s;%s;%s;%s;%d;%s" % (x["sh"], _r(x["thieu"]), x["dvt"], x["nguon"], _r(x["sl"]), _r(x["gia"]), x["so_hd"], x["tin_cay"], x["ghi"].replace(";", ",")))
    for x in kq["lai_lo"]:
        L.append("LL;%s;%s;%s;%s;%s;%s;%s;%d;%d" % (x["sh"], _r(x["gt_thang"]), _r(x["gt_bq"]), _r(x["gia_ban_bq"]), _r(x["gia_ban_thang"]), _r(x["gia_san"]), x["loai"], x["thang_lo"], x["so_thang"]))
        L.append("GS;%s;%s;%s" % (x["sh"], _r(x["gia_san"]), _r(x["gt_bq"])))
    for x in kq["kh_duoi"][:300]:
        L.append("KH;%s;%s;%s;%s;%s;%s" % (x["sh"], x["ma_kh"], _r(x["gia_ban"]), _r(x["gia_san"]), _r(x["gia_von"]), _r(x["sl"])))
    for x in kq["dinh_muc"]:
        L.append("DM;%s;%s;%s;%s" % (x["sh"], _r(x["he_so"]), x["thang"], x["de_xuat"].replace(";", ",")))
    for x in kq["kctp_vuot"]:
        L.append("KV;%d;%s;%s;%s;%s;%s" % (x["thang"], x["sh"], x["dvt"], _r(x["nhu_cau"]), _r(x["co_the"]), _r(x["thieu"])))
    with io.open(p, "w", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")
    with io.open(os.path.join(thu_muc, TEP + ".html"), "w", encoding="utf-8") as f:
        f.write(_html(kq))
    return p


def _html(kq):
    e = html.escape
    o = ["<!DOCTYPE html><html lang='vi'><head><meta charset='utf-8'><title>Kiểm soát NVL - định mức - lãi lỗ</title>",
         "<style>body{font-family:Segoe UI,Arial;font-size:13px;margin:16px}h1{font-size:18px;color:#022452}h2{font-size:15px;margin:18px 0 6px}table{border-collapse:collapse;width:100%}",
         "th,td{border:1px solid #d5dbe3;padding:4px 6px;vertical-align:top}th{background:#eef3fa;text-align:left}td.n{text-align:right;white-space:nowrap}.lo{color:#b00}.ok{color:#070}.vua{color:#a60}</style></head><body>",
         "<h1>Kiểm soát NVL âm – định mức – lãi lỗ: %s</h1><p>Sổ %s, tháng %d (3 tháng gần nhất). Máy chỉ đọc số sổ.</p>" % (e(kq["ten"]), e(kq["so"]), kq["thang_lich"])]
    t = kq["tong_ll"]
    o.append("<h2>C. Lãi lỗ theo thành phẩm (giá thành tháng / BQ 3 tháng / giá bán BQ 3 tháng / giá sàn)</h2>")
    o.append("<p>Tỷ lệ chi phí bán hàng + QLDN trên doanh thu 3 tháng: <b>%.1f%%</b> (%s / %s) → giá sàn = giá thành BQ × %.3f. %s</p>" % (
        t["ty_le_cp"] * 100, G._dd(t["cp_3t"]), G._dd(t["dt_3t"]), 1 + t["ty_le_cp"],
        ("<b class='lo'>LỖ CƠ CẤU: %d/%d thành phẩm lỗ thật 3 tháng – kiểm: %s</b>" % (t["lo_that"], t["so_tp"], "; ".join(kq["kiem_co_cau"]))) if t["co_cau"] else "%d thành phẩm lỗ thật / %d" % (t["lo_that"], t["so_tp"])))
    o.append("<table><tr><th>Mã</th><th>Tên</th><th>ĐVT</th><th>GT tháng</th><th>GT BQ 3T</th><th>Giá bán BQ 3T</th><th>Giá sàn</th><th>Tháng lỗ</th><th>Nhận xét</th></tr>")
    mau = {"LO_THAT": "lo", "LO_THANG": "vua", "DUOI_GIA_SAN": "vua", "GIA_CONG": "", "CHUA_CO_GIA_BAN": "", "": "ok"}
    for x in kq["lai_lo"][:200]:
        o.append("<tr><td>%s</td><td>%s</td><td>%s</td><td class='n'>%s</td><td class='n'>%s</td><td class='n'>%s</td><td class='n'>%s</td><td class='n'>%d/%d</td><td class='%s'>%s</td></tr>" % (
            e(x["sh"]), e(x["ten"][:40]), e(x["dvt"]), G._dd(x["gt_thang"]), G._dd(x["gt_bq"]), G._dd(x["gia_ban_bq"]) if x["gia_ban_bq"] is not None else "-", G._dd(x["gia_san"]), x["thang_lo"], x["so_thang"], mau.get(x["loai"], ""), e(x["loai"] or "ĐẠT")))
    o.append("</table>")
    if kq["kh_duoi"]:
        o.append("<h2>Khách mua dưới giá sàn (3 tháng)</h2><table><tr><th>Mã TP</th><th>Khách</th><th>Giá bán</th><th>Giá sàn</th><th>Giá vốn BQ</th><th>Số lượng</th></tr>")
        for x in kq["kh_duoi"][:100]:
            o.append("<tr><td>%s</td><td>%s</td><td class='n %s'>%s</td><td class='n'>%s</td><td class='n'>%s</td><td class='n'>%s</td></tr>" % (
                e(x["sh"]), e(x["ma_kh"]), "lo" if x["gia_ban"] < x["gia_von"] else "vua", G._dd(x["gia_ban"]), G._dd(x["gia_san"]), G._dd(x["gia_von"]), G._sl(x["sl"])))
        o.append("</table>")
    o.append("<h2>A. NVL âm / xuất thiếu – nguồn nhập bù</h2>")
    if kq["nhap_bu"]:
        o.append("<table><tr><th>NVL</th><th>Thiếu</th><th>Nguồn</th><th>SL nguồn</th><th>Giá</th><th>Hoá đơn / mã</th><th>Tin cậy</th><th>Việc</th></tr>")
        for x in kq["nhap_bu"]:
            o.append("<tr><td>%s</td><td class='n'>%s %s</td><td>%s</td><td class='n'>%s</td><td class='n'>%s</td><td>%s</td><td class='n'>%d</td><td>%s</td></tr>" % (
                e(x["sh"]), G._sl(x["thieu"]), e(x["dvt"]), e(x["nguon"]), G._sl(x["sl"]), G._dd(x["gia"]) if x["gia"] else "-", e(x["so_hd"]), x["tin_cay"], e(x["ghi"])))
        o.append("</table>")
    else:
        o.append("<p class='ok'>Không có NVL âm / xuất thiếu tháng này.</p>")
    o.append("<h2>B. Định mức: thực tế so với khai (tháng sạch - thứ tự năm TC: %s)</h2>" % (", ".join(str(t) for t, s in sorted(kq["sach"].items()) if s) or "không có"))
    if kq["dinh_muc"]:
        o.append("<table><tr><th>NVL</th><th>Hệ số thực/ĐM</th><th>Lệch %</th><th>Tháng lệch</th><th>Đề xuất (người duyệt)</th></tr>")
        for x in kq["dinh_muc"]:
            o.append("<tr><td>%s</td><td class='n'>%.3f</td><td class='n'>%+.1f</td><td>%s</td><td>%s</td></tr>" % (e(x["sh"]), x["he_so"], x["pct"], e(x["thang"]), e(x["de_xuat"])))
        o.append("</table>")
    else:
        o.append("<p class='ok'>Không có NVL lệch định mức 2 tháng liên tiếp (hoặc chưa đủ tháng sạch).</p>")
    if kq["kctp_vuot"]:
        o.append("<h2 class='lo'>KCTP vượt NVL (sản lượng × định mức &gt; NVL xuất + tồn đầu) – không được ghi phiếu</h2><table><tr><th>NVL</th><th>Nhu cầu ĐM</th><th>Có thể xuất</th><th>Thiếu</th></tr>")
        for x in kq["kctp_vuot"]:
            o.append("<tr><td>T%d %s</td><td class='n'>%s</td><td class='n'>%s</td><td class='n lo'>%s %s</td></tr>" % (x["thang"], e(x["sh"]), G._sl(x["nhu_cau"]), G._sl(x["co_the"]), G._sl(x["thieu"]), e(x["dvt"])))
        o.append("</table>")
    o.append("</body></html>")
    return "".join(o)


def chay(duong, thu_muc, thang=0, tu=0):
    kq = phan_tich(duong, thang, tu)
    if kq is None:
        return None, ""
    return kq, ghi(kq, thu_muc)


if __name__ == "__main__":
    import sys
    kq, p = chay(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else ".", int(sys.argv[3]) if len(sys.argv) > 3 else 0)
    if kq:
        print(kq["so"], "thang", kq["thang"], "nhap bu", len(kq["nhap_bu"]), "lo that", kq["tong_ll"]["lo_that"], "/", kq["tong_ll"]["so_tp"], "co cau", kq["tong_ll"]["co_cau"],
              "DM lech", len(kq["dinh_muc"]), "KCTP vuot", len(kq["kctp_vuot"]), "KH duoi san", len(kq["kh_duoi"]), "ty le cp %.3f" % kq["tong_ll"]["ty_le_cp"])
        for x in kq["nhap_bu"][:6]:
            print("  NB", x["sh"], G._sl(x["thieu"]), x["nguon"], x["tin_cay"], x["ghi"])
        for x in kq["dinh_muc"][:6]:
            print("  DM", x["sh"], "%.3f" % x["he_so"], x["thang"])
        for x in kq["kctp_vuot"][:6]:
            print("  KV", x["sh"], G._sl(x["nhu_cau"]), G._sl(x["co_the"]))
        from collections import Counter
        print("  LL", Counter(x["loai"] or "DAT" for x in kq["lai_lo"]))
        for x in kq["kh_duoi"][:5]:
            print("  KH", x["sh"], x["ma_kh"], G._dd(x["gia_ban"]), "san", G._dd(x["gia_san"]))
