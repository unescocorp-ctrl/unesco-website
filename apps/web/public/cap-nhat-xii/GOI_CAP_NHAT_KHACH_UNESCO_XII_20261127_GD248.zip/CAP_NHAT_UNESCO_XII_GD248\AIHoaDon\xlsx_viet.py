# -*- coding: utf-8 -*-
"""GD78 - VIET TEP XLSX CO DINH DANG (khong can openpyxl / Excel): font, nen, khung, can le, xuong dong, dinh dang so,
gop o, do rong cot, chieu cao dong, co dinh dong / cot, trang in (A4 doc / ngang, vua mot trang ngang, lap dong tieu de),
cong thuc (chuoi bat dau '='). Dung chung cho cac bao cao GD78 (bao_cao_nam, thuyet_minh_b09, qtt_tncn, so_sach_mau).
GD79 (doi_chieu_luong): CT(cong_thuc, gia_tri) = cong thuc kem GIA TRI DA TINH (xem truoc / may khong tinh lai van thay so),
ten vung (wb.ten("TS_BHXH", "ThamSo!$C$5")), loc du lieu (ws.loc), to mau co dieu kien (ws.to_mau),
GD134: danh sach tha xuong (ws.chon_ds(r1, c1, r2, c2, "DanhMuc!$A$2:$A$20")), dinh dang o chu so="@",
Chu("=...") = chuoi hien nguyen van (khong phai cong thuc).

    from xlsx_viet import SoExcel
    wb = SoExcel()
    k_td = wb.kieu(dam=True, co=14, can="giua")
    ws = wb.sheet("B01a", cot=[6, 52, 8, 10, 18, 18])
    ws.gop(1, 1, 1, 6, "BÁO CÁO TÌNH HÌNH TÀI CHÍNH", k_td)
    ws.o(5, 5, 123456789, wb.kieu(so="#,##0;(#,##0);\\"-\\"", khung=True))
    ws.in_trang(ngang=False, lap_dong=(8, 9))
    wb.luu("B01a.xlsx")
Hang / cot tinh tu 1. Gia tri: str / int / float / bool / None / datetime.date (ghi so ngay Excel + dinh dang ngay).
"""
import datetime as _dt
import re as _re
import zipfile as _zip
from xml.sax.saxutils import escape as _esc

SO_TIEN = '#,##0;(#,##0);"-"'          # so tien: am trong ngoac, 0 -> "-"
SO_TIEN0 = '#,##0;(#,##0);""'          # 0 -> de trong
SO_NGAY = "dd/mm/yyyy"
_NF_SAN = {"General": 0, "0": 1, "0.00": 2, "#,##0": 3, "#,##0.00": 4, "0%": 9, "0.00%": 10, "dd/mm/yyyy": None, "@": 49}   # GD134: "@" = o chu (Text)
_BAD = _re.compile(u"[\x00-\x08\x0b\x0c\x0e-\x1f￾￿]")


def _cot_chu(c):
    s = ""
    while c > 0:
        c, r = divmod(c - 1, 26)
        s = chr(65 + r) + s
    return s


def dia_chi(r, c):
    return "%s%d" % (_cot_chu(c), r)


def _x(s):
    return _esc(_BAD.sub("", str(s)), {'"': "&quot;"})


class Chu(str):
    """GD79: chuoi hien NGUYEN VAN (ke ca khi bat dau bang '=') - khong coi la cong thuc."""
    __slots__ = ()


class CT(object):
    """GD79: cong thuc Excel kem gia tri da tinh san (cached value) - Excel van tinh lai khi mo (fullCalcOnLoad)."""
    __slots__ = ("f", "v")

    def __init__(self, f, v=None):
        self.f = f if str(f).startswith("=") else "=" + str(f)
        self.v = v


class _Kieu(object):
    __slots__ = ("font", "fill", "border", "nf", "can", "doc", "xuong", "thut", "xoay", "id")

    def __init__(self, font, fill, border, nf, can, doc, xuong, thut, xoay):
        self.font, self.fill, self.border, self.nf = font, fill, border, nf
        self.can, self.doc, self.xuong, self.thut, self.xoay = can, doc, xuong, thut, xoay
        self.id = None

    def khoa(self):
        return (self.font, self.fill, self.border, self.nf, self.can, self.doc, self.xuong, self.thut, self.xoay)


class SoExcel(object):
    """So tinh (workbook)."""

    def __init__(self, font="Times New Roman", co=11):
        self.font_mac_dinh = font
        self.co_mac_dinh = co
        self.sheets = []
        self._fonts = [(font, co, False, False, False, "000000")]
        self._fills = ["none", "gray125"]
        self._borders = [(None, None, None, None)]
        self._nfs = {}
        self._xfs = [(0, 0, 0, 0, None, None, False, 0, 0)]
        self._xf_id = {self._xfs[0]: 0}
        self._cache = {}
        self._dxfs = []       # GD79: kieu to mau co dieu kien (nen, mau chu, dam)
        self._ten = []        # GD79: ten vung (definedName)

    # ---------------------------------------------------------------- kieu o
    def kieu(self, dam=False, nghieng=False, gach=False, co=None, font=None, mau="000000", nen=None,
             khung=False, khung_tren=None, khung_duoi=None, khung_trai=None, khung_phai=None,
             so=None, can=None, doc="giua", xuong=False, thut=0, xoay=0):
        """can: trai / giua / phai / deu ; doc: tren / giua / duoi ; khung: True = vien mong 4 canh ('dam' = vien dam);
        khung_* = None / 'mong' / 'dam' / 'cham' (ghi de tung canh); so: dinh dang so Excel; nen: mau RGB 'D9E1F2'."""
        k = (dam, nghieng, gach, co, font, mau, nen, khung, khung_tren, khung_duoi, khung_trai, khung_phai, so, can, doc, xuong, thut, xoay)
        if k in self._cache:
            return self._cache[k]
        f = (font or self.font_mac_dinh, co or self.co_mac_dinh, bool(dam), bool(nghieng), bool(gach), (mau or "000000").upper())
        if f not in self._fonts:
            self._fonts.append(f)
        fi = 0
        if nen:
            nen = nen.upper()
            if nen not in self._fills:
                self._fills.append(nen)
            fi = self._fills.index(nen)
        mk = "medium" if khung == "dam" else ("thin" if khung else None)

        def _c(v):
            return {"mong": "thin", "dam": "medium", "cham": "dotted", "dut": "dashed", None: mk, False: None}.get(v, mk)
        b = (_c(khung_trai), _c(khung_phai), _c(khung_tren), _c(khung_duoi))
        if b not in self._borders:
            self._borders.append(b)
        nf = 0
        if so:
            if so in _NF_SAN and _NF_SAN[so] is not None:
                nf = _NF_SAN[so]
            else:
                if so not in self._nfs:
                    self._nfs[so] = 164 + len(self._nfs)
                nf = self._nfs[so]
        kq = _Kieu(self._fonts.index(f), fi, self._borders.index(b), nf, can, doc, bool(xuong), int(thut or 0), int(xoay or 0))
        kx = kq.khoa()
        if kx not in self._xf_id:
            self._xf_id[kx] = len(self._xfs)
            self._xfs.append(kx)
        kq.id = self._xf_id[kx]
        self._cache[k] = kq
        return kq

    def ten(self, ten, tham_chieu):
        """GD79: dat ten vung dung trong cong thuc, vd wb.ten("TS_BHXH_NLD", "ThamSo!$C$6")."""
        self._ten.append((ten, tham_chieu))
        return ten

    def _dxf(self, nen, mau, dam):
        k = ((nen or "").upper(), (mau or "").upper(), bool(dam))
        if k not in self._dxfs:
            self._dxfs.append(k)
        return self._dxfs.index(k)

    def sheet(self, ten, cot=None):
        ten = _re.sub(r"[\[\]\*\?/\\:]", "-", str(ten))[:31] or "Sheet"
        goc, i = ten, 1
        while any(s.ten.lower() == ten.lower() for s in self.sheets):
            i += 1
            ten = (goc[:28] + "_%d" % i)
        s = _Sheet(self, ten)
        if cot:
            for i, w in enumerate(cot, start=1):
                if w:
                    s.rong(i, w)
        self.sheets.append(s)
        return s

    # ---------------------------------------------------------------- ghi tep
    def _styles(self):
        nf = "".join('<numFmt numFmtId="%d" formatCode="%s"/>' % (i, _x(c)) for c, i in sorted(self._nfs.items(), key=lambda t: t[1]))
        nf = ('<numFmts count="%d">%s</numFmts>' % (len(self._nfs), nf)) if self._nfs else ""
        fonts = "".join('<font>%s%s%s<sz val="%s"/><color rgb="FF%s"/><name val="%s"/><family val="1"/></font>'
                        % ("<b/>" if f[2] else "", "<i/>" if f[3] else "", "<u/>" if f[4] else "", f[1], f[5], _x(f[0])) for f in self._fonts)
        fills = "".join('<fill><patternFill patternType="%s"/></fill>' % p if p in ("none", "gray125")
                        else '<fill><patternFill patternType="solid"><fgColor rgb="FF%s"/><bgColor indexed="64"/></patternFill></fill>' % p
                        for p in self._fills)

        def _canh(ten, v):
            return ('<%s style="%s"><color indexed="64"/></%s>' % (ten, v, ten)) if v else "<%s/>" % ten
        borders = "".join("<border>%s%s%s%s<diagonal/></border>" % (_canh("left", b[0]), _canh("right", b[1]), _canh("top", b[2]), _canh("bottom", b[3]))
                          for b in self._borders)
        CAN = {"trai": "left", "giua": "center", "phai": "right", "deu": "justify", "giua_vung": "centerContinuous"}
        DOC = {"tren": "top", "giua": "center", "duoi": "bottom"}
        xfs = []
        for (fo, fi, bo, n, can, doc, xuong, thut, xoay) in self._xfs:
            al = ""
            if can or doc or xuong or thut or xoay:
                al = "<alignment%s%s%s%s%s/>" % (' horizontal="%s"' % CAN.get(can, can) if can else "",
                                                 ' vertical="%s"' % DOC.get(doc, doc) if doc else "",
                                                 ' wrapText="1"' if xuong else "", ' indent="%d"' % thut if thut else "",
                                                 ' textRotation="%d"' % xoay if xoay else "")
            xfs.append('<xf numFmtId="%d" fontId="%d" fillId="%d" borderId="%d" xfId="0"%s%s%s%s>%s</xf>'
                       % (n, fo, fi, bo, ' applyNumberFormat="1"' if n else "", ' applyFont="1"' if fo else "",
                          ' applyFill="1"' if fi else "", ' applyBorder="1"' if bo else "", al))
        return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
                '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">%s'
                '<fonts count="%d">%s</fonts><fills count="%d">%s</fills><borders count="%d">%s</borders>'
                '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
                '<cellXfs count="%d">%s</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>%s'
                '</styleSheet>' % (nf, len(self._fonts), fonts, len(self._fills), fills, len(self._borders), borders, len(xfs), "".join(xfs),
                                   self._dxf_xml()))

    def _dxf_xml(self):
        if not self._dxfs:
            return ""
        ds = []
        for nen, mau, dam in self._dxfs:
            fo = ""
            if mau or dam:
                fo = "<font>%s%s</font>" % ("<b/>" if dam else "", ('<color rgb="FF%s"/>' % mau) if mau else "")
            fi = ('<fill><patternFill patternType="solid"><bgColor rgb="FF%s"/></patternFill></fill>' % nen) if nen else ""
            ds.append("<dxf>%s%s</dxf>" % (fo, fi))
        return '<dxfs count="%d">%s</dxfs>' % (len(ds), "".join(ds))

    def luu(self, duong):
        if not self.sheets:
            self.sheet("Sheet1")
        n = len(self.sheets)
        ten_in = []
        for i, s in enumerate(self.sheets):
            if s._loc:
                ten_in.append('<definedName name="_xlnm._FilterDatabase" localSheetId="%d" hidden="1">\'%s\'!$%s$%d:$%s$%d</definedName>'
                              % (i, _x(s.ten.replace("'", "''")), _cot_chu(s._loc[1]), s._loc[0], _cot_chu(s._loc[3]), s._loc[2]))
            if s._lap:
                ten_in.append('<definedName name="_xlnm.Print_Titles" localSheetId="%d">\'%s\'!$%d:$%d</definedName>'
                              % (i, _x(s.ten.replace("'", "''")), s._lap[0], s._lap[1]))
        wbx = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
               '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
               'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
               '<bookViews><workbookView activeTab="0"/></bookViews><sheets>%s</sheets>%s<calcPr calcId="191029" fullCalcOnLoad="1"/></workbook>'
               % ("".join('<sheet name="%s" sheetId="%d"%s r:id="rId%d"/>' % (_x(s.ten), i + 1, ' state="hidden"' if getattr(s, "_an_sheet", False) else "", i + 1) for i, s in enumerate(self.sheets)),
                  ("<definedNames>%s</definedNames>" % "".join(ten_in + ['<definedName name="%s">%s</definedName>' % (_x(t), _x(v))
                                                                          for t, v in sorted(self._ten)])) if (ten_in or self._ten) else ""))
        with _zip.ZipFile(duong, "w", _zip.ZIP_DEFLATED) as z:
            z.writestr("[Content_Types].xml",
                       '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
                       '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                       '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
                       '<Default Extension="xml" ContentType="application/xml"/>'
                       '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
                       '%s<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
                       '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
                       '</Types>' % "".join('<Override PartName="/xl/worksheets/sheet%d.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
                                            % (i + 1) for i in range(n)))
            z.writestr("_rels/.rels",
                       '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
                       '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                       '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
                       '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>'
                       '</Relationships>')
            z.writestr("docProps/core.xml",
                       '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
                       '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
                       'xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" '
                       'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:creator>UNESCO AI</dc:creator>'
                       '<dcterms:created xsi:type="dcterms:W3CDTF">%s</dcterms:created></cp:coreProperties>'
                       % _dt.datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ"))
            z.writestr("xl/workbook.xml", wbx)
            z.writestr("xl/_rels/workbook.xml.rels",
                       '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
                       '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">%s'
                       '<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
                       '</Relationships>' % ("".join('<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" '
                                                     'Target="worksheets/sheet%d.xml"/>' % (i + 1, i + 1) for i in range(n)), n + 1))
            try:                                                        # GD139: tieu de Mau so / Ban hanh theo Thong tu bo so
                import tieu_de_tt as _TD
                for _s in self.sheets:
                    _TD.sua_o(_s._o)
            except Exception:
                pass
            xs = [s._xml(i == 0) for i, s in enumerate(self.sheets)]    # truoc styles: o ngay tu them kieu
            z.writestr("xl/styles.xml", self._styles())
            for i, x in enumerate(xs):
                z.writestr("xl/worksheets/sheet%d.xml" % (i + 1), x)
        return duong


class _Sheet(object):
    def __init__(self, wb, ten):
        self.wb, self.ten = wb, ten
        self._o = {}          # (r, c) -> (gia tri, kieu id)
        self._rong = {}
        self._cao = {}
        self._gop = []
        self._bang = None     # (dong, cot) o dau tien KHONG co dinh
        self._ngang = False
        self._vua_rong = True
        self._lap = None
        self._an_luoi = True
        self._le = (0.5, 0.4, 0.6, 0.6)   # trai, phai, tren, duoi (inch)
        self._ty_le = None
        self._an_cot = set()
        self._ngat = []
        self.dong_cuoi = 0
        self._loc = None      # GD79: (r1, c1, r2, c2) vung loc du lieu
        self._dk = []         # GD79: (vung, cong thuc, dxf id)
        self._dv = []         # GD134: (vung, nguon danh sach, chan gia tri ngoai danh sach)

    def o(self, r, c, gt=None, kieu=None):
        """ghi mot o (gia tri + kieu)."""
        self._o[(r, c)] = (gt, kieu.id if kieu is not None else 0)
        if r > self.dong_cuoi:
            self.dong_cuoi = r
        return self

    def dong(self, r, c, ds, kieu=None):
        """ghi nhieu o lien tiep tren dong r tu cot c; phan tu cua ds co the la (gia tri, kieu)."""
        for i, v in enumerate(ds):
            if isinstance(v, tuple) and len(v) == 2 and (v[1] is None or isinstance(v[1], _Kieu)):
                self.o(r, c + i, v[0], v[1] if v[1] is not None else kieu)
            else:
                self.o(r, c + i, v, kieu)
        return self

    def gop(self, r1, c1, r2, c2, gt=None, kieu=None):
        """gop vung; gia tri o o dau; kieu ap cho MOI o trong vung (de khung vien du)."""
        if (r1, c1) != (r2, c2):
            self._gop.append((r1, c1, r2, c2))
        for r in range(r1, r2 + 1):
            for c in range(c1, c2 + 1):
                if (r, c) == (r1, c1):
                    self.o(r, c, gt, kieu)
                elif kieu is not None or (r, c) not in self._o:
                    self.o(r, c, None, kieu)
        return self

    def rong(self, c, w):
        self._rong[c] = float(w)
        return self

    def cao(self, r, h):
        self._cao[r] = float(h)
        return self

    def an_cot(self, c):
        self._an_cot.add(c)
        return self

    def ngat_trang(self, r):
        """ngat trang in NGAY SAU dong r (moi chung tu / moi so mot trang)."""
        if r > 0 and r not in self._ngat:
            self._ngat.append(r)
        return self

    def loc(self, r1, c1, r2, c2):
        """GD79: bat loc du lieu (AutoFilter) cho vung - dong r1 la dong tieu de cot."""
        if r2 >= r1 and c2 >= c1:
            self._loc = (r1, c1, r2, c2)
        return self

    def to_mau(self, r1, c1, r2, c2, cong_thuc, nen="FFC7CE", mau="9C0006", dam=False):
        """GD79: to mau co dieu kien - cong_thuc tinh cho o dau vung (r1, c1), vd 'ABS(O7)>TS_SAI_SO'."""
        if r2 >= r1 and c2 >= c1:
            vung = dia_chi(r1, c1) + ((":" + dia_chi(r2, c2)) if (r2, c2) != (r1, c1) else "")
            self._dk.append((vung, cong_thuc.lstrip("="), self.wb._dxf(nen, mau, dam)))
        return self

    def chon_ds(self, r1, c1, r2, c2, nguon, chan=False):
        """GD134: o chon tu danh sach tha xuong. nguon: vung "DanhMuc!$A$2:$A$30" hoac chuoi '"Nam,Nữ"'.
        chan=False: van go duoc gia tri khac (khong hien loi)."""
        if r2 >= r1 and c2 >= c1 and nguon:
            vung = dia_chi(r1, c1) + ((":" + dia_chi(r2, c2)) if (r2, c2) != (r1, c1) else "")
            self._dv.append((vung, str(nguon).lstrip("="), bool(chan)))
        return self

    def luoi(self, hien=True):
        """hien / an duong luoi man hinh (mac dinh an - giong mau in)."""
        self._an_luoi = not hien
        return self

    def dong_bang(self, r, c=1):
        """co dinh cac dong phia tren r va cac cot truoc c."""
        self._bang = (r, c)
        return self

    def in_trang(self, ngang=False, vua_rong=True, lap_dong=None, le=None, ty_le=None):
        self._ngang, self._vua_rong, self._lap = ngang, vua_rong, lap_dong
        if le:
            self._le = le
        self._ty_le = ty_le
        return self

    def _gt(self, r, c, gt, k):
        ref = dia_chi(r, c)
        st = (' s="%d"' % k) if k else ""
        if gt is None or gt == "":
            return '<c r="%s"%s/>' % (ref, st) if k else ""
        if isinstance(gt, bool):
            return '<c r="%s"%s t="b"><v>%d</v></c>' % (ref, st, 1 if gt else 0)
        if isinstance(gt, (int, float)):
            if gt != gt or gt in (float("inf"), float("-inf")):
                return '<c r="%s"%s/>' % (ref, st)
            v = repr(float(gt)) if isinstance(gt, float) and not float(gt).is_integer() else str(int(gt))
            return '<c r="%s"%s><v>%s</v></c>' % (ref, st, v)
        if isinstance(gt, (_dt.date, _dt.datetime)):
            d = gt if isinstance(gt, _dt.datetime) else _dt.datetime(gt.year, gt.month, gt.day)
            so = (d - _dt.datetime(1899, 12, 30)).days
            if not k:
                k = self.wb.kieu(so=SO_NGAY).id
                st = ' s="%d"' % k
            return '<c r="%s"%s><v>%d</v></c>' % (ref, st, so)
        if isinstance(gt, CT):
            v = gt.v
            if isinstance(v, bool):
                return '<c r="%s"%s t="b"><f>%s</f><v>%d</v></c>' % (ref, st, _x(gt.f[1:]), 1 if v else 0)
            if isinstance(v, (int, float)) and v == v and v not in (float("inf"), float("-inf")):
                vv = repr(float(v)) if isinstance(v, float) and not float(v).is_integer() else str(int(v))
                return '<c r="%s"%s><f>%s</f><v>%s</v></c>' % (ref, st, _x(gt.f[1:]), vv)
            if isinstance(v, str):
                return '<c r="%s"%s t="str"><f>%s</f><v>%s</v></c>' % (ref, st, _x(gt.f[1:]), _x(v))
            return '<c r="%s"%s><f>%s</f></c>' % (ref, st, _x(gt.f[1:]))
        s = str(gt)
        if s.startswith("=") and len(s) > 1 and not isinstance(gt, Chu):
            return '<c r="%s"%s><f>%s</f></c>' % (ref, st, _x(s[1:]))
        return '<c r="%s"%s t="inlineStr"><is><t xml:space="preserve">%s</t></is></c>' % (ref, st, _x(s))

    def _xml(self, chon):
        rows = {}
        for (r, c), (gt, k) in self._o.items():
            rows.setdefault(r, []).append((c, gt, k))
        sd = []
        for r in sorted(set(rows) | set(self._cao)):
            cells = "".join(self._gt(r, c, gt, k) for c, gt, k in sorted(rows.get(r, []), key=lambda t: t[0]))
            h = (' ht="%s" customHeight="1"' % self._cao[r]) if r in self._cao else ""
            sd.append('<row r="%d"%s>%s</row>' % (r, h, cells))
        cols = ""
        if self._rong or self._an_cot:
            cs = sorted(set(self._rong) | self._an_cot)
            cols = "<cols>%s</cols>" % "".join('<col min="%d" max="%d" width="%s" customWidth="1"%s/>'
                                                % (c, c, self._rong.get(c, 9.0), ' hidden="1"' if c in self._an_cot else "") for c in cs)
        pane = ""
        if self._bang:
            r, c = self._bang
            attrs = []
            if c > 1:
                attrs.append('xSplit="%d"' % (c - 1))
            if r > 1:
                attrs.append('ySplit="%d"' % (r - 1))
            ap = "bottomRight" if (r > 1 and c > 1) else ("bottomLeft" if r > 1 else "topRight")
            pane = '<pane %s topLeftCell="%s" activePane="%s" state="frozen"/>' % (" ".join(attrs), dia_chi(r, c), ap)
        sv = '<sheetViews><sheetView workbookViewId="0"%s%s>%s</sheetView></sheetViews>' % (
            ' tabSelected="1"' if chon else "", ' showGridLines="0"' if self._an_luoi else "", pane)
        loc = ('<autoFilter ref="%s:%s"/>' % (dia_chi(self._loc[0], self._loc[1]), dia_chi(self._loc[2], self._loc[3]))) if self._loc else ""
        dk = "".join('<conditionalFormatting sqref="%s"><cfRule type="expression" dxfId="%d" priority="%d"><formula>%s</formula></cfRule>'
                     '</conditionalFormatting>' % (v, d, i + 1, _x(f)) for i, (v, f, d) in enumerate(self._dk))
        dv = ""
        if self._dv:
            dv = '<dataValidations count="%d">%s</dataValidations>' % (len(self._dv), "".join(
                '<dataValidation type="list" allowBlank="1" showInputMessage="1" showErrorMessage="%d" sqref="%s"><formula1>%s</formula1>'
                '</dataValidation>' % (1 if c else 0, v, _x(f)) for v, f, c in self._dv))
        merge = ""
        if self._gop:
            merge = '<mergeCells count="%d">%s</mergeCells>' % (len(self._gop), "".join(
                '<mergeCell ref="%s:%s"/>' % (dia_chi(a, b), dia_chi(c, d)) for a, b, c, d in self._gop))
        fit = '<sheetPr><pageSetUpPr fitToPage="1"/></sheetPr>' if self._vua_rong else ""
        ps = '<pageSetup paperSize="9" orientation="%s"%s/>' % ("landscape" if self._ngang else "portrait",
                                                                ' fitToWidth="1" fitToHeight="0"' if self._vua_rong else
                                                                (' scale="%d"' % self._ty_le if self._ty_le else ""))
        le = '<pageMargins left="%s" right="%s" top="%s" bottom="%s" header="0.3" footer="0.3"/>' % self._le
        ngat = ""
        if self._ngat:
            ngat = '<rowBreaks count="%d" manualBreakCount="%d">%s</rowBreaks>' % (len(self._ngat), len(self._ngat), "".join(
                '<brk id="%d" max="16383" man="1"/>' % r for r in sorted(self._ngat)))
        return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
                '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
                'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
                '%s%s<sheetFormatPr defaultRowHeight="15"/>%s<sheetData>%s</sheetData>%s%s%s%s'
                '<printOptions horizontalCentered="1"/>%s%s%s</worksheet>'
                % (fit, sv, cols, "".join(sd), loc, merge, dk, dv, le, ps, ngat))
