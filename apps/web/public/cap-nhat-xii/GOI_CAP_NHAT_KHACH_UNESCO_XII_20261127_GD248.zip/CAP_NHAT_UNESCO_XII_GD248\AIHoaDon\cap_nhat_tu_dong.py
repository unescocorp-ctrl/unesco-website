# -*- coding: utf-8 -*-
"""GD118 - CAP NHAT TU DONG phan mem UNESCO XI + AI (chay bang CAP_NHAT_TU_DONG.bat - nhap dup, khong can chep tay).

Anh Thang 04/10/2026: "khi da dang ky thi luu san vao may, khong phai moi khi cap nhat hay doi file .exe phai dang ky lai
key docai_goi.dat. Tao file Update tu dong".

NGUON (--goi, mac dinh = thu muc chua file .bat):
  * GOI cap nhat (CAP_NHAT_..._GDnnn, thu muc hoac tep .zip keo tha vao .bat);
  * hoac THU MUC DU AN VB6 (co Sas.vbp) -> day .exe vua Make (theo Sas.vbp: Path32 + ExeName32) + AIHoaDon sang noi CHAY.
DICH (tu tim; hoac --dich / keo tha thu muc): moi thu muc co AIHoaDon\\tool_so_phu_unesco.py va
  * co file .exe  -> NOI CHAY (chi chep phan chay: .exe, AIHoaDon\\*, RePorts\\*; khong chep ma nguon .frm/.bas);
  * co Sas.vbp    -> DU AN VB6 (chep ca ma nguon, dang ky Sas.vbp bang dang_ky_vbp.vbs, KHONG ghi de Sas.vbp).
  Tim theo danh sach noi cai cua may (%LOCALAPPDATA%\\UNESCO_AI\\noi_cai.txt - phan mem / tool ghi moi lan chay) va quet
  o dia (sau toi da 3 cap thu muc).
KHONG BAO GIO GHI DE du lieu / cau hinh cua may: data\\, *.mdb, LOG\\, AIHoaDon\\ket-qua, nhat ky, cai-dat.json,
  docai.json, python_exe.txt, chrome-ho-so, Tesseract-OCR... Khoa Google cai san (docai_goi.dat): giu cua may - noi chua co
  thi tu chep tu kho may (%LOCALAPPDATA%\\UNESCO_AI\\khoa) / noi khac tren may -> KHONG phai Import lai.
Moi tep bi thay deu sao luu vao <dich>\\_sao_luu_<goi>_<ngay gio>\\ (kem KHOI_PHUC.bat); nhat ky <dich>\\LOG\\CAP_NHAT_*.txt.
Chi chep tep KHAC noi dung (chay lai nhieu lan khong sao). Chu tren man hinh khong dau (cua so CMD).

Dung:  CAP_NHAT_TU_DONG.bat                    (nhap dup trong thu muc goi / thu muc du an)
       CAP_NHAT_TU_DONG.bat "<tep goi .zip>"   (keo tha tep zip vao .bat)
       python cap_nhat_tu_dong.py --goi <goi> --dich <thu muc> [--dich ...] [--khong-hoi] [--thu] [--khong-quet]"""
import fnmatch
import hashlib
import io
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile

PHIEN_BAN = "GD118"
HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)
try:
    import giu_may
except Exception:          # goi cu thieu giu_may.py - van cap nhat duoc, chi khong giu khoa theo may
    giu_may = None

LA_WIN = os.name == "nt"
TOOL_MOC = os.path.join("AIHoaDon", "tool_so_phu_unesco.py")

# Tep / thu muc cua MAY - khong chep tu goi, khong ghi de (mau theo duong tuong doi, '/' ; so khop khong phan biet hoa thuong)
KHONG_CHEP = [
    "data/*", "*.mdb", "*.ldb", "*.laccdb", "log/*", "_sao_luu*", "_backup*", "_cong_cu_rieng/*", "sao_luu_kich_hoat/*",
    "hddttaive/*", "*/__pycache__/*", "__pycache__/*", "*.pyc", "*.tmp", "*.tam", "~$*",
    "aihoadon/ket-qua/*", "aihoadon/chrome-ho-so/*", "aihoadon/tesseract-ocr/*", "aihoadon/docai.json",
    "aihoadon/docai_goi*.dat", "aihoadon/cai-dat.json", "aihoadon/python_exe.txt", "aihoadon/nhat-ky*.txt",
    "aihoadon/vb-nhat-ky*.txt", "aihoadon/thamso_*", "aihoadon/*.log", "aihoadon/htkk_solieu_*.json",
    "aihoadon/htkk-sao-luu/*",          # GD122: to khai HTKK cu da sao luu truoc khi ghi de - du lieu cua may
    "aihoadon/chrome-ho-so*/*",          # GD123b: moi ho so trinh duyet (chrome-ho-so-dvc...) - cookie / lich su cua may
    "_to_delete/*", "*/_to_delete/*",    # GD123b: tep cho xoa
    "aihoadon/bhxh/mau_bhxh.json", "aihoadon/bhxh/ho_so_*", "aihoadon/bhxh_*.json",   # GD128: cau hinh / ho so BHXH cua may, JSON tam co CCCD
]
# Noi chay: chi cac phan nay (ngoai .exe) - ma nguon .frm / .bas / Sas.vbp, cong cu dong goi chi chep vao DU AN VB6
PHAN_CHAY = ["aihoadon/*", "reports/*"]
BO_QUA_NOI_CHAY = ["aihoadon/test_*.py", "aihoadon/kiem_tra_du_an.py", "aihoadon/cai-dat-test.json", "aihoadon/bang115.py"]
# GD123b: nguon la THU MUC DU AN -> khong day reports\*.xls(x): ban lam viec phan mem ghi so lieu vao (bang ke, nhat ky...);
#         mau moi den noi chay qua goi cap nhat.
BO_QUA_TU_DU_AN = ["reports/*.xls", "reports/*.xlsx"]
BO_QUA_QUET = {"windows", "$recycle.bin", "system volume information", "programdata", "program files", "program files (x86)",
               "appdata", "node_modules", ".git", "recovery", "perflogs", "msocache", "$windows.~bt", "$windows.~ws"}
LOG = []


# ---------------------------------------------------------------- tien ich
def noi(s=""):
    s = str(s)
    LOG.append(s)
    try:
        print(s)
    except Exception:
        print(s.encode("ascii", "replace").decode("ascii"))


def bo_dau(s):
    import unicodedata
    s = unicodedata.normalize("NFD", str(s)).replace("\u0111", "d").replace("\u0110", "D")
    return "".join(c for c in s if unicodedata.category(c) != "Mn")


def rel_chuan(rel):
    return rel.replace("\\", "/").lower()


def khop(rel, mau):
    r = rel_chuan(rel)
    return any(fnmatch.fnmatch(r, m) for m in mau)


def bam(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for k in iter(lambda: f.read(1 << 20), b""):
            h.update(k)
    return h.hexdigest()


def giong(a, b):
    try:
        if os.path.getsize(a) != os.path.getsize(b):
            return False
        return bam(a) == bam(b)
    except OSError:
        return False


def la_du_an(d):
    """Thu muc du an VB6 THAT: co Sas.vbp, >= 30 file .frm va >= 90% tep Sas.vbp khai bao co tren dia.
       (Goi cap nhat luy ke cung co Sas.vbp + hang tram .frm nhung chi chua tep DA DOI -> thieu nhieu tep khai bao.)"""
    try:
        p = os.path.join(d, "Sas.vbp")
        if not os.path.isfile(p):
            return False
        if sum(1 for t in os.listdir(d) if t.lower().endswith(".frm")) < 30:
            return False
        with io.open(p, encoding="latin-1") as f:
            ds = re.findall(r"^(?:Form|Module|Class|UserControl)=(?:[^;\r\n]+;\s*)?([^\r\n]+)$", f.read(), re.M)
        if not ds:
            return False
        co = sum(1 for x in ds if os.path.isfile(os.path.join(d, x.strip().replace("\\", os.sep))))
        return co >= 0.9 * len(ds)
    except OSError:
        return False


def exe_cua(d):
    """File .exe phan mem trong thu muc (uu tien UNESCO*.exe, moi nhat). '' neu khong co."""
    try:
        ds = [t for t in os.listdir(d) if t.lower().endswith(".exe") and os.path.isfile(os.path.join(d, t))]
    except OSError:
        return ""
    if not ds:
        return ""
    ds.sort(key=lambda t: (not t.upper().startswith("UNESCO"), -os.path.getmtime(os.path.join(d, t))))
    return ds[0]


def loai_dich(d):
    """'DU_AN' / 'NOI_CHAY' / '' (khong phai noi cai phan mem)."""
    if not os.path.isfile(os.path.join(d, TOOL_MOC)):
        return ""
    if la_du_an(d):
        return "DU_AN"
    if exe_cua(d):
        return "NOI_CHAY"
    return ""


def chuan(p):
    return os.path.normcase(os.path.normpath(os.path.abspath(p)))


def la_sao_luu(p):
    pt = [x.lower() for x in re.split(r"[\\/]+", os.path.abspath(p))]
    return any(x.startswith(("_sao_luu", "_backup", "_ban_cai_khach", "sao_luu_kich_hoat")) for x in pt)


# ---------------------------------------------------------------- nguon
def mo_nguon(goi):
    """-> (thu muc goc nguon, ten nguon, thu muc tam can xoa | None)."""
    goi = os.path.abspath(goi)
    if os.path.isfile(goi) and goi.lower().endswith(".zip"):
        tam = tempfile.mkdtemp(prefix="unesco_capnhat_")
        with zipfile.ZipFile(goi) as z:
            z.extractall(tam)
        goc = tam
        for _ in range(3):                    # zip co mot thu muc goc CAP_NHAT_... ben trong
            if os.path.isfile(os.path.join(goc, TOOL_MOC)):
                break
            con = [os.path.join(goc, x) for x in os.listdir(goc) if os.path.isdir(os.path.join(goc, x))]
            if len(con) != 1:
                break
            goc = con[0]
        return goc, os.path.splitext(os.path.basename(goi))[0], tam
    return goi, os.path.basename(goi.rstrip("\\/")) or "GOI", None


def exe_du_an(du_an):
    """.exe Make tu du an - tep MOI NHAT trong: Sas.vbp Path32 + ExeName32 (vd ..\\FIX_HOA DON\\UNESCOXI_2026_TP1.exe),
    <du an>\\ExeName32, <du an>\\EXE\\UNESCO*.exe (GD123b). '' neu khong co."""
    try:
        with io.open(os.path.join(du_an, "Sas.vbp"), encoding="latin-1") as f:
            s = f.read()
    except OSError:
        return ""
    ten = re.search(r'^ExeName32="([^"]+)"', s, re.M)
    duong = re.search(r'^Path32="([^"]*)"', s, re.M)
    if not ten:
        return ""
    d = duong.group(1) if duong else ""
    ds = [os.path.normpath(os.path.join(du_an, d.replace("\\", os.sep), ten.group(1))), os.path.join(du_an, ten.group(1))]
    ex = os.path.join(du_an, "EXE")            # GD123b: anh Make .exe vao <du an>\\EXE\\UNESCO_AI.exe (khong luu Sas.vbp)
    if os.path.isdir(ex):
        ds += [os.path.join(ex, t) for t in os.listdir(ex) if t.lower().endswith(".exe") and t.upper().startswith("UNESCO")]
    ds = [p for p in ds if os.path.isfile(p)]
    return max(ds, key=os.path.getmtime) if ds else ""


def tep_nguon(goc):
    """[(rel, duong day du)] moi tep trong nguon (bo thu muc tam / sao luu / pycache)."""
    ra = []
    for r, ds, fs in os.walk(goc):
        ds[:] = [x for x in ds if not x.lower().startswith(("_sao_luu", "_backup", "__pycache__", ".git"))]
        for t in fs:
            p = os.path.join(r, t)
            ra.append((os.path.relpath(p, goc), p))
    return ra


# ---------------------------------------------------------------- tim noi cai
def quet_o_dia(han_giay=25, sau=3):
    """Quet cac o dia (toi da 'sau' cap) tim thu muc co AIHoaDon\\tool_so_phu_unesco.py. Chi tren Windows."""
    if not LA_WIN:
        return []
    import string
    t0 = time.time()
    ra = []
    for chu in string.ascii_uppercase[2:]:
        goc = "%s:\\" % chu
        if not os.path.exists(goc):
            continue
        hang = [(goc, 0)]
        while hang:
            if time.time() - t0 > han_giay:
                noi("  (het %d giay quet o dia - dung o %s)" % (han_giay, goc))
                return ra
            d, cap = hang.pop(0)
            if os.path.isfile(os.path.join(d, TOOL_MOC)):
                ra.append(d)
                continue
            if cap >= sau:
                continue
            try:
                with os.scandir(d) as it:
                    for e in it:
                        if e.is_dir(follow_symlinks=False) and e.name.lower() not in BO_QUA_QUET \
                                and not e.name.lower().startswith(("_sao_luu", "_backup", "$")):
                            hang.append((e.path, cap + 1))
            except OSError:
                pass
    return ra


def tim_dich(nguon_goc, quet=True):
    """-> [(thu muc, loai, luc dung gan nhat)] co the cap nhat (bo chinh nguon, thu muc sao luu, bo cai)."""
    ung = []
    luc = {}
    if giu_may:
        for d, l in giu_may.doc_noi_cai():
            ung.append(d)
            luc.setdefault(chuan(d), l)
    if quet:
        noi("Dang tim noi cai phan mem tren cac o dia (toi da 25 giay)...")
        ung.extend(quet_o_dia())
    ra, da = [], set()
    for d in ung:
        k = chuan(d)
        if k in da or k == chuan(nguon_goc) or la_sao_luu(d) or not os.path.isdir(d):
            continue
        da.add(k)
        ld = loai_dich(d)
        if ld:
            ra.append((os.path.abspath(d), ld, luc.get(k, "")))
    return ra


# ---------------------------------------------------------------- chep
def dang_chay(ten_exe):
    """Windows: tien trinh co ten nay dang chay?"""
    if not LA_WIN or not ten_exe:
        return False
    try:
        out = subprocess.run(["tasklist", "/NH", "/FI", "IMAGENAME eq %s" % ten_exe], capture_output=True, text=True,
                             timeout=20).stdout
        return ten_exe.lower() in out.lower()
    except Exception:
        return False


def ke_hoach(nguon_goc, la_nguon_du_an, dich, loai, exe_moi):
    """-> [(rel dich, duong nguon)] can chep (chua co / khac noi dung)."""
    ds = []
    for rel, p in tep_nguon(nguon_goc):
        r = rel_chuan(rel)
        if khop(rel, KHONG_CHEP):
            continue
        if r.endswith(".exe") and "/" not in r:
            continue                            # .exe cua goi: xu ly rieng (doi ten theo .exe cua noi chay)
        if loai == "NOI_CHAY":
            if not khop(rel, PHAN_CHAY) or khop(rel, BO_QUA_NOI_CHAY):
                continue
            if la_nguon_du_an and khop(rel, BO_QUA_TU_DU_AN):
                continue
        else:                                   # DU AN VB6
            if la_nguon_du_an or r == "sas.vbp":
                continue                        # khong day du an sang du an khac; Sas.vbp dang ky bang dang_ky_vbp.vbs
        dich_p = os.path.join(dich, rel)
        if os.path.isfile(dich_p) and giong(p, dich_p):
            continue
        ds.append((rel, p))
    if loai == "NOI_CHAY" and exe_moi:
        ten = exe_cua(dich) or os.path.basename(exe_moi)
        dich_p = os.path.join(dich, ten)
        if not (os.path.isfile(dich_p) and giong(exe_moi, dich_p)):
            if la_nguon_du_an and os.path.isfile(dich_p) and os.path.getmtime(exe_moi) <= os.path.getmtime(dich_p):
                noi("  .exe Make cua du an KHONG moi hon .exe dang chay (%s) - giu .exe hien tai" % ten)
            else:
                ds.append((ten, exe_moi))
    return ds


def giu_khoa_dich(dich, cac_noi):
    """Khoa Google: noi dich chua co -> lay tu kho may / noi khac tren may (moi nhat). Co roi -> luu vao kho may."""
    th = os.path.join(dich, "AIHoaDon")
    if giu_may:
        kq = giu_may.giu_khoa(th, noi)
        if kq.startswith("LOI"):
            noi("  khoa Google: " + kq)
    tep = os.path.join(th, "docai_goi.dat")
    if os.path.isfile(tep):
        return "co"
    ung = []
    for d in cac_noi:
        p = os.path.join(d, "AIHoaDon", "docai_goi.dat")
        if chuan(d) != chuan(dich) and os.path.isfile(p):
            with open(p, "rb") as f:
                if f.read(17) == b"UNESCO-DOCAI-GOI1":
                    ung.append(p)
    if not ung:
        return "khong"
    ung.sort(key=os.path.getmtime, reverse=True)
    shutil.copy2(ung[0], tep)
    noi("  Khoa Google cai san: chep tu %s (khong phai Import lai)" % os.path.dirname(os.path.dirname(ung[0])))
    if giu_may:
        giu_may.giu_khoa(th, None)
    return "chep"


def viet_khoi_phuc(bk, dich, ds_cu, ds_moi):
    with io.open(os.path.join(bk, "DANH_SACH_CAP_NHAT.txt"), "w", encoding="utf-8") as f:
        f.write("Cap nhat %s vao %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), dich))
        f.write("Tep da thay (ban cu nam trong thu muc nay):\n")
        for r in ds_cu:
            f.write("  " + r + "\n")
        f.write("Tep MOI (truoc chua co - khoi phuc khong xoa, xoa tay neu can):\n")
        for r in ds_moi:
            f.write("  " + r + "\n")
    bat = ("@echo off\r\nrem Khoi phuc cac tep da thay khi cap nhat (chep ban cu trong thu muc nay ve lai).\r\n"
           "echo Khoi phuc ve: %s\r\nchoice /C CK /N /M \"Tiep tuc? [C/K]: \"\r\nif errorlevel 2 exit /b 1\r\n"
           "robocopy \"%%~dp0.\" \"%s\" /E /XF KHOI_PHUC.bat DANH_SACH_CAP_NHAT.txt /R:1 /W:1 /NFL /NDL /NJH /NP\r\n"
           "echo Xong.\r\npause\r\n") % (dich, dich)
    with io.open(os.path.join(bk, "KHOI_PHUC.bat"), "w", encoding="ascii", errors="replace", newline="") as f:
        f.write(bat)


def cap_nhat_mot(nguon_goc, ten_nguon, la_nguon_du_an, dich, loai, exe_moi, cac_noi, thu=False):
    noi("")
    noi("=== %s  [%s]" % (dich, "DU AN VB6" if loai == "DU_AN" else "NOI CHAY"))
    if LA_WIN and loai == "DU_AN" and dang_chay("VB6.EXE"):
        noi("  [BO QUA] VB6 dang mo - dong VB6 roi chay lai.")
        return False
    ten_exe = exe_cua(dich)
    if ten_exe and dang_chay(ten_exe):
        noi("  Phan mem %s dang mo - hay THOAT phan mem." % ten_exe)
        if HOI[0]:
            input("  Thoat xong bam Enter de tiep tuc...")
        if dang_chay(ten_exe):
            noi("  [BO QUA] %s van dang chay - khong cap nhat thu muc nay." % ten_exe)
            return False
    ds = ke_hoach(nguon_goc, la_nguon_du_an, dich, loai, exe_moi)
    if not ds:
        noi("  Da moi nhat - khong co tep nao khac.")
    else:
        noi("  %d tep can chep%s" % (len(ds), " (THU - khong chep)" if thu else ""))
        for rel, _ in ds[:12]:
            noi("    " + rel)
        if len(ds) > 12:
            noi("    ... va %d tep khac" % (len(ds) - 12))
    if thu:
        return True
    ts = time.strftime("%Y%m%d_%H%M%S")
    bk = os.path.join(dich, "_sao_luu_%s_%s" % (re.sub(r"[^A-Za-z0-9_.-]+", "_", ten_nguon)[:60], ts))
    ds_cu, ds_moi, loi = [], [], []
    for rel, p in ds:
        dich_p = os.path.join(dich, rel)
        try:
            if os.path.isfile(dich_p):
                b = os.path.join(bk, rel)
                os.makedirs(os.path.dirname(b), exist_ok=True)
                shutil.copy2(dich_p, b)
                ds_cu.append(rel)
            else:
                ds_moi.append(rel)
            os.makedirs(os.path.dirname(dich_p) or dich, exist_ok=True)
            tam = dich_p + ".tam_capnhat"
            shutil.copy2(p, tam)
            os.replace(tam, dich_p)
            if not giong(p, dich_p):
                loi.append(rel + " (chep xong nhung khac noi dung)")
        except Exception as e:
            loi.append("%s (%s)" % (rel, e))
    if ds:
        os.makedirs(bk, exist_ok=True)
        viet_khoi_phuc(bk, dich, ds_cu, ds_moi)
        noi("  Da chep %d tep (%d thay the, %d moi); ban cu sao luu: %s" % (len(ds) - len(loi), len(ds_cu), len(ds_moi), bk))
    for x in loi:
        noi("  [LOI] " + x)
    kh = giu_khoa_dich(dich, cac_noi)
    noi("  Khoa Google cai san (docai_goi.dat): %s" % {"co": "co san / da giu theo may", "chep": "da chep tu noi khac tren may",
                                                       "khong": "CHUA CO tren may nay (Import mot lan, lan sau tu giu)"}[kh])
    if loai == "DU_AN" and LA_WIN and os.path.isfile(os.path.join(nguon_goc, "dang_ky_vbp.vbs")):
        try:
            r = subprocess.run(["cscript", "//nologo", os.path.join(nguon_goc, "dang_ky_vbp.vbs"), os.path.join(dich, "Sas.vbp")],
                               capture_output=True, text=True, timeout=120)
            noi("  Dang ky Sas.vbp: %s" % ("xong" if r.returncode == 0 else "LOI %s" % (r.stdout + r.stderr)[-300:]))
        except Exception as e:
            noi("  [LOI] dang ky Sas.vbp: %s" % e)
    if loai == "DU_AN":
        noi("  -> Mo VB6: Sas.vbp -> Full Compile -> Make .exe; roi nhap dup CAP_NHAT_TU_DONG.bat TRONG THU MUC DU AN de day .exe sang noi chay.")
    if giu_may:
        giu_may.ghi_noi_cai(dich)
    try:
        os.makedirs(os.path.join(dich, "LOG"), exist_ok=True)
        with io.open(os.path.join(dich, "LOG", "CAP_NHAT_%s.txt" % ts), "w", encoding="utf-8") as f:
            f.write("\n".join(LOG) + "\n")
    except Exception:
        pass
    return not loi


HOI = [True]


def chon(ds, mac_dinh):
    noi("")
    noi("Noi cai phan mem tim thay:")
    for i, (d, l, luc) in enumerate(ds, 1):
        exe = exe_cua(d)
        noi("  %d. [%s] %s%s%s" % (i, "DU AN" if l == "DU_AN" else "CHAY ", d, ("  (.exe %s)" % exe) if exe and l != "DU_AN" else "",
                                   ("  - dung luc %s" % luc) if luc else ""))
    md = ",".join(str(i + 1) for i in mac_dinh)
    if not HOI[0]:
        return [ds[i] for i in mac_dinh]
    tl = input("Chon so can cap nhat (vd 1,3; A = tat ca; Enter = %s; 0 = thoat): " % (md or "thoat")).strip().upper()
    if tl == "0":
        return []
    if tl == "A":
        return list(ds)
    if not tl:
        return [ds[i] for i in mac_dinh]
    so = [int(x) for x in re.findall(r"\d+", tl)]
    return [ds[i - 1] for i in so if 1 <= i <= len(ds)]


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    goi, dich, thu, quet = None, [], False, True
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--goi" and i + 1 < len(argv):
            goi = argv[i + 1]
            i += 2
            continue
        if a == "--dich" and i + 1 < len(argv):
            dich.append(argv[i + 1])
            i += 2
            continue
        if a == "--khong-hoi":
            HOI[0] = False
        elif a == "--thu":
            thu = True
        elif a == "--khong-quet":
            quet = False
        elif os.path.isfile(a) and a.lower().endswith(".zip"):
            goi = a                                       # keo tha tep goi .zip
        elif os.path.isdir(a):
            if loai_dich(a) or la_du_an(a):
                dich.append(a)                            # keo tha thu muc phan mem
            elif os.path.isfile(os.path.join(a, TOOL_MOC)):
                goi = a
        i += 1
    goc_mac_dinh = os.path.dirname(HERE)
    nguon_goc, ten_nguon, tam = mo_nguon(goi or goc_mac_dinh)
    noi("CAP NHAT TU DONG UNESCO XI + AI (%s)" % PHIEN_BAN)
    noi("Nguon: %s" % (goi or nguon_goc))
    if not os.path.isfile(os.path.join(nguon_goc, TOOL_MOC)):
        noi("[LOI] Nguon khong phai goi cap nhat UNESCO (thieu %s)." % TOOL_MOC)
        return 2
    la_nguon_du_an = la_du_an(nguon_goc)
    exe_moi = ""
    if la_nguon_du_an:
        exe_moi = exe_du_an(nguon_goc)
        noi("Nguon la THU MUC DU AN VB6 -> day .exe vua Make + AIHoaDon sang noi chay.")
        if exe_moi:
            moi_nhat = max((os.path.getmtime(os.path.join(nguon_goc, t)) for t in os.listdir(nguon_goc)
                            if t.lower().endswith((".frm", ".bas", ".cls"))), default=0)
            noi(".exe Make: %s (%s)" % (exe_moi, time.strftime("%d/%m/%Y %H:%M", time.localtime(os.path.getmtime(exe_moi)))))
            if os.path.getmtime(exe_moi) < moi_nhat:
                noi("[CANH BAO] .exe cu hon ma nguon (co tep .frm/.bas sua sau lan Make .exe cuoi) - nen Full Compile + Make .exe lai.")
        else:
            noi("[CANH BAO] Chua thay .exe Make tu du an (Sas.vbp Path32 / ExeName32) - chi day AIHoaDon.")
    else:
        e = exe_cua(nguon_goc)
        exe_moi = os.path.join(nguon_goc, e) if e else ""
    try:
        if dich:
            ds = []
            for d in dich:
                ld = loai_dich(d) or ("DU_AN" if la_du_an(d) else "")
                if not ld:
                    noi("[BO QUA] %s: khong phai noi cai UNESCO (thieu %s / .exe / Sas.vbp)." % (d, TOOL_MOC))
                    continue
                ds.append((os.path.abspath(d), ld, ""))
            chon_ds = ds
        else:
            ds = tim_dich(nguon_goc, quet)
            if la_nguon_du_an:
                ds = [x for x in ds if x[1] == "NOI_CHAY"]
            if not ds:
                noi("Khong tim thay noi cai phan mem nao. Keo tha thu muc phan mem (noi co file .exe) vao CAP_NHAT_TU_DONG.bat.")
                return 1
            # mac dinh: noi phan mem / tool DA CHAY tren may nay (co trong noi_cai.txt); chua co thi tat ca noi tim thay
            mac_dinh = [k for k, x in enumerate(ds) if x[2]] or list(range(len(ds)))
            chon_ds = chon(ds, mac_dinh)
        if not chon_ds:
            noi("Khong chon thu muc nao - thoat.")
            return 1
        cac_noi = [x[0] for x in tim_dich(nguon_goc, False)] + [x[0] for x in chon_ds]
        ok = True
        for d, ld, _ in chon_ds:
            ok = cap_nhat_mot(nguon_goc, ten_nguon, la_nguon_du_an, d, ld, exe_moi, cac_noi, thu) and ok
        noi("")
        noi("XONG." if ok else "XONG - CO LOI (xem dong [LOI] o tren).")
        return 0 if ok else 1
    finally:
        if tam:
            shutil.rmtree(tam, ignore_errors=True)


if __name__ == "__main__":
    sys.exit(main())
