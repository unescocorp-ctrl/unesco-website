# -*- coding: utf-8 -*-
"""KHOA TAI HOA DON THEO MST (18/11/2026, phan tich bo prompt HDDT - dot 5 «hai lan bam / hai tien trinh cung MST»).

Mot luc chi MOT tien trinh tren may duoc goi cong thue (tra cuu / dong bo / tai) cho cung mot MST: cua so Tai hoa don cua XII
(tool_tai_hoa_don_unesco.py), lo tai hoa don (tai_hoa_don_theo_lo.py), hai cua so mo cung so, hai so cung cong ty. Truoc day chi co
khoa TRONG mot tien trinh (STATE_LOCK) - hai cua so cung MST chay song song duoc, cung phien / cung gioi han cua cong.

Tep khoa: %LOCALAPPDATA%\\UNESCO_AI\\khoa_tai_hddt\\<MST so>.lock (doi bang bien UNESCO_KHOA_TAI_DIR - de kiem thu), noi dung JSON
{pid, may, luc, viec}. Tao bang O_EXCL (nguyen tu). Khoa bo quen (tien trinh ghi khoa da tat, hoac qua 12 gio) -> bo, lay lai.
Trong CUNG tien trinh: dem so lan lay (lay lai duoc), tra het moi xoa tep. Khong luu mat khau / token / cookie.
"""
import json
import os
import re
import socket
import threading
import time

QUA_HAN_GIAY = 12 * 3600
_DEM = {}
_KHOA = threading.Lock()


def thu_muc():
    d = os.environ.get("UNESCO_KHOA_TAI_DIR") or os.path.join(
        os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"), "UNESCO_AI", "khoa_tai_hddt")
    return d


def mst_so(mst):
    return re.sub(r"\D", "", str(mst or ""))


def _may():
    try:
        return re.sub(r"[^A-Za-z0-9._-]", "", socket.gethostname())[:60] or "may"
    except Exception:
        return "may"


def con_song(pid):
    """Tien trinh pid con chay? True / False / None (khong biet)."""
    try:
        pid = int(pid)
    except Exception:
        return None
    if pid <= 0:
        return False
    if pid == os.getpid():
        return True
    if os.name == "nt":
        try:
            import ctypes
            from ctypes import wintypes
            k32 = ctypes.WinDLL("kernel32", use_last_error=True)
            k32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
            k32.OpenProcess.restype = wintypes.HANDLE
            k32.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
            k32.CloseHandle.argtypes = [wintypes.HANDLE]
            h = k32.OpenProcess(0x1000, False, pid)          # PROCESS_QUERY_LIMITED_INFORMATION
            if not h:
                return False if ctypes.get_last_error() == 87 else None          # 87 = khong co tien trinh nay
            try:
                ma = wintypes.DWORD()
                if not k32.GetExitCodeProcess(h, ctypes.byref(ma)):
                    return None
                return ma.value == 259          # STILL_ACTIVE
            finally:
                k32.CloseHandle(h)
        except Exception:
            return None
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except Exception:
        return None


def _duong(so):
    return os.path.join(thu_muc(), so + ".lock")


def doc(mst):
    """Thong tin khoa dang co (dict) hoac None."""
    so = mst_so(mst)
    if not so:
        return None
    try:
        with open(_duong(so), encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def _ban(so):
    """'' khi khong ai khac giu khoa cua MST (khoa bo quen thi don luon); nguoc lai thong bao. Goi trong _KHOA."""
    p = _duong(so)
    if not os.path.exists(p):
        return ""
    cu = doc(so) or {}
    if str(cu.get("pid")) == str(os.getpid()) and cu.get("may") in (None, "", _may()):
        return ""
    try:
        tuoi = time.time() - os.path.getmtime(p)
    except Exception:
        tuoi = 0
    song = con_song(cu.get("pid")) if cu.get("may") in (None, "", _may()) else None
    if song is False or tuoi > QUA_HAN_GIAY or (not cu and tuoi > 5):
        try:
            os.remove(p)          # khoa bo quen: tien trinh da tat / qua han / tep hong
        except FileNotFoundError:
            pass
        except Exception:
            return "Không gỡ được khoá cũ %s." % p
        return ""
    return ("Máy này đang có %s tải hoá đơn của MST %s (từ %s, tiến trình %s). Hai việc cùng gọi cổng thuế cho một MST "
            "dễ bị cổng chặn / lẫn phiên - đợi việc đó xong (hoặc đóng cửa sổ đó) rồi làm lại."
            % (cu.get("viec") or "một cửa sổ khác", so, cu.get("luc") or "?", cu.get("pid") or "?"))


def kiem(mst):
    """Chi kiem (khong lay): '' khi lam duoc, nguoc lai thong bao vi sao khong."""
    so = mst_so(mst)
    if not so:
        return ""
    with _KHOA:
        return "" if _DEM.get(so) else _ban(so)


def lay(mst, viec):
    """-> (True, '') khi lay duoc (hoac khong co MST de khoa); (False, thong bao tieng Viet) khi tien trinh khac dang giu."""
    so = mst_so(mst)
    if not so:
        return True, ""
    with _KHOA:
        if _DEM.get(so):
            _DEM[so] += 1
            return True, ""
        os.makedirs(thu_muc(), exist_ok=True)
        p = _duong(so)
        for _ in range(3):
            try:
                fd = os.open(p, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            except FileExistsError:
                tb = _ban(so)
                if tb:
                    return False, tb
                if os.path.exists(p):          # tep cua chinh tien trinh nay con sot (khong qua dem): ghi de
                    try:
                        os.remove(p)
                    except Exception:
                        break
                continue
            else:
                with os.fdopen(fd, "w", encoding="utf-8") as f:
                    json.dump({"pid": os.getpid(), "may": _may(), "luc": time.strftime("%d/%m/%Y %H:%M"), "viec": str(viec or "")},
                              f, ensure_ascii=False)
                _DEM[so] = 1
                return True, ""
        return False, "Không lấy được khoá tải hoá đơn của MST %s (thư mục %s)." % (so, thu_muc())


def tra(mst):
    """Tra mot lan lay; het lan cuoi thi xoa tep khoa (chi tep cua chinh tien trinh nay)."""
    so = mst_so(mst)
    if not so:
        return
    with _KHOA:
        n = _DEM.get(so, 0)
        if n > 1:
            _DEM[so] = n - 1
            return
        _DEM.pop(so, None)
        cu = doc(so) or {}
        if str(cu.get("pid")) == str(os.getpid()):
            try:
                os.remove(_duong(so))
            except Exception:
                pass
