# -*- coding: utf-8 -*-
"""GD164 - XEM TRUOC TRUOC KHI DUA VAO HTKK: so sanh to khai XML vua lap voi to khai KY TRUOC + kiem cheo TRONG KY.
CHI DOC (khong sua to khai, khong ghi HTKK, khong nop thay). Anh Thang 08/10/2026: "khi bam xuat HTKK tat ca cac bieu mau
(GTGT, TNDN, TNCN, BCTC) so lieu phai xuat vao dung mau, so sanh canh bao so lieu ky truoc, trong ky va cho nguoi dung xem truoc".

Luong: Xuat 1 lan kieu "XP" (xuat_1_lan.chay) / tool /sosanhhtkk:<tep|thu muc> -> xem_truoc(ds_xml, ...) -> cac dong bao cao
(0_KET_QUA.txt / ket-qua\\XEM_TRUOC_HTKK.txt) + XemTruoc_SoSanh.xlsx. VB hien man hinh Xem truoc; bam "Dua vao HTKK" moi chep.

To khai ky truoc (cung MST, cung mau), uu tien:
  4 the Ho so thue (to khai tai ve tu Cong thue - da nop)   3 to khai luu tru / thu muc to khai anh chi da chon
  2 HTKK tren may (DataFiles\\<MST>, cac tep sheet HTKK tu luu)   1 lan xuat truoc cua phan mem (BaoCaoNam / ToKhaiTNCN)
  Cung nguon: bo sung lan sau thay lan truoc, ban moi hon thay ban cu.
Muc canh bao: [!] sai lech phai xem (so chuyen ky khong khop, tong khong khop); [?] nen kiem tra (bien dong lon, doi dau,
  ky nay bang 0); [i] thong tin (khong tim thay ky truoc, mau khac).
Doi chieu TNCN voi so (DC_TNCN, hop dong xuat_1_lan.lap): bang thang thu nhap / thue bang luong - PS Co 334 / 3335 - Nop (No 3335)
  - 05/KK tinh tu bang luong so voi 05/KK da khai theo quy.
Khong ghi so CCCD / MST vao nhat ky."""
import calendar
import io
import os
import re
import time
import zipfile
import xml.etree.ElementTree as ET
from datetime import date, datetime, timedelta

GIAY_QUET = 20                 # tong thoi gian quet cac nguon ky truoc (giay)
TOI_DA_TEP = 400
NGUONG_TIEN = 10000000         # bien dong tien >= 10 trieu
TY_LE = 0.5                    # va >= 50 %
NGUONG_NGUOI = 3               # so nguoi: >= 3 nguoi va >= 30 %
TY_LE_NGUOI = 0.3
TEN_EXCEL = "XemTruoc_SoSanh.xlsx"
THU_MUC_XUAT = ("BaoCaoNam", "ToKhaiTNCN", "BaoCaoThue")      # lan xuat truoc cua phan mem (<thu muc khach>\\<ten>\\<gio>)

# Ma tep HTKK cua bo BCTC phan mem lap / doc (TT133 B01a, B01b, KLT; TT200; TT99) - HTKK con nhieu bo BCTC nganh khac
BCTC_DAU = ("133_B01", "200_01_CDKT", "99_BCTC", "99_01_THTC", "58_BCTC", "58_B01")          # GD171: 58_BCTC TT58 DNSN
HO_TEN = {"GTGT": "01/GTGT", "KK": "05/KK-TNCN", "QTT": "05/QTT-TNCN", "TNDN": "03/TNDN", "BCTC": "Báo cáo tài chính",
          "CNKD": "01/CNKD"}          # GD172: ho kinh doanh

# chi tieu chinh (khoa phang -> ten ngan) theo ho to khai
CT_QTT = [("NVuKhauTruThue/ct16", "[16] Tổng số người lao động", "N"), ("NVuKhauTruThue/ct18", "[18] Số cá nhân đã khấu trừ thuế", "N"),
          ("NVuKhauTruThue/ct23", "[23] Tổng thu nhập chịu thuế trả cho cá nhân", "T"),
          ("NVuKhauTruThue/ct28", "[28] TNCT thuộc diện phải khấu trừ", "T"),
          ("NVuKhauTruThue/ct31", "[31] Tổng thuế TNCN đã khấu trừ", "T"),
          ("NVuQToanThay/ct35", "[35] Số cá nhân ủy quyền quyết toán thay", "N"), ("NVuQToanThay/ct36", "[36] Thuế đã khấu trừ (ủy quyền)", "T"),
          ("NVuQToanThay/ct38", "[38] Tổng thuế TNCN phải nộp", "T"), ("NVuQToanThay/ct40", "[40] Thuế TNCN còn phải nộp", "T"),
          ("NVuQToanThay/ct41", "[41] Thuế TNCN đã nộp thừa", "T")]
CT_GTGT = [("ct22", "[22] Thuế GTGT còn được khấu trừ kỳ trước chuyển sang", "T"), ("ct23", "[23] Giá trị HHDV mua vào", "T"),
           ("ct24", "[24] Thuế GTGT của HHDV mua vào", "T"), ("ct25", "[25] Thuế GTGT được khấu trừ kỳ này", "T"),
           ("ct34", "[34] Tổng doanh thu HHDV bán ra", "T"), ("ct35", "[35] Thuế GTGT của HHDV bán ra", "T"),
           ("ct36", "[36] Thuế GTGT phát sinh trong kỳ", "T"), ("ct40", "[40] Thuế GTGT còn phải nộp trong kỳ", "T"),
           ("ct41", "[41] Thuế GTGT chưa khấu trừ hết kỳ này", "T"), ("ct43", "[43] Thuế GTGT còn được khấu trừ chuyển kỳ sau", "T")]
# khi HTKK tren may khong doc duoc Menu.xml: DataFile chinh theo ten tep HTKK that (khong co phu luc)
DF_MAC_DINH = {"KK": ["05_KK_TNCN_TT80", "05_KK_TNCN"], "QTT": ["05_QTT_TNCN_TT80", "05_QTT_TNCN"], "TNDN": ["03_TNDN_TT80", "03_TNDN"],
               "CNKD": ["01_CNKD_HKD_TT50", "01_CNKD_HKD", "01_CNKD_TT40", "01_CNKD"],
               "GTGT": ["01_GTGT_TT80", "01_GTGT"], "BCTC": ["133_B01A_01_THTC", "133_B01B_01_THTC", "133_B01_01_THTC_KLT", "200_01_CDKT", "99_01_THTC",
                                                           "58_B01_01_THTC"]}
CT_TNDN_CHINH = ["A1", "B1", "B8", "B13", "C1", "C3", "C4", "C9", "C17", "E", "G", "I"]
CT_KK_CHINH = ["16", "18", "21", "26", "29"]
CT_B01_CHINH = [100, 110, 120, 130, 140, 150, 160, 170, 180, 200, 300, 400, 500, 600]
CT_B02_CHINH = [1, 2, 10, 11, 20, 21, 22, 24, 30, 31, 32, 40, 50, 51, 60]
CT_B03_CHINH = [20, 30, 40, 50, 60, 70]
# GD172: 01/CNKD (khoa phang trong CTieuTKhaiChinh - tong cac dia diem / nhom nganh)
CT_CNKD = [("KhaiThueGTGTTNCN/TongCongCT18/tongCT11", "[18] Tổng doanh thu tính thuế GTGT [11]", "T"),
           ("KhaiThueGTGTTNCN/TongCongCT18/tongCT12", "[18] Doanh thu không chịu thuế GTGT [12]", "T"),
           ("KhaiThueGTGTTNCN/TongCongCT18/tongCT13", "[18] Doanh thu chịu thuế suất 0% [13]", "T"),
           ("KhaiThueGTGTTNCN/TongCongCT18/tongCT14", "[18] Tổng thuế GTGT phải nộp [14]", "T"),
           ("KhaiThueGTGTTNCN/TongCongCT18/tongCT15", "[18] Tổng doanh thu tính thuế TNCN [15]", "T"),
           ("KhaiThueGTGTTNCN/TongCongCT18/tongCT16", "[18] Doanh thu được trừ [16]", "T"),
           ("KhaiThueGTGTTNCN/TongCongCT18/tongCT17", "[18] Tổng thuế TNCN phải nộp [17]", "T"),
           ("KhaiThueGTGTTNCN/SoThueConPhaiNopCT20/soThueGTGT_ct14", "[20] Thuế GTGT còn phải nộp", "T"),
           ("KhaiThueGTGTTNCN/SoThueConPhaiNopCT20/soThueTNCN_ct17", "[20] Thuế TNCN còn phải nộp", "T"),
           ("soTienTruKyTiep", "Doanh thu được trừ còn chuyển kỳ sau", "T")]


def _ten(tag):
    return tag.split("}", 1)[-1] if isinstance(tag, str) else ""


def _so(v):
    try:
        s = str(v).strip().replace(",", "")
        if not s:
            return None
        return float(s)
    except (TypeError, ValueError):
        return None


def _vn(x):
    try:
        x = float(x or 0)
    except (TypeError, ValueError):
        return str(x)
    s = "{:,.0f}".format(abs(x)).replace(",", ".")
    return ("-" if x < 0 else "") + s


def _pt(p):
    return ("%+.1f%%" % (p * 100)).replace(".", ",")


def _ngay(s):
    s = str(s or "").strip()
    for f in ("%d/%m/%Y", "%Y-%m-%d", "%d-%m-%Y"):
        try:
            return datetime.strptime(s[:10], f).date()
        except ValueError:
            continue
    return None


def _cuoi_thang(y, m):
    return date(y, m, calendar.monthrange(y, m)[1])


def _mst(s):
    return re.sub(r"[^0-9]", "", str(s or ""))


# ------------------------------------------------------------------ doc to khai
def _phang(nut, goc, ra, dem):
    """La so ct* trong nut -> ra[khoa tuong doi]; nhom lap (nhieu con cung ten: dong bang ke) chi dem so dong."""
    con = list(nut)
    if not con:
        return
    so_ten = {}
    for c in con:
        so_ten[_ten(c.tag)] = so_ten.get(_ten(c.tag), 0) + 1
    for c in con:
        t = _ten(c.tag)
        if so_ten[t] > 1:
            dem[goc + t] = so_ten[t]
            continue
        if len(c):
            _phang(c, goc + t + "/", ra, dem)
        elif re.fullmatch(r"ct\w+", t) or t.startswith("thueTNDN_tamnop") or re.fullmatch(r"(tongCT\d+|soThue\w+|soTienTruKyTiep)", t):
            v = _so(c.text)                    # GD172: o tong 01/CNKD (tongCT11..17, soThueGTGT_ct14, soTienTruKyTiep)
            if v is not None:
                ra[goc + t] = v


def _ho_tu(ma_file, ten, ct_keys):
    s = (ma_file or "").upper()
    t = (ten or "").upper()
    if s.startswith("05_KK_TNCN") or "05/KK-TNCN" in t:
        return "KK"
    if s.startswith("05_QTT_TNCN") or "05/QTT-TNCN" in t or any(k.startswith("NVuKhauTruThue/") for k in ct_keys):
        return "QTT"
    if s.startswith("03_TNDN") or "03/TNDN" in t:
        return "TNDN"
    if s.startswith("01_GTGT") or "01/GTGT" in t:
        return "GTGT"
    if s.startswith("01_CNKD") or "HỘ KINH DOANH, CÁ NHÂN KINH DOANH" in t or any(k.startswith("KhaiThueGTGTTNCN/") for k in ct_keys):
        return "CNKD"                                                  # GD172
    if s.startswith(BCTC_DAU) or "B01" in t or "TÀI CHÍNH" in t or any(k.startswith("SoCuoiNam/") for k in ct_keys):
        return "BCTC"
    return ""


def _ky_tu_ngay(kieu, d1, d2):
    """-> ('M'|'Q'|'Y', d1, d2) chuan."""
    if not d1 or not d2:
        return None
    if kieu not in ("M", "Q", "Y"):
        n = (d2.year - d1.year) * 12 + d2.month - d1.month + 1
        kieu = "M" if n == 1 else "Q" if n == 3 and (d1.month - 1) % 3 == 0 else "Y"
    return (kieu, d1, d2)


def doc_xml_tk(p, du_lieu=None, nguon=""):
    """To khai XML dang HTKK ket xuat / tai tu Cong thue -> dict hoac None."""
    try:
        if du_lieu is None:
            with open(p, "rb") as f:
                du_lieu = f.read()
        b = du_lieu
        if b[:2] in (b"\xff\xfe", b"\xfe\xff"):
            b = b.decode("utf-16").encode("utf-8")
        b = re.sub(rb"^\s*(\xef\xbb\xbf)?\s*<\?xml[^>]*\?>", b"", b)
        goc = ET.fromstring(b)
    except Exception:
        return None
    hs = None
    for e in goc.iter():
        if _ten(e.tag) == "HSoKhaiThue":
            hs = e
            break
    if hs is None:
        return None

    def lay(ten):
        for e in hs.iter():
            if _ten(e.tag) == ten:
                return (e.text or "").strip()
        return ""
    ct, dem = {}, {}
    for c in hs:
        t = _ten(c.tag)
        if t == "CTieuTKhaiChinh":
            _phang(c, "", ct, dem)
        elif t == "PLuc":
            for pl in c:
                _phang(pl, _ten(pl.tag) + "/", ct, dem)
    d1, d2 = _ngay(lay("kyKKhaiTuNgay")), _ngay(lay("kyKKhaiDenNgay"))
    kieu = lay("kieuKy").upper()
    ky = lay("kyKKhai")
    if not (d1 and d2):
        m1 = re.fullmatch(r"(\d{1,2})/(\d{4})", lay("kyKKhaiTuThang"))
        m2 = re.fullmatch(r"(\d{1,2})/(\d{4})", lay("kyKKhaiDenThang"))
        if m1 and m2:
            d1, d2 = date(int(m1.group(2)), int(m1.group(1)), 1), _cuoi_thang(int(m2.group(2)), int(m2.group(1)))
    if not (d1 and d2):
        m = re.fullmatch(r"(\d)/(\d{4})", ky)
        if kieu == "Q" and m:
            q, y = int(m.group(1)), int(m.group(2))
            d1, d2 = date(y, 3 * q - 2, 1), _cuoi_thang(y, 3 * q)
        m = re.fullmatch(r"(\d{1,2})/(\d{4})", ky)
        if not d1 and m:
            y, th = int(m.group(2)), int(m.group(1))
            d1, d2 = date(y, th, 1), _cuoi_thang(y, th)
        m = re.fullmatch(r"(\d{4})", ky)
        if not d1 and m:
            d1, d2 = date(int(ky), 1, 1), date(int(ky), 12, 31)
    k = _ky_tu_ngay(kieu, d1, d2)
    if not k:
        return None
    ma, ten = lay("maTKhai"), lay("tenTKhai")
    try:
        lan = int(re.sub(r"\D", "", lay("soLan")) or 0)
    except ValueError:
        lan = 0
    return {"tep": p, "ma": ma, "pban": lay("pbanTKhaiXML"), "ten": ten, "ma_file": "", "ho": _ho_tu("", ten, ct),
            "ky": k, "loai": (lay("loaiTKhai") or "C").upper(), "lan": lan, "bs": (lay("loaiTKhai") or "").upper() == "B" or lan > 0,
            "mst": _mst(lay("mst")), "ct": ct, "dem": dem, "nguon": nguon, "hang": 0, "ngay": lay("ngayLapTKhai")}


_RE_TEP = re.compile(r"^(bs(\d+)_)?(.+?)_(\d{3,4})(?: \(\d+\))?\.xml$", re.I)


_RE_BAN_SAO = re.compile(r"^(.*) \(\d+\)\.xml$", re.I)


def _la_ban_sao(f, co):
    """GD168: 'X (1).xml' khi thu muc con 'X.xml' (co = ten tep chu thuong) -> True: HTKK chi mo 'X.xml', ban sao bo qua."""
    m = _RE_BAN_SAO.match(f)
    return bool(m) and (m.group(1) + ".xml").lower() in co


def _ky_ten_tep(than):
    """phan ky cua ten tep HTKK -> (kieu, d1, d2) hoac None. 'Q032026' / '072026' / '2025_01012025_31122025' / '2025_012025_122025'."""
    tok = than.split("_")
    tok = [t for t in tok if not re.fullmatch(r"CQTQL\d+", t, re.I)]
    q = [t for t in tok if re.fullmatch(r"Q\d{6}", t, re.I)]
    if q:
        n, y = int(q[0][1:3]), int(q[0][3:])
        if 1 <= n <= 4:
            return ("Q", date(y, 3 * n - 2, 1), _cuoi_thang(y, 3 * n))
        return None
    t8 = [t for t in tok if re.fullmatch(r"\d{8}", t)]
    if len(t8) >= 2:
        try:
            a = datetime.strptime(t8[0], "%d%m%Y").date()
            b = datetime.strptime(t8[1], "%d%m%Y").date()
            return _ky_tu_ngay("Y" if (b - a).days > 100 else "", a, b)
        except ValueError:
            return None
    t6 = [t for t in tok if re.fullmatch(r"\d{6}", t)]
    if len(t6) >= 2:
        try:
            a = date(int(t6[0][2:]), int(t6[0][:2]), 1)
            b = _cuoi_thang(int(t6[1][2:]), int(t6[1][:2]))
            return _ky_tu_ngay("", a, b)
        except ValueError:
            return None
    if len(t6) == 1:
        m, y = int(t6[0][:2]), int(t6[0][2:])
        if 1 <= m <= 12:
            return ("M", date(y, m, 1), _cuoi_thang(y, m))
    return None


def doc_tep_htkk(ds_tep):
    """Cac tep sheet HTKK tu luu (Sections / Cell Path=... Value=...) cua MOT to khai -> {khoa: so}."""
    ct = {}
    for p in ds_tep:
        try:
            with open(p, "rb") as f:
                b = f.read()
            s = b.decode("utf-16") if b[:2] in (b"\xff\xfe", b"\xfe\xff") else b.decode("utf-8-sig", errors="replace")
            g = ET.fromstring(re.sub(r"^\s*<\?xml[^>]*\?>", "", s))
        except Exception:
            continue
        for c in g.iter():
            if _ten(c.tag) != "Cell":
                continue
            duong = (c.get("Path") or "").strip()
            if not duong or not re.search(r"(^|/)ct\w+$|thueTNDN_tamnop\w*$|(^|/)(tongCT\d+|soThue\w+|soTienTruKyTiep)$", duong):
                continue
            if "/CTieuTKhaiChinh/" in duong:
                k = duong.split("/CTieuTKhaiChinh/", 1)[1]
            elif "/PLuc/" in duong:
                k = duong.split("/PLuc/", 1)[1]
            elif duong.startswith("HSoThueDTu"):
                continue
            else:
                k = duong
            v = _so(c.get("Value"))
            if v is not None and k not in ct:
                ct[k] = v
    return ct


# ------------------------------------------------------------------ menu HTKK (ma file, sheet)
def _menu(goc_htkk):
    if not goc_htkk:
        return []
    try:
        import htkk_dua_vao as DV
        return DV.doc_menu(goc_htkk)
    except Exception:
        return []


def _menu_cua(menu, tk):
    cung = [m for m in menu if m.get("MaToKhai") == str(tk.get("ma") or "").strip()]
    if not cung:
        return None
    for m in cung:
        if m.get("VersionXML") == tk.get("pban"):
            return m
    return cung[-1]


def _df_cua_ho(menu, ho, ma_file):
    """DataFile cac sheet cua moi to khai cung ho (dung mau truoc: ten tep HTKK theo DataFile). -> [(MaFile, [DataFile...])]"""
    ra = []
    for m in menu:
        mf = m.get("MaFile") or ""
        if ho == "BCTC" and mf != ma_file and not mf.startswith(BCTC_DAU):
            continue
        dfs = [s.get("DataFile", "") for s in m.get("sheets") or [] if s.get("DataFile")
               and not s.get("DataFile", "").upper().startswith("KHBS")]
        if not dfs:
            continue
        if mf == ma_file or (_ho_tu(mf, m.get("ten", ""), []) == ho and ho):
            ra.append((mf, dfs))
    ra.sort(key=lambda x: 0 if x[0] == ma_file else 1)
    return ra


# ------------------------------------------------------------------ ky truoc
def ky_truoc(k):
    kieu, d1, d2 = k
    if kieu == "M":
        a = (d1.replace(day=1) - timedelta(days=1)).replace(day=1)
        return ("M", a, _cuoi_thang(a.year, a.month))
    if kieu == "Q":
        q, y = (d1.month - 1) // 3 + 1, d1.year
        q, y = (4, y - 1) if q == 1 else (q - 1, y)
        return ("Q", date(y, 3 * q - 2, 1), _cuoi_thang(y, 3 * q))
    try:
        return ("Y", d1.replace(year=d1.year - 1), d2.replace(year=d2.year - 1))
    except ValueError:
        return ("Y", date(d1.year - 1, d1.month, 1), _cuoi_thang(d2.year - 1, d2.month))


def _ten_ky(k):
    if not k:
        return ""
    kieu, d1, d2 = k
    if kieu == "M":
        return "tháng %02d/%d" % (d1.month, d1.year)
    if kieu == "Q":
        return "quý %d/%d" % ((d1.month - 1) // 3 + 1, d1.year)
    if d1.month == 1 and d1.day == 1 and d2.month == 12:
        return "năm %d" % d1.year
    return "năm tài chính %s - %s" % (d1.strftime("%d/%m/%Y"), d2.strftime("%d/%m/%Y"))


def _khop_ky(a, b, ho):
    """a: ky can, b: ky cua to khai. Nam: cung ngay cuoi (hoac cung nam duong lich khi khong ro ngay)."""
    if not a or not b:
        return False
    if a[0] in ("M", "Q") or b[0] in ("M", "Q"):
        return a[0] == b[0] and a[1] == b[1] and a[2] == b[2]
    if a[2] == b[2]:
        return True
    ca_nam = (a[2] - a[1]).days >= 300 and (b[2] - b[1]).days >= 300          # bo bao cao giua nien do (6 thang)
    return ca_nam and a[1].year == b[1].year and a[2].year == b[2].year


def _uu(x):
    return (x.get("hang", 0), 1 if x.get("bs") else 0, x.get("lan", 0), x.get("pb", 0), x.get("mtime", 0))


class Nguon(object):
    """Bo nho cac to khai tim duoc (mot lan quet cho ca lo)."""

    def __init__(self, mst, thu_muc_khach="", htkk_goc="", bo_qua=(), log=None):
        self.mst = _mst(mst)
        self.khach = thu_muc_khach or ""
        self.goc = htkk_goc or ""
        self.bo_qua = set(os.path.normcase(os.path.abspath(x)) for x in bo_qua if x)
        self.log = log or (lambda s: None)
        self.menu = _menu(self.goc)
        self._xml = None
        self.da_quet = []

    # ---- to khai XML / ZIP (Ho so thue, luu tru, thu muc chon, lan xuat truoc)
    def _thu_muc_xml(self):
        """Thu tu quet: lan xuat truoc cua phan mem (it tep) -> Ho so thue -> luu tru -> thu muc to khai da chon (co the lan
        nhieu XML hoa don) sau cung; moi nguon toi da TOI_DA_TEP tep, chung GIAY_QUET giay."""
        ds = []
        if self.khach:
            for ten in THU_MUC_XUAT:
                ds.append((os.path.join(self.khach, ten), "lần xuất trước của phần mềm", 1, True))
            ds.append((os.path.join(self.khach, "ho-so-thue"), "thẻ Hồ sơ thuế", 4, True))
            ds.append((os.path.join(self.khach, "to-khai-luu-tru"), "tờ khai lưu trữ", 3, True))
            try:
                import nguon_ky_truoc as NKT
                t = NKT.thu_muc_to_khai(self.khach)
                if t:
                    ds.append((t, "thư mục tờ khai đã chọn", 3, True))
            except Exception:
                pass
        return ds

    def xml(self):
        if self._xml is not None:
            return self._xml
        ra = []
        het = time.time() + GIAY_QUET
        for d, nhan, hang, de_quy in self._thu_muc_xml():
            if not d or not os.path.isdir(d):
                continue
            n = 0
            if nhan not in self.da_quet:
                self.da_quet.append(nhan)
            for goc, dn, fs in os.walk(d):
                if time.time() > het or n >= TOI_DA_TEP:
                    break
                if not de_quy:
                    dn[:] = []
                dn[:] = [x for x in dn if x not in ("chan-doan", "_dang_tai", "__pycache__")]
                for f in fs:
                    if time.time() > het or n >= TOI_DA_TEP:
                        break
                    fl = f.lower()
                    if not (fl.endswith(".xml") or fl.endswith(".zip")):
                        continue
                    p = os.path.join(goc, f)
                    if os.path.normcase(os.path.abspath(p)) in self.bo_qua:
                        continue
                    try:
                        if os.path.getsize(p) > 20 * 1024 * 1024:
                            continue
                        mt = os.path.getmtime(p)
                    except OSError:
                        continue
                    n += 1
                    for x in self._doc_xml_zip(p, "%s: %s" % (nhan, f)):
                        if self.mst and x["mst"] and x["mst"] != self.mst:
                            continue
                        x["hang"], x["mtime"] = hang, mt
                        ra.append(x)
        self._xml = ra
        return ra

    @staticmethod
    def _doc_xml_zip(p, nguon):
        ra = []
        try:
            if zipfile.is_zipfile(p):
                with zipfile.ZipFile(p) as z:
                    for n in z.namelist():
                        if n.lower().endswith(".xml"):
                            x = doc_xml_tk(n, z.read(n), nguon)
                            if x:
                                ra.append(x)
                return ra
            with open(p, "rb") as f:
                b = f.read()
            if b"HSoKhaiThue" not in b and b"H\x00S\x00o\x00K\x00h\x00a\x00i" not in b:
                return ra
            x = doc_xml_tk(p, b, nguon)
            if x:
                ra.append(x)
        except Exception:
            pass
        return ra

    # ---- HTKK tren may
    def _thu_mst(self):
        if not (self.goc and self.mst):
            return ""
        d = os.path.join(self.goc, "DataFiles", self.mst)
        if os.path.isdir(d):
            return d
        try:
            for e in os.scandir(os.path.join(self.goc, "DataFiles")):
                if e.is_dir() and _mst(e.name) == self.mst:
                    return e.path
        except Exception:
            pass
        return ""

    def htkk(self, tk, k_can):
        """To khai HTKK tu luu cung ho voi tk, ky k_can -> [ung vien]. Moi tep gan vao DataFile DAI NHAT khop dau ten
        (05_KK_TNCN_TT80_... khong bi nhan nham la 05_KK_TNCN cua mau TT92)."""
        thu = self._thu_mst()
        if not thu:
            return []
        if "HTKK trên máy" not in self.da_quet:
            self.da_quet.append("HTKK trên máy")
        m = _menu_cua(self.menu, tk)
        ho_df = _df_cua_ho(self.menu, tk["ho"], (m or {}).get("MaFile", ""))
        if not ho_df:
            ho_df = [(x, [x]) for x in DF_MAC_DINH.get(tk["ho"], [])]
        moi_df = {}
        for mf, dfs in ho_df:
            for i, df in enumerate(dfs):
                moi_df.setdefault(df.lower(), (mf, i == 0))
        tat_ca = sorted(moi_df, key=len, reverse=True)
        try:
            ten_tep = os.listdir(thu)
        except Exception:
            return []
        co = set(x.lower() for x in ten_tep)
        ten_tep = [x for x in ten_tep if not _la_ban_sao(x, co)]          # GD168: doc tep goc nhu HTKK, bo ban sao "X (1).xml"
        nhom = {}
        for f in ten_tep:
            mm = _RE_TEP.match(f)
            if not mm:
                continue
            than = mm.group(3)
            df = next((x for x in tat_ca if than.lower().startswith(x + "_")), None)
            if not df:
                continue
            mf, chinh = moi_df[df]
            kk = _ky_ten_tep(than[len(df) + 1:])
            if not kk or not _khop_ky(k_can, kk, tk["ho"]):
                continue
            khoa = (mf, mm.group(1) or "", than[len(df) + 1:], mm.group(4))
            g = nhom.setdefault(khoa, {"ky": kk, "tep": [], "chinh": ""})
            g["tep"].append(os.path.join(thu, f))
            if chinh:
                g["chinh"] = os.path.join(thu, f)
        ra = []
        for (mf, bs, than_ky, pb), g in nhom.items():
            if not g["chinh"]:
                continue
            ct = doc_tep_htkk(g["tep"])
            if not ct:
                continue
            try:
                mt = max(os.path.getmtime(p) for p in g["tep"])
            except OSError:
                mt = 0
            lan = int(re.sub(r"\D", "", bs) or 0)
            ra.append({"tep": g["chinh"], "ma": "", "pban": "", "ten": "", "ma_file": mf, "ho": tk["ho"], "ky": g["ky"],
                       "loai": "B" if lan else "C", "lan": lan, "bs": lan > 0, "mst": self.mst, "ct": ct, "dem": {},
                       "nguon": "HTKK trên máy: %s" % os.path.basename(g["chinh"]), "hang": 2, "pb": int(pb), "mtime": mt})
        return ra

    def tim(self, tk, k_can):
        """To khai co hieu luc cung ho, ky k_can (None = khong co)."""
        ung = [x for x in self.xml() if x["ho"] == tk["ho"] and _khop_ky(k_can, x["ky"], tk["ho"])]
        ung += self.htkk(tk, k_can)
        if not ung:
            return None
        return max(ung, key=_uu)


# ------------------------------------------------------------------ nhan chi tieu
def _nhan_bao_cao():
    try:
        import bao_cao_nam as B
        b01 = {"SoCuoiNam/ct%d" % ma: ten for ten, ma, _k in B.B01A_DONG if ma}
        b02 = {"PL_KQHDSXKD/NamNay/ct%02d" % ma: ten for ten, ma, _k in B.B02_DONG}
        b03 = {"PL_LCTTTT/NamNay/ct%02d" % ma: ten for ten, ma, _k in B.B03_DONG if ma}
        tndn = {"ct" + ma: ten for _stt, ten, ma in B.TNDN_DONG if ma and len(ma) <= 4}
        return b01, b02, b03, tndn
    except Exception:
        return {}, {}, {}, {}


def _gon(ten, toi_da=60):
    """ten chi tieu ngan: bo dau ':' cuoi; dai qua thi cat o cong thuc '(...)' hoac o toi_da ky tu."""
    ten = (ten or "").strip().rstrip(":").strip()
    if len(ten) <= toi_da:
        return ten
    i = ten.find(" (")
    if 10 < i <= toi_da:
        return ten[:i]
    return ten[:toi_da - 3].rstrip() + "..."


def _nhan_kk():
    try:
        import kk_tncn as KK
        return {"ct" + ma: ten for _stt, ten, ma, _dv, _d in KK.DONG}
    except Exception:
        return {}


def _khoa_b0x(ct, khoi, ma, cung=True):
    """khoa B02 / B03 co the co 'ct01' hoac 'ct1' tuy mau -> khoa co trong ct."""
    for k in ("%s/ct%02d" % (khoi, ma), "%s/ct%d" % (khoi, ma)):
        if k in ct:
            return k
    return "%s/ct%02d" % (khoi, ma) if cung else ""


def danh_sach_chinh(tk):
    """[(khoa, ten, kieu 'T' tien / 'N' nguoi)] cac chi tieu dua vao bang so sanh."""
    ho, ct = tk["ho"], tk["ct"]
    b01, b02, b03, tndn = _nhan_bao_cao()
    if ho == "KK":
        nh = _nhan_kk()
        return [("ct" + c, "[%s] %s" % (c, _gon((nh.get("ct" + c) or "").split(" [")[0])), "N" if c in ("16", "18") else "T")
                for c in CT_KK_CHINH if _khoa_la(ct, "ct" + c)]
    if ho == "QTT":
        return [x for x in CT_QTT if x[0] in ct]
    if ho == "GTGT":
        return [x for x in CT_GTGT if _khoa_la(ct, x[0])]
    if ho == "TNDN":
        return [("ct" + c, "[%s] %s" % (c, _gon(tndn.get("ct" + c))), "T") for c in CT_TNDN_CHINH if _khoa_la(ct, "ct" + c)]
    if ho == "CNKD":
        return [x for x in CT_CNKD if _khoa_la(ct, x[0])]
    if ho == "BCTC" and (str(tk.get("ma") or "") == "1280" or "PL_BCKQHDKD/NamNay/ct01" in ct):
        # GD171: bo BCTC TT 58/2026 doanh nghiep sieu nho (B01-DNSN 13 chi tieu, B02-DNSN 5 chi tieu)
        try:
            import so_sach_tt58 as T58
            n01 = {ma: ten for ten, ma, _k in T58.B01_DONG if ma}
            n02 = dict((ma, ten) for ten, ma in T58.B02_DONG)
        except Exception:
            return []
        ra = [("SoCuoiNam/ct%d" % ma, "B01-DNSN [%d] %s" % (ma, _gon(n01.get(ma))), "T") for ma in T58.B01_MA if "SoCuoiNam/ct%d" % ma in ct]
        ra += [("PL_BCKQHDKD/NamNay/ct%s" % ma, "B02-DNSN [%s] %s" % (ma, _gon(n02.get(ma))), "T") for ma in T58.B02_MA
               if "PL_BCKQHDKD/NamNay/ct%s" % ma in ct]
        return ra
    if ho == "BCTC":
        ra = []
        for ma in CT_B01_CHINH:
            k = "SoCuoiNam/ct%d" % ma
            if k in ct:
                ra.append((k, "B01 [%d] %s" % (ma, _gon(b01.get(k))), "T"))
        for ma in CT_B02_CHINH:
            k = _khoa_b0x(ct, "PL_KQHDSXKD/NamNay", ma, False)
            if k:
                ra.append((k, "B02 [%02d] %s" % (ma, _gon(b02.get("PL_KQHDSXKD/NamNay/ct%02d" % ma))), "T"))
        for ma in CT_B03_CHINH:
            k = _khoa_b0x(ct, "PL_LCTTTT/NamNay", ma, False)
            if k:
                ra.append((k, "B03 [%02d] %s" % (ma, _gon(b03.get("PL_LCTTTT/NamNay/ct%02d" % ma))), "T"))
        return ra
    return []


# ------------------------------------------------------------------ so sanh
def _khoa_la(ct, k):
    """khoa k co trong ct; khong co thi tim theo ten la (to khai long nhom: GiaTriVaThue.../ct23) - bo khoi SoDauNam / phu luc."""
    if not k:
        return None
    if k in ct:
        return k
    la = k.split("/")[-1]
    ung = [x for x in ct if x.split("/")[-1] == la and not x.startswith(("SoDauNam/", "PL_", "PLuc"))]
    return ung[0] if ung else None


def _co(ct, k):
    k2 = _khoa_la(ct, k)
    v = ct.get(k2) if k2 else None
    return float(v) if v is not None else None


def so_sanh(tk, truoc):
    """-> (bang [(khoa, ten, nay, truoc, chenh, ty_le, muc)], canh_bao [(muc, chu)])."""
    bang, cb = [], []
    ds = danh_sach_chinh(tk)
    cung_mau = truoc is not None and (not truoc.get("ma_file") or not tk.get("ma_file") or truoc["ma_file"] == tk["ma_file"]
                                      or truoc.get("ma") == tk.get("ma"))
    for k, ten, loai in ds:
        a = _co(tk["ct"], k) or 0.0
        b = _co(truoc["ct"], k) if truoc else None
        muc, chenh, ty = "", None, None
        if b is not None:
            chenh = a - b
            ty = (chenh / abs(b)) if b else None
            if loai == "N":
                if abs(chenh) >= NGUONG_NGUOI and (b == 0 or abs(chenh) / max(abs(b), 1) >= TY_LE_NGUOI):
                    muc = "?"
            else:
                if b and abs(ty) >= TY_LE and abs(chenh) >= NGUONG_TIEN:
                    muc = "?"
                elif not b and abs(a) >= NGUONG_TIEN:
                    muc = "?"
                elif a == 0 and abs(b) >= NGUONG_TIEN:
                    muc = "?"
                if a * b < 0 and min(abs(a), abs(b)) >= 1000000:
                    muc = "?"
        bang.append((k, ten, a, b, chenh, ty, muc))
        if muc == "?" and b is not None:
            if b and a:
                cb.append(("?", "%s: %s so với kỳ trước (%s -> %s)." % (ten, _pt(ty) if ty is not None else "đổi dấu", _vn(b), _vn(a)), True))
            elif not b:
                cb.append(("?", "%s: kỳ trước bằng 0, kỳ này %s - kiểm tra." % (ten, _vn(a)), True))
            else:
                cb.append(("?", "%s: kỳ này bằng 0, kỳ trước %s - kiểm tra." % (ten, _vn(b)), True))
    if truoc is not None and not cung_mau:
        cb.append(("i", "Tờ khai kỳ trước lập theo mẫu khác (%s) - chỉ so các chỉ tiêu cùng mã." % (truoc.get("ma_file") or truoc.get("pban") or "?")))
    # so chuyen ky
    if truoc is not None:
        lien = ky_truoc(tk["ky"])
        sat = _khop_ky(lien, truoc["ky"], tk["ho"])
        if tk["ho"] == "GTGT" and sat:
            a, b = _co(tk["ct"], "ct22"), _co(truoc["ct"], "ct43")
            if a is not None and b is not None and abs(a - b) >= 1:
                cb.append(("!", "[22] kỳ này %s khác [43] tờ khai kỳ trước %s." % (_vn(a), _vn(b))))
        if tk["ho"] == "BCTC" and sat:
            lech = []
            for k, v in sorted(tk["ct"].items()):
                if not k.startswith("SoDauNam/"):
                    continue
                kc = "SoCuoiNam/" + k.split("/", 1)[1]
                if kc in truoc["ct"] and abs(v - truoc["ct"][kc]) >= 1:
                    lech.append("[%s] %s / %s" % (k.split("ct", 1)[1], _vn(v), _vn(truoc["ct"][kc])))
            if lech:
                cb.append(("!", "B01 số đầu năm khác số cuối năm của BCTC năm trước ở %d chỉ tiêu (đầu năm / cuối năm trước): %s%s."
                           % (len(lech), "; ".join(lech[:10]), "..." if len(lech) > 10 else "")))
            for khoi_nay, khoi_truoc, ten_khoi in (("PL_KQHDSXKD/NamTruoc/", "PL_KQHDSXKD/NamNay/", "B02"),
                                                    ("PL_LCTTTT/NamTruoc/", "PL_LCTTTT/NamNay/", "B03")):
                lech = []
                for k, v in sorted(tk["ct"].items()):
                    if not k.startswith(khoi_nay):
                        continue
                    kt = khoi_truoc + k[len(khoi_nay):]
                    if kt in truoc["ct"] and abs(v - truoc["ct"][kt]) >= 1:
                        lech.append("[%s] %s / %s" % (k.rsplit("ct", 1)[1], _vn(v), _vn(truoc["ct"][kt])))
                if lech:
                    cb.append(("!", "%s cột năm trước khác số năm nay của BCTC năm trước ở %d chỉ tiêu: %s%s."
                               % (ten_khoi, len(lech), "; ".join(lech[:8]), "..." if len(lech) > 8 else "")))
            k60 = _khoa_b0x(tk["ct"], "PL_LCTTTT/NamNay", 60, False)
            k70 = _khoa_b0x(truoc["ct"], "PL_LCTTTT/NamNay", 70, False)
            if k60 and k70 and abs(tk["ct"][k60] - truoc["ct"][k70]) >= 1:
                cb.append(("!", "B03 [60] tiền đầu kỳ %s khác [70] tiền cuối kỳ của BCTC năm trước %s." % (_vn(tk["ct"][k60]), _vn(truoc["ct"][k70]))))
        if not sat:
            cb.append(("i", "Tờ khai gần nhất tìm được là %s (không phải %s liền trước)." % (_ten_ky(truoc["ky"]), _ten_ky(lien))))
    return bang, cb


def kiem_trong_ky(tk, lo, nguon):
    """Kiem cheo trong ky: tong tai san = nguon von; 03/TNDN [A1] = B02 [50] (cung lo); B03 [70] = B01 [110];
    05/QTT [31] = tong [29] cac 05/KK trong nam (va [23] / [21])."""
    cb = []
    ct = tk["ct"]
    if tk["ho"] == "BCTC":
        for khoi in ("SoCuoiNam", "SoDauNam"):
            for ts, nv in ((200, 500), (300, 600)):
                a, b = ct.get("%s/ct%d" % (khoi, ts)), ct.get("%s/ct%d" % (khoi, nv))
                if a is not None and b is not None and (a or b) and abs(a - b) >= 1 and not (ts == 300 and "%s/ct500" % khoi in ct and
                                                                                         "%s/ct200" % khoi in ct):
                    cb.append(("!", "B01 %s: tổng tài sản [%d] %s khác tổng nguồn vốn [%d] %s." % (
                        "cuối năm" if khoi == "SoCuoiNam" else "đầu năm", ts, _vn(a), nv, _vn(b))))
        k70 = _khoa_b0x(ct, "PL_LCTTTT/NamNay", 70, False)
        if k70 and "SoCuoiNam/ct110" in ct and abs(ct[k70] - ct["SoCuoiNam/ct110"]) >= 1:
            cb.append(("!", "B03 [70] tiền cuối kỳ %s khác B01 [110] tiền và tương đương tiền %s." % (_vn(ct[k70]), _vn(ct["SoCuoiNam/ct110"]))))
    if tk["ho"] == "TNDN":
        for x in lo:
            if x["ho"] == "BCTC" and _khop_ky(tk["ky"], x["ky"], "BCTC"):
                k50 = _khoa_b0x(x["ct"], "PL_KQHDSXKD/NamNay", 50, False)
                a1 = _co(ct, "ctA1")
                if k50 and a1 is not None and abs(a1 - x["ct"][k50]) >= 1:
                    cb.append(("!", "03/TNDN [A1] %s khác B02 [50] lợi nhuận trước thuế %s (cùng lần xuất)." % (_vn(a1), _vn(x["ct"][k50]))))
    if tk["ho"] == "QTT":
        nam = tk["ky"][2].year
        tong29, tong21, thieu = 0.0, 0.0, []
        for q in range(1, 5):
            cac = list(range(3 * q - 2, 3 * q + 1))
            gq, hq = _tim_kk(lo, nguon, ("Q", date(nam, 3 * q - 2, 1), _cuoi_thang(nam, 3 * q)))
            gm = [_tim_kk(lo, nguon, ("M", date(nam, m, 1), _cuoi_thang(nam, m))) for m in cac]
            du_thang = all(g is not None for g, _h in gm)
            if du_thang and (gq is None or min(h for _g, h in gm) > hq):     # khai thang (da nop) dang tin hon to khai quy
                chon = [g for g, _h in gm]
            elif gq is not None:
                chon = [gq]
            else:
                chon = [g for g, _h in gm if g is not None]
                thieu += [m for m, (g, _h) in zip(cac, gm) if g is None]
            for g in chon:
                tong29 += _co(g["ct"], "ct29") or 0.0
                tong21 += _co(g["ct"], "ct21") or 0.0
        if thieu and len(thieu) < 12:
            cb.append(("i", "Chưa thấy tờ khai 05/KK-TNCN của tháng %s/%d - tổng các kỳ đã khai chưa đủ năm để đối chiếu."
                       % (", ".join("%02d" % m for m in thieu), nam)))
        elif not thieu:
            a = ct.get("NVuKhauTruThue/ct31")
            if a is not None and abs(a - tong29) >= 1000:
                cb.append(("!", "05/QTT [31] tổng thuế đã khấu trừ %s khác tổng [29] các tờ khai 05/KK-TNCN trong năm %s." % (_vn(a), _vn(tong29))))
            a = ct.get("NVuKhauTruThue/ct23")
            if a is not None and abs(a - tong21) >= 1000:
                cb.append(("?", "05/QTT [23] tổng thu nhập chịu thuế %s khác tổng [21] các tờ khai 05/KK-TNCN trong năm %s." % (_vn(a), _vn(tong21))))
        else:
            cb.append(("i", "Chưa thấy tờ khai 05/KK-TNCN nào của năm %d để đối chiếu với quyết toán." % nam))
    return cb


def _tim_kk(lo, nguon, k_):
    """05/KK-TNCN ky k_: (to khai, hang). To khai da nop / luu tru (hang >= 3) dang tin hon ban vua lap trong lo (2.5),
    ban vua lap dang tin hon HTKK tren may / lan xuat truoc (hang 2 / 1)."""
    a = next((x for x in lo if x["ho"] == "KK" and _khop_ky(k_, x["ky"], "KK")), None)
    b = nguon.tim({"ho": "KK", "ma": "", "pban": ""}, k_) if nguon is not None else None
    hb = b.get("hang", 0) if b is not None else -1
    if a is not None and hb < 3:
        return a, 2.5
    return b, hb


def kk_da_khai(nguon, k_):
    """05/KK-TNCN da khai cho ky k_ (quy: to khai quy, hoac du 3 to khai thang - quy 1/2026 khai thang). None = chua thay."""
    da, _h = _tim_kk([], nguon, k_)
    if da is not None or k_[0] != "Q":
        return da
    ds = []
    y, m0 = k_[1].year, k_[1].month
    for m in range(m0, m0 + 3):
        g, _h = _tim_kk([], nguon, ("M", date(y, m, 1), _cuoi_thang(y, m)))
        if g is None:
            return None
        ds.append(g)
    return {"ct": {"ct21": sum(_co(g["ct"], "ct21") or 0.0 for g in ds), "ct29": sum(_co(g["ct"], "ct29") or 0.0 for g in ds)},
            "nguon": "3 tờ khai tháng %02d-%02d/%d (%s)" % (m0, m0 + 2, y, ds[0].get("nguon", ""))}


def cung_ky(tk, nguon):
    """To khai CUNG KY da co (HTKK tren may / da nop tai ve): bao truoc - dua vao HTKK khong ghi de; da nop thi khai bo sung."""
    cb = []
    ung = [x for x in nguon.xml() if x["ho"] == tk["ho"] and x.get("hang", 0) >= 2 and _khop_ky(tk["ky"], x["ky"], tk["ho"])]
    ung += nguon.htkk(tk, tk["ky"])
    if not ung:
        return cb
    x = max(ung, key=_uu)
    khac = []
    for k, ten, _l in danh_sach_chinh(tk):
        a, b = _co(tk["ct"], k), _co(x["ct"], k)
        if a is not None and b is not None and abs(a - b) >= 1:
            khac.append("%s đang có %s, lần này %s" % (ten.split("]")[0] + "]", _vn(b), _vn(a)))
    nop = any(y.get("hang", 0) == 4 for y in ung)
    if nop:
        cb.append(("?", "Kỳ này ĐÃ NỘP tờ khai (%s). Số liệu khác thì khai BỔ SUNG, không nộp lại tờ khai lần đầu%s." % (
            x.get("nguon", ""), (": " + "; ".join(khac[:5])) if khac else "")))
    else:
        cb.append(("i", "HTKK trên máy đã có tờ khai cùng kỳ (%s) - Đưa vào HTKK sẽ KHÔNG ghi đè; muốn thay thì bấm Mở HTKK "
                        "(hỏi ghi đè, có sao lưu)%s." % (x.get("nguon", ""), (". Khác: " + "; ".join(khac[:5])) if khac else "")))
    return cb


# ------------------------------------------------------------------ lap bao cao
def _ten_tk(tk):
    return "%s %s" % (HO_TEN.get(tk["ho"], tk.get("ten") or "Tờ khai"), _ten_ky(tk["ky"]))


def xem_truoc(ds_xml, mst="", thu_muc_khach="", htkk_goc="", thu_muc_ra="", log=None, nguon=None):
    """-> {'dong': [...], 'loi': so [!], 'xem': so [?], 'excel': duong, 'muc': [...]} cho cac tep XML to khai."""
    log = log or (lambda s: None)
    ds_xml = [p for p in dict.fromkeys(os.path.normcase(os.path.abspath(x)) for x in ds_xml or []) if p.lower().endswith(".xml")]
    lo = []
    for p in ds_xml:
        x = doc_xml_tk(p, nguon="vừa lập")
        if x and x["ho"]:
            lo.append(x)
    if nguon is None:
        nguon = Nguon(mst or (lo[0]["mst"] if lo else ""), thu_muc_khach, htkk_goc, bo_qua=ds_xml, log=log)
    for x in lo:
        m = _menu_cua(nguon.menu, x)
        if m:
            x["ma_file"] = m.get("MaFile", "")
    dong = ["", "XEM TRƯỚC KHI ĐƯA VÀO HTKK - SO SÁNH KỲ TRƯỚC VÀ KIỂM TRA TRONG KỲ (%s)" % datetime.now().strftime("%d/%m/%Y %H:%M"),
            "Dòng [!] là sai lệch phải xem, [?] là nên kiểm tra, [i] là thông tin. Chưa có gì được ghi vào HTKK."]
    if not lo:
        dong.append("[i] Không có tờ khai XML để so sánh.")
        return {"dong": dong, "loi": 0, "xem": 0, "excel": "", "muc": []}
    muc, n_loi, n_xem = [], 0, 0
    for i, tk in enumerate(lo, 1):
        truoc = nguon.tim(tk, ky_truoc(tk["ky"]))
        if truoc is None and tk["ky"][0] in ("M", "Q"):
            k = ky_truoc(tk["ky"])
            for _ in range(3):                                   # thieu ky lien truoc: lui toi da 3 ky
                k = ky_truoc(k)
                truoc = nguon.tim(tk, k)
                if truoc is not None:
                    break
        bang, cb = so_sanh(tk, truoc)
        cb += kiem_trong_ky(tk, lo, nguon)
        cb += cung_ky(tk, nguon)
        mau = (" - khuôn HTKK %s" % tk["ma_file"]) if tk.get("ma_file") else ""
        dong.append("")
        dong.append("%d. %s (%s%s)" % (i, _ten_tk(tk), os.path.basename(tk["tep"]), mau))
        if truoc is None:
            dong.append("   [i] Chưa thấy tờ khai %s kỳ trước (%s) - đã tìm: %s. Chỉ kiểm tra trong kỳ." % (
                HO_TEN.get(tk["ho"], ""), _ten_ky(ky_truoc(tk["ky"])), ", ".join(nguon.da_quet) or "không có nguồn nào"))
        else:
            dong.append("   Kỳ trước: %s - %s%s." % (_ten_ky(truoc["ky"]), truoc.get("nguon", ""),
                                                   (" (bổ sung lần %d)" % truoc["lan"]) if truoc.get("bs") and truoc.get("lan") else ""))
        for k, ten, a, b, chenh, ty, m in bang:
            if b is None:
                dong.append("   %s: %s" % (ten, _vn(a)))
            else:
                dong.append("   %s%s: kỳ này %s | kỳ trước %s | chênh %s%s" % (
                    "[?] " if m == "?" else "", ten, _vn(a), _vn(b), ("+" if chenh > 0 else "") + _vn(chenh),
                    (" (%s)" % _pt(ty)) if ty is not None and chenh else ""))
        for x in cb:
            m, c = x[0], x[1]
            if not (len(x) > 2 and x[2]):                     # dong [?] tu bang da danh dau tren bang
                dong.append("   [%s] %s" % (m, c))
            n_loi += m == "!"
            n_xem += m == "?"
        if not cb and truoc is not None:
            dong.append("   [i] Không thấy sai lệch với kỳ trước.")
        muc.append({"tk": tk, "truoc": truoc, "bang": bang, "cb": cb})
    dong.append("")
    dong.append("Tổng: %d tờ khai; %d dòng [!], %d dòng [?]." % (len(lo), n_loi, n_xem))
    excel = ""
    if thu_muc_ra:
        try:
            excel = lap_excel(muc, os.path.join(thu_muc_ra, TEN_EXCEL))
            dong.append("Bảng so sánh chi tiết: %s" % os.path.basename(excel))
        except Exception as e:
            log("[XEM TRUOC HTKK] khong lap duoc Excel: %s" % e)
    return {"dong": dong, "loi": n_loi, "xem": n_xem, "excel": excel, "muc": muc}


def lap_excel(muc, duong):
    from xlsx_viet import SoExcel
    wb = SoExcel(font="Times New Roman", co=11)
    h = wb.kieu(dam=True, co=10, can="giua", doc="giua", xuong=True, khung=True, nen="E2EFDA")
    c = wb.kieu(co=10, khung=True, xuong=True, doc="giua")
    n = wb.kieu(co=10, khung=True, so="#,##0;(#,##0);0", doc="giua")
    p = wb.kieu(co=10, khung=True, so="0.0%", doc="giua")
    td = wb.kieu(dam=True, co=12)
    gh = wb.kieu(nghieng=True, co=10, xuong=True)
    tong = wb.sheet("Tong hop", cot=[6, 70, 50])
    tong.gop(1, 1, 1, 3, "XEM TRƯỚC KHI ĐƯA VÀO HTKK - SO SÁNH KỲ TRƯỚC VÀ KIỂM TRA TRONG KỲ", td)
    tong.dong(3, 1, ["Mức", "Nội dung", "Tờ khai"], h)
    r = 4
    for i, x in enumerate(muc, 1):
        ten_sh = ("%d %s" % (i, HO_TEN.get(x["tk"]["ho"], "TK")))[:28].replace("/", "-")
        ws = wb.sheet(ten_sh, cot=[52, 18, 18, 18, 10, 26])
        ws.gop(1, 1, 1, 6, _ten_tk(x["tk"]).upper(), td)
        ws.gop(2, 1, 2, 6, ("Kỳ trước: %s - %s" % (_ten_ky(x["truoc"]["ky"]), x["truoc"].get("nguon", ""))) if x["truoc"] else
               "Chưa thấy tờ khai kỳ trước", gh)
        ws.dong(4, 1, ["Chỉ tiêu", "Kỳ này", "Kỳ trước", "Chênh lệch", "Tỷ lệ", "Ghi chú"], h)
        rr = 5
        for k, ten, a, b, chenh, ty, m in x["bang"]:
            ws.dong(rr, 1, [(ten, c), (a, n), (b if b is not None else "", n), (chenh if chenh is not None else "", n),
                            (ty if ty is not None else "", p), ("nên kiểm tra" if m == "?" else "", c)])
            rr += 1
        rr += 1
        for y in x["cb"]:
            m, s = y[0], y[1]
            ws.gop(rr, 1, rr, 6, "[%s] %s" % (m, s), gh)
            ws.cao(rr, 15 * max(1, (len(s) + 119) // 120))
            rr += 1
            tong.dong(r, 1, [("[%s]" % m, c), (s, c), (_ten_tk(x["tk"]), c)])
            tong.cao(r, 15 * max(1, (len(s) + 69) // 70))
            r += 1
    if r == 4:
        tong.gop(r, 1, r, 3, "Không có cảnh báo.", gh)
    wb.luu(duong)
    return duong


# ------------------------------------------------------------------ doi chieu TNCN voi so (muc DC_TNCN cua Xuat 1 lan)
def _sh_map(dl):
    sh = {}
    for r in dl.get("tk") or []:
        try:
            sh[int(r[0])] = str(r[1] or "").strip()
        except (TypeError, ValueError, IndexError):
            continue
    return sh


def _ps_thang(dl, dau_tk, ben):
    """{thang duong lich: phat sinh No ('N') / Co ('C')} cua cac TK bat dau dau_tk (ca ket chuyen)."""
    sh = _sh_map(dl)
    ra = {}
    for r in dl.get("ps") or []:
        try:
            s = sh.get(int(r[0]), "")
            th = int(r[1])
        except (TypeError, ValueError, IndexError):
            continue
        if not s.startswith(dau_tk):
            continue
        v = (_so(r[2]) or 0) + ((_so(r[4]) or 0) if len(r) > 4 else 0) if ben == "N" else \
            (_so(r[3]) or 0) + ((_so(r[5]) or 0) if len(r) > 5 else 0)
        ra[th] = ra.get(th, 0.0) + v
    return ra


def lap(dl, ma="DC_TNCN", kieu="E", thumuc="."):
    """Doi chieu TNCN ca nam tai chinh: bang luong <-> so (334, 3335) theo thang; 05/KK tinh tu bang luong <-> 05/KK da khai."""
    import kk_tncn as KK
    from qtt_tncn import lam_tron
    x1 = dl.get("x1l") or {}
    tu, den = KK._ngay(x1.get("tu")), KK._ngay(x1.get("den"))
    if not tu or not den:
        return {"tep": [], "canh_bao": ["Kỳ đối chiếu TNCN không hợp lệ."]}
    ds_ky = KK.cac_ky(tu, den)
    cb, thang, ky_rows = [], {}, []
    p334, p3335c, p3335n = _ps_thang(dl, "334", "C"), _ps_thang(dl, "3335", "C"), _ps_thang(dl, "3335", "N")
    dn = dl.get("dn") or dl.get("cty") or {}
    try:
        import tool_htkk_unesco as X
        h = X.tim_htkk() or {}
    except Exception:
        h = {}
    thu_muc_khach = os.path.dirname(os.path.dirname(os.path.abspath(thumuc)))
    nguon = Nguon(dn.get("mst", ""), thu_muc_khach, h.get("goc", ""))
    for k in ds_ky:
        kk = KK.tong_hop_ky(dl, k)
        nam = k[1]
        for m in k[3]:
            bl = sum(x["tn"] for x in kk["kiem"] if x["thang"] == m)
            th = sum(x["thue"] for x in kk["kiem"] if x["thang"] == m)
            thang[(nam, m)] = (bl, th)
        a, b = KK.tu_den(k)
        kc = ("Q" if k[0] == "Q" else "M", a.date() if hasattr(a, "date") else a, b.date() if hasattr(b, "date") else b)
        da = kk_da_khai(nguon, kc)
        ky_rows.append((KK.ten_ky(k), kk["ct"]["21"], kk["ct"]["29"], da))
    if not thang:
        return {"tep": [], "canh_bao": ["Không có tháng nào để đối chiếu TNCN."]}
    from xlsx_viet import SoExcel
    wb = SoExcel(font="Times New Roman", co=11)
    h1 = wb.kieu(dam=True, co=10, can="giua", doc="giua", xuong=True, khung=True, nen="E2EFDA")
    c = wb.kieu(co=10, khung=True, xuong=True, doc="giua")
    n = wb.kieu(co=10, khung=True, so="#,##0;(#,##0);0", doc="giua")
    nd = wb.kieu(co=10, khung=True, so="#,##0;(#,##0);0", doc="giua", mau="C00000")
    td = wb.kieu(dam=True, co=12)
    gh = wb.kieu(nghieng=True, co=10, xuong=True)
    ws = wb.sheet("Theo thang", cot=[14, 17, 17, 15, 17, 17, 15, 17, 17])
    ws.gop(1, 1, 1, 9, "ĐỐI CHIẾU THUẾ TNCN: BẢNG LƯƠNG - SỔ KẾ TOÁN (TK 334, 3335) THEO THÁNG", td)
    ws.gop(2, 1, 2, 9, "Đơn vị: %s. Thu nhập / thuế theo bảng lương (như tờ khai 05/KK-TNCN); phát sinh Có / Nợ lấy từ sổ." % dn.get("ten", ""), gh)
    ws.dong(4, 1, ["Tháng", "Thu nhập bảng lương", "PS Có TK 334", "Chênh lệch", "Thuế đã khấu trừ", "PS Có TK 3335", "Chênh lệch",
                   "Đã nộp (PS Nợ 3335)", "Còn phải nộp lũy kế"], h1)
    r, luy, lech_tn, lech_th = 5, 0.0, [], []
    for (nam, m) in sorted(thang):
        bl, th = thang[(nam, m)]
        a334, a3335, nop = lam_tron(p334.get(m, 0)), lam_tron(p3335c.get(m, 0)), lam_tron(p3335n.get(m, 0))
        luy += a3335 - nop
        if abs(bl - a334) >= 1:
            lech_tn.append(m)
        if abs(th - a3335) >= 1:
            lech_th.append(m)
        ws.dong(r, 1, [("%02d/%d" % (m, nam), c), (bl, n), (a334, n), (bl - a334, nd if abs(bl - a334) >= 1 else n), (th, n), (a3335, n),
                       (th - a3335, nd if abs(th - a3335) >= 1 else n), (nop, n), (luy, n)])
        r += 1
    if lech_tn:
        cb.append("Thu nhập bảng lương khác phát sinh Có TK 334 ở tháng %s (lương ghi sổ khác bảng lương / có khoản 334 khác lương)."
                  % ", ".join("%02d" % m for m in lech_tn))
    if lech_th:
        cb.append("Thuế TNCN đã khấu trừ theo bảng lương khác phát sinh Có TK 3335 ở tháng %s (chưa trích thuế vào sổ / 3335 có khoản khác)."
                  % ", ".join("%02d" % m for m in lech_th))
    ws2 = wb.sheet("05-KK da khai", cot=[16, 18, 18, 18, 18, 15, 15, 40])
    ws2.gop(1, 1, 1, 8, "05/KK-TNCN TÍNH TỪ BẢNG LƯƠNG SO VỚI TỜ KHAI ĐÃ KHAI (HTKK TRÊN MÁY, HỒ SƠ THUẾ, TỜ KHAI LƯU TRỮ)", td)
    ws2.dong(3, 1, ["Kỳ", "[21] TNCT bảng lương", "[21] đã khai", "[29] thuế bảng lương", "[29] đã khai", "Chênh [21]", "Chênh [29]",
                    "Nguồn tờ khai đã khai"], h1)
    r = 4
    for ten, a21, a29, da in ky_rows:
        if da is None:
            ws2.dong(r, 1, [(ten, c), (a21, n), ("", n), (a29, n), ("", n), ("", n), ("", n), ("chưa thấy tờ khai đã khai", c)])
        else:
            b21, b29 = _co(da["ct"], "ct21") or 0.0, _co(da["ct"], "ct29") or 0.0
            ws2.dong(r, 1, [(ten, c), (a21, n), (b21, n), (a29, n), (b29, n), (a21 - b21, nd if abs(a21 - b21) >= 1 else n),
                            (a29 - b29, nd if abs(a29 - b29) >= 1 else n), (da.get("nguon", ""), c)])
            if abs(a29 - b29) >= 1 or abs(a21 - b21) >= 1:
                cb.append("05/KK-TNCN %s tính từ bảng lương ([21] %s, [29] %s) khác tờ khai đã khai ([21] %s, [29] %s) - nếu bảng lương "
                          "đã sửa sau khi khai thì cân nhắc khai bổ sung." % (ten, _vn(a21), _vn(a29), _vn(b21), _vn(b29)))
        r += 1
    r += 1
    for s in cb:
        ws2.gop(r, 1, r, 8, "- " + s, gh)
        ws2.cao(r, 15 * max(1, (len(s) + 139) // 140))
        r += 1
    nam_dt = sorted({nam for nam, _m in thang})
    p = os.path.join(thumuc, "DoiChieu_TNCN_%s.xlsx" % "_".join(str(x) for x in nam_dt))
    wb.luu(p)
    cb.insert(0, "Đối chiếu TNCN %d tháng, %d kỳ 05/KK (%d kỳ đã thấy tờ khai đã khai)." % (len(thang), len(ky_rows),
                                                                                       sum(1 for x in ky_rows if x[3] is not None)))
    return {"tep": [p], "canh_bao": cb}
