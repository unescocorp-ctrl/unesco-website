# -*- coding: utf-8 -*-
"""GD254 - BUT TOAN DINH KY THEO THAM SO (nguoi quyet mot lan, may tinh va nhac moi ky): doanh thu chua thuc hien 3387 theo
   hop dong (dich vu), trich truoc chi phi (335), du phong (229x). Tep: <thu muc chinh sach cua so>\\but_toan_dinh_ky.txt, moi dong:
     3387;<ma hop dong>;<tong tien>;<so ky (thang)>;<mm/yyyy bat dau>;<TK doanh thu, vd 5113>
     TRICH_TRUOC;<noi dung>;<so tien moi thang>;<TK No, vd 6422>;<TK Co, vd 335>
     DU_PHONG;<noi dung>;<so du can co cuoi ky>;<TK No, vd 6422>;<TK Co, vd 2293>
   K57: thang trong ky kiem con thieu but toan (3387: thang chua co No 3387 du so; trich truoc: thang chua co Co <TK Co> du so;
        du phong: so du Co cuoi ky khac so can co -> trich them / hoan nhap). May khong ghi so: lap o the Ket chuyen cuoi ky.
"""
import io
import os

MAU = ("# But toan dinh ky theo tham so. Bo dau # va dien. Moi dong mot khoan:\n"
       "#3387;HD001;120000000;12;01/2026;5113\n"
       "#TRICH_TRUOC;Tien thue van phong;10000000;6422;335\n"
       "#DU_PHONG;Du phong phai thu kho doi;50000000;6422;2293\n")


def _f(x):
    try:
        return float(str(x).replace(".", "").replace(",", ".")) if isinstance(x, str) and x.count(".") > 1 else float(x or 0)
    except Exception:
        try:
            return float(str(x).replace(",", ""))
        except Exception:
            return 0.0


def tep_tham_so(S):
    duong = S.dl.get("duong_so") or ""
    if not duong:
        return None
    try:
        import chinh_sach_so
        tm, _ = chinh_sach_so._thu_muc_ra(duong)
        return os.path.join(tm, "but_toan_dinh_ky.txt")
    except Exception:
        return None


def doc(tep):
    out = []
    if not tep or not os.path.isfile(tep):
        return out
    with io.open(tep, encoding="utf-8-sig") as f:
        for d in f:
            d = d.strip()
            if not d or d.startswith("#"):
                continue
            x = [v.strip() for v in d.split(";")]
            if len(x) < 5:
                continue
            lo = x[0].upper()
            try:
                if lo == "3387" and len(x) >= 6:
                    th, nm = x[4].split("/")
                    out.append(("3387", x[1], _f(x[2]), int(x[3]), (int(nm), int(th)), x[5]))
                elif lo == "TRICH_TRUOC":
                    out.append(("TRICH_TRUOC", x[1], _f(x[2]), x[3], x[4]))
                elif lo == "DU_PHONG":
                    out.append(("DU_PHONG", x[1], _f(x[2]), x[3], x[4]))
            except Exception:
                continue
    return out


def _thang_dl(S, t):
    return (t + S.dau_ky - 2) % 12 + 1


def _nam_cua(S, t):
    nam = int(S.dl.get("nam_tc") or 0)
    th = _thang_dl(S, t)
    return nam + (1 if th < S.dau_ky else 0) if nam else 0


def _ps_thang(S, tien_to, t):
    n = c = 0.0
    for m in S.la_theo(tien_to):
        p = S.ps.get(m) if hasattr(S.ps, "get") else None
        x = p["thang"].get(t) if p else None
        if x:
            n += x[0]
            c += x[1]
    return n, c


def k_dinh_ky(S, _kq, DAT, CANH_BAO, LOI, THONG_TIN, tep=None):
    ten = "Bút toán định kỳ theo tham số (3387, trích trước, dự phòng)"
    tep = tep or tep_tham_so(S)
    if not tep:
        return None
    ds = doc(tep)
    if not ds:
        try:
            if not os.path.isfile(tep):
                os.makedirs(os.path.dirname(tep), exist_ok=True)
                with io.open(tep, "w", encoding="utf-8") as f:
                    f.write(MAU)
        except Exception:
            pass
        return [_kq("K57", ten, THONG_TIN, "Chưa khai khoản định kỳ nào. Muốn máy nhắc và tính sẵn: điền %s (3387 theo hợp đồng, trích trước, dự phòng)." % tep)]
    dong = []
    for k in ds:
        if k[0] == "3387":
            _, hd, tong, so_ky, (nam0, th0), tk_dt = k
            moi_ky = tong / so_ky if so_ky else 0
            for t in range(S.t1, S.t2 + 1):
                th, nam = _thang_dl(S, t), _nam_cua(S, t)
                stt = (nam - nam0) * 12 + (th - th0) if nam else (th - th0)
                if not (0 <= stt < so_ky):
                    continue
                n3387, _ = _ps_thang(S, "3387", t)
                if n3387 + 1 < moi_ky:
                    dong.append([th, "Doanh thu chưa thực hiện %s (kỳ %d/%d)" % (hd, stt + 1, so_ky), "3387", tk_dt, round(moi_ky - n3387), "Nợ 3387 / Có %s" % tk_dt])
        elif k[0] == "TRICH_TRUOC":
            _, nd, tien, tk_no, tk_co = k
            for t in range(S.t1, S.t2 + 1):
                _, c = _ps_thang(S, tk_co, t)
                if c + 1 < tien:
                    dong.append([_thang_dl(S, t), "Trích trước: %s" % nd, tk_no, tk_co, round(tien - c), "Nợ %s / Có %s" % (tk_no, tk_co)])
        elif k[0] == "DU_PHONG":
            _, nd, can, tk_no, tk_co = k
            du = -sum(S.du_cuoi(m) for m in S.la_theo(tk_co))
            lech = can - du
            if abs(lech) > 1:
                if lech > 0:
                    dong.append([_thang_dl(S, S.t2), "Dự phòng: %s (cần %s, có %s)" % (nd, _d(can), _d(du)), tk_no, tk_co, round(lech), "Trích thêm: Nợ %s / Có %s" % (tk_no, tk_co)])
                else:
                    dong.append([_thang_dl(S, S.t2), "Dự phòng: %s (cần %s, có %s)" % (nd, _d(can), _d(du)), tk_co, tk_no, round(-lech), "Hoàn nhập: Nợ %s / Có %s" % (tk_co, tk_no)])
    if dong:
        return [_kq("K57", ten, CANH_BAO, "%d bút toán định kỳ còn thiếu theo tham số đã khai (%s). Lập ở thẻ Kết chuyển cuối kỳ theo từng tháng." % (len(dong), tep),
                    ["Tháng", "Nội dung", "Nợ", "Có", "Số tiền", "Bút toán"], dong)]
    return [_kq("K57", ten, DAT, "Các khoản định kỳ đã khai (%d) đều đã có bút toán đủ số trong kỳ." % len(ds))]


def _d(x):
    return "{:,.0f}".format(x).replace(",", ".")
