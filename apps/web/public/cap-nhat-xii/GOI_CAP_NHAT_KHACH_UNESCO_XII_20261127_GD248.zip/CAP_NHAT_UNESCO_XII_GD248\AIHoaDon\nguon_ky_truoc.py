# -*- coding: utf-8 -*-
"""GD162 (anh Thang 08/10/2026) - NGUON KY TRUOC THEO CONG TY: "tep duong dan" <thu muc khach>\\nguon-ky-truoc.json (UTF-8).

  {"thu_muc_to_khai": "<thu muc chua to khai da nop: XML ket xuat tu HTKK, XML / ZIP tai tu Cong thue>",
   "bctc": {"2025": "<tep BCTC nam 2025: Excel / XML / ZIP>"}, "cap_nhat": "yyyy-mm-dd hh:mm"}

Ghi / doc qua tool_htkk_unesco.py /nguonkt:"<thu muc khach>" [/dat:<khoa> /gt:"<gia tri>"] /mst:"<MST>" /ra:"<txt>"
(VB6 ModNguonKyTruoc - menu He thong -> Nguon HTKK, to khai va BCTC ky truoc; nut Nguon ky truoc tren Xem truoc 01/GTGT).
Dung boi:
  * tk_luu_tru.tim / ttc_ky_truoc: quet them thu muc to khai (ca thu muc con) khi tim [43] ky truoc va thong tin chung.
  * bctc_nam_truoc.chay (khong /tep): tep BCTC nam N-1 da luu duoc dung TRUOC khi tu tim.
Chi luu DUONG DAN - khong chep, khong sua, khong xoa tep cua nguoi dung.
"""
import io
import json
import os
import re
from datetime import datetime

TEN_TEP = "nguon-ky-truoc.json"
DUOI_BCTC = (".xlsx", ".xls", ".xlsm", ".csv", ".xml", ".zip")


def duong(thu_muc_khach):
    return os.path.join(thu_muc_khach, TEN_TEP) if thu_muc_khach else ""


def doc(thu_muc_khach):
    """-> dict (rong khi chua co / hong)."""
    p = duong(thu_muc_khach)
    if not p or not os.path.isfile(p):
        return {}
    try:
        with io.open(p, "r", encoding="utf-8-sig") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def ghi(thu_muc_khach, d):
    p = duong(thu_muc_khach)
    if not p:
        raise ValueError("chưa có thư mục khách")
    os.makedirs(thu_muc_khach, exist_ok=True)
    d = dict(d)
    d["cap_nhat"] = datetime.now().strftime("%Y-%m-%d %H:%M")
    tam = p + ".tmp"
    with io.open(tam, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=2)
    os.replace(tam, p)
    return p


def _sach(s):
    s = str(s or "").strip().strip('"').strip()
    while len(s) > 3 and s[-1] in "\\/":
        s = s[:-1]
    return s


def _qua_rong(t):
    """Goc o dia, thu muc nguoi dung / Desktop / Documents: quet ca thu muc con moi lan xuat to khai -> qua cham."""
    a = os.path.normcase(os.path.abspath(t)).rstrip("\\/")
    if not a or os.path.dirname(a) == a or len(a) <= 3:
        return True
    nha = os.path.normcase(os.path.abspath(os.path.expanduser("~"))).rstrip("\\/")
    rong = {nha, os.path.join(nha, "desktop"), os.path.join(nha, "documents"), os.path.join(nha, "downloads")}
    for bien in ("USERPROFILE", "PUBLIC"):
        v = os.environ.get(bien)
        if v:
            v = os.path.normcase(os.path.abspath(v)).rstrip("\\/")
            rong |= {v, os.path.join(v, "desktop"), os.path.join(v, "documents")}
    return a in {x.lower() if os.name == "nt" else x for x in rong}


def thu_muc_to_khai(thu_muc_khach):
    """Thu muc to khai da luu (con ton tai) hoac ''."""
    t = _sach(doc(thu_muc_khach).get("thu_muc_to_khai"))
    return t if t and os.path.isdir(t) else ""


def tep_bctc(thu_muc_khach, nam):
    """Tep BCTC nam `nam` da luu (con ton tai) hoac ''."""
    try:
        k = str(int(nam))
    except (TypeError, ValueError):
        return ""
    t = _sach((doc(thu_muc_khach).get("bctc") or {}).get(k))
    return t if t and os.path.isfile(t) else ""


def dat(thu_muc_khach, khoa, gia_tri):
    """khoa: thu_muc_to_khai | bctc_<nam> | xoa. Gia tri rong = bo duong dan do. -> (True, '') / (False, loi)."""
    khoa = str(khoa or "").strip().lower()
    gt = _sach(gia_tri)
    d = doc(thu_muc_khach)
    if khoa == "xoa":
        d = {}
    elif khoa == "thu_muc_to_khai":
        if gt and not os.path.isdir(gt):
            return False, "Không thấy thư mục: %s" % gt
        if gt and _qua_rong(gt):
            return False, ("Thư mục %s quá rộng (gốc ổ đĩa / thư mục người dùng) - chọn thư mục riêng chứa tờ khai đã nộp "
                           "(phần mềm quét cả thư mục con mỗi lần xuất tờ khai)." % gt)
        if gt:
            d["thu_muc_to_khai"] = gt
        else:
            d.pop("thu_muc_to_khai", None)
    elif re.fullmatch(r"bctc_\d{4}", khoa):
        if gt:
            if not os.path.isfile(gt):
                return False, "Không thấy tệp: %s" % gt
            if not gt.lower().endswith(DUOI_BCTC):
                return False, "Tệp BCTC phải là Excel (.xlsx / .xls / .csv), XML HTKK hoặc ZIP tải từ Cổng thuế: %s" % os.path.basename(gt)
        b = dict(d.get("bctc") or {})
        if gt:
            b[khoa[5:]] = gt
        else:
            b.pop(khoa[5:], None)
        d["bctc"] = b
    else:
        return False, "Khoá không hợp lệ: %s" % khoa
    try:
        ghi(thu_muc_khach, d)
    except Exception as e:
        return False, "Không ghi được %s: %s" % (TEN_TEP, e)
    return True, ""


def tom_tat(thu_muc_khach, mst="", htkk=None):
    """Cac dong KHOA=GIA TRI cho VB6 (khong kem so lieu to khai)."""
    d = doc(thu_muc_khach)
    ra = []
    t = _sach(d.get("thu_muc_to_khai"))
    ra.append("THU_MUC_TO_KHAI=%s" % t)
    ra.append("THU_MUC_TO_KHAI_CO=%d" % (1 if t and os.path.isdir(t) else 0))
    for nam, tep in sorted((d.get("bctc") or {}).items()):
        if re.fullmatch(r"\d{4}", str(nam)):
            tep = _sach(tep)
            ra.append("BCTC_%s=%s" % (nam, tep))
            ra.append("BCTC_%s_CO=%d" % (nam, 1 if tep and os.path.isfile(tep) else 0))
    goc = (htkk or {}).get("goc") or ""
    ra.append("HTKK=%s" % goc)
    co_data = 0
    so = re.sub(r"[^0-9-]", "", str(mst or ""))
    if goc and so:
        for ten in dict.fromkeys((so, so.replace("-", ""))):
            if os.path.isfile(os.path.join(goc, "DataFiles", ten, "HEADER.xml")):
                co_data = 1
                break
    ra.append("HTKK_MST=%d" % co_data)
    ra.append("TEP=%s" % duong(thu_muc_khach))
    return ra
