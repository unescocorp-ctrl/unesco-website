# -*- coding: utf-8 -*-
"""GD124 - KIEM TRA DU LIEU PHIEN BAN CU (CHI DOC, khong sua tep .MDB nao).

Anh Thang 05/10/2026: "kiem tra tung data cap nhat loi luu lai de cap nhat cho cac data cu cua khach hang dang su dung.
Chi cap nhat va sua loi de mo, xuat du lieu Excel, tao file luu lai - khong cap nhat He thong tai khoan, Bao cao tai
chinh vi quy dinh tai moi thoi diem khac nhau."

Voi moi tep .MDB: so voi reports\\MAU.MDB theo DUNG quy tac cua ModNangCapCu.bas (phan mem tu lam khi mo tep, co sao luu):
  * bang / cot se them; cot PSNLK / PSCLK nam truoc cua HeThongTK; bang tam ChungTuP / HoaDonP / ChungTuLQP / CNDauNam2;
  * KHONG them truy van (chuong trinh tu tao khi dung); truy van thieu so voi MAU chi liet ke;
  * KHONG dung: bang Bao cao tai chinh (CDTS*, KQKD*, LCTT*, PLKQKD*, BCTC*, ThuyetMinh*),
    tai khoan trong HeThongTK (chi them cot), kieu / do dai cot da co - chi liet ke de anh biet.
Bao cao ghi ra man hinh + tep KIEM_TRA_DU_LIEU_CU_<ngay gio>.txt canh tep du lieu (hoac --ghi). Khong in ten cong ty / MST.

Dung:  python kiem_tra_du_lieu_cu.py <thu muc hoac tep .MDB> [...] [--mau <MAU.MDB>] [--ghi <tep bao cao>] [--khong-ghi]"""
import datetime
import io
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)
import jet_doc  # noqa: E402

# --- cung quy tac voi ModNangCapCu.bas (test_gd124 doi chieu) ---
# (bang goc, bang tam, dong bo cot): CNDauNam2 can du cot ("INSERT INTO CNDauNam2 SELECT CNDauNam.*"); bang P chi can co mat
BANG_TAM = [("ChungTu", "ChungTuP", False), ("HoaDon", "HoaDonP", False), ("ChungTuLQ", "ChungTuLQP", False), ("CNDauNam", "CNDauNam2", True)]
KHONG_TAO = {"HETHONGTK", "LICENSE", "USERS", "THUE"}
DANH_MUC = {"LOAICONGCUDUNGCU", "PHANLOAIQUANLYNHANVIEN", "QUOCGIA", "TINHTRANG"}
TV_BCTC = {"QCDT", "QKQKD"}
NAM_TT133 = 2017


def la_bctc(ten):
    t = ten.upper().strip()
    return t.startswith(("CDTS", "KQKD", "LCTT", "PLKQKD", "BCTC", "THUYETMINH"))


def la_bang_tam(ten):
    return ten.upper() in {p.upper() for _, p, _d in BANG_TAM}


def cho_tao_bang(ten):
    t = ten.upper()
    return not la_bctc(t) and t not in KHONG_TAO and not la_bang_tam(t)


def la_cot_nam(ten):
    return re.match(r"^PS[NC]LK\d{4}$", ten.upper()) is not None


def bang_xet(ten):
    t = ten.upper()
    return not (t.startswith("MSYS") or t.startswith("~") or t.startswith("USYS"))


def truy_van_xet(ten):
    t = ten.upper().strip()
    if not t or t.startswith("~") or t.startswith("MSYS"):
        return False
    return not (t in TV_BCTC or t.startswith("QLCTT") or t.startswith("QBCTC"))


def cau_truc(m):
    """{TEN_HOA: (ten, {COT_HOA: (ten_cot, kieu, dai, tu_tang)})}, [truy van], nam_tc, so dong moi bang"""
    B = {}
    for t in m.bang():
        if not bang_xet(t):
            continue
        cols = {}
        for c in m.cot(t):
            cols[c["ten"].upper()] = (c["ten"], c["ten_kieu"], c["dai"], c.get("tu_tang", False))
        B[t.upper()] = (t, cols)
    Q = list(m.truy_van())
    nam = None
    if "LICENSE" in B:
        try:
            r = m.doc(B["LICENSE"][0], 1)
            if r:
                nam = r[0].get("NamTC")
        except Exception:
            nam = None
    return B, Q, nam


def ke_hoach(m_cu, m_mau, cache_mau=None):
    """Viec ModNangCapCu se lam khi mo tep (o che do 'lam': buoc 1 -> 2 -> 3 -> 4) + thong tin khong sua."""
    B, Q, nam = cau_truc(m_cu)
    if cache_mau is None:
        cache_mau = cau_truc(m_mau)
    M, QM, _ = cache_mau
    kh = {"bang": [], "cot": [], "tv": [], "tv_thieu": [], "dong_dm": {}, "bctc_thieu_bang": [], "bctc_thieu_cot": [], "khac_kieu": [],
          "chu_ngan": [], "nam": nam, "tam": []}
    sau = {k: (v[0], dict(v[1])) for k, v in B.items()}       # cau truc sau khi lam (de tinh bang tam)
    # 1. bang / cot theo MAU
    qcu = {q.upper() for q in Q}
    for k, (ten, cols) in M.items():
        if k not in B:
            if cho_tao_bang(ten) and k not in qcu:          # trung ten truy van -> Jet bao 3012: bo qua
                kh["bang"].append(ten)
                sau[k] = (ten, dict(cols))
                if k in DANH_MUC:
                    try:
                        n = m_mau.so_ban_ghi(ten)
                    except Exception:
                        n = 0
                    if n:
                        kh["dong_dm"][ten] = min(n, 200)
            elif la_bctc(ten):
                kh["bctc_thieu_bang"].append(ten)
            continue
        tcu, ccu = B[k]
        for ck, (cten, kieu, dai, tu) in cols.items():
            if ck in ccu:
                o = ccu[ck]
                if o[1] != kieu:
                    kh["khac_kieu"].append("%s.%s %s (MAU %s)" % (tcu, o[0], o[1], kieu))
                elif kieu == "TEXT" and o[2] < dai:
                    kh["chu_ngan"].append("%s.%s %d < %d" % (tcu, o[0], o[2], dai))
                continue
            if la_cot_nam(cten):
                continue
            if la_bctc(ten):
                kh["bctc_thieu_cot"].append("%s.%s" % (tcu, cten))
                continue
            kh["cot"].append("%s.%s" % (tcu, cten))
            sau[k][1][ck] = (cten, kieu, dai, tu)
    # 2. PSNLK / PSCLK nam truoc
    try:
        n = int(nam or 0)
    except Exception:
        n = 0
    if 1900 < n < 2200 and "HETHONGTK" in sau:
        tht, cht = sau["HETHONGTK"]
        for c in ("PSNLK%d" % (n - 1), "PSCLK%d" % (n - 1)):
            if c.upper() not in cht:
                kh["cot"].append("%s.%s" % (tht, c))
                cht[c.upper()] = (c, "DOUBLE", 8, False)
    # 3. bang tam theo bang goc (sau buoc 1)
    for goc, tam, dong_bo in BANG_TAM:
        if goc.upper() not in sau:
            continue
        cg = sau[goc.upper()][1]
        if tam.upper() not in sau:
            kh["bang"].append(tam)
            kh["tam"].append("%s (theo %s)" % (tam, sau[goc.upper()][0]))
            sau[tam.upper()] = (tam, dict(cg))
            continue
        if not dong_bo:
            continue
        tt, ct = sau[tam.upper()]
        for ck, v in cg.items():
            if ck not in ct:
                kh["cot"].append("%s.%s" % (tt, v[0]))
                ct[ck] = v
    # 4. KHONG them truy van (chuong trinh tu tao khi dung - SetSQL); chi ghi de biet
    for q in QM:
        if truy_van_xet(q) and q.upper() not in qcu:
            kh["tv_thieu"].append(q)
    kh["so_bang"] = len(B)
    kh["so_tv"] = len(Q)
    return kh


def _nhom_cot(ds):
    g = {}
    for x in ds:
        t, c = x.split(".", 1)
        g.setdefault(t, []).append(c)
    return ["%s: %s" % (t, ", ".join(cs)) for t, cs in sorted(g.items(), key=lambda a: a[0].upper())]


def bao_cao_tep(p, m_mau, cache_mau):
    L = []
    try:
        m = jet_doc.Mdb(p)
    except Exception as e:
        return ["TEP: %s" % os.path.basename(p), "  KHONG DOC DUOC: %s" % e, ""], None
    try:
        kh = ke_hoach(m, m_mau, cache_mau)
        kh["phien"] = "Access97" if not m.jet4 else "Access2000"
        L.append("TEP: %s   (%.1f MB, %s, nam tai chinh %s, %d bang, %d truy van)" % (
            os.path.basename(p), os.path.getsize(p) / 1048576.0, m.phien_ban, kh["nam"], kh["so_bang"], kh["so_tv"]))
        tong = len(kh["bang"]) + len(kh["cot"])
        if tong == 0:
            L.append("  Cau truc DU so voi MAU - phan mem mo khong can bo sung.")
        else:
            L.append("  Phan mem (GD124) se SAO LUU roi bo sung khi mo tep lan dau: %d bang, %d cot." % (
                len(kh["bang"]), len(kh["cot"])))
            if kh["bang"]:
                ds = []
                for t in kh["bang"]:
                    ds.append(t + (" (%d dong danh muc tu MAU)" % kh["dong_dm"][t] if t in kh["dong_dm"] else ""))
                L.append("  + Bang: " + ", ".join(ds))
            if kh["tam"]:
                L.append("    (bang tam tao theo bang goc cua chinh du lieu: %s)" % ", ".join(kh["tam"]))
            for x in _nhom_cot(kh["cot"]):
                L.append("  + Cot  " + x)
        if kh["tv_thieu"]:
            L.append("  Truy van MAU co ma tep chua co (%d) - KHONG them: chuong trinh tu tao khi dung." % len(kh["tv_thieu"]))
        L.append("  KHONG sua (theo yeu cau - quy dinh tung thoi diem):")
        L.append("    - He thong tai khoan: khong them / sua / xoa tai khoan (chi them cot neu thieu, gia tri 0).")
        if kh["bctc_thieu_bang"] or kh["bctc_thieu_cot"]:
            if kh["bctc_thieu_bang"]:
                L.append("    - Bang BCTC MAU co ma du lieu nay khong co: " + ", ".join(kh["bctc_thieu_bang"]))
            for x in _nhom_cot(kh["bctc_thieu_cot"]):
                L.append("    - Cot BCTC thieu so voi MAU: " + x)
            L.append("      -> In BCTC ban hien hanh tren du lieu nay co the bao thieu cot: giu nguyen mau BCTC cu cua thoi diem do.")
        else:
            L.append("    - Bang BCTC (CDTS/KQKD/LCTT...): khong khac MAU.")
        try:
            if kh["nam"] and int(kh["nam"]) < NAM_TT133:
                L.append("    - Nam tai chinh %s < %d: phan mem khong tu sua cong thuc BCTC (GD76/GD77) cho du lieu nay." % (kh["nam"], NAM_TT133))
        except Exception:
            pass
        if kh["khac_kieu"] or kh["chu_ngan"]:
            L.append("  Thong tin (khong sua): %d cot khac kieu, %d cot chu ngan hon MAU (doc / xuat Excel van duoc)." % (
                len(kh["khac_kieu"]), len(kh["chu_ngan"])))
            if kh["khac_kieu"]:
                L.append("    khac kieu: " + "; ".join(kh["khac_kieu"][:12]) + (" ..." if len(kh["khac_kieu"]) > 12 else ""))
        L.append("")
        return L, kh
    finally:
        m.dong()


def tim_tep(ds):
    kq = []
    for d in ds:
        if os.path.isdir(d):
            for r, dirs, fs in os.walk(d):
                dirs[:] = [x for x in dirs if x.upper() not in ("SAO_LUU_NANG_CAP", "_TO_DELETE")]
                for f in sorted(fs):
                    if f.lower().endswith(".mdb"):
                        kq.append(os.path.join(r, f))
        elif os.path.isfile(d):
            kq.append(d)
    return kq


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    mau = None
    ghi = None
    khong_ghi = False
    ds = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--mau":
            mau = argv[i + 1]
            i += 2
            continue
        if a == "--ghi":
            ghi = argv[i + 1]
            i += 2
            continue
        if a == "--khong-ghi":
            khong_ghi = True
            i += 1
            continue
        ds.append(a)
        i += 1
    if not ds:
        print(__doc__)
        return 2
    if mau is None:
        mau = os.path.join(os.path.dirname(HERE), "reports", "MAU.MDB")
    if not os.path.isfile(mau):
        print("Khong thay MAU.MDB: %s (dung --mau)" % mau)
        return 2
    m_mau = jet_doc.Mdb(mau)
    cache = cau_truc(m_mau)
    teps = [p for p in tim_tep(ds) if os.path.abspath(p).lower() != os.path.abspath(mau).lower()]
    now = datetime.datetime.now()
    L = ["KIEM TRA DU LIEU PHIEN BAN CU - GD124 (chi doc, khong sua tep nao)",
         "Luc: %s   Mau so sanh: %s (%s)" % (now.strftime("%Y-%m-%d %H:%M:%S"), mau, m_mau.phien_ban),
         "Quy tac: nhu ModNangCapCu.bas - phan mem tu sao luu (SAO_LUU_NANG_CAP\\) roi bo sung khi mo tep lan dau.",
         "So tep: %d" % len(teps), ""]
    tong = []
    for p in teps:
        dong, kh = bao_cao_tep(p, m_mau, cache)
        L.extend(dong)
        if kh is not None:
            tong.append((os.path.basename(p), kh["phien"], len(kh["bang"]), len(kh["cot"]), kh["nam"]))
    m_mau.dong()
    L.append("TONG HOP")
    L.append("  %-34s %-10s %6s %6s %6s" % ("Tep", "Dinh dang", "Bang", "Cot", "Nam"))
    for t in tong:
        L.append("  %-34s %-10s %6d %6d %6s" % t)
    txt = "\n".join(L) + "\n"
    try:
        print(txt)
    except UnicodeEncodeError:
        print(txt.encode("ascii", "replace").decode("ascii"))
    if not khong_ghi and teps:
        if ghi is None:
            goc = ds[0] if os.path.isdir(ds[0]) else os.path.dirname(os.path.abspath(ds[0]))
            ghi = os.path.join(goc, "KIEM_TRA_DU_LIEU_CU_%s.txt" % now.strftime("%Y%m%d_%H%M%S"))
        io.open(ghi, "w", encoding="utf-8-sig", newline="\r\n").write(txt)
        print("Da luu bao cao: %s" % ghi)
    return 0


if __name__ == "__main__":
    sys.exit(main())
