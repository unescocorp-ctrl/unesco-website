# -*- coding: utf-8 -*-
"""GD241 - Cong G6 "Gia thanh khop" tinh tu chung tu (khong tu so du HeThongTK).
   K47: tong gia thanh tren phieu ket chuyen thanh pham (ThanhPham CPNVL + CPNC + CPSXC) = No 155 / Co 154 tren so theo thang
        (dl["doi_ung"] = [MaTKNo, MaTKCo, thang duong lich, tien], VB GD237).
   K48: so du cuoi TUNG THANG: 154 khong du Co; so TT99: 621 / 622 / 627 khong con du (phai ket chuyen het sang 154).
   K49: gia thanh don vi: dong thanh pham co so luong ma gia = 0 (LOI); gia don vi lech > 50% so trung vi cac thang cua cung ma
        (CANH_BAO). dl["gt"]["dvi"] = [Thang, SoHieu, Ten, SoLuong, GiaTri] (VB GD241 gui them; ban VB cu khong co -> bo qua).
   Chi doc so lieu, khong sua gi. Ham nhan _kq va cac muc tu kiem_khoa_so de khong phu thuoc vong.
"""
from collections import defaultdict

NGUONG_LECH_TIEN = 1000.0       # dong
NGUONG_LECH_TY_LE = 0.005       # 0,5 %
NGUONG_DVI = 0.5                # 50 %


def _f(x):
    try:
        return float(x or 0)
    except Exception:
        return 0.0


def _thang_dl(S, t):
    return (t + S.dau_ky - 2) % 12 + 1


def _t_tc(S, th):
    return (int(th) - S.dau_ky) % 12 + 1


def _du_thang(S, m, t):
    """so du (No - Co) TK la m cuoi thang t (thu tu nam tai chinh), tinh tu phat sinh tung thang (ca phan ket chuyen)."""
    tk = S.tk.get(m) or {}
    du = _f(tk.get("dn0")) - _f(tk.get("dc0"))
    p = S.ps.get(m) if hasattr(S.ps, "get") else None
    if p:
        for k, x in p["thang"].items():
            if k <= t:
                du += x[0] + x[2] - x[1] - x[3]
    return du


def _sh(S, m):
    return (S.tk.get(m) or {}).get("sh", "")


def k_gt_khop_so(S, G, _kq, DAT, CANH_BAO, LOI, THONG_TIN):
    ten = "Giá thành trên phiếu kết chuyển = nhập kho thành phẩm trên sổ (Nợ 155 / Có 154)"
    if not G or not G.co:
        return None
    if G.gia_ht > 0:
        return _kq("K47", ten, THONG_TIN, "Sổ tính theo giá hạch toán - nhập kho thành phẩm theo giá hạch toán, không so mục này.")
    du = S.dl.get("doi_ung") or []
    if not du:
        return _kq("K47", ten, THONG_TIN, "Chưa có số liệu đối ứng tài khoản (bản phần mềm cũ) - Make .exe bản mới rồi chạy lại.")
    so = defaultdict(float)
    so632 = defaultdict(float)
    for r in du:
        try:
            n, c, th, p = int(r[0]), int(r[1]), int(r[2]), _f(r[3])
        except Exception:
            continue
        if not _sh(S, c).startswith("154"):
            continue
        if _sh(S, n).startswith("155"):
            so[th] += p
        elif _sh(S, n).startswith("632"):
            so632[th] += p
    dong = []
    for t in range(S.t1, S.t2 + 1):
        th = _thang_dl(S, t)
        ds = G.phieu_thang(th)
        if not ds:
            continue
        bang = sum(p["nvl"] + p["nc"] + p["sxc"] for p in ds)
        lech = bang - so[th]
        if abs(lech) > max(NGUONG_LECH_TIEN, NGUONG_LECH_TY_LE * abs(bang)):
            dong.append([th, ", ".join(p["sh"] for p in ds), bang, so[th], lech, so632[th],
                         "Mở phiếu kết chuyển tháng %d, bấm Ghi lại (giá thành ghi lại chứng từ nhập kho)" % th])
    if dong:
        return _kq("K47", ten, CANH_BAO, "%d tháng tổng giá thành trên phiếu kết chuyển khác giá trị nhập kho thành phẩm trên sổ (Nợ 155 / Có 154): "
                   "chứng từ nhập kho chưa ghi lại sau khi sửa chi phí, hoặc có bút toán tay vào 155 / 154. Phần chuyển thẳng 632 (vượt mức) "
                   "hiện ở cột riêng để xem." % len(dong),
                   ["Tháng", "Phiếu", "Giá thành trên phiếu", "Nợ 155 / Có 154 trên sổ", "Chênh lệch", "Nợ 632 / Có 154", "Cách xử lý"], dong)
    return _kq("K47", ten, DAT, "Giá thành trên các phiếu kết chuyển khớp nhập kho thành phẩm trên sổ từng tháng.")


def k_gt_du_thang(S, _kq, DAT, CANH_BAO, LOI, THONG_TIN):
    ten = "Số dư cuối từng tháng: 154 không dư Có; 621 / 622 / 627 đã kết chuyển hết (TT99)"
    ds154 = S.la_theo("154")
    ds62 = S.la_theo("621", "622", "627") if S.cp99 else []
    if not ds154 and not ds62:
        return None
    dong = []
    co_loi = False
    for t in range(S.t1, S.t2 + 1):
        th = _thang_dl(S, t)
        for m in ds154:
            d = _du_thang(S, m, t)
            if d < -1:
                co_loi = True
                dong.append([th, S.ten(m), d, "154 dư Có: giá thành nhập kho lớn hơn chi phí đã tập hợp - xem phiếu kết chuyển tháng này"])
        for m in ds62:
            d = _du_thang(S, m, t)
            if abs(d) > 1:
                co_loi = True
                dong.append([th, S.ten(m), d, "Chưa kết chuyển hết sang 154 - Ghi lại phiếu kết chuyển / kết chuyển chi phí sản xuất tháng này"])
    if dong:
        return _kq("K48", ten, LOI if co_loi else CANH_BAO, "%d trường hợp số dư cuối tháng sai nguyên tắc giá thành." % len(dong),
                   ["Tháng", "Tài khoản", "Số dư cuối tháng (Nợ - Có)", "Cách xử lý"], dong)
    return _kq("K48", ten, DAT, "Cuối các tháng: 154 không dư Có%s." % ("; 621 / 622 / 627 không còn dư" if S.cp99 else ""))


def k_gt_don_vi(S, G, _kq, DAT, CANH_BAO, LOI, THONG_TIN):
    ten = "Giá thành đơn vị thành phẩm (giá 0, lệch xa các tháng)"
    if not G or not G.co or G.gia_ht > 0:
        return None
    rows = (S.dl.get("gt") or {}).get("dvi")
    if rows is None:
        return None
    theo_ma = defaultdict(list)
    ten_ma = {}
    for r in rows:
        if len(r) < 5:
            continue
        th, sh, tn, sl, gt = int(_f(r[0])), str(r[1] or ""), str(r[2] or ""), _f(r[3]), _f(r[4])
        if sl <= 0:
            continue
        theo_ma[sh].append((th, sl, gt))
        ten_ma[sh] = tn
    dong = []
    co_loi = False
    thang_ky = set(_thang_dl(S, t) for t in range(S.t1, S.t2 + 1))
    for sh, ds in sorted(theo_ma.items()):
        dv = sorted(gt / sl for _, sl, gt in ds if gt > 0)
        tv = 0.0
        if len(dv) >= 3:
            k = len(dv) // 2
            tv = dv[k] if len(dv) % 2 else (dv[k - 1] + dv[k]) / 2.0
        for th, sl, gt in sorted(ds):
            if th not in thang_ky:
                continue
            g = gt / sl
            if abs(gt) < 1:
                co_loi = True
                dong.append([th, sh, ten_ma[sh], sl, gt, 0, round(tv) if tv else "", "Giá thành = 0: thiếu định mức / chi phí - Ghi lại phiếu"])
            elif tv > 0 and abs(g - tv) > NGUONG_DVI * tv:
                dong.append([th, sh, ten_ma[sh], sl, gt, round(g), round(tv), "Lệch %d%% so trung vị - xem định mức, tiêu thức, sản lượng" % round(100 * (g - tv) / tv)])
    if dong:
        return _kq("K49", ten, LOI if co_loi else CANH_BAO, "%d dòng thành phẩm có giá thành đơn vị bất thường." % len(dong),
                   ["Tháng", "Mã", "Tên", "Số lượng", "Giá trị", "Giá đơn vị", "Trung vị các tháng", "Cách xử lý"], dong)
    return _kq("K49", ten, DAT, "Không có thành phẩm giá 0; giá đơn vị không lệch xa trung vị các tháng.")


def k_g6(S, G, _kq, DAT, CANH_BAO, LOI, THONG_TIN):
    kq = [k_gt_khop_so(S, G, _kq, DAT, CANH_BAO, LOI, THONG_TIN),
          k_gt_du_thang(S, _kq, DAT, CANH_BAO, LOI, THONG_TIN),
          k_gt_don_vi(S, G, _kq, DAT, CANH_BAO, LOI, THONG_TIN)]
    return [k for k in kq if k]
