# -*- coding: utf-8 -*-
"""GD303 - mo phong LOI GIA THANH HOP NHAT (CUNG quy tac ModGiaThanhLoi.bas) tren du lieu gia lap.

Day la ban doi chieu bang Python cua cac cong thuc trong ModGiaThanhLoi.bas:
  do_dang_4        <-> GTL_DoDang4      (QD11)
  chia_dd_dau      <-> GTL_ChiaDDDau
  vuot             <-> GTL_Vuot         (QD2: ba cot vuot)
  sxc_duoi_cs      <-> GTL_SXCDuoiCS    (VAS 02 doan 8)
  sp_hong          <-> GTL_SPHong       (QD9)
  luy_ke           <-> GTL_LuyKe
  con_phai_dc      <-> GTL_ConPhaiDieuChinh (BB8)
  ghi_dieu_chinh   <-> GTL_GhiDieuChinh (QD1)
  chan_khoa_nam    <-> GTL_ChanKhoaNam  (BB8)
Lam tron theo RoundMoney cua Utilitie.bas voi pTien = 0 (VND nguyen dong - quy tac 6).

Dung de kiem so bang tay (test_gd303a.py goi cac ham nay). Khong mo MDB, khong can VB6.
"""
import math


def rm(x):
    """RoundMoney(tien) khi pTien = 0: Fix(+/-0.5 + tien)."""
    return float(math.trunc(x + (0.5 if x >= 0 else -0.5)))


# --------------------------------------------------------------- QD11 do dang cach 4
def do_dang_4(ty_le, dau, ps):
    """dau / ps = (NVL, NC, SXC). Tra ve (tong_do_dang, cuoi_NVL, cuoi_NC, cuoi_SXC).

    DDCuoi = TyLe% x (do dang dau ky + chi phi phat sinh trong ky) cua doi tuong,
    chia cho tung khoan muc theo chi phi thuc te cua khoan muc do trong cung mau so.
    Chenh lech lam tron don vao khoan muc lon nhat (BB2).
    """
    g = [dau[i] + ps[i] for i in range(3)]
    tong = sum(g)
    if ty_le <= 0 or tong <= 0:
        return 0.0, 0.0, 0.0, 0.0
    dd = rm(ty_le / 100.0 * tong)
    if dd <= 0:
        return 0.0, 0.0, 0.0, 0.0
    if dd > rm(tong):
        dd = rm(tong)
    lon = max(range(3), key=lambda i: g[i])
    cuoi = [0.0, 0.0, 0.0]
    da = 0.0
    for i in range(3):
        if i != lon and g[i] > 0:
            cuoi[i] = rm(dd * g[i] / tong)
            da += cuoi[i]
    cuoi[lon] = dd - da
    return dd, cuoi[0], cuoi[1], cuoi[2]


def chia_dd_dau(dau_tong, ps):
    """Chia mot so do dang dau ky TONG thanh ba khoan muc theo ty trong chi phi phat sinh."""
    tong = sum(ps)
    if dau_tong == 0:
        return 0.0, 0.0, 0.0
    if tong <= 0:
        return rm(dau_tong), 0.0, 0.0
    nc = rm(dau_tong * ps[1] / tong)
    sxc = rm(dau_tong * ps[2] / tong)
    return rm(dau_tong) - nc - sxc, nc, sxc


# --------------------------------------------------------------- QD2 ba cot vuot
def vuot(thuc_te, dinh_muc, muc_bt, dm_nha_nuoc):
    """Tra ve (vuot_binh_thuong, vuot_dm_noi_bo, vuot_dm_nha_nuoc)."""
    if dinh_muc <= 0:
        return 0.0, 0.0, 0.0
    if muc_bt < 0:
        muc_bt = 0.0
    chuan = rm(dinh_muc * (1 + muc_bt / 100.0))
    bt = rm(thuc_te - chuan) if thuc_te > chuan else 0.0
    nb = rm(thuc_te - dinh_muc) if thuc_te > dinh_muc else 0.0
    return bt, nb, (nb if dm_nha_nuoc else 0.0)


# --------------------------------------------------------------- VAS 02 doan 8
def sxc_duoi_cs(sxc_co_dinh, sl_thuc_te, cs_bt):
    """Chi phi SXC co dinh KHONG phan bo khi san luong thuc te < cong suat binh thuong."""
    if sxc_co_dinh <= 0 or cs_bt <= 0:
        return 0.0
    if sl_thuc_te < 0:
        sl_thuc_te = 0.0
    if sl_thuc_te >= cs_bt:
        return 0.0
    return rm(sxc_co_dinh) - rm(sxc_co_dinh * sl_thuc_te / cs_bt)


# --------------------------------------------------------------- QD9 san pham hong
def sp_hong(sl_hong, sl_tot, pct_dm, gt_don_vi):
    if sl_hong <= 0 or gt_don_vi <= 0:
        return 0.0
    if pct_dm < 0:
        pct_dm = 0.0
    v = sl_hong - pct_dm / 100.0 * sl_tot
    return rm(v * gt_don_vi) if v > 0 else 0.0


# --------------------------------------------------------------- GiaThanh_KQ
def dong_kq(thang, ma_ct, ma_tp, **kw):
    """Mot dong GiaThanh_KQ gia lap."""
    d = dict(Thang=thang, MaCT=ma_ct, MaTP=ma_tp, SL=0.0, SLHong=0.0,
             CPNVL=0.0, CPNC=0.0, CPSXC=0.0, DDDauNVL=0.0, DDDauNC=0.0, DDDauSXC=0.0,
             DDCuoiNVL=0.0, DDCuoiNC=0.0, DDCuoiSXC=0.0, TyLeDD=0.0, CachDD=4,
             VuotBinhThuong=0.0, VuotDMNhaNuoc=0.0, VuotDMNoiBo=0.0,
             SXCDuoiCS=0.0, SPHong=0.0, DaDieuChinh=0.0, TrangThaiKy="")
    d.update(kw)
    return d


def luy_ke(rows, tu_thang, den_thang):
    """Tra ve (so_dong, vuot_bt, sxc_duoi, hong, da_dieu_chinh) cua ky."""
    r = [d for d in rows if tu_thang <= d["Thang"] <= den_thang]
    return (len(r),
            sum(d["VuotBinhThuong"] for d in r),
            sum(d["SXCDuoiCS"] for d in r),
            sum(d["SPHong"] for d in r),
            sum(d["DaDieuChinh"] for d in r))


def con_phai_dc(rows, bo_qua=()):
    """BB8: con phai dieu chinh trong nam; bo_qua = danh sach thang da ghi ly do bo qua."""
    con = 0.0
    for t in range(1, 13):
        if t in bo_qua:
            continue
        n, bt, sxc, hong, da = luy_ke(rows, t, t)
        if n:
            con += bt + sxc + hong - da
    return max(con, 0.0)


def ghi_dieu_chinh(rows, tu_thang, den_thang, thang_khoa=()):
    """QD1: mot but toan No 632 cho ca ky; chi lay thang chua khoa so.
    Cap nhat DaDieuChinh tai cho. Tra ve tong so tien da ghi."""
    tong = 0.0
    for d in rows:
        if not (tu_thang <= d["Thang"] <= den_thang):
            continue
        if d["Thang"] in thang_khoa:
            continue
        tien = rm(d["VuotBinhThuong"] + d["SXCDuoiCS"] + d["SPHong"] - d["DaDieuChinh"])
        if tien > 0:
            d["DaDieuChinh"] += tien
            tong += tien
    return tong


ID_DC = 640000000


def dieu_chinh_so_don(rows, so_don, tu_thang, den_thang, thang_khoa=()):
    """GD303e - so TT58: moi doi tuong con phai dieu chinh -> mot dong S2b-DNSN yeu to "e",
    MaCT = ID_DC + den_thang; cong DaDieuChinh (thoa BB8). KHONG co chung tu.
    so_don: danh sach dong GiaThanh_SoDon (dict) - them vao tai cho. Tra ve tong."""
    tong = 0.0
    for d in rows:
        if not (tu_thang <= d["Thang"] <= den_thang) or d["Thang"] in thang_khoa:
            continue
        tien = rm(d["VuotBinhThuong"] + d["SXCDuoiCS"] + d["SPHong"] - d["DaDieuChinh"])
        if tien > 0:
            so_don.append(dict(Thang=den_thang, Mau="S2b-DNSN", YeuTo="e", MaCT=ID_DC + den_thang,
                               MaTP=d["MaTP"], SoTien=tien))
            d["DaDieuChinh"] += tien
            tong += tien
    return tong


def ghi_lai_so_don_thang(so_don, thang, dong_moi):
    """GTL_GhiSoDon: xoa dong so don CUA THANG (MaCT < ID_DC) roi ghi lai; giu dong dieu chinh."""
    so_don[:] = [d for d in so_don if not (d["Thang"] == thang and d["MaCT"] < ID_DC)] + list(dong_moi)


def huy_dieu_chinh_so_don(rows, so_don, tu_thang, den_thang):
    """Huy lo SODON: xoa dong S2b cua lo (MaCT = ID_DC + den_thang), tra DaDieuChinh."""
    so_don[:] = [d for d in so_don if d["MaCT"] != ID_DC + den_thang]
    huy_dieu_chinh(rows, tu_thang, den_thang)


def huy_dieu_chinh(rows, tu_thang, den_thang):
    """Huy lo dieu chinh: tra lai DaDieuChinh = 0 cho ky."""
    for d in rows:
        if tu_thang <= d["Thang"] <= den_thang:
            d["DaDieuChinh"] = 0.0


def chan_khoa_nam(rows, bo_qua=()):
    """BB8: "" = khoa duoc; khac "" = ly do chan."""
    if any(d.get("TrangThaiKy") == "CHOKY" for d in rows):
        return "CHOKY"
    return "CONDC" if con_phai_dc(rows, bo_qua) > 0 else ""
