# -*- coding: utf-8 -*-
"""GD161 (Gia thanh Goi A) - BAO CAO KIEM TRA GIA THANH THANG. CHI DOC, khong doi cach tinh.

  * Gia thanh so gia ban (thang chon): moi ma thanh pham co san xuat: san luong, gia thanh / DVT (ThanhPham: NVL + NC + SXC), gia ban / DVT
    (Co 511 theo ma: so tien / so luong; thang chua ban -> thang gan nhat co ban, ghi ro), % gia thanh tren gia ban, lai gop / DVT, ty le
    NVL / NC / SXC tren gia ban (de lap ty le muc tieu o Goi B), gia von xuat ban / DVT (No 632 Co 155) neu co; nhan xet: gia thanh = 0,
    cao hon gia ban (lo), lai mong, chua co gia ban de so.
  * Ky nay so ky truoc: gia thanh / DVT thang chon so thang gan nhat truoc do co san xuat ma do; chenh lech tach NVL / NC / SXC;
    doi tren 25 % -> can xem (khoan muc doi nhieu nhat).
  * Theo thang: gia thanh / DVT tung ma tung thang trong nam tai chinh den thang chon.
Dau vao: JSON VB6 (ModGTTrinhTu.GT161_Json) "gt161" {thang (lich), dau_ky, nam, nc_thuc_te, tp [MaCT, Thang, MaTP, SL, NVL, NC, SXC, GT, Ma154],
  ban [MaVattu, Thang, tien, SL] (Co 511), gv [MaVattu, Thang, tien, SL] (No 632 Co 155), vt [MaSo, SoHieu, Ten, DVT], dm [MaTP, so dong NVL]}.
  GD163 (Goi B): "mt" [thang, MaTP, Ma154, pham vi M/L/S, %NVL, %NC, %SXC, gia ban tay, gia tham chieu, nguon] - ty le muc tieu
  (ModDinhMucTyLe) theo ma / lo; gia so sanh = gia tham chieu VB6 cua lo san luong lon nhat (cung cach buoc 6 DMTL163_DemLech);
  sheet MucTieu: gia thanh thuc te / gia ban so ty le muc tieu (gia von % gia ban), chenh tach NVL / NC / SXC; lech tren 20 % (tuong doi)
  -> canh bao "Lech ty le muc tieu"; dong MT;GTBC;<so ma co muc tieu>;<so ma lech> cho VB6 (buoc 6, tom tat).
Ra: Excel + HTML + ket-qua\\gia_thanh_bc.txt (TONG + dong canh bao cho VB6)."""
import html
import io
import json
import os
import re
from collections import defaultdict

GOC = os.path.dirname(os.path.abspath(__file__))
TEP_KQ = "gia_thanh_bc.txt"
NGUONG_MONG = 0.10          # lai gop duoi 10 % gia ban -> lai mong
NGUONG_DOI = 0.25           # gia thanh / DVT doi tren 25 % so ky truoc -> can xem
NGUONG_MT = 0.20            # GD163: gia thanh / gia ban lech ty le muc tieu tren 20 % (tuong doi) -> can xem
TEN_PV = {"M": "Mã", "L": "Lô", "S": "Sổ"}
MUC = {"Cao": 3, "Vừa": 2, "Thấp": 1, "Thông tin": 0}


def _so(x):
    try:
        return float(x or 0)
    except (TypeError, ValueError):
        return 0.0


def tien(x):
    return "{:,.0f}".format(round(x or 0)).replace(",", ".")


def pt(x, le=1):
    return (("%." + str(le) + "f%%") % (x * 100)).replace(".", ",")


def trung_vi(ds):
    ds = sorted(ds)
    if not ds:
        return None
    n = len(ds)
    return ds[n // 2] if n % 2 else (ds[n // 2 - 1] + ds[n // 2]) / 2.0


def _sach(s, n=300):
    return re.sub(r"[\t\r\n;]+", " ", str(s or "")).strip()[:n]


class BaoCao(object):
    def __init__(self, dl):
        self.dl = dl
        b = dl.get("gt161") or {}
        self.b = b
        self.dau_ky = int(_so(b.get("dau_ky")) or 1)
        if not 1 <= self.dau_ky <= 12:
            self.dau_ky = 1
        self.nam = int(_so(b.get("nam")) or 0)
        self.thang = int(_so(b.get("thang")) or 1)
        self.nc_thuc_te = bool(b.get("nc_thuc_te"))
        self.vt = {}
        for r in b.get("vt") or []:
            self.vt[int(_so(r[0]))] = (str(r[1] or ""), str(r[2] or ""), str(r[3] or "") if len(r) > 3 else "")
        self.dm = {int(_so(r[0])): int(_so(r[1])) for r in b.get("dm") or []}
        # san xuat: (ma, thang tai chinh) -> [sl, nvl, nc, sxc, gt]
        self.sx = defaultdict(lambda: [0.0, 0.0, 0.0, 0.0, 0.0])
        self.sx_lo = defaultdict(float)          # GD163: (ma, thang tai chinh, lo) -> san luong
        for r in b.get("tp") or []:
            ma, th = int(_so(r[2])), self.tc(r[1])
            if ma <= 0 or th <= 0:
                continue
            self.sx_lo[(ma, th, int(_so(r[8])) if len(r) > 8 else 0)] += _so(r[3])
            x = self.sx[(ma, th)]
            x[0] += _so(r[3])
            x[1] += _so(r[4])
            x[2] += _so(r[5])
            x[3] += _so(r[6])
            x[4] += _so(r[7])
        self.ban = defaultdict(lambda: [0.0, 0.0])
        for r in b.get("ban") or []:
            ma, th = int(_so(r[0])), self.tc(r[1])
            if ma > 0 and th > 0:
                self.ban[(ma, th)][0] += _so(r[2])
                self.ban[(ma, th)][1] += _so(r[3])
        self.gv = defaultdict(lambda: [0.0, 0.0])
        for r in b.get("gv") or []:
            ma, th = int(_so(r[0])), self.tc(r[1])
            if ma > 0 and th > 0:
                self.gv[(ma, th)][0] += _so(r[2])
                self.gv[(ma, th)][1] += _so(r[3])
        self.t = self.tc(self.thang)
        self.canh_bao = []
        # GD163: ty le muc tieu (thang tai chinh, ma, lo) -> (pham vi, %NVL, %NC, %SXC, gia ban tay)
        self.mt = {}
        for r in b.get("mt") or []:
            try:
                th, ma, lo = self.tc(r[0]), int(_so(r[1])), int(_so(r[2]))
                pv = str(r[3] or "S")[:1].upper()
                if th > 0 and ma > 0:
                    self.mt[(th, ma, lo)] = (pv if pv in TEN_PV else "S", _so(r[4]), _so(r[5]), _so(r[6]), _so(r[7]) if len(r) > 7 else 0.0,
                                             _so(r[8]) if len(r) > 8 else 0.0)
            except (IndexError, TypeError, ValueError):
                continue
        self.co_mt = bool(self.mt)

    def tc(self, th):
        """thang duong lich -> thu tu thang tai chinh 1..12."""
        t = int(_so(th))
        if not 1 <= t <= 12:
            return 0
        return t - self.dau_ky + 1 if t >= self.dau_ky else 13 - self.dau_ky + t

    def chu_thang(self, t):
        m = (self.dau_ky - 1 + t - 1) % 12 + 1
        y = self.nam + (1 if (self.dau_ky > 1 and m < self.dau_ky) else 0) if self.nam else 0
        return ("%02d/%d" % (m, y)) if y else "%02d" % m

    def ten(self, ma):
        v = self.vt.get(ma)
        return v if v else ("mã %d" % ma, "", "")

    def gia_ban(self, ma, t):
        """-> (gia / DVT, thang lay gia) - thang t, khong co thi thang gan nhat truoc do co ban."""
        for tt in range(t, 0, -1):
            dtien, q = self.ban.get((ma, tt), (0.0, 0.0))
            if q > 0 and dtien > 0:
                return dtien / q, tt
        return None, None

    def muc_tieu(self, ma, t):
        """GD163: ty le muc tieu cua ma trong thang t (gia quyen san luong cac lo co ty le) -> dict hoac None."""
        cac = [(sl, self.mt[(t, m, lo)]) for (m, th, lo), sl in self.sx_lo.items() if m == ma and th == t and (t, m, lo) in self.mt]
        if not cac:
            return None
        tong = sum(max(sl, 0.0) for sl, _ in cac)
        w = [(max(sl, 0.0) / tong) if tong > 0 else 1.0 / len(cac) for sl, _ in cac]
        n = sum(wi * x[1] for wi, (_, x) in zip(w, cac)) / 100.0
        c = sum(wi * x[2] for wi, (_, x) in zip(w, cac)) / 100.0
        x_ = sum(wi * x[3] for wi, (_, x) in zip(w, cac)) / 100.0
        pv = "/".join(TEN_PV[k] for k in ("M", "L", "S") if any(x[0] == k for _, x in cac))
        gbt = max((x[4] for _, x in cac), default=0.0)
        lon = max(cac, key=lambda z: z[0])[1]          # gia tham chieu VB6 (DMTL163_GiaBan) cua lo san luong lon nhat - nhu buoc 6
        return {"pv": pv, "nvl": n, "nc": c, "sxc": x_, "gv": n + c + x_, "gbt": gbt, "gbr": lon[5] if len(lon) > 5 else 0.0}

    # -------------------------------------------------------------------------------------------- tinh
    def tinh(self):
        t = self.t
        dong, ky = [], []
        cb = []
        mt_cb = []
        mas = sorted(set(m for (m, th) in self.sx if th == t))
        tong_thang = sum(self.sx[(m, t)][4] for m in mas) or 1.0
        n_mong = 0
        # bien lai gop trung vi cua so: so bien thap chung (vd 7 %) thi "lai mong" so voi bien cua chinh so (nhu GD159)
        bien = []
        for ma in mas:
            sl, _, _, _, gt = self.sx[(ma, t)]
            gb, _ = self.gia_ban(ma, t)
            if sl > 0 and gt > 0 and gb:
                bien.append((gb - gt / sl) / gb)
        self.bien_tv = trung_vi(bien)
        self.bm = min(NGUONG_MONG, max(0.0, 0.5 * self.bien_tv)) if self.bien_tv is not None else NGUONG_MONG
        for ma in mas:
            sl, nvl, nc, sxc, gt = self.sx[(ma, t)]
            sh, ten, dvt = self.ten(ma)
            u = gt / sl if sl > 0 else None
            gb, tgb = self.gia_ban(ma, t)
            gvt, gvq = self.gv.get((ma, t), (0.0, 0.0))
            r = {"ma": ma, "sh": sh, "ten": ten, "dvt": dvt, "sl": sl, "gt": gt, "u": u, "nvl": nvl, "nc": nc, "sxc": sxc, "gb": gb,
                 "tgb": tgb, "gv_u": (gvt / gvq) if gvq > 0 else None, "ty": None, "lg": None, "nx": ""}
            if sl > 0 and gt <= 0:
                r["nx"] = "Giá thành = 0" + (": chưa có định mức NVL" if not self.dm.get(ma) else ": thiếu chi phí / chưa ghi lại")
                cb.append(("Cao", "Giá thành = 0", sh, "%s: sản lượng %s nhưng giá thành = 0%s" % (ten[:50], tien(sl), "" if self.dm.get(ma) else " (chưa có định mức NVL)"),
                           "Lập định mức (Định mức tự động) / kiểm tra chi phí tháng rồi ghi lại phiếu kết chuyển."))
            elif u is not None and gb:
                r["ty"] = u / gb
                r["lg"] = gb - u
                r["p_nvl"], r["p_nc"], r["p_sxc"] = nvl / sl / gb, nc / sl / gb, sxc / sl / gb
                ghi_gb = "" if tgb == t else " (giá bán tháng %s)" % self.chu_thang(tgb)
                if u > gb:
                    r["nx"] = "Giá thành cao hơn giá bán%s" % ghi_gb
                    cb.append(("Cao", "Giá thành cao hơn giá bán", sh, "%s: giá thành %s / %s, giá bán %s%s" % (ten[:50], tien(u), dvt or "ĐVT", tien(gb), ghi_gb),
                               "Kiểm tra định mức, giá nguyên liệu, chi phí phân bổ; xem lại giá bán."))
                elif (gb - u) / gb < self.bm:
                    r["nx"] = "Lãi mỏng (dưới %s)%s" % (pt(self.bm), ghi_gb)
                    n_mong += 1
                    if n_mong <= 30 and gt >= 0.002 * tong_thang:
                        cb.append(("Vừa", "Lãi mỏng", sh, "%s: giá thành bằng %s giá bán%s" % (ten[:50], pt(u / gb), ghi_gb), "Xem lại giá bán hoặc chi phí."))
                else:
                    r["nx"] = "Bình thường%s" % ghi_gb
            elif u is not None:
                r["nx"] = "Chưa có giá bán để so"
            # GD163: thuc te so ty le muc tieu
            mt = self.muc_tieu(ma, t) if self.co_mt else None
            if mt:
                g = mt["gbr"] if mt["gbr"] > 0 else (mt["gbt"] if mt["gbt"] > 0 else gb)   # gia tham chieu VB6 (tay -> danh diem -> hoa don) roi hoa don
                mt["gb"] = g
                if g and u is not None and sl > 0 and mt["gv"] > 0:
                    mt["tt"] = u / g
                    mt["a_nvl"], mt["a_nc"], mt["a_sxc"] = nvl / sl / g, nc / sl / g, sxc / sl / g
                    mt["lech"] = (mt["tt"] - mt["gv"]) / mt["gv"]
                    if abs(mt["lech"]) > NGUONG_MT:
                        km = max((("NVL", mt["a_nvl"] - mt["nvl"]), ("nhân công", mt["a_nc"] - mt["nc"]), ("chi phí chung", mt["a_sxc"] - mt["sxc"])),
                                 key=lambda z: abs(z[1]))
                        mt["nx"] = "%s mục tiêu %s, chủ yếu do %s" % ("Cao hơn" if mt["lech"] > 0 else "Thấp hơn", pt(abs(mt["lech"]), 0), km[0])
                        mt_cb.append(("Vừa", "Lệch tỷ lệ mục tiêu", sh, "%s: giá thành bằng %s giá bán, mục tiêu %s (%s), chênh nhiều nhất ở %s" % (
                            ten[:50], pt(mt["tt"]), pt(mt["gv"]), mt["pv"], km[0]),
                            "Xem định mức, giá nguyên liệu, chi phí tháng; hoặc sửa tỷ lệ ở Giá thành - Định mức theo tỷ lệ giá bán.", abs(mt["lech"]) * gt))
                    else:
                        mt["nx"] = "Trong mức (lệch dưới %s)" % pt(NGUONG_MT, 0)
                elif u is not None:
                    mt["nx"] = "Chưa có giá bán để so"
                r["mt"] = mt
            dong.append(r)
            # ky truoc
            tp = None
            for tt in range(t - 1, 0, -1):
                x = self.sx.get((ma, tt))
                if x and x[0] > 0 and x[4] > 0:
                    tp = tt
                    break
            if tp and u:
                s2, n2, c2, x2, g2 = self.sx[(ma, tp)]
                u2 = g2 / s2
                k = {"ma": ma, "sh": sh, "ten": ten, "dvt": dvt, "t2": tp, "u2": u2, "u": u, "ch": (u - u2) / u2 if u2 else None,
                     "d_nvl": nvl / sl - n2 / s2, "d_nc": nc / sl - c2 / s2, "d_sxc": sxc / sl - x2 / s2, "nx": ""}
                ky.append(k)
        ch_tv = 0.0
        self.ch_tv = ch_tv
        # nhom ma cung doi mot muc (lam tron 5 %, tu 5 ma) -> 1 dong chung cho nhom, khong bao tung ma
        nhom = defaultdict(list)
        for k in ky:
            if k["ch"] is not None and abs(k["ch"] - ch_tv) > NGUONG_DOI:
                nhom[int(round(k["ch"] * 20))].append(k)
        bo = set()
        for g, ds in sorted(nhom.items(), key=lambda z: -len(z[1])):
            if len(ds) >= 5:
                bo.update(id(k) for k in ds)
                cb.append(("Vừa", "Giá thành chung đổi nhiều so kỳ trước", "", "%d mã cùng %s khoảng %s so tháng trước, ví dụ %s" % (
                    len(ds), "tăng" if g > 0 else "giảm", pt(abs(g) / 20.0, 0), ", ".join(k["sh"] for k in ds[:3])),
                    "Các mã cùng nhóm nguyên liệu / cùng phiếu: xem giá nguyên liệu, chi phí chung, sản lượng của nhóm."))
                for k in ds:
                    k["nx"] = "Đổi %s%s cùng nhóm %d mã" % ("+" if k["ch"] > 0 else "-", pt(abs(k["ch"]), 0), len(ds))
        tong_gt = sum(x["gt"] for x in dong) or 1.0
        le = [k for k in ky if k["ch"] is not None and abs(k["ch"] - ch_tv) > NGUONG_DOI and id(k) not in bo]
        le.sort(key=lambda k: -abs(k["ch"]) * self.sx[(k["ma"], t)][4] / tong_gt)
        for k in le[:30]:
            km = max((("NVL", k["d_nvl"]), ("nhân công", k["d_nc"]), ("chi phí chung", k["d_sxc"])), key=lambda z: abs(z[1]))
            k["nx"] = "%s %s, chủ yếu do %s" % ("Tăng" if k["ch"] > 0 else "Giảm", pt(abs(k["ch"]), 0), km[0])
            cb.append(("Vừa", "Giá thành đổi nhiều so kỳ trước", k["sh"], "%s: %s so tháng %s (%s -> %s / %s), chủ yếu do %s" % (
                k["ten"][:50], ("tăng " if k["ch"] > 0 else "giảm ") + pt(abs(k["ch"]), 0), self.chu_thang(k["t2"]), tien(k["u2"]), tien(k["u"]),
                k["dvt"] or "ĐVT", km[0]),
                "Xem định mức, giá nguyên liệu, sản lượng tháng (chi phí chung chia trên sản lượng thấp làm giá thành tăng)."))
        # theo thang
        theo = defaultdict(dict)
        for (ma, th), x in self.sx.items():
            if th <= t and x[0] > 0:
                theo[ma][th] = x[4] / x[0]
        if self.bien_tv is not None and self.bien_tv < 1.5 * NGUONG_MONG:
            cb.append(("Thông tin", "Biên lãi gộp chung thấp", "", "Biên lãi gộp trung vị của các mã là %s: chỉ báo lãi mỏng khi dưới %s." % (
                pt(self.bien_tv), pt(self.bm)), "Biên chung thấp: xem giá bán, giá nguyên liệu chính."))
        self.dong, self.ky, self.theo = dong, ky, theo
        mt_cb.sort(key=lambda z: -z[5])
        cb += [z[:5] for z in mt_cb[:30]]
        cb.sort(key=lambda z: -MUC.get(z[0], 0))
        self.canh_bao = cb
        self.dem = {"sx": len(dong), "lo": sum(1 for z in cb if z[1] == "Giá thành cao hơn giá bán"), "mong": n_mong,
                    "gt0": sum(1 for z in cb if z[1] == "Giá thành = 0"), "doi": sum(1 for k in ky if k["nx"]) or sum(1 for z in cb if z[1] == "Giá thành chung đổi nhiều so kỳ trước"),
                    "mt": sum(1 for x in dong if x.get("mt")), "mt_lech": len(mt_cb)}
        return self


# ================================================================================================ ghi
def ghi_txt(B, ra_txt, tep):
    d = B.dem
    dong = ["TONG;GTBC;%s;%d;%d;%d;%d;%d;%s" % (B.chu_thang(B.t), d["sx"], d["lo"], d["mong"], d["gt0"], d["doi"], _sach(tep, 400))]
    if d.get("mt"):
        dong.append("MT;GTBC;%d;%d" % (d["mt"], d["mt_lech"]))          # GD163
    dong += ["C;%s;%s;%s" % (_sach(m), _sach(ma, 40), _sach(nd, 220)) for m, _, ma, nd, _ in B.canh_bao[:40]]
    os.makedirs(os.path.dirname(ra_txt), exist_ok=True)
    with io.open(ra_txt + ".tmp", "w", encoding="utf-8", newline="") as f:
        f.write("\r\n".join(dong) + "\r\n")
    os.replace(ra_txt + ".tmp", ra_txt)
    return ra_txt


def lap_excel(B, ra):
    from xlsx_viet import SoExcel
    wb = SoExcel(font="Times New Roman", co=11)
    k_td = wb.kieu(dam=True, co=14, can="giua", mau="0B3D91")
    k_ghi = wb.kieu(nghieng=True, mau="555555", xuong=True, doc="tren")
    k_dau = wb.kieu(dam=True, nen="D9E1F2", khung=True, can="giua", xuong=True)
    k_o = wb.kieu(khung=True, xuong=True, doc="tren")
    k_so = wb.kieu(khung=True, so="#,##0")
    k_sl = wb.kieu(khung=True, so="#,##0.##")
    k_pt = wb.kieu(khung=True, so="0.0%")
    k_do = wb.kieu(khung=True, so="#,##0", mau="C00000", dam=True)
    thang = B.chu_thang(B.t)
    nc = ("Nhân công: chi phí thực tế (1542 / 622) chia theo trọng số." if B.nc_thuc_te else
          "Nhân công: tính theo định mức nhân công (chưa bật giá thành theo đối tượng) - có thể khác chi phí thực tế 1542.")
    ws = wb.sheet("TongQuan", cot=[52, 16])
    ws.gop(1, 1, 1, 2, "KIỂM TRA GIÁ THÀNH THÁNG %s" % thang, k_td)
    ws.gop(2, 1, 2, 2, "Chỉ đọc sổ, không đổi cách tính. Giá thành theo phiếu kết chuyển thành phẩm đã ghi; giá bán theo hoá đơn (Có 511) của mã. " + nc, k_ghi)
    ws.cao(2, 46)
    r = 4
    for t_, v in (("Số mã có sản xuất trong tháng", B.dem["sx"]), ("Giá thành cao hơn giá bán", B.dem["lo"]), ("Lãi mỏng (dưới %s)" % pt(B.bm), B.dem["mong"]),
                  ("Giá thành = 0", B.dem["gt0"]), ("Giá thành / ĐVT đổi trên %s so kỳ trước" % pt(NGUONG_DOI, 0), B.dem["doi"]),
                  ("Tổng giá thành tháng", sum(x["gt"] for x in B.dong))) + ((
                  ("Mã có tỷ lệ mục tiêu (Định mức theo tỷ lệ giá bán)", B.dem["mt"]), ("Lệch tỷ lệ mục tiêu trên %s" % pt(NGUONG_MT, 0), B.dem["mt_lech"])) if B.dem.get("mt") else ()):
        ws.o(r, 1, t_, k_o)
        ws.o(r, 2, v, k_so)
        r += 1
    # gia thanh so gia ban
    w = wb.sheet("GiaThanh_GiaBan", cot=[12, 36, 8, 12, 14, 14, 9, 14, 9, 9, 9, 14, 40])
    w.gop(1, 1, 1, 13, "GIÁ THÀNH SO GIÁ BÁN - THÁNG %s" % thang, k_td)
    w.dong(3, 1, ["Mã", "Tên", "ĐVT", "Sản lượng", "Giá thành / ĐVT", "Giá bán / ĐVT", "GT / GB", "Lãi gộp / ĐVT", "NVL / GB", "NC / GB", "SXC / GB",
                  "Giá vốn xuất / ĐVT", "Nhận xét"], k_dau)
    r = 3
    for x in sorted(B.dong, key=lambda z: (-(z["ty"] or 0) if z["ty"] is not None else 1, z["sh"])):
        r += 1
        w.dong(r, 1, [x["sh"], x["ten"], x["dvt"]], k_o)
        w.o(r, 4, x["sl"], k_sl)
        w.o(r, 5, x["u"] if x["u"] is not None else "", k_so)
        w.o(r, 6, x["gb"] if x["gb"] else "", k_so)
        w.o(r, 7, x["ty"] if x["ty"] is not None else "", k_pt)
        w.o(r, 8, x["lg"] if x["lg"] is not None else "", k_do if (x["lg"] or 0) < 0 else k_so)
        for c, kk in ((9, "p_nvl"), (10, "p_nc"), (11, "p_sxc")):
            w.o(r, c, x.get(kk) if x.get(kk) is not None else "", k_pt)
        w.o(r, 12, x["gv_u"] if x["gv_u"] else "", k_so)
        w.o(r, 13, x["nx"], k_o)
    w.dong_bang(4, 3)
    # ky nay so ky truoc
    w2 = wb.sheet("KyNay_KyTruoc", cot=[12, 36, 8, 10, 14, 14, 9, 14, 14, 14, 36])
    w2.gop(1, 1, 1, 11, "GIÁ THÀNH / ĐVT THÁNG %s SO THÁNG TRƯỚC CÓ SẢN XUẤT" % thang, k_td)
    w2.dong(3, 1, ["Mã", "Tên", "ĐVT", "Tháng so", "GT / ĐVT kỳ trước", "GT / ĐVT kỳ này", "Chênh", "Chênh NVL / ĐVT", "Chênh NC / ĐVT", "Chênh SXC / ĐVT", "Nhận xét"], k_dau)
    r = 3
    for x in sorted(B.ky, key=lambda z: -abs(z["ch"] or 0)):
        r += 1
        w2.dong(r, 1, [x["sh"], x["ten"], x["dvt"], B.chu_thang(x["t2"])], k_o)
        w2.o(r, 5, x["u2"], k_so)
        w2.o(r, 6, x["u"], k_so)
        w2.o(r, 7, x["ch"] if x["ch"] is not None else "", k_pt)
        for c, kk in ((8, "d_nvl"), (9, "d_nc"), (10, "d_sxc")):
            w2.o(r, c, x[kk], k_so)
        w2.o(r, 11, x["nx"], k_o)
    if r == 3:
        w2.gop(4, 1, 4, 11, "Chưa có tháng trước để so.", k_ghi)
    w2.dong_bang(4, 3)
    # theo thang
    ds_t = list(range(1, B.t + 1))
    w3 = wb.sheet("TheoThang", cot=[12, 36] + [12] * len(ds_t))
    w3.gop(1, 1, 1, 2 + len(ds_t), "GIÁ THÀNH / ĐVT THEO THÁNG", k_td)
    w3.dong(3, 1, ["Mã", "Tên"] + [B.chu_thang(t) for t in ds_t], k_dau)
    r = 3
    for ma in sorted(B.theo, key=lambda m: B.ten(m)[0]):
        r += 1
        sh, ten, _ = B.ten(ma)
        w3.dong(r, 1, [sh, ten], k_o)
        for j, t in enumerate(ds_t):
            v = B.theo[ma].get(t)
            w3.o(r, 3 + j, v if v is not None else "", k_so)
    w3.dong_bang(4, 3)
    # GD163: thuc te so ty le muc tieu
    w5 = wb.sheet("MucTieu", cot=[12, 34, 8, 9, 12, 12, 9, 9, 9, 9, 9, 9, 9, 9, 9, 40])
    w5.gop(1, 1, 1, 16, "GIÁ VỐN THỰC TẾ SO TỶ LỆ MỤC TIÊU - THÁNG %s" % thang, k_td)
    w5.gop(2, 1, 2, 16, "Tỷ lệ mục tiêu khai ở Giá thành - Định mức theo tỷ lệ giá bán (cấp mã thay cấp lô, lô thay sổ). Giá thành ghi sổ là chi phí thực tế; "
           "tỷ lệ chỉ để lập định mức, chia chi phí và kiểm tra. Lệch trên %s (tương đối) thì cần xem." % pt(NGUONG_MT, 0), k_ghi)
    w5.cao(2, 34)
    w5.dong(4, 1, ["Mã", "Tên", "ĐVT", "Phạm vi", "Giá bán / ĐVT", "Giá thành / ĐVT", "GT / GB thực tế", "Mục tiêu", "Chênh", "NVL thực tế",
                   "NVL mục tiêu", "NC thực tế", "NC mục tiêu", "SXC thực tế", "SXC mục tiêu", "Nhận xét"], k_dau)
    r = 4
    for x in sorted((z for z in B.dong if z.get("mt")), key=lambda z: (-abs(z["mt"].get("lech") or 0), z["sh"])):
        m = x["mt"]
        r += 1
        w5.dong(r, 1, [x["sh"], x["ten"], x["dvt"], m["pv"]], k_o)
        w5.o(r, 5, m.get("gb") or "", k_so)
        w5.o(r, 6, x["u"] if x["u"] is not None else "", k_so)
        w5.o(r, 7, m["tt"] if m.get("tt") is not None else "", k_pt)
        w5.o(r, 8, m["gv"], k_pt)
        w5.o(r, 9, (m["tt"] - m["gv"]) if m.get("tt") is not None else "", k_pt)
        for c, a, b2 in ((10, "a_nvl", "nvl"), (12, "a_nc", "nc"), (14, "a_sxc", "sxc")):
            w5.o(r, c, m[a] if m.get(a) is not None else "", k_pt)
            w5.o(r, c + 1, m[b2], k_pt)
        w5.o(r, 16, m.get("nx", ""), k_o)
    if r == 4:
        w5.gop(5, 1, 5, 16, "Chưa khai tỷ lệ mục tiêu (Giá thành - Định mức theo tỷ lệ giá bán) hoặc tháng này không có mã có tỷ lệ.", k_ghi)
    w5.dong_bang(5, 3)
    # canh bao
    w4 = wb.sheet("CanhBao", cot=[8, 30, 14, 70, 60])
    w4.gop(1, 1, 1, 5, "CẦN XEM", k_td)
    w4.dong(3, 1, ["Mức", "Loại", "Mã", "Nội dung", "Gợi ý"], k_dau)
    r = 3
    for m, l, ma, nd, gy in B.canh_bao:
        r += 1
        w4.dong(r, 1, [m, l, ma, nd, gy], k_o)
    if r == 3:
        w4.gop(4, 1, 4, 5, "Không có cảnh báo.", k_ghi)
    w4.dong_bang(4, 3)
    os.makedirs(os.path.dirname(os.path.abspath(ra)), exist_ok=True)
    wb.luu(ra)
    return ra


def viet_html(B, ra):
    e = html.escape
    h = ["<!doctype html><html lang='vi'><head><meta charset='utf-8'><title>Kiểm tra giá thành %s</title><style>body{font-family:Segoe UI,Arial,sans-serif;"
         "margin:16px;color:#1f2937}h1{font-size:19px;color:#0b3d91}.g{color:#555;font-style:italic}td,th{padding:3px 8px;font-size:13px;"
         "border-bottom:1px solid #e5e7eb;text-align:left}th{background:#eef2ff}.s{text-align:right}.do{color:#b91c1c;font-weight:600}"
         "table{border-collapse:collapse}</style></head><body>" % e(B.chu_thang(B.t)),
         "<h1>Kiểm tra giá thành tháng %s</h1><p class='g'>Chỉ đọc sổ. %d mã có sản xuất; %d mã giá thành cao hơn giá bán; %d lãi mỏng; %d giá thành = 0; "
         "%d đổi nhiều so kỳ trước.%s</p>" % (e(B.chu_thang(B.t)), B.dem["sx"], B.dem["lo"], B.dem["mong"], B.dem["gt0"], B.dem["doi"],
                                              (" %d mã có tỷ lệ mục tiêu, %d lệch trên %s." % (B.dem["mt"], B.dem["mt_lech"], pt(NGUONG_MT, 0))) if B.dem.get("mt") else ""),
         "<table><tr><th>Mã</th><th>Tên</th><th class='s'>Giá thành / ĐVT</th><th class='s'>Giá bán / ĐVT</th><th class='s'>GT / GB</th><th>Nhận xét</th></tr>"]
    for x in sorted(B.dong, key=lambda z: -(z["ty"] or 0)):
        h.append("<tr><td>%s</td><td>%s</td><td class='s'>%s</td><td class='s'>%s</td><td class='s%s'>%s</td><td>%s</td></tr>" % (
            e(x["sh"]), e(x["ten"][:60]), tien(x["u"]) if x["u"] is not None else "", tien(x["gb"]) if x["gb"] else "",
            " do" if (x["ty"] or 0) > 1 else "", pt(x["ty"]) if x["ty"] is not None else "", e(x["nx"])))
    h.append("</table><h2 style='font-size:16px'>Cần xem</h2><table>")
    for m, l, ma, nd, gy in B.canh_bao[:80]:
        h.append("<tr><td>%s</td><td>%s</td><td>%s</td><td class='g'>%s</td></tr>" % (e(m), e(l), e(nd), e(gy)))
    if not B.canh_bao:
        h.append("<tr><td class='g'>Không có cảnh báo.</td></tr>")
    h.append("</table></body></html>")
    with io.open(ra, "w", encoding="utf-8") as f:
        f.write("\n".join(h))
    return ra


def chay(duong_json, ra):
    with io.open(duong_json, "r", encoding="utf-8-sig") as f:
        dl = json.loads(f.read(), strict=False)
    B = BaoCao(dl).tinh()
    if not ra:
        ra = os.path.join(GOC, "ket-qua", "KiemTra_GiaThanh.xlsx")
    lap_excel(B, ra)
    viet_html(B, os.path.splitext(ra)[0] + ".html")
    ghi_txt(B, os.path.join(GOC, "ket-qua", TEP_KQ), ra)
    return ra, ""


if __name__ == "__main__":
    import sys
    if len(sys.argv) >= 2:
        print(chay(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else ""))
