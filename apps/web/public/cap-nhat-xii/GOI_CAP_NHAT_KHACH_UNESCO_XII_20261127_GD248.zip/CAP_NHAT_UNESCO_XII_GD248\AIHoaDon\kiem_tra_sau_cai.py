# -*- coding: utf-8 -*-
"""KIEM TRA SAU KHI CAI GOI CAP NHAT (GD14 -> GD22) - BAN SAU, CAN PYTHON.

Ban thuong dung la KIEM_TRA_SAU_CAI.bat (chay KIEM_TRA_SAU_CAI.vbs, khong can
Python, doi chieu KICH THUOC file). Ban nay lam dung viec do nhung doi chieu ca
SHA256 tung file - chi chay duoc khi may da cai Python.

Chay sau khi da chay FIX_TU_DONG.bat, TRUOC khi mo VB6. Kiem 5 viec:

  A. Goi cap nhat con nguyen ven      (giai nen thieu / antivirus xoa bot file)
  B. File da chep dung vao thu muc du an  (chep hut giua chung)
  C. Sas.vbp da dang ky du form/module/class moi  (thieu -> Full Compile bao
     "Sub or Function not defined")
  D. SAS.bas trong du an con moc kiem tra cap nhat cua GD22
  E. Khong con file .log nap form cu (dau hieu VB6 bo bot control khi nap form)

Chay:
    python kiem_tra_sau_cai.py --goi "<thu muc goi>" --du-an "<thu muc Sas.vbp>"
Khong truyen tham so thi lay thu muc cha cua script lam goi, va hoi duong dan du an.

Ma tra ve: 0 = dat, 1 = co loi phai xu ly.
"""
import os
import sys
import csv
import re
import glob
import hashlib
import argparse

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

LOI = []
CANH_BAO = []


def bam(duong):
    h = hashlib.sha256()
    with open(duong, "rb") as f:
        for k in iter(lambda: f.read(1 << 20), b""):
            h.update(k)
    return h.hexdigest()


def tieu_de(s):
    print("")
    print(s)
    print("-" * len(s))


def dich_trong_du_an(rel):
    """Duong dan tuong ung trong thu muc du an, hoac None neu FIX_TU_DONG.bat
       khong chep file nay (tai lieu, .bat, .vbs, nhat ky... chi nam trong goi)."""
    rel = rel.replace("\\", "/")
    phan = rel.split("/")
    if len(phan) == 1:
        return rel if os.path.splitext(rel)[1].lower() in (".frm", ".bas", ".cls") else None
    if len(phan) == 2 and phan[0] == "Misu" and phan[1].lower().endswith(".frm"):
        return rel
    if len(phan) == 2 and phan[0] == "AIHoaDon" and phan[1].lower().endswith(".py"):
        return rel
    if rel.startswith("AIHoaDon/tham_khao/sophu/"):
        return rel
    if rel.startswith("AIHoaDon/tham_khao/excel_4_mau/"):
        return rel
    return None


def kiem_0(goi, du_an):
    """Chan truong hop keo nham thu muc - kiem TRUOC moi thu khac."""
    tieu_de("0. Dung thu muc chua")
    if os.path.normcase(os.path.abspath(goi)) == os.path.normcase(os.path.abspath(du_an)):
        print("   [SAI] Thu muc goi va thu muc du an dang la MOT.")
        LOI.append("Dang keo chinh THU MUC GOI CAP NHAT chu khong phai thu muc du an. "
                   "Thu muc du an la noi anh van mo Sas.vbp bang VB6, co hang tram file .frm. "
                   "Keo dung thu muc do roi chay lai.")
        return False
    n = len(glob.glob(os.path.join(du_an, "*.frm")))
    if n < 30:
        print("   [SAI] Thu muc du an chi co %d file .frm." % n)
        LOI.append("\"%s\" co Sas.vbp nhung chi co %d file .frm - thu muc du an UNESCO XI "
                   "that phai co hang tram file. Day gan nhu chac chan khong phai thu muc du an."
                   % (du_an, n))
        return False
    print("   OK - thu muc du an co %d file .frm, khac thu muc goi." % n)
    return True


def doc_manifest(goi):
    duong = os.path.join(goi, "manifest", "SHA256SUMS.csv")
    if not os.path.isfile(duong):
        LOI.append("Khong thay manifest\\SHA256SUMS.csv - goi giai nen thieu hoac sai thu muc.")
        return []
    with open(duong, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def kiem_A(goi, hang):
    tieu_de("A. Goi cap nhat con nguyen ven")
    thieu = lech = 0
    for h in hang:
        rel = h["duong_dan"]
        p = os.path.join(goi, rel.replace("/", os.sep))
        if not os.path.isfile(p):
            print("   [THIEU] " + rel)
            thieu += 1
            continue
        if os.path.getsize(p) != int(h["so_byte"]) or bam(p) != h["sha256"]:
            print("   [SAI ND] " + rel)
            lech += 1
    if thieu or lech:
        LOI.append("Goi cap nhat khong nguyen ven: thieu %d, sai noi dung %d file. "
                   "Giai nen lai file .zip (tat antivirus quet thu muc do neu can) "
                   "roi chay lai FIX_TU_DONG.bat." % (thieu, lech))
    else:
        print("   OK - du %d file, dung sha256." % len(hang))


def kiem_B(goi, du_an, hang):
    tieu_de("B. File da chep vao thu muc du an")
    can, thieu, lech = 0, 0, 0
    for h in hang:
        rel = dich_trong_du_an(h["duong_dan"])
        if rel is None:
            continue
        can += 1
        p = os.path.join(du_an, rel.replace("/", os.sep))
        if not os.path.isfile(p):
            print("   [CHUA CHEP] " + rel)
            thieu += 1
            continue
        if bam(p) != h["sha256"]:
            print("   [KHAC BAN GOI] " + rel)
            lech += 1
    if thieu or lech:
        LOI.append("Chep chua xong: %d file chua co, %d file khac ban trong goi. "
                   "Dong VB6 roi chay lai FIX_TU_DONG.bat." % (thieu, lech))
    else:
        print("   OK - %d/%d file dung ban moi nhat." % (can, can))


def _mang_vbs(txt, ten):
    m = re.search(ten + r"\s*=\s*Array\((.*?)\)", txt, re.S)
    return re.findall(r'"([^"]+)"', m.group(1)) if m else []


def _muc_vbp(vbp_txt):
    """Tra ve 3 tap hop ten (chu thuong) da co trong Sas.vbp: form, module, class.
       Chap nhan ca dang 'Module=Ten; duong\\dan.bas' lan duong dan tuong doi."""
    form, mod, cls = set(), set(), set()
    for d in vbp_txt.splitlines():
        d = d.strip()
        k = d.lower()
        if k.startswith("form="):
            form.add(os.path.basename(d[5:].strip().replace("\\", "/")).lower())
        elif k.startswith("module=") or k.startswith("class="):
            than = d.split("=", 1)[1]
            ten, _, duong = than.partition(";")
            tap = mod if k.startswith("module=") else cls
            tap.add(ten.strip().lower())
            if duong.strip():
                tap.add(os.path.splitext(os.path.basename(
                    duong.strip().replace("\\", "/")))[0].lower())
    return form, mod, cls


def kiem_C(goi, du_an):
    tieu_de("C. Sas.vbp da dang ky form/module/class moi")
    vbs = os.path.join(goi, "dang_ky_vbp.vbs")
    vbp = os.path.join(du_an, "Sas.vbp")
    if not os.path.isfile(vbs) or not os.path.isfile(vbp):
        LOI.append("Khong doc duoc dang_ky_vbp.vbs hoac Sas.vbp de doi chieu.")
        return
    t = open(vbs, encoding="utf-8", errors="replace").read()
    co_form, co_mod, co_cls = _muc_vbp(open(vbp, encoding="latin-1", errors="replace").read())
    thieu = []
    for f in _mang_vbs(t, "needForms"):
        if f.lower() not in co_form:
            thieu.append("Form  " + f)
    for m in _mang_vbs(t, "needMods"):
        if os.path.splitext(m)[0].lower() not in co_mod:
            thieu.append("Module " + m + ".bas")
    for c in _mang_vbs(t, "needClasses"):
        if os.path.splitext(c)[0].lower() not in co_cls:
            thieu.append("Class " + os.path.splitext(c)[0] + ".cls")
    if thieu:
        for x in thieu:
            print("   [CHUA DANG KY] " + x)
        LOI.append("Sas.vbp thieu %d muc. Chay lai FIX_TU_DONG.bat (buoc 4/4), "
                   "hoac trong VB6 bam Project > Add File de them tay." % len(thieu))
    else:
        print("   OK - da co du form/module/class moi trong Sas.vbp.")


def kiem_D(du_an):
    tieu_de("D. Moc kiem tra cap nhat (GD22) trong SAS.bas")
    p = os.path.join(du_an, "SAS.bas")
    if not os.path.isfile(p):
        LOI.append("Khong thay SAS.bas trong thu muc du an.")
        return
    t = open(p, encoding="latin-1", errors="replace").read()
    if "HDDT_CN_KiemTraKhiMo" in t:
        print("   OK - Sub Main co goi HDDT_CN_KiemTraKhiMo.")
    else:
        LOI.append("SAS.bas khong con moc HDDT_CN_KiemTraKhiMo - co the da bi khoi phuc "
                   "nham tu ban sao luu cu. Chep lai SAS.bas tu goi.")


def kiem_E(du_an):
    tieu_de("E. File .log nap form cu")
    ds = [os.path.basename(x) for x in glob.glob(os.path.join(du_an, "*.log"))]
    if ds:
        for x in ds:
            print("   [CON LAI] " + x)
        CANH_BAO.append("Con %d file .log cu (%s). File .log sinh ra khi VB6 nap form va bo bot "
                        "control. Xoa het roi mo lai Sas.vbp; neu mo xong lai sinh .log thi "
                        "gui file do de xem thieu control nao." % (len(ds), ", ".join(ds[:3])))
    else:
        print("   OK - khong co file .log.")


def main():
    ap = argparse.ArgumentParser(add_help=True)
    ap.add_argument("--goi", default="")
    ap.add_argument("--du-an", dest="du_an", default="")
    a = ap.parse_args()

    goi = a.goi or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    du_an = a.du_an
    if not du_an:
        try:
            du_an = input("Duong dan thu muc chua Sas.vbp: ").strip().strip('"')
        except Exception:
            du_an = ""
    goi = os.path.abspath(goi)
    du_an = os.path.abspath(du_an) if du_an else ""

    print("KIEM TRA SAU KHI CAI - goi cap nhat GD14 -> GD22")
    print("Thu muc goi   : " + goi)
    print("Thu muc du an : " + (du_an or "(chua nhap)"))

    if du_an and os.path.normcase(os.path.abspath(goi)) == os.path.normcase(os.path.abspath(du_an)):
        print("")
        print("[LOI] Thu muc goi va thu muc du an dang la MOT.")
        print("      Dang keo chinh THU MUC GOI CAP NHAT chu khong phai thu muc du an.")
        print("      Thu muc du an la noi van mo Sas.vbp bang VB6, co hang tram file .frm.")
        print("      Keo dung thu muc do roi chay lai.")
        return 1

    if not du_an or not os.path.isfile(os.path.join(du_an, "Sas.vbp")):
        print("")
        print("[LOI] Khong thay Sas.vbp trong thu muc du an. Kiem tra lai duong dan.")
        return 1

    if not kiem_0(goi, du_an):
        print("")
        print("=" * 60)
        print("CHUA DAT - dung thu muc truoc da:")
        for i, x in enumerate(LOI, 1):
            print("  %d. %s" % (i, x))
        print("=" * 60)
        return 1

    hang = doc_manifest(goi)
    if hang:
        kiem_A(goi, hang)
        kiem_B(goi, du_an, hang)
    kiem_C(goi, du_an)
    kiem_D(du_an)
    kiem_E(du_an)

    print("")
    print("=" * 60)
    if LOI:
        print("CHUA DAT - %d viec phai xu ly truoc khi mo VB6:" % len(LOI))
        for i, x in enumerate(LOI, 1):
            print("  %d. %s" % (i, x))
    else:
        print("DAT - cai dat day du. Mo Sas.vbp > Run > Full Compile (phai 0 loi) > Save.")
    for x in CANH_BAO:
        print("  [Luu y] " + x)
    print("=" * 60)
    return 1 if LOI else 0


if __name__ == "__main__":
    sys.exit(main())
