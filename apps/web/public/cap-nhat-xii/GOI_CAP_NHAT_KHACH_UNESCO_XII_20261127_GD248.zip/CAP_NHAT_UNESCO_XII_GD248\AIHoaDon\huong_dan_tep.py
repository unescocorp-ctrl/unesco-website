# -*- coding: utf-8 -*-
"""GD259 - 00_DOC_TOI.txt trong thu muc cua tung bo so (AIHoaDon\\ket-qua\\chinh-sach\\<so>_<ma>\\): giai thich tung tep ke toan
   tu ghi va tep may ghi, kem dong mau. Ghi lai moi lan Kiem tra truoc khoa so (noi dung co dinh, khong mat gi)."""
import io
import os

NOI_DUNG = u"""THU MUC CUA BO SO - cac tep ke toan tu ghi (mo bang Notepad, luu UTF-8) va tep may ghi.
Moi tep: dong bat dau bang # la chu thich / dong mau. Lan Kiem tra truoc khoa so sau se ap dung.

=== TEP KE TOAN GHI ===
tra_loi.txt           Tra loi hang doi viec. Moi dong: MA;KHOA;HANH_DONG;ghi chu
                      HANH_DONG: BO_QUA (khong phai loi) | DA_LAM (da lam ngoai phan mem) | HEN (hen ky sau)
                                 | CHAP_NHAN (K51: chap nhan chinh sach moi) | LOAI_HINH (K52: ghi chu = XAY_DUNG, DICH_VU...)
                      KHOA: * = ca ma, hoac gia tri cot dau cua dong chi tiet (bo rieng dong do)
                      Vi du:  K42;VCB_123;DA_LAM;da lap phieu tay    K10;*;HEN;doi doi chieu quy sau
giai_trinh_<nam>_<ky>.txt   Ly do bien dong tai khoan (K44). Moi dong: TK;MA LY DO;ghi chu
                      Ma: MUA_VU TANG_QUY_MO GIA HD_LON TS_MOI VAY_TRA PHAN_LOAI SAI_DA_SUA CHUA_XU_LY KHAC
loai_hinh.txt         Loai hinh doanh nghiep khai co dinh (K52). Mot dong: THUONG_MAI, SAN_XUAT, DICH_VU, XAY_DUNG, XNK
but_toan_dinh_ky.txt  Khoan dinh ky (K57): 3387;<hop dong>;<tong>;<so ky>;<mm/yyyy>;<TK DT>
                      TRICH_TRUOC;<noi dung>;<tien/thang>;<TK No>;<TK Co>   DU_PHONG;<noi dung>;<so du can>;<TK No>;<TK Co>
cong_trinh.txt        Danh muc cong trinh (K59): <TK 154 chi tiet>;<ten>;<du toan>;<gia tri hop dong>;<% hoan thanh>;<TK DT>

=== TEP MAY GHI (chi doc) ===
chinh_sach.html                 Toan bo chinh sach hach toan dang ap dung + dong can sua (K50)
chinh_sach_<nam>_<ky>.json      Anh chup chinh sach lan kiem dau cua ky (K51). Xoa = chap nhan chinh sach moi
hang_doi_viec.html / .txt       Hang doi viec cua so nay (ban sao); tom_tat.txt: so viec / so loi cho Bang dieu hanh
muc_tu_dong.txt                 Muc tu dong 60 ngay + nguong de xuat (K55)
b03_tu_chung_tu_<nam>_<ky>.json B03 truc tiep tinh tu chung tu (K58) - bao_cao_nam so khi xuat BCTC

=== KIEM KE ===
python AIHoaDon\\kiem_ke.py lap <so.mdb> <thang>     -> phieu kiem ke in san so so (cot SO DEM de trong)
python AIHoaDon\\kiem_ke.py doc <phieu da dien>      -> chenh lech + but toan 1381 / 3381 de xuat

=== BO SO CHUAN (hoi quy, thu muc AIHoaDon\\hoi-quy) ===
python AIHoaDon\\hoi_quy.py chot      chot so da xac nhan dung      python AIHoaDon\\hoi_quy.py chay      so lai sau moi goi
"""


def ghi(dl):
    duong = (dl or {}).get("duong_so") or ""
    if not duong:
        return ""
    import chinh_sach_so
    tm, _ = chinh_sach_so._thu_muc_ra(duong)
    p = os.path.join(tm, "00_DOC_TOI.txt")
    with io.open(p, "w", encoding="utf-8") as f:
        f.write(NOI_DUNG)
    return p
