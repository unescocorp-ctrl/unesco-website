# -*- coding: utf-8 -*-
"""GD76 - BANG KE HOA DON MUA VAO / BAN RA THEO SO KE TOAN (chi DOC so, khong ghi so).

VB6 (ModHDDTHTKK: HDDT_BK_Excel) lay bang ke thue trong so: HoaDon (Loai 1 ban ra / -1 mua vao) + dong ChungTu cung MaSo
(thue = dong TK GTGT khau tru 133 / phai nop 3331) + KhachHang, ngay phat hanh trong ky; ghi JSON UTF-8, goi
tool_htkk_unesco.py /bangkehd:<json> /loai:<MV|BR> /ra:<xlsx>. Cung nguon voi to khai 01/GTGT cua phan mem
(chi hoa don khong phai dieu chinh hoac hoa don co dau HD = 1)."""
import json
import os
import re
from collections import OrderedDict

import doi_chieu_hd as D

TEN = {"MV": ("BẢNG KÊ HOÁ ĐƠN, CHỨNG TỪ HÀNG HOÁ, DỊCH VỤ MUA VÀO", -1, "Người bán"),
       "BR": ("BẢNG KÊ HOÁ ĐƠN, CHỨNG TỪ HÀNG HOÁ, DỊCH VỤ BÁN RA", 1, "Người mua")}


def _nhom(dl, loai):
    """Gop dong bang ke theo (so HD, MST doi tac) - mot hoa don co the nhieu dong chung tu."""
    ky = dl.get("ky") or {}
    tu, den = D.ngay_iso(ky.get("tu")), D.ngay_iso(ky.get("den"))
    g = OrderedDict()
    for r in dl.get("hd") or []:
        r = list(r) + [None] * (19 - len(r))
        if int(D._so(r[1])) != loai:
            continue
        if not (int(D._so(r[8])) == 0 or int(D._so(r[9])) == 1):      # hoa don dieu chinh chua danh dau HD: khong ke khai
            continue
        nd = D.ngay_iso(r[4])
        if not nd or (tu and nd < tu) or (den and nd > den):
            continue
        k = (D.so_hd(r[3]), D.mst10(r[15]), D.ky_hieu(r[2]))
        e = g.get(k)
        if e is None:
            e = g[k] = {"kh": str(r[2] or "").strip(), "so": str(r[3] or "").strip(), "ngay": nd, "ngay_vn": str(r[4] or ""),
                        "mst": str(r[15] or "").strip(), "ten": str(r[17] or "").strip(), "ma_kh": str(r[16] or "").strip(),
                        "tien": 0.0, "thue": 0.0, "ts": set(), "kct": False, "ct": OrderedDict(), "ma_hd": set()}
        # ThanhTien la cua dong HoaDon: moi MaSo HoaDon chi cong mot lan (join nhieu dong ChungTu)
        ma_hd = int(D._so(r[0]))
        if ma_hd not in e["ma_hd"]:
            e["ma_hd"].add(ma_hd)
            e["tien"] += D._so(r[5])
            if int(D._so(r[7])) == 1:
                e["kct"] = True
            else:
                e["ts"].add(D._so(r[6]))
        e["thue"] += D._so(r[18])
        sh = str(r[13] or "").strip()
        if sh:
            e["ct"][sh + " " + str(r[14] or "")] = 1
    ds = list(g.values())
    ds.sort(key=lambda e: (e["ngay"], e["so"].zfill(12)))
    return ds, tu, den


def _ten_ts(e):
    if e["kct"] and not e["ts"]:
        return "KCT"
    return ", ".join(("%g%%" % t) for t in sorted(e["ts"])) or "0%"


def lap_excel(dl, loai, ra):
    H = D._xl()
    X = H
    tieu, ma_loai, ten_dt = TEN[loai]
    ds, tu, den = _nhom(dl, ma_loai)
    cty = dl.get("cty") or {}
    ky = dl.get("ky") or {}
    T = [[(tieu, X.X_TITLE)],
         [("Đơn vị: %s    MST: %s    Kỳ: %s - %s (theo ngày phát hành hoá đơn trong sổ)" % (
             cty.get("ten") or "", cty.get("mst") or "", ky.get("tu") or "", ky.get("den") or ""), X.X_THUONG)],
         [("Nguồn: bảng kê thuế trong sổ kế toán (hoá đơn + chứng từ thuế GTGT), cùng nguồn với tờ khai 01/GTGT của phần mềm. "
           "Chỉ đọc sổ.", X.X_GHICHU)], [],
         [(c, X.X_TIEUDE) for c in ("STT", "Ký hiệu", "Số hoá đơn", "Ngày", "Tên " + ten_dt.lower(), "MST " + ten_dt.lower(),
                                    "Giá trị chưa thuế", "Thuế suất", "Thuế GTGT", "Chứng từ trong sổ")]]
    tong = OrderedDict()
    for i, e in enumerate(ds, 1):
        T.append([(i, X.X_SO), (e["kh"], X.X_CHU), (e["so"], X.X_CHU), (e["ngay_vn"], X.X_CHU), ((e["ten"] or e["ma_kh"]), X.X_CHU),
                  (e["mst"], X.X_CHU), (e["tien"], X.X_SO), (_ten_ts(e), X.X_CHU), (e["thue"], X.X_SO), ("; ".join(e["ct"]), X.X_CHU)])
        k = _ten_ts(e)
        a = tong.setdefault(k, [0, 0.0, 0.0])
        a[0] += 1
        a[1] += e["tien"]
        a[2] += e["thue"]
    if ds:
        T.append([("", X.X_MUC), ("Cộng", X.X_MUC)] + [("", X.X_MUC)] * 4 + [(sum(e["tien"] for e in ds), X.X_SOMUC), ("", X.X_MUC),
                                                                          (sum(e["thue"] for e in ds), X.X_SOMUC)])
        T.append([])
        T.append([("Tổng hợp theo thuế suất", X.X_DAM)])
        T.append([(c, X.X_TIEUDE) for c in ("Thuế suất", "Số hoá đơn", "Giá trị chưa thuế", "Thuế GTGT")])
        for k, (n, t, th) in tong.items():
            T.append([(k, X.X_CHU), (n, X.X_SO), (t, X.X_SO), (th, X.X_SO)])
    else:
        T.append([("(không có hoá đơn trong kỳ)", X.X_CHU)])
    sheets = [("Bang ke " + ("mua vao" if loai == "MV" else "ban ra"), [6, 12, 12, 12, 44, 15, 18, 10, 16, 30], T, 5)]
    os.makedirs(os.path.dirname(os.path.abspath(ra)), exist_ok=True)
    H.viet_xlsx_o(ra, sheets)
    return ra, {"so_hd": len(ds), "tien": sum(e["tien"] for e in ds), "thue": sum(e["thue"] for e in ds)}


def chay(loai, duong_json, ra):
    """-> (duong xlsx, loi)."""
    loai = (loai or "MV").upper()
    if loai not in TEN:
        return None, "Loai bang ke khong hop le: %s" % loai
    with open(duong_json, "r", encoding="utf-8-sig") as f:
        dl = json.loads(f.read(), strict=False)
    d, _ = lap_excel(dl, loai, ra)
    return d, ""


if __name__ == "__main__":
    import sys
    if len(sys.argv) >= 3:
        print(chay(sys.argv[1], sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else re.sub(r"\.json$", ".xlsx", sys.argv[2])))
