# -*- coding: utf-8 -*-
"""GD350 - PHUONG AN GIA THANH THANG (xem truoc, chi doc .MDB qua jet_doc, khong ghi gi).

Tap hop cho MOT thang san xuat cua bo so:
  1. NVL theo dinh muc: nhu cau = san luong x dinh muc hieu luc (DinhMuc.ThangHL <= thang) so voi xuat thuc te (dong tu dong
     CT_ID >= 610000000 cua phieu ket chuyen + xuat tay 152 -> 154x). Du / thieu tung NVL, hao hut %, bi cat theo ton (GD316),
     ton cuoi thang, nhu cau thang toi (binh quan san luong 3 thang gan nhat x dinh muc) -> can mua them / ton du / ton am.
  2. Chi phi nhan cong, san xuat chung, luong: phat sinh No TK NC / SXC cua phieu (ThanhPham.MaTKNC / MaTKSX) trong thang so
     voi so da phan bo vao phieu (CPNC / CPSXC) -> chua phan bo; luong vao san xuat (Co 334 -> TK NC) so voi bang luong thang.
  3. Lai lo tung thanh pham: gia thanh / DVT (phieu) so gia ban binh quan (Co 511 theo ma vat tu, thang nay hoac gan nhat), gia
     von xuat ban (No 632); SP lo, lai mong; tong doanh thu / gia von / lai gop thang; theo doi tuong 154 (lo / cong trinh).
  4. Ket chuyen - viec can lam truoc khi khoa thang: thang co NVL xuat / chi phi ma chua co phieu; chi phi chua phan bo; 154 du
     cuoi thang khong co do dang (ThanhPhamDD); NVL am; dien ton; -> danh sach hanh dong + but toan de xuat (chi hien, nguoi bam).
Ra: ket-qua\\gia_thanh_phuong_an.txt (';' cho VB6, dong dau TONG), .html (xem truoc) va ban sao theo bo so (chinh_sach_so).
K60 trong Kiem tra truoc khoa so (k_phuong_an): CANH_BAO khi co SP lo / NVL thieu / chi phi chua phan bo / NVL am; THONG_TIN khi on.
Nguong: ThamSoGiaThanh.NguongLechNVL (% lech NVL, mac dinh 5), HaoHutMacDinh; NGUONG_MONG 10 % (nhu GD161)."""
import datetime as _dt
import html
import io
import os
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
TEP = "gia_thanh_phuong_an"
NGUONG_MONG = 0.10
NGUONG_LECH_NVL = 5.0
SO_THANG_DU_BAO = 3
AUTO_CT = 610000000


def _f(x):
    try:
        return float(x or 0)
    except (TypeError, ValueError):
        return 0.0


def _i(x):
    try:
        return int(_f(x))
    except (TypeError, ValueError):
        return 0


def _s(x):
    return str(x if x is not None else "").replace(";", ",").replace("\r", " ").replace("\n", " ").strip()


def _dd(v):
    try:
        return "{:,.0f}".format(float(v)).replace(",", ".")
    except (TypeError, ValueError):
        return ""


def _sl(v):
    v = _f(v)
    return ("{:,.2f}".format(v).rstrip("0").rstrip(".") if abs(v - round(v)) > 1e-9 else "{:,.0f}".format(v)).replace(",", ".")


# ------------------------------------------------------------------ doc so
def doc(duong):
    import jet_doc
    m = jet_doc.Mdb(duong)
    try:
        bang = {b.lower(): b for b in m.bang()}

        def tb(t, n=None):
            k = bang.get(t.lower())
            return m.doc(k, n) if k else []
        lic = (tb("License", 1) or [{}])[0]
        d = {"lic": lic, "nam": _i(lic.get("NamTC")) or _dt.date.today().year, "dau_ky": _i(lic.get("Thang")) or 1,
             "tk": {r["MaSo"]: str(r.get("SoHieu") or "").strip() for r in tb("HeThongTK")},
             "vt": {r["MaSo"]: r for r in tb("Vattu")},
             "tp": tb("ThanhPham"), "dd": tb("ThanhPhamDD"), "dm": tb("DinhMuc"), "ton": tb("TonKho"), "bl": tb("BangLuong"),
             "pl154": {r["MaSo"]: str(r.get("TenPhanLoai") or r.get("SoHieu") or "") for r in tb("PhanLoai154")},
             "tsgt": (tb("ThamSoGiaThanh", 1) or [{}])[0], "ct": tb("ChungTu")}
        if not 1 <= d["dau_ky"] <= 12:
            d["dau_ky"] = 1
        return d
    finally:
        try:
            m.dong()
        except Exception:
            pass


def thang_lich(d, t):
    """thu tu thang trong nam TC (1..12) -> (thang duong lich, nam)."""
    th = (d["dau_ky"] + t - 2) % 12 + 1
    nam = d["nam"] + (1 if th < d["dau_ky"] else 0)
    return th, nam


def thang_moi_nhat(d):
    """thang (thu tu TC) co phieu ket chuyen gan nhat; khong co -> thang co chung tu 154 gan nhat; khong -> 0."""
    th = [_i(p.get("Thang")) for p in d["tp"] if 1 <= _i(p.get("Thang")) <= 12]
    if th:
        return max(th)
    th = [_i(r.get("ThangCT")) for r in d["ct"] if d["tk"].get(r.get("MaTKNo"), "").startswith("154")]
    return max(th) if th else 0


def _u(d, s):
    """chu font cu cua so (VNI / TCVN3 theo License.FontName) -> Unicode; khong doi duoc thi giu nguyen."""
    s = str(s if s is not None else "").strip()
    if not s:
        return ""
    try:
        import bang_luong_gd78 as B
        f = d.get("_font")
        if f is None:
            f = str((d.get("lic") or {}).get("FontName") or "").upper()
            d["_font"] = f
        if f.startswith("VNI"):
            return B.vni_sang_u(s)
        if f.startswith(".VN") or f.startswith("VN"):
            return B.tcvn3_sang_u(s)
        loai = B.loai_ma([s])
        if loai == "VNI":
            return B.vni_sang_u(s)
        if loai == "TCVN3":
            return B.tcvn3_sang_u(s)
    except Exception:
        pass
    return s


def _ten_vt(d, ma):
    v = d["vt"].get(ma) or {}
    return str(v.get("SoHieu") or ma), _u(d, v.get("TenVattu")), str(v.get("DonVi") or "")


# ------------------------------------------------------------------ phan tich
def phan_tich(d, thang):
    tk = d["tk"]
    nguong_nvl = _f(d["tsgt"].get("NguongLechNVL")) or NGUONG_LECH_NVL
    hao_hut_md = _f(d["tsgt"].get("HaoHutMacDinh"))
    phieu = [p for p in d["tp"] if _i(p.get("Thang")) == thang]
    mact_phieu = {_i(p.get("MaCT")) for p in phieu}
    # dinh muc hieu luc <= thang: moi (MaTP, MaNVL) lay ban ThangHL lon nhat
    dm = {}
    for r in d["dm"]:
        hl = _i(r.get("ThangHL")) or _i(r.get("Thang")) or 1
        if hl > thang:
            continue
        k = (_i(r.get("MaTP")), _i(r.get("MaNVL")))
        if k not in dm or hl >= dm[k][1]:
            dm[k] = (_f(r.get("SoLuong")), hl, _f(r.get("TL")))
    tp_co_dm = {k[0] for k in dm}
    # san luong theo TP (thang nay + 3 thang gan nhat de du bao)
    sl_tp = defaultdict(float)
    sl_tp_qua = defaultdict(float)
    thang_qua = [t for t in range(max(1, thang - SO_THANG_DU_BAO + 1), thang + 1)]
    for p in d["tp"]:
        t = _i(p.get("Thang"))
        if t == thang:
            sl_tp[_i(p.get("MaTP"))] += _f(p.get("SoLuong"))
        if t in thang_qua:
            sl_tp_qua[_i(p.get("MaTP"))] += _f(p.get("SoLuong"))
    n_thang_qua = len({_i(p.get("Thang")) for p in d["tp"] if _i(p.get("Thang")) in thang_qua}) or 1
    # nhu cau NVL theo DM
    nhu_cau = defaultdict(float)
    nhu_cau_toi = defaultdict(float)
    for (ma_tp, ma_nvl), (sl_dm, _hl, _tl) in dm.items():
        if sl_tp.get(ma_tp):
            nhu_cau[ma_nvl] += sl_tp[ma_tp] * sl_dm
        if sl_tp_qua.get(ma_tp):
            nhu_cau_toi[ma_nvl] += sl_tp_qua[ma_tp] / n_thang_qua * sl_dm
    # xuat thuc te thang: dong tu dong (CT_ID >= AUTO_CT) va xuat tay 152 -> 154x
    xuat_dm, xuat_tay, xuat_tay_tien = defaultdict(float), defaultdict(float), defaultdict(float)
    ps_no_tk = defaultdict(float)          # No TK (so hieu) trong thang
    co334_sx = co334_all = 0.0
    tien_nvl_thang = 0.0
    for r in d["ct"]:
        if _i(r.get("ThangCT")) != thang:
            continue
        no, co = tk.get(r.get("MaTKNo"), ""), tk.get(r.get("MaTKCo"), "")
        tien = _f(r.get("SoPS"))
        if not (co.startswith("154") or co.startswith("155")):          # loai dong ket chuyen noi bo 154 -> 155 / 154D
            ps_no_tk[no] += tien
        if co.startswith("334"):
            co334_all += tien
            if no.startswith("154") or no.startswith("622") or no.startswith("627"):
                co334_sx += tien
        if co.startswith("152") and (no.startswith("154") or no.startswith("62")):
            luong = _f(r.get("SoPS2Co")) or _f(r.get("SoPS2No"))
            mv = _i(r.get("MaVattu"))
            tien_nvl_thang += tien
            if _i(r.get("CT_ID")) >= AUTO_CT or _i(r.get("MaCT")) in mact_phieu:
                xuat_dm[mv] += luong
            else:
                xuat_tay[mv] += luong
                xuat_tay_tien[mv] += tien
    # ton kho cuoi thang (tong cac kho / TK), TonKho Luong_<thang>
    ton = defaultdict(float)
    la_152 = set()
    for r in d["ton"]:
        mv = _i(r.get("MaVatTu"))
        ton[mv] += _f(r.get("Luong_%d" % thang))
        if tk.get(r.get("MaTaiKhoan"), "").startswith("152"):
            la_152.add(mv)
    ton_am_khac = {mv for mv, l in ton.items() if l < -1e-6 and mv in la_152}     # NVL am ton nhung khong co trong dinh muc / xuat thang nay
    # bang NVL
    ds_nvl = []
    ma_all = set(nhu_cau) | set(xuat_dm) | set(xuat_tay) | set(nhu_cau_toi) | ton_am_khac
    for mv in sorted(ma_all, key=lambda x: -(nhu_cau.get(x, 0) + xuat_dm.get(x, 0))):
        sh, ten, dvt = _ten_vt(d, mv)
        nc, xd, xt = nhu_cau.get(mv, 0.0), xuat_dm.get(mv, 0.0), xuat_tay.get(mv, 0.0)
        thuc = xd + xt
        lech = thuc - nc
        pct = (lech / nc * 100.0) if nc else None
        tinh = ""
        if nc and xd < nc * (1 - nguong_nvl / 100.0):
            tinh = "XUAT_THIEU"          # GD316 cat theo ton hoac DM moi / chua ghi lai phieu
        elif nc and thuc > nc * (1 + max(nguong_nvl, hao_hut_md) / 100.0):
            tinh = "HAO_HUT_CAO"
        elif not nc and thuc:
            tinh = "KHONG_DM"            # xuat ma khong co dinh muc (xuat tay / TP chua co DM)
        tc = ton.get(mv, 0.0)
        nct = nhu_cau_toi.get(mv, 0.0)
        du_thieu = tc - nct
        ds_nvl.append({"ma": mv, "sh": sh, "ten": ten, "dvt": dvt, "nhu_cau": nc, "xuat_dm": xd, "xuat_tay": xt, "lech": lech, "pct": pct,
                       "tinh": tinh, "ton": tc, "nhu_cau_toi": nct, "du_thieu": du_thieu, "am": tc < -1e-6,
                       "tien_tay": xuat_tay_tien.get(mv, 0.0)})
    # chi phi NC / SXC: theo tien to TK (TT133: 1541 NVL, 1542 NC, 1543 SXC; TT99: 621 / 622 / 627). Khong dung MaTKSX cua phieu
    #   (co so dat 154D = do dang). Chi tinh dong No that (loai dong ket chuyen No 154x / Co 154x-155).
    tk_cp = sorted({x for x in ps_no_tk if x.startswith(("1541", "621"))})
    tk_nc = sorted({x for x in ps_no_tk if x.startswith(("1542", "622"))})
    tk_sx = sorted({x for x in ps_no_tk if x.startswith(("1543", "627"))})
    ps_nc = sum(v for k, v in ps_no_tk.items() if k in tk_nc)
    ps_sx = sum(v for k, v in ps_no_tk.items() if k in tk_sx)
    pb_nvl = sum(_f(p.get("CPNVL")) for p in phieu)
    pb_nc = sum(_f(p.get("CPNC")) for p in phieu)
    pb_sx = sum(_f(p.get("CPSXC")) for p in phieu)
    # luong san xuat theo bang luong (loai nhan vien san xuat: khong co phan loai -> tong bang luong)
    bl_thang = [r for r in d["bl"] if _i(r.get("thang")) == thang]
    bl_tong = sum(_f(r.get("tongthunhap")) for r in bl_thang)
    chi_phi = {"tk_nc": sorted(tk_nc), "tk_sx": sorted(tk_sx), "tk_cp": sorted(tk_cp), "ps_nc": ps_nc, "ps_sx": ps_sx,
               "pb_nvl": pb_nvl, "pb_nc": pb_nc, "pb_sx": pb_sx, "chua_pb_nc": ps_nc - pb_nc, "chua_pb_sx": ps_sx - pb_sx,
               "co334_sx": co334_sx, "co334_all": co334_all, "bang_luong": bl_tong, "so_nv": len(bl_thang), "tien_nvl_xuat": tien_nvl_thang}
    # gia ban / gia von theo ma vat tu (thang nay, gan nhat)
    ban, gv = defaultdict(lambda: [0.0, 0.0]), defaultdict(lambda: [0.0, 0.0])
    ban_gan = {}
    for r in d["ct"]:
        no, co = tk.get(r.get("MaTKNo"), ""), tk.get(r.get("MaTKCo"), "")
        t = _i(r.get("ThangCT"))
        mv = _i(r.get("MaVattu"))
        if not mv or t > thang:
            continue
        luong = _f(r.get("SoPS2Co")) or _f(r.get("SoPS2No"))
        if co.startswith("511"):
            if t == thang:
                ban[mv][0] += _f(r.get("SoPS")); ban[mv][1] += luong
            g = ban_gan.setdefault(mv, [0, 0.0, 0.0])
            if t > g[0]:
                ban_gan[mv] = [t, _f(r.get("SoPS")), luong]
            elif t == g[0]:
                g[1] += _f(r.get("SoPS")); g[2] += luong
        elif no.startswith("632") and t == thang:
            gv[mv][0] += _f(r.get("SoPS")); gv[mv][1] += luong
    ds_tp = []
    gom = defaultdict(lambda: {"sl": 0.0, "nvl": 0.0, "nc": 0.0, "sxc": 0.0, "gt": 0.0, "ma154": set()})
    for p in phieu:
        g = gom[_i(p.get("MaTP"))]
        g["sl"] += _f(p.get("SoLuong")); g["nvl"] += _f(p.get("CPNVL")); g["nc"] += _f(p.get("CPNC")); g["sxc"] += _f(p.get("CPSXC"))
        g["gt"] += _f(p.get("GiaThanh")) or (_f(p.get("CPNVL")) + _f(p.get("CPNC")) + _f(p.get("CPSXC")))
        g["ma154"].add(_i(p.get("Ma154")))
    tong_dt = tong_gv = tong_lai = 0.0
    for ma_tp, g in sorted(gom.items(), key=lambda kv: -kv[1]["gt"]):
        sh, ten, dvt = _ten_vt(d, ma_tp)
        gt_dv = g["gt"] / g["sl"] if g["sl"] else 0.0
        b = ban.get(ma_tp)
        nguon = "tháng này"
        if not (b and b[1]):
            bg = ban_gan.get(ma_tp)
            if bg and bg[2]:
                b = [bg[1], bg[2]]
                nguon = "tháng %d" % thang_lich(d, bg[0])[0]
            else:
                b = None
        gia_ban = (b[0] / b[1]) if b else None
        lai_dv = (gia_ban - gt_dv) if gia_ban is not None else None
        ty_le = (lai_dv / gia_ban) if (gia_ban and lai_dv is not None) else None
        nx = ""
        if g["sl"] and gt_dv <= 0:
            nx = "GIA_THANH_0"
        elif ma_tp not in tp_co_dm and g["nvl"] == 0:
            nx = "CHUA_DM"
        elif gia_ban is None:
            nx = "CHUA_CO_GIA_BAN"
        elif lai_dv < 0:
            nx = "LO"
        elif ty_le is not None and ty_le < NGUONG_MONG:
            nx = "LAI_MONG"
        elif g["nvl"] and gt_dv and g["nvl"] / g["sl"] > gt_dv:
            nx = "GT_THAP_HON_NVL"
        dt_thang = ban.get(ma_tp, [0.0, 0.0])[0]
        gv_thang = gv.get(ma_tp, [0.0, 0.0])[0]
        tong_dt += dt_thang; tong_gv += gv_thang
        lai_t = (lai_dv * g["sl"]) if lai_dv is not None else None
        if lai_t is not None:
            tong_lai += lai_t
        ds_tp.append({"ma": ma_tp, "sh": sh, "ten": ten, "dvt": dvt, "sl": g["sl"], "nvl": g["nvl"], "nc": g["nc"], "sxc": g["sxc"], "gt": g["gt"],
                      "gt_dv": gt_dv, "gia_ban": gia_ban, "nguon_gia": nguon if gia_ban is not None else "", "lai_dv": lai_dv, "ty_le": ty_le,
                      "lai_tong": lai_t, "dt_thang": dt_thang, "gv_thang": gv_thang, "sl_ban": ban.get(ma_tp, [0, 0])[1], "nx": nx,
                      "ma154": ", ".join(_u(d, d["pl154"].get(x, str(x))) for x in sorted(g["ma154"]) if x)})
    # theo doi tuong 154 (lo / cong trinh)
    ds_154 = []
    gom154 = defaultdict(lambda: {"gt": 0.0, "sl": 0.0, "lai": 0.0, "n": 0})
    for x in ds_tp:
        for ma154 in (x["ma154"].split(", ") if x["ma154"] else [""]):
            g = gom154[ma154]
            g["gt"] += x["gt"]; g["sl"] += x["sl"]; g["n"] += 1
            if x["lai_tong"] is not None:
                g["lai"] += x["lai_tong"]
    for k, g in gom154.items():
        ds_154.append({"ten": k or "(không phân loại)", "gt": g["gt"], "sl": g["sl"], "lai": g["lai"], "n": g["n"]})
    dd_thang = [r for r in d["dd"] if _i(r.get("Thang")) == thang]      # do dang cuoi thang da khai (ThanhPhamDD)
    # ket chuyen - viec can lam
    viec = []
    if not phieu and (tien_nvl_thang > 0 or ps_nc > 0 or ps_sx > 0):
        viec.append(("NANG", "KC_CHUA_LAP", "Tháng có xuất NVL / chi phí sản xuất %s nhưng chưa có phiếu kết chuyển thành phẩm" % _dd(tien_nvl_thang + ps_nc + ps_sx),
                     "Giá thành > Lập phương án giá thành / Kết chuyển thành phẩm", tien_nvl_thang + ps_nc + ps_sx))
    if phieu and abs(chi_phi["chua_pb_nc"]) > 1000:
        viec.append(("NANG", "NC_CHUA_PHAN_BO", "Nhân công phát sinh %s, đã vào giá thành %s, chênh %s" % (_dd(ps_nc), _dd(pb_nc), _dd(ps_nc - pb_nc)),
                     "Giá thành > Phiếu kết chuyển > Tính lại / phân bổ NC tháng %d" % thang, ps_nc - pb_nc))
    if phieu and abs(chi_phi["chua_pb_sx"]) > 1000:
        viec.append(("NANG", "SXC_CHUA_PHAN_BO", "Sản xuất chung phát sinh %s, đã vào giá thành %s, chênh %s" % (_dd(ps_sx), _dd(pb_sx), _dd(ps_sx - pb_sx)),
                     "Giá thành > Phiếu kết chuyển > Tính lại / phân bổ SXC tháng %d" % thang, ps_sx - pb_sx))
    if bl_tong and co334_all < bl_tong * 0.98:
        viec.append(("NANG" if co334_all < bl_tong * 0.5 else "VUA", "LUONG_CHUA_TRICH",
                     "Bảng lương tháng %s (%d người) nhưng mới trích vào chi phí %s (Có 334; phần vào sản xuất %s) - lương chưa vào giá thành / chi phí tháng" % (
                         _dd(bl_tong), len(bl_thang), _dd(co334_all), _dd(co334_sx)),
                     "Lao động > Trích lương (hoặc Sổ phụ > Lập chứng từ lương từ bảng lương AI) trước khi tính giá thành", bl_tong - co334_all))
    if phieu and tong_dt <= 0:
        viec.append(("VUA", "CHUA_CO_DOANH_THU", "Tháng có sản xuất nhưng chưa có doanh thu 511 trên sổ - chưa nhập / hạch toán hoá đơn bán ra; lãi lỗ dưới đây tính theo giá bán tháng gần nhất",
                     "Hoá đơn điện tử > tải hoá đơn bán ra tháng này rồi hạch toán", 0))
    n_thieu = [x for x in ds_nvl if x["tinh"] == "XUAT_THIEU"]
    if n_thieu:
        viec.append(("NANG", "NVL_XUAT_THIEU", "%d NVL xuất theo định mức ít hơn nhu cầu quá %.0f%% (thiếu tồn khi ghi phiếu hoặc chưa ghi lại phiếu sau khi đổi định mức): %s" % (
            len(n_thieu), nguong_nvl, ", ".join(x["sh"] for x in n_thieu[:6])), "Kho > Nhập NVL còn thiếu, rồi Giá thành > Ghi lại tất cả phiếu tháng (GĐ316)", sum(x["tien_tay"] for x in n_thieu)))
    n_hh = [x for x in ds_nvl if x["tinh"] == "HAO_HUT_CAO"]
    if n_hh:
        viec.append(("VUA", "HAO_HUT_CAO", "%d NVL xuất vượt định mức: %s" % (len(n_hh), ", ".join("%s +%.0f%%" % (x["sh"], x["pct"]) for x in n_hh[:6])),
                     "Giá thành > Định mức: xem lại định mức / xuất tay", 0))
    n_tay = [x for x in ds_nvl if x["xuat_tay"] and x["nhu_cau"]]
    if n_tay and tien_nvl_thang and sum(x["tien_tay"] for x in ds_nvl) > 0.1 * tien_nvl_thang:
        viec.append(("VUA", "XUAT_TAY_NHIEU", "Xuất tay 152 -> 154 chiếm %.0f%% tiền NVL tháng (%s)" % (100 * sum(x["tien_tay"] for x in ds_nvl) / tien_nvl_thang, _dd(sum(x["tien_tay"] for x in ds_nvl))),
                     "Chuyển các dòng xuất tay vào định mức để giá thành theo từng thành phẩm", sum(x["tien_tay"] for x in ds_nvl)))
    n_am = [x for x in ds_nvl if x["am"]]
    if n_am:
        viec.append(("NANG", "NVL_AM", "%d NVL tồn âm cuối tháng: %s" % (len(n_am), ", ".join("%s %s" % (x["sh"], _sl(x["ton"])) for x in n_am[:6])),
                     "Kho > Nhập kho NVL (hàng về trước hoá đơn sau - GĐ315) trước khi khoá", 0))
    ma_dien = _i(d["tsgt"].get("MaDien"))
    n_mua = [x for x in ds_nvl if x["nhu_cau_toi"] and x["du_thieu"] < 0 and x["ma"] != ma_dien and x["dvt"].upper() not in ("KWH", "KW")]
    if n_mua:
        viec.append(("VUA", "NVL_CAN_MUA", "%d NVL tồn cuối tháng không đủ nhu cầu tháng tới (bình quân %d tháng): %s" % (
            len(n_mua), n_thang_qua, ", ".join("%s thiếu %s %s" % (x["sh"], _sl(-x["du_thieu"]), x["dvt"]) for x in n_mua[:6])), "Kế hoạch mua hàng tháng tới", 0))
    if phieu and tien_nvl_thang - pb_nvl > max(1000000.0, 0.01 * tien_nvl_thang):
        viec.append(("VUA", "NVL_CHUA_VAO_PHIEU", "NVL xuất cho sản xuất %s nhưng phiếu kết chuyển mới nhận %s - chênh %s còn nằm ở 154 (dở dang) hoặc xuất tay chưa gắn thành phẩm" % (
            _dd(tien_nvl_thang), _dd(pb_nvl), _dd(tien_nvl_thang - pb_nvl)), "Giá thành > Phiếu kết chuyển: kiểm dở dang cuối tháng / gắn dòng xuất tay vào định mức", tien_nvl_thang - pb_nvl))
    n_lo = [x for x in ds_tp if x["nx"] == "LO"]
    if n_lo:
        viec.append(("NANG", "SP_LO", "%d thành phẩm giá thành cao hơn giá bán: %s" % (len(n_lo), ", ".join("%s (%s)" % (x["sh"], _dd(x["lai_dv"])) for x in n_lo[:6])),
                     "Xem giá bán / định mức / phân bổ chi phí của mã", sum(x["lai_tong"] or 0 for x in n_lo)))
    n_gt0 = [x for x in ds_tp if x["nx"] in ("GIA_THANH_0", "CHUA_DM")]
    if n_gt0:
        viec.append(("NANG", "GT_0", "%d thành phẩm giá thành = 0 / chưa có định mức: %s" % (len(n_gt0), ", ".join(x["sh"] for x in n_gt0[:6])),
                     "Giá thành > Định mức NVL (Trợ lý định mức GĐ173 gợi ý)", 0))
    tong = {"thang": thang, "thang_lich": thang_lich(d, thang), "so_phieu": len(phieu), "so_tp": len(ds_tp), "san_luong": sum(x["sl"] for x in ds_tp),
            "gia_thanh": sum(x["gt"] for x in ds_tp), "doanh_thu": tong_dt, "gia_von": tong_gv, "lai_gop_thang": tong_dt - tong_gv,
            "lai_du_kien": tong_lai, "sp_lo": len(n_lo), "nvl_thieu": len(n_thieu), "nvl_am": len(n_am), "nvl_can_mua": len(n_mua),
            "chua_pb": chi_phi["chua_pb_nc"] + chi_phi["chua_pb_sx"], "so_viec": len(viec), "nguong_nvl": nguong_nvl, "do_dang": len(dd_thang),
            "muc": "CANH_BAO" if any(v[0] == "NANG" for v in viec) else ("THONG_TIN" if viec else "DAT")}
    return {"tong": tong, "nvl": ds_nvl, "tp": ds_tp, "ma154": ds_154, "chi_phi": chi_phi, "viec": viec}


# ------------------------------------------------------------------ ghi
def ghi(kq, thu_muc, ten_so=""):
    os.makedirs(thu_muc, exist_ok=True)
    t = kq["tong"]
    th, nam = t["thang_lich"]
    dong = ["TONG;%d;%02d/%d;%s;%d;%d;%s;%s;%s;%s;%d;%d;%d;%d;%s;%d" % (
        t["thang"], th, nam, t["muc"], t["so_phieu"], t["so_tp"], _dd(t["gia_thanh"]), _dd(t["doanh_thu"]), _dd(t["gia_von"]), _dd(t["lai_du_kien"]),
        t["sp_lo"], t["nvl_thieu"], t["nvl_am"], t["nvl_can_mua"], _dd(t["chua_pb"]), t["so_viec"])]
    for v in kq["viec"]:
        dong.append("V;%s;%s;%s;%s;%s" % (v[0], v[1], _s(v[2])[:300], _s(v[3])[:150], _dd(v[4])))
    for x in kq["tp"]:
        dong.append("TP;%s;%s;%s;%s;%s;%s;%s;%s;%s;%s" % (_s(x["sh"]), _s(x["ten"])[:60], _sl(x["sl"]), _dd(x["gt_dv"]), _dd(x["gia_ban"]) if x["gia_ban"] is not None else "",
                                                        _dd(x["lai_dv"]) if x["lai_dv"] is not None else "", ("%.1f" % (100 * x["ty_le"])) if x["ty_le"] is not None else "",
                                                        _dd(x["lai_tong"]) if x["lai_tong"] is not None else "", x["nx"], _s(x["ma154"])))
    for x in kq["nvl"]:
        dong.append("NVL;%s;%s;%s;%s;%s;%s;%s;%s;%s;%s;%s" % (_s(x["sh"]), _s(x["ten"])[:60], _s(x["dvt"]), _sl(x["nhu_cau"]), _sl(x["xuat_dm"]), _sl(x["xuat_tay"]),
                                                            _sl(x["lech"]), ("%.1f" % x["pct"]) if x["pct"] is not None else "", x["tinh"], _sl(x["ton"]), _sl(x["du_thieu"])))
    c = kq["chi_phi"]
    dong.append("CP;%s;%s;%s;%s;%s;%s;%s;%s;%s;%d" % (_dd(c["ps_nc"]), _dd(c["pb_nc"]), _dd(c["ps_sx"]), _dd(c["pb_sx"]), _dd(c["pb_nvl"]), _dd(c["tien_nvl_xuat"]), _dd(c["co334_sx"]), _dd(c["co334_all"]), _dd(c["bang_luong"]), c["so_nv"]))
    p_txt = os.path.join(thu_muc, TEP + ".txt")
    with io.open(p_txt, "w", encoding="utf-8") as f:
        f.write("\n".join(dong) + "\n")
    p_html = os.path.join(thu_muc, TEP + ".html")
    with io.open(p_html, "w", encoding="utf-8") as f:
        f.write(_html(kq, ten_so))
    return p_txt, p_html


def _html(kq, ten_so):
    t = kq["tong"]
    th, nam = t["thang_lich"]
    e = html.escape
    mau = {"NANG": "#b3261e", "VUA": "#8a5a00"}
    out = ["<!doctype html><html lang='vi'><head><meta charset='utf-8'><title>Phương án giá thành %02d/%d</title><style>" % (th, nam),
           "body{font-family:Arial,sans-serif;margin:16px;color:#1d2433}h2{margin:18px 0 6px}table{border-collapse:collapse;width:100%;margin-bottom:10px}",
           "th,td{border:1px solid #c5ccd6;padding:5px 6px;font-size:13px;vertical-align:top}th{background:#e8eef5}td.n{text-align:right;white-space:nowrap}",
           ".the{display:inline-block;min-width:150px;margin:4px 8px 4px 0;padding:8px 12px;border:1px solid #c5ccd6;border-radius:8px}.the b{font-size:18px;display:block}",
           ".lo{color:#b3261e;font-weight:bold}.ok{color:#1b7f3b}.nho{color:#5c6672;font-size:12px}</style></head><body>",
           "<h1>Phương án giá thành tháng %02d/%d%s</h1><p class='nho'>Xem trước - máy tập hợp từ sổ, chưa ghi gì. Người quyết định rồi làm trên màn hình tương ứng. Lập %s.</p>" % (
               th, nam, (" - " + e(ten_so)) if ten_so else "", _dt.datetime.now().strftime("%d/%m/%Y %H:%M"))]
    out.append("<div>" + "".join("<div class='the'><span class='nho'>%s</span><b>%s</b></div>" % (a, b) for a, b in (
        ("Phiếu kết chuyển", t["so_phieu"]), ("Thành phẩm", t["so_tp"]), ("Giá thành tháng", _dd(t["gia_thanh"])), ("Doanh thu tháng", _dd(t["doanh_thu"])),
        ("Giá vốn tháng", _dd(t["gia_von"])), ("Lãi gộp dự kiến (SX tháng)", _dd(t["lai_du_kien"])), ("SP lỗ", t["sp_lo"]), ("NVL thiếu / âm / cần mua", "%d / %d / %d" % (t["nvl_thieu"], t["nvl_am"], t["nvl_can_mua"])),
        ("Chi phí chưa phân bổ", _dd(t["chua_pb"])))) + "</div>")
    out.append("<h2>1. Việc cần làm trước khi khoá tháng (%d)</h2>" % len(kq["viec"]))
    if kq["viec"]:
        out.append("<table><tr><th>Mức</th><th>Mã</th><th>Nội dung</th><th>Làm ở đâu</th><th>Số tiền</th></tr>")
        for v in kq["viec"]:
            out.append("<tr><td style='color:%s;font-weight:bold'>%s</td><td>%s</td><td>%s</td><td>%s</td><td class='n'>%s</td></tr>" % (mau.get(v[0], "#1f4e79"), v[0], v[1], e(v[2]), e(v[3]), _dd(v[4]) if v[4] else ""))
        out.append("</table>")
    else:
        out.append("<p class='ok'>Không có việc tồn đọng: NVL khớp định mức, chi phí đã phân bổ hết, không có sản phẩm lỗ.</p>")
    c = kq["chi_phi"]
    out.append("<h2>2. Chi phí vào giá thành</h2><table><tr><th>Khoản</th><th>TK</th><th>Phát sinh tháng</th><th>Đã vào phiếu</th><th>Chênh lệch</th></tr>")
    out.append("<tr><td>NVL xuất</td><td>152 → %s</td><td class='n'>%s</td><td class='n'>%s</td><td class='n'>%s</td></tr>" % (e(", ".join(c["tk_cp"]) or "154x"), _dd(c["tien_nvl_xuat"]), _dd(c["pb_nvl"]), _dd(c["tien_nvl_xuat"] - c["pb_nvl"])))
    out.append("<tr><td>Nhân công</td><td>%s</td><td class='n'>%s</td><td class='n'>%s</td><td class='n %s'>%s</td></tr>" % (e(", ".join(c["tk_nc"])), _dd(c["ps_nc"]), _dd(c["pb_nc"]), "lo" if abs(c["chua_pb_nc"]) > 1000 else "", _dd(c["chua_pb_nc"])))
    out.append("<tr><td>Sản xuất chung</td><td>%s</td><td class='n'>%s</td><td class='n'>%s</td><td class='n %s'>%s</td></tr>" % (e(", ".join(c["tk_sx"])), _dd(c["ps_sx"]), _dd(c["pb_sx"]), "lo" if abs(c["chua_pb_sx"]) > 1000 else "", _dd(c["chua_pb_sx"])))
    out.append("<tr><td>Lương đã trích (Có 334) / vào sản xuất</td><td>334</td><td class='n'>%s / %s</td><td colspan='2'>Bảng lương tháng: %s (%d người); chưa trích: %s</td></tr></table>" % (_dd(c["co334_all"]), _dd(c["co334_sx"]), _dd(c["bang_luong"]), c["so_nv"], _dd(c["bang_luong"] - c["co334_all"])))
    out.append("<h2>3. Lãi / lỗ từng thành phẩm</h2><table><tr><th>Mã</th><th>Tên</th><th>SL sản xuất</th><th>Giá thành / ĐVT</th><th>Giá bán / ĐVT</th><th>Lãi / ĐVT</th><th>% lãi</th><th>Lãi dự kiến</th><th>Nhận xét</th><th>Đối tượng 154</th></tr>")
    for x in kq["tp"]:
        cls = "lo" if x["nx"] in ("LO", "GIA_THANH_0", "CHUA_DM", "GT_THAP_HON_NVL") else ""
        out.append("<tr><td>%s</td><td>%s</td><td class='n'>%s</td><td class='n'>%s</td><td class='n'>%s<br><span class='nho'>%s</span></td><td class='n %s'>%s</td><td class='n'>%s</td><td class='n %s'>%s</td><td class='%s'>%s</td><td>%s</td></tr>" % (
            e(x["sh"]), e(x["ten"]), _sl(x["sl"]), _dd(x["gt_dv"]), _dd(x["gia_ban"]) if x["gia_ban"] is not None else "-", e(x["nguon_gia"]), cls,
            _dd(x["lai_dv"]) if x["lai_dv"] is not None else "-", ("%.1f%%" % (100 * x["ty_le"])) if x["ty_le"] is not None else "-", cls,
            _dd(x["lai_tong"]) if x["lai_tong"] is not None else "-", cls, e(x["nx"]), e(x["ma154"])))
    out.append("</table>")
    if kq["ma154"]:
        out.append("<h2>4. Theo đối tượng 154 (lô / công trình)</h2><table><tr><th>Đối tượng</th><th>Số TP</th><th>Sản lượng</th><th>Giá thành</th><th>Lãi dự kiến</th></tr>")
        for x in kq["ma154"]:
            out.append("<tr><td>%s</td><td class='n'>%d</td><td class='n'>%s</td><td class='n'>%s</td><td class='n %s'>%s</td></tr>" % (e(x["ten"]), x["n"], _sl(x["sl"]), _dd(x["gt"]), "lo" if x["lai"] < 0 else "", _dd(x["lai"])))
        out.append("</table>")
    out.append("<h2>5. Nguyên vật liệu: định mức - thực xuất - tồn - nhu cầu tháng tới</h2><table><tr><th>Mã</th><th>Tên</th><th>ĐVT</th><th>Nhu cầu theo ĐM</th><th>Xuất theo ĐM</th><th>Xuất tay</th><th>Lệch</th><th>%</th><th>Tình trạng</th><th>Tồn cuối tháng</th><th>Nhu cầu tháng tới</th><th>Dư (+) / thiếu (−)</th></tr>")
    for x in kq["nvl"][:300]:
        cls = "lo" if x["tinh"] in ("XUAT_THIEU", "HAO_HUT_CAO") or x["am"] or x["du_thieu"] < 0 else ""
        out.append("<tr><td>%s</td><td>%s</td><td>%s</td><td class='n'>%s</td><td class='n'>%s</td><td class='n'>%s</td><td class='n'>%s</td><td class='n'>%s</td><td class='%s'>%s</td><td class='n %s'>%s</td><td class='n'>%s</td><td class='n %s'>%s</td></tr>" % (
            e(x["sh"]), e(x["ten"]), e(x["dvt"]), _sl(x["nhu_cau"]), _sl(x["xuat_dm"]), _sl(x["xuat_tay"]), _sl(x["lech"]), ("%.1f" % x["pct"]) if x["pct"] is not None else "",
            cls, e(x["tinh"]), "lo" if x["am"] else "", _sl(x["ton"]), _sl(x["nhu_cau_toi"]), "lo" if x["du_thieu"] < 0 else "ok", _sl(x["du_thieu"])))
    out.append("</table><p class='nho'>Ngưỡng lệch NVL %.0f%% (Tham số giá thành). Nhu cầu tháng tới = bình quân sản lượng %d tháng gần nhất × định mức hiệu lực. Không ghi gì vào sổ.</p></body></html>" % (t["nguong_nvl"], SO_THANG_DU_BAO))
    return "".join(out)


# ------------------------------------------------------------------ K60 cho kiem_khoa_so
def k_phuong_an(S, _kq, DAT, CANH_BAO, LOI, THONG_TIN):
    ten = "Phương án giá thành tháng (NVL dư / thiếu, chi phí chưa phân bổ, lãi lỗ thành phẩm) - xem trước"
    duong = (S.dl or {}).get("duong_so") or ""
    if not duong or not os.path.isfile(duong):
        return None
    try:
        d = doc(duong)
    except Exception as ex:
        return [_kq("K60", ten, THONG_TIN, "Không đọc được sổ để lập phương án: %s" % type(ex).__name__)]
    thang = 0
    try:
        thang = int(getattr(S, "t2", 0) or 0)
    except (TypeError, ValueError):
        thang = 0
    if not thang or not any(_i(p.get("Thang")) == thang for p in d["tp"]):
        thang = thang_moi_nhat(d)
    if not thang:
        return None                           # so khong san xuat
    kq = phan_tich(d, thang)
    tm = [os.path.join(HERE, "ket-qua")]
    try:
        import chinh_sach_so
        tm.append(chinh_sach_so._thu_muc_ra(duong)[0])
    except Exception:
        pass
    p_html = ""
    for x in tm:
        try:
            _, p_html = ghi(kq, x, os.path.basename(duong))
        except Exception:
            pass
    t = kq["tong"]
    th, nam = t["thang_lich"]
    dong = [[v[1], v[0], v[2], v[3], _dd(v[4]) if v[4] else ""] for v in kq["viec"]]
    muc = {"CANH_BAO": CANH_BAO, "THONG_TIN": THONG_TIN}.get(t["muc"], DAT)
    kl = ("Tháng %02d/%d: %d phiếu, %d thành phẩm, giá thành %s; lãi gộp dự kiến %s; SP lỗ %d; NVL thiếu %d / âm %d / cần mua %d; chi phí chưa phân bổ %s. "
          "%d việc cần làm - xem phương án: %s" % (th, nam, t["so_phieu"], t["so_tp"], _dd(t["gia_thanh"]), _dd(t["lai_du_kien"]), t["sp_lo"], t["nvl_thieu"], t["nvl_am"],
                                                     t["nvl_can_mua"], _dd(t["chua_pb"]), t["so_viec"], p_html))
    return [_kq("K60", ten, muc, kl, ["Mã", "Mức", "Nội dung", "Làm ở đâu", "Số tiền"], dong)]


def main(argv):
    import sys
    t = {}
    for a in argv[1:]:
        if a.startswith("/") and ":" in a:
            k, v = a[1:].split(":", 1)
            t[k.lower()] = v.strip('"')
    so = t.get("so")
    if not so:
        print("python gia_thanh_phuong_an.py /so:\"<so.MDB>\" [/thang:<1-12 thu tu nam TC>] [/ra:<thu muc>]")
        return 1
    d = doc(so)
    thang = int(t.get("thang") or 0) or thang_moi_nhat(d)
    if not thang:
        print("So khong co phieu ket chuyen / phat sinh 154 - khong lap phuong an.")
        return 2
    kq = phan_tich(d, thang)
    p1, p2 = ghi(kq, t.get("ra") or os.path.join(HERE, "ket-qua"), os.path.basename(so))
    tg = kq["tong"]
    print("Thang %d (%02d/%d): %d phieu, %d TP, %d viec, muc %s -> %s" % (thang, tg["thang_lich"][0], tg["thang_lich"][1], tg["so_phieu"], tg["so_tp"], tg["so_viec"], tg["muc"], p2))
    return 0


if __name__ == "__main__":
    import sys
    sys.exit(main(sys.argv))
