# -*- coding: utf-8 -*-
"""GD100 - mo phong bo may gia thanh theo doi tuong TT133 (CUNG quy tac ModTT133GT) tren du lieu so that / gia lap.
Mo phong "Ghi lai toan bo nam": moi thang, moi phieu (theo MaCT): xoa dong CT_ID 610000000 + MaCT, giu dong xuat NVL tu
dong (MaLoai 2) cu lam "xuat kho thuc te", tinh phan bo, ghi 632, dat ThanhPham CP = phan bo (+ do dang gia lap), ghi
No 155 va cac dong Co 1541 / 1542 / 1543 tach (TK, MaTP nguon). Kiem bat bien so sach sau khi ghi.
Chi dung de kiem thu tren may phat trien. Dung: python3 mo_phong_gt133.py <so.MDB>"""
import collections
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
ID_PHIEU, ID_PBCU = 610000000, 400000000


def rm(x):
    return float(int(x + (0.5 if x >= 0 else -0.5)))


def trong(a, lo, hi):
    return lo <= (a or 0) < hi


class So(object):
    def __init__(s, tk, ct, tp, tp154, dm, dau_ky=1, ts=None, tay=None):
        s.tk = tk                  # MaSo -> (SoHieu, TKCon)
        s.ct = [dict(r) for r in ct]
        s.tp = [dict(r) for r in tp]
        s.tp154 = tp154            # MaSo -> SoHieu
        s.dm = dm
        s.dau_ky = dau_ky
        s.ts = ts or dict(TTNVL=3, TTNC=1, TTSXC=1, DsCoDinh="", CSBT=0, VuotNVL=-1, VuotNC=-1)
        s.tay = tay or {}          # (thang, mact, nhom) -> (tyle, sotien)
        s.canh = []
        s.ma_so_ct = max([r.get("MaSo") or 0 for r in s.ct] + [0])

    # ---------------------------------------------------------- doc MDB
    @staticmethod
    def tu_mdb(duong):
        from mdbread import Mdb
        from do_gt133 import doc
        m = Mdb(duong)
        ten = {"maso": "MaSo", "sohieu": "SoHieu", "tkcon": "TKCon", "thangct": "ThangCT", "matkno": "MaTKNo",
               "matkco": "MaTKCo", "sops": "SoPS", "matp": "MaTP", "ct_id": "CT_ID", "maloai": "MaLoai", "mact": "MaCT",
               "ma154": "Ma154", "xk": "XK", "soluong": "SoLuong", "ddck": "DDCK", "dddk": "DDDK", "thang": "Thang",
               "cpnvl": "CPNVL", "cpnc": "CPNC", "cpsxc": "CPSXC", "matkcp": "MaTKCP", "matknc": "MaTKNC", "manvl": "MaNVL"}

        def chuan(rows):
            return [{ten.get(k, k): v for k, v in r.items()} for r in rows]
        tk = {r["MaSo"]: (str(r.get("SoHieu") or "").strip(), r.get("TKCon") or 0) for r in chuan(doc(m, "HethongTK"))}
        tp154 = {r["MaSo"]: str(r.get("SoHieu") or "").strip() for r in chuan(doc(m, "TP154"))}
        return So(tk, chuan(doc(m, "ChungTu")), chuan(doc(m, "ThanhPham")), tp154, chuan(doc(m, "DinhMuc")))

    def sh(s, ma):
        return s.tk.get(ma or 0, ("", 0))[0]

    def thu_tu(s, t):
        return t + 12 if t < s.dau_ky else t

    def la_chung(s, tp):
        if (tp or 0) <= 0:
            return True
        x = (s.tp154.get(tp) or "").strip().upper()
        return x in ("", "0", "CH", "...")

    def dgnc(s, matp, thang):
        r = [d for d in s.dm if (d.get("MaNVL") or 0) == 0 and d.get("MaTP") == matp and (d.get("Thang") or 0) > 0
             and s.thu_tu(d["Thang"]) <= s.thu_tu(thang)]
        r.sort(key=lambda d: s.thu_tu(d["Thang"]), reverse=True)
        return float(r[0].get("SoLuong") or 0) if r else 0.0

    # ---------------------------------------------------------- TINH (cung thu tu voi TT133GT_Tinh, khong co phieu dang nhap)
    def tinh(s, thang):
        ts = s.ts
        s.canh = []
        U = []
        for r in sorted((r for r in s.tp if r.get("Thang") == thang), key=lambda r: (r["MaCT"], r["MaSo"])):
            if not U or U[-1]["MaCT"] != r["MaCT"]:
                U.append(dict(MaCT=r["MaCT"], Ma154=r.get("Ma154") or 0, XK=r.get("XK") or 0, SL=0.0, DMNC=0.0, CoDMNC=True, NVL=0.0))
            u = U[-1]
            sl = (r.get("SoLuong") or 0) + (r.get("DDCK") or 0) - (r.get("DDDK") or 0)
            u["SL"] += sl
            dg = s.dgnc(r.get("MaTP"), thang)
            if dg > 0:
                u["DMNC"] += sl * dg
            else:
                u["CoDMNC"] = False
        vt = {u["MaCT"]: i for i, u in enumerate(U)}
        co_dt = any(u["Ma154"] > 0 for u in U)
        KC, P632, TRUC, CHUNG, CHO, TONGCHUNG, DDDAU, DDKC = {}, {}, {}, {}, {}, {}, {}, {}

        def cong(d, k, v):
            if v:
                d[k] = d.get(k, 0) + v

        def chia(tien, ds, w, ten):
            w = list(w)
            if not ds or tien == 0:
                return [0.0] * len(ds)
            tong = sum(x for x in w if x > 0)
            if tong <= 0:
                s.canh.append(ten + ": trong so = 0 - chia theo san luong")
                w = [U[i]["SL"] for i in ds]
                tong = sum(x for x in w if x > 0)
            if tong <= 0:
                w = [1.0] * len(ds)
                tong = float(len(ds))
            cuoi = max(i for i, x in enumerate(w) if x > 0)
            kq, da = [0.0] * len(ds), 0.0
            for i, x in enumerate(w):
                if i == cuoi:
                    kq[i] = tien - da
                elif x > 0:
                    kq[i] = rm(tien * x / tong)
                    da += kq[i]
            return kq

        def nhom_tk(x):
            return {"1541": 1, "1542": 2, "1543": 3}.get(x[:4], 0)

        tt_nay = s.thu_tu(thang)
        # --- chi phi thang truoc cua doi tuong (TinhDDDau)
        da_xet = set()
        for u in U:
            o = u["Ma154"]
            if o <= 0 or o in da_xet:
                continue
            da_xet.add(o)
            if s.la_chung(o):
                continue
            truoc = [s.thu_tu(r["Thang"]) for r in s.tp if r.get("Ma154") == o and s.thu_tu(r["Thang"]) < tt_nay]
            cuoi = max(truoc) if truoc else 0
            tong = {}
            for r in s.ct:
                if r.get("MaTP") != o:
                    continue
                cid = r.get("CT_ID") or 0
                if trong(cid, ID_PBCU, ID_PBCU + 10000000):          # so du rong (ca dong do gia thanh ghi), bo phan bo cu
                    continue
                th = r.get("ThangCT") or 0
                ok = (th == 0 and cuoi == 0) or (th > 0 and cuoi < s.thu_tu(th) < tt_nay)
                if not ok:
                    continue
                for ben, dau in (("MaTKNo", 1), ("MaTKCo", -1)):
                    g = nhom_tk(s.sh(r.get(ben)))
                    if g:
                        cong(tong, (g, r[ben]), dau * (r.get("SoPS") or 0))
            ds = [i for i, x in enumerate(U) if x["Ma154"] == o]
            for (g, tk), v in tong.items():
                if abs(v) >= 0.5:
                    for i, x in zip(ds, chia(v, ds, [U[i]["SL"] for i in ds], "dd dau")):
                        cong(DDDAU, (i, g), x)
                        cong(DDKC, (i, g, tk, o), x)
        # --- tung nhom
        for nhom, ten_nhom, tt in ((1, "1541", ts["TTNVL"]), (2, "1542", ts["TTNC"]), (3, "1543", ts["TTSXC"])):
            tt_truc = (3 if nhom == 1 else 1) if tt in (1, 2) else tt

            def trong_so(i, t=None):
                t = tt if t is None else t
                u = U[i]
                if t == 1:
                    return u["SL"] if nhom == 1 else u["NVL"]
                if t == 2:
                    x = s.tay.get((thang, u["MaCT"], nhom))
                    return (x[1] if any(v[1] > 0 for (t2, m2, g2), v in s.tay.items() if t2 == thang and g2 == nhom) else x[0]) if x else 0
                if t == 3:
                    return u["SL"]
                return u["DMNC"]
            pool = {}
            for r in s.ct:
                if r.get("ThangCT") != thang:
                    continue
                cid = r.get("CT_ID") or 0
                if trong(cid, ID_PBCU, ID_PBCU + 10000000):
                    continue
                gt = trong(cid, ID_PHIEU, ID_PHIEU + 10000000)
                for loai, ben in ((1, "MaTKNo"), (2, "MaTKCo")):
                    if not s.sh(r.get(ben)).startswith(ten_nhom):
                        continue
                    if gt and not (loai == 1 and nhom == 1 and r.get("MaLoai") == 2):
                        continue
                    v = (r.get("SoPS") or 0) * (1 if loai == 1 else -1)
                    u = -9
                    if ID_PHIEU < cid < ID_PHIEU + 10000000 and (cid - ID_PHIEU) in vt:
                        u = vt[cid - ID_PHIEU]
                    cong(pool, (r[ben], r.get("MaTP") or 0, u), v)
            w_chung = None
            for (tk, tp, u), v in pool.items():
                if not v:
                    continue
                if u >= 0:
                    cong(KC, (u, nhom, tk, tp), v)
                    cong(TRUC, (u, nhom), v)
                elif U and (s.la_chung(tp) or not co_dt):
                    if w_chung is None:
                        w_chung = [trong_so(i) for i in range(len(U))]
                    ds = list(range(len(U)))
                    for i, x in zip(ds, chia(v, ds, w_chung, "chung " + ten_nhom)):
                        cong(KC, (i, nhom, tk, tp), x)
                        cong(CHUNG, (i, nhom), x)
                    cong(TONGCHUNG, nhom, v)
                elif any(x["Ma154"] == tp for x in U):
                    ds = [i for i, x in enumerate(U) if x["Ma154"] == tp]
                    for i, x in zip(ds, chia(v, ds, [trong_so(i, tt_truc) for i in ds], "truc tiep " + ten_nhom)):
                        cong(KC, (i, nhom, tk, tp), x)
                        cong(TRUC, (i, nhom), x)
                elif s.la_chung(tp):
                    cong(TONGCHUNG, nhom, v)
                else:
                    cong(CHO, (nhom, tk, tp), v)
            if nhom == 1:
                for i, u in enumerate(U):
                    u["NVL"] = TRUC.get((i, 1), 0) + CHUNG.get((i, 1), 0)

        def tong_u(d, i, g):
            return sum(v for k, v in d.items() if k[0] == i and k[1] == g)

        def sang632(i, g, tien):
            ks = [k for k in KC if k[0] == i and k[1] == g and KC[k] > 0]
            tong = sum(KC[k] for k in ks)
            if tien <= 0 or tong <= 0:
                return
            tien = min(tien, tong)
            da = 0
            for j, k in enumerate(ks):
                x = tien - da if j == len(ks) - 1 else rm(tien * KC[k] / tong)
                if j < len(ks) - 1:
                    da += x
                KC[k] -= x
                cong(P632, k, x)
        if ts["VuotNC"] >= 0:
            for i, u in enumerate(U):
                if u["CoDMNC"] and u["DMNC"] > 0:
                    thuc = tong_u(KC, i, 2)
                    chuan = rm(u["DMNC"] * (1 + ts["VuotNC"] / 100.0))
                    if thuc > chuan:
                        sang632(i, 2, thuc - chuan)
        if ts["CSBT"] > 0 and ts["DsCoDinh"]:
            slt = sum(u["SL"] for u in U)
            if 0 <= slt < ts["CSBT"]:
                r = slt / ts["CSBT"]
                pre = [x.strip() for x in ts["DsCoDinh"].replace(";", ",").split(",") if x.strip()]
                dk = {m for m, (shk, con) in s.tk.items() if con == 0 and shk.startswith("1543") and any(shk.startswith(p) for p in pre)}
                ks = [k for k in KC if k[1] == 3 and k[2] in dk and KC[k] > 0]
                tongF = sum(KC[k] for k in ks)
                if tongF > 0:
                    tien = tongF - rm(tongF * r)
                    da = 0
                    for j, k in enumerate(ks):
                        x = tien - da if j == len(ks) - 1 else rm(tien * KC[k] / tongF)
                        if j < len(ks) - 1:
                            da += x
                        KC[k] -= x
                        cong(P632, k, x)
        s.U, s.KC, s.P632, s.CHO, s.DDDAU, s.DDKC, s.TONGCHUNG = U, KC, P632, CHO, DDDAU, DDKC, TONGCHUNG
        s.TRUC, s.CHUNG = TRUC, CHUNG
        return U

    def kq(s, i, g, loai):
        if loai == 1:
            return sum(v for k, v in s.KC.items() if k[0] == i and k[1] == g)
        if loai == 2:
            return sum(v for k, v in s.P632.items() if k[0] == i and k[1] == g)
        if loai == 3:
            return s.TRUC.get((i, g), 0)
        if loai == 4:
            return s.CHUNG.get((i, g), 0)
        return s.DDDAU.get((i, g), 0)

    # ---------------------------------------------------------- GHI (mot phieu) - nhu FTPham Ghi + GhiXuatNVL khi bat
    def them_ct(s, **kv):
        s.ma_so_ct += 1
        r = dict(MaSo=s.ma_so_ct, MaTKNo=0, MaTKCo=0, MaTP=0, MaLoai=0, CT_ID=0)
        r.update(kv)
        s.ct.append(r)

    def ghi_phieu(s, mct, thang, dd=None, tk155=0):
        """dd: {g: chenh lech do dang cua phieu (ThanhPham - phan bo)} gia lap ThanhPhamDD."""
        cid = ID_PHIEU + mct
        xk = [r for r in s.ct if r.get("CT_ID") == cid and r.get("MaLoai") == 2]
        s.ct = [r for r in s.ct if r.get("CT_ID") != cid or r.get("MaLoai") == 2]      # xoa ket chuyen / 632 cu, giu xuat NVL
        s.tinh(thang)
        u = next(i for i, x in enumerate(s.U) if x["MaCT"] == mct)
        dong = [r for r in s.tp if r["MaCT"] == mct]
        ma154 = dong[0].get("Ma154") or 0
        # 632
        for (i, g, tk, tp), v in s.P632.items():
            if i == u and v:
                s.them_ct(ThangCT=thang, MaTKNo=-632, MaTKCo=tk, SoPS=v, MaTP=tp, MaLoai=3, CT_ID=cid)
        # ThanhPham = phan bo + chi phi thang truoc (+ do dang gia lap)
        cp = {g: s.kq(u, g, 1) + s.kq(u, g, 5) + (dd or {}).get(g, 0) for g in (1, 2, 3)}
        for g, cot in ((1, "CPNVL"), (2, "CPNC"), (3, "CPSXC")):
            for j, r in enumerate(dong):
                r[cot] = cp[g] if j == len(dong) - 1 else 0.0
        # No 155
        tong155 = rm(sum(cp.values()))
        s.them_ct(ThangCT=thang, MaTKNo=tk155 or -155, MaTKCo=0, SoPS=tong155, MaTP=ma154, MaLoai=1, CT_ID=cid)
        # Co tach (TK, MaTP nguon) + chenh lech -> TK mac dinh
        lines = collections.defaultdict(float)
        for (i, g, tk, tp), v in s.KC.items():
            if i == u:
                lines[(g, tk, tp)] += v
        for (i, g, tk, tp), v in s.DDKC.items():
            if i == u:
                lines[(g, tk, tp)] += v
        dich = dict(cp)
        for g in (1, 2, 3):
            eng = sum(v for (g2, tk, tp), v in lines.items() if g2 == g)
            cl = dich[g] - eng
            if abs(cl) >= 0.005:
                md = s.tk_mac_dinh(dong[0], g)
                assert md, "khong co TK mac dinh nhom %d" % g
                lines[(g, md, ma154)] += cl
        cl = tong155 - sum(lines.values())          # khop tong Co voi No 155 -> lech vao nhom lon nhat
        if tong155 and abs(cl) >= 0.005:
            g = 3
            for x in (1, 2, 3):
                if abs(dich[x]) > abs(dich[g]):
                    g = x
            lines[(g, s.tk_mac_dinh(dong[0], g), ma154)] += cl
        for (g, tk, tp), v in lines.items():
            if abs(v) >= 0.005:
                if v > 0:
                    s.them_ct(ThangCT=thang, MaTKNo=0, MaTKCo=tk, SoPS=v, MaTP=tp, MaLoai=1, CT_ID=cid)
                else:
                    s.them_ct(ThangCT=thang, MaTKNo=tk, MaTKCo=0, SoPS=-v, MaTP=tp, MaLoai=1, CT_ID=cid)
        return u, cp, xk

    def tk_mac_dinh(s, r, g):
        tk = r.get("MaTKCP") if g == 1 else (r.get("MaTKNC") if g == 2 else 0)
        if tk and s.tk.get(tk, ("", 1))[1] == 0 and s.sh(tk)[:4] == ("1541", "1542", "1543")[g - 1]:
            return tk
        la = [m for m, (x, con) in s.tk.items() if x.startswith(("1541", "1542", "1543")[g - 1]) and con == 0]
        return sorted(la, key=lambda m: s.sh(m))[0] if la else 0

    def ghi_lai_ca_nam(s, dd=None):
        thang = sorted({r["Thang"] for r in s.tp}, key=s.thu_tu)
        for t in thang:
            for mct in sorted({r["MaCT"] for r in s.tp if r["Thang"] == t}):
                s.ghi_phieu(mct, t, (dd or {}).get(mct))

    # ---------------------------------------------------------- so du theo (nhom, MaTP)
    def so_du(s, den_thang=None):
        d = collections.defaultdict(float)
        for r in s.ct:
            th = r.get("ThangCT") or 0
            if den_thang is not None and th and s.thu_tu(th) > s.thu_tu(den_thang):
                continue
            for ben, dau in (("MaTKNo", 1), ("MaTKCo", -1)):
                x = s.sh(r.get(ben))
                g = {"1541": 1, "1542": 2, "1543": 3}.get(x[:4], 0)
                if g:
                    tp = r.get("MaTP") or 0
                    d[(g, 0 if s.la_chung(tp) else tp)] += dau * (r.get("SoPS") or 0)
        return d


def in_so(duong):
    so = So.tu_mdb(duong)
    print("==", os.path.basename(duong))
    du0 = so.so_du()
    so.ghi_lai_ca_nam()
    du1 = so.so_du()
    ten = {0: "chung"}
    ten.update(so.tp154)
    for k in sorted(set(du0) | set(du1)):
        if abs(du0.get(k, 0)) > 1 or abs(du1.get(k, 0)) > 1:
            print("  154%d %-6s truoc %16s  sau %16s" % (k[0], ten.get(k[1], k[1]), format(int(du0.get(k, 0)), ","), format(int(du1.get(k, 0)), ",")))
    return so


if __name__ == "__main__":
    for p in sys.argv[1:]:
        in_so(p)
