# tai_hoa_don_theo_lo_doc_so.ps1 - doc CHI DOC (SELECT) cac so UNESCO XII de lap danh sach "tai hoa don theo lo".
# ASCII-only on purpose (PowerShell 5.1 reads BOM-less files as ANSI).
#   powershell -NoProfile -ExecutionPolicy Bypass -File tai_hoa_don_theo_lo_doc_so.ps1 -Server ".\SQLEXPRESS" -Out "C:\...\so_lieu.json" [-Databases "A_2026,B_2026"]
# Ket noi: tai khoan Windows dang chay, ApplicationIntent=ReadOnly; chi SELECT; khong ghi gi vao so.
# KHONG doc mat khau: tu HDDT_ThamSo chi lay dung 3 khoa HSK_MST, HSK_TenCty, HSK_HDDT_TenDN (khong bao gio HSK_*_MK).
# Ra (JSON, UTF-8): {"may_chu":..., "luc":..., "so":[{"so","mst","ten","nam","hsk_mst","hsk_ten","hsk_tendn","loi",
#   "thang":{"<thang>":{"e_mua","e_ban","td_mua","td_ban","bk_mua","bk_ban","bkk_mua","bkk_ban","vat_mua","vat_ban"}}}]}
# Ket thuc: 0 = da ghi; 2 = khong ket noi duoc may chu (dong cuoi la ly do).
param(
    [Parameter(Mandatory = $true)][string]$Out,
    [string]$Server = '.\SQLEXPRESS',
    [string]$Databases = ''
)
$ErrorActionPreference = 'Stop'

function New-Conn([string]$db) {
    $b = New-Object System.Data.SqlClient.SqlConnectionStringBuilder
    $b['Data Source'] = $Server
    $b['Initial Catalog'] = $db
    $b['Integrated Security'] = $true
    $b['ApplicationIntent'] = 'ReadOnly'
    $b['Connect Timeout'] = 15
    $b['Application Name'] = 'UNESCO XII tai hoa don theo lo (chi doc)'
    $c = New-Object System.Data.SqlClient.SqlConnection $b.ConnectionString
    $c.Open()
    return $c
}

function Get-Rows($cn, [string]$sql, $params) {
    $cmd = $cn.CreateCommand()
    $cmd.CommandTimeout = 300
    $cmd.CommandText = $sql
    if ($params) { foreach ($k in $params.Keys) { [void]$cmd.Parameters.AddWithValue($k, $params[$k]) } }
    $t = New-Object System.Data.DataTable
    $rd = $cmd.ExecuteReader()
    try { $t.Load($rd) } finally { $rd.Close() }
    return , $t
}

function Get-Scalar($cn, [string]$sql, $params) {
    $cmd = $cn.CreateCommand()
    $cmd.CommandTimeout = 120
    $cmd.CommandText = $sql
    if ($params) { foreach ($k in $params.Keys) { [void]$cmd.Parameters.AddWithValue($k, $params[$k]) } }
    return $cmd.ExecuteScalar()
}

function Has-Table($cn, [string]$name) {
    return [int](Get-Scalar $cn "SELECT COUNT(*) FROM sys.tables WHERE [name]=@n AND [schema_id]=SCHEMA_ID(N'dbo')" @{ '@n' = $name }) -eq 1
}

function Has-Column($cn, [string]$table, [string]$column) {
    return [int](Get-Scalar $cn "SELECT COUNT(*) FROM sys.columns WHERE [object_id]=OBJECT_ID(@t) AND [name]=@c" @{ '@t' = ('dbo.' + $table); '@c' = $column }) -eq 1
}

function Month-Slot($thang, [int]$m) {
    $k = [string]$m
    if (-not $thang.Contains($k)) {
        $thang[$k] = [ordered]@{ e_mua = 0; e_ban = 0; td_mua = 0; td_ban = 0; bk_mua = 0; bk_ban = 0; bkk_mua = 0; bkk_ban = 0; vat_mua = 0; vat_ban = 0 }
    }
    return $thang[$k]
}

function Read-Book([string]$db) {
    $o = [ordered]@{ so = $db; mst = ''; ten = ''; nam = 0; hsk_mst = ''; hsk_ten = ''; hsk_tendn = ''; loi = ''; thang = [ordered]@{} }
    $cn = $null
    try {
        $cn = New-Conn $db
        if (-not (Has-Table $cn 'License')) { $o.loi = 'khong phai so UNESCO (khong co bang License)'; return $o }
        $lic = Get-Rows $cn "SELECT TOP 1 ISNULL(CAST([MaSoThue] AS nvarchar(50)),N'') AS MST, ISNULL(CAST([TenCty] AS nvarchar(400)),N'') AS Ten, ISNULL([NamTC],0) AS Nam FROM dbo.License" $null
        if ($lic.Rows.Count -gt 0) {
            $o.mst = [string]$lic.Rows[0]['MST']; $o.ten = [string]$lic.Rows[0]['Ten']; $o.nam = [int]$lic.Rows[0]['Nam']
        }
        if (Has-Table $cn 'HDDT_ThamSo') {
            # chi 3 khoa nay - KHONG bao gio doc khoa mat khau HSK_*_MK
            $hs = Get-Rows $cn "SELECT [Khoa], CAST([GiaTri] AS nvarchar(400)) AS GiaTri FROM dbo.HDDT_ThamSo WHERE [Khoa] IN (N'HSK_MST', N'HSK_TenCty', N'HSK_HDDT_TenDN')" $null
            foreach ($r in $hs.Rows) {
                $v = if ($r['GiaTri'] -is [DBNull]) { '' } else { [string]$r['GiaTri'] }
                switch ([string]$r['Khoa']) { 'HSK_MST' { $o.hsk_mst = $v } 'HSK_TenCty' { $o.hsk_ten = $v } 'HSK_HDDT_TenDN' { $o.hsk_tendn = $v } }
            }
        }
        if (-not (Has-Table $cn 'HDDTTaiVe')) { $o.loi = 'so chua cai ha tang AI hoa don (HDDTTaiVe)'; return $o }
        $rec = if (Has-Column $cn 'HDDTTaiVe' 'AIRecordType') { " AND (e.[AIRecordType] IS NULL OR e.[AIRecordType] = N'INVOICE')" } else { '' }
        $sqlE = @"
SELECT x.Thang, x.BanRa, COUNT(*) AS N, SUM(CASE WHEN x.MST = N'' THEN 1 ELSE 0 END) AS TD FROM (
 SELECT e.[ThangCT] AS Thang, CASE WHEN ISNULL(e.[HDBanRa],0) = 1 THEN 1 ELSE 0 END AS BanRa,
        MAX(REPLACE(REPLACE(REPLACE(ISNULL(CASE WHEN ISNULL(e.[HDBanRa],0) = 1 THEN e.[MSTNguoiMua] ELSE e.[MSTNguoiBan] END, N''), N'-', N''), N' ', N''), N'.', N'')) AS MST
   FROM dbo.HDDTTaiVe e WHERE e.[ThangCT] BETWEEN 1 AND 12 $rec
  GROUP BY e.[ThangCT], CASE WHEN ISNULL(e.[HDBanRa],0) = 1 THEN 1 ELSE 0 END, LTRIM(RTRIM(ISNULL(e.[KyHieuHoaDon],N''))), LTRIM(RTRIM(ISNULL(e.[SoHoaDon],N'')))
) x GROUP BY x.Thang, x.BanRa
"@
        foreach ($r in (Get-Rows $cn $sqlE $null).Rows) {
            $s = Month-Slot $o.thang ([int]$r['Thang'])
            if ([int]$r['BanRa'] -eq 1) { $s.e_ban = [int]$r['N']; $s.td_ban = [int]$r['TD'] } else { $s.e_mua = [int]$r['N']; $s.td_mua = [int]$r['TD'] }
        }
        if ((Has-Table $cn 'HoaDon') -and $o.nam -gt 0) {
            $d0 = New-Object DateTime ($o.nam, 1, 1)
            $p = @{ '@D0' = $d0; '@D1' = $d0.AddYears(1) }
            $num = "TRY_CAST(REPLACE(REPLACE(LTRIM(RTRIM(h.[SoHD])), N'.', N''), N' ', N'') AS bigint)"
            $sqlB = "SELECT MONTH(h.[NgayPH]) AS Thang, CASE WHEN h.[Loai] = 1 THEN 1 ELSE 0 END AS BanRa, COUNT(DISTINCT LTRIM(RTRIM(ISNULL(h.[KyHieu],N''))) + N'|' + LTRIM(RTRIM(ISNULL(h.[SoHD],N'')))) AS N FROM dbo.HoaDon h WHERE h.[NgayPH] >= @D0 AND h.[NgayPH] < @D1 AND h.[Loai] IN (1,-1) GROUP BY MONTH(h.[NgayPH]), CASE WHEN h.[Loai] = 1 THEN 1 ELSE 0 END"
            foreach ($r in (Get-Rows $cn $sqlB $p).Rows) {
                $s = Month-Slot $o.thang ([int]$r['Thang'])
                if ([int]$r['BanRa'] -eq 1) { $s.bk_ban = [int]$r['N'] } else { $s.bk_mua = [int]$r['N'] }
            }
            # bang ke khong co HD dien tu cung chieu, cung so (thang lech <= 1) - cach doi chieu GON (khong xet MST, khong xet ngoai_hddt.txt)
            $sqlK = @"
SELECT MONTH(h.[NgayPH]) AS Thang, CASE WHEN h.[Loai] = 1 THEN 1 ELSE 0 END AS BanRa, COUNT(DISTINCT $num) AS N
  FROM dbo.HoaDon h WHERE h.[NgayPH] >= @D0 AND h.[NgayPH] < @D1 AND h.[Loai] IN (1,-1) AND $num IS NOT NULL
   AND NOT EXISTS (SELECT 1 FROM dbo.HDDTTaiVe x WHERE CASE WHEN ISNULL(x.[HDBanRa],0) = 1 THEN 1 ELSE 0 END = CASE WHEN h.[Loai] = 1 THEN 1 ELSE 0 END
                     AND x.[ThangCT] BETWEEN MONTH(h.[NgayPH]) - 1 AND MONTH(h.[NgayPH]) + 1
                     AND TRY_CAST(REPLACE(REPLACE(LTRIM(RTRIM(x.[SoHoaDon])), N'.', N''), N' ', N'') AS bigint) = $num)
 GROUP BY MONTH(h.[NgayPH]), CASE WHEN h.[Loai] = 1 THEN 1 ELSE 0 END
"@
            foreach ($r in (Get-Rows $cn $sqlK $p).Rows) {
                $s = Month-Slot $o.thang ([int]$r['Thang'])
                if ([int]$r['BanRa'] -eq 1) { $s.bkk_ban = [int]$r['N'] } else { $s.bkk_mua = [int]$r['N'] }
            }
        }
        if ((Has-Table $cn 'ChungTu') -and (Has-Table $cn 'HethongTK')) {
            $sqlV = @"
SELECT c.[ThangCT] AS Thang, SUM(CASE WHEN n.[MaSo] IS NULL THEN 0 ELSE 1 END) AS VM, SUM(CASE WHEN k.[MaSo] IS NULL THEN 0 ELSE 1 END) AS VB
  FROM dbo.ChungTu c
  LEFT JOIN (SELECT [MaSo] FROM dbo.HethongTK WHERE [SoHieu] LIKE N'133%') n ON n.[MaSo] = c.[MaTkNo]
  LEFT JOIN (SELECT [MaSo] FROM dbo.HethongTK WHERE [SoHieu] LIKE N'3331%') k ON k.[MaSo] = c.[MaTkCo]
 WHERE c.[ThangCT] BETWEEN 1 AND 12 GROUP BY c.[ThangCT]
"@
            foreach ($r in (Get-Rows $cn $sqlV $null).Rows) {
                $s = Month-Slot $o.thang ([int]$r['Thang'])
                $s.vat_mua = [int]$r['VM']; $s.vat_ban = [int]$r['VB']
            }
        }
    } catch {
        $o.loi = ('khong doc duoc: ' + $_.Exception.GetType().Name + ' ' + $_.Exception.Message)
        if ($o.loi.Length -gt 300) { $o.loi = $o.loi.Substring(0, 300) }
    } finally {
        if ($cn) { $cn.Close() }
    }
    return $o
}

try {
    $m = New-Conn 'master'
    $all = Get-Rows $m "SELECT [name] FROM sys.databases WHERE [database_id] > 4 AND [state] = 0 ORDER BY [name]" $null
    $m.Close()
} catch {
    Write-Output ('LOI: khong ket noi duoc may chu SQL ' + $Server + ' (' + $_.Exception.GetType().Name + ')')
    exit 2
}
$names = @()
foreach ($r in $all.Rows) { $names += [string]$r['name'] }
if ($Databases.Trim().Length -gt 0) {
    $want = @($Databases.Split(',') | ForEach-Object { $_.Trim() } | Where-Object { $_ -match '^[A-Za-z0-9_\-]{1,128}$' })
    $names = @($names | Where-Object { $want -contains $_ })
}
$books = @()
foreach ($n in $names) {
    $b = Read-Book $n
    if ($b.loi -like 'khong phai so UNESCO*' -and $Databases.Trim().Length -eq 0) { continue }
    $books += $b
}
$res = [ordered]@{ may_chu = $Server; luc = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'); so = $books }
$json = ConvertTo-Json $res -Depth 8 -Compress
$tmp = $Out + '.tmp'
[System.IO.File]::WriteAllText($tmp, $json, (New-Object System.Text.UTF8Encoding($false)))
if (Test-Path -LiteralPath $Out) { Remove-Item -LiteralPath $Out -Force }
Move-Item -LiteralPath $tmp -Destination $Out
Write-Output ('DA GHI ' + $books.Count + ' so')
exit 0
