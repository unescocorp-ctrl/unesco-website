# -*- coding: utf-8 -*-
"""GD234 - CONG G1 "DAY DU" (tram 1 quy trinh lien thong): moi hoa don CQT da thay phai co trong so.

Nguon doc lap:
  <thu muc khach>\\ds-cqt.txt        tool tai hoa don ghi moi lan tra cuu cong thue (danh sach CQT tra ve, khong loc)
                                     TAB: khoa, huong, kind, ngay(yyyy-mm-dd), tthai, tong_tt, khoa_goc, loai_lq, luc
  <thu muc khach>\\trang-thai-hd.txt phan mem ghi (HDDTTaiVe): khoa TAB 1 da hach toan / 0 co, chua / 2 khoa / 3 cho XML
  <thu muc khach>\\ket-qua\\hddt_*.jsonl chua co trong da-doc-ket-qua.txt  = dang cho nhap
  <thu muc khach>\\tong-hop-ban-le.json "tv"                                  = da nam trong chung tu tong hop ban le
Phan loai moi HD CQT trong ky: TRONG_SO | CHO_NHAP | TONG_HOP | HUY (bi huy - khong bat buoc) | THIEU.
K39 (LOI neu THIEU > 0; CANH_BAO neu thang trong ky chua tra cuu cong lan nao).
K40 cap thay the / dieu chinh: HD thay the (tthai 2) va HD goc (khoa_goc) CUNG da hach toan -> CANH_BAO
    (kiem but toan HD goc da huy / dieu chinh chua); HD thay the / dieu chinh co trong so ma HD goc khong co -> CANH_BAO.
"""
import io
import json
import os

TEP_DS = "ds-cqt.txt"
TEN_TT = {"1": "mới", "2": "thay thế", "3": "điều chỉnh", "4": "bị thay thế", "5": "bị điều chỉnh", "6": "bị hủy"}


def doc_ds_cqt(thu_muc):
    ds = {}
    d = os.path.join(thu_muc or "", TEP_DS)
    if not thu_muc or not os.path.exists(d):
        return ds
    with io.open(d, "r", encoding="utf-8-sig") as f:
        for dong in f:
            p = dong.rstrip("\r\n").split("\t")
            if len(p) >= 6 and p[0]:
                ds[p[0]] = {"khoa": p[0], "huong": p[1], "kind": p[2], "ngay": p[3], "tthai": p[4],
                            "tien": _so(p[5]), "goc": p[6] if len(p) > 6 else "", "loai_lq": p[7] if len(p) > 7 else "",
                            "ct": _so(p[9]) if len(p) > 10 else None, "thue": _so(p[10]) if len(p) > 10 else None}     # GD239
    return ds


def _so(x):
    try:
        return float(str(x).replace(",", ""))
    except Exception:
        return 0.0


def doc_trang_thai(thu_muc):
    kq = {}
    d = os.path.join(thu_muc or "", "trang-thai-hd.txt")
    if thu_muc and os.path.exists(d):
        with io.open(d, "r", encoding="utf-8-sig") as f:
            for dong in f:
                dong = dong.rstrip("\r\n")
                if "\t" in dong:
                    k, v = dong.rsplit("\t", 1)
                    if k.strip():
                        kq[k.strip()] = v.strip()
    return kq


def doc_cho_nhap(thu_muc):
    kq = set()
    if not thu_muc:
        return kq
    da = set()
    d = os.path.join(thu_muc, "da-doc-ket-qua.txt")
    if os.path.exists(d):
        with io.open(d, "r", encoding="utf-8-sig") as f:
            da = {x.strip() for x in f if x.strip()}
    kqd = os.path.join(thu_muc, "ket-qua")
    try:
        ten_ds = os.listdir(kqd)
    except Exception:
        return kq
    for ten in ten_ds:
        if not (ten.lower().startswith("hddt_") and ten.lower().endswith(".jsonl")) or ten in da:
            continue
        try:
            with io.open(os.path.join(kqd, ten), "r", encoding="utf-8") as f:
                for dong in f:
                    if '"khoa"' in dong:
                        j = json.loads(dong)
                        if not j.get("chi_kiem_tra"):
                            kq.add(j.get("khoa") or "")
                            if j.get("tv_th"):
                                kq.add(j.get("tv_th"))
        except Exception:
            pass
    return kq


def doc_tong_hop(thu_muc):
    d = os.path.join(thu_muc or "", "tong-hop-ban-le.json")
    try:
        with io.open(d, "r", encoding="utf-8-sig") as f:
            so = json.load(f)
        return set((so.get("tv") or {}).keys())
    except Exception:
        return set()


def thang_cua(ngay):
    try:
        return int(str(ngay)[5:7]), int(str(ngay)[:4])
    except Exception:
        return 0, 0


def phan_loai(thu_muc, thang_ky=None, nam_ky=None):
    """-> (theo_thang {(nam, thang): {loai: n}}, thieu [hd], cap [(loai, hd, goc, tt_hd, tt_goc)], co_ds)"""
    ds = doc_ds_cqt(thu_muc)
    tt = doc_trang_thai(thu_muc)
    cho = doc_cho_nhap(thu_muc)
    th = doc_tong_hop(thu_muc)
    theo, thieu, cap = {}, [], []
    for k, hd in ds.items():
        t, n = thang_cua(hd["ngay"])
        if thang_ky is not None and (n, t) not in thang_ky:
            continue
        if hd["tthai"] == "6":
            loai = "HUY"
        elif k in tt:
            loai = "TRONG_SO"
        elif k in cho:
            loai = "CHO_NHAP"
        elif k in th:
            loai = "TONG_HOP"
        else:
            loai = "THIEU"
            thieu.append(hd)
        theo.setdefault((n, t), {}).setdefault(loai, 0)
        theo[(n, t)][loai] += 1
        g = hd.get("goc") or ""
        if g and hd["tthai"] in ("2", "3") and loai == "TRONG_SO":
            if tt.get(k) == "1" and tt.get(g) == "1" and hd["tthai"] == "2":
                cap.append(("HAI_BEN", hd, g, tt.get(k), tt.get(g)))
            elif g not in tt and g not in cho and g not in th:
                cap.append(("THIEU_GOC", hd, g, tt.get(k), ""))
    return theo, thieu, cap, bool(ds)


def thang_trong_ky(S):
    """S cua kiem_khoa_so: t1..t2 thu tu nam TC, dau_ky, nam_tc (nam cua thang dau ky)."""
    kq = set()
    try:
        nam0 = int(S.dl.get("nam_tc") or 0)
    except Exception:
        nam0 = 0
    for t in range(S.t1, S.t2 + 1):
        th = (t + S.dau_ky - 2) % 12 + 1
        nam = nam0 + (1 if (S.dau_ky > 1 and th < S.dau_ky) else 0)
        kq.add((nam, th))
    return kq


def k_day_du(S, _kq, DAT, CANH_BAO, LOI, THONG_TIN):
    ten = "Hóa đơn trên cổng thuế đã có trong sổ (đủ hóa đơn)"
    ten2 = "Hóa đơn thay thế / điều chỉnh và hóa đơn gốc"
    thu_muc = str(S.dl.get("thu_muc_khach") or "")
    if not thu_muc:
        return [_kq("K39", ten, THONG_TIN, "Bản phần mềm chưa gửi thư mục khách (cần bản GĐ234).")]
    ky = thang_trong_ky(S)
    theo, thieu, cap, co_ds = phan_loai(thu_muc, ky)
    kq = []
    if not co_ds:
        kq.append(_kq("K39", ten, CANH_BAO, "Chưa có danh sách hóa đơn từ cổng thuế (tải hóa đơn bằng bản GĐ234 trở lên để có số đối chiếu)."))
    else:
        chua = sorted(x for x in ky if x not in theo)
        dong = [[n, t, v.get("TRONG_SO", 0), v.get("CHO_NHAP", 0), v.get("TONG_HOP", 0), v.get("HUY", 0), v.get("THIEU", 0)]
                for (n, t), v in sorted(theo.items())]
        cot = ["Năm", "Tháng", "Có trong sổ", "Chờ nhập", "Trong tổng hợp bán lẻ", "Bị hủy", "THIẾU"]
        if thieu:
            ct = [[h["ngay"], h["huong"], h["khoa"], TEN_TT.get(h["tthai"], h["tthai"]), h["tien"]] for h in sorted(thieu, key=lambda x: x["ngay"])]
            kq.append(_kq("K39", ten, LOI, "%d hóa đơn có trên cổng thuế nhưng KHÔNG có trong sổ, không chờ nhập, không trong tổng hợp bán lẻ: "
                          "nhập lại tệp kết quả hoặc tải lại các ngày đó. Danh sách ở cuối bảng." % len(thieu),
                          cot, dong + [["", "", "", "", "", "", ""]] + [[c[0], c[1], c[2], c[3], c[4], "", "THIẾU"] for c in ct]))
        elif chua:
            kq.append(_kq("K39", ten, CANH_BAO, "Các tháng %s chưa tra cứu cổng thuế lần nào: chưa đối chiếu được đủ hóa đơn." %
                          ", ".join("%02d/%d" % (t, n) for n, t in chua), cot, dong))
        else:
            kq.append(_kq("K39", ten, DAT, "Mọi hóa đơn cổng thuế (đã tra cứu) trong kỳ đều có trong sổ / chờ nhập / tổng hợp.", cot, dong))
    if cap:
        dong = [[("Cả hai đã hạch toán" if l == "HAI_BEN" else "Không có HĐ gốc trong sổ"), h["ngay"], h["khoa"],
                 TEN_TT.get(h["tthai"], h["tthai"]), g] for l, h, g, a, b in cap]
        kq.append(_kq("K40", ten2, CANH_BAO, "%d hóa đơn thay thế / điều chỉnh cần xem: thay thế mà HĐ gốc vẫn còn bút toán (nhân đôi), "
                      "hoặc điều chỉnh mà HĐ gốc chưa có trong sổ." % len(cap),
                      ["Tình huống", "Ngày", "HĐ thay thế / điều chỉnh", "Loại", "HĐ gốc"], dong))
    elif co_ds:
        kq.append(_kq("K40", ten2, DAT, "Không có cặp hóa đơn thay thế / điều chỉnh cần xem."))
    return kq


# ============================================================ GD239: CONG G8 "KHOP CHEO" - hoa don CQT <-> so <-> to khai
#   Ban ra: tong chua thue / thue cua HD cong (tru bi huy, bi thay the) trong ky  vs  Co 511 (khong ke ket chuyen) / Co 3331
#           vs thue dau ra theo cach tinh [35] (gtgt.thue_ra).
#   Mua vao: thue HD cong (tru bi huy, bi thay the)  vs  No 133  vs  [24] (gtgt.thue_vao). So > CQT = khau tru vuot hoa don -> LOI.
#   HD dieu chinh (tthai 3) co the mang dau giam - neu ky co HD dieu chinh, ket qua chi CANH_BAO va liet ke so HD dieu chinh.
DUNG_SAI_PT = 0.005
DUNG_SAI_TIEN = 10000.0


def tong_cqt(thu_muc, ky):
    """-> {huong: {"ct", "thue", "n", "n_dc", "thieu_so"}} cac HD cong trong ky (bo bi huy 6, bi thay the 4)."""
    kq = {h: {"ct": 0.0, "thue": 0.0, "n": 0, "n_dc": 0, "thieu_so": 0} for h in ("ban", "mua")}
    for k, hd in doc_ds_cqt(thu_muc).items():
        t, n = thang_cua(hd["ngay"])
        if (n, t) not in ky or hd["tthai"] in ("4", "6") or hd["huong"] not in kq:
            continue
        x = kq[hd["huong"]]
        if hd.get("ct") is None:
            x["thieu_so"] += 1
            continue
        x["ct"] += hd["ct"]
        x["thue"] += hd["thue"]
        x["n"] += 1
        if hd["tthai"] == "3":
            x["n_dc"] += 1
    return kq


def _lech(a, b):
    return abs(a - b) > max(DUNG_SAI_TIEN, DUNG_SAI_PT * max(abs(a), abs(b)))


def k_khop_cheo(S, _kq, DAT, CANH_BAO, LOI, THONG_TIN):
    ten = "Khớp chéo hóa đơn cổng thuế - sổ - tờ khai GTGT (cổng G8)"
    thu_muc = str(S.dl.get("thu_muc_khach") or "")
    if not thu_muc:
        return [_kq("K46", ten, THONG_TIN, "Bản phần mềm chưa gửi thư mục khách (cần bản GĐ234).")]
    ky = thang_trong_ky(S)
    c = tong_cqt(thu_muc, ky)
    if c["ban"]["n"] + c["mua"]["n"] == 0:
        return [_kq("K46", ten, THONG_TIN, "Chưa có tổng tiền hóa đơn cổng thuế trong kỳ (tải lại hóa đơn bằng bản GĐ239 để có số chưa thuế / thuế).")]
    g = S.dl.get("gtgt") or {}

    def ps(tt, ben):
        return sum(S.ps_ky(m, False)[ben] for m in S.la_theo(tt))
    dt_so = ps("511", 1) - ps("511", 0) if hasattr(S, "ps_ky") else 0.0
    ra_so = ps("3331", 1)
    vao_so = ps("133", 0)
    dong, muc = [], DAT
    b, m = c["ban"], c["mua"]
    rows = [("Bán ra - doanh thu chưa thuế", b["ct"], dt_so, None),
            ("Bán ra - thuế GTGT", b["thue"], ra_so, float(g.get("thue_ra") or 0)),
            ("Mua vào - thuế GTGT", m["thue"], vao_so, float(g.get("thue_vao") or 0))]
    for ten_d, cqt, so, tk in rows:
        nx = []
        if _lech(cqt, so):
            if ten_d.startswith("Mua") and so > cqt:
                nx.append("Nợ 133 LỚN HƠN thuế trên hóa đơn cổng thuế: khấu trừ vượt hóa đơn")
                muc = LOI
            else:
                nx.append("Sổ lệch hóa đơn cổng thuế %s" % "{:,.0f}".format(so - cqt).replace(",", "."))
                if muc != LOI:
                    muc = CANH_BAO
        if tk is not None and _lech(so, tk):
            nx.append("Sổ lệch số lên tờ khai %s" % "{:,.0f}".format(so - tk).replace(",", "."))
            if muc != LOI:
                muc = CANH_BAO
        dong.append([ten_d, round(cqt), round(so), "" if tk is None else round(tk), "; ".join(nx) or "khớp"])
    ghi = []
    if b["n_dc"] + m["n_dc"]:
        ghi.append("%d hóa đơn điều chỉnh trong kỳ (số tiền có thể mang dấu giảm - xem tay)" % (b["n_dc"] + m["n_dc"]))
        if muc == LOI:
            muc = CANH_BAO
    if b["thieu_so"] + m["thieu_so"]:
        ghi.append("%d hóa đơn tải bằng bản cũ chưa có số chưa thuế / thuế (không tính)" % (b["thieu_so"] + m["thieu_so"]))
    kl = {DAT: "Hóa đơn cổng thuế, sổ và số lên tờ khai khớp nhau.", CANH_BAO: "Có chênh lệch giữa hóa đơn cổng thuế, sổ và tờ khai - giải trình trước khi nộp.",
          LOI: "Khấu trừ thuế đầu vào lớn hơn thuế trên hóa đơn cổng thuế - sửa trước khi lập 01/GTGT."}[muc]
    return [_kq("K46", ten, muc, kl + ((" " + "; ".join(ghi) + ".") if ghi else ""),
                ["Chỉ tiêu", "Hóa đơn cổng thuế", "Sổ", "Tờ khai ([35] / [24])", "Nhận xét"], dong)]
