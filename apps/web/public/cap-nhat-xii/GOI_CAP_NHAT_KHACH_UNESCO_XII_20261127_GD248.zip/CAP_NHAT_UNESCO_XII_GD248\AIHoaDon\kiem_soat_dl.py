# -*- coding: utf-8 -*-
"""GD146 - EXCEL KIEM SOAT CONG NO & VAT TU (trung ma doi tuong / vat tu, cong no lech, nghi tra ho, am kho, TK khong nhat quan).

VB6 (ModKiemSoatDL.KSD_XuatExcel) tinh het roi ghi JSON:
    {"loai": "kiemsoat", "cty", "mst", "nam_tc", "lap_luc", "so_doi_tuong", "so_vat_tu", "thang_ton",
     "nhom": [{"stt", "loai": "KH"|"VT", "ly_do", "muc", "nguoc": bool, "bo_qua": bool,
               "ma": [{"ma", "ten", "mst" | "dvt", "so_ct", "du131", "du331" | "ton", "giu": bool}]}],
     "van_de": [{"loai", "ten_loai", "ma", "noi_dung", "so_lieu", "goi_y", "bo_qua": bool}]}
    tool_htkk_unesco.py /kiemsoat:<json> /ra:<xlsx>
Sheet TongHop, DoiTuongTrung, CongNo, VatTu (am kho), VatTuTrung, TaiKhoan. Chi doc - khong ghi so. JSON tam doc xong XOA."""
import datetime as _dt
import io
import json
import os

from xlsx_viet import SoExcel

PHIEN_BAN = "GD146"
LOAI_CN = ("TRAHO_131", "TRAHO_331", "CN_131CO", "CN_331NO", "HAI_BEN")
LOAI_VT = ("VT_AM",)
LOAI_TK = ("TK_DT", "TK_KHO", "TK_HANG")


def _so(v):
    try:
        return float(v or 0)
    except (TypeError, ValueError):
        return 0.0


def tinh(dl):
    """-> dict dem cho sheet TongHop (bo qua cac muc nguoi dung da danh dau khong phai loi)."""
    nhom = [g for g in (dl.get("nhom") or []) if not g.get("bo_qua")]
    vd = [v for v in (dl.get("van_de") or []) if not v.get("bo_qua")]
    kh = [g for g in nhom if g.get("loai") == "KH"]
    vt = [g for g in nhom if g.get("loai") == "VT"]

    def nhieu_ps(g):
        return sum(1 for m in (g.get("ma") or []) if int(m.get("so_ct") or 0) > 0) >= 2

    dem = {
        "nhom_kh": len(kh), "nhom_kh_ps": sum(1 for g in kh if nhieu_ps(g)), "nhom_kh_nguoc": sum(1 for g in kh if g.get("nguoc")),
        "nhom_vt": len(vt), "nhom_vt_ps": sum(1 for g in vt if nhieu_ps(g)), "nhom_vt_nguoc": sum(1 for g in vt if g.get("nguoc")),
        "bo_qua": sum(1 for g in (dl.get("nhom") or []) if g.get("bo_qua")) + sum(1 for v in (dl.get("van_de") or []) if v.get("bo_qua")),
    }
    for v in vd:
        dem[v.get("loai")] = dem.get(v.get("loai"), 0) + 1
    dem["bat_thuong"] = sum(1 for v in vd if str(v.get("loai") or "").startswith("BT_"))      # GD157
    return {"kh": kh, "vt": vt, "vd": vd, "dem": dem}


def lap(dl, ra):
    T = tinh(dl)
    d = T["dem"]
    wb = SoExcel(font="Times New Roman", co=11)
    k_td = wb.kieu(dam=True, co=14, can="giua", mau="0B3D91")
    k_dv = wb.kieu(dam=True)
    k_ghi = wb.kieu(nghieng=True, mau="555555", xuong=True, doc="tren")
    k_dau = wb.kieu(dam=True, nen="D9E1F2", khung=True, can="giua", xuong=True)
    k_nhom = wb.kieu(dam=True, nen="FFF2CC", khung=True, xuong=True)
    k_o = wb.kieu(khung=True, xuong=True, doc="tren")
    k_so = wb.kieu(khung=True, so="#,##0", doc="tren")
    k_sl = wb.kieu(khung=True, so="#,##0.###", doc="tren")
    k_giu = wb.kieu(khung=True, dam=True, mau="1E7B34", xuong=True, doc="tren")
    k_do = wb.kieu(khung=True, dam=True, mau="C00000", xuong=True, doc="tren")
    tieu = ("%s - MST %s" % (dl.get("cty") or "", dl.get("mst") or "")).strip(" -")

    # --- TongHop
    ws = wb.sheet("TongHop", cot=[58, 14])
    ws.gop(1, 1, 1, 2, tieu, k_dv)
    ws.gop(2, 1, 2, 2, "KIỂM SOÁT CÔNG NỢ VÀ VẬT TƯ - TRÙNG MÃ, LỆCH TÀI KHOẢN, TRẢ HỘ", k_td)
    ws.gop(3, 1, 3, 2, "Lập lúc %s. Đã rà %s đối tượng, %s vật tư (tồn kho tháng tài chính %s). Chỉ đọc sổ - không sửa số liệu. "
                       "Mục người dùng đã đánh dấu 'không phải lỗi' không tính (%d mục)."
           % (dl.get("lap_luc") or "", dl.get("so_doi_tuong") or 0, dl.get("so_vat_tu") or 0, dl.get("thang_ton") or 0, d["bo_qua"]), k_ghi)
    ws.cao(3, 46)
    ws.dong(5, 1, ["Nội dung", "Số"], k_dau)
    dong = [("Nhóm đối tượng (KH / NCC) trùng mã: cùng MST / cùng tên / cùng số TK ngân hàng", d["nhom_kh"]),
            ("  trong đó phát sinh ở từ 2 mã trở lên", d["nhom_kh_ps"]),
            ("  trong đó công nợ tách ở 2 mã (mã dư Nợ, mã dư Có)", d["nhom_kh_nguoc"]),
            ("Khách hàng dư Có 131", d.get("CN_131CO", 0)),
            ("Nhà cung cấp dư Nợ 331", d.get("CN_331NO", 0)),
            ("Nghi trả hộ / ghi nhầm mã (mã chỉ có tiền về hoặc chỉ có chi trả)", d.get("TRAHO_131", 0) + d.get("TRAHO_331", 0)),
            ("Đối tượng vừa 131 vừa 331 còn số dư", d.get("HAI_BEN", 0)),
            ("Nhóm vật tư trùng mã (cùng tên + ĐVT)", d["nhom_vt"]),
            ("  trong đó nhập mã này - xuất mã kia (mã âm kho, mã dư)", d["nhom_vt_nguoc"]),
            ("Vật tư âm kho", d.get("VT_AM", 0)),
            ("Cùng NCC + tên hàng hạch toán nhiều nhóm TK", d.get("TK_HANG", 0)),
            ("Đối tượng ở nhiều nhóm TK công nợ", d.get("TK_DT", 0)),
            ("Vật tư ở nhiều TK kho", d.get("TK_KHO", 0)),
            ("Bất thường số liệu KS8 - KS12 (thẻ 5 - nếu đã chạy)", d.get("bat_thuong", 0))]     # GD157
    r = 5
    for t, n in dong:
        r += 1
        ws.o(r, 1, t, k_o)
        ws.o(r, 2, n, k_so)
    r += 2
    for t in ["Cách xử lý: gộp mã trùng về một mã (mã giữ = mã dùng nhiều nhất, ưu tiên mã có MST); khác MST là pháp nhân khác - không gộp.",
              "Trả hộ: tiền phải ghi vào mã của người có nghĩa vụ trên hoá đơn; đã lỡ ghi mã khác thì sửa mã trên chứng từ thu / chi "
              "hoặc lập bút toán bù trừ có xác nhận ba bên.",
              "Vật tư: chỉ gộp khi cùng ĐVT; sau gộp tính lại tồn kho và giá xuất từ tháng sớm nhất có phát sinh."]:
        ws.gop(r, 1, r, 2, "- " + t, k_ghi)
        ws.cao(r, 32)
        r += 1

    # --- DoiTuongTrung
    w2 = wb.sheet("DoiTuongTrung", cot=[6, 14, 44, 16, 9, 16, 16, 20, 22])
    w2.gop(1, 1, 1, 9, "ĐỐI TƯỢNG (KHÁCH HÀNG / NHÀ CUNG CẤP) TRÙNG MÃ", k_td)
    w2.dong(3, 1, ["Nhóm", "Mã", "Tên", "MST", "Số CT", "Dư 131 (Nợ +)", "Dư 331 (Có +)", "Đề xuất", "Lý do / mức"], k_dau)
    r = 3
    for g in T["kh"]:
        r += 1
        w2.gop(r, 1, r, 9, "Nhóm %s - %s - %s%s" % (g.get("stt"), g.get("ly_do") or "", g.get("muc") or "",
                                                      " - CÔNG NỢ TÁCH Ở 2 MÃ" if g.get("nguoc") else ""), k_nhom)
        giu = next((m.get("ma") for m in (g.get("ma") or []) if m.get("giu")), "")
        for m in g.get("ma") or []:
            r += 1
            k = k_giu if m.get("giu") else k_o
            w2.o(r, 1, g.get("stt"), k_o)
            w2.dong(r, 2, [m.get("ma") or "", m.get("ten") or "", m.get("mst") or ""], k)
            w2.o(r, 5, int(m.get("so_ct") or 0), k_so)
            w2.o(r, 6, _so(m.get("du131")), k_so)
            w2.o(r, 7, -_so(m.get("du331")), k_so)
            w2.o(r, 8, "GIỮ" if m.get("giu") else "gộp vào %s" % giu, k)
            w2.o(r, 9, g.get("ly_do") or "", k_o)
    if not T["kh"]:
        w2.gop(4, 1, 4, 9, "Không phát hiện đối tượng trùng mã.", k_ghi)
    w2.dong_bang(4, 3)
    w2.in_trang(ngang=True, vua_rong=True, lap_dong=(3, 3))

    # --- CongNo / VatTu / TaiKhoan (van de le)
    def sheet_vd(ten, tieu_de, loai):
        w = wb.sheet(ten, cot=[18, 14, 60, 24, 60])
        w.gop(1, 1, 1, 5, tieu_de, k_td)
        w.dong(3, 1, ["Loại", "Mã", "Nội dung", "Số liệu", "Gợi ý xử lý"], k_dau)
        rr = 3
        for v in T["vd"]:
            if v.get("loai") not in loai:
                continue
            rr += 1
            k = k_do if v.get("loai") in ("TRAHO_131", "TRAHO_331", "VT_AM") else k_o
            w.dong(rr, 1, [v.get("ten_loai") or "", v.get("ma") or "", v.get("noi_dung") or "", v.get("so_lieu") or "", v.get("goi_y") or ""], k)
        if rr == 3:
            w.gop(4, 1, 4, 5, "Không phát hiện.", k_ghi)
        w.dong_bang(4, 3)
        w.in_trang(ngang=True, vua_rong=True, lap_dong=(3, 3))
        return w

    sheet_vd("CongNo", "CÔNG NỢ LỆCH - SAI BÊN - NGHI TRẢ HỘ / GHI NHẦM MÃ", LOAI_CN)
    sheet_vd("VatTu", "VẬT TƯ ÂM KHO", LOAI_VT)
    # nhom vat tu trung ma: sheet rieng VatTuTrung
    w5 = wb.sheet("VatTuTrung", cot=[6, 14, 44, 10, 9, 14, 20])
    w5.gop(1, 1, 1, 7, "VẬT TƯ TRÙNG MÃ (CÙNG TÊN + ĐVT)", k_td)
    w5.dong(3, 1, ["Nhóm", "Mã", "Tên vật tư", "ĐVT", "Số CT", "Tồn", "Đề xuất"], k_dau)
    r = 3
    for g in T["vt"]:
        r += 1
        w5.gop(r, 1, r, 7, "Nhóm %s - %s%s" % (g.get("stt"), g.get("muc") or "", " - NHẬP MÃ NÀY, XUẤT MÃ KIA" if g.get("nguoc") else ""), k_nhom)
        giu = next((m.get("ma") for m in (g.get("ma") or []) if m.get("giu")), "")
        for m in g.get("ma") or []:
            r += 1
            k = k_giu if m.get("giu") else k_o
            w5.o(r, 1, g.get("stt"), k_o)
            w5.dong(r, 2, [m.get("ma") or "", m.get("ten") or "", m.get("dvt") or ""], k)
            w5.o(r, 5, int(m.get("so_ct") or 0), k_so)
            ton = _so(m.get("ton"))
            w5.o(r, 6, ton, k_sl if ton >= 0 else wb.kieu(khung=True, so="#,##0.###", mau="C00000", dam=True))
            w5.o(r, 7, "GIỮ" if m.get("giu") else "gộp vào %s" % giu, k)
    if not T["vt"]:
        w5.gop(4, 1, 4, 7, "Không phát hiện vật tư trùng mã.", k_ghi)
    w5.dong_bang(4, 3)
    w5.in_trang(ngang=True, vua_rong=True, lap_dong=(3, 3))
    sheet_vd("TaiKhoan", "HẠCH TOÁN KHÔNG NHẤT QUÁN TÀI KHOẢN", LOAI_TK)
    loai_bt = tuple(sorted({v.get("loai") for v in (dl.get("van_de") or []) if str(v.get("loai") or "").startswith("BT_")}))
    if loai_bt:                                    # GD157: the Bat thuong so lieu da chay
        sheet_vd("BatThuong", "BẤT THƯỜNG SỐ LIỆU (KS8 - KS12)", loai_bt)
    os.makedirs(os.path.dirname(os.path.abspath(ra)), exist_ok=True)
    wb.luu(ra)
    return ra, T


def chay(duong_json, ra="", ghi_log=None):
    """-> (duong tep Excel, None) | (None, loi). JSON tam doc xong XOA."""
    log = ghi_log or (lambda s: None)
    try:
        with io.open(duong_json, "r", encoding="utf-8-sig") as f:
            dl = json.load(f)
    except Exception as e:
        return None, "Khong doc duoc so lieu kiem soat: %s" % e
    finally:
        try:
            os.remove(duong_json)
        except OSError:
            pass
    try:
        if not ra:
            ra = os.path.join(os.path.dirname(os.path.abspath(duong_json)), "KiemSoat_%s.xlsx" % _dt.datetime.now().strftime("%Y%m%d_%H%M%S"))
        tep, T = lap(dl, ra)
        log("[KIEM SOAT] %s: %d nhom doi tuong, %d nhom vat tu, %d van de" % (os.path.basename(tep), len(T["kh"]), len(T["vt"]), len(T["vd"])))
        return tep, None
    except Exception as e:
        import traceback
        log("[KIEM SOAT] loi: %s\n%s" % (e, traceback.format_exc()))
        return None, "Loi lap Excel kiem soat: %s" % e
