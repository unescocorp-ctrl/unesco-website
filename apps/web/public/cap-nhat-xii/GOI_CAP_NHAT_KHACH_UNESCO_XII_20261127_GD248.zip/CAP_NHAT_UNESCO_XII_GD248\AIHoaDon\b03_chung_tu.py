# -*- coding: utf-8 -*-
"""GD257 - B03 LUU CHUYEN TIEN TE (truc tiep) TINH TU CHUNG TU: moi dong tien (No / Co 111, 112, 113) xep vao ma B03 theo TK doi ung
   (dl["doi_ung"] = [MaTKNo, MaTKCo, thang, tien] - VB GD237). Khong dung so du luu san.
   K58: bang B03 tu chung tu + tu kiem [70] = tien cuoi ky (111 + 112 + 113), [60] = dau ky; luu b03_tu_chung_tu_<nam>_<t1>-<t2>.json
        vao thu muc cua so de bao_cao_nam so voi B03 cua dong co phan mem khi xuat BCTC (lech tung ma -> canh bao).
   Quy tac xep (TT133, phuong phap truc tiep) - THU (No tien, Co X) / CHI (Co tien, No Y) theo tien to TK doi ung, dong dau tien khop:
"""
import io
import json
import os

TIEN = ("111", "112", "113")
# (ma B03, cac tien to TK doi ung) - THU: Co X
THU = [(1, ("131", "511", "3331", "3387", "521")), (22, ("711", "211", "213", "217", "214", "2141", "2142")), (24, ("128", "1283", "221", "222", "228", "1288")),
       (25, ("515",)), (31, ("411", "4111")), (33, ("341", "3411", "311", "315", "336")), (6, ("",))]
# CHI: No Y
CHI = [(3, ("334", "3382", "3383", "3384", "3385", "3386", "3341", "3348")), (4, ("635", "335")), (5, ("3334",)),
       (21, ("211", "213", "217", "241", "2411", "2412", "2413")), (23, ("128", "1283", "221", "222", "228", "1288")),
       (32, ("411", "4111", "419")), (34, ("341", "3411", "311", "315", "336")), (35, ("421", "4211", "4212")),
       (2, ("331", "15", "133", "242", "621", "622", "627", "632", "641", "642", "627")),
       (7, ("",))]
TEN = {1: "Tiền thu từ bán hàng, cung cấp dịch vụ và doanh thu khác", 2: "Tiền chi trả cho người cung cấp hàng hóa, dịch vụ", 3: "Tiền chi trả cho người lao động",
       4: "Tiền lãi vay đã trả", 5: "Thuế thu nhập doanh nghiệp đã nộp", 6: "Tiền thu khác từ hoạt động kinh doanh", 7: "Tiền chi khác cho hoạt động kinh doanh",
       20: "Lưu chuyển tiền thuần từ hoạt động kinh doanh", 21: "Tiền chi mua sắm, xây dựng TSCĐ và tài sản dài hạn khác", 22: "Tiền thu thanh lý, nhượng bán TSCĐ",
       23: "Tiền chi cho vay, đầu tư góp vốn", 24: "Tiền thu hồi cho vay, đầu tư góp vốn", 25: "Tiền thu lãi cho vay, cổ tức, lợi nhuận được chia",
       30: "Lưu chuyển tiền thuần từ hoạt động đầu tư", 31: "Tiền thu từ phát hành cổ phiếu, nhận vốn góp", 32: "Tiền trả lại vốn góp", 33: "Tiền thu từ đi vay",
       34: "Tiền trả nợ gốc vay", 35: "Cổ tức, lợi nhuận đã trả", 40: "Lưu chuyển tiền thuần từ hoạt động tài chính", 50: "Lưu chuyển tiền thuần trong kỳ",
       60: "Tiền và tương đương tiền đầu kỳ", 61: "Ảnh hưởng thay đổi tỷ giá", 70: "Tiền và tương đương tiền cuối kỳ"}
CHI_MA = (2, 3, 4, 5, 7, 21, 23, 32, 34, 35)


def _ma(bang, sh):
    for ma, tt in bang:
        for t in tt:
            if t == "" or sh.startswith(t):
                return ma
    return bang[-1][0]


def _sh(S, m):
    return (S.tk.get(m) or {}).get("sh", "")


def tinh(S):
    """-> (b03 {ma: tien (chi am)}, chi_tiet [[ma, tk tien, tk doi ung, tien]], so dong bo qua)"""
    b = {m: 0.0 for m in TEN}
    ct = {}
    bo = 0
    for r in S.dl.get("doi_ung") or []:
        try:
            n, c, th, p = int(r[0]), int(r[1]), int(r[2]), float(r[3])
        except Exception:
            continue
        t = (th - S.dau_ky) % 12 + 1
        if not (S.t1 <= t <= S.t2):
            continue
        sn, sc = _sh(S, n), _sh(S, c)
        tn, tc = sn.startswith(TIEN), sc.startswith(TIEN)
        if tn and tc:
            bo += 1
            continue
        if tn:
            ma = _ma(THU, sc)
            key = (ma, sn, sc)
            ct[key] = ct.get(key, 0.0) + p
            b[ma] += p
        elif tc:
            ma = _ma(CHI, sn)
            key = (ma, sc, sn)
            ct[key] = ct.get(key, 0.0) + p
            b[ma] -= p
    b[20] = sum(b[m] for m in range(1, 8))
    b[30] = sum(b[m] for m in range(21, 26))
    b[40] = sum(b[m] for m in range(31, 36))
    b[50] = b[20] + b[30] + b[40]
    b[60] = sum(S.du_dau(m) for m in S.la_theo(*TIEN))
    b[61] = 0.0
    b[70] = b[50] + b[60] + b[61]
    chi_tiet = sorted([[k[0], k[1], k[2], round(v)] for k, v in ct.items()], key=lambda x: (x[0], -abs(x[3])))
    return b, chi_tiet, bo


def _tep(S):
    duong = S.dl.get("duong_so") or ""
    if not duong:
        return None
    try:
        import chinh_sach_so
        tm, _ = chinh_sach_so._thu_muc_ra(duong)
        return os.path.join(tm, "b03_tu_chung_tu_%s_%02d-%02d.json" % (S.dl.get("nam_tc") or "", S.t1, S.t2))
    except Exception:
        return None


def k_b03(S, _kq, DAT, CANH_BAO, LOI, THONG_TIN):
    ten = "B03 lưu chuyển tiền tệ (trực tiếp) tính từ chứng từ, khớp tiền cuối kỳ"
    if not S.dl.get("doi_ung"):
        return [_kq("K58", ten, THONG_TIN, "Chưa có số liệu đối ứng tài khoản (bản phần mềm cũ) - Make .exe bản mới rồi chạy lại.")]
    b, ct, bo = tinh(S)
    cuoi = sum(S.du_cuoi(m) for m in S.la_theo(*TIEN))
    dong = [[m, TEN[m], round(b[m]), ""] for m in (1, 2, 3, 4, 5, 6, 7, 20, 21, 22, 23, 24, 25, 30, 31, 32, 33, 34, 35, 40, 50, 60, 61, 70)]
    # TK doi ung chinh cua tung ma (toi da 3)
    for d in dong:
        tks = [c for c in ct if c[0] == d[0]][:3]
        d[3] = "; ".join("%s %s" % (c[2], "{:,.0f}".format(abs(c[3])).replace(",", ".")) for c in tks)
    tep = _tep(S)
    if tep:
        try:
            with io.open(tep, "w", encoding="utf-8") as f:
                json.dump({"nam": S.dl.get("nam_tc"), "t1": S.t1, "t2": S.t2, "b03": {str(k): round(v) for k, v in b.items()},
                           "chi_tiet": ct}, f, ensure_ascii=False)
        except Exception:
            pass
    lech = b[70] - cuoi
    kl = "Lưu chuyển thuần %s; [70] tiền cuối kỳ theo B03 %s, sổ %s" % (_d(b[50]), _d(b[70]), _d(cuoi))
    if abs(lech) > 1:
        return [_kq("K58", ten, LOI, kl + " - LỆCH %s: có chứng từ tiền không có TK đối ứng, TK 111/112 dư Có, hoặc chứng từ tiền ngoài [doi_ung]. %s" % (
            _d(lech), ("%d dòng chuyển tiền nội bộ 11x - 11x bỏ qua." % bo) if bo else ""), ["Mã", "Chỉ tiêu", "Số tiền", "TK đối ứng chính"], dong)]
    return [_kq("K58", ten, DAT, kl + " - khớp. Bảng B03 từ chứng từ đã lưu (%s) để so với B03 khi xuất BCTC. %d dòng chi tiết theo cặp TK." % (tep or "", len(ct)),
                ["Mã", "Chỉ tiêu", "Số tiền", "TK đối ứng chính"], dong)]


def _d(x):
    return "{:,.0f}".format(x).replace(",", ".")


def doc_da_luu(thu_muc, nam):
    """bao_cao_nam: doc B03 tu chung tu da luu (ky ca nam t1=1, t2=12) -> {ma int: tien} hoac None"""
    if not thu_muc or not os.path.isdir(thu_muc):
        return None
    for f_ in sorted(os.listdir(thu_muc)):
        if f_.startswith("b03_tu_chung_tu_%s_01-12" % nam) and f_.endswith(".json"):
            try:
                with io.open(os.path.join(thu_muc, f_), encoding="utf-8") as f:
                    d = json.load(f)
                return {int(k): v for k, v in (d.get("b03") or {}).items()}
            except Exception:
                return None
    return None
