# -*- coding: utf-8 -*-
"""GD171 - BO SO VA BAO CAO TAI CHINH DOANH NGHIEP SIEU NHO THEO THONG TU 58/2026/TT-BTC (hieu luc 01/7/2026, thay TT 132/2018) - CHI DOC SO.

Hop dong (xuat_1_lan.py): lap(dl, ma, kieu, thumuc) -> {"tep": [...], "canh_bao": [...]}; TEN_MAU = {ma: ten}. Ma bat dau "SS_58".
  dl = JSON Xuat 1 lan cua VB (nhu so_sach_mau: tk, ps, kh_dau / kh_no / kh_co, dt, nguoi_ky, x1l, dn, "ss": ct, vt, kho, tonkho,
       tk_nh, tsan / tsan_ts...; "ss"."tt58_pp" = phuong phap thue do nguoi dung chon: 5 / 6 / 7 / 8 (Dieu 5-8 TT58); rong -> tu nhan).
TT 58/2026 BO he thong tai khoan: ghi truc tiep vao so chi tiet. Phan mem van hach toan theo tai khoan (TT133 / TT99) va LAP cac so
TT58 tu chung tu + so du: moi so la mot cach XEM so ke toan theo mau TT58 (so lieu = so cua phan mem, tu doi chieu voi so du TK).
Bon truong hop (Dieu 5-8) -> so bat buoc:
  5: GTGT ty le % + TNDN ty le %            -> S1 (so doanh thu)
  6: GTGT ty le % + TNDN tren thu nhap      -> S2a (doanh thu), S2b (doanh thu - chi phi), S2c (vat lieu), S2d (tien)
  7: GTGT khau tru + TNDN ty le %           -> S3a (doanh thu), S3b (nghia vu thue GTGT)
  8: GTGT khau tru + TNDN tren thu nhap     -> S2b, S2c, S2d, S3b  (+ BCTC B01-DNSN, B02-DNSN nop CQT trong 90 ngay)
So tu chon (Dieu 9): S4a cong no, S4b TSCD, S4c nghia vu thue khac, S4d von chu so huu. Chung tu noi bo: 01-TT, 02-TT, 01-VT, 02-VT (da co).
B01-DNSN (13 chi tieu) / B02-DNSN (5 chi tieu): tu B01a / B02 TT133 cua dong co phan mem (bao_cao_nam.gia_tri_bctc) khi co, khong co
thi tu so du tai khoan; XML 58_BCTC (maTKhai 1280, XML 3.0.5, 2 sheet: 58_B01_01_THTC, 58_B01_02_SXKD) theo XSD HTKK 5.7.9.
Phan loai chi phi S2b theo YEU TO (a NVL, b luong - BH, c khau hao, d dich vu mua ngoai, đ lai vay, e chi khac) lay theo TK doi ung
cua dong chi phi (Co 15x / 334-338 / 214 / 331-11x-141 / 335-341...). Can cu cot so lieu ghi trong tung so."""
import datetime
import os
import xml.etree.ElementTree as ET
from collections import OrderedDict, defaultdict

import kiem_khoa_so as K
import so_sach_mau as SM
from xlsx_viet import SoExcel, dia_chi

GOC = os.path.dirname(os.path.abspath(__file__))
_so, lam_tron, dd = SM._so, SM.lam_tron, SM.dd

TEN_MAU = OrderedDict([
    ("SS_58S1", "TT58 - Sổ doanh thu bán hàng hoá, dịch vụ (S1 / S2a / S3a-DNSN)"),
    ("SS_58S2B", "TT58 - Sổ chi tiết doanh thu, chi phí (S2b-DNSN)"),
    ("SS_58S2C", "TT58 - Sổ chi tiết vật liệu, dụng cụ, sản phẩm, hàng hoá (S2c-DNSN)"),
    ("SS_58S2D", "TT58 - Sổ chi tiết tiền (S2d-DNSN)"),
    ("SS_58S3B", "TT58 - Sổ theo dõi nghĩa vụ thuế GTGT (S3b-DNSN)"),
    ("SS_58S4A", "TT58 - Sổ chi tiết thanh toán công nợ (S4a-DNSN)"),
    ("SS_58S4B", "TT58 - Sổ tài sản cố định (S4b-DNSN)"),
    ("SS_58S4C", "TT58 - Sổ theo dõi nghĩa vụ thuế khác (S4c-DNSN)"),
    ("SS_58S4D", "TT58 - Sổ theo dõi vốn chủ sở hữu (S4d-DNSN)"),
    ("SS_58B01", "TT58 - Báo cáo tình hình tài chính (B01-DNSN) + XML 58_BCTC"),
    ("SS_58B02", "TT58 - Báo cáo kết quả hoạt động kinh doanh (B02-DNSN) + XML 58_BCTC"),
])
TEP = {"SS_58S1": "TT58_S1_SoDoanhThu", "SS_58S2B": "TT58_S2b_DoanhThuChiPhi", "SS_58S2C": "TT58_S2c_VatLieuHangHoa",
       "SS_58S2D": "TT58_S2d_SoChiTietTien", "SS_58S3B": "TT58_S3b_ThueGTGT", "SS_58S4A": "TT58_S4a_CongNo",
       "SS_58S4B": "TT58_S4b_TaiSanCoDinh", "SS_58S4C": "TT58_S4c_ThueKhac", "SS_58S4D": "TT58_S4d_VonChuSoHuu",
       "SS_58B01": "TT58_B01_DNSN", "SS_58B02": "TT58_B02_DNSN"}
CAN_CU = "(Kèm theo Thông tư số 58/2026/TT-BTC ngày 25 tháng 5 năm 2026 của Bộ trưởng Bộ Tài chính)"
PP_TEN = {"5": "Điều 5 - thuế GTGT và thuế TNDN đều nộp theo tỷ lệ % trên doanh thu",
          "6": "Điều 6 - thuế GTGT theo tỷ lệ % trên doanh thu, thuế TNDN trên thu nhập tính thuế",
          "7": "Điều 7 - thuế GTGT theo phương pháp khấu trừ, thuế TNDN theo tỷ lệ % trên doanh thu",
          "8": "Điều 8 - thuế GTGT theo phương pháp khấu trừ, thuế TNDN trên thu nhập tính thuế"}
PP_SO = {"5": ["SS_58S1"], "6": ["SS_58S1", "SS_58S2B", "SS_58S2C", "SS_58S2D"], "7": ["SS_58S1", "SS_58S3B"],
         "8": ["SS_58S2B", "SS_58S2C", "SS_58S2D", "SS_58S3B", "SS_58B01", "SS_58B02"]}
B01_DONG = [("TÀI SẢN", None, "td"), ("1. Tiền", 110, ""), ("2. Các khoản nợ phải thu", 120, ""), ("3. Hàng tồn kho", 130, ""),
            ("4. Tài sản cố định", 140, ""), ("5. Tài sản khác", 150, ""), ("TỔNG CỘNG TÀI SẢN (200=110+120+130+140+150)", 200, "t"),
            ("NGUỒN VỐN", None, "td"), ("I. Nợ phải trả", 300, "d"), ("1. Các khoản nợ phải trả", 310, ""),
            ("2. Thuế và các khoản phải nộp Nhà nước", 320, ""), ("II. Vốn chủ sở hữu", 400, "d"),
            ("1. Vốn đầu tư của chủ sở hữu", 410, ""), ("2. Lợi nhuận sau thuế chưa phân phối", 420, ""),
            ("3. Các quỹ thuộc vốn chủ sở hữu", 430, ""), ("TỔNG CỘNG NGUỒN VỐN (500=300+400)", 500, "t")]
B01_MA = [110, 120, 130, 140, 150, 200, 300, 310, 320, 400, 410, 420, 430, 500]
B02_DONG = [("1. Doanh thu và thu nhập thuần", "01"), ("2. Các khoản chi phí", "02"),
            ("3. Lợi nhuận kế toán trước thuế TNDN {(03)= (01)- (02)}", "03"), ("4. Chi phí thuế TNDN", "10"),
            ("5. Lợi nhuận sau thuế TNDN {(20) = (03)-(10)}", "20")]
B02_MA = ["01", "02", "03", "10", "20"]
F_TIEN, F_SL, F_DG, F_NGAY, F_PT = SM.F_TIEN, SM.F_SL, '#,##0.00;(#,##0.00);"-"', SM.F_NGAY, '0.##"%"'


# ============================================================ so lieu / phuong phap thue
def so_lieu(dl):
    return SM.so_lieu(dl)


def phuong_phap(S):
    """'5'..'8' tu ss.tt58_pp; rong -> tu nhan tu so: GTGT khau tru khi co phat sinh 133 / 3331; TNDN tren thu nhap khi co 821 / 3334 / 911."""
    pp = str((S.ss or {}).get("tt58_pp") or "").strip()
    if pp in PP_TEN:
        return pp, True
    kt = any(abs(S.ps_ky(m, True)[0]) + abs(S.ps_ky(m, True)[1]) > 0.5 for m in S.la_theo("133", "3331"))
    tn = any(abs(S.ps_ky(m, True)[0]) + abs(S.ps_ky(m, True)[1]) > 0.5 for m in S.la_theo("821", "3334", "911"))
    return ("8" if tn else "7") if kt else ("6" if tn else "5"), False


# ============================================================ ve bieu TT58
class Bieu(object):
    def __init__(self, S, ma):
        self.S, self.ma = S, ma
        self.wb = SoExcel(font="Times New Roman", co=11)
        w = self.wb
        self.k_td = w.kieu(dam=True, co=14, can="giua")
        self.k_dam = w.kieu(dam=True)
        self.k_dam_giua = w.kieu(dam=True, can="giua")
        self.k_dam_phai = w.kieu(dam=True, can="phai")
        self.k_thuong = w.kieu()
        self.k_giua = w.kieu(can="giua")
        self.k_nghieng = w.kieu(nghieng=True, co=10, can="giua", xuong=True)
        self.k_nghieng_trai = w.kieu(nghieng=True, co=10, xuong=True)
        self.k_dau = w.kieu(dam=True, co=10, can="giua", xuong=True, khung=True, nen="D9E1F2")
        self.k_so_cot = w.kieu(nghieng=True, co=9, can="giua", khung=True, nen="F2F2F2")
        self.k_o = w.kieu(khung=True, xuong=True, co=10)
        self.k_o_giua = w.kieu(khung=True, can="giua", co=10)
        self.k_o_so = w.kieu(khung=True, so=F_TIEN, co=10)
        self.k_o_sl = w.kieu(khung=True, so=F_SL, co=10)
        self.k_o_dg = w.kieu(khung=True, so=F_DG, co=10)
        self.k_o_ngay = w.kieu(khung=True, so=F_NGAY, can="giua", co=10)
        self.k_o_pt = w.kieu(khung=True, so=F_PT, can="giua", co=10, nen="FFF9C4")
        self.k_nhom = w.kieu(khung=True, dam=True, co=10, nen="EEF5E9")
        self.k_nhom_so = w.kieu(khung=True, dam=True, so=F_TIEN, co=10, nen="EEF5E9")
        self.k_cong = w.kieu(khung=True, dam=True, co=10, nen="FFF2CC")
        self.k_cong_so = w.kieu(khung=True, dam=True, so=F_TIEN, co=10, nen="FFF2CC")
        self.k_cong_sl = w.kieu(khung=True, dam=True, so=F_SL, co=10, nen="FFF2CC")
        self.k_chu_ky = w.kieu(dam=True, can="giua")
        self.k_chu_ky2 = w.kieu(nghieng=True, co=10, can="giua")

    def sheet(self, ten, cot):
        ws = self.wb.sheet(ten[:31], cot=cot)
        return ws

    def dau(self, ws, mau_so, tieu_de, nc, phu=None, ky=None):
        S = self.S
        th = S.thay()
        ws.gop(1, 1, 1, max(3, nc // 2), th["TEN_DV"].upper(), self.k_dam)
        ws.gop(2, 1, 2, max(3, nc // 2), th["DIA_CHI"], self.k_thuong)
        ws.gop(1, max(4, nc // 2 + 1), 1, nc, "Mẫu số " + mau_so, self.k_dam_giua)
        ws.gop(2, max(4, nc // 2 + 1), 3, nc, CAN_CU, self.k_nghieng)
        ws.gop(5, 1, 5, nc, tieu_de, self.k_td)
        r = 6
        if phu:
            ws.gop(r, 1, r, nc, phu, self.k_giua)
            r += 1
        ws.gop(r, 1, r, nc, (ky or th["KY_HOA_TT"]) + "          Đơn vị tính: Đồng Việt Nam", self.k_giua)
        return r + 2

    def tieu_de_cot(self, ws, r, cot, ma_cot=None, cao=40):
        """cot: [(tieu de, c1, c2, r_them)] gop o; ma_cot: [(ma, c)] dong ky hieu cot (A, B, C, 1, 2...)."""
        for td, c1, c2, rt in cot:
            ws.gop(r, c1, r + rt, c2, td, self.k_dau)
        ws.cao(r, cao)
        n = max(x[3] for x in cot) + 1
        if ma_cot:
            for ma, c in ma_cot:
                ws.o(r + n, c, ma, self.k_so_cot)
            n += 1
        return r + n

    def cuoi(self, ws, r, nc, co_ktt=True):
        S = self.S
        nk = S.nguoi_ky
        g1, g2 = 3, max(3, nc // 2)
        c3 = max(g2 + 1, 4)
        ws.gop(r, c3, r, nc, S.noi_ngay(S.ngay_lap), self.k_nghieng)
        r += 1
        ws.gop(r, 1, r, 2, "NGƯỜI LẬP BIỂU", self.k_chu_ky)
        ws.gop(r + 1, 1, r + 1, 2, "(Ký, ghi rõ họ tên)", self.k_chu_ky2)
        ws.gop(r + 5, 1, r + 5, 2, nk.get("nguoi_lap", ""), self.k_chu_ky)
        if co_ktt:
            ws.gop(r, g1, r, g2, "KẾ TOÁN TRƯỞNG", self.k_chu_ky)
            ws.gop(r + 1, g1, r + 1, g2, "(Ký, ghi rõ họ tên)", self.k_chu_ky2)
            ws.gop(r + 5, g1, r + 5, g2, nk.get("ke_toan_truong", ""), self.k_chu_ky)
        ws.gop(r, c3, r, nc, "NGƯỜI ĐẠI DIỆN THEO PHÁP LUẬT", self.k_chu_ky)
        ws.gop(r + 1, c3, r + 1, nc, "(Ký, ghi rõ họ tên, đóng dấu)", self.k_chu_ky2)
        ws.gop(r + 5, c3, r + 5, nc, nk.get("giam_doc", ""), self.k_chu_ky)
        return r + 7

    def ghi_chu(self, ws, r, nc, chu):
        ws.gop(r, 1, r, nc, chu, self.k_nghieng_trai)
        ws.cao(r, 15 * max(1, (len(chu) // 110) + 1))
        return r + 1

    def luu(self, thumuc):
        S = self.S
        ten = TEP[self.ma] + "_%d" % S.nam + ("" if S.ca_nam else "_T%02d-%02d" % (S.thang_lich(S.t1)[0], S.thang_lich(S.t2)[0]))
        p = os.path.join(thumuc, ten + ".xlsx")
        self.wb.luu(p)
        return p


class Kiem(SM.Kiem):
    pass


_sh_cache = {}
_kc_mact = set()


def _khong_kc(d):
    """dong KHONG thuoc chung tu ket chuyen: nhu VB (ModHDDTHTKK / ModBCQuanTri) danh dau theo CHUNG TU co dong TK 911* (ca khi nhap mot ben)."""
    return d.mact not in _kc_mact


def _nap_sh(S):
    _sh_cache.clear()
    for m in S.tk:
        _sh_cache[m] = S.sh(m)
    _kc_mact.clear()
    for d in S.ct:
        if _sh_cache.get(d.no, "").startswith("911") or _sh_cache.get(d.co, "").startswith("911"):
            _kc_mact.add(d.mact)


def _la(S, *tien_to):
    return set(S.la_theo(*tien_to))


# ============================================================ S1 / S2a / S3a: so doanh thu
def lap_s1(S, pp):
    _nap_sh(S)
    ma = {"5": "S1-DNSN", "6": "S2a-DNSN", "7": "S3a-DNSN", "8": "S3a-DNSN"}[pp]
    B, KT = Bieu(S, "SS_58S1"), Kiem("SS_58S1")
    co_gtgt, co_tndn = pp in ("5", "6"), pp in ("5", "7")          # Dieu 8: TNDN tren thu nhap tinh thue -> khong tinh theo ty le o so nay
    cot = [5, 12, 11, 46, 18, 16]
    ws = B.sheet("So doanh thu", cot)
    nc = 5
    r = B.dau(ws, ma, "SỔ DOANH THU BÁN HÀNG HOÁ, DỊCH VỤ", nc, "(%s)" % PP_TEN[pp])
    r = B.tieu_de_cot(ws, r, [("Hoá đơn, chứng từ", 1, 2, 0), ("Diễn giải", 3, 3, 1), ("Số tiền", 4, 4, 1), ("Ghi chú", 5, 5, 1)], None, 30)
    ws.o(r - 1, 1, "Số hiệu", B.k_dau)
    ws.o(r - 1, 2, "Ngày, tháng", B.k_dau)
    for ma_c, c in (("A", 1), ("B", 2), ("C", 3), ("1", 4), ("D", 5)):
        ws.o(r, c, ma_c, B.k_so_cot)
    r += 1
    la511 = _la(S, "511", "512")
    nhom = OrderedDict()
    for d in S.ct:
        if d.co in la511 and _khong_kc(d):
            nhom.setdefault(d.co, []).append((d, d.tien))
        elif d.no in la511 and _khong_kc(d):
            nhom.setdefault(d.no, []).append((d, -d.tien))          # giam tru / hang ban tra lai
    o_thue = []                                                      # (hang tong, hang ty le, hang thue) de cong cuoi
    tong_dt = 0.0
    stt = 0
    for tk in sorted(nhom, key=lambda m: S.sh(m)):
        stt += 1
        ws.gop(r, 1, r, 3, "%d. %s (TK %s)" % (stt, S.ten_tk(tk), S.sh(tk)), B.k_nhom)
        ws.o(r, 4, None, B.k_nhom_so)
        ws.o(r, 5, None, B.k_nhom)
        r += 1
        r0 = r
        tong = 0.0
        for d, tien in nhom[tk]:
            ws.o(r, 1, d.sh, B.k_o_giua)
            ws.o(r, 2, d.ngay, B.k_o_ngay)
            ws.o(r, 3, d.dg, B.k_o)
            ws.o(r, 4, tien, B.k_o_so)
            ws.o(r, 5, ("Giảm trừ / trả lại" if tien < 0 else ""), B.k_o)
            tong += tien
            r += 1
        ws.gop(r, 1, r, 3, "Tổng cộng (%d)" % stt, B.k_cong)
        ws.o(r, 4, "=SUM(%s)" % ("%s:%s" % (dia_chi(r0, 4), dia_chi(r - 1, 4))) if r > r0 else 0, B.k_cong_so)
        ws.o(r, 5, None, B.k_cong)
        r_tong = r
        r += 1
        tong_dt += tong
        for nhan, co in (("Thuế GTGT", co_gtgt), ("Thuế TNDN", co_tndn)):
            if not co:
                continue
            ws.gop(r, 1, r, 3, "%s (tỷ lệ %% trên doanh thu - điền ở cột Ghi chú)" % nhan, B.k_o)
            ws.o(r, 4, "=ROUND(%s*%s/100,0)" % (dia_chi(r_tong, 4), dia_chi(r, 5)), B.k_o_so)
            ws.o(r, 5, None, B.k_o_pt)
            o_thue.append((nhan, r))
            r += 1
    if not nhom:
        ws.gop(r, 1, r, 5, "(kỳ này không có doanh thu bán hàng hoá, dịch vụ trên TK 511)", B.k_o)
        r += 1
    r += 1
    for nhan in (("Thuế GTGT",) if co_gtgt else ()) + (("Thuế TNDN",) if co_tndn else ()):
        ds = [dia_chi(x, 4) for n, x in o_thue if n == nhan]
        ws.gop(r, 1, r, 3, "Tổng số %s phải nộp trong kỳ" % nhan.replace("Thuế", "thuế"), B.k_cong)
        ws.o(r, 4, ("=" + "+".join(ds)) if ds else 0, B.k_cong_so)
        ws.o(r, 5, None, B.k_cong)
        r += 1
    r += 1
    r = B.ghi_chu(ws, r, nc, "Cột 1 ghi doanh thu theo từng nhóm hàng hoá, dịch vụ có cùng tỷ lệ %% thuế (phần mềm nhóm theo tài khoản doanh thu); "
                             "ô vàng cột Ghi chú: điền tỷ lệ %% thuế GTGT / TNDN của nhóm (Luật Thuế GTGT, Luật Thuế TNDN - theo ngành), "
                             "số thuế tự tính. Số liệu lấy từ phát sinh Có TK 511 (giảm trừ ghi âm), không gồm kết chuyển. %s" % (
                                 "" if ma != "S3a-DNSN" else "Thuế GTGT theo khấu trừ xem Sổ theo dõi nghĩa vụ thuế GTGT (S3b)%s." % (
                                     "; thuế TNDN trên thu nhập tính thuế xem S2b và tờ khai 03/TNDN" if pp == "8" else "")))
    B.cuoi(ws, r + 1, nc)
    ps = sum(S.ps_ky(m, False)[1] - S.ps_ky(m, False)[0] for m in la511)
    KT.them("Tổng doanh thu trên sổ = phát sinh Có - Nợ TK 511 (không kể kết chuyển)", tong_dt, ps)
    return B, KT.canh_bao()


# ============================================================ S2b: doanh thu - chi phi - thue TNDN
NHOM_CP = [("a", "Chi phí nguyên liệu, vật liệu, hàng hoá"), ("b", "Chi phí tiền lương và các khoản bảo hiểm"),
           ("c", "Chi phí khấu hao tài sản cố định"), ("d", "Chi phí dịch vụ mua ngoài"), ("đ", "Chi phí lãi tiền vay"),
           ("e", "Các khoản chi khác phục vụ trực tiếp sản xuất, kinh doanh")]


def _nhom_cp(S, d):
    """dong No TK chi phi: nhom theo TK doi ung (Co)."""
    sn, sc = S.sh(d.no), S.sh(d.co)
    if sn.startswith("635") or sc.startswith(("335", "341")):
        return "đ"
    if sc.startswith(("151", "152", "153", "155", "156", "157", "158", "611", "154", "242", "621", "6272", "6273")):
        return "a"
    if sc.startswith(("334", "338", "622", "6271")):
        return "b"
    if sc.startswith(("214", "6274")):
        return "c"
    if sc.startswith(("331", "111", "112", "141", "6277")):
        return "d"
    return "e"


def _nhom_cp_co(S, d):
    """dong Co TK chi phi (ket chuyen 62x -> 154, hoan nhap...): nhom theo ban chat cua chinh TK chi phi duoc ghi Co."""
    sc = S.sh(d.co)
    if sc.startswith(("621", "6272", "6273")):
        return "a"
    if sc.startswith(("622", "6271")):
        return "b"
    if sc.startswith("6274"):
        return "c"
    if sc.startswith(("6277", "6278")):
        return "d"
    if sc.startswith("635"):
        return "đ"
    return _nhom_cp(S, d) if not sc.startswith(("627", "641", "642", "811")) else "e"


def lap_s2b(S, pp):
    _nap_sh(S)
    B, KT = Bieu(S, "SS_58S2B"), Kiem("SS_58S2B")
    cot = [5, 12, 11, 50, 18, 18]
    ws = B.sheet("S2b", cot)
    nc = 5
    r = B.dau(ws, "S2b-DNSN", "SỔ CHI TIẾT DOANH THU, CHI PHÍ", nc)
    r = B.tieu_de_cot(ws, r, [("Hoá đơn, chứng từ", 1, 2, 0), ("Diễn giải", 3, 3, 1), ("Số tiền", 4, 4, 1), ("TK đối ứng", 5, 5, 1)], None, 30)
    ws.o(r - 1, 1, "Số hiệu", B.k_dau)
    ws.o(r - 1, 2, "Ngày, tháng", B.k_dau)
    for ma_c, c in (("A", 1), ("B", 2), ("C", 3), ("1", 4), ("D", 5)):
        ws.o(r, c, ma_c, B.k_so_cot)
    r += 1
    la3334 = _la(S, "3334")
    dau = -sum(S.du_dau(m) for m in la3334)
    ws.gop(r, 1, r, 3, "Số thuế TNDN còn phải nộp đầu kỳ (dư Có TK 3334)", B.k_nhom)
    ws.o(r, 4, dau, B.k_nhom_so)
    ws.o(r, 5, None, B.k_nhom)
    r_dau = r
    r += 1
    la_dt = _la(S, "511", "512", "515", "711")
    la_cp = {m for m in _la(S, "6", "8") if not S.sh(m).startswith(("821", "611"))}      # 611 (KKDK) khong phai chi phi
    dt, cp = [], defaultdict(list)
    for d in S.ct:
        if not _khong_kc(d):
            continue
        if d.co in la_dt:
            dt.append((d, d.tien))
        elif d.no in la_dt and d.co not in la_dt:
            dt.append((d, -d.tien))
        if d.no in la_cp and d.co not in la_cp:
            cp[_nhom_cp(S, d)].append((d, d.tien))
        elif d.co in la_cp and d.no not in la_cp:
            cp[_nhom_cp_co(S, d)].append((d, -d.tien))
    ws.gop(r, 1, r, 5, "Số phát sinh trong kỳ", B.k_nhom)
    r += 1
    ws.gop(r, 1, r, 3, "(1) Doanh thu và thu nhập", B.k_nhom)
    r_dt = r
    ws.o(r, 5, None, B.k_nhom)
    r += 1
    r0 = r
    for d, tien in dt:
        ws.o(r, 1, d.sh, B.k_o_giua)
        ws.o(r, 2, d.ngay, B.k_o_ngay)
        ws.o(r, 3, d.dg, B.k_o)
        ws.o(r, 4, tien, B.k_o_so)
        ws.o(r, 5, "%s / %s" % (S.sh(d.no), S.sh(d.co)), B.k_o_giua)
        r += 1
    ws.o(r_dt, 4, ("=SUM(%s:%s)" % (dia_chi(r0, 4), dia_chi(r - 1, 4))) if r > r0 else 0, B.k_nhom_so)
    tong_dt = sum(t for _, t in dt)
    ws.gop(r, 1, r, 3, "(2) Chi phí", B.k_nhom)
    r_cp = r
    ws.o(r, 5, None, B.k_nhom)
    r += 1
    o_nhom = []
    tong_cp = 0.0
    for ma_n, ten_n in NHOM_CP:
        ds = cp.get(ma_n) or []
        ws.gop(r, 1, r, 3, "%s) %s" % (ma_n, ten_n), B.k_cong)
        rn = r
        ws.o(r, 5, None, B.k_cong)
        r += 1
        r1 = r
        for d, tien in ds:
            ws.o(r, 1, d.sh, B.k_o_giua)
            ws.o(r, 2, d.ngay, B.k_o_ngay)
            ws.o(r, 3, d.dg, B.k_o)
            ws.o(r, 4, tien, B.k_o_so)
            ws.o(r, 5, "%s / %s" % (S.sh(d.no), S.sh(d.co)), B.k_o_giua)
            r += 1
        ws.o(rn, 4, ("=SUM(%s:%s)" % (dia_chi(r1, 4), dia_chi(r - 1, 4))) if r > r1 else 0, B.k_cong_so)
        o_nhom.append(dia_chi(rn, 4))
        tong_cp += sum(t for _, t in ds)
    ws.o(r_cp, 4, "=" + "+".join(o_nhom), B.k_nhom_so)
    ps_nop = sum(S.ps_ky(m, False)[1] for m in la3334)
    da_nop = sum(S.ps_ky(m, False)[0] for m in la3334)
    ws.gop(r, 1, r, 3, "Tổng số thuế TNDN phải nộp trong kỳ (phát sinh Có TK 3334)", B.k_nhom)
    ws.o(r, 4, ps_nop, B.k_nhom_so)
    ws.o(r, 5, None, B.k_nhom)
    r_ps = r
    r += 1
    ws.gop(r, 1, r, 3, "Số thuế TNDN đã nộp trong kỳ (phát sinh Nợ TK 3334)", B.k_nhom)
    ws.o(r, 4, da_nop, B.k_nhom_so)
    ws.o(r, 5, None, B.k_nhom)
    r_dn = r
    r += 1
    ws.gop(r, 1, r, 3, "Số thuế TNDN còn phải nộp cuối kỳ = đầu kỳ + phải nộp - đã nộp", B.k_cong)
    ws.o(r, 4, "=%s+%s-%s" % (dia_chi(r_dau, 4), dia_chi(r_ps, 4), dia_chi(r_dn, 4)), B.k_cong_so)
    ws.o(r, 5, None, B.k_cong)
    r += 2
    r = B.ghi_chu(ws, r, nc, "Doanh thu, thu nhập: phát sinh Có TK 511, 515, 711 (giảm trừ ghi âm). Chi phí phân nhóm theo yếu tố dựa vào tài khoản "
                             "đối ứng của dòng chi phí (Có 15x: nguyên liệu, hàng hoá; Có 334 / 338: lương, bảo hiểm; Có 214: khấu hao; Có 331 / "
                             "111 / 112 / 141 / 242: dịch vụ mua ngoài; TK 635 hoặc Có 335 / 341: lãi vay; còn lại: chi khác). Lợi nhuận kế toán = "
                             "(1) - (2); thu nhập tính thuế theo tờ khai 03/TNDN. Không gồm chứng từ kết chuyển 911.")
    B.cuoi(ws, r + 1, nc)
    cuoi = -sum(S.du_cuoi(m) for m in la3334)
    KT.them("Thuế TNDN còn phải nộp cuối kỳ = dư Có TK 3334", dau + ps_nop - da_nop, cuoi)
    KT.them("Doanh thu, thu nhập = phát sinh Có TK 511 / 515 / 711 (không kể kết chuyển)",
            tong_dt, sum(S.ps_ky(m, False)[1] - S.ps_ky(m, False)[0] for m in la_dt))
    KT.them("Chi phí (2) = phát sinh Nợ - Có TK 6xx / 8xx (không kể 821, 611, kết chuyển)",
            tong_cp, sum(S.ps_ky(m, False)[0] - S.ps_ky(m, False)[1] for m in la_cp))
    return B, KT.canh_bao()


# ============================================================ S2c: vat lieu, dung cu, san pham, hang hoa
def lap_s2c(S, pp):
    _nap_sh(S)
    B, KT = Bieu(S, "SS_58S2C"), Kiem("SS_58S2C")
    KH = SM._kho(S)
    dong = defaultdict(list)
    for d in S.ct:
        if KH.la_nhap(d):
            dong[(d.no, d.vt)].append((d, "N"))
        if KH.la_xuat(d):
            dong[(d.co, d.vt)].append((d, "X"))
    khoa = set(dong) | {k for k, x in KH.ton.items() if abs(x[0]) > 1e-9 or abs(x[1]) > 0.5}
    ds = sorted(khoa, key=lambda k: (S.sh(k[0]), KH.ten_vt(k[1])[0]))
    cot = [5, 12, 11, 34, 8, 13, 10, 15, 10, 15, 10, 15, 14]
    ws = B.sheet("S2c", cot)
    nc = 13
    r = B.dau(ws, "S2c-DNSN", "SỔ CHI TIẾT VẬT LIỆU, DỤNG CỤ, SẢN PHẨM, HÀNG HOÁ", nc)
    tong_cuoi = 0.0
    lech = 0
    for (tk, vt) in ds:
        ten = KH.ten_vt(vt)
        x = KH.nxt(tk, vt)
        l0, t0 = (x[0], x[1]) if x else (0.0, 0.0)
        ws.gop(r, 1, r, nc, "Tên vật liệu, dụng cụ, sản phẩm, hàng hoá: %s - %s    Kho / TK: %s (%s)" % (ten[0], ten[1], S.sh(tk), S.ten_tk(tk)), B.k_dam)
        r += 1
        r = B.tieu_de_cot(ws, r, [("Hoá đơn, chứng từ", 1, 2, 0), ("Diễn giải", 3, 4, 1), ("Đơn vị tính", 5, 5, 1), ("Đơn giá", 6, 6, 1),
                                  ("Nhập", 7, 8, 0), ("Xuất", 9, 10, 0), ("Tồn", 11, 12, 0), ("Ghi chú", 13, 13, 1)],
                           [("A", 1), ("B", 2), ("C", 3), ("D", 5), ("1", 6), ("2", 7), ("3", 8), ("4", 9), ("5", 10), ("6", 11), ("7", 12), ("8", 13)], 30)
        for c, td in ((1, "Số hiệu"), (2, "Ngày, tháng"), (7, "Số lượng"), (8, "Thành tiền"), (9, "Số lượng"), (10, "Thành tiền"),
                      (11, "Số lượng"), (12, "Thành tiền")):
            ws.o(r - 2, c, td, B.k_dau)
        ws.gop(r, 1, r, 4, "Số dư đầu kỳ", B.k_nhom)
        ws.o(r, 5, ten[2], B.k_nhom)
        ws.o(r, 6, (t0 / l0) if l0 else None, B.k_o_dg)
        for c in (7, 8, 9, 10, 13):
            ws.o(r, c, "x" if c != 13 else None, B.k_nhom)
        ws.o(r, 11, l0 or None, B.k_cong_sl)
        ws.o(r, 12, t0 or None, B.k_cong_so)
        r += 1
        l, tt = l0, t0
        sn = sx = ln = lx = 0.0
        for d, ben in dong.get((tk, vt), []):
            ws.o(r, 1, d.sh, B.k_o_giua)
            ws.o(r, 2, d.ngay, B.k_o_ngay)
            ws.gop(r, 3, r, 4, d.dg, B.k_o)
            ws.o(r, 5, ten[2], B.k_o_giua)
            if ben == "N":
                l += d.sl_no
                tt += d.tien
                sn += d.tien
                ln += d.sl_no
                ws.o(r, 6, (d.tien / d.sl_no) if d.sl_no else None, B.k_o_dg)
                ws.o(r, 7, d.sl_no or None, B.k_o_sl)
                ws.o(r, 8, d.tien, B.k_o_so)
                ws.o(r, 9, None, B.k_o_sl)
                ws.o(r, 10, None, B.k_o_so)
            else:
                l -= d.sl_co
                tt -= d.tien
                sx += d.tien
                lx += d.sl_co
                ws.o(r, 6, (d.tien / d.sl_co) if d.sl_co else None, B.k_o_dg)
                ws.o(r, 7, None, B.k_o_sl)
                ws.o(r, 8, None, B.k_o_so)
                ws.o(r, 9, d.sl_co or None, B.k_o_sl)
                ws.o(r, 10, d.tien, B.k_o_so)
            ws.o(r, 11, round(l, 4), B.k_o_sl)
            ws.o(r, 12, tt, B.k_o_so)
            ws.o(r, 13, None, B.k_o)
            r += 1
        ws.gop(r, 1, r, 4, "Cộng phát sinh trong kỳ", B.k_cong)
        ws.o(r, 5, None, B.k_cong)
        ws.o(r, 6, None, B.k_cong)
        ws.o(r, 7, ln or None, B.k_cong_sl)
        ws.o(r, 8, sn, B.k_cong_so)
        ws.o(r, 9, lx or None, B.k_cong_sl)
        ws.o(r, 10, sx, B.k_cong_so)
        for c in (11, 12, 13):
            ws.o(r, c, None, B.k_cong)
        r += 1
        ws.gop(r, 1, r, 4, "Số dư cuối kỳ", B.k_cong)
        for c in (5, 6, 7, 8, 9, 10, 13):
            ws.o(r, c, None, B.k_cong)
        ws.o(r, 11, round(l, 4), B.k_cong_sl)
        ws.o(r, 12, tt, B.k_cong_so)
        r += 2
        tong_cuoi += tt
        if x and (abs(tt - x[7]) > 0.5 or abs(l - x[6]) > 0.001):
            lech += 1
    if not ds:
        ws.gop(r, 1, r, nc, "(kỳ này không có vật liệu, dụng cụ, sản phẩm, hàng hoá nhập, xuất, tồn)", B.k_o)
        r += 2
    r = B.ghi_chu(ws, r, nc, "Mỗi mặt hàng một khối; đơn giá xuất theo giá phần mềm đã tính trên dòng xuất (bình quân); tồn đầu / cuối kỳ theo bảng tồn "
                             "kho của phần mềm (chạy Kiểm tra số liệu / Tính giá xuất kho trước khi lập). Cột 3 = 1 x 2, 5 = 1 x 4, 7 = 1 x 6.")
    B.cuoi(ws, r + 1, nc)
    cb = []
    if lech:
        cb.append("S2c: %d mặt hàng có tồn cuối theo chứng từ khác bảng tồn kho (TonKho) - chạy Tính giá xuất kho rồi lập lại" % lech)
    KT.them("Tổng tồn kho cuối kỳ = số dư Nợ các TK vật tư, hàng hoá", tong_cuoi, sum(S.du_cuoi(m) for m in S.la if m in KH.tk_kho))
    return B, cb + KT.canh_bao()


# ============================================================ S2d: so chi tiet tien
def lap_s2d(S, pp):
    _nap_sh(S)
    B, KT = Bieu(S, "SS_58S2D"), Kiem("SS_58S2D")
    cot = [5, 12, 11, 50, 18, 18, 18]
    ws = B.sheet("S2d", cot)
    nc = 6
    r = B.dau(ws, "S2d-DNSN", "SỔ CHI TIẾT TIỀN", nc)
    r = B.tieu_de_cot(ws, r, [("Hoá đơn, chứng từ", 1, 2, 0), ("Diễn giải", 3, 3, 1), ("Số tiền", 4, 5, 0), ("Tồn / số dư", 6, 6, 1)],
                       [("A", 1), ("B", 2), ("C", 3), ("1", 4), ("2", 5), ("3", 6)], 30)
    for c, td in ((1, "Số hiệu"), (2, "Ngày, tháng"), (4, "Thu / Gửi vào"), (5, "Chi / Rút ra")):
        ws.o(r - 2, c, td, B.k_dau)
    ten_nh = {}
    for x in S.ss.get("tk_nh") or []:
        ten_nh[str(x[0] or "")] = " - ".join(str(y or "") for y in x[1:4] if y)
    khoi = [("Tiền mặt", [m for m in S.la if S.sh(m).startswith("111")], "Tiền mặt tồn đầu kỳ", "Tổng tiền thu vào trong kỳ", "Tổng tiền chi ra trong kỳ", "Tiền mặt tồn cuối kỳ")]
    for m in sorted([m for m in S.la if S.sh(m).startswith("112")], key=lambda x: S.sh(x)):
        khoi.append(("Tiền gửi không kỳ hạn - %s %s" % (S.sh(m), ten_nh.get(S.sh(m)) or S.ten_tk(m)), [m], "Tiền gửi tồn đầu kỳ",
                     "Tổng tiền gửi vào trong kỳ", "Tổng tiền rút ra trong kỳ", "Tiền gửi tồn cuối kỳ"))
    tong_cuoi = 0.0
    for ten, las, n_dau, n_thu, n_chi, n_cuoi in khoi:
        d0 = sum(S.du_dau(m) for m in las)
        ws.gop(r, 1, r, nc, ten, B.k_nhom)
        r += 1
        ws.gop(r, 1, r, 3, n_dau, B.k_cong)
        ws.o(r, 4, None, B.k_cong)
        ws.o(r, 5, None, B.k_cong)
        ws.o(r, 6, d0, B.k_cong_so)
        r += 1
        ton, st, sc = d0, 0.0, 0.0
        phieu = OrderedDict()
        for d in S.ct:
            if d.no in las:
                phieu.setdefault((d.mact, "T", d.no), []).append(d)
            if d.co in las:
                phieu.setdefault((d.mact, "C", d.co), []).append(d)
        for (mact, ben, m), ds in phieu.items():
            d = ds[0]
            tien = sum(x.tien for x in ds)
            ws.o(r, 1, d.thuchi or d.sh, B.k_o_giua)
            ws.o(r, 2, d.ngay, B.k_o_ngay)
            ws.o(r, 3, d.dg, B.k_o)
            if ben == "T":
                ton += tien
                st += tien
                ws.o(r, 4, tien, B.k_o_so)
                ws.o(r, 5, None, B.k_o_so)
            else:
                ton -= tien
                sc += tien
                ws.o(r, 4, None, B.k_o_so)
                ws.o(r, 5, tien, B.k_o_so)
            ws.o(r, 6, ton, B.k_o_so)
            r += 1
        ws.gop(r, 1, r, 3, n_thu, B.k_cong)
        ws.o(r, 4, st, B.k_cong_so)
        ws.o(r, 5, None, B.k_cong)
        ws.o(r, 6, None, B.k_cong)
        r += 1
        ws.gop(r, 1, r, 3, n_chi, B.k_cong)
        ws.o(r, 4, None, B.k_cong)
        ws.o(r, 5, sc, B.k_cong_so)
        ws.o(r, 6, None, B.k_cong)
        r += 1
        ws.gop(r, 1, r, 3, n_cuoi, B.k_cong)
        ws.o(r, 4, None, B.k_cong)
        ws.o(r, 5, None, B.k_cong)
        ws.o(r, 6, d0 + st - sc, B.k_cong_so)
        r += 2
        tong_cuoi += d0 + st - sc
        KT.them("%s: tồn cuối = số dư TK" % ten[:40], d0 + st - sc, sum(S.du_cuoi(m) for m in las))
    r = B.ghi_chu(ws, r, nc, "Cột 1, 2: thu, chi tiền mặt (TK 111) hoặc gửi vào, rút ra tiền gửi không kỳ hạn (TK 112, mỗi ngân hàng một khối); "
                             "mỗi phiếu thu / chi gộp các dòng cùng chứng từ. Tiền gửi có kỳ hạn (TK 128) không ghi sổ này.")
    B.cuoi(ws, r + 1, nc)
    return B, KT.canh_bao()


# ============================================================ S3b: nghia vu thue GTGT
def lap_s3b(S, pp):
    _nap_sh(S)
    B, KT = Bieu(S, "SS_58S3B"), Kiem("SS_58S3B")
    cot = [5, 12, 11, 52, 18, 18]
    ws = B.sheet("S3b", cot)
    nc = 5
    r = B.dau(ws, "S3b-DNSN", "SỔ THEO DÕI NGHĨA VỤ THUẾ GTGT", nc)
    r = B.tieu_de_cot(ws, r, [("Hoá đơn, chứng từ", 1, 2, 0), ("Diễn giải", 3, 3, 1), ("Số thuế GTGT đầu vào được khấu trừ", 4, 4, 1),
                              ("Số thuế GTGT đầu ra", 5, 5, 1)], [("A", 1), ("B", 2), ("C", 3), ("1", 4), ("2", 5)], 42)
    for c, td in ((1, "Số hiệu"), (2, "Ngày, tháng")):
        ws.o(r - 2, c, td, B.k_dau)
    la133, la3331 = _la(S, "133"), _la(S, "3331")
    d_vao = sum(S.du_dau(m) for m in la133)
    d_ra = -sum(S.du_dau(m) for m in la3331)
    ws.gop(r, 1, r, 5, "Số dư đầu kỳ", B.k_nhom)
    r += 1
    ws.gop(r, 1, r, 3, "Thuế GTGT còn được khấu trừ / được hoàn đầu kỳ (dư Nợ TK 133)", B.k_o)
    ws.o(r, 4, d_vao, B.k_o_so)
    ws.o(r, 5, None, B.k_o_so)
    r += 1
    ws.gop(r, 1, r, 3, "Thuế GTGT còn phải nộp đầu kỳ (dư Có TK 3331)", B.k_o)
    ws.o(r, 4, None, B.k_o_so)
    ws.o(r, 5, d_ra, B.k_o_so)
    r += 1
    ws.gop(r, 1, r, 5, "Số phát sinh trong kỳ", B.k_nhom)
    r += 1
    vao = ra = nop = hoan = 0.0
    ds_nop, ds_hoan = [], []
    la_tien = _la(S, "111", "112")
    r0 = r
    for d in S.ct:
        if (d.no in la133) == (d.co in la133) and (d.no in la3331) == (d.co in la3331):
            continue                                  # khong lien quan, hoac No 3331 / Co 133 (khau tru - the hien o so du)
        if d.no in la3331 and d.co in la_tien:
            ds_nop.append(d)
            nop += d.tien
            continue
        if d.co in la133 and d.no in la_tien:
            ds_hoan.append(d)
            hoan += d.tien
            continue
        c1 = c2 = None
        if d.no in la133 and d.co not in la3331:
            c1 = d.tien                               # dau vao duoc khau tru
        elif d.co in la133 and d.no not in la3331:
            c1 = -d.tien                              # giam dau vao (tra lai hang mua, khong duoc khau tru...)
        elif d.co in la3331 and d.no not in la133:
            c2 = d.tien                               # dau ra
        elif d.no in la3331 and d.co not in la133:
            c2 = -d.tien                              # giam dau ra (hang ban tra lai, dieu chinh giam)
        ws.o(r, 1, d.sh, B.k_o_giua)
        ws.o(r, 2, d.ngay, B.k_o_ngay)
        ws.o(r, 3, d.dg + (" (giảm)" if (c1 or 0) < 0 or (c2 or 0) < 0 else ""), B.k_o)
        ws.o(r, 4, c1, B.k_o_so)
        ws.o(r, 5, c2, B.k_o_so)
        vao += c1 or 0.0
        ra += c2 or 0.0
        r += 1
    ws.gop(r, 1, r, 3, "Cộng số phát sinh trong kỳ", B.k_cong)
    ws.o(r, 4, "=SUM(%s:%s)" % (dia_chi(r0, 4), dia_chi(r - 1, 4)) if r > r0 else 0, B.k_cong_so)
    ws.o(r, 5, "=SUM(%s:%s)" % (dia_chi(r0, 5), dia_chi(r - 1, 5)) if r > r0 else 0, B.k_cong_so)
    r += 1
    phai_nop = max(ra - vao - d_vao, 0.0)
    ws.gop(r, 1, r, 3, "Tổng số thuế GTGT phải nộp trong kỳ (2) = đầu ra - đầu vào được khấu trừ (kể cả số còn được khấu trừ kỳ trước chuyển sang; âm ghi 0)", B.k_nhom)
    ws.o(r, 4, None, B.k_nhom)
    ws.o(r, 5, phai_nop, B.k_nhom_so)
    r += 1
    for ten, ds, tong, c in (("Số thuế GTGT đã nộp trong kỳ (3)", ds_nop, nop, 5), ("Số thuế GTGT đã được hoàn trong kỳ (4)", ds_hoan, hoan, 4)):
        ws.gop(r, 1, r, 3, ten, B.k_nhom)
        ws.o(r, 4, tong if c == 4 else None, B.k_nhom_so)
        ws.o(r, 5, tong if c == 5 else None, B.k_nhom_so)
        r += 1
        for d in ds:
            ws.o(r, 1, d.sh, B.k_o_giua)
            ws.o(r, 2, d.ngay, B.k_o_ngay)
            ws.o(r, 3, d.dg, B.k_o)
            ws.o(r, 4, d.tien if c == 4 else None, B.k_o_so)
            ws.o(r, 5, d.tien if c == 5 else None, B.k_o_so)
            r += 1
    ws.gop(r, 1, r, 5, "Số dư cuối kỳ (theo số dư tài khoản cuối kỳ)", B.k_nhom)
    r += 1
    c_vao = sum(S.du_cuoi(m) for m in la133)
    c_ra = -sum(S.du_cuoi(m) for m in la3331)
    ws.gop(r, 1, r, 3, "Thuế GTGT còn được khấu trừ / được hoàn cuối kỳ (dư Nợ TK 133)", B.k_cong)
    ws.o(r, 4, c_vao, B.k_cong_so)
    ws.o(r, 5, None, B.k_cong)
    r += 1
    ws.gop(r, 1, r, 3, "Thuế GTGT còn phải nộp cuối kỳ (dư Có TK 3331)", B.k_cong)
    ws.o(r, 4, None, B.k_cong)
    ws.o(r, 5, c_ra, B.k_cong_so)
    r += 2
    r = B.ghi_chu(ws, r, nc, "Cột 1: thuế GTGT đầu vào được khấu trừ (phát sinh Nợ TK 133; Có 133 không phải hoàn / khấu trừ ghi âm); cột 2: thuế đầu ra "
                             "(phát sinh Có TK 3331; Nợ 3331 không phải nộp / khấu trừ ghi âm). Bút toán khấu trừ Nợ 3331 / Có 133 không liệt kê (đã thể hiện "
                             "ở số dư cuối kỳ). Đã nộp: Nợ 3331 / Có 111, 112; đã hoàn: Nợ 111, 112 / Có 133. Đối chiếu với tờ khai 01/GTGT đã nộp.")
    B.cuoi(ws, r + 1, nc)
    KT.them("Số dư cuối kỳ cột 1 - cột 2 = (dư đầu vào + đầu vào - đầu ra + đã nộp - đã hoàn) - (dư đầu ra ...)",
            c_vao - c_ra, (d_vao + vao - hoan) - (d_ra + ra - nop))
    return B, KT.canh_bao()


# ============================================================ S4a: cong no
def lap_s4a(S, pp):
    _nap_sh(S)
    B, KT = Bieu(S, "SS_58S4A"), Kiem("SS_58S4A")
    cot = [5, 12, 11, 40, 15, 15, 15, 15, 15, 15]
    ws = B.sheet("S4a", cot)
    nc = 9
    r = B.dau(ws, "S4a-DNSN", "SỔ CHI TIẾT THANH TOÁN CÔNG NỢ", nc)
    tong_thu = tong_tra = 0.0

    def dau_khoi(r, ten):
        ws.gop(r, 1, r, nc, "Đối tượng: " + ten, B.k_dam)
        r += 1
        r = B.tieu_de_cot(ws, r, [("Hoá đơn, chứng từ", 1, 2, 0), ("Diễn giải", 3, 3, 1), ("Các khoản nợ phải thu", 4, 6, 0),
                                  ("Các khoản nợ phải trả", 7, 9, 0)],
                           [("A", 1), ("B", 2), ("C", 3), ("1", 4), ("2", 5), ("3", 6), ("4", 7), ("5", 8), ("6", 9)], 30)
        for c, td in ((1, "Số hiệu"), (2, "Ngày, tháng"), (4, "Số phải thu"), (5, "Số đã thu"), (6, "Số còn phải thu"), (7, "Số phải trả"),
                      (8, "Số đã trả"), (9, "Số còn phải trả")):
            ws.o(r - 2, c, td, B.k_dau)
        return r

    def khoi(r, ten, d0, dong, thu):
        """d0 = du dau (No - Co); dong = [(d, ben 'N'/'C')]; thu = True: TK phai thu (cot 1-3) / False: phai tra (cot 4-6)."""
        r = dau_khoi(r, ten)
        c1, c2, c3 = (4, 5, 6) if thu else (7, 8, 9)
        ws.gop(r, 1, r, 3, "Số dư đầu kỳ", B.k_nhom)
        for c in range(4, 10):
            ws.o(r, c, None, B.k_nhom)
        ws.o(r, c3, d0 if thu else -d0, B.k_nhom_so)
        r += 1
        con = d0 if thu else -d0
        sps = sdc = 0.0
        for d, ben in dong:
            ws.o(r, 1, d.sh, B.k_o_giua)
            ws.o(r, 2, d.ngay, B.k_o_ngay)
            ws.o(r, 3, d.dg, B.k_o)
            for c in range(4, 10):
                ws.o(r, c, None, B.k_o_so)
            tang = (ben == "N") if thu else (ben == "C")
            if tang:
                con += d.tien
                sps += d.tien
                ws.o(r, c1, d.tien, B.k_o_so)
            else:
                con -= d.tien
                sdc += d.tien
                ws.o(r, c2, d.tien, B.k_o_so)
            ws.o(r, c3, con, B.k_o_so)
            r += 1
        ws.gop(r, 1, r, 3, "Cộng số phát sinh trong kỳ", B.k_cong)
        for c in range(4, 10):
            ws.o(r, c, None, B.k_cong)
        ws.o(r, c1, sps, B.k_cong_so)
        ws.o(r, c2, sdc, B.k_cong_so)
        r += 1
        ws.gop(r, 1, r, 3, "Số dư cuối kỳ", B.k_cong)
        for c in range(4, 10):
            ws.o(r, c, None, B.k_cong)
        ws.o(r, c3, con, B.k_cong_so)
        return r + 2, con

    # 131 / 331 theo doi tuong (dong khong co doi tuong -> khoi rieng)
    for tk_id, thu in ((K.TKCN_KH, True), (K.TKCN_PT, False)):
        las, g = SM._cong_no(S, tk_id)
        dong = defaultdict(list)
        for d in S.ct:
            if d.no in las:
                dong[(d.no, d.kh)].append((d, "N"))
            if d.co in las:
                dong[(d.co, d.khc)].append((d, "C"))
        khoa = sorted(set(g) | set(dong), key=lambda k: (S.sh(k[0]), k[1] == 0, S.ten_dt(k[1])))
        tong_khoi = 0.0
        for (tk, kh) in khoa:
            x = g.get((tk, kh)) or [0.0, 0.0, 0.0]
            if abs(x[0]) < 0.5 and not dong.get((tk, kh)):
                continue
            if kh:
                ten = "%s (%s) - TK %s" % (S.ten_dt(kh) or ("đối tượng %d" % kh), (S.dt.get(kh) or ["", "", ""])[0], S.sh(tk))
            else:
                ten = "(không ghi đối tượng) - TK %s" % S.sh(tk)
            r, con = khoi(r, ten, x[0], dong.get((tk, kh), []), thu)
            tong_khoi += con
            if thu:
                tong_thu += con
            else:
                tong_tra += con
        if las:
            du = sum(S.du_cuoi(m) for m in las)
            KT.them("Tổng số dư cuối các khối TK %s = số dư TK (Nợ - Có)" % ("131" if thu else "331"), tong_khoi if thu else -tong_khoi, du)
    # phai thu / phai tra khac theo TK (khong theo doi tuong): 136, 138, 141, 1388 | 334, 335, 336, 338, 341, 344
    for tien_to, thu in ((("136", "138", "141"), True), (("334", "335", "336", "338", "341", "344"), False)):
        for m in sorted(_la(S, *tien_to), key=lambda x: S.sh(x)):
            d0 = S.du_dau(m)
            dong = [(d, "N") for d in S.ct if d.no == m] + [(d, "C") for d in S.ct if d.co == m]
            dong.sort(key=lambda x: (x[0].t, x[0].ngay_gs or datetime.date(1900, 1, 1), x[0].mact, x[0].ms))
            if abs(d0) < 0.5 and not dong:
                continue
            r, con = khoi(r, "TK %s - %s" % (S.sh(m), S.ten_tk(m)), d0, dong, thu)
            if thu:
                tong_thu += con
            else:
                tong_tra += con
    r = B.ghi_chu(ws, r, nc, "Phải thu khách hàng (TK 131) và phải trả người bán (TK 331) theo từng đối tượng; các khoản phải thu, phải trả khác "
                             "(136, 138, 141 / 334, 335, 336, 338, 341, 344) theo tài khoản. Không gồm thuế GTGT, thuế TNDN (xem S3b, S2b). "
                             "Sổ có thể mở chi tiết theo thời hạn / từng lần thanh toán.")
    B.cuoi(ws, r + 1, nc)
    return B, KT.canh_bao()


# ============================================================ S4b: tai san co dinh
def lap_s4b(S, pp):
    _nap_sh(S)
    B, KT = Bieu(S, "SS_58S4B"), Kiem("SS_58S4B")
    cot = [5, 12, 11, 34, 12, 16, 9, 14, 16, 12, 11, 24]
    ws = B.sheet("S4b", cot)
    nc = 12
    r = B.dau(ws, "S4b-DNSN", "SỔ TÀI SẢN CỐ ĐỊNH", nc, "Loại tài sản: tài sản cố định hữu hình, vô hình (TK 211 - 213)")
    r = B.tieu_de_cot(ws, r, [("STT", 1, 1, 1), ("Ghi tăng TSCĐ", 2, 6, 0), ("Số khấu hao TSCĐ", 7, 9, 0), ("Ghi giảm TSCĐ", 10, 12, 0)],
                       [("", 1), ("A", 2), ("B", 3), ("C", 4), ("D", 5), ("1", 6), ("2", 7), ("3", 8), ("4", 9), ("E", 10), ("G", 11), ("H", 12)], 42)
    for c, td in ((2, "Chứng từ - Số hiệu"), (3, "Ngày, tháng"), (4, "Tên, đặc điểm, ký hiệu TSCĐ"), (5, "Tháng, năm đưa vào sử dụng"),
                  (6, "Nguyên giá TSCĐ"), (7, "Tỷ lệ (%) khấu hao"), (8, "Mức khấu hao (trong kỳ)"), (9, "Khấu hao luỹ kế"),
                  (10, "Chứng từ - Số hiệu"), (11, "Ngày, tháng, năm"), (12, "Lý do giảm TSCĐ")):
        ws.o(r - 2, c, td, B.k_dau)
    ss = S.ss
    so = defaultdict(dict)
    for x in ss.get("tsan_ts") or []:
        so[int(_so(x[0]))][int(_so(x[1]))] = (_so(x[2]), _so(x[3]), _so(x[4]), int(_so(x[5])))
    t1, t2 = S.t1, S.t2
    stt = 0
    tong = defaultdict(float)
    for x in ss.get("tsan") or []:
        ms, sh, ten, _shl, ten_loai, nkh, nct, tang, giam = x[:9]
        ms = int(_so(ms))
        tt = so.get(ms) or {}
        tang_f = K.thang_tc(tang, S.dau_ky)
        giam_f = 13 if int(_so(giam)) == 0 else K.thang_tc(giam, S.dau_ky)
        if giam_f < t1 or not tt:
            continue
        dk = tt.get(t1 - 1)
        lk_dau = (dk[0] - dk[2]) if (dk and tang_f <= t1 - 1) else 0.0
        kh_ky = sum(v[1] for t, v in tt.items() if t1 <= t <= t2 and tang_f <= t <= giam_f)
        cuoi = tt.get(t2) or dk
        ng = cuoi[0] if cuoi else 0.0
        if ng < 0.5 and not kh_ky:
            continue
        stt += 1
        nkh = int(_so(nkh))
        m_t, y_t = S.thang_lich(tang_f) if 1 <= tang_f <= 12 else (0, 0)
        ws.o(r, 1, stt, B.k_o_giua)
        ws.o(r, 2, sh, B.k_o_giua)
        ws.o(r, 3, SM._ngay(nct), B.k_o_ngay)
        ws.o(r, 4, "%s%s" % (ten, (" (%s)" % ten_loai) if ten_loai else ""), B.k_o)
        ws.o(r, 5, ("%02d/%d" % (m_t, y_t)) if m_t else (SM._ngay(nct).strftime("%m/%Y") if SM._ngay(nct) else ""), B.k_o_giua)
        ws.o(r, 6, ng, B.k_o_so)
        ws.o(r, 7, round(100.0 / nkh, 2) if nkh else None, B.k_o_pt)
        ws.o(r, 8, kh_ky, B.k_o_so)
        ws.o(r, 9, lk_dau + kh_ky, B.k_o_so)
        if giam_f <= t2:
            m_g, y_g = S.thang_lich(giam_f)
            ws.o(r, 10, "", B.k_o_giua)
            ws.o(r, 11, "%02d/%d" % (m_g, y_g), B.k_o_giua)
            ws.o(r, 12, "Ghi giảm (nhượng bán / thanh lý - ghi rõ)", B.k_o)
        else:
            for c in (10, 11, 12):
                ws.o(r, c, None, B.k_o)
        tong[6] += ng
        tong[8] += kh_ky
        tong[9] += lk_dau + kh_ky
        r += 1
    ws.gop(r, 1, r, 5, "Cộng", B.k_cong)
    for c in (6, 8, 9):
        ws.o(r, c, tong[c], B.k_cong_so)
    for c in (7, 10, 11, 12):
        ws.o(r, c, "x", B.k_cong)
    r += 2
    if not stt:
        r = B.ghi_chu(ws, r, nc, "(kỳ này không có tài sản cố định trên bảng khấu hao của phần mềm)")
    r = B.ghi_chu(ws, r, nc, "Cột 2: tỷ lệ khấu hao năm = 100 / số năm khấu hao; cột 3: số khấu hao trong kỳ; cột 4: luỹ kế đến cuối kỳ (theo bảng "
                             "khấu hao - ThongSo). Ghi giảm: tháng ghi giảm theo thẻ tài sản, lý do điền tay.")
    B.cuoi(ws, r + 1, nc)
    l214 = _la(S, "214")
    KT.them("Số khấu hao trong kỳ = phát sinh Có TK 214", tong[8], sum(S.ps_ky(m)[1] for m in l214))
    KT.them("Nguyên giá = số dư Nợ TK 211 - 213", tong[6], sum(S.du_cuoi(m) for m in _la(S, "211", "212", "213")))
    return B, KT.canh_bao()


# ============================================================ S4c: nghia vu thue khac
def lap_s4c(S, pp):
    _nap_sh(S)
    B, KT = Bieu(S, "SS_58S4C"), Kiem("SS_58S4C")
    cot = [5, 12, 11, 50, 17, 17, 17]
    ws = B.sheet("S4c", cot)
    nc = 6
    r = B.dau(ws, "S4c-DNSN", "SỔ THEO DÕI NGHĨA VỤ THUẾ KHÁC", nc, "(thuế TNCN, thuế xuất nhập khẩu, tiêu thụ đặc biệt, tài nguyên, bảo vệ môi trường, "
                                                                  "sử dụng đất, phí, lệ phí và các khoản phải nộp khác - không gồm thuế GTGT, thuế TNDN)")
    r = B.tieu_de_cot(ws, r, [("Hoá đơn, chứng từ", 1, 2, 0), ("Diễn giải", 3, 3, 1), ("Số phải nộp", 4, 4, 1), ("Số đã nộp", 5, 5, 1),
                              ("Số còn phải nộp", 6, 6, 1)], [("A", 1), ("B", 2), ("C", 3), ("1", 4), ("2", 5), ("3", 6)], 30)
    for c, td in ((1, "Số hiệu"), (2, "Ngày, tháng")):
        ws.o(r - 2, c, td, B.k_dau)
    las = [m for m in _la(S, "333") if not S.sh(m).startswith(("3331", "3334"))]
    n = 0
    tong_cuoi = 0.0
    for m in sorted(las, key=lambda x: S.sh(x)):
        d0 = -S.du_dau(m)
        dong = [d for d in S.ct if d.no == m or d.co == m]
        if abs(d0) < 0.5 and not dong:
            continue
        n += 1
        ws.gop(r, 1, r, nc, "TK %s - %s" % (S.sh(m), S.ten_tk(m)), B.k_nhom)
        r += 1
        ws.gop(r, 1, r, 3, "Số còn phải nộp đầu kỳ", B.k_cong)
        ws.o(r, 4, None, B.k_cong)
        ws.o(r, 5, None, B.k_cong)
        ws.o(r, 6, d0, B.k_cong_so)
        r += 1
        con, sp, sd = d0, 0.0, 0.0
        for d in dong:
            ws.o(r, 1, d.sh, B.k_o_giua)
            ws.o(r, 2, d.ngay, B.k_o_ngay)
            ws.o(r, 3, d.dg, B.k_o)
            if d.co == m:
                con += d.tien
                sp += d.tien
                ws.o(r, 4, d.tien, B.k_o_so)
                ws.o(r, 5, None, B.k_o_so)
            else:
                con -= d.tien
                sd += d.tien
                ws.o(r, 4, None, B.k_o_so)
                ws.o(r, 5, d.tien, B.k_o_so)
            ws.o(r, 6, con, B.k_o_so)
            r += 1
        ws.gop(r, 1, r, 3, "Cộng phát sinh trong kỳ", B.k_cong)
        ws.o(r, 4, sp, B.k_cong_so)
        ws.o(r, 5, sd, B.k_cong_so)
        ws.o(r, 6, None, B.k_cong)
        r += 1
        ws.gop(r, 1, r, 3, "Số còn phải nộp cuối kỳ", B.k_cong)
        ws.o(r, 4, None, B.k_cong)
        ws.o(r, 5, None, B.k_cong)
        ws.o(r, 6, con, B.k_cong_so)
        r += 2
        tong_cuoi += con
        KT.them("TK %s: còn phải nộp cuối kỳ = dư Có" % S.sh(m), con, -S.du_cuoi(m))
    if not n:
        ws.gop(r, 1, r, nc, "(kỳ này không có thuế, khoản phải nộp khác ngoài GTGT, TNDN)", B.k_o)
        r += 2
    r = B.ghi_chu(ws, r, nc, "Mỗi loại thuế / khoản phải nộp (TK 333x trừ 3331, 3334) một khối: phải nộp = phát sinh Có, đã nộp = phát sinh Nợ, "
                             "còn phải nộp = đầu kỳ + phải nộp - đã nộp (dư Nợ = nộp thừa, ghi âm).")
    B.cuoi(ws, r + 1, nc)
    return B, KT.canh_bao()


# ============================================================ S4d: von chu so huu
def lap_s4d(S, pp):
    _nap_sh(S)
    B, KT = Bieu(S, "SS_58S4D"), Kiem("SS_58S4D")
    cot = [5, 12, 11, 50, 17, 17, 17]
    ws = B.sheet("S4d", cot)
    nc = 6
    r = B.dau(ws, "S4d-DNSN", "SỔ THEO DÕI VỐN CHỦ SỞ HỮU", nc)
    r = B.tieu_de_cot(ws, r, [("Chứng từ", 1, 2, 0), ("Diễn giải", 3, 3, 1), ("Tăng trong kỳ", 4, 4, 1), ("Giảm trong kỳ", 5, 5, 1),
                              ("Số dư", 6, 6, 1)], [("A", 1), ("B", 2), ("C", 3), ("1", 4), ("2", 5), ("3", 6)], 30)
    for c, td in ((1, "Số hiệu"), (2, "Ngày, tháng")):
        ws.o(r - 2, c, td, B.k_dau)
    nhom = [("1. Vốn góp của chủ sở hữu", [m for m in _la(S, "411", "412", "413", "419")]),
            ("2. Lợi nhuận sau thuế chưa phân phối", [m for m in _la(S, "421")]),
            ("3. Các quỹ thuộc vốn chủ sở hữu", [m for m in _la(S, "41") if not S.sh(m).startswith(("411", "412", "413", "419"))])]
    for i, (ten, las) in enumerate(nhom, start=1):
        d0 = -sum(S.du_dau(m) for m in las)
        ws.gop(r, 1, r, nc, ten + ("" if las else " (sổ không có tài khoản)"), B.k_nhom)
        r += 1
        ws.gop(r, 1, r, 3, "%d.1 Số dư đầu kỳ" % i, B.k_cong)
        ws.o(r, 4, None, B.k_cong)
        ws.o(r, 5, None, B.k_cong)
        ws.o(r, 6, d0, B.k_cong_so)
        r += 1
        ws.gop(r, 1, r, 3, "%d.2 Số phát sinh trong kỳ" % i, B.k_o)
        ws.o(r, 4, None, B.k_o)
        ws.o(r, 5, None, B.k_o)
        ws.o(r, 6, None, B.k_o)
        r += 1
        con, st, sg = d0, 0.0, 0.0
        for d in S.ct:
            if (d.co in las) != (d.no in las):
                ws.o(r, 1, d.sh, B.k_o_giua)
                ws.o(r, 2, d.ngay, B.k_o_ngay)
                ws.o(r, 3, d.dg, B.k_o)
                if d.co in las:
                    con += d.tien
                    st += d.tien
                    ws.o(r, 4, d.tien, B.k_o_so)
                    ws.o(r, 5, None, B.k_o_so)
                else:
                    con -= d.tien
                    sg += d.tien
                    ws.o(r, 4, None, B.k_o_so)
                    ws.o(r, 5, d.tien, B.k_o_so)
                ws.o(r, 6, con, B.k_o_so)
                r += 1
        ws.gop(r, 1, r, 3, "%d.3 Số dư cuối kỳ" % i, B.k_cong)
        ws.o(r, 4, st, B.k_cong_so)
        ws.o(r, 5, sg, B.k_cong_so)
        ws.o(r, 6, con, B.k_cong_so)
        r += 2
        KT.them("%s: số dư cuối = dư Có TK" % ten[3:30], con, -sum(S.du_cuoi(m) for m in las))
    r = B.ghi_chu(ws, r, nc, "Cột 1, 2: tăng (phát sinh Có), giảm (phát sinh Nợ) từng loại vốn chủ sở hữu; cột 3: số dư. Vốn góp gồm TK 411, 412, 413 "
                             "(cổ phiếu quỹ 419 ghi giảm); quỹ gồm các TK 41x còn lại.")
    B.cuoi(ws, r + 1, nc)
    return B, KT.canh_bao()


# ============================================================ B01-DNSN / B02-DNSN
def _gia_tri_bctc(S):
    """-> (b01 {ma: (cuoi, dau)}, b02 {ma: (nay, truoc)}, nguon, cb). Tu B01a / B02 TT133 cua dong co phan mem khi co, khong co thi tu so du."""
    st = getattr(S, "_tt58_bctc", None)
    if st is not None:
        return st
    cb = []
    g = None
    try:
        import bao_cao_nam as BCN
        g = BCN.gia_tri_bctc(S.dl)
    except Exception as e:
        cb.append("Không đọc được B01a / B02 từ động cơ phần mềm (%s) - lấy từ số dư tài khoản." % e)
    b01, b02, nguon = {}, {}, ""
    a = (g or {}).get("B01A")
    if a and str((S.dl.get("bctc") or {}).get("che_do") or "").upper() != "TT99":
        def v(m):
            return a.get(m, (0, 0))
        for i in (0, 1):
            b01.setdefault(110, [0, 0])[i] = v(110)[i]
            b01.setdefault(120, [0, 0])[i] = v(130)[i]
            b01.setdefault(130, [0, 0])[i] = v(140)[i]
            b01.setdefault(140, [0, 0])[i] = v(150)[i]
            b01.setdefault(150, [0, 0])[i] = v(120)[i] + v(160)[i] + v(170)[i] + v(180)[i]
            b01.setdefault(320, [0, 0])[i] = v(313)[i]
            b01.setdefault(310, [0, 0])[i] = sum(v(m)[i] for m in (311, 312, 314, 315, 316, 317, 318, 319, 320))
            b01.setdefault(410, [0, 0])[i] = sum(v(m)[i] for m in (411, 412, 413, 414, 415))
            b01.setdefault(420, [0, 0])[i] = v(417)[i]
            b01.setdefault(430, [0, 0])[i] = v(416)[i]
        nguon = "B01a-DNN của động cơ phần mềm (TT133): 110=110; 120=130; 130=140; 140=150; 150=120+160+170+180; 310=311..320 trừ 313; 320=313; 410=411..415; 420=417; 430=416"
    else:
        def du(tien_to, loai, i):
            tong = 0.0
            for m in S.la_theo(*tien_to):
                x = S.du_cuoi(m) if i == 0 else (S.tk[m]["dn0"] - S.tk[m]["dc0"])
                if loai == "N" and x > 0:
                    tong += x
                elif loai == "C" and x < 0:
                    tong += -x
                elif loai == "T":
                    tong += x
            return tong
        for i in (0, 1):
            b01.setdefault(110, [0, 0])[i] = du(("111", "112", "113"), "T", i)
            b01.setdefault(120, [0, 0])[i] = du(("131", "136", "138", "141", "244"), "N", i) + du(("331", "333", "334", "335", "338", "341", "344"), "N", i)
            b01.setdefault(130, [0, 0])[i] = du(("151", "152", "153", "154", "155", "156", "157", "158"), "T", i) - du(("159", "2294"), "C", i)
            b01.setdefault(140, [0, 0])[i] = du(("211", "212", "213"), "T", i) - du(("214",), "C", i)
            b01.setdefault(150, [0, 0])[i] = du(("121", "128", "133", "217", "221", "222", "228", "229", "241", "242"), "T", i)
            b01.setdefault(320, [0, 0])[i] = du(("333",), "C", i)
            b01.setdefault(310, [0, 0])[i] = du(("331", "334", "335", "336", "338", "341", "344", "352", "353", "356", "357"), "C", i) + du(("131", "136", "138", "141"), "C", i)
            b01.setdefault(410, [0, 0])[i] = du(("411", "412", "413", "419", "415"), "T", i) * -1
            # LNST chua phan phoi: TK 421 + ket qua ky nay con nam tren TK 5 - 9 (so chua ket chuyen 911)
            b01.setdefault(420, [0, 0])[i] = -du(("421",), "T", i) - du(("5", "6", "7", "8", "9"), "T", i)
            b01.setdefault(430, [0, 0])[i] = -sum(S.du_cuoi(m) if i == 0 else (S.tk[m]["dn0"] - S.tk[m]["dc0"]) for m in S.la_theo("41")
                                                 if not S.sh(m).startswith(("411", "412", "413", "419", "415")))
        nguon = "số dư tài khoản (TT133 / TT99 không có B01a động cơ): tiền 11x; phải thu 131, 136, 138, 141, 244 và dư Nợ 331, 333, 334, 338, 341; hàng tồn kho 15x - 159; TSCĐ 21x - 214; tài sản khác 121, 128, 133, 217, 221, 222, 228, 229, 241, 242; nợ phải trả 331, 334-338, 341, 344, 352-357 và dư Có 131, 136, 138, 141; thuế 333; vốn 411-419; LNST 421 (gồm kết quả chưa kết chuyển trên TK 5-9); quỹ 41x khác"
    for i in (0, 1):
        for m in B01_MA:
            b01.setdefault(m, [0, 0])
        b01[200][i] = sum(b01[m][i] for m in (110, 120, 130, 140, 150))
        b01[300][i] = b01[310][i] + b01[320][i]
        b01[400][i] = b01[410][i] + b01[420][i] + b01[430][i]
        b01[500][i] = b01[300][i] + b01[400][i]
    b = (g or {}).get("B02")
    if b:
        for i in (0, 1):
            b02.setdefault("01", [0, 0])[i] = b.get(10, (0, 0))[i] + b.get(21, (0, 0))[i] + b.get(31, (0, 0))[i]
            b02.setdefault("02", [0, 0])[i] = b.get(11, (0, 0))[i] + b.get(22, (0, 0))[i] + b.get(24, (0, 0))[i] + b.get(32, (0, 0))[i]
            b02.setdefault("10", [0, 0])[i] = b.get(51, (0, 0))[i]
        nguon += "; B02: 01=10+21+31; 02=11+22+24+32; 10=51"
    else:
        ps = lambda tt, kc=False: S.ps_tien_to(tt, kc)
        dt = sum(ps(t)[1] - ps(t)[0] for t in ("511", "512", "515", "711"))
        cp = sum(ps(t)[0] - ps(t)[1] for t in ("632", "635", "641", "642", "811"))
        th = ps("821")[0] - ps("821")[1]
        b02 = {"01": [dt, 0], "02": [cp, 0], "10": [th, 0]}
        cb.append("B02-DNSN: không có số B02 của động cơ - lấy phát sinh TK 511, 515, 711 / 632, 635, 641, 642, 811 / 821 (không kể kết chuyển); cột Năm trước để 0.")
    for i in (0, 1):
        b02["03"] = b02.get("03", [0, 0])
        b02["20"] = b02.get("20", [0, 0])
        b02["03"][i] = b02["01"][i] - b02["02"][i]
        b02["20"][i] = b02["03"][i] - b02["10"][i]
    b01 = {m: (lam_tron(v[0]), lam_tron(v[1])) for m, v in b01.items()}
    b02 = {m: (lam_tron(v[0]), lam_tron(v[1])) for m, v in b02.items()}
    S._tt58_bctc = (b01, b02, nguon, cb)
    return S._tt58_bctc


def lap_b01(S, pp):
    B, KT = Bieu(S, "SS_58B01"), Kiem("SS_58B01")
    b01, b02, nguon, cb = _gia_tri_bctc(S)
    cot = [6, 52, 9, 20, 20]
    ws = B.sheet("B01-DNSN", cot)
    nc = 5
    r = B.dau(ws, "B01 - DNSN", "BÁO CÁO TÌNH HÌNH TÀI CHÍNH", nc, None, "Tại ngày %s" % S.den_ky.strftime("%d/%m/%Y"))
    r = B.tieu_de_cot(ws, r, [("STT", 1, 1, 0), ("CHỈ TIÊU", 2, 2, 0), ("Mã số", 3, 3, 0), ("Số cuối năm", 4, 4, 0), ("Số đầu năm", 5, 5, 0)],
                       [("1", 1), ("2", 2), ("3", 3), ("4", 4), ("5", 5)], 30)
    stt = 0
    for ten, ma, loai in B01_DONG:
        if ma is None:
            ws.gop(r, 1, r, nc, ten, B.k_nhom)
        else:
            k = B.k_cong if loai == "t" else (B.k_nhom if loai == "d" else B.k_o)
            ks = B.k_cong_so if loai == "t" else (B.k_nhom_so if loai == "d" else B.k_o_so)
            stt += 1 if loai == "" else 0
            ws.o(r, 1, stt if loai == "" else None, k)
            ws.o(r, 2, ten, k)
            ws.o(r, 3, str(ma), k)
            ws.o(r, 4, b01[ma][0], ks)
            ws.o(r, 5, b01[ma][1], ks)
        r += 1
    r += 1
    r = B.ghi_chu(ws, r, nc, "Nguồn số liệu: " + nguon + ". Doanh nghiệp nộp thuế TNDN trên thu nhập tính thuế nộp báo cáo cho cơ quan thuế trong 90 ngày "
                             "kể từ ngày kết thúc năm (Điều 10 TT 58/2026); nộp theo tỷ lệ % doanh thu thì chỉ lập để lưu tại doanh nghiệp.")
    B.cuoi(ws, r + 1, nc)
    KT.them("B01-DNSN: tổng tài sản = tổng nguồn vốn (cuối năm)", b01[200][0], b01[500][0])
    KT.them("B01-DNSN: tổng tài sản = tổng nguồn vốn (đầu năm)", b01[200][1], b01[500][1])
    return B, cb + KT.canh_bao()


def lap_b02(S, pp):
    B, KT = Bieu(S, "SS_58B02"), Kiem("SS_58B02")
    b01, b02, nguon, cb = _gia_tri_bctc(S)
    cot = [6, 60, 9, 20, 20]
    ws = B.sheet("B02-DNSN", cot)
    nc = 5
    r = B.dau(ws, "B02 - DNSN", "BÁO CÁO KẾT QUẢ HOẠT ĐỘNG KINH DOANH", nc, None, "Năm %d" % S.nam)
    r = B.tieu_de_cot(ws, r, [("STT", 1, 1, 0), ("CHỈ TIÊU", 2, 2, 0), ("Mã số", 3, 3, 0), ("Năm nay", 4, 4, 0), ("Năm trước", 5, 5, 0)],
                       [("1", 1), ("2", 2), ("3", 3), ("4", 4), ("5", 5)], 30)
    for i, (ten, ma) in enumerate(B02_DONG, start=1):
        k, ks = (B.k_cong, B.k_cong_so) if ma in ("03", "20") else (B.k_o, B.k_o_so)
        ws.o(r, 1, i, k)
        ws.o(r, 2, ten, k)
        ws.o(r, 3, ma, k)
        ws.o(r, 4, b02[ma][0], ks)
        ws.o(r, 5, b02[ma][1], ks)
        r += 1
    r += 1
    r = B.ghi_chu(ws, r, nc, "Nguồn số liệu: " + nguon.split("; B02: ")[-1] + ". Chi phí thuế TNDN theo tờ khai quyết toán 03/TNDN.")
    B.cuoi(ws, r + 1, nc)
    return B, cb + KT.canh_bao()


def lap_xml_58(S, thumuc, cb):
    """58_BCTC (maTKhai 1280, XML 3.0.5): B01-DNSN + PL_BCKQHDKD. Lap MOT lan."""
    st = getattr(S, "_tt58_xml", None)
    if st:
        return st
    import bao_cao_nam as BCN
    b01, b02, nguon, cb2 = _gia_tri_bctc(S)
    dl = S.dl
    k = BCN._ky(dl)
    nk = BCN._nguoi_ky(dl)
    NS = BCN.NS
    goc = ET.Element("{%s}HSoThueDTu" % NS)
    hs = BCN._e(goc, "HSoKhaiThue")
    BCN._ttin_chung(dl, hs, "1280", "Bộ báo cáo tài chính năm (TT58/2026/TT-BTC)",
                    "(Ban hành kèm theo Thông tư số 58/2026/TT-BTC ngày 25 tháng 5 năm 2026 của Bộ trưởng Bộ Tài chính)", "3.0.5", cb, "58_BCTC")
    ct = BCN._e(hs, "CTieuTKhaiChinh")
    BCN._khoi_ct(ct, "SoCuoiNam", B01_MA, {m: b01[m][0] for m in B01_MA})
    BCN._khoi_ct(ct, "SoDauNam", B01_MA, {m: b01[m][1] for m in B01_MA})
    pk = BCN._e(ct, "PhanKy")
    BCN._e(pk, "nguoiLapBieu", nk.get("nguoi_lap", ""))
    BCN._e(pk, "keToanTruong", nk.get("ke_toan_truong", ""))
    BCN._e(pk, "ngayLap", BCN._iso(k["lap"]))
    BCN._e(pk, "thuTruongDonVi", nk.get("giam_doc", ""))
    pl = BCN._e(hs, "PLuc")
    n = BCN._e(pl, "PL_BCKQHDKD")
    BCN._khoi_ct(n, "NamNay", B02_MA, {m: b02[m][0] for m in B02_MA})
    BCN._khoi_ct(n, "NamTruoc", B02_MA, {m: b02[m][1] for m in B02_MA})
    p = os.path.join(thumuc, "58_BCTC_%d.xml" % k["nam"])
    BCN._ghi_xml(goc, p)
    S._tt58_xml = p
    return p


# ============================================================ driver
HAM = {"SS_58S1": lap_s1, "SS_58S2B": lap_s2b, "SS_58S2C": lap_s2c, "SS_58S2D": lap_s2d, "SS_58S3B": lap_s3b, "SS_58S4A": lap_s4a,
       "SS_58S4B": lap_s4b, "SS_58S4C": lap_s4c, "SS_58S4D": lap_s4d, "SS_58B01": lap_b01, "SS_58B02": lap_b02}


def lap(dl, ma, kieu, thumuc):
    ma = str(ma or "").strip().upper()
    if ma not in HAM:
        raise ValueError("Mẫu %s không thuộc bộ sổ TT 58/2026" % ma)
    S = so_lieu(dl)
    pp, chon = phuong_phap(S)
    cb = []
    da = getattr(S, "_tt58_da_bao", None)
    if da is None:
        da = S._tt58_da_bao = set()
        cb.append("TT 58/2026 - %s%s. Sổ bắt buộc của trường hợp này: %s; S4a - S4d tự chọn. Phần mềm vẫn hạch toán theo tài khoản; các sổ "
                  "TT58 lập từ chứng từ và số dư (chỉ đọc)." % (PP_TEN[pp], "" if chon else " (TỰ NHẬN BIẾT từ sổ - chọn lại ở menu Dữ liệu nếu khác)",
                                                                ", ".join(TEN_MAU[x].split(" - ", 1)[1].split(" (")[0] for x in PP_SO[pp])))
    kieu = str(kieu or "E").upper()
    tep = []
    if "E" in kieu or ma not in ("SS_58B01", "SS_58B02"):
        B, cb2 = HAM[ma](S, pp)
        tep.append(B.luu(thumuc))
        cb += cb2
    if ma in ("SS_58B01", "SS_58B02") and "X" in kieu:
        p = lap_xml_58(S, thumuc, cb)
        if p not in tep:
            tep.append(p)
    elif ma not in ("SS_58B01", "SS_58B02") and "E" not in kieu:
        cb.append("Sổ TT58 chỉ lập Excel (không có XML HTKK)")
    them = [x for x in S.cb if x not in cb and x not in da]
    da.update(them)
    return {"tep": tep, "canh_bao": them + cb}
