@echo off
chcp 65001 >nul
rem TẢI HOÁ ĐƠN THEO LÔ - người gõ mã captcha cổng thuế MỘT lần cho mỗi khách, máy tải hết các tháng còn thiếu rồi sang khách sau.
rem Không giải / bỏ qua captcha, không đọc / lưu mật khẩu. Đọc sổ CHỈ ĐỌC (SELECT). Tham số thêm (vd /so:A_2026 /den_thang:9) được chuyển cho script.
rem Bản 1.1: hoá đơn KHÔNG có XML gốc (điện, nước, ngân hàng...) được ghi CSV mẫu 1 vào hoa_don\mua, hoa_don\ban để bước Tải hoá đơn nhập như hoá đơn khác.
rem          Hoá đơn máy tính tiền: nếu cổng đòi thêm mã captcha thì máy hỏi DỒN ngay sau khi đăng nhập (mỗi trang 50 HĐ một mã, người gõ).
rem          Tải đủ tháng nào thì ghi tệp đề nghị ghi sổ vào LENH\de_nghi cho ERP ra lệnh tai_hd.
rem Tham số: /tu_ghi:khong = không ghi đề nghị ghi sổ.   /mtt_dung_lai:co = thử dùng một mã cho các trang sau của CÙNG một lần tìm (cổng từ chối thì thôi hẳn).
rem          /mtt:bo = không tải hoá đơn máy tính tiền.   /loai:dt hoặc /loai:mtt = chỉ một loại.
setlocal
cd /d "%~dp0"
set "PY=python"
where python >nul 2>nul
if errorlevel 1 (
    where py >nul 2>nul
    if errorlevel 1 (
        echo LỖI: không thấy Python. Cài Python 3.10 trở lên rồi chạy lại.
        pause
        exit /b 1
    )
    set "PY=py -3"
)
set "DS=%~dp0ket-qua\tai_lo\danh_sach_tai_lo.csv"

:menu
echo.
echo ================ TẢI HOÁ ĐƠN THEO LÔ ================
echo  1. Lập danh sách khách x tháng còn thiếu hoá đơn (chỉ đọc sổ)
echo  2. Mở danh sách để sửa (Excel)
echo  3. Bắt đầu tải theo lô (người gõ captcha cho từng khách)
echo  4. Xem kết quả hôm nay
echo  0. Thoát
echo =====================================================
set "CHON="
set /p CHON=Chọn số rồi Enter:
if "%CHON%"=="1" (
    %PY% -X utf8 "%~dp0tai_hoa_don_theo_lo.py" danh_sach %*
    goto :menu
)
if "%CHON%"=="2" (
    if exist "%DS%" (start "" "%DS%") else (echo Chưa có danh sách - chọn 1 trước.)
    goto :menu
)
if "%CHON%"=="3" (
    %PY% -X utf8 "%~dp0tai_hoa_don_theo_lo.py" chay %*
    goto :menu
)
if "%CHON%"=="4" (
    %PY% -X utf8 "%~dp0tai_hoa_don_theo_lo.py" xem %*
    goto :menu
)
if "%CHON%"=="0" exit /b 0
goto :menu
