# -*- coding: utf-8 -*-
"""GD153 - SOAT RUI RO HOA DON TRUOC KY KHAI 01/GTGT (lo trinh B1) - chi DOC so, chi DANH DAU, khong ghi so.

VB6 (ModRuiRoHD.RR153_Json) gui JSON = doi chieu GD69 (hddt, ct, hd, ky, cty) + khoi rieng:
  hom_nay : dd/mm/yyyy
  hdm     : hoa don MUA trong ky tren bang ke (HoaDon Loai = -1) gop theo so + ky hieu + NCC:
            [so, ky hieu, ma NCC, ngay, chua thue, thue, TK Co nho nhat, MaCT, so hieu CT, MST NCC, ten NCC]
  tt      : tra tien cho NCC (No 331x) tu dau ky den hom nay: [ma NCC, ngay, tien, TK Co, MaCT]
  kqkt    : [MaCT hoa don dien tu, ket qua kiem tra tren CQT] (khac rong)
  nnt     : trang thai nguoi nop thue da biet: [mst, ma (HD/NHD/DONG/KHD/TAM), trang thai, ngay kiem, nguon]
  dau     : dau da danh: [khoa, ma R, loai (LOAI_KT/BO_QUA), ghi chu]
Bay nhom (R6, R7 tu GD170):
  R1 hoa don mua tu 5 trieu (ke ca nhieu hoa don cung NCC cung ngay) - chung tu thanh toan khong dung tien mat
  R2 hoa don da hach toan nhung bi huy / thay the / dieu chinh; hach toan trung; lech tien; chua len bang ke; ban ra chua hach toan
  R3 nguoi ban rui ro (trang thai NNT), hoa don bi CQT tu choi / khong du dieu kien cap ma; nguoi ban chua tra cuu
  R4 hoa don ky hieu co ma (C) chua co ma CQT; tai trung; khong mang MST cong ty
  R5 so co (bang ke) nhung khong thay tren CQT (chieu nguoc GD69)
  R6 thoi diem lap / ky hoa don (ND 254/2026): ky so sau ngay lap qua ngay lam viec tiep theo, ky truoc ngay lap, ban ra lap sau ngay
     chung tu, mua vao ky truoc hach toan ky nay (hddt[18] = NgayNguoiBanKySo)
  R7 nguoi ban trong danh sach DN rui ro cao ve hoa don do CQT cong bo (AIHoaDon\\dn-rui-ro\\*.xlsx|csv - nguoi dung tu tai ve)
Ket qua: Excel (8 sheet) + AIHoaDon\\ket-qua\\rui_ro_hd.txt cho VB6:
  TONG;loi;canh bao;thong tin;tu;den
  CHUA_TRA;mst1,mst2,...
  R;ma;muc;khoa;MaCT;so;ngay;mst;doi tac;tien;dau;ket luan
Can cu: Luat Thue GTGT 48/2024/QH15 (Dieu 14) va ND 181/2025/ND-CP (Dieu 26): tu 01/7/2025 hoa don tu 5 trieu dong (da gom thue)
phai co chung tu thanh toan khong dung tien mat; mua nhieu lan cung ngay tong tu 5 trieu cung vay. ND 70/2025 (sua ND 123/2020):
hoa don huy / thay the / dieu chinh.
"""
import json
import os
import re
import unicodedata
from collections import defaultdict

import doi_chieu_hd as DC

LOI, CANH_BAO, DAT, THONG_TIN = "LOI", "CANH_BAO", "DAT", "THONG_TIN"
TEN_MUC = {LOI: "LỖI", CANH_BAO: "CẦN XEM", DAT: "ĐẠT", THONG_TIN: "THÔNG TIN", "BO_QUA": "ĐÃ BỎ QUA"}
MOC_5TR = 5000000.0
SAI_SO = 10.0
NGAY_TRA_LAI = 180                     # trang thai NNT tra cuu qua 180 ngay -> nen tra lai
TEN_NHOM = {"R1": "R1 Hoá đơn từ 5 triệu - thanh toán không dùng tiền mặt",
            "R2": "R2 Hoá đơn bị huỷ / thay thế / điều chỉnh, trùng, lệch, chưa kê khai",
            "R3": "R3 Người bán rủi ro, hoá đơn bị CQT từ chối",
            "R4": "R4 Chưa có mã CQT, tải trùng, không mang MST công ty",
            "R5": "R5 Sổ có hoá đơn nhưng không thấy trên CQT",
            "R6": "R6 Thời điểm lập / ký hoá đơn",
            "R7": "R7 Người bán trong danh sách rủi ro CQT"}
NHOM = ("R1", "R2", "R3", "R4", "R5", "R6", "R7")
TEN_NNT = {"HD": "Đang hoạt động", "NHD": "Ngừng hoạt động, chưa hoàn thành thủ tục đóng MST",
           "DONG": "Ngừng hoạt động, đã đóng MST", "KHD": "Không hoạt động tại địa chỉ đã đăng ký",
           "TAM": "Tạm ngừng kinh doanh có thời hạn"}
CAN_CU_5TR = ("Luật Thuế GTGT 48/2024/QH15 (Điều 14) và Nghị định 181/2025/NĐ-CP (Điều 26): từ 01/7/2025 hoá đơn mua hàng hoá, "
              "dịch vụ từ 5 triệu đồng trở lên (đã gồm thuế GTGT) phải có chứng từ thanh toán không dùng tiền mặt mới được khấu trừ; "
              "mua nhiều lần trong cùng ngày của cùng người bán có tổng từ 5 triệu đồng cũng vậy. Chưa đến hạn thanh toán vẫn được khấu trừ; "
              "khi trả bằng tiền mặt phải kê khai điều chỉnh giảm.")

_so, _dd, bo_dau, mst10, so_hd, ky_hieu, ngay_iso = DC._so, DC._dd, DC.bo_dau, DC.mst10, DC.so_hd, DC.ky_hieu, DC.ngay_iso



def moc_5tr(ngay):
    """GD156: moc thanh toan khong dung tien mat tai ngay hoa don (bo tham so nam: 20 trieu truoc 01/7/2025, 5 trieu tu 01/7/2025)."""
    try:
        import tham_so_nam as TS
        v = TS.lay("MOC_TT_KHONG_TM", ngay, None)
        return float(v) if v else MOC_5TR
    except Exception:
        return MOC_5TR


def _sach(s, n=400):
    s = str(s if s is not None else "").replace("\r", " ").replace("\n", " ").replace(";", ",")
    return s[:n]


def _ngay_vn(iso):
    return "%s/%s/%s" % (iso[8:10], iso[5:7], iso[:4]) if len(iso) == 10 else ""


def tien_mat(tk):
    return str(tk or "").startswith("111")


def khong_tien_mat(tk):
    return str(tk or "").startswith(("112", "113", "341"))


def cong_no(tk):
    return str(tk or "").startswith(("331", "338"))


def ma_nnt(trang_thai):
    """chu trang thai (tra cuu cong thue) -> ma HD / NHD / DONG / KHD / TAM / '' (khong nhan ra)."""
    t = bo_dau(trang_thai).upper()
    if "KHONG HOAT DONG TAI DIA CHI" in t:
        return "KHD"
    if "TAM NGUNG" in t or "TAM NGHI" in t or "TAM DUNG" in t:
        return "TAM"
    if "NGUNG HOAT DONG" in t or "CHAM DUT" in t or "GIAI THE" in t or "PHA SAN" in t:
        if "CHUA HOAN THANH" in t or "CHUA DONG" in t:
            return "NHD"
        if "DA DONG" in t or "DA HOAN THANH" in t or "DONG MST" in t:
            return "DONG"
        return "NHD"
    if "DANG HOAT DONG" in t or "HOAT DONG BINH THUONG" in t or t.strip() == "HOAT DONG":
        return "HD"
    return ""


def _dong(ma, muc, khoa, ma_kt, so, ngay, mst, doi_tac, tien, ket_luan, chieu="", them=None):
    r = {"ma": ma, "muc": muc, "khoa": khoa or "", "ma_kt": int(ma_kt or 0), "so": str(so or ""), "ngay": str(ngay or ""),
         "mst": str(mst or ""), "doi_tac": str(doi_tac or ""), "tien": float(tien or 0), "ket_luan": ket_luan, "chieu": chieu,
         "dau": "", "ghi_chu_dau": ""}
    if them:
        r.update(them)
    return r


# ============================================================ R1: 5 trieu - thanh toan
def tk_co_phieu(dl):
    """GD355: phieu nhieu dong (moi dong mot TK, dong thue / hang khong ghi TK Co) -> MaCT: TK Co dai dien cua ca phieu.
       Co dong tien mat (111) thi lay 111 (de con bao LOI), khong thi TK Co co so tien lon nhat."""
    gom = defaultdict(lambda: defaultdict(float))
    for r in dl.get("ctco") or []:
        r = list(r) + [None] * (3 - len(r))
        mact, tk = int(_so(r[0])), str(r[1] or "").strip()
        if mact and tk:
            gom[mact][tk] += _so(r[2])
    ra = {}
    for mact, d in gom.items():
        tm = [k for k in d if tien_mat(k)]
        ra[mact] = tm[0] if tm else max(d.items(), key=lambda kv: kv[1])[0]
    return ra


def r1_nam_trieu(dl):
    hom_nay = ngay_iso(dl.get("hom_nay")) or "9999-12-31"
    co_phieu = tk_co_phieu(dl)
    tra = defaultdict(list)
    for r in dl.get("tt") or []:
        r = list(r) + [None] * (5 - len(r))
        kh = int(_so(r[0]))
        tk = str(r[3] or "").strip() or co_phieu.get(int(_so(r[4])), "")          # GD355: dong No 331 khong ghi TK Co
        if kh:
            tra[kh].append({"ngay": ngay_iso(r[1]), "ngay_vn": str(r[1] or ""), "tien": _so(r[2]), "tk": tk, "mact": int(_so(r[4]))})
    hd = []
    for r in dl.get("hdm") or []:
        r = list(r) + [None] * (11 - len(r))
        e = {"so": str(r[0] or "").strip(), "kh2": str(r[1] or "").strip(), "makh": int(_so(r[2])), "ngay": ngay_iso(r[3]),
             "ngay_vn": str(r[3] or ""), "gt": _so(r[4]), "thue": _so(r[5]), "tk": str(r[6] or "").strip(), "mact": int(_so(r[7])),
             "sh": str(r[8] or "").strip(), "mst": mst10(r[9]), "ten": str(r[10] or "").strip()}
        e["tong"] = e["gt"] + e["thue"]
        if not e["tk"]:                                    # GD355: dong hoa don (thuong la dong thue 133) khong ghi TK Co -> TK Co cua ca phieu
            e["tk"] = co_phieu.get(e["mact"], "")
        hd.append(e)
    kq = []

    def khoa(e):
        return "HD:%s|%s" % (e["so"], e["mst"] or e["makh"])

    def thanh_toan_sau(e):
        """(tien mat, chuyen khoan, ngay tien mat, ngay chuyen khoan) cho NCC ke tu ngay hoa don den hom nay."""
        tm = ck = 0.0
        n_tm, n_ck = [], []
        for p in tra.get(e["makh"], []):
            if not p["ngay"] or p["ngay"] < e["ngay"] or p["ngay"] > hom_nay:
                continue
            if tien_mat(p["tk"]):
                tm += p["tien"]
                n_tm.append(p["ngay_vn"])
            elif khong_tien_mat(p["tk"]):
                ck += p["tien"]
                n_ck.append(p["ngay_vn"])
        return tm, ck, sorted(set(n_tm))[:4], sorted(set(n_ck))[:4]
    for e in hd:
        if e["tong"] < moc_5tr(e["ngay"]):
            continue
        if tien_mat(e["tk"]):
            kq.append(_dong("R1", LOI, khoa(e), e["mact"], e["so"], e["ngay_vn"], e["mst"], e["ten"], e["tong"],
                            "Hoá đơn %s trả bằng TIỀN MẶT (Có %s) - thuế GTGT %s KHÔNG được khấu trừ: giảm chỉ tiêu [25] hoặc, nếu thực tế "
                            "trả qua ngân hàng, sửa tài khoản Có trên chứng từ rồi soát lại." % (_dd(e["tong"]), e["tk"], _dd(e["thue"])),
                            "mua", {"tk": e["tk"], "thue": e["thue"], "trang_thai": "Trả tiền mặt"}))
        elif khong_tien_mat(e["tk"]):
            kq.append(_dong("R1", DAT, khoa(e), e["mact"], e["so"], e["ngay_vn"], e["mst"], e["ten"], e["tong"],
                            "Thanh toán không dùng tiền mặt ngay trên chứng từ (Có %s)." % e["tk"], "mua",
                            {"tk": e["tk"], "thue": e["thue"], "trang_thai": "Đã chuyển khoản"}))
        elif cong_no(e["tk"]):
            tm, ck, n_tm, n_ck = thanh_toan_sau(e)
            if tm > 0:
                kq.append(_dong("R1", CANH_BAO, khoa(e), e["mact"], e["so"], e["ngay_vn"], e["mst"], e["ten"], e["tong"],
                                "Ghi công nợ %s nhưng NCC được trả TIỀN MẶT %s sau ngày hoá đơn (ngày %s) - nếu khoản này trả cho hoá đơn này "
                                "thì thuế %s không được khấu trừ; kiểm chứng từ chi, đổi sang chuyển khoản hoặc đánh dấu loại khấu trừ." % (
                                    e["tk"], _dd(tm), ", ".join(n_tm), _dd(e["thue"])), "mua",
                                {"tk": e["tk"], "thue": e["thue"], "trang_thai": "Công nợ - có trả tiền mặt %s" % _dd(tm)}))
            elif ck >= e["tong"] - SAI_SO:
                kq.append(_dong("R1", DAT, khoa(e), e["mact"], e["so"], e["ngay_vn"], e["mst"], e["ten"], e["tong"],
                                "Đã chuyển khoản cho NCC %s (ngày %s) - đủ điều kiện khấu trừ." % (_dd(ck), ", ".join(n_ck)), "mua",
                                {"tk": e["tk"], "thue": e["thue"], "trang_thai": "Đã chuyển khoản %s" % _dd(ck)}))
            elif ck > 0:
                kq.append(_dong("R1", THONG_TIN, khoa(e), e["mact"], e["so"], e["ngay_vn"], e["mst"], e["ten"], e["tong"],
                                "Đã chuyển khoản một phần %s (ngày %s), còn %s chưa trả - phần còn lại khi trả phải chuyển khoản." % (
                                    _dd(ck), ", ".join(n_ck), _dd(e["tong"] - ck)), "mua",
                                {"tk": e["tk"], "thue": e["thue"], "trang_thai": "Chuyển khoản một phần %s" % _dd(ck)}))
            else:
                kq.append(_dong("R1", THONG_TIN, khoa(e), e["mact"], e["so"], e["ngay_vn"], e["mst"], e["ten"], e["tong"],
                                "Chưa thanh toán (còn nợ %s) - vẫn được khấu trừ; khi trả phải chuyển khoản, trả tiền mặt thì phải kê khai "
                                "điều chỉnh giảm." % e["tk"], "mua", {"tk": e["tk"], "thue": e["thue"], "trang_thai": "Chưa thanh toán"}))
        else:
            kq.append(_dong("R1", CANH_BAO, khoa(e), e["mact"], e["so"], e["ngay_vn"], e["mst"], e["ten"], e["tong"],
                            "Tài khoản Có %s - không rõ hình thức thanh toán (tạm ứng, bù trừ, khác): kiểm chứng từ thanh toán không dùng "
                            "tiền mặt tương ứng." % (e["tk"] or "(trống)"), "mua",
                            {"tk": e["tk"], "thue": e["thue"], "trang_thai": "Không rõ"}))
    # nhieu hoa don < 5 trieu cung NCC cung ngay, tong >= 5 trieu, co hoa don tra tien mat
    nhom = defaultdict(list)
    for e in hd:
        if 0 < e["tong"] < moc_5tr(e["ngay"]) and e["ngay"]:
            nhom[(e["makh"], e["ngay"])].append(e)
    for (makh, ngay), ds in sorted(nhom.items()):
        tong = sum(e["tong"] for e in ds)
        if len(ds) < 2 or tong < moc_5tr(ngay):
            continue
        tm = [e for e in ds if tien_mat(e["tk"])]
        if not tm:
            continue
        e0 = ds[0]
        kq.append(_dong("R1", LOI, "HDN:%s|%s" % (e0["mst"] or makh, ngay), tm[0]["mact"], "%d HĐ" % len(ds), e0["ngay_vn"], e0["mst"], e0["ten"], tong,
                        "Cùng người bán, cùng ngày %d hoá đơn tổng %s (từ mốc thanh toán không dùng tiền mặt), trong đó %d hoá đơn trả tiền mặt (số %s, thuế %s) - phần trả "
                        "tiền mặt không được khấu trừ." % (len(ds), _dd(tong), len(tm), ", ".join(e["so"] for e in tm)[:60],
                                                          _dd(sum(e["thue"] for e in tm))), "mua",
                        {"tk": "111", "thue": sum(e["thue"] for e in tm), "trang_thai": "Nhiều HĐ cùng ngày, trả tiền mặt"}))
    return kq


# ============================================================ R2 + R4 + R5: tu doi chieu GD69
def _ma_kt_cua(S, r):
    if r.get("ma_kt") and r["ma_kt"] in S.ct:
        return r["ma_kt"]
    return r["ct"][0] if r.get("ct") else 0


def r2_r4_r5(dl):
    S, kq_dc, nguoc, chua_tai = DC.doi_chieu(dl)
    kq = []
    for r in kq_dc:
        if not r.get("trong_ky"):
            continue
        lk, chieu = r.get("loai_kq"), r.get("chieu")
        ma_kt = _ma_kt_cua(S, r)
        chung = (r["ma"], ma_kt, r["so"], r["ngay_vn"], r["doi_tac_mst"], r["doi_tac"], r["tong"] or (r["tien"] + r["thue"]))
        if chieu == "khac":
            kq.append(_dong("R4", CANH_BAO, *chung, ket_luan="Hoá đơn không mang MST công ty (người bán và người mua đều khác) - kiểm tài khoản "
                            "tra cứu hoá đơn / hoá đơn tải nhầm; không kê khai.", chieu=chieu, them={"tt": r.get("tt", "")}))
            continue
        if lk in ("huy_da_ht", "trung"):
            kq.append(_dong("R2", LOI, *chung, ket_luan=r["ket_luan"], chieu=chieu, them={"tt": r.get("tt", ""), "loai_kq": lk}))
        elif lk in ("dieu_chinh", "lech", "nhieu_ct"):
            kq.append(_dong("R2", CANH_BAO, *chung, ket_luan=r["ket_luan"], chieu=chieu, them={"tt": r.get("tt", ""), "loai_kq": lk}))
        elif lk == "chua_bk":
            kq.append(_dong("R2", LOI if chieu == "ban" else CANH_BAO, *chung, ket_luan=r["ket_luan"] +
                            (" - thiếu thuế đầu ra kỳ này." if chieu == "ban" else " - nếu bỏ sót thì khấu trừ bổ sung."), chieu=chieu,
                            them={"tt": r.get("tt", ""), "loai_kq": lk}))
        elif lk == "chua_ht":
            if chieu == "ban":
                kq.append(_dong("R2", LOI, *chung, ket_luan="Hoá đơn BÁN RA có trên CQT nhưng chưa hạch toán - thiếu doanh thu và thuế đầu ra "
                                "kỳ này; hạch toán trước khi lập 01/GTGT (hoá đơn huỷ / bị thay thế thì không cần).", chieu=chieu,
                                them={"tt": r.get("tt", ""), "loai_kq": lk}))
            else:
                kq.append(_dong("R2", THONG_TIN, *chung, ket_luan="Hoá đơn mua vào chưa hạch toán - chưa khấu trừ kỳ này (có thể khấu trừ khi "
                                "hạch toán; hoá đơn bị điều chỉnh thì kèm hoá đơn điều chỉnh).", chieu=chieu, them={"tt": r.get("tt", ""), "loai_kq": lk}))
        # khong_can (huy / bi thay the chua hach toan) va khop: khong liet ke (xem bao cao Doi chieu HDDT GD69)
    # R4: ky hieu co ma (C) nhung chua co ma CQT ; tai trung
    theo = defaultdict(list)
    for e in S.hddt:
        if not e["trong_ky"] or e["chieu"] == "khac":
            continue
        kh = re.sub(r"^\d+", "", e["kh"].strip().upper())       # ky hieu hoa don: C = co ma CQT, K = khong ma (mau so tach rieng)
        if kh[:1] == "C" and not e["cqt"].strip():
            kq.append(_dong("R4", CANH_BAO, e["ma"], e["ma_kt"] if e["ma_kt"] in S.ct else 0, e["so"], e["ngay_vn"], e["doi_tac_mst"], e["doi_tac"],
                            e["tong"] or (e["tien"] + e["thue"]),
                            "Ký hiệu %s là hoá đơn có mã của CQT nhưng chưa có mã - tải lại / tra cứu trên CQT; hoá đơn chưa được cấp mã không hợp lệ%s." % (
                                e["kh"], " để khấu trừ" if e["chieu"] == "mua" else ""), e["chieu"], {"tt": e["tt"]}))
        theo[(mst10(e["mst_ban"]), ky_hieu(e["kh"]), so_hd(e["so"]))].append(e)
    for k, ds in theo.items():
        if len(ds) < 2 or not k[2]:
            continue
        ds.sort(key=lambda x: x["ma"])
        n_ht = sum(1 for x in ds if x["ma_kt"])
        for x in ds[1:]:
            kq.append(_dong("R4", LOI if n_ht >= 2 else CANH_BAO, x["ma"], x["ma_kt"] if x["ma_kt"] in S.ct else 0, x["so"], x["ngay_vn"], x["doi_tac_mst"],
                            x["doi_tac"], x["tong"] or (x["tien"] + x["thue"]),
                            "Hoá đơn tải TRÙNG %d lần (cùng người bán, ký hiệu, số)%s - giữ một bản, xoá bản thừa ở danh sách hoá đơn." % (
                                len(ds), "; đã hạch toán %d bản - hạch toán trùng" % n_ht if n_ht >= 2 else ""), x["chieu"], {"tt": x["tt"]}))
    # R5: so co - CQT khong
    for g in nguoc:
        chieu = "mua" if g["loai"] == -1 else "ban"
        ma_kt = sorted(g["ct"])[0] if g["ct"] else 0
        kq.append(_dong("R5", LOI if chieu == "ban" else CANH_BAO, "HD:%s|%s" % (g["so_goc"], g["mst"] or g["ma_kh"]), ma_kt, g["so_goc"], g["ngay_vn"],
                        g["mst"], (g["ma_kh"] + " " + g["ten"]).strip(), g["tien"] + g["thue"],
                        ("Hoá đơn BÁN RA trong sổ không thấy trên CQT (đã tải chiều bán ra kỳ này) - hoá đơn chưa gửi / chưa được cấp mã? Kiểm số, ký "
                         "hiệu, MST; tải lại rồi soát lại." if chieu == "ban" else
                         "Hoá đơn mua vào trong sổ không thấy trên CQT (đã tải chiều mua vào kỳ này) - kiểm số, ký hiệu, MST người bán; hoá đơn giấy / "
                         "hoá đơn chưa tải thì tải lại; không có trên CQT thì rủi ro khấu trừ."), chieu, {"ky_hieu": ", ".join(sorted(k for k in g["kh"] if k))}))
    return S, kq, chua_tai


# ============================================================ R3: nguoi ban
def r3_nguoi_ban(dl, S):
    hom_nay = ngay_iso(dl.get("hom_nay"))
    nnt = {}
    for r in dl.get("nnt") or []:
        r = list(r) + [None] * (5 - len(r))
        m = mst10(r[0])
        if m:
            ma = str(r[1] or "").strip().upper() or ma_nnt(r[2])
            nnt[m] = {"ma": ma, "tt": str(r[2] or "").strip() or TEN_NNT.get(ma, ""), "ngay": ngay_iso(r[3]), "ngay_vn": str(r[3] or ""), "nguon": str(r[4] or "")}
    kq = []
    ban = defaultdict(lambda: {"ten": "", "tong": 0.0, "n": 0, "ma": "", "ma_kt": 0, "so": "", "ngay": ""})
    for e in S.hddt:
        if e["chieu"] != "mua" or not e["trong_ky"]:
            continue
        m = mst10(e["mst_ban"])
        if not m:
            continue
        b = ban[m]
        b["ten"] = b["ten"] or e["ten_ban"]
        b["tong"] += e["tong"] or (e["tien"] + e["thue"])
        b["n"] += 1
        if not b["ma"]:
            b["ma"], b["ma_kt"], b["so"], b["ngay"] = e["ma"], e["ma_kt"] if e["ma_kt"] in S.ct else 0, e["so"], e["ngay_vn"]
    for r in dl.get("hdm") or []:           # hoa don nhap tay (khong co HDDT)
        r = list(r) + [None] * (11 - len(r))
        m = mst10(r[9])
        if m and m not in ban:
            b = ban[m]
            b["ten"], b["tong"], b["n"], b["ma_kt"], b["so"], b["ngay"] = str(r[10] or ""), _so(r[4]) + _so(r[5]), 1, int(_so(r[7])), str(r[0] or ""), str(r[3] or "")
    chua_tra, tra_lai = [], []
    for m, b in sorted(ban.items(), key=lambda kv: -kv[1]["tong"]):
        x = nnt.get(m)
        if not x:
            chua_tra.append(m)
            continue
        cu = bool(hom_nay and x["ngay"] and _khoang_ngay(x["ngay"], hom_nay) > NGAY_TRA_LAI)
        if x["ma"] in ("DONG", "KHD", "NHD"):
            kq.append(_dong("R3", LOI, "NNT:" + m, b["ma_kt"], "%d HĐ" % b["n"], b["ngay"], m, b["ten"], b["tong"],
                            "Người bán %s (tra cứu %s%s) - %d hoá đơn, tổng %s trong kỳ: rủi ro cao về khấu trừ và chi phí; rà soát tính có thật "
                            "(hợp đồng, giao hàng, thanh toán qua ngân hàng), giữ hồ sơ; cân nhắc đánh dấu loại khấu trừ." % (
                                x["tt"] or TEN_NNT.get(x["ma"], x["ma"]), x["ngay_vn"], ", " + x["nguon"].lower() if x["nguon"] else "", b["n"], _dd(b["tong"])),
                            "mua", {"trang_thai": x["tt"], "ngay_kiem": x["ngay_vn"]}))
        elif x["ma"] == "TAM":
            kq.append(_dong("R3", CANH_BAO, "NNT:" + m, b["ma_kt"], "%d HĐ" % b["n"], b["ngay"], m, b["ten"], b["tong"],
                            "Người bán tạm ngừng kinh doanh (tra cứu %s) - kiểm ngày hoá đơn so với thời gian tạm ngừng." % x["ngay_vn"],
                            "mua", {"trang_thai": x["tt"], "ngay_kiem": x["ngay_vn"]}))
        elif x["ma"] == "HD":
            if cu:
                tra_lai.append(m)
        else:
            chua_tra.append(m)
    if chua_tra:
        kq.append(_dong("R3", THONG_TIN, "", 0, "", "", "", "%d người bán" % len(chua_tra), sum(ban[m]["tong"] for m in chua_tra),
                        "%d người bán trong kỳ chưa tra cứu trạng thái người nộp thuế (tổng hoá đơn %s). Mục 6: chép MST, mở trang tra cứu của cơ "
                        "quan thuế (anh tự nhập mã xác nhận); mục 7: dán kết quả. Ưu tiên người bán mới, hoá đơn lớn." % (
                            len(chua_tra), _dd(sum(ban[m]["tong"] for m in chua_tra))), "mua", {"ds": chua_tra}))
    if tra_lai:
        kq.append(_dong("R3", THONG_TIN, "", 0, "", "", "", "%d người bán" % len(tra_lai), sum(ban[m]["tong"] for m in tra_lai),
                        "%d người bán đã tra cứu quá %d ngày - nên tra cứu lại (mục 6, 7)." % (len(tra_lai), NGAY_TRA_LAI), "mua", {"ds": tra_lai}))
    # hoa don bi CQT tu choi / khong du dieu kien cap ma
    theo_ma = {e["ma"]: e for e in S.hddt}
    for r in dl.get("kqkt") or []:
        r = list(r) + [None] * (2 - len(r))
        kqc = bo_dau(r[1]).upper()
        if "TU CHOI" in kqc or "KHONG DU DIEU KIEN" in kqc:
            e = theo_ma.get(str(r[0] or ""))
            if e is None or not e["trong_ky"]:
                continue
            kq.append(_dong("R3", LOI, e["ma"], e["ma_kt"] if e["ma_kt"] in S.ct else 0, e["so"], e["ngay_vn"], e["doi_tac_mst"], e["doi_tac"],
                            e["tong"] or (e["tien"] + e["thue"]), "Kết quả kiểm tra trên CQT: %s - hoá đơn không hợp lệ, không kê khai%s." % (
                                str(r[1] or "").strip(), "; nếu đã hạch toán thì loại khỏi khấu trừ" if e["ma_kt"] else ""), e["chieu"], {"kq": str(r[1] or "")}))
    return kq, chua_tra


def _khoang_ngay(iso1, iso2):
    import datetime
    try:
        a = datetime.date(int(iso1[:4]), int(iso1[5:7]), int(iso1[8:10]))
        b = datetime.date(int(iso2[:4]), int(iso2[5:7]), int(iso2[8:10]))
        return (b - a).days
    except (ValueError, TypeError):
        return 0


# ============================================================ GD170: R6 thoi diem lap / ky hoa don - R7 nguoi ban trong danh sach rui ro CQT
CAN_CU_R6 = ("Nghị định 254/2026/NĐ-CP về hoá đơn, chứng từ (thay NĐ 123/2020, NĐ 70/2025): lập hoá đơn đúng thời điểm giao hàng / "
             "hoàn thành dịch vụ; ký số chậm nhất ngày làm việc tiếp theo kể từ thời điểm lập; Nghị định 310/2025/NĐ-CP xử phạt lập "
             "hoá đơn sai thời điểm.")
NGAY_KY_CHAM = 1                        # ky so sau ngay lap qua N ngay -> can xem (ngay lam viec tiep theo; cuoi tuan / le tinh them)
THU_MUC_RUI_RO = "dn-rui-ro"            # AIHoaDon\dn-rui-ro\*.xlsx|xls|csv|txt: danh sach DN rui ro cao ve hoa don (tai tu trang CQT)


def _la_ngay_nghi(d):
    """thu 7 / chu nhat / ngay le (lich nghi cong bo + AIHoaDon\\ngay-nghi-le.txt qua hstk_dvc - chi doc); loi -> chi cuoi tuan."""
    try:
        import hstk_dvc
        return bool(hstk_dvc.la_ngay_nghi(d))
    except Exception:
        return d.weekday() >= 5


def _ngay_lam_viec_sau(iso, n):
    """ngay lam viec thu n sau ngay iso (bo thu 7, chu nhat, ngay le) -> iso."""
    import datetime
    try:
        d = datetime.date(int(iso[:4]), int(iso[5:7]), int(iso[8:10]))
    except (ValueError, TypeError):
        return ""
    k = 0
    while k < n:
        d += datetime.timedelta(days=1)
        if not _la_ngay_nghi(d):
            k += 1
    return d.isoformat()


def r6_thoi_diem(dl, S):
    """R6: (a) ky so sau ngay lap qua 1 ngay lam viec / ky truoc ngay lap; (b) ban ra: hoa don lap sau ngay chung tu (giao hang);
    (c) mua vao: hoa don ngay lap thuoc ky truoc nhung chung tu hach toan trong ky nay (ke khai dung ky phat hien)."""
    kq = []
    ky = dl.get("ky") or {}
    tu, den = ngay_iso(ky.get("tu")), ngay_iso(ky.get("den"))
    for e in S.hddt:
        if e["chieu"] not in ("mua", "ban"):
            continue
        ma_kt = e["ma_kt"] if e["ma_kt"] in S.ct else 0
        ct = S.ct.get(ma_kt) if ma_kt else None
        ngay_ct = ngay_iso(ct["ngay"]) if ct else ""
        if e["trong_ky"] and e.get("ngay_ky") and e["ngay"]:
            if e["ngay_ky"] < e["ngay"]:
                kq.append(_dong("R6", CANH_BAO, e["ma"], ma_kt, e["so"], e["ngay_vn"], e["doi_tac_mst"], e["doi_tac"], e["tong"] or (e["tien"] + e["thue"]),
                                "Ngày ký số (%s) TRƯỚC ngày lập hoá đơn - kiểm tra lại ngày lập / ngày ký trên hoá đơn gốc." % _ngay_vn(e["ngay_ky"]),
                                e["chieu"], {"trang_thai": "ký " + _ngay_vn(e["ngay_ky"])}))
            elif e["ngay_ky"] > _ngay_lam_viec_sau(e["ngay"], NGAY_KY_CHAM):
                muc = CANH_BAO if e["chieu"] == "ban" else THONG_TIN
                kq.append(_dong("R6", muc, e["ma"], ma_kt, e["so"], e["ngay_vn"], e["doi_tac_mst"], e["doi_tac"], e["tong"] or (e["tien"] + e["thue"]),
                                ("Ký số ngày %s, sau ngày lập %d ngày - quá ngày làm việc tiếp theo%s. Kê khai theo ngày lập." % (
                                    _ngay_vn(e["ngay_ky"]), _khoang_ngay(e["ngay"], e["ngay_ky"]),
                                    " (hoá đơn bán ra: rủi ro bị xử phạt lập / ký sai thời điểm)" if e["chieu"] == "ban" else
                                    " (hoá đơn mua vào: ghi nhận, khấu trừ theo ngày lập)")), e["chieu"], {"trang_thai": "ký " + _ngay_vn(e["ngay_ky"])}))
        if e["chieu"] == "ban" and e["trong_ky"] and ngay_ct and e["ngay"] and ngay_ct < e["ngay"]:
            n = _khoang_ngay(ngay_ct, e["ngay"])
            if n >= 1:
                kq.append(_dong("R6", CANH_BAO if n > 1 else THONG_TIN, e["ma"], ma_kt, e["so"], e["ngay_vn"], e["doi_tac_mst"], e["doi_tac"],
                                e["tong"] or (e["tien"] + e["thue"]),
                                "Hoá đơn bán ra lập ngày %s, SAU ngày chứng từ kế toán (%s) %d ngày - nếu đã giao hàng / hoàn thành dịch vụ trước thì "
                                "hoá đơn lập chậm thời điểm; kiểm tra ngày giao hàng, biên bản nghiệm thu." % (e["ngay_vn"], ct["ngay"], n),
                                "ban", {"trang_thai": "CT " + str(ct["ngay"])}))
        if e["chieu"] == "mua" and tu and e["ngay"] and e["ngay"] < tu and ngay_ct and tu <= ngay_ct <= den:
            kq.append(_dong("R6", THONG_TIN, e["ma"], ma_kt, e["so"], e["ngay_vn"], e["doi_tac_mst"], e["doi_tac"], e["tong"] or (e["tien"] + e["thue"]),
                            "Hoá đơn mua vào lập ngày %s (kỳ trước) nhưng hạch toán kỳ này (chứng từ %s) - được kê khai khấu trừ vào kỳ phát hiện "
                            "trước khi cơ quan thuế công bố quyết định kiểm tra (Luật Thuế GTGT 48/2024, Điều 14); ghi nhớ khi lên bảng kê." % (
                                e["ngay_vn"], ct["ngay"]), "mua", {"trang_thai": "CT " + str(ct["ngay"])}))
    return kq


def _chu_mst(o):
    """o Excel -> chu de tim MST: so (mat so 0 dau) -> bu 0 cho du 10 / 13 chu so."""
    if o is None:
        return ""
    if isinstance(o, float) and o.is_integer():
        o = int(o)
    s = str(o).strip()
    if s.endswith(".0"):
        s = s[:-2]
    if s.isdigit() and len(s) in (9, 12):
        s = "0" + s
    return s


def doc_ds_rui_ro(thu_muc):
    """Doc moi tep trong AIHoaDon\\dn-rui-ro (xlsx / xls / csv / txt): lay moi MST 10 / 13 so -> {mst10: ten tep}. Chi doc."""
    ra, tep = {}, []
    try:
        ds = sorted(os.listdir(thu_muc))
    except Exception:
        return ra, tep
    for f in ds:
        p = os.path.join(thu_muc, f)
        if not os.path.isfile(p) or f.startswith("~$") or not f.lower().endswith((".xlsx", ".xls", ".csv", ".txt")):
            continue
        n = 0
        try:
            if f.lower().endswith((".csv", ".txt")):
                with open(p, "r", encoding="utf-8-sig", errors="replace") as g:
                    noi = g.read()
                for m in MST_RE.finditer(noi):
                    k = mst10(m.group(1).replace("-", ""))
                    if k and k not in ra:
                        ra[k] = f
                        n += 1
            else:
                import hd_excel_ai as HX
                sheets, _, _ = HX.doc_tep(p)
                for rows in sheets.values():
                    for row in rows:
                        for o in row:
                            s = _chu_mst(o)
                            for m in MST_RE.finditer(s):
                                k = mst10(m.group(1).replace("-", ""))
                                if k and k not in ra:
                                    ra[k] = f
                                    n += 1
        except Exception:
            continue
        tep.append((f, n))
    return ra, tep


def r7_ds_rui_ro(dl, S):
    """R7: nguoi ban (hoa don mua trong ky) co MST trong danh sach DN rui ro cao ve hoa don do CQT cong bo (tep nguoi dung tai ve)."""
    thu = os.path.join(os.path.dirname(os.path.abspath(__file__)), THU_MUC_RUI_RO)
    ds, tep = doc_ds_rui_ro(thu)
    kq = []
    ban = defaultdict(lambda: {"ten": "", "tong": 0.0, "n": 0, "ma": "", "ma_kt": 0, "so": "", "ngay": ""})
    for e in S.hddt:
        if e["chieu"] != "mua" or not e["trong_ky"]:
            continue
        m = mst10(e["mst_ban"])
        if not m:
            continue
        b = ban[m]
        b["ten"] = b["ten"] or e["ten_ban"]
        b["tong"] += e["tong"] or (e["tien"] + e["thue"])
        b["n"] += 1
        if not b["ma"]:
            b["ma"], b["ma_kt"], b["so"], b["ngay"] = e["ma"], e["ma_kt"] if e["ma_kt"] in S.ct else 0, e["so"], e["ngay_vn"]
    for r in dl.get("hdm") or []:
        r = list(r) + [None] * (11 - len(r))
        m = mst10(r[9])
        if m and m not in ban:
            b = ban[m]
            b["ten"], b["tong"], b["n"], b["ma_kt"], b["so"], b["ngay"] = str(r[10] or ""), _so(r[4]) + _so(r[5]), 1, int(_so(r[7])), str(r[0] or ""), str(r[3] or "")
    if not ds:
        if ban:
            kq.append(_dong("R7", THONG_TIN, "", 0, "", "", "", "%d người bán" % len(ban), sum(b["tong"] for b in ban.values()),
                            "Chưa có danh sách doanh nghiệp rủi ro cao về hoá đơn để đối chiếu %d người bán trong kỳ. Tải danh sách công bố "
                            "(Excel / CSV) từ trang tra cứu hoá đơn của cơ quan thuế, chép vào AIHoaDon\\%s rồi soát lại (mục 9 mở thư mục)." % (
                                len(ban), THU_MUC_RUI_RO), "mua", {"ds": []}))
        return kq, tep
    for m, b in sorted(ban.items(), key=lambda kv: -kv[1]["tong"]):
        if m in ds:
            kq.append(_dong("R7", CANH_BAO, "NNT:" + m, b["ma_kt"], "%d HĐ" % b["n"], b["ngay"], m, b["ten"], b["tong"],
                            "Người bán có MST trong danh sách doanh nghiệp rủi ro cao về hoá đơn do cơ quan thuế công bố (tệp %s) - %d hoá đơn, "
                            "tổng %s trong kỳ: rà soát tính có thật (hợp đồng, giao nhận, thanh toán qua ngân hàng), tra cứu lại trạng thái người "
                            "nộp thuế; cân nhắc đánh dấu loại khấu trừ." % (ds[m], b["n"], _dd(b["tong"])), "mua", {"trang_thai": "DS rủi ro: " + ds[m]}))
    if not kq:
        kq.append(_dong("R7", DAT, "", 0, "", "", "", "%d người bán" % len(ban), sum(b["tong"] for b in ban.values()),
                        "Không người bán nào trong kỳ thuộc danh sách rủi ro (%s)." % ", ".join("%s: %d MST" % t for t in tep[:4]), "mua"))
    return kq, tep


# ============================================================ gop, dau, tong
def ap_dau(dl, ds):
    dau = {}
    for r in dl.get("dau") or []:
        r = list(r) + [None] * (4 - len(r))
        k = (str(r[0] or ""), str(r[1] or ""))
        if k[0]:
            dau[k] = (str(r[2] or "").upper(), str(r[3] or ""))
    for d in ds:
        x = dau.get((d["khoa"], d["ma"]))
        if not x or d["muc"] == DAT:
            continue
        loai, gc = x
        if loai == "BO_QUA":
            d["dau"], d["ghi_chu_dau"], d["muc_goc"], d["muc"] = "BO_QUA", gc, d["muc"], "BO_QUA"
        elif loai == "LOAI_KT":
            d["dau"], d["ghi_chu_dau"], d["muc_goc"] = "LOAI_KT", gc, d["muc"]
            if d["muc"] in (LOI, CANH_BAO):
                d["muc"] = THONG_TIN
            d["ket_luan"] = "ĐÃ ĐÁNH DẤU loại khỏi khấu trừ%s. %s" % ((" (" + gc + ")") if gc else "", d["ket_luan"])
    return ds


def soat(dl):
    ds = r1_nam_trieu(dl)
    S, ds2, chua_tai = r2_r4_r5(dl)
    ds += ds2
    ds3, chua_tra = r3_nguoi_ban(dl, S)
    ds += ds3
    ds += r6_thoi_diem(dl, S)                  # GD170
    ds7, _tep7 = r7_ds_rui_ro(dl, S)
    ds += ds7
    ds = ap_dau(dl, ds)
    thu_tu = {LOI: 0, CANH_BAO: 1, THONG_TIN: 2, DAT: 3, "BO_QUA": 4}
    ds.sort(key=lambda d: (d["ma"], thu_tu.get(d["muc"], 9), ngay_iso(d["ngay"]), so_hd(d["so"]).zfill(12)))
    tong = {m: sum(1 for d in ds if d["muc"] == m) for m in (LOI, CANH_BAO, THONG_TIN, DAT, "BO_QUA")}
    return S, ds, tong, chua_tra, chua_tai


def ghi_ket_qua(dl, ds, tong, chua_tra, ra=None):
    ky = dl.get("ky") or {}
    if ra is None:
        ra = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ket-qua", "rui_ro_hd.txt")
    os.makedirs(os.path.dirname(ra), exist_ok=True)
    dong = ["TONG;%d;%d;%d;%s;%s" % (tong[LOI], tong[CANH_BAO], tong[THONG_TIN], ky.get("tu") or "", ky.get("den") or "")]
    if chua_tra:
        dong.append("CHUA_TRA;%s;;" % ",".join(chua_tra[:200]))
    for d in ds:
        if d["muc"] == DAT:
            continue
        muc = THONG_TIN if d["muc"] == "BO_QUA" else d["muc"]
        dong.append("R;%s;%s;%s;%d;%s;%s;%s;%s;%s;%s;%s" % (d["ma"], muc, _sach(d["khoa"], 250), d["ma_kt"], _sach(d["so"], 30), _sach(d["ngay"], 10),
                                                        _sach(d["mst"], 20), _sach(d["doi_tac"], 80), _dd(d["tien"]).replace(".", ""), d["dau"],
                                                        _sach(d["ket_luan"], 600)))
    tmp = ra + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write("\n".join(dong) + "\n")
    os.replace(tmp, ra)
    return ra


# ============================================================ Excel
def lap_excel(dl, ra):
    import tool_htkk_unesco as X
    S, ds, tong, chua_tra, chua_tai = soat(dl)
    cty = dl.get("cty") or {}
    ky = dl.get("ky") or {}
    kieu = {LOI: X.X_DO, CANH_BAO: X.X_VANG, DAT: X.X_XANH, THONG_TIN: X.X_CHU, "BO_QUA": X.X_CHU}
    T = [[("SOÁT RỦI RO HOÁ ĐƠN TRƯỚC KỲ KHAI 01/GTGT - CHỈ ĐỌC SỔ, CHỈ ĐÁNH DẤU, KHÔNG TỰ SỬA", X.X_TITLE)],
         [("Đơn vị: %s    MST: %s    Kỳ: %s - %s    Ngày soát: %s" % (cty.get("ten") or "", cty.get("mst") or "", ky.get("tu") or "", ky.get("den") or "",
                                                                          dl.get("hom_nay") or ""), X.X_THUONG)],
         [(("CÓ %d LỖI, %d DÒNG CẦN XEM" % (tong[LOI], tong[CANH_BAO])) if tong[LOI] or tong[CANH_BAO] else "KHÔNG CÓ LỖI, KHÔNG CÓ DÒNG CẦN XEM", X.X_DAM)], [],
         [(c, X.X_TIEUDE) for c in ("Nhóm", "Lỗi", "Cần xem", "Thông tin", "Đạt", "Đã bỏ qua", "Nội dung kiểm")]]
    noi = {"R1": "Hoá đơn mua từ 5 triệu (đã gồm thuế): trả tiền mặt (lỗi), công nợ có trả tiền mặt (cần xem), chưa trả / trả một phần (thông tin), "
                 "đã chuyển khoản (đạt); nhiều hoá đơn cùng người bán cùng ngày tổng từ 5 triệu.",
           "R2": "Đối chiếu từng hoá đơn điện tử với sổ (GĐ69): đã hạch toán nhưng bị huỷ / thay thế (lỗi), trùng (lỗi), bị điều chỉnh / lệch tiền / "
                 "nhiều chứng từ (cần xem), chưa lên bảng kê, bán ra trên CQT chưa hạch toán (lỗi).",
           "R3": "Trạng thái người nộp thuế của người bán (bảng HDDT_NNT - nhập tay / dán kết quả tra cứu): ngừng hoạt động, đã đóng MST, không hoạt "
                 "động tại địa chỉ (lỗi), tạm ngừng (cần xem); hoá đơn bị CQT từ chối / không đủ điều kiện cấp mã (lỗi); người bán chưa tra cứu.",
           "R4": "Ký hiệu hoá đơn có mã (C) nhưng chưa có mã CQT; tải trùng cùng người bán, ký hiệu, số; hoá đơn không mang MST công ty.",
           "R5": "Bảng kê trong sổ có hoá đơn nhưng không thấy trên CQT - chỉ khi kỳ này đã tải hoá đơn chiều đó (bán ra: lỗi; mua vào: cần xem).",
           "R6": "Thời điểm lập / ký hoá đơn (NĐ 254/2026): ký số sau ngày lập quá ngày làm việc tiếp theo (bán ra: cần xem; mua vào: thông tin), "
                 "ký trước ngày lập, bán ra lập sau ngày chứng từ, mua vào kỳ trước hạch toán kỳ này (thông tin).",
           "R7": "Người bán có MST trong danh sách doanh nghiệp rủi ro cao về hoá đơn do cơ quan thuế công bố - tệp Excel / CSV anh tải về chép vào "
                 "AIHoaDon\\dn-rui-ro (cần xem); chưa có tệp thì báo thông tin."}
    for ma in NHOM:
        dem = defaultdict(int)
        for d in ds:
            if d["ma"] == ma:
                dem[d["muc"]] += 1
        T.append([(TEN_NHOM[ma], X.X_CHU), (dem[LOI], X.X_SO), (dem[CANH_BAO], X.X_SO), (dem[THONG_TIN], X.X_SO), (dem[DAT], X.X_SO), (dem["BO_QUA"], X.X_SO),
                  (noi[ma], X.X_CHU)])
    T.append([])
    for c in ("mua", "ban"):
        if chua_tai.get(c):
            T.append([("%s: sổ có %d hoá đơn trong kỳ nhưng chưa tải hoá đơn điện tử chiều này - R2, R5 chưa kiểm được chiều %s; tải hoá đơn rồi soát lại." % (
                DC.TEN_CHIEU[c], chua_tai[c], DC.TEN_CHIEU[c].lower()), X.X_GHICHU)])
    if chua_tra:
        T.append([("Người bán chưa tra cứu trạng thái: %d MST (sheet R3). Phần mềm không tra cứu thay và không vượt mã xác nhận; anh tra trên trang của cơ "
                   "quan thuế rồi dán kết quả (Dữ liệu > Soát rủi ro hoá đơn... mục 7)." % len(chua_tra), X.X_GHICHU)])
    T.append([(CAN_CU_5TR, X.X_GHICHU)])
    T.append([(CAN_CU_R6, X.X_GHICHU)])
    T.append([("Dấu LOẠI KHỎI KHẤU TRỪ / BỎ QUA chỉ là ghi nhớ của người dùng (bảng HDDT_RR_DanhDau); bảng kê, chỉ tiêu [25] do người dùng tự sửa. "
               "Hoá đơn khớp sổ và không có rủi ro không liệt kê ở các sheet dưới (trừ R1 đạt).", X.X_GHICHU)])
    import kiem_khoa_so
    T += kiem_khoa_so.khoi_ky(dl, X, 7)
    sheets = [("Tong hop", [44, 8, 10, 11, 8, 11, 110], T, 5)]
    cot = ("Mức", "Chiều", "Số HĐ", "Ngày HĐ", "MST đối tác", "Đối tác", "Tổng tiền", "Trạng thái / TK", "Chứng từ (MaCT)", "Dấu", "Kết luận / cách xử lý")
    rong = [11, 8, 12, 12, 14, 38, 16, 26, 14, 14, 100]

    def dong(d):
        tt = d.get("trang_thai") or d.get("tt") or d.get("kq") or d.get("ky_hieu") or ""
        if d.get("tk") and not d.get("trang_thai"):
            tt = d["tk"]
        return [(TEN_MUC.get(d["muc"], d["muc"]), kieu.get(d["muc"], X.X_CHU)), (DC.TEN_CHIEU.get(d["chieu"], d["chieu"]), X.X_CHU), (d["so"], X.X_CHU),
                (d["ngay"], X.X_CHU), (d["mst"], X.X_CHU), (d["doi_tac"], X.X_CHU), (d["tien"], X.X_SO), (tt, X.X_CHU),
                (d["ma_kt"] if d["ma_kt"] else "", X.X_CHU), (d["dau"] + ((" " + d["ghi_chu_dau"]) if d["ghi_chu_dau"] else ""), X.X_CHU), (d["ket_luan"], X.X_CHU)]
    thu_tu = {LOI: 0, CANH_BAO: 1, THONG_TIN: 2, DAT: 3}
    for ma in NHOM:
        D = [[(TEN_NHOM[ma], X.X_TITLE)], [(noi[ma], X.X_THUONG)], [], [(c, X.X_TIEUDE) for c in cot]]
        sel = sorted([d for d in ds if d["ma"] == ma and d["muc"] != "BO_QUA"], key=lambda d: (thu_tu.get(d["muc"], 9), ngay_iso(d["ngay"]), so_hd(d["so"]).zfill(12)))
        for d in sel:
            D.append(dong(d))
        if ma == "R3" and chua_tra:
            D.append([])
            D.append([("Người bán chưa tra cứu trạng thái (MST) - ưu tiên theo tổng hoá đơn giảm dần:", X.X_DAM)])
            for m in chua_tra:
                D.append([("", X.X_CHU), ("", X.X_CHU), ("", X.X_CHU), ("", X.X_CHU), (m, X.X_CHU)])
        if not sel and not (ma == "R3" and chua_tra):
            D.append([("(không có)", X.X_CHU)])
        sheets.append((ma, rong, D, 4))
    B = [[("DÒNG ĐÃ ĐÁNH DẤU BỎ QUA (không phải rủi ro) - gỡ dấu ở Dữ liệu > Soát rủi ro hoá đơn... > từng dòng", X.X_TITLE)], [], [(c, X.X_TIEUDE) for c in cot]]
    bq = [d for d in ds if d["muc"] == "BO_QUA"]
    for d in bq:
        B.append(dong(d))
    if not bq:
        B.append([("(không có)", X.X_CHU)])
    sheets.append(("Da bo qua", rong, B, 3))
    os.makedirs(os.path.dirname(os.path.abspath(ra)), exist_ok=True)
    X.viet_xlsx_o(ra, sheets)
    ghi_ket_qua(dl, ds, tong, chua_tra)
    return ra, tong


def chay(duong_json, ra):
    """-> (duong xlsx, loi)."""
    with open(duong_json, "r", encoding="utf-8-sig") as f:
        dl = json.loads(f.read(), strict=False)
    d, _ = lap_excel(dl, ra)
    return d, ""


# ============================================================ doc ket qua tra cuu NNT nguoi dung dan
MST_RE = re.compile(r"(?<!\d)(\d{10}(?:-?\d{3})?)(?!\d)")
NGAY_RE = re.compile(r"(?<!\d)(\d{1,2})/(\d{1,2})/(\d{4})(?!\d)")


def doc_nnt(duong, ra):
    """Tep nguoi dung dan (moi dong mot nguoi ban: MST ... trang thai) -> tep 'N;mst;ma;dd/mm/yyyy;ten;trang thai'. Dong khong co MST
    hoac khong nhan ra trang thai thi bo qua (ghi 'B;dong')."""
    with open(duong, "r", encoding="utf-8-sig", errors="replace") as f:
        noi = f.read()
    ra_dong, n = [], 0
    for dong in noi.replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        d = dong.strip()
        if not d or d.startswith("#"):
            continue
        m = MST_RE.search(d)
        if not m:
            continue
        mst = m.group(1).replace("-", "")
        if len(mst) == 13:
            mst = mst[:10] + "-" + mst[10:]
        ma = ma_nnt(d)
        if not ma:
            ra_dong.append("B;%s;;;;%s" % (mst, _sach(d, 120)))
            continue
        ng = ""
        for g in NGAY_RE.finditer(d):
            ng = "%02d/%02d/%s" % (int(g.group(1)), int(g.group(2)), g.group(3))
        phan = [p.strip() for p in re.split(r"\t|\s{2,}|\|", d) if p.strip()]
        ten = ""
        for p in phan:
            p2 = NGAY_RE.sub(" ", MST_RE.sub(" ", p)).strip(" -:;,")
            if len(p2) < 4 or NGAY_RE.search(p):
                continue
            if ma_nnt(p2):
                p2 = _cat_truoc_trang_thai(p2)
            if len(p2) >= 4 and not _la_cqt(p2):
                ten = p2
                break
        tt = TEN_NNT.get(ma, "")
        ra_dong.append("N;%s;%s;%s;%s;%s" % (mst, ma, ng, _sach(ten, 120), tt))
        n += 1
    os.makedirs(os.path.dirname(os.path.abspath(ra)), exist_ok=True)
    with open(ra, "w", encoding="utf-8") as f:
        f.write("\n".join(ra_dong) + "\n")
    return ra, n


TU_TRANG_THAI = ("NNT ", "NGUNG HOAT DONG", "DANG HOAT DONG", "KHONG HOAT DONG", "TAM NGUNG", "TAM NGHI", "TAM DUNG", "HOAT DONG",
                 "CHAM DUT", "GIAI THE", "PHA SAN")


def _cat_truoc_trang_thai(p):
    """cat phan chu truoc tu dau tien cua trang thai (bo_dau giu nguyen do dai -> vi tri khop)."""
    t = bo_dau(p).upper()
    vi = [t.find(k) for k in TU_TRANG_THAI if t.find(k) >= 0]
    if not vi:
        return p
    i = min(vi)
    return p[:i].strip(" -:;,|") if i > 0 else ""


def _la_cqt(p):
    t = bo_dau(p).upper()
    return t.startswith(("CUC THUE", "CHI CUC THUE", "THUE TINH", "THUE THANH PHO", "THUE KHU VUC", "THUE CO SO", "DOI THUE"))


if __name__ == "__main__":
    import sys
    if len(sys.argv) >= 2:
        print(chay(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else re.sub(r"\.json$", ".xlsx", sys.argv[1])))
