# -*- coding: utf-8 -*-
"""UNESCO XII - VIEC TU ERP_ANHMAI vao Hang doi viec (TASK369, theo XI GD348b).

Khong viet lai logic: dung NGUYEN VAN erp_viec.py cua XI (lap / ghi_bo_qua; chep nguyen, co chot bam). Chi thay cho 3 cho XII khac XI:
  * hop thu LENH\\: khoa "lenh" cua xii_erp_tram.json (tep cau hinh tram XII) - XI doc erp_tram.json;
  * ten so: TEN CSDL XII (lenh.so cua ERP = BookFile.FileName = ten CSDL) - XI so ten tep .MDB;
  * so thuc hien ERP_THUCHIEN: so XII la SQL Server, Python khong mo so -> VB (Modules\\AiErpLedger346.vb) doc bang va ghi tep JSON /thuc_hien:
    cung dang erp_thuc_hien.doc; ham doc() duoc thay bang ham tra ve cac dong do (viec da tra loi DA_GHI / KHONG_GHI khong hien lai).
Khong ghi gi vao so, khong goi mang.

  python xii_erp_viec.py /thamso:"<tep>"   (VB: AiErpWork.Refresh) tham so trong tep:
      /so:"<TEN_CSDL>" /cau_hinh:"<xii_erp_tram.json>" /thuc_hien:"<json>" /ra:"<viec.txt>" /bo_qua:"<thu muc>" /moc:"<tep moc>"
Ghi: /ra = "SO;n" + cac dong "V;stt;muc;tram;ma;ten;lam o dau;ket luan" (dung khuon hang_doi_viec.ghi) - ma = E|<lenh>|<ma chung tu sai>|<MaCT>|<khoa_tram>;
     <bo_qua>\\erp_bo_qua.txt (lenh;ma;khoa_tram;ly_do) - VB ghi HDDT_KS_BoQua (ERP348_ApBoQua);
     moc: dong dau "OK <ra>" hoac "LOI <ly do>". Ma thoat 0 / 1.
"""
import io
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

RE_DB = re.compile(r"^[A-Za-z0-9_]{1,100}$")


def _ts(argv):
    t = {}
    for a in argv:
        if a.startswith("/") and ":" in a:
            k, v = a[1:].split(":", 1)
            t[k.lower()] = v.strip('"')
    return t


def ghi_moc(p, noi_dung):
    if not p:
        return
    os.makedirs(os.path.dirname(p) or ".", exist_ok=True)
    tam = "%s.%d.tam" % (p, os.getpid())
    with io.open(tam, "w", encoding="utf-8") as f:
        f.write(noi_dung + "\n")
    os.replace(tam, p)


def hop_thu(cau_hinh):
    """'lenh' cua xii_erp_tram.json. Khong co / hong -> ''."""
    try:
        with io.open(cau_hinh, "r", encoding="utf-8-sig") as f:
            return os.path.normpath(str(json.load(f).get("lenh") or ""))
    except (OSError, ValueError, AttributeError):
        return ""


def doc_thuc_hien(p):
    """Cac dong ERP_THUCHIEN VB da doc (list dict, khuon erp_thuc_hien.doc). Khong co tep -> []."""
    if not p or not os.path.isfile(p):
        return []
    with io.open(p, "r", encoding="utf-8-sig") as f:
        d = json.load(f)
    return [x for x in d if isinstance(x, dict)] if isinstance(d, list) else []


def lap(so, hop, thuc_hien):
    """erp_viec.lap / ghi_bo_qua cua XI tren ten CSDL; erp_thuc_hien.doc tra ve cac dong VB dua. -> (ds, ham ghi bo qua)."""
    import erp_thuc_hien
    import erp_viec
    goc = erp_thuc_hien.doc
    erp_thuc_hien.doc = lambda duong, toi_da=2000: (list(thuc_hien)[:toi_da], "")
    try:
        return erp_viec.lap(so, hop), erp_viec
    finally:
        erp_thuc_hien.doc = goc


def ghi_viec(ds, ra):
    """Cung khuon dong V; cua hang_doi_viec.ghi (AiQueueService.ParseQueue doc lai)."""
    from hang_doi_viec import _sach
    os.makedirs(os.path.dirname(ra) or ".", exist_ok=True)
    tam = ra + ".tam"
    with io.open(tam, "w", encoding="utf-8") as f:
        f.write("SO;%d\n" % len(ds))
        for i, v in enumerate(ds, 1):
            f.write("V;%d;%s;%d;%s;%s;%s;%s\n" % (i, v[7], v[1], v[2], _sach(v[3]), _sach(v[4]), _sach(v[5])[:300]))
    os.replace(tam, ra)


def main(argv=None):
    a = list(sys.argv[1:] if argv is None else argv)
    try:
        import cap_nhat_online as C
        a = C.tham_so(a)
    except Exception:
        pass
    t = _ts(a)
    moc = t.get("moc") or os.path.join(HERE, "ket-qua", "DA_XONG_ERPVIEC")
    try:
        so, ra, bo_qua = t.get("so", ""), t.get("ra", ""), t.get("bo_qua", "")
        if not RE_DB.match(so):
            ghi_moc(moc, "LOI tên sổ không phải tên CSDL XII")
            return 1
        if not ra or not bo_qua:
            ghi_moc(moc, "LOI thiếu /ra hoặc /bo_qua")
            return 1
        hop = hop_thu(t.get("cau_hinh") or os.path.join(HERE, "xii_erp_tram.json"))
        if not hop or not os.path.isdir(hop):
            ghi_viec([], ra)
            ghi_moc(moc, "OK " + ra)                       # khong co hop thu: khong co viec ERP (khong phai loi)
            return 0
        ds, V = lap(so, hop, doc_thuc_hien(t.get("thuc_hien")))
        ghi_viec(ds, ra)
        V.ghi_bo_qua(so, bo_qua, hop)
        ghi_moc(moc, "OK " + ra)
        return 0
    except Exception as e:  # noqa: BLE001 - VB shows the reason, the queue keeps working without the ERP rows
        ghi_moc(moc, "LOI xii_erp_viec: %s: %s" % (type(e).__name__, str(e)[:200]))
        return 1


if __name__ == "__main__":
    sys.exit(main())
