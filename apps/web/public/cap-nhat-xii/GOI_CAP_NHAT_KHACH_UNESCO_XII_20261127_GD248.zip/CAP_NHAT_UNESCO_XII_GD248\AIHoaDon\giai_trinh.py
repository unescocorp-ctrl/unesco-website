# -*- coding: utf-8 -*-
"""GD237 - KHOA SO LIEN TUC (muc 6 lo trinh): D1 but toan cuoi ky de xuat (K45), D2 giai trinh bien dong ky nay / ky truoc (K44).
Chi doc so lieu Kiem tra truoc khoa so (S cua kiem_khoa_so). Khong ghi so.

K44: TK cap 1 nhom ket qua (5-8), thue (133, 3331), luong (334), kho (152, 154, 155, 156) - phat sinh ky nay so ky truoc
     cung do dai (cac thang ngay truoc trong nam tai chinh). Bien dong > NGUONG_PT va > NGUONG_TIEN -> dong giai trinh,
     phan ra theo TK doi ung (dl["doi_ung"] = [MaTKNo, MaTKCo, thang, tien], VB GD237 gui them) - 3 TK doi ung dong gop lon nhat.
K45: but toan cuoi ky con thieu, so tien tinh san: ket chuyen thue GTGT (No 3331 / Co 133), giam tru doanh thu TT99
     (No 511 / Co 521), 62x con du -> 154 (qua phieu ket chuyen thanh pham), doanh thu - chi phi -> 911, 911 -> 4212. Lam o the Ket chuyen cuoi ky (tung thang).
"""
import io
import os
from collections import defaultdict

NGUONG_PT = 30.0           # % bien dong
NGUONG_TIEN = 10000000.0   # d
NHOM_GT = ("5", "6", "7", "8", "133", "3331", "334", "152", "154", "155", "156")


def _thang_dl(S, t):
    return (t + S.dau_ky - 2) % 12 + 1


def _ps_cap1(S, t_tu, t_den):
    """{tk cap 1 (3 so / 4 so cho 133, 3331): [no, co]} phat sinh khong ke ket chuyen 911, thu tu thang TC t_tu..t_den."""
    kq = defaultdict(lambda: [0.0, 0.0])
    for m in S.la:
        sh = S.tk[m]["sh"]
        nhom = next((g for g in NHOM_GT if sh.startswith(g)), None)
        if not nhom:
            continue
        k = nhom if len(nhom) >= 3 else sh[:3]
        p = S.ps.get(m)
        if not p:
            continue
        for t, x in p["thang"].items():
            if t_tu <= t <= t_den:
                kq[k][0] += x[0]
                kq[k][1] += x[1]
    return kq


def _gia_tri(k, nc):
    """gia tri phat sinh 'chinh' cua TK: doanh thu / thu nhap (5, 7, 3331) = Co; con lai = No."""
    return nc[1] if k[:1] in ("5", "7") or k.startswith("3331") or k == "334" else nc[0]


def _doi_ung(S, k, t_tu, t_den):
    """{tk doi ung cap 1: tien} cua phat sinh chinh cua TK k trong khoang thang."""
    kq = defaultdict(float)
    ben_co = k[:1] in ("5", "7") or k.startswith("3331") or k == "334"
    for r in S.dl.get("doi_ung") or []:
        try:
            n, c, th, p = int(r[0]), int(r[1]), int(r[2]), float(r[3])
        except Exception:
            continue
        t = (th - S.dau_ky) % 12 + 1
        if not (t_tu <= t <= t_den):
            continue
        a, b = (c, n) if ben_co else (n, c)
        sa = (S.tk.get(a) or {}).get("sh", "")
        sb = (S.tk.get(b) or {}).get("sh", "")
        if sa.startswith(k) and not sb.startswith("911"):
            kq[sb[:3] or "?"] += p
    return kq


def k_giai_trinh(S, _kq, DAT, CANH_BAO, LOI, THONG_TIN):
    ten = "Giải trình biến động kỳ này so với kỳ trước (phân rã theo tài khoản đối ứng)"
    do_dai = S.t2 - S.t1 + 1
    tr_tu, tr_den = S.t1 - do_dai, S.t1 - 1
    if tr_den < 1:
        return [_kq("K44", ten, THONG_TIN, "Kỳ kiểm bắt đầu từ tháng đầu năm tài chính: chưa có kỳ trước trong năm để so.")]
    tr_tu = max(tr_tu, 1)
    nay, truoc = _ps_cap1(S, S.t1, S.t2), _ps_cap1(S, tr_tu, tr_den)
    he_so = do_dai / float(tr_den - tr_tu + 1)          # quy ve cung do dai neu ky truoc ngan hon
    co_du = bool(S.dl.get("doi_ung"))
    dong = []
    for k in sorted(set(nay) | set(truoc)):
        a = _gia_tri(k, nay.get(k, [0, 0]))
        b = _gia_tri(k, truoc.get(k, [0, 0])) * he_so
        ch = a - b
        pt = (ch / b * 100) if b else (100.0 if a else 0.0)
        if abs(ch) < NGUONG_TIEN or abs(pt) < NGUONG_PT:
            continue
        pr = ""
        if co_du:
            dn, dt = _doi_ung(S, k, S.t1, S.t2), _doi_ung(S, k, tr_tu, tr_den)
            dong_gop = sorted(((x, dn.get(x, 0.0) - dt.get(x, 0.0) * he_so) for x in set(dn) | set(dt)), key=lambda v: -abs(v[1]))[:3]
            pr = "; ".join("%s %s%s" % (x, "+" if v >= 0 else "-", "{:,.0f}".format(abs(v)).replace(",", ".")) for x, v in dong_gop if abs(v) >= 1)
        dong.append([k, round(b), round(a), round(ch), round(pt, 1), pr or "(cần số liệu đối ứng - bản VB GĐ237)"])
    if not dong:
        return [_kq("K44", ten, DAT, "Không có tài khoản nào biến động quá %d%% và quá %s đ so với kỳ trước." % (NGUONG_PT, "{:,.0f}".format(NGUONG_TIEN).replace(",", ".")))]
    dong.sort(key=lambda r: -abs(r[3]))
    # GD245: danh muc ly do + tep giai trinh theo ky (ke toan ghi ly do; dong da co ly do -> khong con la viec can lam)
    tep = tep_giai_trinh(S)
    da = doc_giai_trinh(tep) if tep else {}
    chua = []
    for r in dong:
        g = da.get(str(r[0]))
        if g:
            r.append("%s%s" % (LY_DO.get(g[0], g[0]), (" - " + g[1]) if g[1] else ""))
        else:
            r.append("")
            chua.append(r)
    if tep and chua:
        try:
            them_mau(tep, chua)
        except Exception:
            pass
    cot = ["TK", "Kỳ trước (quy cùng độ dài)", "Kỳ này", "Chênh lệch", "%", "Đóng góp lớn nhất theo TK đối ứng", "Lý do đã ghi"]
    if not chua:
        return [_kq("K44", ten, DAT, "%d tài khoản biến động lớn so với kỳ trước (tháng TC %d-%d) - đã giải trình đủ (%s)." % (len(dong), tr_tu, tr_den, tep or ""),
                    cot, dong)]
    return [_kq("K44", ten, CANH_BAO, "%d / %d tài khoản biến động lớn so với kỳ trước (tháng TC %d-%d) chưa có lý do: xem phân rã đối ứng, ghi mã lý do "
                "vào tệp %s (mỗi dòng: TK;MÃ LÝ DO;ghi chú - mã: %s), rồi kiểm tra lại." %
                (len(chua), len(dong), tr_tu, tr_den, tep or "(chưa có đường dẫn bộ sổ - Make .exe bản mới)", ", ".join(LY_DO)), cot, dong)]


# ============================================================ GD245: danh muc ly do giai trinh
LY_DO = {
    "MUA_VU": "Biến động theo mùa vụ / thời vụ",
    "TANG_QUY_MO": "Tăng / giảm quy mô hoạt động (đơn hàng, hợp đồng mới / kết thúc)",
    "GIA": "Giá mua / giá bán thay đổi",
    "HD_LON": "Hóa đơn / nghiệp vụ lớn không thường xuyên",
    "TS_MOI": "Mua sắm / thanh lý tài sản",
    "VAY_TRA": "Vay mới / trả nợ vay",
    "PHAN_LOAI": "Phân loại lại tài khoản (kỳ trước hạch toán TK khác)",
    "SAI_DA_SUA": "Sai sót kỳ trước đã điều chỉnh trong kỳ này",
    "CHUA_XU_LY": "Đã biết, chưa xử lý - hẹn kỳ sau",
    "KHAC": "Khác (ghi rõ ở ghi chú)",
}


def tep_giai_trinh(S):
    """<ket-qua\\chinh-sach\\<so>>\\giai_trinh_<nam>_<t1>-<t2>.txt ; khong co duong bo so -> None"""
    duong = S.dl.get("duong_so") if hasattr(S, "dl") else None
    if not duong:
        return None
    import chinh_sach_so
    tm, _ = chinh_sach_so._thu_muc_ra(duong)
    return os.path.join(tm, "giai_trinh_%s_%02d-%02d.txt" % (S.dl.get("nam_tc") or "", S.t1, S.t2))


def doc_giai_trinh(tep):
    """-> {TK: (MA_LY_DO, ghi chu)}; dong '#' la chu thich; dong chua co ma ly do bi bo qua."""
    kq = {}
    if not tep or not os.path.isfile(tep):
        return kq
    with io.open(tep, encoding="utf-8-sig") as f:
        for d in f:
            d = d.strip()
            if not d or d.startswith("#"):
                continue
            x = [v.strip() for v in d.split(";")]
            if len(x) < 2 or not x[0] or not x[1]:
                continue
            ma = x[1].upper().replace(" ", "_")
            kq[x[0]] = (ma if ma in LY_DO else "KHAC", ";".join(x[2:]).strip() if ma in LY_DO else (x[1] + " " + ";".join(x[2:])).strip())
    return kq


def them_mau(tep, chua):
    """them dong trong cho TK chua co trong tep (khong dong de dong ke toan da ghi)."""
    co = set()
    moi = not os.path.isfile(tep)
    if not moi:
        with io.open(tep, encoding="utf-8-sig") as f:
            for d in f:
                d = d.strip()
                if d and not d.startswith("#"):
                    co.add(d.split(";")[0].strip())
    them = [r for r in chua if str(r[0]) not in co]
    if not them and not moi:
        return
    with io.open(tep, "a", encoding="utf-8") as f:
        if moi:
            f.write("# Giai trinh bien dong ky nay so voi ky truoc. Moi dong: TK;MA LY DO;ghi chu\n")
            for k, v in LY_DO.items():
                f.write("#   %s = %s\n" % (k, v))
        for r in them:
            f.write("%s;;%s -> %s (%+.1f%%)\n" % (r[0], "{:,.0f}".format(r[1]).replace(",", "."), "{:,.0f}".format(r[2]).replace(",", "."), r[4]))


def k_but_toan_de_xuat(S, _kq, DAT, CANH_BAO, LOI, THONG_TIN):
    ten = "Bút toán cuối kỳ còn thiếu (đề xuất, số tiền tính sẵn)"
    dx = []

    def du(tt):
        return sum(S.du_cuoi(m) for m in S.la_theo(tt))
    d133, d3331 = du("133"), -du("3331")
    if d133 > 1 and d3331 > 1:
        dx.append(["1. Kết chuyển thuế GTGT được khấu trừ", "3331", "133", round(min(d133, d3331)),
                   "133 còn %s, 3331 còn %s" % ("{:,.0f}".format(d133), "{:,.0f}".format(d3331))])
    d521 = du("521") if S.cp99 else 0.0
    if d521 > 1:
        dx.append(["2. Kết chuyển giảm trừ doanh thu (TT99)", "511", "521", round(d521), ""])
    sx = ("621", "622", "623", "627")
    for m in sorted(S.la_theo(*sx), key=lambda x: S.tk[x]["sh"]):
        d = S.du_cuoi(m)
        if d > 1:
            dx.append(["3. Kết chuyển chi phí sản xuất vào 154 (Giá thành)", "154", S.tk[m]["sh"], round(d), S.ten(m) + " - qua phiếu kết chuyển thành phẩm"])
    con_521 = d521
    kq_dt = 0.0
    for m in sorted(S.la, key=lambda x: (not S.tk[x]["sh"].startswith("511"), S.du_cuoi(x), S.tk[x]["sh"])):
        sh = S.tk[m]["sh"]
        if sh[:1] not in ("5", "6", "7", "8") or sh.startswith(sx) or sh.startswith("521"):
            continue
        d = S.du_cuoi(m)
        if sh.startswith("511") and con_521 > 0 and d < 0:          # sau buoc 2, 511 giam phan 521
            tru = min(con_521, -d)
            d += tru
            con_521 -= tru
        if abs(d) <= 1:
            continue
        kq_dt -= d
        if d < 0:
            dx.append(["4. Kết chuyển sang 911", sh, "911", round(-d), S.ten(m)])
        else:
            dx.append(["4. Kết chuyển sang 911", "911", sh, round(d), S.ten(m)])
    kq_dt += -du("911")
    if abs(kq_dt) > 1 and any(r[0].startswith("4.") for r in dx):
        dx.append(["5. Kết chuyển lãi / lỗ", "911" if kq_dt > 0 else "4212", "4212" if kq_dt > 0 else "911", round(abs(kq_dt)),
                   "Lãi" if kq_dt > 0 else "Lỗ"])
    if not dx:
        return [_kq("K45", ten, DAT, "Không còn bút toán kết chuyển cuối kỳ nào thiếu (133 / 3331, loại 5 - 8 đã về 0).")]
    return [_kq("K45", ten, THONG_TIN, "%d bút toán cuối kỳ đề xuất (số cộng cả kỳ): thực hiện ở thẻ Kết chuyển cuối kỳ theo TỪNG THÁNG, rồi Kiểm tra lại." % len(dx),
                ["Bước", "Nợ", "Có", "Số tiền", "Ghi chú"], dx)]
