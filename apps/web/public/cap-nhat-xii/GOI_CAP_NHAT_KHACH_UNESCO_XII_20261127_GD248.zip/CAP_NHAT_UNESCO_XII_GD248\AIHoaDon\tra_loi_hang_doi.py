# -*- coding: utf-8 -*-
"""GD250 - TRA LOI HANG DOI VIEC: ke toan tra loi tung viec trong tep tra_loi.txt cua bo so, lan Kiem tra truoc khoa so sau
   ap dung ngay (khong hoi lai, khong con trong hang doi). Tep: <AIHoaDon\\ket-qua\\chinh-sach\\<so>_<ma>>\\tra_loi.txt
   Moi dong:  MA;KHOA;HANH_DONG;ghi chu
     MA        = ma kiem (K42, K10...), hoac * cho moi ma
     KHOA      = * (ca ma) hoac gia tri cot dau cua dong chi tiet (vd so chung tu, ma doi tac, TK)
     HANH_DONG = BO_QUA      : khong phai loi, co ly do -> ma / dong do ve THONG_TIN, khong vao hang doi
                 DA_LAM      : da xu ly ngoai phan mem (vd da gui bien ban) -> nhu BO_QUA, ghi "da lam"
                 CHAP_NHAN   : (K51) chap nhan chinh sach moi -> xoa anh chup, lan kiem nay lam moc
                 LOAI_HINH   : (K52) ghi chu = ma loai hinh, vd XAY_DUNG, DICH_VU -> ghi loai_hinh.txt
                 HEN         : hen ky sau, ghi chu = ly do -> con trong hang doi nhung muc CANH_BAO (khong chan khoa so)
   Dong bat dau bang # la chu thich. May tu them dong mau (#) cho ma con mo de anh dien.
   Chi doc so; chi ghi tep trong thu muc cua so."""
import io
import os

HANH_DONG = ("BO_QUA", "DA_LAM", "CHAP_NHAN", "LOAI_HINH", "HEN")


def thu_muc_so(S):
    duong = (S.dl.get("duong_so") if hasattr(S, "dl") else "") or ""
    if duong:
        try:
            import chinh_sach_so
            tm, _ = chinh_sach_so._thu_muc_ra(duong)
            return tm
        except Exception:
            pass
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "ket-qua")


def tep_tra_loi(S):
    return os.path.join(thu_muc_so(S), "tra_loi.txt")


def doc(tep):
    """-> [(ma, khoa, hanh_dong, ghi_chu)] (chi dong hop le)."""
    out = []
    if not tep or not os.path.isfile(tep):
        return out
    try:
        with io.open(tep, encoding="utf-8-sig") as f:
            for d in f:
                d = d.strip()
                if not d or d.startswith("#"):
                    continue
                x = [v.strip() for v in d.split(";")]
                if len(x) < 3:
                    continue
                hd = x[2].upper().replace(" ", "_")
                if hd not in HANH_DONG:
                    continue
                out.append((x[0].upper(), x[1] or "*", hd, ";".join(x[3:]).strip()))
    except Exception:
        pass
    return out


def _khop(tl, ma):
    return tl[0] == "*" or tl[0] == ma


def ap_dung(kq, S, LOI, CANH_BAO, DAT, THONG_TIN, tep=None):
    """Sua kq tai cho theo tra loi. -> (so tra loi da ap dung, tep)."""
    tep = tep or tep_tra_loi(S)
    ds = doc(tep)
    n = 0
    tm = os.path.dirname(tep)
    for tl in ds:
        ma, khoa, hd, gc = tl
        if hd == "LOAI_HINH":
            try:
                with io.open(os.path.join(tm, "loai_hinh.txt"), "w", encoding="utf-8") as f:
                    f.write(gc + "\n")
                n += 1
            except Exception:
                pass
            continue
        if hd == "CHAP_NHAN":
            for f_ in os.listdir(tm) if os.path.isdir(tm) else []:
                if f_.startswith("chinh_sach_") and f_.endswith(".json"):
                    try:
                        os.remove(os.path.join(tm, f_))
                        n += 1
                    except Exception:
                        pass
            for k in kq:
                if k.get("ma") == "K51" and k.get("muc") in (LOI, CANH_BAO):
                    k["muc"] = THONG_TIN
                    k["ket_luan"] = "Đã chấp nhận chính sách mới (tra_loi.txt): lần kiểm này làm mốc. " + (k.get("ket_luan") or "")
            continue
        for k in kq:
            if not _khop(tl, k.get("ma")) or k.get("muc") not in (LOI, CANH_BAO):
                continue
            if khoa != "*" and k.get("dong"):
                con = [r for r in k["dong"] if str(r[0] if r else "") != khoa]
                if len(con) == len(k["dong"]):
                    continue
                k["dong"] = con
                n += 1
                if con:
                    k["ket_luan"] = "%s (đã trả lời %s: %s)" % (k.get("ket_luan") or "", khoa, gc or hd.lower())
                    continue
            else:
                n += 1
            if hd == "HEN":
                k["muc"] = CANH_BAO
                k["ket_luan"] = "Hẹn kỳ sau (tra_loi.txt): %s. %s" % (gc, k.get("ket_luan") or "")
            else:
                k["muc"] = THONG_TIN
                k["ket_luan"] = "%s (tra_loi.txt): %s. %s" % ("Không phải lỗi" if hd == "BO_QUA" else "Đã làm", gc, k.get("ket_luan") or "")
    return n, tep


def them_mau(kq, LOI, CANH_BAO, tep):
    """Them dong mau (#) cho ma LOI / CANH_BAO chua co trong tep (khong de dong da ghi)."""
    try:
        co = set()
        moi = not os.path.isfile(tep)
        if not moi:
            with io.open(tep, encoding="utf-8-sig") as f:
                for d in f:
                    d = d.strip().lstrip("#").strip()
                    if d:
                        co.add(d.split(";")[0].strip().upper())
        them = [k for k in kq if k.get("muc") in (LOI, CANH_BAO) and k.get("ma") not in co]
        if not them and not moi:
            return
        os.makedirs(os.path.dirname(tep), exist_ok=True)
        with io.open(tep, "a", encoding="utf-8") as f:
            if moi:
                f.write("# Tra loi hang doi viec. Bo dau # va dien: MA;KHOA;HANH_DONG;ghi chu\n")
                f.write("#   KHOA = * (ca ma) hoac gia tri cot dau cua dong chi tiet\n")
                f.write("#   HANH_DONG = BO_QUA | DA_LAM | HEN | CHAP_NHAN (K51) | LOAI_HINH (K52, ghi chu = XAY_DUNG, DICH_VU...)\n")
            for k in them:
                f.write("#%s;*;BO_QUA;\n" % k["ma"])
    except Exception:
        pass
