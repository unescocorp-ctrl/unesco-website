# -*- coding: utf-8 -*-
"""GD347 - TRAM MAY NHAN LENH TU ERP_ANHMAI (phan CHI DOC). Khuon trao doi phien ban 1 (DAC_TA_BOOKOPS.md) + v1.1 (erp_khuon.py).

  python erp_tram.py /cau_hinh:"<erp_tram.json>"                 vong lap tram (Ctrl+C hoac tep LENH\\tram\\<tram>.dung de dung)
  python erp_tram.py /cau_hinh:"<erp_tram.json>" /mot_lan         quet mot luot roi thoat (Task Scheduler / kiem thu)
  python erp_tram.py /lenh:"<tep lenh.json>" /ra:"<tep ket qua>" /data:"<thu muc DATA>"   lam mot lenh, khong dung hop thu
  python erp_tram.py /mot:"<so.MDB>" /ra:"<kq.json>"              phan tich mot so, ghi phan ket qua (kiem thu doc so)

erp_tram.json: {"lenh": "E:\\\\KETOAN\\\\SUONG_AI\\\\LENH", "data": "E:\\\\KETOAN\\\\SUONG_AI\\\\DATA", "tram": "TRAM-1",
                "phut_moi_so": 20, "giay_cho": 15, "sau": 3}

Hop thu LENH\\ (cau noi AnhMai.Erp.BookBridge ghi cho\\, doc ket_qua\\ va tram\\):
  cho\\<lenh>.json  -> tram doi ten sang dang_lam\\ (cung o dia, nguyen tu: hai tram khong nhan trung) -> lam -> xong\\
  ket_qua\\<lenh>.ket_qua.json  ghi .tmp roi doi ten;  tram\\<tram>.json bao song moi phut;  khoa\\<so>.khoa khi dang lam
Buoc tram chi doc lam duoc: kiem_tra (bat thuong KS8-KS12), doi_chieu (DC1-DC16 doi_chieu_100), hien_trang (bang dieu hanh).
Buoc can ghi so (tai_hd, phan_tich, ghi_trong_nguong, ket_chuyen, bao_cao, sua_chung_tu) -> BO_QUA co ly do + viec_can_nguoi;
sua[] -> da_sua KHONG_SUA (ERP khong bao gio tu coi la da sua). Che do tram VB6 (GD348) se lam cac buoc nay qua ClsChungtu.
KHONG ghi gi vao .MDB. Nhat ky: LENH\\tram\\nhat_ky\\<tram>_<yyyymmdd>.log (ma lenh + ten tep so, khong MST / ten khach).
"""
import datetime as _dt
import io
import json
import os
import re
import socket
import sys
import time
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import erp_khuon as KH  # noqa: E402

BUOC_CHI_DOC = ("kiem_tra", "doi_chieu")
BUOC_VB = ("tai_hd", "phan_tich", "ghi_trong_nguong", "ket_chuyen", "bao_cao")     # GD349: giao cho tram VB6 (ModTramERP349) khi dang bat
GIAY_SONG_VB = 180           # song.txt cu hon -> coi tram VB6 tat
LY_DO_CHUA_HO_TRO = "Trạm VB6 chưa bật (UNESCO AI: Dữ liệu > Chạy hàng loạt > 9 Trạm ERP) - bước này cần phần mềm UNESCO AI đang mở hoặc người làm"
THU_MUC = ("cho", "dang_lam", "xong", "ket_qua", "tram", "khoa", "ho_so", "tep")
PHUT_KHOA_THEM = 10          # khoa so khong lam moi qua (phut_moi_so + 10) phut -> coi la luot truoc bi ngat


# ------------------------------------------------------------------ cau hinh, thu muc, nhat ky
class CauHinh(object):
    def __init__(self, d):
        self.lenh = os.path.normpath(d.get("lenh") or "")
        self.data = os.path.normpath(d.get("data") or "")
        self.tram = str(d.get("tram") or "TRAM-1")[:30]
        self.phut_moi_so = int(d.get("phut_moi_so") or 20)
        self.giay_cho = max(5, int(d.get("giay_cho") or 15))
        self.sau = int(d.get("sau") or 3)
        if not self.lenh or not self.data:
            raise ValueError("cau hinh thieu 'lenh' hoac 'data'")

    def tm(self, *p):
        return os.path.join(self.lenh, *p)


def doc_cau_hinh(duong):
    with io.open(duong, "r", encoding="utf-8-sig") as f:
        return CauHinh(json.load(f))


def tao_thu_muc(ch):
    for t in THU_MUC:
        os.makedirs(ch.tm(t), exist_ok=True)
    os.makedirs(ch.tm("ket_qua", "da_gui"), exist_ok=True)
    os.makedirs(ch.tm("tram", "nhat_ky"), exist_ok=True)


def ghi_log(ch, s):
    dong = "%s %s" % (_dt.datetime.now().strftime("%H:%M:%S"), s)
    try:
        p = ch.tm("tram", "nhat_ky", "%s_%s.log" % (ch.tram, _dt.date.today().strftime("%Y%m%d")))
        with io.open(p, "a", encoding="utf-8") as f:
            f.write(dong + "\n")
    except OSError:
        pass
    try:
        print(dong)
    except (UnicodeEncodeError, OSError):
        pass


def ghi_json_nguyen_tu(duong, d):
    tmp = duong + ".tmp"
    with io.open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1, default=str)
    os.replace(tmp, duong)


def doc_json(duong):
    with io.open(duong, "r", encoding="utf-8-sig") as f:
        return json.load(f)


# ------------------------------------------------------------------ bao song, khoa so
def bao_song(ch, so_dang_lam=None, buoc=None):
    d = {"phien_ban_khuon": KH.PHIEN_BAN_KHUON, "tram": ch.tram, "may": socket.gethostname()[:100], "luc": KH.gio_iso(),
         "so_dang_lam": so_dang_lam, "buoc_dang_lam": buoc}
    try:
        ghi_json_nguyen_tu(ch.tm("tram", ch.tram + ".json"), d)
    except OSError as e:
        ghi_log(ch, "Khong ghi duoc bao song: %s" % type(e).__name__)
    return d


def _khoa_tep(ch, so):
    return ch.tm("khoa", os.path.basename(so) + ".khoa")


def khoa_so(ch, so):
    """True = da khoa. Tep khoa con moi (tram khac dang lam) -> False."""
    p = _khoa_tep(ch, so)
    try:
        fd = os.open(p, os.O_WRONLY | os.O_CREAT | os.O_EXCL)
    except FileExistsError:
        try:
            tuoi = time.time() - os.path.getmtime(p)
        except OSError:
            return False
        if tuoi < (ch.phut_moi_so + PHUT_KHOA_THEM) * 60:
            return False
        try:
            os.remove(p)                                   # khoa cu bi bo quen
            fd = os.open(p, os.O_WRONLY | os.O_CREAT | os.O_EXCL)
        except OSError:
            return False
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write("%s %s\n" % (ch.tram, KH.gio_iso()))
    return True


def mo_khoa(ch, so):
    try:
        os.remove(_khoa_tep(ch, so))
    except OSError:
        pass


# ------------------------------------------------------------------ tim so trong DATA
def tim_so(data, so):
    """so = ten tep (THIEN HUNG 2026.MDB) hoac duong dan tuong doi duoi DATA. -> (duong day du, loi)."""
    so = str(so or "").strip().replace("/", os.sep)
    if not so:
        return None, "lệnh không có tên sổ"
    truc_tiep = os.path.join(data, so)
    if os.path.isfile(truc_tiep):
        return os.path.normpath(truc_tiep), ""
    ten = os.path.basename(so).lower()
    thay = []
    for goc, _, teps in os.walk(data):
        for t in teps:
            if t.lower() == ten:
                thay.append(os.path.join(goc, t))
    if not thay:
        return None, "không thấy sổ '%s' trong %s" % (so, data)
    if len(thay) > 1:
        return None, "có %d sổ cùng tên '%s' trong DATA - ERP phải ghi đường dẫn tương đối" % (len(thay), so)
    return os.path.normpath(thay[0]), ""


# ------------------------------------------------------------------ doc so (chi doc) - co the thay bang stub khi kiem thu
def tham_so_quy_tac(ho_so):
    """ho_so.quy_tac[] (ERP, V0088) -> {ma: tham_so dict}. Chi lay ban co tham_so la object."""
    out = {}
    for q in (ho_so or {}).get("quy_tac") or []:
        if isinstance(q, dict) and q.get("ma") and isinstance(q.get("tham_so"), dict):
            out[str(q["ma"]).upper()] = q["tham_so"]
    return out


def ap_tham_so_bt157(dl, tham_so):
    """Nguong bat thuong KS8 / KS9 cua ERP thay cho HDDT_ThamSo BT157_* (chi khi ke toan da dat): KS8 x (%), tien_min; KS9 y (%).
    -> danh sach ma da ap dung."""
    da = []
    bt = (dl or {}).get("bt157")
    if not isinstance(bt, dict):
        return da
    k8, k9 = tham_so.get("KS8") or {}, tham_so.get("KS9") or {}
    for khoa, nguon, ten in (("x", k8, "x_pct"), ("tien_min", k8, "tien_min"), ("y", k9, "y_pct")):
        v = nguon.get(ten)
        if isinstance(v, (int, float)) and not isinstance(v, bool) and v > 0:
            bt[khoa] = float(v)
            if (("KS8" if nguon is k8 else "KS9")) not in da:
                da.append("KS8" if nguon is k8 else "KS9")
    return da


def phan_tich_so(duong, hom_nay, sau=3, tham_so=None):
    """-> {"dh": bang dieu hanh | None, "dc": doi chieu | None, "bt": {n, cao, vua, thap, dong} | None, "ct": {}, "tk": {},
           "loi": {"dh": "", "bt": "", "dc": ""}, "ban_chup": sha256 truoc, "ban_chup_sau": sha256 sau, "quy_tac_ap_dung": [ma]}.
    tham_so = tham_so_quy_tac(ho_so): nguong ERP giao thay nguong san co. KHONG ghi .MDB."""
    import bang_dieu_hanh as DH
    import bat_thuong as BT
    import doi_chieu_100 as DC
    import hang_loat as HL
    kq = {"dh": None, "dc": None, "bt": None, "ct": {}, "tk": {}, "loi": {"dh": "", "bt": "", "dc": ""}, "quy_tac_ap_dung": []}
    kq["ban_chup"] = KH.sha256_tep(duong)
    bang = DH.doc_bang(duong)
    if bang is None:
        kq["loi"]["dh"] = "không phải bộ sổ UNESCO (thiếu bảng License / ChungTu / HethongTK)"
        kq["loi"]["bt"] = kq["loi"]["dc"] = kq["loi"]["dh"]
        return kq
    r = dict(DH.tinh(bang, hom_nay, DH.doc_ngay_nghi()))
    r.pop("ct_theo_thang", None)
    r.pop("viec", None)
    try:                                                   # GD348c: che do ke toan NGUOI DUNG da chon trong so (License.CheDoTT, GD130) - khong doan
        v = int((bang.get("License") or {}).get("CheDoTT") or 0)
        r["che_do_tt"] = v if v in (133, 99, 58) else None
    except (TypeError, ValueError):
        r["che_do_tt"] = None
    kq["dh"] = r
    try:
        dl, bo_qua = HL.dl_tu_mdb(duong, hom_nay)
        kq["quy_tac_ap_dung"] = ap_tham_so_bt157(dl, tham_so or {})
        kq["ct"], kq["tk"] = KH.ct_tu_dl(dl)
        B = BT.BatThuong(dl, HL._ngay(dl["bt157"]["hom_nay"]))
        dong = [x for x in B.chay() if x["khoa"] not in bo_qua]
        dem = {BT.MUC_CAO: 0, BT.MUC_VUA: 0, BT.MUC_THAP: 0}
        for x in dong:
            dem[x["muc"]] = dem.get(x["muc"], 0) + 1
        kq["bt"] = {"n": len(dong), "cao": dem[BT.MUC_CAO], "vua": dem[BT.MUC_VUA], "thap": dem[BT.MUC_THAP], "bo_qua": len(bo_qua),
                    "dong": [{"ks": BT.MA_KS.get(x["loai"], "KS"), "loai": x["loai"], "muc": x["muc"], "ma": x["ma"], "mo_ta": x["mo_ta"],
                              "so_lieu": x["so_lieu"], "goi_y": x.get("goi_y", ""), "khoa": x.get("khoa", ""), "mact": x.get("mact") or []}
                             for x in dong]}
    except Exception as e:
        kq["loi"]["bt"] = "phát hiện bất thường lỗi: %s" % type(e).__name__
    try:
        dh2 = dict(r)
        dh2["_bt"] = kq.get("bt") or {}
        kq["dc"] = DC.doi_chieu(duong, hom_nay, dh2)
    except Exception as e:
        kq["loi"]["dc"] = "đối chiếu lỗi: %s" % type(e).__name__
    try:                                                   # GD350: phuong an gia thanh thang (chi doc) -> quy_tac K60 + viec_can_nguoi
        import gia_thanh_phuong_an as GT
        dgt = GT.doc(duong)
        th = GT.thang_moi_nhat(dgt)
        kq["gt"] = GT.phan_tich(dgt, th) if th else None
    except Exception as e:
        kq["gt"] = None
        kq["loi"]["gt"] = "phương án giá thành lỗi: %s" % type(e).__name__
    kq["ban_chup_sau"] = KH.sha256_tep(duong)
    return kq


PHAN_TICH = phan_tich_so          # kiem thu thay bang stub


# ------------------------------------------------------------------ GD349: tram VB6 (ModTramERP349) lam buoc ghi
def vb_dang_song(ch):
    p = ch.tm("tram", "vb", "song.txt")
    try:
        return time.time() - os.path.getmtime(p) < GIAY_SONG_VB
    except OSError:
        return False


def _doc_kv(duong):
    d, viec = {}, []
    with io.open(duong, "r", encoding="utf-8-sig") as f:
        for dong in f:
            dong = dong.rstrip("\r\n")
            if "=" not in dong:
                continue
            k, v = dong.split("=", 1)
            if k == "viec":
                viec.append(v)
            else:
                d[k.strip()] = v.strip()
    d["_viec"] = viec
    return d


def yeu_cau_vb(ch, lenh, buoc, duong_so, bao=None):
    """Ghi LENH\\tram\\vb\\<lenh>.<buoc>.yeu_cau.txt, doi tra_loi.txt toi da phut_moi_so phut. -> (buoc dict cho kq, viec[]) hoac None (VB tat)."""
    if not vb_dang_song(ch):
        return None, []
    d = ch.tm("tram", "vb")
    os.makedirs(os.path.join(d, "xong"), exist_ok=True)
    goc = os.path.join(d, "%s.%s" % (lenh["lenh"], buoc))
    yc, tl = goc + ".yeu_cau.txt", goc + ".tra_loi.txt"
    nd = "lenh=%s\nbuoc=%s\nso=%s\nky=%s\nnguong=%s\n" % (lenh["lenh"], buoc, duong_so, lenh.get("ky", ""), lenh.get("nguong", ""))
    with io.open(yc + ".tmp", "w", encoding="utf-8") as f:
        f.write(nd)
    os.replace(yc + ".tmp", yc)
    han = time.time() + ch.phut_moi_so * 60
    t_bao = 0
    while time.time() < han:
        if os.path.isfile(tl):
            time.sleep(0.5)
            try:
                r = _doc_kv(tl)
            except (OSError, ValueError):
                time.sleep(1)
                continue
            try:
                os.replace(tl, os.path.join(d, "xong", os.path.basename(tl)))
            except OSError:
                pass
            tt = r.get("trang_thai", "LOI")
            if tt not in KH.TRANG_THAI_BUOC:
                tt = "LOI"
            b = {"ten": buoc, "trang_thai": tt}
            if tt in ("BO_QUA", "CAN_NGUOI"):
                b["ly_do"] = (r.get("ly_do") or "Trạm VB6 không nêu lý do")[:500]
            elif tt == "LOI":
                b["loi"] = (r.get("ly_do") or "Trạm VB6 báo lỗi")[:500]
            cs = {}
            for k, v in r.items():
                if k.startswith("chi_so."):
                    try:
                        cs[k[7:]] = int(float(v))
                    except ValueError:
                        pass
            if cs:
                b["chi_so"] = cs
            viec = []
            for x in r.get("_viec") or []:
                loai, _, mo_ta = x.partition("|")
                if loai and mo_ta:
                    viec.append({"ma": KH.ma_sach("%s:%s:%s" % (buoc, loai, lenh.get("ky", "")), 100), "loai": loai[:30], "buoc": buoc, "muc": "VUA", "mo_ta": mo_ta[:500]})
            return b, viec
        if not vb_dang_song(ch):
            try:
                os.replace(yc, os.path.join(d, "xong", os.path.basename(yc) + ".bo"))
            except OSError:
                pass
            return {"ten": buoc, "trang_thai": "LOI", "loi": "Trạm VB6 tắt giữa chừng khi đang làm bước này"}, []
        if bao and time.time() - t_bao > 30:
            bao(buoc)
            t_bao = time.time()
        time.sleep(2)
    try:
        os.replace(yc, os.path.join(d, "xong", os.path.basename(yc) + ".qua_han"))
    except OSError:
        pass
    return {"ten": buoc, "trang_thai": "LOI", "loi": "Trạm VB6 không trả lời trong %d phút" % ch.phut_moi_so}, []


# ------------------------------------------------------------------ lam mot lenh
def doc_ho_so(ch, so):
    """LENH\\ho_so\\<ten tep so>.json do cau noi ERP ghi (khuon v1.1). Khong co / hong -> None (lenh van chay, khong doi chieu ho so)."""
    p = ch.tm("ho_so", os.path.basename(str(so or "")) + ".json")
    if not os.path.isfile(p):
        return None
    try:
        d = doc_json(p)
    except (OSError, ValueError):
        return None
    return d if isinstance(d, dict) and d.get("phien_ban_khuon") == KH.PHIEN_BAN_KHUON else None


def lech_ho_so(ho_so, dh):
    """So sanh so da mo voi ho so ERP giao xuong: nam tai chinh (License.NamTC) phai trung nam_tc. -> chuoi ly do hoac ''."""
    if not ho_so or not dh:
        return ""
    try:
        nam_so, nam_erp = int(dh.get("nam") or 0), int(ho_so.get("nam_tc") or 0)
    except (TypeError, ValueError):
        return ""
    if nam_so and nam_erp and nam_so != nam_erp:
        return "sổ đang mở là năm tài chính %d, hồ sơ ERP ghi năm %d - không kiểm, báo lại ERP (F11: không đoán sổ)" % (nam_so, nam_erp)
    # GD348c: che do ke toan (ho_so.thong_tu = BookFile.CircularCode 133 / 99 / 58) phai trung che do da chon trong so;
    #   so chua chon (che_do_tt None) thi khong so (khong doan tu TK 641 - A57)
    try:
        tt_erp = int(re.sub(r"\D", "", str(ho_so.get("thong_tu") or "")) or 0)
    except (TypeError, ValueError):
        tt_erp = 0
    tt_so = dh.get("che_do_tt")
    if tt_erp in (133, 99, 58) and tt_so in (133, 99, 58) and tt_erp != tt_so:
        return "sổ đang mở theo Thông tư %d, hồ sơ ERP ghi Thông tư %d - không kiểm, báo lại ERP (A57: chế độ kế toán do ERP giữ)" % (tt_so, tt_erp)
    return ""


def lam_lenh(ch, lenh, duong_so, hom_nay=None, bao=None, ho_so=None):
    """lenh = dict tep lenh (da kiem_lenh). duong_so = tep .MDB hoac None (khong thay). ho_so = doc_ho_so(...) hoac None.
    -> dict ket qua (da kiem_ket_qua)."""
    hom_nay = hom_nay or _dt.date.today()
    bat_dau = KH.gio_iso()
    kq = {"phien_ban_khuon": KH.PHIEN_BAN_KHUON, "lenh": lenh["lenh"], "tram": ch.tram, "bat_dau": bat_dau, "ket_thuc": None,
          "trang_thai": "LOI", "buoc": [], "viec_can_nguoi": [], "tep": []}
    if not duong_so:
        for b in lenh["buoc"]:
            kq["buoc"].append({"ten": b, "trang_thai": "LOI", "loi": "không mở được sổ"})
        kq["ket_thuc"] = KH.gio_iso()
        kq["trang_thai"] = "LOI"
        return kq
    pt, loi_doc = None, ""
    buoc_bo_qua = []
    viec_them = []               # GD349: viec can nguoi tu tram VB6 (vd DONG_DUOI_NGUONG)
    for b in lenh["buoc"]:
        if bao:
            bao(b)
        if b in BUOC_CHI_DOC:
            if pt is None and not loi_doc:
                try:
                    pt = PHAN_TICH(duong_so, hom_nay, ch.sau, tham_so_quy_tac(ho_so))
                except Exception as e:
                    loi_doc = "không đọc được sổ: %s" % type(e).__name__
                    ghi_log(ch, "%s: %s\n%s" % (lenh["lenh"], loi_doc, traceback.format_exc(limit=3)))
            if loi_doc:
                kq["buoc"].append({"ten": b, "trang_thai": "LOI", "loi": loi_doc})
                continue
            if b == "kiem_tra":
                if pt["loi"]["bt"]:
                    kq["buoc"].append({"ten": b, "trang_thai": "LOI", "loi": pt["loi"]["bt"]})
                else:
                    bt = pt["bt"] or {}
                    kq["buoc"].append({"ten": b, "trang_thai": "XONG",
                                       "chi_so": {"bat_thuong": bt.get("n", 0), "cao": bt.get("cao", 0), "vua": bt.get("vua", 0),
                                                  "thap": bt.get("thap", 0), "chung_tu": (pt["dh"] or {}).get("ct_so")}})
            else:
                if pt["loi"]["dc"]:
                    kq["buoc"].append({"ten": b, "trang_thai": "LOI", "loi": pt["loi"]["dc"]})
                else:
                    dc = pt["dc"] or {}
                    cl = dc.get("cl") or []
                    kq["buoc"].append({"ten": b, "trang_thai": "XONG",
                                       "chi_so": {"chenh_lech": sum(1 for x in cl if x[1] != "THONG_TIN"),
                                                  "loi": sum(1 for x in cl if x[1] == "LOI"), "nhom": dc.get("nhom"),
                                                  "hd_chua_hach_toan": (dc.get("hien_trang") or {}).get("hd_chua")}})
        elif b == "sua_chung_tu":
            # GD348a: so thuc hien ERP_THUCHIEN (GD346) - ma da duoc VB6 / ke toan thuc hien tren UNESCO AI -> DA_SUA; con lai KHONG_SUA
            try:
                import erp_thuc_hien as TH
                th, loi_th = TH.doc(duong_so)
                da = TH.da_sua_tu(lenh.get("sua") or [], th)
            except Exception as e:
                th, loi_th, da = [], "erp_thuc_hien lỗi: %s" % type(e).__name__, {}
            if loi_th:
                ghi_log(ch, "%s: %s" % (lenh["lenh"], loi_th))
            kq["da_sua"] = [da.get(x["ma"]) or {"ma": x.get("ma"), "trang_thai": "KHONG_SUA", "ly_do": LY_DO_CHUA_HO_TRO}
                            for x in (lenh.get("sua") or []) if isinstance(x, dict) and x.get("ma")]
            n_da = sum(1 for x in kq["da_sua"] if x["trang_thai"] == "DA_SUA")
            if n_da and n_da == len(kq["da_sua"]):
                kq["buoc"].append({"ten": b, "trang_thai": "XONG", "chi_so": {"da_sua": n_da}})
            else:
                kq["buoc"].append({"ten": b, "trang_thai": "BO_QUA", "ly_do": LY_DO_CHUA_HO_TRO, "chi_so": {"da_sua": n_da}})
                buoc_bo_qua.append((b, LY_DO_CHUA_HO_TRO))
        elif b in BUOC_VB:
            # GD349: tram VB6 dang bat -> giao buoc ghi (mo so, sao luu, ham co san qua ClsChungtu); tat -> BO_QUA nhu cu
            bv, viec_vb = yeu_cau_vb(ch, lenh, b, duong_so, bao)
            if bv is None:
                kq["buoc"].append({"ten": b, "trang_thai": "BO_QUA", "ly_do": LY_DO_CHUA_HO_TRO})
                buoc_bo_qua.append((b, LY_DO_CHUA_HO_TRO))
            else:
                kq["buoc"].append(bv)
                if bv["trang_thai"] in ("BO_QUA", "CAN_NGUOI"):
                    buoc_bo_qua.append((b, bv.get("ly_do") or ""))
                viec_them.extend(viec_vb)
                ghi_log(ch, "%s: VB6 %s -> %s" % (lenh["lenh"], b, bv["trang_thai"]))
        else:
            kq["buoc"].append({"ten": b, "trang_thai": "BO_QUA", "ly_do": LY_DO_CHUA_HO_TRO})
            buoc_bo_qua.append((b, LY_DO_CHUA_HO_TRO))
    lech = lech_ho_so(ho_so, (pt or {}).get("dh")) if pt is not None else ""
    if lech:
        # So khac ho so ERP: khong gui hien trang / chung tu sai cua so nay vao khach cua ERP.
        for x in kq["buoc"]:
            if x["ten"] in BUOC_CHI_DOC and x["trang_thai"] == "XONG":
                x["trang_thai"] = "LOI"
                x["loi"] = lech
        kq["viec_can_nguoi"] = [{"ma": "HO_SO:NAM_TC", "loai": "KHONG_KHOP_HO_SO", "muc": "NANG", "mo_ta": lech}] + KH.viec_can_nguoi_tu([], None, buoc_bo_qua)
        pt = None
    if pt is not None:
        dh, dc, bt = pt.get("dh"), pt.get("dc"), pt.get("bt")
        kq["hien_trang"] = KH.hien_trang_tu(dh, dc, bt)
        kq["hien_trang"]["ban_chup"] = pt.get("ban_chup")
        if ho_so and ho_so.get("bo_quy_tac"):
            kq["hien_trang"]["bo_quy_tac_erp_giao"] = str(ho_so["bo_quy_tac"])[:40]
            # Da chay bang tham so ke toan dat trong ERP -> ket qua thuoc bo quy tac do (ERP luu RuleSetCode de tai hien).
            if pt.get("quy_tac_ap_dung"):
                kq["hien_trang"]["bo_quy_tac"] = str(ho_so["bo_quy_tac"])[:40]
                kq["hien_trang"]["quy_tac_ap_dung"] = list(pt["quy_tac_ap_dung"])
        if pt.get("ban_chup_sau") and pt.get("ban_chup_sau") != pt.get("ban_chup"):
            # F09: so bi sua trong luc doc -> ket qua khong nhat quan, khong duoc coi la da kiem
            for x in kq["buoc"]:
                if x["ten"] in BUOC_CHI_DOC and x["trang_thai"] == "XONG":
                    x["trang_thai"] = "LOI"
                    x["loi"] = "sổ bị thay đổi trong lúc kiểm (bản chụp trước/sau khác nhau) - chạy lại"
        else:
            cl = (dc or {}).get("cl") or []
            kq["quy_tac"] = KH.quy_tac_tu(cl, bt, pt["loi"]["dc"] or None, pt["loi"]["bt"] or None)
            if "kiem_tra" in lenh["buoc"] and not pt["loi"]["bt"]:
                # "Khong phai loi" ke toan da ket luan trong ERP (bo_qua[]): khong bao lai - nhu HDDT_KS_BoQua cua UNESCO.
                # Loc theo tung chung tu (ma): mot dong bat thuong co 2 chung tu ma ke toan chi bo qua 1 thi dong kia van bao.
                # khoa_tram chi de GD348 (VB6) ghi HDDT_KS_BoQua tren man hinh UNESCO.
                ma_bq, _khoa_bq = KH.khoa_bo_qua(lenh)
                kq["chung_tu_sai"] = [x for x in KH.chung_tu_sai_tu((bt or {}).get("dong"), pt.get("ct"), pt.get("tk")) if x["ma"] not in ma_bq]
                if ma_bq:
                    kq["da_bo_qua"] = sorted(ma_bq)
                # Lop A "tu sua" do ke toan dat trong ERP (tham so tu_sua=true cua ma loi); tram chi doc van tra KHONG_SUA
                # cho toi GD348, nhung ERP hien dung "Duoc" de giao viec.
                ts = tham_so_quy_tac(ho_so)
                for x in kq["chung_tu_sai"]:
                    if (ts.get(x.get("ma_loi", "").upper()) or {}).get("tu_sua") is True:
                        x["tu_sua"] = True
            kq["viec_can_nguoi"] = KH.viec_can_nguoi_tu(cl if not pt["loi"]["dc"] else [], bt, buoc_bo_qua)
            gt = pt.get("gt")
            if gt:                                         # GD350: K60 + viec gia thanh (so co san xuat)
                tg = gt["tong"]
                q = {"ma": "K60", "ten": "Phương án giá thành tháng %02d/%d" % tg["thang_lich"], "so_dong": tg["so_viec"]}
                if any(v[0] == "NANG" for v in gt["viec"]):
                    q.update({"ket_qua": "LECH", "muc": "NANG"})
                elif gt["viec"]:
                    q.update({"ket_qua": "LECH", "muc": "VUA"})
                else:
                    q["ket_qua"] = "DAT"
                q["chi_tiet"] = [{"khoa": v[1], "mo_ta": KH._chu(v[2], 300), "so_lieu": KH._chu(v[4], 300) if v[4] else ""} for v in gt["viec"][:30]]
                kq["quy_tac"].append(q)
                kq["hien_trang"]["gia_thanh"] = {"thang": "%04d-%02d" % (tg["thang_lich"][1], tg["thang_lich"][0]), "so_phieu": tg["so_phieu"], "so_tp": tg["so_tp"],
                                                 "gia_thanh": int(tg["gia_thanh"]), "doanh_thu": int(tg["doanh_thu"]), "lai_du_kien": int(tg["lai_du_kien"]),
                                                 "sp_lo": tg["sp_lo"], "nvl_thieu": tg["nvl_thieu"], "nvl_am": tg["nvl_am"], "nvl_can_mua": tg["nvl_can_mua"],
                                                 "chi_phi_chua_phan_bo": int(tg["chua_pb"])}
                co = {v.get("ma") for v in kq["viec_can_nguoi"]}
                for v in gt["viec"]:
                    ma = KH.ma_sach("K60:%s:%s" % (v[1], kq["hien_trang"]["gia_thanh"]["thang"]), 100)
                    if ma not in co:
                        kq["viec_can_nguoi"].append({"ma": ma, "loai": v[1][:30], "buoc": "kiem_tra", "quy_tac": "K60", "muc": v[0],
                                                     "mo_ta": KH._chu(v[2] + " | Làm ở: " + v[3], 500), "so_lieu": KH._chu(v[4], 300) if v[4] else ""})
    elif not lech:
        kq["viec_can_nguoi"] = KH.viec_can_nguoi_tu([], None, buoc_bo_qua)
    try:                                                   # GD348a: so thuc hien (v1.1) - moi dong ERP_THUCHIEN, ke ca de xuat DX263
        import erp_thuc_hien as TH
        th, _ = TH.doc(duong_so)
        if th:
            kq["thuc_hien"] = th[:500]
    except Exception:
        pass
    if viec_them:
        co = {v.get("ma") for v in kq["viec_can_nguoi"]}
        kq["viec_can_nguoi"] += [v for v in viec_them if v["ma"] not in co]
    tt = [x["trang_thai"] for x in kq["buoc"]]
    if any(t == "LOI" for t in tt):
        kq["trang_thai"] = "LOI"
    elif kq["viec_can_nguoi"]:
        kq["trang_thai"] = "XONG_CO_VIEC"
    else:
        kq["trang_thai"] = "XONG"
    kq["ket_thuc"] = KH.gio_iso()
    return kq


def ghi_ket_qua(ch, kq):
    loi = KH.kiem_ket_qua(kq)
    if loi:
        raise ValueError("kết quả sai khuôn: " + "; ".join(loi[:5]))
    p = ch.tm("ket_qua", kq["lenh"] + ".ket_qua.json")
    ghi_json_nguyen_tu(p, kq)
    return p


def _da_co_ket_qua(ch, ma):
    return os.path.isfile(ch.tm("ket_qua", ma + ".ket_qua.json")) or os.path.isfile(ch.tm("ket_qua", "da_gui", ma + ".ket_qua.json"))


def _tra_ve_cho(ch, dang_lam, ten):
    try:
        os.replace(dang_lam, ch.tm("cho", ten))
    except OSError:
        pass


def xu_ly_tep_lenh(ch, tep_cho, hom_nay=None):
    """Nhan mot tep lenh trong cho\\. -> 'XONG' | 'BO_QUA' (khong nhan) | 'LOI'."""
    ten = os.path.basename(tep_cho)
    ma = ten[:-5] if ten.lower().endswith(".json") else ten
    try:
        lenh = doc_json(tep_cho)
    except (OSError, ValueError) as e:
        ghi_log(ch, "%s: tệp lệnh không đọc được (%s) - để lại" % (ten, type(e).__name__))
        return "BO_QUA"
    loi = KH.kiem_lenh(lenh)
    if not loi and lenh["lenh"] != ma:
        loi = ["tên tệp khác mã lệnh"]
    het_han = KH.doc_gio(lenh.get("het_han")) if isinstance(lenh, dict) else None
    if not loi and het_han and het_han < _dt.datetime.now().astimezone():
        return "BO_QUA"                                    # ERP tu chuyen HET_HAN; tram khong nhan lenh da het han
    if _da_co_ket_qua(ch, ma):
        try:
            os.replace(tep_cho, ch.tm("xong", ten))
        except OSError:
            pass
        ghi_log(ch, "%s: đã có kết quả - không làm lại" % ma)
        return "BO_QUA"
    dang_lam = ch.tm("dang_lam", ten)
    try:
        os.replace(tep_cho, dang_lam)                      # nguyen tu cung o dia: tram khac se khong thay tep nua
    except OSError:
        return "BO_QUA"
    if loi:
        kq = {"phien_ban_khuon": KH.PHIEN_BAN_KHUON, "lenh": ma if KH._RE_LENH.match(ma) else "LENH-SAI", "tram": ch.tram,
              "bat_dau": KH.gio_iso(), "ket_thuc": KH.gio_iso(), "trang_thai": "LOI", "buoc": [],
              "viec_can_nguoi": [{"loai": "LENH_SAI_KHUON", "mo_ta": "; ".join(loi)[:500]}]}
        ghi_log(ch, "%s: lệnh sai khuôn: %s" % (ma, "; ".join(loi)))
        try:
            ghi_ket_qua(ch, kq)
            os.replace(dang_lam, ch.tm("xong", ten))
        except (OSError, ValueError) as e:
            ghi_log(ch, "%s: không ghi được kết quả lỗi: %s" % (ma, type(e).__name__))
        return "LOI"
    so = lenh["so"]
    if not khoa_so(ch, so):
        ghi_log(ch, "%s: sổ %s đang được trạm khác làm - trả lại hàng đợi" % (ma, os.path.basename(so)))
        _tra_ve_cho(ch, dang_lam, ten)
        return "BO_QUA"
    try:
        duong, loi_so = tim_so(ch.data, so)
        if loi_so:
            ghi_log(ch, "%s: %s" % (ma, loi_so))
        bao_song(ch, os.path.basename(so), lenh["buoc"][0])
        ghi_log(ch, "%s: bắt đầu, sổ %s, bước %s" % (ma, os.path.basename(so), ",".join(lenh["buoc"])))
        kq = lam_lenh(ch, lenh, duong, hom_nay, bao=lambda b: bao_song(ch, os.path.basename(so), b), ho_so=doc_ho_so(ch, so))
        if loi_so:
            kq["viec_can_nguoi"].insert(0, {"loai": "KHONG_THAY_SO", "mo_ta": loi_so[:500]})
        ghi_ket_qua(ch, kq)
        os.replace(dang_lam, ch.tm("xong", ten))
        ghi_log(ch, "%s: %s (%s)" % (ma, kq["trang_thai"], ", ".join("%s=%s" % (b["ten"], b["trang_thai"]) for b in kq["buoc"])))
        return "XONG"
    except Exception as e:
        ghi_log(ch, "%s: LỖI %s\n%s" % (ma, type(e).__name__, traceback.format_exc(limit=5)))
        try:
            kq = {"phien_ban_khuon": KH.PHIEN_BAN_KHUON, "lenh": ma, "tram": ch.tram, "bat_dau": KH.gio_iso(), "ket_thuc": KH.gio_iso(),
                  "trang_thai": "LOI", "buoc": [{"ten": b, "trang_thai": "LOI", "loi": "lỗi chương trình trạm: %s" % type(e).__name__} for b in lenh["buoc"]],
                  "viec_can_nguoi": []}
            ghi_ket_qua(ch, kq)
            os.replace(dang_lam, ch.tm("xong", ten))
        except Exception:
            _tra_ve_cho(ch, dang_lam, ten)
        return "LOI"
    finally:
        mo_khoa(ch, so)
        bao_song(ch)


def quet_mot_luot(ch, hom_nay=None):
    """Quet cho\\ theo thu tu gio tep. -> so lenh da lam."""
    bao_song(ch)
    n = 0
    try:
        teps = sorted((p for p in os.listdir(ch.tm("cho")) if p.lower().endswith(".json")),
                      key=lambda p: os.path.getmtime(ch.tm("cho", p)))
    except OSError:
        return 0
    for p in teps:
        if os.path.isfile(ch.tm("tram", ch.tram + ".dung")):
            break
        if xu_ly_tep_lenh(ch, ch.tm("cho", p), hom_nay) == "XONG":
            n += 1
    return n


def vong_lap(ch):
    tao_thu_muc(ch)
    dung = ch.tm("tram", ch.tram + ".dung")
    ghi_log(ch, "Trạm %s bắt đầu (chỉ đọc). Hộp thư %s. Dừng an toàn: tạo tệp %s" % (ch.tram, ch.lenh, dung))
    try:
        while not os.path.isfile(dung):
            quet_mot_luot(ch)
            for _ in range(ch.giay_cho):
                if os.path.isfile(dung):
                    break
                time.sleep(1)
    except KeyboardInterrupt:
        pass
    try:
        os.remove(dung)
    except OSError:
        pass
    ghi_log(ch, "Trạm %s dừng." % ch.tram)


# ------------------------------------------------------------------ dong lenh
def _ts(argv):
    t = {}
    for a in argv[1:]:
        if a.startswith("/") and ":" in a:
            k, v = a[1:].split(":", 1)
            t[k.lower()] = v.strip('"')
        elif a.startswith("/"):
            t[a[1:].lower()] = "1"
    return t


def main(argv=None):
    t = _ts(argv or sys.argv)
    hom_nay = _dt.date.today()
    if t.get("mot"):
        ch = CauHinh({"lenh": os.path.join(HERE, "ket-qua", "erp_tram_thu"), "data": os.path.dirname(t["mot"]), "tram": "THU"})
        pt = PHAN_TICH(t["mot"], hom_nay)
        kq = {"hien_trang": KH.hien_trang_tu(pt.get("dh"), pt.get("dc"), pt.get("bt")),
              "quy_tac": KH.quy_tac_tu(((pt.get("dc") or {}).get("cl")), pt.get("bt"), pt["loi"]["dc"] or None, pt["loi"]["bt"] or None),
              "chung_tu_sai": KH.chung_tu_sai_tu(((pt.get("bt") or {}).get("dong")), pt.get("ct"), pt.get("tk")),
              "loi": pt["loi"], "ban_chup": pt.get("ban_chup")}
        ra = t.get("ra") or os.path.join(HERE, "ket-qua", "erp_tram_mot.json")
        os.makedirs(os.path.dirname(ra), exist_ok=True)
        ghi_json_nguyen_tu(ra, kq)
        print("Da ghi %s: chung_tu_sai=%d quy_tac=%d" % (ra, len(kq["chung_tu_sai"]), len(kq["quy_tac"])))
        return 0
    if t.get("lenh"):
        lenh = doc_json(t["lenh"])
        loi = KH.kiem_lenh(lenh)
        if loi:
            print("Lenh sai khuon: " + "; ".join(loi))
            return 2
        ch = CauHinh({"lenh": os.path.join(HERE, "ket-qua", "erp_tram_thu"), "data": t.get("data") or HERE, "tram": t.get("tram") or "THU"})
        duong, loi_so = tim_so(ch.data, lenh["so"])
        kq = lam_lenh(ch, lenh, duong, hom_nay)
        if loi_so:
            kq["viec_can_nguoi"].insert(0, {"loai": "KHONG_THAY_SO", "mo_ta": loi_so})
        loi = KH.kiem_ket_qua(kq)
        ra = t.get("ra") or os.path.join(HERE, "ket-qua", lenh["lenh"] + ".ket_qua.json")
        os.makedirs(os.path.dirname(ra), exist_ok=True)
        ghi_json_nguyen_tu(ra, kq)
        print("Da ghi %s: trang_thai=%s loi_khuon=%s" % (ra, kq["trang_thai"], loi or "khong"))
        return 0 if not loi else 3
    if not t.get("cau_hinh"):
        print(__doc__)
        return 1
    ch = doc_cau_hinh(t["cau_hinh"])
    tao_thu_muc(ch)
    if t.get("mot_lan"):
        n = quet_mot_luot(ch)
        ghi_log(ch, "Quét một lượt: %d lệnh đã làm" % n)
        return 0
    vong_lap(ch)
    return 0


if __name__ == "__main__":
    sys.exit(main())
