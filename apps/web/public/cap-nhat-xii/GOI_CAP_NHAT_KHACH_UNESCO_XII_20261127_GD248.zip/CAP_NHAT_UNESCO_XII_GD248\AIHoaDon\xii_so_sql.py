# -*- coding: utf-8 -*-
"""UNESCO XII only: reads a snapshot of the SQL Server book where UNESCO XI read the .MDB (XII has no .MDB).

The VB side (AiSqlBookSnapshot) writes <tool folder>\\so_sql_<stamp>.json, read only, never back into the book:
  {"format": "xii-so-sql-1", "db": "<database>", "tables": {"<Table>": {"cols": [...], "kinds": ["i"|"f"|"s"|"d"|"b", ...], "rows": [[...], ...]}}}
  i integer, f decimal / float, s text, d datetime "yyyy-MM-dd HH:mm:ss", b boolean, null stays null (like jet_doc).

Front door of the tool for these commands:   python xii_so_sql.py /thamso:<file>
  * installs this module as `jet_doc`, so the XI modules gia_thanh_phuong_an, no_kho_doi, khoa_so_thang, xuat_thang_nvl and
    nghiep_vu_dinh_ky run byte for byte as in XI against the snapshot;
  * /phuongan:"<snapshot>" [/thang:n] [/ra:<folder>] runs gia_thanh_phuong_an (XI runs it from its own command line); marker
    DA_XONG_KHOASO "OK <html>" like every other command of tool_htkk_unesco.py;
  * every other command is handed to tool_htkk_unesco.py unchanged (/nokhodoi, /khoathang, /nghiepvu, /xuatthang).
Prior-year books: XI's no_kho_doi.tim_so_nam_truoc globs *.MDB next to the book; XII has one SQL database per book, so the VB side
(AiPriorYearBook, TASK369 / Q-YE4) finds the books of the previous years of the same tax code on the server, snapshots them read only and
passes /sotruoc:"<year>=<snapshot>;..."; _so_nam_truoc answers tim_so_nam_truoc from that list (year of the book - 1), nothing else changes.
Without the switch the opening balance stays "age unknown", as XI does when it has no prior book."""
import datetime
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
FORMAT = "xii-so-sql-1"

# jet_doc constants, kept so a module that reads them keeps working
T_BOOL, T_BYTE, T_INT, T_LONG, T_MONEY, T_FLOAT, T_DOUBLE = 1, 2, 3, 4, 5, 6, 7
T_DATE, T_BINARY, T_TEXT, T_OLE, T_MEMO, T_GUID, T_NUMERIC = 8, 9, 0x0A, 0x0B, 0x0C, 0x0F, 0x10
TEN_KIEU = {"i": "LONG", "f": "DOUBLE", "s": "TEXT", "d": "DATETIME", "b": "BOOLEAN"}
KIEU_JET = {"i": T_LONG, "f": T_DOUBLE, "s": T_TEXT, "d": T_DATE, "b": T_BOOL}


def _ngay(s):
    if not isinstance(s, str) or not s:
        return None
    try:
        return datetime.datetime.fromisoformat(s.replace("T", " ")[:19])
    except ValueError:
        return None


class Mdb(object):
    """Same surface as jet_doc.Mdb for what the XI analysers call: bang, cot, so_ban_ghi, doc, dong."""

    def __init__(self, path, codepage=None):
        self.path = path
        self.phien_ban = "XII SQL Server"
        with open(path, "r", encoding="utf-8-sig") as f:
            goc = json.load(f)
        if not isinstance(goc, dict) or goc.get("format") != FORMAT:
            raise ValueError("Khong phai tep chup so SQL cua UNESCO XII (%s)" % os.path.basename(path))
        self.ten_db = goc.get("db") or ""
        self.bang_goc = {}
        for ten, t in (goc.get("tables") or {}).items():
            self.bang_goc[ten.lower()] = (ten, list(t.get("cols") or []), list(t.get("kinds") or []), t.get("rows") or [])

    def dong(self):
        self.bang_goc = {}

    def bang(self, he_thong=False):
        return {v[0]: 0 for v in self.bang_goc.values()}

    def truy_van(self):
        return []

    def bang_lien_ket(self):
        return []

    def _tim(self, ten):
        v = self.bang_goc.get(str(ten).lower())
        if v is None:
            raise KeyError("Khong co bang %s" % ten)
        return v

    def cot(self, ten):
        _, cols, kinds, _rows = self._tim(ten)
        return [{"ten": c, "kieu": KIEU_JET.get(k, T_TEXT), "ten_kieu": TEN_KIEU.get(k, "TEXT"), "dai": 0} for c, k in zip(cols, kinds)]

    def so_ban_ghi(self, ten):
        v = self.bang_goc.get(str(ten).lower())
        return len(v[3]) if v else None

    def doc(self, ten, toi_da=None):
        _, cols, kinds, rows = self._tim(ten)
        ngay = [cols[i] for i, k in enumerate(kinds) if k == "d" and i < len(cols)]
        so_thuc = [cols[i] for i, k in enumerate(kinds) if k == "f" and i < len(cols)]
        so_nguyen = [cols[i] for i, k in enumerate(kinds) if k == "i" and i < len(cols)]
        out = []
        for r in rows:
            if toi_da and len(out) >= toi_da:
                break
            d = dict(zip(cols, r))
            for c in ngay:
                d[c] = _ngay(d[c])
            for c in so_thuc:                 # jet_doc gives float for DOUBLE / CURRENCY, int for LONG: keep the type, keep null
                if d[c] is not None:
                    d[c] = float(d[c])
            for c in so_nguyen:
                if d[c] is not None:
                    d[c] = int(d[c])
            out.append(d)
        return out

    def cau_truc(self):
        return {v[0]: {c: (TEN_KIEU.get(k, "TEXT"), 0) for c, k in zip(v[1], v[2])} for v in self.bang_goc.values()}


def cai_dat():
    """From now on `import jet_doc` gives this module (the process is private to the run)."""
    sys.modules["jet_doc"] = sys.modules[__name__]


def _tham_so(args):
    ts = {}
    for a in args:
        for k in ("phuongan", "sphoctay", "ks368", "tenso", "thang", "tuthang", "ra", "sotruoc"):
            if a.startswith("/" + k + ":"):
                ts[k] = a[len(k) + 2:].strip('"')
    return ts


def _phuong_an(T, ts):
    """XI GD350 command line: gia_thanh_phuong_an.py /so:<book> [/thang:n] [/ra:<folder>] -> .txt + .html."""
    try:
        import gia_thanh_phuong_an as GT
        so = ts["phuongan"]
        d = GT.doc(so)
        thang = int(ts.get("thang") or 0) or GT.thang_moi_nhat(d)
        if not thang:
            T._ket_khoaso("", "So khong co phieu ket chuyen / phat sinh 154 - khong lap phuong an.")
            return 2
        kq = GT.phan_tich(d, thang)
        _txt, p_html = GT.ghi(kq, ts.get("ra") or os.path.join(HERE, "ket-qua"), os.path.basename(so))
        T._ket_khoaso(p_html, "")
        return 0
    except Exception as e:
        import traceback
        T.ghi_log("[PHUONG AN GIA THANH] loi: %s\n%s" % (e, traceback.format_exc()))
        T._ket_khoaso("", "Loi phuong an gia thanh: %s" % e)
        return 1


def _so_phu_hoc_tay(T, ts):
    """XI GD363 / GD365: so_phu_hoc_tay.chay(book, folder, name) -> ket-qua\\sp_hoc_tay.txt (H / QT / TK112 / SP / SD lines), read only."""
    try:
        import so_phu_hoc_tay as SP
        _q, _dx, _sd, p = SP.chay(ts["sphoctay"], ts.get("ra") or os.path.join(HERE, "ket-qua"), ts.get("tenso") or "")
        T._ket_khoaso(p, "")
        return 0
    except Exception as e:
        import traceback
        T.ghi_log("[SO PHU HOC TAY] loi: %s\n%s" % (e, traceback.format_exc()))
        T._ket_khoaso("", "Loi hoc so phu tu so tay: %s" % e)
        return 1


def _kiem_soat_368(T, ts):
    """XI GD368: gia_thanh_kiem_soat368.chay(book, folder, month, from) -> gia_thanh_kiem_soat.txt (TONG / NB / LL / GS / KH / DM / KV) + .html, read only."""
    try:
        import gia_thanh_kiem_soat368 as KS
        kq, p = KS.chay(ts["ks368"], ts.get("ra") or os.path.join(HERE, "ket-qua"), int(ts.get("thang") or 0), int(ts.get("tuthang") or 0))
        if not kq:
            T._ket_khoaso("", "So khong co phieu ket chuyen / phat sinh 154 - khong kiem soat gia thanh.")
            return 2
        T._ket_khoaso(p, "")
        return 0
    except Exception as e:
        import traceback
        T.ghi_log("[KIEM SOAT GIA THANH 368] loi: %s\n%s" % (e, traceback.format_exc()))
        T._ket_khoaso("", "Loi kiem soat gia thanh: %s" % e)
        return 1


def _so_nam_truoc(chuoi):
    """/sotruoc:"<year>=<snapshot>;..." (AiPriorYearBook.SnapshotChain): no_kho_doi.tim_so_nam_truoc answers from this list instead of
    globbing *.MDB - the book of year N-1 for a book of year N; the VB side already checked year and tax code (XI B09_SoTruoc)."""
    bang = {}
    for phan in (chuoi or "").split(";"):
        if "=" not in phan:
            continue
        nam, tep = phan.split("=", 1)
        try:
            if tep.strip() and os.path.isfile(tep.strip()):
                bang[int(nam.strip())] = tep.strip()
        except ValueError:
            pass
    if not bang:
        return
    import no_kho_doi
    no_kho_doi.tim_so_nam_truoc = lambda d, thu_muc_them=(): bang.get(int(d.get("nam") or 0) - 1)


def main(argv):
    cai_dat()
    if HERE not in sys.path:
        sys.path.insert(0, HERE)
    import tool_htkk_unesco as T
    ts = _tham_so([str(a) for a in T.mo_rong_tham_so(argv)])
    if ts.get("phuongan"):
        return _phuong_an(T, ts)
    if ts.get("sphoctay"):
        return _so_phu_hoc_tay(T, ts)
    if ts.get("ks368"):
        return _kiem_soat_368(T, ts)
    _so_nam_truoc(ts.get("sotruoc"))
    import runpy
    tool = os.path.join(HERE, "tool_htkk_unesco.py")
    sys.argv = [tool] + list(argv)
    runpy.run_path(tool, run_name="__main__")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
