# -*- coding: utf-8 -*-
"""GD78 - XUAT 1 LAN (Excel / XML HTKK) - CHI DOC SO.
VB6 (ModHDDTXuat1Lan.HDDT_X1L_Chay) lap JSON -> tool_htkk_unesco.py /xuat1lan:<json> /muc:<MA,...> /kieu:<E|X|EX> /thumuc:<thu muc MOI>
-> chay(duong_json, muc, kieu, thumuc) -> (thumuc, loi) -> moc DA_XONG_KHOASO "OK <thumuc>".
Moi muc do MOT module lap: lap(dl, ma, kieu, thumuc) -> {"tep": [duong...], "canh_bao": [chuoi...]} (hoac list duong tep)
  B01A B02 B03 F01 TNDN -> bao_cao_nam      B09 -> thuyet_minh_b09      TNCN -> qtt_tncn      SS_<ma> -> so_sach_mau
  GD171: SS_58<ma> -> so_sach_tt58 (bo so + B01 / B02-DNSN + XML 58_BCTC theo TT 58/2026 doanh nghiep sieu nho)
  GD172: SS_HKD<ma> -> ho_kinh_doanh (so S1a / S2a / S2b-HKD TT 152/2025 + to khai 01/CNKD TT 50/2026 + XML 01_CNKD_HKD_TT50)
  GD121: KK_TNCN -> kk_tncn (05/KK-TNCN quy)  DK_TNCN -> dk_tncn (05-DKT-TH TT90/2026)
  GD330: DK_NPT -> dk_npt (20/DK-TH-TCT TT86/2024 nguoi phu thuoc, Excel + XML HTKK)
  GD122: kieu co X -> tep XML vua lap duoc dua THANG vao HTKK tren may (htkk_dua_vao, khong ghi de to khai dang co)
  GD164: kieu co P (XP / EXP) -> CHUA dua vao HTKK: so_sanh_htkk.xem_truoc so voi to khai ky truoc + kiem cheo trong ky, ghi vao
         0_KET_QUA.txt + XemTruoc_SoSanh.xlsx; VB hien man hinh Xem truoc, bam "Dua vao HTKK" moi chep (tool /duavaohtkk:<thu muc>).
         DC_TNCN -> so_sanh_htkk (doi chieu TNCN: bang luong - TK 334 / 3335 - 05/KK da khai).
Loi cua mot muc KHONG lam hong ca lo: ghi vao 0_KET_QUA.txt, cac muc khac van lap. Thu muc ra do VB tao MOI moi lan
(khong ghi de / khong dung lai ket qua cu); tool tu choi thu muc da co tep .xlsx / .xml tu truoc."""
import importlib
import io
import json
import os
import traceback
from datetime import datetime

TEN_MUC = {
    "B01A": "B01a-DNN Báo cáo tình hình tài chính",
    "B02": "B02-DNN Báo cáo kết quả hoạt động kinh doanh",
    "B03": "B03-DNN Báo cáo lưu chuyển tiền tệ",
    "F01": "F01-DNN Bảng cân đối tài khoản",
    "B09": "B09-DNN Thuyết minh báo cáo tài chính",
    "TNDN": "03/TNDN Tờ khai quyết toán thuế TNDN",
    "TNCN": "05/QTT-TNCN Tờ khai quyết toán thuế TNCN",
    "KK_TNCN": "05/KK-TNCN Tờ khai khấu trừ thuế TNCN theo quý",
    "DK_TNCN": "05-ĐKT-TH Tờ khai đăng ký thuế tổng hợp của người lao động",
    "DK_NPT": "20/ĐK-TH-TCT Tờ khai đăng ký thuế tổng hợp người phụ thuộc (giảm trừ gia cảnh)",
    "DC_TNCN": "Đối chiếu thuế TNCN với sổ (bảng lương - TK 334, 3335 - 05/KK-TNCN đã khai)",
}
MODULE = {"B01A": "bao_cao_nam", "B02": "bao_cao_nam", "B03": "bao_cao_nam", "F01": "bao_cao_nam", "TNDN": "bao_cao_nam",
          "B09": "thuyet_minh_b09", "TNCN": "qtt_tncn", "KK_TNCN": "kk_tncn", "DK_TNCN": "dk_tncn", "DK_NPT": "dk_npt",
          "DC_TNCN": "so_sanh_htkk"}
# thu tu lap: bao cao tai chinh truoc (to khai / thuyet minh dung lai so lieu), roi to khai, roi so sach
THU_TU = ["B01A", "B02", "B03", "F01", "B09", "TNDN", "TNCN", "KK_TNCN", "DK_TNCN", "DK_NPT", "DC_TNCN"]


def ten_muc(ma):
    if ma in TEN_MUC:
        return TEN_MUC[ma]
    if ma.startswith("SS_"):
        try:
            m = importlib.import_module("so_sach_tt58" if ma.startswith("SS_58") else "ho_kinh_doanh" if ma.startswith("SS_HKD") else "so_sach_mau")
            return (getattr(m, "TEN_MAU", {}) or {}).get(ma, ma)
        except Exception:
            return ma
    return ma


def module_cua(ma):
    if ma.startswith("SS_58"):          # GD171: bo so TT 58/2026 doanh nghiep sieu nho
        return "so_sach_tt58"
    if ma.startswith("SS_HKD"):         # GD172: ho kinh doanh - so TT 152/2025 + 01/CNKD
        return "ho_kinh_doanh"
    if ma.startswith("SS_"):
        return "so_sach_mau"
    return MODULE.get(ma)


def sap_xep(ds):
    ds = [x for x in ds if x]
    ds2 = [x for x in THU_TU if x in ds] + [x for x in ds if x not in THU_TU]
    return list(dict.fromkeys(ds2))


def doc_json(duong):
    with open(duong, "r", encoding="utf-8-sig") as f:
        dl = json.loads(f.read(), strict=False)      # nhu cac bao cao khac: chuoi VB co the co ky tu dieu khien
    try:
        import tieu_de_tt
        tieu_de_tt.nhan(dl)                           # GD139: Thong tu cua bo so -> tieu de mau khi ghi Excel
    except Exception:
        pass
    return dl


def _chuan_kq(r):
    if r is None:
        return [], []
    if isinstance(r, dict):
        return list(r.get("tep") or []), list(r.get("canh_bao") or [])
    if isinstance(r, (list, tuple)):
        return [str(x) for x in r], []
    return [str(r)], []


def _dua_vao_htkk(dl, kieu, tep, log):
    """GD122: tep XML HTKK vua lap -> dua THANG vao HTKK tren may (DataFiles\\<MST>): mo HTKK dung MST la thay so.
    To khai HTKK dang co cung ky -> KHONG ghi de (quy tac 18), ghi danh sach cho de nut Mo HTKK hoi ghi de."""
    xml = [t for t in tep if t.lower().endswith(".xml")]
    if "X" not in kieu or not xml:
        return []
    xml = list(dict.fromkeys(os.path.normcase(os.path.abspath(t)) for t in xml))    # nhieu muc BCTC chung mot tep XML
    try:
        import htkk_dua_vao as DV
        if not DV.bat():
            return []
        mst = (dl.get("dn") or dl.get("cty") or {}).get("mst", "")
        goc = DV._goc_htkk("")
        d = ["", "ĐƯA VÀO HTKK (bấm Mở HTKK - tự đăng nhập MST công ty, mở tờ khai đúng kỳ là thấy số, không cần Nhập XML):"]
        if not goc:
            return d + ["[--] Không tìm thấy HTKK trên máy - dùng Nhập XML trong HTKK với các tệp XML ở trên."]
        kqs = []
        for p in xml:
            k = DV.dua_vao(p, mst, goc, False, log=log)
            kqs.append(k)
            d.extend(DV.mo_ta(k))
        if DV.ghi_cho_ghi_de(kqs):
            d.append("      Bấm Mở HTKK: phần mềm hỏi có ghi đè tờ khai đang có trong HTKK không (tờ khai cũ được sao lưu trước).")
        return d
    except Exception as e:
        log("[XUAT 1 LAN] dua vao HTKK loi: %s" % e)
        return ["", "[--] Đưa vào HTKK: lỗi %s - dùng Nhập XML trong HTKK." % e]


def _xem_truoc(dl, tep, thumuc, log):
    """GD164: XML vua lap -> so sanh ky truoc + kiem cheo trong ky (chua ghi HTKK). -> cac dong bao cao."""
    xml = [t for t in tep if t.lower().endswith(".xml")]
    if not xml:
        return ["", "[i] Không có tờ khai XML để xem trước / đưa vào HTKK."]
    try:
        import htkk_dua_vao as DV
        import so_sanh_htkk as SS
        mst = (dl.get("dn") or dl.get("cty") or {}).get("mst", "")
        khach = os.path.dirname(os.path.dirname(os.path.abspath(thumuc)))
        kq = SS.xem_truoc(xml, mst, khach, DV._goc_htkk(""), thumuc, log)
        return kq["dong"]
    except Exception as e:
        log("[XUAT 1 LAN] xem truoc HTKK loi: %s\n%s" % (e, traceback.format_exc()))
        return ["", "[i] Chưa so sánh được với kỳ trước (%s) - vẫn có thể đưa vào HTKK." % e]


def chay(duong_json, muc, kieu, thumuc, ghi_log=None):
    """-> (thumuc, loi). loi rong khi co it nhat mot tep; bao cao chi tiet trong <thumuc>/0_KET_QUA.txt."""
    log = ghi_log or (lambda s: None)
    kieu = (kieu or "E").upper()
    if not any(k in kieu for k in "EX"):
        kieu = "E"
    ds = sap_xep([x.strip().upper() for x in (muc or "").split(",")])
    if not ds:
        return None, "Chua chon muc nao"
    if not thumuc:
        return None, "Thieu thu muc ket qua"
    os.makedirs(thumuc, exist_ok=True)
    cu = [f for f in os.listdir(thumuc) if f.lower().endswith((".xlsx", ".xml", ".xls"))]
    if cu:
        return None, "Thu muc ket qua da co tep cu (%s) - phai la thu muc moi" % cu[0]
    dl = doc_json(duong_json)
    dl.setdefault("x1l", {})
    dl["x1l"]["thumuc"] = thumuc
    dl["x1l"]["kieu"] = kieu
    dong = ["KẾT QUẢ XUẤT 1 LẦN - %s" % datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
            "Đơn vị: %s   MST: %s" % ((dl.get("dn") or dl.get("cty") or {}).get("ten", ""), (dl.get("dn") or dl.get("cty") or {}).get("mst", "")),
            "Kỳ: %s - %s   Kiểu: %s" % ((dl.get("x1l") or {}).get("tu", ""), (dl.get("x1l") or {}).get("den", ""),
                                       {"E": "Excel", "X": "XML HTKK", "EX": "Excel + XML HTKK"}.get(kieu.replace("P", ""), kieu)),
            "Thư mục: %s" % thumuc, ""]
    tong_tep, so_loi = [], 0
    cache = {}
    for ma in ds:
        ten = ten_muc(ma)
        mod = module_cua(ma)
        if not mod:
            dong.append("[LỖI] %s: mục không có trong phần mềm" % ma)
            so_loi += 1
            continue
        try:
            if mod not in cache:
                cache[mod] = importlib.import_module(mod)
            tep, cb = _chuan_kq(cache[mod].lap(dl, ma, kieu, thumuc))
            tep = [t for t in tep if t and os.path.isfile(t)]
            if tep:
                dong.append("[OK] %s" % ten)
                for t in tep:
                    dong.append("      %s" % os.path.basename(t))
                tong_tep.extend(tep)
            else:
                dong.append("[--] %s: không có số liệu để lập" % ten)
            for c in cb:
                dong.append("      ! %s" % c)
        except Exception as e:
            so_loi += 1
            log("[XUAT 1 LAN] %s loi: %s\n%s" % (ma, e, traceback.format_exc()))
            dong.append("[LỖI] %s: %s" % (ten, e))
    dong.append("")
    dong.append("Tổng: %d tệp, %d mục lỗi. Số liệu lấy trực tiếp từ sổ tại thời điểm xuất (không dùng tệp cũ)." % (len(tong_tep), so_loi))
    if "P" in kieu and "X" in kieu:
        dong.extend(_xem_truoc(dl, tong_tep, thumuc, log))          # GD164: xem truoc, chua dua vao HTKK
    else:
        dong.extend(_dua_vao_htkk(dl, kieu, tong_tep, log))
    try:
        with io.open(os.path.join(thumuc, "0_KET_QUA.txt"), "w", encoding="utf-8-sig", newline="\r\n") as f:
            f.write("\n".join(dong) + "\n")
    except Exception as e:
        log("[XUAT 1 LAN] khong ghi duoc 0_KET_QUA.txt: %s" % e)
    if not tong_tep:
        return None, "Khong lap duoc tep nao - xem %s" % os.path.join(thumuc, "0_KET_QUA.txt")
    return thumuc, ""
