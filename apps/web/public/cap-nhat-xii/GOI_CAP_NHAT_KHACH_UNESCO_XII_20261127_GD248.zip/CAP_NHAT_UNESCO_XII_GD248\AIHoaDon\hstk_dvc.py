# -*- coding: utf-8 -*-
"""
hstk_dvc.py - GD54: tab "Ho so thue - Cong DVC" tren man hinh tai hoa don (tool_tai_hoa_don_unesco.py).

MUC DICH (theo video anh Thang 24/09/2026 tren dichvucong.gdt.gov.vn):
  1. Doi chieu so lieu : chi tieu to khai DA NOP (XML tai tu cong) <-> so sach UNESCO <-> hoa don dien tu da tai.
  2. Xac nhan ho so    : danh sach ho so da nop, trang thai (Da chap nhan...), thong bao tiep nhan / xac nhan,
                         ky nao den han ma chua thay to khai.
  3. Cac thong bao     : tai ve va doc noi dung thong bao cua tung ho so.
  4. So thue phai nop  : theo to khai (01/GTGT: [40] con phai nop, [43] chuyen ky sau; 03/TNDN: [I]) + han nop.

LUONG (dung dung cac buoc anh lam tren video):
  Chrome (ho so rieng cua MST) -> NGUOI DUNG tu dang nhap (MST-ql + mat khau + ma captcha) -> TRA CUU HO SO ->
  go Tu ngay / Den ngay / Ma xac nhan -> Tim kiem.  Tool chi DOC bang ket qua dang hien tren trang.
  Sau do tool tu mo trang chi tiet tung ho so (trang nay khong co captcha), doc thong tin, bam "Xem thong bao" /
  "Xem tai lieu" -> "Tai xuong" -> doc XML to khai + XML thong bao.

QUY TAC 17 (bat bien): KHONG dien / khong doc / khong vuot captcha, KHONG doc hay luu mat khau, KHONG ky, KHONG nop
thay. Tool KHONG goi lai lenh tra cuu (lenh co ma xac nhan) - chi doc ket qua nguoi dung vua tra.
Khong ghi so ke toan: chi luu du lieu tra cuu + tep tai ve, va ghi dvc_hs_*.jsonl de UNESCO nap vao kho tra cuu DVC.
"""
import io
import json
import os
import re
import shutil
import subprocess
import threading
import time
import unicodedata
import urllib.parse
import urllib.request
import zipfile
import xml.etree.ElementTree as ET
from datetime import date, datetime, timedelta

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TRANG_DVC = "https://dichvucong.gdt.gov.vn"
TRANG_TCHS = TRANG_DVC + "/tthc/tchs"
# Duong trang chi tiet thay trong video: /tthc/tchs/files/detail/G12.18-260721-00083065?loai=
MAU_CT_MAC_DINH = TRANG_DVC + "/tthc/tchs/files/detail/{MA}?loai="
NGUONG_LECH = 1000          # lech tren 1.000 d moi bao "Lech"

# Cau hinh do tool tai hoa don gan vao (xem cau_hinh()). Chay doc lap thi dung gia tri mac dinh.
CAU_HINH = {
    "log": None,                      # doi tuong co .ghi(chuoi) va .loi(chuoi, e)
    # Ho so Chrome RIENG cho Cong DVC cua tung MST (chrome-ho-so\<MST>-dvc): khong dung chung ho so voi Chrome
    # trang hoa don (hai Chrome cung mot ho so thi cai mo sau khong nhan cong go loi -> tool tai hoa don bi treo cho).
    "ho_so_chrome": lambda: os.path.join(BASE_DIR, "chrome-ho-so", "CHUNG-dvc"),
    "tim_chrome": lambda: "",
    "thu_muc": lambda: "",            # thu muc du lieu cua khach (<MDB>\AIHoaDon\<MST>)
    "mst": lambda: "",
    "headless": False,                # chi dung khi kiem thu
    "trang_vao": TRANG_TCHS,
}

TT = {"cong": 0, "tien_trinh": None, "kenh": None, "kenh_b": None, "trang_thai": "chua_mo", "loi": "",
      "nghe": False, "luong_nghe": None, "dung": False, "the_he": 0,
      "viec": {"dang_chay": False, "ten": "", "tong": 0, "xong": 0, "loi": 0, "hien_tai": "", "ket_thuc": ""},
      "bao": ""}
KHOA = threading.Lock()
_KHO = {"du_lieu": None, "duong": ""}

try:
    from tool_dvc_unesco import KenhCDP                   # dung chung voi tool Cong DVC (GD19-GD23)
except Exception:                                          # pragma: no cover
    KenhCDP = None


# ---------------------------------------------------------------------------
#  tien ich
# ---------------------------------------------------------------------------
def cau_hinh(**kw):
    for k, v in kw.items():
        CAU_HINH[k] = v


def _ghi(s):
    lg = CAU_HINH.get("log")
    try:
        if lg is not None:
            lg.ghi("[HSTK] " + s)
    except Exception:
        pass


def bo_dau(s):
    s = str(s or "").replace("Đ", "D").replace("đ", "d")
    s = "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")
    return re.sub(r"\s+", " ", s).strip().lower()


def _so(v):
    """'1.148.254.512' / '1148254512' / '100.00' / '-16000000' -> float (khong doc duoc -> None)."""
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    t = str(v).strip().replace(" ", "")
    if not t:
        return None
    am = t.startswith("(") and t.endswith(")")
    t = t.strip("()")
    if re.fullmatch(r"-?\d{1,3}(\.\d{3})+(,\d+)?", t):
        t = t.replace(".", "").replace(",", ".")
    elif re.fullmatch(r"-?\d{1,3}(,\d{3})+(\.\d+)?", t):
        t = t.replace(",", "")
    elif re.fullmatch(r"-?\d+,\d+", t):
        t = t.replace(",", ".")
    try:
        x = float(t)
    except ValueError:
        return None
    return -x if am else x


def _ten_an_toan(s):
    s = re.sub(r"[^0-9A-Za-z._-]+", "_", bo_dau(s).upper() if not re.fullmatch(r"[0-9A-Za-z._-]+", str(s)) else str(s))
    return s.strip("_")[:80] or "HS"


def _thu_muc():
    d = ""
    try:
        d = CAU_HINH["thu_muc"]() or ""
    except Exception:
        d = ""
    if not d:
        m = ""
        try:
            m = CAU_HINH["mst"]() or ""
        except Exception:
            pass
        d = os.path.join(BASE_DIR, "hstk-" + (re.sub(r"[^0-9-]", "", m) or "CHUNG"))
    d = os.path.join(d, "ho-so-thue")
    os.makedirs(d, exist_ok=True)
    return d


# ---------------------------------------------------------------------------
#  kho du lieu (JSON, ghi nguyen tu)
# ---------------------------------------------------------------------------
def kho():
    duong = os.path.join(_thu_muc(), "du-lieu.json")
    if _KHO["du_lieu"] is not None and _KHO["duong"] == duong:
        return _KHO["du_lieu"]
    d = {"ho_so": {}, "tra_cuu": [], "mau_url": {}}
    try:
        with io.open(duong, "r", encoding="utf-8") as f:
            x = json.load(f)
        if isinstance(x, dict):
            d.update(x)
    except Exception:
        pass
    _KHO["du_lieu"], _KHO["duong"] = d, duong
    return d


def luu_kho():
    d = kho()
    duong = _KHO["duong"]
    tam = duong + ".tmp"
    with io.open(tam, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1)
    os.replace(tam, duong)


def quen_kho():
    _KHO["du_lieu"], _KHO["duong"] = None, ""


# ---------------------------------------------------------------------------
#  CHROME: dung chung Chrome cua man hinh tai hoa don neu dang mo, khong thi mo ho so cua MST
# ---------------------------------------------------------------------------
def _http_json(cong, duong, method="GET", timeout=5):
    req = urllib.request.Request("http://127.0.0.1:%d%s" % (cong, duong), method=method)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def _con_song(cong):
    if not cong:
        return False
    try:
        _http_json(cong, "/json/version", timeout=3)
        return True
    except Exception:
        return False


def _cong_tu_ho_so(ho_so):
    """Chrome ghi cong go loi vao <ho so>\\DevToolsActivePort - dung lai Chrome tool da mo tu lan truoc."""
    try:
        with io.open(os.path.join(ho_so, "DevToolsActivePort"), "r") as f:
            return int((f.readline() or "0").strip() or 0)
    except Exception:
        return 0


def _mo_chrome_moi():
    chrome = CAU_HINH["tim_chrome"]() or ""
    if not chrome:
        return 0, "Không tìm thấy Google Chrome trên máy."
    ho_so = CAU_HINH["ho_so_chrome"]()
    os.makedirs(ho_so, exist_ok=True)
    c = _cong_tu_ho_so(ho_so)
    if _con_song(c):
        return c, ""
    s = __import__("socket").socket()
    s.bind(("127.0.0.1", 0))
    cong = s.getsockname()[1]
    s.close()
    lenh = [chrome, "--remote-debugging-port=%d" % cong, "--user-data-dir=" + ho_so, "--no-first-run",
            "--no-default-browser-check", "--disable-sync", "--window-size=1280,920", "--new-window"]
    if CAU_HINH.get("headless"):
        lenh += ["--headless=new", "--disable-gpu", "--no-sandbox"]
    lenh.append(CAU_HINH.get("trang_vao") or TRANG_TCHS)
    try:
        TT["tien_trinh"] = subprocess.Popen(lenh, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception as e:
        return 0, "Không mở được Chrome: %s" % str(e)[:200]
    t0 = time.time()
    while time.time() - t0 < 40:
        if _con_song(cong):
            return cong, ""
        c = _cong_tu_ho_so(ho_so)
        if c and _con_song(c):
            return c, ""
        time.sleep(0.5)
    return 0, ("Chrome không mở cổng điều khiển. Có thể cửa sổ Chrome của tool (hồ sơ của MST này) đang mở từ lần "
               "trước mà không còn liên lạc được: đóng hết các cửa sổ đó rồi bấm lại.")


def _cac_tab(cong):
    try:
        return [t for t in _http_json(cong, "/json/list") if t.get("type") == "page"]
    except Exception:
        return []


def _tab_dvc(cong):
    goc = (CAU_HINH.get("trang_vao") or TRANG_TCHS).split("/tthc")[0]
    for t in _cac_tab(cong):
        u = t.get("url") or ""
        if u == goc or u.startswith(goc + "/"):
            return t
    return None


def _tab_moi(cong, url):
    q = "/json/new?" + urllib.parse.quote(url, safe=":/?=&")
    for m in ("PUT", "GET"):
        try:
            return _http_json(cong, q, method=m)
        except Exception:
            continue
    return None


def mo_chrome():
    """Chay nen. Ket qua o TT['trang_thai'] = da_mo / loi."""
    if KenhCDP is None:
        TT["trang_thai"], TT["loi"] = "loi", "Thiếu tool_dvc_unesco.py trong thư mục AIHoaDon."
        return
    TT["trang_thai"], TT["loi"] = "dang_mo", ""
    try:
        cong = TT["cong"] if _con_song(TT["cong"]) else 0
        if not cong:
            cong, loi = _mo_chrome_moi()
            if not cong:
                TT["trang_thai"], TT["loi"] = "loi", loi
                return
        TT["cong"] = cong
        tab = None
        t0 = time.time()
        while tab is None and time.time() - t0 < 10:
            tab = _tab_dvc(cong)
            if tab is None:
                time.sleep(0.5)
        if tab is None:
            tab = _tab_moi(cong, CAU_HINH.get("trang_vao") or TRANG_TCHS)
        if not tab or not tab.get("webSocketDebuggerUrl"):
            TT["trang_thai"], TT["loi"] = "loi", "Không mở được thẻ Cổng dịch vụ công trong Chrome."
            return
        cu = TT.get("kenh")
        TT["kenh"] = KenhCDP(tab["webSocketDebuggerUrl"])
        if cu is not None:
            try:
                cu.dong()           # bam Mo lai: bo ket noi cu, khong de ro ri
            except Exception:
                pass
        for lenh in ("Page.enable", "Runtime.enable"):
            try:
                TT["kenh"].goi(lenh)
            except Exception:
                pass
        try:
            TT["kenh"].goi("Page.bringToFront")
        except Exception:
            pass
        TT["trang_thai"] = "da_mo"
        _ghi("Da noi the Cong DVC (cong go loi %d)" % cong)
    except Exception as e:
        TT["trang_thai"], TT["loi"] = "loi", "Lỗi khi mở Chrome: %s" % str(e)[:200]
        _ghi("LOI mo Chrome: %s" % e)


def _kenh():
    k = TT.get("kenh")
    if k is not None and not getattr(k, "loi_ket_noi", None):
        return k
    if not TT["cong"]:
        raise IOError("Chưa mở Cổng dịch vụ công.")
    tab = _tab_dvc(TT["cong"])
    if not tab:
        raise IOError("Không thấy thẻ Cổng dịch vụ công trong Chrome (đã bị đóng?). Bấm Mở Cổng DVC lại.")
    TT["kenh"] = KenhCDP(tab["webSocketDebuggerUrl"])
    for lenh in ("Page.enable", "Runtime.enable"):
        try:
            TT["kenh"].goi(lenh)
        except Exception:
            pass
    return TT["kenh"]


_JS_CAU_TRUC = r"""
(() => {
  const c = document.documentElement.cloneNode(true);
  c.querySelectorAll('script,style,link,noscript,svg,canvas,iframe,object,embed').forEach(e => e.remove());
  c.querySelectorAll('img').forEach(e => { e.removeAttribute('src'); e.removeAttribute('srcset'); });
  c.querySelectorAll('input,textarea,select').forEach(e => {
    e.removeAttribute('value');
    if (e.tagName === 'TEXTAREA') e.textContent = '';
  });
  // Chi ghi gia tri o CHI DOC (readonly / disabled - vd trang chi tiet ho so) vao data-gt de biet o nao chua gi.
  // O nguoi dung go (ten dang nhap, mat khau, ma xac nhan, ngay tra cuu) KHONG ghi.
  const goc = document.querySelectorAll('input,textarea,select'), ban = c.querySelectorAll('input,textarea,select');
  for (let i = 0; i < goc.length && i < ban.length; i++) {
    const t = (goc[i].type || '').toLowerCase(), ten = ((goc[i].name || '') + ' ' + (goc[i].id || '') + ' ' + (goc[i].placeholder || '')).toLowerCase();
    if (t === 'password' || t === 'hidden' || /captcha|xac.?nhan|ma.?xn|otp|pass|mat.?khau/.test(ten)) continue;
    if (!(goc[i].readOnly || goc[i].disabled)) continue;
    if (goc[i].value) ban[i].setAttribute('data-gt', String(goc[i].value).slice(0, 80));
  }
  return {url: location.href, html: c.outerHTML};
})()
"""


def luu_cau_truc(ly_do="nguoi-dung"):
    """Ghi ban sao trang Chrome dang mo (khong script, khong mat khau / ma xac nhan / anh captcha) vao
       ho-so-thue\\chan-doan\\ de gui ho tro khi Cong khac video. Tra ve duong tep ("" neu khong ghi duoc)."""
    try:
        r = _js(_JS_CAU_TRUC) or {}
    except Exception as e:
        _ghi("Khong lay duoc cau truc trang: %s" % e)
        return ""
    thu = os.path.join(_thu_muc(), "chan-doan")
    os.makedirs(thu, exist_ok=True)
    duong = os.path.join(thu, "trang_%s_%s.html" % (datetime.now().strftime("%Y%m%d_%H%M%S"), _ten_an_toan(ly_do)[:30]))
    with io.open(duong, "w", encoding="utf-8") as f:
        f.write("<!-- UNESCO GD54 - cau truc trang de ho tro. Dia chi: %s -->\n" % str(r.get("url", "")).replace("--", "- -"))
        # GD63: che so 9-16 chu so (CCCD, so tai khoan) chi giu 4 so cuoi - tru MST 10 so - truoc khi ghi tep gui ho tro
        html = re.sub(r"(?<!\d)(\d{9,16})(?!\d)", lambda m: m.group(1) if len(m.group(1)) == 10 else
                      ("*" * (len(m.group(1)) - 4) + m.group(1)[-4:]), r.get("html") or "")
        f.write('<meta charset="utf-8">\n' + html)
    _ghi("Luu cau truc trang: " + duong)
    return duong


def _js(bieu_thuc, cho_promise=False):
    return _kenh().chay_js(bieu_thuc, cho_promise=cho_promise)


# ---------------------------------------------------------------------------
#  JAVASCRIPT CHAY TRONG TRANG (chi DOC + bam link xem / tai xuong; khong dong vao o captcha / mat khau)
# ---------------------------------------------------------------------------
_JS_CHUNG = r"""
const bo = s => (s||'').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'').replace(/đ/g,'d').replace(/\s+/g,' ').trim();
const hien = e => { if (!e) return false; const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
const NHAN_BIET = new Set(%s);
const docO = (x) => {
  if (!x) return '';
  if (/^(INPUT|TEXTAREA|SELECT)$/.test(x.tagName)) { if ((x.type||'').toLowerCase() === 'password') return ''; return (x.value||'').trim(); }
  const i = x.querySelector && x.querySelector('input:not([type=password]),textarea,select');
  if (i) return (i.value||'').trim();
  return (x.innerText||'').replace(/\s+/g,' ').trim();
};
const laNhan = v => { const b = bo(v).replace(/:$/,''); return NHAN_BIET.has(b); };
const giaTri = (e) => {
  let s = e.nextElementSibling;
  for (let k = 0; s && k < 3; k++, s = s.nextElementSibling) { const v = docO(s); if (v && !laNhan(v)) return v; if (v) return ''; }
  let p = e.parentElement;
  for (let up = 0; p && up < 3; up++, p = p.parentElement) {
    const i = p.querySelector('input:not([type=password]),textarea,select');
    if (i && i !== e && p.contains(e)) { const v = (i.value||'').trim(); if (v) return v; }
    let q = p.nextElementSibling;
    for (let k = 0; q && k < 2; k++, q = q.nextElementSibling) {
      const v = docO(q); if (!v) continue; if (laNhan(v) || v.length > 600) return ''; return v;
    }
  }
  return '';
};
const timNhan = (nhan) => {
  const t = bo(nhan); let tot = null;
  for (const e of document.querySelectorAll('label,span,div,td,th,p,b,strong,dt,h5,h6,a')) {
    if (e.children.length > 2) continue;
    const tx = bo(e.innerText || e.textContent).replace(/:$/,'');
    if (tx === t && hien(e)) { if (!tot || tot.contains(e)) tot = e; }
  }
  return tot;
};
"""

_NHAN_CT = [("tthc", "Thủ tục hành chính"), ("to_khai", "Tờ khai"), ("ky", "Kỳ tính thuế"), ("loai_tk", "Loại tờ khai"),
            ("lan_nop", "Lần nộp"), ("lan_bs", "Lần bổ sung"), ("nghiep_vu", "Nghiệp vụ"),
            ("ten_nnt", "Tên người nộp thuế"), ("mst", "Mã số thuế"), ("ma_hs", "Mã hồ sơ"),
            ("don_vi", "Đơn vị tiếp nhận"), ("trang_thai", "Trạng thái hiện tại"), ("ngay_nop", "Ngày nộp"),
            ("ngay_tiep_nhan", "Ngày tiếp nhận"), ("noi_nop", "Nơi nộp tờ khai"), ("ma_gd", "Mã giao dịch")]
_TAT_CA_NHAN = [bo_dau(x[1]) for x in _NHAN_CT] + ["tu ngay", "den ngay", "ma xac nhan", "danh sach tai lieu dinh kem",
                                                  "danh sach thong bao", "xem tai lieu", "xem thong bao", "tai xuong"]


def _js_voi(than):
    return "(() => {" + (_JS_CHUNG % json.dumps(_TAT_CA_NHAN)) + than + "})()"


_JS_TRANG = _js_voi(r"""
  const out = {url: location.href, bang: '', phan_trang: '', tu: '', den: '', tab: '', chi_tiet: /\/detail\//i.test(location.pathname),
               dang_nhap: !/\/login/i.test(location.pathname)};
  for (const e of document.querySelectorAll('input[type=password]')) if (hien(e)) { out.dang_nhap = false; break; }
  // Bang ket qua: <table> thuong hoac bang dung the div (role=table / mat-table). Doc chu tung o + link cua o.
  const chu = c => (c.innerText || c.textContent || '').replace(/\s+/g, ' ').trim();
  const link = c => {
    const a = c.querySelector && c.querySelector('a[href]'); let h = a ? (a.getAttribute('href') || '') : '';
    if (!h || /^(#|javascript)/i.test(h)) return '';
    try { return new URL(h, location.href).href; } catch (e) { return ''; }
  };
  const ungVien = Array.from(document.querySelectorAll('table,[role=table],[role=grid],mat-table,.mat-table,.mat-mdc-table'));
  for (const t of ungVien) {
    if (!hien(t)) continue;
    let hang, oCua;
    if (t.tagName === 'TABLE') { hang = Array.from(t.rows); oCua = r => Array.from(r.cells); }
    else {
      hang = Array.from(t.querySelectorAll('[role=row],mat-row,mat-header-row,.mat-row,.mat-header-row,.mat-mdc-row,.mat-mdc-header-row'));
      oCua = r => Array.from(r.querySelectorAll('[role=cell],[role=columnheader],[role=gridcell],mat-cell,mat-header-cell,.mat-cell,.mat-header-cell,.mat-mdc-cell,.mat-mdc-header-cell'));
    }
    if (hang.length < 2) continue;
    let iDau = hang.findIndex(r => oCua(r).some(c => c.tagName === 'TH' || c.getAttribute('role') === 'columnheader' || /header/i.test(c.tagName + ' ' + c.className)));
    if (iDau < 0) iDau = 0;
    const dau = oCua(hang[iDau]).map(chu);
    const b = bo(dau.join('|'));
    if (b.indexOf('ma ho so') < 0 && b.indexOf('ma giao dich') < 0) continue;
    const dong = [];
    for (let i = iDau + 1; i < hang.length && dong.length < 2000; i++) {
      const o = oCua(hang[i]);
      if (o.length < 2) continue;
      dong.push(o.map(c => ({t: chu(c).slice(0, 400), h: link(c)})));
    }
    out.bang = {dau: dau, dong: dong};
    out.ky_hieu = JSON.stringify(out.bang).length + '|' + dong.map(r => r.map(c => c.t).join('~')).join('#').slice(0, 20000);
    break;
  }
  const m = (document.body.innerText || '').match(/Trang\s*\d+\s*\/\s*\d+[^\n]{0,60}/i);
  if (m) out.phan_trang = m[0];
  for (const [k, nh] of [['tu','Từ ngày'],['den','Đến ngày']]) { const e = timNhan(nh); if (e) out[k] = giaTri(e); }
  for (const e of document.querySelectorAll('.active,[aria-selected=true],.selected,.current')) {
    const tx = bo(e.innerText); if (tx.indexOf('tra cuu ho so da nop') >= 0 && tx.length < 90) { out.tab = tx; break; }
  }
  return out;
""")

_JS_CHI_TIET = _js_voi(r"""
  const NHAN = %s;
  const out = {url: location.href, dang_nhap: !/\/login/i.test(location.pathname)};
  for (const e of document.querySelectorAll('input[type=password]')) if (hien(e)) { out.dang_nhap = false; break; }
  for (const [k, nh] of NHAN) { const e = timNhan(nh); if (e) out[k] = giaTri(e).slice(0, 400); }
  const h = timNhan('Tiến trình tiếp nhận và xử lý hồ sơ');
  if (h && h.parentElement) out.tien_trinh = (h.parentElement.innerText || '').replace(/\s+\n/g, '\n').slice(0, 3000);
  return out;
""" % json.dumps(_NHAN_CT))

_JS_DANH_DAU_CU = _js_voi(r"""
  let n = 0;
  for (const e of document.querySelectorAll('a,button,span')) {
    const t = bo(e.innerText || e.textContent);
    if (t && t.length <= 25 && t.indexOf('tai xuong') >= 0) { e.setAttribute('data-hstk-cu', '1'); n++; }
  }
  return n;
""")

# MODE: 'trang' = link Tai xuong tren trang (ngoai hop), 'moi' = link moi hien sau khi mo hop
_JS_LINK = r"""
  const DLG = '[role=dialog],.modal,.modal-dialog,.modal-content,.ant-modal,.mat-dialog-container,.p-dialog,.cdk-overlay-pane,.el-dialog,.v-dialog';
  for (const e of document.querySelectorAll('[data-hstk-i]')) e.removeAttribute('data-hstk-i');
  const ds = [];
  for (const e of document.querySelectorAll('a,button,span')) {
    const t = bo(e.innerText || e.textContent);
    if (!t || t.length > 25 || t.indexOf('tai xuong') < 0 || !hien(e)) continue;
    if (e.querySelector('a,button')) continue;
    if (e.parentElement && e.parentElement.closest('a,button') && e.tagName === 'SPAN') continue;
    const cu = e.getAttribute('data-hstk-cu') === '1';
    if (MODE === 'moi' && cu) continue;
    if (MODE === 'trang' && e.closest(DLG)) continue;
    let p = e.parentElement, nhan = '';
    for (let k = 0; p && k < 5; k++, p = p.parentElement) {
      const bot = (p.innerText || '').replace(/\s+/g, ' ').replace(/\S?\s*Tải xuống/gi, '').trim();
      if (bot.length >= 6) { nhan = bot.slice(0, 220); break; }
    }
    const i = ds.length;
    e.setAttribute('data-hstk-i', MODE + i);
    let href = e.getAttribute('href') || '';
    if (href && !/^(#|javascript)/i.test(href)) href = new URL(href, location.href).href; else href = '';
    ds.push({i: i, nhan: nhan, href: href});
  }
  return ds;
"""


def _js_link(mode):
    return _js_voi(("const MODE = %s;" % json.dumps(mode)) + _JS_LINK)


# Danh dau MOI nut co chu dung bang `can` (vd. nhieu nut "Xem thong bao" - moi buoc xu ly mot nut), tra ve so nut.
_JS_DANH_DAU_NUT = _js_voi(r"""
  const can = bo(%s);
  for (const e of document.querySelectorAll('[data-hstk-nut]')) e.removeAttribute('data-hstk-nut');
  const ds = [];
  for (const e of document.querySelectorAll('a,button,span,div')) {
    const t = bo(e.innerText || e.textContent);
    if (t !== can || !hien(e)) continue;
    // chi lay phan tu trong cung (the span ben trong button thi lay button - phan tu bam duoc)
    let trong = false;
    for (const c of e.querySelectorAll('a,button,span,div')) if (bo(c.innerText || c.textContent) === can) { trong = true; break; }
    if (trong && !/^(A|BUTTON)$/.test(e.tagName)) continue;
    if (e.parentElement && e.parentElement.closest('a,button') && bo(e.parentElement.closest('a,button').innerText) === can) continue;
    ds.push(e);
  }
  ds.forEach((e, i) => e.setAttribute('data-hstk-nut', String(i)));
  return ds.length;
""")

_JS_BAM_NUT = _js_voi(r"""
  const e = document.querySelector('[data-hstk-nut="' + %s + '"]');
  if (!e) return 'khong_thay';
  e.click(); return 'da_bam';
""")

_JS_BAM_I = _js_voi(r"""
  const e = document.querySelector('[data-hstk-i=%s]');
  if (!e) return 'khong_thay';
  e.click(); return 'da_bam';
""")

_JS_DONG_HOP = _js_voi(r"""
  const DLG = '[role=dialog],.modal,.modal-dialog,.modal-content,.ant-modal,.mat-dialog-container,.p-dialog,.cdk-overlay-pane,.el-dialog,.v-dialog';
  const mau = document.querySelector('[data-hstk-i^=moi]');
  let goc = mau && mau.closest(DLG);
  if (!goc) { const ds = Array.from(document.querySelectorAll(DLG)).filter(hien); goc = ds.length ? ds[ds.length - 1] : null; }
  if (!goc) return 'khong';
  for (const e of goc.querySelectorAll('button,a,span')) {
    const t = bo(e.innerText || e.textContent);
    if (t && t.length <= 12 && /(^|[^a-z])dong$/.test(t) && hien(e)) { e.click(); return 'dong'; }
  }
  const x = goc.querySelector('.close,.btn-close,[aria-label=Close],[aria-label="Đóng"]');
  if (x && hien(x)) { x.click(); return 'x'; }
  return 'khong';
""")

_JS_FETCH = r"""
(async () => {
  try {
    const r = await fetch(%s, {credentials: 'include'});
    const u = new Uint8Array(await r.arrayBuffer());
    let s = ''; const CH = 0x8000;
    for (let i = 0; i < u.length; i += CH) s += String.fromCharCode.apply(null, u.subarray(i, i + CH));
    return JSON.stringify({s: r.status, t: r.headers.get('content-type') || '', cd: r.headers.get('content-disposition') || '', d: btoa(s)});
  } catch (e) { return JSON.stringify({s: 0, e: String(e)}); }
})()
"""


# ---------------------------------------------------------------------------
#  NHAN KET QUA TRA CUU (nguoi dung tu tra; tool doc bang tren trang)
# ---------------------------------------------------------------------------
def _cot(r, *ten):
    """Lay o theo ten cot (khong dau). Uu tien: trung khop han -> bat dau bang -> chua trong.
       Ten ket thuc bang '=' chi nhan trung khop han (vd 'ky=' khong bat nham cot 'Ngay ky')."""
    cot = [(bo_dau(k), v) for k, v in r.items() if not k.startswith("_")]
    for cach in (0, 1, 2):
        for t in ten:
            han = t.endswith("=")
            t = t.rstrip("=")
            if han and cach:
                continue
            for kb, v in cot:
                if (cach == 0 and kb == t) or (cach == 1 and kb.startswith(t)) or (cach == 2 and t in kb):
                    return (v or "").strip()
    return ""


def _ngay_iso(s):
    s = str(s or "")
    m = re.search(r"(\d{1,2})/(\d{1,2})/(\d{4})", s)
    if m:
        try:
            return date(int(m.group(3)), int(m.group(2)), int(m.group(1))).isoformat()
        except ValueError:
            return ""
    m = re.search(r"(\d{4})-(\d{2})-(\d{2})", s)
    return m.group(0) if m else ""


def bang_thanh_dong(bang):
    """{dau: [tieu de cot], dong: [[{t: chu, h: link}]]} (doc trong trang) -> [dict tieu_de -> chu, '_link': {tieu_de: link}]."""
    ra = []
    dau = [str(x or "") for x in (bang or {}).get("dau") or []]
    for o in (bang or {}).get("dong") or []:
        r, lk = {}, {}
        for j, c in enumerate(o):
            ten = dau[j] if j < len(dau) and dau[j] else "cot%d" % (j + 1)
            if ten in r:
                ten = "%s_%d" % (ten, j)
            r[ten] = str((c or {}).get("t") or "")
            if (c or {}).get("h"):
                lk[ten] = c["h"]
        r["_link"] = lk
        ra.append(r)
    return ra


def gop_ket_qua(bang, url_trang="", tu="", den="", tab=""):
    """Doc bang ket qua tra cuu -> cap nhat kho. Tra ve (so dong doc duoc, so ho so moi)."""
    rows = bang_thanh_dong(bang)
    d = kho()
    n_moi, n_doc = 0, 0
    nguon_tab = "TDT" if "thue dien tu" in bo_dau(tab) else ""
    for r in rows:
        ma = _cot(r, "ma ho so")
        nguon = nguon_tab or "DVC"
        if not ma:
            ma = _cot(r, "ma giao dich")
            if ma:
                nguon = "TDT"
        ma = re.sub(r"\s+", "", ma)
        if len(ma) < 5:
            continue
        n_doc += 1
        rec = d["ho_so"].get(ma)
        if rec is None:
            rec = {"ma_hs": ma, "nguon": nguon, "thu_luc": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
            d["ho_so"][ma] = rec
            n_moi += 1
        gt = {"tthc": _cot(r, "ten tthc", "thu tuc"), "to_khai": _cot(r, "to khai"), "ky": _cot(r, "ky tinh thue", "ky ke khai", "ky thue", "ky="),
              "ngay_nop": _cot(r, "ngay nop", "ngay gui"), "trang_thai": _cot(r, "trang thai"),
              "lan_nop": _cot(r, "lan nop"), "loai_tk": _cot(r, "loai to khai")}
        for k, v in gt.items():
            if v:
                rec[k] = v
        for h in (r.get("_link") or {}).values():
            if h and "detail" in h.lower():
                rec["url_ct"] = urllib.parse.urljoin(url_trang or TRANG_TCHS, h)
    if n_doc:
        tc = {"tu": _ngay_iso(tu), "den": _ngay_iso(den), "nguon": nguon_tab or "DVC"}
        if tc["tu"] and tc["den"] and tc not in [{k: x.get(k) for k in ("tu", "den", "nguon")} for x in d["tra_cuu"]]:
            tc["luc"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            d["tra_cuu"].append(tc)
        luu_kho()
    return n_doc, n_moi


def hoc_mau_url(url):
    """Nguoi dung tu mo chi tiet mot ho so -> nho mau duong (thay ma ho so bang {MA})."""
    m = re.search(r"/detail/([^/?#]+)", url or "")
    if not m:
        return False
    ma = urllib.parse.unquote(m.group(1))
    d = kho()
    nguon = "TDT" if "loai=" in url and re.search(r"loai=[^&#]+", url) else "DVC"
    mau = url.split("#")[0].replace(m.group(1), "{MA}")
    if d["mau_url"].get(nguon) != mau:
        d["mau_url"][nguon] = mau
        if ma in d["ho_so"] and not d["ho_so"][ma].get("url_ct"):
            d["ho_so"][ma]["url_ct"] = url.split("#")[0]
        luu_kho()
    return True


def _vong_nghe(the_he, gioi_han=45 * 60):
    t0 = time.time()
    lan_ky_hieu = ""
    tong_moi = 0
    TT["bao"] = "Đang chờ kết quả tra cứu trên Chrome..."
    while TT["nghe"] and TT["the_he"] == the_he and time.time() - t0 < gioi_han:
        try:
            r = _js(_JS_TRANG) or {}
        except Exception as e:
            TT["bao"] = "Mất liên lạc với thẻ Cổng DVC: %s" % str(e)[:120]
            time.sleep(2)
            try:
                TT["kenh"] = None
                _kenh()
            except Exception:
                pass
            continue
        if r.get("chi_tiet"):
            hoc_mau_url(r.get("url"))
        if not r.get("dang_nhap"):
            TT["bao"] = "Chờ anh/chị đăng nhập trên Chrome (tên đăng nhập MST-ql, mật khẩu, mã captcha)."
        elif r.get("bang") and r.get("ky_hieu") != lan_ky_hieu:
            lan_ky_hieu = r.get("ky_hieu")
            with KHOA:
                n_doc, n_moi = gop_ket_qua(r["bang"], r.get("url"), r.get("tu"), r.get("den"), r.get("tab"))
            tong_moi += n_moi
            TT["bao"] = ("Đã đọc %d hồ sơ trên trang (%d mới; tổng %d). %s"
                         % (n_doc, n_moi, len(kho()["ho_so"]), r.get("phan_trang") or ""))
            _ghi("Doc bang ket qua: %d dong, %d moi" % (n_doc, n_moi))
        elif not r.get("bang"):
            TT["bao"] = ("Đã đăng nhập. Trên Chrome: TRA CỨU HỒ SƠ -> chọn Từ ngày / Đến ngày -> gõ Mã xác nhận -> "
                         "Tìm kiếm. Tool tự đọc bảng kết quả (tổng %d hồ sơ)." % len(kho()["ho_so"]))
        time.sleep(1.5)
    if TT["the_he"] != the_he:
        return
    TT["nghe"] = False
    TT["bao"] = "Đã dừng nhận kết quả (%d hồ sơ mới trong lần này)." % tong_moi


def bat_nghe(bat=True):
    if not bat:
        TT["nghe"] = False
        TT["the_he"] += 1
        TT["bao"] = "Đã dừng nhận kết quả."
        return True, ""
    if TT["trang_thai"] != "da_mo":
        return False, "Bấm Mở Cổng DVC trước."
    if TT["viec"].get("dang_chay"):
        return False, "Đang lấy chi tiết hồ sơ, đợi xong rồi bấm lại."
    if TT["nghe"] and TT["luong_nghe"] and TT["luong_nghe"].is_alive():
        return True, ""
    TT["nghe"] = True
    TT["the_he"] += 1
    TT["luong_nghe"] = threading.Thread(target=_vong_nghe, args=(TT["the_he"],), daemon=True)
    TT["luong_nghe"].start()
    return True, ""


# ---------------------------------------------------------------------------
#  CHI TIET + TAI THONG BAO / TAI LIEU
# ---------------------------------------------------------------------------
def _dat_thu_muc_tai(thu):
    os.makedirs(thu, exist_ok=True)
    try:
        if TT.get("kenh_b") is None or getattr(TT["kenh_b"], "loi_ket_noi", None):
            v = _http_json(TT["cong"], "/json/version")
            TT["kenh_b"] = KenhCDP(v["webSocketDebuggerUrl"])
        TT["kenh_b"].goi("Browser.setDownloadBehavior", {"behavior": "allow", "downloadPath": os.path.abspath(thu),
                                                          "eventsEnabled": False})
        return True
    except Exception:
        pass
    try:
        _kenh().goi("Page.setDownloadBehavior", {"behavior": "allow", "downloadPath": os.path.abspath(thu)})
        return True
    except Exception as e:
        _ghi("Khong dat duoc thu muc tai: %s" % e)
        return False


def _cho_tep(thu, truoc, gioi_han=40, cho_bat_dau=15):
    """Cho tep tai xong. Qua `cho_bat_dau` giay ma chua co gi bat dau tai -> bo (link khong tai tep)."""
    t0 = time.time()
    kich = {}
    while time.time() - t0 < gioi_han:
        if time.time() - t0 > cho_bat_dau and not [f for f in os.listdir(thu) if f not in truoc]:
            return ""
        moi = [f for f in os.listdir(thu) if f not in truoc and not f.endswith((".crdownload", ".tmp", ".part"))]
        dang = [f for f in os.listdir(thu) if f.endswith(".crdownload")]
        if moi and not dang:
            f = moi[0]
            try:
                s = os.path.getsize(os.path.join(thu, f))
            except OSError:
                s = -1
            if kich.get(f) == s and s >= 0:
                return f
            kich[f] = s
        time.sleep(0.5)
    return ""


def _luu_tep(thu_ho_so, loai, stt, ten_goc, du_lieu=None, nguon=None):
    ten = re.sub(r'[\\/:*?"<>|]+', "_", ten_goc or "tep")[-80:] or "tep"
    dich = os.path.join(thu_ho_so, "%s_%02d_%s" % (loai, stt, ten))
    k = 2
    while os.path.exists(dich):
        g, du = os.path.splitext(dich)
        dich = "%s_%d%s" % (g, k, du)
        k += 1
    if du_lieu is not None:
        with open(dich, "wb") as f:
            f.write(du_lieu)
    else:
        shutil.move(nguon, dich)
    return dich


def _tai_bang_fetch(href):
    import base64
    kq = json.loads(_js(_JS_FETCH % json.dumps(href), cho_promise=True) or "{}")
    if kq.get("s") != 200:
        return None, ""
    ten = ""
    m = re.search(r"filename\*?=(?:UTF-8'')?\"?([^\";]+)", kq.get("cd") or "", re.I)
    if m:
        ten = urllib.parse.unquote(m.group(1))
    if not ten:
        ten = os.path.basename(urllib.parse.urlparse(href).path) or "tep"
    return base64.b64decode(kq.get("d") or ""), ten


def _tai_cac_link(thu_ho_so, loai, mo_bang_chu=None):
    """Tai het link 'Tai xuong' tren trang (mo_bang_chu=None), hoac: bam LAN LUOT tung nut mo_bang_chu
       (vd. moi buoc xu ly co mot nut "Xem thong bao") -> hop hien ra -> tai het link moi -> dong hop."""
    if not mo_bang_chu:
        return _tai_mot_lan(thu_ho_so, loai, None, [])
    ra = []
    n = _js(_JS_DANH_DAU_NUT % json.dumps(mo_bang_chu)) or 0
    for i in range(min(int(n), 30)):
        if TT["dung"]:
            break
        if i:
            _js(_JS_DANH_DAU_NUT % json.dumps(mo_bang_chu))     # trang co the ve lai sau khi dong hop
        _tai_mot_lan(thu_ho_so, loai, i, ra)
    return ra


def _tai_mot_lan(thu_ho_so, loai, so_nut, ra):
    mo_bang_chu = so_nut is not None
    _js(_JS_DANH_DAU_CU)
    if mo_bang_chu:
        if _js(_JS_BAM_NUT % json.dumps(str(so_nut))) != "da_bam":
            return ra
        ds = []
        t0 = time.time()
        while time.time() - t0 < 8:
            time.sleep(0.6)
            ds = _js(_js_link("moi")) or []
            if ds:
                break
    else:
        ds = _js(_js_link("trang")) or []
    tam = os.path.join(thu_ho_so, "_dang_tai")
    for x in ds:
        if TT["dung"]:
            break
        tep = ""
        try:
            if x.get("href"):
                b, ten = _tai_bang_fetch(x["href"])
                if b:
                    tep = _luu_tep(thu_ho_so, loai, len(ra) + 1, ten, du_lieu=b)
            if not tep:
                shutil.rmtree(tam, ignore_errors=True)
                os.makedirs(tam, exist_ok=True)
                _dat_thu_muc_tai(tam)
                tab_truoc = {t.get("id") for t in _cac_tab(TT["cong"])}
                _js(_JS_BAM_I % json.dumps(("moi" if mo_bang_chu else "trang") + str(x["i"])))
                f = _cho_tep(tam, set(), 40)
                if f:
                    tep = _luu_tep(thu_ho_so, loai, len(ra) + 1, f, nguon=os.path.join(tam, f))
                else:
                    # tep mo ra o the moi (vd. PDF) -> lay lai bang fetch trong the Cong DVC roi dong the do
                    for t in _cac_tab(TT["cong"]):
                        if t.get("id") not in tab_truoc and (t.get("url") or "").startswith("http"):
                            b, ten = _tai_bang_fetch(t["url"])
                            try:
                                _http_json(TT["cong"], "/json/close/" + t["id"])
                            except Exception:
                                pass
                            if b:
                                tep = _luu_tep(thu_ho_so, loai, len(ra) + 1, ten, du_lieu=b)
                            break
        except Exception as e:
            _ghi("Loi tai '%s': %s" % (x.get("nhan", "")[:60], e))
        ra.append({"loai": loai, "nhan": x.get("nhan", ""), "tep": tep})
    shutil.rmtree(tam, ignore_errors=True)
    if mo_bang_chu:
        r = _js(_JS_DONG_HOP)
        if r == "khong":
            try:
                for kieu in ("keyDown", "keyUp"):
                    _kenh().goi("Input.dispatchKeyEvent", {"type": kieu, "key": "Escape", "code": "Escape",
                                                           "windowsVirtualKeyCode": 27})
            except Exception:
                pass
        time.sleep(0.5)
    return ra


def _url_chi_tiet(rec):
    if rec.get("url_ct"):
        return rec["url_ct"]
    mau = kho()["mau_url"].get(rec.get("nguon") or "DVC")
    if not mau and (rec.get("nguon") or "DVC") == "DVC":
        mau = MAU_CT_MAC_DINH
    if not mau:
        return ""
    return mau.replace("{MA}", urllib.parse.quote(rec["ma_hs"], safe=""))


class PhienHetHan(Exception):
    """Cong DVC dua ve trang dang nhap: dung ca lan lay chi tiet, nguoi dung dang nhap lai roi bam tiep."""


def _mot_ho_so(ma):
    d = kho()
    rec = d["ho_so"][ma]
    url = _url_chi_tiet(rec)
    if not url:
        raise ValueError("Chưa biết đường mở chi tiết (hồ sơ nộp trên thuế điện tử): khi đang nhận kết quả, "
                         "anh/chị mở chi tiết một hồ sơ loại này bằng tay để tool học đường.")
    _kenh().goi("Page.navigate", {"url": url})
    ct, t0 = {}, time.time()
    while time.time() - t0 < 30:
        time.sleep(1.0)
        try:
            ct = _js(_JS_CHI_TIET) or {}
        except Exception:
            ct = {}
        if ct.get("ma_hs") or ct.get("trang_thai") or ct.get("to_khai"):
            time.sleep(0.8)
            ct = _js(_JS_CHI_TIET) or ct
            break
        if ct and ct.get("dang_nhap") is False and time.time() - t0 > 3:
            raise PhienHetHan("Cổng dịch vụ công đã về trang đăng nhập (phiên hết hạn).")
    if not (ct.get("ma_hs") or ct.get("trang_thai")):
        if ct.get("dang_nhap") is False:
            raise PhienHetHan("Cổng dịch vụ công đã về trang đăng nhập (phiên hết hạn).")
        tep = luu_cau_truc("chi-tiet-khong-doc-duoc") if not TT.get("da_chan_doan") else ""
        TT["da_chan_doan"] = True
        raise ValueError("Trang chi tiết không hiện thông tin hồ sơ" + (" (đã lưu cấu trúc trang: %s)" % os.path.basename(tep) if tep else ""))
    for k, _ in _NHAN_CT:
        if ct.get(k):
            rec[k] = ct[k]
    rec["ma_hs"] = ma
    if ct.get("tien_trinh"):
        rec["tien_trinh"] = ct["tien_trinh"]
    rec["url_ct"] = rec.get("url_ct") or url
    thu = os.path.join(_thu_muc(), "tep", _ten_an_toan(ma))
    os.makedirs(thu, exist_ok=True)
    tep = []
    tep += _tai_cac_link(thu, "ho_so")
    tep += _tai_cac_link(thu, "thong_bao", "Xem thông báo")
    tep += _tai_cac_link(thu, "tai_lieu", "Xem tài liệu")
    rec["tep"] = tep
    rec["thong_bao"] = []
    rec.pop("chi_tieu", None)
    for x in tep:
        if not x.get("tep"):
            continue
        for kq in doc_tep(x["tep"]):
            if kq.get("loai") == "to_khai":
                rec["to_khai_xml"] = {k: v for k, v in kq.items() if k != "chi_tieu"}
                rec["chi_tieu"] = kq.get("chi_tieu") or {}
                rec["tep_to_khai"] = x["tep"]
            elif kq.get("loai") == "thong_bao":
                tb = dict(kq)
                tb["tep"] = x["tep"]
                tb["nhan"] = x.get("nhan", "")
                dau = (tb.get("ten"), tb.get("so"), tb.get("ngay"), tb.get("ma_gd"))
                if any(dau != ("", "", "", "") and (t.get("ten"), t.get("so"), t.get("ngay"), t.get("ma_gd")) == dau
                       for t in rec["thong_bao"]):
                    continue           # cung mot thong bao tai 2 lan (vd. tren trang va trong hop)
                rec["thong_bao"].append(tb)
        if x["loai"] == "thong_bao" and not any(t.get("tep") == x["tep"] for t in rec["thong_bao"]):
            rec["thong_bao"].append({"loai": "thong_bao", "ten": x.get("nhan", ""), "tep": x["tep"], "nhan": x.get("nhan", "")})
    rec["chi_tiet_luc"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    rec.pop("loi_ct", None)
    return rec


def _chay_chi_tiet(ds):
    v = TT["viec"]
    v.update({"dang_chay": True, "ten": "chi_tiet", "tong": len(ds), "xong": 0, "loi": 0, "hien_tai": "", "ket_thuc": ""})
    TT["dung"] = False
    TT["da_chan_doan"] = False
    het_han = ""
    dang_nghe = TT["nghe"]
    TT["nghe"] = False
    TT["the_he"] += 1
    time.sleep(1.6)
    try:
        for ma in ds:
            if TT["dung"]:
                break
            v["hien_tai"] = ma
            try:
                with KHOA:
                    _mot_ho_so(ma)
                    luu_kho()
                v["xong"] += 1
            except PhienHetHan as e:
                het_han = str(e)
                _ghi("Dung lay chi tiet: " + het_han)
                break
            except Exception as e:
                v["loi"] += 1
                with KHOA:
                    kho()["ho_so"][ma]["loi_ct"] = str(e)[:300]
                    luu_kho()
                _ghi("Loi chi tiet %s: %s" % (ma, e))
    finally:
        v["dang_chay"] = False
        v["hien_tai"] = ""
        v["ket_thuc"] = ("Đã lấy chi tiết %d/%d hồ sơ%s." % (v["xong"], v["tong"], (", %d lỗi" % v["loi"]) if v["loi"] else "")
                         + (" (đã dừng theo yêu cầu)" if TT["dung"] else "")
                         + ((" DỪNG: " + het_han + " Đăng nhập lại trên Chrome rồi bấm Lấy chi tiết - tool làm tiếp các hồ sơ còn lại.")
                            if het_han else ""))
        v["het_han"] = bool(het_han)
        try:
            if TT.get("kenh_b") is not None:
                TT["kenh_b"].goi("Browser.setDownloadBehavior", {"behavior": "default"})
        except Exception:
            pass
        try:
            if not het_han:
                _kenh().goi("Page.navigate", {"url": CAU_HINH.get("trang_vao") or TRANG_TCHS})
        except Exception:
            pass
        if dang_nghe:
            bat_nghe(True)


def lay_chi_tiet(ds_ma=None, lam_lai=False):
    if TT["trang_thai"] != "da_mo":
        return False, "Bấm Mở Cổng DVC và đăng nhập trước."
    if TT["viec"].get("dang_chay"):
        return False, "Đang chạy, đợi xong."
    d = kho()
    if ds_ma:
        ds = [m for m in ds_ma if m in d["ho_so"]]
    else:
        ds = [m for m, r in d["ho_so"].items() if lam_lai or not r.get("chi_tiet_luc")]
    if not ds:
        return False, "Không có hồ sơ nào cần lấy chi tiết (tra cứu trước, hoặc chọn 'Lấy lại')."
    threading.Thread(target=_chay_chi_tiet, args=(ds,), daemon=True).start()
    return True, ""


# ---------------------------------------------------------------------------
#  DOC XML TO KHAI / THONG BAO
# ---------------------------------------------------------------------------
def _ten_the(tag):
    return tag.split("}", 1)[-1] if isinstance(tag, str) else ""


def _chu_the(root, ten):
    for e in root.iter():
        if _ten_the(e.tag) == ten:
            return (e.text or "").strip()
    return ""


_RX_MAU = re.compile(r"(?i)m[aẫ]u\s*s[oố]\s*[:.]?\s*([0-9]{2}[A-Z]?/[A-Z0-9Đ\-]+)")


def ma_mau(s):
    """'01/GTGT - TO KHAI...' / '...(Mau so 01/GTGT)' -> '01/GTGT'."""
    s = str(s or "")
    m = re.match(r"\s*([0-9]{2}[A-Z]?/[A-Z0-9\-]+)", s)
    if m:
        return m.group(1).upper()
    m = _RX_MAU.search(s)
    return m.group(1).upper() if m else ""


def _doc_to_khai(root):
    kq = {"loai": "to_khai"}
    for k in ("maTKhai", "tenTKhai", "loaiTKhai", "soLan", "kieuKy", "kyKKhai", "kyKKhaiTuNgay", "kyKKhaiDenNgay",
              "ngayLapTKhai", "tenCQTNoiNop", "mst", "tenNNT"):
        kq[k] = _chu_the(root, k)
    kq["mau"] = ma_mau(kq.get("tenTKhai"))
    ct = {}
    for e in root.iter():
        if _ten_the(e.tag) == "CTieuTKhaiChinh":
            for x in e.iter():
                t = _ten_the(x.tag)
                if re.fullmatch(r"ct[0-9A-Z][0-9A-Za-z_]*", t) and x.text and x.text.strip():
                    v = _so(x.text)
                    if v is not None:
                        ct[t[2:]] = v
            break
    kq["chi_tieu"] = ct
    return kq


_RX_TEN_TB = re.compile(r"(?i)^(ten|tieu).*(tb|tbao|thongbao)|^tieude|^tentb")
_RX_SO_TB = re.compile(r"(?i)^so(tb|tbao|thongbao|hieu)?$")
_RX_NGAY_TB = re.compile(r"(?i)^(ngay|n)(tb|tbao|thongbao|lap|ky|gui)")
_RX_MA_GD = re.compile(r"(?i)^m(a)?(gdich|giaodich|gd)")


def _doc_thong_bao(root):
    la = []
    for e in root.iter():
        t = _ten_the(e.tag)
        if t in ("Signature", "SignedInfo", "SignatureValue", "KeyInfo", "X509Data", "X509Certificate", "DigestValue"):
            continue
        if len(list(e)) == 0 and (e.text or "").strip():
            la.append((t, e.text.strip()))
    kq = {"loai": "thong_bao", "ten": "", "so": "", "ngay": "", "ma_gd": "", "noi_dung": "", "truong": la[:60]}
    for t, v in la:
        if not kq["ten"] and _RX_TEN_TB.search(t):
            kq["ten"] = v
        elif not kq["so"] and _RX_SO_TB.search(t):
            kq["so"] = v
        elif not kq["ngay"] and _RX_NGAY_TB.search(t):
            kq["ngay"] = v
        elif not kq["ma_gd"] and _RX_MA_GD.search(t):
            kq["ma_gd"] = v
    dai = sorted((v for t, v in la if len(v) > 40), key=len, reverse=True)
    kq["noi_dung"] = dai[0][:1500] if dai else ""
    if not kq["ten"]:
        for t, v in la:
            if re.search(r"(?i)th[oô]ng b[aá]o|v/v", v) and len(v) < 250:
                kq["ten"] = v
                break
    # Chi xet TEN thong bao: than thong bao tiep nhan thuong co cau mau "...ket qua chap nhan/khong chap nhan..."
    kq["canh_bao"] = bool(re.search(r"khong chap nhan|tu choi|khong hop le|khong tiep nhan", bo_dau(kq["ten"])))
    return kq


def doc_xml(b):
    if isinstance(b, bytes):
        b = b.lstrip(b"\xef\xbb\xbf \r\n\t")
    root = ET.fromstring(b)
    ten = {_ten_the(e.tag) for e in root.iter()}
    if "CTieuTKhaiChinh" in ten or "HSoKhaiThue" in ten:
        return _doc_to_khai(root)
    return _doc_thong_bao(root)


def doc_tep(duong):
    kq = []
    try:
        if zipfile.is_zipfile(duong):
            with zipfile.ZipFile(duong) as z:
                for n in z.namelist():
                    if n.lower().endswith(".xml"):
                        try:
                            kq.append(doc_xml(z.read(n)))
                        except Exception:
                            pass
            return kq
        with open(duong, "rb") as f:
            b = f.read()
        if b.lstrip(b"\xef\xbb\xbf \r\n\t")[:1] == b"<" and not b.lstrip()[:15].lower().startswith(b"<!doctype html"):
            kq.append(doc_xml(b))
    except Exception as e:
        _ghi("Khong doc duoc tep %s: %s" % (os.path.basename(duong), e))
    return kq


# ---------------------------------------------------------------------------
#  KY, HAN NOP, SO PHAI NOP, KY CHUA THAY, DOI CHIEU
# ---------------------------------------------------------------------------
def chuan_ky(rec):
    """-> (kieu 'M'/'Q'/'Y', nam, so) hoac None. Uu tien XML to khai, sau do cot 'Ky tinh thue'."""
    x = rec.get("to_khai_xml") or {}
    kieu, ky = (x.get("kieuKy") or "").upper(), x.get("kyKKhai") or ""
    if kieu in ("M", "Q", "Y") and ky:
        m = re.match(r"\s*(\d{1,2})/(\d{4})", ky)
        if kieu in ("M", "Q") and m:
            return (kieu, int(m.group(2)), int(m.group(1)))
        m = re.match(r"\s*(\d{4})", ky)
        if kieu == "Y" and m:
            return ("Y", int(m.group(1)), 0)
    s = bo_dau(rec.get("ky")).upper().replace(" ", "")
    m = re.match(r"^Q(?:UY)?([1-4])[/\-](\d{4})$", s)
    if m:
        return ("Q", int(m.group(2)), int(m.group(1)))
    m = re.match(r"^(\d{1,2})/(\d{4})$", s)
    if m and 1 <= int(m.group(1)) <= 12:
        return ("M", int(m.group(2)), int(m.group(1)))
    m = re.match(r"^(?:NAM)?(\d{4})$", s)
    if m:
        return ("Y", int(m.group(1)), 0)
    m = re.match(r"^(?:THANG)?(\d{1,2})[/\-](\d{4})$", s)
    if m and 1 <= int(m.group(1)) <= 12:
        return ("M", int(m.group(2)), int(m.group(1)))
    m = re.findall(r"(\d{2})/(\d{2})/(\d{4})", s)
    if len(m) == 2:
        a = date(int(m[0][2]), int(m[0][1]), int(m[0][0]))
        b = date(int(m[1][2]), int(m[1][1]), int(m[1][0]))
        dai = (b - a).days
        if dai <= 31:
            return ("M", a.year, a.month)
        if dai <= 92:
            return ("Q", a.year, (a.month - 1) // 3 + 1)
        return ("Y", a.year, 0)
    return None


def ten_ky(k):
    if not k:
        return ""
    if k[0] == "M":
        return "%02d/%d" % (k[2], k[1])
    if k[0] == "Q":
        return "Quý %d/%d" % (k[2], k[1])
    return "Năm %d" % k[1]


def thang_cua_ky(k):
    if not k:
        return []
    if k[0] == "M":
        return ["%d-%02d" % (k[1], k[2])]
    if k[0] == "Q":
        return ["%d-%02d" % (k[1], (k[2] - 1) * 3 + i) for i in (1, 2, 3)]
    return ["%d-%02d" % (k[1], i) for i in range(1, 13)]


# Ngay le duong lich co dinh (Bo luat Lao dong 2019): Tet duong lich, 30/4, 1/5, Quoc khanh 2/9.
_NGHI_CO_DINH = ((1, 1), (30, 4), (1, 5), (2, 9))
# Lich nghi DA CONG BO cho cong chuc (gom ngay nghi bu / hoan doi). Nam sau: them vao AIHoaDon\ngay-nghi-le.txt.
_NGHI_CONG_BO = """
25/01/2025-02/02/2025 Tet Nguyen dan At Ty
07/04/2025 Gio To Hung Vuong
30/04/2025-04/05/2025 Le 30/4 - 1/5 (hoan doi 02/5)
30/08/2025-02/09/2025 Quoc khanh
01/01/2026-04/01/2026 Tet Duong lich (hoan doi 02/1)
14/02/2026-22/02/2026 Tet Nguyen dan Binh Ngo
25/04/2026-27/04/2026 Gio To Hung Vuong (nghi bu 27/4)
30/04/2026-03/05/2026 Le 30/4 - 1/5
29/08/2026-02/09/2026 Quoc khanh (hoan doi 31/8)
"""
_NGHI = {"tap": None, "moc": None}


def doc_ngay_nghi(noi_dung):
    """Dong 'dd/mm/yyyy' hoac 'dd/mm/yyyy-dd/mm/yyyy' (+ ghi chu). Dong bat dau '#' bo qua. Tra ve set(date)."""
    ra = set()
    for dong in str(noi_dung or "").splitlines():
        dong = dong.strip()
        if not dong or dong.startswith("#"):
            continue
        m = re.match(r"(\d{1,2})/(\d{1,2})/(\d{4})(?:\s*-\s*(\d{1,2})/(\d{1,2})/(\d{4}))?", dong)
        if not m:
            continue
        try:
            a = date(int(m.group(3)), int(m.group(2)), int(m.group(1)))
            b = date(int(m.group(6)), int(m.group(5)), int(m.group(4))) if m.group(4) else a
        except ValueError:
            continue
        if b < a or (b - a).days > 31:
            continue
        while a <= b:
            ra.add(a)
            a += timedelta(days=1)
    return ra


_MAU_TEP_NGHI = """# Lich NGAY NGHI LE dung de tinh HAN NOP to khai (tab Ho so thue - Cong dich vu cong).
# Moi dong: dd/mm/yyyy  hoac  dd/mm/yyyy-dd/mm/yyyy  roi ghi chu. Dong bat dau bang dau # bi bo qua.
# Chuong trinh DA CO SAN: 1/1, 30/4, 1/5, 2/9 hang nam va lich nghi da cong bo nam 2025, 2026
# (Tet Nguyen dan, Gio To, nghi bu / hoan doi). Cac nam sau: them lich Chinh phu cong bo vao duoi day.
# Vi du (bo dau # o dau dong khi da co thong bao chinh thuc):
# 04/02/2027-10/02/2027 Tet Dinh Mui
"""


def ngay_nghi():
    """Tap ngay nghi (khong ke thu 7 / CN): lich cong bo + tep nguoi dung (doc lai khi tep doi)."""
    tep = os.path.join(BASE_DIR, "ngay-nghi-le.txt")
    if not os.path.exists(tep):
        try:
            with io.open(tep, "w", encoding="utf-8") as f:
                f.write(_MAU_TEP_NGHI)
        except Exception:
            pass
    try:
        moc = os.path.getmtime(tep)
    except OSError:
        moc = None
    if _NGHI["tap"] is None or _NGHI["moc"] != moc:
        tap = doc_ngay_nghi(_NGHI_CONG_BO)
        if moc is not None:
            try:
                with io.open(tep, "r", encoding="utf-8-sig") as f:
                    tap |= doc_ngay_nghi(f.read())
            except Exception:
                pass
        _NGHI["tap"], _NGHI["moc"] = tap, moc
    return _NGHI["tap"]


def la_ngay_nghi(d):
    return d.weekday() >= 5 or (d.day, d.month) in _NGHI_CO_DINH or d in ngay_nghi()


def _lui_ngay_nghi(d):
    """Han nop trung thu 7 / CN / ngay nghi le -> ngay lam viec tiep theo."""
    n = 0
    while la_ngay_nghi(d) and n < 40:
        d += timedelta(days=1)
        n += 1
    return d


def han_nop(k):
    """Han nop to khai (Luat Quan ly thue 38/2019): thang -> ngay 20 thang sau; quy -> ngay cuoi thang dau quy sau;
       nam (quyet toan) -> ngay cuoi thang thu 3 sau nam. Trung thu 7 / CN / ngay nghi le -> ngay lam viec tiep theo."""
    if not k:
        return None
    if k[0] == "M":
        y, m = (k[1] + (k[2] // 12), k[2] % 12 + 1)
        return _lui_ngay_nghi(date(y, m, 20))
    if k[0] == "Q":
        m = k[2] * 3 + 1
        y = k[1]
        if m > 12:
            m, y = 1, y + 1
        return _lui_ngay_nghi(date(y + (m // 12), m % 12 + 1, 1) - timedelta(days=1))
    return _lui_ngay_nghi(date(k[1] + 1, 4, 1) - timedelta(days=1))


def mau_cua(rec):
    return (rec.get("to_khai_xml") or {}).get("mau") or ma_mau(rec.get("to_khai")) or ma_mau(rec.get("tthc"))


def _la_bo_sung(rec):
    x = rec.get("to_khai_xml") or {}
    return (x.get("loaiTKhai") or "").upper() == "B" or "bo sung" in bo_dau(rec.get("loai_tk"))


def _bi_tu_choi(rec):
    """Ho so bi CQT khong chap nhan / tu choi (theo trang thai hoac ten thong bao) -> khong dung lam so phai nop."""
    t = bo_dau(rec.get("trang_thai"))
    if re.search(r"khong chap nhan|tu choi|khong tiep nhan|bi loi", t):
        return True
    return any(x.get("canh_bao") for x in (rec.get("thong_bao") or []))


def _thu_tu(rec):
    """Chon to khai co hieu luc cua mot ky: bo ho so bi tu choi, bo sung sau thay chinh thuc, lan sau thay lan truoc."""
    x = rec.get("to_khai_xml") or {}
    try:
        lan = int(x.get("soLan") or re.sub(r"\D", "", str(rec.get("lan_bs") or "")) or 0)
    except ValueError:
        lan = 0
    return (0 if _bi_tu_choi(rec) else 1, 1 if _la_bo_sung(rec) else 0, lan, _ngay_iso(rec.get("ngay_nop")) or "")


def _chap_nhan(rec):
    t = bo_dau(rec.get("trang_thai"))
    return ("chap nhan" in t and "khong chap nhan" not in t and "cho chap nhan" not in t) or "da tiep nhan" in t


PHAI_NOP = {
    "01/GTGT": {"phai_nop": "40", "chuyen_sau": "43", "de_nghi_hoan": "42"},
    "03/TNDN": {"phai_nop": "I", "tong": "E", "da_tam_nop": "G"},
}


def to_khai_hieu_luc():
    """{(mau, ky): ho so} - to khai co hieu luc cua moi ky (bo sung sau thay chinh thuc, bi tu choi xep cuoi)."""
    tot = {}
    for rec in kho()["ho_so"].values():
        mau, k = mau_cua(rec), chuan_ky(rec)
        if not mau or not k:
            continue
        khoa = (mau, k)
        if khoa not in tot or _thu_tu(rec) > _thu_tu(tot[khoa]):
            tot[khoa] = rec
    return tot


def ky_truoc(k):
    if k[0] == "M":
        return ("M", k[1] - 1, 12) if k[2] == 1 else ("M", k[1], k[2] - 1)
    if k[0] == "Q":
        return ("Q", k[1] - 1, 4) if k[2] == 1 else ("Q", k[1], k[2] - 1)
    return ("Y", k[1] - 1, 0)


def lien_ky():
    """01/GTGT: [22] thue con duoc khau tru ky truoc chuyen sang PHAI BANG [43] cua to khai co hieu luc ky lien truoc.
       Doi thang <-> quy: thang 1/4/7/10 so voi quy lien truoc, quy so voi thang cuoi quy truoc."""
    tot = to_khai_hieu_luc()
    ra = []
    for (mau, k), rec in tot.items():
        ct = rec.get("chi_tieu") or {}
        if mau != "01/GTGT" or not ct or _bi_tu_choi(rec):
            continue
        ung = [ky_truoc(k)]
        if k[0] == "M" and k[2] in (1, 4, 7, 10):
            ung.append(("Q", k[1] - 1, 4) if k[2] == 1 else ("Q", k[1], (k[2] - 1) // 3))
        if k[0] == "Q":
            ung.append(("M", k[1] - 1, 12) if k[2] == 1 else ("M", k[1], (k[2] - 1) * 3))
        tr = None
        for u in ung:
            x = tot.get((mau, u))
            if x is not None and x.get("chi_tieu") and not _bi_tu_choi(x):
                tr, kt = x, u
                break
        if tr is None:
            continue
        a, b = ct.get("22") or 0.0, tr["chi_tieu"].get("43") or 0.0
        ra.append({"ky": ten_ky(k), "ma_hs": rec["ma_hs"], "ct22": a, "ky_truoc": ten_ky(kt), "ma_hs_truoc": tr["ma_hs"],
                   "ct43_truoc": b, "lech": a - b, "co_lech": abs(a - b) > NGUONG_LECH, "khoa": [k[1], k[2]]})
    ra.sort(key=lambda x: x["khoa"], reverse=True)
    return ra


LOAI_THUE = {"01/GTGT": "GTGT", "03/TNDN": "TNDN"}


def nop_tien_nam(sl=None, pn=None):
    """Doi chieu nop tien theo NAM tai chinh cua bo so (tham khao):
       GTGT: tong [40] cac to khai co hieu luc co HAN NOP trong nam <-> tong da nop theo so sach (No 3331 / Co 111,112
       trong nam) <-> tong giay nop tien loai GTGT tai tu Cong DVC (neu co).
       TNDN: khong co to khai tam nop quy -> chi liet ke da nop (so sach / GNT) va [I] quyet toan co han trong nam."""
    sl = so_lieu() if sl is None else sl
    pn = bang_phai_nop() if pn is None else pn
    nam = (sl or {}).get("nam")
    if not nam:
        return []
    ra = []
    for loai, tk in (("GTGT", "3331"), ("TNDN", "3334")):
        ky = [x for x in pn if LOAI_THUE.get(x["mau"]) == loai and x.get("han_nop", "").endswith("/%s" % nam)
              and not x.get("bi_tu_choi")]
        phai = sum(float(x.get("phai_nop") or 0) for x in ky)
        thieu_xml = [x["ky"] for x in ky if not x.get("co_xml")]
        so = [x for x in (sl.get("nop_so_sach") or []) if str(x.get("tk", "")).startswith(tk)]
        gnt = [x for x in (sl.get("gnt") or []) if x.get("loai") == loai]
        da_so = sum(float(x.get("tien") or 0) for x in so)
        da_gnt = sum(float(x.get("tien") or 0) for x in gnt)
        ra.append({"loai": loai, "nam": nam, "so_ky": len(ky), "ky": [x["ky"] for x in ky], "thieu_xml": thieu_xml,
                   "phai_nop": phai, "da_nop_so": da_so, "so_lan_so": len(so), "co_gnt": bool(gnt), "da_nop_gnt": da_gnt,
                   "chenh_so": (phai - da_so) if loai == "GTGT" else None,
                   "chenh_gnt": (phai - da_gnt) if (loai == "GTGT" and gnt) else None,
                   "ky_chua_thay": [x["ky"] for x in ky_chua_thay() if LOAI_THUE.get(x["mau"]) == loai
                                    and x["han_nop"].endswith("/%s" % nam)]})
    return ra


def bang_phai_nop():
    """Moi (mau, ky): to khai co hieu luc -> so phai nop + han nop."""
    tot = to_khai_hieu_luc()
    ra = []
    for (mau, k), rec in sorted(tot.items(), key=lambda x: (x[0][1][1], x[0][1][0], x[0][1][2], x[0][0])):
        ct = rec.get("chi_tieu") or {}
        cfg = PHAI_NOP.get(mau, {})
        so = None
        if cfg and ct:
            so = ct.get(cfg["phai_nop"])
            if so is not None and so < 0:
                so = 0.0
        h = han_nop(k)
        ra.append({"ma_hs": rec["ma_hs"], "mau": mau, "ky": ten_ky(k), "han_nop": h.strftime("%d/%m/%Y") if h else "",
                   "qua_han": bool(h and h < date.today() and so), "phai_nop": so,
                   "chuyen_sau": ct.get(cfg.get("chuyen_sau", "_")) if cfg else None,
                   "de_nghi_hoan": ct.get(cfg.get("de_nghi_hoan", "_")) if cfg else None,
                   "trang_thai": rec.get("trang_thai", ""), "ngay_nop": rec.get("ngay_nop", ""),
                   "bo_sung": _la_bo_sung(rec), "co_xml": bool(ct), "bi_tu_choi": _bi_tu_choi(rec),
                   "ghi_chu": ("HỒ SƠ BỊ TỪ CHỐI - chưa có tờ khai được chấp nhận cho kỳ này. " if _bi_tu_choi(rec) else "")
                   + _ghi_chu_pn(mau, ct)})
    return ra


def _ghi_chu_pn(mau, ct):
    if not ct:
        return "Chưa có tờ khai XML (bấm Lấy chi tiết)"
    if mau == "03/TNDN":
        g = "[E] thuế TNDN phải nộp cả năm %s, [G] đã tạm nộp %s" % (_tien(ct.get("E")), _tien(ct.get("G")))
        if (ct.get("I") or 0) < 0:
            g += "; nộp thừa %s" % _tien(-ct["I"])
        return g
    if mau == "01/GTGT":
        g = []
        if ct.get("41"):
            g.append("[41] chưa khấu trừ hết %s" % _tien(ct["41"]))
        if ct.get("42"):
            g.append("[42] đề nghị hoàn %s" % _tien(ct["42"]))
        return "; ".join(g)
    return ""


def _tien(v):
    try:
        return "{:,.0f}".format(float(v)).replace(",", ".")
    except Exception:
        return ""


def ky_chua_thay():
    """Ky DEN HAN trong cac khoang ngay da tra cuu ma chua thay to khai (theo tan suat da thay cua tung mau)."""
    d = kho()
    tan_suat, co = {}, {}
    for rec in d["ho_so"].values():
        mau, k = mau_cua(rec), chuan_ky(rec)
        if not mau or not k or k[0] == "Y":
            continue
        tan_suat.setdefault(mau, {}).setdefault(k[0], 0)
        tan_suat[mau][k[0]] += 1
        co.setdefault(mau, set()).add(k)
    ra = []
    hom_nay = date.today()
    for mau, dem in tan_suat.items():
        kieu = max(dem, key=dem.get)
        can = set()
        for tc in d["tra_cuu"]:
            try:
                a, b = date.fromisoformat(tc["tu"]), date.fromisoformat(tc["den"])
            except Exception:
                continue
            for nam in range(a.year - 1, b.year + 1):
                for so in (range(1, 13) if kieu == "M" else range(1, 5)):
                    k = (kieu, nam, so)
                    h = han_nop(k)
                    if h and a <= h <= b and h <= hom_nay:
                        can.add(k)
        for k in sorted(can - co.get(mau, set()), key=lambda x: (x[1], x[2])):
            ra.append({"mau": mau, "ky": ten_ky(k), "han_nop": han_nop(k).strftime("%d/%m/%Y")})
    return ra


def so_lieu():
    duong = os.path.join(os.path.dirname(_thu_muc()), "so-lieu-doi-chieu.json")
    try:
        with io.open(duong, "r", encoding="utf-8-sig") as f:
            return json.load(f)
    except Exception:
        return {}


def doi_chieu(rec, sl=None):
    """01/GTGT: to khai da nop <-> so sach UNESCO <-> hoa don dien tu da tai (cung ky)."""
    sl = so_lieu() if sl is None else sl
    ct = rec.get("chi_tieu") or {}
    k = chuan_ky(rec)
    if mau_cua(rec) != "01/GTGT" or not ct or not k:
        return None
    thang = thang_cua_ky(k)
    ky_sl = (sl or {}).get("ky") or {}
    co_so = all(t in ky_sl for t in thang)

    def cong(nhanh, khoa):
        if not co_so:
            return None
        return sum(float(((ky_sl[t].get(nhanh) or {}).get(khoa)) or 0) for t in thang)
    dong = [("23", "Giá trị HHDV mua vào (chưa thuế)", cong("so_sach", "23"), cong("hddt", "mua_chua_thue")),
            ("24", "Thuế GTGT của HHDV mua vào", cong("so_sach", "24"), cong("hddt", "mua_thue")),
            ("25", "Thuế GTGT được khấu trừ kỳ này (so với [24] sổ sách)", cong("so_sach", "24"), None),
            ("26", "Doanh thu không chịu thuế", cong("so_sach", "26"), None),
            ("34", "Tổng doanh thu bán ra", cong("so_sach", "34"), cong("hddt", "ban_chua_thue")),
            ("35", "Tổng thuế GTGT bán ra", cong("so_sach", "35"), cong("hddt", "ban_thue")),
            ("22", "Thuế còn được khấu trừ kỳ trước chuyển sang", None, None),
            ("40", "Thuế GTGT còn phải nộp", None, None),
            ("43", "Thuế còn được khấu trừ chuyển kỳ sau", None, None)]
    ra = []
    so_lech = 0
    for ma, ten, so_sach, hddt in dong:
        tk = ct.get(ma)
        l1 = (tk or 0) - so_sach if so_sach is not None and tk is not None else None
        l2 = (tk or 0) - hddt if hddt is not None and tk is not None else None
        lech = any(x is not None and abs(x) > NGUONG_LECH for x in (l1, l2))
        so_lech += 1 if lech else 0
        ra.append({"ct": ma, "ten": ten, "to_khai": tk, "so_sach": so_sach, "hddt": hddt, "lech_so": l1, "lech_hd": l2, "lech": lech})
    return {"ma_hs": rec["ma_hs"], "ky": ten_ky(k), "co_so_lieu": co_so, "nam_so_lieu": (sl or {}).get("nam"),
            "tao_luc": (sl or {}).get("tao_luc", ""), "dong": ra, "so_lech": so_lech, "khoa_ky": [k[1], k[2]],
            "bo_sung": _la_bo_sung(rec), "lan": (rec.get("to_khai_xml") or {}).get("soLan") or "",
            "bi_tu_choi": _bi_tu_choi(rec), "ngay_nop": rec.get("ngay_nop", "")}


def tong_hop():
    """Du lieu cho giao dien: ho so, thong bao, doi chieu, so phai nop, ky chua thay."""
    d = kho()
    sl = so_lieu()
    hs = []
    tb = []
    dc = []
    for rec in sorted(d["ho_so"].values(), key=lambda r: (_ngay_iso(r.get("ngay_nop")) or "", r["ma_hs"]), reverse=True):
        k = chuan_ky(rec)
        ds_tb = rec.get("thong_bao") or []
        hs.append({"ma_hs": rec["ma_hs"], "nguon": rec.get("nguon", "DVC"), "mau": mau_cua(rec),
                   "to_khai": rec.get("to_khai", ""), "ky": ten_ky(k) or rec.get("ky", ""), "ngay_nop": rec.get("ngay_nop", ""),
                   "trang_thai": rec.get("trang_thai", ""), "chap_nhan": _chap_nhan(rec),
                   "loai_tk": rec.get("loai_tk", ""), "lan": rec.get("lan_bs") or rec.get("lan_nop") or "",
                   "so_tb": len(ds_tb), "canh_bao_tb": any(t.get("canh_bao") for t in ds_tb),
                   "co_to_khai": bool(rec.get("chi_tieu")), "chi_tiet": bool(rec.get("chi_tiet_luc")),
                   "loi": rec.get("loi_ct", ""), "don_vi": rec.get("don_vi", "")})
        for t in ds_tb:
            tb.append({"ma_hs": rec["ma_hs"], "ten": t.get("ten") or t.get("nhan") or "", "so": t.get("so", ""),
                       "ngay": t.get("ngay", ""), "canh_bao": bool(t.get("canh_bao")), "tep": t.get("tep", ""),
                       "noi_dung": (t.get("noi_dung") or "")[:600]})
        x = doi_chieu(rec, sl)
        if x:
            dc.append(x)
    pn = bang_phai_nop()
    hieu_luc = {x["ma_hs"] for x in pn}
    for x in dc:
        x["hieu_luc"] = x["ma_hs"] in hieu_luc       # to khai dang co hieu luc cua ky (ban khac: da bi thay / bi tu choi)
    dc.sort(key=lambda x: (x["khoa_ky"], 1 if x["hieu_luc"] else 0), reverse=True)
    return {"ho_so": hs, "thong_bao": tb, "doi_chieu": dc, "phai_nop": pn, "ky_chua_thay": ky_chua_thay(),
            "lien_ky": lien_ky(), "nop_tien": nop_tien_nam(sl, pn),
            "so_lieu": {"co": bool(sl), "nam": sl.get("nam") if sl else None, "tao_luc": sl.get("tao_luc", "") if sl else "",
                        "dvc_nap_nham": (sl or {}).get("dong_dvc_nap_nham") or 0},
            "tra_cuu": d.get("tra_cuu", []), "thu_muc": _thu_muc()}


# ---------------------------------------------------------------------------
#  GUI SANG UNESCO (kho tra cuu Cong DVC - bang HDDT_DVC_Dong, nhom HSDVC) + bao cao CSV
# ---------------------------------------------------------------------------
def xuat_unesco():
    d = kho()
    thu = os.path.dirname(_thu_muc())
    kq = os.path.join(thu, "ket-qua")
    os.makedirs(kq, exist_ok=True)
    mst = re.sub(r"[^0-9-]", "", CAU_HINH["mst"]() or "") or "CHUNG"
    pn = {x["ma_hs"]: x for x in bang_phai_nop()}
    dong = []
    for rec in d["ho_so"].values():
        k = chuan_ky(rec)
        ds_tb = rec.get("thong_bao") or []
        dong.append({"khoa": "HSDVC|" + rec["ma_hs"], "nhom": "HSDVC", "mst": mst, "ma": rec["ma_hs"],
                     "ngay": _ngay_iso(rec.get("ngay_nop")),
                     "tieu_de": ((mau_cua(rec) or rec.get("to_khai", "")) + " " + (ten_ky(k) or rec.get("ky", ""))).strip()[:255],
                     "trang_thai": (rec.get("trang_thai") or "")[:60], "ky": (ten_ky(k) or rec.get("ky", ""))[:30],
                     "so_tien": (pn.get(rec["ma_hs"]) or {}).get("phai_nop") or 0,
                     "tep": rec.get("tep_to_khai", ""), "tep_da_tai": os.path.join(_thu_muc(), "tep", _ten_an_toan(rec["ma_hs"])),
                     "cq": (rec.get("don_vi") or "")[:60], "loai_tb": "; ".join((t.get("ten") or t.get("nhan") or "")[:80] for t in ds_tb)[:255],
                     "ma_gd": (rec.get("ma_gd") or "")[:40], "chi_tieu": rec.get("chi_tieu") or {},
                     # GD97-C: MST / ten nguoi nop thue tren ho so -> VB doi chieu cong ty dang mo truoc khi nhap
                     "mst_dang_nhap": re.sub(r"[^0-9-]", "", rec.get("mst") or ""), "ten_dang_nhap": (rec.get("ten_nnt") or "")[:120],
                     "thong_bao": [{k2: t.get(k2) for k2 in ("ten", "so", "ngay", "canh_bao", "tep")} for t in ds_tb]})
    ts = datetime.now().strftime("%Y%m%d%H%M%S")
    duong = os.path.join(kq, "dvc_hs_%s_%s.jsonl" % (mst, ts))
    with io.open(duong + ".tmp", "w", encoding="utf-8") as f:
        for x in dong:
            f.write(json.dumps(x, ensure_ascii=False) + "\n")
    os.replace(duong + ".tmp", duong)
    try:
        with io.open(os.path.join(kq, "DA_XONG_DVC"), "w", encoding="utf-8") as f:
            f.write(duong)
    except Exception:
        pass
    # bao cao CSV (Excel doc duoc tieng Viet nho BOM)
    csv = os.path.join(_thu_muc(), "BAO_CAO_HO_SO_THUE_%s.csv" % ts)
    th = tong_hop()
    dong_csv = ["Mã hồ sơ;Mẫu;Kỳ;Ngày nộp;Trạng thái;Lần;Số thông báo;Thuế còn phải nộp;Hạn nộp;Chuyển kỳ sau;Lệch đối chiếu"]
    so_lech = {x["ma_hs"]: x["so_lech"] for x in th["doi_chieu"]}
    for h in th["ho_so"]:
        p = pn.get(h["ma_hs"]) or {}
        dong_csv.append(";".join(str(x) for x in [h["ma_hs"], h["mau"], h["ky"], h["ngay_nop"], h["trang_thai"], h["lan"], h["so_tb"],
                                                  _tien(p.get("phai_nop")) if p.get("phai_nop") is not None else "", p.get("han_nop", ""),
                                                  _tien(p.get("chuyen_sau")) if p.get("chuyen_sau") is not None else "",
                                                  so_lech.get(h["ma_hs"], "")]))
    for x in th["ky_chua_thay"]:
        dong_csv.append(";".join(["", x["mau"], x["ky"], "", "CHƯA THẤY TỜ KHAI (hạn nộp %s)" % x["han_nop"], "", "", "", x["han_nop"], "", ""]))
    with io.open(csv, "w", encoding="utf-8-sig") as f:
        f.write("\r\n".join(dong_csv) + "\r\n")
    _ghi("Xuat %d ho so -> %s ; bao cao %s" % (len(dong), os.path.basename(duong), os.path.basename(csv)))
    return duong, csv, len(dong)


def mo_tep(duong):
    """Chi mo tep NAM TRONG thu muc ho so thue (khong mo duong bat ky tu giao dien)."""
    goc = os.path.normcase(os.path.abspath(_thu_muc()))
    p = os.path.abspath(duong or "")
    if not (os.path.normcase(p) + os.sep).startswith(goc + os.sep) or not os.path.exists(p):
        return False, "Tệp không nằm trong thư mục hồ sơ thuế."
    try:
        if hasattr(os, "startfile"):
            os.startfile(p)
        else:
            subprocess.Popen(["xdg-open", p])
        return True, ""
    except Exception as e:
        return False, str(e)[:200]


def xoa_ho_so(ma):
    d = kho()
    if ma in d["ho_so"]:
        del d["ho_so"][ma]
        luu_kho()
        return True
    return False


# ---------------------------------------------------------------------------
#  API cho giao dien (goi tu Handler cua tool tai hoa don)
# ---------------------------------------------------------------------------
def xu_ly_api(duong, p):
    """duong: '/api/hstk/<viec>'. Tra ve dict (JSON)."""
    viec = duong.rsplit("/", 1)[-1]
    try:
        if viec == "trang-thai":
            return {"ok": True, "chrome": TT["trang_thai"], "loi": TT["loi"], "nghe": TT["nghe"], "bao": TT["bao"],
                    "viec": dict(TT["viec"]), "so_ho_so": len(kho()["ho_so"])}
        if viec == "mo-chrome":
            if TT["trang_thai"] not in ("dang_mo",):
                threading.Thread(target=mo_chrome, daemon=True).start()
            return {"ok": True}
        if viec == "nghe":
            ok, loi = bat_nghe(bool(p.get("bat", True)))
            return {"ok": ok, "loi": loi}
        if viec == "lay-chi-tiet":
            ok, loi = lay_chi_tiet(p.get("ma") or None, bool(p.get("lam_lai")))
            return {"ok": ok, "loi": loi}
        if viec == "dung":
            TT["dung"] = True
            return {"ok": True}
        if viec == "du-lieu":
            return dict(ok=True, **tong_hop())
        if viec == "mo-tep":
            ok, loi = mo_tep(p.get("duong"))
            return {"ok": ok, "loi": loi}
        if viec == "xuat":
            duong_j, csv, n = xuat_unesco()
            mo_tep(csv)
            return {"ok": True, "jsonl": duong_j, "csv": csv, "so": n}
        if viec == "xoa":
            return {"ok": xoa_ho_so(p.get("ma", ""))}
        if viec == "chan-doan":
            if TT["trang_thai"] != "da_mo":
                return {"ok": False, "loi": "Chưa mở Cổng dịch vụ công."}
            if TT["viec"].get("dang_chay"):
                return {"ok": False, "loi": "Đang lấy chi tiết, đợi xong rồi bấm lại."}
            duong_cd = luu_cau_truc(p.get("ly_do") or "nguoi-dung")
            if not duong_cd:
                return {"ok": False, "loi": "Không đọc được trang trên Chrome (thẻ Cổng DVC đã đóng?)."}
            mo_tep(os.path.dirname(duong_cd))
            return {"ok": True, "duong": duong_cd}
        if viec == "chi-tiet-ho-so":
            rec = kho()["ho_so"].get(p.get("ma", ""))
            return {"ok": bool(rec), "ho_so": rec, "doi_chieu": doi_chieu(rec) if rec else None}
        return {"ok": False, "loi": "Không có việc " + viec}
    except Exception as e:
        _ghi("LOI API %s: %s" % (viec, e))
        return {"ok": False, "loi": str(e)[:300]}
