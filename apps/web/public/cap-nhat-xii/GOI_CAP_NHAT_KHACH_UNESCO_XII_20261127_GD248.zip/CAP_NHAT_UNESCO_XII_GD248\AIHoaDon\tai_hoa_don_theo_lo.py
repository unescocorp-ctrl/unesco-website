# -*- coding: utf-8 -*-
"""
TẢI HOÁ ĐƠN THEO LÔ (UNESCO XII) - 11/11/2026

Quyết định của chủ: NGƯỜI gõ mã captcha của cổng thuế MỘT lần cho mỗi khách; máy tải hết các tháng còn thiếu
của khách đó rồi sang khách sau. Script này KHÔNG giải / bỏ qua / đọc (OCR) captcha, KHÔNG đọc, lưu, in hay
truyền mật khẩu (Chrome tự điền mật khẩu đã lưu trong hồ sơ Chrome của khách là việc của người dùng).

Ba lệnh:
  python -X utf8 tai_hoa_don_theo_lo.py danh_sach [/may_chu:.\\SQLEXPRESS] [/so:A_2026,B_2026] [/tu_thang:1] [/den_thang:9]
                                                   [/lenh:E:\\KETOAN\\LENH] [/huong:ca] [/so_lieu:<tệp json đã đọc>]
      -> đọc CHỈ ĐỌC các sổ (SELECT, tài khoản Windows) + báo cáo đối chiếu của trạm (DOI_CHIEU_HD_<kỳ>.csv),
         ghi danh sách khách × tháng còn thiếu vào ket-qua\\tai_lo\\danh_sach_tai_lo.csv (người sửa được) và in bảng.
  python -X utf8 tai_hoa_don_theo_lo.py chay [/lenh:...] [/loai:ca|dt|mtt] [/mtt:hoi|bo] [/cho_phut:20] [/khong_hoi]
                                              [/tu_ghi:khong] [/mtt_dung_lai:co]
      -> với từng khách (gộp theo MST) trong danh sách: mở Chrome hồ sơ riêng của MST (đường có sẵn của
         tool_tai_hoa_don_unesco.py), chờ người đăng nhập + gõ captcha, tải mọi tháng còn thiếu (XML) vào
         <LENH>\\tep\\<sổ>\\<yyyy-mm>\\hoa_don\\ - nơi bước "tai_hd" của trạm nhập vào sổ - rồi sang khách sau.
         Phím trong lúc chạy: B = bỏ qua khách này, D = dừng cả lô (hoặc tạo tệp ket-qua\\tai_lo\\DUNG).
         Chạy lại trong ngày: tháng đã xong hôm nay được bỏ qua.
  python -X utf8 tai_hoa_don_theo_lo.py xem
      -> in kết quả hôm nay.

Bản 1.1 (quyết định của chủ 11/11/2026):
  1. Hoá đơn KHÔNG có XML gốc trên cổng thuế (điện, nước, ngân hàng…): lô lấy dữ liệu chi tiết của cổng thuế (đường có sẵn của
     tool) và ghi ra CSV đúng 36 cột "mẫu 1" vào <LENH>\\tep\\<sổ>\\<yyyy-mm>\\hoa_don\\mua\\ hoặc \\ban\\ - nơi bước tai_hd của trạm
     đã đọc Excel / CSV (AiExcelInvoiceImportService) - tên tệp KHONG_XML_GOC_<kỳ>_<hướng>_<loại>.csv. KHÔNG tạo XML giả.
  2. HĐ máy tính tiền: mọi lần tìm (tháng × mua / bán) của một khách được tra DỒN lên đầu ngay sau khi đăng nhập, nên các câu
     hỏi captcha (nếu cổng đòi) đến liền nhau rồi máy tự chạy hết. Mặc định mỗi trang (50 HĐ) cổng đòi mã thì hỏi người một mã.
     /mtt_dung_lai:co (mặc định TẮT - chỉ bật khi đã thấy chính trang web cổng thuế hỏi mã MỘT lần cho cả lần tìm): trang sau
     của CÙNG một lần tìm gửi lại đúng mã người vừa gõ và cổng vừa nhận; cổng từ chối thì thôi hẳn (không thử lại trong lô) và
     hỏi người mã mới. Máy không giải / đoán / đọc captcha và không bao giờ gửi lại mã đã bị từ chối.
  3. Tháng tải ĐỦ và có tệp chờ nhập: lô ghi tệp "đề nghị ghi sổ" <LENH>\\de_nghi\\<sổ>.<kỳ>.tai_hd.de_nghi.json để ERP ra lệnh
     tai_hd cho trạm theo đường lệnh thường (lô không ghi sổ, không tự đặt lệnh vào LENH\\cho). /tu_ghi:khong = không ghi.

KHÔNG bao giờ tự tạo khong_phat_sinh.txt (đó là xác nhận của người): tháng cổng thuế không có hoá đơn chỉ được
liệt kê trong ket-qua\\tai_lo\\THANG_KHONG_CO_HD_<ngày>.txt để kế toán xem rồi tự xác nhận.
"""
import csv
import io
import json
import os
import re
import subprocess
import sys
import threading
import time
from datetime import date, datetime, timedelta

PHIEN_BAN = "1.2 (18/11/2026)"
HERE = os.path.dirname(os.path.abspath(__file__))
TEN_TOOL = "tool_tai_hoa_don_unesco.py"
TEP_DOC_SO = "tai_hoa_don_theo_lo_doc_so.ps1"
TEP_DANH_SACH = "danh_sach_tai_lo.csv"
COT_DANH_SACH = ["Chon", "Khach", "So", "MST", "TenKhach", "TenDangNhap", "Ky", "Huong", "LyDo"]
COT_KET_QUA = ["Luc", "Khach", "MST", "TenKhach", "So", "KetQua", "ThangXong", "ThangKhongCoHD", "ThangChuaXong",
               "HDMua", "HDBan", "TaiMoi", "DaCoSan", "KhongCoXMLGoc", "LoiTai", "GhiChu", "KhongXMLDaGhiCSV", "DeNghiGhiSo",
               "CaptchaMTT"]
TRANG_THAI_XONG = ("xong", "khong_co_tren_cong")
LOAI_DU = ("dt", "mtt")          # P0 18/11/2026: tháng chỉ ĐỦ khi cả HĐ điện tử và HĐ máy tính tiền đã tra xong
TEN_TRANG_THAI = {"xong": "đã tải xong", "khong_co_tren_cong": "cổng thuế không có hoá đơn", "mot_phan": "mới tải được một phần",
                  "loi": "lỗi", "dang_do": "đang dở (bỏ qua / dừng)", "bo_qua": "bỏ qua"}
TEN_KET_LUAN = {"CHUA_TAI": "chưa tải hoá đơn", "CHUA_TAI_DU": "chưa tải đủ hoá đơn",
                "CHUA_XAC_NHAN": "chưa có hoá đơn, chưa xác nhận không phát sinh"}
TEN_NHOM = {("mua", "dt"): "Mua vào - HĐ điện tử", ("mua", "mtt"): "Mua vào - HĐ máy tính tiền",
            ("ban", "dt"): "Bán ra - HĐ điện tử", ("ban", "mtt"): "Bán ra - HĐ máy tính tiền"}
XAC_NHAN_KHONG_PS = "khong_phat_sinh.txt"
# 36 cột "mẫu 1" (HDDTTaiVe) - đúng thứ tự hd_excel_ai.COT_MAU1, khuôn mà bước nhập Excel / CSV của trạm đã nhận
COT_MAU1 = ["KyHieuMauSo", "KyHieuHoaDon", "SoHoaDon", "NgayLap", "NgayNguoiBanKySo", "MCCQT", "NgayCQTKySo",
            "DonViTienTe", "TyGia", "TenNguoiBanNguoiXuatHang", "MSTNguoiBanNguoiXuatHang", "DiaChiNguoiBan",
            "TenNguoiMuaNguoiNhanHang", "MSTNguoiMuaNguoiNhanHang", "DiaChiNguoiMua", "MaVT", "TenHangHoaDichVu",
            "DonViTinh", "SoLuong", "DonGia", "ChietKhau", "ThueSuat", "ThanhTienChuaThue", "TienThue",
            "TongTienChietKhauThuongMai", "TongTienPhi", "TongTienThanhToan", "TrangThaiHoaDon", "KetQuaKiemTraHoaDon",
            "TaiKhoan", "PhanLoai", "ThanhToan", "ThangCT", "MaSoLoaiCT", "STTBangKe", "MaCT"]
COT_SO_MAU1 = ("TyGia", "SoLuong", "DonGia", "ChietKhau", "ThanhTienChuaThue", "TienThue", "TongTienChietKhauThuongMai",
               "TongTienPhi", "TongTienThanhToan")
TIEN_TO_KHONG_XML = "KHONG_XML_GOC_"
TEP_GHI_CHU_KHONG_XML = "KHONG_XML_GOC_DOC_TOI.txt"
NGUON_KHONG_XML = "không có XML gốc – lấy từ dữ liệu chi tiết của cổng thuế"
THU_MUC_DE_NGHI = "de_nghi"
NGUON_DE_NGHI = "TAI_HOA_DON_THEO_LO"


# ==========================================================================
#  THAM SỐ / ĐƯỜNG DẪN
# ==========================================================================
def doc_tham_so(argv):
    """['x.py', 'chay', '/lenh:E:\\L', '/khong_hoi'] -> ('chay', {'lenh': 'E:\\L', 'khong_hoi': ''})"""
    lenh, ts = "", {}
    for a in argv[1:]:
        a = str(a).strip()
        if not a:
            continue
        if a.startswith("/"):
            k, _, v = a[1:].partition(":")
            ts[k.strip().lower()] = v.strip().strip('"')
        elif not lenh:
            lenh = a.lower()
    return lenh or "danh_sach", ts


def thu_muc_lo(ts=None):
    d = (ts or {}).get("thu_muc") or os.path.join(HERE, "ket-qua", "tai_lo")
    os.makedirs(d, exist_ok=True)
    return d


def doc_hop_thu(ts=None, goc=HERE):
    """Gốc hộp thư LENH: /lenh: hoặc khoá "lenh" của AIHoaDon\\xii_erp_tram.json (tệp trạm và XII cùng đọc)."""
    v = (ts or {}).get("lenh") or ""
    if not v:
        try:
            with io.open(os.path.join(goc, "xii_erp_tram.json"), encoding="utf-8-sig") as f:
                v = str((json.load(f) or {}).get("lenh") or "")
        except Exception:
            v = ""
    v = v.strip().rstrip("\\/")
    return os.path.normpath(v) if v else ""


def ten_an_toan(s):
    return re.sub(r"[^A-Za-z0-9_\-]", "_", str(s or "")) or "_"


def mst_so(v):
    return re.sub(r"\D", "", str(v or ""))


def thu_muc_hoa_don(lenh, so, ky):
    """Nơi bước tai_hd của trạm đọc (AiInvoiceGate.FolderOf): <LENH>\\tep\\<sổ>\\<yyyy-mm>\\hoa_don"""
    return os.path.join(lenh, "tep", so, ky, "hoa_don")


def da_xac_nhan_khong_ps(lenh, so, ky):
    return bool(lenh) and os.path.isfile(os.path.join(thu_muc_hoa_don(lenh, so, ky), XAC_NHAN_KHONG_PS))


# ==========================================================================
#  KỲ / KHOẢNG NGÀY
# ==========================================================================
def ky_chuoi(nam, thang):
    return "%04d-%02d" % (int(nam), int(thang))


def khoang_ky(ky, hom_nay):
    """'2026-02' -> ('2026-02-01', '2026-02-28'); tháng hiện tại: đến hôm nay; tháng tương lai -> None."""
    m = re.match(r"^(\d{4})-(\d{2})$", str(ky or ""))
    if not m:
        return None
    y, mo = int(m.group(1)), int(m.group(2))
    if not 1 <= mo <= 12:
        return None
    dau = date(y, mo, 1)
    cuoi = (date(y + (mo == 12), mo % 12 + 1, 1) - timedelta(days=1))
    if dau > hom_nay:
        return None
    cuoi = min(cuoi, hom_nay)
    return dau.strftime("%Y-%m-%d"), cuoi.strftime("%Y-%m-%d")


def ds_thang(nam, hom_nay, tu_thang=None, den_thang=None):
    """Các tháng cần xét của một sổ năm `nam`: mặc định tháng 1 -> tháng TRƯỚC tháng hiện tại (tháng hiện tại chưa đủ);
    năm đã qua: cả 12 tháng; năm sau: không tháng nào."""
    try:
        nam = int(nam)
    except Exception:
        return []
    if nam <= 0 or nam > hom_nay.year:
        return []
    tran = 12 if nam < hom_nay.year else hom_nay.month          # không tra tháng chưa tới
    den = min(int(den_thang), tran) if den_thang else (12 if nam < hom_nay.year else hom_nay.month - 1)
    tu = max(1, int(tu_thang)) if tu_thang else 1
    return list(range(tu, den + 1))


# ==========================================================================
#  NGUỒN 1: BÁO CÁO ĐỐI CHIẾU CỦA TRẠM (DOI_CHIEU_HD_<kỳ>.csv, AiInvoiceGate.WriteReport)
# ==========================================================================
def doc_doi_chieu(duong):
    try:
        with io.open(duong, encoding="utf-8-sig") as f:
            dong = f.read().splitlines()
    except Exception:
        return None
    if not dong:
        return None
    kl = re.search(r"ket luan:\s*([A-Z_]+)", dong[0])
    luc = re.search(r"luc\s+(\d{2}/\d{2}/\d{4} \d{2}:\d{2})", dong[0])
    ra = {"ket_luan": kl.group(1) if kl else "", "luc": luc.group(1) if luc else ""}
    dau = None
    for d in dong[1:]:
        o = d.split(";")
        if o and o[0] == "Chieu" and len(o) > 1 and o[1] == "HDDT":
            dau = o
            continue
        if dau and o and o[0] in ("MUA", "BAN") and len(o) == len(dau):
            s = {}
            for k, v in zip(dau[1:], o[1:]):
                try:
                    s[k] = int(float(v or 0))
                except Exception:
                    s[k] = 0
            ra[o[0]] = s
        elif o and o[0] == "Chieu" and len(o) > 1 and o[1] == "Loai":
            break
    return ra if ra["ket_luan"] else None


def huong_tu_doi_chieu(dc):
    """-> (thiếu?, hướng 'mua'|'ban'|'ca', lý do)"""
    kl = dc.get("ket_luan") or ""
    if kl in ("DU", "KHONG_PHAT_SINH"):
        return False, "", ""
    chieu = []
    trong = lambda s: s.get("HDDT", 0) == 0 and s.get("BangKe", 0) == 0 and s.get("DongThue", 0) == 0          # noqa: E731
    for ma, h in (("MUA", "mua"), ("BAN", "ban")):
        s = dc.get(ma) or {}
        khac = dc.get("BAN" if ma == "MUA" else "MUA") or {}
        if (s.get("HDDT", 0) == 0 and (s.get("BangKe", 0) > 0 or s.get("DongThue", 0) > 0)) \
                or s.get("ThieuDauHD", 0) > 0 or s.get("BKKhongHDDT", 0) > 0 \
                or (trong(s) and not trong(khac)):          # P0 18/11/2026: chiều trống chưa có bằng chứng cổng -> tra chiều đó
            chieu.append(h)
    huong = chieu[0] if len(chieu) == 1 else "ca"
    return True, huong, "trạm đối chiếu lúc %s: %s" % (dc.get("luc") or "?", TEN_KET_LUAN.get(kl, kl))


# ==========================================================================
#  NGUỒN 2: SỐ LIỆU SỔ (tai_hoa_don_theo_lo_doc_so.ps1, chỉ SELECT)
# ==========================================================================
def chieu_co_bang_chung(thu_muc):
    """P0 18/11/2026: các chiều của tháng đã có bằng chứng 'không phát sinh' trong thư mục hoá đơn của tháng (như AiInvoiceGate đọc):
    khong_phat_sinh_mua.txt / khong_phat_sinh_ban.txt của kế toán, hoặc cong_thue_da_tra.json (lô đã tra đủ, chiều đó 0 HĐ)."""
    ra = set()
    for h in ("mua", "ban"):
        if os.path.isfile(os.path.join(thu_muc, "khong_phat_sinh_%s.txt" % h)):
            ra.add(h)
    try:
        with io.open(os.path.join(thu_muc, TEP_BANG_CHUNG_CONG), encoding="utf-8-sig") as f:
            j = json.load(f)
        for h in ("mua", "ban"):
            v = j.get(h) if isinstance(j, dict) else None
            if isinstance(v, dict) and v.get("du") is True and v.get("tong") == 0:
                ra.add(h)
    except Exception:
        pass
    return ra


def huong_tu_so_lieu(s, bang_chung=None):
    """Cách chốt của AiInvoiceGate, bản gọn (không xét MST khi khớp bảng kê, không xét ngoai_hddt.txt).
    s = {e_mua, e_ban, td_mua, td_ban, bk_mua, bk_ban, bkk_mua, bkk_ban, vat_mua, vat_ban} -> (thiếu?, hướng, lý do)
    bang_chung (P0 18/11/2026) = các chiều đã có bằng chứng 'không phát sinh' (chieu_co_bang_chung): chiều trống mà chiều kia có số liệu
    chỉ được bỏ qua khi có bằng chứng (trước đây luôn coi là không phát sinh)."""
    g = lambda k: int((s or {}).get(k) or 0)  # noqa: E731
    if g("e_mua") + g("e_ban") + g("bk_mua") + g("bk_ban") + g("vat_mua") + g("vat_ban") == 0:
        return True, "ca", "chưa có hoá đơn điện tử, bảng kê, dòng thuế - chưa xác nhận không phát sinh"
    bang_chung = set(bang_chung or ())
    chieu, ly_do = [], []
    for h, ten in (("mua", "mua vào"), ("ban", "bán ra")):
        if g("e_" + h) + g("bk_" + h) + g("vat_" + h) == 0:
            if h not in bang_chung:
                chieu.append(h)
                ly_do.append("%s trống, chưa có bằng chứng cổng thuế không có HĐ" % ten)
        elif g("e_" + h) == 0 and (g("bk_" + h) > 0 or g("vat_" + h) > 0):
            chieu.append(h)
            ly_do.append("%s chưa tải (bảng kê %d HĐ, %d dòng thuế)" % (ten, g("bk_" + h), g("vat_" + h)))
        elif g("td_" + h) > 0:
            chieu.append(h)
            ly_do.append("%s %d HĐ thiếu phần đầu" % (ten, g("td_" + h)))
        elif g("bkk_" + h) > 0:
            chieu.append(h)
            ly_do.append("%s %d HĐ trên bảng kê chưa có HĐ điện tử" % (ten, g("bkk_" + h)))
    if not chieu:
        return False, "", ""
    return True, ("ca" if len(chieu) == 2 else chieu[0]), "; ".join(ly_do)


def doc_so_sql(may_chu, ds_so, ra_json, chay=subprocess.run):
    """Chạy tai_hoa_don_theo_lo_doc_so.ps1 (CHỈ ĐỌC). -> (dict số liệu | None, lỗi)"""
    lenh = ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", os.path.join(HERE, TEP_DOC_SO),
            "-Server", may_chu or ".\\SQLEXPRESS", "-Out", ra_json]
    if ds_so:
        lenh += ["-Databases", ",".join(ds_so)]
    try:
        p = chay(lenh, capture_output=True, timeout=1800)
        out = (p.stdout or b"").decode("utf-8", "replace").strip()
    except Exception as e:
        return None, "không chạy được PowerShell đọc sổ: %s" % e
    if p.returncode != 0 or not os.path.isfile(ra_json):
        return None, (out.splitlines()[-1] if out else "đọc sổ không xong (mã %s)" % p.returncode)
    try:
        with io.open(ra_json, encoding="utf-8-sig") as f:
            return json.load(f), ""
    except Exception as e:
        return None, "không đọc được kết quả đọc sổ: %s" % e


# ==========================================================================
#  LẬP DANH SÁCH
# ==========================================================================
def lap_danh_sach(so_lieu, lenh, hom_nay, tu_thang=None, den_thang=None, huong_ep=""):
    """-> (dòng [{so, mst, ten, ten_dn, ky, huong, ly_do}], ghi chú [str] về sổ bị bỏ).
    Bỏ tháng: đã có khong_phat_sinh.txt; trạm đối chiếu ĐỦ / KHÔNG PHÁT SINH; số liệu sổ cho thấy đã đủ."""
    dong, ghi_chu = [], []
    for b in (so_lieu or {}).get("so") or []:
        so = str(b.get("so") or "")
        if b.get("loi"):
            ghi_chu.append("Sổ %s: %s - bỏ qua." % (so, b["loi"]))
            continue
        mst = str(b.get("mst") or "").strip() or str(b.get("hsk_mst") or "").strip()
        mst = re.sub(r"[^0-9\-]", "", mst)
        if not mst_so(mst):
            ghi_chu.append("Sổ %s: chưa có mã số thuế (License.MaSoThue / HSK_MST) - bỏ qua." % so)
            continue
        ten = str(b.get("hsk_ten") or "").strip() or str(b.get("ten") or "").strip() or so
        ten = re.sub(r"\s{2,}", " ", ten)
        thang_sl = b.get("thang") or {}
        for m in ds_thang(b.get("nam"), hom_nay, tu_thang, den_thang):
            ky = ky_chuoi(b["nam"], m)
            if da_xac_nhan_khong_ps(lenh, so, ky):
                continue
            dc = doc_doi_chieu(os.path.join(thu_muc_hoa_don(lenh, so, ky), "DOI_CHIEU_HD_%s.csv" % ky)) if lenh else None
            if dc:
                thieu, huong, ly_do = huong_tu_doi_chieu(dc)
            else:
                thieu, huong, ly_do = huong_tu_so_lieu(thang_sl.get(str(m)) or thang_sl.get(m) or {},
                                                       chieu_co_bang_chung(thu_muc_hoa_don(lenh, so, ky)) if lenh else None)
            if not thieu:
                continue
            dong.append({"so": so, "mst": mst, "ten": ten, "ten_dn": str(b.get("hsk_tendn") or "").strip(),
                         "ky": ky, "huong": huong_ep if huong_ep in ("mua", "ban", "ca") else huong, "ly_do": ly_do})
    return dong, ghi_chu


def ghi_danh_sach_csv(dong, duong):
    """CSV ';' có BOM (Excel tiếng Việt mở đúng). Cột Chon = x: chạy; xoá x (hoặc xoá dòng) để bỏ."""
    thu_tu = {}
    for d in dong:
        thu_tu.setdefault(mst_so(d["mst"]), len(thu_tu) + 1)
    tmp = duong + ".tmp"
    with io.open(tmp, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f, delimiter=";")
        w.writerow(COT_DANH_SACH)
        for d in dong:
            w.writerow(["x", thu_tu[mst_so(d["mst"])], d["so"], d["mst"], d["ten"], d.get("ten_dn", ""), d["ky"], d["huong"], d.get("ly_do", "")])
    os.replace(tmp, duong)
    return duong


def doc_danh_sach_csv(duong):
    """-> danh sách KHÁCH theo thứ tự trong tệp, gộp theo MST:
    [{mst, ten, ten_dn, viec: [{so, ky, huong}]}]. Chỉ dòng có Chon = x / 1 / c."""
    with io.open(duong, encoding="utf-8-sig") as f:
        noi_dung = f.read()
    dau = noi_dung.splitlines()[0] if noi_dung else ""
    dl = ";" if dau.count(";") >= dau.count(",") else ","
    khach, theo_mst = [], {}
    for r in csv.DictReader(io.StringIO(noi_dung), delimiter=dl):
        r = {str(k or "").strip(): str(v or "").strip() for k, v in r.items()}
        if r.get("Chon", "").lower() not in ("x", "1", "c", "có", "co"):
            continue
        mst = re.sub(r"[^0-9\-]", "", r.get("MST", ""))
        so, ky = r.get("So", ""), r.get("Ky", "")
        if not mst_so(mst) or not re.match(r"^[A-Za-z0-9_\-]{1,128}$", so) or not re.match(r"^\d{4}-(0[1-9]|1[0-2])$", ky):
            continue
        huong = r.get("Huong", "").lower()
        if huong not in ("mua", "ban", "ca"):
            huong = "ca"
        k = theo_mst.get(mst_so(mst))
        if k is None:
            k = {"mst": mst, "ten": r.get("TenKhach") or so, "ten_dn": r.get("TenDangNhap", ""), "viec": []}
            theo_mst[mst_so(mst)] = k
            khach.append(k)
        if not any(v["so"] == so and v["ky"] == ky for v in k["viec"]):
            k["viec"].append({"so": so, "ky": ky, "huong": huong})
    return khach


def bang_danh_sach(dong):
    """Bảng khách × tháng (một dòng mỗi sổ). M = mua vào, B = bán ra, C = cả hai."""
    ky_hieu = {"mua": "M", "ban": "B", "ca": "C"}
    nhom, thu_tu = {}, []
    for d in dong:
        k = (d["mst"], d["so"])
        if k not in nhom:
            nhom[k] = {"ten": d["ten"], "thang": {}}
            thu_tu.append(k)
        nhom[k]["thang"][int(d["ky"][5:7])] = ky_hieu.get(d["huong"], "C")
    ra = ["%-3s %-34s %-13s %-26s %s  %s" % ("STT", "Khách", "MST", "Sổ", " ".join("T%-2d" % m for m in range(1, 13)), "Số tháng")]
    stt_mst = {}
    for (mst, so) in thu_tu:
        stt_mst.setdefault(mst, len(stt_mst) + 1)
        g = nhom[(mst, so)]
        o = " ".join("%-3s" % g["thang"].get(m, "·") for m in range(1, 13))
        ra.append("%-3s %-34s %-13s %-26s %s  %d" % (stt_mst[mst], g["ten"][:34], mst, so[:26], o, len(g["thang"])))
    ra.append("Ký hiệu: C = tải cả mua vào và bán ra · M = chỉ mua vào · B = chỉ bán ra · · = không cần tải / ngoài kỳ xét")
    ra.append("Tổng: %d khách (theo MST), %d sổ, %d tháng-sổ cần tải." % (len(stt_mst), len(thu_tu), len(dong)))
    return "\n".join(ra)


# ==========================================================================
#  SỔ TIẾN ĐỘ (chạy lại trong ngày: bỏ qua tháng đã xong hôm nay)
# ==========================================================================
class SoTienDo:
    # Đợt 5 (chủ quyết 18/11/2026 «lô nhớ nhiều ngày»): tháng đã tra ĐỦ cả HĐ điện tử + máy tính tiền được nhớ SO_NGAY_NHO ngày, hôm sau
    # không tra lại; THÁNG HIỆN TẠI và THÁNG TRƯỚC luôn tra lại (bắt HĐ đến muộn / đổi trạng thái). Mỗi ngày vẫn một tệp tien_do_<ngày>.jsonl.
    SO_NGAY_NHO = 7

    def __init__(self, thu_muc, hom_nay, so_ngay_nho=None):
        self.thu_muc = thu_muc
        self.hom_nay = hom_nay
        self.so_ngay_nho = self.SO_NGAY_NHO if so_ngay_nho is None else max(1, int(so_ngay_nho))
        self.duong = os.path.join(thu_muc, "tien_do_%s.jsonl" % hom_nay.strftime("%Y%m%d"))
        self.khoa = threading.Lock()

    @staticmethod
    def _doc_tep(duong):
        ra = []
        try:
            with io.open(duong, encoding="utf-8") as f:
                for d in f:
                    d = d.strip()
                    if d:
                        try:
                            ra.append(json.loads(d))
                        except Exception:
                            pass
        except FileNotFoundError:
            pass
        return ra

    def doc(self):
        return self._doc_tep(self.duong)

    def doc_nhieu_ngay(self):
        """Bản ghi của so_ngay_nho ngày gần nhất (cũ trước, hôm nay sau cùng - lần ghi sau thắng)."""
        ra = []
        for i in range(self.so_ngay_nho - 1, -1, -1):
            ngay = self.hom_nay - timedelta(days=i)
            ra.extend(self._doc_tep(os.path.join(self.thu_muc, "tien_do_%s.jsonl" % ngay.strftime("%Y%m%d"))))
        return ra

    def nho_qua_ngay(self, ky):
        """Kỳ 'yyyy-mm' cũ hơn tháng trước của hôm nay -> được dùng kết quả các ngày trước."""
        try:
            y, m = int(str(ky)[:4]), int(str(ky)[5:7])
        except Exception:
            return False
        return y * 12 + m <= self.hom_nay.year * 12 + self.hom_nay.month - 2

    def ghi(self, ban_ghi):
        ban_ghi = dict(ban_ghi)
        ban_ghi.setdefault("luc", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        with self.khoa:
            with io.open(self.duong, "a", encoding="utf-8") as f:
                f.write(json.dumps(ban_ghi, ensure_ascii=False) + "\n")

    def da_xong(self, so, ky, huong, loai=None):
        """Tháng đã xong HÔM NAY: lần ghi cuối của (sổ, kỳ) có trạng thái xong / cổng không có HĐ và đã phủ hướng cần.
        loai (P0 18/11/2026) = các loại HĐ phải đã tra ('dt', 'mtt'): mỗi loại xét lần ghi cuối CÓ loại đó. Bản ghi cũ không có
        trường 'loai' thì không phủ loại nào (chạy lại cho chắc). loai=None: không xét loại (cách cũ)."""
        if not loai:
            cuoi = None
            for b in self.doc():
                if b.get("so") == so and b.get("ky") == ky and b.get("huong") in (huong, "ca"):
                    cuoi = b
            return bool(cuoi) and cuoi.get("trang_thai") in TRANG_THAI_XONG
        cuoi = {}
        for b in (self.doc_nhieu_ngay() if self.nho_qua_ngay(ky) else self.doc()):          # đợt 5: tháng cũ nhớ nhiều ngày
            if b.get("so") == so and b.get("ky") == ky and b.get("huong") in (huong, "ca"):
                for kind in (b.get("loai") or []):
                    cuoi[kind] = b
        return all(kind in cuoi and cuoi[kind].get("trang_thai") in TRANG_THAI_XONG for kind in loai)


# ==========================================================================
#  TỆP ĐÃ CÓ (trong thư mục tháng hoặc đã được trạm nhập, nằm ở hoa_don\da_nhap\<lúc>\)
# ==========================================================================
def xml_loi(p):
    """P1 18/11/2026: '' khi tệp XML đọc được (không rỗng, không cắt dở, không phải trang HTML, không DOCTYPE); ngược lại lý do."""
    import xml.etree.ElementTree as ET
    try:
        if os.path.getsize(p) == 0:
            return "tệp rỗng (0 byte)"
        if os.path.getsize(p) > 20 * 1024 * 1024:
            return "tệp quá lớn"
        with open(p, "rb") as f:
            b = f.read()
        if b"<!DOCTYPE" in b[:4096].upper() or b"<!ENTITY" in b[:4096].upper():
            return "XML có DOCTYPE / ENTITY"
        goc = ET.fromstring(b)
        if goc.tag.rsplit("}", 1)[-1].lower() in ("html", "body", "head"):
            return "trang HTML, không phải hoá đơn"
        return ""
    except Exception as e:
        return "XML hỏng / bị cắt dở (%s)" % str(e)[:80]


def cach_ly(p, ly_do):
    """Chuyển tệp hỏng sang <thư mục>\\cach_ly\\ (KHÔNG xoá) kèm lý do; trạm không đọc thư mục con này."""
    try:
        d = os.path.join(os.path.dirname(p), "cach_ly")
        os.makedirs(d, exist_ok=True)
        moi = os.path.join(d, "%s.%s" % (os.path.basename(p), datetime.now().strftime("%Y%m%d_%H%M%S")))
        os.replace(p, moi)
        with io.open(moi + ".ly_do.txt", "w", encoding="utf-8") as f:
            f.write("%s\n%s\nLô tải lại hoá đơn này ở lần chạy sau.\n" % (p, ly_do))
        return moi
    except Exception:
        return ""


TEP_BANG_CHUNG_CONG = "cong_thue_da_tra.json"


def ghi_bang_chung_cong(thu_muc, so_hd_theo_chieu, luc=None):
    """P0 18/11/2026: <LENH>\\tep\\<sổ>\\<kỳ>\\hoa_don\\cong_thue_da_tra.json - {"phien_ban_khuon": 1, "mua"|"ban": {"tong", "du", "luc",
    "nguon"}}: chiều đã tra cổng thuế ĐỦ (cả hai loại HĐ, không cảnh báo) và số HĐ cổng trả. XII (AiInvoiceGate) đọc để biết chiều trống
    là 'cổng không có HĐ' chứ không phải 'chưa tải'. Ghi nguyên tử, gộp với chiều đã ghi trước."""
    os.makedirs(thu_muc, exist_ok=True)
    p = os.path.join(thu_muc, TEP_BANG_CHUNG_CONG)
    cu = {}
    try:
        with io.open(p, encoding="utf-8-sig") as f:
            cu = json.load(f)
        if not isinstance(cu, dict):
            cu = {}
    except Exception:
        cu = {}
    luc = (luc or datetime.now()).strftime("%Y-%m-%d %H:%M:%S")
    cu["phien_ban_khuon"] = 1
    for h, n in so_hd_theo_chieu.items():
        cu[h] = {"tong": int(n), "du": True, "luc": luc, "nguon": "TAI_HOA_DON_THEO_LO", "loai": list(LOAI_DU)}
    tam = p + ".tmp"
    with io.open(tam, "w", encoding="utf-8") as f:
        json.dump(cu, f, ensure_ascii=False, indent=1, sort_keys=True)
    os.replace(tam, p)
    return p


def ten_da_co(thu_muc):
    co = set()
    if not os.path.isdir(thu_muc):
        return co
    for ten in os.listdir(thu_muc):
        if ten.lower().endswith(".xml"):
            p = os.path.join(thu_muc, ten)
            ly_do = xml_loi(p) if os.path.isfile(p) else "không phải tệp"
            if ly_do:          # P1 18/11/2026: tệp dở / hỏng không được coi là 'đã có' (trước đây chỉ so tên) -> cách ly, tải lại
                cach_ly(p, ly_do)
                continue
            co.add(ten[:-4].lower())
    dn = os.path.join(thu_muc, "da_nhap")
    if os.path.isdir(dn):
        for goc, _, tep in os.walk(dn):
            for ten in tep:
                if ten.lower().endswith(".xml"):
                    co.add(ten[:-4].lower())
    return co


# ==========================================================================
#  HOÁ ĐƠN KHÔNG CÓ XML GỐC -> CSV 36 cột "mẫu 1" trong hoa_don\mua | hoa_don\ban (bước tai_hd của trạm đã đọc *.csv ở đó)
# ==========================================================================
def so_csv(v):
    """Số -> chuỗi mà hd_excel_ai.so đọc lại đúng: không dấu nghìn, dấu chấm thập phân, KHÔNG BAO GIỜ đúng 3 chữ số lẻ
    ('12.345' sẽ bị hiểu là 12345)."""
    if v is None or v == "" or isinstance(v, bool):
        return ""
    try:
        x = float(v)
    except (TypeError, ValueError):
        return str(v)
    if x == int(x) and abs(x) < 1e15:
        return "%d" % int(x)
    s = ("%.6f" % x).rstrip("0")
    if len(s.split(".")[1]) == 3:
        s += "0"
    return s


def khoa_dong(d):
    """Khoá hoá đơn của một dòng mẫu 1: <MST bán>|<mẫu số>|<ký hiệu>|<số> (cùng dạng khoá của tool tải)."""
    return "|".join(str(d.get(c) or "").strip() for c in ("MSTNguoiBanNguoiXuatHang", "KyHieuMauSo", "KyHieuHoaDon", "SoHoaDon")).upper()


def doc_csv_mau1(duong):
    try:
        with io.open(duong, encoding="utf-8-sig", newline="") as f:
            return [dict(r) for r in csv.DictReader(f, delimiter=";")]
    except Exception:
        return []


def khoa_khong_xml_da_ghi(thu_muc_hd, huong):
    """Khoá các hoá đơn đã nằm trong mọi tệp KHONG_XML_GOC_*.csv của hướng này (đang chờ + đã được trạm chuyển vào da_nhap)."""
    d = os.path.join(thu_muc_hd, "ban" if huong == "ban" else "mua")
    co = set()
    if os.path.isdir(d):
        for goc, _, tep in os.walk(d):
            for t in tep:
                if t.startswith(TIEN_TO_KHONG_XML) and t.lower().endswith(".csv"):
                    co.update(khoa_dong(r) for r in doc_csv_mau1(os.path.join(goc, t)))
    return co


def ghi_khong_xml(thu_muc_hd, ky, huong, kind, dong):
    """Ghi các dòng hoá đơn không có XML gốc vào <hoa_don>\\<mua|ban>\\KHONG_XML_GOC_<kỳ>_<hướng>_<loại>.csv.
    Không ghi hai lần một hoá đơn: bỏ hoá đơn đã nằm trong tệp KHONG_XML_GOC_* khác đang chờ hoặc đã được trạm nhập
    (<mua|ban>\\da_nhap\\<lúc>\\); tệp cùng tên đang chờ thì gộp thêm hoá đơn mới.
    -> (đường tệp | '', số HĐ mới ghi, số HĐ đã ghi trước)."""
    ten_huong = "ban" if huong == "ban" else "mua"
    d = os.path.join(thu_muc_hd, ten_huong)
    duong = os.path.join(d, "%s%s_%s_%s.csv" % (TIEN_TO_KHONG_XML, ky, ten_huong, kind))
    cu = doc_csv_mau1(duong) if os.path.isfile(duong) else []
    da_ghi = set(khoa_dong(r) for r in cu)
    if os.path.isdir(d):
        for goc, _, tep in os.walk(d):
            for t in tep:
                p = os.path.join(goc, t)
                if t.startswith(TIEN_TO_KHONG_XML) and t.lower().endswith(".csv") and os.path.normcase(p) != os.path.normcase(duong):
                    da_ghi.update(khoa_dong(r) for r in doc_csv_mau1(p))
    moi, khoa_moi, khoa_cu = [], set(), set()
    for r in dong:
        k = khoa_dong(r)
        if k in da_ghi:
            khoa_cu.add(k)
        else:
            khoa_moi.add(k)
            moi.append(r)
    if not moi:
        return (duong if cu else ""), 0, len(khoa_cu)
    os.makedirs(d, exist_ok=True)
    tam = duong + ".tmp"          # đuôi .tmp: trạm chỉ đọc *.xlsx / *.xls / *.csv nên không bao giờ thấy tệp ghi dở
    with io.open(tam, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f, delimiter=";", quoting=csv.QUOTE_ALL)
        w.writerow(COT_MAU1)
        for r in cu + moi:
            w.writerow([so_csv(r.get(c)) if c in COT_SO_MAU1 else ("" if r.get(c) is None else str(r.get(c))) for c in COT_MAU1])
    os.replace(tam, duong)
    try:
        with io.open(os.path.join(d, TEP_GHI_CHU_KHONG_XML), "w", encoding="utf-8-sig") as f:
            f.write("Các tệp %s*.csv trong thư mục này (và trong da_nhap) do công cụ Tải hoá đơn theo lô ghi.\n"
                    "NGUỒN: %s.\n"
                    "Đây KHÔNG phải XML gốc có chữ ký số: cổng thuế không giữ XML gốc của các hoá đơn này (điện, nước, ngân hàng…).\n"
                    "Trạm nhập như bảng kê Excel (nguồn \"bangke\"); khi nào tải được XML gốc thì XML thay cho dòng bảng kê.\n"
                    % (TIEN_TO_KHONG_XML, NGUON_KHONG_XML))
    except Exception:
        pass
    return duong, len(khoa_moi), len(khoa_cu)


# ==========================================================================
#  ĐỀ NGHỊ GHI SỔ: <LENH>\de_nghi\<sổ>.<kỳ>.tai_hd.de_nghi.json - ERP nhặt rồi ra lệnh tai_hd cho trạm theo đường lệnh thường
# ==========================================================================
def tep_cho_nhap(thu_muc_hd):
    """Số tệp đang chờ bước tai_hd nhập: *.xml / *.zip trong hoa_don, *.xlsx / *.xls / *.csv trong hoa_don\\mua và \\ban."""
    n = 0
    for d, duoi in ((thu_muc_hd, (".xml", ".zip")), (os.path.join(thu_muc_hd, "mua"), (".xlsx", ".xls", ".csv")),
                    (os.path.join(thu_muc_hd, "ban"), (".xlsx", ".xls", ".csv"))):
        if os.path.isdir(d):
            n += sum(1 for t in os.listdir(d) if t.lower().endswith(duoi) and os.path.isfile(os.path.join(d, t)))
    return n


def dem_de_nghi_cho(lenh):
    """Số tệp đề nghị ghi sổ còn nằm chờ (cầu nối chưa đọc; tệp đã đọc được chuyển sang thư mục con)."""
    d = os.path.join(lenh, THU_MUC_DE_NGHI)
    try:
        return len([t for t in os.listdir(d) if t.lower().endswith(".de_nghi.json") and os.path.isfile(os.path.join(d, t))])
    except OSError:
        return 0


def ghi_de_nghi(lenh, so, ky, luc, thong_tin=None):
    """Ghi (nguyên tử) một đề nghị chạy bước tai_hd cho (sổ, kỳ). Lô KHÔNG tự đặt lệnh vào LENH\\cho và KHÔNG ghi sổ:
    đề nghị chỉ là tệp để ERP đọc, ERP tạo lệnh như mọi lệnh khác nên mọi chốt của ERP và của trạm giữ nguyên."""
    d = os.path.join(lenh, THU_MUC_DE_NGHI)
    os.makedirs(d, exist_ok=True)
    duong = os.path.join(d, "%s.%s.tai_hd.de_nghi.json" % (ten_an_toan(so), ky))
    nd = {"phien_ban_khuon": 1, "loai": "de_nghi_ghi_so", "so": so, "ky": ky, "buoc": ["tai_hd"], "nguon": NGUON_DE_NGHI,
          "luc": luc.strftime("%Y-%m-%d %H:%M:%S"),
          "khoa_chong_trung": "%s|%s|%s|tai_hd|%s" % (NGUON_DE_NGHI, so, ky, luc.strftime("%Y%m%d-%H%M%S")),
          "ly_do": "Tải hoá đơn theo lô vừa tải đủ hoá đơn của tháng - đề nghị chạy bước Tải hoá đơn để nhập vào sổ"}
    nd.update(thong_tin or {})
    tam = duong + ".tmp"
    with io.open(tam, "w", encoding="utf-8") as f:
        json.dump(nd, f, ensure_ascii=False, indent=1)
    os.replace(tam, duong)
    return duong


# ==========================================================================
#  BÀN PHÍM: B = bỏ qua khách, D = dừng, M = mở lại Chrome
# ==========================================================================
class BanPhim:
    def __init__(self):
        self.tam_dung = threading.Event()          # đang hỏi captcha HĐ máy tính tiền: không đọc phím

    def doc(self):
        if self.tam_dung.is_set():
            return None
        try:
            import msvcrt
        except Exception:
            return None
        ky = None
        try:
            while msvcrt.kbhit():
                c = msvcrt.getwch()
                if c and c.upper() in ("B", "D", "M", "X"):          # X = người xác nhận đúng tài khoản khi phiên không đọc được MST
                    ky = c.upper()
        except Exception:
            return None
        return ky


# ==========================================================================
#  CỔNG THUẾ THẬT: lái tool_tai_hoa_don_unesco.py (nạp như thư viện, KHÔNG sửa tệp tool)
# ==========================================================================
def nap_tool():
    luu = sys.argv
    sys.argv = [os.path.join(HERE, TEN_TOOL)]          # tool đọc /unesco /mst ... của sys.argv lúc nạp: không để lẫn tham số lô
    try:
        if HERE not in sys.path:
            sys.path.insert(0, HERE)
        import tool_tai_hoa_don_unesco as T
    finally:
        sys.argv = luu
    return T


class CongThueThat:
    """Bọc các hàm có sẵn của tool: chrome_mo_trang_thue (Chrome thật, hồ sơ riêng theo MST, người đăng nhập + captcha),
    trạng thái phiên CHROME, tra_cuu (chia khoảng ngày), chay_tai (tải XML từng hoá đơn). Chế độ UNESCO của tool TẮT
    (UNESCO['bat'] = False): không ghi JSONL vào thư mục khách của XII - hoá đơn vào sổ qua bước tai_hd của trạm."""

    def __init__(self, T, thu_muc_lo, phim=None, hoi=input, in_ra=print, bo_mtt_luon=False, dung_lai_captcha=False):
        self.T = T
        # Dùng lại mã captcha HĐ máy tính tiền cho các trang sau của CÙNG một lần tìm (/mtt_dung_lai:co). Mặc định TẮT: chưa
        # biết trang web cổng thuế có tự làm vậy không - chỉ bật khi đã thấy trang web hỏi mã MỘT lần cho cả lần tìm.
        self.cho_dung_lai = bool(dung_lai_captcha)
        self.dung_lai = None                       # None = chưa thử, True = cổng nhận, False = cổng từ chối -> thôi hẳn trong lô
        self.cap_cuoi = None                       # (ckey, mã người gõ, nhóm, trang) - lần gõ gần nhất của lần tìm đang chạy
        self._vua_dung_lai = False
        self.dem_cap = {"hoi": 0, "dung_lai": 0}   # số lần NGƯỜI gõ / số trang dùng lại mã, của khách đang làm
        self.lo = thu_muc_lo
        self.phim = phim
        self.hoi = hoi
        self.in_ra = in_ra
        self.du_lieu = thu_muc_lo
        self.bo_mtt_luon = bo_mtt_luon          # /mtt:bo - không hỏi captcha HĐ máy tính tiền (tháng ghi 'một phần' nếu cổng đòi)
        self.bo_mtt = bo_mtt_luon
        self.ten_khach = ""
        T.UNESCO["bat"] = False
        T._thu_muc_du_lieu = lambda: self.du_lieu          # da-tai.json / khoa-ban-le.json riêng từng khách trong thư mục lô
        T.xin_captcha_mtt = self._xin_captcha_mtt          # captcha HĐ máy tính tiền: NGƯỜI gõ ở cửa sổ lô

    def chuan_bi(self, khach):
        self.dong()
        T = self.T
        mst = re.sub(r"[^0-9\-]", "", khach["mst"])
        T.UNESCO["mst"] = mst                              # chrome_ho_so_cho(MST): hồ sơ Chrome riêng của khách (không đụng cai-dat.json)
        self.du_lieu = os.path.join(self.lo, "khach", ten_an_toan(mst))
        os.makedirs(self.du_lieu, exist_ok=True)
        self.bo_mtt = self.bo_mtt_luon
        self.ten_khach = khach.get("ten") or mst
        self.cap_cuoi, self._vua_dung_lai = None, False
        self.dem_cap = {"hoi": 0, "dung_lai": 0}
        T.CHO_CAPTCHA_MTT.update(can=False, bo_qua=False, cho=False)

    def mo(self):
        return self.T.chrome_mo_trang_thue()

    def trang_thai(self):
        return self.T.CHROME.get("trang_thai") or "", self.T.CHROME.get("loi") or ""

    def mst_dang_nhap(self):
        return self.T.CHROME.get("mst") or self.T.STATE.get("mst") or ""

    def hien(self):
        try:
            self.T._chrome_cua_so("normal")
        except Exception:
            pass

    def tra_cuu(self, tu, den, huong, kind):
        T = self.T
        T.CHO_CAPTCHA_MTT["bo_qua"] = self.bo_mtt
        self.cap_cuoi, self._vua_dung_lai = None, False          # mã của lần tìm trước KHÔNG bao giờ mang sang lần tìm khác
        rows, loi = T.tra_cuu({"tu_ngay": tu, "den_ngay": den, "kind": kind, "direction": huong})
        if self._vua_dung_lai:
            self.dung_lai = True
        self.cap_cuoi, self._vua_dung_lai = None, False
        return rows, loi, list(T.TRA_CUU_CANH_BAO)

    def captcha_mtt(self):
        """(số lần người gõ mã, số trang dùng lại mã) của khách đang làm."""
        return self.dem_cap.get("hoi", 0), self.dem_cap.get("dung_lai", 0)

    # ---------------- hoá đơn không có XML gốc
    def khoa(self, hd):
        return self.T.khoa_cua(hd)

    def khong_xml_da_biet(self):
        """Khoá các hoá đơn mà tool đã ghi nhận 'cổng thuế không có XML gốc' (da-tai.json của khách trong thư mục lô)."""
        try:
            with io.open(os.path.join(self.du_lieu, "da-tai.json"), encoding="utf-8") as f:
                so = json.load(f)
        except Exception:
            return set()
        return set(k for k, v in so.items() if isinstance(v, dict) and v.get("khong_xml")) if isinstance(so, dict) else set()

    def dong_khong_xml(self, rows, huong, kind):
        """Dòng 'mẫu 1' của các hoá đơn không có XML gốc, lấy từ DỮ LIỆU CHI TIẾT của cổng thuế (đường có sẵn của tool, cùng
        phiên người đã đăng nhập). Cổng không trả chi tiết -> một dòng tổng của hoá đơn (từ kết quả tra cứu).
        -> (dòng, số HĐ chỉ có dòng tổng, bị chặn)."""
        T = self.T
        dong, chi_tong = [], 0
        for hd in rows:
            ds = None
            try:
                ds = T.unesco_chi_tiet_tu_cong(hd, kind)
            except Exception:
                ds = None
            if T.LY_DO_TAI.get("bi_chan"):
                return dong, chi_tong, True
            d = []
            if ds:
                try:
                    d = T.unesco_dong_tu_chi_tiet(hd, ds, huong, kind) or []
                except Exception:
                    d = []
            if not d:
                chi_tong += 1
                d = T.unesco_dong_tu_cong(hd, huong, kind) or []
            dong.extend(d)
        return dong, chi_tong, False

    def tai(self, rows, kind, huong, thu_muc):
        T = self.T
        os.makedirs(thu_muc, exist_ok=True)
        T.chay_tai(list(rows), kind, huong, thu_muc, ["xml"], False)
        t = T.STATE["tai"]
        return {"tong": t.get("tong", 0), "xong": t.get("xong", 0), "ok": t.get("ok", 0), "bo_qua": t.get("bo_qua", 0),
                "loi": t.get("loi", 0), "khong_xml": t.get("khong_xml", 0), "bi_chan": bool(t.get("bi_chan")), "dung": bool(t.get("dung"))}

    def dung(self):
        try:
            self.T.STATE["tai"]["dung"] = True
        except Exception:
            pass

    def ten_tep(self, hd, huong):
        return self.T.ten_file(hd, huong)

    def dong(self):
        """Đóng Chrome trang thuế của khách vừa xong (Chrome lưu hồ sơ bình thường) và quên phiên."""
        T = self.T
        try:
            if T.CHROME.get("cong"):
                T._chrome_dong_han()
        except Exception:
            pass
        k = T.CHROME.get("kenh")
        if k is not None:
            try:
                k.dong()
            except Exception:
                pass
        T.CHROME.update(kenh=None, tab_id="", trang_thai="chua_mo", loi="", mst="", cong=0, tien_trinh=None,
                        header_mau=None, nhan_token=False, tk_moi_nhat="", tk_cu=set(), menu_xong=False, co_yc_moi=False)
        T.CHROME["the_he"] = T.CHROME.get("the_he", 0) + 1          # luồng chờ / theo dõi của khách cũ tự dừng
        T.STATE["token"] = ""
        T.STATE["mst"] = ""

    def _xin_captcha_mtt(self, mo_ta, loi_truoc=""):
        """Cổng thuế bắt captcha cho từng trang tra cứu HĐ máy tính tiền: hiện ảnh captcha trong trình duyệt, NGƯỜI gõ mã
        vào cửa sổ lô. Enter trống = bỏ qua HĐ máy tính tiền của khách này (tháng ghi 'một phần')."""
        T = self.T
        if self.bo_mtt:
            return None, None
        m = re.match(r"^(.*) - trang (\d+)$", mo_ta or "")
        nhom, trang = (m.group(1), int(m.group(2))) if m else (mo_ta, 0)
        if loi_truoc:
            if self._vua_dung_lai:
                self.dung_lai = False              # cổng KHÔNG nhận mã dùng lại: thôi hẳn trong lô này, không thử lần nào nữa
                self.dem_cap["dung_lai"] = max(0, self.dem_cap["dung_lai"] - 1)
                self.in_ra("  Cổng thuế không nhận dùng lại mã cho trang sau - từ giờ mỗi trang hỏi một mã mới.")
            self.cap_cuoi = None                   # mã đã bị cổng từ chối: KHÔNG BAO GIỜ gửi lại
        elif self._vua_dung_lai:
            self.dung_lai = True
        self._vua_dung_lai = False
        c = self.cap_cuoi
        if self.cho_dung_lai and self.dung_lai is not False and not loi_truoc and c and trang > 1 and c[2] == nhom and c[3] == trang - 1:
            self.cap_cuoi = (c[0], c[1], nhom, trang)
            self._vua_dung_lai = True
            self.dem_cap["dung_lai"] += 1
            return c[0], c[1]
        anh, loi = T.lay_captcha()
        if loi or not anh:
            self.in_ra("  Không lấy được ảnh captcha HĐ máy tính tiền: %s" % (loi or "trống"))
            return None, None
        tep = os.path.join(self.lo, "captcha_may_tinh_tien.html")
        try:
            with io.open(tep, "w", encoding="utf-8") as f:
                f.write("<!doctype html><meta charset='utf-8'><title>Mã captcha – hoá đơn máy tính tiền</title>"
                        "<body style='font:16px sans-serif;padding:24px'><p><b>%s</b> – %s</p><div style='background:#fff;display:inline-block;"
                        "padding:8px;border:1px solid #999'>%s</div><p>Gõ mã trong ảnh vào cửa sổ đen “Tải hoá đơn theo lô” rồi bấm Enter."
                        "</p></body>" % (_html(self.ten_khach), _html(mo_ta), anh))
            os.startfile(tep)
        except Exception as e:
            self.in_ra("  Không mở được ảnh captcha (%s) - mở tay tệp %s" % (e, tep))
        if self.phim is not None:
            self.phim.tam_dung.set()
        try:
            s = self.hoi("  Mã captcha HĐ máy tính tiền (%s)%s – gõ mã rồi Enter (Enter trống = bỏ qua HĐ máy tính tiền của khách này): "
                         % (mo_ta, (" – " + loi_truoc) if loi_truoc else ""))
        except Exception:
            s = ""
        finally:
            if self.phim is not None:
                self.phim.tam_dung.clear()
            try:
                os.remove(tep)
            except Exception:
                pass
        s = (s or "").strip()
        if not s:
            self.bo_mtt = True
            return None, None
        self.dem_cap["hoi"] += 1
        self.cap_cuoi = (T.STATE.get("ckey"), s, nhom, trang)
        return T.STATE.get("ckey"), s


def _html(s):
    return str(s or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


# ==========================================================================
#  CHẠY LÔ
# ==========================================================================
class ChayLo:
    def __init__(self, cong, khach, lenh, thu_muc_lo, hom_nay, phim=None, in_ra=print, loai=("dt", "mtt"),
                 cho_toi_da=20 * 60, ngu=time.sleep, gio=time.time, tu_ghi=True):
        self.cong = cong
        self.tu_ghi = bool(tu_ghi)          # tháng tải đủ + có tệp chờ nhập -> ghi tệp đề nghị ghi sổ (LENH\de_nghi)
        self.de_nghi = []                   # đường các tệp đề nghị đã ghi trong lần chạy này
        self.mtt_san = {}                   # (kỳ, hướng) -> (rows, lỗi, cảnh báo): HĐ máy tính tiền đã tra dồn ở đầu khách
        self.cap_khach = (0, 0)             # (số lần người gõ captcha MTT, số trang dùng lại mã) của khách đang làm
        self.khach = khach
        self.lenh = lenh
        self.lo = thu_muc_lo
        self.hom_nay = hom_nay
        self.phim = phim
        self.in_ra = in_ra
        self.loai = list(loai)
        self.cho_toi_da = cho_toi_da
        self.ngu = ngu
        self.gio = gio
        self.so = SoTienDo(thu_muc_lo, hom_nay)
        self.dung = False
        self.bo_khach = False
        self.bi_chan = False
        self.ket_qua = []
        self.tep_ket_qua = os.path.join(thu_muc_lo, "ket_qua_%s.csv" % hom_nay.strftime("%Y%m%d"))
        self.tep_khong_co = os.path.join(thu_muc_lo, "THANG_KHONG_CO_HD_%s.txt" % hom_nay.strftime("%Y%m%d"))
        self.tep_dung = os.path.join(thu_muc_lo, "DUNG")

    def _giu_tep_ket_qua_cu(self):
        # Tệp kết quả cùng ngày do bản cũ tạo (tiêu đề khác): đổi tên giữ lại, không xoá, để dòng mới không lệch cột.
        if getattr(self, "_da_xem_tieu_de", False) or not os.path.exists(self.tep_ket_qua):
            self._da_xem_tieu_de = True
            return
        self._da_xem_tieu_de = True
        try:
            with io.open(self.tep_ket_qua, encoding="utf-8-sig") as f:
                dau = f.readline().rstrip("\r\n")
            if dau == ";".join(COT_KET_QUA):
                return
            goc_ten, duoi = os.path.splitext(self.tep_ket_qua)
            i = 1
            while os.path.exists("%s.ban_cu_%d%s" % (goc_ten, i, duoi)):
                i += 1
            os.rename(self.tep_ket_qua, "%s.ban_cu_%d%s" % (goc_ten, i, duoi))
        except (OSError, UnicodeError):
            pass

    # ---------------- phím / tệp DUNG
    def _xem_phim(self):
        k = self.phim.doc() if self.phim is not None else None
        if not self.dung and (k == "D" or os.path.exists(self.tep_dung)):
            self.dung = True
            self.cong.dung()
            self.in_ra("  >> Đã nhận lệnh DỪNG: dừng sau việc đang làm dở (hoá đơn đã tải vẫn giữ).")
        elif k == "B" and not self.bo_khach:
            self.bo_khach = True
            self.cong.dung()
            self.in_ra("  >> Bỏ qua khách này: chuyển sang khách sau (hoá đơn đã tải vẫn giữ).")
        return k

    def _nen(self, ham, *a):
        """Chạy việc dài (tra cứu / tải) ở luồng phụ, luồng chính vẫn nghe phím B / D."""
        kq = {}

        def _chay():
            try:
                kq["v"] = ham(*a)
            except Exception as e:          # lỗi bất ngờ của tool: ghi lại, không làm sập cả lô
                kq["e"] = e
        th = threading.Thread(target=_chay, daemon=True)
        th.start()
        while th.is_alive():
            th.join(0.3)
            self._xem_phim()
        if "e" in kq:
            raise kq["e"]
        return kq.get("v")

    # ---------------- chờ người đăng nhập
    def _cho_dang_nhap(self, k):
        """-> 'ok' | 'bo_qua' | 'dung' | 'het_gio'"""
        t0 = self.gio()
        lan_nhac, bao_sai, bao_dong, bao_khong_doc = 1, False, "", False
        while True:
            phim = self._xem_phim()
            if self.dung:
                return "dung"
            if self.bo_khach:
                return "bo_qua"
            tt, loi = self.cong.trang_thai()
            if tt == "da_dang_nhap":
                dn = mst_so(self.cong.mst_dang_nhap())
                if dn and dn == mst_so(k["mst"]):
                    return "ok"
                if not dn:
                    # P0 18/11/2026: phiên không đọc được MST -> KHÔNG mặc định là đúng khách; chờ NGƯỜI xác nhận (phím X)
                    if phim == "X":
                        self.in_ra("  Người đã xác nhận (phím X): tài khoản đang đăng nhập là của khách %s (MST %s)." % (k["ten"], k["mst"]))
                        return "ok"
                    if not bao_khong_doc:
                        bao_khong_doc = True
                        self.cong.hien()
                        self.in_ra("  !! Máy KHÔNG đọc được MST của phiên đăng nhập nên chưa xác nhận được đây là tài khoản của khách %s (MST %s). "
                                   "Máy CHƯA tải. Nhìn trên cửa sổ Chrome: nếu đúng tài khoản của khách thì bấm X để xác nhận; "
                                   "nếu không, đăng xuất rồi đăng nhập đúng tài khoản (B = bỏ qua khách)." % (k["ten"], k["mst"]))
                elif not bao_sai:
                    bao_sai = True
                    self.cong.hien()
                    self.in_ra("  !! Tài khoản đang đăng nhập là MST %s, nhưng khách này là MST %s (CÔNG TY KHÁC). Máy KHÔNG tải. "
                               "Trên cửa sổ Chrome: đăng xuất rồi đăng nhập đúng tài khoản của khách (hoặc bấm B để bỏ qua khách)."
                               % (self.cong.mst_dang_nhap(), k["mst"]))
            elif tt in ("dong", "loi"):
                if bao_dong != tt:
                    bao_dong = tt
                    self.in_ra("  !! %s Bấm M để mở lại Chrome cho khách này, B để bỏ qua khách, D để dừng."
                               % (loi or ("Cửa sổ Chrome của khách đã đóng." if tt == "dong" else "Chrome báo lỗi.")))
                if phim == "M":
                    bao_dong = ""
                    ok, loi2 = self.cong.mo()
                    self.in_ra("  Đã mở lại Chrome - đăng nhập và nhập mã captcha trên cửa sổ đó." if ok else "  Không mở được Chrome: %s" % loi2)
            else:
                bao_dong = ""
            da_cho = self.gio() - t0
            if self.cho_toi_da and da_cho >= self.cho_toi_da:
                return "het_gio"
            if da_cho >= 60 * lan_nhac:
                lan_nhac += 1
                self.in_ra("  … vẫn đang chờ đăng nhập cho %s (%d phút). B = bỏ qua khách, D = dừng." % (k["ten"], int(da_cho // 60)))
            self.ngu(0.5)

    def _dang_nhap_lai(self, k):
        """Phiên hết giữa chừng: hỏi lại người CHO RIÊNG khách này rồi làm tiếp tháng đang dở."""
        self.in_ra("  !! Phiên cổng thuế của %s đã hết. Đăng nhập lại (gõ mã captcha) trên cửa sổ Chrome đang hiện - máy tải tiếp phần đang dở."
                   % k["ten"])
        self.cong.hien()
        t0 = self.gio()                     # tool cần ~10 giây mới nhận ra phiên mất: chờ trạng thái rời 'da_dang_nhap'
        while self.cong.trang_thai()[0] == "da_dang_nhap" and self.gio() - t0 < 20:
            self._xem_phim()
            if self.dung or self.bo_khach:
                return "dung" if self.dung else "bo_qua"
            self.ngu(0.5)
        return self._cho_dang_nhap(k)

    @staticmethod
    def _mat_phien(loi):
        s = str(loi or "").lower()
        return "hết hạn" in s or "het han" in s or "đăng nhập trước" in s or "dang nhap truoc" in s

    # ---------------- tra cứu (đăng nhập lại nếu phiên hết)
    def _tra_cuu(self, k, tu, den, h, kind):
        """-> (rows, lỗi, cảnh báo, còn làm tiếp được). 'còn làm tiếp được' = False khi phiên hết mà không đăng nhập lại được."""
        lan = 0
        while True:
            try:
                rows, loi, cb = self._nen(self.cong.tra_cuu, tu, den, h, kind)
            except Exception as e:
                rows, loi, cb = None, "lỗi bất ngờ khi tra cứu: %s" % str(e)[:200], []
            if loi and (self._mat_phien(loi) or self.cong.trang_thai()[0] != "da_dang_nhap") and lan < 3 \
                    and not (self.dung or self.bo_khach):
                lan += 1
                if self._dang_nhap_lai(k) == "ok":
                    continue
                return None, loi, [], False
            return rows, loi, cb, True

    def _hoi_truoc_mtt(self, k, con):
        """HĐ máy tính tiền: tra DỒN mọi lần tìm (tháng × mua / bán) của khách ngay sau khi đăng nhập, để các câu hỏi captcha
        (nếu cổng đòi) đến liền nhau khi người còn ngồi đó; sau bước này máy tự chạy hết, không hỏi gì nữa.
        Chỉ giữ kết quả chắc chắn (tra được, hoặc người chưa nhập captcha); lỗi khác thì lúc làm tháng đó tra lại."""
        self.mtt_san = {}
        if "mtt" not in self.loai:
            return
        viec = []
        for v in con:
            kh = khoang_ky(v["ky"], self.hom_nay)
            if not kh:
                continue
            for h in (["mua", "ban"] if v["huong"] == "ca" else [v["huong"]]):
                if (v["ky"], h) not in [(x[0], x[1]) for x in viec]:
                    viec.append((v["ky"], h, kh))
        if not viec:
            return
        self.in_ra("  Bước 1/2 – hoá đơn máy tính tiền: tra trước %d lần tìm (tháng × mua / bán). Nếu cổng thuế đòi mã captcha, "
                   "máy hỏi DỒN ngay ở bước này." % len(viec))
        for ky, h, (tu, den) in viec:
            if self.dung or self.bo_khach:
                break
            rows, loi, cb, song = self._tra_cuu(k, tu, den, h, "mtt")
            if not song:
                break
            if not loi or "captcha" in str(loi).lower():
                self.mtt_san[(ky, h)] = (rows, loi, cb)
        dem = getattr(self.cong, "captcha_mtt", None)
        self.cap_khach = tuple(dem()) if dem else (0, 0)
        self.in_ra("  Bước 2/2 – máy tự tải, không hỏi gì thêm%s."
                   % ((" (HĐ máy tính tiền: người đã gõ %d mã captcha%s)"
                       % (self.cap_khach[0], (", dùng lại cho %d trang sau" % self.cap_khach[1]) if self.cap_khach[1] else ""))
                      if self.cap_khach[0] else ""))

    # ---------------- hoá đơn không có XML gốc -> CSV mẫu 1 cho bước tai_hd
    def _khong_xml(self, kq, rows, h, kind, thu_muc, nhom):
        """-> False nếu cổng thuế chặn giữa chừng (lô phải dừng)."""
        lay, biet = getattr(self.cong, "dong_khong_xml", None), getattr(self.cong, "khong_xml_da_biet", None)
        if not lay or not biet or self.dung or self.bo_khach:
            return True
        try:
            kx = biet()
            if not kx:
                return True
            co = ten_da_co(thu_muc)
            ds = [r for r in rows if self.cong.khoa(r) in kx and self.cong.ten_tep(r, h).lower() not in co]
            da_ghi = khoa_khong_xml_da_ghi(thu_muc, h)
            con = [r for r in ds if str(self.cong.khoa(r)).upper() not in da_ghi]          # đã ghi CSV rồi: không hỏi cổng lần nữa
            kq["kx_da_ghi"] += len(ds) - len(con)
            if not con:
                return True
            dong, chi_tong, chan = self._nen(lay, con, h, kind)
            if dong:
                _, moi, cu = ghi_khong_xml(thu_muc, kq["ky"], h, kind, dong)
                kq["kx_ghi"] += moi
                kq["kx_da_ghi"] += cu
            if chi_tong:
                kq["ghi_chu"].append("%s: %d HĐ không có XML gốc chỉ lấy được dòng tổng (cổng không trả chi tiết)" % (nhom, chi_tong))
            if chan:
                self.bi_chan = True
                self.dung = True
                kq["loi"].append("%s: cổng thuế đang CHẶN (hành vi không hợp lệ) khi lấy chi tiết HĐ không có XML gốc" % nhom)
                kq["dang_do"] = True
                return False
        except Exception as e:
            kq["canh_bao"].append("%s: chưa ghi được HĐ không có XML gốc ra CSV: %s" % (nhom, str(e)[:200]))
        return True

    # ---------------- một tháng của một sổ
    def _mot_thang(self, k, v):
        so, ky, huong_dong = v["so"], v["ky"], v["huong"]
        kq = {"so": so, "ky": ky, "huong": huong_dong, "mst": k["mst"], "tim_thay": 0, "mua": 0, "ban": 0, "tai": 0, "da_co": 0,
              "khong_xml": 0, "loi_tai": 0, "loi": [], "canh_bao": [], "dang_do": False, "kx_ghi": 0, "kx_da_ghi": 0, "ghi_chu": []}
        khoang = khoang_ky(ky, self.hom_nay)
        if not khoang:
            kq["loi"].append("kỳ %s chưa tới" % ky)
            return self._chot(kq)
        tu, den = khoang
        thu_muc = thu_muc_hoa_don(self.lenh, so, ky)
        for h in (["mua", "ban"] if huong_dong == "ca" else [huong_dong]):
            for kind in self.loai:
                if self.dung or self.bo_khach:
                    kq["dang_do"] = True
                    return self._chot(kq)
                nhom = TEN_NHOM.get((h, kind), "%s/%s" % (h, kind))
                san = self.mtt_san.get((ky, h)) if kind == "mtt" else None
                if san is not None:
                    rows, loi, cb = san                    # đã tra dồn ở đầu khách (_hoi_truoc_mtt)
                else:
                    rows, loi, cb, song = self._tra_cuu(k, tu, den, h, kind)
                    if not song:
                        kq["dang_do"] = True
                        return self._chot(kq)
                if loi and "đang CHẶN" in str(loi):          # P2 18/11/2026: cổng chặn khi TRA CỨU -> dừng cả lô như khi tải
                    self.bi_chan = True
                    self.dung = True
                    kq["loi"].append("%s: cổng thuế đang CHẶN tra cứu (hành vi không hợp lệ)" % nhom)
                    kq["dang_do"] = True
                    return self._chot(kq)
                if loi:
                    if kind == "mtt" and "captcha" in str(loi).lower():
                        kq["canh_bao"].append("%s: chưa nhập captcha - chưa tải" % nhom)
                    else:
                        kq["loi"].append("%s: %s" % (nhom, loi))
                    continue
                kq["canh_bao"].extend("%s: %s" % (nhom, x) for x in (cb or []))
                rows = list(rows or [])
                kq["tim_thay"] += len(rows)
                kq[h] += len(rows)
                if not rows:
                    continue
                co = ten_da_co(thu_muc)
                can = [r for r in rows if self.cong.ten_tep(r, h).lower() not in co]
                kq["da_co"] += len(rows) - len(can)
                lan = 0
                while can:
                    if self.dung or self.bo_khach:
                        kq["dang_do"] = True
                        return self._chot(kq)
                    try:
                        t = self._nen(self.cong.tai, can, kind, h, thu_muc)
                    except Exception as e:
                        kq["loi"].append("%s: lỗi bất ngờ khi tải: %s" % (nhom, str(e)[:200]))
                        break
                    kq["tai"] += t.get("ok", 0)
                    kq["da_co"] += t.get("bo_qua", 0)
                    kq["khong_xml"] += t.get("khong_xml", 0)
                    if t.get("bi_chan"):
                        self.bi_chan = True
                        self.dung = True
                        kq["loi"].append("%s: cổng thuế đang CHẶN tải (hành vi không hợp lệ)" % nhom)
                        kq["dang_do"] = True
                        return self._chot(kq)
                    if t.get("loi") and self.cong.trang_thai()[0] != "da_dang_nhap" and lan < 3 and not (self.dung or self.bo_khach):
                        lan += 1                     # lỗi do mất phiên: đăng nhập lại rồi tải lại phần chưa có tệp
                        if self._dang_nhap_lai(k) != "ok":
                            kq["dang_do"] = True
                            return self._chot(kq)
                        co = ten_da_co(thu_muc)
                        can = [r for r in can if self.cong.ten_tep(r, h).lower() not in co]
                        continue
                    kq["loi_tai"] += t.get("loi", 0)
                    if t.get("dung") and (self.dung or self.bo_khach):
                        kq["dang_do"] = True
                    break
                if not self._khong_xml(kq, rows, h, kind, thu_muc, nhom):
                    return self._chot(kq)
        return self._chot(kq)

    def _chot(self, kq):
        if kq["dang_do"]:
            tt = "dang_do"
        elif kq["loi"]:
            tt = "loi"
        elif kq["loi_tai"] or kq["canh_bao"]:
            tt = "mot_phan"
        elif kq["tim_thay"] == 0:
            tt = "khong_co_tren_cong"
        else:
            tt = "xong"
        kq["trang_thai"] = tt
        ban_ghi = {k: kq[k] for k in ("so", "ky", "huong", "mst", "trang_thai", "tim_thay", "mua", "ban", "tai", "da_co",
                                      "khong_xml", "loi_tai", "loi", "canh_bao", "kx_ghi", "kx_da_ghi", "ghi_chu")}
        ban_ghi["loai"] = sorted(self.loai)          # P0 18/11/2026: phạm vi đã tra (/loai:dt không phủ HĐ máy tính tiền)
        self.so.ghi(ban_ghi)
        if tt in TRANG_THAI_XONG and set(self.loai) == set(LOAI_DU):
            # P0 18/11/2026: bằng chứng cho chốt tải hoá đơn của XII (AiInvoiceGate): cổng đã tra ĐỦ (cả HĐ điện tử + máy tính tiền,
            # không cảnh báo) và có bao nhiêu HĐ mỗi chiều -> chiều 0 HĐ mới được coi là 'không phát sinh'.
            try:
                ghi_bang_chung_cong(thu_muc_hoa_don(self.lenh, kq["so"], kq["ky"]),
                                    {h: kq[h] for h in (["mua", "ban"] if kq["huong"] == "ca" else [kq["huong"]])})
            except Exception as e:
                kq["ghi_chu"].append("không ghi được %s: %s" % (TEP_BANG_CHUNG_CONG, str(e)[:120]))
        self.in_ra("  %s %s (%s): %s - trên cổng %d HĐ (mua %d, bán %d), tải mới %d, đã có %d%s%s%s%s"
                   % (kq["so"], kq["ky"], {"mua": "mua vào", "ban": "bán ra"}.get(kq["huong"], "mua + bán"), TEN_TRANG_THAI[tt],
                      kq["tim_thay"], kq["mua"], kq["ban"], kq["tai"], kq["da_co"],
                      (", không có XML gốc %d" % kq["khong_xml"]) if kq["khong_xml"] else "",
                      (" (ghi CSV cho trạm nhập: %d HĐ mới, %d HĐ đã ghi trước)" % (kq["kx_ghi"], kq["kx_da_ghi"]))
                      if (kq["kx_ghi"] or kq["kx_da_ghi"]) else "",
                      (", lỗi tải %d" % kq["loi_tai"]) if kq["loi_tai"] else "",
                      ("; " + "; ".join(kq["loi"] + kq["canh_bao"] + kq["ghi_chu"])) if (kq["loi"] or kq["canh_bao"] or kq["ghi_chu"]) else ""))
        return kq

    # ---------------- một khách
    def _mot_khach(self, i, n, k):
        """18/11/2026: giữ khoá tải theo MST (khoa_tai_mst) suốt lượt của khách - cửa sổ Tải hoá đơn / lô khác cùng MST trên máy
        không gọi cổng song song. Không lấy được khoá -> bỏ qua khách (ghi lý do), sang khách sau."""
        try:
            if HERE not in sys.path:
                sys.path.insert(0, HERE)
            import khoa_tai_mst as KM
        except Exception:
            KM = None
        if KM is not None:
            ok, tb = KM.lay(k["mst"], "lô tải hoá đơn (%s)" % (k.get("ten") or k["mst"]))
            if not ok:
                self.in_ra("\nKhách %d/%d – %s (MST %s): %s Bỏ qua khách này." % (i, n, k["ten"], k["mst"], tb))
                return self._ghi_khach(i, k, [], "bỏ qua: " + tb)
        try:
            return self._mot_khach_than(i, n, k)
        finally:
            if KM is not None:
                KM.tra(k["mst"])

    def _mot_khach_than(self, i, n, k):
        self.bo_khach = False
        self.mtt_san, self.cap_khach = {}, (0, 0)
        con = [v for v in k["viec"] if not self.so.da_xong(v["so"], v["ky"], v["huong"], self.loai)]
        if not con:
            self.in_ra("\nKhách %d/%d – %s (MST %s): mọi tháng đã tải xong hôm nay - bỏ qua." % (i, n, k["ten"], k["mst"]))
            return self._ghi_khach(i, k, [], "đã xong hôm nay")
        self.in_ra("\n" + "=" * 78)
        self.in_ra("Khách %d/%d – %s (MST %s): đăng nhập và nhập mã captcha trên cửa sổ Chrome vừa mở" % (i, n, k["ten"], k["mst"]))
        if k.get("ten_dn"):
            self.in_ra("  Tên đăng nhập cổng thuế: %s (mật khẩu: Chrome tự điền nếu đã lưu, hoặc người gõ)." % k["ten_dn"])
        self.in_ra("  Sẽ tải %d tháng: %s" % (len(con), ", ".join("%s %s" % (v["so"], v["ky"]) for v in con)))
        self.in_ra("  Phím: B = bỏ qua khách này · D = dừng cả lô")
        self.cong.chuan_bi(k)
        ok, loi = self.cong.mo()
        if not ok:
            self.in_ra("  !! Không mở được Chrome: %s" % loi)
            return self._ghi_khach(i, k, [], "không mở được Chrome: %s" % loi)
        cho = self._cho_dang_nhap(k)
        if cho != "ok":
            self.cong.dong()
            ly_do = {"bo_qua": "người bấm bỏ qua", "dung": "dừng lô", "het_gio": "quá %d phút không có người đăng nhập" % (self.cho_toi_da // 60)}[cho]
            self.in_ra("  Khách %s: %s." % (k["ten"], ly_do))
            return self._ghi_khach(i, k, [], ly_do)
        self.in_ra("  Đã nhận phiên đăng nhập (MST %s). Máy đang tải - không cần thao tác gì thêm." % (self.cong.mst_dang_nhap() or k["mst"]))
        self._hoi_truoc_mtt(k, con)
        ds = []
        for v in con:
            if self.dung or self.bo_khach:
                break
            ds.append(self._mot_thang(k, v))
        dem = getattr(self.cong, "captcha_mtt", None)
        if dem:
            self.cap_khach = tuple(dem())
        self.mtt_san = {}
        self.cong.dong()
        ghi_chu = "bị chặn tải - dừng lô" if self.bi_chan else ("người bấm bỏ qua giữa chừng" if self.bo_khach else ("dừng lô" if self.dung else ""))
        return self._ghi_khach(i, k, ds, ghi_chu)

    def _ghi_khach(self, i, k, ds, ghi_chu):
        xong = [d for d in ds if d["trang_thai"] == "xong"]
        khong = [d for d in ds if d["trang_thai"] == "khong_co_tren_cong"]
        chua = [d for d in ds if d["trang_thai"] not in TRANG_THAI_XONG]
        da_lam = set((d["so"], d["ky"]) for d in ds)
        chua_lam = [v for v in k["viec"] if (v["so"], v["ky"]) not in da_lam and not self.so.da_xong(v["so"], v["ky"], v["huong"], self.loai)]
        # P0 18/11/2026: chỉ tra một loại HĐ (/loai:dt hoặc /loai:mtt) -> tháng 'xong' cho PHẠM VI đã chọn, nhưng chưa phải đủ cả tháng:
        # không đề nghị ghi sổ và không liệt kê 'cổng không có HĐ' trừ khi cả hai loại đã xong hôm nay.
        du_ca_thang = lambda d: self.so.da_xong(d["so"], d["ky"], d["huong"], LOAI_DU)          # noqa: E731
        if khong and set(self.loai) != set(LOAI_DU):
            khong = [d for d in khong if du_ca_thang(d)]
        so_s = ",".join(sorted(set(v["so"] for v in k["viec"])))
        # Đề nghị ghi sổ: CHỈ cho (sổ, kỳ) mà mọi dòng việc đã tải đủ hôm nay và đang có tệp chờ bước tai_hd nhập.
        de_nghi, khong_gui = [], []
        if self.tu_ghi and ds:
            nhom = {}
            for d in ds:
                nhom.setdefault((d["so"], d["ky"]), []).append(d)
            dang_thieu = set((v["so"], v["ky"]) for v in chua_lam)
            for (s_, ky_), dd in sorted(nhom.items()):
                du = all(d["trang_thai"] in TRANG_THAI_XONG for d in dd) and (s_, ky_) not in dang_thieu
                if du and not all(du_ca_thang(d) for d in dd):
                    khong_gui.append("%s:%s(mới tra %s)" % (s_, ky_, "HĐ điện tử, chưa tra HĐ máy tính tiền" if "mtt" not in self.loai
                                                            else "HĐ máy tính tiền, chưa tra HĐ điện tử"))
                    continue
                if not du:
                    khong_gui.append("%s:%s" % (s_, ky_))
                    continue
                cho = tep_cho_nhap(thu_muc_hoa_don(self.lenh, s_, ky_))
                tai, kx = sum(d["tai"] for d in dd), sum(d.get("kx_ghi", 0) for d in dd)
                if not (tai or kx or cho):
                    continue                          # không có tệp nào chờ nhập: không cần ra lệnh
                try:
                    self.de_nghi.append(ghi_de_nghi(self.lenh, s_, ky_, datetime.now(),
                                                    {"mst": k["mst"], "tep_moi": tai, "khong_xml_csv": kx, "tep_cho_nhap": cho}))
                    de_nghi.append("%s:%s" % (s_, ky_))
                except Exception as e:
                    ghi_chu = (ghi_chu + "; " if ghi_chu else "") + "không ghi được đề nghị ghi sổ %s %s: %s" % (s_, ky_, str(e)[:120])
        dong = {"Luc": datetime.now().strftime("%Y-%m-%d %H:%M"), "Khach": i, "MST": k["mst"], "TenKhach": k["ten"], "So": so_s,
                "KetQua": ("XONG" if ds and not chua and not chua_lam else ("CHUA_XONG" if ds or chua_lam else "XONG")),
                "ThangXong": " ".join("%s:%s" % (d["so"], d["ky"]) for d in xong),
                "ThangKhongCoHD": " ".join("%s:%s" % (d["so"], d["ky"]) for d in khong),
                "ThangChuaXong": " ".join(["%s:%s(%s)" % (d["so"], d["ky"], TEN_TRANG_THAI[d["trang_thai"]]) for d in chua] +
                                          ["%s:%s(chưa làm)" % (v["so"], v["ky"]) for v in chua_lam]),
                "HDMua": sum(d["mua"] for d in ds), "HDBan": sum(d["ban"] for d in ds), "TaiMoi": sum(d["tai"] for d in ds),
                "DaCoSan": sum(d["da_co"] for d in ds), "KhongCoXMLGoc": sum(d["khong_xml"] for d in ds),
                "LoiTai": sum(d["loi_tai"] for d in ds), "GhiChu": ghi_chu,
                "KhongXMLDaGhiCSV": sum(d.get("kx_ghi", 0) for d in ds), "DeNghiGhiSo": " ".join(de_nghi),
                "CaptchaMTT": ("gõ %d, dùng lại %d" % self.cap_khach) if (ds and any(self.cap_khach)) else ""}
        self._giu_tep_ket_qua_cu()
        moi = not os.path.exists(self.tep_ket_qua)
        with io.open(self.tep_ket_qua, "a", encoding="utf-8-sig" if moi else "utf-8", newline="") as f:
            w = csv.DictWriter(f, fieldnames=COT_KET_QUA, delimiter=";")
            if moi:
                w.writeheader()
            w.writerow(dong)
        if khong:
            moi = not os.path.exists(self.tep_khong_co)
            with io.open(self.tep_khong_co, "a", encoding="utf-8") as f:
                if moi:
                    f.write("# Tháng cổng thuế KHÔNG có hoá đơn (mua vào / bán ra đã tra) - máy KHÔNG tự xác nhận.\n"
                            "# Kế toán xem lại; nếu đúng là tháng không phát sinh hoá đơn thì TỰ tạo tệp khong_phat_sinh.txt\n"
                            "# (ghi tên người xác nhận) ở đường dẫn bên cạnh rồi chạy lại bước Tải hoá đơn của trạm.\n")
                for d in khong:
                    f.write("%s | %s | %s | %s | %s\n" % (k["mst"], k["ten"], d["so"], d["ky"],
                                                         os.path.join(thu_muc_hoa_don(self.lenh, d["so"], d["ky"]), XAC_NHAN_KHONG_PS)))
        self.ket_qua.append(dong)
        self.in_ra("  => Khách %d – %s: %s. Xong %d tháng, cổng không có HĐ %d tháng, chưa xong %d tháng; mua %d HĐ, bán %d HĐ, tải mới %d%s."
                   % (i, k["ten"], dong["KetQua"], len(xong), len(khong), len(chua) + len(chua_lam), dong["HDMua"], dong["HDBan"], dong["TaiMoi"],
                      (" (" + ghi_chu + ")") if ghi_chu else ""))
        if de_nghi:
            self.in_ra("     Đã ghi đề nghị ghi sổ (bước Tải hoá đơn của trạm) cho: %s" % ", ".join(de_nghi))
        if khong_gui:
            self.in_ra("     KHÔNG đề nghị ghi sổ (tháng chưa tải đủ): %s" % ", ".join(khong_gui))
        return dong

    def chay(self):
        try:
            if os.path.exists(self.tep_dung):
                os.remove(self.tep_dung)          # tệp DUNG của lần trước
        except Exception:
            pass
        n = len(self.khach)
        for i, k in enumerate(self.khach, 1):
            self._xem_phim()
            if self.dung:
                break
            self._mot_khach(i, n, k)
        if self.bi_chan:
            self.in_ra("\n!! Cổng thuế đang CHẶN tải (“hành vi không hợp lệ”). Lô đã DỪNG để không bị chặn lâu hơn. Đợi khoảng 30 phút rồi chạy "
                       "lại lệnh chay - phần đã xong hôm nay được bỏ qua.")
        return self.ket_qua


# ==========================================================================
#  LỆNH
# ==========================================================================
def _in(s=""):
    try:
        print(s, flush=True)
    except UnicodeEncodeError:
        print(str(s).encode("ascii", "replace").decode("ascii"), flush=True)


def lenh_danh_sach(ts, hom_nay=None, in_ra=_in):
    hom_nay = hom_nay or date.today()
    lo = thu_muc_lo(ts)
    lenh = doc_hop_thu(ts)
    if ts.get("so_lieu"):
        try:
            with io.open(ts["so_lieu"], encoding="utf-8-sig") as f:
                so_lieu, loi = json.load(f), ""
        except Exception as e:
            so_lieu, loi = None, str(e)
    else:
        in_ra("Đang đọc các sổ trên máy chủ %s (CHỈ ĐỌC)…" % (ts.get("may_chu") or ".\\SQLEXPRESS"))
        ds_so = [x.strip() for x in (ts.get("so") or "").split(",") if x.strip()]
        if not ds_so and lenh and os.path.isdir(os.path.join(lenh, "ho_so")):
            ds_so = sorted(os.path.splitext(t)[0] for t in os.listdir(os.path.join(lenh, "ho_so")) if t.lower().endswith(".json"))
        so_lieu, loi = doc_so_sql(ts.get("may_chu"), ds_so, os.path.join(lo, "so_lieu_so.json"))
    if so_lieu is None:
        in_ra("LỖI: %s" % loi)
        return 2
    if not lenh:
        in_ra("CHÚ Ý: chưa biết hộp thư LENH (AIHoaDon\\xii_erp_tram.json khoá \"lenh\", hoặc /lenh:). Danh sách chỉ dựa trên số liệu sổ; "
              "lúc chạy tải phải có LENH.")
    dong, ghi_chu = lap_danh_sach(so_lieu, lenh, hom_nay, ts.get("tu_thang"), ts.get("den_thang"), (ts.get("huong") or "").lower())
    duong = os.path.join(lo, TEP_DANH_SACH)
    if os.path.exists(duong):
        os.replace(duong, os.path.join(lo, "danh_sach_tai_lo_cu_%s.csv" % datetime.now().strftime("%Y%m%d_%H%M%S")))
    ghi_danh_sach_csv(dong, duong)
    for g in ghi_chu:
        in_ra("  - " + g)
    in_ra("")
    in_ra(bang_danh_sach(dong))
    in_ra("")
    in_ra("Danh sách đã ghi: %s" % duong)
    in_ra("Sửa được bằng Excel: xoá chữ x ở cột Chon (hoặc xoá dòng) để bỏ; đổi cột Huong thành mua / ban / ca. Rồi chạy: Bắt đầu tải.")
    return 0


def lenh_chay(ts, hom_nay=None, in_ra=_in, cong=None, phim=None, hoi=input):
    hom_nay = hom_nay or date.today()
    lo = thu_muc_lo(ts)
    lenh = doc_hop_thu(ts)
    if not lenh or not os.path.isdir(lenh):
        in_ra("LỖI: không thấy hộp thư LENH (%s). Ghi đường dẫn vào AIHoaDon\\xii_erp_tram.json (khoá \"lenh\") hoặc thêm /lenh:<thư mục>."
              % (lenh or "chưa khai"))
        return 2
    duong = ts.get("danh_sach") or os.path.join(lo, TEP_DANH_SACH)
    if not os.path.isfile(duong):
        in_ra("LỖI: chưa có danh sách %s - chạy bước Lập danh sách trước." % duong)
        return 2
    khach = doc_danh_sach_csv(duong)
    so = SoTienDo(lo, hom_nay)
    loai = {"dt": ("dt",), "mtt": ("mtt",)}.get((ts.get("loai") or "").lower(), ("dt", "mtt"))
    con = sum(1 for k in khach for v in k["viec"] if not so.da_xong(v["so"], v["ky"], v["huong"], loai))
    in_ra("TẢI HOÁ ĐƠN THEO LÔ %s – %d khách, %d tháng-sổ còn phải tải hôm nay (tháng đã xong hôm nay được bỏ qua)."
          % (PHIEN_BAN, len(khach), con))
    in_ra("Tệp hoá đơn vào: %s\\tep\\<sổ>\\<yyyy-mm>\\hoa_don\\ (bước Tải hoá đơn của trạm nhập vào sổ)." % lenh)
    if not con:
        in_ra("Không còn việc gì.")
        return 0
    if "khong_hoi" not in ts:
        tl = hoi("Gõ C rồi Enter để bắt đầu (Enter để thôi): ")
        if str(tl or "").strip().upper() != "C":
            in_ra("Chưa chạy.")
            return 0
    if set(loai) != set(LOAI_DU):
        in_ra("Lưu ý: chỉ tra %s (/loai:%s) - tháng tải xong vẫn CHƯA đủ cả tháng: không đề nghị ghi sổ, không liệt kê 'cổng không có HĐ' "
              "cho tới khi loại còn lại cũng đã tra hôm nay." % ("HĐ điện tử" if "dt" in loai else "HĐ máy tính tiền", loai[0]))
    if phim is None:
        phim = BanPhim()
    if cong is None:
        cong = CongThueThat(nap_tool(), lo, phim=phim, hoi=hoi, in_ra=in_ra, bo_mtt_luon=(ts.get("mtt") or "").lower() == "bo",
                            dung_lai_captcha=(ts.get("mtt_dung_lai") or "").lower() in ("co", "có", "1"))
    tu_ghi = (ts.get("tu_ghi") or "").lower() not in ("khong", "không", "0", "tat", "tắt")
    try:
        cho = int(float(ts.get("cho_phut") or 20)) * 60
    except Exception:
        cho = 20 * 60
    lo_chay = ChayLo(cong, khach, lenh, lo, hom_nay, phim=phim, in_ra=in_ra, loai=loai, cho_toi_da=cho, tu_ghi=tu_ghi)
    try:
        lo_chay.chay()
    finally:
        try:
            cong.dong()
        except Exception:
            pass
    in_ra("\nKết quả từng khách: %s" % lo_chay.tep_ket_qua)
    if os.path.exists(lo_chay.tep_khong_co):
        in_ra("Tháng cổng thuế không có hoá đơn (kế toán xem rồi TỰ xác nhận): %s" % lo_chay.tep_khong_co)
    if not tu_ghi:
        in_ra("Tự đề nghị ghi sổ đang TẮT (/tu_ghi:khong). Bước tiếp: ERP ra lệnh Tải hoá đơn (tai_hd) cho các tháng trên để nhập vào sổ.")
    elif lo_chay.de_nghi:
        in_ra("Đã ghi %d đề nghị ghi sổ vào %s (mỗi tệp = một sổ-tháng tải đủ, có tệp chờ nhập)."
              % (len(lo_chay.de_nghi), os.path.join(lenh, THU_MUC_DE_NGHI)))
        in_ra("ERP đọc đề nghị rồi ra lệnh Tải hoá đơn (tai_hd) cho trạm theo đường lệnh thường.")
    else:
        in_ra("Không có sổ-tháng nào vừa tải đủ mà có tệp chờ nhập - không ghi đề nghị ghi sổ.")
    if tu_ghi:
        cho = dem_de_nghi_cho(lenh)
        if cho:
            in_ra("ĐANG CHỜ: %d đề nghị ghi sổ chưa được đọc trong %s." % (cho, os.path.join(lenh, THU_MUC_DE_NGHI)))
            in_ra("Cầu nối sổ sách TỰ đọc lại khi được mở - không cần chạy lại lô, không mất tệp. Nếu cầu nối đang tắt thì "
                  "tệp nằm chờ; cần gấp thì vào ERP ra lệnh Tải hoá đơn (tai_hd) bằng tay.")
    return 0


def lenh_xem(ts, hom_nay=None, in_ra=_in):
    hom_nay = hom_nay or date.today()
    lo = thu_muc_lo(ts)
    so = SoTienDo(lo, hom_nay)
    ds = so.doc()
    if not ds:
        in_ra("Hôm nay chưa tải lô nào.")
        return 0
    cuoi = {}
    for b in ds:
        cuoi[(b.get("so"), b.get("ky"))] = b
    for (s, ky), b in sorted(cuoi.items()):
        in_ra("%-28s %s  %-28s cổng %4d HĐ, tải mới %4d, đã có %4d%s" % (s, ky, TEN_TRANG_THAI.get(b.get("trang_thai"), b.get("trang_thai")),
                                                                     b.get("tim_thay", 0), b.get("tai", 0), b.get("da_co", 0),
                                                                     ("  " + "; ".join((b.get("loi") or []) + (b.get("canh_bao") or [])))
                                                                     if (b.get("loi") or b.get("canh_bao")) else ""))
    xong = sum(1 for b in cuoi.values() if b.get("trang_thai") in TRANG_THAI_XONG)
    in_ra("Tổng: %d tháng-sổ, xong %d, chưa xong %d." % (len(cuoi), xong, len(cuoi) - xong))
    return 0


def main(argv=None):
    for s in (sys.stdout, sys.stderr):
        try:
            s.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    lenh, ts = doc_tham_so(argv or sys.argv)
    if lenh in ("danh_sach", "ds"):
        return lenh_danh_sach(ts)
    if lenh == "chay":
        return lenh_chay(ts)
    if lenh == "xem":
        return lenh_xem(ts)
    _in(__doc__)
    return 1


if __name__ == "__main__":
    sys.exit(main())
