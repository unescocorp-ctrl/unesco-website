# -*- coding: utf-8 -*-
"""GD356 - BAI KIEM TRA TONG HOP KHOA SO THEO THANG (chi DOC .MDB qua jet_doc, khong ghi so).

Chay lan luot tung thang (thu tu nam tai chinh) tu /tu: den /den: - thang sau chi duoc khoa khi thang truoc da khoa:
  1. DA LAM: so phieu / dong, hoa don, khau hao, luong, phan bo 242, ket chuyen 911, thue GTGT da lam trong thang.
  2. BUT TOAN SAI (tung dong, co MaCT de mo chung tu): phieu khong can No / Co, TK tong hop (co TK con), TK khong ton tai,
     cong no thieu doi tuong, ngay chung tu ngoai thang, chi tien mat tu 5 trieu co thue dau vao, nghi trung chung tu,
     quy tien mat / tien gui am (dong lam am).  Moi loi: mo ta + cach sua + but toan dung goi y.
  3. CAN LAM truoc khi khoa: khau hao, phan bo 242, trich luong / bao hiem, ket chuyen 911, ket chuyen thue GTGT, hoa don dien tu
     chua hach toan, ton kho am, viec gia thanh (GD350 K60) - moi viec: cach lam (but toan) + noi lam.
  4. KET LUAN: DA_KHOA / DUOC_KHOA (khong loi, khong viec nang, thang truoc da khoa) / CHUA_KHOA; diem 0-100.
Ra: ket-qua\\khoa_so_thang.txt (VB6 FrmKhoaThang356 doc) + khoa_so_thang.html.
  TONG;<so>;<nam>;<tu>;<den>;<luc>
  THANG;t;mm/yyyy;trang_thai;diem;n_loi;n_canh_bao;n_viec_nang;n_viec;da_khoa
  BT;t;muc;ma;MaCT;so;ngay;tk_no;tk_co;tien;doi_tuong;mo_ta;cach_sua
  VIEC;t;muc;ma;noi_dung;cach_lam;noi_lam;so_tien
  DA;t;noi_dung
Khoa thang: VB6 goi dung lenh Khoa so cua menu (frmMain.mnK_Click - co cham diem san sang + sao luu)."""
import datetime as _dt
import html
import io
import os
import re
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
TEP = "khoa_so_thang"
MOC_TM = 5000000.0
CONG_NO = ("131", "331", "1388", "3388", "136", "336")
DT_TEN = {"PHIEU_LECH": "Phiếu không cân Nợ / Có", "TK_TONG_HOP": "Hạch toán vào TK tổng hợp", "TK_LA": "Tài khoản không có trong hệ thống",
          "THIEU_DT": "Công nợ thiếu đối tượng", "NGAY_LECH": "Ngày chứng từ ngoài tháng", "TM_5TR": "Chi tiền mặt từ 5 triệu có thuế đầu vào",
          "TRUNG": "Nghi trùng chứng từ", "QUY_AM": "Tiền mặt / tiền gửi âm"}


def _f(x):
    try:
        return float(x or 0)
    except (TypeError, ValueError):
        return 0.0


def _i(x):
    return int(_f(x))


def _s(x):
    return str(x if x is not None else "").replace(";", ",").replace("\r", " ").replace("\n", " ").strip()


def _dd(v):
    return "{:,.0f}".format(round(_f(v))).replace(",", ".")


def _mst_dt(v):
    """GD370: MST doi tac de so: 10 so (chi nhanh -001 bo phan duoi); CCCD 12 so giu nguyen; '...' / rong -> ''."""
    t = re.sub(r"\D", "", str(v or ""))
    return t[:10] if len(t) in (10, 13, 14) else t


def _hd_ban_ra(h):
    v = h.get("HDBanRa")
    if isinstance(v, str):
        return v.strip().lower() in ("1", "-1", "true", "yes", "co")
    return bool(v)


def hd_tong(d, h):
    """GD370: tong thanh toan cua CA hoa don (cac dong HDDTTaiVe cung ky hieu + so + MST ban; dong le co the ghi 0)."""
    tg = d.get("_hd_tong")
    if tg is None:
        tg = d["_hd_tong"] = {}
        for x in d.get("hddt", ()):
            k = (str(x.get("KyHieuHoaDon") or "").strip(), str(x.get("SoHoaDon") or "").strip().lstrip("0"), _mst_dt(x.get("MSTNguoiBanNguoiXuatHang")))
            tg[k] = max(tg.get(k, 0.0), _f(x.get("TongTienThanhToan")))
    k = (str(h.get("KyHieuHoaDon") or "").strip(), str(h.get("SoHoaDon") or "").strip().lstrip("0"), _mst_dt(h.get("MSTNguoiBanNguoiXuatHang")))
    return max(tg.get(k, 0.0), _f(h.get("TongTienThanhToan")))


def hd_ghi_tay(d, h):
    """GD370 (dinh danh day du - truoc day chi so hoa don + thang, hoac so + MST): hoa don tai ve h da duoc GHI TAY vao so
    (bang HoaDon) khi: cung SO, cung CHIEU (mua / ban - HoaDon.Loai 1 ban, -1 mua) va
      - MST doi tac hai ben cung co va trung nhau, hoac
      - cung thang + mot ben khong co MST (khach le, '...'), hoac
      - cung thang + MST khac nhau (ghi tay sai ma khach / CCCD) nhung TIEN khop (tien chua thue x (1 + thue suat) = tong thanh toan, sai <= 0,5% / 1.000 d).
    Ky hieu ghi tay thuong sai (1C25THH cho C26MHO) nen KHONG dung de so. Hai NCC cung so hoa don, hoa don mua trung so hoa don ban -> khong con nham."""
    idx = d.get("hd_tay")
    so = str(h.get("SoHoaDon") or "").strip().lstrip("0")
    if not idx or not so or so not in idx:
        return False
    ban = _hd_ban_ra(h)
    loai = 1 if ban else -1
    mst = _mst_dt(h.get("MSTNguoiMuaNguoiNhanHang") if ban else h.get("MSTNguoiBanNguoiXuatHang"))
    g = _ngay(h.get("NgayLap"))
    tong = None
    for c in idx[so]:
        if c["loai"] in (1, -1) and c["loai"] != loai:
            continue
        if mst and c["mst"] and mst == c["mst"]:
            return True
        if g and (c["th"], c["nam"]) != (g.month, g.year):
            continue
        if not (mst and c["mst"]):
            return True
        if tong is None:
            tong = hd_tong(d, h)
        if tong > 0 and c["tien"] > 0:
            for v in (c["tien"] * (1 + c["tl"] / 100.0), c["tien"]):
                if abs(v - tong) <= max(1000.0, tong * 0.005):
                    return True
    return False


def _ngay(v):
    if isinstance(v, _dt.datetime):
        v = v.date()
    return v if isinstance(v, _dt.date) and v.year > 1990 else None


def _nd(d):
    return d.strftime("%d/%m/%Y") if d else ""


def doc(duong):
    import jet_doc
    m = jet_doc.Mdb(duong)
    try:
        bang = {b.lower(): b for b in m.bang()}

        def tb(t, n=None):
            k = bang.get(t.lower())
            return m.doc(k, n) if k else []
        lic = (tb("License", 1) or [{}])[0]
        htk = tb("HeThongTK")
        d = {"duong": duong, "lic": lic, "nam": _i(lic.get("NamTC")) or _dt.date.today().year, "dau_ky": _i(lic.get("Thang")) or 1,
             "tk": {r["MaSo"]: str(r.get("SoHieu") or "").strip() for r in htk},
             "tk_con": {r["MaSo"] for r in htk if r.get("TKCon")},
             "tk_dau": {r["MaSo"]: _f(r.get("DuNo_0")) - _f(r.get("DuCo_0")) for r in htk if not r.get("TKCon")},
             "kh": {r["MaSo"]: r for r in tb("KhachHang")}, "ct": tb("ChungTu"), "ton": tb("TonKho"), "bl": tb("BangLuong"),
             "ts": tb("TaiSan"), "vt": {r["MaSo"]: r for r in tb("Vattu")}, "hddt": [], "duong_so": duong,
             "tham_so": {str(r.get("Khoa") or ""): str(r.get("GiaTri") or "") for r in tb("HDDT_ThamSo")}}
        if not 1 <= d["dau_ky"] <= 12:
            d["dau_ky"] = 1
        for r in tb("HDDTTaiVe"):
            d["hddt"].append({k: r.get(k) for k in ("MaCT", "SoHoaDon", "KyHieuHoaDon", "MSTNguoiBanNguoiXuatHang", "MSTNguoiMuaNguoiNhanHang", "NgayLap", "MaCTKeToan", "HDBanRa",
                                                    "TongTienThanhToan", "TrangThaiHoaDon")})
        mst = {k: re.sub(r"\D", "", str(v.get("MST") or ""))[:10] for k, v in d["kh"].items()}
        d["hd_so"] = {(str(x.get("SoHD") or "").strip().lstrip("0"), mst.get(x.get("MaKhachHang"), "")) for x in tb("HoaDon")}
        mst_dt = {k: _mst_dt(v.get("MST")) for k, v in d["kh"].items()}
        d["hd_tay"] = defaultdict(list)          # GD370: hoa don ghi tay (bang HoaDon) theo so -> chieu, MST doi tac, thang, tien
        for x in tb("HoaDon"):
            so = str(x.get("SoHD") or "").strip().lstrip("0")
            if not so:
                continue
            g = _ngay(x.get("NgayPH"))
            d["hd_tay"][so].append({"loai": _i(x.get("Loai")), "mst": mst_dt.get(x.get("MaKhachHang"), ""), "th": g.month if g else 0,
                                    "nam": g.year if g else 0, "tien": _f(x.get("ThanhTien")), "tl": max(_f(x.get("TyLe")), 0.0)})
        d["hddt_da"] = {str(r.get("MaCTHDDTTaiVe") or "").strip() for r in d["ct"] if str(r.get("MaCTHDDTTaiVe") or "").strip() not in ("", "0")}
        for r in tb("HDDT_QuanHe"):
            for k in ("MaCTHDDT", "MaCT", "MaHDDT"):
                if str(r.get(k) or "").strip():
                    d["hddt_da"].add(str(r.get(k)).strip())
        return d
    finally:
        try:
            m.dong()
        except Exception:
            pass


def _u(d, s):
    try:
        import no_kho_doi as N
        return N._u(d, s)
    except Exception:
        return str(s or "")


def thang_lich(d, t):
    th = (d["dau_ky"] + t - 2) % 12 + 1
    return th, d["nam"] + (1 if th < d["dau_ky"] else 0)


def cuoi_thang(d, t):
    th, nam = thang_lich(d, t)
    return (_dt.date(nam + (th == 12), th % 12 + 1, 1) - _dt.timedelta(days=1))


def khoa_thang(d, t):
    return _i(d["lic"].get("Lock%d" % t)) % 10 == 1


def _ten_kh(d, ma):
    k = d["kh"].get(ma) or {}
    return _u(d, k.get("Ten")) or (str(k.get("SoHieu") or "") if k else "")


# ------------------------------------------------------------------ phan tich mot thang
def phan_tich_thang(d, t, theo_thang, gt=None):
    tk = d["tk"]
    sh = lambda m: tk.get(m, "")
    rows = theo_thang.get(t, [])
    bt, viec, da = [], [], []
    phieu = defaultdict(list)
    for r in rows:
        phieu[r.get("MaCT")].append(r)
    th, nam = thang_lich(d, t)

    def loi(muc, ma, r, mo_ta, cach, tien=None, no=None, co=None, dt=""):
        bt.append({"muc": muc, "ma": ma, "mact": _i(r.get("MaCT")), "so": _u(d, r.get("SoHieu")), "ngay": _nd(_ngay(r.get("NgayCT"))),
                   "no": sh(r.get("MaTKNo")) if no is None else no, "co": sh(r.get("MaTKCo")) if co is None else co,
                   "tien": _f(r.get("SoPS")) if tien is None else tien, "dt": dt, "mo_ta": mo_ta, "cach": cach})
    # 1. phieu khong can (phieu nhieu dong: moi dong mot ben)
    for mact, L in phieu.items():
        mot_ben = [r for r in L if not (_i(r.get("MaTKNo")) and _i(r.get("MaTKCo")))]
        if not mot_ben:
            continue
        sn = sum(_f(r.get("SoPS")) for r in L if _i(r.get("MaTKNo")) and not _i(r.get("MaTKCo")))
        sc = sum(_f(r.get("SoPS")) for r in L if _i(r.get("MaTKCo")) and not _i(r.get("MaTKNo")))
        if abs(sn - sc) > 1:
            r0 = L[0]
            loi("LOI", "PHIEU_LECH", r0, "Phiếu %s không cân: tổng Nợ %s, tổng Có %s (lệch %s)." % (_u(d, r0.get("SoHieu")), _dd(sn), _dd(sc), _dd(sn - sc)),
                "Mở chứng từ, bổ sung / sửa dòng còn thiếu cho tổng Nợ = tổng Có (thường thiếu dòng thuế, dòng công nợ hoặc gõ sai số tiền).",
                tien=sn - sc, no="Nợ %s" % _dd(sn), co="Có %s" % _dd(sc))
    # 2. tung dong
    khoa_trung = defaultdict(set)
    da_lech = set()
    for r in rows:
        no, co, p = _i(r.get("MaTKNo")), _i(r.get("MaTKCo")), _f(r.get("SoPS"))
        if not p:
            continue
        for m, ben in ((no, "Nợ"), (co, "Có")):
            if m and m not in tk:
                loi("LOI", "TK_LA", r, "Bên %s dùng tài khoản mã %d không có trong Hệ thống tài khoản." % (ben, m),
                    "Mở chứng từ, chọn lại tài khoản đúng (hoặc khai thêm tài khoản trong Hệ thống tài khoản).")
            elif m in d["tk_con"]:
                loi("LOI", "TK_TONG_HOP", r, "Bên %s hạch toán vào TK tổng hợp %s (đã có TK con) - sổ chi tiết và BCTC không lên số." % (ben, sh(m)),
                    "Mở chứng từ, đổi sang tài khoản chi tiết cấp dưới của %s." % sh(m))
        if no and sh(no).startswith(CONG_NO) and not _i(r.get("MaKH")):
            loi("CANH_BAO", "THIEU_DT", r, "Nợ %s không có đối tượng (khách hàng / nhà cung cấp) - sổ chi tiết công nợ sẽ lệch tổng hợp." % sh(no),
                "Mở chứng từ, chọn đối tượng cho dòng Nợ %s." % sh(no))
        if co and sh(co).startswith(CONG_NO) and not _i(r.get("MaKHC")):
            loi("CANH_BAO", "THIEU_DT", r, "Có %s không có đối tượng (khách hàng / nhà cung cấp) - sổ chi tiết công nợ sẽ lệch tổng hợp." % sh(co),
                "Mở chứng từ, chọn đối tượng cho dòng Có %s." % sh(co))
        ng = _ngay(r.get("NgayCT"))
        if ng and (ng.month, ng.year) != (th, nam) and _i(r.get("MaCT")) not in da_lech:
            da_lech.add(_i(r.get("MaCT")))
            tien_p = sum(_f(x.get("SoPS")) for x in phieu.get(r.get("MaCT"), []) if _i(x.get("MaTKNo")))
            loi("CANH_BAO", "NGAY_LECH", r, "Ngày chứng từ %s nhưng phiếu ghi vào tháng %02d/%d (cả phiếu %s)." % (_nd(ng), th, nam, _dd(tien_p)),
                "Sửa ngày chứng từ cho đúng tháng, hoặc chuyển chứng từ sang đúng tháng phát sinh.", tien=tien_p)
        so_hieu = str(r.get("SoHieu") or "").strip()
        if so_hieu and so_hieu != "..." and no and co:
            khoa_trung[(so_hieu, ng, round(p), no, co)].add(_i(r.get("MaCT")))
    for (so_hieu, ng, p, no, co), ms in khoa_trung.items():
        if len(ms) > 1:
            r0 = next(r for r in rows if _i(r.get("MaCT")) == max(ms) and str(r.get("SoHieu") or "").strip() == so_hieu)
            loi("CANH_BAO", "TRUNG", r0, "Chứng từ %s ngày %s, Nợ %s / Có %s %s có ở %d phiếu khác nhau - nghi ghi trùng." % (
                _u(d, so_hieu), _nd(ng), sh(no), sh(co), _dd(p), len(ms)),
                "Mở các phiếu cùng số, xoá phiếu ghi trùng (giữ phiếu gắn hoá đơn / sổ phụ).")
    # 3. chi tien mat tu 5 trieu co thue dau vao
    for mact, L in phieu.items():
        tm = sum(_f(r.get("SoPS")) for r in L if sh(r.get("MaTKCo")).startswith("111"))
        thue = sum(_f(r.get("SoPS")) for r in L if sh(r.get("MaTKNo")).startswith("133"))
        if tm >= MOC_TM and thue > 0:
            r0 = next(r for r in L if sh(r.get("MaTKCo")).startswith("111"))
            loi("CANH_BAO", "TM_5TR", r0, "Phiếu trả TIỀN MẶT %s có thuế GTGT đầu vào %s - hoá đơn từ 5 triệu trả tiền mặt không được khấu trừ." % (_dd(tm), _dd(thue)),
                "Nếu thực tế trả qua ngân hàng: sửa Có 111 thành Có 112. Nếu trả tiền mặt thật: chuyển thuế vào chi phí (Nợ 642 / Có 133) hoặc loại khỏi khấu trừ trên tờ khai.",
                tien=tm, no="133", co="111")
    viec_tu = _viec_thang(d, t, theo_thang, rows, gt)
    viec.extend(viec_tu[0])
    da.extend(viec_tu[1])
    return bt, viec, da


def _ps(rows, tk, ben, tien_to):
    k = "MaTKNo" if ben == "N" else "MaTKCo"
    return sum(_f(r.get("SoPS")) for r in rows if tk.get(r.get(k), "").startswith(tien_to))


def _viec_thang(d, t, theo_thang, rows, gt):
    tk = d["tk"]
    viec, da = [], []
    th, nam = thang_lich(d, t)
    n_phieu = len({r.get("MaCT") for r in rows})
    da.append("%d phiếu, %d dòng hạch toán, tổng phát sinh %s." % (n_phieu, len(rows), _dd(sum(_f(r.get("SoPS")) for r in rows))))
    # khau hao
    ps214 = _ps(rows, tk, "C", "214")
    ts_dang = [x for x in d["ts"] if 0 < _i(x.get("ThangTang")) <= t and not (0 < _i(x.get("ThangGiam")) <= t)]
    truoc214 = any(_ps(theo_thang.get(k, []), tk, "C", "214") for k in range(1, t))
    if ps214:
        da.append("Đã trích khấu hao TSCĐ %s." % _dd(ps214))
    elif ts_dang or truoc214:
        viec.append(("VUA", "KHAU_HAO", "Chưa trích khấu hao TSCĐ tháng %02d/%d (%d tài sản đang dùng)." % (th, nam, len(ts_dang)),
                     "Tài sản > Tính khấu hao tháng; bút toán Nợ 627 / 641 / 642 (theo bộ phận dùng) / Có 214.", "Tài sản cố định", 0))
    # phan bo 242
    la242 = [m for m, s in tk.items() if s.startswith("242") and m in d["tk_dau"]]
    du242 = sum(d["tk_dau"].get(m, 0) for m in la242)
    for k in range(1, t):
        du242 += _ps(theo_thang.get(k, []), tk, "N", "242") - _ps(theo_thang.get(k, []), tk, "C", "242")
    c242 = _ps(rows, tk, "C", "242")
    if c242:
        da.append("Đã phân bổ chi phí trả trước (Có 242) %s." % _dd(c242))
    elif du242 > 1000:
        viec.append(("VUA", "PHAN_BO_242", "Chi phí trả trước 242 còn %s đầu tháng nhưng chưa phân bổ tháng này." % _dd(du242),
                     "Công cụ dụng cụ / Chi phí trả trước > Phân bổ tháng; bút toán Nợ 627 / 641 / 642 / Có 242.", "Công cụ dụng cụ", du242))
    # luong
    bl = [r for r in d["bl"] if _i(r.get("thang")) in (th, t)]
    tong_bl = sum(_f(r.get("tongthunhap")) for r in bl)
    c334 = _ps(rows, tk, "C", "334")
    if c334:
        da.append("Đã trích lương (Có 334) %s." % _dd(c334))
    if tong_bl > 0 and c334 < tong_bl * 0.5:
        viec.append(("NANG", "LUONG", "Bảng lương tháng %s nhưng Có 334 trong tháng mới %s - chưa trích (đủ) lương." % (_dd(tong_bl), _dd(c334)),
                     "Nhân viên - lương > Trích lương tháng; bút toán Nợ 622 / 627 / 641 / 642 / Có 334 theo bảng lương.", "Nhân viên - lương", tong_bl - c334))
    bh = sum(_f(r.get("DNBHXH")) + _f(r.get("DNBHYT")) + _f(r.get("DNBHTN")) for r in bl)
    c338 = _ps(rows, tk, "C", "338")
    if bh > 0 and c338 < bh * 0.5:
        viec.append(("VUA", "BAO_HIEM", "Bảo hiểm doanh nghiệp đóng theo bảng lương %s chưa trích (Có 338 tháng %s)." % (_dd(bh), _dd(c338)),
                     "Trích BHXH / BHYT / BHTN / KPCĐ: Nợ 622 / 642... / Có 3383, 3384, 3386, 3382.", "Nhân viên - lương", bh - c338))
    # ket chuyen 911
    kq_tk = ("511", "515", "521", "632", "635", "641", "642", "711", "811", "821")
    co_ps_kq = any(tk.get(r.get("MaTKNo"), "").startswith(kq_tk) or tk.get(r.get("MaTKCo"), "").startswith(kq_tk) for r in rows
                   if not (tk.get(r.get("MaTKNo"), "").startswith("911") or tk.get(r.get("MaTKCo"), "").startswith("911")))
    co911 = any(tk.get(r.get("MaTKNo"), "").startswith("911") or tk.get(r.get("MaTKCo"), "").startswith("911") for r in rows)
    if co911:
        da.append("Đã kết chuyển xác định kết quả kinh doanh (911).")
    elif co_ps_kq:
        viec.append(("NANG", "KC_911", "Có doanh thu / chi phí phát sinh nhưng chưa kết chuyển sang 911.",
                     "Kết chuyển cuối kỳ (màn hình AI > Kết chuyển cuối kỳ, hoặc Tổng hợp > Kết chuyển): Nợ 511, 515, 711 / Có 911; Nợ 911 / Có 632, 635, 641, 642, 811; "
                     "lãi lỗ Nợ / Có 911 - 4212.", "Kết chuyển cuối kỳ", 0))
    # thue GTGT
    n133 = _ps(rows, tk, "N", "133")
    c3331 = _ps(rows, tk, "C", "3331")
    kc_thue = sum(_f(r.get("SoPS")) for r in rows if tk.get(r.get("MaTKNo"), "").startswith("3331") and tk.get(r.get("MaTKCo"), "").startswith("133"))
    if kc_thue:
        da.append("Đã kết chuyển thuế GTGT khấu trừ (Nợ 3331 / Có 133) %s." % _dd(kc_thue))
    elif n133 and c3331:
        viec.append(("NHE", "THUE_GTGT", "Có thuế đầu vào %s và đầu ra %s nhưng chưa kết chuyển khấu trừ." % (_dd(n133), _dd(c3331)),
                     "Cuối kỳ kê khai: Nợ 3331 / Có 133 số nhỏ hơn giữa hai bên (khớp tờ khai 01/GTGT).", "Kết chuyển cuối kỳ", min(n133, c3331)))
    # hoa don dien tu chua hach toan
    gom = {}
    for h in d["hddt"]:
        ng = _ngay(h.get("NgayLap"))
        if not ng or (ng.month, ng.year) != (th, nam):
            continue
        if "thay thế" in str(h.get("TrangThaiHoaDon") or "").lower() or "huỷ" in str(h.get("TrangThaiHoaDon") or "").lower() or "hủy" in str(h.get("TrangThaiHoaDon") or "").lower():
            continue
        doi = h.get("MSTNguoiMuaNguoiNhanHang") if h.get("HDBanRa") else h.get("MSTNguoiBanNguoiXuatHang")
        so = str(h.get("SoHoaDon") or "").strip().lstrip("0")
        k = (str(h.get("KyHieuHoaDon") or ""), so, re.sub(r"\D", "", str(doi or ""))[:10])
        da_ht = (bool(str(h.get("MaCTKeToan") or "").strip() not in ("", "0")) or str(h.get("MaCT") or "").strip() in d["hddt_da"]
                 or hd_ghi_tay(d, h))          # GD370
        gom[k] = gom.get(k, False) or da_ht
    chua = sum(1 for v in gom.values() if not v)
    if gom:
        da.append("Hoá đơn điện tử trong tháng: %d, đã hạch toán %d." % (len(gom), len(gom) - chua))
    if chua:
        viec.append(("VUA", "HDDT_CHUA_HT", "%d hoá đơn điện tử tháng %02d/%d chưa hạch toán vào sổ." % (chua, th, nam),
                     "Màn hình AI > Hoá đơn: chọn hoá đơn chưa hạch toán, Phân tích rồi Ghi (xem trước bút toán).", "AI hoá đơn", 0))
    # ton kho am
    am = []
    for r in d["ton"]:
        q = _f(r.get("Luong_%d" % t))
        if q < -1e-6:
            v = d["vt"].get(r.get("MaVatTu")) or {}
            am.append("%s (%s)" % (str(v.get("SoHieu") or r.get("MaVatTu")), ("%g" % q)))
    if am:
        viec.append(("NANG", "TON_AM", "%d mặt hàng tồn kho âm cuối tháng: %s." % (len(am), ", ".join(am[:6])),
                     "Nhập bổ sung phiếu nhập còn thiếu (hàng về trước hoá đơn sau) hoặc sửa phiếu xuất vượt tồn; tính lại giá xuất.", "Vật tư - kho", 0))
    # GD357: doanh nghiep dich vu (da dat TK xuat thang NVL) - 152 con ton cuoi thang -> xuat thang sang chi phi
    if (d.get("tham_so") or {}).get("XT357_TK"):
        la152 = {r.get("MaTaiKhoan") for r in d["ton"] if tk.get(r.get("MaTaiKhoan"), "").startswith("152")}
        t152 = sum(_f(r.get("Tien_%d" % t)) for r in d["ton"] if r.get("MaTaiKhoan") in la152)
        if t152 > 1000:
            viec.append(("VUA", "NVL_TON_DV", "NVL (152) còn tồn %s cuối tháng - doanh nghiệp dịch vụ: NVL mua về dùng ngay, chưa xuất thẳng sang chi phí." % _dd(t152),
                         "Trung tâm điều hành > Kho > Xuất thẳng NVL sang chi phí: Nợ %s / Có 152 cho các phiếu nhập chưa xuất." % d["tham_so"]["XT357_TK"],
                         "Xuất thẳng NVL", t152))
    # gia thanh (GD350)
    if gt:
        for v in gt:
            if v[1] in ("LUONG_CHUA_TRICH", "NVL_AM"):
                continue                                   # da co o LUONG / TON_AM
            viec.append((v[0], "GT_" + v[1], v[2], "Giá thành: " + v[3], "Giá thành", v[4] if len(v) > 4 else 0))
    return viec, da


def _quy_am(d, theo_thang, t_max):
    """tien mat 111 / tien gui 112 am: ngay dau tien am trong tung thang + dong lam am. -> {t: [bt...]}"""
    tk = d["tk"]
    ra = defaultdict(list)
    for tien_to, ten in (("111", "Tiền mặt"), ("112", "Tiền gửi ngân hàng")):
        la = {m for m, s in tk.items() if s.startswith(tien_to)}
        du = sum(v for m, v in d["tk_dau"].items() if m in la)
        for t in range(1, t_max + 1):
            ngay = defaultdict(list)
            for r in theo_thang.get(t, []):
                ngay[_ngay(r.get("NgayCT")) or _dt.date(1900, 1, 1)].append(r)
            bao = False
            for ng in sorted(ngay):                         # cong / tru ca ngay roi moi xet am (thu - chi trong ngay khong bao nham)
                chi = []
                for r in ngay[ng]:
                    p = _f(r.get("SoPS"))
                    if r.get("MaTKNo") in la:
                        du += p
                    if r.get("MaTKCo") in la:
                        du -= p
                        chi.append(r)
                if du < -1 and chi and not bao:
                    r = max(chi, key=lambda x: _f(x.get("SoPS")))
                    p = _f(r.get("SoPS"))
                    if True:
                        bao = True
                        ra[t].append({"muc": "LOI", "ma": "QUY_AM", "mact": _i(r.get("MaCT")), "so": _u(d, r.get("SoHieu")), "ngay": _nd(_ngay(r.get("NgayCT"))),
                                      "no": tk.get(r.get("MaTKNo"), ""), "co": tk.get(r.get("MaTKCo"), ""), "tien": p, "dt": "",
                                      "mo_ta": "%s âm %s cuối ngày %s (khoản chi lớn nhất ngày đó)." % (ten, _dd(du), _nd(ng)),
                                      "cach": "Kiểm tra phiếu thu / sổ phụ ngân hàng ghi thiếu trước ngày này, hoặc ngày chứng từ chi ghi sớm; bổ sung thu / sửa ngày rồi kiểm lại."})
    return ra


def phan_tich(d, tu=1, den=None):
    theo_thang = defaultdict(list)
    for r in d["ct"]:
        t = _i(r.get("ThangCT"))
        if 1 <= t <= 12 and (_f(r.get("SoPS"))):
            theo_thang[t].append(r)
    co_dl = sorted(theo_thang)
    den = den or (max(co_dl) if co_dl else 1)
    tu = max(1, min(tu, den))
    quy = _quy_am(d, theo_thang, den)
    gt_ds = {}
    try:
        import gia_thanh_phuong_an as GT
        dg = GT.doc(d["duong"])
        for t in range(tu, den + 1):
            if any(_i(p.get("Thang")) == t for p in dg["tp"]) or any(GT._i(r.get("ThangCT")) == t and dg["tk"].get(r.get("MaTKNo"), "").startswith("154") for r in dg["ct"]):
                g = GT.phan_tich(dg, t)
                gt_ds[t] = [v for v in g["viec"] if v[0] in ("NANG", "VUA")]
    except Exception:
        pass
    thang = []
    truoc_khoa = khoa_thang(d, tu - 1) if tu > 1 else True
    for t in range(tu, den + 1):
        bt, viec, da = phan_tich_thang(d, t, theo_thang, gt_ds.get(t))
        bt = quy.get(t, []) + bt
        n_loi = sum(1 for x in bt if x["muc"] == "LOI")
        n_cb = sum(1 for x in bt if x["muc"] == "CANH_BAO")
        n_nang = sum(1 for v in viec if v[0] == "NANG")
        da_khoa = khoa_thang(d, t)
        diem = max(0, 100 - 10 * n_loi - 2 * n_cb - 15 * n_nang - 5 * sum(1 for v in viec if v[0] == "VUA"))
        if da_khoa:
            tt = "DA_KHOA"
        elif n_loi == 0 and n_nang == 0 and truoc_khoa:
            tt = "DUOC_KHOA"
        else:
            tt = "CHUA_KHOA"
        if not truoc_khoa and not da_khoa:
            viec.insert(0, ("NANG", "THANG_TRUOC", "Tháng trước chưa khoá - khoá sổ theo thứ tự từng tháng.",
                            "Xử lý và khoá tháng trước trước, rồi mới khoá tháng này.", "Trung tâm khoá sổ", 0))
        th, nam = thang_lich(d, t)
        bt.sort(key=lambda x: (0 if x["muc"] == "LOI" else 1, x["ma"], x["ngay"][-4:] + x["ngay"][3:5] + x["ngay"][:2], x["mact"]))
        thang.append({"t": t, "th": "%02d/%d" % (th, nam), "tt": tt, "diem": diem, "n_loi": n_loi, "n_cb": n_cb, "n_nang": n_nang,
                      "bt": bt, "viec": viec, "da": da, "da_khoa": da_khoa})
        truoc_khoa = da_khoa
    return {"tu": tu, "den": den, "thang": thang, "nam": d["nam"], "ten": _u(d, d["lic"].get("TenCty")), "so": os.path.basename(d["duong"])}


# ------------------------------------------------------------------ ghi
def ghi(kq, thu_muc):
    os.makedirs(thu_muc, exist_ok=True)
    L = ["TONG;%s;%d;%d;%d;%s" % (_s(kq["so"]), kq["nam"], kq["tu"], kq["den"], _dt.datetime.now().strftime("%d/%m/%Y %H:%M"))]
    for m in kq["thang"]:
        L.append("THANG;%d;%s;%s;%d;%d;%d;%d;%d;%d" % (m["t"], m["th"], m["tt"], m["diem"], m["n_loi"], m["n_cb"], m["n_nang"], len(m["viec"]), 1 if m["da_khoa"] else 0))
        for x in m["bt"][:400]:
            L.append("BT;%d;%s;%s;%d;%s;%s;%s;%s;%s;%s;%s;%s" % (m["t"], x["muc"], x["ma"], x["mact"], _s(x["so"])[:30], x["ngay"], _s(x["no"])[:20], _s(x["co"])[:20],
                                                              _dd(x["tien"]), _s(x["dt"])[:60], _s(x["mo_ta"])[:300], _s(x["cach"])[:300]))
        for v in m["viec"]:
            L.append("VIEC;%d;%s;%s;%s;%s;%s;%s" % (m["t"], v[0], v[1], _s(v[2])[:300], _s(v[3])[:300], _s(v[4])[:60], _dd(v[5]) if v[5] else ""))
        for s in m["da"]:
            L.append("DA;%d;%s" % (m["t"], _s(s)[:300]))
    p_txt = os.path.join(thu_muc, TEP + ".txt")
    with io.open(p_txt, "w", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")
    p_html = os.path.join(thu_muc, TEP + ".html")
    with io.open(p_html, "w", encoding="utf-8") as f:
        f.write(_html(kq))
    return p_txt, p_html


TEN_MUC = {"LOI": "LỖI", "CANH_BAO": "CẦN XEM", "NANG": "NẶNG", "VUA": "VỪA", "NHE": "NHẸ"}
TEN_TT = {"DA_KHOA": ("Đã khoá", "#1d6b34"), "DUOC_KHOA": ("Được khoá", "#0d5c8c"), "CHUA_KHOA": ("Chưa khoá được", "#a3262a")}


def _html(kq):
    e = html.escape
    p = ["<!doctype html><html lang='vi'><head><meta charset='utf-8'><title>Khoá sổ theo tháng</title><style>"
         "body{font-family:Segoe UI,Arial,sans-serif;background:#f4f6f8;color:#17212b;margin:0;padding:16px;font-size:14px}h1{font-size:21px;margin:0 0 4px}"
         "h2{font-size:17px;margin:22px 0 6px}.mu{color:#5a6672}.th{background:#fff;border:1px solid #d6dce2;border-radius:8px;padding:12px 14px;margin:14px 0}"
         ".tag{color:#fff;border-radius:4px;padding:2px 8px;font-weight:600;font-size:12px}table{border-collapse:collapse;width:100%;margin:6px 0}"
         "th,td{border-bottom:1px solid #e1e6ea;padding:5px 7px;text-align:left;vertical-align:top}th{font-size:12px;color:#5a6672}.n{text-align:right;white-space:nowrap}"
         ".LOI,.NANG{color:#a3262a;font-weight:600}.CANH_BAO,.VUA{color:#9a5b00;font-weight:600}.NHE{color:#0d5c8c}.sc{overflow-x:auto}</style></head><body>"]
    p.append("<h1>Kiểm tra tổng hợp khoá sổ – %s</h1><p class='mu'>%s · năm %d · tháng %d → %d · máy chỉ đọc sổ, không ghi. Khoá tháng theo thứ tự: tháng trước khoá rồi mới khoá tháng sau.</p>" % (
        e(kq["ten"]), e(kq["so"]), kq["nam"], kq["tu"], kq["den"]))
    p.append("<div class='sc'><table><tr><th>Tháng</th><th>Kết luận</th><th>Điểm</th><th>Bút toán lỗi</th><th>Cần xem</th><th>Việc nặng</th><th>Việc</th></tr>%s</table></div>" % "".join(
        "<tr><td><a href='#t%d'>%s</a></td><td><span class='tag' style='background:%s'>%s</span></td><td class='n'>%d</td><td class='n'>%d</td><td class='n'>%d</td><td class='n'>%d</td><td class='n'>%d</td></tr>" % (
            m["t"], m["th"], TEN_TT[m["tt"]][1], TEN_TT[m["tt"]][0], m["diem"], m["n_loi"], m["n_cb"], m["n_nang"], len(m["viec"])) for m in kq["thang"]))
    for m in kq["thang"]:
        p.append("<div class='th' id='t%d'><h2>Tháng %s – <span class='tag' style='background:%s'>%s</span> · điểm %d</h2>" % (m["t"], m["th"], TEN_TT[m["tt"]][1], TEN_TT[m["tt"]][0], m["diem"]))
        p.append("<b>Đã làm</b><ul>%s</ul>" % "".join("<li>%s</li>" % e(s) for s in m["da"]))
        p.append("<b>Cần làm trước khi khoá</b><div class='sc'><table><tr><th>Mức</th><th>Việc</th><th>Cách làm / bút toán</th><th>Làm ở đâu</th><th>Số tiền</th></tr>%s</table></div>" % (
            "".join("<tr><td class='%s'>%s</td><td>%s</td><td>%s</td><td>%s</td><td class='n'>%s</td></tr>" % (v[0], TEN_MUC.get(v[0], v[0]), e(v[2]), e(v[3]), e(v[4]), _dd(v[5]) if v[5] else "")
                    for v in m["viec"]) or "<tr><td colspan=5>Không có</td></tr>"))
        p.append("<b>Bút toán sai / cần xem (%d)</b><div class='sc'><table><tr><th>Mức</th><th>Lỗi</th><th>Số CT</th><th>Ngày</th><th>Nợ</th><th>Có</th><th>Số tiền</th><th>Mô tả</th><th>Cách sửa</th></tr>%s</table></div></div>" % (
            len(m["bt"]), "".join("<tr><td class='%s'>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td class='n'>%s</td><td>%s</td><td>%s</td></tr>" % (
                x["muc"], TEN_MUC.get(x["muc"], x["muc"]), e(DT_TEN.get(x["ma"], x["ma"])), e(x["so"]), x["ngay"], e(x["no"]), e(x["co"]), _dd(x["tien"]), e(x["mo_ta"]), e(x["cach"])) for x in m["bt"][:400])
            or "<tr><td colspan=9>Không có</td></tr>"))
    p.append("</body></html>")
    return "".join(p)


def chay(duong, tu=1, den=None, thu_muc=None):
    d = doc(duong)
    kq = phan_tich(d, tu, den)
    p_txt, p_html = ghi(kq, thu_muc or os.path.join(HERE, "ket-qua"))
    return kq, p_txt, p_html


def main(argv):
    t = {}
    for a in argv[1:]:
        if a.startswith("/") and ":" in a:
            k, v = a[1:].split(":", 1)
            t[k.lower()] = v.strip('"')
    if not t.get("so"):
        print('python khoa_so_thang.py /so:"<so.MDB>" [/tu:1] [/den:12] [/ra:<thu muc>]')
        return 1
    kq, p1, p2 = chay(t["so"], int(t.get("tu") or 1), int(t.get("den") or 0) or None, t.get("ra"))
    for m in kq["thang"]:
        print("%s %s diem %d loi %d cb %d nang %d viec %d" % (m["th"], m["tt"], m["diem"], m["n_loi"], m["n_cb"], m["n_nang"], len(m["viec"])))
    print(p2)
    return 0


if __name__ == "__main__":
    import sys
    sys.exit(main(sys.argv))
