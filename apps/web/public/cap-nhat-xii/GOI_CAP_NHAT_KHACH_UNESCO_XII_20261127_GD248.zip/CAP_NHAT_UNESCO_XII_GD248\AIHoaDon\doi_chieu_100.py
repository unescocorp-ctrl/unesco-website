# -*- coding: utf-8 -*-
"""GD338 - DIEU HANH 100 BO SO: chup hien trang (nhom A/B/C/D), doi chieu T1..T(ky gan nhat) voi nguon chan ly, hang doi viec
   can nguoi GOP moi bo so, chi so van hanh. CHI DOC .MDB (jet_doc, mo 'rb'); chi ghi tep ket qua.

Goi tu hang_loat.py (tien trinh con moi bo so):  dc = doi_chieu(duong, hom_nay, dh)   (dh = bang_dieu_hanh.tinh)
Tong hop (tien trinh cha):  them_sheet(wb, kieu, ket, ...), lap_hang_doi(ket, ...), ghi_lich_su(ket, ...)

Ma chenh lech (tra loi / giai trinh trong tra_loi.txt cua bo so, dang MA;KHOA;BO_QUA|DA_LAM|HEN;ly do - nhu GD250):
  DC1 hoa don CQT chua co chung tu        DC2 lien ket hoa don -> chung tu bi mat     DC3 hoa don huy / bi thay the da hach toan
  DC4 so du 112 cuoi thang <> sao ke      DC5 thieu sao ke thang co phat sinh 112     DC6 doanh thu 511 <> hoa don ban ra
  DC7 thue 3331 <> thue hoa don ban ra    DC8 thue 133 <> thue hoa don mua vao        DC9 phat sinh 334 <> bang luong
  DC10 ton kho am                         DC11 trung ma doi tac                      DC12 thang khong co chung tu / thieu bang luong
  DC13 chua tai hoa don CQT thang co phat sinh   DC14 chung tu ghi ngay sau hom nay (thong tin)
  DC15 (GD340) chi tieu to khai 01/GTGT da xuat HTKK (htkk-sao-luu/<MST>, ban moi nhat cua ky) <> so hien tai:
       [24] <-> No 133, [35] <-> Co 3331, [34] <-> doanh thu 511 thuan. Ky da nop (DVC) -> LOI (so doi sau khi nop: khai bo sung?),
       chua nop -> CANH BAO (xuat lai to khai truoc khi nop). DC16 ky da ket thuc chua co to khai xuat HTKK (thong tin).
KHOA = thang (vd 07) / so hoa don / so TK ngan hang / ma vat tu; * = ca ma.
"""
import datetime as _dt
import io
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))

LOI, CB, TT = "LOI", "CANH_BAO", "THONG_TIN"
TEN_MUC = {LOI: "LỖI", CB: "CẢNH BÁO", TT: "THÔNG TIN"}
THU_MUC_UT = {LOI: 0, CB: 1, TT: 2}
TRAM = {"DC15": 8, "DC16": 8, "DC13": 1, "DC14": 4, "DC1": 1, "DC2": 4, "DC3": 1, "DC4": 3, "DC5": 1, "DC6": 8, "DC7": 8, "DC8": 8, "DC9": 4, "DC10": 5, "DC11": 2, "DC12": 1}
LAM_O = {
    "DC1": "Màn hình AI > Hoá đơn: lập chứng từ cho hoá đơn Sẵn sàng lập (hoặc đánh dấu Bỏ qua kèm lý do)",
    "DC2": "Màn hình AI > Hoá đơn: chứng từ đã bị xoá - Kiểm tra lại trạng thái / lập lại chứng từ",
    "DC3": "Màn hình AI > Hoá đơn Cần xem lại: huỷ hoặc điều chỉnh chứng từ của hoá đơn bị huỷ / bị thay thế",
    "DC4": "Thẻ Sổ phụ NH: đối chiếu số dư, ghi các dòng chưa hạch toán; kiểm tra chứng từ 112 nhập tay",
    "DC5": "Xin khách sao kê tháng còn thiếu, Import sổ phụ",
    "DC6": "Đối chiếu HĐĐT bán ra với 511 (Kiểm tra khoá sổ / Đối chiếu HĐĐT)",
    "DC7": "Đối chiếu thuế bán ra 3331 với bảng kê bán ra trước khi lập 01/GTGT",
    "DC8": "Đối chiếu thuế đầu vào 133 với bảng kê mua vào (hoá đơn chưa hạch toán / hạch toán sai kỳ)",
    "DC9": "Đối chiếu bảng lương với chứng từ 334 (Tính lương / Lập chứng từ lương)",
    "DC10": "Tính lại tồn kho, nhập bù NVL (hàng về trước hoá đơn sau) hoặc sửa phiếu xuất",
    "DC11": "Danh mục khách hàng: Gộp mã trùng theo đề xuất AI",
    "DC12": "Xin khách chứng từ / bảng lương tháng còn thiếu",
    "DC13": "Tải hoá đơn từ CQT các tháng còn thiếu (Màn hình AI > Tải hoá đơn, nhập captcha)",
    "DC14": "Xem lại ngày chứng từ (lập trước cho kỳ sau hay ghi nhầm năm)",
    "DC15": "Báo cáo & thuế > Tờ khai 01/GTGT: xem trước, so với sổ; kỳ đã nộp mà sổ đổi -> lập tờ khai bổ sung; chưa nộp -> xuất lại XML",
    "DC16": "Lập tờ khai 01/GTGT của kỳ (Báo cáo & thuế), xuất XML vào HTKK",
}


def _so(x):
    try:
        return float(x or 0)
    except (TypeError, ValueError):
        try:
            return float(str(x).replace(",", "."))
        except (TypeError, ValueError):
            return 0.0


def _ngay(x):
    import bang_dieu_hanh as DH
    return DH._ngay(x)


def vn(d):
    return d.strftime("%d/%m/%Y") if d else ""


def tien(v):
    return "{:,.0f}".format(v or 0).replace(",", ".")


def _bo_dau(s):
    import bang_dieu_hanh as DH
    return DH.bo_dau(s)


def _thap(r):
    return {str(k).lower(): v for k, v in r.items()}


# ------------------------------------------------------------------ doc du lieu
def _doc(duong):
    import jet_doc
    m = jet_doc.Mdb(duong)
    try:
        bang = {k.lower(): k for k in m.bang()}

        def doc(t, n=None):
            k = bang.get(t.lower())
            return [_thap(r) for r in m.doc(k, n)] if k else []
        d = {"lic": (doc("License", 1) or [{}])[0], "tk": doc("HethongTK"), "ct": doc("ChungTu"), "hd": doc("HDDTTaiVe"),
             "sp": doc("HDDT_SP_Dong"), "tknh": doc("HDDT_SP_TaiKhoanNH"), "kh": doc("KhachHang"), "tonkho": doc("TonKho"),
             "bl": doc("BangLuong"), "dvc": doc("HDDT_DVC_Dong"), "hoadon": doc("HoaDon"),
             "qh": doc("HDDT_QuanHe"), "nk_chedo": [r for r in doc("HDDT_NhatKy") if str(r.get("loai") or "").upper() in ("CHE_DO", "SUA_DONG_HD", "CAN_XEM_LAI", "HUY")]}     # GD347 (F06)
    finally:
        m.dong()
    return d


def _thang_ky(lic, hom_nay):
    """-> (thang_dau, nam, [thang duong lich da KET THUC trong nam tai chinh, theo thu tu], ham chi so nam TC)"""
    dau = int(_so(lic.get("thang"))) or 1
    if not 1 <= dau <= 12:
        dau = 1
    nam = int(_so(lic.get("namtc"))) or hom_nay.year
    ds = []
    for i in range(12):
        y, m = nam + (dau + i - 1) // 12, (dau + i - 1) % 12 + 1
        c = _dt.date(y + (1 if m == 12 else 0), 1 if m == 12 else m + 1, 1) - _dt.timedelta(days=1)
        if c < hom_nay:
            ds.append((y, m))
    return dau, nam, ds


def _la_huy(tt):
    t = _bo_dau(tt).upper()
    return "HUY" in t or "DA BI THAY THE" in t


def _chuan_ten(s):
    t = re.sub(r"[^A-Z0-9 ]+", " ", _bo_dau(s).upper())
    t = " " + re.sub(r"\s+", " ", t).strip() + " "
    for w in (" CONG TY ", " CTY ", " CT ", " TNHH ", " CO PHAN ", " CP ", " MOT THANH VIEN ", " MTV ", " DNTN ", " DOANH NGHIEP TU NHAN ",
              " HKD ", " HO KINH DOANH ", " VIET NAM ", " VN "):
        t = t.replace(w, " ")
    return t.replace(" ", "")


def _ten_kh(s, font):
    import hang_loat
    return hang_loat.chu_u(s, font)


# ------------------------------------------------------------------ mot bo so
def doi_chieu(duong, hom_nay, dh=None):
    """-> {"hien_trang": {...}, "cl": [[ma, muc, khoa, viec, so lieu]], "nhom": A/B/C/D, "ly_do_nhom": [..], "chi_so": {...}}"""
    d = _doc(duong)
    lic = d["lic"]
    font = lic.get("fontname")
    dau, nam, thangs = _thang_ky(lic, hom_nay)
    tm_set = set(m for _, m in thangs)
    dh = dh or {}
    cl = []

    def them(ma, muc, khoa, viec, so_lieu=""):
        cl.append([ma, muc, str(khoa), viec, so_lieu])

    # tai khoan
    tk = {int(_so(r.get("maso"))): r for r in d["tk"]}
    sh = {k: str(r.get("sohieu") or "").strip() for k, r in tk.items()}
    co_con = set(int(_so(r.get("tkcha0"))) for r in d["tk"])

    def goc(ms, g):
        return sh.get(ms, "").startswith(g)
    # chung tu theo thang (lich)
    ct_thang, ct_mact = {}, set()
    ps = []                                              # (thang, no, co, tien)
    for r in d["ct"]:
        th = int(_so(r.get("thangct")))
        mact = int(_so(r.get("mact")))
        ct_mact.add(mact)
        if not 1 <= th <= 12:
            continue
        ct_thang[th] = ct_thang.get(th, 0) + 1
        no, co, s = int(_so(r.get("matkno"))), int(_so(r.get("matkco"))), _so(r.get("sops"))
        if s and (no or co):
            ps.append((th, no, co, s))
    # ---- DC12 thang khong co chung tu
    thang_trong = [m for _, m in thangs if not ct_thang.get(m)]
    if thang_trong and ct_thang:
        dau_co = next((i for i, (_, m) in enumerate(thangs) if ct_thang.get(m)), None)
        thieu = [m for i, (_, m) in enumerate(thangs) if not ct_thang.get(m) and dau_co is not None and i > dau_co]
        for m in thieu:
            them("DC12", CB, "%02d" % m, "Tháng %d không có chứng từ nào" % m)
    # ---- hoa don
    hd = {}
    for r in d["hd"]:
        k = str(r.get("mact") or "")
        if not k:
            continue
        x = hd.setdefault(k, {"ban": bool(r.get("hdbanra")), "ngay": _ngay(r.get("ngaylap")), "so": str(r.get("sohoadon") or "").strip(),
                              "ky6": _ky6(r.get("kyhieuhoadon")),
                              "mst": re.sub(r"\D", "", str((r.get("mstnguoimuanguoinhanhang") if r.get("hdbanra") else r.get("mstnguoibannguoixuathang")) or ""))[:10],
                              "tt": str(r.get("trangthaihoadon") or ""), "mact": str(r.get("mactketoan") or "").strip(),
                              "ai": str(r.get("aivalidationstatus") or "").upper(), "lo": str(r.get("aibatchid") or "").strip(),
                              "tien": 0.0, "thue": 0.0, "dt": str(r.get("tennguoibannguoixuathang") or r.get("tennguoimuanguoinhanhang") or "")[:60]})
        x["tien"] += _so(r.get("thanhtienchuathue"))
        x["thue"] += _so(r.get("tienthue"))
    # hoa don nhap tay tren so (bang HoaDon): khoa (so HD, 6 ky tu cuoi ky hieu) va (so HD, MST doi tac)
    mst_kh = {int(_so(r.get("maso"))): re.sub(r"\D", "", str(r.get("mst") or "")) for r in d["kh"]}
    idx_ky, idx_mst, idx_tien = set(), set(), {}
    for r in d["hoadon"]:
        so = _so_hd(r.get("sohd"))
        if not so:
            continue
        ky = _ky6(r.get("kyhieu"))
        if ky:
            idx_ky.add((so, ky[-3:]))                    # 3 ky tu cuoi: nguoi nhap tay hay giu nam cu (1C25TTT <-> C26TTT)
        mst = mst_kh.get(int(_so(r.get("makhachhang"))), "")
        if len(mst) >= 10:
            idx_mst.add((so, mst[:10]))
        k2 = (so, ky[-3:] if ky else "")
        a = idx_tien.setdefault(so, {}).setdefault(k2, [_ngay(r.get("ngayph")), 0.0])
        a[1] += _so(r.get("thanhtien"))
    hd_den = None
    ky_set = set(thangs)
    n_tay = 0
    chua_thang = {}
    n_chua = t_chua = n_hong = n_huy = 0
    n_ht = n_may = 0
    # GD347 (F06): may lap = HDDT_QuanHe AI_LAP (khong con dua vao AIBatchID - lo xem truoc / gan tay cung co lo); khong cham tay =
    #   nhat ky CHE_DO TU_DONG va khong co SUA_DONG_HD / CAN_XEM_LAI / HUY cho hoa don do
    qh_may, qh_tay = set(), set()
    for r in d.get("qh") or []:
        lo = str(r.get("loai") or "").upper()
        (qh_may if lo == "AI_LAP" else qh_tay if lo in ("GAN_TAY", "GAN_CO_SAN") else set()).add(str(r.get("khoacon") or ""))
    che_do, cham = {}, set()
    for r in d.get("nk_chedo") or []:
        k = str(r.get("mact") or "")
        if str(r.get("loai") or "").upper() == "CHE_DO":
            che_do[k] = str(r.get("noidung") or "").split(" ")[0].upper()
        else:
            cham.add(k)
    n_tay_gan = n_khong_cham = n_biet = n_tu_ghi = n_nguoi_ghi = 0
    hd_ban, hd_mua = {}, {}
    for k, x in hd.items():
        ng = x["ngay"]
        if ng and (hd_den is None or ng > hd_den):
            hd_den = ng
        trong_ky = bool(ng) and (ng.year, ng.month) in ky_set
        huy = _la_huy(x["tt"])
        so_ct = [int(v) for v in re.findall(r"\d+", x["mact"])]
        if so_ct:
            n_ht += 1
            if k in qh_may:
                n_may += 1
                if k in che_do:
                    n_biet += 1
                    if che_do[k] == "TU_DONG":
                        n_tu_ghi += 1
                        if k not in cham:
                            n_khong_cham += 1
                    else:
                        n_nguoi_ghi += 1                  # XEM_TRUOC / NGUOI: nguoi bam Ghi
            elif k in qh_tay:
                n_tay_gan += 1
            elif x["lo"] and not d.get("qh"):
                n_may += 1                                   # so rat cu chua co HDDT_QuanHe: giu cach dem theo lo
        if not trong_ky:
            continue
        if not huy:
            (hd_ban if x["ban"] else hd_mua).setdefault(ng.month, [0.0, 0.0])
            a = (hd_ban if x["ban"] else hd_mua)[ng.month]
            a[0] += x["tien"]
            a[1] += x["thue"]
        if huy and so_ct:
            n_huy += 1
            them("DC3", LOI, x["so"], "Hoá đơn %s %s số %s ngày %s (%s) đã hạch toán" % ("bán" if x["ban"] else "mua", _bo_huy(x["tt"]), x["so"], vn(ng), x["dt"][:40]),
                 tien(x["tien"] + x["thue"]))
        elif so_ct and not any(v in ct_mact for v in so_ct):
            n_hong += 1
            them("DC2", LOI, x["so"], "Hoá đơn số %s ngày %s: chứng từ liên kết (MaCT %s) không còn trong sổ" % (x["so"], vn(ng), x["mact"][:20]), tien(x["tien"] + x["thue"]))
        elif not so_ct and not huy and x["ai"] not in ("BO_QUA",):
            so = _so_hd(x["so"])
            if so and ((so, x["ky6"][-3:]) in idx_ky or (len(x["mst"]) >= 10 and (so, x["mst"]) in idx_mst) or _khop_tien(idx_tien.get(so), ng, x["tien"])):
                n_tay += 1                                    # da co tren so (nhap tay, bang HoaDon) - khong phai sot
                continue
            n_chua += 1
            t_chua += x["tien"] + x["thue"]
            chua_thang[ng.month] = chua_thang.get(ng.month, 0) + 1
    if n_chua:
        them("DC1", CB if n_chua < 20 else LOI, "*", "%d hoá đơn CQT trong kỳ chưa thấy trên sổ (không có chứng từ AI, không khớp số + ký hiệu / MST trong bảng hoá đơn nhập tay)" % n_chua,
             "%s; theo tháng: %s" % (tien(t_chua), ", ".join("T%d: %d" % (m, chua_thang[m]) for m in sorted(chua_thang))))
    # gom chi tiet DC2 / DC3 qua dai
    for ma in ("DC2", "DC3"):
        ds = [x for x in cl if x[0] == ma]
        if len(ds) > 10:
            for x in ds[10:]:
                cl.remove(x)
            them(ma, LOI, "*", "... và %d hoá đơn khác cùng lỗi (tổng %d)" % (len(ds) - 10, len(ds)))
    # ---- doanh thu / thue so voi hoa don (theo thang)
    dt_so, v_ra, v_vao = {}, {}, {}
    for th, no, co, s in ps:
        if th not in tm_set:
            continue
        if goc(co, "511") and not goc(no, "911"):
            dt_so[th] = dt_so.get(th, 0) + s
        if goc(no, "511") and not goc(co, "911"):
            dt_so[th] = dt_so.get(th, 0) - s
        if goc(co, "3331"):
            v_ra[th] = v_ra.get(th, 0) + s
        if goc(no, "133") and not goc(co, "3331"):
            v_vao[th] = v_vao.get(th, 0) + s
    def pham_vi(dd):                                     # thang dau / cuoi co hoa don da tai (theo thu tu nam TC)
        ds = [i for i, (_, m) in enumerate(thangs) if m in dd]
        return (min(ds), max(ds)) if ds else (None, None)
    b0, b1 = pham_vi(hd_ban)
    m0, m1 = pham_vi(hd_mua)
    thieu_hd = []
    for i, (_, m) in enumerate(thangs):
        hb = hd_ban.get(m, [0.0, 0.0])
        if abs(dt_so.get(m, 0.0)) > 1000 and m not in hd_ban:
            thieu_hd.append(("bán ra", m))
        if abs(v_vao.get(m, 0.0)) > 1000 and m not in hd_mua:
            thieu_hd.append(("mua vào", m))
        if m in hd_ban:
            a, b = dt_so.get(m, 0.0), hb[0]
            if abs(a - b) > max(1000.0, 0.005 * max(abs(a), abs(b))):
                them("DC6", CB, "%02d" % m, "Tháng %d: doanh thu 511 trên sổ khác tiền chưa thuế hoá đơn bán ra" % m, "sổ %s / HĐ %s / lệch %s" % (tien(a), tien(b), tien(a - b)))
            a, b = v_ra.get(m, 0.0), hb[1]
            if abs(a - b) > max(1000.0, 0.005 * max(abs(a), abs(b))):
                them("DC7", CB, "%02d" % m, "Tháng %d: thuế GTGT đầu ra 3331 khác thuế trên hoá đơn bán ra" % m, "sổ %s / HĐ %s / lệch %s" % (tien(a), tien(b), tien(a - b)))
        if m in hd_mua:
            a, b = v_vao.get(m, 0.0), hd_mua.get(m, [0.0, 0.0])[1]
            if abs(a - b) > max(1000000.0, 0.05 * max(abs(a), abs(b))):
                them("DC8", TT if a < b else CB, "%02d" % m, "Tháng %d: thuế đầu vào 133 khác thuế hoá đơn mua vào tháng đó (có thể do kê khai khác kỳ)" % m,
                     "sổ %s / HĐ %s / lệch %s" % (tien(a), tien(b), tien(a - b)))
    for huong in ("bán ra", "mua vào"):
        ms_ = [m for h_, m in thieu_hd if h_ == huong]
        if ms_:
            them("DC13", CB, huong, "Sổ có %s nhưng chưa tải hoá đơn %s các tháng %s - chưa đối chiếu được" % (
                "doanh thu" if huong == "bán ra" else "thuế đầu vào", huong, ", ".join(str(x) for x in ms_)))
    # chung tu ghi ngay sau hom nay
    sau = {}
    for r in d["ct"]:
        ng = _ngay(r.get("ngayct"))
        if ng and (ng.date() if hasattr(ng, "date") else ng) > hom_nay:
            sau[ng.month] = sau.get(ng.month, 0) + 1
    if sau:
        them("DC14", TT, "*", "%d chứng từ ghi ngày sau hôm nay (tháng %s) - chứng từ lập trước / ghi nhầm năm" % (sum(sau.values()), ", ".join(str(x) for x in sorted(sau))))
    # ---- tien gui: so du 112 cuoi thang <> sao ke, thieu sao ke
    sp_theo = {}
    for r in d["sp"]:
        stk = str(r.get("sotknh") or "").strip()
        ng = _ngay(r.get("ngaygd"))
        if stk and ng:
            sd_tho = r.get("sodu")          # GD345 (F02): giu None khi sao ke khong co so du - khac so du bang 0
            sd = None if sd_tho is None or str(sd_tho).strip() == "" else _so(sd_tho)
            sp_theo.setdefault(stk, []).append((ng, int(_so(r.get("maso"))), sd, str(r.get("trangthai") or "").upper()))
    tk_ms = {v: k for k, v in sh.items()}
    map_tk = {}
    for r in d["tknh"]:
        stk, t112 = str(r.get("sotknh") or "").strip(), str(r.get("tk112") or "").strip()
        if stk and t112:
            map_tk.setdefault(t112, []).append(stk)
    sp_den = None
    for stk, ds in sp_theo.items():
        ds.sort()
        if sp_den is None or ds[-1][0] > sp_den:
            sp_den = ds[-1][0]
    for t112, stks in map_tk.items():
        ms = tk_ms.get(t112)
        stks = [s for s in stks if s in sp_theo]
        if not ms or not stks or ms in co_con:
            continue
        if len(stks) > 1:
            continue                                             # nhieu so TK cung mot TK 112: khong so tung so du
        stk = stks[0]
        ds = sp_theo[stk]
        r0 = tk.get(ms) or {}
        du = _so(r0.get("duno_0")) - _so(r0.get("duco_0"))
        theo_th = {}
        for th, no, co, s in ps:
            if no == ms:
                theo_th[th] = theo_th.get(th, 0) + s
            if co == ms:
                theo_th[th] = theo_th.get(th, 0) - s
        dau_sp = ds[0][0]
        co_so_du = any(x[2] for x in ds)          # GD345 (F02): sao ke co cot so du (it nhat 1 dong khac 0) -> so du 0 la so that
        lech_thang = 0
        for y, m in thangs:
            du += theo_th.get(m, 0.0)
            trong = [x for x in ds if x[0].year == y and x[0].month == m]
            if not trong:
                if (y, m) >= (dau_sp.year, dau_sp.month) and abs(theo_th.get(m, 0.0)) > 0:
                    them("DC5", CB, stk[-4:], "TK %s (…%s) tháng %d có phát sinh trên sổ nhưng chưa có sao kê" % (t112, stk[-4:], m))
                continue
            cuoi = max(trong, key=lambda x: (x[0], x[1]))
            if cuoi[2] is None or (cuoi[2] == 0 and not co_so_du):
                continue                                         # khong co so du tren sao ke -> khong so (khong coi 0 la so du)
            if abs(cuoi[2] - du) > 1:
                lech_thang += 1
                them("DC4", LOI, "%s-%02d" % (stk[-4:], m), "TK %s (…%s) cuối tháng %d: số dư sổ khác số dư sao kê" % (t112, stk[-4:], m),
                     "sổ %s / sao kê %s / lệch %s" % (tien(du), tien(cuoi[2]), tien(du - cuoi[2])))
    # ---- luong
    bl = {}
    for r in d["bl"]:
        th = int(_so(r.get("thang")))
        if 1 <= th <= 12:
            bl[th] = bl.get(th, 0.0) + _so(r.get("tongthunhap"))
    if bl:
        co334 = {}
        for th, no, co, s in ps:
            if goc(co, "334"):
                co334[th] = co334.get(th, 0) + s
        dau_bl = min(bl)
        for _, m in thangs:
            if bl.get(m):
                a, b = co334.get(m, 0.0), bl[m]
                if not a:
                    them("DC9", CB, "%02d" % m, "Tháng %d có bảng lương nhưng chưa hạch toán lương (không có Có 334)" % m, "bảng lương %s" % tien(b))
                elif abs(a - b) > 1000:
                    them("DC9", CB, "%02d" % m, "Tháng %d: phát sinh Có 334 khác tổng thu nhập bảng lương" % m, "sổ %s / bảng lương %s / lệch %s" % (tien(a), tien(b), tien(a - b)))
            elif m > dau_bl and co334.get(m):
                them("DC12", CB, "BL%02d" % m, "Tháng %d có chi phí lương (Có 334) nhưng chưa có bảng lương" % m)
    # ---- ton kho am (thang cuoi ky)
    n_am = 0
    if thangs:
        idx = (thangs[-1][1] - dau) % 12 + 1
        for r in d["tonkho"]:
            l, t = _so(r.get("luong_%d" % idx)), _so(r.get("tien_%d" % idx))
            if l < -0.0005 or t < -1:
                n_am += 1
        if n_am:
            them("DC10", LOI, "*", "%d mã vật tư tồn kho âm cuối tháng %d" % (n_am, thangs[-1][1]))
    # ---- trung ma doi tac (chi ma da dung)
    dung = set()
    for r in d["ct"]:
        for c in ("makh", "makhc"):
            v = int(_so(r.get(c)))
            if v:
                dung.add(v)
    nhom_ten = {}
    for r in d["kh"]:
        ms = int(_so(r.get("maso")))
        if ms not in dung:
            continue
        k = _chuan_ten(_ten_kh(r.get("ten"), font))
        if len(k) < 4:
            continue
        nhom_ten.setdefault(k, []).append((str(r.get("sohieu") or "").strip(), re.sub(r"\D", "", str(r.get("mst") or ""))))
    n_trung = 0
    for k, ds in nhom_ten.items():
        if len(ds) < 2:
            continue
        mst = set(x[1] for x in ds if len(x[1]) >= 10)
        if len(mst) <= 1:
            n_trung += 1
            if n_trung <= 15:
                them("DC11", CB, ds[0][0], "Một đối tác có %d mã đều có phát sinh: %s" % (len(ds), ", ".join(x[0] for x in ds[:6])))
    if n_trung > 15:
        them("DC11", CB, "*", "... còn %d nhóm mã trùng khác" % (n_trung - 15))
    # ---- ky to khai da / chua nop
    ky_ds = []
    da_nop = dh.get("da_nop") or {}
    if isinstance(da_nop, list):
        da_nop = {tuple(x.split(" ", 1)): 1 for x in da_nop}
    co_dvc = any(str(r.get("nhom") or "") in ("HSDVC", "HSK") for r in d["dvc"])
    ky_gtgt = dh.get("ky_gtgt") or "Q"
    import bang_dieu_hanh as DH
    le = DH.doc_ngay_nghi()
    for y, m in thangs:
        if ky_gtgt == "T":
            k = DH.ky_t(y, m)
        elif m % 3 == 0:
            k = DH.ky_q(y, m // 3)
        else:
            continue
        ky_ds.append([k, DH.ky_chu(k), DH.han_gtgt(k, le), (("01/GTGT", k) in da_nop) if co_dvc else None])
    # ---- GD340: chi tieu to khai 01/GTGT da xuat HTKK <> so
    try:
        _doi_chieu_to_khai(d, ky_ds, ps, goc, them, hom_nay)
    except Exception:
        pass
    # ---- tra loi / giai trinh (tra_loi.txt cua bo so)
    tl = []
    try:
        import chinh_sach_so
        import tra_loi_hang_doi
        tm, _ = chinh_sach_so._thu_muc_ra(duong, tao=False)
        tl = tra_loi_hang_doi.doc(os.path.join(tm, "tra_loi.txt"))
    except Exception:
        tm = ""
    n_gt = 0
    for x in cl:
        for t in tl:
            if (t[0] == "*" or t[0] == x[0]) and (t[1] == "*" or t[1] == x[2]):
                x.append(t[2] + ((": " + t[3]) if t[3] else ""))
                if t[2] in ("BO_QUA", "DA_LAM"):
                    x[1] = TT
                n_gt += 1
                break
        if len(x) < 6:
            x.append("")
    # ---- hien trang + nhom
    ky_gan = ky_ds[-1] if ky_ds else None
    cuoi_ky_m = thangs[-1][1] if thangs else 0
    ct_cuoi = dh.get("ct_cuoi") or 0
    khoa = dh.get("khoa") or []
    sp_co = bool(sp_theo)
    ht = {"hd_tay": n_tay, "thang_ky": cuoi_ky_m, "ct_cuoi": ct_cuoi, "hd_den": vn(hd_den), "sp_den": vn(sp_den), "khoa": khoa,
          "ky_gan": ky_gan[1] if ky_gan else "", "ky_gan_han": vn(ky_gan[2]) if ky_gan else "",
          "ky_gan_nop": ("đã nộp" if ky_gan[3] else "CHƯA NỘP") if ky_gan and ky_gan[3] is not None else ("chưa có dữ liệu DVC" if ky_gan else ""),
          "co_dvc": co_dvc, "hd_so": len(hd), "hd_chua": n_chua, "hd_hong": n_hong, "hd_huy_ht": n_huy, "ton_am": n_am, "trung_ma": n_trung,
          "sp_co": sp_co, "ky": [[k[1], vn(k[2]), ("đã nộp" if k[3] else "chưa nộp") if k[3] is not None else "?"] for k in ky_ds]}
    con = [x for x in cl if x[1] != TT]
    ly = {"D": [], "C": [], "B": []}
    con_ma = set(x[0] for x in con)                     # chi tinh chenh lech CHUA giai trinh (BO_QUA / DA_LAM khong xep nhom)
    if "DC10" not in con_ma:
        n_am = 0
    if "DC2" not in con_ma:
        n_hong = 0
    if "DC11" not in con_ma:
        n_trung = 0
    if n_am >= 3:
        ly["D"].append("tồn kho âm %d mã" % n_am)
    elif n_am:
        ly["B"].append("tồn kho âm %d mã" % n_am)
    if n_hong:
        ly["D"].append("%d hoá đơn mất liên kết chứng từ" % n_hong)
    if n_trung >= 3:
        ly["D"].append("%d nhóm mã đối tác trùng" % n_trung)
    if sum(1 for x in con if x[0] == "DC4") >= 2:
        ly["D"].append("số dư 112 lệch sao kê nhiều tháng")
    bt = (dh.get("_bt") or {})
    if (bt.get("cao") or 0) >= 3:
        ly["D"].append("%d bất thường số liệu mức Cao" % bt["cao"])
    elif bt.get("cao"):
        ly["B"].append("%d bất thường số liệu mức Cao" % bt["cao"])
    if cuoi_ky_m and ct_cuoi and _thu_tu(ct_cuoi, dau) < _thu_tu(cuoi_ky_m, dau):
        ly["C"].append("chứng từ mới đến tháng %d" % ct_cuoi)
    elif cuoi_ky_m and not ct_cuoi:
        ly["C"].append("chưa có chứng từ")
    if not hd:
        ly["C"].append("chưa tải hoá đơn điện tử")
    elif hd_den and thangs and (_dt.date(thangs[-1][0], thangs[-1][1], 1) - hd_den.date() if hasattr(hd_den, "date") else _dt.date(thangs[-1][0], thangs[-1][1], 1) - hd_den).days > 0:
        ly["C"].append("hoá đơn mới tải đến %s" % vn(hd_den))
    if any(x[0] == "DC13" for x in con):
        ly["C"].append("chưa tải đủ hoá đơn CQT các tháng có phát sinh")
    if any(x[0] == "DC5" for x in con):
        ly["C"].append("thiếu sao kê ngân hàng")
    if any(x[0] == "DC12" for x in con):
        ly["C"].append("tháng thiếu chứng từ / bảng lương")
    if ky_gan and ky_gan[3] is not True:
        ly["B"].append("kỳ %s %s" % (ky_gan[1], "chưa nộp" if ky_gan[3] is False else "chưa xác nhận đã nộp (chưa tải DVC)"))
    if cuoi_ky_m and cuoi_ky_m not in khoa:
        ly["B"].append("tháng %d chưa khoá" % cuoi_ky_m)
    if n_chua or dh.get("sp_chua"):
        ly["B"].append("còn hoá đơn / sổ phụ chưa hạch toán")
    if con:
        ly["B"].append("%d chênh lệch chưa giải trình" % len(con))
    nhom = "D" if ly["D"] else ("C" if ly["C"] else ("B" if ly["B"] else "A"))
    ly_do = ly.get(nhom, []) if nhom != "A" else ["đủ chứng từ, đã nộp kỳ gần nhất, đã khoá, không chênh lệch"]
    # ---- chi so van hanh
    ct_ngay = dh.get("ct_ngay")
    if isinstance(ct_ngay, str):
        ct_ngay = _ngay(ct_ngay)
    tre = sum(1 for k in ky_ds if k[3] is False and k[2] and k[2] < hom_nay)
    cs = {"tl_may": round(100.0 * n_may / n_ht, 1) if n_ht else None, "hd_ht": n_ht, "hd_may": n_may,
          "hd_gan_tay": n_tay_gan, "hd_khong_cham": n_khong_cham, "hd_biet_che_do": n_biet, "hd_tu_ghi": n_tu_ghi, "hd_nguoi_ghi": n_nguoi_ghi,
          "tl_khong_cham": round(100.0 * n_khong_cham / n_biet, 1) if n_biet else None,     # GD347 (F06): KPI khong cham tay that
          "ngay_tu_ct": max(0, (hom_nay - (ct_ngay.date() if hasattr(ct_ngay, "date") else ct_ngay)).days) if ct_ngay else None,
          "to_khai_tre": tre, "cl_chua_gt": len(con), "cl_gt": n_gt}
    return {"hien_trang": ht, "cl": cl, "nhom": nhom, "ly_do_nhom": ly_do, "chi_so": cs, "thu_muc": tm}


def _tk_xuat(mst, tok):
    """Ban 01/GTGT moi nhat da xuat HTKK cho ky tok ('092026' / 'Q032026') trong AIHoaDon\\htkk-sao-luu\\<MST>\\<lan>\\ -> (tep, {ct: so})."""
    goc = os.path.join(HERE, "htkk-sao-luu", mst)
    if not mst or not os.path.isdir(goc):
        return "", {}
    ung = []
    for lan in os.listdir(goc):
        tm = os.path.join(goc, lan)
        if not os.path.isdir(tm):
            continue
        for f in os.listdir(tm):
            if re.match(r"(?i)^01_GTGT_", f) and re.search(r"(?i)_%s_" % re.escape(tok), f) and f.lower().endswith(".xml"):
                p = os.path.join(tm, f)
                ung.append((os.path.getmtime(p), p))
    if not ung:
        return "", {}
    p = max(ung)[1]
    with io.open(p, encoding="utf-8-sig", errors="replace") as fh:
        s = fh.read()
    ct = {}
    for m in re.finditer(r"<Cell\s[^>]*>", s):
        t = m.group(0)
        pa = re.search(r'Path="[^"]*/(ct\d+[a-z]?)"', t)
        va = re.search(r'\sValue="([^"]*)"', t)
        if pa and va:
            try:
                ct[pa.group(1)] = float(va.group(1).replace(",", "") or 0)
            except ValueError:
                pass
    if not ct:                                           # dang XML to khai that (<ct24>...</ct24>)
        for m in re.finditer(r"<(ct\d+[a-z]?)>([-0-9.]*)</\1>", s):
            try:
                ct[m.group(1)] = float(m.group(2) or 0)
            except ValueError:
                pass
    return p, ct


def _doi_chieu_to_khai(d, ky_ds, ps, goc, them, hom_nay):
    mst = re.sub(r"\D", "", str(d["lic"].get("masothue") or ""))
    if not mst or not ky_ds:
        return
    for i, (k, ten, han, nop) in enumerate(ky_ds):
        y = int(k[1:5])
        if k.startswith("T"):
            m = int(k[6:8])
            ms = [m]
            tok = "%02d%d" % (m, y)
        else:
            q = int(k[6:])
            ms = [q * 3 - 2, q * 3 - 1, q * 3]
            tok = "Q%02d%d" % (q, y)
        p, ct = _tk_xuat(mst, tok)
        if not ct:
            if i == len(ky_ds) - 1:
                them("DC16", TT, tok, "Kỳ %s chưa có tờ khai 01/GTGT xuất HTKK từ phần mềm" % ten)
            continue
        no133 = sum(s for th, no, co, s in ps if th in ms and goc(no, "133") and not goc(co, "3331"))
        co3331 = sum(s for th, no, co, s in ps if th in ms and goc(co, "3331"))
        dt = sum(s for th, no, co, s in ps if th in ms and goc(co, "511") and not goc(no, "911")) - \
            sum(s for th, no, co, s in ps if th in ms and goc(no, "511") and not goc(co, "911"))
        muc = LOI if nop else CB
        trang = "đã nộp" if nop else ("chưa nộp" if nop is False else "chưa xác nhận nộp")
        for ma_ct, ten_ct, so in (("ct24", "[24] thuế GTGT mua vào", no133), ("ct35", "[35] thuế GTGT đầu ra", co3331), ("ct34", "[34] doanh thu bán ra", dt)):
            if ma_ct not in ct:
                continue
            a = ct[ma_ct]
            if abs(a - so) > max(1000.0, 0.001 * max(abs(a), abs(so))):
                them("DC15", muc, "%s-%s" % (tok, ma_ct), "Kỳ %s (%s): tờ khai %s khác sổ hiện tại" % (ten, trang, ten_ct),
                     "tờ khai %s / sổ %s / lệch %s (tệp %s)" % (tien(a), tien(so), tien(so - a), os.path.basename(os.path.dirname(p))))


def _khop_tien(ds, ng, tien_hd):
    """so HD trung + tien chua thue lech <= 1% + ngay lech <= 45 ngay -> coi la cung hoa don (nhap tay)."""
    if not ds or not ng:
        return False
    for ngay, t in ds.values():
        if ngay and abs((ngay - ng).days) <= 45 and abs(t - tien_hd) <= max(1000.0, 0.01 * abs(tien_hd)):
            return True
    return False


def _so_hd(s):
    t = re.sub(r"\D", "", str(s or ""))
    try:
        return int(t) if t else 0
    except ValueError:
        return 0


def _ky6(s):
    t = re.sub(r"[^A-Z0-9]", "", _bo_dau(s).upper())
    return t[-6:] if len(t) >= 4 else ""


def _bo_huy(tt):
    t = _bo_dau(tt).upper()
    return "bị huỷ" if "HUY" in t else "đã bị thay thế"


def _thu_tu(m, dau):
    return (m - dau) % 12


# ------------------------------------------------------------------ hang doi gop moi bo so
def phu_trach(duong, bang):
    """bang: [(mau, nhan_vien)] tu hang-loat\\phu_trach.txt; khong khop -> ten thu muc cha."""
    p = os.path.abspath(duong).lower()
    for mau, nv in bang:
        if mau.lower() in p:
            return nv
    return os.path.basename(os.path.dirname(os.path.abspath(duong))) or "-"


def doc_phu_trach(goc):
    out = []
    p = os.path.join(goc, "phu_trach.txt")
    if not os.path.isfile(p):
        try:
            with io.open(p, "w", encoding="utf-8") as f:
                f.write("# Phan cong nhan vien phu trach: moi dong <mot phan duong dan / ten tep bo so>;<ten nhan vien>\n"
                        "# Vi du:  \\NHOM1\\;Lan      hoac   PHAT NGHE;Huong\n"
                        "# Khong khai -> lay ten thu muc chua bo so.\n")
        except Exception:
            pass
        return out
    try:
        with io.open(p, encoding="utf-8-sig") as f:
            for d in f:
                d = d.strip()
                if d and not d.startswith("#") and ";" in d:
                    a, b = d.split(";", 1)
                    if a.strip():
                        out.append((a.strip(), b.strip()))
    except Exception:
        pass
    return out


def _hang_doi_so(tm):
    """doc hang_doi_viec.txt (GD238) cua bo so -> [(muc, tram, ma, ten, lam_o)]"""
    out = []
    p = os.path.join(tm or "", "hang_doi_viec.txt")
    if not tm or not os.path.isfile(p):
        return out
    try:
        with io.open(p, encoding="utf-8") as f:
            for d in f:
                x = d.rstrip("\r\n").split(";")
                if x[0] != "V" or len(x) < 7:
                    continue
                mu = _bo_dau(x[2]).upper()
                muc = LOI if "LOI" in mu else (CB if "CANH" in mu else TT)
                try:
                    tr = int(x[3])
                except ValueError:
                    tr = 0
                out.append((muc, tr, x[4], x[5], x[6]))
    except Exception:
        pass
    return out


def lap_hang_doi(ket, hom_nay, goc):
    """-> danh sach viec: [uu_tien, nhan_vien, nhom, bo_so, han, muc, tram, ma, viec, lam_o, so_lieu, tep]"""
    pt = doc_phu_trach(goc)
    v = []
    for k in ket:
        dh, dc = k.get("dh") or {}, k.get("dc") or {}
        ten = dh.get("ten") or k.get("tep")
        nv = phu_trach(k.get("duong") or "", pt)
        nhom = dc.get("nhom") or "-"
        han = dh.get("han_gan_iso") or ""
        han_d = _ngay(han) if han else None
        for x in (dh.get("viec_han") or []):
            h, ten_v, nop = x
            hd_ = _ngay(h)
            if nop or not hd_:
                continue
            con = (hd_ - hom_nay).days
            muc = LOI if con <= 5 else (CB if con <= 15 else TT)
            v.append([None, nv, nhom, ten, h, muc, 8, "HAN", ("QUÁ HẠN " if con < 0 else "") + "%s hạn %s chưa thấy nộp" % (ten_v, vn(hd_)),
                      "Lập tờ khai (Báo cáo & thuế), ký số, nộp; tải lại DVC để máy ghi đã nộp", "", k.get("tep")])
        for x in dc.get("cl") or []:
            if x[1] == TT:
                continue
            v.append([None, nv, nhom, ten, han, x[1], TRAM.get(x[0], 0), x[0], x[3], LAM_O.get(x[0], ""), x[4], k.get("tep")])
        for muc, tr, ma, tv, lo in _hang_doi_so(dc.get("thu_muc")):
            if muc == TT:
                continue
            v.append([None, nv, nhom, ten, han, muc, tr, ma, tv, lo, "", k.get("tep")])
        bt = k.get("bt") or {}
        if bt.get("cao"):
            v.append([None, nv, nhom, ten, han, LOI, 3, "BT", "%d bất thường số liệu mức Cao" % bt["cao"], "Kiểm soát > thẻ Bất thường số liệu", "", k.get("tep")])
        if k.get("loi"):
            v.append([None, nv, nhom, ten, han, CB, 0, "LOI", "Lỗi chạy: " + k["loi"], "Mở bộ sổ kiểm tra", "", k.get("tep")])
    v.sort(key=lambda x: (x[4] or "9999-99-99", THU_MUC_UT[x[5]], x[6], x[3].lower(), x[7]))
    for i, x in enumerate(v, 1):
        x[0] = i
    return v


def ghi_hang_doi(v, lan):
    p = os.path.join(lan, "hang_doi_100.txt")
    with io.open(p, "w", encoding="utf-8", newline="") as f:
        f.write("SO\t%d\r\n" % len(v))
        for x in v:
            f.write("V\t" + "\t".join(str(c if c is not None else "").replace("\t", " ").replace("\r", " ").replace("\n", " ") for c in x) + "\r\n")
    return p


def ghi_lich_su(ket, goc, hom_nay):
    """Ghi chi so cua lan chay vao hang-loat\\chi_so_lich_su.csv (moi bo so mot dong) - de xem xu huong theo thang."""
    p = os.path.join(goc, "chi_so_lich_su.csv")
    moi = not os.path.isfile(p)
    try:
        with io.open(p, "a", encoding="utf-8-sig" if moi else "utf-8", newline="") as f:
            if moi:
                f.write("ngay;tep;nhom;hd_tu_dong_pct;hd_hach_toan;viec_can_nguoi;ngay_tu_chung_tu_cuoi;to_khai_tre;chenh_lech_chua_giai_trinh\r\n")
            for k in ket:
                dc = k.get("dc") or {}
                cs = dc.get("chi_so") or {}
                f.write("%s;%s;%s;%s;%s;%s;%s;%s;%s\r\n" % (hom_nay.isoformat(), k.get("tep"), dc.get("nhom", ""), "" if cs.get("tl_may") is None else cs["tl_may"],
                                                          cs.get("hd_ht", ""), k.get("n_viec", ""), "" if cs.get("ngay_tu_ct") is None else cs["ngay_tu_ct"],
                                                          cs.get("to_khai_tre", ""), cs.get("cl_chua_gt", "")))
    except Exception:
        pass
    return p


# ------------------------------------------------------------------ Excel / HTML
TEN_NHOM = {"A": "A - hoàn thiện, chuyển thẳng tháng sau", "B": "B - đủ chứng từ, còn việc cuối kỳ / khoá / nộp",
            "C": "C - thiếu chứng từ, xin khách", "D": "D - dữ liệu bẩn, làm sạch trước", "-": "-"}
MAU_NHOM = {"A": "C6EFCE", "B": "DDEBF7", "C": "FFE699", "D": "F8CBAD", "-": "FFFFFF"}


def them_sheet(wb, ket, hang_doi, k_td, k_ghi, k_dau, k_o):
    k_n = {g: wb.kieu(khung=True, dam=True, nen=MAU_NHOM[g], can="giua") for g in MAU_NHOM}
    k_m = {LOI: wb.kieu(khung=True, dam=True, mau="B3261E", xuong=True, doc="tren"), CB: wb.kieu(khung=True, dam=True, mau="8A5A00", xuong=True, doc="tren"),
           TT: wb.kieu(khung=True, mau="1F4E79", xuong=True, doc="tren")}
    # 1. phan nhom
    cot = ["STT", "Bộ sổ", "Nhóm", "Lý do xếp nhóm", "Tháng kỳ", "CT đến tháng", "HĐ tải đến", "Sổ phụ đến", "Tháng đã khoá",
           "Kỳ GTGT gần nhất", "Hạn", "Đã nộp?", "HĐ chưa HT", "Chênh lệch chưa GT", "Tồn âm", "Mã trùng"]
    ws = wb.sheet("PhanNhom", cot=[5, 30, 7, 46, 7, 8, 11, 11, 12, 14, 11, 16, 8, 9, 7, 7])
    ws.gop(1, 1, 1, len(cot), "CHỤP HIỆN TRẠNG - XẾP NHÓM A / B / C / D", k_td)
    dem = {g: sum(1 for k in ket if (k.get("dc") or {}).get("nhom") == g) for g in "ABCD"}
    ws.gop(2, 1, 2, len(cot), "A %d · B %d · C %d · D %d. A: chuyển thẳng tháng sau; B: làm cuối kỳ, khoá, nộp; C: gửi yêu cầu chứng từ cho khách ngay; "
                              "D: làm sạch trước (gộp mã, tồn âm, liên kết, số dư). Chỉ đọc sổ." % (dem["A"], dem["B"], dem["C"], dem["D"]), k_ghi)
    ws.cao(2, 30)
    ws.dong(4, 1, cot, k_dau)
    r = 4
    for k in sorted(ket, key=lambda k: ("DCBA".find((k.get("dc") or {}).get("nhom") or "A"), str((k.get("dh") or {}).get("han_gan_iso") or "9"), str((k.get("dh") or {}).get("ten") or k["tep"]).lower())):
        dc, dh = k.get("dc") or {}, k.get("dh") or {}
        ht = dc.get("hien_trang") or {}
        g = dc.get("nhom") or "-"
        r += 1
        ws.dong(r, 1, [k.get("stt"), dh.get("ten") or k["tep"], g, "; ".join(dc.get("ly_do_nhom") or []), ht.get("thang_ky", ""), ht.get("ct_cuoi", ""),
                       ht.get("hd_den", ""), ht.get("sp_den", ""), ", ".join(str(x) for x in ht.get("khoa") or []), ht.get("ky_gan", ""), ht.get("ky_gan_han", ""),
                       ht.get("ky_gan_nop", ""), ht.get("hd_chua", ""), (dc.get("chi_so") or {}).get("cl_chua_gt", ""), ht.get("ton_am", ""), ht.get("trung_ma", "")], k_o)
        ws.o(r, 3, g, k_n.get(g, k_o))
    ws.dong_bang(5, 3)
    ws.in_trang(ngang=True, vua_rong=True, lap_dong=(4, 4))
    # 2. ky chua nop
    w = wb.sheet("KyChuaNop", cot=[5, 30, 7, 16, 12, 22, 40])
    w.gop(1, 1, 1, 7, "KỲ TỜ KHAI GTGT TRONG NĂM - CHƯA NỘP / CHƯA XÁC NHẬN (theo dữ liệu Cổng DVC đã tải về từng sổ)", k_td)
    w.dong(3, 1, ["STT", "Bộ sổ", "Nhóm", "Kỳ", "Hạn", "Tình trạng", "Ghi chú"], k_dau)
    r = 3
    rows = []
    for k in ket:
        dc = k.get("dc") or {}
        for ky in (dc.get("hien_trang") or {}).get("ky") or []:
            if ky[2] != "đã nộp":
                rows.append((ky[1][6:] + ky[1][3:5] + ky[1][:2] if ky[1] else "9", k, ky))
    for _, k, ky in sorted(rows, key=lambda x: x[0]):
        dc, dh = k.get("dc") or {}, k.get("dh") or {}
        r += 1
        w.dong(r, 1, [k.get("stt"), dh.get("ten") or k["tep"], dc.get("nhom"), ky[0], ky[1], "CHƯA NỘP" if ky[2] == "chưa nộp" else "chưa có dữ liệu DVC",
                      "" if ky[2] == "chưa nộp" else "Tải dữ liệu Cổng DVC của sổ để máy xác nhận đã nộp"], k_o)
    if r == 3:
        w.gop(4, 1, 4, 7, "Mọi kỳ đã nộp.", k_ghi)
    w.dong_bang(4, 3)
    # 3. chenh lech
    w = wb.sheet("ChenhLech", cot=[5, 28, 6, 7, 11, 12, 62, 34, 30])
    w.gop(1, 1, 1, 9, "ĐỐI CHIẾU VỚI NGUỒN CHÂN LÝ (hoá đơn CQT, sao kê, bảng lương, tồn kho, danh mục) - CHỈ ĐỌC", k_td)
    w.gop(2, 1, 2, 9, "Giải trình / bỏ qua từng dòng: ghi vào tra_loi.txt của bộ sổ (thư mục ket-qua\\chinh-sach\\<sổ>) dòng MÃ;KHOÁ;BO_QUA|DA_LAM|HEN;lý do. "
                      "Lần chạy sau máy áp dụng.", k_ghi)
    w.cao(2, 30)
    w.dong(4, 1, ["STT", "Bộ sổ", "Nhóm", "Mã", "Khoá", "Mức", "Chênh lệch", "Số liệu", "Giải trình"], k_dau)
    r = 4
    for k in ket:
        dc, dh = k.get("dc") or {}, k.get("dh") or {}
        for x in dc.get("cl") or []:
            r += 1
            w.dong(r, 1, [k.get("stt"), dh.get("ten") or k["tep"], dc.get("nhom"), x[0], x[2], TEN_MUC[x[1]], x[3], x[4], x[5] if len(x) > 5 else ""], k_o)
            w.o(r, 6, TEN_MUC[x[1]], k_m[x[1]])
            if r > 20000:
                break
    if r == 4:
        w.gop(5, 1, 5, 9, "Không có chênh lệch.", k_ghi)
    w.dong_bang(5, 3)
    # 4. hang doi gop
    w = wb.sheet("HangDoi100", cot=[6, 14, 6, 28, 11, 11, 6, 7, 60, 52, 26])
    w.gop(1, 1, 1, 11, "HÀNG ĐỢI VIỆC CẦN NGƯỜI - GỘP MỌI BỘ SỔ (xếp theo hạn nộp, mức, trạm đang chặn)", k_td)
    w.gop(2, 1, 2, 11, "Phân công nhân viên: tệp hang-loat\\phu_trach.txt. Làm xong / giải trình: tra_loi.txt của bộ sổ, Kiểm tra trước khoá sổ, lần chạy sau tự rời hàng đợi.", k_ghi)
    w.dong(4, 1, ["#", "Nhân viên", "Nhóm", "Bộ sổ", "Hạn sổ", "Mức", "Trạm", "Mã", "Việc", "Làm ở đâu", "Số liệu"], k_dau)
    r = 4
    for x in hang_doi[:20000]:
        r += 1
        w.dong(r, 1, [x[0], x[1], x[2], x[3], vn(_ngay(x[4])) if x[4] else "", TEN_MUC[x[5]], x[6] or "", x[7], x[8], x[9], x[10]], k_o)
        w.o(r, 6, TEN_MUC[x[5]], k_m[x[5]])
    if r == 4:
        w.gop(5, 1, 5, 11, "Không có việc cần người.", k_ghi)
    w.dong_bang(5, 4)
    w.in_trang(ngang=True, vua_rong=True, lap_dong=(4, 4))
    # 5. chi so
    w = wb.sheet("ChiSo", cot=[5, 30, 7, 12, 11, 12, 12, 10, 12, 12])
    w.gop(1, 1, 1, 10, "CHỈ SỐ VẬN HÀNH (lưu dồn vào hang-loat\\chi_so_lich_su.csv để xem xu hướng)", k_td)
    w.dong(3, 1, ["STT", "Bộ sổ", "Nhóm", "% HĐ máy hạch toán", "HĐ đã HT", "Việc cần người", "Ngày từ CT cuối", "Tờ khai trễ", "Chênh lệch chưa GT", "Đã giải trình"], k_dau)
    r = 3
    for k in ket:
        dc, dh = k.get("dc") or {}, k.get("dh") or {}
        cs = dc.get("chi_so") or {}
        r += 1
        w.dong(r, 1, [k.get("stt"), dh.get("ten") or k["tep"], dc.get("nhom"), "" if cs.get("tl_may") is None else cs["tl_may"], cs.get("hd_ht", ""),
                      k.get("n_viec", ""), "" if cs.get("ngay_tu_ct") is None else cs["ngay_tu_ct"], cs.get("to_khai_tre", ""), cs.get("cl_chua_gt", ""), cs.get("cl_gt", "")], k_o)
    w.dong_bang(4, 3)


def html_hang_doi(v, ra, luc):
    import html
    mau = {LOI: "#b3261e", CB: "#8a5a00", TT: "#1f4e79"}
    h = ["<!doctype html><html lang='vi'><head><meta charset='utf-8'><title>Hàng đợi việc cần người</title><style>"
         "body{font-family:Segoe UI,Arial,sans-serif;margin:16px;color:#1f2937}h1{font-size:20px;color:#0b3d91}"
         "table{border-collapse:collapse;width:100%;font-size:13px}th,td{border:1px solid #cbd5e1;padding:4px 6px;vertical-align:top}"
         "th{background:#d9e1f2;position:sticky;top:0}.g{color:#555;font-style:italic}</style></head><body>",
         "<h1>HÀNG ĐỢI VIỆC CẦN NGƯỜI - MỌI BỘ SỔ</h1><p class='g'>Lập lúc %s. %d việc, xếp theo hạn nộp của sổ, mức, trạm đang chặn.</p>" % (html.escape(luc), len(v)),
         "<table><tr><th>#</th><th>Nhân viên</th><th>Nhóm</th><th>Bộ sổ</th><th>Hạn sổ</th><th>Mức</th><th>Trạm</th><th>Việc</th><th>Làm ở đâu</th></tr>"]
    for x in v[:5000]:
        h.append("<tr><td>%d</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td style='color:%s;font-weight:bold'>%s</td><td>%s</td><td><b>%s</b> %s<br><span class='g'>%s</span></td><td>%s</td></tr>" % (
            x[0], html.escape(str(x[1])), x[2], html.escape(str(x[3])), vn(_ngay(x[4])) if x[4] else "", mau[x[5]], TEN_MUC[x[5]], x[6] or "",
            html.escape(str(x[7])), html.escape(str(x[8])), html.escape(str(x[10])), html.escape(str(x[9]))))
    h.append("</table></body></html>")
    with io.open(ra, "w", encoding="utf-8") as f:
        f.write("\n".join(h))
    return ra
