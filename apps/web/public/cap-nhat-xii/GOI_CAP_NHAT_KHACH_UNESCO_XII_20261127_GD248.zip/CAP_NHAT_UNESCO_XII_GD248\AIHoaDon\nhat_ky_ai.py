# -*- coding: utf-8 -*-
"""GD155 - NHAT KY GIAI THICH AI: "AI da lam gi thang nay" (lo trinh D2) - chi doc, lap Excel + HTML tu JSON cua VB6 (ModTinCay.NK155_Json):
  {"cty": {ten, mst}, "ky": {tu, den}, "nguong_tu_dong", "nguong_thap", "che_do_ghi",
   "nk":   [[thoi gian, loai, noi dung, MaCT, LoId, nguoi dung]],
   "hd":   [[MaCT, chieu, so, ngay, doi tac, tong, trang thai AI, tin cay min, chung tu, lo, ma KH, nguoi duyet, so dong, so dong Claude, nguon max, nguon min]],
   "ghep": [[MST, khoa ten, ma VT, TK no, tinh chat, so lan, lan cuoi, nguon]],
   "gop":  [[lan, loai, so hieu cu, so hieu moi, luc, trang thai, so dong]],
   "sp":   [[trang thai, nguon ghep, n, n tin cay >= 80, n sua tay]],
   "trung": [[quy tac, hanh dong, n]], "dau": [[ma R, loai, n]]}
Sheet: Tong quan (so lieu + phan bo tin cay + nguon + hanh dong), Hoa don (tung hoa don: diem, nguon, can cu de doc, chung tu), Nhat ky (loai ->
ten Viet), Ma ghep, Gop ma, So phu - chong trung - dau. HTML cung ten de doc / gui khach. Khong ghi so.
"""
import html
import io
import json
import os
import re
from collections import defaultdict

TEN_NGUON = {"MA_HD": "Mã ghi trên hoá đơn", "DA_HOC_TK": "Đã học từ NCC này", "DA_HOC": "Đã học từ NCC này", "DA_HOC_KHAC_NCC": "Học từ NCC khác",
             "TU_KHOA": "Từ khoá vật tư", "TU_KHOA_TK": "Từ khoá tài khoản", "TEN_TUYET_DOI": "Tên trùng tuyệt đối", "GAN_DUNG": "Tên gần đúng",
             "MA_CHUNG": "Mã chung", "SUY_RA": "Suy ra từ tên hàng", "CHI_PHI_DA_HOC": "Chi phí đã học", "CHI_PHI_AI": "Chi phí (AI đoán)",
             "AI": "Claude gợi ý", "NGUOI": "Người chọn", "MOI": "Chưa ghép", "": "Chưa ghép"}
TEN_TT = {"MOI": "Chưa phân tích", "THIEU_MA": "Thiếu mã", "SAN_SANG": "Sẵn sàng", "DA_HACH_TOAN": "Đã hạch toán", "LOI": "Không xử lý",
          "BO_QUA": "Bỏ qua", "CAN_XEM_LAI": "Cần xem lại", "CHO_XAC_NHAN": "Chờ xác nhận"}
TEN_LOAI_NK = {"TU_DONG": "Chế độ tự động ghi", "LO": "Lô hạch toán", "AI": "Gọi Claude", "CANH_BAO": "Cảnh báo", "LOI": "Lỗi", "HUY": "Huỷ chứng từ",
               "CHONG_TRUNG": "Chống trùng", "TRUNG": "Trùng", "LECH_TIEN": "Lệch tiền", "CAN_XEM_LAI": "Chuyển Cần xem lại", "SUA": "Sửa",
               "SO_PHU": "Sổ phụ", "SP_MA_MOI": "Sổ phụ - mã mới", "GOP_MA": "Gộp mã", "KIEM_SOAT": "Kiểm soát", "KIEM_DL": "Kiểm dữ liệu",
               "HTKK": "Báo cáo / tờ khai", "TO_KHAI": "Tờ khai HQ", "DVC": "Cổng DVC", "KHOA_SO": "Khoá sổ", "QUY_TAC": "Quy tắc",
               "DINH_KHOAN": "Định khoản", "CHI_PHI": "Chi phí", "LIEN_KET": "Liên kết chứng từ", "KHAC_MST": "Khác MST", "CONG_VIEC": "Công việc",
               "BANG_LUONG": "Bảng lương", "THONG_TU": "Thông tư", "NANG_CAP": "Nâng cấp dữ liệu", "HE_THONG": "Hệ thống", "CAPNHAT": "Cập nhật",
               "CAP_NHAT": "Cập nhật", "HEN_GIO": "Hẹn giờ", "BCTC": "BCTC", "HDEXCEL": "Hoá đơn Excel", "XLU": "Chữ Việt", "GD97": "Hạch toán từng bước",
               "SCV132": "Sửa chữ Việt", "HDLD133": "Hợp đồng lao động", "XN_CONG_TY": "Xác nhận công ty"}
LOAI_AI = {"TU_DONG", "LO", "AI", "CANH_BAO", "HUY", "CHONG_TRUNG", "TRUNG", "LECH_TIEN", "CAN_XEM_LAI", "SUA", "SO_PHU", "SP_MA_MOI", "GOP_MA",
           "DINH_KHOAN", "CHI_PHI", "LIEN_KET", "KHAC_MST", "GD97", "QUY_TAC", "KIEM_SOAT"}
BUC = ((90, 100, "90-100 (ghi tự động được)"), (80, 89, "80-89"), (60, 79, "60-79"), (0, 59, "dưới 60"))


def _so(x):
    try:
        return float(x or 0)
    except (TypeError, ValueError):
        return 0.0


def _dd(x):
    return "{:,.0f}".format(x).replace(",", ".")


def buc(tc):
    if tc <= 0:
        return "chưa chấm (0)"
    for a, b, ten in BUC:
        if a <= tc <= b:
            return ten
    return "dưới 60"


def can_cu(h):
    """cau can cu ngan cho mot hoa don (dict)."""
    kl = []
    ng = sorted({x for x in (h["ng1"], h["ng2"]) if x})
    if ng:
        kl.append("nguồn: " + " / ".join(TEN_NGUON.get(x, x) for x in ng))
    if h["n_ai"]:
        kl.append("%d dòng Claude gợi ý (phải xem trước)" % h["n_ai"])
    if h["tc"] >= h["nguong"] and not h["n_ai"]:
        kl.append("đạt ngưỡng tự động %d" % h["nguong"])
    elif h["tc"] < h["nguong"]:
        kl.append("dưới ngưỡng tự động %d" % h["nguong"])
    if h["kt"] and h["kt"] != "...":
        kl.append("chứng từ %s" % h["kt"] + (" (lô %s)" % h["lo"] if h["lo"] else "") + (" - duyệt: %s" % h["nd"] if h["nd"] else ""))
    elif h["tt"] in ("SAN_SANG", "THIEU_MA", "MOI"):
        kl.append("chưa hạch toán")
    if h["tt"] == "CAN_XEM_LAI":
        kl.append("đang Cần xem lại")
    if h["tt"] == "BO_QUA":
        kl.append("người dùng bỏ qua")
    return "; ".join(kl)


def tinh(dl):
    nguong = int(_so(dl.get("nguong_tu_dong")) or 90)
    hd = []
    for r in dl.get("hd") or []:
        r = list(r) + [None] * (16 - len(r))
        hd.append({"ma": str(r[0] or ""), "chieu": str(r[1] or ""), "so": str(r[2] or ""), "ngay": str(r[3] or "")[:10], "doi_tac": str(r[4] or ""),
                   "tong": _so(r[5]), "tt": str(r[6] or "").upper(), "tc": int(_so(r[7])), "kt": str(r[8] or ""), "lo": str(r[9] or ""),
                   "kh": str(r[10] or ""), "nd": str(r[11] or ""), "n": int(_so(r[12])), "n_ai": int(_so(r[13])), "ng1": str(r[14] or "").upper(),
                   "ng2": str(r[15] or "").upper(), "nguong": nguong})
    for h in hd:
        h["can_cu"] = can_cu(h)
        h["buc"] = buc(h["tc"])
    nk = []
    for r in dl.get("nk") or []:
        r = list(r) + [None] * (6 - len(r))
        nk.append({"luc": str(r[0] or ""), "loai": str(r[1] or "").upper(), "nd": str(r[2] or ""), "ma": str(r[3] or ""), "lo": str(r[4] or ""),
                   "nguoi": str(r[5] or "")})
    tong = {"hd": len(hd), "mua": sum(1 for h in hd if h["chieu"] == "mua"), "ban": sum(1 for h in hd if h["chieu"] == "ban"),
            "da_ht": sum(1 for h in hd if h["kt"] and h["kt"] != "..."), "tu_dong": 0, "claude": sum(1 for h in hd if h["n_ai"]),
            "xem_lai": sum(1 for h in hd if h["tt"] == "CAN_XEM_LAI"), "bo_qua": sum(1 for h in hd if h["tt"] == "BO_QUA"),
            "chua": sum(1 for h in hd if not (h["kt"] and h["kt"] != "...") and h["tt"] not in ("BO_QUA", "LOI")),
            "thap": sum(1 for h in hd if 0 < h["tc"] < int(_so(dl.get("nguong_thap")) or 80))}
    # lo tu dong: nhat ky TU_DONG "da ghi N chung tu"
    for x in nk:
        if x["loai"] == "TU_DONG":
            m = re.search(r"da ghi (\d+) chung tu", x["nd"]) or re.search(r"đã ghi (\d+) chứng từ", x["nd"])
            if m:
                tong["tu_dong"] += int(m.group(1))
    theo_buc = defaultdict(int)
    theo_nguon = defaultdict(int)
    for h in hd:
        theo_buc[h["buc"]] += 1
        for x in {h["ng1"], h["ng2"]}:
            if x:
                theo_nguon[x] += 1
    theo_loai = defaultdict(int)
    for x in nk:
        theo_loai[x["loai"]] += 1
    return {"nguong": nguong, "hd": hd, "nk": nk, "tong": tong, "theo_buc": theo_buc, "theo_nguon": theo_nguon, "theo_loai": theo_loai,
            "ghep": [list(r) + [None] * (8 - len(r)) for r in dl.get("ghep") or []], "gop": [list(r) + [None] * (7 - len(r)) for r in dl.get("gop") or []],
            "sp": [list(r) + [None] * (5 - len(r)) for r in dl.get("sp") or []], "trung": [list(r) + [None] * (3 - len(r)) for r in dl.get("trung") or []],
            "dau": [list(r) + [None] * (3 - len(r)) for r in dl.get("dau") or []]}


def lap_excel(dl, ra):
    import tool_htkk_unesco as X
    K = tinh(dl)
    cty = dl.get("cty") or {}
    ky = dl.get("ky") or {}
    T = [[("AI ĐÃ LÀM GÌ - NHẬT KÝ GIẢI THÍCH AI (chỉ đọc)", X.X_TITLE)],
         [("Đơn vị: %s    MST: %s    Kỳ: %s - %s    Ngưỡng ghi tự động: %d    Chế độ ghi: %s" % (
             cty.get("ten") or "", cty.get("mst") or "", ky.get("tu") or "", ky.get("den") or "", K["nguong"],
             "tự động" if int(_so(dl.get("che_do_ghi"))) == 1 else "xem trước rồi ghi"), X.X_THUONG)], [],
         [(c, X.X_TIEUDE) for c in ("Chỉ tiêu", "Số", "Ghi chú")]]
    t = K["tong"]
    for ten, so, gc in (("Hoá đơn điện tử trong kỳ", t["hd"], "%d mua vào, %d bán ra" % (t["mua"], t["ban"])),
                        ("Đã hạch toán (có chứng từ)", t["da_ht"], "kể cả người dùng lập"),
                        ("Chứng từ ghi bằng chế độ tự động", t["tu_dong"], "theo nhật ký TU_DONG trong kỳ"),
                        ("Hoá đơn có dòng Claude gợi ý", t["claude"], "luôn phải xem trước"),
                        ("Đang Cần xem lại", t["xem_lai"], "huỷ / thay thế sau hạch toán, R3, tháng khoá..."),
                        ("Người dùng bỏ qua", t["bo_qua"], ""),
                        ("Chưa hạch toán", t["chua"], ""),
                        ("Hoá đơn tin cậy thấp (dưới %d)" % (int(_so(dl.get("nguong_thap")) or 80)), t["thap"], "xem ở thẻ Hoá đơn: Sắp xếp cột > Chỉ hiện tin cậy thấp")):
        T.append([(ten, X.X_CHU), (so, X.X_SO), (gc, X.X_CHU)])
    T.append([])
    T.append([(c, X.X_TIEUDE) for c in ("Phân bố điểm tin cậy hoá đơn", "Số hoá đơn", "")])
    for ten in [x[2] for x in BUC] + ["chưa chấm (0)"]:
        T.append([(ten, X.X_CHU), (K["theo_buc"].get(ten, 0), X.X_SO), ("", X.X_CHU)])
    T.append([])
    T.append([(c, X.X_TIEUDE) for c in ("Nguồn ghép mã (hoá đơn có dùng)", "Số hoá đơn", "Ý nghĩa")])
    y_nghia = {"MA_HD": "mã vật tư ghi trên hoá đơn (100)", "DA_HOC_TK": "học từ hoá đơn trước của cùng người bán (100)", "DA_HOC_KHAC_NCC": "học từ người bán khác (90)",
               "TU_KHOA": "từ khoá đã khai báo (95)", "TU_KHOA_TK": "từ khoá chỉ biết TK (90)", "TEN_TUYET_DOI": "tên trùng danh mục (90)",
               "GAN_DUNG": "tên gần giống (độ giống - 30)", "MA_CHUNG": "mã chung của quy tắc (70)", "SUY_RA": "suy ra từ tên hàng (70 / 85)",
               "CHI_PHI_DA_HOC": "chi phí đã học (100)", "CHI_PHI_AI": "chi phí AI đoán (85)", "AI": "Claude gợi ý (tối đa 89)", "NGUOI": "người chọn (100)"}
    for k, v in sorted(K["theo_nguon"].items(), key=lambda kv: -kv[1]):
        T.append([(TEN_NGUON.get(k, k), X.X_CHU), (v, X.X_SO), (y_nghia.get(k, ""), X.X_CHU)])
    T.append([])
    T.append([(c, X.X_TIEUDE) for c in ("Việc AI / phần mềm đã ghi nhật ký", "Số dòng", "")])
    for k, v in sorted(K["theo_loai"].items(), key=lambda kv: -kv[1]):
        T.append([(TEN_LOAI_NK.get(k, k), X.X_CHU), (v, X.X_SO), ("liên quan AI" if k in LOAI_AI else "", X.X_CHU)])
    if K["trung"]:
        T.append([])
        T.append([(c, X.X_TIEUDE) for c in ("Chống trùng (quy tắc)", "Số", "Hành động")])
        for r in K["trung"]:
            T.append([(str(r[0] or ""), X.X_CHU), (int(_so(r[2])), X.X_SO), (str(r[1] or ""), X.X_CHU)])
    if K["dau"]:
        T.append([])
        T.append([(c, X.X_TIEUDE) for c in ("Dấu soát rủi ro hoá đơn (GĐ153)", "Số", "Loại dấu")])
        for r in K["dau"]:
            T.append([(str(r[0] or ""), X.X_CHU), (int(_so(r[2])), X.X_SO), (str(r[1] or ""), X.X_CHU)])
    T.append([])
    T.append([("Điểm tin cậy hoá đơn = điểm thấp nhất các dòng (trừ chiết khấu / khuyến mại). Chế độ tự động chỉ ghi hoá đơn đạt ngưỡng và không có dòng Claude gợi ý. "
               "Căn cứ từng hoá đơn: nút Vì sao? trên thẻ Hoá đơn.", X.X_GHICHU)])
    import kiem_khoa_so
    T += kiem_khoa_so.khoi_ky(dl, X, 3)
    sheets = [("Tong quan", [52, 12, 90], T, 4)]
    # hoa don
    cot = ("Chiều", "Số HĐ", "Ngày", "Đối tác", "Tổng tiền", "Trạng thái AI", "Tin cậy", "Bậc", "Chứng từ", "Lô", "Mã đối tượng", "Người duyệt", "Căn cứ")
    H = [[("TỪNG HOÁ ĐƠN: ĐIỂM TIN CẬY, NGUỒN GHÉP, CĂN CỨ", X.X_TITLE)], [], [(c, X.X_TIEUDE) for c in cot]]
    for h in sorted(K["hd"], key=lambda h: (h["tc"], h["ngay"][6:] + h["ngay"][3:5] + h["ngay"][:2], h["so"].zfill(12))):
        kieu = X.X_DO if 0 < h["tc"] < 60 else (X.X_VANG if h["tc"] < K["nguong"] else X.X_XANH)
        H.append([("Mua vào" if h["chieu"] == "mua" else "Bán ra", X.X_CHU), (h["so"], X.X_CHU), (h["ngay"], X.X_CHU), (h["doi_tac"], X.X_CHU), (h["tong"], X.X_SO),
                  (TEN_TT.get(h["tt"], h["tt"]), X.X_CHU), (h["tc"], kieu), (h["buc"], X.X_CHU), (h["kt"] if h["kt"] != "..." else "", X.X_CHU), (h["lo"], X.X_CHU),
                  (h["kh"], X.X_CHU), (h["nd"], X.X_CHU), (h["can_cu"], X.X_CHU)])
    if not K["hd"]:
        H.append([("(không có hoá đơn trong kỳ)", X.X_CHU)])
    sheets.append(("Hoa don", [9, 10, 11, 36, 15, 14, 8, 20, 12, 16, 12, 12, 80], H, 3))
    # nhat ky
    N = [[("NHẬT KÝ (loại -> ý nghĩa) - chỉ các dòng trong kỳ, bỏ dòng tệp", X.X_TITLE)], [], [(c, X.X_TIEUDE) for c in ("Thời gian", "Loại", "Ý nghĩa", "Nội dung", "Hoá đơn (MaCT)", "Lô", "Người dùng")]]
    for x in K["nk"]:
        N.append([(x["luc"], X.X_CHU), (x["loai"], X.X_CHU), (TEN_LOAI_NK.get(x["loai"], ""), X.X_CHU), (x["nd"], X.X_CHU), (x["ma"], X.X_CHU), (x["lo"], X.X_CHU), (x["nguoi"], X.X_CHU)])
    if not K["nk"]:
        N.append([("(không có)", X.X_CHU)])
    sheets.append(("Nhat ky", [17, 14, 22, 90, 24, 18, 12], N, 3))
    G = [[("MÃ GHÉP ĐÃ HỌC / DÙNG TRONG KỲ (quy tắc ghép theo người bán + tên hàng)", X.X_TITLE)], [],
         [(c, X.X_TIEUDE) for c in ("MST người bán", "Khoá tên hàng", "Mã VT", "TK Nợ", "Tính chất", "Số lần", "Lần cuối", "Nguồn")]]
    for r in K["ghep"]:
        G.append([(str(r[0] or ""), X.X_CHU), (str(r[1] or ""), X.X_CHU), (str(r[2] or ""), X.X_CHU), (str(r[3] or ""), X.X_CHU), (str(r[4] or ""), X.X_CHU),
                  (int(_so(r[5])), X.X_SO), (str(r[6] or ""), X.X_CHU), (TEN_NGUON.get(str(r[7] or "").upper(), str(r[7] or "")), X.X_CHU)])
    if not K["ghep"]:
        G.append([("(không có)", X.X_CHU)])
    sheets.append(("Ma ghep", [14, 50, 14, 10, 10, 8, 17, 18], G, 3))
    P = [[("GỘP MÃ (GĐ149) - SỔ PHỤ - trong kỳ", X.X_TITLE)], [], [(c, X.X_TIEUDE) for c in ("Lần gộp", "Loại", "Mã cũ", "Mã giữ", "Lúc", "Trạng thái", "Số dòng")]]
    for r in K["gop"]:
        P.append([(str(r[0] or ""), X.X_CHU), (str(r[1] or ""), X.X_CHU), (str(r[2] or ""), X.X_CHU), (str(r[3] or ""), X.X_CHU), (str(r[4] or ""), X.X_CHU),
                  (str(r[5] or ""), X.X_CHU), (int(_so(r[6])), X.X_SO)])
    if not K["gop"]:
        P.append([("(không gộp mã trong kỳ)", X.X_CHU)])
    P.append([])
    P.append([(c, X.X_TIEUDE) for c in ("Sổ phụ - trạng thái", "Nguồn ghép", "Số dòng", "Tin cậy từ 80", "Sửa tay", "", "")])
    for r in K["sp"]:
        P.append([(TEN_TT.get(str(r[0] or "").upper(), str(r[0] or "")), X.X_CHU), (TEN_NGUON.get(str(r[1] or "").upper(), str(r[1] or "")), X.X_CHU),
                  (int(_so(r[2])), X.X_SO), (int(_so(r[3])), X.X_SO), (int(_so(r[4])), X.X_SO)])
    if not K["sp"]:
        P.append([("(không có dòng sổ phụ trong kỳ)", X.X_CHU)])
    sheets.append(("Gop ma - So phu", [16, 12, 16, 16, 17, 12, 10], P, 3))
    os.makedirs(os.path.dirname(os.path.abspath(ra)), exist_ok=True)
    X.viet_xlsx_o(ra, sheets)
    try:
        viet_html(dl, K, os.path.splitext(ra)[0] + ".html")
    except Exception:
        pass
    return ra, K["tong"]


def viet_html(dl, K, ra):
    cty = dl.get("cty") or {}
    ky = dl.get("ky") or {}
    t = K["tong"]
    h = ["<!DOCTYPE html><html lang='vi'><head><meta charset='utf-8'><title>AI đã làm gì</title>",
         "<style>body{font-family:Segoe UI,Arial,sans-serif;font-size:13px;margin:16px}table{border-collapse:collapse;margin:8px 0}",
         "th,td{border:1px solid #bbb;padding:3px 6px;vertical-align:top}th{background:#3a5c14;color:#fff}td.n{text-align:right}</style></head><body>",
         "<h2>AI đã làm gì - %s - kỳ %s - %s</h2>" % (html.escape(cty.get("ten") or ""), ky.get("tu") or "", ky.get("den") or ""),
         "<p>%d hoá đơn điện tử (%d mua, %d bán); đã hạch toán %d; ghi tự động %d chứng từ; Claude gợi ý %d; cần xem lại %d; chưa hạch toán %d.</p>" % (
             t["hd"], t["mua"], t["ban"], t["da_ht"], t["tu_dong"], t["claude"], t["xem_lai"], t["chua"]),
         "<h3>Phân bố điểm tin cậy</h3><table><tr><th>Bậc</th><th>Số hoá đơn</th></tr>"]
    for ten in [x[2] for x in BUC] + ["chưa chấm (0)"]:
        h.append("<tr><td>%s</td><td class='n'>%d</td></tr>" % (ten, K["theo_buc"].get(ten, 0)))
    h.append("</table><h3>Nguồn ghép mã</h3><table><tr><th>Nguồn</th><th>Số hoá đơn</th></tr>")
    for k, v in sorted(K["theo_nguon"].items(), key=lambda kv: -kv[1]):
        h.append("<tr><td>%s</td><td class='n'>%d</td></tr>" % (html.escape(TEN_NGUON.get(k, k)), v))
    h.append("</table><h3>Hoá đơn tin cậy thấp nhất (tối đa 40)</h3><table><tr><th>Chiều</th><th>Số HĐ</th><th>Ngày</th><th>Đối tác</th><th>Tổng</th><th>Tin cậy</th><th>Căn cứ</th></tr>")
    for x in sorted(K["hd"], key=lambda z: z["tc"])[:40]:
        mau = "#f8d7da" if 0 < x["tc"] < 60 else ("#fff3cd" if x["tc"] < K["nguong"] else "#d4edda")
        h.append("<tr style='background:%s'><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td class='n'>%s</td><td class='n'>%d</td><td>%s</td></tr>" % (
            mau, "Mua" if x["chieu"] == "mua" else "Bán", html.escape(x["so"]), x["ngay"], html.escape(x["doi_tac"]), _dd(x["tong"]), x["tc"], html.escape(x["can_cu"])))
    h.append("</table><h3>Nhật ký liên quan AI (tối đa 200 dòng)</h3><table><tr><th>Lúc</th><th>Việc</th><th>Nội dung</th></tr>")
    n = 0
    for x in K["nk"]:
        if x["loai"] in LOAI_AI:
            n += 1
            if n > 200:
                break
            h.append("<tr><td>%s</td><td>%s</td><td>%s</td></tr>" % (x["luc"], html.escape(TEN_LOAI_NK.get(x["loai"], x["loai"])), html.escape(x["nd"])))
    h.append("</table><p><small>Chỉ đọc. Điểm tin cậy = điểm thấp nhất các dòng (trừ CK / KM); ngưỡng ghi tự động %d.</small></p></body></html>" % K["nguong"])
    with io.open(ra, "w", encoding="utf-8") as f:
        f.write("\n".join(h))
    return ra


def chay(duong_json, ra):
    with open(duong_json, "r", encoding="utf-8-sig") as f:
        dl = json.loads(f.read(), strict=False)
    d, _ = lap_excel(dl, ra)
    return d, ""


if __name__ == "__main__":
    import sys
    if len(sys.argv) >= 2:
        print(chay(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else re.sub(r"\.json$", ".xlsx", sys.argv[1])))
