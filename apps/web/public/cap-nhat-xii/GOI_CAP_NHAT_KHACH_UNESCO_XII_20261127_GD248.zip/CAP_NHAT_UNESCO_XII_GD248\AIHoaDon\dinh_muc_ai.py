# -*- coding: utf-8 -*-
"""GD173 - TRO LY LAP DINH MUC NGUYEN VAT LIEU THONG MINH (goi C1: khoi tao tu hoa don mua / ban, ten san pham, mau nganh) - CHI DOC SO.

VB6 (ModDinhMucAI173.DMAI173_TroLy) lap JSON du lieu so (danh muc vat tu + TK, mua vao, ban ra, don gia ton, dinh muc da co, nhap 155,
xuat 152, ho so dinh muc, lua chon da luu) -> tool_htkk_unesco.py /dinhmucai:<json> /buoc:1|2 [/chon:<json>] /ra:<txt>
  buoc 1: de xuat NGANH (thu vien tham_khao\\dinh_muc_nganh\\*.json), xep NHOM tung NVL (Chinh / Phu / Bao bi / Nang luong / Khong vao gia thanh),
          tach THUOC TINH san pham (gram, ml, vat lieu, kieu) va gom nhom "cung khuon" -> VB hoi nguoi dung 4 cau (chon / tick, khong go so).
  buoc 2: voi lua chon cua nguoi dung (nganh, NVL chinh, NVL khong vao gia thanh, san pham can lap) chay cac BO MAY de xuat dinh muc:
          C  san pham tuong tu cung so (dinh muc ma khac x he so gram / ml)                tin cay nen 0,75
          D  can bang khoi luong: tong NVL (kg) = trong luong 1 SP x (1 + hao hut), chia theo co cau NVL chinh   0,70
          E  ty le gia ban: chi phi NVL = gia ban x % NVL (mau nganh) chia theo co cau, / don gia ton      0,60
          F  mau nganh (chi co cau, khong ra so khi thieu gram va gia ban)                                   0,30
          + dien (kWh / kg) tu ho so dinh muc hoac mau nganh; co cau NVL chinh tu gia tri MUA VAO (hoa don) thay vi go.
          Diem = tin cay nguon x do hop ly (CP NVL / gia ban trong khoang nganh; can bang khoi luong; khoang cac bo may lech <= 25 %).
          Ket qua tung ma: dong NVL (SoLuong / 1 DVT san pham), nguon, khoang min - max, muc xanh / vang / do + bao cao; Excel de xem.
Ghi: VB doc tep ';' (khong JSON), nap len luoi Dinh muc tu dong (phuong an 4 "AI so moi"), nguoi dung xem / sua / Ghi vao dinh muc
qua DMTD_GhiBOM (hoi truoc; ma da co dinh muc thang do hoi ghi de). Module nay KHONG ghi MDB, khong goi Claude API; moi so deu co nguon.
Khong ghi ten khach / MST vao nhat ky; tep ket qua chi nam trong AIHoaDon\\ket-qua cua may."""
import datetime
import io
import json
import os
import re
import unicodedata
from collections import OrderedDict, defaultdict

GOC = os.path.dirname(os.path.abspath(__file__))
THU_NGANH = os.path.join(GOC, "tham_khao", "dinh_muc_nganh")
NHOM = ("CHINH", "PHU", "BAOBI", "NANGLUONG", "KHONG")
TEN_NHOM = {"CHINH": "Nguyên liệu chính", "PHU": "Phụ gia / phụ liệu", "BAOBI": "Bao bì", "NANGLUONG": "Năng lượng", "KHONG": "Không vào giá thành"}
TIN_CAY = {"C": 0.75, "D": 0.70, "E": 0.60, "F": 0.30, "H": 0.90}
MUC_TEN = {"XANH": "Xanh", "VANG": "Vàng", "DO": "Đỏ"}
TEN_BO_MAY = {"C": "Sản phẩm tương tự", "D": "Cân bằng khối lượng", "E": "Tỷ lệ giá bán", "F": "Mẫu ngành", "H": "Bảng định mức / dự toán của khách"}
TK_NVL = ("152", "153")
TK_TP = ("155",)
PA_AI = 4


# ============================================================ tien ich
def _so(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return 0.0


def _int(v):
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return 0


def khong_dau(s):
    s = unicodedata.normalize("NFD", str(s or ""))
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    return s.replace("đ", "d").replace("Đ", "D").lower()


def bo_dau(s):
    """bo dau, GIU hoa / thuong (chuoi dua len luoi / nhan ANSI cua VB)."""
    s = unicodedata.normalize("NFD", str(s or ""))
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    return s.replace("\u0111", "d").replace("\u0110", "D")


def _chu(v):
    return str(v or "").replace(";", ",").replace("\r", " ").replace("\n", " ").strip()


_RE_TOKEN = re.compile(r"[^\W_]+", re.U)


def _tokens(s):
    return _RE_TOKEN.findall(unicodedata.normalize("NFC", str(s or "")).lower())


def _khop_token(t, k):
    """token van ban t khop token tu khoa k: giong het (co dau); van ban KHONG dau thi so khong dau; 'pp01' khop 'pp'."""
    if t == k:
        return True
    kd = khong_dau(k)
    t_kd = khong_dau(t) == t
    if t_kd and t == kd:
        return True
    if t.startswith(k) and t[len(k):].isdigit():
        return True
    return t_kd and t.startswith(kd) and t[len(kd):].isdigit()


def khop_tu(van_ban, tu_khoa):
    """tu khoa (1 hay nhieu tu) co trong van ban theo TU TRON VEN: 'cổng' khong khop 'công ty', 'than' khong khop 'thanh sat';
    van ban khong dau (go tat) thi so khong dau. van_ban: chuoi hoac danh sach token (_tokens)."""
    kt = _tokens(tu_khoa)
    if not kt:
        return False
    vt = van_ban if isinstance(van_ban, list) else _tokens(van_ban)
    n = len(kt)
    for i in range(len(vt) - n + 1):
        if all(_khop_token(vt[i + j], kt[j]) for j in range(n)):
            return True
    return False


def dd(x):
    try:
        x = float(x)
    except (TypeError, ValueError):
        return ""
    if abs(x - round(x)) < 0.0005 and abs(x) >= 1:
        return "{:,.0f}".format(x).replace(",", ".")
    return ("%.6f" % x).rstrip("0").rstrip(".").replace(".", ",")


def _lam_tron_dm(x):
    """so luong dinh muc: 6 chu so co nghia, toi da 6 so le."""
    if x == 0:
        return 0.0
    return float("%.6g" % x) if abs(x) < 1 else round(x, 4)


# ============================================================ thu vien mau nganh
_NGANH = {}


def nganh_lib(thu=None):
    thu = thu or THU_NGANH
    if _NGANH.get("_thu") == thu and _NGANH.get("ds"):
        return _NGANH["ds"]
    ds = OrderedDict()
    try:
        ten_tep = sorted(f for f in os.listdir(thu) if f.lower().endswith(".json"))
    except OSError:
        ten_tep = []
    for f in ten_tep:
        try:
            with io.open(os.path.join(thu, f), "r", encoding="utf-8-sig") as g:
                d = json.load(g)
            if d.get("ma"):
                ds[d["ma"]] = d
        except Exception:
            continue
    if "KHAC" in ds:
        ds.move_to_end("KHAC")
    _NGANH["_thu"], _NGANH["ds"] = thu, ds
    return ds


def nganh(ma):
    ds = nganh_lib()
    return ds.get(str(ma or "").upper()) or ds.get("KHAC") or {"ma": "KHAC", "ten": "Khác", "nhom_nvl": {}, "co_cau_chinh": [],
                                                                 "ty_le_gia_ban": {"NVL": [0.4, 0.7]}, "hao_hut": [0.02, 0.06],
                                                                 "dien_kwh_kg": [0.1, 0.4], "ty_trong": {}, "vat_lieu": [], "kieu": []}


def _khoang(ng, khoa, mac_dinh):
    v = ng.get(khoa)
    if isinstance(v, (list, tuple)) and len(v) >= 2:
        return float(v[0]), float(v[1])
    return mac_dinh


def _giua(kh):
    return (kh[0] + kh[1]) / 2.0


# ============================================================ so lieu tu JSON cua VB
class SoLieu(object):
    """vt: [MaSo, SoHieu, Ten, DonVi, TK]; mua: [MaVattu, soLan, tien, luong]; ban: [MaVattu, thang, tien, luong];
    dg: [MaNVL, donGia]; dm: [MaTP, MaNVL, SoLuong, Luong, PL, TL, Thang]; nhap155: [MaTP, thang, luong]; xuat152: [MaNVL, thang, luong, tien];
    hs: {hao_hut %, ma_dien, ds_chinh "1,2", hs_nvl_kwh}; da_chon: {nganh, chinh, khong}; thieu: [MaTP]; dn: {ten}."""

    def __init__(self, dl):
        self.dl = dl or {}
        self.thang = _int(self.dl.get("thang")) or 1
        self.vt = OrderedDict()
        for r in self.dl.get("vt") or []:
            r = list(r) + [""] * (5 - len(r))
            ma = _int(r[0])
            if ma > 0:
                self.vt[ma] = {"ma": ma, "sh": str(r[1] or "").strip(), "ten": str(r[2] or "").strip(), "dvt": str(r[3] or "").strip().upper(),
                               "tk": str(r[4] or "").strip()}
        self.mua = {}
        for r in self.dl.get("mua") or []:
            ma = _int(r[0])
            if ma > 0:
                self.mua[ma] = {"lan": _int(r[1]), "tien": _so(r[2]), "luong": _so(r[3])}
        self.ban = defaultdict(lambda: {"tien": 0.0, "luong": 0.0, "thang": set()})
        for r in self.dl.get("ban") or []:
            ma = _int(r[0])
            if ma > 0:
                b = self.ban[ma]
                b["tien"] += _so(r[2])
                b["luong"] += _so(r[3])
                b["thang"].add(_int(r[1]))
        self.dg = {}
        for r in self.dl.get("dg") or []:
            ma = _int(r[0])
            if ma > 0 and _so(r[1]) > 0:
                self.dg[ma] = _so(r[1])
        self.dm = defaultdict(list)
        for r in self.dl.get("dm") or []:
            ma = _int(r[0])
            if ma > 0 and _int(r[1]) > 0:
                self.dm[ma].append({"nvl": _int(r[1]), "sl": _so(r[2]), "luong": _so(r[3]), "pl": str(r[4] or "-"), "tl": _so(r[5]), "thang": _int(r[6])})
        self.hs = dict(self.dl.get("hs") or {})
        self.da_chon = dict(self.dl.get("da_chon") or {})
        self.thieu = set(_int(x) for x in (self.dl.get("thieu") or []) if _int(x) > 0)
        self.dn = dict(self.dl.get("dn") or {})

    def la_nvl(self, v):
        return v["tk"].startswith(TK_NVL) or (not v["tk"] and v["dvt"] in ("KG", "LIT", "LÍT", "L", "M", "M2", "M3", "KWH"))

    def la_tp(self, v):
        return v["tk"].startswith(TK_TP) or (not v["tk"] and v["ma"] in self.ban)

    def ds_nvl(self):
        return [v for v in self.vt.values() if self.la_nvl(v)]

    def ds_tp(self):
        return [v for v in self.vt.values() if self.la_tp(v)]

    def dm_hieu_luc(self, ma_tp):
        """dong dinh muc cua thang hieu luc gan nhat <= thang."""
        ds = [d for d in self.dm.get(ma_tp, []) if d["thang"] <= self.thang]
        if not ds:
            return []
        t = max(d["thang"] for d in ds)
        return [d for d in ds if d["thang"] == t]

    def gia_ban(self, ma_tp):
        b = self.ban.get(ma_tp)
        if b and b["luong"] > 0:
            return b["tien"] / b["luong"]
        return 0.0

    def don_gia(self, ma_nvl):
        if ma_nvl in self.dg:
            return self.dg[ma_nvl]
        m = self.mua.get(ma_nvl)
        if m and m["luong"] > 0:
            return m["tien"] / m["luong"]
        return 0.0


# ============================================================ buoc 1: nganh, nhom NVL, thuoc tinh san pham
def de_xuat_nganh(S, ds=None):
    """diem tung nganh tu ten cong ty + ten san pham ban (trong so doanh thu) + ten NVL mua -> [(ma, diem, ly do)] giam dan."""
    ds = ds or nganh_lib()
    van_ban = []
    van_ban.append((_tokens(S.dn.get("ten")), 3.0, "tên công ty"))
    for v in S.ds_tp():
        w = 1.0 + (2.0 if v["ma"] in S.ban else 0.0)
        van_ban.append((_tokens(v["ten"]), w, "sản phẩm"))
    for v in S.ds_nvl():
        w = 0.5 + (0.5 if v["ma"] in S.mua else 0.0)
        van_ban.append((_tokens(v["ten"]), w, "NVL"))
    ra = []
    for ma, ng in ds.items():
        if ma == "KHAC":
            continue
        diem, trung = 0.0, []
        for tk in ng.get("tu_khoa_nganh") or []:
            n = 0.0
            for vb, w, _ng in van_ban:
                if khop_tu(vb, tk):
                    n += w
            if n:
                diem += min(n, 6.0)
                trung.append(tk)
        for tk in (ng.get("nhom_nvl") or {}).get("CHINH") or []:
            k = khong_dau(tk).strip()
            if len(k) < 3:
                continue
            for vb, w, _ng in van_ban:
                if _ng == "NVL" and khop_tu(vb, tk):
                    diem += 0.3 * w
        ra.append((ma, round(diem, 2), ", ".join(trung[:6])))
    ra.sort(key=lambda x: -x[1])
    return ra


def _khop_tu_khoa(ten_tok, ds_tk):
    for tk in ds_tk or []:
        if khop_tu(ten_tok, tk):
            return tk
    return ""


def phan_nhom_nvl(S, ma_nganh, chon_chinh=(), chon_khong=(), qd_chinh=False, qd_khong=False):
    """-> OrderedDict {MaSo: {"nhom", "diem", "ly_do", "tu_khoa"}}: tu khoa nganh (uu tien thu tu KHONG, NANGLUONG, BAOBI, PHU, CHINH),
    roi gia tri mua vao (NVL mua nhieu nhat chua co nhom -> CHINH), ma dien / NVL chu dao trong ho so, lua chon nguoi dung ghi de.
    qd_chinh / qd_khong = nguoi dung DA tra loi cau hoi: danh sach chon la quyet dinh - ma CHINH / KHONG theo tu khoa ma khong duoc tich
    thi ha xuong PHU (bo tick co tac dung)."""
    ng = nganh(ma_nganh)
    nhom_tk = ng.get("nhom_nvl") or {}
    tong_mua = sum(m["tien"] for m in S.mua.values()) or 0.0
    chon_chinh, chon_khong = set(_int(x) for x in chon_chinh), set(_int(x) for x in chon_khong)
    ma_dien = _int(S.hs.get("ma_dien"))
    ds_chinh_hs = set(_int(x) for x in str(S.hs.get("ds_chinh") or "").replace(";", ",").split(",") if _int(x) > 0)
    ra = OrderedDict()
    for v in S.ds_nvl():
        ten_tok = _tokens(v["sh"] + " " + v["ten"])
        nhom, ly_do, diem, tk_trung = "", "", 0.5, ""
        if v["dvt"] in ("KWH",) or v["ma"] == ma_dien:
            nhom, ly_do, diem = "NANGLUONG", "mã điện (hồ sơ định mức / kWh)", 0.95
        else:
            for n in ("KHONG", "NANGLUONG", "BAOBI", "PHU", "CHINH"):
                tk_trung = _khop_tu_khoa(ten_tok, nhom_tk.get(n))
                if tk_trung:
                    nhom, ly_do, diem = n, "từ khoá '%s' (mẫu ngành %s)" % (tk_trung, ng.get("ma")), 0.75
                    break
        m = S.mua.get(v["ma"]) or {"lan": 0, "tien": 0.0, "luong": 0.0}
        ty = (m["tien"] / tong_mua) if tong_mua else 0.0
        if not nhom:
            if ty >= 0.05:
                nhom, ly_do, diem = "CHINH", "mua vào %.0f%% giá trị NVL năm" % (ty * 100), 0.6
            elif m["lan"] > 0:
                nhom, ly_do, diem = "PHU", "mua %d lần, giá trị nhỏ" % m["lan"], 0.4
            else:
                nhom, ly_do, diem = "PHU", "không có từ khoá, chưa mua trong năm", 0.3
        if v["ma"] in ds_chinh_hs and nhom != "NANGLUONG":
            nhom, ly_do, diem = "CHINH", "NVL chủ đạo trong Hồ sơ định mức", 0.95
        if qd_chinh and nhom == "CHINH" and v["ma"] not in chon_chinh:
            nhom, ly_do, diem = "PHU", "người dùng bỏ chọn NVL chính", 0.9
        if qd_khong and nhom == "KHONG" and v["ma"] not in chon_khong:
            nhom, ly_do, diem = "PHU", "người dùng không loại khỏi định mức", 0.9
        if v["ma"] in chon_chinh:
            nhom, ly_do, diem = "CHINH", "người dùng chọn", 1.0
        elif v["ma"] in chon_khong:
            nhom, ly_do, diem = "KHONG", "người dùng chọn", 1.0
        ra[v["ma"]] = {"nhom": nhom, "diem": diem, "ly_do": ly_do, "tu_khoa": tk_trung, "lan": m["lan"], "tien": m["tien"], "ty": ty,
                       "don_gia": S.don_gia(v["ma"])}
    return ra


_RE_SO = r"(\d+(?:[\.,]\d+)?)"
_RE_GRAM = re.compile(_RE_SO + r"\s*(?:gr|g|gram|gam)\b(?![a-z])", re.I)
_RE_KG = re.compile(_RE_SO + r"\s*kg\b", re.I)
_RE_ML = re.compile(_RE_SO + r"\s*ml\b", re.I)
_RE_LIT = re.compile(_RE_SO + r"\s*(?:lit|lít|l)\b", re.I)
_RE_OZ = re.compile(_RE_SO + r"\s*oz\b", re.I)
_RE_KT = re.compile(r"(\d+(?:[\.,]\d+)?)\s*[x×\*]\s*(\d+(?:[\.,]\d+)?)(?:\s*[x×\*]\s*(\d+(?:[\.,]\d+)?))?", re.I)


def _so_vn(s):
    return _so(str(s).replace(",", "."))


def tach_thuoc_tinh(ten, ng):
    """ten san pham -> {"gram", "ml", "kg_sp", "vat_lieu", "kieu", "kich_thuoc", "nguon_kg"}; kg_sp = trong luong 1 SP (kg) neu suy duoc."""
    t = str(ten or "")
    tk = _tokens(t)
    kq = {"gram": 0.0, "ml": 0.0, "kg_sp": 0.0, "vat_lieu": "", "kieu": "", "kich_thuoc": "", "nguon_kg": "", "uoc": False}
    m = _RE_KG.search(t)
    if m:
        kq["gram"] = _so_vn(m.group(1)) * 1000
    m = _RE_GRAM.search(t)
    if m and not kq["gram"]:
        kq["gram"] = _so_vn(m.group(1))
    m = _RE_ML.search(t)
    if m:
        kq["ml"] = _so_vn(m.group(1))
    m = _RE_LIT.search(t)
    if m and not kq["ml"]:
        kq["ml"] = _so_vn(m.group(1)) * 1000
    m = _RE_OZ.search(t)
    if m and not kq["ml"]:
        kq["ml"] = _so_vn(m.group(1)) * 29.5735
    m = _RE_KT.search(t)
    if m:
        kq["kich_thuoc"] = "x".join(x for x in m.groups() if x)
    for vl in ng.get("vat_lieu") or []:
        if khop_tu(tk, vl):
            kq["vat_lieu"] = vl
            break
    for k in ng.get("kieu") or []:
        if khop_tu(tk, k):
            kq["kieu"] = k
            break
    if kq["gram"] > 0:
        kq["kg_sp"], kq["nguon_kg"] = kq["gram"] / 1000.0, "gram trong tên"
    elif kq["ml"] > 0:
        tt = ng.get("ty_trong") or {}
        if ng.get("ml_to_g_mac_dinh"):
            # nganh vo chua (ly, hop, chai nhua): ml la DUNG TICH, khoi luong vo ~ ml x g/ml mau nganh (tin cay thap)
            kq["kg_sp"], kq["nguon_kg"] = kq["ml"] * float(ng["ml_to_g_mac_dinh"]) / 1000.0, "ước tính: %s ml x %s g/ml theo vỏ chứa của mẫu ngành" % (dd(kq["ml"]), dd(float(ng["ml_to_g_mac_dinh"])))
            kq["uoc"] = True
        else:
            rho = tt.get(kq["vat_lieu"]) or tt.get("MAC_DINH")
            if rho:
                kq["kg_sp"], kq["nguon_kg"] = kq["ml"] * float(rho) / 1000.0, "ml x tỷ trọng %s" % rho
    return kq


def thuoc_tinh_sp(S, ma_nganh):
    ng = nganh(ma_nganh)
    ra = OrderedDict()
    for v in S.ds_tp():
        tt = tach_thuoc_tinh(v["ten"], ng)
        b = S.ban.get(v["ma"])
        tt["gia_ban"] = S.gia_ban(v["ma"])
        tt["doanh_thu"] = b["tien"] if b else 0.0
        tt["co_dm"] = 1 if S.dm_hieu_luc(v["ma"]) else 0
        tt["thieu"] = 1 if (v["ma"] in S.thieu or (not tt["co_dm"])) else 0
        tt["nhom_sp"] = "|".join(x for x in (tt["vat_lieu"], tt["kieu"]) if x) or "(khác)"
        ra[v["ma"]] = tt
    return ra


# ============================================================ buoc 2: cac bo may de xuat
def _co_cau(S, ng, ds_chinh, nhom_nvl):
    """ty trong tung NVL chinh: theo gia tri mua vao (hoa don) trong nhom tu khoa cua mau nganh; khong co mua -> chia deu trong nhom."""
    cc = ng.get("co_cau_chinh") or []
    ra = {}
    if cc:
        nhom_ma = defaultdict(list)
        for ma in ds_chinh:
            ten_tok = _tokens(S.vt[ma]["sh"] + " " + S.vt[ma]["ten"])
            k, dai = None, 0
            for i, (rx, _ty) in enumerate(cc):
                # nhom co tu khoa khop DAI nhat thang ("hat mau" -> nhom mau, khong phai nhom "hat")
                d = max([len(x.strip()) for x in rx.split("|") if x.strip() and khop_tu(ten_tok, x)] or [0])
                if d > dai:
                    k, dai = i, d
            nhom_ma[k].append(ma)
        tong_ty = sum(ty for i, (_rx, ty) in enumerate(cc) if i in nhom_ma) or 1.0
        for k, mas in nhom_ma.items():
            ty = (cc[k][1] / tong_ty) if k is not None else 0.0
            if k is None:
                continue
            tien = {ma: (S.mua.get(ma) or {}).get("tien", 0.0) for ma in mas}
            tong = sum(tien.values())
            for ma in mas:
                ra[ma] = ty * ((tien[ma] / tong) if tong > 0 else 1.0 / len(mas))
        con = [ma for ma in ds_chinh if ma not in ra]
        if con:
            du = max(0.0, 1.0 - sum(ra.values()))
            tien = {ma: (S.mua.get(ma) or {}).get("tien", 0.0) for ma in con}
            tong = sum(tien.values())
            for ma in con:
                ra[ma] = (du if du > 0 else 0.1) * ((tien[ma] / tong) if tong > 0 else 1.0 / len(con))
    else:
        tien = {ma: (S.mua.get(ma) or {}).get("tien", 0.0) for ma in ds_chinh}
        tong = sum(tien.values())
        for ma in ds_chinh:
            ra[ma] = (tien[ma] / tong) if tong > 0 else 1.0 / max(len(ds_chinh), 1)
    s = sum(ra.values())
    if s > 0:
        ra = {k: v / s for k, v in ra.items()}
    return ra


def _la_kg(S, ma):
    return S.vt[ma]["dvt"] in ("KG", "KILOGAM", "KILOGRAM")


def bo_may_D(S, ng, tt, ds_chinh, ds_phu, co_cau, hao_hut):
    """can bang khoi luong: tong NVL chinh (kg) = kg_sp x (1 + hao hut) chia theo co cau; phu = % tren NVL chinh (chia deu)."""
    kq = {}
    if tt["kg_sp"] <= 0 or not ds_chinh:
        return kq, "thiếu trọng lượng / dung tích trong tên sản phẩm" if tt["kg_sp"] <= 0 else "chưa có NVL chính"
    tong = tt["kg_sp"] * (1.0 + hao_hut)
    for ma in ds_chinh:
        if _la_kg(S, ma):
            kq[ma] = tong * co_cau.get(ma, 0.0)
    ty_phu = float(ng.get("phu_ty_le_chinh") or 0.0)
    phu_kg = [ma for ma in ds_phu if _la_kg(S, ma)]
    if phu_kg and ty_phu > 0:
        for ma in phu_kg:
            kq[ma] = tong * ty_phu / len(phu_kg)
    return kq, "1 SP = %s g x (1 + hao hụt %.0f%%)" % (dd(round(tt["kg_sp"] * 1000, 1)), hao_hut * 100)


def bo_may_E(S, ng, tt, ds_chinh, ds_phu, co_cau, ty_nvl):
    """ty le gia ban: chi phi NVL = gia ban x % NVL; chia theo co cau; so luong = chi phi / don gia (NVL co don gia)."""
    kq = {}
    gb = tt["gia_ban"]
    if gb <= 0 or not ds_chinh:
        return kq, "chưa có giá bán (hoá đơn 511)" if gb <= 0 else "chưa có NVL chính"
    cp = gb * ty_nvl
    ty_phu = float(ng.get("phu_ty_le_chinh") or 0.0)
    thieu = []
    for ma in ds_chinh:
        dg = S.don_gia(ma)
        if dg > 0:
            kq[ma] = cp * (1.0 - ty_phu) * co_cau.get(ma, 0.0) / dg
        else:
            thieu.append(S.vt[ma]["sh"])
    phu = [ma for ma in ds_phu if S.don_gia(ma) > 0]
    if phu and ty_phu > 0:
        for ma in phu:
            kq[ma] = cp * ty_phu / len(phu) / S.don_gia(ma)
    gc = "Chi phí NVL = giá bán %s x %.0f%%" % (dd(gb), ty_nvl * 100)
    if thieu:
        gc += "; thiếu đơn giá: " + ", ".join(thieu[:4])
    return kq, gc


def bo_may_C(S, ng, ma_tp, tt, tt_all, nhom=None):
    """san pham tuong tu cung so: ma co dinh muc, cung nhom (vat lieu | kieu), co kg_sp -> x he so kg; khong kg -> he so 1 neu cung nhom.
    NVL nhom KHONG (nguoi dung loai) trong dinh muc ma nen khong dua sang."""
    kq, nen, he_so = {}, None, 0.0
    ung = []
    for ma, t2 in tt_all.items():
        if ma == ma_tp or not S.dm_hieu_luc(ma):
            continue
        diem = 0.0
        if t2["nhom_sp"] == tt["nhom_sp"] and tt["nhom_sp"] != "(khác)":
            diem += 2.0
        elif t2["vat_lieu"] and t2["vat_lieu"] == tt["vat_lieu"]:
            diem += 1.0
        elif t2["kieu"] and t2["kieu"] == tt["kieu"]:
            diem += 1.0
        if tt["kg_sp"] > 0 and t2["kg_sp"] > 0:
            r = tt["kg_sp"] / t2["kg_sp"]
            if 0.2 <= r <= 5:
                diem += 1.0 - min(abs(1 - r), 0.8)
        if diem > 0:
            ung.append((diem, ma, t2))
    if not ung:
        return kq, None, 0.0, "không có mã cùng nhóm đã có định mức"
    ung.sort(key=lambda x: -x[0])
    diem, nen, t2 = ung[0]
    he_so = (tt["kg_sp"] / t2["kg_sp"]) if (tt["kg_sp"] > 0 and t2["kg_sp"] > 0) else 1.0
    for d in S.dm_hieu_luc(nen):
        if d["sl"] > 0 and ((nhom or {}).get(d["nvl"]) or {}).get("nhom") != "KHONG":
            kq[d["nvl"]] = d["sl"] * he_so
    return kq, nen, he_so, "định mức %s x %s" % (S.vt.get(nen, {}).get("sh", nen), dd(he_so))


def de_xuat_ma(S, ng, ma_tp, tt, tt_all, nhom, ds_chinh, ds_phu, ma_dien, hao_hut, ty_nvl):
    """gop cac bo may cho mot ma -> {"dong": [...], "tin_cay", "tom_tat", "bao_cao", "muc"}."""
    co_cau = _co_cau(S, ng, ds_chinh, nhom)
    ung = defaultdict(list)             # ma_nvl -> [(bo may, so luong)]
    bc = []
    if tt.get("nguon_kg"):
        bc.append("Trọng lượng 1 SP: %s g (%s)" % (dd(round(tt["kg_sp"] * 1000, 1)), tt["nguon_kg"]))
    kqD, gcD = bo_may_D(S, ng, tt, ds_chinh, ds_phu, co_cau, hao_hut)
    bc.append("Cân bằng khối lượng: %s%s" % (gcD, " (ra %d dòng NVL)" % len(kqD) if kqD else ""))
    for ma, sl in kqD.items():
        ung[ma].append(("D", sl))
    tin_cay = dict(TIN_CAY)
    if tt.get("uoc"):
        tin_cay["D"] = 0.45                  # khoi luong uoc tu dung tich (vo chua) -> tin cay thap hon
    kqE, gcE = bo_may_E(S, ng, tt, ds_chinh, ds_phu, co_cau, ty_nvl)
    bc.append("Tỷ lệ giá bán: %s%s" % (gcE, " (ra %d dòng NVL)" % len(kqE) if kqE else ""))
    for ma, sl in kqE.items():
        ung[ma].append(("E", sl))
    kqC, nen, he_so, gcC = bo_may_C(S, ng, ma_tp, tt, tt_all, nhom)
    bc.append("Sản phẩm tương tự: %s%s" % (gcC, " (ra %d dòng NVL)" % len(kqC) if kqC else ""))
    for ma, sl in kqC.items():
        if ma in S.vt:
            ung[ma].append(("C", sl))
    # dien
    dien_kwh = 0.0
    if ma_dien and tt["kg_sp"] > 0:
        hs = _so(S.hs.get("hs_nvl_kwh"))
        if hs > 0:
            dien_kwh, ng_dien = tt["kg_sp"] * (1 + hao_hut) / hs, "hồ sơ %s kg NVL/kWh" % dd(hs)
        else:
            kwh_kg = _giua(_khoang(ng, "dien_kwh_kg", (0.1, 0.4)))
            dien_kwh, ng_dien = tt["kg_sp"] * (1 + hao_hut) * kwh_kg, "mẫu ngành %s kWh/kg" % dd(kwh_kg)
        if "C" not in [u[0] for u in ung.get(ma_dien, [])]:
            ung[ma_dien].append(("F", dien_kwh))
        bc.append("Điện: %s kWh/SP (%s)" % (dd(dien_kwh), ng_dien))
    # F: chi co cau khi khong co so
    if not ung:
        for ma in ds_chinh + ds_phu:
            ung[ma].append(("F", 0.0))
        bc.append("Mẫu ngành: chỉ ghi cơ cấu NVL (thiếu gram / giá bán) - cần khai trọng lượng 1 sản phẩm hoặc giá bán")
    for ma in ds_chinh:
        if ma not in ung:
            ung[ma].append(("F", 0.0))          # NVL chinh khong bo may nao tinh duoc (khong kg, khong don gia) -> dong DO, nguoi dung tu dien
    dong = []
    tin_cay_ma, n_tin = 0.0, 0
    for ma in list(ds_chinh) + list(ds_phu) + [m for m in ung if m not in ds_chinh and m not in ds_phu]:
        if ma not in ung or ma not in S.vt:
            continue
        cands = [(bm, sl) for bm, sl in ung[ma] if sl > 0]
        if not cands:
            dong.append({"nvl": ma, "sl": 0.0, "nguon": "Mẫu ngành (chưa tính được số)", "min": 0.0, "max": 0.0, "muc": "DO", "tin_cay": 0.3, "bo_may": "F"})
            continue
        cands.sort(key=lambda x: -tin_cay[x[0]])
        bm, sl = cands[0]
        gia = sorted(x[1] for x in cands)
        lo, hi = gia[0], gia[-1]
        if len(cands) >= 2:
            sl = gia[len(gia) // 2] if len(gia) % 2 else (gia[len(gia) // 2 - 1] + gia[len(gia) // 2]) / 2.0
        tc = tin_cay[bm]
        lech = ((hi - lo) / hi) if hi > 0 else 0.0
        if len(cands) >= 2:
            tc = tc * (1.0 - min(lech, 0.5) * 0.6) + 0.1 * (len(cands) - 1)
        tc = min(tc, 0.95)
        nguon = " + ".join(TEN_BO_MAY[b] for b, _v in cands) if len(cands) > 1 else TEN_BO_MAY[bm]
        if bm == "C" and nen:
            khac = [TEN_BO_MAY[b] for b, _v in cands if b != "C"]
            nguon = "%s: %s x %s" % (TEN_BO_MAY["C"], S.vt.get(nen, {}).get("sh", nen), dd(he_so)) + "".join(" + " + t for t in khac)
        muc = "XANH" if (tc >= 0.65 and lech <= 0.25) else ("VANG" if tc >= 0.3 else "DO")
        dong.append({"nvl": ma, "sl": _lam_tron_dm(sl), "nguon": nguon, "min": _lam_tron_dm(lo), "max": _lam_tron_dm(hi), "muc": muc, "tin_cay": round(tc, 2), "bo_may": bm})
        tin_cay_ma += tc
        n_tin += 1
    tin_cay = (tin_cay_ma / n_tin) if n_tin else 0.0
    # hop ly: CP NVL / gia ban ; can bang khoi luong
    hop_ly, gc_hl = 1.0, []
    cp = sum(d["sl"] * S.don_gia(d["nvl"]) for d in dong if d["sl"] > 0 and S.don_gia(d["nvl"]) > 0)
    if tt["gia_ban"] > 0 and cp > 0:
        r = cp / tt["gia_ban"]
        lo, hi = (ng.get("ty_le_gia_ban") or {}).get("NVL", [0.4, 0.7])
        if lo <= r <= hi:
            gc_hl.append("Chi phí NVL / giá bán %.0f%% trong khoảng ngành %.0f-%.0f%%" % (r * 100, lo * 100, hi * 100))
        elif lo * 0.6 <= r <= min(hi * 1.3, 1.1):
            hop_ly = min(hop_ly, 0.75)
            gc_hl.append("Chi phí NVL / giá bán %.0f%% hơi lệch khoảng ngành %.0f-%.0f%%" % (r * 100, lo * 100, hi * 100))
        else:
            hop_ly = min(hop_ly, 0.4)
            gc_hl.append("Chi phí NVL / giá bán %.0f%% NGOÀI khoảng ngành %.0f-%.0f%%" % (r * 100, lo * 100, hi * 100))
    tong_kg = sum(d["sl"] for d in dong if d["sl"] > 0 and _la_kg(S, d["nvl"]) and d["nvl"] != ma_dien)
    if tt["kg_sp"] > 0 and tong_kg > 0:
        q = tong_kg / (tt["kg_sp"] * (1 + hao_hut))
        if 0.85 <= q <= 1.2:
            gc_hl.append("cân bằng khối lượng: NVL %s g / SP %s g (hệ số %s)" % (dd(round(tong_kg * 1000, 1)), dd(round(tt["kg_sp"] * 1000, 1)), dd(round(q, 2))))
        elif 0.6 <= q <= 1.8:
            hop_ly = min(hop_ly, 0.7)
            gc_hl.append("cân bằng khối lượng lệch: NVL %s g / SP %s g (hệ số %s)" % (dd(round(tong_kg * 1000, 1)), dd(round(tt["kg_sp"] * 1000, 1)), dd(round(q, 2))))
        else:
            hop_ly = min(hop_ly, 0.4)
            gc_hl.append("KHÔNG cân bằng: NVL %s g / SP %s g (hệ số %s)" % (dd(round(tong_kg * 1000, 1)), dd(round(tt["kg_sp"] * 1000, 1)), dd(round(q, 2))))
    tin_cay = round(tin_cay * hop_ly, 2)
    for d in dong:
        if hop_ly < 0.5 and d["muc"] == "XANH":
            d["muc"] = "VANG"
    so_xanh = sum(1 for d in dong if d["muc"] == "XANH")
    tom_tat = "Trợ lý AI (sổ mới): %d dòng NVL, %d dòng xanh, độ tin cậy %d%% - %s" % (len(dong), so_xanh, round(tin_cay * 100), "; ".join(gc_hl) or "chưa kiểm được hợp lý")
    bc.append("Hợp lý: " + ("; ".join(gc_hl) or "chưa kiểm được (thiếu giá bán / gram)"))
    bc.append("Kết luận: " + tom_tat)
    muc = "XANH" if tin_cay >= 0.65 else ("VANG" if tin_cay >= 0.3 else "DO")
    return {"dong": dong, "tin_cay": tin_cay, "tom_tat": tom_tat, "bao_cao": bc, "muc": muc, "co_cau": co_cau}


def buoc2(S, chon):
    ma_nganh = str(chon.get("nganh") or S.da_chon.get("nganh") or "KHAC").upper()
    ng = nganh(ma_nganh)
    chinh = [_int(x) for x in (chon.get("chinh") or []) if _int(x) > 0]
    khong = set(_int(x) for x in (chon.get("khong") or []) if _int(x) > 0)
    nhom = phan_nhom_nvl(S, ma_nganh, chinh, khong, qd_chinh=bool(chinh), qd_khong=bool(chon.get("hoi_khong", True)))
    ds_chinh = [ma for ma, n in nhom.items() if n["nhom"] == "CHINH" and ma not in khong]
    ds_phu = [ma for ma, n in nhom.items() if n["nhom"] == "PHU" and ma not in khong]
    ma_dien = _int(S.hs.get("ma_dien")) or next((ma for ma, n in nhom.items() if n["nhom"] == "NANGLUONG" and S.vt[ma]["dvt"] == "KWH"), 0)
    hao_hut = _so(S.hs.get("hao_hut")) / 100.0 if _so(S.hs.get("hao_hut")) > 0 else _giua(_khoang(ng, "hao_hut", (0.02, 0.06)))
    ty_nvl = _giua(tuple((ng.get("ty_le_gia_ban") or {}).get("NVL", [0.4, 0.7])))
    tt_all = thuoc_tinh_sp(S, ma_nganh)
    ds_sp = [_int(x) for x in (chon.get("sp") or []) if _int(x) > 0] or [ma for ma, t in tt_all.items() if t["thieu"]]
    gram_them = {_int(k): _so(v) for k, v in (chon.get("gram") or {}).items()}
    kq = OrderedDict()
    try:                                       # GD211: bang dinh muc / du toan cua khach (thu muc nguon) la nguon UU TIEN (bo may H)
        import dinh_muc_nguon
        ng_h = dinh_muc_nguon.nap(S)
    except Exception:
        dinh_muc_nguon, ng_h = None, None
    for ma in ds_sp:
        if ma not in S.vt:
            continue
        tt = tt_all.get(ma) or tach_thuoc_tinh(S.vt[ma]["ten"], ng)
        if gram_them.get(ma, 0) > 0:
            tt = dict(tt)
            tt["kg_sp"], tt["nguon_kg"] = gram_them[ma] / 1000.0, "người dùng khai"
        kq[ma] = de_xuat_ma(S, ng, ma, tt, tt_all, nhom, ds_chinh, ds_phu, ma_dien, hao_hut, ty_nvl)
        kq[ma]["tt"] = tt
        h = dinh_muc_nguon.de_xuat_tu_bang(S, ng_h, ma, _lam_tron_dm) if dinh_muc_nguon else None
        if h:
            ai = {d["nvl"]: d["sl"] for d in kq[ma]["dong"] if d["sl"] > 0}
            lech = []
            for d in h["dong"]:
                a = ai.get(d["nvl"], 0.0)
                if a > 0 and d["sl"] > 0 and abs(a - d["sl"]) / d["sl"] > 0.5:
                    lech.append("%s: bảng %s, AI ước tính %s" % (S.vt[d["nvl"]]["sh"], dd(d["sl"]), dd(a)))
            bc_ai = ["Ước tính của AI (chỉ để đối chiếu, không dùng): " + kq[ma]["tom_tat"]]
            if lech:
                bc_ai.append("Lệch trên 50%% so với ước tính AI (xem lại bảng): %s" % "; ".join(lech[:6]))
            kq[ma].update({"dong": h["dong"], "tin_cay": h["tin_cay"], "tom_tat": h["tom_tat"], "muc": h["muc"], "bao_cao": h["bao_cao"] + bc_ai + kq[ma]["bao_cao"]})
    return {"nganh": ma_nganh, "ten_nganh": ng.get("ten", ma_nganh), "hao_hut": hao_hut, "ty_nvl": ty_nvl, "ds_chinh": ds_chinh, "ds_phu": ds_phu,
            "ma_dien": ma_dien, "kq": kq, "nhom": nhom, "nguon_dm": (dinh_muc_nguon.tom_tat_nguon(ng_h) if dinh_muc_nguon else [])}


def buoc1(S):
    da = S.da_chon
    ds_ng = de_xuat_nganh(S)
    ma_nganh = str(da.get("nganh") or "").upper()
    ly_do = "đã chọn lần trước"
    if ma_nganh not in nganh_lib():
        ma_nganh, ly_do = (ds_ng[0][0], "từ khoá: " + ds_ng[0][2]) if ds_ng and ds_ng[0][1] > 0 else ("KHAC", "không nhận ra ngành từ tên công ty / sản phẩm")
    chon_chinh = [_int(x) for x in str(da.get("chinh") or "").replace(";", ",").split(",") if _int(x) > 0]
    chon_khong = [_int(x) for x in str(da.get("khong") or "").replace(";", ",").split(",") if _int(x) > 0]
    # lua chon da luu (VB ghi DMAI_CHINH / DMAI_KHONG; "-" = da hoi, khong loai gi) la quyet dinh cho tick mac dinh lan sau
    nhom = phan_nhom_nvl(S, ma_nganh, chon_chinh, chon_khong, qd_chinh=bool(chon_chinh), qd_khong=bool(str(da.get("khong") or "").strip()))
    tt = thuoc_tinh_sp(S, ma_nganh)
    try:                                       # GD211: san pham co trong bang dinh muc / du toan cua khach (thu muc nguon)
        import dinh_muc_nguon
        ng_h = dinh_muc_nguon.nap(S)
    except Exception:
        ng_h = None
    for ma, t in tt.items():
        t["co_bang"] = 1 if (ng_h and ma in ng_h["sp_map"]) else 0
        if t["co_bang"] and not t["co_dm"]:
            t["thieu"] = 1
    return {"nganh": ma_nganh, "ly_do": ly_do, "ds_nganh": ds_ng, "nhom": nhom, "tt": tt, "nguon_dm": ng_h}


# ============================================================ ghi ket qua cho VB (tep ';') + Excel
def ghi_txt1(S, k1, duong):
    ds = nganh_lib()
    d = ["TONG;1;%s;%d;%d" % (k1["nganh"], len(k1["nhom"]), len(k1["tt"]))]
    for ma, ng in ds.items():
        d.append("DS;%s;%s" % (ma, _chu(ng.get("ten"))))
    diem = {x[0]: x[1] for x in k1["ds_nganh"]}
    d.append("NGANH;%s;%s;%s;%s" % (k1["nganh"], _chu(ds.get(k1["nganh"], {}).get("ten", k1["nganh"])), dd(diem.get(k1["nganh"], 0)), _chu(k1["ly_do"])))
    for ma, n in sorted(k1["nhom"].items(), key=lambda kv: (NHOM.index(kv[1]["nhom"]) if kv[1]["nhom"] in NHOM else 9, -kv[1]["tien"])):
        v = S.vt[ma]
        d.append("NVL;%d;%s;%s;%s;%s;%d;%s;%s;%s" % (ma, _chu(v["sh"]), _chu(v["ten"]), _chu(v["dvt"]), n["nhom"], n["lan"], dd(round(n["tien"])), dd(n["don_gia"]), _chu(n["ly_do"])))
    for ma, t in sorted(k1["tt"].items(), key=lambda kv: (-kv[1]["thieu"], -kv[1]["doanh_thu"])):
        v = S.vt[ma]
        d.append("SP;%d;%s;%s;%s;%s;%s;%s;%s;%s;%d;%d;%d" % (ma, _chu(v["sh"]), _chu(v["ten"]), _chu(v["dvt"]), dd(t["kg_sp"] * 1000), _chu(t["vat_lieu"]),
                                                       _chu(t["nhom_sp"]), dd(round(t["gia_ban"])), dd(round(t["doanh_thu"])), t["co_dm"], t["thieu"], t.get("co_bang", 0)))
    with io.open(duong, "w", encoding="utf-8-sig", newline="\r\n") as f:
        f.write("\n".join(d) + "\n")
    return duong


def ghi_txt2(S, k2, duong, xlsx=""):
    kq = k2["kq"]
    n = {"XANH": 0, "VANG": 0, "DO": 0}
    for r in kq.values():
        n[r["muc"]] += 1
    d = ["TONG;2;%d;%d;%d;%d;%s" % (len(kq), n["XANH"], n["VANG"], n["DO"], _chu(xlsx))]
    for ma, r in kq.items():
        # nguon / tom tat / bao cao: BO DAU (luoi MSFlexGrid, Label cua form VB la ANSI - chu Unicode gan thang thanh "?"); Excel giu dau
        d.append("KQ;%d;%d;%s;%s;%s" % (ma, PA_AI, ("%.2f" % r["tin_cay"]).replace(",", "."), r["muc"], bo_dau(_chu(r["tom_tat"]))))
        for x in r["dong"]:
            v = S.vt.get(x["nvl"]) or {"sh": str(x["nvl"]), "ten": "", "dvt": ""}
            d.append("D;%d;%d;%s;%s;%s;%s;0;-;0;%s;%s;%s;%s;%s" % (ma, x["nvl"], _chu(v["sh"]), _chu(v["ten"]), _chu(v["dvt"]), repr(float(x["sl"])),
                                                              bo_dau(_chu(x["nguon"])), repr(float(x["min"])), repr(float(x["max"])), x["muc"], ("%.2f" % x["tin_cay"])))
        for b in r["bao_cao"]:
            d.append("BC;%d;%s" % (ma, bo_dau(_chu(b))))
    for b in k2.get("nguon_dm") or []:
        d.append("NGUON;%s" % bo_dau(_chu(b)))
    with io.open(duong, "w", encoding="utf-8-sig", newline="\r\n") as f:
        f.write("\n".join(d) + "\n")
    return duong


def ghi_excel(S, k1, k2, duong):
    try:
        from xlsx_viet import SoExcel
    except Exception:
        return ""
    wb = SoExcel(font="Times New Roman", co=11)
    k_dam = wb.kieu(dam=True)
    k_td = wb.kieu(dam=True, co=13)
    k_dau = wb.kieu(dam=True, co=10, can="giua", xuong=True, khung=True, nen="D9E1F2")
    k_o = wb.kieu(khung=True, co=10, xuong=True)
    k_so = wb.kieu(khung=True, co=10, so="#,##0.######")
    k_tien = wb.kieu(khung=True, co=10, so="#,##0")
    k_xanh = wb.kieu(khung=True, co=10, nen="E2F0D9")
    k_vang = wb.kieu(khung=True, co=10, nen="FFF2CC")
    k_do = wb.kieu(khung=True, co=10, nen="F8CBAD")
    mau = {"XANH": k_xanh, "VANG": k_vang, "DO": k_do}
    ws = wb.sheet("Đề xuất", [12, 12, 40, 8, 14, 34, 12, 12, 8, 8])
    r = 1
    ws.gop(r, 1, r, 10, "TRỢ LÝ LẬP ĐỊNH MỨC - ĐỀ XUẤT (ngành %s; hao hụt %.0f%%; chi phí NVL / giá bán %.0f%%) - %s" % (
        k2["ten_nganh"], k2["hao_hut"] * 100, k2["ty_nvl"] * 100, datetime.datetime.now().strftime("%d/%m/%Y %H:%M")), k_td)
    r += 1
    ws.gop(r, 1, r, 10, "AI chỉ đề xuất; xem, sửa trên màn hình Định mức tự động rồi bấm Ghi vào định mức. Xanh = tin cậy cao, vàng = kiểm lại, đỏ = chưa tính được.", wb.kieu(nghieng=True, co=10))
    r += 2
    for c, td in enumerate(("Mã SP", "Mã NVL", "Tên NVL", "ĐVT", "Số lượng / 1 SP", "Nguồn", "Khoảng thấp", "Khoảng cao", "Mức", "Tin cậy"), 1):
        ws.o(r, c, td, k_dau)
    r += 1
    for ma, kq in k2["kq"].items():
        v = S.vt[ma]
        ws.gop(r, 1, r, 10, "%s - %s | %s | tin cậy %d%% (%s)" % (v["sh"], v["ten"], MUC_TEN.get(kq["muc"], kq["muc"]), round(kq["tin_cay"] * 100), kq["tom_tat"]), mau.get(kq["muc"], k_o))
        r += 1
        for x in kq["dong"]:
            n = S.vt.get(x["nvl"]) or {"sh": str(x["nvl"]), "ten": "", "dvt": ""}
            ws.o(r, 1, v["sh"], k_o)
            ws.o(r, 2, n["sh"], k_o)
            ws.o(r, 3, n["ten"], k_o)
            ws.o(r, 4, n["dvt"], k_o)
            ws.o(r, 5, x["sl"], k_so)
            ws.o(r, 6, x["nguon"], k_o)
            ws.o(r, 7, x["min"], k_so)
            ws.o(r, 8, x["max"], k_so)
            ws.o(r, 9, MUC_TEN.get(x["muc"], x["muc"]), mau.get(x["muc"], k_o))
            ws.o(r, 10, x["tin_cay"], k_o)
            r += 1
        for b in kq["bao_cao"]:
            ws.gop(r, 2, r, 10, b, wb.kieu(nghieng=True, co=9))
            r += 1
        r += 1
    ws = wb.sheet("Nhóm NVL", [12, 40, 8, 16, 8, 16, 14, 40])
    r = 1
    for c, td in enumerate(("Mã", "Tên NVL", "ĐVT", "Nhóm", "Số lần mua", "Giá trị mua", "Đơn giá", "Lý do"), 1):
        ws.o(r, c, td, k_dau)
    r += 1
    for ma, n in k2["nhom"].items():
        v = S.vt[ma]
        for c, gt, k in ((1, v["sh"], k_o), (2, v["ten"], k_o), (3, v["dvt"], k_o), (4, TEN_NHOM.get(n["nhom"], n["nhom"]), k_o), (5, n["lan"], k_o),
                         (6, n["tien"], k_tien), (7, n["don_gia"], k_tien), (8, n["ly_do"], k_o)):
            ws.o(r, c, gt, k)
        r += 1
    ws = wb.sheet("Sản phẩm", [12, 40, 8, 12, 12, 16, 14, 16, 8, 8])
    r = 1
    for c, td in enumerate(("Mã", "Tên SP", "ĐVT", "Gram / SP", "Vật liệu", "Nhóm (cùng khuôn)", "Giá bán BQ", "Doanh thu", "Có ĐM", "Cần lập"), 1):
        ws.o(r, c, td, k_dau)
    r += 1
    for ma, t in k1["tt"].items():
        v = S.vt[ma]
        for c, gt, k in ((1, v["sh"], k_o), (2, v["ten"], k_o), (3, v["dvt"], k_o), (4, t["kg_sp"] * 1000, k_so), (5, t["vat_lieu"], k_o), (6, t["nhom_sp"], k_o),
                         (7, t["gia_ban"], k_tien), (8, t["doanh_thu"], k_tien), (9, t["co_dm"], k_o), (10, t["thieu"], k_o)):
            ws.o(r, c, gt, k)
        r += 1
    ws = wb.sheet("Căn cứ", [120])
    r = 1
    for chu in can_cu_chu(k2):
        ws.o(r, 1, chu, k_dam if chu.isupper() else wb.kieu())
        r += 1
    wb.luu(duong)
    return duong


def can_cu_chu(k2):
    ng = nganh(k2["nganh"])
    ra = ["CĂN CỨ ĐỀ XUẤT ĐỊNH MỨC NGUYÊN VẬT LIỆU (TRỢ LÝ LẬP ĐỊNH MỨC)",
          "Ngành: %s - %s. %s" % (ng.get("ma"), ng.get("ten"), ng.get("mo_ta", "")),
          "Nhóm NVL: từ khoá mẫu ngành + giá trị mua vào (hoá đơn) + hồ sơ định mức; người dùng sửa nhóm ở bước 2 (lưu cho lần sau).",
          "Bảng định mức / dự toán của khách trong thư mục chỉ định (độ tin cậy 0,90): mã nào có trong bảng thì lấy đúng số trong bảng (đổi đơn vị g/kg, ml/l; chia cho số lượng sản phẩm của dự toán); các cách tính dưới đây chỉ dùng cho mã chưa có trong bảng.",
          "Các cách tính: sản phẩm tương tự cùng sổ (độ tin cậy 0,75), cân bằng khối lượng (0,70), tỷ lệ giá bán (0,60), mẫu ngành (0,30). Nhiều cách cùng cho kết quả thì lấy giá trị ở giữa; khoảng thấp - cao là phạm vi giữa các cách tính.",
          "Cơ cấu NVL chính: tỷ trọng mẫu ngành theo từ khoá, chia trong nhóm theo giá trị mua vào. Hao hụt: hồ sơ định mức hoặc khoảng ngành %s-%s%%." % (dd(_khoang(ng, "hao_hut", (0, 0))[0] * 100), dd(_khoang(ng, "hao_hut", (0, 0))[1] * 100)),
          "Điện: hồ sơ định mức (kg NVL / kWh) hoặc mẫu ngành %s-%s kWh/kg." % (dd(_khoang(ng, "dien_kwh_kg", (0, 0))[0]), dd(_khoang(ng, "dien_kwh_kg", (0, 0))[1])),
          "Hợp lý: chi phí NVL / giá bán nằm trong khoảng ngành %s-%s%%; cân bằng khối lượng NVL (kg) so với gram trong tên; nếu lệch thì chuyển từ xanh sang vàng." % (
              dd((ng.get("ty_le_gia_ban") or {}).get("NVL", [0, 0])[0] * 100), dd((ng.get("ty_le_gia_ban") or {}).get("NVL", [0, 0])[1] * 100)),
          "AI chỉ đề xuất, không ghi sổ; ghi qua màn hình Định mức tự động (Ghi vào định mức - hỏi trước, mã đã có định mức tháng đó hỏi ghi đè).",
          "Văn bản tham chiếu của ngành: " + ("; ".join("%s (%s, %s)" % (x.get("so_hieu"), x.get("ten"), x.get("nam")) for x in ng.get("dinh_muc_cong_bo") or []) or "chưa có")]
    return ra


# ============================================================ entry
def chay(duong_json, buoc="1", duong_chon="", duong_ra="", ghi_log=None):
    log = ghi_log or (lambda s: None)
    with io.open(duong_json, "r", encoding="utf-8-sig") as f:
        dl = json.loads(f.read(), strict=False)
    S = SoLieu(dl)
    chon = {}
    if duong_chon and os.path.isfile(duong_chon):
        with io.open(duong_chon, "r", encoding="utf-8-sig") as f:
            chon = json.loads(f.read(), strict=False) or {}
    thu = os.path.dirname(os.path.abspath(duong_ra)) if duong_ra else os.path.join(GOC, "ket-qua")
    os.makedirs(thu, exist_ok=True)
    gio = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
    if str(chon.get("nganh") or "").strip():
        S.da_chon["nganh"] = str(chon["nganh"]).strip().upper()      # nguoi dung doi nganh o buoc 1 -> phan nhom lai theo nganh moi
    k1 = buoc1(S)
    if str(buoc) == "1":
        p = duong_ra or os.path.join(thu, "dinh_muc_ai_1_%s.txt" % gio)
        ghi_txt1(S, k1, p)
        log("[DINH MUC AI] buoc 1: nganh %s, %d NVL, %d SP" % (k1["nganh"], len(k1["nhom"]), len(k1["tt"])))
        return p
    k2 = buoc2(S, chon)
    p = duong_ra or os.path.join(thu, "dinh_muc_ai_2_%s.txt" % gio)
    xlsx = ""
    try:
        xlsx = ghi_excel(S, k1, k2, os.path.splitext(p)[0] + ".xlsx")
    except Exception as e:
        log("[DINH MUC AI] Excel loi: %s" % e)
    ghi_txt2(S, k2, p, xlsx)
    log("[DINH MUC AI] buoc 2: nganh %s, %d SP" % (k2["nganh"], len(k2["kq"])))
    return p
