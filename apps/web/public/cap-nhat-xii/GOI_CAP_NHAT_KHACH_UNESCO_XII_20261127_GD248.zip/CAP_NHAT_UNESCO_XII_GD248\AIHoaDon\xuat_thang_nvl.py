# -*- coding: utf-8 -*-
"""GD357 - XUAT THANG NVL SANG CHI PHI HANG LOAT (doanh nghiep dich vu) - PHAN TICH / DE XUAT (chi DOC .MDB qua jet_doc).

Doanh nghiep dich vu (quan ca phe, phong tra, nha hang, spa...) mua NVL tuoi dung ngay: nhap 152 nhung khong xuat -> 152 ton ao tang dan,
chi phi / gia von thieu. Phieu nhap co o "Xuat thang" (ClsChungtu.XuatThang: No <TK chi phi> / Co 152, cung so luong / gia tri dong nhap,
So hieu + "XT", CT_ID = 900000000 + MaSo dong nhap) nhung phai tick tung phieu. Cong cu nay lap DE XUAT cho moi dong nhap 152 chua xuat thang:
  - bo dong da xuat thang (co CT_ID 900000000 + MaSo), thang da khoa, vat tu nguoi dung loai tru (XT357_Bo trong HDDT_ThamSo);
  - KHONG lam am kho: so luong xuat <= ton hien tai cua vat tu (TonKho Luong_t, theo kho + TK) o thang do VA moi thang sau (da tru phan
    da xuat tay / gia thanh dinh muc). Dong khong du ton -> THIEU_TON (con bao nhieu), nguoi xem lai;
  - TK No mac dinh: TK cua lan xuat thang gan nhat trong so (vd 1541), khong co -> 1541 (TT133) / 154 (TT99); 154 thi doi tuong 154 theo
    thang (TP154 'T<thang>' neu co) - giong thao tac tay tren phieu (anh chup: 1541 + T5).
Ra ket-qua\\xuat_thang_nvl.txt cho VB6 FrmXuatThang357 (nguoi duyet, bam Xuat thang -> VB goi dung ClsChungtu.XuatThang tung dong):
  TONG;<so>;<tu>;<den>;<tk>;<n de xuat>;<tien de xuat>;<n thieu ton>;<n da xt>;<n khoa>;<ton 152 tien cuoi>
  DX;t;MaSo;MaCT;so CT;ngay;ma VT;ten VT;dvt;SL;tien;ton truoc;trang thai(XUAT|THIEU_TON);MaDT;so hieu DT;ghi chu;TK NVL;ten TK NVL;phan loai VT (GD359c)
  VT;t;ma VT;ten;nhap;de xuat;ton sau"""
import datetime as _dt
import io
import os
import re
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
TEP = "xuat_thang_nvl"
XT_ID = 900000000
SAI = 1e-6


def _f(x):
    try:
        return float(x or 0)
    except (TypeError, ValueError):
        return 0.0


def _i(x):
    return int(_f(x))


def _s(x):
    return str(x if x is not None else "").replace(";", ",").replace("\r", " ").replace("\n", " ").strip()


def _dd(v):
    return "{:,.0f}".format(round(_f(v))).replace(",", ".")


def _sl(v):
    v = _f(v)
    return ("%.3f" % v).rstrip("0").rstrip(".")


def doc(duong):
    import jet_doc
    m = jet_doc.Mdb(duong)
    try:
        bang = {b.lower(): b for b in m.bang()}

        def tb(t, n=None):
            k = bang.get(t.lower())
            return m.doc(k, n) if k else []
        lic = (tb("License", 1) or [{}])[0]
        d = {"duong": duong, "lic": lic, "nam": _i(lic.get("NamTC")) or _dt.date.today().year, "dau_ky": _i(lic.get("Thang")) or 1,
             "tk": {r["MaSo"]: str(r.get("SoHieu") or "").strip() for r in tb("HeThongTK")},
             "tk_con": {r["MaSo"] for r in tb("HeThongTK") if r.get("TKCon")},
             "vt": {r["MaSo"]: r for r in tb("Vattu")},
             "pl": {r.get("MaSo"): r for r in tb("PhanLoaiVattu")},          # GD359c: loc theo phan loai vat tu
             "tk_ten": {r["MaSo"]: (r.get("Ten") or r.get("TenTK") or r.get("TenTaiKhoan") or "") for r in tb("HeThongTK")}, "ton": tb("TonKho"), "tp": tb("TP154"),
             "ts": {str(r.get("Khoa") or ""): str(r.get("GiaTri") or "") for r in tb("HDDT_ThamSo")}}
        d["ct"] = [{k: r.get(k) for k in ("MaSo", "MaCT", "MaLoai", "ThangCT", "SoHieu", "NgayCT", "MaTKNo", "MaTKCo", "SoPS", "SoPS2No", "SoPS2Co",
                                          "MaVattu", "MaKho", "CT_ID", "MaTP")} for r in tb("ChungTu")]
        if not 1 <= d["dau_ky"] <= 12:
            d["dau_ky"] = 1
        return d
    finally:
        try:
            m.dong()
        except Exception:
            pass


def _u(d, s):
    try:
        import no_kho_doi as N
        return N._u(d, s)
    except Exception:
        return str(s or "")


def thang_lich(d, t):
    th = (d["dau_ky"] + t - 2) % 12 + 1
    return th, d["nam"] + (1 if th < d["dau_ky"] else 0)


def tk_mac_dinh(d):
    """TK No cua lan xuat thang gan nhat trong so; khong co -> 1541 / 154."""
    xt = [r for r in d["ct"] if _i(r.get("CT_ID")) > XT_ID and _i(r.get("MaLoai")) == 2]
    if xt:
        r = max(xt, key=lambda x: (_i(x.get("ThangCT")), _i(x.get("MaSo"))))
        sh = d["tk"].get(r.get("MaTKNo"), "")
        if sh:
            return sh
    co = set(d["tk"].values())
    return "1541" if "1541" in co else "154"


def doi_tuong(d, tk, t):
    """TK 154x -> doi tuong TP154 'T<thang lich>' (cung TK) neu co -> (MaSo, SoHieu); khac -> (0, '')."""
    if not tk.startswith("154"):
        return 0, ""
    th, _ = thang_lich(d, t)
    ma_tk = {s: m for m, s in d["tk"].items()}.get(tk)
    for r in d["tp"]:
        if str(r.get("SoHieu") or "").strip().upper() == "T%d" % th and (not ma_tk or _i(r.get("MaTK")) in (0, ma_tk)):
            return _i(r.get("MaSo")), str(r.get("SoHieu")).strip()
    return 0, ""


def khoa(d, t):
    return _i(d["lic"].get("Lock%d" % t)) % 10 == 1


def phan_tich(d, tu=1, den=12, tk=None, bo=None):
    tk = tk or d["ts"].get("XT357_TK") or tk_mac_dinh(d)
    bo = {x.strip().upper() for x in (bo if bo is not None else re.split(r"[,;\s]+", d["ts"].get("XT357_Bo", ""))) if x.strip()}
    sh = d["tk"]
    da_xt = {_i(r.get("CT_ID")) - XT_ID for r in d["ct"] if _i(r.get("CT_ID")) > XT_ID}
    t_max = max([_i(r.get("ThangCT")) for r in d["ct"]] + [den])
    ton = {}
    for r in d["ton"]:
        k = (_i(r.get("MaSoKho")), _i(r.get("MaTaiKhoan")), _i(r.get("MaVatTu")))
        ton[k] = [_f(r.get("Luong_%d" % t)) for t in range(0, 13)] if "Luong_0" in r else [0.0] + [_f(r.get("Luong_%d" % t)) for t in range(1, 13)]
    giam = defaultdict(lambda: [0.0] * 14)                 # so luong de xuat xuat them, cong don tu thang t tro di
    dong, vt_tong = [], defaultdict(lambda: [0.0, 0.0])
    n_da = n_khoa = 0
    nhap = [r for r in d["ct"] if _i(r.get("MaLoai")) == 1 and sh.get(r.get("MaTKNo"), "").startswith("152") and _i(r.get("MaVattu"))
            and _f(r.get("SoPS2No")) > SAI and tu <= _i(r.get("ThangCT")) <= den]
    nhap.sort(key=lambda r: (_i(r.get("ThangCT")), r.get("NgayCT") or _dt.datetime(1900, 1, 1), _i(r.get("MaSo"))))
    for r in nhap:
        t = _i(r.get("ThangCT"))
        if _i(r.get("MaSo")) in da_xt:
            n_da += 1
            continue
        if khoa(d, t):
            n_khoa += 1
            continue
        v = d["vt"].get(r.get("MaVattu")) or {}
        ma_vt = str(v.get("SoHieu") or r.get("MaVattu")).strip()
        if ma_vt.upper() in bo:
            continue
        k = (_i(r.get("MaKho")), _i(r.get("MaTKNo")), _i(r.get("MaVattu")))
        q = _f(r.get("SoPS2No"))
        lu = ton.get(k)
        if lu is None:
            co = 0.0
        else:
            co = min(lu[x] - giam[k][x] for x in range(t, min(t_max, 12) + 1))
        tt = "XUAT" if q <= co + 1e-6 else "THIEU_TON"
        dt_ma, dt_sh = doi_tuong(d, tk, t)
        if tt == "XUAT":
            for x in range(t, 13):
                giam[k][x] += q
            vt_tong[(t, ma_vt)][1] += q
        vt_tong[(t, ma_vt)][0] += q
        ng = r.get("NgayCT")
        pl = (d.get("pl") or {}).get(v.get("MaPhanLoai")) or {}
        pl_ten = (str(pl.get("SoHieu") or "").strip() + " - " + _u(d, pl.get("TenPhanLoai"))).strip(" -") if pl else ""
        tk_nvl = sh.get(r.get("MaTKNo"), "")
        dong.append({"tk_nvl": tk_nvl, "tk_nvl_ten": _u(d, (d.get("tk_ten") or {}).get(r.get("MaTKNo"))), "pl": pl_ten, "t": t, "ms": _i(r.get("MaSo")), "mact": _i(r.get("MaCT")), "so": _u(d, r.get("SoHieu")), "ngay": ng.strftime("%d/%m/%Y") if ng else "",
                     "ma_vt": ma_vt, "ten": _u(d, v.get("TenVattu")), "dvt": _u(d, v.get("DonVi")), "sl": q, "tien": _f(r.get("SoPS")), "ton": max(co, 0.0), "tt": tt,
                     "dt": dt_ma, "dt_sh": dt_sh,
                     "ghi": "" if tt == "XUAT" else "Tồn hiện tại %s %s < số nhập %s (đã xuất tay / theo định mức) - không xuất thẳng để kho không âm" % (_sl(max(co, 0)), _u(d, v.get("DonVi")), _sl(q))})
    xuat = [x for x in dong if x["tt"] == "XUAT"]
    return {"tk": tk, "tu": tu, "den": den, "dong": dong, "vt": vt_tong, "so": os.path.basename(d["duong"]),
            "n": len(xuat), "tien": sum(x["tien"] for x in xuat), "n_thieu": len(dong) - len(xuat), "n_da": n_da, "n_khoa": n_khoa,
            "ton_truoc": sum(_f(r.get("Tien_%d" % min(t_max, 12))) for r in d["ton"] if sh.get(r.get("MaTaiKhoan"), "").startswith("152"))}


def ghi(kq, thu_muc):
    os.makedirs(thu_muc, exist_ok=True)
    L = ["TONG;%s;%d;%d;%s;%d;%s;%d;%d;%d;%s" % (_s(kq["so"]), kq["tu"], kq["den"], kq["tk"], kq["n"], _dd(kq["tien"]), kq["n_thieu"], kq["n_da"], kq["n_khoa"], _dd(kq["ton_truoc"]))]
    for x in kq["dong"]:
        L.append("DX;%d;%d;%d;%s;%s;%s;%s;%s;%s;%s;%s;%s;%d;%s;%s;%s;%s;%s" % (x["t"], x["ms"], x["mact"], _s(x["so"])[:30], x["ngay"], _s(x["ma_vt"])[:30], _s(x["ten"])[:80],
                                                                  _s(x["dvt"])[:15], _sl(x["sl"]), _dd(x["tien"]), _sl(x["ton"]), x["tt"], x["dt"], _s(x["dt_sh"]), _s(x["ghi"])[:200],
                                                                  _s(x.get("tk_nvl")), _s(x.get("tk_nvl_ten"))[:60], _s(x.get("pl"))[:60]))          # GD359c: 16 TK NVL, 17 ten TK, 18 phan loai VT
    for (t, ma), (nh, xu) in sorted(kq["vt"].items()):
        L.append("VT;%d;%s;%s;%s" % (t, _s(ma), _sl(nh), _sl(xu)))
    p = os.path.join(thu_muc, TEP + ".txt")
    with io.open(p, "w", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")
    return p


def chay(duong, tu=1, den=12, tk=None, thu_muc=None):
    d = doc(duong)
    kq = phan_tich(d, tu, den, tk)
    return kq, ghi(kq, thu_muc or os.path.join(HERE, "ket-qua"))


def main(argv):
    t = {}
    for a in argv[1:]:
        if a.startswith("/") and ":" in a:
            k, v = a[1:].split(":", 1)
            t[k.lower()] = v.strip('"')
    if not t.get("so"):
        print('python xuat_thang_nvl.py /so:"<so.MDB>" [/tu:1] [/den:12] [/tk:1541] [/ra:<thu muc>]')
        return 1
    kq, p = chay(t["so"], int(t.get("tu") or 1), int(t.get("den") or 12), t.get("tk") or None, t.get("ra"))
    print("TK No %s: de xuat %d dong %s d, thieu ton %d, da xuat thang %d, thang khoa %d -> %s" % (kq["tk"], kq["n"], _dd(kq["tien"]), kq["n_thieu"], kq["n_da"], kq["n_khoa"], p))
    return 0


if __name__ == "__main__":
    import sys
    sys.exit(main(sys.argv))
