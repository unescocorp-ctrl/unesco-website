# -*- coding: utf-8 -*-
"""GD66 - KIEM TRA TRUOC KHOA SO (TT133) va UOC TINH THUE TNDN NAM - chi DOC so, khong ghi so.

VB6 (ModHDDTHTKK: HDDT_KS_Excel) lay so lieu TONG HOP bang SQL (phat sinh theo TK la + thang, cong no theo doi tuong,
tien mat / tien gui theo ngay, hoa don mua vao tu 5 trieu...) ghi JSON UTF-8, goi tool_htkk_unesco.py
/kiemkhoaso:<json> hoac /uoctndn:<json> /ra:<xlsx>. Tep nay tinh + lap Excel (cung bo ghi xlsx voi 01/GTGT).

Muc do: LOI (do - nen sua truoc khi khoa so), CANH_BAO (vang - xem lai), DAT (xanh), THONG_TIN.
Thang: ChungTu.ThangCT la THANG DUONG LICH ghi tren chung tu (cach UNESCO cong so) -> doi sang thu tu trong nam tai
chinh theo thang_dau_ky (CThangDB).
"""
import json
import os
import re
from collections import defaultdict

LOI, CANH_BAO, DAT, THONG_TIN = "LOI", "CANH_BAO", "DAT", "THONG_TIN"
TEN_MUC = {LOI: "LỖI", CANH_BAO: "CẢNH BÁO", DAT: "ĐẠT", THONG_TIN: "THÔNG TIN"}
TKCN_KH, TKCN_PT = 3500, 3310          # TK_ID cong no phai thu khach hang (131) / phai tra nguoi ban (331) - SAS.bas
MOC_5_TRIEU = 5000000.0
# GD347 (F10): dung sai co ten, co ly do (truoc day 1 / 1000 rai rac trong ma)
DUNG_SAI_DONG = 1.0         # 1 dong: sai so lam tron VND khi cong nhieu dong (so ghi so nguyen dong)
DUNG_SAI_THUE = 1000.0      # 1.000 dong: thue 133 / 3331 so voi hoa don - hoa don lam tron tung dong, to khai lam tron nghin


def _so(x):
    """GD347 (F10): tien -> float da lam tron 2 chu so, doc chuoi qua Decimal (khong cong don sai so nhi phan cua chuoi '0.1').
    VND nguyen dong < 2^53 bieu dien chinh xac bang float; moi phep so sanh dung dung sai co ten o tren."""
    if x is None or x == "":
        return 0.0
    if isinstance(x, bool):
        return float(x)
    if isinstance(x, (int, float)):
        return round(float(x), 2)
    try:
        from decimal import Decimal, InvalidOperation
        try:
            return round(float(Decimal(str(x).replace(",", "").strip())), 2)
        except (InvalidOperation, ValueError):
            return 0.0
    except ImportError:
        try:
            return round(float(str(x).replace(",", "")), 2)
        except ValueError:
            return 0.0


def _dd(x):
    return "{:,.0f}".format(x).replace(",", ".")


def doc_thong_tu(dl, co_641=False):
    """GD179 - Thong tu cua bo so: 133 hoac 99. dl["thong_tu"] (VB6: TT130_CheDo, nguoi dung da chon) co thi theo do;
    thieu thi doan theo he thong tai khoan (co TK 641 = so TT99)."""
    try:
        v = int(_so((dl or {}).get("thong_tu")))
    except (TypeError, ValueError):
        v = 0
    if v in (99, 133):
        return v
    return 99 if co_641 else 133


def _khong_dau(s):
    import unicodedata
    s = unicodedata.normalize("NFD", str(s or "").replace("đ", "d").replace("Đ", "D"))
    return "".join(c for c in s if unicodedata.category(c) != "Mn").lower()


def thang_tc(thang_ct, dau_ky):
    """thang duong lich (1..12) -> thu tu thang trong nam tai chinh (CThangDB)."""
    t = int(_so(thang_ct))
    if t <= 0:
        return 0
    if t > 12:
        return 13
    return t - dau_ky + 1 if t >= dau_ky else 13 - dau_ky + t


class SoLieu(object):
    def __init__(self, dl):
        self.dl = dl
        self.dau_ky = int(_so(dl.get("thang_dau_ky")) or 1)
        th = dl.get("thang") or [1, 12]
        self.t1, self.t2 = int(_so(th[0])), int(_so(th[1]))
        self.tk = {}
        for r in dl.get("tk") or []:
            ma = int(_so(r[0]))
            self.tk[ma] = {"sh": str(r[1] or "").strip(), "con": int(_so(r[2])), "cha": int(_so(r[3])), "ten": str(r[4] or ""),
                           "dn0": _so(r[5]), "dc0": _so(r[6]), "id": int(_so(r[7])) if len(r) > 7 else 0}
        self.la = [m for m, t in self.tk.items() if t["con"] == 0]
        # GD179: Thong tu cua bo so (VB6 gui "thong_tu" = TT130_CheDo) va he thong TK thuc te (641 = so TT99)
        self.co_641 = any(self.tk[m]["sh"].startswith("641") for m in self.la)
        self.tt = doc_thong_tu(dl, self.co_641)
        self.cp99 = self.co_641          # TK chi phi theo KIEU TT99 (641 ban hang, 642 quan ly) hay TT133 (6421, 6422): theo he thong TK thuc te
        # phat sinh theo TK la: truoc ky / trong ky / sau ky ; tach phan chung tu ket chuyen (co dong 911)
        self.ps = defaultdict(lambda: {"no_t": 0.0, "co_t": 0.0, "no": 0.0, "co": 0.0, "no_kc": 0.0, "co_kc": 0.0,
                                       "thang": defaultdict(lambda: [0.0, 0.0, 0.0, 0.0])})
        for r in dl.get("ps") or []:
            ma, t = int(_so(r[0])), thang_tc(r[1], self.dau_ky)
            no, co, nk, ck = _so(r[2]), _so(r[3]), _so(r[4]), _so(r[5])
            p = self.ps[ma]
            x = p["thang"][t]
            x[0] += no
            x[1] += co
            x[2] += nk
            x[3] += ck
            if t < self.t1:
                p["no_t"] += no + nk
                p["co_t"] += co + ck
            elif t <= self.t2:
                p["no"] += no
                p["co"] += co
                p["no_kc"] += nk
                p["co_kc"] += ck

    # ---- so du
    def du_dau(self, ma):
        """so du (No - Co) TK la tai dau ky kiem tra."""
        t = self.tk.get(ma) or {}
        p = self.ps.get(ma)
        return t.get("dn0", 0.0) - t.get("dc0", 0.0) + ((p["no_t"] - p["co_t"]) if p else 0.0)

    def ps_ky(self, ma, kc=True):
        p = self.ps.get(ma)
        if not p:
            return 0.0, 0.0
        return (p["no"] + (p["no_kc"] if kc else 0.0), p["co"] + (p["co_kc"] if kc else 0.0))

    def du_cuoi(self, ma):
        no, co = self.ps_ky(ma)
        return self.du_dau(ma) + no - co

    def la_theo(self, *tien_to):
        return [m for m in self.la if any(self.tk[m]["sh"].startswith(tt) for tt in tien_to)]

    def tong(self, tien_to, ham):
        return sum(ham(m) for m in self.la_theo(*tien_to))

    # ---- GD179: tai khoan theo Thong tu / he thong TK cua bo so
    def tk_bhtn(self):
        """TK bao hiem that nghiep: TT133 = 3385, TT99 = 3386 (3385 TT99 la phai tra ve co phan hoa; 3386 TT133 la ky quy).
        Uu tien ten TK trong he thong; khong co thi theo he thong TK (641 = so TT99)."""
        for sh in ("3385", "3386"):
            for m in self.la_theo(sh):
                if "that nghiep" in _khong_dau(self.tk[m]["ten"]):
                    return sh
        return "3386" if self.cp99 else "3385"

    def tk_bhxh(self):
        """cac TK phai tra bao hiem + kinh phi cong doan theo Thong tu: (3382, 3383, 3384, BHTN)."""
        return ("3382", "3383", "3384", self.tk_bhtn())

    def tk_cp_ban_hang(self):
        """tien to TK chi phi ban hang: TT99 = 641, TT133 = 6421."""
        return ("641",) if self.cp99 else ("6421",)

    def tk_cp_quan_ly(self):
        """tien to TK chi phi quan ly doanh nghiep: TT99 = 642 (6421-6428 la yeu to), TT133 = 6422 (khong co 6421 / 6422 thi gop ca 642)."""
        if self.cp99 or not (self.la_theo("6421") or self.la_theo("6422")):
            return ("642",)
        return ("6422",)

    def ps_tien_to(self, tien_to, kc=False):
        """(No, Co) trong ky cua cac TK la bat dau bang tien_to (mac dinh BO phan chung tu ket chuyen 911)."""
        n = c = 0.0
        for m in self.la_theo(tien_to):
            a, b = self.ps_ky(m, kc)
            n += a
            c += b
        return n, c

    def ten(self, ma):
        t = self.tk.get(ma) or {}
        return (t.get("sh", "?") + " " + t.get("ten", "")).strip()


def _kq(ma, ten, muc, ket_luan, cot=None, dong=None, can_cu=""):
    return {"ma": ma, "ten": ten, "muc": muc, "ket_luan": ket_luan, "cot": cot or [], "dong": dong or [], "can_cu": can_cu}


# ============================================================ cac bai kiem
def k_du_dau_nam(S):
    n = sum(S.tk[m]["dn0"] for m in S.la)
    c = sum(S.tk[m]["dc0"] for m in S.la)
    if abs(n - c) > DUNG_SAI_DONG:
        return _kq("K01", "Số dư đầu năm: tổng Dư Nợ = tổng Dư Có", LOI,
                   "Lệch %s (Dư Nợ %s - Dư Có %s): sửa số dư đầu năm trước khi khoá sổ." % (_dd(n - c), _dd(n), _dd(c)))
    return _kq("K01", "Số dư đầu năm: tổng Dư Nợ = tổng Dư Có", DAT, "Cân: %s" % _dd(n))


def k_ps_can(S):
    n = c = 0.0
    for m in S.la:
        a, b = S.ps_ky(m)
        n += a
        c += b
    if abs(n - c) > DUNG_SAI_DONG:
        return _kq("K02", "Phát sinh trong kỳ: tổng Nợ = tổng Có", LOI,
                   "Lệch %s (Nợ %s - Có %s): xem mục Chứng từ lệch Nợ / Có." % (_dd(n - c), _dd(n), _dd(c)))
    return _kq("K02", "Phát sinh trong kỳ: tổng Nợ = tổng Có", DAT, "Cân: %s" % _dd(n))


def k_ct_lech(S):
    if "ct_lech" not in S.dl:          # GD345 (F03): thieu du lieu -> khong duoc ket luan Dat
        return _kq("K03", "Chứng từ lệch Nợ / Có", CANH_BAO, "Không kiểm được: phần mềm chưa gửi danh sách chứng từ lệch (thiếu dữ liệu) - chạy lại Kiểm tra trước khoá sổ.")
    ds = S.dl.get("ct_lech") or []
    if ds:
        return _kq("K03", "Chứng từ lệch Nợ / Có", LOI, "%d chứng từ có tổng Nợ khác tổng Có - mở từng phiếu sửa lại." % len(ds),
                   ["Số chứng từ", "Ngày", "Tổng Nợ", "Tổng Có", "Chênh lệch"],
                   [[r[0], r[1], _so(r[2]), _so(r[3]), _so(r[2]) - _so(r[3])] for r in ds])
    return _kq("K03", "Chứng từ lệch Nợ / Có", DAT, "Không có chứng từ lệch.")


def k_ngoai_nam(S):
    ds = S.dl.get("ct_ngoai_nam") or []
    if not ds:
        return _kq("K04", "Chứng từ có ngày ngoài năm tài chính", DAT, "Không có.")
    co_tien = [r for r in ds if abs(_so(r[3])) > 0]
    return _kq("K04", "Chứng từ có ngày ngoài năm tài chính", CANH_BAO if co_tien else THONG_TIN,
               "%d chứng từ ngày ngoài năm tài chính (%d có số tiền) - UNESCO vẫn cộng theo tháng ghi trên phiếu; sửa ngày cho đúng."
               % (len(ds), len(co_tien)), ["Số chứng từ", "Ngày", "Tháng ghi sổ", "Số tiền"],
               [[r[0], r[1], int(_so(r[2])), _so(r[3])] for r in ds])


def k_tien_am(S):
    theo_ngay = defaultdict(lambda: defaultdict(float))
    for r in S.dl.get("ngay") or []:
        theo_ngay[int(_so(r[0]))][str(r[1])[:10]] += _so(r[2]) - _so(r[3])
    dong = []
    for m in S.la_theo("111", "112"):
        du = S.du_dau(m)
        am, ngay_dau, thap = False, "", du
        if du < -1:
            am, ngay_dau = True, "đầu kỳ"
        for ng in sorted(theo_ngay.get(m, {})):
            du += theo_ngay[m][ng]
            if du < thap:
                thap = du
            if du < -1 and not am:
                am, ngay_dau = True, "%s/%s/%s" % (ng[8:10], ng[5:7], ng[0:4])
        if am:
            dong.append([S.ten(m), ngay_dau, thap, S.du_cuoi(m)])
    if dong:
        return _kq("K05", "Tiền mặt, tiền gửi âm theo ngày (111, 112)", LOI,
                   "%d tài khoản có ngày số dư âm - thường do ghi chi trước thu, sai ngày hoặc thiếu phiếu thu / giấy báo có." % len(dong),
                   ["Tài khoản", "Ngày bắt đầu âm", "Số dư thấp nhất", "Số dư cuối kỳ"], dong)
    return _kq("K05", "Tiền mặt, tiền gửi âm theo ngày (111, 112)", DAT, "Không có ngày nào số dư âm.")


# (tien to, phai du ben, muc khi sai) - TT133
_BEN = (("111", "N", LOI), ("112", "N", LOI), ("141", "N", CANH_BAO), ("151", "N", LOI), ("152", "N", LOI), ("153", "N", LOI),
        ("154", "N", LOI), ("155", "N", LOI), ("156", "N", LOI), ("157", "N", LOI), ("211", "N", LOI), ("217", "N", LOI),
        ("241", "N", CANH_BAO), ("242", "N", CANH_BAO), ("214", "C", LOI), ("229", "C", LOI), ("133", "N", CANH_BAO),
        ("3331", "C", CANH_BAO), ("334", "C", CANH_BAO), ("411", "C", CANH_BAO))


def k_sai_ben(S):
    dong, muc = [], DAT
    for m in S.la:
        sh = S.tk[m]["sh"]
        quy = next((q for q in _BEN if sh.startswith(q[0])), None)
        if not quy:
            continue
        du = S.du_cuoi(m)
        if (quy[1] == "N" and du < -1) or (quy[1] == "C" and du > 1):
            dong.append([S.ten(m), "Có" if du < 0 else "Nợ", abs(du), "phải dư %s" % ("Nợ" if quy[1] == "N" else "Có"), TEN_MUC[quy[2]]])
            if quy[2] == LOI:
                muc = LOI
            elif muc == DAT:
                muc = CANH_BAO
    if dong:
        return _kq("K06", "Số dư sai bên cuối kỳ", muc, "%d tài khoản dư sai bên (tiền, hàng tồn kho, TSCĐ dư Có; hao mòn dư Nợ...)." % len(dong),
                   ["Tài khoản", "Đang dư", "Số tiền", "Quy định", "Mức"], dong)
    return _kq("K06", "Số dư sai bên cuối kỳ", DAT, "Các tài khoản tiền, hàng tồn kho, TSCĐ, hao mòn, thuế dư đúng bên.")


def k_chua_ket_chuyen(S):
    dong = []
    for m in S.la:
        sh = S.tk[m]["sh"]
        if sh[:1] in ("5", "6", "7", "8", "9"):
            du = S.du_cuoi(m)
            if abs(du) > 1:
                dong.append([S.ten(m), "Nợ" if du > 0 else "Có", abs(du)])
    if dong:
        return _kq("K07", "TK doanh thu, chi phí, 911 còn số dư (chưa kết chuyển)", CANH_BAO,
                   "%d tài khoản loại 5 - 9 còn số dư cuối kỳ: chạy kết chuyển (911 -> 4212) trước khi khoá sổ / lập báo cáo." % len(dong),
                   ["Tài khoản", "Dư", "Số tiền"], dong)
    return _kq("K07", "TK doanh thu, chi phí, 911 còn số dư (chưa kết chuyển)", DAT, "Loại 5 - 9 đã về 0.")


def _cong_no(S):
    """-> {maso_tk: {maso_kh: [dau, no_ky, co_ky]}} cho TK la cong no (TK_ID 3500 / 3310)."""
    la_cn = {m for m in S.la if S.tk[m]["id"] in (TKCN_KH, TKCN_PT)}
    if not la_cn:
        la_cn = set(S.la_theo("131", "331"))
    d = defaultdict(lambda: defaultdict(lambda: [0.0, 0.0, 0.0]))
    for r in S.dl.get("kh_dau") or []:
        m = int(_so(r[0]))
        if m in la_cn:
            d[m][int(_so(r[1]))][0] += _so(r[2]) - _so(r[3])
    for khoa, dau in (("kh_no", 1), ("kh_co", -1)):
        for r in S.dl.get(khoa) or []:
            m = int(_so(r[0]))
            if m not in la_cn:
                continue
            t = thang_tc(r[2], S.dau_ky)
            x = d[m][int(_so(r[1]))]
            if t < S.t1:
                x[0] += dau * _so(r[3])
            elif t <= S.t2:
                x[1 if dau > 0 else 2] += _so(r[3])
    return la_cn, d


def k_cong_no(S, dt):
    la_cn, d = _cong_no(S)
    lech, khong_dt = [], []
    for m in sorted(la_cn, key=lambda x: S.tk[x]["sh"]):
        ct = sum(v[0] + v[1] - v[2] for v in d[m].values())
        th = S.du_cuoi(m)
        if abs(ct - th) > 1:
            lech.append([S.ten(m), th, ct, th - ct])
        x = d[m].get(0)
        if x and (abs(x[1]) > 0 or abs(x[2]) > 0 or abs(x[0]) > 1):
            khong_dt.append([S.ten(m), x[0], x[1], x[2]])
    kq = []
    if lech:
        kq.append(_kq("K08", "Công nợ chi tiết theo đối tượng khớp sổ tổng hợp (131, 331)", CANH_BAO,
                      "%d tài khoản công nợ: tổng chi tiết đối tượng khác sổ tổng hợp - thường do dòng công nợ chưa chọn khách hàng / "
                      "nhà cung cấp hoặc số dư đầu năm chi tiết chưa khớp." % len(lech),
                      ["Tài khoản", "Sổ tổng hợp (Nợ - Có)", "Cộng chi tiết đối tượng", "Chênh lệch"], lech))
    else:
        kq.append(_kq("K08", "Công nợ chi tiết theo đối tượng khớp sổ tổng hợp (131, 331)", DAT, "Khớp."))
    if khong_dt:
        kq.append(_kq("K09", "Dòng công nợ không có đối tượng", CANH_BAO,
                      "%d tài khoản công nợ có phát sinh không chọn khách hàng / nhà cung cấp." % len(khong_dt),
                      ["Tài khoản", "Đầu kỳ (không đối tượng)", "Phát sinh Nợ", "Phát sinh Có"], khong_dt))
    # 131 du Co / 331 du No theo doi tuong (thong tin - trinh bay rieng tren B01)
    tt = []
    for m in la_cn:
        la_thu = S.tk[m]["id"] == TKCN_KH or S.tk[m]["sh"].startswith("131")
        for kh, v in d[m].items():
            du = v[0] + v[1] - v[2]
            if kh and ((la_thu and du < -1) or (not la_thu and du > 1)):
                x = dt.get(kh) or ["", "", ""]
                tt.append([S.tk[m]["sh"], x[0], x[1], "Có (khách trả trước)" if la_thu else "Nợ (trả trước người bán)", abs(du)])
    if tt:
        tt.sort(key=lambda r: -r[4])
        kq.append(_kq("K10", "131 dư Có / 331 dư Nợ theo đối tượng", THONG_TIN,
                      "%d đối tượng: trên B01-DNN trình bày ở chỉ tiêu Người mua trả tiền trước / Trả trước cho người bán." % len(tt),
                      ["TK", "Mã đối tượng", "Tên", "Dư", "Số tiền"], tt[:300]))
    return kq


def k_kho_am(S):
    ds = S.dl.get("kho") or []
    if ds:
        return _kq("K11", "Tồn kho âm cuối kỳ", LOI, "%d mã vật tư tồn âm (số lượng hoặc giá trị) - kiểm tra phiếu xuất trước nhập, sai mã, sai kho." % len(ds),
                   ["Mã vật tư", "Tên", "TK", "Số lượng", "Giá trị"], [[r[0], r[1], r[2], _so(r[3]), _so(r[4])] for r in ds])
    return _kq("K11", "Tồn kho âm cuối kỳ", DAT, "Không có mã tồn âm.")


def k_khau_hao(S):
    kq = []
    ts = S.tong(("211", "213", "217"), S.du_dau)
    _, co214 = S.ps_tien_to("214")
    if ts > 1 and co214 <= 0:
        kq.append(_kq("K12", "Trích khấu hao TSCĐ trong kỳ", CANH_BAO,
                      "Có TSCĐ (nguyên giá %s) nhưng kỳ này chưa có phát sinh Có 214 - chưa trích khấu hao?" % _dd(ts)))
    else:
        kq.append(_kq("K12", "Trích khấu hao TSCĐ trong kỳ", DAT, "Có trích khấu hao: Có 214 = %s." % _dd(co214) if ts > 1 else "Không có TSCĐ."))
    tt = S.tong(("242",), S.du_dau)
    _, co242 = S.ps_tien_to("242")
    if tt > 1 and co242 <= 0:
        kq.append(_kq("K13", "Phân bổ chi phí trả trước (242) trong kỳ", CANH_BAO,
                      "242 còn %s đầu kỳ nhưng kỳ này chưa phân bổ (chưa có phát sinh Có 242)." % _dd(tt)))
    else:
        kq.append(_kq("K13", "Phân bổ chi phí trả trước (242) trong kỳ", DAT,
                      ("Đã phân bổ: Có 242 = %s." % _dd(co242)) if tt > 1 else "Không có số dư 242."))
    return kq


def k_gia_von(S):
    kq = []
    _, dt = S.ps_tien_to("511")
    gv, _ = S.ps_tien_to("632")
    if dt > 0 and gv <= 0:
        kq.append(_kq("K14", "Giá vốn hàng bán", CANH_BAO, "Có doanh thu (Có 511 = %s) nhưng chưa có giá vốn (Nợ 632 = 0) - chưa tính giá vốn / xuất kho?" % _dd(dt)))
    else:
        kq.append(_kq("K14", "Giá vốn hàng bán", DAT, "Doanh thu %s - giá vốn %s." % (_dd(dt), _dd(gv))))
    n154, c154 = S.ps_tien_to("154")
    if n154 > 0 and c154 <= 0:
        kq.append(_kq("K15", "Giá thành (154)", CANH_BAO, "Nợ 154 = %s nhưng chưa kết chuyển giá thành (Có 154 = 0)." % _dd(n154)))
    return kq


def k_thue_gtgt(S):
    g = S.dl.get("gtgt") or {}
    kq = []
    n133 = sum(S.ps_ky(m, False)[0] for m in S.la_theo("133"))
    vao = _so(g.get("thue_vao"))
    muc = CANH_BAO if abs(n133 - vao) > DUNG_SAI_THUE else DAT
    kq.append(_kq("K16", "Thuế GTGT đầu vào: Nợ 133 khớp bảng kê hoá đơn mua vào [24]", muc,
                  "Nợ 133 trong kỳ %s - thuế trên hoá đơn mua vào %s - chênh %s%s." % (_dd(n133), _dd(vao), _dd(n133 - vao),
                  (": có bút toán 133 không gắn hoá đơn (hoặc hoá đơn thiếu dòng thuế)" if muc != DAT else ""))))
    la_ra = S.la_theo("33311") or S.la_theo("3331")
    c3331 = sum(S.ps_ky(m, False)[1] for m in la_ra)
    ra = _so(g.get("thue_ra"))
    muc = CANH_BAO if abs(c3331 - ra) > DUNG_SAI_THUE else DAT
    kq.append(_kq("K17", "Thuế GTGT đầu ra: Có 3331 khớp bảng kê hoá đơn bán ra [35]", muc,
                  "Có 3331 trong kỳ %s - thuế trên hoá đơn bán ra %s - chênh %s." % (_dd(c3331), _dd(ra), _dd(c3331 - ra))))
    return kq


def k_moc_5_trieu(S, dt):
    ds = S.dl.get("hd5") or []
    tra = defaultdict(float)
    ngay_tra = defaultdict(list)
    for r in S.dl.get("tra_tm") or []:
        tra[int(_so(r[0]))] += _so(r[2])
        ngay_tra[int(_so(r[0]))].append(str(r[1]))
    loi, cb, cho = [], [], []
    for r in ds:
        so_hd, ngay, kh, gt, thue, tk_co = r[0], r[1], int(_so(r[2])), _so(r[3]), _so(r[4]), str(r[5] or "")
        x = dt.get(kh) or ["", "", ""]
        dong = [so_hd, ngay, x[2], x[1], gt + thue, thue, tk_co]
        if tk_co.startswith("111"):
            loi.append(dong + ["Trả tiền mặt - thuế " + _dd(thue) + " KHÔNG được khấu trừ"])
        elif kh in tra:
            cb.append(dong + ["Nhà cung cấp được trả tiền mặt %s trong kỳ (ngày %s)" % (_dd(tra[kh]), ", ".join(sorted(set(ngay_tra[kh]))[:4]))])
        elif tk_co.startswith("331"):
            cho.append(dong + ["Chưa thanh toán - khi trả phải chuyển khoản"])
    cot = ["Số HĐ", "Ngày", "MST", "Nhà cung cấp", "Tổng thanh toán", "Thuế GTGT", "TK Có", "Nhận xét"]
    kq = []
    if loi:
        kq.append(_kq("K18", "Hoá đơn mua từ 5 triệu trả bằng tiền mặt", LOI,
                      "%d hoá đơn (thuế %s) trả tiền mặt: không đủ điều kiện khấu trừ thuế GTGT - giảm [25] hoặc bổ sung chứng từ thanh toán qua ngân hàng." %
                      (len(loi), _dd(sum(x[5] for x in loi))), cot, loi,
                      "Luật Thuế GTGT 48/2024/QH15 (hiệu lực 01/7/2025): hoá đơn mua hàng hoá, dịch vụ từ 5 triệu đồng trở lên (đã có thuế GTGT) phải có chứng từ thanh toán không dùng tiền mặt."))
    else:
        kq.append(_kq("K18", "Hoá đơn mua từ 5 triệu trả bằng tiền mặt", DAT, "Không có hoá đơn từ 5 triệu ghi Có 111."))
    if cb:
        kq.append(_kq("K19", "Hoá đơn từ 5 triệu - nhà cung cấp có khoản trả tiền mặt", CANH_BAO,
                      "%d hoá đơn ghi công nợ nhưng nhà cung cấp được trả tiền mặt trong kỳ - kiểm tra khoản trả đó thuộc hoá đơn nào." % len(cb), cot, cb))
    if cho:
        kq.append(_kq("K20", "Hoá đơn từ 5 triệu chưa thanh toán", THONG_TIN,
                      "%d hoá đơn (thuế %s) ghi công nợ 331: khi trả phải chuyển khoản mới được giữ khấu trừ." % (len(cho), _dd(sum(x[5] for x in cho))), cot, cho))
    return kq


# ============================================================ GD82: gia thanh (ket chuyen thanh pham, dien) - chi doc
#   So lieu: dl["gt"] (VB KS_GiaThanh): phieu ket chuyen theo MaCT, chung tu tu dong CT_ID 610000000 + MaCT, thanh pham
#   chua co dinh muc NVL, dien (TonKho theo thang + dong nhap). So khong san xuat (khong co phieu) -> bo qua ca nhom.
NGUONG_DIEN_TON = 0.005        # dien ton cuoi thang > 0,5% luong nhap trong thang (it nhat 1 kWh) -> canh bao


def _thang_nam(s):
    m = re.match(r"^\s*(\d{1,2})/(\d{1,2})/(\d{4})", str(s or ""))
    return (int(m.group(2)), int(m.group(3))) if m else (0, 0)


def _ngay_so(s):
    m = re.match(r"^\s*(\d{1,2})/(\d{1,2})/(\d{4})", str(s or ""))
    return (int(m.group(3)), int(m.group(2)), int(m.group(1))) if m else None


def _nam_cua(S, thang_dl):
    nam = int(_so(S.dl.get("nam_tc")))
    if not nam:
        return 0
    return nam if thang_dl >= S.dau_ky else nam + 1


def _trong_ky(S, thang_dl):
    t = thang_tc(thang_dl, S.dau_ky)
    return 0 < t and S.t1 <= t <= S.t2


def _thang_dl(S, t):
    """thu tu thang trong nam tai chinh -> thang duong lich."""
    return (t + S.dau_ky - 2) % 12 + 1


class GiaThanh(object):
    def __init__(self, S):
        g = S.dl.get("gt") or {}
        self.phieu = []
        for r in g.get("phieu") or []:
            if len(r) < 13:
                continue
            self.phieu.append({"mact": int(_so(r[0])), "sh": str(r[1] or ""), "thang": int(_so(r[2])), "n1": str(r[3] or ""),
                               "n2": str(r[4] or ""), "lo": int(_so(r[5])), "dong": int(_so(r[6])), "nvl": _so(r[7]),
                               "nc": _so(r[8]), "sxc": _so(r[9]), "nvl0": int(_so(r[10])), "sl": _so(r[11]), "xk": int(_so(r[12]))})
        self.ct = {}
        for r in g.get("ctkc") or []:
            if len(r) < 7:
                continue
            self.ct[int(_so(r[0]))] = {"dong": int(_so(r[1])), "t1": int(_so(r[2])), "t2": int(_so(r[3])), "n1": str(r[4] or ""),
                                       "n2": str(r[5] or ""), "tien": _so(r[6])}
        self.dm_thieu = [r for r in (g.get("dm_thieu") or []) if len(r) >= 4]
        self.dien = g.get("dien") or None
        self.gia_ht = int(_so(g.get("gia_ht")))
        self.ky = {}                   # thang duong lich -> (ngay dau, ngay cuoi) dang (nam, thang, ngay)
        for r in g.get("ky_thang") or []:
            if len(r) >= 3:
                a, b = _ngay_so(r[1]), _ngay_so(r[2])
                if a and b:
                    self.ky[int(_so(r[0]))] = (a, b)
        self.co = bool(self.phieu)

    def sh_phieu(self, mact):
        return next((p["sh"] for p in self.phieu if p["mact"] == mact), str(mact))

    def phieu_thang(self, thang_dl):
        return [p for p in self.phieu if p["thang"] == thang_dl]


def _ps_thang(S, tien_to, t):
    """(No, Co) thang t (thu tu nam tai chinh) cua TK la bat dau bang tien_to (chuoi hoac bo tien to) - CA phan ket chuyen."""
    n = c = 0.0
    for m in (S.la_theo(*tien_to) if isinstance(tien_to, (tuple, list)) else S.la_theo(tien_to)):
        x = S.ps[m]["thang"].get(t) if m in S.ps else None
        if x:
            n += x[0] + x[2]
            c += x[1] + x[3]
    return n, c


def k_gt_chua_chung_tu(S, G):
    ten = "Phiếu kết chuyển thành phẩm chưa có chứng từ hạch toán"
    if G.gia_ht > 0:
        return _kq("K21", ten, THONG_TIN, "Sổ tính theo giá hạch toán: phiếu kết chuyển không tự lập chứng từ nhập kho thành phẩm - không kiểm mục này.")
    dong = []
    for p in G.phieu:
        if not _trong_ky(S, p["thang"]):
            continue
        ct = G.ct.get(p["mact"])
        co_so = abs(p["nvl"]) + abs(p["nc"]) + abs(p["sxc"]) > 1
        if co_so and (not ct or abs(ct["tien"]) < 1):
            dong.append([p["sh"], p["thang"], p["n1"], p["dong"], p["nvl"] + p["nc"] + p["sxc"],
                         "Mở Kết chuyển thành phẩm tháng %d, chọn phiếu %s, bấm Ghi (lập lại phiếu xuất NVL + nhập kho thành phẩm)" % (p["thang"], p["sh"])])
    if dong:
        return _kq("K21", ten, LOI, "%d phiếu có trong sổ giá thành nhưng không có chứng từ xuất NVL / nhập kho thành phẩm: giá vốn, tồn kho 152 / 154 / 155 sai." % len(dong),
                   ["Phiếu", "Tháng", "Ngày phiếu", "Số dòng", "Giá thành trên phiếu", "Cách xử lý"], dong)
    return _kq("K21", ten, DAT, "Mọi phiếu kết chuyển trong kỳ đều có chứng từ hạch toán.")


def k_gt_ngay(S, G):
    ten = "Ngày phiếu kết chuyển thành phẩm ngoài tháng kết chuyển"
    dong = []
    for p in G.phieu:
        if not _trong_ky(S, p["thang"]):
            continue
        nam = _nam_cua(S, p["thang"])
        ky = G.ky.get(p["thang"])

        def lech(s):
            if ky:                     # ky that cua thang (co ngay bat dau thang rieng)
                d = _ngay_so(s)
                return bool(d) and not (ky[0] <= d <= ky[1])
            th, nm = _thang_nam(s)
            return bool(th) and (th != p["thang"] or bool(nam and nm != nam))
        sai = []
        for s in {p["n1"], p["n2"]}:
            if lech(s):
                sai.append(s)
        ct = G.ct.get(p["mact"])
        if ct:
            for s in {ct["n1"], ct["n2"]}:
                if lech(s) and s not in sai:
                    sai.append(s + " (chứng từ)")
        if sai:
            dong.append([p["sh"], p["thang"], ", ".join(sorted(sai)),
                         "Mở phiếu, bấm Ghi: phần mềm hỏi đổi sang ngày cuối tháng %d (Yes)" % p["thang"]])
    if dong:
        return _kq("K22", ten, LOI, "%d phiếu có ngày không thuộc tháng kết chuyển: giá xuất kho NVL tính theo tháng của ngày phiếu, "
                   "chứng từ xuất NVL / nhập kho thành phẩm mang ngày đó - giá thành và tồn kho các tháng lệch." % len(dong),
                   ["Phiếu", "Tháng kết chuyển", "Ngày ghi trên phiếu / chứng từ", "Cách xử lý"], dong)
    return _kq("K22", ten, DAT, "Ngày phiếu kết chuyển đều thuộc tháng kết chuyển.")


def k_gt_nc_sxc(S, G):
    # GD179: so TT133 hach toan nhan cong 1542 / san xuat chung 1543; so TT99 hach toan 622 / 627 (roi ket chuyen sang 154)
    tk_nc, tk_sx = (("622",), ("627",)) if S.cp99 else (("1542",), ("1543",))
    ma_nc, ma_sx = tk_nc[0], tk_sx[0]
    ten = "Kết chuyển không nhận chi phí nhân công (%s) / sản xuất chung (%s)" % (ma_nc, ma_sx)
    dong = []
    for t in range(S.t1, S.t2 + 1):
        th = _thang_dl(S, t)
        ds = G.phieu_thang(th)
        if not ds:
            continue
        nc = sum(p["nc"] for p in ds)
        sx = sum(p["sxc"] for p in ds)
        n2, _ = _ps_thang(S, tk_nc, t)
        n3, _ = _ps_thang(S, tk_sx, t)
        sh = ", ".join(p["sh"] for p in ds)
        if n2 > 1 and abs(nc) < 1:
            dong.append([th, sh, "%s nhân công" % ma_nc, n2, nc])
        if n3 > 1 and abs(sx) < 1:
            dong.append([th, sh, "%s sản xuất chung" % ma_sx, n3, sx])
    if dong:
        return _kq("K23", ten, LOI, "%d trường hợp tháng có phát sinh Nợ %s / %s nhưng phiếu kết chuyển không nhận chi phí (= 0): giá thành thiếu, "
                   "154 còn dư. Lỗi đã sửa ở GĐ82 (lưới từ 14 mã trở lên không phân bổ) - mở phiếu, bấm Ghi lại." % (len(dong), ma_nc, ma_sx),
                   ["Tháng", "Phiếu", "Khoản", "Phát sinh Nợ trong tháng", "Trên phiếu kết chuyển"], dong)
    return _kq("K23", ten, DAT, "Tháng có chi phí nhân công / sản xuất chung thì phiếu kết chuyển đều nhận chi phí.")


def k_gt_dinh_muc(S, G):
    ten = "Thành phẩm chưa có định mức NVL (giá thành NVL = 0)"
    dong = []
    for r in G.dm_thieu:
        th = int(_so(r[0]))
        if _trong_ky(S, th):
            dong.append([th, G.sh_phieu(int(_so(r[1]))), str(r[2] or ""), str(r[3] or "")])
    if dong:
        return _kq("K24", ten, CANH_BAO, "%d dòng thành phẩm trên phiếu kết chuyển chưa có định mức NVL hiệu lực: giá thành NVL = 0. "
                   "Lập định mức (Định mức tự động) rồi Ghi lại phiếu." % len(dong), ["Tháng", "Phiếu", "Mã thành phẩm", "Tên"], dong)
    return _kq("K24", ten, DAT, "Thành phẩm trên các phiếu kết chuyển trong kỳ đều có định mức NVL.")


def k_gt_154_du(S, G):
    ten = "Chi phí sản xuất dở dang (154) còn dư cuối kỳ"
    dong = []
    for m in sorted(S.la_theo("154"), key=lambda x: S.tk[x]["sh"]):
        du = S.du_cuoi(m)
        if abs(du) > 1:
            dong.append([S.ten(m), du])
    if dong:
        return _kq("K25", ten, CANH_BAO, "%d tài khoản 154 còn số dư: hợp lệ nếu là chi phí của lô / công trình chưa hoàn thành; nếu không, xem K23 "
                   "và Ghi lại phiếu kết chuyển của tháng cuối." % len(dong), ["Tài khoản", "Số dư cuối kỳ (Nợ - Có)"], dong)
    return _kq("K25", ten, DAT, "154 không còn số dư cuối kỳ.")


def k_gt_dien_ton(S, G):
    ten = "Điện tồn kho cuối tháng (điện không tồn kho: nhập bao nhiêu xuất bấy nhiêu)"
    d = G.dien
    if not d:
        return None
    dong = []
    for r in d.get("thang") or []:
        t = int(_so(r[0]))
        if not (S.t1 <= t <= S.t2):
            continue
        td, nh, xu, tc, tien = _so(r[1]), _so(r[2]), _so(r[3]), _so(r[4]), _so(r[5])
        nguong = max(1.0, NGUONG_DIEN_TON * nh)
        if abs(tc) > nguong:
            dong.append([_thang_dl(S, t), td, nh, xu, tc, tien,
                         "Tồn âm: xuất nhiều hơn điện có - kiểm tra hoá đơn điện (kWh) / giảm sản lượng" if tc < 0 else
                         "Ghi lại phiếu kết chuyển tháng này, chọn Yes ở câu hỏi Xuất hết điện"])
    if dong:
        return _kq("K26", ten, CANH_BAO, "%d tháng điện (mã %s) còn tồn cuối tháng: điện đã mua phải xuất hết cho sản xuất trong tháng." % (len(dong), d.get("sh") or ""),
                   ["Tháng", "Tồn đầu (kWh)", "Nhập (kWh)", "Xuất (kWh)", "Tồn cuối (kWh)", "Giá trị tồn", "Cách xử lý"], dong)
    return _kq("K26", ten, DAT, "Điện không còn tồn cuối các tháng trong kỳ.")


def k_gt_dien_gia(S, G):
    ten = "Nhập điện có đơn giá lạ (số kWh gõ sai?)"
    d = G.dien
    if not d:
        return None
    ds = [r for r in d.get("nhap") or [] if len(r) >= 5]
    gia = sorted(_so(r[4]) / _so(r[3]) for r in ds if _so(r[3]) > 0 and _so(r[4]) > 0)
    if len(gia) >= 3:
        k = len(gia) // 2
        tv = gia[k] if len(gia) % 2 else (gia[k - 1] + gia[k]) / 2.0
        lo, hi = tv / 3.0, tv * 3.0
    else:
        tv, lo, hi = 0.0, 300.0, 20000.0
    dong = []
    for r in ds:
        th = int(_so(r[0]))
        if not _trong_ky(S, th):
            continue
        L, tien = _so(r[3]), _so(r[4])
        g = tien / L if L > 0 else 0.0
        if L <= 0 or g < lo or g > hi:
            dong.append([th, str(r[1] or ""), str(r[2] or ""), L, tien, round(g), round(tien / tv) if tv > 0 else ""])
    if dong:
        return _kq("K27", ten, LOI, "%d dòng nhập điện có đơn giá ngoài khoảng %s - %s đ/kWh (trung vị %s đ/kWh): thường do gõ thiếu số 0 / nhầm dấu "
                   "thập phân ở số kWh - điện theo sổ sai, cân đối điện và giá thành sai. Sửa số kWh trên phiếu nhập." % (len(dong), _dd(lo), _dd(hi), _dd(tv)),
                   ["Tháng", "Số chứng từ", "Ngày", "kWh", "Số tiền", "Đơn giá (đ/kWh)", "kWh gợi ý (tiền / trung vị)"], dong)
    return _kq("K27", ten, DAT, "Đơn giá các dòng nhập điện trong kỳ bình thường%s." % ((" (trung vị %s đ/kWh)" % _dd(tv)) if tv else ""))


def k_gt_ban_chua_kc(S, G):
    ten = "Tháng có xuất bán thành phẩm nhưng chưa có phiếu kết chuyển"
    dong = []
    for t in range(S.t1, S.t2 + 1):
        th = _thang_dl(S, t)
        _, c155 = _ps_thang(S, "155", t)
        if c155 > 1 and not G.phieu_thang(th):
            dong.append([th, c155])
    if dong:
        return _kq("K28", ten, CANH_BAO, "%d tháng có xuất kho thành phẩm (Có 155) nhưng chưa lập phiếu kết chuyển thành phẩm: nhập kho thành phẩm, "
                   "giá vốn tháng đó chưa đúng." % len(dong), ["Tháng", "Có 155 trong tháng"], dong)
    return _kq("K28", ten, DAT, "Tháng nào có xuất bán thành phẩm cũng đã có phiếu kết chuyển.")


def kiem_gia_thanh(S):
    """GD82: K21 - K28. So khong co phieu ket chuyen thanh pham -> [] (khong hien nhom nay)."""
    G = GiaThanh(S)
    if not G.co:
        return []
    kq = [k_gt_chua_chung_tu(S, G), k_gt_ngay(S, G), k_gt_nc_sxc(S, G), k_gt_dinh_muc(S, G), k_gt_154_du(S, G),
          k_gt_dien_ton(S, G), k_gt_dien_gia(S, G), k_gt_ban_chua_kc(S, G)]
    return [k for k in kq if k]


def kiem_tra(dl):
    S = SoLieu(dl)
    dt = {int(_so(r[0])): [str(r[1] or ""), str(r[2] or ""), str(r[3] or "")] for r in dl.get("dt") or []}
    kq = [k_du_dau_nam(S), k_ps_can(S), k_ct_lech(S), k_ngoai_nam(S), k_tien_am(S), k_sai_ben(S), k_chua_ket_chuyen(S)]
    kq += k_cong_no(S, dt)
    kq.append(k_kho_am(S))
    kq += k_khau_hao(S)
    kq += k_gia_von(S)
    kq += k_thue_gtgt(S)
    kq += k_moc_5_trieu(S, dt)
    kq += kiem_gia_thanh(S)          # GD82
    try:
        import bat_bien_gt               # GD241: cong G6 gia thanh khop tu chung tu (K47 - K49)
        kq += bat_bien_gt.k_g6(S, GiaThanh(S), _kq, DAT, CANH_BAO, LOI, THONG_TIN)
    except Exception as e:
        kq.append(_kq("K47", "Giá thành khớp sổ (cổng G6)", CANH_BAO, "Lỗi khi chạy kiểm tra (chưa kiểm được) - Không kiểm được: %s" % e))
    try:
        import chinh_sach_so             # GD242: chinh sach bo so hop nhat (K50 TK hop le / ghep ma mo ho, K51 doi sau lan kiem truoc)
        kq += chinh_sach_so.k_chinh_sach(S, _kq, DAT, CANH_BAO, LOI, THONG_TIN)
    except Exception as e:
        kq.append(_kq("K50", "Chính sách bộ sổ", CANH_BAO, "Lỗi khi chạy kiểm tra (chưa kiểm được) - Không đọc được chính sách: %s" % e))
    try:
        import loai_hinh                 # GD243: loai hinh doanh nghiep la tham so (K52) + bat bien rieng (K53)
        kq += loai_hinh.k_loai_hinh(S, _kq, DAT, CANH_BAO, LOI, THONG_TIN)
    except Exception as e:
        kq.append(_kq("K52", "Loại hình doanh nghiệp", CANH_BAO, "Lỗi khi chạy kiểm tra (chưa kiểm được) - Không xác định được: %s" % e))
    kq += k_kiem_soat(S)             # GD151
    kq += k_rui_ro(S)                # GD153
    try:
        import day_du_hd                 # GD234: K39 du hoa don cong thue, K40 cap thay the / dieu chinh
        kq += day_du_hd.k_day_du(S, _kq, DAT, CANH_BAO, LOI, THONG_TIN)
        kq += day_du_hd.k_khop_cheo(S, _kq, DAT, CANH_BAO, LOI, THONG_TIN)     # GD239: K46 khop cheo HD CQT - so - to khai
    except Exception as e:
        kq.append(_kq("K39", "Hóa đơn trên cổng thuế đã có trong sổ", CANH_BAO, "Lỗi khi chạy kiểm tra (chưa kiểm được) - Không đối chiếu được: %s" % e))
    try:
        import to_khai_da_nop            # GD246: K54 to khai 01/GTGT da nop (Ho so thue) khop so + noi tiep ky truoc
        kq += to_khai_da_nop.k_to_khai_nop(S, _kq, DAT, CANH_BAO, LOI, THONG_TIN) or []
    except Exception as e:
        kq.append(_kq("K54", "Tờ khai 01/GTGT đã nộp", CANH_BAO, "Lỗi khi chạy kiểm tra (chưa kiểm được) - Không đọc được tờ khai đã nộp: %s" % e))
    try:
        import doi_chieu_3c              # GD235: K41 doi chieu ba chieu HD - so phu - chung tu, K42 dong so phu chua xu ly
        kq += doi_chieu_3c.k_ba_chieu(S, _kq, DAT, CANH_BAO, LOI, THONG_TIN)
    except Exception as e:
        kq.append(_kq("K41", "Đối chiếu hóa đơn - sổ phụ - chứng từ", CANH_BAO, "Lỗi khi chạy kiểm tra (chưa kiểm được) - Không đối chiếu được: %s" % e))
    try:
        import doi_chieu_cong_no         # GD236: K43 lap bien ban doi chieu cong no + nhac no (chi doc so, ghi tep)
        kq += doi_chieu_cong_no.k_lap_bien_ban(S, dt, _cong_no, _kq, DAT, CANH_BAO, LOI, THONG_TIN)
    except Exception as e:
        kq.append(_kq("K43", "Biên bản đối chiếu công nợ", CANH_BAO, "Lỗi khi chạy kiểm tra (chưa kiểm được) - Không lập được: %s" % e))
    try:
        import giai_trinh                # GD237: K44 giai trinh bien dong, K45 but toan cuoi ky de xuat
        kq += giai_trinh.k_giai_trinh(S, _kq, DAT, CANH_BAO, LOI, THONG_TIN)
        kq += giai_trinh.k_but_toan_de_xuat(S, _kq, DAT, CANH_BAO, LOI, THONG_TIN)
    except Exception as e:
        kq.append(_kq("K44", "Giải trình biến động / bút toán cuối kỳ", CANH_BAO, "Lỗi khi chạy kiểm tra (chưa kiểm được) - Không lập được: %s" % e))
    try:
        import tram_ky                   # GD233: K38 tram can chay lai
        kq += tram_ky.k_tram_ky(S, _kq, DAT, CANH_BAO, LOI, THONG_TIN)
    except Exception as e:
        kq.append(_kq("K38", "Trạm quy trình cần chạy lại", CANH_BAO, "Lỗi khi chạy kiểm tra (chưa kiểm được) - Không đọc được trạng thái trạm: %s" % e))
    try:
        import do_tu_dong                # GD249: K55 muc tu dong + nguong ghi tu dong de xuat
        kq += do_tu_dong.k_muc_tu_dong(S, _kq, DAT, CANH_BAO, LOI, THONG_TIN) or []
    except Exception as e:
        kq.append(_kq("K55", "Mức tự động của bộ sổ", CANH_BAO, "Lỗi khi chạy kiểm tra (chưa kiểm được) - Không đo được: %s" % e))
    try:
        import but_toan_dinh_ky          # GD254: K57 but toan dinh ky theo tham so (3387, trich truoc, du phong)
        kq += but_toan_dinh_ky.k_dinh_ky(S, _kq, DAT, CANH_BAO, LOI, THONG_TIN) or []
    except Exception as e:
        kq.append(_kq("K57", "Bút toán định kỳ theo tham số", CANH_BAO, "Lỗi khi chạy kiểm tra (chưa kiểm được) - Không đọc được tham số: %s" % e))
    try:
        import b03_chung_tu              # GD257: K58 B03 truc tiep tu chung tu, khop tien cuoi ky
        kq += b03_chung_tu.k_b03(S, _kq, DAT, CANH_BAO, LOI, THONG_TIN) or []
    except Exception as e:
        kq.append(_kq("K58", "B03 tính từ chứng từ", CANH_BAO, "Lỗi khi chạy kiểm tra (chưa kiểm được) - Không tính được: %s" % e))
    try:
        import cong_trinh                # GD258: K59 cong trinh - du toan, % hoan thanh, gia von theo nghiem thu
        kq += cong_trinh.k_cong_trinh(S, _kq, DAT, CANH_BAO, LOI, THONG_TIN) or []
    except Exception as e:
        kq.append(_kq("K59", "Công trình", CANH_BAO, "Lỗi khi chạy kiểm tra (chưa kiểm được) - Không đọc được danh mục công trình: %s" % e))
    try:
        import gia_thanh_phuong_an       # GD350: K60 phuong an gia thanh thang (NVL du / thieu, chi phi chua phan bo, lai lo TP) - xem truoc
        kq += gia_thanh_phuong_an.k_phuong_an(S, _kq, DAT, CANH_BAO, LOI, THONG_TIN) or []
    except Exception as e:
        kq.append(_kq("K60", "Phương án giá thành tháng", CANH_BAO, "Lỗi khi chạy kiểm tra (chưa kiểm được) - Không lập được phương án: %s" % e))
    try:
        import no_kho_doi                # GD353: K61 no phai thu kho doi - tuoi no, du phong, ho so trich lap / xoa no (TT48/2019) - xem truoc
        kq += no_kho_doi.k_no_kho_doi(S, _kq, DAT, CANH_BAO, LOI, THONG_TIN) or []
    except Exception as e:
        kq.append(_kq("K61", "Nợ phải thu khó đòi", CANH_BAO, "Lỗi khi chạy kiểm tra (chưa kiểm được) - Không lập được phân tích nợ khó đòi: %s" % e))
    try:
        import tra_loi_hang_doi          # GD250: ke toan tra loi trong tra_loi.txt -> ap dung, them dong mau cho ma con mo
        n_tl, tep_tl = tra_loi_hang_doi.ap_dung(kq, S, LOI, CANH_BAO, DAT, THONG_TIN)
        tra_loi_hang_doi.them_mau(kq, LOI, CANH_BAO, tep_tl)
        if n_tl:
            kq.append(_kq("K56", "Trả lời hàng đợi đã áp dụng", THONG_TIN, "%d trả lời trong %s đã áp dụng cho lần kiểm này." % (n_tl, tep_tl)))
    except Exception as e:
        kq.append(_kq("K56", "Trả lời hàng đợi", CANH_BAO, "Lỗi khi chạy kiểm tra (chưa kiểm được) - Không đọc được tra_loi.txt: %s" % e))
    return S, kq


# ============================================================ GD153: K36 - soat rui ro hoa don truoc ky khai (ModRuiRoHD.RR153_JsonNgan)
#   dl["rr"] = {"luc", "tu" (iso), "den" (iso), "loi", "cb", "tt"} lan soat gan nhat ; {} = chua soat lan nao.
def k_rui_ro(S):
    rr = S.dl.get("rr")
    if not isinstance(rr, dict):
        return []
    ten = "Soát rủi ro hoá đơn trước kỳ khai (5 triệu không tiền mặt, huỷ / thay thế, người bán, mã CQT)"
    menu = "Dữ liệu > Soát rủi ro hoá đơn trước kỳ khai..."
    if not rr:
        return [_kq("K36", ten, CANH_BAO, "Chưa soát lần nào - chạy %s trước khi lập 01/GTGT và khoá sổ." % menu)]
    den_kiem = _iso_cua(((S.dl.get("ky") or {}).get("den")) or "")
    den_rr = str(rr.get("den") or "")
    if den_kiem and den_rr and den_rr[:7] < den_kiem[:7]:
        return [_kq("K36", ten, CANH_BAO, "Lần soát gần nhất (%s) chỉ đến %s - chưa phủ tháng %s/%s; soát lại ở %s." % (
            rr.get("luc") or "", _ngay_vn_iso(den_rr), den_kiem[5:7], den_kiem[:4], menu))]
    loi, cb = int(_so(rr.get("loi"))), int(_so(rr.get("cb")))
    if loi:
        return [_kq("K36", ten, LOI, "Lần soát %s: còn %d LỖI (trả tiền mặt từ 5 triệu, hoá đơn huỷ / thay thế đã hạch toán, người bán ngừng hoạt động, "
                    "bán ra chưa hạch toán...) và %d dòng cần xem - xử lý hoặc đánh dấu ở %s." % (rr.get("luc") or "", loi, cb, menu))]
    if cb:
        return [_kq("K36", ten, CANH_BAO, "Lần soát %s: không có lỗi, còn %d dòng cần xem (%s)." % (rr.get("luc") or "", cb, menu))]
    return [_kq("K36", ten, DAT, "Lần soát %s: không có lỗi, không có dòng cần xem." % (rr.get("luc") or ""))]


def _ngay_vn_iso(iso):
    return "%s/%s/%s" % (iso[8:10], iso[5:7], iso[:4]) if len(str(iso)) == 10 else str(iso)


def _iso_cua(s):
    t = _ngay_so(s)
    return "%04d-%02d-%02d" % t if t else ""


# ============================================================ GD151: KS1-KS7 (Kiem soat cong no / vat tu - ModKiemSoatDL.KSD_JsonNgan)
#   dl["ks"] = {"lap_luc", "so": {NHOM_KH, NHOM_KH_PS, NHOM_KH_NGUOC, NHOM_VT, NHOM_VT_PS, NHOM_VT_NGUOC, TRAHO_131, TRAHO_331,
#   CN_131CO, CN_331NO, HAI_BEN, VT_AM, TK_DT, TK_KHO, TK_HANG, BO_QUA}, "dong": [{the, muc, van_de, ma, so_lieu, goi_y}]}.
#   Chi doc; sua tren man hinh Kiem soat (Gop ma..., Xu ly...: tra ho, bu tru, chot TK chuan).
TEN_THE_KS = ("Đối tượng trùng mã", "Công nợ lệch / trả hộ", "Vật tư trùng mã / âm kho", "TK không nhất quán", "Bất thường số liệu")   # GD157: + the 5


def _dong_ks(ks, the):
    return [[TEN_THE_KS[int(r.get("the") or 0)], r.get("muc") or "", r.get("van_de") or "", r.get("ma") or "", r.get("so_lieu") or "", r.get("goi_y") or ""]
            for r in (ks.get("dong") or []) if int(r.get("the") or 0) in the]


def k_kiem_soat(S):
    ks = S.dl.get("ks")
    if not isinstance(ks, dict):
        return []
    so = ks.get("so") or {}

    def n(k):
        return int(_so(so.get(k) or 0))
    cot = ["Thẻ", "Mức", "Vấn đề", "Mã liên quan", "Số liệu", "Gợi ý xử lý"]
    kq = []
    a, b, c = n("NHOM_KH"), n("NHOM_KH_PS"), n("NHOM_KH_NGUOC")
    if a:
        kq.append(_kq("K30", "KS1 - Khách hàng / NCC trùng mã (cùng MST, cùng tên, cùng số TK)", LOI if b else CANH_BAO,
                      "%d nhóm trùng mã, %d nhóm có phát sinh ở nhiều mã, %d nhóm số dư ngược bên. Công nợ chi tiết, đối chiếu công nợ và khớp sổ phụ sai cho tới khi gộp. "
                      "Màn hình Kiểm soát > Gộp mã... (có sao lưu, hoàn tác)." % (a, b, c), cot, _dong_ks(ks, (0,))))
    else:
        kq.append(_kq("K30", "KS1 - Khách hàng / NCC trùng mã", DAT, "Không có nhóm trùng mã."))
    th = n("TRAHO_131") + n("TRAHO_331")
    if th:
        kq.append(_kq("K31", "KS3 - Nghi trả hộ / ghi nhầm mã đối tượng", CANH_BAO,
                      "%d mã chỉ có tiền về (131) hoặc chỉ có chi trả (331) mà không có hoá đơn: tiền của người khác ghi vào mã này. "
                      "Màn hình Kiểm soát > Xử lý trả hộ... (sửa mã trên chứng từ hoặc lập chứng từ bù trừ)." % th, cot,
                      [r for r in _dong_ks(ks, (1,)) if "trả hộ" in (r[1] or "").lower()]))
    else:
        kq.append(_kq("K31", "KS3 - Nghi trả hộ / ghi nhầm mã đối tượng", DAT, "Không có mã chỉ có tiền về / chi trả."))
    hb = n("HAI_BEN")
    if hb:
        kq.append(_kq("K32", "KS4 - Đối tượng vừa phải thu (131) vừa phải trả (331) còn số dư", THONG_TIN,
                      "%d đối tượng: chỉ bù trừ khi có biên bản bù trừ công nợ (Màn hình Kiểm soát > Bù trừ 131/331...). Trên B01 trình bày riêng hai bên." % hb, cot,
                      [r for r in _dong_ks(ks, (1,)) if (r[1] or "").startswith("Vừa 131")]))
    v, vp, vn, am = n("NHOM_VT"), n("NHOM_VT_PS"), n("NHOM_VT_NGUOC"), n("VT_AM")
    if v:
        kq.append(_kq("K33", "KS5 - Vật tư hàng hoá trùng mã (cùng tên + ĐVT)", LOI if vn else CANH_BAO,
                      "%d nhóm trùng mã, %d nhóm có phát sinh ở nhiều mã, %d nhóm nhập mã này - xuất mã kia (mã âm kho + mã dương kho). Giá xuất, bảng kê tồn sai. "
                      "Màn hình Kiểm soát > Gộp mã... rồi Tính lại giá xuất kho. Âm kho cuối kỳ: %d mã (xem K11)." % (v, vp, vn, am), cot, _dong_ks(ks, (2,))))
    else:
        kq.append(_kq("K33", "KS5 - Vật tư hàng hoá trùng mã", DAT, "Không có nhóm trùng mã."))
    tk = n("TK_DT") + n("TK_KHO") + n("TK_HANG")
    if tk:
        kq.append(_kq("K34", "KS7 - Hạch toán không nhất quán tài khoản", CANH_BAO,
                      "%d trường hợp: cùng NCC + mặt hàng nhiều TK (%d), đối tượng ở nhiều nhóm TK công nợ (%d), vật tư ở nhiều TK kho (%d). "
                      "Màn hình Kiểm soát > Chốt TK chuẩn... (hoá đơn sau hạch toán đúng TK; chứng từ cũ sửa tay)." % (tk, n("TK_HANG"), n("TK_DT"), n("TK_KHO")),
                      cot, _dong_ks(ks, (3,))))
    else:
        kq.append(_kq("K34", "KS7 - Hạch toán không nhất quán tài khoản", DAT, "Không phát hiện."))
    # GD157: KS8 - KS12 bat thuong so lieu (the 5) - BAT_THUONG = -1 / khong co: chua chay trong 24 gio
    bt = so.get("BAT_THUONG")
    ten_bt = "KS8-KS12 - Bất thường số liệu (chi phí, giá, số chứng từ, ghi lùi ngày, lương, khấu hao)"
    if bt is None or n("BAT_THUONG") < 0:
        kq.append(_kq("K37", ten_bt, THONG_TIN, "Chưa chạy phát hiện bất thường cho sổ này trong 24 giờ: mở Kiểm soát > thẻ Bất thường số liệu "
                      "(chi phí tăng đột biến, giá mua lệch, bán dưới giá vốn, số chứng từ trùng / nhảy, hoá đơn trùng, ghi lùi vào tháng đã khoá, "
                      "lương dưới tối thiểu vùng, khấu hao bất thường)."))
    elif n("BAT_THUONG") > 0:
        kq.append(_kq("K37", ten_bt, CANH_BAO, "%d dòng bất thường chưa xử lý / chưa đánh dấu 'Không phải lỗi' (Kiểm soát > thẻ Bất thường số liệu)." % n("BAT_THUONG"),
                      cot, _dong_ks(ks, (4,))))
    else:
        kq.append(_kq("K37", ten_bt, DAT, "Không phát hiện bất thường (hoặc đã đánh dấu Không phải lỗi)."))
    bq = n("BO_QUA")
    if bq:
        kq.append(_kq("K35", "Kiểm soát - mục đã đánh dấu không phải lỗi", THONG_TIN, "%d mục đã được đánh dấu 'Không phải lỗi' trên màn hình Kiểm soát (không tính ở trên)." % bq))
    return kq


# ============================================================ GD152: DIEM SAN SANG KHOA SO (B6) - tom tat cho VB6 (ModSanSang)
#   Tep text ';' o AIHoaDon\ket-qua\sansang_khoa_so.txt (VB6 doc bang Line Input + Split, khong can JSON):
#     DIEM;72 | LOI;2 | CANH_BAO;5 | CHUA;3 | THANG;9 | MUC;CON_VIEC
#     L;K05;ten;ket luan      C;K08;ten;ket luan      B;9;buoc;menu   (buoc khoa so CHUA cua thang cuoi ky)
#   Diem = 100 - 15 x loi - 5 x canh bao - 8 x buoc chua lam (khong am). >= 90 SAN_SANG, 70..89 CON_VIEC, < 70 CHUA_NEN.
TRU_LOI, TRU_CANH_BAO, TRU_BUOC = 15, 5, 8


def diem_san_sang(kq, trinh_tu):
    """-> (diem, muc, n_loi, n_cb, buoc_chua[(thang, ten, menu)], thang_cuoi)"""
    n_loi = sum(1 for k in kq if k["muc"] == LOI)
    n_cb = sum(1 for k in kq if k["muc"] == CANH_BAO)
    buoc, thang_cuoi = [], 0
    if trinh_tu:
        thang_cuoi, dong = trinh_tu[-1]
        buoc = [(thang_cuoi, ten, menu) for ten, tt, so, menu in dong if tt == "CHƯA"]
    diem = 100 - TRU_LOI * n_loi - TRU_CANH_BAO * n_cb - TRU_BUOC * len(buoc)
    if diem < 0:
        diem = 0
    if n_loi == 0 and diem >= 90:
        muc = "SAN_SANG"
    elif diem >= 70 and n_loi == 0:
        muc = "CON_VIEC"
    else:
        muc = "CHUA_NEN"
    return diem, muc, n_loi, n_cb, buoc, thang_cuoi


def _sach_dong(s):
    return str(s or "").replace(";", ",").replace("\r", " ").replace("\n", " ")


def ghi_san_sang(kq, trinh_tu, ra=None):
    diem, muc, n_loi, n_cb, buoc, thang_cuoi = diem_san_sang(kq, trinh_tu)
    if ra is None:
        ra = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ket-qua", "sansang_khoa_so.txt")
    dong = ["DIEM;%d" % diem, "LOI;%d" % n_loi, "CANH_BAO;%d" % n_cb, "CHUA;%d" % len(buoc), "THANG;%d" % thang_cuoi, "MUC;%s" % muc]
    for k in kq:
        if k["muc"] == LOI:
            dong.append("L;%s;%s;%s" % (k["ma"], _sach_dong(k["ten"]), _sach_dong(k["ket_luan"])[:300]))
    for k in kq:
        if k["muc"] == CANH_BAO:
            dong.append("C;%s;%s;%s" % (k["ma"], _sach_dong(k["ten"]), _sach_dong(k["ket_luan"])[:300]))
    for thang, ten, menu in buoc:
        dong.append("B;%d;%s;%s" % (thang, _sach_dong(ten), _sach_dong(menu)))
    os.makedirs(os.path.dirname(os.path.abspath(ra)), exist_ok=True)
    with open(ra, "w", encoding="utf-8") as f:
        f.write("\n".join(dong) + "\n")
    return ra, diem


# ============================================================ GD70: trinh tu khoa so thang (chi doc)
BUOC_KHOA_SO = [
    ("Trích khấu hao TSCĐ", ("214",), "C", ("211", "213", "217"), "du", "Tài sản cố định > Tính khấu hao"),
    ("Phân bổ chi phí trả trước (242)", ("242",), "C", ("242",), "du", "Chi phí trả trước > Phân bổ"),
    ("Tính lương, trích BHXH (334, 338)", ("334",), "C", ("334",), "ps_nam", "Tiền lương > Bảng lương / Bảng lương AI"),
    ("Kết chuyển thuế GTGT khấu trừ (Nợ 3331 / Có 133) - theo tháng hoặc quý", ("133",), "C", ("133",), "quy_133", "Kết chuyển > KC thuế GTGT khấu trừ"),
    ("Tính giá vốn hàng bán (Nợ 632)", ("632",), "N", ("511",), "ps_thang_co", "Vật tư hàng hoá > Tính giá vốn"),
    ("Tính giá thành, nhập kho thành phẩm (Có 154)", ("154",), "C", ("154",), "ps_thang_no", "Giá thành > Lập phương án giá thành / Kết chuyển thành phẩm"),
    ("Kết chuyển doanh thu, chi phí sang 911", ("911",), "KC", ("511", "632", "641", "642"), "ps_thang", "Kết chuyển > Kết chuyển cuối kỳ"),
    ("Thuế TNDN tạm tính quý (Nợ 821 / Có 3334)", ("821",), "N", ("911",), "quy", "Kết chuyển > Thuế TNDN tạm tính (cuối quý)"),
]


# GD179: so TT99 co TK 521 (giam tru doanh thu): ket chuyen Co 521 / No 511 truoc khi ket chuyen sang 911 (ModTT99TK them lenh 521 -> 511)
BUOC_TT99_GIAM_TRU = ("Kết chuyển giảm trừ doanh thu (Nợ 511 / Có 521)", ("521",), "CK", ("521",), "ps_thang_no", "Kết chuyển > Kết chuyển cuối kỳ")


def buoc_khoa_so(S):
    """cac buoc trinh tu khoa so theo he thong TK: so TT99 them buoc ket chuyen 521 truoc buoc 911."""
    ds = list(BUOC_KHOA_SO)
    if S.cp99 and S.la_theo("521"):
        i = next((k for k, b in enumerate(ds) if b[1] == ("911",)), len(ds))
        ds.insert(i, BUOC_TT99_GIAM_TRU)
    return ds


def trinh_tu_khoa_so(S):
    """-> [(thang duong lich, [(buoc, trang thai, so tien, menu)])] cho tung thang cua ky kiem tra."""
    ra = []
    for t in range(S.t1, S.t2 + 1):
        thang_dl = (t + S.dau_ky - 2) % 12 + 1
        dong = []
        for ten, tk, ben, dk_tk, dk, menu in buoc_khoa_so(S):
            la = S.la_theo(*tk)
            x = [0.0, 0.0, 0.0, 0.0]
            for m in la:
                v = S.ps[m]["thang"].get(t) if m in S.ps else None
                if v:
                    for i in range(4):
                        x[i] += v[i]
            if ben == "N":
                so = x[0]
            elif ben == "C":
                so = x[1]
            elif ben == "CK":
                so = x[1] + x[3]            # Co ca phan chung tu ket chuyen 911 (521 co the ket chuyen thang sang 911)
            else:
                so = x[2] + x[3]
            can = False
            la_dk = S.la_theo(*dk_tk)
            if dk == "du":
                can = sum(S.du_dau(m) for m in la_dk) > 1 or any(S.ps[m]["thang"].get(t, [0, 0, 0, 0])[0] > 0 for m in la_dk if m in S.ps)
            elif dk == "ps_nam":
                can = any(sum(v[0] + v[1] for v in S.ps[m]["thang"].values()) > 0 for m in la_dk if m in S.ps)
            elif dk == "ps_thang_co":
                can = any(S.ps[m]["thang"].get(t, [0, 0, 0, 0])[1] > 0 for m in la_dk if m in S.ps)
            elif dk == "ps_thang_no":
                can = any(S.ps[m]["thang"].get(t, [0, 0, 0, 0])[0] > 0 for m in la_dk if m in S.ps)
            elif dk == "ps_thang":
                can = any(sum(S.ps[m]["thang"].get(t, [0, 0, 0, 0])[:2]) > 0 for m in la_dk if m in S.ps)
            elif dk == "quy":
                can = thang_dl in (3, 6, 9, 12)
            elif dk == "quy_133":
                # ke khai thang: co Co 133 trong thang; ke khai quy: xet o thang cuoi quy (cong 3 thang)
                if so <= 0.5 and thang_dl in (3, 6, 9, 12):
                    so = sum(S.ps[m]["thang"].get(tq, [0, 0, 0, 0])[1] for m in la if m in S.ps for tq in (t - 2, t - 1, t))
                can = so > 0.5 or thang_dl in (3, 6, 9, 12)
            if not can:
                tt = "Không cần"
            elif so > 0.5:
                tt = "Đã làm"
            else:
                tt = "CHƯA"
            dong.append((ten, tt, so, menu))
        ra.append((thang_dl, dong))
    return ra


def khoi_ky(dl, X, so_cot):
    """GD70: khoi ky ten cuoi bang (nguoi ky khai bao mot lan)."""
    import datetime
    nk = dl.get("nguoi_ky") or {}
    if not any(nk.get(k) for k in ("nguoi_lap", "ke_toan_truong", "giam_doc")):
        return []
    ngay = datetime.date.today()
    dong = [[], [(None, 0)] * (so_cot - 2) + [("Lập, ngày %d tháng %d năm %d" % (ngay.day, ngay.month, ngay.year), X.X_THUONG)]]
    vt = [("Người lập biểu", nk.get("nguoi_lap", "")), ("Kế toán trưởng", nk.get("ke_toan_truong", "")), ("Người đại diện theo pháp luật", nk.get("giam_doc", ""))]
    cot = [0, so_cot // 2, so_cot - 2] if so_cot >= 6 else [0, min(1, so_cot - 1), so_cot - 1]
    for k in range(3):
        d = [(None, 0)] * so_cot
        for i, (ten, gia) in enumerate(vt):
            d[cot[i]] = ((ten, "(Ký, họ tên)", gia or "")[k], X.X_DAM if k == 0 else (X.X_GHICHU if k == 1 else X.X_THUONG))
        dong.append(d)
    return dong


# ============================================================ can doi tai khoan
def can_doi(S):
    """-> [(sh, ten, cap, dau_no, dau_co, ps_no, ps_co, cuoi_no, cuoi_co)] - TK cha cong cac TK la (tach ben theo tung TK la)."""
    gom = defaultdict(lambda: [0.0] * 6)
    cha = {m: t["cha"] for m, t in S.tk.items()}
    for m in S.la:
        d, (n, c) = S.du_dau(m), S.ps_ky(m)
        cu = d + n - c
        v = [max(d, 0), max(-d, 0), n, c, max(cu, 0), max(-cu, 0)]
        x, buoc = m, 0
        while x and x in S.tk and buoc < 8:
            g = gom[x]
            for i in range(6):
                g[i] += v[i]
            x, buoc = cha.get(x), buoc + 1
    ra = []
    for m, t in sorted(S.tk.items(), key=lambda kv: kv[1]["sh"]):
        g = gom.get(m)
        if not g or not any(abs(v) > 0.5 for v in g):
            continue
        ra.append((t["sh"], t["ten"], 0 if not t["cha"] else 1, g[0], g[1], g[2], g[3], g[4], g[5]))
    return ra


# ============================================================ uoc tinh TNDN
def _thuan(S, tien_to, ben):
    n, c = S.ps_tien_to(tien_to)
    return (c - n) if ben == "C" else (n - c)


def thue_suat_goi_y(dt_nam_truoc):
    if dt_nam_truoc is None:
        return None, "Chưa có tổng doanh thu năm trước"
    if dt_nam_truoc <= 3e9:
        return 15, "Tổng doanh thu năm trước %s <= 3 tỷ: 15%%" % _dd(dt_nam_truoc)
    if dt_nam_truoc <= 50e9:
        return 17, "Tổng doanh thu năm trước %s trên 3 tỷ đến 50 tỷ: 17%%" % _dd(dt_nam_truoc)
    return 20, "Tổng doanh thu năm trước %s trên 50 tỷ: 20%%" % _dd(dt_nam_truoc)


def uoc_tndn(dl):
    """03-1A (so lieu theo Thong tu cua bo so, BO chung tu ket chuyen 911) -> [A1] -> thue suat goi y -> thue uoc tinh; theo quy.
    GD179: so TT99 - giam tru doanh thu ghi No 521, chi phi ban hang 641, chi phi quan ly 642 (so TT133: No 511, 6421, 6422)."""
    S = SoLieu(dl)
    c = {}
    n511, co511 = S.ps_tien_to("511")
    n521, c521 = S.ps_tien_to("521")
    c["04"] = co511
    c["06"] = n511 + (n521 - c521)              # giam tru doanh thu: TT133 ghi No 511; TT99 (va so co TK 521) ghi No 521
    c["10"] = _thuan(S, "515", "C")
    c["13"] = _thuan(S, "632", "N")
    c14 = sum(_thuan(S, tk, "N") for tk in S.tk_cp_ban_hang())
    c15 = sum(_thuan(S, tk, "N") for tk in S.tk_cp_quan_ly())
    c["14"], c["15"] = c14, c15
    c["12"] = c["13"] + c["14"] + c["15"]
    c["16"] = _thuan(S, "635", "N")
    c["18"] = c["04"] - c["06"] + c["10"] - c["12"] - c["16"]
    c["19"] = _thuan(S, "711", "C")
    c["20"] = _thuan(S, "811", "N")
    c["21"] = c["19"] - c["20"]
    c["22"] = c["18"] + c["21"]
    dtt = dl.get("dt_nam_truoc") or {}
    so_dt = _so(dtt.get("so")) if dtt.get("so") not in (None, "") else None
    ts, ly_do = thue_suat_goi_y(so_dt)
    thu_nhap = max(c["22"], 0.0)
    thue = round(thu_nhap * ts / 100.0) if ts else None
    n821, c821 = S.ps_tien_to("821")
    n3334, c3334 = S.ps_tien_to("3334")
    # theo quy trong nam tai chinh (thang 1-3, 4-6...)
    quy = []
    quy_ct = []
    for q in range(4):
        th = range(q * 3 + 1, q * 3 + 4)
        if th[0] > S.t2:
            break

        def thq(tt, ben):
            n = cc = 0.0
            for m in S.la_theo(tt):
                p = S.ps.get(m)
                if not p:
                    continue
                for t in th:
                    if t <= S.t2:
                        x = p["thang"].get(t)
                        if x:
                            n += x[0]
                            cc += x[1]
            return (cc - n) if ben == "C" else (n - cc)
        ln = (thq("511", "C") - thq("521", "N") + thq("515", "C") - thq("632", "N") - thq("641", "N") - thq("642", "N") - thq("635", "N")
              + thq("711", "C") - thq("811", "N"))          # GD179: 521 (giam tru DT) va 641 (chi phi ban hang) cua so TT99; so TT133 khong co -> 0
        quy.append((q + 1, ln, round(max(ln, 0) * ts / 100.0) if ts else None))
        # GD207: tam nop theo quy - so da nop trong quy (No 3334) de doi chieu
        nop = 0.0
        for m in S.la_theo("3334"):
            p = S.ps.get(m)
            if p:
                for t in th:
                    if t <= S.t2:
                        x = p["thang"].get(t)
                        if x:
                            nop += x[0]
        quy_ct.append({"quy": q + 1, "ln": ln, "nop": nop})
    # GD207 (anh Thang: "quy 3 la so cua quy 3, tu thang 7 - thang 9"): moi quy tinh rieng so cua quy do -
    #   thue tam nop quy = loi nhuan quy x thue suat (quy lo -> 0); con phai nop = tam nop - da nop trong quy; kyChon: quy nam trong ky chon
    for d in quy_ct:
        d["phai_nop"] = round(max(d["ln"], 0) * ts / 100.0) if ts else None
        d["con"] = (d["phai_nop"] - d["nop"]) if ts else None
        d["ky_chon"] = (d["quy"] - 1) * 3 + 3 >= S.t1
    return S, c, {"quy_ct": quy_ct, "tt": S.tt, "cp99": S.cp99, "dt_nam_truoc": so_dt, "nguon_dt": dtt.get("nguon") or "", "thue_suat": ts, "ly_do": ly_do,
                  "thu_nhap": thu_nhap, "thue": thue, "n821": n821 - c821, "n3334": n3334, "c3334": c3334, "quy": quy}


# ============================================================ Excel
def _xl():
    import tool_htkk_unesco as H
    return H


def lap_excel_khoa_so(dl, ra):
    H = _xl()
    S, kq = kiem_tra(dl)
    X = H
    cty = dl.get("cty") or {}
    ky = dl.get("ky") or {}
    n_loi = sum(1 for k in kq if k["muc"] == LOI)
    n_cb = sum(1 for k in kq if k["muc"] == CANH_BAO)
    T = [[("KIỂM TRA TRƯỚC KHOÁ SỔ (%s)" % ("TT99" if S.tt == 99 else "TT133"), X.X_TITLE)],
         [("Đơn vị: %s    MST: %s    Kỳ: %s - %s" % (cty.get("ten") or "", cty.get("mst") or "", ky.get("tu") or "", ky.get("den") or ""), X.X_THUONG)],
         [(("CÓ %d LỖI - CHƯA NÊN KHOÁ SỔ" % n_loi) if n_loi else ("KHÔNG CÓ LỖI%s" % ((" - %d cảnh báo cần xem" % n_cb) if n_cb else "")), X.X_DAM)], [],
         [("Mã", X.X_TIEUDE), ("Nội dung kiểm tra", X.X_TIEUDE), ("Kết quả", X.X_TIEUDE), ("Kết luận / cách xử lý", X.X_TIEUDE)]]
    kieu_muc = {LOI: X.X_DO, CANH_BAO: X.X_VANG, DAT: X.X_XANH, THONG_TIN: X.X_CHU}
    for k in kq:
        T.append([(k["ma"], X.X_CHU), (k["ten"], X.X_CHU), (TEN_MUC[k["muc"]], kieu_muc[k["muc"]]),
                  (k["ket_luan"] + ((" " + k["can_cu"]) if k["can_cu"] else "") + (("  (chi tiết: sheet %s)" % k["ma"]) if k["dong"] else ""), X.X_CHU)])
    T += khoi_ky(dl, X, 4)
    sheets = [("Tong hop", [7, 52, 12, 90], T, 5)]
    # GD70: trinh tu khoa so thang (buoc nao da lam / chua lam / khong can)
    Q = [[("TRÌNH TỰ KHOÁ SỔ THÁNG - bước nào đã làm (theo phát sinh trong sổ)", X.X_TITLE)],
         [("Đã làm = tháng đó có phát sinh của bước; CHƯA = có số liệu cần bước này nhưng chưa có phát sinh; Không cần = không có số liệu liên quan. "
           "Chạy đúng thứ tự từ trên xuống bằng menu ghi ở cột cuối, rồi kiểm tra lại.", X.X_THUONG)], [],
         [(c, X.X_TIEUDE) for c in ("Tháng", "Bước", "Trạng thái", "Số tiền trong tháng", "Chạy ở menu")]]
    tt_ks = trinh_tu_khoa_so(S)
    for thang_dl, dong in tt_ks:
        for ten, tt, so, menu in dong:
            Q.append([("Tháng %d" % thang_dl, X.X_CHU), (ten, X.X_CHU), (tt, X.X_DO if tt == "CHƯA" else (X.X_XANH if tt == "Đã làm" else X.X_CHU)),
                      (round(so), X.X_SO), (menu, X.X_CHU)])
    sheets.append(("Trinh tu khoa so", [10, 48, 12, 20, 56], Q, 4))
    for k in kq:
        if not k["dong"]:
            continue
        D = [[("%s - %s" % (k["ma"], k["ten"]), X.X_TITLE)], [(k["ket_luan"], X.X_THUONG)], [],
             [(c, X.X_TIEUDE) for c in k["cot"]]]
        for r in k["dong"]:
            D.append([(v, X.X_SO if isinstance(v, (int, float)) and not isinstance(v, bool) else X.X_CHU) for v in r])
        sheets.append((k["ma"], [max(12, min(60, max([len(str(c)) for c in k["cot"]] + [0]) + 4))] + [22] * (len(k["cot"]) - 1), D, 4))
    C = [[("BẢNG CÂN ĐỐI TÀI KHOẢN KỲ KIỂM TRA (tính từ chứng từ)", X.X_TITLE)], [],
         [(c, X.X_TIEUDE) for c in ("Số hiệu", "Tên tài khoản", "Đầu kỳ Nợ", "Đầu kỳ Có", "Phát sinh Nợ", "Phát sinh Có", "Cuối kỳ Nợ", "Cuối kỳ Có")]]
    tong = [0.0] * 6
    for sh, ten, cap, *v in can_doi(S):
        kieu, kso = (X.X_MUC, X.X_SOMUC) if cap == 0 else (X.X_CHU, X.X_SO)
        C.append([(sh, kieu), (ten, kieu)] + [(x, kso) for x in v])
        if cap == 0:
            tong = [a + b for a, b in zip(tong, v)]
    C.append([("", X.X_MUC), ("Cộng (TK cấp 1)", X.X_MUC)] + [(x, X.X_SOMUC) for x in tong])
    sheets.append(("Can doi TK", [10, 46, 18, 18, 18, 18, 18, 18], C, 3))
    os.makedirs(os.path.dirname(os.path.abspath(ra)), exist_ok=True)
    H.viet_xlsx_o(ra, sheets)
    try:
        ghi_san_sang(kq, tt_ks)          # GD152: tom tat diem san sang cho VB6 (ModSanSang)
    except Exception:
        pass
    try:
        import but_toan_de_xuat          # GD263: gom but toan de xuat (K45 / K57 / K59) cho VB lap sau khi nguoi duyet
        tm263 = [os.path.join(os.path.dirname(os.path.abspath(__file__)), "ket-qua")]
        if dl.get("duong_so"):
            import chinh_sach_so
            tm263.append(chinh_sach_so._thu_muc_ra(dl["duong_so"])[0])
        but_toan_de_xuat.ghi(kq, S, tm263)
    except Exception:
        pass
    try:
        import huong_dan_tep             # GD259: 00_DOC_TOI.txt trong thu muc cua so - giai thich tung tep ke toan tu ghi
        huong_dan_tep.ghi(dl)
    except Exception:
        pass
    try:
        import hoi_quy                   # GD248: luu so lieu + ket qua lan nay (bo so chuan, hoi quy)
        hoi_quy.luu_lan_cuoi(dl, kq)
    except Exception:
        pass
    try:
        import tram_ky
        import datetime as _dt233
        tram_ky.ghi_kiem(kq, S, _dt233.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), LOI, CANH_BAO)     # GD233
    except Exception:
        pass
    try:
        import tram_ky
        import hang_doi_viec             # GD238: hang doi viec can lam (ket-qua\\hang_doi_viec.txt / .html)
        ds_viec = hang_doi_viec.lap(kq, tt_ks, LOI, CANH_BAO, tram_ky.tram_cua)
        try:                             # GD348b: viec ERP giao (lenh sua[] trong hop thu tram) vao cung hang doi
            import erp_viec
            ds_viec = list(ds_viec) + erp_viec.lap(dl.get("duong_so"))
            erp_viec.ghi_bo_qua(dl.get("duong_so"), os.path.join(os.path.dirname(os.path.abspath(__file__)), "ket-qua"))
        except Exception:
            pass
        try:
            import tra_loi_hang_doi
            tep_tl250 = tra_loi_hang_doi.tep_tra_loi(S)
        except Exception:
            tep_tl250 = ""
        hang_doi_viec.ghi(ds_viec, os.path.join(os.path.dirname(os.path.abspath(__file__)), "ket-qua"), lambda t: tram_ky.TEN_TRAM.get(t, ""), tep_tl250, ky)
        if dl.get("duong_so"):           # GD244: ban sao theo bo so + tom tat cho Bang dieu hanh
            import chinh_sach_so
            import datetime as _dt244
            tm244, _ = chinh_sach_so._thu_muc_ra(dl["duong_so"])
            hang_doi_viec.ghi(ds_viec, tm244, lambda t: tram_ky.TEN_TRAM.get(t, ""), tep_tl250, ky)
            hang_doi_viec.ghi_tom_tat(ds_viec, tm244, _dt244.datetime.now().strftime("%d/%m/%Y %H:%M"),
                                      "%s - %s" % (ky.get("tu") or "", ky.get("den") or ""))
    except Exception:
        pass
    return ra, {"loi": n_loi, "canh_bao": n_cb}


def ten_ky_bao_cao(tu, den):
    """GD206: ten ky theo ngay chon (dd/mm/yyyy): THANG mm/yyyy, QUY q/yyyy, NAM yyyy, n THANG NAM yyyy (tu dau nam) hoac TU ... DEN ...
    -> (ten in hoa, ten thuong, ca_nam)."""
    import calendar
    import datetime as _dt

    def doc(x):
        try:
            d, m, y = [int(v) for v in str(x or "").strip().split("/")]
            return _dt.date(y, m, d)
        except Exception:
            return None
    a, b = doc(tu), doc(den)
    if not a or not b or b < a:
        return "", "", False
    dau_thang = a.day == 1
    cuoi_thang = b.day == calendar.monthrange(b.year, b.month)[1]
    so_thang = (b.year - a.year) * 12 + b.month - a.month + 1
    if dau_thang and cuoi_thang:
        if so_thang == 12:
            if a.month == 1:
                return "NĂM %d" % a.year, "năm %d" % a.year, True
            return "NĂM TÀI CHÍNH %02d/%d - %02d/%d" % (a.month, a.year, b.month, b.year), "năm tài chính %02d/%d - %02d/%d" % (a.month, a.year, b.month, b.year), True
        if so_thang == 1:
            return "THÁNG %02d/%d" % (b.month, b.year), "tháng %02d/%d" % (b.month, b.year), False
        if so_thang == 3 and a.month in (1, 4, 7, 10) and a.year == b.year:
            q = (a.month - 1) // 3 + 1
            return "QUÝ %d/%d" % (q, a.year), "quý %d/%d" % (q, a.year), False
        if a.month == 1 and a.year == b.year:
            return "%d THÁNG NĂM %d" % (so_thang, a.year), "%d tháng năm %d" % (so_thang, a.year), False
    return ("TỪ %s ĐẾN %s" % (a.strftime("%d/%m/%Y"), b.strftime("%d/%m/%Y")),
            "từ %s đến %s" % (a.strftime("%d/%m/%Y"), b.strftime("%d/%m/%Y")), False)


def lap_excel_tndn(dl, ra):
    H = _xl()
    X = H
    S, c, t = uoc_tndn(dl)
    cty = dl.get("cty") or {}
    ky = dl.get("ky") or {}
    # GD206 (anh Thang 12/10/2026): tieu de theo ky chon (thang / quy / n thang / nam); bo dong ky thuat (chi doc, bo 911, phu luc HTKK)
    ky_hoa, ky_thuong, ca_nam = ten_ky_bao_cao(ky.get("tu"), ky.get("den"))
    T = [[("ƯỚC TÍNH THUẾ TNDN %s" % (ky_hoa or "NĂM"), X.X_TITLE)],
         [("Đơn vị: %s    MST: %s    Kỳ: %s - %s    Chế độ: %s" % (cty.get("ten") or "", cty.get("mst") or "", ky.get("tu") or "", ky.get("den") or "",
                                                                   "TT99" if S.tt == 99 else "TT133"), X.X_THUONG)],
         [],
         [("Mã", X.X_TIEUDE), ("Chỉ tiêu (phụ lục 03-1A/TNDN)", X.X_TIEUDE), ("Số tiền", X.X_TIEUDE)]]
    tk99 = S.cp99          # GD179: so TT99 - giam tru DT ghi No 521, chi phi ban hang 641, chi phi quan ly 642
    dong = (("04", "Doanh thu bán hàng, cung cấp dịch vụ (Có 511)"),
            ("06", "Các khoản giảm trừ doanh thu (Nợ 521)" if tk99 else "Các khoản giảm trừ doanh thu (Nợ 511)"),
            ("10", "Doanh thu hoạt động tài chính (515)"), ("12", "Chi phí SXKD = [13] + [14] + [15]"), ("13", "Giá vốn hàng bán (632)"),
            ("14", "Chi phí bán hàng (641)" if tk99 else "Chi phí bán hàng (6421)"),
            ("15", "Chi phí quản lý doanh nghiệp (642)" if tk99 else "Chi phí quản lý doanh nghiệp (6422)"), ("16", "Chi phí tài chính (635)"),
            ("18", "Lợi nhuận thuần từ HĐKD = [04] - [06] + [10] - [12] - [16]"), ("19", "Thu nhập khác (711)"), ("20", "Chi phí khác (811)"),
            ("21", "Lợi nhuận khác = [19] - [20]"), ("22", "Tổng lợi nhuận kế toán trước thuế = [18] + [21] (= [A1] tờ khai)"))
    for ma, ten in dong:
        dam = ma in ("18", "22")
        T.append([("[%s]" % ma, X.X_MUC if dam else X.X_CHU), (ten, X.X_MUC if dam else X.X_CHU), (c[ma], X.X_SOMUC if dam else X.X_SO)])
    T.append([])
    T.append([("THUẾ SUẤT VÀ THUẾ ƯỚC TÍNH", X.X_MUC)])
    T.append([("", X.X_CHU), ("Tổng doanh thu năm trước (DT thuần + DT tài chính + thu nhập khác) - %s" % (t["nguon_dt"] or "chưa có"), X.X_CHU),
              (t["dt_nam_truoc"], X.X_SO)])
    T.append([("", X.X_CHU), ("Thuế suất gợi ý: %s" % t["ly_do"], X.X_CHU), (t["thue_suat"], X.X_SO)])
    T.append([("", X.X_CHU), ("Thu nhập tính thuế ước tính (chưa gồm điều chỉnh [B], thu nhập miễn thuế, chuyển lỗ)", X.X_CHU), (t["thu_nhap"], X.X_SO)])
    T.append([("", X.X_MUC), ("Thuế TNDN ước tính cả năm" if (ca_nam or not ky_thuong) else "Thuế TNDN ước tính %s" % ky_thuong, X.X_MUC), (t["thue"], X.X_SOMUC)])
    if t["thue"] and (ca_nam or not ky_thuong):          # GD207: chua het nam -> xem bang Tam nop theo quy
        T.append([("", X.X_CHU), ("Tạm nộp 4 quý tối thiểu 80% số quyết toán", X.X_CHU), (round(t["thue"] * 0.8), X.X_SO)])
    T.append([("", X.X_CHU), ("Chi phí thuế TNDN đã hạch toán (Nợ 821)", X.X_CHU), (t["n821"], X.X_SO)])
    T.append([("", X.X_CHU), ("Phát sinh Nợ 3334 (đã nộp / bù trừ)", X.X_CHU), (t["n3334"], X.X_SO)])
    T.append([])
    # GD207 (anh Thang 12/10/2026): TAM NOP THEO TUNG QUY - so cua rieng quy do (quy 3 = thang 7 - 9); cac quy truoc trong nam de doi chieu
    T.append([("TẠM NỘP THUẾ TNDN THEO QUÝ (thuế suất gợi ý %s)" % (("%g%%" % t["thue_suat"]) if t["thue_suat"] else "- chưa có"), X.X_MUC)])
    T.append([("Quý", X.X_TIEUDE), ("Lợi nhuận kế toán quý", X.X_TIEUDE), ("Thuế tạm nộp quý", X.X_TIEUDE),
              ("Đã nộp trong quý (Nợ 3334)", X.X_TIEUDE), ("Còn phải nộp", X.X_TIEUDE)])
    for d in t["quy_ct"]:
        kd = X.X_MUC if d["ky_chon"] else X.X_CHU
        T.append([("Quý %d%s" % (d["quy"], " (kỳ chọn)" if d["ky_chon"] else ""), kd), (d["ln"], X.X_SOMUC if d["ky_chon"] else X.X_SO),
                  (d["phai_nop"], X.X_SOMUC if d["ky_chon"] else X.X_SO), (d["nop"], X.X_SO), (d["con"], X.X_SOMUC if d["ky_chon"] else X.X_SO)])
    if t["quy_ct"]:
        tn = [d for d in t["quy_ct"]]
        T.append([("Cộng từ đầu năm", X.X_MUC), (sum(d["ln"] for d in tn), X.X_SOMUC),
                  (sum(d["phai_nop"] or 0 for d in tn) if t["thue_suat"] else None, X.X_SOMUC), (sum(d["nop"] for d in tn), X.X_SOMUC),
                  (sum(d["con"] or 0 for d in tn) if t["thue_suat"] else None, X.X_SOMUC)])
        T.append([("Thuế tạm nộp quý = lợi nhuận kế toán của quý x thuế suất gợi ý (quý lỗ: 0); hạn nộp ngày cuối tháng đầu quý sau. "
                   "Tổng tạm nộp 4 quý không thấp hơn 80% thuế TNDN quyết toán năm (phần thiếu tính tiền chậm nộp).", X.X_GHICHU)])
    T.append([])
    T.append([("Căn cứ: Luật Thuế TNDN 67/2025/QH15, Nghị định 320/2025/NĐ-CP Điều 11 - thuế suất 15% (tổng doanh thu năm trước không quá 3 tỷ), "
               "17% (trên 3 tỷ đến 50 tỷ), còn lại 20%. Tổng doanh thu = doanh thu bán hàng, cung cấp dịch vụ (trừ giảm trừ) + doanh thu tài chính + "
               "thu nhập khác của năm trước liền kề; doanh nghiệp hoạt động dưới 12 tháng thì bình quân tháng x 12. Không áp dụng 15% / 17% cho "
               "doanh nghiệp có quan hệ liên kết mà bên liên kết không phải doanh nghiệp nhỏ và vừa, và phần thu nhập không được ưu đãi. "
               "Số trên đây là ước tính từ sổ: tờ khai 03/TNDN chính thức lập trên HTKK sau khi điều chỉnh [B], chuyển lỗ, thu nhập miễn thuế.", X.X_GHICHU)])
    T += khoi_ky(dl, X, 3)
    sheets = [("Uoc tinh TNDN", [16, 70, 20, 22, 20], T, 4)]          # GD206: bo dong ky thuat -> tieu de cot o dong 4
    os.makedirs(os.path.dirname(os.path.abspath(ra)), exist_ok=True)
    H.viet_xlsx_o(ra, sheets)
    return ra, t


def chay(loai, duong_json, ra):
    """-> (duong xlsx, loi)."""
    with open(duong_json, "r", encoding="utf-8-sig") as f:
        dl = json.loads(f.read(), strict=False)
    if loai == "tndn":
        d, _ = lap_excel_tndn(dl, ra)
    else:
        d, _ = lap_excel_khoa_so(dl, ra)
    return d, ""


# ============================================================ GD86: Ket chuyen cuoi ky (tab moi FrmAIHoaDon)
#   Loc trinh_tu_khoa_so() con dung 3 viec cua tab: CCDC/242, Khau hao TSCD, Trich luong + ket chuyen 911.
#   Gia thanh / thue GTGT khau tru / gia von / TNDN tam tinh KHONG thuoc tab nay (co cong cu rieng).
TEN_KET_CHUYEN_CUOI_KY = ("Trích khấu hao TSCĐ", "Phân bổ chi phí trả trước (242)",
                          "Tính lương, trích BHXH (334, 338)", "Kết chuyển doanh thu, chi phí sang 911")


def ket_chuyen_cuoi_ky(dl):
    """-> [[thang_duong_lich, [[buoc, trang_thai, so_tien, menu], ...]], ...] - chi 4 buoc lien quan tab moi."""
    S = SoLieu(dl)
    ra = []
    for thang_dl, dong in trinh_tu_khoa_so(S):
        loc = [[ten, tt, so, menu] for ten, tt, so, menu in dong if ten in TEN_KET_CHUYEN_CUOI_KY]
        ra.append([thang_dl, loc])
    return ra


def _dong_ket_chuyen_txt(kq):
    """[[thang, [[ten, tt, so, menu], ...]], ...] -> dong text ';' - VB6 doc bang Line Input + Split (khong can
    dung JSON parser rieng ben VB6). Moi dong: thang;ten;trang_thai;so_tien;menu ."""
    ds = []
    for thang_dl, dong in kq:
        for ten, tt, so, menu in dong:
            for x in (ten, tt, menu):
                assert ";" not in x and "\n" not in x and "\r" not in x, "GD86: truong co ky tu dac biet: %r" % (x,)
            ds.append("%d;%s;%s;%s;%s" % (thang_dl, ten, tt, repr(float(so)), menu))
    return "\r\n".join(ds) + ("\r\n" if ds else "")


def chay_ket_chuyen(duong_json, ra):
    """-> (duong tep ket qua, loi). Doc so lieu (dung chung KS_Json ben VB6), ghi text ';' cho luoi VB6 (KHONG
    phai JSON - VB6 khong co san bo doc JSON, doc bang Line Input + Split de tranh phai tu viet parser)."""
    with open(duong_json, "r", encoding="utf-8-sig") as f:
        dl = json.loads(f.read(), strict=False)
    kq = ket_chuyen_cuoi_ky(dl)
    os.makedirs(os.path.dirname(os.path.abspath(ra)), exist_ok=True)
    with open(ra, "w", encoding="utf-8") as f:
        f.write(_dong_ket_chuyen_txt(kq))
    return ra, ""


if __name__ == "__main__":
    import sys
    if len(sys.argv) >= 3:
        print(chay("tndn" if "tndn" in sys.argv[1].lower() else "khoaso", sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else re.sub(r"\.json$", ".xlsx", sys.argv[2])))
