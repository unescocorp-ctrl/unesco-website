# -*- coding: utf-8 -*-
"""GD238 - HANG DOI "VIEC CAN ANH" (muc 8 lo trinh): gom moi ket qua Kiem tra truoc khoa so (K01-K45) + buoc khoa so con
CHUA thanh MOT danh sach viec co thu tu uu tien, noi ro: thieu gi, lam o dau, hau qua neu bo qua.

Thu tu: (1) LOI theo tram tang dan (sua tram truoc thi tram sau tu het loi), (2) buoc khoa so CHUA theo thang, (3) CANH_BAO
theo tram. THONG_TIN / DAT khong vao hang doi.
Ghi <AIHoaDon>\\ket-qua\\hang_doi_viec.txt (';' cho VB6 / bang dieu hanh):  V;<stt>;<muc>;<tram>;<ma>;<ten>;<lam o dau>;<ket luan>
va hang_doi_viec.html (mo bang trinh duyet). Chi doc.
"""
import html
import io
import os

# ma -> (lam o dau, hau qua neu bo qua)
HUONG = {
    "K01": ("Hệ thống > Số dư đầu năm", "BCTC không cân"),
    "K02": ("Kiểm tra số liệu (Hệ thống)", "Sổ cái không cân"),
    "K03": ("Mở chứng từ lệch, sửa Nợ / Có", "Sổ cái không cân"),
    "K04": ("Sửa ngày chứng từ", "Số liệu rơi ngoài năm tài chính"),
    "K05": ("Sổ quỹ / sổ tiền gửi: kiểm thứ tự thu - chi", "Quỹ âm - không hợp lệ"),
    "K06": ("Xem TK dư sai bên", "BCTC trình bày sai"),
    "K07": ("Thẻ Kết chuyển cuối kỳ (xem K45)", "Lãi lỗ, BCTC sai"),
    "K08": ("Công nợ: chọn đối tượng cho dòng 131 / 331", "Sổ chi tiết công nợ lệch sổ cái"),
    "K09": ("Mở chứng từ công nợ chưa chọn khách / NCC", "Không đối chiếu được công nợ"),
    "K11": ("Tính giá xuất kho / kiểm phiếu xuất; kiểm kê: python kiem_ke.py lap <sổ.mdb> <tháng> rồi doc <phiếu đã điền>", "Tồn kho âm - giá vốn sai"),
    "K12": ("Thẻ Kết chuyển cuối kỳ > Khấu hao", "Chi phí thiếu"),
    "K13": ("Thẻ Kết chuyển cuối kỳ > Phân bổ 242", "Chi phí thiếu"),
    "K14": ("Tính giá xuất kho", "Giá vốn sai"),
    "K15": ("Giá thành > Kết chuyển thành phẩm", "Giá thành, tồn kho 155 sai"),
    "K16": ("Đối chiếu bảng kê mua vào với Nợ 133", "Tờ khai 01/GTGT lệch sổ"),
    "K17": ("Đối chiếu bảng kê bán ra với Có 3331", "Tờ khai 01/GTGT lệch sổ"),
    "K18": ("Bổ sung chứng từ ngân hàng hoặc giảm [25]", "Mất khấu trừ thuế GTGT"),
    "K19": ("Kiểm khoản trả tiền mặt thuộc hoá đơn nào", "Có thể mất khấu trừ"),
    "K21": ("Giá thành: ghi lại phiếu kết chuyển", "Tồn kho 152/154/155 sai"),
    "K22": ("Sửa ngày phiếu kết chuyển", "Giá xuất kho NVL sai tháng"),
    "K23": ("Ghi lại phiếu kết chuyển để nhận chi phí", "Giá thành thiếu NC / SXC"),
    "K24": ("Giá thành > Định mức tự động", "Giá thành NVL = 0"),
    "K25": ("Xem 154 còn dư", "Dở dang sai"),
    "K26": ("Giá thành AI > Cân đối theo thực tế", "Tồn điện ảo"),
    "K27": ("Sửa đơn giá điện", "Giá thành sai"),
    "K28": ("Lập phiếu kết chuyển thành phẩm", "Xuất kho 155 không có nhập"),
    "K30": ("Kiểm soát > KS1 trùng mã", "Công nợ tách đôi"),
    "K31": ("Kiểm soát > Xử lý trả hộ", "Công nợ sai đối tượng"),
    "K33": ("Kiểm soát > KS5 trùng vật tư", "Tồn kho tách đôi"),
    "K34": ("Kiểm soát > Chốt TK chuẩn", "Hạch toán không nhất quán"),
    "K36": ("Dữ liệu > Soát rủi ro hoá đơn trước kỳ khai", "Rủi ro phạt khi khai thuế"),
    "K37": ("Kiểm soát > Bất thường số liệu", "Số liệu bất thường chưa giải thích"),
    "K38": ("Chạy lại các trạm cần chạy lại rồi Kiểm tra lại", "Số đã kiểm không còn đúng"),
    "K39": ("Tải lại / nhập tệp kết quả hoá đơn thiếu", "Thiếu hoá đơn trong sổ"),
    "K40": ("Huỷ bút toán HĐ gốc bị thay thế / nhập HĐ gốc", "Nhân đôi chi phí / doanh thu"),
    "K41": ("Huỷ bút toán trả 2 lần / ghi chứng từ cho dòng sổ phụ", "Tiền và công nợ sai"),
    "K42": ("Thẻ Sổ phụ: xử lý hoặc đánh dấu bỏ qua", "Sao kê chưa vào sổ"),
    "K44": ("Ghi mã lý do vào tệp giai_trinh_<năm>_<kỳ>.txt (đường dẫn trong kết luận)", "Không giải thích được số liệu khi quyết toán"),
    "K58": ("Sửa chứng từ tiền thiếu TK đối ứng; xem sheet K58 cặp TK", "B03 không cân với B01"),
    "K59": ("Giá thành > Kết chuyển: Nợ 632 / Có 154x theo cột Xử lý; cập nhật % hoàn thành trong cong_trinh.txt", "Giá vốn, doanh thu công trình sai kỳ"),
    "K57": ("Thẻ Kết chuyển cuối kỳ: lập bút toán theo cột Bút toán, từng tháng", "Chi phí, doanh thu sai kỳ"),
    "K55": ("Quy tắc hạch toán > Ngưỡng tin cậy tự động (đổi theo đề xuất)", "Máy ghi quá tay hoặc hỏi quá nhiều"),
    "K54": ("Khai bổ sung (KHBS) trên HTKK hoặc sửa chứng từ; tải lại hồ sơ đã nộp từ Cổng thuế", "Tờ khai sai, bị phạt khai sai"),
    "K46": ("So bảng kê / chứng từ thuế với hóa đơn cổng thuế", "Tờ khai GTGT sai, khấu trừ vượt"),
    "K47": ("Giá thành > Kết chuyển thành phẩm: mở phiếu tháng lệch, bấm Ghi lại", "Tồn kho 155, giá vốn sai"),
    "K48": ("Giá thành > Kết chuyển thành phẩm / kết chuyển chi phí sản xuất tháng đó", "Giá thành, BCTC sai"),
    "K49": ("Giá thành > Kiểm tra định mức; Ghi lại phiếu kết chuyển", "Giá vốn từng mặt hàng sai"),
    "K50": ("Mở chinh_sach.html (đường dẫn trong kết luận); sửa ở Quy tắc / Ghép mã / Kiểm soát KS7", "Hạch toán tự động sai TK"),
    "K51": ("So bảng thay đổi; lập lại lô bị ảnh hưởng hoặc chấp nhận chính sách mới", "Chứng từ trong kỳ không nhất quán"),
    "K53": ("Lập bút toán theo cột Cách xử lý (kết chuyển 3387 / 154 / 1562, đánh giá 413)", "Doanh thu, giá vốn, KQKD sai kỳ"),
    "K60": ("Giá thành > Kết chuyển thành phẩm / Kho / Lương - xem cột Làm ở đâu của từng việc", "Giá thành, giá vốn, lãi lỗ tháng sai"),
    "K61": ("Chạy hàng loạt > mục I: Nợ khó đòi (no_kho_doi.html, bộ hồ sơ) - xem cột Làm ở đâu", "Dự phòng sai, chi phí bị loại khi quyết toán TNDN"),
}
# GD353: hau qua tung viec no kho doi (K61:<MA>)
HAU_QUA_K61 = {"NKD_TRICH": "Thiếu dự phòng: tài sản, lợi nhuận BCTC năm phản ánh sai", "NKD_HOAN": "Dự phòng thừa: chi phí cao hơn thực tế, có thể bị loại khi quyết toán",
               "NKD_HS": "Trích lập không đủ hồ sơ: chi phí không được trừ khi quyết toán TNDN", "NKD_XOA": "Nợ không thu được vẫn treo trên 131, BCTC sai",
               "NKD_TUOI": "Không xác định được mức trích của nợ cũ", "NKD_HAN": "Tuổi nợ tính theo hạn giả định, có thể sai mức trích"}
# GD352: hau qua tung viec gia thanh (K60:<MA>)
HAU_QUA_K60 = {"KC_CHUA_LAP": "Giá thành tháng = 0, 154 treo, giá vốn sai", "NC_CHUA_PHAN_BO": "Giá thành thiếu nhân công, 154 dư ảo",
               "SXC_CHUA_PHAN_BO": "Giá thành thiếu SXC, 154 dư ảo", "LUONG_CHUA_TRICH": "Chi phí tháng thiếu lương, lãi ảo, 334 không khớp bảng lương",
               "NVL_XUAT_THIEU": "Giá thành thiếu NVL, tồn 152 ảo", "HAO_HUT_CAO": "Giá thành cao bất thường / định mức sai", "XUAT_TAY_NHIEU": "Không tính được giá thành từng mặt hàng",
               "NVL_AM": "Tồn kho âm - BCTC sai, không khoá được", "NVL_CAN_MUA": "Thiếu NVL cho sản xuất tháng tới", "NVL_CHUA_VAO_PHIEU": "154 dư cuối tháng chưa rõ dở dang",
               "CHUA_CO_DOANH_THU": "Thiếu doanh thu, thuế GTGT đầu ra kỳ này", "SP_LO": "Bán dưới giá thành - xem giá bán / định mức", "GT_0": "Giá vốn mặt hàng = 0"}


def _muc_so(m, LOI, CANH_BAO):
    return 0 if m == LOI else (2 if m == CANH_BAO else 9)


def lap(kq, trinh_tu, LOI, CANH_BAO, tram_cua):
    """-> danh sach viec [(muc, tram, ma, ten, lam_o_dau, ket_luan, hau_qua)] da xep."""
    ds = []
    for k in kq or []:
        m = k.get("muc")
        if m not in (LOI, CANH_BAO):
            continue
        ma = str(k.get("ma") or "")
        noi, hq = HUONG.get(ma[:3], ("Xem chi tiết trong Excel kiểm tra", ""))
        if ma in ("K60", "K61") and k.get("dong"):          # GD352: moi viec gia thanh mot dong rieng (ma K60:<MA>); GD353: K61 no kho doi
            hq_ma = HAU_QUA_K60 if ma == "K60" else HAU_QUA_K61
            for d in k["dong"]:
                if len(d) < 4:
                    continue
                ma_v, muc_v = str(d[0]), str(d[1]).upper()
                m_v = LOI if muc_v == "NANG" else CANH_BAO
                if muc_v == "NHE" and ma == "K61":
                    continue                               # K61: viec NHE (thong tin) khong vao hang doi
                ds.append((_muc_so(m_v, LOI, CANH_BAO), 6 if ma == "K60" else 5, ma + ":" + ma_v, str(d[2]), str(d[3]), (k.get("ket_luan") or "")[:160] + ((" | Số tiền: " + str(d[4])) if len(d) > 4 and d[4] else ""),
                           hq_ma.get(ma_v.split(":")[0], hq), m_v))
            continue
        ds.append((_muc_so(m, LOI, CANH_BAO), tram_cua(ma) or 9, ma, k.get("ten") or "", noi, k.get("ket_luan") or "", hq, m))
    for thang, dong in trinh_tu or []:
        for ten, tt, so, menu in dong:
            if tt == "CHƯA":
                ds.append((1, 7, "B%02d" % int(thang), "Tháng %s: %s" % (thang, ten), menu, "Bước khoá sổ chưa làm", "Khoá sổ thiếu bước", "BUOC"))
    ds.sort(key=lambda v: (v[0], v[1], v[2]))
    return ds


def _sach(s):
    return str(s or "").replace(";", ",").replace("\r", " ").replace("\n", " ")


TEN_MUC = {0: "LỖI - chặn khoá sổ", 1: "Bước khoá sổ chưa làm", 2: "Cần xem"}


def _tra_loi(v):
    """GD250: dong mau de dan vao tra_loi.txt."""
    ma = v[2]
    if ma.startswith("B"):
        return ""
    if ma == "K51":
        return "K51;*;CHAP_NHAN;"
    if ma == "K52":
        return "K52;*;LOAI_HINH;XAY_DUNG, DICH_VU"
    if ma == "K44":
        return "(ghi mã lý do vào tệp giai_trinh_...txt)"
    return "%s;*;BO_QUA;<lý do>  hoặc  %s;*;HEN;<lý do>" % (ma, ma)


def ghi(ds, thu_muc, ten_tram, tep_tra_loi="", ky=None):
    os.makedirs(thu_muc, exist_ok=True)
    t = os.path.join(thu_muc, "hang_doi_viec.txt")
    with io.open(t, "w", encoding="utf-8") as f:
        f.write("SO;%d\n" % len(ds))
        if tep_tra_loi:
            f.write("TL;%s\n" % _sach(tep_tra_loi))        # GD253: VB mo tep tra loi tu hop hoi hang doi
        if ky and (ky.get("tu") or ky.get("den")):
            f.write("KY;%s;%s\n" % (_sach(ky.get("tu")), _sach(ky.get("den"))))   # GD260: FrmHangDoi "Kiem tra lai" cung ky
        for i, v in enumerate(ds, 1):
            f.write("V;%d;%s;%d;%s;%s;%s;%s\n" % (i, v[7], v[1], v[2], _sach(v[3]), _sach(v[4]), _sach(v[5])[:300]))
    dong = []
    for i, v in enumerate(ds, 1):
        mau = "#b3261e" if v[0] == 0 else ("#8a5a00" if v[0] == 1 else "#1f4e79")
        dong.append("<tr><td>%d</td><td style='color:%s;font-weight:bold'>%s</td><td>%d. %s</td><td>%s</td><td><b>%s</b><br>%s</td>"
                    "<td>%s</td><td>%s</td><td><code>%s</code></td></tr>" % (i, mau, html.escape(TEN_MUC.get(v[0], "")), v[1], html.escape(ten_tram(v[1])),
                                                     html.escape(v[2]), html.escape(v[3]), html.escape(v[5][:400]), html.escape(v[4]), html.escape(v[6]),
                                                     html.escape(_tra_loi(v))))
    doc = ("<!doctype html><html lang='vi'><head><meta charset='utf-8'><title>Việc cần làm</title><style>"
           "body{font-family:Arial,sans-serif;margin:16px;color:#1d2433}table{border-collapse:collapse;width:100%}"
           "th,td{border:1px solid #c5ccd6;padding:6px;vertical-align:top;font-size:13px}th{background:#e8eef5}</style></head><body>"
           "<h2>Việc cần làm trước khi khoá sổ (@@N@@ việc)</h2><p>Làm từ trên xuống: lỗi ở trạm trước sửa xong thường kéo theo trạm sau "
           "hết lỗi. Làm xong bấm Kiểm tra trước khoá sổ lại. Việc không phải lỗi hoặc đã làm ngoài phần mềm: ghi một dòng như cột "
           "<b>Trả lời</b> vào tệp <code>@@TL@@</code>, lần kiểm sau máy áp dụng và không hỏi lại.</p><table><tr><th>#</th><th>Mức</th><th>Trạm</th><th>Mã</th><th>Việc</th>"
           "<th>Làm ở đâu</th><th>Bỏ qua thì</th><th>Trả lời (dòng dán vào tra_loi.txt)</th></tr>@@DONG@@</table></body></html>").replace("@@N@@", str(len(ds))).replace(
               "@@DONG@@", "".join(dong)).replace("@@TL@@", html.escape(tep_tra_loi or "tra_loi.txt"))
    h = os.path.join(thu_muc, "hang_doi_viec.html")
    with io.open(h, "w", encoding="utf-8") as f:
        f.write(doc)
    return t, h


def ghi_tom_tat(ds, thu_muc, luc, ky=""):
    """GD244: tom tat 1 dong cho Bang dieu hanh: LUC;<luc>;<so viec>;<so loi>;<ky>"""
    os.makedirs(thu_muc, exist_ok=True)
    n_loi = sum(1 for v in ds if v[0] == 0)
    with io.open(os.path.join(thu_muc, "tom_tat.txt"), "w", encoding="utf-8") as f:
        f.write("LUC;%s;%d;%d;%s\n" % (_sach(luc), len(ds), n_loi, _sach(ky)))


def doc_tom_tat(thu_muc):
    """-> {"luc", "n", "loi", "ky"} hoac None"""
    p = os.path.join(thu_muc, "tom_tat.txt")
    if not os.path.isfile(p):
        return None
    try:
        with io.open(p, encoding="utf-8") as f:
            x = f.readline().strip().split(";")
        if x[0] != "LUC" or len(x) < 4:
            return None
        return {"luc": x[1], "n": int(x[2]), "loi": int(x[3]), "ky": x[4] if len(x) > 4 else ""}
    except Exception:
        return None
