# -*- coding: utf-8 -*-
"""GD118 - GIU KHOA GOOGLE CUA MAY qua cac lan cap nhat / doi file .exe / cai lai / chay .exe o thu muc khac.

Anh Thang 04/10/2026: "khi da dang ky thi luu san vao may, khong phai moi khi cap nhat hay doi file .exe phai dang ky lai
key docai_goi.dat".
Truoc GD118 khoa Google Document AI cai san chi nam o <thu muc .exe>\\AIHoaDon\\docai_goi.dat: chay .exe o thu muc khac
(thu muc Make .exe, bo cai moi, thu muc sao chep) -> phan mem bao chua co khoa -> phai IMPORT lai.
Nay giu them MOT ban o KHO CUA MAY: %LOCALAPPDATA%\\UNESCO_AI\\khoa\\docai_goi.dat (cung cho voi tep so trang kh101.dat):
  * AIHoaDon co, kho chua co / khac va AIHoaDon MOI HON -> chep vao kho;
  * AIHoaDon chua co (hoac cu hon kho) -> chep tu kho vao AIHoaDon (tu khoi phuc, khong hoi).
Khoa van chi MO duoc khi may da kich hoat AI (phan mem truyen khoa mo) - giu tep khong mo them quyen gi.
Ghi them danh sach noi cai phan mem tren may (%LOCALAPPDATA%\\UNESCO_AI\\noi_cai.txt) cho CAP_NHAT_TU_DONG.bat tim thu muc
can cap nhat. Moi loi deu nuot (khong lam hong tool goi no).
Goi tu: tham_so_du_phong.bu_tham_so (dau 5 tool) va docai_unesco (truoc khi tim khoa); VB6 (GD118) lam cung viec luc mo AI."""
import io
import os
import shutil
import time

TEP_KHOA = "docai_goi.dat"
TEP_NOI_CAI = "noi_cai.txt"
TOI_DA_NOI_CAI = 40
_DA_CHAY = {}


def kho_may(tao=False):
    """%LOCALAPPDATA%\\UNESCO_AI (hoac %APPDATA%); '' neu khong co bien moi truong (vd. may Linux kiem thu khong dat)."""
    d = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA") or ""
    if not d:
        return ""
    p = os.path.join(d, "UNESCO_AI")
    if tao:
        try:
            os.makedirs(os.path.join(p, "khoa"), exist_ok=True)
        except OSError:
            return ""
    return p


def tep_khoa_may():
    k = kho_may()
    return os.path.join(k, "khoa", TEP_KHOA) if k else ""


def _giong(a, b):
    try:
        if os.path.getsize(a) != os.path.getsize(b):
            return False
        with open(a, "rb") as fa, open(b, "rb") as fb:
            return fa.read() == fb.read()
    except OSError:
        return False


def _chep(a, b):
    """Chep giu ngay gio tep (de lan sau so 'moi hon' dung); ghi qua tep tam roi doi ten."""
    tam = b + ".tam"
    shutil.copy2(a, tam)
    os.replace(tam, b)


def _dung_dang(p):
    try:
        with open(p, "rb") as f:
            return f.read(17) == b"UNESCO-DOCAI-GOI1"
    except OSError:
        return False


def giu_khoa(thu_muc_tool, ghi=None):
    """Dong bo AIHoaDon\\docai_goi.dat <-> kho may. Tra ve 'LUU' / 'KHOI_PHUC' / 'CAP_NHAT' / '' (khong doi) / 'LOI: ..'."""
    try:
        tool = os.path.join(thu_muc_tool, TEP_KHOA)
        co_tool = os.path.isfile(tool) and _dung_dang(tool)
        kho = tep_khoa_may()
        if not kho:
            return ""
        co_kho = os.path.isfile(kho) and _dung_dang(kho)
        if co_tool and co_kho and _giong(tool, kho):
            return ""
        if co_tool and (not co_kho or os.path.getmtime(tool) >= os.path.getmtime(kho)):
            if not kho_may(tao=True):
                return ""
            _chep(tool, kho)
            kq = "LUU"
        elif co_kho:
            _chep(kho, tool)
            kq = "KHOI_PHUC" if not co_tool else "CAP_NHAT"
        else:
            return ""
        if ghi:
            ghi({"LUU": "GD118: da luu khoa Google cai san vao kho cua may (%LOCALAPPDATA%\\UNESCO_AI\\khoa)",
                 "KHOI_PHUC": "GD118: tu khoi phuc AIHoaDon\\docai_goi.dat tu kho cua may (khong phai Import lai)",
                 "CAP_NHAT": "GD118: kho cua may co khoa Google moi hon -> cap nhat AIHoaDon\\docai_goi.dat"}[kq])
        return kq
    except Exception as e:          # khong bao gio lam hong tool
        return "LOI: %s" % str(e)[:150]


def _chuan(p):
    return os.path.normcase(os.path.normpath(os.path.abspath(p)))


def doc_noi_cai():
    """-> [(thu muc goc, 'yyyy-mm-dd hh:mm:ss')] moi nhat truoc."""
    k = kho_may()
    if not k:
        return []
    p = os.path.join(k, TEP_NOI_CAI)
    ra = []
    try:
        with io.open(p, "r", encoding="utf-8-sig", errors="replace") as f:
            for d in f:
                pt = d.rstrip("\r\n").split("\t")
                if pt and pt[0].strip():
                    ra.append((pt[0].strip(), pt[1].strip() if len(pt) > 1 else ""))
    except OSError:
        return []
    return ra


def ghi_noi_cai(thu_muc_goc):
    """Ghi thu muc cai phan mem (thu muc chua AIHoaDon) len dau danh sach noi cai cua may."""
    try:
        k = kho_may(tao=True)
        if not k or not thu_muc_goc:
            return False
        goc = os.path.abspath(thu_muc_goc)
        ds = [x for x in doc_noi_cai() if _chuan(x[0]) != _chuan(goc)]
        ds.insert(0, (goc, time.strftime("%Y-%m-%d %H:%M:%S")))
        p = os.path.join(k, TEP_NOI_CAI)
        tam = p + ".tam"
        with io.open(tam, "w", encoding="utf-8") as f:
            for a, b in ds[:TOI_DA_NOI_CAI]:
                f.write("%s\t%s\n" % (a, b))
        os.replace(tam, p)
        return True
    except Exception:
        return False


def chay(thu_muc_tool, ghi=None):
    """Mot lan / tien trinh / thu muc: giu khoa + ghi noi cai (thu muc cha cua AIHoaDon)."""
    key = _chuan(thu_muc_tool or ".")
    if key in _DA_CHAY:
        return _DA_CHAY[key]
    kq = giu_khoa(thu_muc_tool, ghi)
    if os.path.basename(os.path.normpath(thu_muc_tool)).lower() == "aihoadon":
        ghi_noi_cai(os.path.dirname(os.path.abspath(thu_muc_tool)))
    _DA_CHAY[key] = kq
    return kq
