# -*- coding: utf-8 -*-
"""GD143 - CHU KY SO Ed25519 (RFC 8032), Python thuan - khong can thu vien ngoai (may khach chi co Python chuan).
Dung cho kenh cap nhat phan mem tu dong: nha phat hanh KY tep unesco_cap_nhat.json bang khoa RIENG (chi nam o may phat hanh,
_CONG_CU_RIENG), may khach KIEM bang khoa CONG KHAI (AIHoaDon\\cap_nhat_khoa_cong_khai.txt) truoc khi tai / cai bat cu gi.
  kiem(khoa_cong_khai_32_byte, du_lieu, chu_ky_64_byte) -> True / False   (khong bao gio nem loi voi du lieu xau)
  khoa_cong_khai(hat_32_byte) -> 32 byte ; ky(hat_32_byte, du_lieu) -> 64 byte
Da doi chieu vector chuan RFC 8032 muc 7.1 (test_gd143)."""
import hashlib

_P = 2 ** 255 - 19
_Q = 2 ** 252 + 27742317777372353535851937790883648493


def _nghich(x):
    return pow(x, _P - 2, _P)


_D = -121665 * _nghich(121666) % _P
_CAN_M1 = pow(2, (_P - 1) // 4, _P)


def _sha512(b):
    return hashlib.sha512(b).digest()


def _sha512_q(b):
    return int.from_bytes(_sha512(b), "little") % _Q


def _cong(P, Q):
    A = (P[1] - P[0]) * (Q[1] - Q[0]) % _P
    B = (P[1] + P[0]) * (Q[1] + Q[0]) % _P
    C = 2 * P[3] * Q[3] * _D % _P
    D = 2 * P[2] * Q[2] % _P
    E, F, G, H = B - A, D - C, D + C, B + A
    return (E * F % _P, G * H % _P, F * G % _P, E * H % _P)


def _nhan(s, P):
    Q = (0, 1, 1, 0)
    while s > 0:
        if s & 1:
            Q = _cong(Q, P)
        P = _cong(P, P)
        s >>= 1
    return Q


def _bang(P, Q):
    if (P[0] * Q[2] - Q[0] * P[2]) % _P != 0:
        return False
    return (P[1] * Q[2] - Q[1] * P[2]) % _P == 0


def _tim_x(y, dau):
    if y >= _P:
        return None
    x2 = (y * y - 1) * _nghich(_D * y * y + 1) % _P
    if x2 == 0:
        return None if dau else 0
    x = pow(x2, (_P + 3) // 8, _P)
    if (x * x - x2) % _P != 0:
        x = x * _CAN_M1 % _P
    if (x * x - x2) % _P != 0:
        return None
    if (x & 1) != dau:
        x = _P - x
    return x


_GY = 4 * _nghich(5) % _P
_GX = _tim_x(_GY, 0)
_G = (_GX, _GY, 1, _GX * _GY % _P)


def _nen(P):
    zi = _nghich(P[2])
    x = P[0] * zi % _P
    y = P[1] * zi % _P
    return int.to_bytes(y | ((x & 1) << 255), 32, "little")


def _giai_nen(s):
    if len(s) != 32:
        return None
    y = int.from_bytes(s, "little")
    dau = y >> 255
    y &= (1 << 255) - 1
    x = _tim_x(y, dau)
    if x is None:
        return None
    return (x, y, 1, x * y % _P)


def _mo_rong(hat):
    if len(hat) != 32:
        raise ValueError("khoa rieng phai 32 byte")
    h = _sha512(hat)
    a = int.from_bytes(h[:32], "little")
    a &= (1 << 254) - 8
    a |= (1 << 254)
    return a, h[32:]


def khoa_cong_khai(hat):
    a, _ = _mo_rong(hat)
    return _nen(_nhan(a, _G))


def ky(hat, du_lieu):
    a, tien_to = _mo_rong(hat)
    A = _nen(_nhan(a, _G))
    r = _sha512_q(tien_to + du_lieu)
    Rs = _nen(_nhan(r, _G))
    h = _sha512_q(Rs + A + du_lieu)
    s = (r + h * a) % _Q
    return Rs + int.to_bytes(s, 32, "little")


def kiem(cong_khai, du_lieu, chu_ky):
    try:
        if len(cong_khai) != 32 or len(chu_ky) != 64:
            return False
        A = _giai_nen(cong_khai)
        if A is None:
            return False
        Rs = chu_ky[:32]
        R = _giai_nen(Rs)
        if R is None:
            return False
        s = int.from_bytes(chu_ky[32:], "little")
        if s >= _Q:
            return False
        h = _sha512_q(Rs + cong_khai + du_lieu)
        return _bang(_nhan(s, _G), _cong(R, _nhan(h, A)))
    except Exception:
        return False
