# -*- coding: utf-8 -*-
"""
=============================================================================
  TRICH XUAT SO PHU  -  gan Ma khach hang / Tai khoan / Ten vao so phu ngan hang
=============================================================================

  CACH DUNG (3 buoc):
    1. Bam doi vao file nay. Mot cua so den hien ra, giu nguyen, dung tat.
    2. Trinh duyet tu mo giao dien. Chon file, bam "Chay khop".
    3. Kiem tra cac dong mau vang/do roi bam "Xuat file".

  Khong can cai dat gi them ngoai Python (python.org, nho tich "Add to PATH").
  Doc duoc ca .xls lan .xlsx. Toan bo du lieu nam tren may ban.
=============================================================================
"""
import os
import re
import base64
import sys
import json
import time
import queue
import socket
import shutil
import struct
import zipfile
import platform
import threading
import traceback
import subprocess
import webbrowser
import unicodedata
import http.server
import urllib.parse
import xml.etree.ElementTree as ET
from datetime import datetime
from difflib import SequenceMatcher

try:
    import tkinter as tk
    from tkinter import filedialog
    TK_OK = True
except Exception:
    tk = None
    filedialog = None
    TK_OK = False

APP_VERSION = "1.3.0"

# Logo UNESCO (sao 5 canh + dong $, GD167) - PNG 96x96 nhung san trong file (GD150: thay logo / ten cong ty cu)
LOGO_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAArkUlEQVR42u2dd5gdxbH2f93TM3PS5l3trnJCWUIBJBBBiCABAkQO"
    "JicjwnXAxmCMjSN8YOOA4WKMCQZhgsnJRIFACCGEcs7Salebw8lnQvf3x0o2vtf29bWRLH+fap955uzuOc+Z7rfqreqq6hnYL/tl"
    "v+yX/fKPipQgpdg/Efvl/zOxZPd5xuGJvqceXdK/+2/7LWGvUg/AJ7Mr/vDp04P/0P23/QDsVe0/fIxVUVgqw8K8nuGh44rL/x2t"
    "QP47AmB2nb92mbjJqdHSibXL684uu3q/au5F7R89UCbymyx/3Vwnt/k14adX9E8N6B11hPgTPe23gD2p/Vc4X3bjofpWU3VwZ64m"
    "H+/Rmrji/MrTjAEh9vuCPeZ4hYCBvSw3syWeqZtrFaLLDvV7fjK5kFxM2Lhq8NayYltC9/v2W8DnLEKAMfClK4ovjFV7sfu6qrxc"
    "nzgNlSXy6abSbPWI9n7nnVM9EcCy9lvB56spohuA3lXK7mrs0dG6Wvn93x9biOeO82k7yZ/w8thc0C7DlStGz7Etud8CPnftlwJj"
    "4IuXVcwsro6Xzt5WkW8YUiJtDxSGT6uq1bsrivMjR/lTjzu2urcx/x5WYP37UI+gsljIhx49+A1SMnZ9OiILQ0tFNq00PiK0HNLb"
    "/PCcAXV2Vc3g2OzHG17dTVn7LeCf1RJLYIzh0ot7HNWjV6HX8ys781sPKJcRDwqBhUZqKTSvx6qd9Usz3jFTMl8cN6aqyBizz1uB"
    "9e+h/VCcsMRvH+z5WjSzovym1mqRHVMu0klB1rOMBFQ+EHkiROtzhemDd7jSGtLw8msNC+Uu6tpvAf+U9sMXzuoxoU9t+7A5i2R+"
    "3bBqmdCGVEFqqTUmgBCBkCGPBzVO+1Y3OPfCwT/q1yth69Ds0wszua9rfxgaIlHBly8q+aVZ3qIfU31Vok+EbFpS8AVCA77BSEsr"
    "L6QhFpNPrqrOFxWfW3zZZeOnG0Duwwjs0wBYu+jjjJnVQ4cN6Drko41W/pPBvWQJIS1ZgQiBAPCBQEv8EByXBztyTtDq6Mu/eNld"
    "pQlEGJp9NizdpwEINVhK8JULSn5s6pv0o1ZPKQbHyGQ0qSxIz2A8A56WpqDRgJXyWSKr5JwFv8z26l075PSZPUbvy854nwVgd+Qz"
    "/ZiK3geNy528fov25gzurWKW0U1dgjCroRBKkw2kyfqQDTDaIFMeRhZx3+q1yuTu1tdc3fs2JSEM91vA/0p2Ry5f+2rFD5E7eMSr"
    "0smhcYKsT2eHQeRCyAeQCxF5DdkAPI3OG2S6wBu5MrV63lv5CQe3zDj2sJJe+6oVyH1V+7U2HDaxtOyoaeMubthamn+xpsYpLhF0"
    "dhhZaAsQ2QCTDhHZEDIhJDUiZzChQbUUyHmShz4ugvqdXHV+4iufBXU/AP+j9ndr6g03HHejFF9l9ppyXTeqCFnw6GjUmGQIKQ1d"
    "GpPUmM4QkgEm6YPR6FSAyPs81VDmtC4PvOMPzl036gAnZvS+F5LucwBYErTWjDzAih5/Wq+vdqx43PtdJOfEetkkO3xydR4yG0Ay"
    "gKQPnR4kC5r0rteFAB0arK489SmHp1fHvYjVFbn6THWhYd9LU+97FrBrhq6fVT7L9R5znv/owWD1uBocCqTqAnST3z35XT6kfOgq"
    "aJIBpANIh5DTGK0hFUAh4KG1xY7XGAZnH6Nv7VEurDDszqzuB+AvXYwErQ0D+yrn7GP0bfk5bcFDdpWjBtvkUiH5NR4i7UOnD10+"
    "IuUjckaKTCi7LaL7EFKgCxrL81nc5Mo5q+x8Ze+w9qKTnSN3f89+AP5G3mfWubEzEnY68toax1s4rhxXarLbNHprgMhrTJeP7izo"
    "sDlP2JIj7Mhp3VlAZzxNIdTdIxPIgsaEgvuXFSnT4esrTovdrixBEILYD8B/uRDRHasP6G07F88Ud+mWQvBwV0L5tS4agbewgG4p"
    "oNsLyJzGVTaJkiLKqsooqyqXiZIEjq0w+RCd8jAW6ILWQmv9yraI2rjdzg8dl5901vGxIQByH0lDqn8x1f85/YRwQE+3okfP0lqv"
    "nPT3RN/Imtk72DytCrnRJ9q/hNLaMkqqyympKJPx4mKikRiOsAiDgFRXSrbU7aRxWxPJDa3otJYmk+fOM6P0PqY0oBgmjpCHPfFq"
    "Zj0IhPgvcan5U9F/r83D3ztB4jPvFog/++RfjSx2D2jX2RjzNwdpWYIwNMw6uXTyfY9P/dCPjM1unL/SOfy5+aTHDMYpiyCUg8wZ"
    "VDrEDQUuEgswrkPgWHjFNp4V4HcmSb6zg1sHGb71tamebXfE3n5g8cOnXrv28lyI2Z3o+2tjF0L8cczir85UN2ea/zZm898WlH9p"
    "kfk3AdjTzGcpgaOkcGwp4jFLNDVnw9CAUpIg0Hz3kgFn3frrrz3t05l9/LFnnEsXtlJVVcKkklKO6F/OqLIItaUQVzkCbdGekWzt"
    "FCyob2N+XZolac3BnU3Mv3NkICtHqi0f7Nh4yAnPjGrNEXb7AUNpwhJuxJaZbKj9QJuCr/f6au2vAqBcia2kcGxL2LYSrmtJ15Ey"
    "4korGpUqGpF2JCrtREJFYjHlFBXJRDxqxaOuicYdovGISEQcKx6PmHjU1rGoK4tijiyKxihKFFMaifnFkYQotot0VEVk+eLF7nOn"
    "n73ymmQGY9sS42vef3zKCxNOlSc3rOz0FtWNcWZMPlC7bjH5zozc2GrpHV0eXYHC0qGsiFj0Kw30oJo2SaSBhau2aL+1jVFjtwdF"
    "RQMiZ52y8YDnF6Q3RlxJvqCZflSk5sHf9Hs3JoN4ISs7Cikrnc+SzGZFKpe1Url82JUthJ25PNmMJ1KZQpAseCaX82QunQ0z2ZzM"
    "ZnNWPpvLFzJpL18ohEEhr4N8IfQLBR3m8jrMeyYseNr4Yag9X5uCZ4znhUj+lJsSfzK77uTXvbf2vXb6IWVfSCfTyVhcVZWXBsVO"
    "US7h2Dpux01MlmlFIgBRBNQAg4AcsBj8BmjXkNaQBfK7/pUDHUAhhLyAApA3kDOSQghjju4RyNIr1dsvrv7PU8569rqc323Dl053"
    "J//6oa99qBNT09nOfOzRhTn9zM4SuSTRh3RtNVSXEUvAcG20l4eW+u3EG5vkFDZy2eDF+pDhW7QlM85HL21cMPmyzYfuHuvUidGq"
    "F165amNxVWNx64rnaF/jYVvgCLrPlsBWAuVKVEQiXYmICyhWkFBQVAJMACYD7cAnwCagAAUJSYGXsnTgmbxBpvOd5NKdpPI53ZYo"
    "Lav+5ey6r93xUMtrfwaAFN3cPGagXTT7lqLXRo3LHk6Q59M1tSxLDcMt8ukquEGauM5ZMfImqguU6WwYJ1dwdd4z5DybXNYml7Mp"
    "eC4F3yHvR2Q+7xAULDzfkX4hQuDZ+L7CBEIGDdv53oxHuemusz3HcRKv/+6en517+byvH3/c0KH33H/fC9Kv7H/7S1u5v7mvTA0f"
    "Dj0VlEMimmaas4jauEOt1GzPO7wkJ9KUArMT2J5kSuMH8qZh7wTHHNkePP/kptuvuG7+beMPTJS9+NzJm4t7XZSoWzHXm3viz2Wv"
    "ekVFPKZDZcARCBttXLBcIAKha7SIAFGwogLiNioWJYhEcSJahiaNkVmgoEzoIcMACKTrIDNtyKoZ0HMAYMp5+DH7m994oPXHralu"
    "GxB/KQ6PuYgHv1Pxw3O/6t+8ZG1Z8tz3H3XWjz9cyWFGayEkId3VZAN4f9Jysv/ldWrX6wzQCaSBZLeikClA+3pkBHRZwANDbueS"
    "W4sCq/XTyJKF/VaOP+X2Ua+8m+L8N60gWTUOeli4KiCIQlisiGY20zLwJqKDAhDtvPNuJdP0MxABsiG2K4hWSoq3tXPK+tn88prN"
    "avOquiWR5IJ+vY/tW75j47D8spNeUAdtTVKnLWqcYnoWVUA8AjEH4g5ELIgrKLKgREFpBCpiUFUM1aXo6gqMCaCpFbOtHrO1GbOz"
    "nbAriWpJ6vTirNxxpvIG/KLgxFMl6utfD6f8/NmO9/8s8PhLq1EvgGfn5Oaojtjacy43518+5PVgy8clrGgfKytrPIp7+ESjGpcQ"
    "R4dYQaAtPxTCC5GF7gyl7NLIjhDRFCIaQ0Szh2hJQ1sboqsBkdoOqQ5tj+0jnGlDeHlhL/qveVz27hX1Bk25vuf/ebzdu7ltSHj2"
    "WcOEO1BT12gI8wrlphke3cJUdw3Tey3DSryDYDu5TH9aqaAqmsfWCVobXAqboddBLmLEITx/dyZ/xjEdfcsrE9Etcz72Vl+32jp0"
    "S5qKWkVrRrMzlyeZy1DIZDC5LMbLQeCjZYC2Ndo1mAjoCGjXoL0sunEHbFoLa9fC1q2IZBMiTOFu7SC5Lmd13l7sD7+DaGZ7tP2s"
    "c7LDZ89JLbesv8MJ7w4rjYFLTigd98BjYxarsgpufmpy9vb6LzvOgRbxET5+QuK3g98BJgUmuUvT23YdSQNpNBkgF0oKOY2fAi8L"
    "YUqKmE3s5NG4lZr2lYprghvlPXe6/PDePsF3tp0jH/1OMefHC8xql7y1tsAVsdc5rfolBkfWoew0YZgGbydogRWtAkeC7EEmHKk/"
    "aRsmb1t0HO+sPJBDp2um93dZetdT+sEbPqTxo43SO/UNxvRzCLWmMyPY2gZxIYkaSUJIokpgu5YWUSlFTGCKFKLYgiKFKbLAAaQB"
    "YRCWwGAQrXmsBZ00CEnwaGm+//F+YtmL4t1zv9h10tpmP7s7+vqbFvBZZCxLsGR9vnHuq033TTuyz5mnHfNxj/7pudlX509V6S0J"
    "RJdPaEu03w2AyOyinuwuL+sD2hhCIDCG0IfABxOAlxPuyL4khiTorJdM2vwoz9xbb556sdhc9+jZonJiJUeM8/jIcznSsfhR3/kc"
    "U3wdld4HSNEAfisml9cmj0FaRsZ84Uc78IOMdq21DEy8Iy6s/YBkOsIzc0bhlXjkasaJObO3iWv/o0g2kTXi5R0UlUZRxiKTN0gj"
    "iFoWrrJwHAWuZUREGlwphCPABiNACNO9TpACoQQmFaCWd2E+7KBhSEzbbxX7vQ/Ox39/R3j76Vd3XlKfCj1lQfAXqnLW/1SVUkqw"
    "pSnIvPDsxvsnDgkPPHnGwtFHOu9m564+TLVuq8XaEaBzAmEJKAhECsgayHX/Tt4YPMAPJb4nCD2DzkrhWhQd3AcdtQjnLucPN75F"
    "OlfBCbccRZioRvbRvNoaJZnZyrdrHiCavJt86xpUQZDcaDNn7jCqewwRbmSLEZEK2jeMF7IpSayPK8JcRvhdmjDZzIk1S/ho+wDm"
    "vlFKJtXM4u0DqclsMid+qScrn1lJbXOI5boEPnh+iCsljpQoSyKVMNgW0hbCKKmxLSEsgRES4UjIh5j1KdSCdnINeXaeWxRUvqys"
    "8pKs+4NZ+oxr7kzfU9AYS3bXt/+hXFAQGCwLNjeTn3Zm88xH7yj67pGHLkq8f8o0b4r7Cn6jg7Uc+EhjdhhMju6J94HAaELA1xAG"
    "3QeBxMuhqstxim06lgRcMeINho6JMuvH/cgW+iJjraS2JCl8nOH79s+wt99EbtMiIgWHuo09OXr97+UZvV8lH0iEllr6aT7qHMCJ"
    "8+6iY2klli+JFALctCFs2MEx4UuIjk46F25F5DQ3P3EQbR3l9PjhFOq6skhsEjEXKSwMQhshupfKQnavbLWAUEhCCUKBLzDrU5i5"
    "TailHbTlNY3fLfX6PxFG2JHPn3dcOPw7v8k8J3Y1FP+1yf+7k3Fh2O2c0wHm4ptS3/v25dFTe9c0xeZ84VyuqvmZDrpsSdpGrtaw"
    "DkTHLhDyQlIQEl9LfA/CAgRZMBpZWUoqCdEtK7j50jrmL3B465MhWPGO7sgiKxgSXcEhiTnopEDYClz4ZeP5LBl+su4RzSMlmABJ"
    "XlPkeMzrfwHf+PRC5FqYN3cQ33zxcsb/7nFuWXYtWDlCrbDSDXTo0fz04SgDThlH4+hywpRPJBbBthWhNtKY7qqcCY1Ed7e+CC0R"
    "gUTX5wgXtiBWd2ElA11X45J6qjw/6NYgtuEP5pOp0/w+T75fWKtUN4P8TwvrvzsbqnU3mlLCDx/OvXjO+WpkJq2DX132defuyZd4"
    "VksLWttY6QBTF0JjDrJhd5jqeeDnQeehkIFYFFEUI7sJju39ITX9mvnx0z2RdhmiSIBraXDoZdVjR5IExWhRqjVliqEDJGyHtoYI"
    "WAFS70rJaB+nPccz8hIOfu0ROWXNXO7M/pKV7tEEkTKMsiESQQd5hJvm4Q/HkM1Lii4aSnu6gO06RGJOt6syEIYa7RukLxCBoNBR"
    "ILW2neyGTshr8jpg40QH592q/MCzCok3fs79h59ZmLxoS9CpLAiCPZCONqYbCGXB0+96q6eepXuuX162/D+ufDny2hevyPfKfEyY"
    "dVEip0lloK0ZkjvBz4H2u7XfzyGKigmRUNfJF6Z8TKopzdvLBqB7FhH0qcbYFkQs2lJRQhFDVhusCimDeMDlk9/jnkG/4DB7FSLq"
    "gm3A7eZvb4dLsr2SxfEzNYkErmrRSqY1SkE0BhEX7caQpo2mYAjvzWun/0lx2uMSjMQtiuOj8UJNGBqENmTynmxsTdPSlCKb9xGW"
    "oiMssO2SfkHt3FN17bDaxM+uE1ee+NXMrJasDiz5l53tXy3B/iMJJG26Qahv0/nfP+//ZnRt7z7Tzpwy6fSx72eXfJJRWxrHCuVk"
    "MH4aCh1QaEPofLcP8H3kgP6E0SiqcT33nH8vH60ewKPLLqLf6aXImiiFpDHCkaK9kOC0snepGZ0XvnCxVBVGtjCx3/tcMHgxtmuh"
    "83VGKoVKDBTChFSqVihkaO+MERbKhLZsYVkhRstdaViJ5WUwRf2oCFfKU45ZYrY9k6JnLoIuidHVlsTS4KFpDAu0eAX8UGtpW8YO"
    "jWi0Q7y7ensjb780arWG6qoz35t4+xPJV8yubIL+X+by/uGyhDbdBfRUwegnX2x7sazQ2jb93OpTLzjmV/nmjUnxyZoJQtgBUqcw"
    "fh6ybZpCh8BysYYNREubvpmFfPP0B7n/9cksHnYGr14JTQhW1dkCzyNM9GLr5ow8f8AOo6qmEVAOYQd+rgnj7dAit91IY2ECTXli"
    "p5g+8C3OG/gGlx/wNqcdsIRe5e1s6KyiK1eLZYfdzhQQvodOVGLnm82lU19h59wCFfUx7OoSWtu6aPSztOKTQ2MJoZWSkiAUDf1s"
    "yn5bnB92USS+Y37jhlNOe2n4Cx/nN1iW+IdrCf9UXciYXZUs4A/zWhe2Ld/03owZ1pUnTX1HlGe2+W8tHSFDHcMSKYzvGbwOIxxL"
    "qANHEAaS0eYDLjn2Ze6Z+wXqB0/kp2MCysok64wklbQJRMiG6KFm4RrJxISgRyKGFVuHUp0ITwhywphAIEJDmMyKQlsW09FJJNNA"
    "LcuZUjufC0ctZVu2Jytbh+4CAUQQYuJFWCbPrEm/p3O5R2JdEdE+Faxua6M1m0ZJiSWEdqSQhTCg6+gihvw8lu93WDbx/uzg9ydd"
    "tOHYFfUmpXbVMP5lFTFtdjtnwT3PZ+du3Bb0e+Tn7idfOufZHsPLN6QvfeS6WH37YK2cFAEGHIVTZQi7oDSfBKeKNl2B68N8T7DM"
    "g5MnwKEjLLoyoEWAsS7hqc51VL/9GkOCsfRKKGpLt+DWhJKCpwmFtJXEjmkoWHg5gQg0utBOZWIOT54BheKhvLSkD5ZsR/s+KEE6"
    "dPFCF5lIY2Ix6FECriIEtCUQvpbNQNlV5frQy9GRRFvige/YN3zpp+135emO74Pwn6sffC4lSWO6q0tKweuLve1Tzw0GPvYD99Xj"
    "Ji+f8kHZLdlLHrzUeX/1JKnilg5ti7StoNlH6Q6IlBMaCx/4IGXY2GGwFVgOFJcZXeRqSqOBlP2G0jJiKIu2FNi0toHYvPk8cswt"
    "lFl1CKHYWteXlUtcJg3bTNUwn1BIJDae8HHMMn527DaW0Z/tqxPIdJ4w4WCyAqFiZJ1O6lM5IhmNlDbCEnh+SKpMMfSb5d6BR2cj"
    "IpOW19+mjv3ZC7l3/ljD1p9DH9TnWd3ZHSE1J43/9Jv60cGVbvFhh6WPPO+gJfm2dGgtXDbIUrLNnN7zQ3nj2J+Fpw/+IKwd3Es+"
    "/8koVqsx9Oyp6chJcho8bcgZWzQWlNjUrqhvSLJ0O6xplmy1KqinB1dXPUkk22qEpc2ChonilJVv8/iGk4g31HPwwV2EKovlCgLX"
    "UFH2BZKiP+9tAisToIsTVPmbuW7yh1iW7wVHGbNTeOxY2yw623KIUVEm3VWaH35IV7xlW6HlrJvFqMfeDZbsbmn5vApnn3tRPgi7"
    "nXNn3uizbi1cf0e9veIb1+Yeuucbz3oHj9wSDDmwWB8yJS6VWhzxPq5HcLAeVJHWtENDlyCnDcoXBEohW1L089Yxs2oRw/IfM/W9"
    "Wym4/SEb0CPXijUm2u2AhMSN2EgrYGePiXyp/l6mN59P/17teDm0CnyZb3+c99aOgEQVuBFwbHoVdxIt7qXLohti/U7xMOJQ3ffa"
    "wdn1z3ysDjgoGfTo2ZZY9JZ564Lv6FPXNZrsX8vn7HNdEaH+U0b1xl/7D6/ZqpbdfZv45LLrF0s4lOzOPnw6v/jTBe+0v/HFbxfP"
    "OmRovPTeF1N6S1McpzgklVOcyYvMOuAFhpSuQFpbIAz58toDuXP5VyBqtCWkNEqCY8CxEMpCpjNoY2sZ+FImSqBLQ0Egg5CdO5fx"
    "/kutUJpAui7ChXGVWaxErfPos94d/VbHek2cmjyzemx5oupLDnSmeOIucccX79A3p32j98Tk79G2FGN2Z1ThkTeDxVvq6fnt64t+"
    "9d7cNc+9+s5Hr62s99p9MJNPyQ87ftKQ0yMvt3o76opU8eCA9i0woGoBw3o9R35nGtICKxR8b9J9pPMRfr3+AtWWMdpIH+ICogbf"
    "1wTtEUqdBvnj056gr1qDX68JtSXp6fDSOwPQLcWoMMAbFAW/XZ8ySqp0s930jQfT38zptOkZe+WKKRPKRl5wVuQri5a6r9z6UPbp"
    "3f2qwR7aX7BXuiL+UjZQKUUQBFxx7oGHPPDE2x99722Z/v5HxRFR4RNmXab5s+XrZ1+Fl9PaNh5hziL0DU5NDStTE1naNJBTRy8i"
    "3vWBxrbZkjlaflA3lqlDV9FXfkqhbidIC7dSs35Jf4789U9oS0yBfglKpimG7tzgzbuiK/bEf37/2xd+5dUf7r6ev9att8fmZm8A"
    "YEx3Dml3etuyJEEQUlHiyovPqDx/5Njjjx5YWWUefDMnvXaJLLPY3lxjTig8bnrTwaJFtdRWpLF7alApelSvZcwBy1H5FoznCx0Y"
    "U1HVIsYOmEeJvwa8FKoMlNDMfWcIZz90Aw3hCIRbghgf5wtHBtwxMiKKZFfob5sdb/PUW6vXdSYBXEf8Mfm4NzpU9lqD3h8Xbbq7"
    "AfeU6VV9n3pyyJvTDqu7qHPDVr/2gMHW8qWtrFpTjB3L4xVX8eHGwTy9fhrfTd3B++uGUdLcRRkWMQMil0SHGuFrjCUN5IRIBvgd"
    "0Fwf44N5Q+V3nzjH3PjWLDr8aqRAm6IawSiX8UE7F48vE12bnzJDe87uf+5VtV/t07Nn64IF7YuT6dB0Nwn/i/uC9lTjbY9KZX3/"
    "O0O+eNV/jP5PWEfbkrXZO24Z78y6fQLx2hpGX3UsLYk+WANdwkgpuHQfAF0e1W3LGJzbwBB3DT+98nmiZg1WqWLVssHc8siZNIU1"
    "bOnsR2u6SpIpaIIWpLQw0QGIyaORegcfXPYJY4dobjvlMY6euVgffnWglTMssmVdsPzGG9ac/vuX2zftLRD2igXs7sfvX6uceX/o"
    "++mxp8rL/Lyffe0/I+ENXz/Pnr/mdjYtX875F93PhJ5NPDHvMAI3hl2qMQkDUYNUASKiSJf0pq5kNOvFUG6a9AhuVTuiQrNu03C+"
    "tfDnNIgBZDMGmWk2Mt+s0ZYQkSrk+APR2SS/PvIuTpr2IndftJDMq2ex+PVysW5pSvYaFGT7H9jR56zznC85mcjydz5Mr90bu+z3"
    "CgDde77gijNKjjh7SvrG7Ysa22++ZlLiN49eK1T0dHpXazZtHseOFfO57PKXGRNL8+KqI/D6llM0TFNaK8krSZgEK1lAZjRl2e0c"
    "lXqOtk0OXZuKWLmsmFfWj8fKtEKqS+tAG2MlpKroTThqAibXyc8nfpurrniQ332jk40PX8HwmnKqKKdrZT/e/F2zSqa2esOLd+hR"
    "PYqPf+CVzE9yeWP29I6avdIdvTsCOmFS9DLTslPPfnBibOHKR3VljyWEwRYCrx+9ayO8MfdXRK+5lJt/8DDv9vC5evu9DOifYGZP"
    "jxuXCloaBVpLTODRHNQw5fVHIB8isgV0GBAqCQWlhV2EVRSTurovQVklVZnl3D/tR8yc8QyPfTnBike+xUGDxpBJNmMsSdbdSSI7"
    "gA/vcNTkQS95fYcWyg8fF+v98tz0drmHt7ju8f0B3dGEYdggOzp5mDkn12z0gg0z1fD+DhbQ2LqUZGoj6JABvXvx6oeP8rXrTmRC"
    "dLb8dOYt/LA8x5LtDk1NNjpQCDTKeFhGo6t6o3vUEFTXQmUvVElCW/16STN6vAxHjseUWfK8ot+w8sqLmTnuGX55ZU/W/u6nTB5y"
    "GNKS+CJkdXY+mwprqFSGHqIfy5aXalSaEw6Jnbg33OQepyBLCrSBi08tPfLEo3OXffChk33zo9tUz8pq8oUCXekGPK+DfL4d10nQ"
    "v3d/NjSczAuvOKJ39AkxYdhbYhxbTGFLgbq1glSzQhciaBHFyAjGKYFEGaakCl1ULYztUGZt5uyql3hkyg/N1VN/ydbljfz8m0dL"
    "d9tdZvLQg/CDPFtblrGq+R2dC9pNXERFf1mJq+O0i3Y56fA6q7KktP8Dr6V/5Xl79jYHam/Rz4wjEpci65i3fLoqiY1ACTDaw7Es"
    "bCuCDjLsbFhIId9G3z6jyRRu1TffdhwHP3+nvOS07/GLCXD3oH5yfstBel79YNa0DWBHV0k+rxXK8qlNdDnDy+rlxKplHN5nCfHo"
    "Drl5Gfpn3xhEw+LLmdj3Al07IsGOphUs3/gGTV2riQiXmIghMFoKKSssm80rD5Dbd36aHTAyGHXomFjNOx9ndu5JGlJ7mn60Ngzp"
    "60QPPbxwdle9CVZvOk3VViqCMEcyVYdrx7QSSgoMvta6pWU9mXSz7NVrOEMGTWZdwzP66tveo1/1Uxx38Lv6iAnPcn0/UGOFFCVO"
    "AglIDSmfXAtBRxu89XScT9+fRMemYxhRdjInjDyAXNDBgpVvsmnHhxidIyGKUBgU4Blfdpg01bFiSlJ9Wb60VPc5Nq1PPLJk2jsf"
    "Z37bTUPm3xGA7h3vJx9bfmjkgArn/bdE2stNi5RUwbbGnRB6xO0EWodaGKSwNEoqCl5ab964UCYSm6iuHUpZn6NJ547i/8zezNq2"
    "67n2ioVy83vZzgeeyZ2jXLxcAW/moZHvHTQ1euzi1VHvlZ/OUlPLp+oJvUowUZ+lm19jU8MneIV2HRcujowjjEZhpAW4QpLTBQIR"
    "UGWV0bBgiBKly+T0E0tm3fSTht/6odljEOxRAHab7amnjZsFh7Fg3lpVUdoXIzxSySYidgwppAyFwhiwjJHa+AhL6ECEOpVqll2p"
    "VmLxCDU1A+lbWcmQ0XHdb9rByq9IbnviG/Pf3v1d08/u8fKwmQdPS8UagkFRR8loKwt2vkdzcjuhnyWGo4tlHNuAMloqJApQu7Y4"
    "+dqjy8/Qv6SSrlUHqG3rYt6Iw04+ZNywG8oXrtHtUn4+BZi9BsAf6acX0YlHXTCzeUN7sH3j0aq2BlraWhGBJu7E0TpEC7Q2oQyN"
    "JggNjhRSofCVJus30NLeSGd6AR25vuysb9ehadTtjfZOJUEqSRhompv85kDXBfnWAgtyi1jT8jEZL0mMiC6WxdIxQjoGrdDSReIA"
    "FgKJpRVG2sLSWS8vKQ4p7ezH5jcCr9+4052Tp9999MI1254Re2hpLPck/QCcfFzlIU6ij/PxH1bmlTyGmA2Z9hRxp5ioFSduJXTU"
    "cqVrOTjCwpYKJR2EyRGGDVgyS1GkmEymjHjxUkYO2+RZXaul8ptkoLtD3FCD7xXyylupqtzN+R6jN9HhhZSKUmLKlsbk8UkDnoxh"
    "EcEigiKGIoEloyhKcKQdSpL5JDXxfjS92aoMc5gxY/zl3VuK9owPkHucfmaOuhpeZO0npapHeW9SXZ2owCWuiojICI7lSsdycaSD"
    "Ix1sYWF0B2HYjGsbpF9EMgVHTV+k35j9Uv70o7cVd75v6fseaP8egNHdYeILrybf+/RBb/6wmnTlQ/du1mdcszEIIhkIbIotF0eA"
    "wcMQ/BEAF5sINjEcIrgkRIxCJk8sLpArh6iG1b/xDjwsf/yo/qrImD1zow9rT9GPMTCkpxX50V29HmnausK88ci1skf5AFrrM4jQ"
    "wRYKS1gIKQGDhUQbn5zXjBZJlLTpapOU9NrMjd963fv2lz+MlEc6neefl/d/4fvmmDeXhJuF+FPLZGO7Ljz2pn44n5SrDjugcO7k"
    "GWk14rAgu61eyq5tMVFsIkSUxMIghCGOSxQHG4mDjY3CFS4ylERcm3iqH63VLxcGHL3F2b48+t68pdlNu1Mq+7wFyF0rlxOPKpnk"
    "FK9wFr+RyEftyehsiJWLEZMxHBnF3jX0iIhijEchbMG2Q0y+lHSmwAkXfqB/97unvHPPXRSrW5HZedHXxKTTv69nrd1pUtZn8vW7"
    "U925APPDp/XvD/8yla8/l3tq1LAtidt+s0Gd8L3tQVDRhQ4sotJGAgVRwKCJEMUh0v1jXKJEyKcKFMsEqTmjFUE7M45zLmEP0dAe"
    "ASDUBgmceZJ7Lfku1n80Q1UURci2+USl0o5Q2kKhcLBx8XSSgm5B4ZButakZsILbHng8f/udLzk9Y9tiD97Ndw+9Qgx47D29UIi/"
    "3BKiP1MCXbLVtJ1wM+de9XU9tWXjzs4zLl0V+dJzm4OeJzSRDgJcHcOyJFny+MInIlxcnO6rERHwFZb0ia48RO1cJIKDJ5jTBtbY"
    "7m6g92kKkrvy/oNq7Mht37Ye3bk+1B+9fIdMqFqyraGWu94ghWU0WqTCHXi0k09G8cJtzJg1V3/noTnh8DGfxFa9llt+2TflkXc9"
    "q59LFQgtq5tyzN9R+DHAp5vY+vs3xC9rjBc7/PDWIw6+NCeDAYFXt7AgrWQJRSpKgIdCERVxLLppUWEjpUala2jv/XF+wOEdsfXL"
    "Iq9+sraww7LE/7r/c69awG5HdeIRsfF2UZdaMnd8XpnRBJmg+/6dEqS0ZWg8mWYbvu+RanfoP24e339+Tv4rd/Z34oET+clXzTWT"
    "L5HjX/1Ur9/93IC/Nx2we4KUBdvaTe6827n+vCsYv33hjrpjr0xGLlzc1ys/v0F3BSnsMEbBypEmjUSisHCF1GGgKdZxsh9MkLTm"
    "mHmkuGy3de/TFLSbGk4/Us6iIWTrqlNVQim8bIBSSNeypWdSpPUO0h02JtrIOV+/z/vpk79gwuGfJuY/9fSbh09a1OOG+/R9SV+H"
    "1q7w+x8pjAThn257/+QHesnBp8hB99208+aaiuLYebOHOROfW5NPDt2O51toE5CWyT+CYBmFkiFi1UFO8wahJ48Mz6qtkOrzpiHx"
    "edOPNjCw1nJXz7Y7WxqN+u2Dn1BiRpLJeKAtMmGSlq4MyWyKIVNe0Rdc8qQ3aMjqRGe9l//B3ZxxzzP8wQPzR7r5nBTus50Z08da"
    "A3/6k77PjDimdVzn+sr8+z8fRfrB4arMKyeiLEpNWbd/shSpQCG/85X8hBlNifNvUiN/905h9efZI/S5+gDL6gbg3GMjE2ZOz189"
    "7/1Dsk2bb1COCEEaUvkcjS0QqV7GqbNu964877FIudruPPu0fuALN8ljX/nErAr/uIr+/JsCdjcRb9ypO2Y/3vmArPMbjhneedqw"
    "qS1KTmjPNmx3FfVVSAxRFcFC4gTFtEfrdf8j19phPtbxzPveu3yOrSpyT9DPzEnWpeRg88aTZVxIpPJo71C0dKQYe+JPgm/ecaE3"
    "47iXY9tWpndecLM18cwfmS+ua9ZpZXWb5J4qhnfv8DFYEpIh+qbfmF8fcbGonf9y+5sjhy9LnHDvq7roq3OClkgb7Z4HElwZYi2f"
    "6KQa4OgxweWlcSG13gefUbObF/tUSifzhpOqf9zxf3LsMv/+Y0L/hoGhf8sRr/kfPnZIyuzAmAWY+661bqkpEs5//fzeEiG6LRbA"
    "EULcdKZ1VuZljNnsmE0vDky9OunKwpvc729zXvQXq6f8JT+oypgFtjl+ottrt7XvU6J2XdAVJ0XGmaWYd350aOpH43V4y8gd4W9v"
    "+FIhWRfNmTTm09+qj44bLft/lpv/lfLZ7x/dW5b94Xb5pNmB8Vqj/offnZx7M3Gbv4w5/twzp6XMMsy9Xym6ap8EYHf4+fKd0Z/q"
    "RcL8eMZdmTumv+4ve2dQxhhMfpMy373Yvigmumlvd2i5L4j4jAKB4JoT1bEtC60uYyyz+dPq1OuHXVN4pfybhezb0mx9OrYsYv+N"
    "m2j9Swaw60p6lgu76227o/NNJ3zh9sMzXqvrG4N5/Vfuk2N7WeX7itb/TzQK0L9Uxp663b3X5KXRaRW+feuIzKbH4jmzWJrDRsrK"
    "fWocu7Xn8pPtcXq5bTIfiRbThWmcb3dcMa37Xp27zfbf4elSn6WX845QE+retBpNGybzkWwJl1r+D2apmfyZ1ewj9PPsXdHbTL00"
    "ZpUyj9ysfty3WEb/VU7287CG3ZZdExPu/V+zvmuWW8ZsFWbBI85LYl8z2z5V0g7Xl5p1r0TXnzpRjfhL2vTvKJ+9/pPGW8NX/V6t"
    "MXVRM3awLP6s8v3Ltf/ocXbPX1xXemOZLdVuv/D/yvOVP/uE1hILdfdXir919tGxUfusP7Mk/0/KZ8e1Tw5xXwot96Q17H9a7n7Z"
    "L/tlv+yX/bJf9ss/K/8XdBU3A2k9JogAAAAASUVORK5CYII="
)

if getattr(sys, "frozen", False):
    BASE_DIR = os.path.dirname(sys.executable)
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))

LOG_PATH = os.path.join(BASE_DIR, "nhat-ky-trich-xuat-so-phu.txt")
LOG_OLD = os.path.join(BASE_DIR, "nhat-ky-trich-xuat-so-phu.1.txt")
SETTINGS_PATH = os.path.join(BASE_DIR, "cai-dat.json")
LOG_MAX = 5 * 1024 * 1024

LOG = None
SETTINGS = {}


def _gd167_ico(cs):
    """GD167: bieu tuong cua so = logo UNESCO (AIHoaDon/giao-dien/unesco.ico); thieu tep / loi -> bo qua"""
    try:
        p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "giao-dien", "unesco.ico")
        if os.path.exists(p):
            cs.iconbitmap(default=p)
    except Exception:
        pass


class Ole2:
    def __init__(self, data):
        if data[:8] != b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1":
            raise ValueError("Khong phai file .xls (thieu chu ky OLE2)")
        self.d = data
        self.ssz = 1 << struct.unpack_from("<H", data, 0x1E)[0]
        self.msz = 1 << struct.unpack_from("<H", data, 0x20)[0]
        n_fat = struct.unpack_from("<I", data, 0x2C)[0]
        dir0 = struct.unpack_from("<I", data, 0x30)[0]
        self.cutoff = struct.unpack_from("<I", data, 0x38)[0]
        mini0 = struct.unpack_from("<I", data, 0x3C)[0]
        n_mini = struct.unpack_from("<I", data, 0x40)[0]
        dif0 = struct.unpack_from("<I", data, 0x44)[0]
        n_dif = struct.unpack_from("<I", data, 0x48)[0]

        difat = list(struct.unpack_from("<109I", data, 0x4C))
        sec, cnt = dif0, 0
        per = self.ssz // 4 - 1
        while sec not in (0xFFFFFFFE, 0xFFFFFFFF) and cnt < n_dif + 8:
            raw = self._sect(sec)
            difat += list(struct.unpack_from("<%dI" % per, raw, 0))
            sec = struct.unpack_from("<I", raw, self.ssz - 4)[0]
            cnt += 1

        self.fat = []
        for s in difat[:max(n_fat, 0)]:
            if s in (0xFFFFFFFE, 0xFFFFFFFF):
                continue
            self.fat += list(struct.unpack_from("<%dI" % (self.ssz // 4), self._sect(s), 0))

        self.minifat = []
        sec, cnt = mini0, 0
        while sec not in (0xFFFFFFFE, 0xFFFFFFFF) and cnt < n_mini + 8:
            self.minifat += list(struct.unpack_from("<%dI" % (self.ssz // 4), self._sect(sec), 0))
            sec = self.fat[sec] if sec < len(self.fat) else 0xFFFFFFFE
            cnt += 1

        dir_raw = self._chain(dir0)
        self.entries = []
        for i in range(0, len(dir_raw) - 127, 128):
            e = dir_raw[i:i + 128]
            nlen = struct.unpack_from("<H", e, 0x40)[0]
            if nlen < 2:
                continue
            name = e[:nlen - 2].decode("utf-16-le", "ignore")
            self.entries.append({
                "name": name, "type": e[0x42],
                "start": struct.unpack_from("<I", e, 0x74)[0],
                "size": struct.unpack_from("<I", e, 0x78)[0],
            })
        root = next((e for e in self.entries if e["type"] == 5), None)
        self.mini_stream = self._chain(root["start"]) if root and root["size"] else b""

    def _sect(self, n):
        off = 512 + n * self.ssz
        return self.d[off:off + self.ssz]

    def _chain(self, start, size=None):
        out, s, guard = [], start, 0
        while s not in (0xFFFFFFFE, 0xFFFFFFFF) and guard < 1 << 22:
            out.append(self._sect(s))
            s = self.fat[s] if s < len(self.fat) else 0xFFFFFFFE
            guard += 1
        b = b"".join(out)
        return b[:size] if size else b

    def _minichain(self, start, size):
        out, s, guard = [], start, 0
        while s not in (0xFFFFFFFE, 0xFFFFFFFF) and guard < 1 << 22:
            out.append(self.mini_stream[s * self.msz:(s + 1) * self.msz])
            s = self.minifat[s] if s < len(self.minifat) else 0xFFFFFFFE
            guard += 1
        return b"".join(out)[:size]

    def stream(self, *names):
        for e in self.entries:
            if e["name"] in names:
                if e["size"] < self.cutoff and self.mini_stream:
                    return self._minichain(e["start"], e["size"])
                return self._chain(e["start"], e["size"])
        raise ValueError("Khong tim thay luong du lieu %s trong file" % (names,))


# ===================== BIFF8 =====================
def _rk(v):
    cents = v & 1
    if v & 2:
        n = float(v >> 2)
        if (v >> 2) & 0x20000000:
            n = float((v >> 2) - 0x40000000)
    else:
        n = struct.unpack("<d", struct.pack("<q", (v & 0xFFFFFFFC) << 32))[0]
    return n / 100 if cents else n


class _Cur:
    """Con tro doc xuyen qua cac khoi SST + CONTINUE."""
    def __init__(self, blocks):
        self.b, self.i, self.p = blocks, 0, 0

    def _skip_empty(self):
        while self.i < len(self.b) and self.p >= len(self.b[self.i]):
            self.i += 1
            self.p = 0

    def eof(self):
        self._skip_empty()
        return self.i >= len(self.b)

    def take(self, n):
        out = b""
        while n > 0:
            self._skip_empty()
            if self.i >= len(self.b):
                break
            cur = self.b[self.i]
            k = min(n, len(cur) - self.p)
            out += cur[self.p:self.p + k]
            self.p += k
            n -= k
        return out

    def new_block(self):
        """True neu con tro dang dung dau mot khoi CONTINUE."""
        self._skip_empty()
        return self.p == 0 and self.i > 0

    def u8(self):
        return self.take(1)[0]

    def u16(self):
        d = self.take(2)
        return struct.unpack("<H", d)[0] if len(d) == 2 else 0

    def u32(self):
        d = self.take(4)
        return struct.unpack("<I", d)[0] if len(d) == 4 else 0


def _sst_string(c):
    cch = c.u16()
    flags = c.u8()
    high = flags & 1
    rich = (flags >> 3) & 1
    ext = (flags >> 2) & 1
    nrun = c.u16() if rich else 0
    cbext = c.u32() if ext else 0
    chars, got = [], 0
    while got < cch:
        if c.eof():
            break
        if c.new_block():
            high = c.u8() & 1
        room = len(c.b[c.i]) - c.p
        step = min(cch - got, max(1, room // (2 if high else 1)))
        raw = c.take(step * (2 if high else 1))
        chars.append(raw.decode("utf-16-le" if high else "latin-1", "ignore"))
        got += step
    if nrun:
        c.take(4 * nrun)
    if cbext:
        c.take(cbext)
    return "".join(chars)


def _byte_str(b, off):
    """Chuoi co do dai 1 byte (dung cho BOUNDSHEET)."""
    cch = b[off]
    high = b[off + 1] & 1
    n = cch * (2 if high else 1)
    return b[off + 2:off + 2 + n].decode("utf-16-le" if high else "latin-1", "ignore")


def _short_str(b, off):
    cch = struct.unpack_from("<H", b, off)[0]
    high = b[off + 2] & 1
    n = cch * (2 if high else 1)
    s = b[off + 3:off + 3 + n].decode("utf-16-le" if high else "latin-1", "ignore")
    return s, off + 3 + n


# GD78: BIFF5 (Excel 5.0 / 95) - chuoi 8 bit theo trang ma (record CODEPAGE 0x0042), khong co byte co / bang SST.
#   Chu VNI / TCVN3 luu bang ma 1252 (font chu Viet kieu cu la font "Western") -> doc 1258 nhu 1252.
_CP_BIFF = {932: "cp932", 936: "gbk", 949: "cp949", 950: "cp950", 1250: "cp1250", 1251: "cp1251", 1253: "cp1253",
            1254: "cp1254", 1255: "cp1255", 1256: "cp1256", 1257: "cp1257", 10000: "mac_roman"}
_BANG_1252 = None


def _giai_8bit(b, cp):
    global _BANG_1252
    if cp in _CP_BIFF:
        return bytes(b).decode(_CP_BIFF[cp], "replace")
    if _BANG_1252 is None:
        bang = []
        for x in range(256):
            try:
                bang.append(bytes([x]).decode("cp1252"))
            except UnicodeDecodeError:
                bang.append(chr(x))
        _BANG_1252 = bang
    return "".join(_BANG_1252[x] for x in bytes(b))


def _str5(b, off, cp, dai_byte=2):
    """chuoi BIFF5: do dai 1 / 2 byte + cac byte 8 bit"""
    if off + dai_byte > len(b):
        return "", len(b)
    n = b[off] if dai_byte == 1 else struct.unpack_from("<H", b, off)[0]
    off += dai_byte
    return _giai_8bit(b[off:off + n], cp), off + n


class BangExcel(dict):
    """GD79: {ten sheet: [[o]]} nhu truoc + thong tin phu cho bang luong (cac cho khac dung nhu dict thuong):
      gop      {sheet: [(dong1, cot1, dong2, cot2)]}  o gop (chi so tu 0, ke ca bien)
      an_dong  {sheet: set(chi so dong an)}
      an_sheet set(ten sheet an / an han)
      ct_trong {sheet: so o cong thuc CHUA co gia tri luu (tep do phan mem khac lap, chua mo bang Excel)}"""

    def __init__(self, *a, **k):
        dict.__init__(self, *a, **k)
        self.gop = {}
        self.an_dong = {}
        self.an_sheet = set()
        self.ct_trong = {}


_LOI_XLS = {0x00: "#NULL!", 0x07: "#DIV/0!", 0x0F: "#VALUE!", 0x17: "#REF!", 0x1D: "#NAME?", 0x24: "#NUM!", 0x2A: "#N/A",
            0x2B: "#GETTING_DATA"}


def doc_xls(path):
    """Tra ve {ten_sheet: [[o,...],...]} — moi o la str hoac float hoac None. GD79: kem o gop / dong an / sheet an (BangExcel)."""
    with open(path, "rb") as f:          # GD79: dong tep ngay (Windows khoa tep dang mo)
        ole = Ole2(f.read())
    wb = ole.stream("Workbook", "Book")
    recs, i = [], 0
    while i + 4 <= len(wb):
        t, ln = struct.unpack_from("<HH", wb, i)
        recs.append((t, wb[i + 4:i + 4 + ln]))
        i += 4 + ln

    # GD78: BIFF5 / BIFF7 (BOF phien ban 0x0500) - Excel 5.0 / 95
    biff5, cp = False, 1252
    if recs and recs[0][0] == 0x0809 and len(recs[0][1]) >= 2 and struct.unpack_from("<H", recs[0][1], 0)[0] == 0x0500:
        biff5 = True
    for t, d in recs[:200]:
        if t == 0x0042 and len(d) >= 2:
            cp = struct.unpack_from("<H", d, 0)[0]
            break
    sheets, sst, an_sheet = [], [], set()
    for k, (t, d) in enumerate(recs):
        if t == 0x0085 and len(d) >= 7 and biff5:
            sheets.append([struct.unpack_from("<I", d, 0)[0], _str5(d, 6, cp, 1)[0]])
        elif t == 0x0085 and len(d) >= 8:
            sheets.append([struct.unpack_from("<I", d, 0)[0], _byte_str(d, 6)])
        else:
            continue
        if d[4] & 3:                     # GD79: BOUNDSHEET hsState 1 = an, 2 = an han
            an_sheet.add(sheets[-1][1])
    for k, (t, d) in enumerate(recs):
        if t == 0x00FC:
            blocks = [d[8:]]
            j = k + 1
            while j < len(recs) and recs[j][0] == 0x003C:
                blocks.append(recs[j][1])
                j += 1
            n_uni = struct.unpack_from("<I", d, 4)[0]
            c = _Cur(blocks)
            for _ in range(n_uni):
                if c.eof():
                    break
                sst.append(_sst_string(c))

    # vi tri byte cua tung BOF sheet -> chi so record
    pos, idx = 0, {}
    for n, (t, d) in enumerate(recs):
        idx[pos] = n
        pos += 4 + len(d)

    out = BangExcel()
    for si, (bofpos, name) in enumerate(sheets):
        start = idx.get(bofpos)
        if start is None:
            continue
        end = len(recs)
        for nx in sheets[si + 1:]:
            e = idx.get(nx[0])
            if e:
                end = e
                break
        cells, gop, an = {}, [], set()
        n = start
        while n < end:
            t, d = recs[n]
            if t == 0x00FD and len(d) >= 10:
                r, c, _, isst = struct.unpack_from("<HHHI", d, 0)
                cells[(r, c)] = sst[isst] if isst < len(sst) else ""
            elif t in (0x0204, 0x00D6) and len(d) >= 8 and biff5:
                r, c = struct.unpack_from("<HH", d, 0)
                cells[(r, c)] = _str5(d, 6, cp)[0]          # GD78: LABEL / RSTRING BIFF5
            elif t == 0x0204 and len(d) >= 8:
                r, c = struct.unpack_from("<HH", d, 0)
                cells[(r, c)] = _short_str(d, 6)[0]
            elif t == 0x027E and len(d) >= 10:
                r, c, _, v = struct.unpack_from("<HHHI", d, 0)
                cells[(r, c)] = _rk(v)
            elif t == 0x00BD and len(d) >= 6:
                r, c0 = struct.unpack_from("<HH", d, 0)
                k2, col = 4, c0
                while k2 + 6 <= len(d) - 2:
                    cells[(r, col)] = _rk(struct.unpack_from("<I", d, k2 + 2)[0])
                    k2 += 6
                    col += 1
            elif t == 0x0203 and len(d) >= 14:
                r, c = struct.unpack_from("<HH", d, 0)
                cells[(r, c)] = struct.unpack_from("<d", d, 6)[0]
            elif t == 0x0006 and len(d) >= 16:
                r, c = struct.unpack_from("<HH", d, 0)
                if d[12] == 0xFF and d[13] == 0xFF and d[6] == 0:
                    # GD79: ket qua chuoi nam o record STRING ngay sau - co the cach SHRFMLA / ARRAY / TABLE (cong thuc keo xuong)
                    for m in range(n + 1, min(n + 4, end)):
                        if recs[m][0] == 0x0207:
                            cells[(r, c)] = _str5(recs[m][1], 0, cp)[0] if biff5 else _short_str(recs[m][1], 0)[0]
                            break
                        if recs[m][0] not in (0x04BC, 0x0221, 0x0236):
                            break
                elif d[12] == 0xFF and d[13] == 0xFF and d[6] == 2:
                    cells[(r, c)] = _LOI_XLS.get(d[8], "#VALUE!")          # GD370: cong thuc ra LOI -> giu dau vet (truoc bo trong = 0 im lang)
                elif not (d[12] == 0xFF and d[13] == 0xFF):
                    cells[(r, c)] = struct.unpack_from("<d", d, 6)[0]
            elif t == 0x0205 and len(d) >= 8:
                # GD370: BOOLERR - o hang so loi (#N/A go tay, #REF! sau khi xoa cot) -> chuoi loi; o TRUE/FALSE bo qua
                if d[7] == 1:
                    r, c = struct.unpack_from("<HH", d, 0)
                    cells[(r, c)] = _LOI_XLS.get(d[6], "#VALUE!")
            elif t == 0x0208 and len(d) >= 14:
                # GD79: ROW - co fDyZero (0x20) = dong an
                if struct.unpack_from("<H", d, 12)[0] & 0x20:
                    an.add(struct.unpack_from("<H", d, 0)[0])
            elif t == 0x00E5 and len(d) >= 2:
                # GD79: MERGEDCELLS (BIFF8)
                so = struct.unpack_from("<H", d, 0)[0]
                for q in range(so):
                    o = 2 + 8 * q
                    if o + 8 > len(d):
                        break
                    r1, r2, c1, c2 = struct.unpack_from("<HHHH", d, o)
                    gop.append((r1, c1, r2, c2))
            n += 1
        if cells:
            mr = max(k[0] for k in cells) + 1
            mc = max(k[1] for k in cells) + 1
            out[name] = [[cells.get((r, c)) for c in range(mc)] for r in range(mr)]
        else:
            out[name] = []
        out.gop[name] = gop
        out.an_dong[name] = an
    out.an_sheet = an_sheet
    return out


# ===================== XLSX =====================
def _col(ref):
    n = 0
    for ch in ref:
        if ch.isalpha():
            n = n * 26 + ord(ch.upper()) - 64
        else:
            break
    return n - 1


def _o_tham_chieu(ref):
    """'B12' -> (11, 1)"""
    m = re.match(r"^\$?([A-Za-z]{1,3})\$?(\d+)$", (ref or "").strip())
    if not m:
        return None
    return int(m.group(2)) - 1, _col(m.group(1))


def _chuoi_si(si, ns):
    """chuoi trong sharedStrings: <t> truc tiep hoac cac doan <r><t> (bo <rPh> phien am)"""
    kq = []
    for x in si:
        if x.tag == ns + "t":
            kq.append(x.text or "")
        elif x.tag == ns + "r":
            for t in x.iter(ns + "t"):
                kq.append(t.text or "")
    return "".join(kq)


def doc_xlsx(path):
    """GD79: kem o gop / dong an / sheet an / o cong thuc chua co gia tri (BangExcel); o khong ghi dia chi (r) lay theo thu tu."""
    z = zipfile.ZipFile(path)
    ten_tep = z.namelist()
    ns = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
    rns = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
    rel, tep_ss = {}, "xl/sharedStrings.xml"
    for r in ET.fromstring(z.read("xl/_rels/workbook.xml.rels")):
        dich = (r.get("Target") or "").replace("\\", "/")
        dich = dich.lstrip("/")
        dich = dich[3:] if dich.startswith("xl/") else dich
        rel[r.get("Id")] = dich
        if (r.get("Type") or "").endswith("/sharedStrings") and "xl/" + dich in ten_tep:
            tep_ss = "xl/" + dich            # GD79: ten tep bang chuoi lay theo quan he (co phan mem ghi SharedStrings.xml)
    shared = []
    if tep_ss in ten_tep:
        for si in ET.fromstring(z.read(tep_ss)):
            shared.append(_chuoi_si(si, ns))
    out = BangExcel()
    for sh in ET.fromstring(z.read("xl/workbook.xml")).iter(ns + "sheet"):
        tgt = "xl/" + rel.get(sh.get(rns + "id"), "")
        if tgt not in ten_tep:
            continue
        ten = sh.get("name")
        if (sh.get("state") or "visible") in ("hidden", "veryHidden"):
            out.an_sheet.add(ten)
        goc = ET.fromstring(z.read(tgt))
        rows, mc, an, ct_trong = [], 0, set(), 0
        for row in goc.iter(ns + "row"):
            cur = {}
            ci_truoc = -1
            for c in row.iter(ns + "c"):
                ci = _col(c.get("r")) if c.get("r") else ci_truoc + 1
                ci_truoc = ci
                t, v = c.get("t"), c.find(ns + "v")
                if t == "s":
                    try:
                        k = int(v.text) if v is not None else -1
                    except (TypeError, ValueError):
                        k = -1
                    val = shared[k] if 0 <= k < len(shared) else ""
                elif t == "inlineStr":
                    val = "".join(x.text or "" for x in c.iter(ns + "t"))
                elif v is None or v.text is None:
                    val = None
                    if c.find(ns + "f") is not None:
                        ct_trong += 1
                else:
                    try:
                        val = float(v.text)
                    except (TypeError, ValueError):
                        val = v.text
                cur[ci] = val
                mc = max(mc, ci + 1)
            ri = int(row.get("r")) - 1 if row.get("r") else len(rows)
            while len(rows) <= ri:
                rows.append({})
            rows[ri] = cur
            if (row.get("hidden") or "").lower() in ("1", "true"):
                an.add(ri)
        gop = []
        for m in goc.iter(ns + "mergeCell"):
            ab = (m.get("ref") or "").split(":")
            a = _o_tham_chieu(ab[0]) if ab else None
            b = _o_tham_chieu(ab[-1]) if ab else None
            if a and b:
                gop.append((a[0], a[1], b[0], b[1]))
        out[ten] = [[r.get(c) for c in range(mc)] for r in rows]
        out.gop[ten] = gop
        out.an_dong[ten] = an
        if ct_trong:
            out.ct_trong[ten] = ct_trong
    return out


def doc_excel(path):
    return doc_xlsx(path) if path.lower().endswith((".xlsx", ".xlsm")) else doc_xls(path)


_ESC = {"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;"}
_BAD = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")


def esc(s):
    s = _BAD.sub("", str(s))
    return "".join(_ESC.get(c, c) for c in s)


def col_name(n):
    s = ""
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(65 + r) + s
    return s


# kieu: 0 thuong | 1 tieu de | 2 nen vang | 3 nen do | 4 dam
STYLES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<fonts count="2">
<font><sz val="11"/><name val="Times New Roman"/></font>
<font><b/><sz val="11"/><name val="Times New Roman"/></font>
</fonts>
<fills count="5">
<fill><patternFill patternType="none"/></fill>
<fill><patternFill patternType="gray125"/></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFD9E1F2"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFFFF2CC"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFFCE4E4"/><bgColor indexed="64"/></patternFill></fill>
</fills>
<borders count="2"><border/><border>
<left style="thin"><color rgb="FFBFBFBF"/></left><right style="thin"><color rgb="FFBFBFBF"/></right>
<top style="thin"><color rgb="FFBFBFBF"/></top><bottom style="thin"><color rgb="FFBFBFBF"/></bottom>
</border></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="5">
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1"/>
<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
<xf numFmtId="0" fontId="0" fillId="3" borderId="1" xfId="0" applyFill="1" applyBorder="1"/>
<xf numFmtId="0" fontId="0" fillId="4" borderId="1" xfId="0" applyFill="1" applyBorder="1"/>
<xf numFmtId="0" fontId="1" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1"/>
</cellXfs>
<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
<dxfs count="0"/>
<tableStyles count="0" defaultTableStyle="TableStyleMedium2" defaultPivotStyle="PivotStyleLight16"/>
</styleSheet>"""


def _so(v):
    """Ghi so sao cho Excel khong bao loi (khong dung ky hieu mu)."""
    v = float(v)
    if v != v or v in (float("inf"), float("-inf")):
        return "0"
    if abs(v - round(v)) < 1e-9 and abs(v) < 1e15:
        return str(int(round(v)))
    return ("%.10f" % v).rstrip("0").rstrip(".")


def _sheet_xml(rows, widths, freeze, merges=None):
    """Thu tu the trong worksheet phai dung theo lieu do cua Excel:
       sheetViews -> cols -> sheetData -> mergeCells. Sai thu tu la Excel bao hong file."""
    out = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
           '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">']
    if freeze:
        out.append('<sheetViews><sheetView workbookViewId="0">'
                   '<pane ySplit="%d" topLeftCell="A%d" activePane="bottomLeft" state="frozen"/>'
                   '<selection pane="bottomLeft" activeCell="A%d" sqref="A%d"/>'
                   '</sheetView></sheetViews>' % (freeze, freeze + 1, freeze + 1, freeze + 1))
    else:
        out.append('<sheetViews><sheetView workbookViewId="0"/></sheetViews>')
    if widths:
        out.append("<cols>")
        for i, w in enumerate(widths, 1):
            out.append('<col min="%d" max="%d" width="%.2f" customWidth="1"/>' % (i, i, float(w)))
        out.append("</cols>")
    out.append("<sheetData>")
    for ri, row in enumerate(rows, 1):
        cells = []
        for ci, cell in enumerate(row, 1):
            if isinstance(cell, tuple):
                v, st = cell
            else:
                v, st = cell, 0
            ref = "%s%d" % (col_name(ci), ri)
            if v is None or v == "":
                if st:                      # o trong nhung van phai to mau ca dong
                    cells.append('<c r="%s" s="%d"/>' % (ref, st))
                continue
            if isinstance(v, bool):
                v = str(v)
            if isinstance(v, (int, float)):
                cells.append('<c r="%s" s="%d"><v>%s</v></c>' % (ref, st, _so(v)))
            else:
                cells.append('<c r="%s" s="%d" t="inlineStr"><is><t xml:space="preserve">%s</t></is></c>'
                             % (ref, st, esc(v)))
        if cells:
            out.append('<row r="%d">%s</row>' % (ri, "".join(cells)))
    out.append("</sheetData>")
    if merges:
        out.append('<mergeCells count="%d">%s</mergeCells>'
                   % (len(merges), "".join('<mergeCell ref="%s"/>' % m for m in merges)))
    out.append("</worksheet>")
    return "".join(out)


def ghi_xlsx(path, sheets):
    """sheets = [(ten, rows, widths, freeze)] hoac [(ten, rows, widths, freeze, merges)].
       Moi o = gia_tri hoac (gia_tri, kieu)."""
    sheets = [tuple(s) + ((),) * (5 - len(s)) for s in sheets]
    n = len(sheets)
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml",
                   '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                   '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
                   '<Default Extension="xml" ContentType="application/xml"/>'
                   '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
                   '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
                   + "".join('<Override PartName="/xl/worksheets/sheet%d.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' % (i + 1) for i in range(n))
                   + "</Types>")
        z.writestr("_rels/.rels",
                   '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
                   '</Relationships>')
        z.writestr("xl/workbook.xml",
                   '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
                   'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>'
                   + "".join('<sheet name="%s" sheetId="%d" r:id="rId%d"/>' % (esc(s[0])[:31], i + 1, i + 1)
                             for i, s in enumerate(sheets))
                   + "</sheets></workbook>")
        z.writestr("xl/_rels/workbook.xml.rels",
                   '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   + "".join('<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet%d.xml"/>' % (i + 1, i + 1) for i in range(n))
                   + '<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>' % (n + 1)
                   + "</Relationships>")
        z.writestr("xl/styles.xml", STYLES)
        for i, (name, rows, widths, freeze, merges) in enumerate(sheets):
            z.writestr("xl/worksheets/sheet%d.xml" % (i + 1),
                       _sheet_xml(rows, widths, freeze, merges))
    return path


_SECRET = ("password", "matkhau", "mat_khau", "pass", "pwd", "token", "apikey",
           "api_key", "authorization", "bearer", "cccd", "cmnd", "sotaikhoan")


def mask_tail(v):
    s = str(v)
    return "*" * len(s) if len(s) <= 3 else "*" * (len(s) - 3) + s[-3:]


def scrub(text):
    try:
        s = str(text)
    except Exception:
        return "<khong doc duoc>"
    try:
        for k in _SECRET:
            s = re.sub(r'("%s"\s*:\s*")([^"]*)(")' % re.escape(k),
                       lambda m: m.group(1) + mask_tail(m.group(2)) + m.group(3), s, flags=re.I)
            s = re.sub(r'(\b%s=)([^&\s"\']+)' % re.escape(k),
                       lambda m: m.group(1) + mask_tail(m.group(2)), s, flags=re.I)
        s = re.sub(r"(?<!\d)(\d{9,25})(?!\d)", lambda m: mask_tail(m.group(1)), s)
    except Exception:
        return "<loi che thong tin>"
    return s


class NhatKy:
    def __init__(self, path, old, maxb):
        self.path, self.old, self.maxb = path, old, maxb
        self.lock = threading.Lock()
        self.dong = []

    def _xoay(self):
        try:
            if os.path.exists(self.path) and os.path.getsize(self.path) > self.maxb:
                if os.path.exists(self.old):
                    os.remove(self.old)
                os.rename(self.path, self.old)
        except Exception:
            pass

    def ghi(self, msg, che=True):
        t = datetime.now().strftime("%H:%M:%S")
        line = t + "  " + (scrub(msg) if che else str(msg))
        with self.lock:
            self.dong.append(line)
            if len(self.dong) > 4000:
                self.dong = self.dong[-2000:]
            try:
                self._xoay()
                with open(self.path, "a", encoding="utf-8") as f:
                    f.write(datetime.now().strftime("%Y-%m-%d ") + line + "\n")
            except Exception:
                pass

    def loi(self, msg, e):
        self.ghi("LOI: %s | %s" % (msg, e))
        try:
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(scrub(traceback.format_exc()) + "\n")
        except Exception:
            pass

    def phan_cach(self, t):
        self.ghi("=" * 20 + " " + t + " " + "=" * 20, che=False)


# ==========================================================================
#  CHUYEN FONT VNI CU SANG UNICODE
# ==========================================================================
CIRC, BREVE, ACUTE, GRAVE, TILDE, HOOK, DOT = (
    "\u0302", "\u0306", "\u0301", "\u0300", "\u0303", "\u0309", "\u0323")
MARK = {"Â": CIRC, "â": CIRC, "Ê": BREVE, "ê": BREVE, "Ù": ACUTE, "ù": ACUTE,
        "Ø": GRAVE, "ø": GRAVE, "Õ": TILDE, "õ": TILDE, "Û": HOOK, "û": HOOK,
        "Ï": DOT, "ï": DOT,
        "À": CIRC + GRAVE, "à": CIRC + GRAVE, "Á": CIRC + ACUTE, "á": CIRC + ACUTE,
        "Ã": CIRC + TILDE, "ã": CIRC + TILDE, "Å": CIRC + HOOK, "å": CIRC + HOOK,
        "Ä": CIRC + DOT, "ä": CIRC + DOT,
        "È": BREVE + GRAVE, "è": BREVE + GRAVE, "É": BREVE + ACUTE, "é": BREVE + ACUTE,
        "Ë": BREVE + TILDE, "ë": BREVE + TILDE, "Ç": BREVE + HOOK, "ç": BREVE + HOOK,
        "Ð": BREVE + DOT, "ð": BREVE + DOT}
LETTER = {"Ñ": "Đ", "ñ": "đ", "Ö": "Ư", "ö": "ư", "Ô": "Ơ", "ô": "ơ"}
LE = {"Ì": "Ì", "ì": "ì", "Í": "Í", "í": "í", "Ò": "Ị", "ò": "ị",
      "Ó": "Ĩ", "ó": "ĩ", "Æ": "Ỉ", "æ": "ỉ"}


def vni2uni(s):
    if not isinstance(s, str) or not s:
        return ""
    for ch in s:
        if ord(ch) > 255:
            return s
    out = []
    for ch in s:
        out.append(LETTER.get(ch) or MARK.get(ch) or LE.get(ch) or ch)
    return unicodedata.normalize("NFC", "".join(out))


def bo_dau(s):
    s = str(s or "").replace("Đ", "D").replace("đ", "d")
    return "".join(c for c in unicodedata.normalize("NFD", s)
                   if unicodedata.category(c) != "Mn")


FORMS = ["CONG TY CO PHAN", "CTCP", "CONG TY TNHH MTV", "CONG TY TNHH MOT THANH VIEN",
         "CONG TY TNHH", "CONG TY CP", "CONG TY", "CTY TNHH MTV", "CTY TNHH", "CTY CP",
         "CTY", "CT TNHH", "CT CP", "DNTN", "DOANH NGHIEP TU NHAN", "HO KINH DOANH",
         "HKD", "TNHH", "MTV", "MOT THANH VIEN", "CO PHAN"]
NOISE = ["SAN XUAT THUONG MAI DICH VU", "SAN XUAT THUONG MAI", "THUONG MAI DICH VU",
         "XUAT NHAP KHAU", "SAN XUAT", "THUONG MAI", "DICH VU", "TMDV", "SXTM",
         "SX TM XNK", "SX TM", "TM XNK", "XNK", "TM DV", "SX", "DV"]


VIET_TAT = [("TMDV", "THUONG MAI DICH VU"), ("SXTM", "SAN XUAT THUONG MAI"),
            ("XNK", "XUAT NHAP KHAU"), ("TM", "THUONG MAI"), ("DV", "DICH VU"),
            ("SX", "SAN XUAT"), ("TH", "TONG HOP")]


def chuan(s, bo_loai_hinh=True, vni=False):
    if not isinstance(s, str) or not s:
        return ""
    t = vni2uni(s) if vni else s
    t = re.sub(r"[^A-Z0-9 ]+", " ", bo_dau(t).upper())
    t = re.sub(r"\s+", " ", t).strip()
    for a, b in VIET_TAT:                       # gian viet tat de hai ben so khop duoc
        t = re.sub(r"\b%s\b" % a, b, t)
    t = re.sub(r"\s+", " ", t).strip()
    if bo_loai_hinh:
        doi = True
        while doi:
            doi = False
            for f in FORMS:
                if t.startswith(f + " "):
                    t, doi = t[len(f) + 1:].strip(), True
        for n in NOISE:
            if t.startswith(n + " "):
                t = t[len(n) + 1:].strip()
                break
        for suf in (" VIET NAM", " VN"):
            if t.endswith(suf):
                t = t[:-len(suf)].strip()
    return re.sub(r"\s+", " ", t).strip()


def chuan_mst(x):
    if x is None:
        return ""
    if isinstance(x, float):
        x = "%d" % int(x)
    return re.sub(r"[^0-9]", "", str(x).split("-")[0]).lstrip("0")


# GD21 - MST Viet Nam co SO KIEM TRA o chu so thu 10:
#   tong = sum(chu so 1..9 x [31,29,23,19,17,13,7,5,3]); chu so 10 = 10 - (tong mod 11)
# Dung no de khong nham so tai khoan / ma giao dich 10 chu so thanh MST.
_TRONG_SO_MST = (31, 29, 23, 19, 17, 13, 7, 5, 3)


def la_mst(x):
    t = re.sub(r"\D", "", str(x or ""))
    if len(t) == 13:
        t = t[:10]
    if len(t) != 10:
        return False
    tong = sum(int(t[i]) * _TRONG_SO_MST[i] for i in range(9))
    kt = 10 - (tong % 11)
    return kt <= 9 and kt == int(t[9])


def so(x):
    if x is None or x == "":
        return 0.0
    if isinstance(x, (int, float)):
        return float(x)
    try:
        return float(str(x).replace(",", "").replace(" ", ""))
    except ValueError:
        return 0.0


def tien(n):
    return "{:,.0f}".format(n).replace(",", ".") if n else ""


def diem(a, b):
    return SequenceMatcher(None, a, b).ratio() * 100


def diem_tu(a, b):
    ta, tb = set(a.split()), set(b.split())
    if not ta or not tb:
        return 0.0
    it = sorted(ta & tb)
    ra, rb = sorted(ta - tb), sorted(tb - ta)
    s1 = " ".join(it)
    s2 = (s1 + " " + " ".join(ra)).strip()
    s3 = (s1 + " " + " ".join(rb)).strip()
    return max(diem(s1, s2), diem(s1, s3), diem(s2, s3), diem(a, b))


# ==========================================================================
#  BOC TEN DOI TAC TU DIEN GIAI
# ==========================================================================
VERBS = (r"chuyen\s*tien|chuyen\s*khoan|chuyen\b|thanh\s*toan|tt\b|tra\s*tien|"
         r"tra\s*luong|nop\b|ck\b|hoan\s*tien|gui\s*tien|tra\s*no|hd\b|hoa\s*don")
RAC = {"TRANSFER", "IBFT", "NOT PROVIDED", "NA", "CHUYEN TIEN", "THANH TOAN",
       "CK", "TT", "HD", "ND", "MBBANK IBFT", "MBBANK", "NGAN HANG", "IBPS",
       "NAPAS", "VIETQR", "QR CODE", "CKRUTGON", "MB BANK", "CHUYEN KHOAN",
       "GHI CO", "GHI NO", "NOP TIEN", "RUT TIEN",
       "MBCT", "TTTM", "TT TM", "MBVCB", "MB", "VCB", "BIDV", "TCB", "STB", "ACB", "VPB", "MBBIZ",   # GD191: tien to lenh chuyen
       "CTY SX", "CONG TY SX", "CTY", "CONG TY", "CTY TNHH", "CONG TY TNHH", "CTY CP", "CONG TY CO PHAN"}

# Ma tham chieu cua ngan hang hay bi nham la ten nguoi: EB3741004222, FT26245001,
# 6008TPBV2MKCAS9... Dac diem chung: rat nhieu chu so trong mot cum khong dau cach.
def _ten_la_rac(c):
    u = re.sub(r"[^A-Za-z0-9]", "", bo_dau(c).upper())
    if not u:
        return True
    if c.strip().upper() in RAC:
        return True
    if re.search(_NH_RX, bo_dau(c).upper()):
        return True
    so = sum(1 for k in u if k.isdigit())
    if so >= 6:
        return True
    if so and so * 2 >= len(u):
        return True
    if re.match(r"^[A-Z]{0,4}\d", u) and so >= 4:
        return True
    # chi con lai toan phu am / qua ngan sau khi bo so
    return len(re.sub(r"\d", "", u)) < 4


# Ten ngan hang KHONG BAO GIO la doi tac - mot khoan phi khong phai
# mot lan mua hang cua ngan hang.
_NH_RX = (r"NGAN\s*HANG|MBBANK|MB\s*BANK|VIETCOMBANK|VIETINBANK|SACOMBANK|TECHCOMBANK|"
          r"AGRIBANK|EXIMBANK|TPBANK|VPBANK|HDBANK|SEABANK|ABBANK|OCEANBANK|SHINHAN|"
          r"\bTMCP\b|\bBIDV\b|\bVIB\b|\bSHB\b|\bMSB\b|\bOCB\b|\bACB\b")

# Duoi dong tu bi dinh vao ten: "BUI TAN DUNG chuyen tien hang" -> "BUI TAN DUNG"
_DUOI_RX = (r"\s+(?:CHUYEN\s*TIEN|CHUYEN\s*KHOAN|CHUYEN|THANH\s*TOAN|TRA\s*TIEN|TRA\s*NO|"
            r"NOP\s*TIEN|THU\s*TIEN|TT\s*HD|TT|CK|TTHD|HOAN\s*TIEN|HOAN\s*TRA|GUI\s*TIEN|UNG\s*TIEN)\b.*$")

# GD191: duoi "rac" cua sao ke dinh sau ten doi tac: ma giao dich MB (D2PQK16N/726212), "Ma giao dich/ Trace 983478",
#   "lan 2", "ngay 05-09-2026", ma tham chieu, so hoa don
_DUOI_RAC_RX = (r"\s+(?:D2[A-Z0-9]{6}/\d+|Ma\s*giao\s*dich.*|Trace\s*\d+.*|lan\s*\d+\b.*|ngay\s*\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4}.*|"
                r"so\s*\d+.*|hd\s*\d+.*|mst\s*\d+.*|\d{6,}.*|[A-Z0-9]{8,}/\d+.*)$")
_LOAI_HINH = r"(?:cong\s*ty|cty|ct|dntn|hkd|ho\s*kinh\s*doanh|cn|chi\s*nhanh|hop\s*tac\s*xa|htx)"
_TU_DUNG = r"(?:cua|cho|tu|den|toi|voi|boi|cty|cong\s*ty|ct)\b"


def _bo_lap(n):
    """"CONG TY A CONG TY A" -> "CONG TY A" (sao ke hay lap ten nguoi chuyen hai lan)."""
    t = n.split()
    for k in range(len(t) // 2, 1, -1):
        if t[:k] == t[k:2 * k]:
            return " ".join(t[k:]) if len(t) > 2 * k else " ".join(t[:k])
    return n


def _lam_sach(x):
    n = re.sub(r"\s+", " ", x).strip(" -.,")
    n = re.sub(r"^(QR|VCB|STB|ACB|MB|BIDV|TCB|VPB)\s*[-,]\s*", "", n, flags=re.I)
    n = re.sub(r"\b(CKN|FT\d+|MBVCB\S*|IBPS)\b.*$", "", n, flags=re.I).strip(" -.,")
    n = re.sub(_DUOI_RX, "", " " + n, flags=re.I).strip(" -.,")
    n = re.sub(_DUOI_RAC_RX, "", " " + n, flags=re.I).strip(" -.,/")          # GD191
    n = _bo_lap(n)
    return n.strip(" -.,")


def boc_ten(d):
    """Tra ve danh sach ung vien ten: ten chu tai khoan VA ten dau dien giai."""
    out = []

    def them(t):
        c = _lam_sach(t)
        if c and len(c) >= 4 and not _ten_la_rac(c) and c not in out:
            out.append(c)

    m = re.search(r"-\s*([^-]{3,60}?)\s*-\s*Ngan\s*hang", d, re.I)
    if m:
        them(m.group(1))
    m = re.match(r"^([A-Za-zÀ-ỹ][A-Za-zÀ-ỹ0-9.,\s&]{3,55}?)\s+(?:" + VERBS + ")", d, re.I)
    if m and not re.match(r"^\d", _lam_sach(m.group(1))):
        them(m.group(1))
    m = re.match(r"^([A-Za-zÀ-ỹ][A-Za-zÀ-ỹ0-9.,\s&]{3,50}?)\s+(?:FT\d|CKN|MBBIZ|MBVCB|EWX)", d, re.I)
    if m:
        them(m.group(1))
    m = re.search(r"^[A-Z]{2,4}\s*,\s*\d{6,}\s*,\s*(.+?)\s+(?:" + VERBS + ")", d, re.I)
    if m:
        them(m.group(1))
    # GD191: "MB 3997996666 TRINH THI YEN NGHI chuyen tien" (ma NH + so TK cua MINH roi ten nguoi chuyen)
    m = re.match(r"^(?:MB|VCB|STB|ACB|BIDV|TCB|VPB|TPB|MSB|HDB|VIB|SHB|OCB|EIB|SCB)\s+\d{8,16}\s+([A-Za-zÀ-ỹ][A-Za-zÀ-ỹ .&\-]{3,55}?)\s+(?:" + VERBS + ")", d, re.I)
    if m:
        them(m.group(1))
    m = re.search(r"CT\s+tu\s+\d{6,}\s+(.+?)\s+toi\s+\d{6,}", d, re.I)
    if m:
        them(m.group(1))
    m = re.search(r"^QR\s*-\s*(.+?)\s+(?:" + VERBS + ")", d, re.I)
    if m:
        them(m.group(1))
    m = re.search(r"^EWX\d+\s+(.+?)\s+(?:" + VERBS + ")", d, re.I)
    if m:
        them(m.group(1))
    m = re.search(r"IBPS\.(.+?)\s+(?:" + VERBS + ")", d, re.I)
    if m:
        them(m.group(1))
    m = re.match(r"^(.{4,55}?)\s+MBBIZ\d+", d, re.I)
    if m:
        them(m.group(1))
    # "....P.HKD Van kim thanh thanh toan hoa don so 9" - ho kinh doanh viet tat
    m = re.search(r"\b(?:P\.)?(HKD|HO KINH DOANH|CTY|CONG TY|DNTN)[\s.]+(.{3,50}?)\s+(?:" + VERBS + ")", d, re.I)
    if m:
        them(m.group(1) + " " + m.group(2))
        them(m.group(2))
    # GD191: "thanh toan hd 9685 cua cty bb Tan phong - Ma giao dich", "tien dau cty cuong thinh D2PQK16N/726212",
    #   "hd 136 cty dv co khi Nhat Tan", "tt hd so 328 ngay 05-09-2026 lan 01 cua cty cp co khi Duc Huy"
    for m in re.finditer(r"\b(?:cua|cho|tu|den|toi)\s+(" + _LOAI_HINH + r"\s+[A-Za-zÀ-ỹ][A-Za-zÀ-ỹ0-9 .&\-]{2,60}?)"
                         r"(?=\s*-|\s+(?:D2[A-Z0-9]{6}/|Ma\s*giao|Trace|lan\s*\d|ngay\s*\d|so\s*\d|hd\s*\d|mst|tk|stk|thang|ky)\b|\s*$)", d, re.I):
        them(m.group(1))
    m = re.search(r"\b(?:cua|cho)\s+([A-Za-zÀ-ỹ][A-Za-zÀ-ỹ .&\-]{3,50}?)(?=\s*-|\s+(?:D2[A-Z0-9]{6}/|Ma\s*giao|Trace|lan\s*\d|ngay\s*\d|so\s*\d|hd\s*\d|mst|thang|ky)\b|\s*$)", d, re.I)
    if m:
        them(m.group(1))
    m = re.search(r"\b(" + _LOAI_HINH + r"\s+(?:[A-Za-zÀ-ỹ][A-Za-zÀ-ỹ&\-]*\s+){1,6}?[A-Za-zÀ-ỹ][A-Za-zÀ-ỹ&\-]*)(?=\s+(?:D2[A-Z0-9]{6}/|Ma\s*giao|Trace|lan\s*\d|ngay\s*\d|so\s*\d|hd\s*\d|mst|tk|thang|ky|\d{5,})\b|\s*-|\s*$)", d, re.I)
    if m:
        them(m.group(1))
    # ten dung cuoi dien giai sau dau gach: "... CKN 725866 - NGUYEN NGOC HUE"
    m = re.search(r"-\s*([A-Za-zÀ-ỹ][A-Za-zÀ-ỹ .,&]{5,60})\s*$", d)
    if m:
        them(m.group(1))
    return out


def loai_gd(d):
    u = bo_dau(d).upper()
    if "KBNN" in u or "NTDT+KB" in u or re.search(r"\bNTDT\b|NOP NSNN|KHO BAC NHA NUOC", u):
        return "NOP_THUE"
    if re.search(r"\bTRA LUONG|\bLUONG THANG\b|\bLUONG T\d|THANH TOAN LUONG|CHI LUONG|"
                 r"LENH CHI LUONG|CHI TRA LUONG|\bTT LUONG\b", u):
        return "LUONG"
    if re.search(r"LAI NHAP VON|CHI LAI TK TIEN GUI|LAI NHAP GOC|LAI TIEN GUI|"
                 r"\bLAI KKH\b|TRA LAI TIEN GUI|\bLAI TG\b", u):
        return "LAI_TG"
    # GD27: tren sao ke that phi hay viet tat "PHI MB", "PHI CT", "PHI CK NHANH",
    # "Thu phi chuyen khoan ngoai HT" - bo mau cu bo sot het.
    if re.search(r"\bCP\d\d\b|PHI DICH VU|PHI QUAN LY|PHI SMS|PHI THUONG NIEN|THU PHI|"
                 r"\bPHI (MB|CT|CK|DV|GD|NH|TN|NCC|RUT|NOP)\b|PHI CHUYEN (TIEN|KHOAN)|"
                 r"PHI NGAN HANG|PHI DUY TRI|PHI TIN NHAN|PHI THU HO|\bVAT PHI\b", u):
        return "PHI_NH"
    if re.search(r"NOP TM|NOP TIEN MAT|NOP TIEN VAO TK", u):
        return "NOP_TM"
    if re.search(r"RUT TM|RUT TIEN MAT|RUT TKTK|RUT TK TIET KIEM", u):
        return "RUT_TM"
    if re.search(r"TIEN KHO|THUE KHO|TIEN NHA XUONG", u):
        return "THUE_KHO"
    return ""


def thang_luong(d):
    u = bo_dau(d).lower()
    m = (re.search(r"luong\s*thang\s*0?(\d{1,2})", u) or
         re.search(r"luong\s*t\s*0?(\d{1,2})", u) or
         re.search(r"thang\s*0?(\d{1,2})", u))
    if not m:
        return None
    n = int(m.group(1))
    return n if 1 <= n <= 12 else None


def _sach_dau_vet(d):
    """Bo cac chuoi tham chieu cua ngan hang de khong nham voi so hoa don."""
    s = " " + bo_dau(d) + " "
    s = re.sub(r"-\d{6}-\d\d:\d\d:\d\d.*$", " ", s)
    s = re.sub(r"\bCKN\s*\d+.*$", " ", s, flags=re.I)
    s = re.sub(r"\bFT\d{6,}\b", " ", s, flags=re.I)
    s = re.sub(r"\bEWX\d+\b", " ", s, flags=re.I)
    s = re.sub(r"\bMBVCB[.\d]*", " ", s, flags=re.I)
    s = re.sub(r"\bIBPS\b.*$", " ", s, flags=re.I)
    s = re.sub(r"\b\d{9,}\b", " ", s)          # so tai khoan, MST
    s = re.sub(r"(\d)(NGAY|HD)", r"\1 \2", s, flags=re.I)
    s = re.sub(r"(NGAY|HD)(\d)", r"\1 \2", s, flags=re.I)
    return s


_NGAY = [
    r"ngay\s*(\d{1,2})\s*[/.\-]\s*(\d{1,2})\s*[/.\-]\s*(\d{2,4})",
    r"ngay\s*(\d{2})(\d{2})(\d{4})\b",
    r"ngay\s*(\d{1,2})\s*[/.\-]\s*(\d{1,2})()",
    r"\b(\d{1,2})/(\d{1,2})/(\d{4})\b",
    r"\b(\d{1,2})-(\d{1,2})-(\d{2,4})\b",
]


def truy_vet(d):
    """Bóc số hóa đơn (kể cả nhiều số và dải số) + ngày ghi trong diễn giải."""
    s = _sach_dau_vet(d)
    ngay = ""
    for p in _NGAY:
        m = re.search(p, s, re.I)
        if m:
            dd, mm, yy = m.group(1), m.group(2), (m.group(3) or "")
            if yy and len(yy) == 2:
                yy = "20" + yy
            if int(mm) > 12 >= int(dd):
                dd, mm = mm, dd
            ngay = "%02d/%02d/%s" % (int(dd), int(mm), yy) if yy else "%02d/%02d" % (int(dd), int(mm))
            s = s[:m.start()] + " " + s[m.end():]
            break
    s = re.sub(r"\b\d{1,2}\s*[/.\-]\s*\d{1,2}(\s*[/.\-]\s*\d{2,4})?\b", " ", s)

    nums, dai = [], False
    m = re.search(r"tu\s*0*(\d{1,5})\s*(?:den|->|-)\s*0*(\d{1,5})", s, re.I)
    if m:
        a, b = int(m.group(1)), int(m.group(2))
        if 0 < b - a < 500:
            nums = [str(x) for x in range(a, b + 1)]
            dai = True
    if not nums:
        # GD21: dang "ky hieu + so" hay gap tren sao ke: "1C26TAA 00001234", "C26TYY-123".
        # Phai xet TRUOC, neu khong thi "hoa don 1C26TAA" bi doc nham thanh so hoa don "1".
        for m in re.finditer(r"\b\d?[A-Z]{1,2}\d{2}[A-Z]{2,3}\b\s*[-/]?\s*0*(\d{1,8})\b", s, re.I):
            v = m.group(1).lstrip("0") or "0"
            if v != "0" and v not in nums:
                nums.append(v)
        s = re.sub(r"\b\d?[A-Z]{1,2}\d{2}[A-Z]{2,3}\b\s*[-/]?\s*0*\d{1,8}\b", " ", s, flags=re.I)
    if not nums:
        def gom(chuoi):
            for x in re.findall(r"\d+", chuoi):
                v = x.lstrip("0") or "0"
                if v != "0" and len(v) <= 5 and v not in nums:
                    nums.append(v)
        for m in re.finditer(r"\b(?:tthd|hd|hoa\s*don|don|so|inv|invoice)\b\s*[:#]?\s*"
                             r"((?:0*\d{1,5}[\s,;+]+){0,6}0*\d{1,5})(?![A-Za-z])", s, re.I):
            gom(m.group(1))
        for m in re.finditer(r"((?:0*\d{1,5}[\s,;]+){1,6})(?:tthd|hd|inv)\b", s, re.I):
            gom(m.group(1))
    return {"hd": nums[:40], "dai": dai, "ngay": ngay}


def so_hoa_don(d):
    n = truy_vet(d)["hd"]
    return n[0] if n else ""


TK_LOAI = {"LUONG": "334", "LAI_TG": "515", "PHI_NH": "6425",
           "NOP_TM": "1111", "RUT_TM": "1111", "NOP_THUE": "3339"}
TK_NHAN = {"LAI_TG": "Lãi tiền gửi", "PHI_NH": "Phí ngân hàng",
           "NOP_TM": "Nộp tiền mặt vào TK", "RUT_TM": "Rút tiền mặt từ TK",
           "NOP_THUE": "Nộp thuế / NSNN", "THUE_KHO": "Tiền thuê kho"}
TAP_TK = {"1311", "3311", "334", "515", "6425", "1111", "3339"}


# ==========================================================================
#  DOC TUNG LOAI FILE
# ==========================================================================
def _sa(x):
    return bo_dau(str(x or "")).lower().strip()


def doc_danh_muc(path, log):
    tab = doc_excel(path)
    ten_sheet = next((s for s in tab if re.search(r"khach\s*hang", s, re.I)), list(tab)[0])
    A = tab[ten_sheet]
    hK = next((i for i, r in enumerate(A)
               if any(re.search(r"so hieu|^ma kh|ma khach|ma doi tuong", _sa(c)) for c in r)), 2)
    H = [_sa(c) for c in A[hK]]

    def tim(rx, mac):
        for i, c in enumerate(H):
            if re.search(rx, c):
                return i
        return mac

    iMa = tim(r"so hieu|^ma kh|ma khach|ma doi tuong", 2)
    iTen = tim(r"^ten$|^ten kh|ten khach|ten doi tuong|^ho ten|^ten don vi", 3)
    iMst = tim(r"ma so thue|^mst", 4)
    iDC = tim(r"dia chi", 5)
    iPL = tim(r"phan loai|^nhom", 1)
    iTk = next((i for i, c in enumerate(H) if "tai khoan" in c and "ngan hang" not in c), 14)
    log.ghi("Danh muc: tieu de dong %d; cot ma=%d ten=%d MST=%d TK=%d"
            % (hK + 1, iMa + 1, iTen + 1, iMst + 1, iTk + 1), che=False)

    RAC_MA = {"#", "...", "#0000000000", "#7723952", "0"}
    dm = []
    for r in A[hK + 1:]:
        if len(r) <= max(iMa, iTen):
            continue
        ma, ten = r[iMa], r[iTen]
        if not ma or not ten:
            continue
        ms = str(ma).strip()
        if ms in RAC_MA or ms.startswith("#") or str(ten).strip() in RAC_MA:
            continue
        gv = lambda i: r[i] if i < len(r) else None
        dm.append({
            "ma": ms, "ten": vni2uni(str(ten)).strip(),
            "ten_chuan": chuan(str(ten), True, True),
            "mst": chuan_mst(gv(iMst)) if gv(iMst) and str(gv(iMst)) != "..." else "",
            "diachi": vni2uni(str(gv(iDC))) if gv(iDC) and str(gv(iDC)) != "..." else "",
            "phan_loai": str(gv(iPL)).strip() if gv(iPL) else "",
            "tk": str(gv(iTk)).strip() if gv(iTk) else "", "moi": False,
        })
    return dm


def doc_bang_luong(path, log):
    tab = doc_excel(path)
    thang = {}
    for sh, A in tab.items():
        m = re.search(r"(\d{1,2})", bo_dau(sh))
        if not m or not A:
            continue
        hr = next((i for i, r in enumerate(A)
                   if any("ho va ten" in _sa(c) for c in r)), 2)
        iN = next((i for i, c in enumerate(A[hr]) if "thuc nhan" in _sa(c)), 13)
        ds = []
        for r in A[hr + 1:]:
            if len(r) < 2 or not isinstance(r[1], str) or not r[1].strip():
                continue
            if _sa(r[1]) == "tong":
                continue
            net = round(so(r[iN] if iN < len(r) else 0))
            if net:
                ds.append({"ten": r[1].strip(), "ten_chuan": chuan(r[1]), "net": net})
        if ds:
            thang[int(m.group(1))] = ds
    log.ghi("Bang luong: %d thang, %d dong thuc nhan"
            % (len(thang), sum(len(v) for v in thang.values())), che=False)
    return thang


def doc_hoa_don(path, i_mst, i_ten, i_dc, loai):
    A = doc_excel(path)
    A = A[list(A)[0]]
    ra = []
    for r in A[1:]:
        if len(r) < 3 or not r[2]:
            continue
        ra.append(r)
    return ra


def doc_so_phu(path, log):
    tab = doc_excel(path)
    sh = next((s for s in tab if re.search(r"so\s*phu|sophu", s, re.I)), list(tab)[0])
    S = tab[sh]
    hR = next((i for i, r in enumerate(S)
               if any(re.search(r"di.n gi.i|description", str(c or ""), re.I) for c in r)), 11)
    gv = lambda i, j: S[i][j] if i < len(S) and j < len(S[i]) else None
    info = {"so_tk": gv(5, 2), "chu_tk": gv(6, 2), "du_dau": gv(8, 2),
            "ky1": gv(1, 3), "ky2": gv(2, 3)}
    tx, ft = [], []
    for r in S[hR + 1:]:
        if not r or not r[0]:
            continue
        a = str(r[0]).strip()
        if isinstance(r[0], float):
            a = "%d" % int(r[0])
        g = lambda j: r[j] if j < len(r) else None
        if not a.isdigit():
            ft.append({"nhan": a, "debit": g(5), "credit": g(6), "sodu": g(7)})
            continue
        tx.append({"stt": int(a), "ngay_gd": g(1), "ngay_hl": g(2), "so_gd": g(3),
                   "dg": str(g(4) or "").strip(), "debit": g(5), "credit": g(6), "sodu": g(7)})
    log.ghi("So phu: %d giao dich, %d dong tong cong cuoi bang" % (len(tx), len(ft)), che=False)
    return info, tx, ft


def chay_khop(duong, duyet_tay, log, bao):
    bao("Đang đọc danh mục khách hàng…", 5)
    dm = doc_danh_muc(duong["kh"], log)
    n_tm = sum(1 for d in dm if d["phan_loai"] == "TM")
    log.ghi("Danh muc: %d doi tac, trong do %d nhom TM" % (len(dm), n_tm), che=False)

    bao("Đang đọc bảng lương…", 12)
    luong = doc_bang_luong(duong["luong"], log) if duong.get("luong") else {}

    bao("Đang đọc bảng kê hóa đơn…", 20)
    hdp = {}
    hd_ban, hd_mua = {}, {}
    hdt_ban, hdt_mua = {}, {}
    tien_ban, tien_mua = {}, {}
    mst_ban, mst_mua = {}, {}

    def nap(path, i_mst, i_ten, i_dc, loai, H, HT, T, MS):
        if not path:
            return
        for r in doc_hoa_don(path, i_mst, i_ten, i_dc, loai):
            g = lambda j: r[j] if j < len(r) else None
            ten = g(i_ten)
            if not ten:
                continue
            k = chuan(str(ten))
            e = hdp.setdefault(k, {"ten": str(ten).strip(), "mst": "", "loai": loai,
                                   "diachi": str(g(i_dc) or "")})
            ms = chuan_mst(g(i_mst))
            if ms and not e["mst"]:
                e["mst"] = ms
            if loai == "NCC":
                e["loai"] = "NCC"
            sohd = str(g(2)).strip().lstrip("0")
            if isinstance(g(2), float):
                sohd = "%d" % int(g(2))
            tt = round(so(g(22)))
            ng = str(g(3) or "").strip()[:10]
            H.setdefault(sohd, []).append((k, tt, ng, ms))
            HT.setdefault(sohd + "|" + str(tt), []).append(k)
            T.setdefault(tt, []).append(k)
            if ms:
                MS.setdefault(tt, set()).add(ms)

    nap(duong.get("banra"), 8, 9, 11, "KH", hd_ban, hdt_ban, tien_ban, mst_ban)
    nap(duong.get("muavao"), 6, 7, 10, "NCC", hd_mua, hdt_mua, tien_mua, mst_mua)

    # ---------- ung vien ----------
    bao("Đang dựng danh sách ứng viên…", 30)
    dung = set(d["ma"] for d in dm)
    co_ten = set(d["ten_chuan"] for d in dm)
    co_mst = set(d["mst"] for d in dm if d["mst"])
    seqs = [int(m.group(2)) for m in
            (re.match(r"^([A-Z]{2,6})(\d{1,3})$", u) for u in dung) if m]
    seq = [max(seqs) + 1] if seqs else [200]
    cand = [dict(d) for d in dm]

    def nen(s):
        return s.replace(" ", "")

    def tim_trong_dm(tc, ms=""):
        """Tim ten trong danh muc. Neu hai ben deu co MST ma khac nhau thi
        day la hai phap nhan khac nhau — khong duoc gop lam mot."""
        if not tc:
            return None
        hop = [c for c in cand if not (ms and c["mst"] and c["mst"] != ms)]
        ex = [c for c in hop if c["ten_chuan"] == tc]
        if ex:
            return ex[0]
        if ms:
            em = [c for c in hop if c["mst"] == ms]
            if len(em) == 1:
                return em[0]
        cp = [c for c in hop if nen(c["ten_chuan"]) == nen(tc)]
        if len(cp) == 1:
            return cp[0]
        sc = sorted(((diem_tu(tc, c["ten_chuan"]), c) for c in hop), key=lambda x: -x[0])
        if sc and sc[0][0] >= 92 and (len(sc) == 1 or sc[1][0] < sc[0][0] - 1.5):
            return sc[0][1]
        return None

    def viet_tat(ten):
        w = [x for x in bo_dau(ten).upper().split() if x[:1].isalpha()]
        if not w:
            return ""
        return ("".join(x[0] for x in w[:-1]) + w[-1][:2])[:6]

    moi = []
    bo_qua = 0
    for k in sorted(hdp):
        v = hdp[k]
        if k in co_ten or (v["mst"] and v["mst"] in co_mst):
            continue
        if tim_trong_dm(k, v["mst"]):
            bo_qua += 1
            continue
        if v["mst"]:
            base = v["mst"].zfill(10)[-4:]
            ma, i = base, 1
            while ma in dung:
                ma = "%s_%d" % (base, i)
                i += 1
        else:
            ini = viet_tat(v["ten"])
            if not ini:
                continue
            ma = "%s%d" % (ini, seq[0])
            while ma in dung:
                seq[0] += 1
                ma = "%s%d" % (ini, seq[0])
            seq[0] += 1
        dung.add(ma)
        c = {"ma": ma, "ten": v["ten"], "ten_chuan": k, "mst": v["mst"],
             "diachi": v["diachi"], "tk": "3311" if v["loai"] == "NCC" else "1311",
             "phan_loai": "PTR" if v["loai"] == "NCC" else "PTH", "moi": True}
        cand.append(c)
        moi.append(c)
    if bo_qua:
        log.ghi("Bo qua %d doi tac vi ten da co san trong danh muc" % bo_qua, che=False)

    nv = {}
    for th in luong:
        for e in luong[th]:
            if e["ten_chuan"] in nv:
                continue
            c = tim_trong_dm(e["ten_chuan"], "")
            if not c:
                ini = viet_tat(e["ten"])
                if not ini:
                    continue
                ma = "%s%d" % (ini, seq[0])
                while ma in dung:
                    seq[0] += 1
                    ma = "%s%d" % (ini, seq[0])
                seq[0] += 1
                dung.add(ma)
                c = {"ma": ma, "ten": e["ten"], "ten_chuan": e["ten_chuan"], "mst": "",
                     "diachi": "", "tk": "334", "phan_loai": "TM", "moi": True}
                cand.append(c)
                moi.append(c)
                log.ghi('Nhan vien "%s" chua co ma — de xuat %s' % (e["ten"], ma), che=False)
            nv[e["ten_chuan"]] = c

    theo_ten, theo_mst = {}, {}
    for c in cand:
        theo_ten.setdefault(c["ten_chuan"], []).append(c)
        if c["mst"]:
            theo_mst.setdefault(c["mst"], []).append(c)

    bao("Đang đọc sổ phụ…", 38)
    info, tx, ft = doc_so_phu(duong["sophu"], log)

    # ---------- khop tung dong ----------
    ket = []
    for n, t in enumerate(tx):
        if n % 100 == 0:
            bao("Đang khớp giao dịch %d/%d…" % (n, len(tx)), 40 + int(55 * n / max(1, len(tx))))
        lg = loai_gd(t["dg"])
        ten_uv = [] if lg in ("LUONG", "LAI_TG", "PHI_NH") else boc_ten(t["dg"])
        keys = []
        for x in ten_uv:
            k = chuan(x)
            if k and k not in keys:
                keys.append(k)
        vet = truy_vet(t["dg"])
        sohd = vet["hd"][0] if vet["hd"] else ""
        # GD21: chi giu cum so QUA DUOC so kiem tra MST (truoc day lay bua moi cum 10-14 chu so)
        msts = [chuan_mst(x) for x in re.findall(r"\b\d{10,14}\b", t["dg"]) if la_mst(x)]
        msts = [m for m in msts if m and m != chuan_mst("0319318647")]
        tt = round(so(t["credit"]) or so(t["debit"]))
        thu = so(t["credit"]) > 0
        r = dict(t, loai=lg, ten_boc=ten_uv[0] if ten_uv else "", ma="", ten="",
                 tk="", L=0, M=0, note="", uv=[], tien=tt, thang=None, skey="",
                 key=keys[0] if keys else "", nhom=False)

        # --- chi luong ---
        if lg == "LUONG":
            r["tk"] = "334"
            r["thang"] = thang_luong(t["dg"])
            r["skey"] = "LUONG|%s|%d" % (r["thang"], tt)
            if r["skey"] in duyet_tay:
                c = next((x for x in cand if x["ma"] == duyet_tay[r["skey"]]), None)
                if c:
                    r.update(ma=c["ma"], ten=c["ten"], L=100, M=100, note="Đã duyệt tay kỳ trước")
                    ket.append(r)
                    continue
            if not luong:
                r.update(L=60, note="Chưa nạp bảng lương — chọn nhân viên thủ công")
                ket.append(r)
                continue
            trong = [e for e in luong.get(r["thang"], []) if e["net"] == tt]
            if len(trong) == 1 and nv.get(trong[0]["ten_chuan"]):
                c = nv[trong[0]["ten_chuan"]]
                r.update(ma=c["ma"], ten=c["ten"], L=100, M=100,
                         note="Khớp thực nhận bảng lương tháng %s" % r["thang"])
                ket.append(r)
                continue
            if len(trong) > 1:
                r["uv"] = [{"ma": nv[e["ten_chuan"]]["ma"], "ten": e["ten"], "d": 100}
                           for e in trong if nv.get(e["ten_chuan"])]
                r.update(L=60, M=100, note="Tháng %s có %d nhân viên cùng mức thực nhận %s"
                         % (r["thang"], len(trong), tien(tt)))
                ket.append(r)
                continue
            khac = [(th, e) for th in luong for e in luong[th] if e["net"] == tt]
            uniq = list({e["ten_chuan"] for _, e in khac})
            if len(uniq) == 1 and nv.get(uniq[0]):
                c = nv[uniq[0]]
                r.update(ma=c["ma"], ten=c["ten"], L=85, M=100,
                         note="Không có ở tháng %s; khớp thực nhận tháng %s" % (r["thang"], khac[0][0]))
                ket.append(r)
                continue
            r["uv"] = [{"ma": nv[k]["ma"], "ten": nv[k]["ten"], "d": 90} for k in uniq[:6] if nv.get(k)]
            if not r["uv"]:
                r["uv"] = [{"ma": c["ma"], "ten": c["ten"], "d": 0} for c in list(nv.values())[:8]]
            r["note"] = "Không nhân viên nào thực nhận %s ở tháng %s" % (tien(tt), r["thang"])
            ket.append(r)
            continue

        if lg in ("LAI_TG", "PHI_NH"):
            r.update(tk=TK_LOAI[lg], note=TK_NHAN[lg], L=100, nhom=True)
            ket.append(r)
            continue
        nhom_tk = bool(lg)
        if nhom_tk:
            r["tk"] = TK_LOAI.get(lg, "")

        if r["key"] and r["key"] in duyet_tay:
            c = next((x for x in cand if x["ma"] == duyet_tay[r["key"]]), None)
            if c:
                r.update(ma=c["ma"], ten=c["ten"], L=100, M=100, note="Đã duyệt tay kỳ trước",
                         tk=r["tk"] or c["tk"] or ("1311" if thu else "3311"))
                ket.append(r)
                continue

        best = None
        for m in msts:
            if len(theo_mst.get(m, [])) == 1:
                best = theo_mst[m][0]
                r.update(L=100, note="Khớp MST trong diễn giải")
                break

        def theo_hd():
            """Truy vet theo TAT CA so hoa don trong dien giai, co doi chieu ngay va tong tien."""
            if not vet["hd"]:
                return None
            reg = hd_ban if thu else hd_mua
            tap, tong, thay, ms_hd = [], 0.0, 0, set()
            for n in vet["hd"]:
                e = reg.get(n)
                if not e:
                    continue
                if vet["ngay"]:
                    loc = [x for x in e if x[2] and (x[2] == vet["ngay"] or x[2][:5] == vet["ngay"][:5])]
                    if loc:
                        e = loc
                ks = {x[0] for x in e}
                for x in e:
                    if len(x) > 3 and x[3]:
                        ms_hd.add(x[3])
                tap.append(ks)
                thay += 1
                if len(ks) == 1:
                    tong += e[0][1]
            if not tap:
                return None
            giao = set(tap[0])
            for s2 in tap[1:]:
                giao &= s2
            if len(giao) != 1:
                return None
            k = giao.pop()
            ung = theo_ten.get(k, [])
            if not ung and ms_hd:
                ung = [c for c in cand if c["mst"] and c["mst"] in ms_hd]
                if len(ung) == 1:
                    return (ung[0], "khớp mã số thuế trên hóa đơn %s"
                            % ", ".join(vet["hd"][:3]), 95)
            if len(ung) != 1:
                cc = [c for c in ung if c["mst"] and c["mst"] in ms_hd]
                if len(cc) != 1:
                    return None
                theo_ten[k] = ung
                ung = cc
            ch = ung[0]
            ds = ", ".join(vet["hd"][:4]) + ("…" if len(vet["hd"]) > 4 else "")
            if thay == len(vet["hd"]) and abs(tong - tt) <= 10 and tong > 0:
                return ch, "khớp %d số hóa đơn (%s) và tổng tiền" % (thay, ds), 100
            if vet["ngay"]:
                return ch, "khớp số hóa đơn %s ngày %s" % (ds, vet["ngay"]), 100
            if vet["dai"]:
                return ch, "dải hóa đơn %s-%s cùng một đối tác" % (vet["hd"][0], vet["hd"][-1]), 95
            u = set((hdt_ban if thu else hdt_mua).get(vet["hd"][0] + "|" + str(tt)) or [])
            if len(u) == 1:
                return ch, "khớp số HĐ %s + số tiền" % vet["hd"][0], 100
            return ch, "khớp số hóa đơn %s" % ds, 95

        if not best:
            h = theo_hd()
            if h:
                best, r["L"], r["note"] = h[0], h[2], h[1].capitalize()

        if not best:
            for k in keys:
                g = theo_ten.get(k)
                if not g:
                    continue
                if len(g) == 1:
                    best = g[0]
                    r.update(L=95, M=100, note="Tên trùng khít")
                    break
                pick = None
                for m in msts:
                    cc = [c for c in g if c["mst"] == m]
                    if len(cc) == 1:
                        pick = cc[0]
                        r["note"] = "Tên trùng %d mã — phân giải bằng MST" % len(g)
                        break
                if not pick:
                    ms = (mst_ban if thu else mst_mua).get(tt, set())
                    cc = [c for c in g if c["mst"] and c["mst"] in ms]
                    if len(cc) == 1:
                        pick = cc[0]
                        r["note"] = "Tên trùng %d mã — phân giải bằng số tiền HĐ" % len(g)
                if not pick:
                    cc = [c for c in g if c["mst"]]
                    if len(cc) == 1 and len(g) == 2:
                        pick = cc[0]
                        r["note"] = "Tên trùng %d mã — chọn mã có MST" % len(g)
                if pick:
                    best = pick
                    r.update(L=88, M=100)
                    break
                ds_ma = {c["ma"] for c in g}
                r["uv"] = [{"ma": c["ma"], "ten": c["ten"], "d": 100} for c in g]
                r.update(L=60, M=100, trung=True, nhom_trung=ds_ma,
                         note="Trùng mã trong danh mục (%d mã cùng tên)" % len(g))
                break

        if not best and r["L"] == 0:
            for k in keys:
                if len(k) < 12:
                    continue
                pre = [c for c in cand
                       if (c["ten_chuan"].startswith(k) or k.startswith(c["ten_chuan"]))
                       and min(len(c["ten_chuan"]), len(k)) >= 12]
                if not pre:
                    continue
                if len(pre) == 1:
                    best = pre[0]
                    r.update(L=90, M=round(diem_tu(k, pre[0]["ten_chuan"])),
                             note="Tên bị cắt cụt — khớp tiền tố")
                    break
                nn = {c["ten_chuan"] for c in pre}
                ms = (mst_ban if thu else mst_mua).get(tt, set())
                cc = [c for c in pre if c["mst"] and c["mst"] in ms]
                if len(nn) == 1 and len(cc) == 1:
                    best = cc[0]
                    r.update(L=90, M=100, note="Tên trùng — phân giải bằng số tiền HĐ")
                    break
                r["uv"] = [{"ma": c["ma"], "ten": c["ten"],
                            "d": round(diem_tu(k, c["ten_chuan"]))} for c in pre[:6]]
                r.update(L=60, trung=(len(nn) == 1),
                         note=("Trùng mã trong danh mục (%d mã cùng tên)" % len(pre))
                         if len(nn) == 1 else "Khớp tiền tố nhưng có %d ứng viên" % len(pre))
                break

        fz = None
        if not best and r["L"] == 0 and keys:
            for k in keys:
                sc = sorted(((diem_tu(k, c["ten_chuan"]), c) for c in cand), key=lambda x: -x[0])
                if not fz or sc[0][0] > fz[1][0][0]:
                    fz = (k, sc)
            top = fz[1][0]
            gan = [x for x in fz[1] if x[0] >= top[0] - 1.5]
            if top[0] >= 90 and len(gan) == 1:
                best = top[1]
                r.update(L=85, M=round(top[0]), note="Khớp gần đúng %d" % round(top[0]))

        # Truy vet bang so hoa don / so tien — chay ca khi khop ten dang do dang
        if not best:
            h = theo_hd()
            if h:
                best = h[0]
                r.update(L=min(95, h[2]), uv=[], trung=False,
                         note=("Tên chưa xác định — " if keys else "") + h[1])
            else:
                u = list({x for x in (tien_ban if thu else tien_mua).get(tt, [])})
                if len(u) == 1 and len(theo_ten.get(u[0], [])) == 1:
                    best = theo_ten[u[0]][0]
                    r.update(L=85, uv=[], trung=False,
                             note=("Tên chưa xác định — " if keys else "")
                             + "khớp duy nhất theo số tiền thanh toán")
                elif len(u) > 1 and r["L"] == 0:
                    r["uv"] = [{"ma": theo_ten[x][0]["ma"], "ten": theo_ten[x][0]["ten"], "d": 0}
                               for x in u[:5] if len(theo_ten.get(x, [])) == 1]
                    r.update(L=60, note="Số tiền %s khớp %d hóa đơn khác nhau" % (tien(tt), len(u)))

        if not best and r["L"] == 0:
            if fz:
                top = fz[1][0]
                r["M"] = round(top[0])
                r["uv"] = [{"ma": c["ma"], "ten": c["ten"], "d": round(s)}
                           for s, c in fz[1][:5] if s >= 55]
                if top[0] >= 75:
                    r.update(L=60, note="Cần duyệt — điểm %d" % round(top[0]))
                else:
                    r["note"] = "Tên không có trong danh mục, số tiền và số hóa đơn cũng không xác định được"
            else:
                r["note"] = "Không bóc được tên, số tiền không khớp hóa đơn nào"

        if not best and nhom_tk:
            r.update(nhom=True, L=100,
                     note=(TK_NHAN.get(lg, "Giao dịch nội bộ")) + " — không xác định đối tượng")
        elif best:
            r["ma"], r["ten"] = best["ma"], best["ten"]
            r["tk"] = TK_LOAI[lg] if lg in TK_LOAI else (best["tk"] or ("1311" if thu else "3311"))
            if nhom_tk:
                r["note"] = TK_NHAN.get(lg, "") + " · " + r["note"]
            if best["moi"]:
                r["note"] += " | MÃ MỚI — CHỜ DUYỆT"
            p = (tien_ban if thu else tien_mua).get(tt, [])
            if best["ten_chuan"] in p:
                r["L"] = 100
                r["note"] += " | Khớp số tiền hóa đơn"
        ket.append(r)

    tu_dong = sum(1 for r in ket if r["L"] >= 85)
    log.ghi("Khop xong: %d/%d dong tu dong (%.1f%%)"
            % (tu_dong, len(ket), 100.0 * tu_dong / max(1, len(ket))), che=False)
    lgr = [r for r in ket if r["loai"] == "LUONG"]
    if lgr:
        log.ghi("Lenh chi luong: %d/%d dong xac dinh duoc nhan vien"
                % (sum(1 for r in lgr if r["ma"]), len(lgr)), che=False)
    bao("Xong", 100)
    return {"info": info, "rows": ket, "footer": ft, "cand": cand, "moi": moi}


# ==========================================================================
#  KIEM TRA
# ==========================================================================
def kiem_tra(kq):
    rows, ft, info, cand = kq["rows"], kq["footer"], kq["info"], kq["cand"]
    if not rows:
        return []
    sd = sum(so(r["debit"]) for r in rows)
    sc = sum(so(r["credit"]) for r in rows)
    dd = so(info.get("du_dau"))
    cuoi = so(rows[-1]["sodu"])
    ma_set = {c["ma"] for c in cand}
    ngoai = sorted({r["ma"] for r in rows if r["ma"] and r["ma"] not in ma_set})
    bad = sorted({r["tk"] for r in rows if r["tk"] and r["tk"] not in TAP_TK})
    lech = sum(1 for r in rows if bool(r["ma"]) != bool(r["ten"]))
    m2t = {}
    for r in rows:
        if r["ma"] and r["ten"]:
            m2t.setdefault(r["ma"], set()).add(r["ten"])
    cheo = sum(1 for v in m2t.values() if len(v) > 1)
    LOI = ("ï¿½", "â€", "Ñ", "Ö", "Ï", "Ø", "Û", "Æ")
    font = sum(1 for r in rows if r["ten"] and any(c in r["ten"] for c in LOI))
    auto = sum(1 for r in rows if r["L"] >= 85)
    out = [
        ("Số dòng giao dịch", True, "%d dòng, %d dòng tổng cộng tách riêng" % (len(rows), len(ft))),
        ("Tổng Debit / Credit", True, "Chi %s · Thu %s" % (tien(sd), tien(sc))),
        ("Số dư cuối kỳ", abs(dd + sc - sd - cuoi) < 1,
         "%s + %s − %s = %s · sổ ghi %s" % (tien(dd), tien(sc), tien(sd), tien(dd + sc - sd), tien(cuoi))),
        ("Mã hợp lệ", not ngoai, ("Ngoại lệ: " + ", ".join(ngoai)) if ngoai
         else "%d mã được dùng" % len({r["ma"] for r in rows if r["ma"]})),
        ("Tài khoản hợp lệ", not bad, ("Ngoại lệ: " + ", ".join(bad)) if bad
         else ", ".join(sorted({r["tk"] for r in rows if r["tk"]}))),
        ("Mã và tên đồng bộ", lech == 0, "%d dòng lệch" % lech if lech else "Không có dòng lệch"),
        ("Một mã không mang hai tên", cheo == 0, "%d trường hợp" % cheo if cheo else "Không có"),
        ("Không lỗi font ở cột tên", font == 0, "%d dòng lỗi" % font if font else "Không có"),
        ("Tỷ lệ khớp tự động", auto / len(rows) >= 0.75,
         "%d/%d = %.1f%%" % (auto, len(rows), 100.0 * auto / len(rows))),
    ]
    lgr = [r for r in rows if r["loai"] == "LUONG"]
    if lgr:
        out.append(("Lệnh chi lương có mã nhân viên", all(r["ma"] for r in lgr),
                    "%d/%d dòng" % (sum(1 for r in lgr if r["ma"]), len(lgr))))
    return out


# ==========================================================================
#  XUAT FILE
# ==========================================================================
def xuat_file(kq, thu_muc, log):
    rows, ft, info, moi = kq["rows"], kq["footer"], kq["info"], kq["moi"]
    ra = []

    # ---- Sheet so phu: dung dung khuon MAU_SOPHU (tieu de dong 12, du lieu tu dong 13) ----
    B = [[None] * 15 for _ in range(12)]

    def dat(o, r, c, v, st=0):
        o[r - 1][c - 1] = (v, st) if st else v

    dat(B, 1, 4, "SỔ PHỤ TÀI KHOẢN TIỀN GỬI KHÔNG KỲ HẠN", 4)
    dat(B, 1, 7, "PHẦN MỀM KẾ TOÁN UNESCO XI + AI", 4)
    dat(B, 2, 4, "Từ ngày: %s  Đến ngày: %s" % (info.get("ky1") or "", info.get("ky2") or ""))
    dat(B, 2, 7, "Ngày kết xuất: " + datetime.now().strftime("%d/%m/%Y %H:%M:%S"))
    dat(B, 3, 4, "From: %s  To: %s" % (info.get("ky1") or "", info.get("ky2") or ""))
    dat(B, 4, 4, "---oOo---")
    dat(B, 6, 1, "Số tài khoản/Account no:", 4)
    dat(B, 6, 3, info.get("so_tk") or "")
    dat(B, 7, 1, "Tên khách hàng/\nAccount holder:", 4)
    dat(B, 7, 3, info.get("chu_tk") or "")
    dat(B, 8, 1, "Số giao dịch/Transactions:", 4)
    dat(B, 8, 3, len(rows))
    dat(B, 9, 1, "Số dư đầu kỳ/Openning balance:", 4)
    dat(B, 9, 3, info.get("du_dau") or "")
    dat(B, 10, 1, "Mã tiền tệ/Currency:", 4)
    dat(B, 10, 3, "VND")
    head = ["STT\nNo", "Ngày giao dịch\nBooking date (*)", "Ngày hiệu lực\nValue date (*)",
            "Số giao dịch\nTxn ID", "Diễn giải\nDescription", "Số tiền rút\nDebit",
            "Số tiền gửi\nCredit", "Số dư\nActual Balance (*)", "Mã khách hàng", "Tài khoản",
            "TÊN khách hàng", "TỶ LỆ KHỚP MÃ ", "TỶ LỆ KHỚP TÊN", "Trạng thái", "Ghi chú"]
    for c, h in enumerate(head, 1):
        dat(B, 12, c, h, 1)
    gop = ["D1:F1", "G1:H1", "D2:F2", "G2:H2", "D3:F3", "G3:H3", "D4:F4", "G4:H4",
           "A5:H5", "A6:B6", "C6:H6", "A7:B7", "C7:H7", "A8:B8", "C8:H8",
           "A9:B9", "C9:H9", "A10:B10", "C10:H10", "A11:H11"]

    for r in rows:
        st = 0 if r["L"] >= 85 else (2 if r["L"] > 0 else 3)
        tt = "Đã gắn" if r["L"] >= 85 else ("Cần duyệt" if r["L"] > 0 else "Chưa khớp")
        B.append([(x, st) for x in
                  [r["stt"], r["ngay_gd"], r["ngay_hl"], r["so_gd"], r["dg"],
                   r["debit"], r["credit"], r["sodu"], r["ma"], r["tk"], r["ten"],
                   r["L"], r["M"] or "", tt, r["note"]]])
    for f in ft:
        B.append([(f["nhan"], 4), "", "", "", "", (f["debit"], 4), (f["credit"], 4), (f["sodu"], 4)])

    f1 = os.path.join(thu_muc, "SOPHU_DA_GAN_MA.xlsx")
    ghi_xlsx(f1, [("So phu", B,
                   [4.6, 18.7, 11.4, 11.7, 43.3, 14, 13.1, 13.6, 19.3, 16, 60.1, 13.7, 13.7, 11, 28],
                   12, gop)])
    ra.append(f1)

    dem = {}
    for r in rows:
        if r["ma"]:
            dem[r["ma"]] = dem.get(r["ma"], 0) + 1
    h2 = ["Phân loại", "Số hiệu", "Tên", "MST", "Địa chỉ", "Tài khoản",
          "Số GD phát sinh", "Ghi chú"]
    b2 = [[c["phan_loai"], (c["ma"], 2), c["ten"], c["mst"], c["diachi"], c["tk"],
           dem.get(c["ma"], 0),
           "Nhân viên trên bảng lương, chưa có mã trong danh mục" if c["phan_loai"] == "TM"
           else "Mã sinh theo quy ước: " + ("4 số cuối MST" if c["mst"] else "viết tắt tên + số thứ tự")]
          for c in sorted(moi, key=lambda x: -dem.get(x["ma"], 0))]
    f2 = os.path.join(thu_muc, "DANH_MUC_KH_BO_SUNG.xlsx")
    ghi_xlsx(f2, [("Khach hang bo sung", [[(h, 1) for h in h2]] + b2,
                   [11, 12, 46, 16, 52, 11, 16, 40], 1)])
    ra.append(f2)

    def bang(R):
        h = ["STT", "Ngày", "Số tiền", "Diễn giải", "Tên bóc được", "Ứng viên", "Ghi chú"]
        return [[(x, 1) for x in h]] + [
            [r["stt"], r["ngay_hl"], r["debit"] or r["credit"], r["dg"], r["ten_boc"],
             "  ;;  ".join("%s | %s (%s)" % (u["ma"], u["ten"], u["d"]) for u in r["uv"]),
             r["note"]] for r in R]

    W = [7, 12, 16, 60, 30, 60, 30]
    duyet = [r for r in rows if 0 < r["L"] < 85 and not r.get("trung")]
    trung = [r for r in rows if r.get("trung")]
    chua = [r for r in rows if r["L"] == 0]
    cap = {}
    for r in trung:
        k = "  ++  ".join("%s | %s" % (u["ma"], u["ten"]) for u in r["uv"])
        cap[k] = cap.get(k, 0) + 1
    f3 = os.path.join(thu_muc, "BANG_KIEM_TRA.xlsx")
    ghi_xlsx(f3, [
        ("1. Can duyet", bang(duyet), W, 1),
        ("2. Trung ma danh muc", bang(trung), W, 1),
        ("3. Chua khop", bang(chua), W, 1),
        ("4. Chi luong", bang([r for r in rows if r["loai"] == "LUONG"]), W, 1),
        ("5. Cap ma can gop", [[("#", 1), ("Số GD ảnh hưởng", 1), ("Các mã cùng một tên", 1)]] +
         [[i + 1, v, k] for i, (k, v) in enumerate(sorted(cap.items(), key=lambda x: -x[1]))],
         [5, 16, 100], 1),
    ])
    ra.append(f3)
    for f in ra:
        log.ghi("Da ghi: " + f, che=False)
    return ra


GIAO_DIEN = r"""<!DOCTYPE html>
<html lang="vi"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Trích xuất sổ phụ — UNESCO XI + AI</title>
<link rel="icon" href="/logo.png">
<style>
:root{
 --bg:#F1F6F3; --surface:#FFFFFF; --ink:#1A2248; --soft:#56628C;
 --line:#DEE8E3; --lineS:#C3D4CC; --blue:#394B9F; --blueD:#28346F; --blueT:#EDEFF8;
 --green:#006631; --greenT:#EBF8F1; --amber:#6B5A2B; --amberT:#FFF6DD;
 --red:#B3261E; --redT:#FBEBE9; --violet:#00618B; --violetT:#EBF7FD;
 --la:#00A54F; --duong:#009DE0; --vang:#FFD766;
 --mono:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;
}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);font:14px/1.5 system-ui,'Segoe UI',Roboto,sans-serif}
.wrap{max-width:1320px;margin:0 auto;padding:0 20px 60px}
.bar{position:sticky;top:0;z-index:40;background:rgba(255,255,255,.94);
 backdrop-filter:blur(10px);border-bottom:1px solid var(--line)}
.bar .in{max-width:1320px;margin:0 auto;padding:12px 20px;display:flex;align-items:center;gap:14px;flex-wrap:wrap}
.mark{width:38px;height:38px;border-radius:50%;border:1px solid var(--line);
 background:#fff;display:block;object-fit:contain}
.cty{font:600 10.5px/1 var(--mono);letter-spacing:.07em;text-transform:uppercase;
 color:var(--soft);margin-top:3px}
.ttl{font-size:16px;font-weight:700}.sub{font-size:12px;color:var(--soft)}
.chip{display:inline-flex;align-items:center;gap:7px;padding:6px 12px;border-radius:999px;
 font-size:12.5px;font-weight:600;border:1px solid var(--lineS);background:#fff;color:var(--soft)}
.chip.on{border-color:#B9E3D2;background:var(--greenT);color:var(--green)}
.dot{width:8px;height:8px;border-radius:50%;background:var(--lineS)}
.chip.on .dot{background:var(--green)}
.steps{max-width:1320px;margin:0 auto;padding:0 20px 10px;display:flex;gap:6px}
.steps button{padding:8px 16px;border-radius:7px;border:0;background:none;color:var(--soft);
 font-weight:600;font-size:13.5px;cursor:pointer}
.steps button.on{background:var(--blueT);color:var(--blue)}
.steps button:disabled{opacity:.4;cursor:not-allowed}
.card{background:var(--surface);border:1px solid var(--line);border-radius:12px;margin-top:18px;
 box-shadow:0 1px 2px rgba(14,27,51,.05),0 8px 24px -12px rgba(14,27,51,.18)}
.pad{padding:18px}
.eyebrow{font:600 11px/1 var(--mono);letter-spacing:.09em;text-transform:uppercase;color:var(--violet);margin-bottom:8px}
h2{font-size:14.5px;margin:0 0 4px}
.grid{display:grid;gap:12px;grid-template-columns:repeat(auto-fit,minmax(240px,1fr))}
.drop{border:1px dashed var(--lineS);border-radius:12px;padding:16px;cursor:pointer;background:#fff}
.drop.ok{border-style:solid;border-color:var(--la);background:linear-gradient(0deg,var(--greenT),var(--greenT)) padding-box}
.drop b{font-size:13px}.drop .h{font-size:12px;color:var(--soft);margin-top:2px}
.drop .p{margin-top:10px;font:12px var(--mono);color:var(--soft);word-break:break-all}
.drop.ok .p{color:var(--green)}
button.b{padding:10px 18px;border-radius:8px;font-weight:600;font-size:14px;cursor:pointer;
 border:1px solid var(--lineS);background:#fff;color:var(--ink)}
button.b.pri{background:var(--blue);color:#fff;border-color:transparent}
button.b:disabled{opacity:.45;cursor:not-allowed}
button.sm{padding:5px 9px;font-size:11.5px;border-radius:6px;border:1px solid var(--lineS);background:#fff;cursor:pointer}
.rail{height:8px;border-radius:999px;background:var(--blueT);overflow:hidden;margin-top:12px}
.rail i{display:block;height:100%;width:0;transition:width .3s;
 background:linear-gradient(90deg,var(--la),var(--duong))}
.tabs{padding:12px 18px;border-bottom:1px solid var(--line);display:flex;gap:20px;flex-wrap:wrap}
.tabs button{padding:10px 2px;border:0;background:none;cursor:pointer;font-weight:600;
 font-size:13.5px;color:var(--soft);border-bottom:2px solid transparent;margin-bottom:-1px}
.tabs button.on{color:var(--blue);border-bottom-color:var(--blue)}
.tabs .n{font:11.5px var(--mono);margin-left:6px;padding:1px 7px;border-radius:999px;background:var(--bg)}
.tabs button.on .n{background:var(--blueT)}
.tools{padding:10px 18px;background:#FAFCFB;border-bottom:1px solid var(--line);
 display:flex;gap:12px;align-items:center;flex-wrap:wrap}
input[type=text],input[type=search]{padding:8px 11px;border:1px solid var(--lineS);border-radius:8px;font:inherit}
input:focus,.pk input:focus{outline:none;border-color:var(--blue);box-shadow:0 0 0 3px rgba(57,75,159,.14)}
.tbl{overflow:auto;max-height:60vh}
table{width:100%;border-collapse:collapse;font-size:13px}
th{position:sticky;top:0;z-index:2;background:#F5F9F7;padding:10px 12px;text-align:left;
 font-size:11.5px;font-weight:700;color:var(--soft);border-bottom:1px solid var(--lineS);white-space:nowrap}
th.sx{cursor:pointer;user-select:none}
th.sx:hover{background:#E9F2ED;color:var(--blue)}
th.sx.on{color:var(--blue)}
th .mt{opacity:.45;font-size:10px;margin-left:3px}
th.sx.on .mt{opacity:1}
tr.pick{background:var(--blueT)!important;box-shadow:inset 3px 0 0 var(--blue)}
.thanhchon{padding:10px 18px;background:var(--blueT);border-bottom:1px solid var(--lineS);
 display:flex;gap:10px;align-items:center;flex-wrap:wrap;font-size:13px}
.thanhchon b{color:var(--blueD)}
td.ck,th.ck{width:34px;padding-left:14px;padding-right:0}
input[type=checkbox]{width:15px;height:15px;accent-color:var(--blue);cursor:pointer}
td{padding:9px 12px;border-bottom:1px solid var(--line);vertical-align:top}
td.n{font:12.5px var(--mono);text-align:right;white-space:nowrap}
td.m{font:12px var(--mono)}
tr.duyet{background:var(--amberT)}tr.chua{background:var(--redT)}tr.luong{background:var(--violetT)}
.macode{font:12.5px var(--mono);font-weight:700;padding:2px 8px;border-radius:5px;background:var(--blueT);color:var(--blueD)}
.pk{margin-top:8px;border:1px solid var(--lineS);border-radius:9px;background:#fff;
 box-shadow:0 10px 28px -14px rgba(14,27,51,.4);overflow:hidden;width:400px;max-width:78vw}
.pk input{width:100%;border:0;border-bottom:1px solid var(--line);padding:10px 12px;font:13px inherit;outline:none}
.pkkq{max-height:250px;overflow:auto}
.pkr{display:flex;align-items:center;gap:8px;padding:7px 10px;border-bottom:1px solid var(--line)}
.pkr:hover{background:var(--blueT)}
.pkr .t{flex:1;min-width:0;font-size:12.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.pkr .c{font:11.5px var(--mono);color:var(--soft)}
.pkft{padding:8px 10px;background:#FAFCFB;font-size:11.5px;color:var(--soft)}
.uv{display:flex;gap:4px;flex-wrap:wrap;margin-top:5px}
.uv button{padding:3px 8px;font-size:11.5px;border-radius:999px;border:1px solid var(--lineS);
 background:var(--blueT);color:var(--blueD);cursor:pointer;max-width:210px;overflow:hidden;
 text-overflow:ellipsis;white-space:nowrap}
.badge{padding:3px 10px;border-radius:6px;font-size:11.5px;font-weight:700}
.ok{background:var(--greenT);color:var(--green)}.no{background:var(--redT);color:var(--red)}
.note{font-size:12px;color:var(--soft);max-width:210px}
.hint{font-size:12.5px;color:var(--soft)}
.log{padding:0 18px 16px;font:12px var(--mono);color:var(--soft);max-height:220px;overflow:auto}
.msg{padding:14px;border-radius:10px;margin-top:18px;font-weight:600}
.msg.i{background:var(--blueT);color:var(--blueD)}
.msg.e{background:var(--redT);color:var(--red)}
.empty{padding:56px;text-align:center;color:var(--soft)}
ol,ul{margin:0;padding-left:20px;color:var(--soft);font-size:13.5px;line-height:1.85}
</style></head><body>

<div class="bar">
 <div class="in">
  <img class="mark" src="/logo.png" alt="UNESCO">
  <div style="margin-right:auto">
   <div class="ttl">Trích xuất sổ phụ</div>
   <div class="sub">Gắn mã khách hàng, tài khoản và tên vào sổ phụ ngân hàng</div>
   <div class="cty">Phần mềm kế toán UNESCO XI + AI</div>
  </div>
  <div class="chip" id="chip"><span class="dot"></span><span id="chipT">Chưa nạp dữ liệu</span></div>
 </div>
 <div class="steps">
  <button id="s1" class="on" onclick="buoc(1)">Nạp dữ liệu</button>
  <button id="s2" disabled onclick="buoc(2)">Kiểm tra và duyệt</button>
  <button id="s3" disabled onclick="buoc(3)">Xuất file</button>
 </div>
</div>

<div class="wrap">
 <div id="bao"></div>

 <!-- BUOC 1 -->
 <div id="b1">
  <div class="card pad">
   <div class="eyebrow">Bước 1</div>
   <h2>Nạp dữ liệu của kỳ</h2>
   <div class="hint" style="margin-bottom:16px">Hai file đầu bắt buộc. Bảng kê hóa đơn dùng để đối chiếu số hóa đơn với số tiền; bảng lương dùng để xác định nhân viên trong các lệnh chi lương.</div>
   <div class="grid" id="oFile"></div>
   <div style="margin-top:18px;display:flex;gap:10px;align-items:center;flex-wrap:wrap">
    <button class="b pri" id="btnChay" onclick="chay()">Chạy khớp</button>
    <span class="hint">Dữ liệu chỉ được xử lý trên máy này, không gửi đi đâu.</span>
   </div>
   <div class="rail" id="rail" style="display:none"><i id="railI"></i></div>
   <div class="hint" id="tienTrinh" style="margin-top:6px"></div>
  </div>
  <div class="card pad">
   <div class="eyebrow">Cách làm việc</div>
   <h2>Tool xác định mã khách hàng như thế nào</h2>
   <ol>
    <li>Chuyển danh mục từ font VNI cũ sang Unicode trước khi so khớp</li>
    <li>Bóc cả tên đứng đầu diễn giải lẫn tên chủ tài khoản, lấy tên nào thật sự có trong danh mục</li>
    <li>Khớp theo mã số thuế, cặp số hóa đơn với số tiền, tên trùng khít, tên bị cắt cụt</li>
    <li>Tên lạ thì quay sang đối chiếu số hóa đơn và số tiền thanh toán</li>
    <li>Lệnh chi lương đối chiếu với cột Thực nhận của đúng tháng ghi trong diễn giải</li>
    <li>Từ hai ứng viên ngang điểm trở lên thì để trống và báo lại, không đoán</li>
   </ol>
  </div>
 </div>

 <!-- BUOC 2 -->
 <div id="b2" style="display:none">
  <div class="card">
   <div class="tabs" id="tabs"></div>
   <div class="tools">
    <input type="search" id="q" placeholder="Tìm theo diễn giải, tên hoặc mã" style="flex:1;min-width:200px" oninput="timCham()">
    <span class="hint" id="soDong"></span>
    <button class="b sm" onclick="doiTrang(-1)">Trước</button>
    <span class="m" id="trang" style="font:12.5px var(--mono)"></span>
    <button class="b sm" onclick="doiTrang(1)">Sau</button>
   </div>
   <div id="thanhchon"></div>
   <div class="tbl">
    <table><thead><tr id="thead"></tr></thead><tbody id="tb"></tbody></table>
   </div>
   <div style="padding:10px 18px;border-top:1px solid var(--line)" class="hint">
    Bấm tiêu đề cột để sắp xếp. Tick ô vuông đầu dòng để chọn nhiều chứng từ rồi gán chung một mã chỉ bằng một lần bấm. Nút "Áp tất cả" gán cho mọi giao dịch có cùng tên bóc được, hoặc cùng tháng và cùng mức lương.
   </div>
  </div>
 </div>

 <!-- BUOC 3 -->
 <div id="b3" style="display:none">
  <div class="card pad">
   <div class="eyebrow">Bước 3</div>
   <h2>Kiểm tra trước khi import</h2>
   <table style="margin-top:10px"><tbody id="kt"></tbody></table>
  </div>
  <div class="card pad">
   <h2>Xuất kết quả</h2>
   <div class="hint" style="margin-bottom:14px">Thư mục lưu: <span class="m" id="tm">(chưa chọn, mặc định cạnh file tool)</span></div>
   <div style="display:flex;gap:10px;flex-wrap:wrap">
    <button class="b" onclick="chonThuMuc()">Chọn thư mục lưu</button>
    <button class="b pri" id="btnXuat" onclick="xuat()">Xuất 3 file</button>
    <button class="b" onclick="moThuMuc()">Mở thư mục</button>
   </div>
   <div id="ketXuat" class="hint" style="margin-top:14px"></div>
  </div>
 </div>

 <div class="card">
  <button onclick="hienLog()" style="width:100%;padding:12px 18px;background:none;border:0;
   text-align:left;cursor:pointer;font-weight:700;font-size:13.5px">
   Nhật ký xử lý <span class="hint" id="logN"></span>
  </button>
  <div class="log" id="logBox" style="display:none"></div>
  <div style="padding:0 18px 14px"><button class="b sm" onclick="fetch('/api/mo-nhat-ky')">Mở file nhật ký</button></div>
 </div>
</div>


<script>
var FILES=[["sophu","Sổ phụ ngân hàng","Sao kê tải từ ngân hàng",1],
           ["kh","Danh mục khách hàng","Xuất từ phần mềm kế toán",1],
           ["banra","Bảng kê bán ra","Hóa đơn đầu ra trong kỳ",0],
           ["muavao","Bảng kê mua vào","Hóa đơn đầu vào trong kỳ",0],
           ["luong","Bảng lương","Mỗi tháng một sheet, cột Thực nhận",0]];
var duong={},loc="duyet",trang=0,soTrang=1,DSMA=[],dangMo=0,tHen=null;
var sap="stt",chieu="xuoi",CHON={},STT_LOC=[],pickChon=false;
var COT=[["stt","STT"],["ngay","Ngày"],["tien","Số tiền"],["dg","Diễn giải"],
         ["ma","Mã khách hàng/NCC"],["tk","TK"],["khop","Khớp"],["",  "Ghi chú"]];
function demChon(){var n=0;for(var k in CHON)if(CHON[k])n++;return n;}
function doiSap(k){
  if(!k)return;
  if(sap===k){chieu=(chieu==="xuoi"?"nguoc":"xuoi");}else{sap=k;chieu="xuoi";}
  trang=0;tai();
}
function veThead(){
  document.getElementById("thead").innerHTML=
   '<th class="ck"><input type="checkbox" id="ckAll" onclick="chonTrang(this.checked)" title="Chọn cả trang"></th>'+
   COT.map(function(c){
     var on=(c[0]&&sap===c[0]);
     return '<th class="'+(c[0]?"sx":"")+(on?" on":"")+'"'+(c[0]?' onclick="doiSap(\''+c[0]+'\')"':'')+
       (c[0]==="tien"?' style="text-align:right"':'')+'>'+c[1]+
       (c[0]?'<span class="mt">'+(on?(chieu==="xuoi"?"▲":"▼"):"↕")+'</span>':'')+'</th>';
   }).join("");
}
function chonTrang(v){
  var o=document.querySelectorAll("#tb input.ckr");
  for(var i=0;i<o.length;i++){o[i].checked=v;CHON[o[i].value]=v;}
  veThanhChon();danhDauDong();
}
function chonHet(){
  for(var i=0;i<STT_LOC.length;i++)CHON[STT_LOC[i]]=true;
  var o=document.querySelectorAll("#tb input.ckr");
  for(var j=0;j<o.length;j++)o[j].checked=true;
  veThanhChon();danhDauDong();
}
function boChon(){CHON={};pickChon=false;
  var o=document.querySelectorAll("#tb input.ckr");
  for(var j=0;j<o.length;j++)o[j].checked=false;
  document.getElementById("ckAll").checked=false;veThanhChon();danhDauDong();}
function tickDong(el){CHON[el.value]=el.checked;veThanhChon();danhDauDong();}
function danhDauDong(){
  var tr=document.querySelectorAll("#tb tr");
  for(var i=0;i<tr.length;i++){
    var c=tr[i].querySelector("input.ckr");
    if(c)tr[i].className=tr[i].className.replace(/\s*pick/,"")+(c.checked?" pick":"");
  }
}
function veThanhChon(){
  var n=demChon(),b=document.getElementById("thanhchon");
  if(!n){b.innerHTML="";return;}
  b.innerHTML='<div class="thanhchon"><b>Đã chọn '+n+' chứng từ</b>'+
    '<button class="b sm" onclick="chonHet()">Chọn cả '+STT_LOC.length+' dòng đang lọc</button>'+
    '<button class="b sm" onclick="boChon()">Bỏ chọn</button>'+
    '<span style="flex:1"></span>'+
    '<button class="b pri" style="padding:7px 14px;font-size:13px" onclick="moPickChon()">Gán một mã cho '+n+' chứng từ</button></div>'+
    (pickChon?'<div style="padding:12px 18px;background:var(--blueT);border-bottom:1px solid var(--lineS)">'+
      vePicker(-1)+'</div>':"");
  if(pickChon){var e=document.getElementById("pkq");if(e){locMa(-1);e.focus();}}
}
function moPickChon(){pickChon=!pickChon;veThanhChon();}
function ganNhieu(ma){
  var ds=[];for(var k in CHON)if(CHON[k])ds.push(parseInt(k,10));
  fetch("/api/gan-nhieu",{method:"POST",headers:{"Content-Type":"application/json"},
    body:JSON.stringify({stts:ds,ma:ma})}).then(function(r){return r.json()}).then(function(j){
      if(!j.ok){bao(j.loi||"Không gán được","e");return;}
      bao("Đã gán mã cho "+j.so_dong+" chứng từ và lưu lại cho kỳ sau.");
      CHON={};pickChon=false;tai();napLog();});
}
function boDau(s){return String(s==null?"":s).normalize("NFD").replace(/[\u0300-\u036f]/g,"")
  .replace(/đ/g,"d").replace(/Đ/g,"D").toUpperCase();}

function esc(s){return String(s==null?"":s).replace(/[&<>"]/g,function(c){
  return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c];});}
function tien(n){n=Number(n)||0;return n?n.toLocaleString("vi-VN"):"";}
function num(x){if(x==null||x==="")return 0;if(typeof x==="number")return x;
  var v=parseFloat(String(x).replace(/,/g,""));return isNaN(v)?0:v;}
function bao(t,k){document.getElementById("bao").innerHTML=t?'<div class="msg '+(k||"i")+'">'+esc(t)+'</div>':"";}

function veFile(){
  document.getElementById("oFile").innerHTML=FILES.map(function(f){
    var p=duong[f[0]]||"";
    return '<div class="drop'+(p?" ok":"")+'" onclick="chonFile(\''+f[0]+'\')">'+
      '<b>'+f[1]+(f[3]?' <span style="color:var(--red)">*</span>':'')+'</b>'+
      '<div class="h">'+f[2]+'</div>'+
      '<div class="p">'+(p?esc(p):"Bấm để chọn file .xls hoặc .xlsx")+'</div></div>';
  }).join("");
  document.getElementById("btnChay").disabled=!(duong.sophu&&duong.kh);
}
function chonFile(k){
  bao("Đang mở hộp thoại chọn file. Nếu không thấy, kiểm tra phía sau cửa sổ trình duyệt.");
  fetch("/api/chon-file?loai="+k).then(function(r){return r.json()}).then(function(j){
    duong=j.duong||duong;veFile();bao("");});
}
function chonThuMuc(){
  bao("Đang mở hộp thoại chọn thư mục…");
  fetch("/api/chon-thu-muc").then(function(r){return r.json()}).then(function(j){
    document.getElementById("tm").textContent=j.thu_muc||"(chưa chọn)";bao("");});
}
function moThuMuc(){fetch("/api/mo-thu-muc",{method:"POST",body:"{}"});}

function buoc(n){
  [1,2,3].forEach(function(i){
    document.getElementById("b"+i).style.display=(i===n?"block":"none");
    document.getElementById("s"+i).className=(i===n?"on":"");});
  if(n===2)tai();if(n===3)taiKT();
}
function chay(){
  document.getElementById("rail").style.display="block";
  bao("Đang xử lý, vui lòng đợi…");
  fetch("/api/chay-khop",{method:"POST",body:"{}"}).then(function(r){return r.json()}).then(function(j){
    if(!j.ok){bao(j.loi||"Không chạy được","e");return;}
    theoDoi();});
}
function theoDoi(){
  fetch("/api/tien-trinh").then(function(r){return r.json()}).then(function(j){
    document.getElementById("railI").style.width=(j.phan_tram||0)+"%";
    document.getElementById("tienTrinh").textContent=j.buoc||"";
    napLog();
    if(j.dang_chay){setTimeout(theoDoi,500);return;}
    document.getElementById("rail").style.display="none";
    if((j.buoc||"").indexOf("Lỗi")===0){bao(j.buoc,"e");return;}
    bao("");
    fetch("/api/thiet-lap").then(function(r){return r.json()}).then(function(t){
      if(t.co_ket_qua){
        document.getElementById("s2").disabled=false;
        document.getElementById("s3").disabled=false;
        document.getElementById("chip").className="chip on";
        document.getElementById("chipT").textContent=t.so_gd+" giao dịch";
        document.getElementById("tm").textContent=t.thu_muc||"(chưa chọn, mặc định cạnh file tool)";
        napMa();buoc(2);
      }});
  });
}
function napMa(){
  fetch("/api/danh-sach-ma").then(function(r){return r.json()}).then(function(a){
    DSMA=a.map(function(c){return {ma:c.ma,ten:c.ten,k:boDau(c.ma+" "+c.ten)};});});
}
function moPicker(stt){dangMo=(dangMo===stt?0:stt);tai();}
function vePicker(stt){
  return '<div class="pk" onclick="event.stopPropagation()">'+
    '<input id="pkq" placeholder="Gõ tên khách hàng hoặc mã…" oninput="locMa('+stt+')">'+
    '<div class="pkkq" id="pkkq"></div>'+
    '<div class="pkft">'+(stt<0?'Mã chọn ở đây sẽ gán cho toàn bộ chứng từ đang tick.'
      :'Bấm <b>Dòng này</b> để gán riêng dòng, <b>Tất cả</b> để gán cho mọi giao dịch tương tự.')+'</div></div>';
}
function locMa(stt){
  var el=document.getElementById("pkq");if(!el)return;
  var v=boDau(el.value).trim(),kq=DSMA;
  if(v){var ts=v.split(/\s+/);
    kq=DSMA.filter(function(c){return ts.every(function(t){return c.k.indexOf(t)>=0});});}
  var box=document.getElementById("pkkq");if(!box)return;
  box.innerHTML=kq.slice(0,20).map(function(c){
    return '<div class="pkr"><span class="c">'+esc(c.ma)+'</span><span class="t">'+esc(c.ten)+'</span>'+
      (stt<0
        ? '<button class="sm" onclick="ganNhieu(\''+esc(c.ma)+'\')">Gán cho '+demChon()+' dòng</button>'
        : '<button class="sm" onclick="ganMa('+stt+',\''+esc(c.ma)+'\',\'one\')">Dòng này</button>'+
          '<button class="sm" onclick="ganMa('+stt+',\''+esc(c.ma)+'\',\'all\')">Tất cả</button>')+'</div>';
  }).join("")||'<div class="pkft">Không tìm thấy mã nào khớp.</div>';
}
function timCham(){clearTimeout(tHen);tHen=setTimeout(function(){trang=0;tai();},300);}
function doiTrang(d){var t=trang+d;if(t<0||t>=soTrang)return;trang=t;tai();}
function tai(){
  var q=encodeURIComponent(document.getElementById("q").value||"");
  fetch("/api/ket-qua?loc="+loc+"&q="+q+"&trang="+trang+"&sap="+sap+"&chieu="+chieu)
   .then(function(r){return r.json()}).then(function(j){
    STT_LOC=j.tat_ca_stt||[];veThead();
    var d=j.dem||{};
    var T=[["duyet","Cần duyệt",d.duyet],["trung","Trùng mã danh mục",d.trung],
           ["chua","Chưa khớp",d.chua],["luong","Chi lương",d.luong],
           ["auto","Đã gắn tự động",d.auto],["nhom","Không có đối tác",d.nhom]];
    document.getElementById("tabs").innerHTML=T.map(function(t){
      return '<button class="'+(loc===t[0]?"on":"")+'" onclick="doiLoc(\''+t[0]+'\')">'+
        t[1]+'<span class="n">'+(t[2]||0)+'</span></button>';}).join("");
    document.getElementById("soDong").textContent=j.tong+" dòng";
    soTrang=j.so_trang||1;
    document.getElementById("trang").textContent=(trang+1)+"/"+soTrang;
    document.getElementById("tb").innerHTML=(j.rows||[]).map(ve).join("")||
      '<tr><td colspan="9" class="empty"><b style="display:block;color:var(--ink);font-size:15px;margin-bottom:5px">Không có dòng nào ở nhóm này</b>Chuyển sang nhóm khác hoặc xoá từ khoá tìm kiếm.</td></tr>';
    veThanhChon();danhDauDong();
    if(dangMo){locMa(dangMo);var e=document.getElementById("pkq");if(e)e.focus();}
  });
}
function doiLoc(k){loc=k;trang=0;CHON={};pickChon=false;tai();}
function ve(r){
  var cls=r.loai==="LUONG"&&!r.ma?"luong":(r.L>=85?"":(r.L>0?"duyet":"chua"));
  var chi=num(r.debit),thu=num(r.credit);
  var uv=(!r.ma&&r.uv&&r.uv.length)?'<div class="uv">'+r.uv.slice(0,4).map(function(u){
      return '<button title="'+esc(u.ten)+'" onclick="ganMa('+r.stt+',\''+esc(u.ma)+'\',\'one\')">'+
        esc(u.ten)+(u.d?" · "+u.d:"")+'</button>';}).join("")+'</div>':"";
  return '<tr class="'+cls+(CHON[r.stt]?" pick":"")+'">'+
   '<td class="ck"><input type="checkbox" class="ckr" value="'+r.stt+'" '+
     (CHON[r.stt]?'checked ':'')+'onclick="tickDong(this)"></td>'+
   '<td class="m">'+r.stt+'</td>'+
   '<td class="m">'+esc(r.ngay_hl)+'</td>'+
   '<td class="n" style="color:'+(chi?"var(--red)":"var(--green)")+'">'+(chi?"−"+tien(chi):tien(thu))+'</td>'+
   '<td style="max-width:300px;font-size:12.5px;color:var(--soft)">'+esc((r.dg||"").slice(0,100))+
     (r.ten_boc?'<div style="color:var(--ink);font-weight:600;margin-top:2px">Bóc được: '+esc(r.ten_boc)+'</div>':"")+
     (r.loai==="LUONG"?'<div style="color:var(--violet);font-weight:600;margin-top:2px">Lệnh chi lương'+(r.thang?" · tháng "+r.thang:"")+'</div>':"")+'</td>'+
   '<td><div style="display:flex;gap:5px;align-items:center;flex-wrap:wrap">'+
     (r.ma?'<span class="macode">'+esc(r.ma)+'</span>':'<span class="hint">chưa có mã</span>')+
     '<button class="sm" onclick="moPicker('+r.stt+')">'+(r.ma?"Đổi":"Chọn mã")+'</button>'+
     (r.ma?'<button class="sm" onclick="ganMa('+r.stt+',\''+esc(r.ma)+'\',\'all\')">Áp tất cả</button>'+
           '<button class="sm" onclick="ganMa('+r.stt+',\'\',\'one\')">Xoá</button>':"")+
     '</div>'+
     (r.ten?'<div style="font-size:12px;margin-top:3px;font-weight:600">'+esc(r.ten)+'</div>':"")+
     uv+(dangMo===r.stt?vePicker(r.stt):"")+'</td>'+
   '<td class="m">'+esc(r.tk||"—")+'</td>'+
   '<td class="m" style="text-align:center">'+r.L+'</td>'+
   '<td class="note">'+esc(r.note)+'</td></tr>';
}
function ganMa(stt,ma,pv){
  fetch("/api/gan-ma",{method:"POST",headers:{"Content-Type":"application/json"},
    body:JSON.stringify({stt:stt,ma:ma,pham_vi:pv})})
   .then(function(r){return r.json()}).then(function(j){
     if(!j.ok){bao(j.loi||"Không gán được mã","e");return;}
     dangMo=0;bao(pv==="all"?"Đã áp mã cho mọi dòng tương tự và lưu lại cho kỳ sau.":"");
     tai();napLog();});
}
function taiKT(){
  fetch("/api/kiem-tra").then(function(r){return r.json()}).then(function(a){
    document.getElementById("kt").innerHTML=a.map(function(x){
      return '<tr><td style="width:250px;font-weight:600">'+esc(x.ten)+'</td>'+
        '<td style="width:110px"><span class="badge '+(x.dat?"ok":"no")+'">'+(x.dat?"Đạt":"Không đạt")+'</span></td>'+
        '<td class="m" style="color:var(--soft)">'+esc(x.chi_tiet)+'</td></tr>';}).join("");
    var ba=a.slice(0,3).every(function(x){return x.dat});
    document.getElementById("btnXuat").disabled=!ba;
    if(!ba)document.getElementById("ketXuat").innerHTML=
      '<span style="color:var(--red)">Ba mục kiểm tra đầu chưa đạt nên chưa cho xuất. Đây là dấu hiệu đọc sai cấu trúc file, không phải khớp sai.</span>';
  });
}
function xuat(){
  document.getElementById("ketXuat").textContent="Đang ghi file…";
  fetch("/api/xuat",{method:"POST",headers:{"Content-Type":"application/json"},body:"{}"})
   .then(function(r){return r.json()}).then(function(j){
     if(!j.ok){document.getElementById("ketXuat").innerHTML='<span style="color:var(--red)">'+esc(j.loi)+'</span>';return;}
     document.getElementById("ketXuat").innerHTML="Đã ghi xong:<br>"+
       j.files.map(function(f){return '<span class="m">'+esc(f)+'</span>'}).join("<br>");
     napLog();});
}
function hienLog(){
  var b=document.getElementById("logBox");
  b.style.display=b.style.display==="none"?"block":"none";napLog();
}
function napLog(){
  fetch("/api/nhat-ky").then(function(r){return r.json()}).then(function(j){
    document.getElementById("logN").textContent="("+j.dong.length+" dòng)";
    var b=document.getElementById("logBox");
    if(b.style.display!=="none"){
      b.innerHTML=j.dong.map(function(d){return "<div>"+esc(d)+"</div>"}).join("");
      b.scrollTop=b.scrollHeight;}});
}
fetch("/api/thiet-lap").then(function(r){return r.json()}).then(function(j){
  duong=j.duong||{};veFile();
  document.getElementById("tm").textContent=j.thu_muc||"(chưa chọn, mặc định cạnh file tool)";
  if(j.co_ket_qua){document.getElementById("s2").disabled=false;
    document.getElementById("s3").disabled=false;napMa();}
  napLog();
});
</script></body></html>
"""


TRANG_THAI = {"buoc": "", "phan_tram": 0, "dang_chay": False}
KHOA = threading.Lock()
KET_QUA = {"du_lieu": None}
DUONG = {"sophu": "", "kh": "", "banra": "", "muavao": "", "luong": ""}
HOP_THU = queue.Queue()


def bao(buoc, pt):
    with KHOA:
        TRANG_THAI["buoc"] = buoc
        TRANG_THAI["phan_tram"] = pt


def doc_thiet_lap():
    """GD63: utf-8-sig (tep co BOM truoc day doc ra rong roi bi ghi de)."""
    try:
        with open(SETTINGS_PATH, encoding="utf-8-sig") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def luu_thiet_lap(s):
    """GD63: gop vao tep hien tai (doc lai, chi doi khoa truyen vao), ghi tam + os.replace - khong xoa khoa cua tool khac."""
    try:
        hien = doc_thiet_lap() if os.path.exists(SETTINGS_PATH) else {}
        hien.update(s)
        tam = SETTINGS_PATH + ".%d.tmp" % os.getpid()
        with open(tam, "w", encoding="utf-8") as f:
            json.dump(hien, f, ensure_ascii=False, indent=1)
        os.replace(tam, SETTINGS_PATH)
    except Exception as e:
        LOG.loi("Khong luu duoc cai dat", e)


def hoi_nguoi_dung(kieu, tieu_de):
    tra = queue.Queue()
    HOP_THU.put((kieu, tieu_de, tra))
    try:
        return tra.get(timeout=600)
    except Exception:
        return ""


# ==========================================================================
#  MAY CHU
# ==========================================================================
class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _tra(self, obj, ma=200):
        try:
            raw = json.dumps(obj, ensure_ascii=False, default=str).encode("utf-8")
            self.send_response(ma)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)
        except Exception as e:
            LOG.loi("Khong tra duoc du lieu ve giao dien", e)

    def _loc(self, q):
        kq = KET_QUA["du_lieu"]
        if not kq:
            return []
        R = kq["rows"]
        f = q.get("loc", ["duyet"])[0]
        if f == "auto":
            R = [r for r in R if r["L"] >= 85 and not r["nhom"]]
        elif f == "nhom":
            R = [r for r in R if r["nhom"]]
        elif f == "duyet":
            R = [r for r in R if 0 < r["L"] < 85 and not r.get("trung")]
        elif f == "trung":
            R = [r for r in R if r.get("trung")]
        elif f == "chua":
            R = [r for r in R if r["L"] == 0]
        elif f == "luong":
            R = [r for r in R if r["loai"] == "LUONG"]
        tk = (q.get("q", [""])[0] or "").strip().lower()
        if tk:
            R = [r for r in R if tk in (r["dg"] + " " + r["ten"] + " " + r["ma"] + " " + r["ten_boc"]).lower()]
        sap = q.get("sap", ["stt"])[0]
        nguoc = q.get("chieu", ["xuoi"])[0] == "nguoc"
        khoa = {
            "stt": lambda r: r["stt"],
            "ngay": lambda r: tuple(reversed(str(r["ngay_hl"] or "").split("/"))),
            "tien": lambda r: so(r["credit"]) - so(r["debit"]),
            "dg": lambda r: bo_dau(r["dg"]).lower(),
            "ma": lambda r: (r["ma"] == "", bo_dau(r["ten"] or r["ten_boc"]).lower()),
            "tk": lambda r: str(r["tk"] or ""),
            "khop": lambda r: r["L"],
        }.get(sap)
        if khoa:
            R = sorted(R, key=khoa, reverse=nguoc)
        return R

    def do_GET(self):
        try:
            u = urllib.parse.urlparse(self.path)
            q = urllib.parse.parse_qs(u.query)
            d = u.path
            if d in ("/", "/index.html"):
                raw = GIAO_DIEN.encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)
                return
            if d in ("/logo.png", "/favicon.ico"):
                raw = base64.b64decode(LOGO_B64)
                self.send_response(200)
                self.send_header("Content-Type", "image/png")
                self.send_header("Cache-Control", "max-age=86400")
                self.send_header("Content-Length", str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)
                return
            if d == "/api/thiet-lap":
                kq = KET_QUA["du_lieu"]
                self._tra({"duong": DUONG, "thu_muc": SETTINGS.get("thu_muc_luu", ""),
                           "phien_ban": APP_VERSION, "nhat_ky": LOG_PATH,
                           "co_ket_qua": bool(kq),
                           "so_gd": len(kq["rows"]) if kq else 0})
                return
            if d == "/api/tien-trinh":
                with KHOA:
                    self._tra(dict(TRANG_THAI))
                return
            if d == "/api/nhat-ky":
                self._tra({"dong": LOG.dong[-300:]})
                return
            if d == "/api/chon-file":
                loai = q.get("loai", [""])[0]
                p = hoi_nguoi_dung("file", "Chọn file " + loai)
                if p:
                    DUONG[loai] = p
                    SETTINGS.setdefault("duong", {})[loai] = p
                    luu_thiet_lap(SETTINGS)
                self._tra({"ok": bool(p), "duong": DUONG})
                return
            if d == "/api/chon-thu-muc":
                p = hoi_nguoi_dung("thu_muc", "Chọn thư mục lưu kết quả")
                if p:
                    SETTINGS["thu_muc_luu"] = p
                    luu_thiet_lap(SETTINGS)
                self._tra({"ok": bool(p), "thu_muc": SETTINGS.get("thu_muc_luu", "")})
                return
            if d == "/api/ket-qua":
                kq = KET_QUA["du_lieu"]
                if not kq:
                    self._tra({"rows": [], "tong": 0, "dem": {}})
                    return
                R = self._loc(q)
                tr = int(q.get("trang", ["0"])[0])
                per = 60
                rows = kq["rows"]
                dem = {
                    "auto": sum(1 for r in rows if r["L"] >= 85 and not r["nhom"]),
                    "nhom": sum(1 for r in rows if r["nhom"]),
                    "duyet": sum(1 for r in rows if 0 < r["L"] < 85 and not r.get("trung")),
                    "trung": sum(1 for r in rows if r.get("trung")),
                    "chua": sum(1 for r in rows if r["L"] == 0),
                    "luong": sum(1 for r in rows if r["loai"] == "LUONG"),
                }
                self._tra({"tong": len(R), "trang": tr, "so_trang": max(1, (len(R) + per - 1) // per),
                           "dem": dem, "tat_ca_stt": [r["stt"] for r in R],
                           "rows": [{k: r[k] for k in
                                     ("stt", "ngay_hl", "debit", "credit", "dg", "ten_boc",
                                      "ma", "ten", "tk", "L", "note", "uv", "loai", "thang")}
                                    for r in R[tr * per:(tr + 1) * per]]})
                return
            if d == "/api/danh-sach-ma":
                kq = KET_QUA["du_lieu"]
                self._tra([{"ma": c["ma"], "ten": c["ten"]} for c in (kq["cand"] if kq else [])])
                return
            if d == "/api/kiem-tra":
                kq = KET_QUA["du_lieu"]
                self._tra([{"ten": a, "dat": b, "chi_tiet": c} for a, b, c in kiem_tra(kq)] if kq else [])
                return
            if d == "/api/mo-nhat-ky":
                try:
                    if platform.system() == "Windows":
                        os.startfile(LOG_PATH)
                    elif platform.system() == "Darwin":
                        subprocess.Popen(["open", LOG_PATH])
                    else:
                        subprocess.Popen(["xdg-open", LOG_PATH])
                except Exception as e:
                    LOG.loi("Khong mo duoc nhat ky", e)
                self._tra({"ok": True})
                return
            self._tra({"loi": "khong co duong dan nay"}, 404)
        except Exception as e:
            LOG.loi("Loi khi xu ly yeu cau GET", e)
            self._tra({"loi": str(e)}, 500)

    def do_POST(self):
        try:
            n = int(self.headers.get("Content-Length", 0))
            body = json.loads(self.rfile.read(n) or b"{}")
            d = urllib.parse.urlparse(self.path).path

            if d == "/api/chay-khop":
                if not DUONG["sophu"] or not DUONG["kh"]:
                    self._tra({"ok": False, "loi": "Cần chọn sổ phụ và danh mục khách hàng."})
                    return
                if TRANG_THAI["dang_chay"]:
                    self._tra({"ok": False, "loi": "Đang chạy, vui lòng đợi."})
                    return

                def chay():
                    TRANG_THAI["dang_chay"] = True
                    try:
                        LOG.phan_cach("Chay khop")
                        KET_QUA["du_lieu"] = chay_khop(DUONG, SETTINGS.get("duyet_tay", {}), LOG, bao)
                    except Exception as e:
                        LOG.loi("Loi khi khop", e)
                        bao("Lỗi: " + str(e), 0)
                    finally:
                        TRANG_THAI["dang_chay"] = False

                threading.Thread(target=chay, daemon=True).start()
                self._tra({"ok": True})
                return

            if d == "/api/gan-ma":
                kq = KET_QUA["du_lieu"]
                if not kq:
                    self._tra({"ok": False})
                    return
                stt, ma, pv = body.get("stt"), (body.get("ma") or "").strip(), body.get("pham_vi", "one")
                goc = next((r for r in kq["rows"] if r["stt"] == stt), None)
                if not goc:
                    self._tra({"ok": False, "loi": "Không thấy dòng"})
                    return
                if not ma:
                    goc.update(ma="", ten="", L=0 if not goc["nhom"] else 100, note="Đã xoá mã thủ công")
                    self._tra({"ok": True})
                    return
                c = next((x for x in kq["cand"] if x["ma"] == ma), None)
                if not c:
                    self._tra({"ok": False, "loi": 'Mã "%s" không có trong danh mục' % ma})
                    return
                for r in kq["rows"]:
                    if pv == "one":
                        hit = r["stt"] == stt
                    elif goc["loai"] == "LUONG":
                        hit = r["loai"] == "LUONG" and r["skey"] == goc["skey"]
                    else:
                        hit = bool(r["key"]) and r["key"] == goc["key"]
                    if not hit:
                        continue
                    r.update(ma=c["ma"], ten=c["ten"], L=100, M=100, note="Duyệt tay", uv=[], trung=False)
                    if not r["loai"]:
                        r["tk"] = c["tk"] or ("1311" if so(r["credit"]) > 0 else "3311")
                sk = goc["skey"] if goc["loai"] == "LUONG" else goc["key"]
                if sk:
                    SETTINGS.setdefault("duyet_tay", {})[sk] = ma
                    luu_thiet_lap(SETTINGS)
                LOG.ghi("Duyet tay: %s -> %s (%s)" % (goc["ten_boc"] or goc["dg"][:40], ma, pv))
                self._tra({"ok": True})
                return

            if d == "/api/gan-nhieu":
                kq = KET_QUA["du_lieu"]
                if not kq:
                    self._tra({"ok": False, "loi": "Chưa có kết quả"})
                    return
                ds = set(body.get("stts") or [])
                ma = (body.get("ma") or "").strip()
                if not ds:
                    self._tra({"ok": False, "loi": "Chưa chọn dòng nào"})
                    return
                c = next((x for x in kq["cand"] if x["ma"] == ma), None) if ma else None
                if ma and not c:
                    self._tra({"ok": False, "loi": 'Mã "%s" không có trong danh mục' % ma})
                    return
                n, ghi_nho = 0, {}
                for r in kq["rows"]:
                    if r["stt"] not in ds:
                        continue
                    n += 1
                    if not c:
                        r.update(ma="", ten="", L=100 if r["nhom"] else 0, note="Đã xoá mã thủ công")
                        continue
                    r.update(ma=c["ma"], ten=c["ten"], L=100, M=100,
                             note="Duyệt tay hàng loạt", uv=[], trung=False)
                    if not r["loai"]:
                        r["tk"] = c["tk"] or ("1311" if so(r["credit"]) > 0 else "3311")
                    sk = r["skey"] if r["loai"] == "LUONG" else r["key"]
                    if sk:
                        ghi_nho[sk] = ma
                if ghi_nho:
                    SETTINGS.setdefault("duyet_tay", {}).update(ghi_nho)
                    luu_thiet_lap(SETTINGS)
                LOG.ghi("Duyet hang loat: %d dong -> %s" % (n, ma or "(xoa ma)"))
                self._tra({"ok": True, "so_dong": n})
                return

            if d == "/api/xuat":
                kq = KET_QUA["du_lieu"]
                if not kq:
                    self._tra({"ok": False, "loi": "Chưa có kết quả"})
                    return
                tm = SETTINGS.get("thu_muc_luu") or BASE_DIR
                try:
                    fs = xuat_file(kq, tm, LOG)
                    self._tra({"ok": True, "files": fs, "thu_muc": tm})
                except Exception as e:
                    LOG.loi("Loi khi xuat file", e)
                    self._tra({"ok": False, "loi": str(e)})
                return

            if d == "/api/mo-thu-muc":
                tm = SETTINGS.get("thu_muc_luu") or BASE_DIR
                try:
                    if platform.system() == "Windows":
                        os.startfile(tm)
                    elif platform.system() == "Darwin":
                        subprocess.Popen(["open", tm])
                    else:
                        subprocess.Popen(["xdg-open", tm])
                except Exception as e:
                    LOG.loi("Khong mo duoc thu muc", e)
                self._tra({"ok": True})
                return

            self._tra({"loi": "khong co duong dan nay"}, 404)
        except Exception as e:
            LOG.loi("Loi khi xu ly yeu cau POST", e)
            self._tra({"loi": str(e)}, 500)


# ==========================================================================
#  KHOI DONG
# ==========================================================================
def tim_cong(bat_dau=8770):
    for c in range(bat_dau, bat_dau + 60):
        s = socket.socket()
        try:
            s.bind(("127.0.0.1", c))
            s.close()
            return c
        except Exception:
            pass
        finally:
            try:
                s.close()
            except Exception:
                pass
    return 0


def tim_chrome():
    ung_vien = [
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        "/usr/bin/google-chrome", "/usr/bin/chromium-browser", "/usr/bin/chromium",
    ]
    for p in ung_vien:
        if p and os.path.exists(p):
            return p
    return shutil.which("chrome") or shutil.which("google-chrome") or shutil.which("msedge")


def mo_trinh_duyet(url):
    exe = tim_chrome()
    if exe:
        try:
            subprocess.Popen([exe, "--app=" + url, "--window-size=1360,900"])
            return
        except Exception as e:
            LOG.loi("Khong mo duoc Chrome che do app", e)
    try:
        webbrowser.open(url)
    except Exception as e:
        LOG.loi("Khong mo duoc trinh duyet", e)


def main():
    LOG.phan_cach("Mo tool")
    LOG.ghi("Phien ban tool     : %s" % APP_VERSION, che=False)
    LOG.ghi("Phien ban Python   : %s" % sys.version.replace("\n", " "), che=False)
    LOG.ghi("He dieu hanh       : %s %s" % (platform.system(), platform.release()), che=False)
    LOG.ghi("Thu muc chua tool  : %s" % BASE_DIR, che=False)
    LOG.ghi("Hop thoai chon file: %s" % ("dung duoc" if TK_OK else "KHONG (thieu tkinter)"), che=False)

    for k, v in (SETTINGS.get("duong") or {}).items():
        if k in DUONG and v and os.path.exists(v):
            DUONG[k] = v

    cong = tim_cong()
    if not cong:
        print("Khong tim duoc cong trong. Xem nhat ky:", LOG_PATH)
        input("Nhan Enter de dong...")
        return
    dia_chi = "http://127.0.0.1:%d" % cong
    server = http.server.ThreadingHTTPServer(("127.0.0.1", cong), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    LOG.ghi("Giao dien chay tai: " + dia_chi, che=False)

    print("=" * 62)
    print("  TRICH XUAT SO PHU - phien ban", APP_VERSION)
    print("=" * 62)
    print("  Giao dien dang mo trong trinh duyet:", dia_chi)
    print("  File nhat ky:", LOG_PATH)
    print()
    print("  GIU NGUYEN cua so den nay trong luc dung tool.")
    print("  Dong cua so nay = tat tool.")
    print("=" * 62)

    time.sleep(0.6)
    mo_trinh_duyet(dia_chi)

    if TK_OK:
        root = tk.Tk()
        _gd167_ico(root)
        root.withdraw()

        def kiem():
            try:
                while True:
                    kieu, tieu_de, tra = HOP_THU.get_nowait()
                    try:
                        root.attributes("-topmost", True)
                        if kieu == "thu_muc":
                            p = filedialog.askdirectory(
                                title=tieu_de,
                                initialdir=SETTINGS.get("thu_muc_luu") or os.path.expanduser("~"))
                        else:
                            p = filedialog.askopenfilename(
                                title=tieu_de,
                                filetypes=[("Excel", "*.xls *.xlsx"), ("Tất cả", "*.*")],
                                initialdir=SETTINGS.get("thu_muc_mo") or os.path.expanduser("~"))
                            if p:
                                SETTINGS["thu_muc_mo"] = os.path.dirname(p)
                        root.attributes("-topmost", False)
                        tra.put(p or "")
                    except Exception as e:
                        LOG.loi("Loi hop thoai chon file", e)
                        tra.put("")
            except queue.Empty:
                pass
            root.after(200, kiem)

        root.after(200, kiem)
        try:
            root.mainloop()
        except KeyboardInterrupt:
            pass
    else:
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            pass


if __name__ == "__main__":
    LOG = NhatKy(LOG_PATH, LOG_OLD, LOG_MAX)
    SETTINGS = doc_thiet_lap()
    try:
        main()
    except Exception as exc:
        try:
            LOG.loi("Loi khong mong doi", exc)
        except Exception:
            pass
        print("Co loi:", exc)
        print("Xem chi tiet trong file nhat ky ben canh tool.")
        try:
            input("Nhan Enter de dong...")
        except Exception:
            pass
