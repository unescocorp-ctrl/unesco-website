# -*- coding: utf-8 -*-
"""GD102 - NHAN DANG MAU EXCEL HOA DON (AI tu nhan dang cot) -> MAU BANG KE CHI TIET UNESCO (mau file 1).

Man hinh Hoa don mua vao / ban ra (FrmChungtu) -> Import Excel -> Mau file "4. Excel bat ky - AI tu nhan dang mau":
VB6 goi tool_htkk_unesco.py /hdexcel:<tep> /huong:mua|ban /mst:<MST bo so> /ra:<xlsx> va cho moc DA_XONG_KHOASO.

  - Doc .xlsx / .xlsm / .xls (BIFF5/8) / .csv (stdlib, dung bo doc cua tool_trich_xuat_so_phu).
  - Tim sheet + dong tieu de (1 hoac 2 dong, o gop), nhan dang tung cot bang tu dien dong nghia khong dau
    (so hoa don, ky hieu, mau so, ngay, MST / ten / dia chi nguoi ban - nguoi mua - doi tac, ma hang, ten hang, DVT,
    so luong, don gia, chiet khau, thue suat, thanh tien, tien thue, tong tien...). Mau da gap luu vao
    mau_excel_hd.json (theo chu ky tieu de) -> lan sau nhan ngay.
  - Dong tiep theo cua cung hoa don (o so HD trong / o gop) lay lai thong tin dau hoa don; bo dong Tong cong.
  - Chuan hoa: so (1.234.567,5 / 1,234,567.5), ngay (so Excel, dd/mm/yyyy, yyyy-mm-dd), MST (bu so 0 dau bi Excel cat),
    thue suat (10% / 0.1 / 10 / KCT / KKKNT), tien thue dong (tinh tu thue suat; don lech tong thue ve dong cuoi).
  - Huong: mua = nguoi MUA la cong ty (MST bo so), ban = nguoi BAN la cong ty. Hoa don nguoc huong / cong ty khac -> bo, bao.
  - Ghi xlsx theo dung 36 cot cua mau 1 (HDDTTaiVe): sheet 1 du lieu (dong 1 ten cot, tu dong 2), sheet NhanDang
    (cot nao -> truong nao, canh bao) + <ra>.txt tom tat (UTF-8) cho VB6 hien truoc khi nhap.
  Chi DOC tep cua nguoi dung, KHONG ghi so: viec lap chung tu van do man hinh Hoa don (ImportExcelPurchase / Sale).
  GD108 - /vaoai:1 /khach:<thu muc du lieu AI cua cong ty> (man hinh AI - thu Danh sach hoa don, nut Import bang ke Excel):
    them <ra>.jsonl dung dinh dang JSONL cua tool tai hoa don (moi dong hang 1 dong, khoa <MST ban>|<mau>|<ky hieu>|<so>)
    -> VB6 chep vao ket-qua cua khach -> HDDT_DocKetQua nap vao HDDTTaiVe -> AI ghep ma, dinh khoan (chua ghi so).
    Bo hoa don da co trong phan mem (trang-thai-hd.txt do VB6 ghi ngay truoc khi goi), trung so trong tep.
    Dong mang "nguon": "bangke" -> sau nay tool tai duoc XML cua hoa don (chua lap chung tu) thi VB6 thay bang XML.
"""
import csv
import datetime as _dt
import io
import json
import os
import re
import sys
import unicodedata

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

TEP_MAU = os.path.join(BASE_DIR, "mau_excel_hd.json")
MAU_PHIEN = 110         # GD110: tu dien doi (ho ten nguoi mua, tong tien mat hang, tinh chat) -> mau hoc truoc do nhan dang lai
MA_DA_DOI = [""]          # "VNI" / "TCVN3" khi tep vua doc da doi sang Unicode

# 36 cot cua mau 1 (dung thu tu HDDT_SqlBangHDDTTaiVe / XuatExcelTuBangHDDTTaiVe)
COT_MAU1 = ["KyHieuMauSo", "KyHieuHoaDon", "SoHoaDon", "NgayLap", "NgayNguoiBanKySo", "MCCQT", "NgayCQTKySo",
            "DonViTienTe", "TyGia", "TenNguoiBanNguoiXuatHang", "MSTNguoiBanNguoiXuatHang", "DiaChiNguoiBan",
            "TenNguoiMuaNguoiNhanHang", "MSTNguoiMuaNguoiNhanHang", "DiaChiNguoiMua", "MaVT", "TenHangHoaDichVu",
            "DonViTinh", "SoLuong", "DonGia", "ChietKhau", "ThueSuat", "ThanhTienChuaThue", "TienThue",
            "TongTienChietKhauThuongMai", "TongTienPhi", "TongTienThanhToan", "TrangThaiHoaDon", "KetQuaKiemTraHoaDon",
            "TaiKhoan", "PhanLoai", "ThanhToan", "ThangCT", "MaSoLoaiCT", "STTBangKe", "MaCT"]

TEN_TRUONG = {
    "mau_so": "Mẫu số", "ky_hieu": "Ký hiệu", "so_hd": "Số hoá đơn", "ngay": "Ngày hoá đơn",
    "mst_ban": "MST người bán", "ten_ban": "Tên người bán", "dc_ban": "Địa chỉ người bán",
    "mst_mua": "MST người mua", "ten_mua": "Tên người mua", "dc_mua": "Địa chỉ người mua",
    "mst_dt": "MST đối tác", "ten_dt": "Tên đối tác", "dc_dt": "Địa chỉ đối tác",
    "ma_hang": "Mã hàng", "ten_hang": "Tên hàng hoá, dịch vụ", "dvt": "Đơn vị tính", "so_luong": "Số lượng",
    "don_gia": "Đơn giá", "chiet_khau": "Chiết khấu", "thue_suat": "Thuế suất", "thanh_tien": "Thành tiền chưa thuế",
    "tien_thue": "Tiền thuế", "tong_chua_thue": "Tổng tiền chưa thuế", "tong_thue": "Tổng tiền thuế",
    "tong_ck": "Tổng chiết khấu thương mại", "tong_tt": "Tổng tiền thanh toán", "trang_thai": "Trạng thái hoá đơn",
    "mccqt": "Mã của CQT", "tien_te": "Đơn vị tiền tệ", "ty_gia": "Tỷ giá", "ket_qua": "Kết quả kiểm tra",
    "phan_loai": "Phân loại", "tai_khoan": "Tài khoản", "pl_kh": "Phân loại khách (Thanh toán)",
    "ngay_ky": "Ngày ký", "stt": "STT",
    "hoten_mua": "Họ tên người mua (cá nhân)", "tt_dong": "Tiền dòng có thuế", "tinh_chat": "Tính chất dòng",
    "ma_kh": "Mã khách hàng (không dùng)", "cccd": "Căn cước công dân (không dùng)",
}

# tu dien dong nghia (viet KHONG dau, thuong). (chuoi, diem): khop NGUYEN o = diem; chua tron cum tu = diem - 15
DONG_NGHIA = {
    "mau_so": ["mau so", "ky hieu mau so", "kh mau so", "khmshdon", "mau so hoa don", "mau hd", "mau so hd", "kyhieumauso",
               "ky hieu mau", "ky hieu mau hoa don", "mau"],
    "ky_hieu": ["ky hieu", "ky hieu hoa don", "khhdon", "ky hieu hd", "serial", "kyhieuhoadon", "ky hieu hdon"],
    "so_hd": ["so hoa don", "so hd", "shdon", "so hdon", "invoice no", "hoa don so", "so", "sohoadon", "so hoa don dien tu",
              "invoice number"],
    "ngay": ["ngay hoa don", "ngay lap", "ngay hd", "ngay lap hoa don", "ngay", "ngay thang", "tdlap", "ngaylap",
             "ngay phat hanh", "invoice date", "ngay xuat hoa don", "ngay hdon", "ngay thang nam"],
    "ngay_ky": ["ngay ky", "ngay nguoi ban ky so", "ngaynguoibankyso", "ngay ky so"],
    "mst_ban": ["mst nguoi ban", "ma so thue nguoi ban", "mst ben ban", "mst ncc", "ma so thue nha cung cap",
                "mst nha cung cap", "nbmst", "mst don vi ban", "mst nguoi ban nguoi xuat hang", "mst nguoi ban mst nguoi xuat hang", "msthguoiban",
                "mstnguoibannguoixuathang", "ma so thue ben ban", "mst nb"],
    "ten_ban": ["ten nguoi ban", "nguoi ban", "ten don vi ban", "nha cung cap", "ten ncc", "ten nha cung cap", "nbten",
                "don vi ban hang", "ten nguoi ban nguoi xuat hang", "ten nguoi ban ten nguoi xuat hang", "tennguoibannguoixuathang", "ten ben ban", "ncc",
                "ten don vi ban hang"],
    "dc_ban": ["dia chi nguoi ban", "dia chi ncc", "dia chi ben ban", "dia chi nha cung cap", "nbdchi", "diachinguoiban"],
    "mst_mua": ["mst nguoi mua", "ma so thue nguoi mua", "mst ben mua", "mst khach hang", "ma so thue khach hang",
                "nmmst", "mst nguoi mua nguoi nhan hang", "mst nguoi mua mst nguoi nhan hang", "mstnguoimuanguoinhanhang", "ma so thue ben mua", "mst kh",
                "mst nm"],
    "ten_mua": ["ten nguoi mua", "nguoi mua", "ten don vi mua", "khach hang", "ten khach hang", "nmten",
                "ten nguoi mua nguoi nhan hang", "tennguoimuanguoinhanhang", "ten nguoi mua ten nguoi nhan hang", "ten ben mua", "ten kh",
                "don vi mua hang", "ten don vi mua hang"],
    # GD110: ho ten CA NHAN nguoi mua - tep cong thue co ca "Ten nguoi mua/Ten nguoi nhan hang" lan "Ho ten nguoi mua"
    "hoten_mua": ["ho ten nguoi mua", "ho ten nguoi mua hang", "nguoi mua hang", "ho ten khach hang", "hvtnmhang"],
    "dc_mua": ["dia chi nguoi mua", "dia chi khach hang", "dia chi ben mua", "nmdchi", "diachinguoimua", "dia chi kh"],
    "mst_dt": ["ma so thue", "mst", "mst doi tac", "ma so thue doi tac"],
    "ten_dt": ["ten doi tac", "doi tac", "ten khach hang nha cung cap", "ten kh ncc", "ten don vi", "khach hang ncc",
               "ten khach hang ncc", "ten doi tuong", "doi tuong"],
    "dc_dt": ["dia chi", "dia chi doi tac"],
    "ma_hang": ["ma hang", "ma hang hoa", "ma vt", "ma vat tu", "ma sp", "ma san pham", "mhhdvu", "ma hh", "mavt",
                "ma hang hoa dich vu", "ma hhdv", "ma"],
    "ten_hang": ["ten hang", "ten hang hoa", "ten hang hoa dich vu", "ten hhdv", "hang hoa dich vu", "mat hang",
                 "ten san pham", "dien giai", "noi dung", "ten vat tu", "hang hoa", "tenhanghoadichvu",
                 "ten hang hoa dv", "description", "ten hh", "ten hang hoa dich vu", "ten mat hang"],
    "dvt": ["dvt", "don vi tinh", "dv tinh", "dvtinh", "don vi", "donvitinh", "dvi tinh"],
    "so_luong": ["so luong", "sl", "sluong", "luong", "soluong", "so luong hang"],
    "don_gia": ["don gia", "dgia", "gia", "don gia chua thue", "dongia", "gia ban", "don gia ban"],
    "chiet_khau": ["chiet khau", "tien chiet khau", "ck", "stckhau", "giam gia", "chietkhau", "tien ck"],
    "thue_suat": ["thue suat", "ts", "ltsuat", "tsuat", "thue suat gtgt", "vat rate", "muc thue", "thuesuat",
                  "thue suat vat", "ts gtgt", "phan tram thue", "loai thue suat"],
    "thanh_tien": ["thanh tien", "thanh tien chua thue", "tien hang", "thtien", "gia tri chua thue", "doanh so",
                   "doanh thu chua thue", "tien chua thue", "thanh tien truoc thue", "thanhtienchuathue",
                   "gia tri hhdv chua thue", "doanh so ban chua co thue", "gia tri hang hoa dich vu chua thue",
                   "tien hang chua thue", "thanh tien chua co thue", "so tien chua thue", "doanh so mua chua co thue"],
    "tien_thue": ["tien thue", "thue gtgt", "tien thue gtgt", "tthue", "thue", "vat", "tienthue", "tien vat",
                  "thue vat", "so tien thue"],
    "tong_chua_thue": ["tong tien chua thue", "tgtcthue", "tong tien hang", "tong cong tien hang",
                       "tong gia tri chua thue"],
    "tong_thue": ["tong tien thue", "tgtthue", "tong thue", "tong tien thue gtgt", "tong thue gtgt"],
    "tong_ck": ["tong tien chiet khau", "ttcktmai", "chiet khau thuong mai", "tongtienchietkhauthuongmai",
                "tong chiet khau"],
    "tong_tt": ["tong tien thanh toan", "tong thanh toan", "tong cong", "tong tien", "tgtttbso", "thanh tien sau thue",
                "tong gia tri thanh toan", "tongtienthanhtoan", "tong cong thanh toan", "tien thanh toan",
                "tong tien tt", "tong gia tri", "tong cong thanh tien", "thanh tien co thue", "tien sau thue",
                "tong cong thanh tien co thue"],
    "trang_thai": ["trang thai", "trang thai hoa don", "tinh trang", "tthai", "trangthaihoadon", "tinh trang hoa don"],
    "mccqt": ["ma cqt", "ma cua cqt", "mccqt", "ma co quan thue", "ma hoa don cqt"],
    "tien_te": ["don vi tien te", "loai tien", "tien te", "dvtte", "donvitiente", "ma tien te"],
    "ty_gia": ["ty gia", "tgia", "tygia"],
    "ket_qua": ["ket qua kiem tra", "ket qua kiem tra hoa don", "ketquakiemtrahoadon", "ttxly"],
    "phan_loai": ["phan loai", "phanloai", "loai hang", "phan loai vat tu", "phan loai hang"],
    # GD102: cot "Thanh toan" cua bang ke UNESCO = ma phan loai khach hang (PTR / PTH) -> cot 32 mau 1 (chi nhan MA)
    "pl_kh": ["phan loai khach hang", "phan loai kh", "pl kh", "phan loai doi tuong", "thanh toan"],
    "tai_khoan": ["tai khoan", "taikhoan", "tk", "tk no", "tai khoan no"],
    "stt": ["stt", "so thu tu", "tt"],
    # GD110: tien DONG da co thue (tep chi tiet cong thue: "Tong tien mat hang") - KHONG phai tong chua thue cua hoa don
    "tt_dong": ["tong tien mat hang", "thanh tien sau thue mat hang", "tien sau thue mat hang", "thanh tien co thue mat hang"],
    "tinh_chat": ["tinh chat", "tchat", "tinh chat hang hoa", "tinh chat hhdv", "tinh chat dong hang"],
    # GD110: cot ma / can cuoc khach hang (tep cong thue) - giu rieng, khong de cot Ten nguoi mua nhan nham "Ma khach hang"
    "ma_kh": ["ma khach hang", "ma kh", "ma doi tuong", "ma nguoi mua"],
    "cccd": ["can cuoc cong dan", "cccd", "so cccd", "so dinh danh", "so dinh danh ca nhan", "cmnd cccd"],
}
TRUONG_DAU = ("mau_so", "ky_hieu", "so_hd", "ngay", "ngay_ky", "mst_ban", "ten_ban", "dc_ban", "mst_mua", "ten_mua",
              "dc_mua", "mst_dt", "ten_dt", "dc_dt", "tong_chua_thue", "tong_thue", "tong_ck", "tong_tt",
              "trang_thai", "mccqt", "tien_te", "ty_gia", "ket_qua", "pl_kh", "hoten_mua")
TRUONG_DONG = ("ma_hang", "ten_hang", "dvt", "so_luong", "don_gia", "chiet_khau", "thue_suat", "thanh_tien",
               "tien_thue", "phan_loai", "tai_khoan", "tt_dong", "tinh_chat")
TU_TONG = ("tong cong", "cong", "tong", "cong tien", "tong so", "cong phat sinh", "tong cong tien")


def khong_dau(s):
    s = unicodedata.normalize("NFD", str(s or ""))
    s = "".join(c for c in s if unicodedata.category(c) != "Mn").replace("đ", "d").replace("Đ", "D")
    return s


def chuan(s):
    """thuong, khong dau, chi chu so + 1 dau cach; tach chu hoa kieu CamelCase (KyHieuMauSo)."""
    s = khong_dau(s)
    s = re.sub(r"([a-z])([A-Z])", r"\1 \2", s)
    s = re.sub(r"[^0-9A-Za-z%]+", " ", s).lower()
    return re.sub(r"\s+", " ", s).strip()


def gon(s):
    return chuan(s).replace(" ", "")


def diem_o(o, truong):
    """diem khop 1 o tieu de voi 1 truong (0..100)."""
    h = chuan(o)
    if not h:
        return 0
    hg = h.replace(" ", "")
    tot = 0
    for dn in DONG_NGHIA[truong]:
        dg = dn.replace(" ", "")
        if h == dn or hg == dg:
            d = 100
        elif len(dn) >= 4 and (" " + dn + " ") in (" " + h + " "):
            d = 85 - min(20, max(0, len(h) - len(dn)) // 3)
        elif len(dg) >= 6 and dg in hg:
            d = 70 - min(20, max(0, len(hg) - len(dg)) // 3)
        elif " " in dn and set(dn.split()) <= set(h.split()):
            d = 72 - min(20, max(0, len(h) - len(dn)) // 3)      # du tu, khac thu tu (tieu de 2 dong: "Nguoi ban | MST")
        else:
            continue
        tot = max(tot, d)
    # phat: o co chu "tong" ma truong la cap dong / nguoc lai
    if tot and truong in TRUONG_DONG and re.search(r"\btong\b", h) and truong not in ("thanh_tien", "tt_dong"):
        tot -= 30
    if tot and truong in ("tong_tt", "tong_chua_thue", "tong_thue", "tong_ck") and "tong" not in h and \
            "thanh toan" not in h:
        tot -= 20
    if truong == "thanh_tien" and re.search(r"\b(co thue|sau thue|gom thue|bao gom thue)\b", h) and "chua" not in h:
        tot -= 40       # "Thanh tien co thue" la tong thanh toan, khong phai tien hang
    if truong == "so_hd" and re.search(r"\b(luong|tien|tk|tai khoan|thu tu|ct|chung tu|lo|hop dong)\b", h):
        tot = 0
    if truong == "ngay" and re.search(r"\b(ky|cqt|chung tu|hach toan|thanh toan)\b", h) and "lap" not in h:
        tot = min(tot, 40)
    return max(0, tot)


# ------------------------------------------------------------------ doc tep
def _doc_csv(path):
    raw = open(path, "rb").read()
    for enc in ("utf-8-sig", "utf-16", "cp1258", "cp1252"):
        try:
            txt = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    else:
        txt = raw.decode("utf-8", "replace")
    mau = txt[:4096]
    try:
        dl = csv.Sniffer().sniff(mau, delimiters=",;\t|").delimiter
    except csv.Error:
        dl = ";" if mau.count(";") > mau.count(",") else ","
    rows = [list(r) for r in csv.reader(io.StringIO(txt), delimiter=dl)]
    return {"CSV": rows}, {}


def doc_tep(path):
    """-> (dict sheet -> [[o]], dict sheet -> [(r1,c1,r2,c2)] o gop, set sheet an)"""
    if path.lower().endswith((".csv", ".txt")):
        b, g = _doc_csv(path)
        return _doi_ma(b), g, set()
    import tool_trich_xuat_so_phu as CU
    b = CU.doc_excel(path)
    return _doi_ma(dict(b)), dict(getattr(b, "gop", {}) or {}), set(getattr(b, "an_sheet", set()) or set())


def _doi_ma(tab):
    """Tep cua phan mem cu go chu VNI / TCVN3 (font .VnTime, VNI-Times) -> Unicode (dung bo nhan ma cua bang luong GD78).
    Giu nguyen ten sheet (khoa cua o gop / sheet an)."""
    try:
        import bang_luong_gd78 as BL
        kq, ma = BL.chuyen_bang(tab)
    except Exception:
        return tab
    if ma in ("VNI", "TCVN3"):
        MA_DA_DOI[0] = ma
        return dict(zip(tab.keys(), kq.values()))
    # tep Unicode con vai o go VNI (ten khach "PHAÏM NGOÏC BÍCH"): o co ky tu CHI VNI dung (Ï Ø Û Ñ Ö...) -> doi rieng o do
    dem = [0]

    def o_vni(c):
        if isinstance(c, str) and c and all(ord(x) <= 255 for x in c) and any(x in BL._VNI_RIENG for x in c) \
                and BL.loai_ma([c]) == "VNI" and BL._vni_hop_le(c):
            dem[0] += 1
            return BL.vni_sang_u(c)
        return c
    kq = {sh: [[o_vni(c) for c in (r or [])] for r in (A or [])] for sh, A in zip(tab.keys(), kq.values())}
    if dem[0]:
        MA_DA_DOI[0] = "VNI (%d ô)" % dem[0]
    return kq


def _lap_o_gop(rows, gop):
    """o gop -> chep gia tri o dau vao ca vung (de dong sau cua hoa don co thong tin dau)."""
    for (r1, c1, r2, c2) in gop or []:
        if r1 >= len(rows):
            continue
        v = rows[r1][c1] if c1 < len(rows[r1]) else None
        for r in range(r1, min(r2, len(rows) - 1) + 1):
            for c in range(c1, c2 + 1):
                while len(rows[r]) <= c:
                    rows[r].append(None)
                if rows[r][c] in (None, ""):
                    rows[r][c] = v
    return rows


# ------------------------------------------------------------------ nhan dang tieu de
def _tieu_de_o(rows, r, c, hai_dong):
    a = rows[r][c] if c < len(rows[r]) else None
    s = str(a).strip() if a not in (None, "") and not isinstance(a, float) else ""
    if hai_dong and r + 1 < len(rows):
        b = rows[r + 1][c] if c < len(rows[r + 1]) else None
        sb = str(b).strip() if b not in (None, "") and not isinstance(b, float) else ""
        if sb and sb != s:
            s = (s + " " + sb).strip()
    return s


def gan_cot(tieu_de):
    """tieu_de: {c: chuoi}. Gan moi truong toi da 1 cot, moi cot 1 truong; tham lam theo diem cao nhat."""
    ung = []
    for c, h in tieu_de.items():
        for t in DONG_NGHIA:
            d = diem_o(h, t)
            if d >= 55:
                ung.append((d, -c, c, t))
    ung.sort(reverse=True)
    gan, cot_da = {}, set()
    for d, _, c, t in ung:
        if t in gan or c in cot_da:
            continue
        gan[t] = (c, d)
        cot_da.add(c)
    return gan


def _diem_bang(gan):
    """diem mot cach gan: can so_hd; cong diem truong quan trong."""
    if "so_hd" not in gan:
        return 0
    w = {"so_hd": 3, "ngay": 3, "ky_hieu": 2, "ten_hang": 2, "thanh_tien": 2, "tien_thue": 1.5, "thue_suat": 1.5,
         "mst_ban": 1.5, "mst_mua": 1.5, "mst_dt": 1, "ten_ban": 1, "ten_mua": 1, "ten_dt": 1, "so_luong": 1,
         "don_gia": 1, "dvt": 1, "tong_tt": 1, "mau_so": 1}
    return sum(w.get(t, 0.5) * (d / 100.0) for t, (c, d) in gan.items())


def tim_bang(sheets, gop, an, thieu_so=None):
    """-> dict ket qua nhan dang tot nhat: sheet, dong tieu de, so dong tieu de, gan cot, diem.
    thieu_so (dict): ghi bang tot nhat KHONG co cot So hoa don (de bao ro tep thieu cot nao)."""
    tot = None
    for ten, rows in sheets.items():
        if ten in an or not rows:
            continue
        rows = _lap_o_gop([list(r) for r in rows], gop.get(ten))
        for r in range(min(len(rows), 40)):
            nc = len(rows[r])
            for hai in (False, True):
                td = {}
                for c in range(nc):
                    s = _tieu_de_o(rows, r, c, hai)
                    if s:
                        td[c] = s
                if len(td) < 3:
                    continue
                g = gan_cot(td)
                d = _diem_bang(g) - (0.3 if hai else 0)
                if not hai and r > 0:
                    tren = [x for x in rows[r - 1] if isinstance(x, str) and x.strip()]
                    if len(set(tren)) >= 2:
                        d -= 0.5        # dong tren la nhom cot (Hoa don | Nguoi ban ...) -> uu tien tieu de 2 dong
                if d > 0 and (tot is None or d > tot["diem"]):
                    tot = {"sheet": ten, "dong": r, "hai_dong": hai, "gan": g, "diem": d, "tieu_de": td, "rows": rows}
                if thieu_so is not None and "so_hd" not in g:
                    dk = _diem_bang(dict(g, so_hd=(-1, 0)))
                    if dk > thieu_so.get("diem", 0):
                        thieu_so.update({"sheet": ten, "dong": r, "gan": g, "diem": dk})
    return tot


NHAN_DAU = ("mst_ban", "ten_ban", "dc_ban", "mst_mua", "ten_mua", "dc_mua")


def thong_tin_dau(rows, den):
    """Phan dau tep (tren dong tieu de): "Ten nguoi ban: ...", "MST nguoi ban: | 0300000001" -> {truong: gia tri}.
    Dung khi bang khong co cot do (vd bang ke hoa don ban ra cua mot don vi: MST nguoi ban ghi o dau trang)."""
    kq = {}
    for r in range(min(den, len(rows))):
        row = rows[r]
        for c, o in enumerate(row):
            if not isinstance(o, str) or not o.strip():
                continue
            nhan, co_hai_cham, gt = o.partition(":")
            if len(chuan(nhan)) > 40:
                continue
            tot = None
            for t in NHAN_DAU:
                d = diem_o(nhan, t)
                if d >= 85 and (tot is None or d > tot[0]):
                    tot = (d, t)
            if not tot:
                continue
            gt = gt.strip() if co_hai_cham else ""
            if not gt:
                for x in row[c + 1:]:
                    if x not in (None, "") and not (isinstance(x, str) and not x.strip()):
                        gt = x
                        break
            if gt in (None, "") or (isinstance(gt, str) and re.match(r"^[.\s_…-]*$", gt)):
                continue
            if tot[1].startswith("mst") and not mst(gt):
                continue
            kq.setdefault(tot[1], gt)
    return kq


def chu_ky(td):
    return "|".join(gon(td[c]) for c in sorted(td))[:600]


def nap_mau():
    try:
        with io.open(TEP_MAU, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def luu_mau(ky, gan, ten_tep):
    m = nap_mau()
    m[ky] = {"gan": {t: c for t, (c, d) in gan.items()}, "tep": os.path.basename(ten_tep), "phien": MAU_PHIEN,
             "luc": _dt.datetime.now().strftime("%Y-%m-%d %H:%M"),
             "lan": int(m.get(ky, {}).get("lan", 0)) + 1 if m.get(ky, {}).get("phien") == MAU_PHIEN else 1}
    try:
        tam = TEP_MAU + ".tmp"
        with io.open(tam, "w", encoding="utf-8") as f:
            json.dump(m, f, ensure_ascii=False, indent=1)
        os.replace(tam, TEP_MAU)
    except Exception:
        pass
    return m[ky]["lan"]


# ------------------------------------------------------------------ chuan hoa gia tri
def so(v):
    if v is None or v == "":
        return None
    if isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip().replace(" ", "").replace(" ", "")
    s = re.sub(r"(?i)(vnd|vnđ|đ|d)$", "", s)
    am = s.startswith("(") and s.endswith(")")
    s = s.strip("()")
    if s.startswith("-"):
        am, s = True, s[1:]
    if not s or not re.match(r"^[0-9.,]+$", s):
        return None
    if "." in s and "," in s:
        if s.rfind(",") > s.rfind("."):
            s = s.replace(".", "").replace(",", ".")
        else:
            s = s.replace(",", "")
    elif "," in s:
        p = s.split(",")
        s = s.replace(",", "") if all(len(x) == 3 for x in p[1:]) and len(p) > 1 else s.replace(",", ".")
    elif "." in s:
        p = s.split(".")
        if len(p) > 2 or (len(p) == 2 and len(p[1]) == 3 and len(p[0]) <= 3 and p[0] not in ("0",)):
            s = s.replace(".", "")
    try:
        x = float(s)
    except ValueError:
        return None
    return -x if am else x


def ngay(v):
    if v is None or v == "":
        return None
    if isinstance(v, _dt.datetime):
        return v.date()
    if isinstance(v, _dt.date):
        return v
    if isinstance(v, (int, float)):
        if 20000 < v < 80000:
            return (_dt.datetime(1899, 12, 30) + _dt.timedelta(days=int(v))).date()
        return None
    s = str(v).strip()
    m = re.match(r"^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})", s)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
    else:
        m = re.match(r"^(\d{1,2})[-/.](\d{1,2})[-/.](\d{2,4})", s)
        if not m:
            m2 = re.search(r"ng[aà]y\s*(\d{1,2})\s*th[aá]ng\s*(\d{1,2})\s*n[aă]m\s*(\d{4})", s, re.I)
            if not m2:
                return None
            d, mo, y = int(m2.group(1)), int(m2.group(2)), int(m2.group(3))
        else:
            d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
            if y < 100:
                y += 2000
            if mo > 12 and d <= 12:
                d, mo = mo, d
    try:
        return _dt.date(y, mo, d)
    except ValueError:
        return None


def mst(v):
    """MST 10 so / 10-3 so (chi nhanh) / CCCD 12 so. So Excel mat so 0 dau -> bu lai."""
    if v is None or v == "":
        return ""
    if isinstance(v, float):
        if not v.is_integer():
            return ""
        d = str(int(v))
        if len(d) in (9, 11, 12):        # 10 / CCCD 12 / 13 so bi mat so 0 dau
            d = "0" + d
    else:
        s = re.sub(r"[\s.]", "", str(v).strip())
        m = re.match(r"^(\d{10})-(\d{3})$", s)
        if m:
            return s
        d = re.sub(r"\D", "", s)
        if not d or len(d) < 9:
            return ""
        if len(d) == 9:
            d = "0" + d
    if len(d) == 13:
        return d[:10] + "-" + d[10:]
    if len(d) in (10, 12):
        return d
    return ""


def mst_so(s):
    return re.sub(r"\D", "", s or "")


def cung_mst(a, b):
    a, b = mst_so(a), mst_so(b)
    return bool(a) and bool(b) and (a == b or a[:10] == b[:10] and (len(a) == 10 or len(b) == 10))


def thue_suat(v):
    if v is None or v == "":
        return ""
    if isinstance(v, (int, float)):
        x = float(v)
        if 0 < x < 1:
            x *= 100
        x = round(x, 2)
        return ("%g%%" % x)
    s = khong_dau(str(v)).strip().upper().replace(" ", "")
    if s in ("KCT", "KHONGCHIUTHUE", "KHONGCHIU THUE"):
        return "KCT"
    if s in ("KKKNT", "KHONGKEKHAI", "KHONGKEKHAINOPTHUE"):
        return "KKKNT"
    if s.startswith("KHAC"):
        return str(v).strip().upper()
    x = so(s.rstrip("%"))
    if x is None:
        return str(v).strip()
    if 0 < x < 1 and "%" not in s:
        x *= 100
    return "%g%%" % round(x, 2)


def ts_so(ts):
    m = re.match(r"^(\d+(?:\.\d+)?)%$", ts or "")
    return float(m.group(1)) if m else None


def chu(v):
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return re.sub(r"\s+", " ", str(v)).strip()


def ma_pl(v):
    """ma phan loai (vat tu / khach hang): chi nhan MA ngan (HH, NVL, PTR...), khong nhan chu dien giai."""
    s = chu(v).upper()
    return s if re.match(r"^[A-Z][A-Z0-9_]{0,9}$", s) else ""


def ma_tk(v):
    s = chu(v).upper()
    return s if re.match(r"^\d{3,10}[A-Z0-9]{0,6}$", s) else ""


def ma_pl_kh(v):
    s = ma_pl(v)
    return s if len(s) >= 2 and s not in ("TM", "CK", "TMCK", "TT", "NH") else ""


def ma_tinh_chat(v):
    """GD110: tinh chat dong hang (cot Tinh chat cua tep cong thue) -> '1' hang hoa / '2' khuyen mai / '3' chiet khau /
    '4' ghi chu, dien giai; khong ro -> ''."""
    s = chuan(chu(v))
    if s in ("1", "2", "3", "4"):
        return s
    if not s:
        return ""
    if "khuyen mai" in s or s == "km":
        return "2"
    if "chiet khau" in s or s == "ck":
        return "3"
    if "ghi chu" in s or "dien giai" in s:
        return "4"
    if "hang hoa" in s or "dich vu" in s:
        return "1"
    return ""


def so_hd(v):
    s = chu(v)
    s = re.sub(r"^0+(?=\d)", "", s) if re.match(r"^\d+$", s) else s
    return s


# ------------------------------------------------------------------ doc du lieu
def _la_tong(x):
    """o nhan dong cong: "Tong cong", "Cong", "Tong cong tien hang", "Cong thang 9"... (KHONG bat "Tong dai", "Cong ty")."""
    t = chuan(x)
    return t in TU_TONG or re.match(r"^(tong cong|cong tien|cong phat sinh|tong so|cong so)\b", t) is not None or \
        re.match(r"^(tong|cong)( (hoa don|thang|quy|nam|ky|trang|nhom|muc|i|ii|iii|iv|\d+))*( \d+)?$", t) is not None


def doc_hoa_don(kq):
    rows, gan, r0 = kq["rows"], kq["gan"], kq["dong"] + (2 if kq["hai_dong"] else 1)
    cot = {t: c for t, (c, d) in gan.items()}
    md = {t: v for t, v in (kq.get("mac_dinh") or {}).items() if t not in cot}

    def lay(row, t):
        c = cot.get(t)
        return row[c] if c is not None and c < len(row) else None
    dong, dau_truoc, bo_tong, bo_trong = [], None, 0, 0
    for r in range(r0, len(rows)):
        row = rows[r]
        if not any(x not in (None, "") for x in row):
            bo_trong += 1
            continue
        o_co = [x for x in row if x not in (None, "")]
        if len(o_co) >= 3 and len(set(chu(x) for x in o_co)) == 1:
            dau_truoc = None
            continue            # dong nhom gop ngang ca dong ("1. Hang hoa, dich vu dung rieng cho SXKD...")
        sh = so_hd(lay(row, "so_hd"))
        if len(sh) > 25 or sh.count(" ") >= 3:
            continue            # o so HD la chu dien giai (dong muc / ghi chu), khong phai so hoa don
        nhan = [x for x in row[:max(6, cot.get("ten_hang", 0) + 1)] if isinstance(x, str)]
        co_dong = any(lay(row, t) not in (None, "") for t in ("ten_hang", "thanh_tien", "so_luong", "tien_thue"))
        if not sh and any(_la_tong(x) for x in nhan) and lay(row, "don_gia") in (None, ""):
            bo_tong += 1
            continue
        if sh and (not re.search(r"\d", sh) or sh == "0"):
            # dong nhom / tieu de lap lai / dong mau trong (so 0)
            continue
        if o_co and sum(1 for x in o_co if re.match(r"^[(\[]?\d{1,2}[)\]]?$|^[(\[]?[A-Z][)\]]?$", chu(x))) >= 0.7 * len(o_co) \
                and ngay(lay(row, "ngay")) is None:
            continue            # dong danh so cot (1) (2) (3) / A B C duoi tieu de
        if sh:
            dau = {t: lay(row, t) for t in TRUONG_DAU}
            for t, v in md.items():
                if dau.get(t) in (None, ""):
                    dau[t] = v
            if dau_truoc and dau_truoc.get("so_hd") == dau.get("so_hd"):
                for t in TRUONG_DAU:
                    if dau.get(t) in (None, "") and dau_truoc.get(t) not in (None, ""):
                        dau[t] = dau_truoc[t]
            dau_truoc = dau
        elif dau_truoc and co_dong:
            dau = dict(dau_truoc)
        else:
            continue
        d = {t: lay(row, t) for t in TRUONG_DONG}
        d["_dong"] = r + 1
        d.update({("h_" + t): dau.get(t) for t in TRUONG_DAU})
        dong.append(d)
    return dong, bo_tong


def lap_hoa_don(dong, huong, mst_cty):
    """-> list hoa don {dau..., dong:[...]}, canh bao"""
    hd, thu_tu, canh = {}, [], []
    for d in dong:
        nl = ngay(d["h_ngay"])
        sh = so_hd(d["h_so_hd"])
        mb, mm, mdt = mst(d["h_mst_ban"]), mst(d["h_mst_mua"]), mst(d["h_mst_dt"])
        tb, tm, tdt = chu(d["h_ten_ban"]), chu(d["h_ten_mua"]) or chu(d["h_hoten_mua"]), chu(d["h_ten_dt"])     # GD110
        db, dm, ddt = chu(d["h_dc_ban"]), chu(d["h_dc_mua"]), chu(d["h_dc_dt"])
        # doi tac chung (khong ro ben ban / mua) -> theo huong
        if huong == "mua":
            mb, tb, db = mb or mdt, tb or tdt, db or ddt
        else:
            mm, tm, dm = mm or mdt, tm or tdt, dm or ddt
        k = (mst_so(mb), chu(d["h_mau_so"]), chu(d["h_ky_hieu"]).upper(), sh, nl)
        if k not in hd:
            hd[k] = {"so_hd": sh, "ngay": nl, "mau_so": chu(d["h_mau_so"]), "ky_hieu": chu(d["h_ky_hieu"]).upper(),
                     "mst_ban": mb, "ten_ban": tb, "dc_ban": db, "mst_mua": mm, "ten_mua": tm, "dc_mua": dm,
                     "tong_chua_thue": so(d["h_tong_chua_thue"]), "tong_thue": so(d["h_tong_thue"]),
                     "tong_ck": so(d["h_tong_ck"]), "tong_tt": so(d["h_tong_tt"]), "trang_thai": chu(d["h_trang_thai"]),
                     "mccqt": chu(d["h_mccqt"]), "tien_te": chu(d["h_tien_te"]) or "VND",
                     "ty_gia": so(d["h_ty_gia"]) or 1, "ket_qua": chu(d["h_ket_qua"]),
                     "ngay_ky": ngay(d["h_ngay_ky"]), "pl_kh": ma_pl_kh(d["h_pl_kh"]), "dong": [], "dong_excel": []}
            thu_tu.append(k)
        h = hd[k]
        h["dong_excel"].append(d["_dong"])
        tt = so(d["thanh_tien"])
        if tt is None and d["ten_hang"] in (None, "") and so(d["so_luong"]) is None:
            continue
        tc = ma_tinh_chat(d["tinh_chat"])
        if tc == "4" and not tt:
            continue            # GD110: dong ghi chu / dien giai (tinh chat 4) - khong phai hang (nhu tool tai XML)
        h["dong"].append({"tchat": tc, "tt_dong": so(d["tt_dong"]),
                          "ma_hang": chu(d["ma_hang"]), "ten_hang": chu(d["ten_hang"]), "dvt": chu(d["dvt"]),
                          "so_luong": so(d["so_luong"]), "don_gia": so(d["don_gia"]),
                          "chiet_khau": so(d["chiet_khau"]) or 0.0, "thue_suat": thue_suat(d["thue_suat"]),
                          "thanh_tien": tt, "tien_thue": so(d["tien_thue"]), "phan_loai": ma_pl(d["phan_loai"]),
                          "tai_khoan": ma_tk(d["tai_khoan"])})
    ds = [hd[k] for k in thu_tu]
    for h in ds:
        _hoan_thien(h, canh)
    return ds, canh


def _hoan_thien(h, canh):
    dong = h["dong"]
    h["_chi_tong"] = not dong          # GD108: bang ke chi co tong tien hoa don (khong co dong hang)
    if not dong:
        tct = h["tong_chua_thue"]
        if tct is None and h["tong_tt"] is not None:
            tct = h["tong_tt"] - (h["tong_thue"] or 0)
        dong.append({"ma_hang": "", "ten_hang": "Hàng hóa, dịch vụ", "dvt": "", "so_luong": None, "don_gia": None,
                     "chiet_khau": 0.0, "thue_suat": "", "thanh_tien": tct or 0.0, "tien_thue": h["tong_thue"],
                     "phan_loai": "", "tai_khoan": ""})
    for x in dong:
        if x["thanh_tien"] is None:
            if x["so_luong"] is not None and x["don_gia"] is not None:
                x["thanh_tien"] = round(x["so_luong"] * x["don_gia"] - (x["chiet_khau"] or 0), 2)
            else:
                x["thanh_tien"] = 0.0
        if x["don_gia"] is None and x["so_luong"]:
            x["don_gia"] = round((x["thanh_tien"] + (x["chiet_khau"] or 0)) / x["so_luong"], 4)
        if x["so_luong"] is None:
            x["so_luong"] = 0.0 if x["don_gia"] is None else 1.0
        if x["don_gia"] is None:
            x["don_gia"] = 0.0
        p = ts_so(x["thue_suat"])
        if not x["thue_suat"] and x["tien_thue"] is not None and x["thanh_tien"]:
            r = x["tien_thue"] / x["thanh_tien"] * 100
            gan = min((0, 5, 8, 10), key=lambda q: abs(q - r))
            if abs(gan - r) < 0.6:
                x["thue_suat"] = "%d%%" % gan
                p = float(gan)
        if x["tien_thue"] is None and x.get("tt_dong") is not None and x["thanh_tien"]:
            x["tien_thue"] = round(x["tt_dong"] - x["thanh_tien"], 2)      # GD110: tien dong co thue - chua thue
        if x["tien_thue"] is None:
            x["tien_thue"] = round(x["thanh_tien"] * p / 100.0) if p is not None else 0.0
    if not any(x["thue_suat"] for x in dong) and h["tong_thue"] and h["tong_chua_thue"]:
        r = h["tong_thue"] / h["tong_chua_thue"] * 100
        gan = min((0, 5, 8, 10), key=lambda q: abs(q - r))
        if abs(gan - r) < 0.6:
            for x in dong:
                x["thue_suat"] = "%d%%" % gan
    tong_tien = sum(x["thanh_tien"] for x in dong)
    tong_thue = sum(x["tien_thue"] for x in dong)
    if h["tong_thue"] is not None:
        lech = h["tong_thue"] - tong_thue
        if 0.5 <= abs(lech) < 1000 * len(dong) and not all(x["tien_thue"] == 0 for x in dong):
            dong[-1]["tien_thue"] += lech
            tong_thue += lech
        elif abs(lech) >= 1000 * len(dong):
            canh.append("HĐ %s: tổng thuế trên file %s khác cộng dòng %s" % (h["so_hd"], _t(h["tong_thue"]),
                                                                            _t(tong_thue)))
    if h["tong_chua_thue"] is not None and abs(h["tong_chua_thue"] - tong_tien) >= 1 and \
            abs(h["tong_chua_thue"] - tong_tien - tong_thue) < 1 and tong_thue:
        h["tong_chua_thue"] = None          # GD110: cot gan nham la tien DA CO thue (tien hang + thue) -> bo, khong canh bao
    if h["tong_chua_thue"] is not None and abs(h["tong_chua_thue"] - tong_tien) >= 1:
        canh.append("HĐ %s: tổng tiền hàng trên file %s khác cộng dòng %s" % (h["so_hd"], _t(h["tong_chua_thue"]),
                                                                               _t(tong_tien)))
    if abs(tong_tien) < 0.5 and abs(tong_thue) >= 1:
        canh.append("HĐ %s: tiền hàng 0 nhưng tiền thuế %s - kiểm tra lại cột tiền trong tệp" % (h["so_hd"], _t(tong_thue)))
    if h["tong_tt"] is None:
        h["tong_tt"] = tong_tien + tong_thue - (h["tong_ck"] or 0)
    h["tien_hang"], h["tien_thue"] = tong_tien, tong_thue


def _t(x):
    try:
        return "{:,.0f}".format(x).replace(",", ".")
    except Exception:
        return str(x)


def loc_huong(ds, huong, mst_cty):
    giu, bo = [], []
    for h in ds:
        ly = ""
        tt = chuan(h["trang_thai"])
        if re.search(r"\b(huy|bi thay the|da bi thay the|xoa bo)\b", tt):
            ly = "hoá đơn %s" % h["trang_thai"]
        elif not h["so_hd"]:
            ly = "thiếu số hoá đơn"
        elif h["ngay"] is None:
            ly = "không đọc được ngày hoá đơn"
        elif mst_cty:
            la_mua = cung_mst(h["mst_mua"], mst_cty)
            la_ban = cung_mst(h["mst_ban"], mst_cty)
            if huong == "mua":
                if la_ban and not la_mua:
                    ly = "là hoá đơn BÁN RA của công ty (người bán = MST bộ sổ)"
                elif h["mst_mua"] and not la_mua:
                    ly = "người mua MST %s không phải công ty đang mở" % h["mst_mua"]
                elif not h["mst_mua"]:
                    h["mst_mua"] = mst_cty
            else:
                if la_mua and not la_ban:
                    ly = "là hoá đơn MUA VÀO của công ty (người mua = MST bộ sổ)"
                elif h["mst_ban"] and not la_ban:
                    ly = "người bán MST %s không phải công ty đang mở" % h["mst_ban"]
                elif not h["mst_ban"]:
                    h["mst_ban"] = mst_cty
        if ly:
            bo.append((h, ly))
        else:
            giu.append(h)
    return giu, bo


# ------------------------------------------------------------------ ghi mau 1
def ghi_mau1(ds, huong, ra, kq, bo, canh, ten_tep, ky_mau, lan_mau):
    from xlsx_viet import SoExcel
    wb = SoExcel(font="Times New Roman", co=11)
    k_td = wb.kieu(dam=True, nen="D9E1F2", khung=True, can="giua", xuong=True)
    k_so = wb.kieu(so="#,##0.##", khung=True)
    k_ng = wb.kieu(so="dd/mm/yyyy", khung=True)
    k_ch = wb.kieu(khung=True)
    ws = wb.sheet("HDDTTaiVe", cot=[8, 10, 10, 11, 11, 14, 11, 7, 6, 32, 15, 30, 32, 15, 30, 12, 36, 8, 10, 12, 10,
                                    8, 14, 12, 12, 8, 14, 14, 12, 8, 8, 8, 7, 7, 7, 7])
    for c, t in enumerate(COT_MAU1, 1):
        ws.o(1, c, t, k_td)
    r = 2
    so_dong = 0
    for h in ds:
        for x in h["dong"]:
            gt = [h["mau_so"], h["ky_hieu"], h["so_hd"], h["ngay"], h["ngay_ky"], h["mccqt"], None, h["tien_te"],
                  h["ty_gia"], h["ten_ban"], h["mst_ban"], h["dc_ban"], h["ten_mua"], h["mst_mua"], h["dc_mua"],
                  x["ma_hang"], x["ten_hang"], x["dvt"], x["so_luong"], x["don_gia"], x["chiet_khau"], x["thue_suat"],
                  x["thanh_tien"], x["tien_thue"], h["tong_ck"] or 0, 0, h["tong_tt"],
                  h["trang_thai"] or "Hóa đơn mới", h["ket_qua"], x["tai_khoan"] or None,
                  x["phan_loai"] or "HH", h.get("pl_kh") or ("PTR" if huong == "mua" else "PTH"), "%02d" % h["ngay"].month,
                  1 if huong == "mua" else 8, None, None]
            for c, v in enumerate(gt, 1):
                if isinstance(v, _dt.date):
                    ws.o(r, c, v, k_ng)
                elif isinstance(v, (int, float)) and not isinstance(v, bool) and c not in (34,):
                    ws.o(r, c, v, k_so)
                else:
                    ws.o(r, c, v, k_ch)
            r += 1
            so_dong += 1
    ws.dong_bang(2, 4)
    # sheet nhan dang
    wn = wb.sheet("NhanDang", cot=[30, 14, 46, 10])
    k_dam = wb.kieu(dam=True, co=13)
    wn.o(1, 1, "AI NHẬN DẠNG MẪU EXCEL HOÁ ĐƠN %s" % ("MUA VÀO" if huong == "mua" else "BÁN RA"), k_dam)
    wn.o(2, 1, "Tệp: %s  |  sheet: %s  |  dòng tiêu đề: %d%s" % (os.path.basename(ten_tep), kq["sheet"], kq["dong"] + 1,
                                                                   " - %d" % (kq["dong"] + 2) if kq["hai_dong"] else ""))
    wn.o(3, 1, "Mẫu: %s" % ("đã gặp %d lần" % (lan_mau - 1) if lan_mau > 1 else "mẫu mới (đã ghi nhớ)"))
    them = []
    if kq.get("mac_dinh"):
        them.append("Lấy từ phần đầu tệp: " + "; ".join("%s = %s" % (TEN_TRUONG.get(t, t), chu(v)[:60])
                                                        for t, v in kq["mac_dinh"].items()))
    if MA_DA_DOI[0]:
        them.append("Chữ %s đã đổi sang Unicode" % MA_DA_DOI[0])
    if them:
        wn.o(4, 1, " | ".join(them))
    for c, t in enumerate(["Trường của phần mềm", "Cột Excel", "Tiêu đề cột trong tệp", "Độ khớp"], 1):
        wn.o(5, c, t, k_td)
    rr = 6
    from xlsx_viet import dia_chi
    for t in DONG_NGHIA:
        if t in kq["gan"]:
            c, d = kq["gan"][t]
            wn.o(rr, 1, TEN_TRUONG.get(t, t), k_ch)
            wn.o(rr, 2, re.sub(r"\d", "", dia_chi(1, c + 1)), k_ch)
            wn.o(rr, 3, kq["tieu_de"].get(c, ""), k_ch)
            wn.o(rr, 4, "%d%%" % d, k_ch)
            rr += 1
    rr += 1
    if bo:
        wn.o(rr, 1, "HOÁ ĐƠN KHÔNG NHẬP (%d)" % len(bo), k_dam)
        rr += 1
        for h, ly in bo[:500]:
            wn.o(rr, 1, "HĐ %s %s" % (h["so_hd"] or "?", h["ngay"].strftime("%d/%m/%Y") if h["ngay"] else ""), k_ch)
            wn.o(rr, 3, ly, k_ch)
            rr += 1
        rr += 1
    if canh:
        wn.o(rr, 1, "CẦN XEM LẠI (%d)" % len(canh), k_dam)
        rr += 1
        for s in canh[:500]:
            wn.o(rr, 1, s)
            rr += 1
    tam = ra + ".tmp.xlsx"
    wb.luu(tam)
    os.replace(tam, ra)
    return so_dong


def chay(tep, huong, mst_cty, ra, ghi_log=print, vao_ai=False, khach=""):
    """-> (duong xlsx mau 1, loi). Ghi them <ra>.txt tom tat UTF-8 cho VB6.
    GD108 vao_ai: them <ra>.jsonl (chi khi co hoa don moi) de VB6 dua vao danh sach AI; khach = thu muc du lieu AI
    cua cong ty (co trang-thai-hd.txt)."""
    huong = "ban" if str(huong).lower().startswith("b") else "mua"
    mst_cty = mst(mst_cty)
    if not os.path.isfile(tep):
        return None, "Không tìm thấy tệp: %s" % tep
    MA_DA_DOI[0] = ""
    try:
        sheets, gop, an = doc_tep(tep)
    except Exception as e:
        ghi_log("[HD EXCEL] khong doc duoc %s: %s" % (tep, e))
        return None, "Không đọc được tệp Excel (%s). Hãy mở tệp bằng Excel rồi lưu lại dạng .xlsx và thử lại." % e
    thieu_so = {}
    kq = tim_bang(sheets, gop, an, thieu_so)
    if not kq or kq["diem"] < 4:
        if thieu_so.get("diem", 0) >= 4:
            nhan = ", ".join("%s = cột %s" % (TEN_TRUONG.get(t, t), _ten_cot(c)) for t, (c, d) in
                             sorted(thieu_so["gan"].items(), key=lambda x: x[1][0]) if t != "stt")
            return None, ("Tệp không có cột Số hoá đơn (sheet \"%s\", dòng tiêu đề %d; AI nhận ra: %s). Cần bảng kê hoá đơn "
                          "đã phát hành có cột Số hoá đơn - tệp lập hoá đơn chưa có số, báo cáo doanh thu không nhập được."
                          % (thieu_so["sheet"], thieu_so["dong"] + 1, nhan[:500]))
        return None, ("Không nhận dạng được bảng hoá đơn trong tệp: cần ít nhất cột Số hoá đơn, Ngày và Thành tiền / "
                      "Tên hàng. Hãy kiểm tra tệp có dòng tiêu đề cột.")
    ky = chu_ky(kq["tieu_de"])
    mau = nap_mau().get(ky)
    if mau and mau.get("phien") != MAU_PHIEN:
        mau = None      # GD110: mau hoc bang tu dien cu (vd ten nguoi mua -> cot Ho ten) - nhan dang lai
    if mau:          # mau da gap: dung lai cach gan da luu (giu diem 100)
        kq["gan"] = {t: (int(c), 100) for t, c in mau["gan"].items()}
    thieu = [TEN_TRUONG[t] for t in ("so_hd", "ngay") if t not in kq["gan"]]
    if not any(t in kq["gan"] for t in ("thanh_tien", "tong_chua_thue", "tong_tt", "ten_hang")):
        thieu.append("Thành tiền / Tên hàng")
    if thieu:
        return None, "Tệp thiếu cột: %s." % ", ".join(thieu)
    kq["mac_dinh"] = {t: v for t, v in thong_tin_dau(kq["rows"], kq["dong"]).items() if t not in kq["gan"]}
    dong, bo_tong = doc_hoa_don(kq)
    ds, canh = lap_hoa_don(dong, huong, mst_cty)
    ds, bo = loc_huong(ds, huong, mst_cty)
    if not ds:
        ly = "; ".join(sorted(set(l for h, l in bo)))[:400]
        return None, "Không có hoá đơn %s hợp lệ trong tệp%s" % ("mua vào" if huong == "mua" else "bán ra",
                                                                 (": " + ly) if ly else ".")
    lan = luu_mau(ky, kq["gan"], tep)
    tat_ca = ds
    if vao_ai:          # GD108: chi hoa don CHUA co trong phan mem
        da_co, mau_da_co = doc_da_co(khach)
        cac_dong, ds_ai, bo_ai = dong_vao_ai(ds, huong, mst_cty, tep, da_co, mau_da_co)
        so_dong = ghi_mau1(ds_ai, huong, ra, kq, bo + bo_ai, canh, tep, ky, lan)
        tep_ai = ra + ".jsonl"
        if os.path.exists(tep_ai):
            os.remove(tep_ai)
        if cac_dong:
            ghi_jsonl(cac_dong, tep_ai)
    else:
        so_dong = ghi_mau1(ds, huong, ra, kq, bo, canh, tep, ky, lan)
    tien = sum(h["tien_hang"] for h in ds)
    thue = sum(h["tien_thue"] for h in ds)
    ngay_min = min(h["ngay"] for h in ds)
    ngay_max = max(h["ngay"] for h in ds)
    cot = ", ".join("%s = cột %s" % (TEN_TRUONG.get(t, t), _ten_cot(c)) for t, (c, d) in
                    sorted(kq["gan"].items(), key=lambda x: x[1][0]) if t in ("so_hd", "ngay", "ky_hieu", "mst_ban",
                                                                              "mst_mua", "mst_dt", "ten_hang", "ten_ban", "ten_mua",
                                                                              "hoten_mua", "ten_dt",
                                                                              "thanh_tien", "thue_suat", "tien_thue"))
    tom = ["AI đã nhận dạng tệp: %s" % os.path.basename(tep),
           "Sheet \"%s\", dòng tiêu đề %d%s - %s." % (kq["sheet"], kq["dong"] + 1, " - %d" % (kq["dong"] + 2)
                                                      if kq["hai_dong"] else "",
                                                      "mẫu đã gặp %d lần" % (lan - 1) if lan > 1 else "mẫu mới"),
           "Cột: " + cot + ".",
           "Hoá đơn %s: %d hoá đơn, %d dòng hàng, ngày %s - %s." % ("mua vào" if huong == "mua" else "bán ra", len(ds),
                                                                    sum(len(h["dong"]) for h in tat_ca),
                                                                    ngay_min.strftime("%d/%m/%Y"),
                                                                    ngay_max.strftime("%d/%m/%Y")),
           "Tiền hàng %s, thuế %s, thanh toán %s." % (_t(tien), _t(thue), _t(sum(h["tong_tt"] or 0 for h in ds)))]
    if bo:
        tom.append("Không nhập %d hoá đơn (khác công ty / ngược hướng / thiếu số, ngày) - xem sheet NhanDang." % len(bo))
    if canh:
        tom.append("Cần xem lại %d chỗ (lệch tổng, tiền hàng 0...) - xem sheet NhanDang." % len(canh))
    if bo_tong:
        tom.append("Đã bỏ %d dòng Tổng cộng." % bo_tong)
    if not any(t in kq["gan"] for t in (("ten_mua", "hoten_mua") if huong == "ban" else ("ten_ban",)) + ("ten_dt",)):
        tom.append("CHÚ Ý: không tìm thấy cột tên người %s - cột Đối tác trên màn hình AI sẽ trống (AI vẫn ghép theo MST). "
                   "Sửa tiêu đề cột (vd. 'Tên người mua') rồi import lại." % ("mua" if huong == "ban" else "bán"))
    if kq["mac_dinh"]:
        tom.append("Lấy từ phần đầu tệp: " + "; ".join("%s = %s" % (TEN_TRUONG.get(t, t), chu(v)[:60])
                                                       for t, v in kq["mac_dinh"].items()) + ".")
    if MA_DA_DOI[0]:
        tom.append("Chữ %s trong tệp đã đổi sang Unicode." % MA_DA_DOI[0])
    if vao_ai:          # GD108
        tom.append("")
        if ds_ai:
            n_cn = sum(1 for h in ds_ai if h.get("_cap_nhat"))
            tom.append("ĐƯA VÀO DANH SÁCH AI: %d hoá đơn mới (%d dòng hàng, tiền hàng %s, thuế %s)." % (
                len(ds_ai) - n_cn, so_dong, _t(sum(h["tien_hang"] for h in ds_ai)), _t(sum(h["tien_thue"] for h in ds_ai)))
                       if not n_cn else
                       "ĐƯA VÀO DANH SÁCH AI: %d hoá đơn (%d mới, %d CẬP NHẬT LẠI hoá đơn đã import từ bảng kê, chưa lập chứng từ "
                       "- thay dữ liệu cũ); %d dòng hàng, tiền hàng %s, thuế %s." % (
                           len(ds_ai), len(ds_ai) - n_cn, n_cn, so_dong, _t(sum(h["tien_hang"] for h in ds_ai)),
                           _t(sum(h["tien_thue"] for h in ds_ai))))
        else:
            tom.append("KHÔNG CÓ HOÁ ĐƠN MỚI để đưa vào danh sách AI.")
        n_co = sum(1 for h, ly in bo_ai if ly.startswith("đã có"))
        n_mst = sum(1 for h, ly in bo_ai if ly.startswith("thiếu MST"))
        if n_co:
            tom.append("Bỏ qua %d hoá đơn đã có trong danh sách hoá đơn của AI (đã tải / import trước đây)." % n_co)
        if n_mst:
            tom.append("Bỏ qua %d hoá đơn thiếu MST người bán - xem sheet NhanDang." % n_mst)
        if len(bo_ai) > n_co + n_mst:
            tom.append("Bỏ qua %d hoá đơn trùng số trong tệp - xem sheet NhanDang." % (len(bo_ai) - n_co - n_mst))
        n_tong = sum(1 for h in ds_ai if h.get("_chi_tong"))
        if n_tong:
            tom.append("%d hoá đơn chỉ có tổng tiền (không có dòng hàng): AI hạch toán theo tổng; lần tải hoá đơn từ CQT sau "
                       "lấy được XML (hoá đơn chưa lập chứng từ) thì phần mềm tự thay bằng chi tiết." % n_tong)
        if ds_ai:
            tom.append("AI sẽ ghép mã %s, vật tư và định khoản như hoá đơn tải từ CQT - chưa ghi sổ cho tới khi lập chứng từ. "
                       "Hoá đơn đã nhập tay vào sổ: AI phát hiện khi phân tích, để Cần xem lại."
                       % ("nhà cung cấp" if huong == "mua" else "khách hàng"))
    else:
        tom.append("Mặc định: phân loại vật tư HH, phân loại khách %s, tháng chứng từ = tháng hoá đơn."
                   % ("PTR" if huong == "mua" else "PTH"))
    with io.open(ra + ".txt", "w", encoding="utf-8") as f:
        f.write("\n".join(tom) + "\n")
    ghi_log("[HD EXCEL] %s -> %s: %d HD, %d dong, bo %d, canh bao %d%s" % (
        tep, ra, len(ds), so_dong, len(bo), len(canh),
        (", VAO AI %d HD (da co / trung %d)" % (len(ds_ai), len(bo_ai))) if vao_ai else ""))
    return ra, None


# ------------------------------------------------------------------ GD108: dua bang ke vao danh sach AI
_KH_GOP = re.compile(r"^([1-9])([CK]\d{2}[A-Z]{3})$")      # "1C26TAA" = mau 1 + ky hieu C26TAA
_KH_TT78 = re.compile(r"^[CK]\d{2}[A-Z]{3}$")


class _Ma(str):
    """Ma trang thai (str) kem khoa goc phan mem dang giu (GD110: import lai bang ke ma 3 dung dung khoa do)."""
    goc = ""


def doc_da_co(khach):
    """trang-thai-hd.txt (VB6 ghi ngay truoc khi goi tool): '<MST ban>|<mau>|<ky hieu>|<so>\\t<ma>' moi dong (ma 0 / 1 / 2 /
    3 = da nap tu bang ke, cho XML). -> ({(MST chu so, ky hieu, so HD): ma}, {(MST 10 so, ky hieu): mau}). Khong tep -> ({}, {})."""
    da, mau = {}, {}
    if not khach:
        return da, mau
    try:
        with io.open(os.path.join(khach, "trang-thai-hd.txt"), encoding="utf-8-sig") as f:
            for dong in f:
                dong = dong.rstrip("\r\n")
                if "\t" not in dong:
                    continue
                k, ma = dong.rsplit("\t", 1)
                a = k.strip().split("|")
                if len(a) != 4:
                    continue
                m, kh = mst_so(a[0]), a[2].strip().upper()
                ma = _Ma(ma.strip())
                ma.goc = k.strip()
                da[(m, kh, so_hd(a[3]))] = ma
                if a[1].strip():
                    mau.setdefault((m[:10], kh), a[1].strip())
    except (IOError, OSError):
        pass
    return da, mau


def _tim_da_co(da_co, chi_so, k):
    """Hoa don (MST chu so, ky hieu, so) da co? Khop dung MST; hoac mot ben chi ghi MST 10 so cua don vi co chi nhanh
    (MST 13 so) - bang ke hay bo duoi -001. -> ma trang thai / None."""
    if k in da_co:
        return da_co[k]
    m, kh, sh = k
    for md, ma in chi_so.get((m[:10], kh, sh), ()):
        if len(m) == 10 or len(md) == 10:
            return ma
    return None


def mau_ky_hieu(h, mau_da_co):
    """Mau so + ky hieu theo cach cong thue / XML ghi (de khoa trung voi hoa don tai tu CQT):
    "1C26TAA" -> ("1", "C26TAA"); mau "01" -> "1"; thieu mau: lay theo hoa don cung ky hieu da co trong phan mem,
    khong co thi hoa don co thue suat -> 1 (GTGT), khong -> 2 (ban hang)."""
    kh = re.sub(r"\s+", "", h["ky_hieu"] or "").upper()
    mau = re.sub(r"\s+", "", h["mau_so"] or "").upper()
    m = _KH_GOP.match(kh)
    if m:
        kh = m.group(2)
        if not mau or re.match(r"^0*%s$" % m.group(1), mau):
            mau = m.group(1)
    m = re.match(r"^0*([1-9])$", mau)
    if m:
        mau = m.group(1)
    if not mau and _KH_TT78.match(kh):
        mau = mau_da_co.get((mst_so(h["mst_ban"])[:10], kh)) or \
            ("1" if any(x["thue_suat"] for x in h["dong"]) or h.get("tien_thue") else "2")
    return mau, kh


def _ngay_iso(d):
    return d.strftime("%Y-%m-%d") if d else ""


def dong_vao_ai(ds, huong, mst_cty, tep, da_co, mau_da_co):
    """-> (cac dong JSONL, hoa don dua vao, [(h, ly do)] khong dua vao)"""
    ra, moi, bo, thay = [], [], [], set()
    chi_so = {}
    for (m, kh, sh), ma in da_co.items():
        chi_so.setdefault((m[:10], kh, sh), []).append((m, ma))
    for h in ds:
        if huong == "mua" and not mst_so(h["mst_ban"]):
            bo.append((h, "thiếu MST người bán - AI cần MST để ghép nhà cung cấp và chống trùng với hoá đơn tải từ CQT"))
            continue
        mau, kh = mau_ky_hieu(h, mau_da_co)
        k = (mst_so(h["mst_ban"]), kh, h["so_hd"])
        ma = _tim_da_co(da_co, chi_so, k)
        if ma is not None and ma != "3":
            bo.append((h, "đã có trong danh sách hoá đơn của AI" + (" (đã hạch toán)" if ma == "1" else "") +
                       " - không đưa vào lần nữa"))
            continue
        h["_cap_nhat"] = ma == "3"          # GD110: da import tu bang ke, chua lap chung tu -> import lai thay du lieu cu
        goc = getattr(ma, "goc", "") if h["_cap_nhat"] else ""      # khoa phan mem dang giu (vd MST 13 so) - VB tim dung dong cu
        if goc and goc in thay:
            bo.append((h, "trùng hoá đơn %s / ký hiệu %s đã cập nhật lại ở dòng trước trong tệp" % (h["so_hd"], kh)))
            continue
        if goc:
            thay.add(goc)
        if k in thay:
            bo.append((h, "trùng số hoá đơn %s / ký hiệu %s / người bán với hoá đơn khác trong tệp" % (h["so_hd"], kh)))
            continue
        thay.add(k)
        moi.append(h)
        co_hang = any((x["thanh_tien"] or 0) > 0 for x in h["dong"])     # dong chiet khau chi khi hoa don co dong hang
        tct = h["tong_chua_thue"] if h["tong_chua_thue"] is not None else h["tien_hang"]
        tth = h["tong_thue"] if h["tong_thue"] is not None else h["tien_thue"]
        chung = {
            "KyHieuMauSo": mau, "KyHieuHoaDon": kh, "SoHoaDon": h["so_hd"], "NgayLap": _ngay_iso(h["ngay"]),
            "NgayNguoiBanKySo": _ngay_iso(h["ngay_ky"]), "MCCQT": h["mccqt"], "NgayCQTKySo": "",
            "DonViTienTe": h["tien_te"] or "VND", "TyGia": h["ty_gia"] or 1,
            "TenNguoiBanNguoiXuatHang": h["ten_ban"], "MSTNguoiBanNguoiXuatHang": h["mst_ban"],
            "DiaChiNguoiBan": h["dc_ban"],
            "TenNguoiMuaNguoiNhanHang": h["ten_mua"], "MSTNguoiMuaNguoiNhanHang": h["mst_mua"],
            "DiaChiNguoiMua": h["dc_mua"],
            "TongTienChietKhauThuongMai": h["tong_ck"] or 0, "TongTienPhi": 0, "TongTienThanhToan": h["tong_tt"] or 0,
            "TrangThaiHoaDon": h["trang_thai"] or "Hóa đơn mới", "KetQuaKiemTraHoaDon": h["ket_qua"],
            "XML": False, "HDBanRa": huong == "ban", "MaSoLoaiCT": "8" if huong == "ban" else "1",
            "MSTLogin": mst_cty,
            "khoa": goc or "%s|%s|%s|%s" % (h["mst_ban"], mau, kh, h["so_hd"]),
            "huong": huong, "tep_xml": tep, "tthai": "", "ttxly": "",
            "mtt": bool(_KH_TT78.match(kh)) and kh[3] == "M", "loai_hd": "", "httt": "", "lien_quan": None,
            "tong_chua_thue": tct or 0, "tong_thue": tth or 0, "nguon": "bangke",
        }
        if h.get("_cap_nhat"):
            chung["thay_bk"] = True         # GD110: VB6 thay dong bang ke cu (chua lap chung tu) bang du lieu moi
        n = len(h["dong"])
        for i, x in enumerate(h["dong"]):
            ts = x["thue_suat"] or ""
            d = dict(chung)
            d.update({
                "stt_dong": i + 1, "so_dong": n,
                "tchat": x.get("tchat") or ("3" if co_hang and (x["thanh_tien"] or 0) < 0 and
                                            re.search(r"chiet khau|giam gia", chuan(x["ten_hang"])) else "1"),
                "MaVT": x["ma_hang"], "TenHangHoaDichVu": x["ten_hang"], "DonViTinh": x["dvt"],
                "SoLuong": x["so_luong"] or 0, "DonGia": x["don_gia"] or 0, "ChietKhau": x["chiet_khau"] or 0,
                "ThueSuat": ts, "ThanhTienChuaThue": x["thanh_tien"] or 0, "TienThue": x["tien_thue"] or 0,
                "giam2": ts.upper().startswith("KHAC"),
            })
            ra.append(d)
    return ra, moi, bo


def ghi_jsonl(cac_dong, duong):
    tam = duong + ".tmp"
    with io.open(tam, "w", encoding="utf-8", newline="\n") as f:
        for d in cac_dong:
            f.write(json.dumps(d, ensure_ascii=False) + "\n")
    os.replace(tam, duong)


def _ten_cot(c):
    s, c = "", c + 1
    while c > 0:
        c, r = divmod(c - 1, 26)
        s = chr(65 + r) + s
    return s


if __name__ == "__main__":
    a = dict(x.split(":", 1) for x in sys.argv[1:] if x.startswith("/") and ":" in x)
    d, loi = chay(a.get("/hdexcel", "").strip('"'), a.get("/huong", "mua"), a.get("/mst", ""),
                  a.get("/ra", "hd_excel_ai_ra.xlsx").strip('"'), vao_ai=a.get("/vaoai", "") == "1",
                  khach=a.get("/khach", "").strip('"'))
    print(d or ("LOI " + loi))
