# -*- coding: utf-8 -*-
"""GD129 - BANG CAN DOI SO PHAT SINH ra Excel DUNG MAU (anh Thang 06/10/2026: "Xuat Excel bang can doi so phat sinh ra
mau link loai tru va xuat dung mau").

Truoc GD129 nut Excel cua "Bang can doi so phat sinh" (man hinh Bao cao, So chi phi) ghi so lieu vao Excels\\QTTNDN.XLS -
mau LINK quyet toan TNDN (sheet namnay / namtruoc, cac sheet BCTC lay so bang cong thuc), hoi Yes / No va khong mo tep.
Nay: VB6 dung DUNG truy van QCdt cua mau in CDT.RPT (InCdt: cap tai khoan, "In chi tiet khong phat sinh", chi nhanh, sau
ket chuyen) -> JSON UTF-8 -> tool_htkk_unesco.py /cdps:<json> /ra:<xlsx> -> module nay lap tep Excel rieng:

  * Dau trang: don vi, dia chi, MST (chu Unicode), "BANG CAN DOI SO PHAT SINH", ky, chi nhanh, don vi tinh.
  * Cot A Số hiệu TK | B Tên tài khoản | 1-2 Số dư đầu kỳ Nợ / Có | 3-4 Phát sinh trong kỳ Nợ / Có | 5-6 Số dư cuối kỳ Nợ / Có
    (dung bo cuc cot F01-DNN, TT 133/2016) + cot "Cấp" (cap tai khoan, dung cho cong thuc tong).
  * TK luong tinh (131 / 331 / 138 / 333 / 338 - cac TK VB SoDuTKCN2 tinh theo tung doi tuong): so du ghi HAI BEN Nợ / Có
    theo doi tuong (khong bu tru). TK khac: so du ghi mot ben (Nợ - Có).
  * Dong "Tổng cộng" = CONG THUC SUMIF(cot Cấp = 1) - LOAI TRU dong TK chi tiet (cap 2, 3...) de khong cong trung.
  * Dong kiem tra Nợ - Có (phai = 0) bang cong thuc; dong TK nao "dư cuối ≠ dư đầu + phát sinh" to mau cam (dinh dang co dieu kien).
  * Ky ten: ngay lap, Người lập biểu / Kế toán trưởng / Giám đốc (ten lay tu "Người ký" cua man hinh AI).
CHI DOC JSON - khong ghi so. Tra (duong tep, "") hoac ("", loi)."""
import datetime
import io
import json
import os

from xlsx_viet import CT, SoExcel, dia_chi

TIEN = '#,##0;(#,##0);""'         # so tien: 0 -> de trong, am trong ngoac
TK_LT_MAC_DINH = ("131", "331", "138", "333", "338")
COT = ("dk_no", "dk_co", "ps_no", "ps_co", "ck_no", "ck_co")


def _so(x):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return 0.0
    if v != v or v in (float("inf"), float("-inf")):
        return 0.0
    return round(v, 2)


def _chu(x):
    return str(x if x is not None else "").strip()


def _ngay(s):
    s = _chu(s)
    for f in ("%d/%m/%Y", "%Y-%m-%d"):
        try:
            return datetime.datetime.strptime(s, f)
        except ValueError:
            pass
    return None


def doc_json(tep):
    with io.open(tep, encoding="utf-8-sig") as f:
        dl = json.load(f)
    try:
        import tieu_de_tt
        tieu_de_tt.nhan(dl)                     # GD139: Thong tu cua bo so
    except Exception:
        pass
    return dl


def ky_chu(dl):
    """Chu ky bao cao: 'Tháng 06 năm 2026' / 'Từ tháng 01/2026 đến tháng 06/2026'."""
    tu, den = _ngay(dl.get("tu")), _ngay(dl.get("den"))
    if not tu or not den:
        nam = int(_so(dl.get("nam_tc")) or datetime.datetime.now().year)
        t1, t2 = int(_so(dl.get("tu_thang")) or 1), int(_so(dl.get("den_thang")) or 12)
        dk = int(_so(dl.get("thang_dau_ky")) or 1)
        tu = datetime.datetime(nam + (1 if t1 < dk else 0), t1, 1)
        den = datetime.datetime(nam + (1 if t2 < dk else 0), t2, 28)
    if (tu.year, tu.month) == (den.year, den.month):
        return "Tháng %02d năm %d" % (tu.month, tu.year)
    if tu.year == den.year and tu.month == 1 and den.month == 12:
        return "Năm %d" % tu.year
    return "Từ tháng %02d/%d đến tháng %02d/%d" % (tu.month, tu.year, den.month, den.year)


def dong_bang(dl):
    """Dong JSON VB -> danh sach dong bao cao {sh, ten, cap, lt, dk_no ... ck_co}, sap theo loai + so hieu.
    Bo dong nhom "Loại x" (cap 0 / so hieu khong phai so) va dong khong co so lieu khi khong tich In chi tiet khong phat sinh."""
    lt = tuple(_chu(x) for x in (dl.get("tk_lt") or TK_LT_MAC_DINH) if _chu(x))
    ct = int(_so(dl.get("ct")))
    ds = []
    for r in dl.get("dong") or []:
        if not isinstance(r, (list, tuple)) or len(r) < 11:
            continue
        sh, cap, ten = _chu(r[0]), int(_so(r[1])), _chu(r[2])
        if cap <= 0 or not sh or not sh[0].isdigit():
            continue
        dkn, dkc, psn, psc, ckn, ckc = (_so(x) for x in r[5:11])
        la_lt = any(sh.startswith(p) for p in lt)
        if la_lt:
            v = [dkn, dkc, psn, psc, ckn, ckc]
        else:
            d0, d1 = round(dkn - dkc, 2), round(ckn - ckc, 2)
            v = [max(d0, 0.0), max(-d0, 0.0), psn, psc, max(d1, 0.0), max(-d1, 0.0)]
        if ct == 0 and not any(v):
            continue
        x = dict(zip(COT, v))
        x.update(sh=sh, ten=ten, cap=cap, lt=la_lt, loai=int(_so(r[4])))
        ds.append(x)
    ds.sort(key=lambda d: (d["loai"], d["sh"]))           # nhu mau in: order by Loai, SoHieu
    return ds


def tong_cap1(ds):
    """Tong 6 cot chi tren dong cap nho nhat (cap 1) - giong cong thuc SUMIF tren tep."""
    if not ds:
        return [0.0] * 6
    c = min(d["cap"] for d in ds)
    return [round(sum(d[k] for d in ds if d["cap"] == c), 2) for k in COT]


def _tt99(dl):
    """GD139: bo so theo TT99/2025 (JSON VB: thong_tu = 99)."""
    return str(dl.get("thong_tu") or "").strip().startswith("99")


def lap(dl, ra):
    ds = dong_bang(dl)
    if not ds:
        raise ValueError("Không có tài khoản nào có số liệu trong kỳ (Bảng cân đối số phát sinh trống) - kiểm tra kỳ, cấp tài khoản.")
    cty = dl.get("cty") or {}
    nk = dl.get("nguoi_ky") or {}
    cap_min = min(d["cap"] for d in ds)
    wb = SoExcel(font="Times New Roman", co=11)
    ws = wb.sheet("Can doi so phat sinh", cot=[11, 42, 16, 16, 16, 16, 16, 16, 6])
    k_trai = wb.kieu(can="trai")
    k_trai_d = wb.kieu(can="trai", dam=True)
    k_ghi = wb.kieu(nghieng=True, can="giua", co=9, xuong=True)
    # ---- dau trang
    ws.gop(1, 1, 1, 5, "Đơn vị: %s" % _chu(cty.get("ten")), k_trai_d)
    ws.gop(2, 1, 2, 5, "Địa chỉ: %s" % _chu(cty.get("dia_chi")), k_trai)
    ws.gop(3, 1, 3, 5, "Mã số thuế: %s" % _chu(cty.get("mst")), k_trai)
    if _tt99(dl):                                      # GD139: bo so TT99 - Bang can doi so phat sinh = so S06-DN (TT99 Phu luc III)
        ws.gop(1, 6, 1, 9, "Mẫu số S06-DN", wb.kieu(dam=True, can="giua"))
        ws.gop(2, 6, 3, 9, "(Kèm theo Thông tư số 99/2025/TT-BTC ngày 27/10/2025 của Bộ trưởng Bộ Tài chính)", k_ghi)
    else:
        ws.gop(1, 6, 1, 9, "Sổ kế toán tổng hợp", wb.kieu(dam=True, can="giua"))
        ws.gop(2, 6, 3, 9, "(Cột số liệu theo mẫu F01-DNN - Thông tư số 133/2016/TT-BTC ngày 26/8/2016 của Bộ Tài chính)", k_ghi)
    ws.cao(3, 18)
    ws.gop(5, 1, 5, 9, "BẢNG CÂN ĐỐI SỐ PHÁT SINH", wb.kieu(dam=True, co=15, can="giua"))
    ws.cao(5, 24)
    ws.gop(6, 1, 6, 9, ky_chu(dl), wb.kieu(nghieng=True, dam=True, can="giua"))
    r = 7
    phu = []
    if _chu(dl.get("chi_nhanh")):
        phu.append(_chu(dl.get("chi_nhanh")))           # VB gui san nhan: "Chi nhánh: X" / "Tất cả chi nhánh"
    cap = int(_so(dl.get("cap")))
    if cap:
        phu.append("Tài khoản đến cấp %d" % cap)
    if phu:
        ws.gop(r, 1, r, 9, " - ".join(phu), wb.kieu(nghieng=True, can="giua", co=10))
        r += 1
    ws.gop(r, 6, r, 9, "Đơn vị tính: đồng", wb.kieu(nghieng=True, can="phai"))
    r += 1
    # ---- tieu de cot
    kh = wb.kieu(dam=True, can="giua", khung=True, xuong=True, nen="DDEBF7")
    kh2 = wb.kieu(nghieng=True, can="giua", khung=True, co=10)
    ws.gop(r, 1, r + 1, 1, "Số hiệu tài khoản", kh)
    ws.gop(r, 2, r + 1, 2, "Tên tài khoản", kh)
    for i, t in enumerate(("Số dư đầu kỳ", "Số phát sinh trong kỳ", "Số dư cuối kỳ")):
        ws.gop(r, 3 + 2 * i, r, 4 + 2 * i, t, kh)
        ws.o(r + 1, 3 + 2 * i, "Nợ", kh)
        ws.o(r + 1, 4 + 2 * i, "Có", kh)
    ws.gop(r, 9, r + 1, 9, "Cấp", kh)
    ws.cao(r, 20)
    for i, t in enumerate(("A", "B", "1", "2", "3", "4", "5", "6", ""), start=1):
        ws.o(r + 2, i, t, kh2)
    ws.in_trang(ngang=True, lap_dong=(r, r + 2), le=(0.4, 0.3, 0.5, 0.5))
    r += 3
    ws.dong_bang(r)
    r1 = r
    # ---- dong tai khoan
    kieu_dong = {}
    for d in ds:
        muc = d["cap"] - cap_min
        dam = muc == 0
        nghieng = muc >= 2
        if muc not in kieu_dong:
            kieu_dong[muc] = (
                wb.kieu(khung=True, can="trai", dam=dam, nghieng=nghieng, thut=min(muc, 4)),
                wb.kieu(khung=True, can="trai", xuong=True, dam=dam, nghieng=nghieng, thut=min(muc, 4)),
                wb.kieu(khung=True, so=TIEN, can="phai", dam=dam, nghieng=nghieng),
                wb.kieu(khung=True, can="giua", co=9, mau="808080"))
        k_sh, k_ten, k_so, k_cap = kieu_dong[muc]
        ws.o(r, 1, d["sh"], k_sh)
        ws.o(r, 2, d["ten"], k_ten)
        for i, c in enumerate(COT):
            ws.o(r, 3 + i, d[c] if d[c] else None, k_so)
        ws.o(r, 9, d["cap"], k_cap)
        r += 1
    r2 = r - 1
    # dong du cuoi khong khop du dau + phat sinh -> to cam (xem lai so lieu / chi tiet doi tuong)
    ws.to_mau(r1, 1, r2, 8, "ABS(($C%d-$D%d)+($E%d-$F%d)-($G%d-$H%d))>=1" % ((r1,) * 6), nen="FCE4D6", mau="9C3D00")
    # ---- tong cong = SUMIF cap 1 (loai tru TK chi tiet)
    tong = tong_cap1(ds)
    k_tong = wb.kieu(dam=True, khung=True, can="giua", nen="F2F2F2")
    k_tong_so = wb.kieu(dam=True, khung=True, so=TIEN, can="phai", nen="F2F2F2")
    ws.gop(r, 1, r, 2, "Tổng cộng", k_tong)
    vung_cap = "$I$%d:$I$%d" % (r1, r2)
    for i in range(6):
        c = 3 + i
        cot = dia_chi(r1, c)[:-len(str(r1))]
        ws.o(r, c, CT("SUMIF(%s,%d,%s$%d:%s$%d)" % (vung_cap, cap_min, cot, r1, cot, r2), tong[i]), k_tong_so)
    ws.o(r, 9, None, k_tong)
    rt = r
    r += 1
    # ---- kiem tra Nợ = Có (ngoai khung bang)
    k_kt = wb.kieu(nghieng=True, can="trai", co=9, mau="595959")
    k_kt_so = wb.kieu(nghieng=True, so='#,##0;-#,##0;0', can="phai", co=9, mau="595959")
    ws.gop(r, 1, r, 2, "Kiểm tra: Nợ - Có (phải bằng 0)", k_kt)
    for i in range(3):
        cn, cc = 3 + 2 * i, 4 + 2 * i
        ws.o(r, cn, CT("%s-%s" % (dia_chi(rt, cn), dia_chi(rt, cc)), round(tong[2 * i] - tong[2 * i + 1], 2)), k_kt_so)
    ws.to_mau(r, 3, r, 8, "ABS(C%d)>=1" % r, nen="FFC7CE", mau="9C0006", dam=True)
    r += 1
    ws.gop(r, 1, r, 9, "Ghi chú: Tổng cộng = SUMIF cột Cấp = %d (chỉ cộng tài khoản cấp %d), loại trừ dòng tài khoản chi tiết để không cộng trùng. "
           "TK %s ghi số dư hai bên theo từng đối tượng (không bù trừ). Dòng tô cam: số dư cuối khác số dư đầu + phát sinh - "
           "kiểm tra lại số liệu / chi tiết đối tượng." % (cap_min, cap_min, ", ".join(dl.get("tk_lt") or TK_LT_MAC_DINH)),
           wb.kieu(nghieng=True, can="trai", co=9, xuong=True, mau="595959"))
    ws.cao(r, 28)
    r += 2
    # ---- ky ten
    lap_ngay = _ngay(dl.get("hom_nay")) or datetime.datetime.now()
    ws.gop(r, 6, r, 9, "Ngày %02d tháng %02d năm %d" % (lap_ngay.day, lap_ngay.month, lap_ngay.year), wb.kieu(nghieng=True, can="giua"))
    r += 1
    kd = wb.kieu(dam=True, can="giua")
    kn = wb.kieu(nghieng=True, can="giua", co=9)
    khoi = ((1, 2), (3, 5), (6, 9))
    for (c1, c2), td, gc, ten in zip(khoi, ("NGƯỜI LẬP BIỂU", "KẾ TOÁN TRƯỞNG", "GIÁM ĐỐC"),
                                     ("(Ký, họ tên)", "(Ký, họ tên)", "(Ký, họ tên, đóng dấu)"),
                                     (nk.get("nguoi_lap"), nk.get("ke_toan_truong"), nk.get("giam_doc") or nk.get("nguoi_ky"))):
        ws.gop(r, c1, r, c2, td, kd)
        ws.gop(r + 1, c1, r + 1, c2, gc, kn)
        ws.gop(r + 5, c1, r + 5, c2, _chu(ten), kd)
    thu_muc = os.path.dirname(ra)
    if thu_muc:
        os.makedirs(thu_muc, exist_ok=True)
    wb.luu(ra)
    return ra


def chay(tep_json, ra=""):
    """Goi tu tool_htkk_unesco.py /cdps:<json> /ra:<xlsx>. -> (duong, loi)."""
    try:
        dl = doc_json(tep_json)
    except Exception as e:
        return "", "Không đọc được số liệu (%s)" % e
    if not ra:
        goc = _chu(dl.get("excels")) or os.path.join(os.path.dirname(os.path.abspath(__file__)), "ket-qua")
        ra = os.path.join(goc, "BaoCao", "BangCanDoiSoPhatSinh_%s.xlsx" % datetime.datetime.now().strftime("%Y%m%d_%H%M%S"))
    try:
        return lap(dl, ra), ""
    except PermissionError:
        # tep cung ten dang mo trong Excel -> them gio phut giay
        goc, duoi = os.path.splitext(ra)
        try:
            return lap(dl, "%s_%s%s" % (goc, datetime.datetime.now().strftime("%H%M%S"), duoi)), ""
        except Exception as e:
            return "", "Không ghi được tệp Excel (%s)" % e
    except ValueError as e:
        return "", str(e)
    except Exception as e:
        return "", "Lỗi lập Bảng cân đối số phát sinh: %s" % e
