# -*- coding: utf-8 -*-
"""GD293 - GOI TRAO DOI .ukx giua UNESCO (van phong) va CONG CU KHACH (may khach). Dung chung hai phia.

Goi = zip:  goi.json (mo ta + sha256 tung tep) + goi.sig (chu ky Ed25519 cua goi.json, hex) + cac tep du lieu.
  goi.json: {"loai": "DI"|"VE", "mst", "ten_cty", "so_thu_tu", "ngay_chot", "tao_luc", "phien_ban", "may", "tep": {ten: sha256},
             "khoa_cong_khai": hex 32 byte cua ben phat hanh (DI: van phong; VE: may khach)}
Kiem khi mo: chu ky dung voi khoa cong khai da ghim (hoac khoa trong goi neu chua ghim), MST dung, so_thu_tu > so da nap.
Khoa rieng: 32 byte ngau nhien (hat), luu hex trong tep; khong bao gio dua vao goi / bo cai.
"""
import hashlib
import io
import json
import os
import time
import zipfile

PHIEN_BAN = "GD293"
DUOI = ".ukx"


# ------------------------------------------------------------------------------------------------ khoa
def _ky_so():
    import ky_so_ed25519
    return ky_so_ed25519


def doc_hoac_tao_khoa(tep):
    """Doc hat 32 byte (hex) tu tep; chua co -> tao moi (os.urandom), ghi tep. -> bytes"""
    if os.path.isfile(tep):
        with io.open(tep, "r", encoding="ascii") as f:
            h = bytes.fromhex(f.read().strip())
        if len(h) == 32:
            return h
    h = os.urandom(32)
    d = os.path.dirname(tep)
    if d and not os.path.isdir(d):
        os.makedirs(d)
    with io.open(tep + ".tmp", "w", encoding="ascii") as f:
        f.write(h.hex() + "\n")
    os.replace(tep + ".tmp", tep)
    return h


def khoa_cong_khai(hat):
    return _ky_so().khoa_cong_khai(hat).hex()


# ------------------------------------------------------------------------------------------------ ghi / doc goi
def _sha(b):
    return hashlib.sha256(b).hexdigest()


def _json_bytes(d):
    return json.dumps(d, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def ghi_goi(duong, loai, mst, ten_cty, so_thu_tu, ngay_chot, hat, tep_du_lieu, may="", them=None):
    """tep_du_lieu: {ten: bytes | str}. -> duong. Ghi tam roi doi ten (khong de lai goi dang do)."""
    noi_dung = {}
    for ten, b in tep_du_lieu.items():
        if isinstance(b, str):
            b = b.encode("utf-8")
        noi_dung[ten] = b
    mo_ta = {"loai": loai, "mst": str(mst or ""), "ten_cty": ten_cty or "", "so_thu_tu": int(so_thu_tu), "ngay_chot": ngay_chot or "",
             "tao_luc": time.strftime("%Y-%m-%d %H:%M:%S"), "phien_ban": PHIEN_BAN, "may": may or "",
             "tep": {t: _sha(b) for t, b in noi_dung.items()}, "khoa_cong_khai": khoa_cong_khai(hat)}
    if them:
        mo_ta.update(them)
    mt = _json_bytes(mo_ta)
    sig = _ky_so().ky(hat, mt).hex()
    tam = duong + ".tmp"
    with zipfile.ZipFile(tam, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("goi.json", mt)
        z.writestr("goi.sig", sig)
        for t, b in noi_dung.items():
            z.writestr(t, b)
    os.replace(tam, duong)
    return duong


def doc_goi(duong, mst_mong=None, khoa_ghim=None, so_da_nap=None):
    """Mo + kiem goi. -> (mo_ta, {ten: bytes}) ; loi -> raise ValueError(thong bao tieng Viet).
    khoa_ghim: hex khoa cong khai da ghim (None = tin khoa trong goi - lan dau). so_da_nap: so_thu_tu lon nhat da nap (None = bo qua)."""
    if not os.path.isfile(duong):
        raise ValueError("Không thấy tệp gói: %s" % duong)
    try:
        z = zipfile.ZipFile(duong)
    except Exception:
        raise ValueError("Tệp không phải gói %s hợp lệ (không mở được zip)." % DUOI)
    with z:
        ten = set(z.namelist())
        if "goi.json" not in ten or "goi.sig" not in ten:
            raise ValueError("Gói thiếu goi.json / goi.sig - không phải gói của UNESCO.")
        mt_b = z.read("goi.json")
        sig = z.read("goi.sig").decode("ascii", "replace").strip()
        try:
            mo_ta = json.loads(mt_b.decode("utf-8"))
        except Exception:
            raise ValueError("goi.json hỏng.")
        kck = str(mo_ta.get("khoa_cong_khai") or "")
        if khoa_ghim and kck.lower() != khoa_ghim.lower():
            raise ValueError("Gói ký bằng khoá KHÁC khoá đã ghim của bên kia - không nhận (có thể gói của máy khác / giả mạo).")
        try:
            ok = _ky_so().kiem(bytes.fromhex(kck), mt_b, bytes.fromhex(sig))
        except Exception:
            ok = False
        if not ok:
            raise ValueError("Chữ ký gói SAI - gói bị sửa hoặc không do bên kia tạo.")
        if mst_mong and str(mo_ta.get("mst") or "") != str(mst_mong):
            raise ValueError("Gói của công ty MST %s, không phải công ty này (MST %s)." % (mo_ta.get("mst"), mst_mong))
        if so_da_nap is not None and int(mo_ta.get("so_thu_tu") or 0) <= int(so_da_nap):
            raise ValueError("Gói số %s đã nạp rồi (đã nạp đến số %s) - chọn gói mới hơn." % (mo_ta.get("so_thu_tu"), so_da_nap))
        du_lieu = {}
        for t, h in (mo_ta.get("tep") or {}).items():
            if t not in ten:
                raise ValueError("Gói thiếu tệp %s." % t)
            b = z.read(t)
            if _sha(b) != h:
                raise ValueError("Tệp %s trong gói bị sửa (sai sha256)." % t)
            du_lieu[t] = b
    return mo_ta, du_lieu


def ten_goi(loai, mst, so_thu_tu, ngay=None):
    ngay = ngay or time.strftime("%Y%m%d_%H%M")
    return "GOI_%s_%s_%s_%03d%s" % (loai, mst or "CHUNG", ngay, int(so_thu_tu), DUOI)
