# -*- coding: utf-8 -*-
"""GD87 - SO CHI TIET THEO HOA DON: CCDC (153) / Chi phi tra truoc (242) / TSCD (211, 2411) / Khau hao (214).

Dau vao: JSON do VB6 HDTS_Json (ModHDDTHTKK.bas) ghi ra:
  cty, ky {tu, den}, nam_tc, thang_dau_ky,
  hd      : dong hang HDDTTaiVe mua vao trong ky (tinh chat CCDC / TSCD hoac TK 153* 242* 211* 2411*) + kt (MaCT ke toan)
  tk      : [[MaSo, SoHieu, TKCon, Ten, DuNo_0, DuCo_0], ...] cac TK 153* 242* 211* 2411* 214*
  ps_truoc: [[MaSo, no, co], ...] phat sinh tu dau nam tai chinh den truoc ngay dau ky
  dong    : dong ChungTu trong ky co No hoac Co thuoc cac TK tren (+ so HD / NCC hoa don goc qua MaCTHDDTTaiVe)
Dau ra: 1 tep .xlsx (xlsx_viet - khong can Excel / openpyxl):
  sheet 1 "Bang ke hoa don" : bang ke hoa don xep vao CCDC / 242 / TSCD, nhom theo 3 nhom, dong nao chua ghi so ghi ro,
                              TK ghi so khac nhom (vd 156) ghi "TK khac" de nguoi dung thay hoa don xep sai tinh chat;
  moi TK LA (khong co TK con trong bo) co phat sinh / so du: 1 sheet "So chi tiet TK" (S-DNN): Ngay GS, So CT, Ngay CT,
                              Dien giai, Hoa don goc (So HD - NCC), TK doi ung, No, Co, Du No, Du Co.
Chi doc so lieu; cach dung: python tool_htkk_unesco.py /sohdts:"<json>" /ra:"<xlsx>"  (VB6: HDDT_HDTS_Excel).
"""
import io
import json
import os
from collections import OrderedDict, defaultdict

from xlsx_viet import SoExcel, SO_TIEN

TEN_NHOM = OrderedDict([("CCDC", "Công cụ dụng cụ (TK 153)"), ("242", "Chi phí trả trước (TK 242)"),
                        ("TSCD", "Tài sản cố định (TK 211 / 2411)")])
TIEU_DE_SO = "SỔ CHI TIẾT TÀI KHOẢN (theo hoá đơn)"


def _so(x):
    try:
        return float(x or 0)
    except Exception:
        return 0.0


def nhom_theo_tk(tk, tchat=""):
    """153* -> CCDC, 242* -> 242, 211* / 2411* -> TSCD; khong ro -> theo tinh chat; con lai ''."""
    tk = (tk or "").strip()
    if tk.startswith("153"):
        return "CCDC"
    if tk.startswith("242"):
        return "242"
    if tk.startswith("211") or tk.startswith("2411"):
        return "TSCD"
    if tchat == "CCDC":
        return "CCDC"
    if tchat == "TSCD":
        return "TSCD"
    return ""


def ghi_so_cua(hd, tk_no_theo_ct):
    """Trang thai ghi so 1 dong hoa don: ('', 'Chua ghi so') / ('CT x / 153', nhom) / ('CT x / TK khac: 156', '')."""
    kt = int(_so(hd.get("kt")))
    if kt <= 0:
        return "Chưa ghi sổ", nhom_theo_tk(hd.get("tk"), hd.get("tchat")), False
    so_ct, tks = tk_no_theo_ct.get(kt, ("", []))
    so_ct = so_ct or str(kt)
    if not tks:
        return "CT " + so_ct, nhom_theo_tk(hd.get("tk"), hd.get("tchat")), True
    nh = nhom_theo_tk(tks[0])
    if nh:
        return "CT %s / %s" % (so_ct, ",".join(tks)), nh, True
    return "CT %s / TK khác: %s" % (so_ct, ",".join(tks)), "", True


def _tk_no_theo_ct(dong):
    """MaCT -> (so CT, [TK No khong phai 133*, khong trung]) tu cac dong chung tu trong ky."""
    kq = {}
    for d in dong:
        ma = int(_so(d.get("ma_ct")))
        so_ct, tks = kq.get(ma, (d.get("so_ct") or "", []))
        tkn = (d.get("tk_no") or "").strip()
        if tkn and not tkn.startswith("133") and tkn not in tks:
            tks.append(tkn)
        kq[ma] = (so_ct or (d.get("so_ct") or ""), tks)
    return kq


def tk_la(tk):
    """TK la = khong co TK nao khac trong bo lay so hieu no lam tien to."""
    sh = [t[1] for t in tk]
    return [t for t in tk if not any(x != t[1] and x.startswith(t[1]) for x in sh)]


def _thay_chu(v):
    return v if v else ""


class _Ve(object):
    def __init__(self, dl):
        self.dl = dl
        self.wb = SoExcel("Times New Roman", 11)
        w = self.wb
        self.k_cty = w.kieu(dam=True, co=11, can="trai")
        self.k_td = w.kieu(dam=True, co=14, can="giua")
        self.k_ky = w.kieu(nghieng=True, co=11, can="giua")
        self.k_h = w.kieu(dam=True, khung=True, can="giua", doc="giua", xuong=True, nen="D9E1F2")
        self.k_c = w.kieu(khung=True, can="trai", doc="tren", xuong=True)
        self.k_cg = w.kieu(khung=True, can="giua", doc="tren")
        self.k_s = w.kieu(khung=True, so=SO_TIEN, can="phai", doc="tren")
        self.k_sl = w.kieu(khung=True, so='#,##0.##;(#,##0.##);"-"', can="phai", doc="tren")
        self.k_nhom = w.kieu(dam=True, khung=True, can="trai", nen="FFF2CC")
        self.k_tong = w.kieu(dam=True, khung=True, so=SO_TIEN, can="phai", nen="FFF2CC")
        self.k_tong_c = w.kieu(dam=True, khung=True, can="trai", nen="FFF2CC")
        self.k_chua = w.kieu(khung=True, can="trai", doc="tren", xuong=True, mau="C00000", dam=True)
        self.k_ky_ten = w.kieu(dam=True, can="giua")
        self.k_ky_ten2 = w.kieu(nghieng=True, can="giua", co=10)

    def dau(self, ws, so_cot, tieu_de, phu=""):
        cty = self.dl.get("cty") or {}
        ky = self.dl.get("ky") or {}
        ws.o(1, 1, "Đơn vị: " + _thay_chu(cty.get("ten")), self.k_cty)
        ws.o(2, 1, "Mã số thuế: " + _thay_chu(cty.get("mst")), self.k_cty)
        ws.gop(4, 1, 4, so_cot, tieu_de, self.k_td)
        ws.gop(5, 1, 5, so_cot, phu or ("Kỳ: từ %s đến %s" % (ky.get("tu", ""), ky.get("den", ""))), self.k_ky)
        return 7

    def cuoi(self, ws, r, so_cot):
        nk = self.dl.get("nguoi_ky") or {}
        ky = self.dl.get("ky") or {}
        ws.gop(r, max(1, so_cot - 3), r, so_cot, "Ngày ..... tháng ..... năm ..... (lập từ dữ liệu đến %s)" % ky.get("den", ""), self.k_ky_ten2)
        r += 1
        vi = [("Người lập", nk.get("nguoi_lap")), ("Kế toán trưởng", nk.get("ke_toan_truong")), ("Giám đốc", nk.get("giam_doc"))]
        rong = max(1, so_cot // 3)
        for i, (ten, nguoi) in enumerate(vi):
            c1 = 1 + i * rong
            c2 = so_cot if i == 2 else c1 + rong - 1
            ws.gop(r, c1, r, c2, ten, self.k_ky_ten)
            ws.gop(r + 1, c1, r + 1, c2, "(Ký, họ tên)", self.k_ky_ten2)
            ws.gop(r + 5, c1, r + 5, c2, _thay_chu(nguoi), self.k_ky_ten)
        return r + 6


def _bang_ke(V, dl, tk_no_ct):
    ws = V.wb.sheet("Bang ke hoa don", cot=[5, 11, 10, 9, 30, 13, 40, 7, 9, 13, 15, 12, 8, 8, 26])
    ws.in_trang(ngang=True, lap_dong=(7, 7))
    n = 15
    r = V.dau(ws, n, "BẢNG KÊ HOÁ ĐƠN MUA VÀO XẾP VÀO CÔNG CỤ DỤNG CỤ / CHI PHÍ TRẢ TRƯỚC / TÀI SẢN CỐ ĐỊNH")
    td = ["STT", "Ngày HĐ", "Số HĐ", "Ký hiệu", "Nhà cung cấp", "MST", "Tên hàng", "ĐVT", "Số lượng", "Đơn giá",
          "Thành tiền", "Tiền thuế", "Tính chất", "TK", "Ghi sổ (chứng từ / TK Nợ)"]
    for c, t in enumerate(td, start=1):
        ws.o(r, c, t, V.k_h)
    ws.cao(r, 30)
    ws.dong_bang(r + 1)
    r += 1
    nhom = defaultdict(list)
    khac = []
    for hd in dl.get("hd") or []:
        gs, nh, da = ghi_so_cua(hd, tk_no_ct)
        (nhom[nh] if nh else khac).append((hd, gs, da))
    tong = {"tien": 0.0, "thue": 0.0}
    stt = 0
    thu_tu = [k for k in TEN_NHOM if nhom.get(k)] + ([""] if khac else [])
    for nh in thu_tu:
        ds = nhom.get(nh) if nh else khac
        ws.gop(r, 1, r, n, TEN_NHOM.get(nh, "Ghi sổ vào tài khoản KHÁC nhóm (xem lại tính chất / TK)"), V.k_nhom)
        r += 1
        st = {"tien": 0.0, "thue": 0.0}
        for hd, gs, da in ds:
            stt += 1
            ws.o(r, 1, stt, V.k_cg)
            ws.o(r, 2, hd.get("ngay") or "", V.k_cg)
            ws.o(r, 3, hd.get("so_hd") or "", V.k_cg)
            ws.o(r, 4, hd.get("ky_hieu") or "", V.k_cg)
            ws.o(r, 5, hd.get("ncc") or "", V.k_c)
            ws.o(r, 6, hd.get("mst") or "", V.k_cg)
            ws.o(r, 7, hd.get("ten") or "", V.k_c)
            ws.o(r, 8, hd.get("dvt") or "", V.k_cg)
            ws.o(r, 9, _so(hd.get("sl")) or None, V.k_sl)
            ws.o(r, 10, _so(hd.get("dg")) or None, V.k_s)
            ws.o(r, 11, _so(hd.get("tien")), V.k_s)
            ws.o(r, 12, _so(hd.get("thue")) or None, V.k_s)
            ws.o(r, 13, hd.get("tchat") or "", V.k_cg)
            ws.o(r, 14, hd.get("tk") or "", V.k_cg)
            ws.o(r, 15, gs, V.k_c if da and nh else V.k_chua)
            st["tien"] += _so(hd.get("tien"))
            st["thue"] += _so(hd.get("thue"))
            r += 1
        ws.gop(r, 1, r, 10, "Cộng " + TEN_NHOM.get(nh, "nhóm khác") + " (%d dòng)" % len(ds), V.k_tong_c)
        ws.o(r, 11, st["tien"], V.k_tong)
        ws.o(r, 12, st["thue"], V.k_tong)
        for c in range(13, n + 1):
            ws.o(r, c, None, V.k_tong_c)
        tong["tien"] += st["tien"]
        tong["thue"] += st["thue"]
        r += 1
    ws.gop(r, 1, r, 10, "TỔNG CỘNG (%d dòng hoá đơn)" % stt, V.k_tong_c)
    ws.o(r, 11, tong["tien"], V.k_tong)
    ws.o(r, 12, tong["thue"], V.k_tong)
    for c in range(13, n + 1):
        ws.o(r, c, None, V.k_tong_c)
    r += 1
    chua = sum(1 for k in nhom for _, _, da in nhom[k] if not da)
    ws.gop(r, 1, r, n, "Ghi chú: %d dòng CHƯA ghi sổ (chữ đỏ) - hạch toán trước khi phân bổ / khấu hao; nhóm \"TK khác\" = hoá đơn xếp tính chất "
                       "CCDC / TSCĐ nhưng chứng từ ghi vào TK khác - xem lại." % chua, V.k_ky)
    V.cuoi(ws, r + 2, n)
    return stt


def _so_chi_tiet(V, dl, hd_theo_ct):
    tk = dl.get("tk") or []
    ps = {}
    for m, no, co in (dl.get("ps_truoc") or []):
        a, b = ps.get(int(m), (0.0, 0.0))
        ps[int(m)] = (a + _so(no), b + _so(co))
    ten_tk = {int(t[0]): t for t in tk}
    dong_tk = defaultdict(list)
    for d in dl.get("dong") or []:
        mn, mc = int(_so(d.get("ma_no"))), int(_so(d.get("ma_co")))
        if mn in ten_tk:
            dong_tk[mn].append((d, "N"))
        if mc in ten_tk:
            dong_tk[mc].append((d, "C"))
    so_sheet = 0
    for t in tk_la(tk):
        m = int(t[0])
        du0 = _so(t[4]) - _so(t[5]) + ps.get(m, (0, 0))[0] - ps.get(m, (0, 0))[1]
        ds = dong_tk.get(m, [])
        if abs(du0) < 0.5 and not ds:
            continue
        so_sheet += 1
        ws = V.wb.sheet("TK " + t[1], cot=[11, 11, 11, 42, 34, 10, 15, 15, 15, 15])
        ws.in_trang(ngang=True, lap_dong=(7, 7))
        n = 10
        r = V.dau(ws, n, TIEU_DE_SO, "Tài khoản: %s - %s     Kỳ: từ %s đến %s" % (t[1], t[3], (dl.get("ky") or {}).get("tu", ""), (dl.get("ky") or {}).get("den", "")))
        td = ["Ngày ghi sổ", "Số CT", "Ngày CT", "Diễn giải", "Hoá đơn gốc (số HĐ - nhà cung cấp)", "TK đối ứng", "Nợ", "Có", "Dư Nợ", "Dư Có"]
        for c, x in enumerate(td, start=1):
            ws.o(r, c, x, V.k_h)
        ws.cao(r, 30)
        ws.dong_bang(r + 1)
        r += 1
        ws.gop(r, 1, r, 6, "Số dư đầu kỳ", V.k_tong_c)
        ws.o(r, 7, None, V.k_tong)
        ws.o(r, 8, None, V.k_tong)
        ws.o(r, 9, du0 if du0 > 0 else None, V.k_tong)
        ws.o(r, 10, -du0 if du0 < 0 else None, V.k_tong)
        r += 1
        du = du0
        sn = sc = 0.0
        for d, ben in ds:
            tien = _so(d.get("tien"))
            ws.o(r, 1, d.get("ngay_gs") or d.get("ngay") or "", V.k_cg)
            ws.o(r, 2, d.get("so_ct") or "", V.k_cg)
            ws.o(r, 3, d.get("ngay") or "", V.k_cg)
            ws.o(r, 4, d.get("dg") or "", V.k_c)
            hd = ""
            if d.get("hd_so") or d.get("hd_ncc"):
                hd = "%s - %s" % (d.get("hd_so") or "", d.get("hd_ncc") or "")
            elif int(_so(d.get("ma_ct"))) in hd_theo_ct:
                x = hd_theo_ct[int(_so(d.get("ma_ct")))]
                hd = "%s - %s" % (x.get("so_hd") or "", x.get("ncc") or "")
            ws.o(r, 5, hd, V.k_c)
            if ben == "N":
                ws.o(r, 6, d.get("tk_co") or "", V.k_cg)
                ws.o(r, 7, tien, V.k_s)
                ws.o(r, 8, None, V.k_s)
                sn += tien
                du += tien
            else:
                ws.o(r, 6, d.get("tk_no") or "", V.k_cg)
                ws.o(r, 7, None, V.k_s)
                ws.o(r, 8, tien, V.k_s)
                sc += tien
                du -= tien
            ws.o(r, 9, du if du > 0 else None, V.k_s)
            ws.o(r, 10, -du if du < 0 else None, V.k_s)
            r += 1
        ws.gop(r, 1, r, 6, "Cộng phát sinh trong kỳ", V.k_tong_c)
        ws.o(r, 7, sn, V.k_tong)
        ws.o(r, 8, sc, V.k_tong)
        ws.o(r, 9, None, V.k_tong)
        ws.o(r, 10, None, V.k_tong)
        r += 1
        ws.gop(r, 1, r, 6, "Số dư cuối kỳ", V.k_tong_c)
        ws.o(r, 7, None, V.k_tong)
        ws.o(r, 8, None, V.k_tong)
        ws.o(r, 9, du if du > 0 else None, V.k_tong)
        ws.o(r, 10, -du if du < 0 else None, V.k_tong)
        V.cuoi(ws, r + 2, n)
    return so_sheet


def lap(duong_json, ra):
    """Lap tep Excel; tra ve (duong, loi)."""
    try:
        with io.open(duong_json, "r", encoding="utf-8-sig") as f:
            dl = json.loads(f.read(), strict=False)
    except Exception as e:
        return None, "Khong doc duoc so lieu: %s" % e
    if (dl.get("loai") or "") != "SO_HD_TAI_SAN":
        return None, "So lieu khong dung loai (SO_HD_TAI_SAN)"
    V = _Ve(dl)
    tk_no_ct = _tk_no_theo_ct(dl.get("dong") or [])
    hd_theo_ct = {}
    for hd in dl.get("hd") or []:
        kt = int(_so(hd.get("kt")))
        if kt > 0 and kt not in hd_theo_ct:
            hd_theo_ct[kt] = hd
    so_hd = _bang_ke(V, dl, tk_no_ct)
    so_sheet = _so_chi_tiet(V, dl, hd_theo_ct)
    try:
        d = os.path.dirname(ra)
        if d and not os.path.isdir(d):
            os.makedirs(d, exist_ok=True)
        V.wb.luu(ra)
    except Exception as e:
        return None, "Khong ghi duoc tep Excel: %s" % e
    return ra, "" if (so_hd or so_sheet) else "Khong co hoa don / phat sinh CCDC-242-TSCD trong ky (van lap tep trong)"


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 3:
        print("dung: python so_hd_tai_san.py <json> <xlsx>")
        sys.exit(2)
    d, loi = lap(sys.argv[1], sys.argv[2])
    print(d or "", loi)
    sys.exit(0 if d else 1)
