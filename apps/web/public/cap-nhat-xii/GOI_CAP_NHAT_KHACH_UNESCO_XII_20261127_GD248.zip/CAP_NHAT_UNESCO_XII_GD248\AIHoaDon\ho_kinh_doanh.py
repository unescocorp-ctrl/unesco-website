# -*- coding: utf-8 -*-
"""GD172 - HO KINH DOANH, CA NHAN KINH DOANH: so doanh thu TT 152/2025 (S1a / S2a / S2b-HKD) + to khai 01/CNKD TT 50/2026
(Excel xem truoc + XML HTKK 01_CNKD_HKD_TT50, maTKhai 1266, XML 2.9.8) - CHI DOC SO.

Hop dong (xuat_1_lan.py): lap(dl, ma, kieu, thumuc) -> {"tep": [...], "canh_bao": [...]}; TEN_MAU = {ma: ten}. Ma bat dau "SS_HKD".
  dl = JSON Xuat 1 lan cua VB (nhu so_sach_mau: tk, ps, doi_ung (ca nam), dt, nguoi_ky, x1l, dn, "ss": ct, tk_nh...; "ss"."hkd" =
       {"pp": MIEN | DT | TN, "nganh_md": "01".."06", "nganh": "5111=01;5113=02K", "ky": Q | M} do nguoi dung chon o ModHKD172).
Can cu (10/2026):
  - TT 152/2025/TT-BTC (31/12/2025, hieu luc 01/01/2026, thay TT 88/2021): so S1a-HKD (ho khong chiu thue GTGT, khong nop TNCN),
    S2a-HKD (ho nop GTGT + TNCN theo ty le % tren doanh thu - ghi theo nhom nganh nghe cung ty le), S2b-HKD (GTGT ty le %, TNCN
    tren thu nhap tinh thue; kem S2c / S2d / S2e da co o In toan bo so), S3a-HKD nghia vu thue khac (da co).
  - ND 68/2026, ND 141/2026 (29/4/2026, hieu luc 01/01/2026): doanh thu nam <= 1 ty -> khong nop GTGT, TNCN (chi thong bao doanh thu
    01/TKN-CNKD truoc 31/01 nam sau); tren 1 ty -> khai 01/CNKD theo quy (thang khi doanh thu > 50 ty) tu quy vuot nguong;
    thue TNCN = (doanh thu - 1 ty duoc tru / nam) x ty le; hoac (doanh thu - chi phi) x 15 % / 17 % / 20 % theo muc doanh thu.
  - TT 18/2026 + TT 50/2026/TT-BTC (13/5/2026): mau 01/CNKD, 01/BK-STK, 01/BK-HTK; HTKK 5.7.9: 01_CNKD_HKD_TT50 v2.9.8 (xem XSD).
  - Ty le % tren doanh thu theo nhom nganh (ma HTKK): 01 phan phoi hang hoa 1 / 0,5; 02 dich vu, xay dung khong bao thau 5 / 2;
    03 cho thue tai san 5 / 5; 04 san xuat, van tai, dich vu gan hang hoa, xay dung bao thau 3 / 1,5; 05 noi dung so 5 / 5;
    06 khac 2 / 1 - lay tu tham_so_nam (HKD_TL_GTGT_xx / HKD_TL_TNCN_xx), sua duoc bang tham_so_nam_rieng.txt.
Phan mem hach toan theo tai khoan (TT133 / TT99); doanh thu = phat sinh Co TK 511 / 512 (giam tru ghi am, bo ket chuyen 911).
Nhom nganh cua tung dong: theo anh xa tai khoan doanh thu (mac dinh 5111 -> 01, 5112 -> 04, 5113 -> 02, 5117 -> 03, 5118 -> 06;
nguoi dung sua: "5111=01;5118=06K" - K = khong chiu thue GTGT [12], Z = thue suat 0 % [13]). Khong ghi so, khong dua vao HTKK (xem truoc).
"""
import datetime
import io
import os
import re
import xml.etree.ElementTree as ET
from collections import OrderedDict, defaultdict

import so_sach_mau as SM
from xlsx_viet import SoExcel, dia_chi

GOC = os.path.dirname(os.path.abspath(__file__))
_so, lam_tron, dd = SM._so, SM.lam_tron, SM.dd
F_TIEN, F_NGAY, F_PT = SM.F_TIEN, SM.F_NGAY, '0.##"%"'

TEN_MAU = OrderedDict([
    ("SS_HKDS1A", "S1a-HKD - Sổ doanh thu bán hàng hoá, dịch vụ (hộ không chịu thuế GTGT, không nộp thuế TNCN - doanh thu năm đến 1 tỷ)"),
    ("SS_HKDS2A", "S2a-HKD - Sổ doanh thu bán hàng hoá, dịch vụ (hộ nộp thuế GTGT và TNCN theo tỷ lệ % trên doanh thu)"),
    ("SS_HKDS2B", "S2b-HKD - Sổ doanh thu bán hàng hoá, dịch vụ (hộ nộp GTGT theo tỷ lệ %, TNCN trên thu nhập tính thuế)"),
    ("SS_HKDCNKD", "01/CNKD - Tờ khai thuế hộ kinh doanh, cá nhân kinh doanh (TT 50/2026) + XML HTKK 01_CNKD_HKD_TT50"),
])
TEP = {"SS_HKDS1A": "TT152_S1a_SoDoanhThu", "SS_HKDS2A": "TT152_S2a_SoDoanhThu", "SS_HKDS2B": "TT152_S2b_SoDoanhThu", "SS_HKDCNKD": "01_CNKD"}
CAN_CU = "(Kèm theo Thông tư số 152/2025/TT-BTC ngày 31 tháng 12 năm 2025 của Bộ trưởng Bộ Tài chính)"
CAN_CU_TK = "(Kèm theo Thông tư số 50/2026/TT-BTC ngày 13 tháng 5 năm 2026 của Bộ trưởng Bộ Tài chính)"
MA_FILE = "01_CNKD_HKD_TT50"
MA_TKHAI, PBAN_XML = "1266", "2.9.8"
TEN_TKHAI = "TỜ KHAI THUẾ ĐỐI VỚI HỘ KINH DOANH, CÁ NHÂN KINH DOANH"
PP_TEN = OrderedDict([("MIEN", "Hộ doanh thu năm đến 1 tỷ đồng - không chịu thuế GTGT, không phải nộp thuế TNCN (sổ S1a-HKD)"),
                      ("DT", "Hộ nộp thuế GTGT và thuế TNCN theo tỷ lệ % trên doanh thu (sổ S2a-HKD, tờ khai 01/CNKD)"),
                      ("TN", "Hộ nộp thuế GTGT theo tỷ lệ % trên doanh thu, thuế TNCN trên thu nhập tính thuế (sổ S2b-HKD, 01/CNKD)")])
PP_SO = {"MIEN": ["SS_HKDS1A"], "DT": ["SS_HKDS2A", "SS_HKDCNKD"], "TN": ["SS_HKDS2B", "SS_HKDCNKD"]}
# nhom nganh nghe (ma theo HTKK 01_CNKD_HKD_TT50, XSD ct09_ma): (ten, ty le GTGT %, ty le TNCN %, ma chi tieu [10])
NHOM_NGANH = OrderedDict([
    ("01", ("Phân phối, cung cấp hàng hoá", 1.0, 0.5, "(a)")),
    ("02", ("Dịch vụ, xây dựng không bao thầu nguyên vật liệu", 5.0, 2.0, "(b)")),
    ("03", ("Hoạt động cho thuê tài sản trừ bất động sản", 5.0, 5.0, "(c)")),
    ("04", ("Sản xuất, vận tải, dịch vụ có gắn với hàng hoá, xây dựng có bao thầu nguyên vật liệu", 3.0, 1.5, "(d)")),
    ("05", ("Hoạt động cung cấp sản phẩm nội dung thông tin số về giải trí, trò chơi điện tử, phim số, ảnh số, nhạc số, quảng cáo số", 5.0, 5.0, "(e)")),
    ("06", ("Hoạt động kinh doanh khác", 2.0, 1.0, "(f)")),
])
# anh xa mac dinh tai khoan doanh thu TT133 -> nhom nganh
TK_NHOM_MAC_DINH = OrderedDict([("5111", "01"), ("5112", "04"), ("5113", "02"), ("5117", "03"), ("5118", "06")])
TIEU_MUC_GTGT = ("1701", "Thuế giá trị gia tăng hàng sản xuất, kinh doanh trong nước")
TIEU_MUC_TNCN = ("1003", "Thuế thu nhập từ hoạt động sản xuất, kinh doanh của cá nhân")
DT_TRU_MAC_DINH = 1000000000.0          # doanh thu duoc tru de tinh TNCN (1 ty / nam - TT 50/2026 chi tieu [16])
NGUONG_MIEN_MAC_DINH = 1000000000.0     # doanh thu nam <= 1 ty: khong nop GTGT, TNCN (ND 141/2026)
NGUONG_THANG_MAC_DINH = 50000000000.0   # doanh thu nam > 50 ty: khai thang
_RE_NGANH = re.compile(r"(\d{3,8})\s*[=:]\s*(0[1-6])\s*([KZkz]?)")


# ============================================================ tham so
def tham_so(khoa, ngay, mac_dinh):
    try:
        import tham_so_nam as TS
        v = TS.lay(khoa, ngay, None)
        return float(v) if v is not None else mac_dinh
    except Exception:
        return mac_dinh


def ty_le(nhom, ngay=None):
    """(ty le GTGT %, ty le TNCN %) cua nhom nganh - tham_so_nam HKD_TL_GTGT_xx / HKD_TL_TNCN_xx, mac dinh theo bang."""
    t = NHOM_NGANH.get(nhom) or NHOM_NGANH["06"]
    return tham_so("HKD_TL_GTGT_" + nhom, ngay, t[1]), tham_so("HKD_TL_TNCN_" + nhom, ngay, t[2])


def thue_suat_tn(doanh_thu_nam, ngay=None):
    """thue suat TNCN tren thu nhap tinh thue theo muc doanh thu nam (Luat Thue TNCN 109/2025: 15 % / 17 % / 20 %)."""
    n1 = tham_so("HKD_NGUONG_TS_1", ngay, 3000000000.0)
    n2 = tham_so("HKD_NGUONG_TS_2", ngay, 50000000000.0)
    if doanh_thu_nam <= n1:
        return tham_so("HKD_TNCN_TS_1", ngay, 0.15)
    if doanh_thu_nam <= n2:
        return tham_so("HKD_TNCN_TS_2", ngay, 0.17)
    return tham_so("HKD_TNCN_TS_3", ngay, 0.20)


# ============================================================ so lieu
def so_lieu(dl):
    return SM.so_lieu(dl)


def cau_hinh(S):
    """{"pp", "nganh_md", "nganh": {tien to TK: (nhom, co)}, "ky"} tu ss.hkd (VB) - thieu thi mac dinh DT / 01 / Q."""
    h = dict((S.ss or {}).get("hkd") or {})
    pp = str(h.get("pp") or "").strip().upper()
    if pp not in PP_TEN:
        pp = "DT"
    md = str(h.get("nganh_md") or "").strip()
    if md not in NHOM_NGANH:
        md = "01"
    anh_xa = OrderedDict()
    for tk, nhom, co in _RE_NGANH.findall(str(h.get("nganh") or "")):
        anh_xa[tk] = (nhom, co.upper())
    ky = str(h.get("ky") or "").strip().upper()
    sai = []
    for muc in re.split(r"[;,\n]+", str(h.get("nganh") or "")):
        if muc.strip() and not _RE_NGANH.fullmatch(muc.strip()):
            sai.append(muc.strip())
    return {"pp": pp, "nganh_md": md, "nganh": anh_xa, "ky": "M" if ky == "M" else "Q", "chon": bool(h.get("pp")), "sai": sai}


class DongDT(object):
    __slots__ = ("d", "tien", "nhom", "co", "thang", "nam", "tk")


def _kc_mact(S):
    kc = set()
    for d in S.ct:
        if S.sh(d.no).startswith("911") or S.sh(d.co).startswith("911"):
            kc.add(d.mact)
    return kc


def nhom_cua_tk(S, ma, cfg):
    """(nhom nganh, co K/Z/'') cua tai khoan doanh thu ma: anh xa nguoi dung (tien to dai nhat) -> mac dinh TT133 -> nhom mac dinh."""
    sh = S.sh(ma)
    for tk in sorted(cfg["nganh"], key=len, reverse=True):
        if sh.startswith(tk):
            return cfg["nganh"][tk]
    for tk in sorted(TK_NHOM_MAC_DINH, key=len, reverse=True):
        if sh.startswith(tk):
            return TK_NHOM_MAC_DINH[tk], ""
    return cfg["nganh_md"], ""


def dong_doanh_thu(S, cfg):
    """cac dong doanh thu trong ky (Co 511 / 512 duong, No 511 / 512 am - giam tru; bo chung tu ket chuyen) -> [DongDT]."""
    kc = _kc_mact(S)
    la511 = set(S.la_theo("511", "512"))
    ra = []
    for d in S.ct:
        if d.mact in kc or (d.co in la511 and d.no in la511):          # bo dong phan loai lai 511 <-> 511
            continue
        if d.co in la511:
            tk, tien = d.co, d.tien
        elif d.no in la511:
            tk, tien = d.no, -d.tien
        else:
            continue
        x = DongDT()
        x.d, x.tien, x.tk = d, tien, tk
        x.nhom, x.co = nhom_cua_tk(S, tk, cfg)
        x.thang, x.nam = S.thang_lich(d.t)
        ra.append(x)
    return ra


def luy_ke_truoc(S, thang_dau, nam):
    """doanh thu (Co - No 511 / 512, bo 911) cac thang truoc thang_dau cua nam duong lich - tu dl["doi_ung"] (ca nam tai chinh).
    -> (so tien, co du lieu)."""
    du = S.dl.get("doi_ung")
    if du is None:
        return 0.0, False
    la511 = set(S.la_theo("511", "512"))
    la911 = set(S.la_theo("911"))
    t = 0.0
    for r in du:
        try:
            no, co, th, ps = int(_so(r[0])), int(_so(r[1])), int(_so(r[2])), _so(r[3])
        except (TypeError, ValueError, IndexError):
            continue
        if not 1 <= th <= 12 or S.thang_lich(SM.K.thang_tc(th, S.dau_ky))[1] != nam or th >= thang_dau:
            continue
        if co in la511 and no in la511:
            continue
        if co in la511 and no not in la911:
            t += ps
        elif no in la511 and co not in la911:
            t -= ps
    return t, True


# ============================================================ ky khai
def cac_ky(S, cfg):
    """ky khai 01/CNKD trong khoang thang cua S (tron thang): 'M' -> tung thang; 'Q' -> cac quy tron trong khoang.
    -> ([(kieu, nam, so, [thang...])], canh_bao)."""
    thang = []
    for t in range(S.t1, S.t2 + 1):
        m, y = S.thang_lich(t)
        thang.append((y, m))
    cb = []
    if cfg["ky"] == "M":
        return [("M", y, m, [m]) for y, m in thang], cb
    ra, le = [], []
    for (y, m) in thang:
        q = (m - 1) // 3 + 1
        if (y, q) in [(k[1], k[2]) for k in ra] or (y, q) in le:
            continue
        ds = [3 * q - 2, 3 * q - 1, 3 * q]
        if all((y, x) in thang for x in ds):
            ra.append(("Q", y, q, ds))
        else:
            le.append((y, q))
    for (y, q) in le:
        cb.append("Quý %d/%d không trọn trong kỳ đã chọn (%s - %s) - chưa lập tờ khai 01/CNKD quý này; chọn kỳ trọn quý (hoặc chọn kỳ khai tháng)."
                  % (q, y, S.tu_ky.strftime("%d/%m/%Y"), S.den_ky.strftime("%d/%m/%Y")))
    return ra, cb


def ten_ky(k):
    return ("Quý %d năm %d" % (k[2], k[1])) if k[0] == "Q" else ("Tháng %02d năm %d" % (k[2], k[1]))


def tu_den(k):
    y, m1, m2 = k[1], k[3][0], k[3][-1]
    d1 = datetime.date(y, m1, 1)
    d2 = datetime.date(y + (m2 == 12), m2 % 12 + 1, 1) - datetime.timedelta(days=1)
    return d1, d2


def han_nop(k):
    """han nop ho so: quy -> ngay cuoi thang dau quy sau; thang -> ngay 20 thang sau (Luat Quan ly thue)."""
    _d1, d2 = tu_den(k)
    y, m = d2.year + (d2.month == 12), d2.month % 12 + 1
    if k[0] == "Q":
        return datetime.date(y + (m == 12), m % 12 + 1, 1) - datetime.timedelta(days=1)
    return datetime.date(y, m, 20)


# ============================================================ tong hop to khai
def tong_hop_ky(S, cfg, k, dong, lk_truoc, ngay=None):
    """so lieu 01/CNKD mot ky: dong theo nhom nganh [08]-[17], tong [18], mien [19], con phai nop [20], so duoc tru chuyen ky tiep.
    Tham so (ty le, muc tru) lay theo ngay cuoi ky. Doanh thu nhom am (giam tru > ban) -> ghi 0 + canh bao (HTKK: ct11 / 12 / 13 / 16 >= 0)."""
    thang = set(k[3])
    nam = k[1]
    ngay = ngay or tu_den(k)[1]
    cb = []
    trong_ky = [x for x in dong if x.nam == nam and x.thang in thang]
    nhom = OrderedDict()
    for x in trong_ky:
        g = nhom.setdefault(x.nhom, {"dt": 0.0, "kct": 0.0, "k0": 0.0, "dong": []})
        g["dt"] += x.tien
        if x.co == "K":
            g["kct"] += x.tien
        elif x.co == "Z":
            g["k0"] += x.tien
        g["dong"].append(x)
    tru_nam = tham_so("HKD_DT_TRU_TNCN", ngay, DT_TRU_MAC_DINH)
    con_tru = max(0.0, tru_nam - min(tru_nam, max(lk_truoc, 0.0)))
    hang = []
    for ma in NHOM_NGANH:
        if ma not in nhom:
            continue
        g = nhom[ma]
        tl_g, tl_t = ty_le(ma, ngay)
        dt, kct, k0 = lam_tron(g["dt"]), lam_tron(g["kct"]), lam_tron(g["k0"])
        if dt < 0 or kct < 0 or k0 < 0 or kct + k0 > dt:
            cb.append("%s: nhóm ngành %s doanh thu %s (không chịu thuế %s, 0%% %s) - giảm trừ lớn hơn doanh thu hoặc ánh xạ K / Z lệch; tờ khai ghi 0 cho phần âm - kiểm tra lại."
                      % (ten_ky(k), ma, dd(dt), dd(kct), dd(k0)))
            dt, kct, k0 = max(dt, 0), max(kct, 0), max(k0, 0)
            if kct + k0 > dt:
                kct, k0 = min(kct, dt), min(k0, max(dt - min(kct, dt), 0))
        h = {"nhom": ma, "ten": NHOM_NGANH[ma][0], "ct10": NHOM_NGANH[ma][3], "ct11": dt, "ct12": kct, "ct13": k0,
             "tl_gtgt": tl_g, "tl_tncn": tl_t, "ct15": dt, "ct16": 0, "ct17": 0, "so_ct": len(g["dong"])}
        h["ct14"] = lam_tron(max(dt - h["ct12"] - h["ct13"], 0) * tl_g / 100.0) if cfg["pp"] != "MIEN" else 0
        hang.append(h)
    tong_dt = sum(h["ct11"] for h in hang)
    tncn_tn = None
    if cfg["pp"] == "DT":
        for h in sorted(hang, key=lambda h: -h["tl_tncn"]):          # tru vao nhom co ty le TNCN cao nhat truoc (co loi nhat)
            h["ct16"] = lam_tron(min(con_tru, max(h["ct15"], 0)))
            con_tru -= h["ct16"]
            h["ct17"] = lam_tron(max(h["ct15"] - h["ct16"], 0) * h["tl_tncn"] / 100.0)
    elif cfg["pp"] == "TN" and hang:
        cp = chi_phi_ky(S, k)
        dt_nt = _so(((S.dl.get("dt_nam_truoc") or {}).get("so")) or 0) or 0.0
        can_cu_dt = max(max(lk_truoc, 0.0) + tong_dt, dt_nt)
        ts = thue_suat_tn(can_cu_dt, ngay)
        tn = max(tong_dt - cp, 0.0)
        tncn_tn = {"chi_phi": lam_tron(cp), "thu_nhap": lam_tron(tn), "thue_suat": ts, "thue": lam_tron(tn * ts), "dt_can_cu": lam_tron(can_cu_dt)}
        cb.append("%s: thuế TNCN tạm nộp theo thu nhập tính thuế = (%s - chi phí %s) x %s%% (thuế suất theo doanh thu năm %s - luỹ kế / năm trước; "
                  "quyết toán năm xác định lại) = %s." % (ten_ky(k), dd(tong_dt), dd(cp), _pt(ts * 100), dd(can_cu_dt), dd(tn * ts)))
        h0 = max(hang, key=lambda h: h["ct11"])
        h0["ct17"] = tncn_tn["thue"]
        con_tru = 0.0
    tong = {c: sum(h[c] for h in hang) for c in ("ct11", "ct12", "ct13", "ct14", "ct15", "ct16", "ct17")}
    return {"ky": k, "hang": hang, "tong": tong, "mien": {"ct14": 0, "ct17": 0}, "con": {"ct14": tong["ct14"], "ct17": tong["ct17"]},
            "tru_tiep": lam_tron(con_tru) if cfg["pp"] == "DT" else 0, "lk_truoc": lam_tron(lk_truoc), "lk_cuoi": lam_tron(lk_truoc + tong_dt),
            "tncn_tn": tncn_tn, "han": han_nop(k), "so_dong": len(trong_ky), "canh_bao": cb}


def chi_phi_ky(S, k):
    """chi phi trong ky (No - Co TK 6xx, 8xx tru 821; bo ket chuyen) - phuong phap TNCN tren thu nhap tinh thue."""
    kc = _kc_mact(S)
    la = set(m for m in S.la_theo("6", "8") if not S.sh(m).startswith("821"))
    thang = set(k[3])
    t = 0.0
    for d in S.ct:
        if d.mact in kc:
            continue
        m, y = S.thang_lich(d.t)
        if y != k[1] or m not in thang:
            continue
        if d.no in la:
            t += d.tien
        if d.co in la:
            t -= d.tien
    return t


# ============================================================ ve so TT152
class Bieu(object):
    def __init__(self, S, ma):
        self.S, self.ma = S, ma
        self.wb = SoExcel(font="Times New Roman", co=11)
        w = self.wb
        self.k_td = w.kieu(dam=True, co=14, can="giua")
        self.k_dam = w.kieu(dam=True)
        self.k_dam_giua = w.kieu(dam=True, can="giua")
        self.k_thuong = w.kieu()
        self.k_giua = w.kieu(can="giua")
        self.k_phai = w.kieu(can="phai")
        self.k_nghieng = w.kieu(nghieng=True, co=10, can="giua", xuong=True)
        self.k_nghieng_trai = w.kieu(nghieng=True, co=10, xuong=True)
        self.k_dau = w.kieu(dam=True, co=10, can="giua", xuong=True, khung=True, nen="D9E1F2")
        self.k_so_cot = w.kieu(nghieng=True, co=9, can="giua", khung=True, nen="F2F2F2")
        self.k_o = w.kieu(khung=True, xuong=True, co=10)
        self.k_o_giua = w.kieu(khung=True, can="giua", co=10)
        self.k_o_so = w.kieu(khung=True, so=F_TIEN, co=10)
        self.k_o_ngay = w.kieu(khung=True, so=F_NGAY, can="giua", co=10)
        self.k_o_pt = w.kieu(khung=True, so=F_PT, can="giua", co=10, nen="FFF9C4")
        self.k_nhom = w.kieu(khung=True, dam=True, co=10, nen="EEF5E9")
        self.k_nhom_so = w.kieu(khung=True, dam=True, so=F_TIEN, co=10, nen="EEF5E9")
        self.k_cong = w.kieu(khung=True, dam=True, co=10, nen="FFF2CC")
        self.k_cong_so = w.kieu(khung=True, dam=True, so=F_TIEN, co=10, nen="FFF2CC")
        self.k_chu_ky = w.kieu(dam=True, can="giua")
        self.k_chu_ky2 = w.kieu(nghieng=True, co=10, can="giua")

    def sheet(self, ten, cot):
        return self.wb.sheet(ten[:31], cot=cot)

    def dau(self, ws, mau_so, tieu_de, nc, can_cu=CAN_CU, ky=None):
        """dau so ho kinh doanh: HO, CA NHAN KINH DOANH / Dia chi / Ma so thue - Mau so - tieu de - ky ke khai."""
        S = self.S
        dn = S.dn
        th = S.thay()
        c2 = max(nc // 2 + 1, 3)
        ws.gop(1, 1, 1, c2 - 1, "HỘ, CÁ NHÂN KINH DOANH: " + (dn.get("ten") or "").upper(), self.k_dam)
        ws.gop(2, 1, 2, c2 - 1, th["DIA_CHI"], self.k_thuong)
        ws.gop(3, 1, 3, c2 - 1, "Mã số thuế: " + str(dn.get("mst") or ""), self.k_thuong)
        ws.gop(1, c2, 1, nc, "Mẫu số " + mau_so, self.k_dam_giua)
        ws.gop(2, c2, 3, nc, can_cu, self.k_nghieng)
        ws.gop(5, 1, 5, nc, tieu_de, self.k_td)
        ws.gop(6, 1, 6, nc, "Địa điểm kinh doanh: " + (dn.get("dia_chi") or ""), self.k_giua)
        ws.gop(7, 1, 7, nc, "Kỳ kê khai: " + (ky or th["KY_TT"]), self.k_giua)
        ws.gop(8, nc - 1, 8, nc, "Đơn vị tính: Đồng Việt Nam", self.k_nghieng)
        return 9

    def tieu_de_cot(self, ws, r, cot, ma_cot=None, cao=36):
        for td, c1, c2, rt in cot:
            ws.gop(r, c1, r + rt, c2, td, self.k_dau)
        ws.cao(r, cao)
        n = max(x[3] for x in cot) + 1
        if ma_cot:
            for ma, c in ma_cot:
                ws.o(r + n, c, ma, self.k_so_cot)
            n += 1
        return r + n

    def cuoi(self, ws, r, nc):
        S = self.S
        c1 = max(nc // 2 + 1, 2)
        ws.gop(r, c1, r, nc, S.noi_ngay(S.ngay_lap), self.k_nghieng)
        ws.gop(r + 1, c1, r + 1, nc, "NGƯỜI ĐẠI DIỆN HỘ KINH DOANH / CÁ NHÂN KINH DOANH", self.k_chu_ky)
        ws.gop(r + 2, c1, r + 2, nc, "(Ký, ghi rõ họ tên, đóng dấu (nếu có))", self.k_chu_ky2)
        ws.gop(r + 6, c1, r + 6, nc, S.nguoi_ky.get("giam_doc", ""), self.k_chu_ky)
        return r + 8

    def ghi_chu(self, ws, r, nc, chu):
        ws.gop(r, 1, r, nc, chu, self.k_nghieng_trai)
        ws.cao(r, 15 * max(1, (len(chu) // 110) + 1))
        return r + 1

    def luu(self, thumuc, hau=""):
        S = self.S
        ten = TEP[self.ma] + "_%d" % S.nam + ("" if S.ca_nam else "_T%02d-%02d" % (S.thang_lich(S.t1)[0], S.thang_lich(S.t2)[0])) + hau
        p = os.path.join(thumuc, ten + ".xlsx")
        self.wb.luu(p)
        return p


def _ten_thang(y, m):
    return "tháng %02d/%d" % (m, y)


def lap_s1a(S, cfg):
    """S1a-HKD: ngay thang (A), dien giai (B), so tien (1) - ghi theo NGAY (gop cac chung tu cung ngay), cong thang, luy ke."""
    B, KT = Bieu(S, "SS_HKDS1A"), SM.Kiem("SS_HKDS1A")
    ws = B.sheet("S1a-HKD", [14, 60, 20])
    nc = 3
    r = B.dau(ws, "S1a-HKD", "SỔ DOANH THU BÁN HÀNG HOÁ, DỊCH VỤ", nc)
    r = B.tieu_de_cot(ws, r, [("Ngày, tháng", 1, 1, 0), ("Diễn giải", 2, 2, 0), ("Số tiền", 3, 3, 0)], [("A", 1), ("B", 2), ("1", 3)], 24)
    dong = dong_doanh_thu(S, cfg)
    lk, _co = luy_ke_truoc(S, S.thang_lich(S.t1)[0], S.thang_lich(S.t1)[1])
    ws.o(r, 1, None, B.k_o_giua)
    ws.o(r, 2, "Luỹ kế doanh thu từ đầu năm đến đầu kỳ", B.k_o)
    ws.o(r, 3, lk, B.k_o_so)
    r += 1
    tong = 0.0
    o_thang = []
    for t in range(S.t1, S.t2 + 1):
        m, y = S.thang_lich(t)
        ngay = OrderedDict()
        for x in dong:
            if (x.nam, x.thang) == (y, m):
                g = ngay.setdefault(x.d.ngay or S.tu_ky, [0.0, 0])
                g[0] += x.tien
                g[1] += 1
        r0 = r
        for ng in sorted(ngay):
            tien, n = ngay[ng]
            ws.o(r, 1, ng, B.k_o_ngay)
            ws.o(r, 2, "Doanh thu bán hàng hoá, dịch vụ trong ngày (%d chứng từ)" % n, B.k_o)
            ws.o(r, 3, tien, B.k_o_so)
            tong += tien
            r += 1
        ws.o(r, 1, None, B.k_cong)
        ws.o(r, 2, "Cộng " + _ten_thang(y, m), B.k_cong)
        ws.o(r, 3, ("=SUM(%s:%s)" % (dia_chi(r0, 3), dia_chi(r - 1, 3))) if r > r0 else 0, B.k_cong_so)
        o_thang.append(dia_chi(r, 3))
        r += 1
    ws.o(r, 1, None, B.k_cong)
    ws.o(r, 2, "Tổng cộng doanh thu trong kỳ", B.k_cong)
    ws.o(r, 3, "=" + "+".join(o_thang), B.k_cong_so)
    r += 1
    ws.o(r, 1, None, B.k_cong)
    ws.o(r, 2, "Luỹ kế doanh thu từ đầu năm đến cuối kỳ", B.k_cong)
    ws.o(r, 3, lk + tong, B.k_cong_so)
    r += 2
    nguong = tham_so("HKD_NGUONG_MIEN", S.den_ky, NGUONG_MIEN_MAC_DINH)
    r = B.ghi_chu(ws, r, nc, "Sổ dùng cho hộ, cá nhân kinh doanh thuộc đối tượng không chịu thuế GTGT, không phải nộp thuế TNCN (doanh thu năm đến %s đồng - "
                             "NĐ 141/2026/NĐ-CP): ghi doanh thu theo ngày; cuối năm gửi Thông báo doanh thu 01/TKN-CNKD trước 31/01 năm sau. "
                             "Số liệu = phát sinh Có TK 511, 512 (giảm trừ ghi âm), không gồm kết chuyển." % dd(nguong))
    if lk + tong > nguong:
        r = B.ghi_chu(ws, r, nc, "[!] Luỹ kế doanh thu năm %s đồng đã VƯỢT ngưỡng %s đồng: từ kỳ này hộ phải khai, nộp thuế GTGT, TNCN (sổ S2a / S2b-HKD và tờ khai 01/CNKD)."
                      % (dd(lk + tong), dd(nguong)))
    B.cuoi(ws, r + 1, nc)
    ps = sum(S.ps_ky(m, False)[1] - S.ps_ky(m, False)[0] for m in S.la_theo("511", "512"))
    KT.them("Tổng doanh thu trên sổ = phát sinh Có - Nợ TK 511, 512 (không kể kết chuyển)", tong, ps)
    return B, KT.canh_bao()


def lap_s2(S, cfg, ma):
    """S2a-HKD (GTGT + TNCN theo ty le) / S2b-HKD (chi GTGT theo ty le): chung tu (A, B), dien giai (C), doanh thu (1) theo NHOM NGANH;
    cuoi so: bang thue theo nhom (o vang ty le - sua duoc, so thue tu tinh)."""
    la_s2a = ma == "SS_HKDS2A"
    B, KT = Bieu(S, ma), SM.Kiem(ma)
    nc = 5
    ws = B.sheet("S2a-HKD" if la_s2a else "S2b-HKD", [12, 11, 50, 18, 14])
    r = B.dau(ws, "S2a-HKD" if la_s2a else "S2b-HKD", "SỔ DOANH THU BÁN HÀNG HOÁ, DỊCH VỤ", nc)
    r = B.tieu_de_cot(ws, r, [("Chứng từ", 1, 2, 0), ("Diễn giải", 3, 3, 1), ("Doanh thu", 4, 4, 1), ("Ghi chú", 5, 5, 1)], None, 24)
    ws.o(r - 1, 1, "Số hiệu", B.k_dau)
    ws.o(r - 1, 2, "Ngày, tháng", B.k_dau)
    for ma_c, c in (("A", 1), ("B", 2), ("C", 3), ("1", 4), ("D", 5)):
        ws.o(r, c, ma_c, B.k_so_cot)
    r += 1
    dong = dong_doanh_thu(S, cfg)
    nhom = OrderedDict()
    for x in dong:
        nhom.setdefault(x.nhom, []).append(x)
    o_nhom = {}
    tong = 0.0
    stt = 0
    for ma_n in NHOM_NGANH:
        if ma_n not in nhom:
            continue
        stt += 1
        tl_g, tl_t = ty_le(ma_n, S.den_ky)
        ws.gop(r, 1, r, 3, "%d. Nhóm ngành nghề %s - %s" % (stt, ma_n, NHOM_NGANH[ma_n][0]), B.k_nhom)
        ws.o(r, 4, None, B.k_nhom_so)
        ws.o(r, 5, None, B.k_nhom)
        r += 1
        r0 = r
        thang_cu = None
        o_th = []
        r_th = r
        for x in nhom[ma_n]:
            th = (x.nam, x.thang)
            if thang_cu is not None and th != thang_cu and S.t2 > S.t1:
                ws.gop(r, 1, r, 3, "Cộng " + _ten_thang(*thang_cu), B.k_cong)
                ws.o(r, 4, "=SUM(%s:%s)" % (dia_chi(r_th, 4), dia_chi(r - 1, 4)), B.k_cong_so)
                ws.o(r, 5, None, B.k_cong)
                o_th.append(dia_chi(r, 4))
                r += 1
                r_th = r
            thang_cu = th
            d = x.d
            ws.o(r, 1, d.sh, B.k_o_giua)
            ws.o(r, 2, d.ngay, B.k_o_ngay)
            ws.o(r, 3, d.dg, B.k_o)
            ws.o(r, 4, x.tien, B.k_o_so)
            ws.o(r, 5, "Giảm trừ / trả lại" if x.tien < 0 else ("Không chịu thuế GTGT" if x.co == "K" else ("Thuế suất 0%" if x.co == "Z" else "")), B.k_o)
            tong += x.tien
            r += 1
        if S.t2 > S.t1 and thang_cu is not None:
            ws.gop(r, 1, r, 3, "Cộng " + _ten_thang(*thang_cu), B.k_cong)
            ws.o(r, 4, "=SUM(%s:%s)" % (dia_chi(r_th, 4), dia_chi(r - 1, 4)), B.k_cong_so)
            ws.o(r, 5, None, B.k_cong)
            o_th.append(dia_chi(r, 4))
            r += 1
        ws.gop(r, 1, r, 3, "Cộng nhóm %s (tỷ lệ GTGT %s%%%s)" % (ma_n, _pt(tl_g), (", TNCN %s%%" % _pt(tl_t)) if la_s2a else ""), B.k_cong)
        ws.o(r, 4, ("=" + "+".join(o_th)) if o_th else (("=SUM(%s:%s)" % (dia_chi(r0, 4), dia_chi(r - 1, 4))) if r > r0 else 0), B.k_cong_so)
        ws.o(r, 5, None, B.k_cong)
        o_nhom[ma_n] = (r, sum(x.tien for x in nhom[ma_n]), sum(x.tien for x in nhom[ma_n] if x.co in ("K", "Z")), tl_g, tl_t)
        r += 1
    if not nhom:
        ws.gop(r, 1, r, nc, "(kỳ này không có doanh thu bán hàng hoá, dịch vụ trên TK 511, 512)", B.k_o)
        r += 1
    ws.gop(r, 1, r, 3, "TỔNG CỘNG DOANH THU TRONG KỲ", B.k_cong)
    ws.o(r, 4, ("=" + "+".join(dia_chi(x[0], 4) for x in o_nhom.values())) if o_nhom else 0, B.k_cong_so)
    ws.o(r, 5, None, B.k_cong)
    r += 2
    # bang thue theo nhom nganh
    lk, co_lk = luy_ke_truoc(S, S.thang_lich(S.t1)[0], S.thang_lich(S.t1)[1])
    tru_nam = tham_so("HKD_DT_TRU_TNCN", S.den_ky, DT_TRU_MAC_DINH)
    ws.gop(r, 1, r, nc, "THUẾ PHẢI NỘP THEO TỶ LỆ %% TRÊN DOANH THU (%s)" % ("thuế GTGT và thuế TNCN" if la_s2a else "thuế GTGT; thuế TNCN trên thu nhập tính thuế xem sổ S2c-HKD và tờ khai 01/CNKD"), B.k_dam)
    r += 1
    cot = [("Nhóm ngành", 1, 2, 0), ("Doanh thu tính thuế GTGT", 3, 3, 0), ("Tỷ lệ GTGT", 4, 4, 0), ("Thuế GTGT", 5, 5, 0)]
    r = B.tieu_de_cot(ws, r, cot, None, 30)
    o_g = []
    for ma_n, (rn, dt, kz, tl_g, tl_t) in o_nhom.items():
        ws.gop(r, 1, r, 2, ma_n + " - " + NHOM_NGANH[ma_n][0][:40], B.k_o)
        ws.o(r, 3, dt - kz, B.k_o_so)
        ws.o(r, 4, tl_g, B.k_o_pt)
        ws.o(r, 5, "=ROUND(%s*%s/100,0)" % (dia_chi(r, 3), dia_chi(r, 4)), B.k_o_so)
        o_g.append(dia_chi(r, 5))
        r += 1
    ws.gop(r, 1, r, 4, "Tổng số thuế GTGT phải nộp trong kỳ", B.k_cong)
    ws.o(r, 5, ("=" + "+".join(o_g)) if o_g else 0, B.k_cong_so)
    r += 2
    if la_s2a:
        cot = [("Nhóm ngành", 1, 1, 0), ("Doanh thu tính thuế TNCN", 2, 2, 0), ("Doanh thu được trừ (1 tỷ/năm)", 3, 3, 0), ("Tỷ lệ TNCN", 4, 4, 0), ("Thuế TNCN", 5, 5, 0)]
        r = B.tieu_de_cot(ws, r, cot, None, 30)
        con = max(0.0, tru_nam - min(tru_nam, max(lk, 0.0)))
        o_t = []
        for ma_n, (rn, dt, kz, tl_g, tl_t) in sorted(o_nhom.items(), key=lambda kv: -kv[1][4]):
            tru = min(con, max(dt, 0.0))
            con -= tru
            ws.o(r, 1, ma_n, B.k_o_giua)
            ws.o(r, 2, dt, B.k_o_so)
            ws.o(r, 3, tru, B.k_o_so)
            ws.o(r, 4, tl_t, B.k_o_pt)
            ws.o(r, 5, "=ROUND((%s-%s)*%s/100,0)" % (dia_chi(r, 2), dia_chi(r, 3), dia_chi(r, 4)), B.k_o_so)
            o_t.append(dia_chi(r, 5))
            r += 1
        ws.gop(r, 1, r, 4, "Tổng số thuế TNCN phải nộp trong kỳ", B.k_cong)
        ws.o(r, 5, ("=" + "+".join(o_t)) if o_t else 0, B.k_cong_so)
        r += 1
        ws.gop(r, 1, r, 4, "Doanh thu được trừ còn lại chuyển kỳ sau (mức %s đồng/năm, đã dùng trước kỳ %s)" % (dd(tru_nam), dd(min(tru_nam, max(lk, 0.0)))), B.k_o)
        ws.o(r, 5, con, B.k_o_so)
        r += 1
    r += 1
    r = B.ghi_chu(ws, r, nc, "Cột 1 ghi doanh thu theo từng nhóm ngành nghề có cùng tỷ lệ %% thuế (phần mềm xếp nhóm theo tài khoản doanh thu - sửa ánh xạ ở menu Dữ liệu); "
                             "ô vàng: tỷ lệ %% theo Phụ lục I Luật Thuế GTGT, Luật Thuế TNCN (HTKK 01/CNKD) - sửa được, số thuế tự tính. "
                             "Số liệu = phát sinh Có TK 511, 512 (giảm trừ ghi âm), không gồm kết chuyển.%s"
                  % ("" if co_lk else " Chưa có số luỹ kế các tháng trước kỳ (JSON không có doi_ung)."))
    B.cuoi(ws, r + 1, nc)
    ps = sum(S.ps_ky(m, False)[1] - S.ps_ky(m, False)[0] for m in S.la_theo("511", "512"))
    KT.them("Tổng doanh thu trên sổ = phát sinh Có - Nợ TK 511, 512 (không kể kết chuyển)", tong, ps)
    return B, KT.canh_bao()


# ============================================================ to khai 01/CNKD - Excel xem truoc
def _vn(x):
    return dd(x)


def _pt(x):
    return ("%g" % x).replace(".", ",")


def lap_excel_cnkd(S, cfg, ds_kq, cb, duong):
    B = Bieu(S, "SS_HKDCNKD")
    dn = S.dn
    for kq in ds_kq:
        k = kq["ky"]
        ws = B.sheet(("01-CNKD " + ("Q%d_%d" % (k[2], k[1]) if k[0] == "Q" else "T%02d_%d" % (k[2], k[1]))), [6, 46, 9, 16, 16, 16, 16, 16, 16, 16])
        nc = 10
        ws.gop(1, 1, 1, 6, "CỘNG HOÀ XÃ HỘI CHỦ NGHĨA VIỆT NAM", B.k_dam_giua)
        ws.gop(2, 1, 2, 6, "Độc lập - Tự do - Hạnh phúc", B.k_giua)
        ws.gop(1, 7, 1, nc, "Mẫu số: 01/CNKD", B.k_dam_giua)
        ws.gop(2, 7, 3, nc, CAN_CU_TK, B.k_nghieng)
        ws.gop(5, 1, 5, nc, TEN_TKHAI, B.k_td)
        ws.gop(6, 1, 6, nc, "(Áp dụng cho hộ kinh doanh, cá nhân kinh doanh có doanh thu năm trên 1 tỷ đồng)", B.k_nghieng)
        d1, d2 = tu_den(k)
        ws.gop(7, 1, 7, nc, "[01] Kỳ tính thuế: %s (từ %s đến %s)      [02] Lần đầu: [X]      [03] Bổ sung lần thứ: ..." % (ten_ky(k), d1.strftime("%d/%m/%Y"), d2.strftime("%d/%m/%Y")), B.k_giua)
        r = 9
        for nhan, gt in (("[04] Người nộp thuế:", dn.get("ten") or ""), ("[05] Mã số thuế / số định danh cá nhân:", str(dn.get("mst") or "")),
                         ("[26] Địa chỉ:", dn.get("dia_chi") or ""), ("[27] Điện thoại:", dn.get("dien_thoai") or ""), ("[29] Email:", dn.get("email") or "")):
            ws.gop(r, 1, r, 3, nhan, B.k_dam)
            ws.gop(r, 4, r, nc, gt, B.k_thuong)
            r += 1
        ws.gop(r, 1, r, nc, "[X] " + ("Hộ kinh doanh, cá nhân kinh doanh thuộc đối tượng nộp thuế TNCN trên doanh thu tính thuế" if cfg["pp"] != "TN"
                                   else "Hộ kinh doanh, cá nhân kinh doanh thuộc đối tượng nộp thuế TNCN trên thu nhập tính thuế"), B.k_thuong)
        r += 2
        ws.gop(r, 1, r, nc, "A. KÊ KHAI THUẾ GTGT, TNCN - I. Hoạt động sản xuất, kinh doanh hàng hoá, cung cấp dịch vụ có địa điểm kinh doanh cố định (trụ sở kinh doanh chính)", B.k_dam)
        r += 1
        ws.gop(r, 9, r, nc, "Đơn vị tiền: Đồng Việt Nam", B.k_nghieng)
        r += 1
        cot = [("STT", 1, 1, 1), ("Nhóm ngành nghề", 2, 2, 1), ("Mã CT", 3, 3, 1), ("Thuế GTGT", 4, 7, 0), ("Thuế TNCN", 8, 10, 0)]
        for td, c1, c2, rt in cot:
            ws.gop(r, c1, r + rt, c2, td, B.k_dau)
        for td, c in (("Doanh thu", 4), ("Trong đó: doanh thu không chịu thuế GTGT", 5), ("Trong đó: doanh thu chịu thuế suất 0%", 6), ("Số thuế phải nộp", 7),
                      ("Doanh thu", 8), ("Doanh thu được trừ để xác định doanh thu tính thuế", 9), ("Số thuế phải nộp", 10)):
            ws.o(r + 1, c, td, B.k_dau)
        ws.cao(r, 24)
        ws.cao(r + 1, 48)
        r += 2
        for ma_c, c in (("[08]", 1), ("[09]", 2), ("[10]", 3), ("[11]", 4), ("[12]", 5), ("[13]", 6), ("[14]", 7), ("[15]", 8), ("[16]", 9), ("[17]", 10)):
            ws.o(r, c, ma_c, B.k_so_cot)
        r += 1
        r0 = r
        for i, h in enumerate(kq["hang"]):
            ws.o(r, 1, "1.%d" % (i + 1), B.k_o_giua)
            ws.o(r, 2, "%s - %s (GTGT %s%%, TNCN %s%%)" % (h["nhom"], h["ten"], _pt(h["tl_gtgt"]), _pt(h["tl_tncn"])), B.k_o)
            ws.o(r, 3, h["ct10"], B.k_o_giua)
            for c, key in ((4, "ct11"), (5, "ct12"), (6, "ct13"), (7, "ct14"), (8, "ct15"), (9, "ct16"), (10, "ct17")):
                ws.o(r, c, h[key], B.k_o_so)
            r += 1
        if not kq["hang"]:
            ws.gop(r, 1, r, nc, "(kỳ này không có doanh thu)", B.k_o)
            r += 1
        for nhan, ma_c, d in (("IV. Tổng cộng", "[18]", kq["tong"]), ("V. Số thuế được miễn", "[19]", kq["mien"]), ("VI. Số thuế còn phải nộp", "[20]", kq["con"])):
            ws.gop(r, 1, r, 2, nhan, B.k_cong)
            ws.o(r, 3, ma_c, B.k_cong)
            for c, key in ((4, "ct11"), (5, "ct12"), (6, "ct13"), (7, "ct14"), (8, "ct15"), (9, "ct16"), (10, "ct17")):
                ws.o(r, c, d.get(key, None), B.k_cong_so)
            r += 1
        r += 1
        ws.gop(r, 1, r, nc, "D. HỖ TRỢ TỰ ĐỘNG THÔNG TIN NỘP THUẾ (HTKK tự điền chương, địa bàn, cơ quan thu)", B.k_dam)
        r += 1
        for td, c1, c2 in (("STT", 1, 1), ("Nội dung các khoản nộp NSNN", 2, 3), ("Số tiền", 4, 4), ("Tiểu mục", 5, 5), ("Hạn nộp thuế", 6, 7)):
            ws.gop(r, c1, r, c2, td, B.k_dau)
        r += 1
        for i, (tm, so) in enumerate(((TIEU_MUC_GTGT, kq["con"]["ct14"]), (TIEU_MUC_TNCN, kq["con"]["ct17"]))):
            ws.o(r, 1, i + 1, B.k_o_giua)
            ws.gop(r, 2, r, 3, tm[1], B.k_o)
            ws.o(r, 4, so, B.k_o_so)
            ws.o(r, 5, tm[0], B.k_o_giua)
            ws.gop(r, 6, r, 7, kq["han"], B.k_o_ngay)
            r += 1
        ws.gop(r, 1, r, 3, "Tổng cộng [47]", B.k_cong)
        ws.o(r, 4, kq["con"]["ct14"] + kq["con"]["ct17"], B.k_cong_so)
        r += 2
        if cfg["pp"] == "DT":
            ws.gop(r, 1, r, nc, "Bạn còn được tiếp tục trừ %s đồng vào doanh thu tính thuế TNCN của kỳ tiếp theo (mức 1 tỷ đồng/năm; đã dùng trước kỳ này %s đồng)."
                   % (_vn(kq["tru_tiep"]), _vn(min(kq["lk_truoc"], tham_so("HKD_DT_TRU_TNCN", S.den_ky, DT_TRU_MAC_DINH)))), B.k_thuong)
            r += 1
        if kq["tncn_tn"]:
            t = kq["tncn_tn"]
            ws.gop(r, 1, r, nc, "Thuế TNCN trên thu nhập tính thuế (tạm nộp): doanh thu %s - chi phí %s = thu nhập %s x thuế suất %s%% = %s đồng (ghi ở dòng có doanh thu lớn nhất)."
                   % (_vn(kq["tong"]["ct11"]), _vn(t["chi_phi"]), _vn(t["thu_nhap"]), _pt(t["thue_suat"] * 100), _vn(t["thue"])), B.k_thuong)
            r += 1
        ws.gop(r, 1, r, nc, "Luỹ kế doanh thu từ đầu năm: trước kỳ %s đồng, đến hết kỳ %s đồng." % (_vn(kq["lk_truoc"]), _vn(kq["lk_cuoi"])), B.k_nghieng_trai)
        r += 2
        ws.gop(r, 6, r, nc, S.noi_ngay(S.ngay_lap), B.k_nghieng)
        ws.gop(r + 1, 6, r + 1, nc, "NGƯỜI NỘP THUẾ hoặc ĐẠI DIỆN HỢP PHÁP CỦA NGƯỜI NỘP THUẾ", B.k_chu_ky)
        ws.gop(r + 2, 6, r + 2, nc, "(Chữ ký, ghi rõ họ tên; chức vụ và đóng dấu (nếu có) / Ký điện tử)", B.k_chu_ky2)
        ws.gop(r + 6, 6, r + 6, nc, S.nguoi_ky.get("giam_doc", ""), B.k_chu_ky)
    # chi tiet doanh thu theo nhom
    ws = B.sheet("Chi tiet doanh thu", [10, 16, 12, 11, 50, 10, 18, 22])
    r = 1
    ws.gop(r, 1, r, 8, "CHI TIẾT DOANH THU THEO NHÓM NGÀNH NGHỀ (căn cứ lập 01/CNKD - phát sinh Có TK 511, 512, giảm trừ ghi âm, bỏ kết chuyển)", B.k_dam)
    r += 1
    r = B.tieu_de_cot(ws, r, [("Kỳ", 1, 1, 0), ("Nhóm ngành", 2, 2, 0), ("Số hiệu", 3, 3, 0), ("Ngày", 4, 4, 0), ("Diễn giải", 5, 5, 0), ("TK", 6, 6, 0), ("Doanh thu", 7, 7, 0), ("Ghi chú", 8, 8, 0)], None, 24)
    dong = dong_doanh_thu(S, cfg)
    for kq in ds_kq:
        k = kq["ky"]
        for x in dong:
            if x.nam != k[1] or x.thang not in set(k[3]):
                continue
            ws.o(r, 1, ("Q%d/%d" % (k[2], k[1])) if k[0] == "Q" else ("%02d/%d" % (k[2], k[1])), B.k_o_giua)
            ws.o(r, 2, x.nhom, B.k_o_giua)
            ws.o(r, 3, x.d.sh, B.k_o_giua)
            ws.o(r, 4, x.d.ngay, B.k_o_ngay)
            ws.o(r, 5, x.d.dg, B.k_o)
            ws.o(r, 6, S.sh(x.tk), B.k_o_giua)
            ws.o(r, 7, x.tien, B.k_o_so)
            ws.o(r, 8, "Không chịu thuế GTGT" if x.co == "K" else ("Thuế suất 0%" if x.co == "Z" else ("Giảm trừ / trả lại" if x.tien < 0 else "")), B.k_o)
            r += 1
    # can cu + canh bao
    ws = B.sheet("Can cu", [120])
    r = 1
    for chu in can_cu_chu(cfg) + [""] + ["! " + c for c in cb]:
        ws.o(r, 1, chu, B.k_dam if chu.isupper() else B.k_thuong)
        r += 1
    B.wb.luu(duong)
    return duong


def can_cu_chu(cfg):
    return ["CĂN CỨ LẬP TỜ KHAI 01/CNKD (phần mềm lập từ sổ - chỉ đọc; xem trước rồi mới đưa vào HTKK)",
            "Phương pháp: " + PP_TEN[cfg["pp"]] + ("" if cfg["chon"] else " (chưa chọn ở menu Dữ liệu - mặc định)"),
            "TT 50/2026/TT-BTC (13/5/2026) sửa TT 18/2026: mẫu 01/CNKD, 01/BK-STK (thông báo tài khoản ngân hàng kèm tờ khai đầu tiên của năm), 01/BK-HTK.",
            "NĐ 68/2026/NĐ-CP, NĐ 141/2026/NĐ-CP (29/4/2026, từ 01/01/2026): doanh thu năm đến 1 tỷ đồng không nộp thuế GTGT, TNCN (chỉ Thông báo doanh thu 01/TKN-CNKD "
            "trước 31/01 năm sau); trên 1 tỷ: khai theo quý từ quý có doanh thu luỹ kế vượt ngưỡng (hạn: ngày cuối tháng đầu quý sau); trên 50 tỷ: khai tháng (hạn ngày 20 tháng sau).",
            "Thuế GTGT [14] = ([11] - [12] - [13]) x tỷ lệ % theo nhóm ngành; thuế TNCN [17] = ([15] - [16]) x tỷ lệ %; [16] doanh thu được trừ tối đa 1 tỷ đồng/năm, "
            "trừ vào nhóm ngành có tỷ lệ cao nhất trước (có lợi nhất), phần chưa dùng chuyển kỳ sau.",
            "Tỷ lệ % (Phụ lục I TT 40/2021, HTKK 01_CNKD_HKD_TT50): 01 phân phối hàng hoá 1 / 0,5; 02 dịch vụ, xây dựng không bao thầu 5 / 2; 03 cho thuê tài sản 5 / 5; "
            "04 sản xuất, vận tải, dịch vụ gắn hàng hoá, xây dựng bao thầu 3 / 1,5; 05 nội dung số 5 / 5; 06 khác 2 / 1 (sửa trong tham_so_nam_rieng.txt: HKD_TL_GTGT_xx, HKD_TL_TNCN_xx).",
            "Nhóm ngành của từng dòng doanh thu theo ánh xạ tài khoản: mặc định 5111 -> 01, 5112 -> 04, 5113 -> 02, 5117 -> 03, 5118 -> 06; người dùng sửa ở menu Dữ liệu "
            "(K = không chịu thuế GTGT [12], Z = thuế suất 0 % [13]).",
            "Phương pháp thu nhập tính thuế: thuế TNCN = (doanh thu - chi phí được trừ) x 15 % (doanh thu năm đến 3 tỷ) / 17 % (đến 50 tỷ) / 20 % - Luật Thuế TNCN 109/2025; "
            "chi phí lấy theo phát sinh TK 6xx, 8xx (trừ 821) - kiểm tra chi phí được trừ trước khi nộp.",
            "Hàng hoá, dịch vụ thuộc diện giảm thuế GTGT (NQ 204/2025 - giảm 20 % mức tỷ lệ %): phần mềm chưa lập phụ lục PL 204 - nhập trên HTKK nếu có.",
            "Phần mềm KHÔNG ký, không nộp thay; XML chỉ chép vào HTKK khi bấm Đưa vào HTKK sau khi xem trước (GĐ164); tờ khai cùng kỳ đang có trong HTKK không bị ghi đè."]


# ============================================================ XML HTKK 01_CNKD_HKD_TT50
_DIA_DIEM = ("mst_diaDiemKD", "ma_diaDiemKD", "ten_diaDiemKD", ("diaChi_diaDiemKD", ("diaChi", "ma_xaPhuong", "ten_xaPhuong", "ma_tinh", "ten_tinh")))
_CT_DT = ("ct09_ma", "ct09_ten", "ct10", "ct11", "ct12", "ct13", "ct14_maTieuMuc", "ct14_tenTieuMuc", "ct14_soThue", "ct15", "ct16",
          "ct17_maTieuMuc", "ct17_tenTieuMuc", "ct17_soThue")
_TTDB_DONG = ("ct2_ma", "ct2_ten", "ct3", "ct4", "ct5", "ct6", "ct7_maTieuMuc", "ct7_tenTieuMuc", "ct7_soTien")
_TN_DONG = ("ct2_ma", "ct2_ten", "truSoChinh", "ct3_mst_diaDiemKD", "ct3_ma_diaDiemKD", "ct4_ten_diaDiemKD",
            ("diaChi_diaDiemKD", ("diaChi", "ma_xaPhuong", "ten_xaPhuong", "ma_tinh", "ten_tinh")), "ct5", "ct6", "ct7", "ct8", "ct9",
            "ct10_maTieuMuc", "ct10_tenTieuMuc")
_HOTRO_DONG = ("ct38_mst", "ct38_ma", "ct38_ten", "ct39", "ct40", "soTienChenhLech", "ct41_ma", "ct42_ma", "ct43_maDBHC", "ct43_tenDBHC",
               "ct44_maCQThu", "ct44_tenCQThu", "ct45_maCQThue", "ct45_tenCQThue", "ct46", "idKhoanNopTam")


def _tao(cha, spec, gia=None, E=None):
    """tao cac the con theo spec (chuoi = the la; (ten, spec con) = the nhom); gia: {ten la: gia tri}."""
    gia = gia or {}
    for x in spec:
        if isinstance(x, tuple):
            n = E(cha, x[0])
            _tao(n, x[1], gia, E)
        else:
            v = gia.get(x)
            E(cha, x, "" if v is None else v)


def _khuon_may():
    """mo ta to khai tren HTKK cai o may (maTKhai, pban, ten, mo ta) - khong co HTKK thi mac dinh theo HTKK 5.7.9."""
    try:
        import tool_htkk_unesco as X
        h = X.tim_htkk()
        if isinstance(h, dict) and h.get("goc"):
            km, _loi = X.khuon_may(h["goc"], MA_FILE)
            if km:
                return km
    except Exception:
        pass
    return None


def lap_xml_cnkd(S, cfg, kq, duong, cb):
    import bao_cao_nam as BCN
    dl = S.dl
    E = BCN._e
    km = _khuon_may()
    ma_tk, pban = MA_TKHAI, PBAN_XML
    ten_tk, mo_ta = TEN_TKHAI, "(Kèm theo Thông tư số 50/2026/TT-BTC ngày 05/3/2026 của Bộ trưởng Bộ Tài chính)"
    if km:
        ma_tk, pban = km.get("maTKhai") or ma_tk, km.get("pbanTKhaiXML") or pban
        ten_tk, mo_ta = km.get("tenTKhai") or ten_tk, km.get("moTaBMau") or mo_ta
        if pban != PBAN_XML:
            cb.append("HTKK trên máy có khuôn %s phiên bản %s (phần mềm lập theo %s) - kiểm tra kỹ trên HTKK sau khi đưa vào." % (MA_FILE, pban, PBAN_XML))
    k = kq["ky"]
    d1, d2 = tu_den(k)
    goc = ET.Element("{%s}HSoThueDTu" % BCN.NS)
    hs = E(goc, "HSoKhaiThue")
    hs.set("id", "ID_1")
    BCN._ttin_chung(dl, hs, ma_tk, ten_tk, mo_ta, pban, cb, "01/CNKD", dly=False)
    for n in hs.iter():
        t = BCN._ten(n)
        if t == "kieuKy":
            n.text = k[0]
        elif t == "kyKKhai":
            n.text = ("%d/%d" % (k[2], k[1])) if k[0] == "Q" else ("%02d/%d" % (k[2], k[1]))
        elif t == "kyKKhaiTuNgay":
            n.text = d1.strftime("%d/%m/%Y")
        elif t == "kyKKhaiDenNgay":
            n.text = d2.strftime("%d/%m/%Y")
    dn = S.dn
    mst = re.sub(r"[^0-9-]", "", str(dn.get("mst") or ""))
    if not re.fullmatch(r"\d{10}(-\d{3})?|\d{12}", mst or ""):
        cb.append("Chưa lập XML 01/CNKD %s: mã số thuế / số định danh (%s) không hợp lệ." % (ten_ky(k), mst))
        return None
    ct = E(hs, "CTieuTKhaiChinh")
    E(ct, "mst_cu", "")
    hd = E(ct, "Header")
    E(hd, "nopThueTNCNDoanhThu", "true" if cfg["pp"] != "TN" else "false")
    E(hd, "nopThueTNCNThunhapTinhThue", "true" if cfg["pp"] == "TN" else "false")
    E(hd, "hoatDongTMDT", "false")
    E(hd, "hoatDongKhac", "false")
    E(hd, "hoatDongLPS", "false")
    tc = E(hd, "ToChucNopThueThay")
    for t in ("ct6_ten", "ct6_1_ma", "ct6_2_so", "ct6_2_ngay"):
        E(tc, t, "")
    kt = E(ct, "KhaiThueGTGTTNCN")
    cd = E(kt, "KinhDoanhDiaDiemCoDinh")
    dd1 = E(cd, "DoanhThuThueGTGTTNCN")
    dd1.set("id", "ID_1")
    E(dd1, "stt", "1")
    E(dd1, "truSoChinh", "true")
    _tao(dd1, _DIA_DIEM, {"mst_diaDiemKD": mst, "ten_diaDiemKD": dn.get("ten") or "", "diaChi": dn.get("dia_chi") or "", "ten_tinh": dn.get("tinh") or ""}, E)
    for i, h in enumerate(kq["hang"]):
        n = E(dd1, "CTietDoanhThu")
        n.set("id", "ID_%d" % (i + 1))
        _tao(n, _CT_DT, {"ct09_ma": h["nhom"], "ct09_ten": h["ten"], "ct10": h["ct10"], "ct11": str(int(h["ct11"])), "ct12": str(int(h["ct12"])),
                         "ct13": str(int(h["ct13"])), "ct14_maTieuMuc": TIEU_MUC_GTGT[0], "ct14_tenTieuMuc": TIEU_MUC_GTGT[1], "ct14_soThue": str(int(h["ct14"])),
                         "ct15": str(int(h["ct15"])), "ct16": str(int(h["ct16"])), "ct17_maTieuMuc": TIEU_MUC_TNCN[0], "ct17_tenTieuMuc": TIEU_MUC_TNCN[1],
                         "ct17_soThue": str(int(h["ct17"]))}, E)
    if not kq["hang"]:
        n = E(dd1, "CTietDoanhThu")
        n.set("id", "ID_1")
        _tao(n, _CT_DT, {"ct14_maTieuMuc": TIEU_MUC_GTGT[0], "ct17_maTieuMuc": TIEU_MUC_TNCN[0], "ct11": "0", "ct12": "0", "ct13": "0",
                         "ct14_soThue": "0", "ct15": "0", "ct16": "0", "ct17_soThue": "0"}, E)
    for ten_khoi in ("KinhDoanhTMDT", "KinhDoanhLPS"):
        kh = E(kt, ten_khoi)
        d0 = E(kh, "DoanhThuThueGTGTTNCN")
        _tao(d0, _DIA_DIEM, None, E)
        n = E(d0, "CTietDoanhThu")
        n.set("id", "ID_1")
        _tao(n, _CT_DT, {"ct14_maTieuMuc": TIEU_MUC_GTGT[0], "ct17_maTieuMuc": TIEU_MUC_TNCN[0]}, E)
    t18 = E(kt, "TongCongCT18")
    for c in ("11", "12", "13", "14", "15", "16", "17"):
        E(t18, "tongCT" + c, str(int(kq["tong"]["ct" + c])))
    t19 = E(kt, "SoThueMienCT19")
    E(t19, "soThueDuocMienCT14", "0")
    E(t19, "soThueDuocMienCT17", "0")
    t20 = E(kt, "SoThueConPhaiNopCT20")
    E(t20, "soThueGTGT_ct14", str(int(kq["con"]["ct14"])))
    E(t20, "soThueTNCN_ct17", str(int(kq["con"]["ct17"])))
    # B. TTDB (khong co)
    tt = E(ct, "KKhaiThueTTDB")
    nd = E(tt, "NoiDungKhaiThueTTDB")
    nd.set("id", "ID_1")
    E(nd, "stt", "")
    E(nd, "truSoChinh", "")
    _tao(nd, _DIA_DIEM, None, E)
    hh = E(nd, "doanhThuHangHoaTTDB")
    hh.set("id", "ID_1")
    _tao(hh, _TTDB_DONG, None, E)
    t22 = E(tt, "TongCongCT22")
    E(t22, "tongCT5", "")
    E(t22, "tongCT7", "")
    E(tt, "soThueMienCT23", "")
    E(tt, "soThueConPhaiNopCT24", "")
    # C. tai nguyen / BVMT / phi BVMT (khong co)
    tn = E(ct, "KKhaiTaiNguyen")
    for khoi, dong, so_tien, so in (("ThueTaiNguyen", "CTietThueTaiNguyen", "ct10_soTien", ("26", "27", "28")),
                                   ("ThueBVMT", "CTietThueBVMT", "ct10_soThue", ("30", "31", "32")),
                                   ("PhiBVMT", "CTietPhiBVMT", "ct10_soThue", ("34", "35", "36"))):
        kh = E(tn, khoi)
        n = E(kh, dong)
        n.set("id", "ID_1")
        _tao(n, _TN_DONG + (so_tien,), None, E)
        E(kh, "tongCongCT" + so[0], "")
        E(kh, "soThueMienCT" + so[1], "")
        E(kh, "soThueConPhaiNopCT" + so[2], "")
    # D. ho tro thong tin nop thue
    ht = E(ct, "HoTroThongTinNopThue")
    tong47 = 0
    i = 0
    for tm, so in ((TIEU_MUC_GTGT, kq["con"]["ct14"]), (TIEU_MUC_TNCN, kq["con"]["ct17"])):
        if so <= 0:
            continue
        i += 1
        n = E(ht, "ChiTietThongTinNopTHue")
        n.set("id", "ID_%d" % i)
        _tao(n, _HOTRO_DONG, {"ct38_mst": mst, "ct38_ten": dn.get("ten") or "", "ct39": tm[1], "ct40": str(int(so)), "soTienChenhLech": "0",
                              "ct42_ma": tm[0], "ct46": kq["han"].strftime("%Y-%m-%d")}, E)
        tong47 += int(so)
    if i == 0:
        n = E(ht, "ChiTietThongTinNopTHue")
        n.set("id", "ID_1")
        _tao(n, _HOTRO_DONG, None, E)
    E(ht, "tongTienCT47", str(tong47))
    E(ct, "soTienTruKyTiep", str(int(kq["tru_tiep"])))
    pl = E(hs, "PLuc")
    if kq.get("bk_stk"):
        bk = E(pl, "PLuc_01_BK_STK")
        for j, r in enumerate(kq["bk_stk"]):
            n = E(bk, "CTietSTK")
            n.set("id", "ID_%d" % (j + 1))
            _tao(n, ("ct04_ten", "ct05_mst", "ct05_ma", "ct06", "ct07", "ct08_ma", "ct08_ten", "ct09_ma", "ct09_ten"),
                 {"ct04_ten": dn.get("ten") or "", "ct05_mst": mst, "ct06": r[0], "ct07": r[1], "ct08_ten": r[2], "ct09_ma": "00", "ct09_ten": "Khai lần đầu"}, E)
    BCN._ghi_xml(goc, duong)
    loi = kiem_xml_cnkd(duong, (km or {}).get("khung"))
    if loi:
        cb.append("XML 01/CNKD %s tự kiểm: %s" % (ten_ky(k), "; ".join(str(x) for x in loi[:6])))
    return duong


_SO_NGUYEN = re.compile(r"^(ct1[1-7]|ct14_soThue|ct17_soThue|tongCT\d+|soThue\w+|soTienTruKyTiep|tongTienCT47|ct40|soTienChenhLech)$")


def kiem_xml_cnkd(duong, khung=None):
    """tu kiem XML 01/CNKD: vung ten, ma to khai, ky, MST, cac o so cua phan GTGT / TNCN la so nguyen, thu tu the nhu khung HTKK
    (kiem_noi_bo cua tool_htkk_unesco doi moi ct* la so - khong hop to khai nay: ct09_ten, ct10 '(a)', ct46 ngay)."""
    import bao_cao_nam as BCN
    loi = []
    try:
        goc = ET.parse(duong).getroot()
    except Exception as e:
        return ["Không đọc được XML: %s" % e]
    if goc.tag != "{%s}HSoThueDTu" % BCN.NS:
        loi.append("thẻ gốc / vùng tên sai: %s" % goc.tag)
    ten = {}
    for n in goc.iter():
        t = BCN._ten(n)
        if t in ("maTKhai", "pbanTKhaiXML", "kieuKy", "kyKKhai", "ngayKy", "mst") and t not in ten:
            ten[t] = (n.text or "").strip()
    if not re.fullmatch(r"\d+", ten.get("maTKhai") or ""):
        loi.append("maTKhai = '%s'" % ten.get("maTKhai"))
    if not re.fullmatch(r"\d+\.\d+\.\d+", ten.get("pbanTKhaiXML") or ""):
        loi.append("pbanTKhaiXML = '%s'" % ten.get("pbanTKhaiXML"))
    if ten.get("kieuKy") not in ("Q", "M"):
        loi.append("kieuKy = '%s'" % ten.get("kieuKy"))
    if not re.fullmatch(r"\d{1,2}/\d{4}", ten.get("kyKKhai") or ""):
        loi.append("kyKKhai = '%s'" % ten.get("kyKKhai"))
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", ten.get("ngayKy") or ""):
        loi.append("ngayKy = '%s'" % ten.get("ngayKy"))
    if not re.fullmatch(r"(\d{10}(-\d{3})?)|(\d{12})", ten.get("mst") or ""):
        loi.append("mst sai dạng")
    ctn = None
    for n in goc.iter():
        if BCN._ten(n) == "CTieuTKhaiChinh":
            ctn = n
            break
    if ctn is None:
        return loi + ["không có CTieuTKhaiChinh"]
    kt = [c for c in ctn if BCN._ten(c) == "KhaiThueGTGTTNCN"]
    for khoi in (kt[0] if kt else []):
        if BCN._ten(khoi) in ("KinhDoanhTMDT", "KinhDoanhLPS"):
            continue                                    # khoi khong dung: de trong nhu khung HTKK
        for n in khoi.iter():
            t = BCN._ten(n)
            if not list(n) and _SO_NGUYEN.match(t) and not re.fullmatch(r"-?\d+", (n.text or "").strip()):
                loi.append("%s = '%s' (phải là số nguyên)" % (t, n.text))
            elif not list(n) and t in ("ct11", "ct12", "ct13", "ct16") and (n.text or "").strip().startswith("-"):
                loi.append("%s = %s âm (HTKK không nhận)" % (t, n.text))
    ht = [c for c in ctn if BCN._ten(c) == "HoTroThongTinNopThue"]
    for n in (ht[0].iter() if ht else []):
        t = BCN._ten(n)
        if t in ("ct40", "tongTienCT47") and (n.text or "").strip() and not re.fullmatch(r"-?\d+", (n.text or "").strip()):
            loi.append("%s = '%s' (phải là số nguyên)" % (t, n.text))
    if khung and os.path.isfile(khung):
        try:
            import tool_htkk_unesco as X
            kg = X._khung_ns(khung)
            a = [X._ten(c) for c in list(X._tim_nut(kg, "/HSoKhaiThue/CTieuTKhaiChinh"))]
            b = [BCN._ten(c) for c in list(ctn)]
            if a != b:
                loi.append("thứ tự thẻ chỉ tiêu khác khung HTKK (%s)" % os.path.basename(khung))
        except Exception:
            pass
    return loi


def bang_ke_stk(S, k, cb):
    """01/BK-STK kem to khai DAU TIEN cua nam (quy 1 / thang 1): tai khoan ngan hang khai bao trong phan mem (ss.tk_nh)."""
    if not (k[3][0] == 1):
        return []
    ra = []
    chu_tk = S.nguoi_ky.get("giam_doc") or S.dn.get("ten") or ""
    for r in (S.ss or {}).get("tk_nh") or []:
        try:
            so, ten_nh = str(r[1] or "").strip(), str(r[3] or r[2] or "").strip()
        except (IndexError, TypeError):
            continue
        if so:
            ra.append((so, chu_tk, ten_nh))
    if ra:
        cb.append("01/BK-STK kèm tờ khai đầu năm: %d tài khoản ngân hàng khai trong phần mềm (Sổ phụ ngân hàng) - chọn mã ngân hàng trên HTKK; "
                  "chủ tài khoản ghi theo người đại diện." % len(ra))
    else:
        cb.append("01/BK-STK (thông báo tài khoản ngân hàng kèm tờ khai đầu năm): phần mềm chưa có tài khoản ngân hàng khai báo - nhập trên HTKK nếu cần.")
    return ra


# ============================================================ driver
def lap(dl, ma, kieu, thumuc):
    ma = str(ma or "").strip().upper()
    if ma not in TEN_MAU:
        raise ValueError("Mẫu %s không thuộc phần hộ kinh doanh" % ma)
    S = so_lieu(dl)
    cfg = cau_hinh(S)
    kieu = str(kieu or "E").upper()
    cb = []
    da = getattr(S, "_hkd_da_bao", None)
    if da is None:
        da = S._hkd_da_bao = set()
        cb.append("Hộ kinh doanh - %s%s. Sổ / tờ khai của trường hợp này: %s. Phần mềm hạch toán theo tài khoản, sổ TT 152/2025 và 01/CNKD lập từ chứng từ (chỉ đọc)."
                  % (PP_TEN[cfg["pp"]], "" if cfg["chon"] else " (CHƯA CHỌN ở menu Dữ liệu - lấy mặc định)",
                     ", ".join(TEN_MAU[x].split(" - ", 1)[0] for x in PP_SO[cfg["pp"]])))
        if ma not in PP_SO[cfg["pp"]]:
            cb.append("%s không thuộc trường hợp đã chọn (%s) - vẫn lập để tham khảo." % (TEN_MAU[ma].split(" - ", 1)[0], cfg["pp"]))
        if cfg["sai"]:
            cb.append("Ánh xạ tài khoản -> nhóm ngành có mục không đọc được (bỏ qua): %s - đúng dạng là TK=nhóm (01-06), thêm K / Z nếu cần." % "; ".join(cfg["sai"][:5]))
        if S.dau_ky != 1:
            cb.append("Năm tài chính bắt đầu tháng %d: luỹ kế doanh thu theo năm dương lịch chỉ gồm các tháng có trong bộ sổ này - doanh thu được trừ [16] "
                      "và ngưỡng 1 tỷ cần đối chiếu với bộ sổ năm trước." % S.dau_ky)
    tep = []
    if ma == "SS_HKDS1A":
        B, cb2 = lap_s1a(S, cfg)
        tep.append(B.luu(thumuc))
        cb += cb2
    elif ma in ("SS_HKDS2A", "SS_HKDS2B"):
        B, cb2 = lap_s2(S, cfg, ma)
        tep.append(B.luu(thumuc))
        cb += cb2
    else:
        ds_ky, cb2 = cac_ky(S, cfg)
        cb += cb2
        if cfg["pp"] == "MIEN":
            cb.append("Hộ doanh thu năm đến 1 tỷ đồng không phải nộp tờ khai 01/CNKD (chỉ Thông báo doanh thu 01/TKN-CNKD trước 31/01 năm sau) - tờ khai lập để tham khảo.")
        dong = dong_doanh_thu(S, cfg)
        ds_kq = []
        nguong = tham_so("HKD_NGUONG_MIEN", S.den_ky, NGUONG_MIEN_MAC_DINH)
        for k in ds_ky:
            lk, co_lk = luy_ke_truoc(S, k[3][0], k[1])
            if not co_lk and k[3][0] > 1:
                cb.append("%s: chưa có số luỹ kế doanh thu các tháng trước kỳ (JSON không có doi_ung) - doanh thu được trừ [16] tính như kỳ đầu năm." % ten_ky(k))
            kq = tong_hop_ky(S, cfg, k, dong, lk)
            kq["bk_stk"] = bang_ke_stk(S, k, cb)
            ds_kq.append(kq)
            cb.extend(kq["canh_bao"])
            cb.append("01/CNKD %s: %d dòng doanh thu, %d nhóm ngành; [11] doanh thu %s, [14] thuế GTGT %s, [16] được trừ %s, [17] thuế TNCN %s; hạn nộp %s."
                      % (ten_ky(k), kq["so_dong"], len(kq["hang"]), dd(kq["tong"]["ct11"]), dd(kq["tong"]["ct14"]), dd(kq["tong"]["ct16"]),
                         dd(kq["tong"]["ct17"]), kq["han"].strftime("%d/%m/%Y")))
            if kq["lk_cuoi"] <= nguong and cfg["pp"] != "MIEN":
                cb.append("%s: luỹ kế doanh thu năm đến hết kỳ %s đồng chưa vượt %s đồng - hộ chưa phải khai, nộp thuế kỳ này (NĐ 141/2026); chỉ nộp khi đã vượt ngưỡng trong năm."
                          % (ten_ky(k), dd(kq["lk_cuoi"]), dd(nguong)))
            if any(h["ct12"] or h["ct13"] for h in kq["hang"]):
                cb.append("%s: có doanh thu không chịu thuế GTGT / thuế suất 0%% theo ánh xạ tài khoản (K / Z) - kiểm tra lại." % ten_ky(k))
            if tham_so("GTGT_GIAM_2PT", tu_den(k)[1], 0) and kq["tong"]["ct14"]:
                cb.append("%s: nếu có hàng hoá, dịch vụ được giảm thuế GTGT theo NQ 204/2025 (giảm 20%% tỷ lệ) - nhập phụ lục PL 204 trên HTKK, phần mềm chưa lập." % ten_ky(k))
        if not ds_kq:
            cb.append("Không có kỳ khai nào trọn trong khoảng đã chọn - chưa lập 01/CNKD.")
            return {"tep": [], "canh_bao": cb}
        if "X" in kieu:
            cb.append("Trên HTKK sau khi đưa vào: chọn Tỉnh / Xã của địa điểm kinh doanh, mã ngân hàng (01/BK-STK), chương / địa bàn / cơ quan thu "
                      "ở mục D (HTKK tự điền khi mở lại) - phần mềm không có danh mục mã của HTKK.")
        if "X" in kieu:
            for kq in ds_kq:
                k = kq["ky"]
                hau = ("Q%d_%d" % (k[2], k[1])) if k[0] == "Q" else ("T%02d_%d" % (k[2], k[1]))
                p = lap_xml_cnkd(S, cfg, kq, os.path.join(thumuc, "%s_%s.xml" % (MA_FILE, hau)), cb)
                if p:
                    tep.append(p)
        if "E" in kieu or "X" not in kieu:
            k0, k1 = ds_kq[0]["ky"], ds_kq[-1]["ky"]
            hau = ("Q%d" % k0[2] if k0[0] == "Q" else "T%02d" % k0[2]) + ("" if k0 == k1 else ("-Q%d" % k1[2] if k1[0] == "Q" else "-T%02d" % k1[2])) + "_%d" % k1[1]
            p = os.path.join(thumuc, "01_CNKD_%s.xlsx" % hau)
            lap_excel_cnkd(S, cfg, ds_kq, list(cb), p)
            tep.append(p)
    them = [x for x in S.cb if x not in cb and x not in da]
    da.update(them)
    return {"tep": tep, "canh_bao": them + cb}
