# -*- coding: utf-8 -*-
"""
sp_anh_excel.py - GD62: ANH / PDF sao ke ngan hang -> FILE EXCEL so phu de kiem tra truoc khi nhap.
Hoc tu "AI Accounting UNESCO R15" (Go): doc toan bo tai lieu bang thi giac AI theo JSON schema, HAI luot doc doc lap
(CHINH + KIEM_TRA_DOC_LAP) roi doi chieu tung dong; kiem chuoi so du, so du dau / cuoi, tong phat sinh, dong trung,
khoang trong STT; moi dong to mau XANH / VANG / DO NHAT / MOI. Co them duong OCR OFFLINE cua Windows (Windows.Media.Ocr
qua PowerShell) - KHONG gui anh ra ngoai; GD64: bo doc v2 (tieu de song ngu, nhieu tai khoan / thang trong mot PDF,
chuoi so du xac dinh chieu tien) - dong XANH khi so tien + so du khop chuoi, con lai VANG / DO NHAT.

Dung tu tool_so_phu_unesco.py (che do /sophu_excel) - file nay khong phu thuoc thu vien ngoai (Excel ghi bang zip + XML).
Nhat ky: che so tai khoan (chi 4 so cuoi). Khong luu khoa API, khong luu anh.
"""
import io
import os
import re
import sys
import json
import time
import base64
import zipfile
import unicodedata
import subprocess
import urllib.request
import urllib.error
from datetime import datetime, date, timedelta

_RUN_GOC = subprocess.run          # GD104: chay_ps_tien_do nhan biet kiem thu thay subprocess.run

PHIEN_BAN = "GD68"
MAU = {"XANH": "FFC6EFCE", "VANG": "FFFFEB9C", "DO_NHAT": "FFF4CCCC", "MOI": "FFF8CBAD"}
TEN_MAU = {"XANH": "XANH", "VANG": "VANG", "DO_NHAT": "DO NHAT", "MOI": "MOI"}
DUOI_ANH = (".jpg", ".jpeg", ".png", ".webp", ".tif", ".tiff", ".bmp")
SAI_SO = 1.0          # VND: lech <= 1 dong coi nhu bang

_log = None


def dat_nhat_ky(ham):
    """tool_so_phu_unesco truyen ham ghi nhat ky (da che so TK)."""
    global _log
    _log = ham


def ghi(msg):
    if _log:
        try:
            _log(msg)
            return
        except Exception:
            pass
    try:
        print(msg)
    except Exception:
        pass


# ---------------------------------------------------------------- chuoi / so / ngay
def bo_dau(s):
    s = str(s or "").replace("đ", "d").replace("Đ", "D")
    return "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")


def chuan(s):
    """Bo dau, VIET HOA, chi giu chu so va khoang trang don."""
    return " ".join(re.sub(r"[^A-Z0-9]+", " ", bo_dau(s).upper()).split())


def tien(v):
    """Chuoi tien doc tu anh -> float (None neu khong phai so).
       "1.234.567,89" -> 1234567.89 ; "1,234,567.89" -> 1234567.89 ; "1.234.567" -> 1234567 ; "(1.000)" / "-1.000" -> -1000 ;
       "", "-", "0.00" -> 0. Sua lan chu OCR: O/o -> 0. Loai chuoi giong so TK / so dien thoai (>= 7 so bat dau bang 0)."""
    if v is None:
        return None
    if isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip()
    if s in ("", "-", "–", "—", "."):
        return 0.0
    am = s.startswith("(") and s.endswith(")")
    s = s.strip("()").replace("O", "0").replace("o", "0")
    s = re.sub(r"(?i)\b(VND|VNĐ|USD|EUR|đ|d)\b", "", s).strip()
    s = s.replace(" ", "")
    if s.startswith("-") or s.startswith("−"):
        am = True
        s = s[1:]
    if not re.match(r"^[0-9.,]+$", s):
        return None
    if "," in s and "." in s:
        # dau nao dung sau la dau thap phan
        if s.rfind(",") > s.rfind("."):
            s = s.replace(".", "").replace(",", ".")
        else:
            s = s.replace(",", "")
    elif "," in s:
        p = s.split(",")
        if len(p) == 2 and len(p[1]) <= 2:
            s = p[0] + "." + p[1]          # 123,45 -> thap phan
        else:
            s = s.replace(",", "")
    elif s.count(".") > 1 or (s.count(".") == 1 and len(s.split(".")[1]) == 3):
        s = s.replace(".", "")            # 1.234.567 / 12.500 -> phan cach nghin
    try:
        x = float(s)
    except Exception:
        return None
    return -x if am else x


def ngay_iso(v):
    """-> 'yyyy-mm-dd' hoac ''. Nhan yyyy-mm-dd, dd/mm/yyyy, dd-mm-yy, dd.mm.yyyy, so serial Excel; sua O->0, I/l->1."""
    if v is None or v == "":
        return ""
    if isinstance(v, (datetime, date)):
        return v.strftime("%Y-%m-%d")
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        if 20000 < v < 80000:
            return (date(1899, 12, 30) + timedelta(days=int(v))).strftime("%Y-%m-%d")
        return ""
    s = str(v).strip().replace("O", "0").replace("o", "0").replace("I", "1").replace("l", "1").replace("|", "")
    s = s.replace(" ", "")
    m = re.match(r"^(\d{4})[/.\-](\d{1,2})[/.\-](\d{1,2})", s)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
    else:
        m = re.match(r"^(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{2,4})", s)
        if not m:
            return ""
        d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if y < 100:
            y += 2000
        if mo > 12 and d <= 12:
            d, mo = mo, d
    try:
        return date(y, mo, d).strftime("%Y-%m-%d")
    except Exception:
        return ""


def ngay_vn(iso):
    if not iso:
        return ""
    p = iso.split("-")
    return "%s/%s/%s" % (p[2], p[1], p[0]) if len(p) == 3 else iso


def bang(a, b, sai_so=SAI_SO):
    if a is None or b is None:
        return False
    return abs(float(a) - float(b)) <= sai_so


def fmt(v):
    try:
        return "{:,.0f}".format(float(v)).replace(",", ".")
    except Exception:
        return str(v)


# ---------------------------------------------------------------- mo hinh dong
COT_DONG = ("trang", "thu_tu", "stt", "ngay", "ngay_gt", "so_ct", "loai", "noi_dung", "doi_ung_ten", "doi_ung_stk",
            "doi_ung_nh", "tien_ra", "tien_vao", "phi", "thue", "so_du", "bang_chung")


def dong_moi(**kw):
    d = {"trang": 0, "thu_tu": 0, "stt": "", "ngay": "", "ngay_gt": "", "so_ct": "", "loai": "", "noi_dung": "",
         "doi_ung_ten": "", "doi_ung_stk": "", "doi_ung_nh": "", "tien_ra": 0.0, "tien_vao": 0.0, "phi": 0.0, "thue": 0.0,
         "so_du": None, "bang_chung": "", "trang_thai": "VANG", "ly_do": [], "tin_cay": 0}
    d.update(kw)
    return d


def dau_moi(**kw):
    h = {"ngan_hang": "", "so_tk": "", "loai_tien": "VND", "ky_tu": "", "ky_den": "", "so_du_dau": None, "tong_no": None,
         "tong_co": None, "so_du_cuoi": None, "so_trang": 0, "day_du": True, "ly_do_thieu": [], "canh_bao": [],
         "cach_doc": "", "tep": "", "muc": ""}
    h.update(kw)
    return h


def _them_ly_do(d, ly_do, trang_thai=None):
    if ly_do and ly_do not in d["ly_do"]:
        d["ly_do"].append(ly_do)
    if trang_thai:
        d["trang_thai"] = _nang(d["trang_thai"], trang_thai)


_THU_TU_TT = {"XANH": 0, "MOI": 1, "VANG": 2, "DO_NHAT": 3}


def _nang(cu, moi):
    """Trang thai chi xau di (XANH < MOI < VANG < DO_NHAT)."""
    return moi if _THU_TU_TT.get(moi, 0) > _THU_TU_TT.get(cu, 0) else cu


def _dong_tu_json(g, trang_goc=0):
    """Mot phan tu giao_dich (JSON cua AI) -> dong chuan. Tien chuoi -> so; ngay -> ISO."""
    d = dong_moi()
    d["trang"] = int(g.get("trang") or trang_goc or 0)
    d["thu_tu"] = int(g.get("thu_tu") or 0)
    d["stt"] = str(g.get("stt") or "").strip()[:20]
    d["ngay"] = ngay_iso(g.get("ngay_gd"))
    d["ngay_gt"] = ngay_iso(g.get("ngay_gt"))
    d["so_ct"] = str(g.get("so_ct") or "").strip()[:60]
    d["loai"] = str(g.get("loai_gd") or "").strip()[:60]
    d["noi_dung"] = " ".join(str(g.get("noi_dung") or "").split())[:2000]
    d["doi_ung_ten"] = str(g.get("doi_ung_ten") or "").strip()[:255]
    d["doi_ung_stk"] = re.sub(r"[^0-9A-Za-z]", "", str(g.get("doi_ung_stk") or ""))[:40]
    d["doi_ung_nh"] = str(g.get("doi_ung_nh") or "").strip()[:80]
    for k, kj in (("tien_ra", "tien_ra"), ("tien_vao", "tien_vao"), ("phi", "phi"), ("thue", "thue")):
        x = tien(g.get(kj))
        d[k] = abs(x) if x is not None else 0.0
    sd = tien(g.get("so_du"))
    d["so_du"] = sd if sd is not None and str(g.get("so_du") or "").strip() not in ("", "-") else None
    d["bang_chung"] = str(g.get("bang_chung") or "").strip()[:300]
    return d


# ---------------------------------------------------------------- AI (Claude) - 2 luot doc doc lap
PROMPT_AI = """Bạn là công cụ trích xuất SỔ PHỤ / SAO KÊ tài khoản ngân hàng cho kế toán Việt Nam. Đọc trực tiếp toàn bộ ảnh /
trang được gửi bằng thị giác tài liệu, kể cả trang xoay 90/180/270 độ, bảng nhiều trang và diễn giải xuống dòng.
QUY TẮC BẮT BUỘC:
- KHÔNG bịa, KHÔNG hoàn thiện chữ / số không nhìn thấy, KHÔNG sửa số tiền để cho cân. Ô mờ / bị che: để chuỗi rỗng và ghi vào canh_bao.
- Giữ đúng thứ tự vật lý: theo trang rồi từ trên xuống dưới. Mỗi giao dịch là MỘT phần tử; dòng in nối tiếp (chỉ có phần
  diễn giải, không có ngày và số tiền) thì GỘP vào giao dịch ngay phía trên, không tạo giao dịch mới.
- Tách ngân hàng phát hành sao kê khỏi ngân hàng đối tác; không lấy tên ngân hàng trong diễn giải làm ngân hàng phát hành.
- Không gộp phí / VAT vào giao dịch chính: tách tien_ra (ghi Nợ / rút ra), tien_vao (ghi Có / gửi vào), phi, thue, so_du.
- Số tiền là CHUỖI SỐ THUẦN, không dấu phân cách hàng nghìn (ví dụ "1234567" hoặc "1234567.89"). Ở Việt Nam dấu chấm
  thường là phân cách nghìn ("1.234.567" = 1234567), dấu phẩy là thập phân. Ô trống, "-" -> "0" (riêng so_du mờ -> "").
- Ngày theo dạng YYYY-MM-DD; "05/01/2026" là ngày 5 tháng 1 (ngày trước tháng). Không chắc thì để chuỗi rỗng.
- Số chứng từ / mã giao dịch (FT, HB, TT, REF...) ghi vào so_ct; không nhầm với số hoá đơn.
- Bỏ dòng tiêu đề, dòng tổng cộng, dòng số dư đầu / cuối kỳ khỏi giao_dich - nhưng ghi giá trị số dư đầu, tổng Nợ, tổng Có,
  số dư cuối, số tài khoản, kỳ sao kê vào các trường tương ứng nếu nhìn thấy (không thấy -> chuỗi rỗng).
- Nếu thiếu trang, bắt đầu giữa bảng, STT đứt quãng, trang trắng bất thường hoặc thiếu số dư đầu / cuối thì day_du=false
  và ghi lý do vào ly_do_thieu.
- bang_chung: đoạn chữ NHÌN THẤY trong ảnh làm căn cứ (ngắn), không suy luận.
- Chỉ trả kết quả qua công cụ ghi_so_phu đúng schema, không giải thích thêm."""

SCHEMA_AI = {
    "type": "object",
    "properties": {
        "ngan_hang": {"type": "string", "description": "Ma / ten ngan hang phat hanh sao ke (VCB, BIDV, CTG, TCB, MBB, ACB, VPB, STB, TPB, SHB, HDB, EIB, OCB, MSB, VIB, SEAB, ABB, NAB, AGRI...) hoac rong"},
        "so_tk": {"type": "string", "description": "So tai khoan cua sao ke (chuoi so) hoac rong"},
        "loai_tien": {"type": "string"},
        "ky_tu": {"type": "string", "description": "Ngay bat dau ky sao ke YYYY-MM-DD hoac rong"},
        "ky_den": {"type": "string"},
        "so_du_dau": {"type": "string"},
        "tong_no": {"type": "string"},
        "tong_co": {"type": "string"},
        "so_du_cuoi": {"type": "string"},
        "so_trang": {"type": "integer"},
        "day_du": {"type": "boolean"},
        "ly_do_thieu": {"type": "array", "items": {"type": "string"}},
        "canh_bao": {"type": "array", "items": {"type": "string"}},
        "giao_dich": {"type": "array", "items": {"type": "object", "properties": {
            "trang": {"type": "integer"}, "thu_tu": {"type": "integer"}, "stt": {"type": "string"},
            "ngay_gd": {"type": "string"}, "ngay_gt": {"type": "string"}, "gio": {"type": "string"},
            "so_ct": {"type": "string"}, "loai_gd": {"type": "string"}, "noi_dung": {"type": "string"},
            "doi_ung_ten": {"type": "string"}, "doi_ung_stk": {"type": "string"}, "doi_ung_nh": {"type": "string"},
            "tien_ra": {"type": "string"}, "tien_vao": {"type": "string"}, "phi": {"type": "string"}, "thue": {"type": "string"},
            "so_du": {"type": "string"}, "bang_chung": {"type": "string"}},
            "required": ["trang", "thu_tu", "ngay_gd", "so_ct", "noi_dung", "tien_ra", "tien_vao", "so_du"]}},
    },
    "required": ["ngan_hang", "so_tk", "so_du_dau", "so_du_cuoi", "day_du", "giao_dich"],
}


def _nen_anh(b):
    """Thu nho canh dai ve toi da 2400 px, JPEG 80 (du net chu so nho). Khong co Pillow thi giu nguyen."""
    try:
        from PIL import Image
    except Exception:
        return b, "image/png"
    try:
        im = Image.open(io.BytesIO(b))
        if im.mode not in ("RGB", "L"):
            im = im.convert("RGB")
        w, h = im.size
        if max(w, h) > 2400:
            tl = 2400.0 / max(w, h)
            im = im.resize((max(1, int(w * tl)), max(1, int(h * tl))), Image.LANCZOS)
        out = io.BytesIO()
        im.save(out, format="JPEG", quality=80)
        return out.getvalue(), "image/jpeg"
    except Exception as e:
        ghi("Khong nen duoc anh: %s" % e)
        return b, "image/png"


def _anh_tu_pdf(path, dpi=300, max_trang=60):
    """PDF -> danh sach PNG tung trang (pypdfium2). Khong co thu vien -> None (se gui PDF nguyen ban)."""
    try:
        import pypdfium2 as pdfium
    except Exception:
        return None
    pdf = pdfium.PdfDocument(path)
    n = min(len(pdf), max_trang)
    if len(pdf) > max_trang:
        ghi("PDF co %d trang, chi doc %d trang dau" % (len(pdf), max_trang))
    anh = []
    for i in range(n):
        bm = pdf[i].render(scale=dpi / 72.0)
        out = io.BytesIO()
        bm.to_pil().save(out, format="PNG")
        anh.append(out.getvalue())
    return anh


def _kieu_anh(path):
    p = path.lower()
    if p.endswith(".png"):
        return "image/png"
    if p.endswith(".webp"):
        return "image/webp"
    if p.endswith((".tif", ".tiff", ".bmp")):
        return "image/png"          # se duoc Pillow doi sang JPEG trong _nen_anh
    return "image/jpeg"


def noi_dung_tai_lieu(path, cai_dat):
    """-> danh sach lo; moi lo = (mo ta, [khoi noi dung Claude], so trang trong lo, trang dau).
       Anh: 1 lo 1 khoi. PDF: dung anh trang (pypdfium2) gom moi lo <= ocr_trang_moi_lan trang; khong co pypdfium2 -> gui PDF nguyen ban."""
    p = path.lower()
    moi_lan = int(cai_dat.get("ocr_trang_moi_lan") or 4)
    if moi_lan < 1 or moi_lan > 20:
        moi_lan = 4
    if p.endswith(".pdf"):
        dpi = int(cai_dat.get("ocr_dpi") or 300)
        if dpi < 120 or dpi > 600:
            dpi = 300
        anh = _anh_tu_pdf(path, dpi)
        if anh is None:
            raw = open(path, "rb").read()
            if len(raw) > 30 * 1024 * 1024:
                raise RuntimeError("PDF lon hon 30 MB va may chua co thu vien pypdfium2 de tach trang. Cai: pip install --user pypdfium2 pillow")
            ghi("Khong co pypdfium2 - gui PDF nguyen ban cho AI (1 lo)")
            return [("PDF nguyen ban", [{"type": "document", "source": {"type": "base64", "media_type": "application/pdf",
                                                                            "data": base64.b64encode(raw).decode("ascii")}}], 0, 1)]
    else:
        anh = [open(path, "rb").read()]
    lo = []
    for i in range(0, len(anh), moi_lan):
        khoi = []
        for j, b in enumerate(anh[i:i + moi_lan]):
            b2, kieu = _nen_anh(b)
            if kieu == "image/png" and not p.endswith(".pdf"):
                kieu = _kieu_anh(path)
            khoi.append({"type": "text", "text": "Trang %d:" % (i + j + 1)})
            khoi.append({"type": "image", "source": {"type": "base64", "media_type": kieu, "data": base64.b64encode(b2).decode("ascii")}})
        lo.append(("trang %d-%d" % (i + 1, i + len(khoi) // 2), khoi, len(khoi) // 2, i + 1))
    return lo


def goi_claude(key, model, khoi, van_ban, max_tokens=16000, thoi_gian=300):
    """Goi Claude voi tool ghi_so_phu (ep tra JSON dung schema). -> (dict, stop_reason). Loi 400/401/403 -> RuntimeError."""
    body = {"model": model, "max_tokens": max_tokens, "system": PROMPT_AI,
            "tools": [{"name": "ghi_so_phu", "description": "Ghi ket qua doc so phu ngan hang theo dung schema.", "input_schema": SCHEMA_AI}],
            "tool_choice": {"type": "tool", "name": "ghi_so_phu"},
            "messages": [{"role": "user", "content": list(khoi) + [{"type": "text", "text": van_ban}]}]}
    loi_cuoi = ""
    for lan in range(3):
        try:
            req = urllib.request.Request("https://api.anthropic.com/v1/messages", data=json.dumps(body).encode("utf-8"),
                                         headers={"Content-Type": "application/json", "x-api-key": key,
                                                  "anthropic-version": "2023-06-01"}, method="POST")
            with urllib.request.urlopen(req, timeout=thoi_gian) as r:
                kq = json.loads(r.read().decode("utf-8"))
            for c in kq.get("content") or []:
                if c.get("type") == "tool_use" and isinstance(c.get("input"), dict):
                    return c["input"], kq.get("stop_reason") or ""
            txt = "".join(c.get("text", "") for c in (kq.get("content") or []))
            m = re.search(r"\{.*\}", txt, re.S)
            if m:
                return json.loads(m.group(0)), kq.get("stop_reason") or ""
            loi_cuoi = "Claude khong tra JSON"
        except urllib.error.HTTPError as e:
            try:
                chi_tiet = e.read().decode("utf-8", "replace")[:300]
            except Exception:
                chi_tiet = ""
            loi_cuoi = "HTTP %s %s" % (e.code, chi_tiet)
            ghi("[AI] loi %s (lan %d)" % (loi_cuoi[:120], lan + 1))
            if e.code in (400, 401, 403, 404):
                raise RuntimeError("Claude API tu choi (%s). Kiem tra khoa API / ten model trong cai-dat.json." % loi_cuoi[:200])
        except Exception as e:
            loi_cuoi = str(e)
            ghi("[AI] loi %s (lan %d)" % (loi_cuoi[:120], lan + 1))
        time.sleep(3 + 5 * lan)
    raise RuntimeError("Khong goi duoc Claude API sau 3 lan: " + loi_cuoi[:200])


def _van_ban_luot(vai_tro, nh, muc, mo_ta, du_truoc, tong_trang, nhac=None):
    s = ("Tài liệu: %s (tổng %d trang). Ngân hàng gợi ý: %s. Mức đọc: %s.\nVai trò lượt đọc: %s.\n"
         % (mo_ta, tong_trang, nh or "tự nhận", muc, vai_tro))
    if du_truoc is not None:
        s += "Số dư cuối của phần trước: %s - CHỈ để tự kiểm, KHÔNG được sửa số đọc được cho khớp.\n" % fmt(du_truoc)
    if vai_tro == "KIEM_TRA_DOC_LAP":
        s += "Đây là lượt đọc ĐỘC LẬP thứ hai để đối chiếu: đọc lại từ ảnh, không dựa vào bất kỳ kết quả nào khác.\n"
    if nhac:
        s += "Lượt đọc trước có các chỗ chưa thống nhất, hãy nhìn lại THẬT KỸ từng chữ số của các dòng sau (không sửa cho khớp):\n"
        for x in nhac[:15]:
            s += "- " + x + "\n"
    s += "Hãy gọi công cụ ghi_so_phu với toàn bộ giao dịch của phần này."
    return s


def _doc_mot_luot(key, model, mo_ta, khoi, so_trang, vai_tro, nh, muc, du_truoc, tong_trang, max_tokens, nhac=None, sau=0):
    """Doc mot lo bang mot luot; ket qua cat (max_tokens) va lo co > 1 trang -> chia doi lo va doc lai."""
    kq, ly_do = goi_claude(key, model, khoi, _van_ban_luot(vai_tro, nh, muc, mo_ta, du_truoc, tong_trang, nhac), max_tokens)
    if ly_do == "max_tokens" and so_trang > 1 and sau < 3:
        ghi("[AI] %s %s: ket qua bi cat - chia doi lo" % (vai_tro, mo_ta))
        # khoi = [text "Trang n:", image] x so_trang
        nua = (so_trang + 1) // 2
        k1, k2 = khoi[:nua * 2], khoi[nua * 2:]
        a = _doc_mot_luot(key, model, mo_ta + "a", k1, nua, vai_tro, nh, muc, du_truoc, tong_trang, max_tokens, nhac, sau + 1)
        du = None
        for g in (a.get("giao_dich") or []):
            x = tien(g.get("so_du"))
            if x is not None and str(g.get("so_du") or "").strip():
                du = x
        b = _doc_mot_luot(key, model, mo_ta + "b", k2, so_trang - nua, vai_tro, nh, muc, du, tong_trang, max_tokens, nhac, sau + 1)
        for k in ("ngan_hang", "so_tk", "loai_tien", "ky_tu", "ky_den", "so_du_dau", "tong_no", "tong_co", "so_du_cuoi"):
            if not str(a.get(k) or "").strip():
                a[k] = b.get(k, "")
        a["giao_dich"] = (a.get("giao_dich") or []) + (b.get("giao_dich") or [])
        a["canh_bao"] = (a.get("canh_bao") or []) + (b.get("canh_bao") or [])
        a["ly_do_thieu"] = (a.get("ly_do_thieu") or []) + (b.get("ly_do_thieu") or [])
        a["day_du"] = bool(a.get("day_du", True)) and bool(b.get("day_du", True))
        return a
    if ly_do == "max_tokens":
        kq.setdefault("canh_bao", []).append("Ket qua doc %s bi cat vi qua dai - co the thieu dong cuoi" % mo_ta)
    return kq


def _khop_dong(a, b):
    """Dong luot chinh a khop dong luot kiem b? (so CT trung, hoac cung ngay + cung tien ra + cung tien vao)."""
    if a["so_ct"] and b["so_ct"] and a["so_ct"].upper() == b["so_ct"].upper():
        return True
    return a["ngay"] and a["ngay"] == b["ngay"] and bang(a["tien_ra"], b["tien_ra"]) and bang(a["tien_vao"], b["tien_vao"])


def doi_chieu_hai_luot(chinh, kiem):
    """Giu gia tri luot chinh; luot kiem chi XAC NHAN hoac BAO KHAC (khong ghi de). -> danh sach dong da gan trang thai.
       Dong chinh khong ai xac nhan -> VANG; dong kiem khong khop dong nao -> MOI (chen sau dong chinh gan nhat)."""
    ra, da_dung = [], [False] * len(kiem)
    vi_tri = {}
    for i, a in enumerate(chinh):
        khop = -1
        for j, b in enumerate(kiem):
            if not da_dung[j] and _khop_dong(a, b):
                khop = j
                break
        if khop < 0:
            _them_ly_do(a, "Lượt đọc 2 không thấy dòng này", "VANG")
        else:
            da_dung[khop] = True
            vi_tri[khop] = len(ra)
            b = kiem[khop]
            xung_dot = []
            if a["ngay"] != b["ngay"]:
                xung_dot.append("ngày %s / %s" % (ngay_vn(a["ngay"]), ngay_vn(b["ngay"])))
            for k, ten in (("tien_ra", "tiền ra"), ("tien_vao", "tiền vào"), ("phi", "phí"), ("thue", "thuế")):
                if not bang(a[k], b[k]):
                    xung_dot.append("%s %s / %s" % (ten, fmt(a[k]), fmt(b[k])))
            if (a["so_du"] is None) != (b["so_du"] is None) or (a["so_du"] is not None and not bang(a["so_du"], b["so_du"])):
                xung_dot.append("số dư %s / %s" % (fmt(a["so_du"]) if a["so_du"] is not None else "trống",
                                                    fmt(b["so_du"]) if b["so_du"] is not None else "trống"))
            if xung_dot:
                _them_ly_do(a, "Hai lượt đọc khác nhau: " + "; ".join(xung_dot), "VANG")
            else:
                a["trang_thai"] = "XANH"
                a["tin_cay"] = 100
                if not a["noi_dung"] and b["noi_dung"]:
                    a["noi_dung"] = b["noi_dung"]
        ra.append(a)
    # dong chi luot 2 thay -> MOI, chen sau dong chinh da khop gan nhat truoc no
    chen = []
    sau = -1
    for j, b in enumerate(kiem):
        if da_dung[j]:
            sau = vi_tri.get(j, sau)
            continue
        b["trang_thai"] = "MOI"
        _them_ly_do(b, "Chỉ lượt đọc 2 thấy dòng này - có thể lượt 1 bỏ sót, hoặc lượt 2 đọc thừa: đối chiếu sao kê gốc")
        chen.append((sau, b))
    for sau, b in reversed(chen):
        ra.insert(sau + 1, b)
    return ra


def kiem_dong_thieu(dong):
    """Thieu ngay / thieu tien / vua ra vua vao -> DO NHAT."""
    for d in dong:
        if not d["ngay"]:
            _them_ly_do(d, "Không đọc được ngày giao dịch", "DO_NHAT")
        if d["tien_ra"] == 0 and d["tien_vao"] == 0 and d["phi"] == 0 and d["thue"] == 0:
            _them_ly_do(d, "Không có số tiền ra / vào", "DO_NHAT")
        if d["tien_ra"] > 0 and d["tien_vao"] > 0:
            _them_ly_do(d, "Vừa có tiền ra vừa có tiền vào trên một dòng", "DO_NHAT")


def doc_bang_ai(path, nh_goi_y, cai_dat, muc=""):
    """Anh / PDF -> (dau, dong) bang Claude: luot CHINH + luot KIEM_TRA_DOC_LAP (muc CAO / PRO), doi chieu tung dong.
       cai_dat: dict cai-dat.json (anthropic_key, anthropic_model, anthropic_model_kiem, cho_phep_gui_anh, ocr_muc...)."""
    if not cai_dat.get("cho_phep_gui_anh"):
        raise RuntimeError("Muc 'Cho phep gui anh so phu cho AI' dang TAT nen khong doc bang AI duoc. Bat muc do (nut Gui anh cho AI) "
                           "hoac chon OCR Offline cua Windows.")
    key = cai_dat.get("anthropic_key", "")
    if not key:
        raise RuntimeError("Chua khai khoa Claude API (anthropic_key trong cai-dat.json / nut AI goi y cua tool hoa don).")
    model = cai_dat.get("anthropic_model") or "claude-sonnet-4-5"
    model_kiem = cai_dat.get("anthropic_model_kiem") or model
    muc = (muc or cai_dat.get("ocr_muc") or "CAO").upper()
    if muc not in ("NHANH", "CAO", "PRO"):
        muc = "CAO"
    max_tokens = int(cai_dat.get("ocr_max_tokens") or 16000)
    lo = noi_dung_tai_lieu(path, cai_dat)
    tong_trang = sum(x[2] for x in lo) or len(lo)
    ghi("[AI] %s: %d lo, %d trang, muc %s, model %s / %s" % (os.path.basename(path), len(lo), tong_trang, muc, model, model_kiem))
    dau = dau_moi(cach_doc="AI %s (%s)" % (muc, model), tep=os.path.basename(path), muc=muc, so_trang=tong_trang)
    tat_ca = []
    du_truoc = None
    for mo_ta, khoi, so_trang, trang_dau in lo:
        c = _doc_mot_luot(key, model, mo_ta, khoi, so_trang, "CHINH", nh_goi_y, muc, du_truoc, tong_trang, max_tokens)
        chinh = [_dong_tu_json(g, trang_dau) for g in (c.get("giao_dich") or [])]
        ghi("[AI] luot CHINH %s: %d dong" % (mo_ta, len(chinh)))
        _gop_dau(dau, c)
        if muc == "NHANH":
            for d in chinh:
                _them_ly_do(d, "Chỉ đọc 1 lượt (mức NHANH) - chưa có lượt đối chiếu", "VANG")
            dong = chinh
        else:
            k = _doc_mot_luot(key, model_kiem, mo_ta, khoi, so_trang, "KIEM_TRA_DOC_LAP", nh_goi_y, muc, du_truoc, tong_trang, max_tokens)
            kiem = [_dong_tu_json(g, trang_dau) for g in (k.get("giao_dich") or [])]
            ghi("[AI] luot KIEM %s: %d dong" % (mo_ta, len(kiem)))
            _gop_dau(dau, k, chi_bo_sung=True)
            dong = doi_chieu_hai_luot(chinh, kiem)
            if muc == "PRO":
                nhac = [("dòng %s %s: %s" % (ngay_vn(d["ngay"]), d["so_ct"], "; ".join(d["ly_do"])))
                        for d in dong if d["trang_thai"] in ("VANG", "MOI")]
                if nhac:
                    ghi("[AI] PRO: %d dong chua thong nhat -> luot 3 trong tai" % len(nhac))
                    t = _doc_mot_luot(key, model, mo_ta, khoi, so_trang, "TRONG_TAI", nh_goi_y, muc, du_truoc, tong_trang, max_tokens, nhac)
                    ba = [_dong_tu_json(g, trang_dau) for g in (t.get("giao_dich") or [])]
                    _trong_tai(dong, ba)
        dong = _bo_dong_tong_ai(dong, dau)          # GD325: AI doc ca dong "Tong gui vao / Total Credit" thanh giao dich
        for d in dong:
            if d["so_du"] is not None:
                du_truoc = d["so_du"]
        tat_ca.extend(dong)
    for i, d in enumerate(tat_ca):
        d["thu_tu"] = i + 1
    return dau, tat_ca


RX_TONG_AI = re.compile(r"^\s*(TONG\s+(GUI\s+VAO|RUT\s+RA|TIEN\s+(VAO|RA)|GHI\s+(NO|CO)|PHAT\s+SINH|SO\s+PHAT\s+SINH|CONG(?!\s*TY))|"
                        r"CONG\s+PHAT\s+SINH|TOTAL\b|SO\s+DU\s+(DAU|CUOI)|OPENING\s+BALANCE|CLOSING\s+BALANCE|ENDING\s+BALANCE)")


def _bo_dong_tong_ai(dong, dau):
    """GD325: dong tong / so du dau-cuoi ma AI doc nham thanh giao dich (khong so CT, noi dung 'Tong gui vao Total Credit',
       'Tong rut ra Total Debit', 'So du cuoi'...) -> bo khoi danh sach; so tien dua vao tong_co / tong_no cua dau sao ke."""
    giu = []
    for d in dong:
        nd = unicodedata.normalize("NFD", str(d.get("noi_dung") or "")).encode("ascii", "ignore").decode().upper()
        nd = re.sub(r"[^A-Z0-9 ]", " ", nd.replace("Đ", "D"))
        if not str(d.get("so_ct") or "").strip() and RX_TONG_AI.search(nd):
            v, r = d.get("tien_vao") or 0, d.get("tien_ra") or 0
            if v and dau.get("tong_co") is None and ("GUI VAO" in nd or "CREDIT" in nd or "TIEN VAO" in nd or "GHI CO" in nd):
                dau["tong_co"] = abs(v)
            if r and dau.get("tong_no") is None and ("RUT RA" in nd or "DEBIT" in nd or "TIEN RA" in nd or "GHI NO" in nd):
                dau["tong_no"] = abs(r)
            ghi("[AI] GD325: bo dong tong '%s' (%s / %s)" % (str(d.get("noi_dung"))[:40], v, r))
            continue
        giu.append(d)
    return giu


def _trong_tai(dong, ba):
    """Muc PRO: luot 3 dong y voi luot chinh o cac truong tien / ngay / so du -> dong VANG thanh XANH (da so 2/3)."""
    da_dung = [False] * len(ba)
    for d in dong:
        if d["trang_thai"] not in ("VANG", "MOI"):
            continue
        for j, b in enumerate(ba):
            if da_dung[j] or not _khop_dong(d, b):
                continue
            da_dung[j] = True
            if d["ngay"] == b["ngay"] and bang(d["phi"], b["phi"]) and bang(d["thue"], b["thue"]) and \
               ((d["so_du"] is None and b["so_du"] is None) or (d["so_du"] is not None and b["so_du"] is not None and bang(d["so_du"], b["so_du"]))):
                d["trang_thai"] = "XANH"
                d["tin_cay"] = 90
                d["ly_do"] = ["Lượt 3 (trọng tài) đồng ý với lượt chính - " + "; ".join(d["ly_do"])]
            break


def _gop_dau(dau, kq, chi_bo_sung=False):
    """Lay thong tin dau sao ke tu JSON (lo nao doc duoc truoc thi giu)."""
    for k in ("ngan_hang", "so_tk", "loai_tien", "ky_tu", "ky_den"):
        v = str(kq.get(k) or "").strip()
        if v and (not dau.get(k) or (k == "loai_tien" and dau[k] == "VND")):
            if k in ("ky_tu", "ky_den"):
                v = ngay_iso(v)
            if k == "so_tk":
                v = re.sub(r"\D", "", v)
            if v:
                dau[k] = v
    for k in ("so_du_dau", "tong_no", "tong_co", "so_du_cuoi"):
        s = str(kq.get(k) or "").strip()
        if s and dau.get(k) is None:
            x = tien(s)
            if x is not None:
                dau[k] = abs(x)
    if not chi_bo_sung:
        if kq.get("day_du") is False:
            dau["day_du"] = False
        for x in (kq.get("ly_do_thieu") or []):
            if x and x not in dau["ly_do_thieu"]:
                dau["ly_do_thieu"].append(str(x)[:300])
        for x in (kq.get("canh_bao") or []):
            if x and x not in dau["canh_bao"]:
                dau["canh_bao"].append("AI: " + str(x)[:300])


# ---------------------------------------------------------------- kiem tra tai lieu
def kiem_tra(dau, dong):
    """Chuoi so du, dong trung, khoang trong STT, doi chieu so du dau / cuoi va tong phat sinh. Ghi vao dong + dau['kiem']."""
    kt = {"so_du_kiem": 0, "so_du_lech": 0, "trung": 0, "stt_trong": 0, "doi_chieu": [], "trang_thai": "DA_KIEM_TRA"}
    kiem_dong_thieu(dong)
    # chuoi so du tren cac dong KHONG phai MOI (dong MOI chua chac co that - xet rieng ben duoi)
    truoc, truoc_i = None, -1
    if dau.get("so_du_dau") is not None:
        truoc = dau["so_du_dau"]
    # GD66: sao ke OCR nhieu ky (moi thang mot phan, co phan khong co cot so du): dau moi phan lay so du dau ky cua phan do;
    #   dong khong co so du van cong tien vao chuoi (truoc day bo qua -> dong dau thang sau bi bao lech oan)
    phan_ = [p for p in (dau.get("phan") or []) if p.get("trang_dau")]
    phan_cua = lambda d: next((k for k, p in enumerate(phan_) if p["trang_dau"] <= int(d.get("trang") or 0) <= p.get("trang_cuoi", p["trang_dau"])), None)
    pk_truoc = phan_cua(dong[0]) if (dong and phan_) else None
    for i, d in enumerate(dong):
        if phan_:
            pk = phan_cua(d)
            if pk is not None and pk != pk_truoc and phan_[pk].get("so_du_dau") is not None:
                truoc, truoc_i = phan_[pk]["so_du_dau"], -1
            pk_truoc = pk if pk is not None else pk_truoc
        if d["trang_thai"] == "MOI":
            continue
        if d["so_du"] is None:
            if truoc is not None and phan_:
                truoc += d["tien_vao"] - d["tien_ra"] - d["phi"] - d["thue"]
            continue
        if truoc is not None:
            mong = truoc + d["tien_vao"] - d["tien_ra"] - d["phi"] - d["thue"]
            kt["so_du_kiem"] += 1
            if not bang(mong, d["so_du"]):
                kt["so_du_lech"] += 1
                _them_ly_do(d, "Lệch số dư: đọc được %s, theo %s phải là %s" % (
                    fmt(d["so_du"]), ("số dư đầu kỳ" if truoc_i < 0 else "dòng %d" % (truoc_i + 1)), fmt(mong)), "DO_NHAT")
                if truoc_i >= 0 and dong[truoc_i]["trang_thai"] == "XANH":
                    _them_ly_do(dong[truoc_i], "Dòng %d ngay sau lệch số dư - kiểm lại số dư dòng này" % (i + 1), "VANG")
        truoc, truoc_i = d["so_du"], i
    # dong MOI: khop chuoi so du voi dong truoc / sau (khong MOI) -> nhieu kha nang luot 1 bo sot; khong khop -> luot 2 doc thua
    for i, d in enumerate(dong):
        if d["trang_thai"] != "MOI" or d["so_du"] is None:
            continue
        tr = next((dong[j]["so_du"] for j in range(i - 1, -1, -1) if dong[j]["trang_thai"] != "MOI" and dong[j]["so_du"] is not None),
                  dau.get("so_du_dau"))
        if tr is None:
            continue
        sau = next((dong[j] for j in range(i + 1, len(dong)) if dong[j]["trang_thai"] != "MOI" and dong[j]["so_du"] is not None), None)
        khop_truoc = bang(tr + d["tien_vao"] - d["tien_ra"] - d["phi"] - d["thue"], d["so_du"])
        khop_sau = True if sau is None else bang(d["so_du"] + sau["tien_vao"] - sau["tien_ra"] - sau["phi"] - sau["thue"], sau["so_du"])
        if khop_truoc and khop_sau:
            _them_ly_do(d, "Số dư dòng MỚI khớp chuỗi số dư với dòng trước và sau (có thể lượt 1 bỏ sót dòng này - kiểm rồi ghi OK)")
        else:
            _them_ly_do(d, "Số dư dòng MỚI KHÔNG khớp chuỗi số dư (có thể lượt 2 đọc thừa - kiểm rồi xoá dòng)")
    # dong trung
    da_thay = {}
    for i, d in enumerate(dong):
        k = "%s|%s|%.0f|%.0f|%s" % (d["ngay"], d["so_ct"].upper(), d["tien_ra"], d["tien_vao"], chuan(d["noi_dung"])[:80])
        if k in da_thay and (d["tien_ra"] or d["tien_vao"]):
            kt["trung"] += 1
            _them_ly_do(d, "Trùng với dòng %d (cùng ngày, số CT, số tiền, nội dung) - có thể đọc 2 lần" % (da_thay[k] + 1), "VANG")
        else:
            da_thay[k] = i
    # khoang trong STT
    stt = [(i, int(re.sub(r"\D", "", d["stt"]))) for i, d in enumerate(dong) if re.sub(r"\D", "", d["stt"])]
    if len(stt) >= 3 and len(stt) * 10 >= len(dong) * 8:
        for (i1, a), (i2, b) in zip(stt, stt[1:]):
            if b > a + 1 and b - a - 1 == i2 - i1 - 1:
                continue                                # GD66: cac dong o giua khong doc duoc STT - du so dong, khong thieu
            if b > a + 1:
                d1, d2 = dong[i1], dong[i2]
                if i2 == i1 + 1 and d2["trang_thai"] == "XANH" and d1["so_du"] is not None and d2["so_du"] is not None and \
                        bang(d1["so_du"] + d2["tien_vao"] - d2["tien_ra"] - d2["phi"] - d2["thue"], d2["so_du"]):
                    # GD66: chuoi so du lien mach qua cho hong STT -> OCR doc sai STT, khong thieu dong
                    _them_ly_do(d2, "STT đọc %s sau %s nhưng chuỗi số dư liền mạch - không thiếu dòng (OCR đọc sai STT)" % (b, a))
                    continue
                kt["stt_trong"] += b - a - 1
                _them_ly_do(dong[i2], "Khoảng trống STT %d-%d trước dòng này - có thể thiếu dòng / thiếu trang" % (a + 1, b - 1), "VANG")
    # doi chieu tong
    chinh = [d for d in dong if d["trang_thai"] != "MOI"]
    moi = [d for d in dong if d["trang_thai"] == "MOI"]
    s_ra = sum(d["tien_ra"] + d["phi"] + d["thue"] for d in chinh)
    s_vao = sum(d["tien_vao"] for d in chinh)
    m_ra = sum(d["tien_ra"] + d["phi"] + d["thue"] for d in moi)
    m_vao = sum(d["tien_vao"] for d in moi)
    dc = kt["doi_chieu"]

    def _dc(ten, gia_tri, so_sanh, them=0.0):
        x = {"chi_tieu": ten, "gia_tri": gia_tri, "so_sanh": so_sanh, "khop": None if so_sanh is None else bang(gia_tri, so_sanh)}
        if x["khop"] is False and moi and bang(gia_tri + them, so_sanh):
            x["khop"] = True
            x["chi_tieu"] = ten + " (khớp khi tính cả %d dòng MỚI)" % len(moi)
            x["gia_tri"] = gia_tri + them
        dc.append(x)

    _dc("Tổng tiền ra + phí + thuế (các dòng)", s_ra, dau.get("tong_no"), m_ra)
    _dc("Tổng tiền vào (các dòng)", s_vao, dau.get("tong_co"), m_vao)
    if dau.get("so_du_dau") is not None and dau.get("so_du_cuoi") is not None:
        _dc("Số dư đầu + tiền vào - tiền ra (- phí, thuế)", dau["so_du_dau"] + s_vao - s_ra, dau["so_du_cuoi"], m_vao - m_ra)
    cuoi = [d for d in chinh if d["so_du"] is not None]
    if cuoi and dau.get("so_du_cuoi") is not None:
        dc.append({"chi_tieu": "Số dư dòng cuối", "gia_tri": cuoi[-1]["so_du"], "so_sanh": dau["so_du_cuoi"],
                   "khop": bang(cuoi[-1]["so_du"], dau["so_du_cuoi"])})
    for x in dc:
        if x["khop"] is False:
            dau["canh_bao"].append("%s = %s khác số trên sao kê %s" % (x["chi_tieu"], fmt(x["gia_tri"]), fmt(x["so_sanh"])))
    if not dau.get("day_du", True):
        dau["canh_bao"].append("AI xác định tài liệu KHÔNG đầy đủ: " + "; ".join(dau.get("ly_do_thieu") or []))
    if not dong:
        dau["canh_bao"].append("Không tái tạo được dòng giao dịch nào")
    if any(d["trang_thai"] != "XANH" for d in dong) or any(x["khop"] is False for x in dc) or not dau.get("day_du", True) or not dong:
        kt["trang_thai"] = "CAN_XEM_LAI"
    dau["kiem"] = kt
    return kt


def dem_mau(dong):
    n = {"XANH": 0, "VANG": 0, "DO_NHAT": 0, "MOI": 0}
    for d in dong:
        n[d["trang_thai"]] = n.get(d["trang_thai"], 0) + 1
    return n


# ---------------------------------------------------------------- PDF co chu / bang da doc -> dong chuan
def tu_dong_so_phu(info, dong_tool, cach_doc="PDF có chữ (đọc trực tiếp, không OCR)"):
    """Dong tu doc_so_phu() cua tool (dict ngay_gd / so_ct_nh / noi_dung / tien_vao / tien_ra / so_du / doi_ung_*) -> (dau, dong).
       Moi dong XANH (chu that trong PDF); chuoi so du lech -> DO NHAT o kiem_tra()."""
    dau = dau_moi(ngan_hang=info.get("ngan_hang", ""), so_tk=info.get("so_tk", ""), cach_doc=cach_doc, tep=info.get("tep", ""))
    ra = []
    for i, x in enumerate(dong_tool):
        d = dong_moi(thu_tu=i + 1, ngay=x.get("ngay_gd", ""), so_ct=str(x.get("so_ct_nh") or ""), noi_dung=x.get("noi_dung", ""),
                     doi_ung_ten=x.get("doi_ung_ten", ""), doi_ung_stk=x.get("doi_ung_stk", ""),
                     tien_ra=float(x.get("tien_ra") or 0), tien_vao=float(x.get("tien_vao") or 0),
                     so_du=(None if x.get("so_du") is None else float(x["so_du"])), trang_thai="XANH", tin_cay=100,
                     trang=int(x.get("trang") or 0))
        ra.append(d)
    return dau, ra


# ---------------------------------------------------------------- OCR OFFLINE (Windows.Media.Ocr qua PowerShell)
PS1_OFFLINE = r'''param(
    [Parameter(Mandatory = $true)][string]$InputPath,
    [Parameter(Mandatory = $true)][string]$OutputJson,
    [string]$Language = "vi-VN",
    [int]$PdfWidth = 2400,
    [switch]$TryAllRotations = $true,
    [int]$ThemVung = 1,
    [string]$XuatAnhDir = "",
    [int]$LamSach = 1,
    [string]$XoayAnh = ""
)
# UNESCO GD62 - OCR offline bang Windows.Media.Ocr (khong gui du lieu ra ngoai). Hoc tu R15 Invoke-WindowsOfflineOcr.ps1.
$ErrorActionPreference = "Stop"
function Write-Failure([string]$Message) {
    $obj = [ordered]@{ engine = "WINDOWS_MEDIA_OCR_UNESCO"; success = $false; error = $Message; pages = @() }
    [System.IO.File]::WriteAllText($OutputJson, ($obj | ConvertTo-Json -Depth 12), (New-Object System.Text.UTF8Encoding($false)))
}
function Get-DeepMessage($ex) {
    $parts = @(); $cur = $ex; $n = 0
    while ($null -ne $cur -and $n -lt 12) {
        if ($cur.Message -and ($parts -notcontains $cur.Message)) { $parts += $cur.Message }
        $cur = $cur.InnerException; $n++
    }
    return ($parts -join " | ")
}
try {
    Add-Type -AssemblyName System.Runtime.WindowsRuntime
    [Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime] | Out-Null
    [Windows.Storage.FileAccessMode, Windows.Storage, ContentType = WindowsRuntime] | Out-Null
    [Windows.Storage.Streams.IRandomAccessStream, Windows.Storage.Streams, ContentType = WindowsRuntime] | Out-Null
    [Windows.Storage.Streams.InMemoryRandomAccessStream, Windows.Storage.Streams, ContentType = WindowsRuntime] | Out-Null
    [Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics.Imaging, ContentType = WindowsRuntime] | Out-Null
    [Windows.Graphics.Imaging.SoftwareBitmap, Windows.Graphics.Imaging, ContentType = WindowsRuntime] | Out-Null
    [Windows.Graphics.Imaging.BitmapTransform, Windows.Graphics.Imaging, ContentType = WindowsRuntime] | Out-Null
    [Windows.Graphics.Imaging.BitmapRotation, Windows.Graphics.Imaging, ContentType = WindowsRuntime] | Out-Null
    [Windows.Graphics.Imaging.BitmapPixelFormat, Windows.Graphics.Imaging, ContentType = WindowsRuntime] | Out-Null
    [Windows.Graphics.Imaging.BitmapAlphaMode, Windows.Graphics.Imaging, ContentType = WindowsRuntime] | Out-Null
    [Windows.Graphics.Imaging.ExifOrientationMode, Windows.Graphics.Imaging, ContentType = WindowsRuntime] | Out-Null
    [Windows.Graphics.Imaging.ColorManagementMode, Windows.Graphics.Imaging, ContentType = WindowsRuntime] | Out-Null
    [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime] | Out-Null
    [Windows.Media.Ocr.OcrResult, Windows.Foundation, ContentType = WindowsRuntime] | Out-Null
    [Windows.Globalization.Language, Windows.Globalization, ContentType = WindowsRuntime] | Out-Null
    [Windows.Data.Pdf.PdfDocument, Windows.Data.Pdf, ContentType = WindowsRuntime] | Out-Null
    [Windows.Data.Pdf.PdfPageRenderOptions, Windows.Data.Pdf, ContentType = WindowsRuntime] | Out-Null
    [Windows.Graphics.Imaging.BitmapBounds, Windows.Graphics.Imaging, ContentType = WindowsRuntime] | Out-Null
    [Windows.Graphics.Imaging.BitmapInterpolationMode, Windows.Graphics.Imaging, ContentType = WindowsRuntime] | Out-Null

    $asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
        $_.Name -eq 'AsTask' -and $_.IsGenericMethodDefinition -and $_.GetParameters().Count -eq 1 -and
        $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' } | Select-Object -First 1)
    $asTaskAction = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
        $_.Name -eq 'AsTask' -and -not $_.IsGenericMethodDefinition -and $_.GetParameters().Count -eq 1 -and
        $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncAction' } | Select-Object -First 1)
    if ($null -eq $asTaskGeneric -or $null -eq $asTaskAction) { throw "Khong tim thay bo chuyen doi WinRT async cua Windows PowerShell." }
    function Await-Operation($Operation, [Type]$ResultType) {
        try { $task = $asTaskGeneric.MakeGenericMethod($ResultType).Invoke($null, @($Operation)); return $task.GetAwaiter().GetResult() }
        catch { throw (Get-DeepMessage $_.Exception) }
    }
    function Await-Action($Action) {
        try { $task = $asTaskAction.Invoke($null, @($Action)); [void]$task.GetAwaiter().GetResult() }
        catch { throw (Get-DeepMessage $_.Exception) }
    }
    # GD66: -XuatAnhDir: chi ve tung trang PDF (hoac anh) ra PNG cho Tesseract OCR, khong OCR; -LamSach 1: xam max(R,G,B)
    #   (con dau do / xanh nhat di) + xoa duong ke bang (C# UnescoLamSach)
$CS_LAM_SACH = @'
using System;
// <XU>
using System.Drawing;
using System.Drawing.Imaging;
// </XU>
using System.Runtime.InteropServices;

public static class UnescoLamSach
{
    // UNESCO GD66: lam sach anh trang sao ke truoc Tesseract - xam = max(R,G,B) (con dau / chu mau nhat di),
    // xoa duong ke bang (doc / ngang dai, manh). Tra ve so diem da xoa.
    // <XU>
    public static int Xu(string path)
    {
        int W, H;
        byte[] g;
        using (Bitmap b0 = new Bitmap(path))
        {
            W = b0.Width;
            H = b0.Height;
            Rectangle rc = new Rectangle(0, 0, W, H);
            BitmapData bd = b0.LockBits(rc, ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
            int st = bd.Stride;
            byte[] buf = new byte[st * H];
            Marshal.Copy(bd.Scan0, buf, 0, buf.Length);
            b0.UnlockBits(bd);
            g = XamTuBgra(buf, W, H, st);
        }
        int n = XoaKe(g, W, H);
        using (Bitmap b1 = new Bitmap(W, H, PixelFormat.Format24bppRgb))
        {
            Rectangle rc = new Rectangle(0, 0, W, H);
            BitmapData bd = b1.LockBits(rc, ImageLockMode.WriteOnly, PixelFormat.Format24bppRgb);
            int st = bd.Stride;
            byte[] buf = new byte[st * H];
            for (int y = 0; y < H; y++)
            {
                for (int x = 0; x < W; x++)
                {
                    byte v = g[y * W + x];
                    int o = y * st + x * 3;
                    buf[o] = v;
                    buf[o + 1] = v;
                    buf[o + 2] = v;
                }
            }
            Marshal.Copy(buf, 0, bd.Scan0, buf.Length);
            b1.UnlockBits(bd);
            b1.Save(path, ImageFormat.Png);
        }
        return n;
    }
    // </XU>

    public static byte[] XamTuBgra(byte[] buf, int W, int H, int st)
    {
        byte[] g = new byte[W * H];
        for (int y = 0; y < H; y++)
        {
            for (int x = 0; x < W; x++)
            {
                int o = y * st + x * 4;
                int v = Math.Max((int)buf[o], Math.Max((int)buf[o + 1], (int)buf[o + 2]));
                int al = buf[o + 3];
                v = 255 - (al * (255 - v)) / 255;
                g[y * W + x] = (byte)v;
            }
        }
        return g;
    }

    public static int XoaKe(byte[] g, int W, int H)
    {
        int Lv = Math.Max(25, (int)(0.015 * W));
        int Lh = Math.Max(60, (int)(0.05 * W));
        int Wm = Math.Max(6, (int)(0.004 * W));
        const int r = 2;
        const int TOI = 170;
        const int NHAT = 235;
        bool[] m = new bool[W * H];
        for (int x = 0; x < W; x++)
        {
            int y = 0;
            while (y < H)
            {
                if (g[y * W + x] >= TOI) { y++; continue; }
                int a = y;
                while (y < H && g[y * W + x] < TOI) y++;
                int b = y;
                if (b - a < Lv) continue;
                int mong = 0;
                if (RongNgang(g, W, a + (b - a) / 4, x, TOI) <= Wm) mong++;
                if (RongNgang(g, W, (a + b) / 2, x, TOI) <= Wm) mong++;
                if (RongNgang(g, W, a + 3 * (b - a) / 4, x, TOI) <= Wm) mong++;
                if (mong < 2) continue;
                int y0 = Math.Max(0, a - r), y1 = Math.Min(H, b + r), x0 = Math.Max(0, x - r), x1 = Math.Min(W, x + r + 1);
                for (int yy = y0; yy < y1; yy++)
                    for (int xx = x0; xx < x1; xx++)
                        if (g[yy * W + xx] < NHAT) m[yy * W + xx] = true;
            }
        }
        for (int y = 0; y < H; y++)
        {
            int x = 0;
            while (x < W)
            {
                if (g[y * W + x] >= TOI) { x++; continue; }
                int a = x;
                while (x < W && g[y * W + x] < TOI) x++;
                int b = x;
                if (b - a < Lh) continue;
                int mong = 0;
                if (RongDoc(g, W, H, a + (b - a) / 4, y, TOI) <= Wm) mong++;
                if (RongDoc(g, W, H, (a + b) / 2, y, TOI) <= Wm) mong++;
                if (RongDoc(g, W, H, a + 3 * (b - a) / 4, y, TOI) <= Wm) mong++;
                if (mong < 2) continue;
                int y0 = Math.Max(0, y - r), y1 = Math.Min(H, y + r + 1), x0 = Math.Max(0, a - r), x1 = Math.Min(W, b + r);
                for (int yy = y0; yy < y1; yy++)
                    for (int xx = x0; xx < x1; xx++)
                        if (g[yy * W + xx] < NHAT) m[yy * W + xx] = true;
            }
        }
        int n = 0;
        for (int i = 0; i < m.Length; i++)
        {
            if (m[i]) { g[i] = 255; n++; }
        }
        return n;
    }

    static int RongNgang(byte[] g, int W, int y, int x, int toi)
    {
        if (g[y * W + x] >= toi) return 0;
        int a = x, b = x;
        while (a > 0 && g[y * W + a - 1] < toi) a--;
        while (b + 1 < W && g[y * W + b + 1] < toi) b++;
        return b - a + 1;
    }

    static int RongDoc(byte[] g, int W, int H, int x, int y, int toi)
    {
        if (g[y * W + x] >= toi) return 0;
        int a = y, b = y;
        while (a > 0 && g[(a - 1) * W + x] < toi) a--;
        while (b + 1 < H && g[(b + 1) * W + x] < toi) b++;
        return b - a + 1;
    }
}
'@
    if ($XoayAnh) {
        # GD66: -XoayAnh "tep*goc|tep*goc": xoay anh trang (scan nguoc / nam ngang) de Tesseract doc lai
        Add-Type -AssemblyName System.Drawing
        $kq1 = New-Object System.Collections.ArrayList
        foreach ($muc in $XoayAnh.Split("|")) {
            $pp = $muc.Split("*")
            if ($pp.Length -lt 2) { continue }
            $src1 = $pp[0]
            $goc1 = [int]$pp[1]
            $dst1 = $src1.Substring(0, $src1.Length - 4) + "_x" + $goc1 + ".png"
            $bm1 = [System.Drawing.Image]::FromFile($src1)
            try {
                if ($goc1 -eq 180) { $bm1.RotateFlip([System.Drawing.RotateFlipType]::Rotate180FlipNone) }
                elseif ($goc1 -eq 90) { $bm1.RotateFlip([System.Drawing.RotateFlipType]::Rotate90FlipNone) }
                else { $bm1.RotateFlip([System.Drawing.RotateFlipType]::Rotate270FlipNone) }
                $bm1.Save($dst1, [System.Drawing.Imaging.ImageFormat]::Png)
            } finally { $bm1.Dispose() }
            [void]$kq1.Add([ordered]@{ src = $src1; goc = $goc1; file = $dst1 })
        }
        $obj1 = [ordered]@{ engine = "XOAY_UNESCO"; success = $true; pages = @($kq1) }
        [System.IO.File]::WriteAllText($OutputJson, ($obj1 | ConvertTo-Json -Depth 6), (New-Object System.Text.UTF8Encoding($false)))
        exit 0
    }
    if ($XuatAnhDir) {
        [void][System.IO.Directory]::CreateDirectory($XuatAnhDir)
        $rs0 = [System.IO.Path]::GetFullPath($InputPath)
        $ds0 = New-Object System.Collections.ArrayList
        $loiLS = ""
        if ($LamSach -gt 0) {
            try {
                Add-Type -AssemblyName System.Drawing
                Add-Type -TypeDefinition $CS_LAM_SACH -ReferencedAssemblies System.Drawing
            } catch { $LamSach = 0; $loiLS = Get-DeepMessage $_.Exception }
        }
        if ([System.IO.Path]::GetExtension($rs0).ToLower() -ne ".pdf") {
            Add-Type -AssemblyName System.Drawing
            $tep0 = Join-Path $XuatAnhDir "trang_001.png"
            $bm0 = [System.Drawing.Image]::FromFile($rs0)
            try { $bm0.Save($tep0, [System.Drawing.Imaging.ImageFormat]::Png) } finally { $bm0.Dispose() }
            $xoa0 = -1
            $goc0 = ""
            if ($LamSach -gt 0) {
                try { $goc0 = $tep0.Substring(0, $tep0.Length - 4) + "_goc.png"; [System.IO.File]::Copy($tep0, $goc0, $true) } catch { $goc0 = "" }
                try { $xoa0 = [UnescoLamSach]::Xu($tep0) } catch { $loiLS = Get-DeepMessage $_.Exception }
            }
            [void]$ds0.Add([ordered]@{ page_number = 1; file = $tep0; goc = $goc0; lam_sach = $xoa0 })
            $obj0 = [ordered]@{ engine = "PDF_PNG_UNESCO"; success = $true; lam_sach = $LamSach; loi_lam_sach = $loiLS; pages = @($ds0) }
            [System.IO.File]::WriteAllText($OutputJson, ($obj0 | ConvertTo-Json -Depth 6), (New-Object System.Text.UTF8Encoding($false)))
            exit 0
        }
        $sf0 = Await-Operation ([Windows.Storage.StorageFile]::GetFileFromPathAsync($rs0)) ([Windows.Storage.StorageFile])
        $pdf0 = Await-Operation ([Windows.Data.Pdf.PdfDocument]::LoadFromFileAsync($sf0)) ([Windows.Data.Pdf.PdfDocument])
        for ($i = 0; $i -lt [int]$pdf0.PageCount; $i++) {
            $pg0 = $pdf0.GetPage([uint32]$i)
            $st0 = New-Object Windows.Storage.Streams.InMemoryRandomAccessStream
            $o0 = New-Object Windows.Data.Pdf.PdfPageRenderOptions
            if ($PdfWidth -gt 0) { $o0.DestinationWidth = [uint32]$PdfWidth }
            Await-Action ($pg0.RenderToStreamAsync($st0, $o0))
            $st0.Seek(0)
            $tep0 = Join-Path $XuatAnhDir ("trang_{0:D3}.png" -f ($i + 1))
            [Console]::Out.WriteLine(("UNESCO_VE {0}/{1}" -f ($i + 1), [int]$pdf0.PageCount)); [Console]::Out.Flush()
            $ns0 = [System.IO.WindowsRuntimeStreamExtensions]::AsStreamForRead($st0)
            $fs0 = [System.IO.File]::Create($tep0)
            try { $ns0.CopyTo($fs0) } finally { $fs0.Dispose() }
            $xoa0 = -1
            $goc0 = ""
            if ($LamSach -gt 0) {
                try { $goc0 = $tep0.Substring(0, $tep0.Length - 4) + "_goc.png"; [System.IO.File]::Copy($tep0, $goc0, $true) } catch { $goc0 = "" }
                try { $xoa0 = [UnescoLamSach]::Xu($tep0) } catch { $loiLS = Get-DeepMessage $_.Exception }
            }
            [void]$ds0.Add([ordered]@{ page_number = $i + 1; file = $tep0; goc = $goc0; lam_sach = $xoa0 })
            try { $st0.Dispose() } catch {}; try { $pg0.Dispose() } catch {}
        }
        $obj0 = [ordered]@{ engine = "PDF_PNG_UNESCO"; success = $true; lam_sach = $LamSach; loi_lam_sach = $loiLS; pages = @($ds0) }
        [System.IO.File]::WriteAllText($OutputJson, ($obj0 | ConvertTo-Json -Depth 6), (New-Object System.Text.UTF8Encoding($false)))
        exit 0
    }
    $ocr = $null
    try { $ocr = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage((New-Object Windows.Globalization.Language($Language))) } catch { $ocr = $null }
    if ($null -eq $ocr) { try { $ocr = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage((New-Object Windows.Globalization.Language("en-US"))) } catch { $ocr = $null } }
    if ($null -eq $ocr) { $ocr = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages() }
    if ($null -eq $ocr) { throw "Windows OCR chua co goi ngon ngu. Cai Language OCR (Vietnamese / English) trong Windows Settings > Time & Language." }

    function Convert-Bitmap($bitmap, [int]$pageNumber, [int]$rot) {
        $r = Await-Operation ($ocr.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])
        $words = New-Object System.Collections.ArrayList
        $lines = New-Object System.Collections.ArrayList
        foreach ($line in $r.Lines) {
            $lw = New-Object System.Collections.ArrayList
            foreach ($w in $line.Words) {
                $b = $w.BoundingRect
                $e = [ordered]@{ text = [string]$w.Text; x = [double]$b.X; y = [double]$b.Y; width = [double]$b.Width; height = [double]$b.Height }
                [void]$words.Add($e); [void]$lw.Add($e)
            }
            if ($lw.Count -gt 0) {
                $x0 = ($lw | ForEach-Object { $_.x } | Measure-Object -Minimum).Minimum
                $y0 = ($lw | ForEach-Object { $_.y } | Measure-Object -Minimum).Minimum
                $x1 = ($lw | ForEach-Object { $_.x + $_.width } | Measure-Object -Maximum).Maximum
                $y1 = ($lw | ForEach-Object { $_.y + $_.height } | Measure-Object -Maximum).Maximum
                [void]$lines.Add([ordered]@{ text = [string]$line.Text; x = [double]$x0; y = [double]$y0; width = [double]($x1 - $x0); height = [double]($y1 - $y0) })
            }
        }
        $text = [string]$r.Text
        $score = [double]$words.Count + ([double]$lines.Count * 4.0)
        $up = $text.ToUpperInvariant()
        foreach ($kw in @("NGAY", "NGÀY", "DATE", "DEBIT", "CREDIT", "GHI NO", "GHI NỢ", "GHI CO", "GHI CÓ", "SO DU", "SỐ DƯ", "BALANCE", "DIEN GIAI", "DIỄN GIẢI", "NOI DUNG", "NỘI DUNG", "PHAT SINH", "PHÁT SINH")) {
            if ($up.Contains($kw)) { $score += 35.0 }
        }
        $score += [double]([regex]::Matches($text, '\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b').Count) * 8.0
        $score += [double]([regex]::Matches($text, '\b\d{1,3}(?:[.,]\d{3})+(?:[.,]\d{1,2})?\b').Count) * 4.0
        return [ordered]@{ page_number = $pageNumber; width = [int]$bitmap.PixelWidth; height = [int]$bitmap.PixelHeight
            rotation_degrees = $rot; orientation_score = [math]::Round($score, 2); text = $text; words = @($words); lines = @($lines) }
    }
    # GD66: Windows OCR doc ca trang bo sot phan lon so tien tren ban scan (thu tren sao ke that: lam den trang anh con te hon);
    #   doc them o nhieu co anh va tung dai ngang cua vung cot so tien, Python gop lai (bo phieu).
    function Ocr-Words($bmp, [double]$ox, [double]$sx, [double]$sy) {
        $r = Await-Operation ($ocr.RecognizeAsync($bmp)) ([Windows.Media.Ocr.OcrResult])
        $ws = New-Object System.Collections.ArrayList
        foreach ($line in $r.Lines) {
            foreach ($w in $line.Words) {
                $b = $w.BoundingRect
                [void]$ws.Add([ordered]@{ text = [string]$w.Text; x = [math]::Round($ox + $b.X * $sx, 1); y = [math]::Round($b.Y * $sy, 1)
                    width = [math]::Round($b.Width * $sx, 1); height = [math]::Round($b.Height * $sy, 1) })
            }
        }
        return ,$ws
    }
    function Render-Bmp($page, [double]$x0, [double]$x1, [int]$rong) {
        $sz = $page.Size
        $o = New-Object Windows.Data.Pdf.PdfPageRenderOptions
        if ($x0 -gt 0 -or $x1 -lt 1) { $o.SourceRect = New-Object Windows.Foundation.Rect(($x0 * $sz.Width), 0, (($x1 - $x0) * $sz.Width), $sz.Height) }
        $o.DestinationWidth = [uint32]$rong
        $st = New-Object Windows.Storage.Streams.InMemoryRandomAccessStream
        Await-Action ($page.RenderToStreamAsync($st, $o))
        $st.Seek(0)
        $d = Await-Operation ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($st)) ([Windows.Graphics.Imaging.BitmapDecoder])
        $b = Await-Operation ($d.GetSoftwareBitmapAsync([Windows.Graphics.Imaging.BitmapPixelFormat]::Bgra8, [Windows.Graphics.Imaging.BitmapAlphaMode]::Premultiplied)) ([Windows.Graphics.Imaging.SoftwareBitmap])
        try { $st.Dispose() } catch {}
        return $b
    }
    function Get-DaiPhai($page, [int]$fw, [int]$fh, [double]$x0, [double]$tyLe, [string]$ten) {
        # cat vung cot so tien thanh cac dai ngang (~1,5 dong), OCR tung dai (Windows OCR bo sot so tien khi doc ca trang)
        $o = New-Object Windows.Data.Pdf.PdfPageRenderOptions
        if ($PdfWidth -gt 0) { $o.DestinationWidth = [uint32]$PdfWidth }
        $st = New-Object Windows.Storage.Streams.InMemoryRandomAccessStream
        Await-Action ($page.RenderToStreamAsync($st, $o))
        $st.Seek(0)
        $d = Await-Operation ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($st)) ([Windows.Graphics.Imaging.BitmapDecoder])
        $W = [int]$d.PixelWidth; $H = [int]$d.PixelHeight
        $sw = [uint32][math]::Round($W * $tyLe); $sh = [uint32][math]::Round($H * $tyLe)
        $bx = [uint32][math]::Floor($x0 * $sw); $bw = [uint32]($sw - $bx)
        $cao = [uint32][math]::Round(170.0 * $sh / $fh)
        $buoc = [uint32][math]::Max(1, [math]::Round($cao / 2.0))
        $sx = $fw / [double]$sw; $sy = $fh / [double]$sh
        $ws = New-Object System.Collections.ArrayList
        $y = [uint32]0
        while ($y -lt $sh) {
            $hh = [uint32][math]::Min([double]$cao, [double]($sh - $y))
            if ($hh -lt 20) { break }
            $t = New-Object Windows.Graphics.Imaging.BitmapTransform
            $t.ScaledWidth = $sw; $t.ScaledHeight = $sh
            $t.InterpolationMode = [Windows.Graphics.Imaging.BitmapInterpolationMode]::Fant
            $bb = New-Object Windows.Graphics.Imaging.BitmapBounds
            $bb.X = $bx; $bb.Y = $y; $bb.Width = $bw; $bb.Height = $hh
            $t.Bounds = $bb
            $bmp = Await-Operation ($d.GetSoftwareBitmapAsync([Windows.Graphics.Imaging.BitmapPixelFormat]::Bgra8, [Windows.Graphics.Imaging.BitmapAlphaMode]::Premultiplied, $t,
                [Windows.Graphics.Imaging.ExifOrientationMode]::IgnoreExifOrientation, [Windows.Graphics.Imaging.ColorManagementMode]::DoNotColorManage)) ([Windows.Graphics.Imaging.SoftwareBitmap])
            try {
                $r = Await-Operation ($ocr.RecognizeAsync($bmp)) ([Windows.Media.Ocr.OcrResult])
                foreach ($line in $r.Lines) {
                    foreach ($w in $line.Words) {
                        $b = $w.BoundingRect
                        [void]$ws.Add([ordered]@{ text = [string]$w.Text; x = [math]::Round(($bx + $b.X) * $sx, 1); y = [math]::Round(($y + $b.Y) * $sy, 1)
                            width = [math]::Round($b.Width * $sx, 1); height = [math]::Round($b.Height * $sy, 1) })
                    }
                }
            } finally { try { $bmp.Dispose() } catch {} }
            $y = [uint32]($y + $buoc)
        }
        try { $st.Dispose() } catch {}
        return [ordered]@{ ten = $ten; words = @($ws) }
    }
    function Get-Vung($page, [int]$fw, [int]$fh) {
        $ra = New-Object System.Collections.ArrayList
        foreach ($v in @(@{ N = "dai_phai_08"; X0 = 0.55; T = 0.8 }, @{ N = "dai_phai_06"; X0 = 0.55; T = 0.6 })) {
            try { [void]$ra.Add((Get-DaiPhai $page $fw $fh $v.X0 $v.T $v.N)) }
            catch { [void]$ra.Add([ordered]@{ ten = $v.N; loi = (Get-DeepMessage $_.Exception); words = @() }) }
        }
        foreach ($rong in @(1200, 1400, 1600, 1800, 2000, 2200, 2600)) {
            try {
                $bmp = Render-Bmp $page 0.0 1.0 $rong
                try {
                    $ws = Ocr-Words $bmp 0.0 ($fw / [double]$bmp.PixelWidth) ($fh / [double]$bmp.PixelHeight)
                    [void]$ra.Add([ordered]@{ ten = ("toan_" + $rong); px = [int]$bmp.PixelWidth; words = @($ws) })
                } finally { try { $bmp.Dispose() } catch {} }
            } catch { [void]$ra.Add([ordered]@{ ten = ("toan_" + $rong); loi = (Get-DeepMessage $_.Exception); words = @() }) }
        }
        return ,$ra
    }
    function Get-Best($decoder, [int]$pageNumber) {
        $cands = @(@{ E = [Windows.Graphics.Imaging.BitmapRotation]::None; D = 0 }, @{ E = [Windows.Graphics.Imaging.BitmapRotation]::Clockwise90Degrees; D = 90 },
                   @{ E = [Windows.Graphics.Imaging.BitmapRotation]::Clockwise180Degrees; D = 180 }, @{ E = [Windows.Graphics.Imaging.BitmapRotation]::Clockwise270Degrees; D = 270 })
        if (-not $TryAllRotations) { $cands = @($cands[0]) }
        $best = $null
        foreach ($c in $cands) {
            $t = New-Object Windows.Graphics.Imaging.BitmapTransform
            $t.Rotation = $c.E
            $bmp = Await-Operation ($decoder.GetSoftwareBitmapAsync([Windows.Graphics.Imaging.BitmapPixelFormat]::Bgra8, [Windows.Graphics.Imaging.BitmapAlphaMode]::Premultiplied, $t,
                [Windows.Graphics.Imaging.ExifOrientationMode]::IgnoreExifOrientation, [Windows.Graphics.Imaging.ColorManagementMode]::DoNotColorManage)) ([Windows.Graphics.Imaging.SoftwareBitmap])
            try {
                $res = Convert-Bitmap $bmp $pageNumber ([int]$c.D)
                if ($null -eq $best -or [double]$res.orientation_score -gt [double]$best.orientation_score) { $best = $res }
            } finally { try { $bmp.Dispose() } catch {} }
        }
        return $best
    }
    $resolved = [System.IO.Path]::GetFullPath($InputPath)
    $ext = [System.IO.Path]::GetExtension($resolved).ToLowerInvariant()
    $pages = New-Object System.Collections.ArrayList
    $sf = Await-Operation ([Windows.Storage.StorageFile]::GetFileFromPathAsync($resolved)) ([Windows.Storage.StorageFile])
    if ($ext -eq ".pdf") {
        $pdf = Await-Operation ([Windows.Data.Pdf.PdfDocument]::LoadFromFileAsync($sf)) ([Windows.Data.Pdf.PdfDocument])
        for ($i = 0; $i -lt [int]$pdf.PageCount; $i++) {
            $page = $pdf.GetPage([uint32]$i)
            $stream = New-Object Windows.Storage.Streams.InMemoryRandomAccessStream
            $opt = New-Object Windows.Data.Pdf.PdfPageRenderOptions
            if ($PdfWidth -gt 0) { $opt.DestinationWidth = [uint32]$PdfWidth }
            Await-Action ($page.RenderToStreamAsync($stream, $opt))
            $stream.Seek(0)
            $dec = Await-Operation ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
            $best = Get-Best $dec ($i + 1)
            if ($ThemVung -ne 0 -and $null -ne $best -and [int]$best.rotation_degrees -eq 0) {
                try { $best["vung"] = (Get-Vung $page ([int]$best.width) ([int]$best.height)) } catch { $best["vung_loi"] = (Get-DeepMessage $_.Exception) }
            }
            [void]$pages.Add($best)
            [Console]::Out.WriteLine(("UNESCO_TRANG {0}/{1}" -f ($i + 1), [int]$pdf.PageCount)); [Console]::Out.Flush()
            try { $stream.Dispose() } catch {}; try { $page.Dispose() } catch {}
        }
    } else {
        $stream = Await-Operation ($sf.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
        $dec = Await-Operation ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
        [void]$pages.Add((Get-Best $dec 1))
    }
    $result = [ordered]@{ engine = "WINDOWS_MEDIA_OCR_UNESCO"; success = $true; language = [string]$ocr.RecognizerLanguage.LanguageTag
        source = $resolved; generated_at = [DateTime]::UtcNow.ToString("o"); pages = @($pages) }
    [System.IO.File]::WriteAllText($OutputJson, ($result | ConvertTo-Json -Depth 15), (New-Object System.Text.UTF8Encoding($false)))
    exit 0
} catch {
    $msg = Get-DeepMessage $_.Exception
    if (-not $msg) { $msg = [string]$_ }
    Write-Failure $msg
    Write-Error $msg
    exit 1
}
'''


def _tim_powershell():
    goc = os.environ.get("SystemRoot", r"C:\Windows")
    for p in (os.path.join(goc, "Sysnative", "WindowsPowerShell", "v1.0", "powershell.exe"),
              os.path.join(goc, "System32", "WindowsPowerShell", "v1.0", "powershell.exe"),
              os.path.join(goc, "SysWOW64", "WindowsPowerShell", "v1.0", "powershell.exe")):
        if os.path.exists(p):
            return p
    return "powershell.exe"


def chay_ps_tien_do(cmd, thoi_gian, nhan="", env=None):
    """GD104: chay PowerShell OCR / ve trang, doc tung dong in ra -> ghi tien do 'trang i/n' vao nhat ky (cua so den khong
       dung im 5 - 10 phut). Het thoi_gian giay -> dung tien trinh. -> (ma tra ve, chu in ra)."""
    import threading
    import time as _tg
    if subprocess.run is not _RUN_GOC:          # kiem thu thay subprocess.run (test_gd66/67/68) -> chay kieu cu, khong tien do
        r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=thoi_gian, env=env,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        return r.returncode, (r.stdout or b"").decode("utf-8", "replace")
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=env,
                         creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    het = [False]

    def canh():
        het[0] = True
        try:
            p.kill()
        except Exception:
            pass
    t = threading.Timer(thoi_gian, canh)
    t.daemon = True
    t.start()
    ra, t0, lan_cuoi = [], _tg.time(), 0.0
    try:
        for b in iter(p.stdout.readline, b""):
            ln = b.decode("utf-8", "replace").strip()
            m = re.match(r"^UNESCO_(TRANG|VE) (\d+)/(\d+)$", ln)
            if m:
                i, n = int(m.group(2)), int(m.group(3))
                if i == n or i == 1 or _tg.time() - lan_cuoi >= 8 or n <= 30:
                    lan_cuoi = _tg.time()
                    ghi("[OFFLINE] %s%s trang %d/%d (%d giay)" % (nhan, "doc" if m.group(1) == "TRANG" else "ve anh", i, n,
                                                                int(_tg.time() - t0)))
                continue
            ra.append(ln)
        p.wait()
    finally:
        t.cancel()
    if het[0]:
        raise RuntimeError("quá %d phút chưa xong - dừng (tệp quá nhiều trang / máy chậm)" % max(1, thoi_gian // 60))
    return p.returncode, "\n".join(ra)


def _ocr_bo_nho(path, thu_muc_tam, them=""):
    """GD66: tep ket qua OCR tho theo noi dung tep anh / PDF (sha1) - doc lai khong can OCR lai."""
    import hashlib
    h = hashlib.sha1()
    with open(path, "rb") as f:
        for khoi in iter(lambda: f.read(1 << 20), b""):
            h.update(khoi)
    h.update(PS1_OFFLINE.encode("utf-8"))          # doi cach OCR (do phan giai...) -> OCR lai
    h.update(them.encode("utf-8"))
    return os.path.join(thu_muc_tam, "ocr_tho_%s.json" % h.hexdigest()[:20])


def _ocr_don_bo_nho(thu_muc_tam, giu=20):
    try:
        ds = sorted((os.path.getmtime(os.path.join(thu_muc_tam, t)), os.path.join(thu_muc_tam, t))
                    for t in os.listdir(thu_muc_tam) if t.startswith("ocr_tho_") and t.endswith(".json"))
        for _, p in ds[:-giu] if len(ds) > giu else []:
            os.remove(p)
    except Exception:
        pass


def chay_ocr_offline(path, thu_muc_tam):
    """Chay Windows OCR (PowerShell + WinRT) -> dict JSON {success, pages:[{width,height,words:[{text,x,y,width,height}],lines,...}]}.
       Script duoc ghi ra thu_muc_tam (co BOM UTF-8 - PowerShell 5.1 can BOM). JSON tho duoc xoa sau khi doc."""
    os.makedirs(thu_muc_tam, exist_ok=True)
    bo_nho = _ocr_bo_nho(path, thu_muc_tam)          # GD66
    if os.path.exists(bo_nho):
        try:
            with io.open(bo_nho, "r", encoding="utf-8-sig") as f:
                doc = json.load(f)
            if doc and doc.get("success") and doc.get("pages"):
                ghi("[OFFLINE] dung lai ket qua OCR da doc cua tep nay (%s)" % os.path.basename(bo_nho))
                os.utime(bo_nho, None)
                return doc
        except Exception:
            pass
    if not sys.platform.startswith("win"):
        raise RuntimeError("OCR Offline chi chay tren Windows (Windows.Media.Ocr).")
    ps1 = os.path.join(thu_muc_tam, "Invoke-OcrOffline-UNESCO.ps1")
    noi_dung = PS1_OFFLINE.encode("utf-8")
    try:
        cu = open(ps1, "rb").read() if os.path.exists(ps1) else b""
    except Exception:
        cu = b""
    if cu != b"\xef\xbb\xbf" + noi_dung:
        with open(ps1, "wb") as f:
            f.write(b"\xef\xbb\xbf" + noi_dung)
    ra = os.path.join(thu_muc_tam, "ocr_tho_%s.json" % datetime.now().strftime("%Y%m%d%H%M%S"))
    cmd = [_tim_powershell(), "-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", ps1,
           "-InputPath", path, "-OutputJson", ra, "-Language", "vi-VN"]
    env = dict(os.environ)
    env["POWERSHELL_TELEMETRY_OPTOUT"] = "1"
    ghi("[OFFLINE] chay Windows OCR: %s" % os.path.basename(path))
    try:
        ma_ra, out = chay_ps_tien_do(cmd, 1800, "Windows OCR ", env)
    except Exception as e:
        raise RuntimeError("Khong chay duoc PowerShell / Windows OCR: %s" % e)
    r = type("KQ", (), {"returncode": ma_ra})()
    doc = None
    try:
        with io.open(ra, "r", encoding="utf-8-sig") as f:
            doc = json.load(f)
    except Exception:
        doc = None
    try:
        if os.path.exists(ra):
            if doc and doc.get("success") and doc.get("pages"):
                os.replace(ra, bo_nho)      # GD66: giu ket qua theo noi dung tep (doc lai nhanh, sua bo doc tren du lieu that)
                _ocr_don_bo_nho(thu_muc_tam)
            else:
                os.remove(ra)
    except Exception:
        pass
    if not doc:
        raise RuntimeError("Windows OCR khong tao ket qua (ma %s): %s" % (getattr(r, "returncode", "?"), out[-600:]))
    if not doc.get("success"):
        raise RuntimeError("Windows OCR loi: %s" % (doc.get("error") or out[-600:]))
    return doc


# --- giai ma ket qua OCR tho -> dong (bo doc chung, cot theo tieu de hoac dai co dinh)
COT_TU_KHOA = (("ngay", r"\bNGAY\b|\bDATE\b|NGAY GD|NGAY GIAO DICH|NGAY HACH TOAN|NGAY HL"),
               ("so_ct", r"SO GD|SO CT|SO CHUNG TU|SO BUT TOAN|SO THAM CHIEU|\bREF\b|TRANSACTION NO|MA GD"),
               ("noi_dung", r"DIEN GIAI|NOI DUNG|DESCRIPTION|MO TA|DETAILS|REMARK|NARRATIVE"),
               ("tien_ra", r"GHI NO|\bNO\b|DEBIT|RUT RA|TIEN RA|PHAT SINH NO|WITHDRAW|SO TIEN RUT"),
               ("tien_vao", r"GHI CO|\bCO\b|CREDIT|GUI VAO|TIEN VAO|PHAT SINH CO|DEPOSIT|SO TIEN GUI"),
               ("so_du", r"SO DU|BALANCE"),
               ("doi_ung", r"DOI UNG|TK DOI UNG|COUNTER|BENEFICIARY|NGUOI NHAN|NGUOI CHUYEN|TEN DOI UNG"))
DAI_MAC_DINH = (("ngay", 0.20), ("noi_dung", 0.62), ("tien_ra", 0.76), ("tien_vao", 0.89), ("so_du", 1.01))
RX_NGAY_OCR = re.compile(r"(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{2,4})")


def _gom_dong_theo_y(words, cao_trang):
    tol = max(5.0, cao_trang * 0.0065)
    ws = sorted(words, key=lambda w: (w["y"] + w["height"] / 2.0, w["x"]))
    dong = []
    for w in ws:
        cy = w["y"] + w["height"] / 2.0
        tot = None
        for ln in dong[-4:]:
            if abs(ln["y"] - cy) <= tol and (tot is None or abs(ln["y"] - cy) < abs(tot["y"] - cy)):
                tot = ln
        if tot is None:
            dong.append({"y": cy, "tu": [w]})
        else:
            tot["tu"].append(w)
            tot["y"] = (tot["y"] * (len(tot["tu"]) - 1) + cy) / len(tot["tu"])
    for ln in dong:
        ln["tu"].sort(key=lambda w: w["x"])
        ln["text"] = " ".join(w["text"] for w in ln["tu"])
    dong.sort(key=lambda ln: ln["y"])
    return dong


def _tim_tieu_de(dong, rong_trang):
    """Dong tieu de bang: co >= 3 cot nhan ra (trong do co Noi dung va No / Co). -> (chi so dong, [(ten cot, x_giua)]) hoac (-1, None).
       x_giua = tam cua cum 1-3 tu dau tien khop tu khoa cua cot do (ti le theo be rong trang)."""
    for i, ln in enumerate(dong[:60]):
        t = chuan(ln["text"])
        thay = [ten for ten, rx in COT_TU_KHOA if re.search(rx, t)]
        if len(thay) >= 3 and ("tien_ra" in thay or "tien_vao" in thay) and "noi_dung" in thay:
            cot, tu = [], ln["tu"]
            for ten, rx in COT_TU_KHOA:
                vi_tri = None
                for dai_cum in (1, 2, 3):          # cum ngan truoc (tranh "DUNG GHI NO" bat vao cot Noi dung)
                    for j in range(len(tu) - dai_cum + 1):
                        if re.search(rx, chuan(" ".join(w["text"] for w in tu[j:j + dai_cum]))):
                            k = j + dai_cum
                            vi_tri = (tu[j]["x"] + tu[k - 1]["x"] + tu[k - 1]["width"]) / 2.0 / rong_trang
                            break
                    if vi_tri is not None:
                        break
                if vi_tri is not None:
                    cot.append((ten, vi_tri))
            if len(cot) >= 3 and any(c[0] in ("tien_ra", "tien_vao") for c in cot):
                cot.sort(key=lambda c: c[1])
                return i, cot
    return -1, None


def _dai_cot(cot):
    """[(ten, x_giua)] sap theo x -> [(ten, gioi han phai)] (giua hai tam ke nhau)."""
    ra = []
    for k, (ten, x) in enumerate(cot):
        if k + 1 < len(cot):
            ra.append((ten, (x + cot[k + 1][1]) / 2.0))
        else:
            ra.append((ten, 1.01))
    return ra


def _cot_cua(xg, dai):
    for ten, gh in dai:
        if xg < gh:
            return ten
    return dai[-1][0]


def _tien_ocr(s):
    """Chuoi trong cot tien cua OCR -> so (None neu khong phai tien: so TK, dien thoai, ma GD...)."""
    t = chuan(s)
    if re.search(r"CCCD|CMND|ACCOUNT|TAI KHOAN|PHONE|DIEN THOAI|MST|TAX CODE|TXN|TRANSACTION|\bFT\d|\bTT\d", t):
        return None
    s2 = s.replace("O", "0").replace("o", "0").replace("|", "").replace("]", "").replace("[", "")
    s2 = re.sub(r"(?i)\bVND\b|\bVNĐ\b", "", s2).strip()
    if not re.match(r"^-?[0-9][0-9 .,]*$", s2):
        return None
    chu_so = re.sub(r"\D", "", s2)
    if not chu_so or len(chu_so) > 15:
        return None
    if chu_so.startswith("0") and len(chu_so) >= 7:
        return None            # so dien thoai / so TK
    if len(chu_so) >= 8 and not re.search(r"[.,]", s2) and not re.match(r"^\s*\d{1,3}(?:\s+\d{3})+\s*$", s2):
        return None            # 8+ chu so lien khong phan cach: ma GD / so TK
    x = tien(s2.replace(" ", ""))
    return x


# --- GD64: giai ma ket qua OCR tho -> dong (bo doc v2)
#   Loi GD62 (sao ke Sacombank song ngu): cot "No" (STT tieng Anh) bi nhan la cot Tien ra -> Tien ra = so thu tu; so tien /
#   so du khong doc duoc; trang khong co dong tieu de dung dai cot mac dinh sai; nhieu tai khoan trong mot PDF bi tron.
#   v2: tieu de 1-3 dong (Viet + Anh), tu khoa manh truoc yeu sau (NO / CO chi la cot tien khi nam ben phai Dien giai);
#   ngay GD / ngay hieu luc / STT nhan theo mau (khong theo dai cot); bo cot mang sang trang khong co tieu de (can theo
#   ngay + so du); moi lan gap khoi dau sao ke moi -> PHAN moi (so TK, ky, so du dau / cuoi, tong phat sinh); noi chuoi so
#   du de xac dinh chieu tien, suy so tien / so du con thieu; tach theo tai khoan.
# (ten cot, tu khoa manh (khop NGUYEN cum 1-4 tu), tu khoa yeu) - thu tu = uu tien (cu the truoc, chung sau)
COT_MAU = (
    ("ngay_gt", ("NGAY HL", "NGAY HIEU LUC", "VALUE DATE", "EFFECTIVE DATE", "NGAY GIA TRI"), ()),
    ("so_ct", ("SO GD", "SO GIAO DICH", "TXN ID", "TXN NO", "SO CT", "SO CHUNG TU", "SO BUT TOAN", "SO THAM CHIEU", "REF NO",
               "REFERENCE", "REFERENCE NO", "TRANSACTION NO", "TRANSACTION ID", "MA GD", "MA GIAO DICH", "SO GIAO DICH GD"), ()),
    ("noi_dung", ("DIEN GIAI", "NOI DUNG", "DESCRIPTION", "MO TA", "DETAILS", "DETAIL", "REMARK", "REMARKS", "NARRATIVE",
                  "NOI DUNG GIAO DICH", "DIEN GIAI GIAO DICH", "TRANSACTION DETAILS"), ()),
    ("tien_ra", ("SO TIEN RUT", "DEBIT", "DEBITS", "GHI NO", "PHAT SINH NO", "RUT RA", "TIEN RA", "WITHDRAWAL", "WITHDRAWALS",
                 "SO TIEN GHI NO", "SO TIEN NO", "DEBIT AMOUNT"), ("NO",)),
    ("tien_vao", ("SO TIEN GUI", "CREDIT", "CREDITS", "GHI CO", "PHAT SINH CO", "GUI VAO", "TIEN VAO", "DEPOSIT", "DEPOSITS",
                  "SO TIEN GHI CO", "SO TIEN CO", "CREDIT AMOUNT"), ("CO",)),
    ("so_du", ("SO DU", "BALANCE", "SO DU CUOI", "ACTUAL BALANCE"), ()),
    ("doi_ung", ("DOI UNG", "TK DOI UNG", "TAI KHOAN DOI UNG", "COUNTERPART", "COUNTER PARTY", "BENEFICIARY", "NGUOI NHAN",
                 "NGUOI CHUYEN", "TEN DOI UNG"), ()),
    ("ngay", ("NGAY GD", "NGAY GIAO DICH", "BOOKING DATE", "TRANSACTION DATE", "TRANS DATE", "NGAY HACH TOAN", "POSTING DATE",
              "NGAY CT", "NGAY CHUNG TU"), ("NGAY", "DATE")),
    ("stt", ("STT", "SO TT"), ("TT", "NO")),
)
COT_TIEN = ("tien_ra", "tien_vao", "so_du")
RX_TONG = re.compile(r"TOTAL RECORDED|CONG PHAT SINH|TONG SO PHAT SINH|TONG PHAT SINH|PHAT SINH TRONG KY|^TONG CONG(?! TY)|^TOTAL\b")
RX_CUOI = re.compile(r"ENDING BALANCE|CLOSING BALANCE|SO DU CUOI|SO DU TAI KHOAN CUOI|DU CUOI KY|SO DU T\S{0,3} KH\S{0,5} CUOI")
RX_DAU = re.compile(r"OPENING BALANCE|BEGINNING BALANCE|SO DU DAU|SO DU TAI KHOAN DAU|DU DAU KY|SO DU T\S{0,3} KH\S{0,5} DAU")
RX_HET = re.compile(r"^(NGAY LAP|LAP PHIEU|NGUOI LAP|KIEM SOAT|KE TOAN|GIAM DOC|TRONG DO|WITH|THIS STATEMENT|SO PHU NAY|"
                    r"GHI CHU|NOTE|ACTUAL BALANCE|BOOKING DATE|VALUE DATE|NGAY GIAO DICH|NGAY HIEU LUC|SO DU \(?\*)")
RX_KHOI_DAU = re.compile(r"TU NGAY|FROM|SO TAI KHOAN|ACCOUNT NO|ACCOUNT NUMBER|TAI KHOAN SO|OPENING|SO DU DAU|DAU KY|SO PHU|"
                         r"STATEMENT|SAO KE|KHACH HANG|ACCOUNT HOLDER")
RX_MA_GD = re.compile(r"^[A-Z]{1,4}\d{5,}[A-Z0-9\\/]*$|^\d{6,}[A-Z]+[A-Z0-9]*$")


def _tach_tu(words):
    """OCR hay doc duong ke bang thanh | ] [ { } dinh vao tu ("|01/04/2026]01/04/2026]") -> tach thanh tu rieng."""
    ra = []
    for w in words:
        t = str(w.get("text") or "")
        if not re.search(r"[|\[\]{}]", t):
            if t.strip():
                ra.append(w)
            continue
        cw = float(w.get("width") or 0) / max(1, len(t))
        x = float(w.get("x") or 0)
        for p in re.split(r"([|\[\]{}])", t):
            if p and not re.fullmatch(r"[|\[\]{}]", p) and p.strip():
                ra.append({"text": p, "x": x, "y": w["y"], "width": cw * len(p), "height": w["height"], "alt": w.get("alt")})
            x += cw * len(p)
    ra2 = []
    for w in ra:                    # "LD26043003351,095,000,000": ma GD dinh so tien (hai cot sat nhau) -> tach
        m = re.fullmatch(r"(.*[A-Za-z].*?\d{6,})(\d{1,3}(?:,\d{3}){2,}|\d{1,3}(?:\.\d{3}){2,})", str(w["text"]))
        if m:
            cw = float(w.get("width") or 0) / max(1, len(w["text"]))
            ra2.append({"text": m.group(1), "x": w["x"], "y": w["y"], "width": cw * len(m.group(1)), "height": w["height"]})
            ra2.append({"text": m.group(2), "x": w["x"] + cw * len(m.group(1)), "y": w["y"], "width": cw * len(m.group(2)), "height": w["height"],
                        "alt": w.get("alt")})
        else:
            ra2.append(w)
    return [w for w in ra2 if re.search(r"[0-9A-Za-zÀ-ỹ]", str(w["text"]))]


def _ngay_tok(t):
    s = str(t).strip().strip("_.,;:'\"`~-\u2018\u2019\u201c\u201d\u00b4|()")        # GD66: ‘21/01/2026 (Tesseract)
    s = s.replace("O", "0").replace("o", "0").replace("I", "1").replace("l", "1")
    m = RX_NGAY_OCR.fullmatch(s) or RX_NGAY_OCR.match(s)
    if not m or len(m.group(3)) not in (2, 4):
        return ""
    return ngay_iso(m.group(0))


def _tien_tok(t, so_nho=False):
    """Tu OCR -> so tien (None neu khong phai). Nghiem: phai co dau phan cach nghin (1,234,567 / 1.234.567); so_nho: nhan them
       so <= 3 chu so (vd 792, 0) - chi dung khi tu nam trong vung cot tien."""
    s = str(t).strip().strip("_;:'\"`~|*\u2018\u2019\u201c\u201d\u00b4()")        # GD66: dau nhay cong
    s = s.lstrip("\\/")
    if s.startswith("$") or s.startswith("S"):
        s = "5" + s[1:]                    # OCR hay doc 5 dau so thanh $ / S
    s = s.replace("O", "0").replace("o", "0")
    s = re.sub(r"[.,]{2,}", ",", s).rstrip(".,-")
    if re.fullmatch(r"\d{1,3}(?:[.,]\d{3})+(?:[.,]\d{1,2})?", s):
        return tien(s)
    if so_nho and re.fullmatch(r"\d{1,3}", s):
        return float(s)
    return None


def _gan_dung(txt, mau):
    """GD66: 'CREAIT' ~ 'CREDIT', 'DEBLT' ~ 'DEBIT' (OCR doc sai chu tieu de): mot tu, dai >= 5, giong >= 0.8."""
    if " " in txt or len(txt) < 5:
        return False
    import difflib
    for m in mau:
        if " " not in m and len(m) >= 5 and abs(len(m) - len(txt)) <= 1 and m[0] == txt[0] and \
                difflib.SequenceMatcher(None, txt, m).ratio() >= 0.8:
            return True
    return False


def _tim_tieu_de2(dong, W):
    """Dong tieu de bang 1-3 dong lien nhau (Viet + Anh). -> (chi so dong cuoi cua tieu de, [{ten, xc, xl, xr}]) / (-1, None)."""
    for i, ln in enumerate(dong[:90]):
        if RX_NGAY_OCR.search(ln["text"]) or any(_tien_tok(w["text"]) is not None for w in ln["tu"]):
            continue
        cua_so, cao = [ln], max(8.0, sorted(w["height"] for w in ln["tu"])[len(ln["tu"]) // 2])
        for ln2 in dong[i + 1:i + 4]:
            if ln2["y"] - cua_so[-1]["y"] > cao * 2.6 or re.search(r"\d", re.sub(r"\(\s*\*\s*\)", "", ln2["text"])):
                break
            cua_so.append(ln2)
        tu = []
        for li, l in enumerate(cua_so):
            tu.extend([(li, w) for w in l["tu"]])
        dung, cot = set(), {}

        def cum(n):
            for li in range(len(cua_so)):
                ds = [(k, w) for k, (l2, w) in enumerate(tu) if l2 == li]
                for j in range(len(ds) - n + 1):
                    yield [k for k, _ in ds[j:j + n]], chuan(" ".join(w["text"] for _, w in ds[j:j + n]))

        for yeu in (False, True):
            for ten, manh, mau_yeu in COT_MAU:
                if ten in cot:
                    continue
                mau = mau_yeu if yeu else manh
                if not mau:
                    continue
                for n in ((4, 3, 2, 1) if not yeu else (1,)):
                    for ks, txt in cum(n):
                        if (txt in mau or (n == 1 and not yeu and _gan_dung(txt, mau))) and not (set(ks) & dung):
                            xl = min(tu[k][1]["x"] for k in ks) / W
                            xr = max(tu[k][1]["x"] + tu[k][1]["width"] for k in ks) / W
                            xc = (xl + xr) / 2.0
                            if yeu and ten in ("tien_ra", "tien_vao") and not ("noi_dung" in cot and xc > cot["noi_dung"]["xc"]):
                                continue            # "NO" / "CO" ben trai Dien giai = cot STT tieng Anh, khong phai tien
                            if yeu and ten == "stt" and "ngay" in cot and xc > cot["ngay"]["xc"]:
                                continue
                            cot[ten] = {"ten": ten, "xc": xc, "xl": xl, "xr": xr}
                            dung.update(ks)
                            break
                    if ten in cot:
                        break
        # danh dau tu da thuoc cot (ca tieng Anh trung vi tri) de khong nham lai
        so_tien = sum(1 for t in COT_TIEN if t in cot)
        # GD66: doc duoc No va So du ma thieu Co (hoac nguoc lai) - cot giua bi OCR doc hong -> dat o giua
        if "so_du" in cot and ("tien_ra" in cot) != ("tien_vao" in cot):
            du = cot["so_du"]
            if "tien_ra" in cot and du["xc"] - cot["tien_ra"]["xc"] >= 0.12:
                xc = (du["xc"] + cot["tien_ra"]["xc"]) / 2.0
                cot["tien_vao"] = {"ten": "tien_vao", "xc": xc, "xl": xc - 0.03, "xr": xc + 0.03}
            elif "tien_vao" in cot and "noi_dung" in cot and cot["tien_vao"]["xc"] - cot["noi_dung"]["xc"] >= 0.25:
                xc = cot["tien_vao"]["xc"] - (du["xc"] - cot["tien_vao"]["xc"])
                if xc > cot["noi_dung"]["xc"] + 0.1:
                    cot["tien_ra"] = {"ten": "tien_ra", "xc": xc, "xl": xc - 0.03, "xr": xc + 0.03}
            so_tien = sum(1 for t in COT_TIEN if t in cot)
        if "noi_dung" in cot and so_tien and ("ngay" in cot or "ngay_gt" in cot or so_tien >= 2):
            ds = sorted(cot.values(), key=lambda c: c["xc"])
            return i + len(cua_so) - 1, ds
    return -1, None


def _dai(cot):
    """[{ten, xc}] -> [(ten, gioi han phai)] (giua hai tam ke nhau)."""
    ra = []
    for k, c in enumerate(cot):
        ra.append((c["ten"], (c["xc"] + cot[k + 1]["xc"]) / 2.0 if k + 1 < len(cot) else 9.0))
    return ra


def _cot_cua2(xg, dai):
    for ten, gh in dai:
        if xg < gh:
            return ten
    return dai[-1][0]


def _neo(dong, W, bat_dau, co_so_du):
    """Neo can cot cua mot trang: trung vi x trai cua ngay dau dong, trung vi x phai cua so tien cuoi dong (khi bang co So du)."""
    xs, xr = [], []
    for ln in dong[bat_dau:]:
        ngay = [w for w in ln["tu"] if _ngay_tok(w["text"])]
        if not ngay:
            continue
        xs.append(ngay[0]["x"] / W)
        if co_so_du:
            tien_ = [w for w in ln["tu"] if _tien_tok(w["text"]) is not None]
            if tien_:
                w = max(tien_, key=lambda w: w["x"])
                xr.append((w["x"] + w["width"]) / W)
    trung = lambda a: sorted(a)[len(a) // 2] if len(a) >= 3 else None
    return trung(xs), trung(xr)


def _ham_anh_xa(neo_goc, neo_trang):
    """x tren trang nay -> x theo he toa do trang co dong tieu de (tinh tien theo ngay; co ca so du thi co gian)."""
    (a0, b0), (a1, b1) = neo_goc, neo_trang
    if a0 is None or a1 is None:
        return lambda x: x
    if b0 is not None and b1 is not None and b1 - a1 > 0.2:
        k = (b0 - a0) / (b1 - a1)
        if 0.9 < k < 1.1:
            return lambda x: a0 + (x - a1) * k
    return lambda x: x + (a0 - a1)


def _so_tk_ocr(s):
    """Chuoi OCR sau nhan 'So tai khoan' -> so TK (sua lan chu: O/D/Q->0, I/l/|->1, S->5, B->8, Z->2, G->6).
       Chi ghep cac tu lien nhau tu tu dau co chu so, dung o tu toan chu (SO TAI KHOAN CU / LOAI TIEN ...)."""
    cum, bat = [], False
    for tu in str(s).upper().split():
        so = sum(ch.isdigit() for ch in tu)
        if so:
            bat = True
        if bat:
            if so * 2 < len(tu) and len(cum) > 0:
                break
            cum.append(tu)
    t = "".join(cum) if cum else str(s).upper().replace(" ", "")
    t = t.translate(str.maketrans({"O": "0", "D": "0", "Q": "0", "I": "1", "L": "1", "|": "1", "S": "5", "B": "8", "Z": "2", "G": "6"}))
    m = re.findall(r"\d{9,16}", t)
    if m:
        return max(m, key=len)
    m = re.findall(r"\d{3,}", t)
    return ("~" + m[-1]) if m else ""            # "~41540": chi doc duoc duoi so - dung de ghep voi TK da biet


def _gia_tri_canh(dong, k, x_nhan, W):
    """So tien nam cung dong k (ben phai nhan) hoac dong ke tren / duoi (gia tri dat giua nhan Viet / Anh)."""
    for kk in (k, k - 1, k + 1):
        if not (0 <= kk < len(dong)):
            continue
        if kk != k and abs(dong[kk]["y"] - dong[k]["y"]) > 60 * W / 2400.0:
            continue
        ts = _so_dong([w for w in dong[kk]["tu"] if w["x"] / W > x_nhan])
        if ts:
            return ts
    return []


def _tien_tu(w):
    """GD68: so tien cua tu; tu khong doc duoc so (con dau / mo: "ati", "61783226571", "«783,226,571") -> so doc lai o (alt)."""
    v = _tien_tok(w["text"])
    if v is None:
        for a in w.get("alt") or []:
            v = _tien_tok(a)
            if v is not None:
                break
    return v


def _so_dong(tu):
    """So tien tren mot dong nhan (tong / so du dau / cuoi): so nghiem; khong co thi chi nhan so 0 ("0 0")."""
    ts = [x for x in (_tien_tu(w) for w in tu) if x is not None]
    if ts:
        return ts
    return [0.0 for w in tu if str(w["text"]).strip(".,:;") == "0"]


def _thong_tin_phan(dong, W, den):
    """Khoi dau sao ke (cac dong truoc tieu de bang) -> so TK, ky, so du dau / cuoi, tong, ngan hang."""
    p = {"so_tk": "", "ky_tu": "", "ky_den": "", "so_du_dau": None, "so_du_cuoi": None, "tong_no": None, "tong_co": None,
         "ngan_hang": "", "loai_tien": ""}
    for k, ln in enumerate(dong[:den]):
        up = bo_dau(ln["text"]).upper()
        c = chuan(ln["text"])
        if not p["ky_tu"]:
            m = re.search(r"(?:TU NGAY|FROM|T\S{0,2} NGAY)\W{0,4}(\d{1,2}/\d{1,2}/\d{4}).{0,40}?(\d{1,2}/\d{1,2}/\d{4})", up)
            if not m:
                m = re.search(r"(\d{1,2}/\d{1,2}/\d{4})\W{0,4}(?:DEN NGAY|DEN|TO)\W{0,4}(\d{1,2}/\d{1,2}/\d{4})", up)
            if m:
                p["ky_tu"], p["ky_den"] = ngay_iso(m.group(1)), ngay_iso(m.group(2))
        if not p["so_tk"] or p["so_tk"].startswith("~"):
            m = re.search(r"(?:\bS\w{0,2} TAI KH\w*|ACCOUNT N\w*|TAI KH\w* SO|\bSO TK\b|\bSTK\b|\bTAI KHOAN(?= \d{6,}))\W*(.*)$", c)
            if m:
                ung = _so_tk_ocr(m.group(1))
                if not ung and k + 1 < len(dong):
                    ung = _so_tk_ocr(chuan(dong[k + 1]["text"]))
                if ung and (not p["so_tk"] or not ung.startswith("~")):
                    p["so_tk"] = ung
        if p["so_du_dau"] is None and RX_DAU.search(c):
            ts = _gia_tri_canh(dong, k, ln["tu"][0]["x"] / W + 0.02, W)
            if ts:
                p["so_du_dau"] = ts[-1]
        if not p["loai_tien"]:
            m = re.search(r"\b(VND|USD|EUR)\b", c)
            if m and re.search(r"TIEN TE|CURRENCY|LOAI TIEN", c + " " + (chuan(dong[k - 1]["text"]) if k else "")):
                p["loai_tien"] = m.group(1)
    return p


# GD66: Windows OCR doc ca trang bo sot phan lon so tien (thu tren sao ke that: 108 / ~420 so). PS1 doc them nhieu co anh
#   va tung dai cot so tien (pg["vung"]); gop: moi o so tien lay ban doc duoc nhieu lan nhat (bo phieu giua cac lan doc).
RX_TIEN_GOP = re.compile(r"^[\(\-]?\d{1,3}(?:[.,]\d{3})+(?:[.,]\d{1,2})?[\)\-]?$")


def _gop_vung_ocr(pg):
    goc = [w for w in (pg.get("words") or []) if str(w.get("text", "")).strip()]
    vung = [v for v in (pg.get("vung") or []) if v.get("words")]
    if not vung:
        return goc
    ung = []
    for ws in [goc] + [v["words"] for v in vung]:
        for w in ws:
            t = str(w.get("text", "")).strip()
            if RX_TIEN_GOP.match(t) and float(w.get("width") or 0) > 0:
                ung.append(dict(w, text=t))
    cum = []
    for w in ung:
        cx, cy = w["x"] + w["width"] / 2.0, w["y"] + w["height"] / 2.0
        for c in cum:
            if abs(c["cx"] - cx) < max(c["w"], w["width"]) * 0.5 and abs(c["cy"] - cy) < max(c["h"], w["height"]) * 0.7:
                c["ds"].append(w)
                break
        else:
            cum.append({"cx": cx, "cy": cy, "w": w["width"], "h": w["height"], "ds": [w]})
    chon = []
    for c in cum:
        dem = {}
        for x in c["ds"]:
            dem[x["text"]] = dem.get(x["text"], 0) + 1
        tot = max(dem.items(), key=lambda kv: (kv[1], len(re.sub(r"\D", "", kv[0]))))[0]
        mau = next(x for x in c["ds"] if x["text"] == tot)
        chon.append({"text": tot, "x": mau["x"], "y": mau["y"], "width": mau["width"], "height": mau["height"]})

    def chong(a, b):
        return not (a["x"] + a["width"] <= b["x"] or b["x"] + b["width"] <= a["x"] or
                    a["y"] + a["height"] <= b["y"] or b["y"] + b["height"] <= a["y"])
    ra = [w for w in goc if not RX_TIEN_GOP.match(str(w.get("text", "")).strip()) and not any(chong(w, u) for u in chon)]
    return ra + chon


def _noi_so_tach(dong):
    """GD66: OCR tach mot so tien thanh hai tu sat nhau ("5,538, 160,982" -> 5,538,160,982): noi lai khi co dau phay o cho tach
       va khoang cach < 1 chu (hai so o hai cot sat nhau khong co dau phay o giua -> khong noi)."""
    for ln in dong:
        ra = []
        for w in ln["tu"]:
            p = ra[-1] if ra else None
            if p is not None:
                a, b = str(p["text"]), str(w["text"])
                cw = float(p["width"]) / max(1, len(a))
                gap = float(w["x"]) - (float(p["x"]) + float(p["width"]))
                if -cw <= gap <= 1.0 * cw and re.fullmatch(r"\d{1,3}(?:,\d{3})*,?", a) and re.fullmatch(r",?\d{3}(?:,\d{3})*", b) \
                        and (a.endswith(",") or b.startswith(",")):
                    ra[-1] = dict(p, text=a.rstrip(",") + "," + b.lstrip(","), width=float(w["x"]) + float(w["width"]) - float(p["x"]), alt=None)
                    continue
            ra.append(w)
        if len(ra) != len(ln["tu"]):
            ln["tu"] = ra
            ln["text"] = " ".join(str(w["text"]) for w in ra)
    return dong


def giai_ma_offline(doc, nh_goi_y=""):
    """JSON OCR tho -> (dau, dong). GD64: cot theo tieu de 1-3 dong (bo cot mang sang trang sau), dong = cum tu cung y,
       dong khong ngay la dong noi tiep (tru khi co dau hieu dong moi: STT + ma GD / so tien trung cot); moi khoi dau sao ke
       la mot PHAN (so TK, ky, so du dau / cuoi, tong). Sau do noi chuoi so du (_noi_chuoi) va danh mau."""
    dau = dau_moi(ngan_hang=(nh_goi_y or "").upper(), cach_doc="Windows OCR Offline (không gửi ảnh ra ngoài)")
    dong_ra, phan, van_ban = [], [], []
    bo_cot, neo_goc = None, (None, None)
    hien, khoa = None, False
    for pg in doc.get("pages") or []:
        W = float(pg.get("width") or 1) or 1.0
        H = float(pg.get("height") or 1) or 1.0
        so_trang = int(pg.get("page_number") or (len(van_ban) + 1))
        words = _tach_tu([w for w in _gop_vung_ocr(pg) if str(w.get("text", "")).strip()])      # GD66: gop cac lan doc
        if not words:
            van_ban.append("")
            dau["canh_bao"].append("Trang %d trống / không OCR được" % so_trang)
            continue
        dong = _noi_so_tach(_gom_dong_theo_y(words, H))
        van_ban.append("\n".join(ln["text"] for ln in dong))
        cao = sorted(w["height"] for w in words)[len(words) // 2] or 10.0
        i_td, cot = _tim_tieu_de2(dong, W)
        bat_dau = 0
        if cot:
            bat_dau = i_td + 1
            tt = _thong_tin_phan(dong, W, i_td)
            tt["_vb"] = chuan(" ".join(ln["text"] for ln in dong[:i_td]))
            khoi_moi = any(RX_KHOI_DAU.search(chuan(ln["text"])) for ln in dong[:i_td])
            if khoi_moi or not phan:
                if hien:
                    dong_ra.append(hien)
                hien, khoa = None, False
                tt.update({"trang_dau": so_trang, "trang_cuoi": so_trang, "tieu_de": [c["ten"] for c in cot]})
                phan.append(tt)
            bo_cot = cot
            neo_goc = _neo(dong, W, bat_dau, any(c["ten"] == "so_du" for c in cot))
            ax = lambda x: x
        elif bo_cot:
            ax = _ham_anh_xa(neo_goc, _neo(dong, W, 0, any(c["ten"] == "so_du" for c in bo_cot)))
        else:
            bo_cot = [{"ten": t, "xc": x - 0.05} for t, x in DAI_MAC_DINH]
            dau["canh_bao"].append("Trang %d: không thấy dòng tiêu đề bảng - dùng dải cột mặc định (Ngày | Nội dung | Nợ | Có | Số dư)" % so_trang)
            ax = lambda x: x
        if not phan:
            phan.append({"so_tk": "", "ky_tu": "", "ky_den": "", "so_du_dau": None, "so_du_cuoi": None, "tong_no": None, "tong_co": None,
                         "ngan_hang": "", "loai_tien": "", "trang_dau": so_trang, "trang_cuoi": so_trang, "tieu_de": []})
        ph = phan[-1]
        ph["trang_cuoi"] = so_trang
        dai = _dai(bo_cot)
        tam = {c["ten"]: c["xc"] for c in bo_cot}
        x_nd = tam.get("noi_dung", 0.4)
        tien_cot = [c for c in bo_cot if c["ten"] in COT_TIEN]
        bien_tien = min((c["xc"] for c in tien_cot), default=0.7)
        bien_tien = (x_nd + bien_tien) / 2.0 if tien_cot else 0.7          # tu tien phai nam ben phai bien nay
        x_ng = max(tam.get("ngay", 0.0), tam.get("ngay_gt", 0.0))
        sau_ng = [c["xc"] for c in bo_cot if c["xc"] > x_ng + 0.01 and c["ten"] not in ("ngay", "ngay_gt", "stt")]
        if x_ng and sau_ng:
            x_ngay_max = (x_ng + min(sau_ng)) / 2.0
        else:                       # tieu de khong doc duoc cot ngay: ngay nam ben trai So GD / Dien giai
            x_ngay_max = min([c["xc"] for c in bo_cot if c["ten"] in ("so_ct", "noi_dung")] or [x_nd]) - 0.04
        bien_nho = min((c["xc"] for c in tien_cot), default=0.7) - 0.04       # so <= 3 chu so chi nhan sat cot tien
        x_tien_trai = min((c["xl"] for c in tien_cot if "xl" in c), default=bien_tien + 0.05) - 0.005
        y_truoc, dau_trang = None, True
        for k in range(bat_dau, len(dong)):
            ln = dong[k]
            c = chuan(ln["text"])
            # dong tong / so du dau / cuoi / chu ky / ghi chu
            if RX_TONG.search(c) and not _ngay_tok(ln["tu"][0]["text"]):
                ts = _so_dong(ln["tu"])
                if len(ts) >= 2 and ph.get("tong_no") is None:
                    ph["tong_no"], ph["tong_co"] = ts[-2], ts[-1]
                if hien:
                    dong_ra.append(hien)
                hien, khoa = None, True
                continue
            if RX_CUOI.search(c) and not _ngay_tok(ln["tu"][0]["text"]):
                ts = _so_dong(ln["tu"])
                if ts and ph.get("so_du_cuoi") is None:
                    ph["so_du_cuoi"] = ts[1] - ts[0] if (len(ts) == 2 and "so_du" not in ph.get("tieu_de", [])) else ts[-1]
                if hien:
                    dong_ra.append(hien)
                hien, khoa = None, True
                continue
            if RX_DAU.search(c) and not _ngay_tok(ln["tu"][0]["text"]):
                ts = _so_dong(ln["tu"])
                if ts and ph.get("so_du_dau") is None:
                    ph["so_du_dau"] = ts[1] - ts[0] if (len(ts) == 2 and "so_du" not in ph.get("tieu_de", [])) else ts[-1]
                continue
            if RX_HET.search(c):
                if hien:
                    dong_ra.append(hien)
                hien, khoa = None, True
                continue
            # phan loai tu
            o, ngay_ds, stt_tu, tien_ds = {}, [], "", []
            for w in ln["tu"]:
                xg = ax((w["x"] + w["width"] / 2.0) / W)
                t = str(w["text"])
                n_iso = _ngay_tok(t) if xg < x_ngay_max else ""
                if n_iso:
                    ngay_ds.append(n_iso)
                    continue
                if re.fullmatch(r"\d{1,2}:\d{2}(:\d{2})?", t.strip("_.,;")) and xg < x_nd:
                    continue                                   # gio giao dich
                if not ngay_ds and not stt_tu and w is ln["tu"][0] and re.fullmatch(r"\d{1,4}", t) and xg < tam.get("ngay", x_nd):
                    stt_tu = t
                    continue
                if xg > bien_tien:
                    x = _tien_tok(t)
                    nghiem = x is not None
                    if x is None and xg > bien_nho:
                        x = _tien_tok(t, so_nho=True)
                    if x is not None:
                        tien_ds.append((xg, x, nghiem, _alt_tien(w, x)))
                        continue
                    if xg > x_tien_trai:
                        continue                                # chu rac trong vung cot tien (con dau, duong ke)
                if xg < x_ngay_max and "noi_dung" in tam and x_nd > x_ngay_max:
                    continue                                    # chu rac trong vung ngay / STT (o ngay doc hong)
                ten = _cot_cua2(xg, dai)
                if ten in COT_TIEN or ten in ("ngay", "ngay_gt", "stt"):
                    ten = "so_ct" if ("so_ct" in tam and abs(xg - tam["so_ct"]) < abs(xg - x_nd)) else "noi_dung"
                if ten == "so_ct" and not re.search(r"\d", t) and "noi_dung" in tam:
                    ten = "noi_dung"                            # So GD luon co chu so; chu thuong la Dien giai
                o.setdefault(ten, []).append((xg, t))
            # So GD: MOT tu - uu tien dang ma giao dich (FT.., TT.., LD..), gan tam cot nhat; tu con lai tra ve Dien giai
            ung = o.pop("so_ct", [])
            if ung:
                chon = [u for u in ung if RX_MA_GD.match(u[1].strip("_.,;:"))] or ung
                ct = min(chon, key=lambda u: abs(u[0] - tam.get("so_ct", u[0])))
                o["so_ct"] = [ct]
                if len(ung) > 1 and "noi_dung" in tam:
                    o["noi_dung"] = sorted(o.get("noi_dung", []) + [u for u in ung if u is not ct])
            o = {t: " ".join(x[1] for x in sorted(v)) for t, v in o.items()}
            so_ct = re.sub(r"\s+", "", o.get("so_ct", "")).strip("_.,;:")
            nghiem_ds = [(xg, x) for xg, x, ng, _al in tien_ds if ng]
            # dong moi?
            moi = bool(ngay_ds)
            if not moi and hien is not None and not khoa:
                trung_tien = any(_cot_tien(xg, tien_cot) in hien["_tien"] for xg, _ in nghiem_ds)
                if (stt_tu and (RX_MA_GD.match(so_ct) or nghiem_ds)) or (so_ct and hien["so_ct"] and RX_MA_GD.match(so_ct) and nghiem_ds) \
                        or trung_tien:
                    moi = True
            if moi:
                if hien:
                    dong_ra.append(hien)
                khoa = False
                ngay = ngay_ds[0] if ngay_ds else (hien["ngay"] if hien else "")
                hien = dong_moi(trang=so_trang, ngay=ngay, ngay_gt=(ngay_ds[1] if len(ngay_ds) > 1 else ""), stt=stt_tu,
                                so_ct=so_ct[:60], noi_dung=" ".join(o.get("noi_dung", "").split()), doi_ung_ten=o.get("doi_ung", "")[:255],
                                bang_chung="trang %d dòng OCR %d" % (so_trang, k + 1))
                hien["ly_do"] = []
                hien["_tien"] = {}
                hien["_phan"] = len(phan) - 1
                hien["_ngay_doan"] = not ngay_ds
                if not ngay_ds:
                    _them_ly_do(hien, "Không đọc được ngày - tạm lấy ngày dòng trên, kiểm lại", "VANG")
                for xg, x, ng, al in tien_ds:
                    hien["_tien"].setdefault(_cot_tien(xg, tien_cot), []).append((xg, x, ng, al))
                y_truoc, dau_trang = ln["y"], False
                continue
            # dong noi tiep
            if hien is None or khoa:
                continue
            if not dau_trang and y_truoc is not None and ln["y"] - y_truoc > cao * 5.5:
                continue                                        # xa dong truoc (ghi chu / chu ky) - khong noi
            if o.get("noi_dung"):
                hien["noi_dung"] = (hien["noi_dung"] + " " + " ".join(o["noi_dung"].split())).strip()
            if o.get("doi_ung") and not hien["doi_ung_ten"]:
                hien["doi_ung_ten"] = o["doi_ung"][:255]
            if so_ct and not hien["so_ct"]:
                hien["so_ct"] = so_ct[:60]
            elif so_ct and len(hien["so_ct"]) < 40 and not RX_MA_GD.match(so_ct) and re.search(r"[\\/]$|^[\\/]", hien["so_ct"] + so_ct):
                hien["so_ct"] = (hien["so_ct"] + so_ct)[:60]
            for xg, x, ng, al in tien_ds:
                hien["_tien"].setdefault(_cot_tien(xg, tien_cot), []).append((xg, x, ng, al))
            y_truoc, dau_trang = ln["y"], False
    if hien:
        dong_ra.append(hien)
    # so tien theo cot. So du: chi so nghiem (co dau phan cach) hoac 0; so nho (<= 3 chu so) chi la so tien khi khong co so nghiem
    for d in dong_ra:
        tt = d.pop("_tien", {})
        ds = sorted([(xg, x, ten, ng, al) for ten, v in tt.items() for xg, x, ng, al in v], key=lambda t: t[:4])
        tieu_de = phan[d["_phan"]].get("tieu_de") or []
        co_du = "so_du" in tieu_de or not tieu_de
        ng_ds = [t for t in ds if t[3]]
        if co_du:
            ung_du = [t for t in ng_ds if t[2] == "so_du"] or ([ng_ds[-1]] if len(ng_ds) >= 2 else [])
            if not ung_du:
                ung_du = [t for t in ds if t[2] == "so_du" and t[1] == 0]
            if ung_du:
                d["so_du"] = ung_du[-1][1]
                d["_ung_du"] = list(ung_du[-1][4] or [])
                ds = [t for t in ds if t is not ung_du[-1]]
                ng_ds = [t for t in ds if t[3]]
        tien_ = ng_ds or [t for t in ds if t[1] > 0 and (t[2] != "so_du" or not co_du)]
        if tien_:
            xg, x, ten, ng, al = tien_[-1]
            d[ten if ten in ("tien_ra", "tien_vao") else "tien_vao"] = abs(x)
            d["_ung_tien"] = [abs(v) for v in al or []]
            if len(tien_) > 1:
                _them_ly_do(d, "Có %d số trong vùng cột tiền - kiểm lại" % (len(tien_) + (1 if d["so_du"] is not None else 0)), "VANG")
    # GD66: dong 'ma' (chi co so du: o so du in dam lech xuong dong duoi / OCR tach dong; khong ngay, so CT, so tien) -> gop vao dong tren
    gon = []
    for d in dong_ra:
        p = gon[-1] if gon else None
        if p is not None and p["_phan"] == d["_phan"] and d.get("_ngay_doan") and not d["so_ct"] and not d["tien_ra"] \
                and not d["tien_vao"] and d["so_du"] is not None and len(re.sub(r"\W", "", d["noi_dung"])) < 4 \
                and (p["so_du"] is None or bang(p["so_du"], d["so_du"])):
            p["so_du"] = d["so_du"]
            p["_ung_du"] = d.get("_ung_du") or p.get("_ung_du")
            continue
        gon.append(d)
    dong_ra[:] = gon
    # thong tin chung + tai khoan cua tung phan
    vb = chuan("\n".join(van_ban))
    if not dau["ngan_hang"]:
        for rx, ma in (("VIETCOMBANK|VCB", "VCB"), ("BIDV|DAU TU VA PHAT TRIEN", "BIDV"), ("VIETINBANK|CONG THUONG", "CTG"),
                       ("TECHCOMBANK|KY THUONG", "TCB"), ("MBBANK|MB BANK|QUAN DOI|MILITARY", "MBB"), ("\\bACB\\b|A CHAU|ASIA COMMERCIAL", "ACB"),
                       ("VPBANK|VP BANK", "VPB"), ("SACOMBANK|SAI GON THUONG TIN", "STB"), ("TPBANK|TIEN PHONG", "TPB"), ("\\bSHB\\b", "SHB"),
                       ("HDBANK", "HDB"), ("EXIMBANK|XUAT NHAP KHAU", "EIB"), ("\\bOCB\\b|PHUONG DONG", "OCB"), ("\\bMSB\\b|MARITIME|HANG HAI", "MSB"),
                       ("\\bVIB\\b", "VIB"), ("SEABANK", "SEAB"), ("ABBANK", "ABB"), ("NAM A BANK", "NAB"), ("AGRIBANK|NONG NGHIEP", "AGRI")):
            # uu tien ngan hang o khoi dau sao ke (noi dung giao dich co ten ngan hang doi ung)
            if re.search(rx, " ".join(p.get("_vb", "") for p in phan)):
                dau["ngan_hang"] = ma
                break
        if not dau["ngan_hang"]:
            m = re.search(r"SACOMBANK|VIETCOMBANK|VIETINBANK|TECHCOMBANK|AGRIBANK|BIDV", vb)
            dau["ngan_hang"] = {"SACOMBANK": "STB", "VIETCOMBANK": "VCB", "VIETINBANK": "CTG", "TECHCOMBANK": "TCB", "AGRIBANK": "AGRI",
                                "BIDV": "BIDV"}.get(m.group(0), "") if m else ""
    _gan_tai_khoan(phan, dong_ra)
    for d in dong_ra:
        d["nhom"] = phan[d["_phan"]]["nhom"]
        d["so_tk_phan"] = phan[d["_phan"]]["so_tk"]
    _noi_chuoi(phan, dong_ra)
    for p in phan:
        for x in p.get("canh_bao_chuoi") or []:
            dau["canh_bao"].append("TK %s (%s - %s): %s" % (p.get("so_tk") or "?", ngay_vn(p.get("ky_tu") or ""), ngay_vn(p.get("ky_den") or ""), x))
    for i, d in enumerate(dong_ra):
        d["thu_tu"] = i + 1
    dau["phan"] = phan
    _dau_tu_phan(dau, phan, list(range(len(phan))))      # xem chung (mot tai khoan); nhieu TK -> tach_tai_khoan
    dau["so_trang"] = len(doc.get("pages") or [])
    dau["canh_bao"].insert(0, "OCR Offline: XANH = số tiền đã kiểm chéo bằng chuỗi số dư / tổng phát sinh (số dư đọc sai do con dấu "
                              "đã tính lại theo chuỗi); VÀNG = cần xem lại; nội dung diễn giải luôn phải đối chiếu sao kê gốc")
    if not dong_ra:
        dau["canh_bao"].append("Không tái tạo được dòng giao dịch từ OCR Offline - thử AI đọc ảnh hoặc xin ngân hàng file Excel")
    return dau, dong_ra


def _cot_tien(xg, tien_cot):
    if not tien_cot:
        return "tien_vao"
    return min(tien_cot, key=lambda c: abs(c["xc"] - xg))["ten"]


def _giong(a, b):
    import difflib
    return difflib.SequenceMatcher(None, a, b).ratio()


def _gan_tai_khoan(phan, dong):
    """Moi phan -> so TK + nhom tai khoan. So TK doc o khoi dau (OCR co the sai vai chu so) duoc doi chieu voi so TK xuat hien
       trong noi dung giao dich ("... toi 0602... CTY ... tai Sacombank" - thuong doc dung, nhieu lan) va so TK doc duoc o
       phan khac; chi doc duoc duoi so -> ghep TK da biet; khong doc duoc -> noi tiep so du / cung mau voi phan ke ben."""
    from collections import Counter
    nd = Counter(m for d in dong for m in re.findall(r"(?<!\d)(\d{9,16})(?!\d)", d["noi_dung"]))
    doc_dau = Counter(p["so_tk"] for p in phan if p["so_tk"] and not p["so_tk"].startswith("~"))
    for p in phan:
        tk = p["so_tk"]
        if not tk or tk.startswith("~"):
            # GD66: so TK o khoi dau bi con dau de / OCR hong -> TK chinh chu xuat hien trong giao dich cua phan nay
            #   ("CHI LAI TK TIEN GUI 0602...", "STB;0602...;", "... toi 0602... CTY ...")
            pi_ = phan.index(p)
            tu = Counter(m for d in dong if d.get("_phan") == pi_ for m in
                         re.findall(r"(?:TIEN GUI|STB;|\bTOI)\s*(\d{9,16})(?!\d)", bo_dau(d["noi_dung"]).upper()))
            if tu:
                so, lan = tu.most_common(1)[0]
                if (not tk or so.endswith(tk[1:][-4:])) and (lan >= 2 or any("TIEN GUI " + so in bo_dau(d["noi_dung"]).upper()
                                                                            for d in dong if d.get("_phan") == pi_)):
                    tk = so
                    p["so_tk"] = so
        if tk and not tk.startswith("~"):
            ung = [(n, nd[n] + 2 * doc_dau[n], _giong(tk, n)) for n in set(nd) | set(doc_dau) if _giong(tk, n) >= 0.75]
            if ung:
                tk = max(ung, key=lambda x: (x[1], x[2]))[0]
        elif tk.startswith("~"):
            duoi = tk[1:][-5:]
            ung = [n for n in set(nd) | set(doc_dau) if len(duoi) >= 3 and n.endswith(duoi)]
            tk = max(ung, key=lambda n: (doc_dau[n], nd[n])) if ung else ""
        p["so_tk"] = tk
    nhom = []
    for pi, p in enumerate(phan):
        tk = p["so_tk"]
        g = next((k for k, t in enumerate(nhom) if t and tk and (t == tk or _giong(t, tk) >= 0.85)), None)
        if g is None:
            nhom.append(tk)
            g = len(nhom) - 1
        p["_g"] = g
    # nhom chua biet so TK (hoac so TK doc sai nhe): ghep vao phan ke ben khi so du noi tiep / cung mau cot
    def du_cuoi(pi):
        p = phan[pi]
        if p.get("so_du_cuoi") is not None:
            return p["so_du_cuoi"]
        ds = [d for d in dong if d["_phan"] == pi and d["so_du"] is not None]
        return ds[-1]["so_du"] if ds else None

    def noi(pa, pb):
        """phan pb noi tiep so du cua phan pa?"""
        a = du_cuoi(pa)
        if a is None:
            return False
        if phan[pb].get("so_du_dau") is not None and bang(a, phan[pb]["so_du_dau"]):
            return True
        d = next((d for d in dong if d["_phan"] == pb and d["so_du"] is not None and (d["tien_ra"] or d["tien_vao"])), None)
        return d is not None and abs(abs(d["so_du"] - a) - (d["tien_ra"] or d["tien_vao"])) <= SAI_SO

    loi = lambda p: frozenset(p.get("tieu_de") or []) - {"stt", "ngay_gt", "doi_ung", "so_ct"}
    for pi in range(1, len(phan)):
        a, b = phan[pi - 1], phan[pi]
        if a["_g"] == b["_g"]:
            continue
        ta, tb = nhom[a["_g"]], nhom[b["_g"]]
        hop = False
        if not ta or not tb:
            hop = noi(pi - 1, pi) or (not tb and loi(a) == loi(b) and b.get("so_du_dau") is None)
        elif _giong(ta, tb) >= 0.6 and noi(pi - 1, pi):
            hop = True
        if hop:
            giu, bo = (a["_g"], b["_g"]) if (ta or not tb) else (b["_g"], a["_g"])
            if ta and tb and nd[tb] + doc_dau[tb] > nd[ta] + doc_dau[ta]:
                nhom[a["_g"]] = tb
            for q in phan:
                if q["_g"] == bo:
                    q["_g"] = giu
    for pi in range(len(phan) - 2, -1, -1):          # phan dau chua biet TK, phan sau cung mau / noi tiep co TK
        a, b = phan[pi], phan[pi + 1]
        if not nhom[a["_g"]] and nhom[b["_g"]] and a["_g"] != b["_g"] and (noi(pi, pi + 1) or loi(a) == loi(b)):
            bo = a["_g"]
            for q in phan:
                if q["_g"] == bo:
                    q["_g"] = b["_g"]
    for p in phan:
        p["nhom"] = nhom[p["_g"]] or "?%d" % (p["_g"] + 1)
        p["so_tk"] = nhom[p["_g"]]


def _lech_chu_so(a, b):
    """So chu so phai sua (them / bot / thay - khoang cach Levenshtein) de bien so a thanh so b: OCR doc sai thuong chi lech
       1 chu so (4 <-> 1, 9 <-> 0, mat so 1 dau)."""
    x, y = "%d" % round(abs(a or 0)), "%d" % round(abs(b or 0))
    truoc = list(range(len(y) + 1))
    for i, cx in enumerate(x, 1):
        hang = [i]
        for j, cy in enumerate(y, 1):
            hang.append(min(truoc[j] + 1, hang[j - 1] + 1, truoc[j - 1] + (cx != cy)))
        truoc = hang
    return truoc[-1]


def _nghi(d, ly_do, tt="VANG"):
    _them_ly_do(d, ly_do, tt)
    d["_nghi"] = True


def _giai_chuoi(phan, dong, chuoi):
    """GD66: giai chuoi so du cua MOT doan lien tuc (mot tai khoan, cac phan co cot so du).
       chuoi: [nut] - nut dong {"i", "A": [so tien ung vien], "s": +1 vao / -1 ra / 0, "B": [so du ung vien]}, nut ao (so du dau /
       cuoi ky doc o dau / cuoi phan) {"i": None, "A": [0], "s": 0, "B": [...], "phan", "loai"}.
       1) Chon so du tung nut (Viterbi) cho nhieu canh khop nhat; 2) nut 'neo' = so du nam tren mot canh khop;
       3) giua hai neo: tong so tien = chenh lech so du -> tinh lai so du o giua (OCR doc sai so du); chi mot dong khong doc duoc
          so tien -> suy; mot so tien doc sai -> sua khi giong so goc; khong giai duoc -> danh dau kiem lai."""
    n = len(chuoi)
    if not n:
        return

    def khop(b1, b2, nut):
        if b1 is None or b2 is None:
            return None
        for a in (nut["A"] or []):
            if abs(abs(b2 - b1) - a) <= SAI_SO:
                return a
        return None

    # 1) Viterbi tren ung vien so du
    ung = [[(b, 0.0 if k == 0 else 0.2) for k, b in enumerate(nut["B"])] or [(None, 0.0)] for nut in chuoi]
    diem = [[-p for _, p in ung[0]]]
    ve = [[None] * len(ung[0])]
    for j in range(1, n):
        dj, vj = [], []
        for b, p in ung[j]:
            tot, arg = None, 0
            for k, (b0, _) in enumerate(ung[j - 1]):
                s = diem[-1][k] + (1.0 if khop(b0, b, chuoi[j]) is not None else 0.0)
                if tot is None or s > tot:
                    tot, arg = s, k
            dj.append(tot - p)
            vj.append(arg)
        diem.append(dj)
        ve.append(vj)
    k = max(range(len(diem[-1])), key=lambda t: diem[-1][t])
    chon = [None] * n
    for j in range(n - 1, -1, -1):
        chon[j] = ung[j][k][0]
        if j:
            k = ve[j][k]
    ok = [False] * n
    for j in range(1, n):
        a = khop(chon[j - 1], chon[j], chuoi[j])
        if a is not None:
            ok[j] = True
            nut = chuoi[j]
            nut["a"], nut["sd"] = a, (1 if chon[j] - chon[j - 1] > 0 else (-1 if chon[j] < chon[j - 1] else nut["s"]))
    neo = [chon[j] is not None and (ok[j] or (j + 1 < n and ok[j + 1])) for j in range(n)]
    for j in range(n):
        chuoi[j]["kq"] = chon[j] if neo[j] else None
        chuoi[j]["tin"] = ok[j] and neo[j - 1] if j else False

    def dat(nut, a, s):
        nut["a"], nut["sd"] = a, s

    # 3) doan giua hai neo
    # neo yeu: so du dau / cuoi ky in o dau / cuoi phan (co the doc sai) - chi dung khi tong so tien khop dung chenh lech
    ds_neo = [j for j in range(n) if neo[j] or (chuoi[j]["i"] is None and chon[j] is not None)]
    for L, R in zip(ds_neo, ds_neo[1:]):
        if R == L + 1 and ok[R]:
            continue
        yeu = not (neo[L] and neo[R])
        doan = chuoi[L + 1:R + 1]
        delta = chon[R] - chon[L]
        that = [x for x in doan if x["i"] is not None]
        chua = [x for x in that if not x["A"]]
        giai = None
        if not chua:
            # (a) tong so tien (co the doi chieu cot) = chenh lech so du
            lua = []
            for x in doan:
                if x["i"] is None:
                    lua.append([(0.0, 0, 0.0)])
                    continue
                o = []
                for ka, a in enumerate(x["A"]):
                    for s in ((x["s"],) if x["s"] else (1, -1)):
                        o.append((a, s, 0.3 * ka))
                    if x["s"]:
                        o.append((a, -x["s"], 1.0 + 0.3 * ka))
                lua.append(o)
            so_to_hop = 1
            for o in lua:
                so_to_hop *= len(o)
            if so_to_hop <= 4096:
                tot = []

                def duyet(j, tong, phat, chon_):
                    if j == len(lua):
                        if abs(tong - delta) <= SAI_SO:
                            tot.append((phat, list(chon_)))
                        return
                    for a, s, p in lua[j]:
                        chon_.append((a, s))
                        duyet(j + 1, tong + s * a, phat + p, chon_)
                        chon_.pop()
                duyet(0, 0.0, 0.0, [])
                tot.sort(key=lambda t: t[0])
                if tot and (len(tot) == 1 or tot[1][0] > tot[0][0]):
                    giai = "tong"
                    for x, (a, s) in zip(doan, tot[0][1]):
                        dat(x, a, s)
        if giai is None and yeu:
            continue
        if yeu:
            chuoi[L]["kq"], chuoi[R]["kq"] = chon[L], chon[R]
        if giai is None and len(chua) == 1 and all(x["s"] for x in that if x is not chua[0]):
            # (b) mot dong khong doc duoc so tien
            con = sum(x["s"] * x["A"][0] for x in that if x is not chua[0])
            v = delta - con
            if abs(v) <= SAI_SO:
                u = chua[0]
                for x in that:
                    if x is not u:
                        dat(x, x["A"][0], x["s"])
                giai = "thua"
                _nghi(dong[u["i"]], "Dòng không có số tiền, số dư không đổi - có thể là dòng thừa do OCR tách dòng, kiểm lại")
            else:
                u = chua[0]
                dat(u, abs(v), 1 if v > 0 else -1)
                for x in that:
                    if x is not u:
                        dat(x, x["A"][0], x["s"])
                giai = "thieu"
                d = dong[u["i"]]
                if len(that) == 1:
                    _them_ly_do(d, "Không đọc được số tiền - suy từ chênh lệch số dư (hai đầu đã khớp chuỗi)")
                else:
                    _nghi(d, "Không đọc được số tiền - suy từ chênh lệch số dư, kiểm lại")
        if giai is None and not chua and that and all(x["s"] for x in that):
            # (c) mot so tien doc sai: thay so do bang phan con thieu; chon dong co so moi giong so goc nhat
            tong = sum(x["s"] * x["A"][0] for x in that)
            best = None
            for u in that:
                v = delta - (tong - u["s"] * u["A"][0])
                if abs(v) <= SAI_SO:
                    continue
                g = 1 if any(bang(abs(v), t) for t in u["A"][1:]) else -_lech_chu_so(v, u["A"][0])     # GD67: trung so doc lai o
                # so du OCR o giua doan khop voi chuoi sau khi sua
                chay, trung = chon[L], 0
                for x in doan[:-1]:
                    chay += (abs(v) * (1 if v > 0 else -1)) if x is u else (x["s"] * x["A"][0] if x["i"] is not None else 0.0)
                    if x["B"] and abs(x["B"][0] - chay) <= SAI_SO:
                        trung += 1
                diem_ = (trung, g)
                if best is None or diem_ > best[0]:
                    best = (diem_, u, v)
            if best is not None and best[0][1] == -2:
                # lech 2 chu so: co the OCR doc sai 2 chu hoac thieu dong -> KHONG sua, chi goi y
                _nghi(dong[best[1]["i"]], "Chuỗi số dư cần %s ở dòng này (OCR đọc %s) - OCR đọc sai hoặc thiếu dòng, kiểm lại" % (
                    fmt(abs(best[2])), fmt(best[1]["A"][0])))
            elif best is not None and best[0][1] >= -1:
                (trung, g), u, v = best
                for x in that:
                    if x is u:
                        dat(x, abs(v), 1 if v > 0 else -1)
                    else:
                        dat(x, x["A"][0], x["s"])
                giai = "sua"
                d = dong[u["i"]]
                msg = "Số tiền OCR đọc %s - sửa theo chuỗi số dư thành %s" % (fmt(u["A"][0]), fmt(abs(v)))
                if g == 1:
                    msg = "Số tiền OCR đọc %s - đọc lại ô được %s, khớp chuỗi số dư" % (fmt(u["A"][0]), fmt(abs(v)))
                # so du OCR o giua doan phai trung chuoi moi hoac chi lech mot chu so (con dau / mo) thi moi tin
                chay, hop = chon[L], True
                for x in doan[:-1]:
                    chay += (x.get("sd") or 0) * (x.get("a") or 0) if x["i"] is not None else 0.0
                    if x["B"] and not bang(x["B"][0], chay) and _lech_chu_so(x["B"][0], chay) > 2:
                        hop = False
                if g >= -1 and hop and (len(that) == 1 or trung >= 1 or len(that) <= 2):
                    _them_ly_do(d, msg)
                else:
                    _nghi(d, msg + ", kiểm lại")
        if giai is None:
            for x in that:
                if x["A"]:
                    dat(x, x["A"][0], x["s"] or 1)
                _nghi(dong[x["i"]], "Chuỗi số dư lệch %s giữa hai số dư đã khớp - OCR đọc sai hoặc thiếu dòng, kiểm lại" % fmt(
                    delta - sum((x2.get("sd") or 0) * (x2.get("a") or 0) for x2 in that)))
            continue
        # tinh lai so du o giua doan
        chay = chon[L]
        for x in doan[:-1]:
            chay += (x.get("sd") or 0) * (x.get("a") or 0) if x["i"] is not None else 0.0
            x["kq"] = chay
            x["tin"] = giai in ("tong", "sua", "thieu", "thua")
        doan[-1]["tin"] = True
        if giai in ("thieu", "sua", "thua"):
            for x in that:
                x["tin"] = x["tin"] and not dong[x["i"]].get("_nghi")
    # dau / duoi chuoi (truoc neo dau, sau neo cuoi): tinh tu so tien, khong kiem duoc
    if ds_neo:
        f = ds_neo[0]
        for j in range(f - 1, -1, -1):
            x = chuoi[j + 1]
            if x["i"] is not None and x["A"] and x["s"] and chuoi[j + 1]["kq"] is not None:
                chuoi[j]["kq"] = chuoi[j + 1]["kq"] - x["s"] * x["A"][0]
            elif x["i"] is None and chuoi[j + 1]["kq"] is not None:
                chuoi[j]["kq"] = chuoi[j + 1]["kq"]
        f = ds_neo[-1]
        for j in range(f + 1, n):
            x = chuoi[j]
            if chuoi[j - 1]["kq"] is None:
                break
            if x["i"] is None:
                x["kq"] = chuoi[j - 1]["kq"]
            elif x["A"] and x["s"]:
                x["kq"] = chuoi[j - 1]["kq"] + x["s"] * x["A"][0]
    else:
        truoc = None
        for x in chuoi:
            if x["B"]:
                truoc = x["B"][0]
            elif truoc is not None and x["i"] is not None and x["A"] and x["s"]:
                truoc = truoc + x["s"] * x["A"][0]
            x["kq"] = truoc
    # ghi ket qua vao dong
    for x in chuoi:
        if x["i"] is None:
            if x["B"] and x["kq"] is not None and not bang(x["B"][0], x["kq"]) and x["loai"] in ("dau", "cuoi"):
                ph = phan[x["phan"]]
                ph.setdefault("canh_bao_chuoi", []).append("Số dư %s kỳ đọc %s, tính theo chuỗi giao dịch %s" % (
                    "đầu" if x["loai"] == "dau" else "cuối", fmt(x["B"][0]), fmt(x["kq"])))
            continue
        d = dong[x["i"]]
        a, s = x.get("a"), x.get("sd")
        if a is None and x["A"]:
            a, s = x["A"][0], x["s"]
        if a:
            if x["s"] and s and s != x["s"]:
                _them_ly_do(d, "Đổi cột %s -> %s theo chuỗi số dư" % ("tiền ra" if x["s"] < 0 else "tiền vào",
                                                                     "tiền vào" if s > 0 else "tiền ra"))
            d["tien_ra"], d["tien_vao"] = (0.0, a) if (s or 1) > 0 else (a, 0.0)
            if x["A"] and not bang(a, x["A"][0]) and any(bang(a, t) for t in x["A"][1:]) and \
                    not any("đọc lại ô" in r for r in d.get("ly_do") or []):
                _them_ly_do(d, "Số tiền OCR đọc %s - đọc lại ô được %s, khớp chuỗi số dư" % (fmt(x["A"][0]), fmt(a)))
        cu = x["B"][0] if x["B"] else None
        if x["kq"] is not None:
            if cu is None:
                _them_ly_do(d, "Không đọc được số dư - tính theo chuỗi")
            elif not bang(cu, x["kq"]):
                _them_ly_do(d, ("Số dư OCR đọc %s - đọc lại ô được %s, khớp chuỗi" if any(bang(x["kq"], t) for t in x["B"][1:]) else
                                "Số dư OCR đọc %s - tính lại theo chuỗi thành %s") % (fmt(cu), fmt(x["kq"])))
            d["so_du"] = x["kq"]
        else:
            d["so_du"] = cu
        d["_kiem"] = bool(x.get("tin")) and bool(d["tien_ra"] or d["tien_vao"])
        if not d["_kiem"] and not d.get("_nghi"):
            _them_ly_do(d, "Không kiểm được theo chuỗi số dư", "VANG")


def _sua_ngay(phan, dong):
    """GD66: ngay ngoai ky sao ke do OCR doc sai mot chu so (15/04/2926, 24/08/2026 trong ky thang 3): thu thay nam / thang theo
       ky sao ke va thang cua dong truoc / sau (sao ke xep theo ngay); chi sua khi ra DUNG MOT ngay nam trong ky, dung thu tu."""
    from datetime import date as _ngay
    for i, d in enumerate(dong):
        ph = phan[d["_phan"]]
        a, b = ph.get("ky_tu") or "", ph.get("ky_den") or ""
        if not d["ngay"] or not a or not b or a <= d["ngay"] <= b or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", d["ngay"]):
            continue
        if d.get("ngay_gt") and a <= d["ngay_gt"] <= b:
            # ngan hang ghi so dau thang sau nhung ngay hieu luc trong ky (lai tien gui 01/04, HL 31/03) - sao ke ky nay da gom
            _them_ly_do(d, "Ngày GD %s ngoài kỳ - lấy ngày hiệu lực %s (trong kỳ, số dư cuối kỳ sao kê đã gồm)" % (
                ngay_vn(d["ngay"]), ngay_vn(d["ngay_gt"])))
            d["ngay"] = d["ngay_gt"]
            continue
        cung = {id(x) for x in dong if x["_phan"] == d["_phan"] and x["ngay"] and a <= x["ngay"] <= b}
        truoc = next((x["ngay"] for x in reversed(dong[:i]) if id(x) in cung), a)
        sau = next((x["ngay"] for x in dong[i + 1:] if id(x) in cung), b)
        _, m, dd = d["ngay"].split("-")
        ung = set()
        for yy in {a[:4], b[:4]}:
            for mm in {m, a[5:7], b[5:7], truoc[5:7], sau[5:7]}:
                try:
                    c = _ngay(int(yy), int(mm), int(dd)).isoformat()
                except ValueError:
                    continue
                if truoc <= c <= sau and a <= c <= b:
                    ung.add(c)
        if len(ung) == 1:
            c = ung.pop()
            _them_ly_do(d, "Ngày OCR đọc %s - sửa theo kỳ sao kê / dòng trước sau thành %s" % (ngay_vn(d["ngay"]), ngay_vn(c)))
            d["ngay"] = c


def _khop_tong_ung_vien(ds, cot, dich, toi_da=3):
    """GD67: mau khong co cot so du - tong cot (tien_ra / tien_vao) lech tong in tren sao ke: thu thay 1 .. toi_da dong bang so
       doc lai (_ung_tien). Dung MOT cach it dong nhat khop dung tong -> tra ve [(dong, so moi)], khong thi []."""
    import itertools
    lech = dich - sum(d[cot] for d in ds)
    if abs(lech) <= SAI_SO:
        return []
    ung = [(d, [v - d[cot] for v in d.get("_ung_tien") or []]) for d in ds if d[cot] and d.get("_ung_tien")]
    for k in range(1, min(toi_da, len(ung)) + 1):
        tim = []
        for bo in itertools.combinations(ung, k):
            for chon in itertools.product(*[x[1] for x in bo]):
                if abs(sum(chon) - lech) <= SAI_SO:
                    tim.append([(x[0], x[0][cot] + c) for x, c in zip(bo, chon)])
                    if len(tim) > 1:
                        break
            if len(tim) > 1:
                break
        if len(tim) == 1:
            return tim[0]
        if tim:
            return []
    return []


def _noi_chuoi(phan, dong):
    """GD66: chuoi so du tung nhom tai khoan giai bang _giai_chuoi (chon so du, neo, sua doan). Phan khong co cot so du:
       kiem cheo bang tong phat sinh. XANH = so tien da kiem cheo va khong con nghi van (ngay doc duoc, trong ky)."""
    co_du = lambda d: "so_du" in (phan[d["_phan"]].get("tieu_de") or ["so_du"])
    for d in dong:
        d["_kiem"] = False
    nhom = []
    for d in dong:
        if d["nhom"] not in nhom:
            nhom.append(d["nhom"])
    for nh in nhom:
        chuoi, pi_truoc = [], None
        ds = [i for i, d in enumerate(dong) if d["nhom"] == nh]
        for k, i in enumerate(ds):
            d = dong[i]
            pi = d["_phan"]
            ph = phan[pi]
            if not co_du(d):
                d["so_du"] = None
                if chuoi:
                    _giai_chuoi(phan, dong, chuoi)
                chuoi, pi_truoc = [], pi
                continue
            if pi != pi_truoc:
                if ph.get("so_du_dau") is not None:
                    B_ = [ph["so_du_dau"]]
                    # GD68: so du dau ky doc sai ("$59,824,546") - so du cuoi ky phan truoc cung TK in tren cung PDF la ung vien
                    if pi_truoc is not None and co_du(dong[ds[k - 1]]) and phan[pi_truoc].get("so_du_cuoi") is not None and \
                            not bang(phan[pi_truoc]["so_du_cuoi"], B_[0]):
                        B_.append(phan[pi_truoc]["so_du_cuoi"])
                    chuoi.append({"i": None, "A": [0.0], "s": 0, "B": B_, "phan": pi, "loai": "dau"})
                elif not chuoi and pi_truoc is not None and phan[pi_truoc].get("so_du_cuoi") is not None:
                    # phan truoc (mau khong co cot so du) co so du cuoi ky -> so du dau cua phan nay
                    chuoi.append({"i": None, "A": [0.0], "s": 0, "B": [phan[pi_truoc]["so_du_cuoi"]], "phan": pi, "loai": "dau_truoc"})
                pi_truoc = pi
            A = d["tien_ra"] or d["tien_vao"]
            ung_a = [A] if A else []
            ung_a += [v for v in d.get("_ung_tien") or [] if v and all(not bang(v, u) for u in ung_a)]
            ung_b = [d["so_du"]] if d["so_du"] is not None else []
            ung_b += [v for v in d.get("_ung_du") or [] if all(not bang(v, u) for u in ung_b)]
            chuoi.append({"i": i, "A": ung_a, "s": 1 if d["tien_vao"] else (-1 if d["tien_ra"] else 0), "B": ung_b, "phan": pi})
            cuoi_phan = k + 1 == len(ds) or dong[ds[k + 1]]["_phan"] != pi
            if cuoi_phan and ph.get("so_du_cuoi") is not None:
                chuoi.append({"i": None, "A": [0.0], "s": 0, "B": [ph["so_du_cuoi"]], "phan": pi, "loai": "cuoi"})
        if chuoi:
            _giai_chuoi(phan, dong, chuoi)
    _sua_ngay(phan, dong)
    # ngay trong ky
    for d in dong:
        ph = phan[d["_phan"]]
        if not d["ngay"]:
            _nghi(d, "Thiếu ngày", "DO_NHAT")
        elif ph.get("ky_tu") and ph.get("ky_den") and not (ph["ky_tu"] <= d["ngay"] <= ph["ky_den"]):
            _nghi(d, "Ngày %s ngoài kỳ sao kê %s - %s (OCR đọc sai ngày?)" % (ngay_vn(d["ngay"]), ngay_vn(ph["ky_tu"]), ngay_vn(ph["ky_den"])))
        if not d["tien_ra"] and not d["tien_vao"]:
            _nghi(d, "Thiếu số tiền", "DO_NHAT")
        if d.get("_ngay_doan"):
            d["_nghi"] = True
    # tong phat sinh cua phan: chi giu khi hop ly (dau + co - no = cuoi); phan khong co cot so du: tong khop -> kiem cheo
    for pi, ph in enumerate(phan):
        ds = [d for d in dong if d["_phan"] == pi]
        dau_ = ph["so_du_dau"] if ph.get("so_du_dau") is not None else ph.get("_dau_dung")
        if ph.get("tong_no") is not None and dau_ is not None and ph.get("so_du_cuoi") is not None and \
                not bang(dau_ + ph["tong_co"] - ph["tong_no"], ph["so_du_cuoi"]):
            ph["canh_bao_tong"] = "Tổng phát sinh đọc được (Nợ %s / Có %s) không khớp số dư đầu / cuối - bỏ qua, kiểm tay" % (
                fmt(ph["tong_no"]), fmt(ph["tong_co"]))
            ph["tong_no"] = ph["tong_co"] = None
        if not ds or "so_du" in (ph.get("tieu_de") or ["so_du"]):
            continue
        tn, tc = sum(d["tien_ra"] for d in ds), sum(d["tien_vao"] for d in ds)
        if ph.get("tong_no") is not None and ph.get("tong_co") is not None and not (bang(tn, ph["tong_no"]) and bang(tc, ph["tong_co"])):
            # GD67: thay so doc lai tung o cho it dong nhat de tong khop (chi khi dung mot cach)
            for cot, dich in (("tien_ra", ph["tong_no"]), ("tien_vao", ph["tong_co"])):
                for d, v in _khop_tong_ung_vien(ds, cot, dich):
                    _them_ly_do(d, "Số tiền OCR đọc %s - đọc lại ô được %s, khớp tổng phát sinh in trên sao kê" % (fmt(d[cot]), fmt(v)))
                    d[cot] = v
            tn, tc = sum(d["tien_ra"] for d in ds), sum(d["tien_vao"] for d in ds)
        if ph.get("tong_no") is not None and ph.get("tong_co") is not None and bang(tn, ph["tong_no"]) and bang(tc, ph["tong_co"]):
            for d in ds:
                if d["ngay"] and (d["tien_ra"] or d["tien_vao"]):
                    d["_kiem"] = True
        else:
            ben_khop = [c for c, t, dich in (("tien_ra", tn, ph.get("tong_no")), ("tien_vao", tc, ph.get("tong_co")))
                        if dich is not None and bang(t, dich)]
            for d in ds:
                if d["ngay"] and any(d[c] for c in ben_khop):
                    d["_kiem"] = True
                    _them_ly_do(d, "Tổng tiền %s các dòng khớp tổng in trên sao kê" % ("ra" if d["tien_ra"] else "vào"))
            if ph.get("tong_no") is not None and ph.get("tong_co") is not None:
                ph.setdefault("canh_bao_chuoi", []).append(
                    "Tổng các dòng (ra %s / vào %s) khác tổng phát sinh in trên sao kê (Nợ %s / Có %s): ra lệch %s, vào lệch %s" % (
                        fmt(tn), fmt(tc), fmt(ph["tong_no"]), fmt(ph["tong_co"]), fmt(tn - ph["tong_no"]), fmt(tc - ph["tong_co"])))
                # goi y: chi mot dong ma bot / them phan lech thi ra so gan giong so doc (lech mot chu so) -> ghi goi y, KHONG tu sua
                for cot, lech in (("tien_ra", tn - ph["tong_no"]), ("tien_vao", tc - ph["tong_co"])):
                    if abs(lech) <= SAI_SO:
                        continue
                    ung = [d for d in ds if d[cot] and d[cot] - lech > 0 and _lech_chu_so(d[cot] - lech, d[cot]) <= 1]
                    if 1 <= len(ung) <= 3:
                        for d in ung:
                            _nghi(d, "Tổng %s lệch %s: nếu số này là %s thì khớp tổng in trên sao kê%s - kiểm lại" % (
                                "ra" if cot == "tien_ra" else "vào", fmt(lech), fmt(d[cot] - lech),
                                "" if len(ung) == 1 else " (một trong %d dòng nghi)" % len(ung)))
            # GD67: dong co so doc lai o khac so dang lay, ben tong con lech (hoac khong co tong) -> goi y cu the
            for d in ds:
                for cot, dich in (("tien_ra", ph.get("tong_no")), ("tien_vao", ph.get("tong_co"))):
                    if d[cot] and d.get("_ung_tien") and (dich is None or not bang(sum(x[cot] for x in ds), dich)):
                        _nghi(d, "OCR đọc lại ô số tiền được %s (đang lấy %s) - kiểm lại" % (
                            " / ".join(fmt(v) for v in d["_ung_tien"][:3]), fmt(d[cot])))
            for d in ds:
                a = d["tien_ra"] or d["tien_vao"]
                if a and a < 1000:
                    _nghi(d, "Số tiền đọc được rất nhỏ (%s) - OCR có thể đọc sót chữ số (con dấu / mờ), kiểm lại" % fmt(a))
                if not d["_kiem"]:
                    _them_ly_do(d, "Mẫu không có cột số dư: chỉ kiểm được bằng tổng phát sinh (chưa khớp)")
    for d in dong:
        if d["_kiem"] and not d.get("_nghi") and d["trang_thai"] != "DO_NHAT":
            d["trang_thai"] = "XANH"
            d["tin_cay"] = 90
            d["ly_do"] = [x for x in d["ly_do"] if not x.startswith(("Không kiểm được", "Có "))]
            _them_ly_do(d, "OCR Offline: số tiền khớp chuỗi số dư / tổng phát sinh - đối chiếu lại nội dung")
        else:
            d["trang_thai"] = _nang(d["trang_thai"], "VANG")
            _them_ly_do(d, "OCR Offline - bắt buộc đối chiếu sao kê gốc")
        for k in ("_kiem", "_ngay_doan", "_nghi", "_ung_tien", "_ung_du"):
            d.pop(k, None)


def tach_tai_khoan(dau, dong):
    """(dau, dong) -> [(dau_tk, dong_tk)] theo nhom tai khoan (OCR Offline nhieu sao ke trong mot PDF). Khong co phan -> nguyen."""
    phan = dau.get("phan") or []
    nhom = []
    for d in dong:
        if d.get("nhom") not in nhom:
            nhom.append(d.get("nhom"))
    if len(nhom) <= 1 or not phan:
        if phan:
            _dau_tu_phan(dau, phan, list(range(len(phan))))
        for d in dong:
            d.pop("_phan", None)
        return [(dau, dong)]
    ra = []
    for nh in nhom:
        ds = [d for d in dong if d.get("nhom") == nh]
        pis = sorted(set(d["_phan"] for d in ds))
        dm = dict(dau)
        dm["canh_bao"] = list(dau.get("canh_bao") or [])
        _dau_tu_phan(dm, phan, pis)
        for i, d in enumerate(ds):
            d["thu_tu"] = i + 1
            d.pop("_phan", None)
        ra.append((dm, ds))
    ra.sort(key=lambda x: -len(x[1]))
    return ra


def _dau_tu_phan(dm, phan, pis):
    ps = [phan[i] for i in pis]
    dm["phan"] = ps
    tk = next((p["so_tk"] for p in ps if p["so_tk"]), "")
    if tk:
        dm["so_tk"] = tk
    ky = sorted(p["ky_tu"] for p in ps if p.get("ky_tu"))
    kd = sorted(p["ky_den"] for p in ps if p.get("ky_den"))
    dm["ky_tu"] = ky[0] if ky else dm.get("ky_tu", "")
    dm["ky_den"] = kd[-1] if kd else dm.get("ky_den", "")
    dm["so_du_dau"] = ps[0].get("so_du_dau")
    dm["so_du_cuoi"] = ps[-1].get("so_du_cuoi")
    dm["tong_no"] = sum(p["tong_no"] for p in ps) if all(p.get("tong_no") is not None for p in ps) else None
    dm["tong_co"] = sum(p["tong_co"] for p in ps) if all(p.get("tong_co") is not None for p in ps) else None
    lt = next((p["loai_tien"] for p in ps if p.get("loai_tien")), "")
    if lt:
        dm["loai_tien"] = lt


def doc_bang_offline(path, nh_goi_y, thu_muc_tam, cai_dat=None):
    """GD66: may co Tesseract OCR (tu cai, offline) -> dung Tesseract (doc so tien tot hon nhieu); khong co / loi -> Windows OCR.
       cai-dat.json "ocr_offline_may": "tu_dong" (mac dinh) | "windows" | "tesseract"."""
    cd = cai_dat or {}
    may = str(cd.get("ocr_offline_may") or "tu_dong").lower()
    doc, cach = None, ""
    exe = "" if may == "windows" else tim_tesseract(cd)
    if exe:
        try:
            doc = chay_ocr_tesseract(path, thu_muc_tam, exe)
            cach = "Tesseract OCR Offline (không gửi ảnh ra ngoài)"
        except Exception as e:
            ghi("[OFFLINE] Tesseract loi (%s) -> Windows OCR" % e)
            doc = None
    elif may == "tesseract":
        ghi("[OFFLINE] chua cai Tesseract OCR -> dung Windows OCR")
    elif may != "windows":
        ghi("[OFFLINE] may nay chua co Tesseract OCR -> doc bang Windows OCR (cham, doc so tien kem hon). Cach co Tesseract: "
            "tren may da cai Tesseract, Import so phu > muc 6 (chep Tesseract vao thu muc chuong trinh), roi chep thu muc "
            "AIHoaDon\\Tesseract-OCR sang AIHoaDon cua may nay; hoac cai Tesseract (ban UB Mannheim, chon them tieng Viet).")
    if doc is None:
        doc = chay_ocr_offline(path, thu_muc_tam)
    dau, dong = giai_ma_offline(doc, nh_goi_y)
    if cach:
        dau["cach_doc"] = cach
    dau["tep"] = os.path.basename(path)
    return dau, dong


# ---------------------------------------------------------------- GD97: Google Document AI (tai khoan Google Cloud cua ke toan)
def _ve_anh_trang(path, thu_muc_tam):
    """PDF / anh -> PNG tung trang (PowerShell + Windows.Data.Pdf, khong lam sach) -> [(so_trang, tep_png)]."""
    if not sys.platform.startswith("win"):
        raise RuntimeError("Vẽ từng trang PDF ra ảnh chỉ chạy trên Windows.")
    tam = os.path.join(thu_muc_tam, "docai_%s" % datetime.now().strftime("%Y%m%d%H%M%S"))
    os.makedirs(tam, exist_ok=True)
    ps1 = os.path.join(thu_muc_tam, "Invoke-OcrOffline-UNESCO.ps1")
    with open(ps1, "wb") as f:
        f.write(b"\xef\xbb\xbf" + PS1_OFFLINE.encode("utf-8"))
    ra = os.path.join(tam, "trang.json")
    chay_ps_tien_do([_tim_powershell(), "-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", ps1,
                     "-InputPath", path, "-OutputJson", ra, "-XuatAnhDir", tam, "-LamSach", "0"], 1800, "Document AI: ")
    with io.open(ra, "r", encoding="utf-8-sig") as f:
        kq = json.load(f)
    return [(int(p["page_number"]), p["file"]) for p in kq.get("pages") or []]


def doc_bang_docai(path, nh_goi_y, thu_muc_tam, cai_dat=None):
    """GD97: Google Document AI (processor cua ke toan, docai.json) -> cung bo giai ma / kiem tra nhu OCR Offline
       (chuoi so du, tong phat sinh -> XANH / VANG / DO NHAT). Anh trang tam xoa sau khi doc; ket qua tho giu theo
       noi dung tep (doc lai khong goi Google lan nua)."""
    import shutil
    import docai_unesco as DA
    DA.dat_nhat_ky(ghi)
    cd = DA.doc_cau_hinh()
    if not DA.da_cau_hinh(cd):
        raise RuntimeError(DA.ly_do_chua_cau_hinh())          # GD104: ly do ro (chua kich hoat / thieu khoa / ban khac)
    os.makedirs(thu_muc_tam, exist_ok=True)
    bo_nho = _ocr_bo_nho(path, thu_muc_tam, "docai|" + DA.ten_processor(cd.get("processor", ""))[0])
    doc = None
    if os.path.exists(bo_nho):
        try:
            with io.open(bo_nho, "r", encoding="utf-8-sig") as f:
                doc = json.load(f)
            if doc and doc.get("success") and doc.get("pages"):
                ghi("[DOCAI] dung lai ket qua Document AI da doc cua tep nay")
                os.utime(bo_nho, None)
            else:
                doc = None
        except Exception:
            doc = None
    goi_moi = False          # GD111: True = lan nay goi Google that (khong dung lai bo nho)
    if doc is None:
        goi_moi = True
        cac_tam = []

        def ve(p, t):
            ds = _ve_anh_trang(p, t)
            if ds:
                cac_tam.append(os.path.dirname(ds[0][1]))
            return ds
        try:
            doc = DA.chay(path, thu_muc_tam, cd, ve_anh=ve)
        finally:
            for t in cac_tam:
                shutil.rmtree(t, ignore_errors=True)          # anh trang sao ke - khong giu lai
        if any(p["words"] for p in doc.get("pages") or []):
            with io.open(bo_nho, "w", encoding="utf-8") as f:
                json.dump(doc, f, ensure_ascii=False)
            _ocr_don_bo_nho(thu_muc_tam)
    dau, dong = giai_ma_offline(doc, nh_goi_y)
    dau["cach_doc"] = ("Google Document AI OCR (khoá cài sẵn UNESCO)" if cd.get("_goi")
                       else "Google Document AI OCR (gửi ảnh tới Google Cloud của anh)")
    dau["tep"] = os.path.basename(path)
    # GD111: so trang gui Google bang KHOA CAI SAN (tru vao so trang cua ma kich hoat) - theo khoa thuc dung (processor cua goi,
    #   hoac docai.json khong khoa roi ve khoa cai san); doc lai bo nho / Google rieng = 0
    dau["so_trang_google"] = len(doc.get("pages") or []) if (goi_moi and (cd.get("_goi") or DA.token_la_goi())) else 0
    return dau, dong


def docai_da_luu(path, thu_muc_tam):
    """GD111: tep nay da doc bang Document AI (cung processor) va con ket qua luu -> doc lai khong goi Google (khong tru trang)."""
    try:
        import docai_unesco as DA
        cd = DA.doc_cau_hinh()
        p = _ocr_bo_nho(path, thu_muc_tam, "docai|" + DA.ten_processor(cd.get("processor", ""))[0])
        if not os.path.exists(p):
            return False
        with io.open(p, "r", encoding="utf-8-sig") as f:
            doc = json.load(f)
        return bool(doc and doc.get("success") and doc.get("pages"))
    except Exception:
        return False


# ---------------------------------------------------------------- GD66: Tesseract OCR (offline, doc so tien tot hon Windows OCR)
TESS_DUONG = (r"C:\Program Files\Tesseract-OCR\tesseract.exe", r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe")


def tess_mang_theo():
    """GD104: cho Tesseract MANG THEO (chep tu may da cai, khong can cai dat): AIHoaDon\\Tesseract-OCR, thu muc chuong trinh\\
       Tesseract-OCR, %LOCALAPPDATA%\\UNESCO_AI\\Tesseract-OCR."""
    goc = os.path.dirname(os.path.abspath(__file__))
    ds = [os.path.join(goc, "Tesseract-OCR", "tesseract.exe"), os.path.join(os.path.dirname(goc), "Tesseract-OCR", "tesseract.exe")]
    if os.environ.get("LOCALAPPDATA"):
        ds.append(os.path.join(os.environ["LOCALAPPDATA"], "UNESCO_AI", "Tesseract-OCR", "tesseract.exe"))
    return ds


def _tessdata_canh(exe):
    td = os.path.join(os.path.dirname(os.path.abspath(exe)), "tessdata")
    return td if os.path.isdir(td) and not os.environ.get("TESSDATA_PREFIX") else ""


def chep_tesseract(dich, nguon_exe=None):
    """GD104: chep Tesseract dang cai tren may nay -> <dich>\\Tesseract-OCR (tesseract.exe + DLL + tessdata vie / eng / osd +
       configs) de mang sang may khac (dat canh AIHoaDon). -> (duong exe moi, so tep, MB). Loi -> RuntimeError."""
    import shutil
    exe = nguon_exe or tim_tesseract()
    if not exe:
        raise RuntimeError("Máy này chưa cài Tesseract OCR - không có gì để chép.")
    goc = os.path.dirname(os.path.abspath(exe))
    ra = os.path.join(dich, "Tesseract-OCR")
    if os.path.abspath(ra) == os.path.abspath(goc):
        raise RuntimeError("Thư mục đích chính là thư mục Tesseract đang dùng.")
    os.makedirs(os.path.join(ra, "tessdata"), exist_ok=True)
    n, b = 0, 0
    for t in os.listdir(goc):
        p = os.path.join(goc, t)
        if os.path.isfile(p) and t.lower().endswith((".exe", ".dll")) and "unins" not in t.lower():
            shutil.copy2(p, os.path.join(ra, t))
            n += 1
            b += os.path.getsize(p)
    td = os.path.join(goc, "tessdata")
    if not os.path.isdir(td) and os.environ.get("TESSDATA_PREFIX"):
        td = os.environ["TESSDATA_PREFIX"]
    for t in ("vie.traineddata", "eng.traineddata", "osd.traineddata"):
        p = os.path.join(td, t)
        if os.path.isfile(p):
            shutil.copy2(p, os.path.join(ra, "tessdata", t))
            n += 1
            b += os.path.getsize(p)
    for d in ("configs", "tessconfigs"):
        if os.path.isdir(os.path.join(td, d)):
            shutil.copytree(os.path.join(td, d), os.path.join(ra, "tessdata", d), dirs_exist_ok=True)
    if not os.path.isfile(os.path.join(ra, "tessdata", "vie.traineddata")):
        ghi("[OFFLINE] chep Tesseract: may nguon khong co goi tieng Viet (vie.traineddata) - chi doc duoc tieng Anh")
    return os.path.join(ra, os.path.basename(exe)), n, round(b / 1048576.0, 1)


def tim_tesseract(cai_dat=None):
    """tesseract.exe: cai-dat.json "tesseract_exe" -> thu muc cai mac dinh -> PATH -> GD104 ban mang theo. "" = chua cai."""
    import shutil
    cd = cai_dat or {}
    ds = [str(cd.get("tesseract_exe") or "")] + list(TESS_DUONG)
    la = os.environ.get("LOCALAPPDATA", "")
    if la:
        ds.append(os.path.join(la, "Programs", "Tesseract-OCR", "tesseract.exe"))
    w = shutil.which("tesseract")
    if w:
        ds.append(w)
    ds += tess_mang_theo()
    for p in ds:
        if p and os.path.isfile(p):
            return p
    return ""


def _tess_ngon_ngu(exe):
    try:
        r = subprocess.run([exe, "--list-langs"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=60,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        co = set(x.strip() for x in (r.stdout or b"").decode("utf-8", "replace").splitlines())
    except Exception:
        co = set()
    return "+".join(x for x in ("vie", "eng") if x in co) or "eng"


def _tsv_sang_trang(tsv, so_trang):
    """TSV cua Tesseract -> trang cung dang Windows OCR {page_number, width, height, text, words, lines}."""
    import csv
    W = H = 0
    words, dong = [], {}
    for x in csv.DictReader(io.StringIO(tsv), delimiter="\t", quoting=csv.QUOTE_NONE):
        try:
            muc = int(x.get("level") or 0)
            if muc == 1:
                W, H = int(x["width"]), int(x["height"])
                continue
            t = (x.get("text") or "").strip()
            if muc != 5 or not t or float(x.get("conf") or -1) < 0:
                continue
            w = {"text": t, "x": float(x["left"]), "y": float(x["top"]), "width": float(x["width"]), "height": float(x["height"]),
                 "conf": float(x.get("conf") or 0)}
            words.append(w)
            dong.setdefault((x["block_num"], x["par_num"], x["line_num"]), []).append(w)
        except (KeyError, ValueError):
            continue
    return {"page_number": so_trang, "width": W or 1, "height": H or 1, "text": "\n".join(" ".join(w["text"] for w in v) for v in dong.values()),
            "words": words, "lines": []}


def _diem_trang(pg):
    """GD66: do tin cay trung vi cua chu Tesseract tren trang (trang scan nguoc: chu rac, tin cay thap)."""
    c = sorted(float(w.get("conf", 0) or 0) for w in pg.get("words") or [])
    return c[len(c) // 2] if len(c) >= 8 else 0.0


def _trang_nghi_xoay(pg):
    return len(pg.get("words") or []) >= 15 and _diem_trang(pg) < 65


# ---------------------------------------------------------------- GD67: doc lai tung o so tien (ung vien cho chuoi so du / tong)
def _o_tien_nghi(pg):
    """Tu co the la so tien tren trang: >= 4 chu so co dau phan cach nghin (khong chu cai), hoac 1 - 3 chu so o nua phai trang."""
    W = float(pg.get("width") or 1) or 1.0
    ra = []
    for w in pg.get("words") or []:
        t = re.sub(r"[|\[\]{}]", "", str(w.get("text") or ""))
        so = sum(ch.isdigit() for ch in t)
        if re.search(r"[A-Za-z/:]", t):
            continue
        if (so >= 4 and re.search(r"\d[.,]\d{3}", t)) or (so >= 7 and re.fullmatch(r"\W?[\d.,]+\W?", t)) or \
                (1 <= so <= 3 and re.fullmatch(r"[\d.,]+", t)
                                                            and (float(w["x"]) + float(w["width"]) / 2.0) / W > 0.55):
            ra.append(w)
    return ra


def _vung_o(ws, W, H):
    """O doc lai: ca so tien (mo rong trai 3 ky tu / 10 ky tu voi so ngan de bat chu so bi mat, phai 1.5 / 4 ky tu), cao = chieu cao
       tu +- nua dong (dong chu so trung vi cua trang)."""
    cao = sorted(float(w["height"]) for w in ws) or [30.0]
    hm = cao[len(cao) // 2]
    vs = []
    for w in ws:
        t = str(w["text"])
        cw = float(w["width"]) / max(1, len(t))
        so_cs = sum(ch.isdigit() for ch in t)
        ngan = so_cs <= 3
        cw = max(cw, 0.45 * hm) if ngan else cw
        x0 = max(0, int(float(w["x"]) - cw * (10 if ngan else (7 if so_cs <= 6 else 3))))     # GD68: "1,260" <- "4,481,260"
        x1 = min(int(W) - 1, int(float(w["x"]) + float(w["width"]) + cw * (4 if ngan else 1.5)))
        y0 = max(0, int(float(w["y"]) - 0.5 * hm))
        y1 = min(int(H) - 1, int(float(w["y"]) + float(w["height"]) + 0.5 * hm))
        vs.append((x0, y0, x1, y1))
    return vs, hm


_NHAN_CUOI = {"KY", "BALANCE", "SINH", "TOTAL", "RECORDED", "DAU", "CUOI", "CONG"}
_NHAN_TU = _NHAN_CUOI | {"SO", "DU", "OPENING", "CLOSING", "ENDING", "BEGINNING", "TONG", "PHAT", "TRONG", "TAI", "KHOAN", "SE", "CO", "NO"}


def _o_nhan(pg, da_chon):
    """GD68: dong nhan (so du dau / cuoi ky, tong phat sinh): cac tu ben phai tu nhan cuoi, tren dong nhan hoac dong ke tren / duoi
       (nhan Viet / Anh hai dong, gia tri o giua), gom theo khoang cach -> nhom (moi nhom mot so). Bo nhom chi gom mot tu da la o
       so tien (da_chon). Tra ve [(nhom tu, (x0, y0, x1, y1))]."""
    ws = [w for w in pg.get("words") or [] if str(w.get("text") or "").strip()]
    if not ws:
        return []
    cao = sorted(float(w["height"]) for w in ws)
    hm = cao[len(cao) // 2]
    cy_ = lambda w: float(w["y"]) + float(w["height"]) / 2.0
    dong_ = []
    for w in sorted(ws, key=cy_):
        if dong_ and abs(cy_(w) - dong_[-1][0]) < 0.6 * hm:
            dong_[-1][1].append(w)
        else:
            dong_.append([cy_(w), [w]])
    ra, da = [], set()
    for cy, tu in dong_:
        tu = sorted(tu, key=lambda w: float(w["x"]))
        c = chuan(" ".join(str(w["text"]) for w in tu))
        if not (RX_DAU.search(c) or RX_CUOI.search(c) or RX_TONG.search(c)):
            continue
        cuoi = max((i for i, w in enumerate(tu) if chuan(str(w["text"])) in _NHAN_CUOI or str(w["text"]).rstrip().endswith(":")), default=None)
        if cuoi is None:
            continue
        x_nhan = float(tu[cuoi]["x"]) + float(tu[cuoi]["width"])
        gia = sorted([w for w in ws if abs(cy_(w) - cy) <= 1.6 * hm and float(w["x"]) > x_nhan and id(w) not in da
                      and chuan(str(w["text"])) not in _NHAN_TU], key=lambda w: float(w["x"]))
        if not gia:
            continue
        cw = sorted(float(w["width"]) / max(1, len(str(w["text"]))) for w in gia)[len(gia) // 2]
        nhom = [[gia[0]]]
        for w in gia[1:]:
            p = nhom[-1][-1]
            if float(w["x"]) - (float(p["x"]) + float(p["width"])) <= 5 * cw:
                nhom[-1].append(w)
            else:
                nhom.append([w])
        for g in nhom:
            da.update(id(w) for w in g)
            if len(g) == 1 and any(g[0] is w for w in da_chon):
                continue
            x0 = max(0, int(float(g[0]["x"]) - 1.5 * cw))
            x1 = min(int(float(pg.get("width") or 1)) - 1, int(float(g[-1]["x"]) + float(g[-1]["width"]) + 2 * cw))
            y0 = max(0, int(min(float(w["y"]) for w in g) - 0.5 * hm))
            y1 = min(int(float(pg.get("height") or 1)) - 1, int(max(float(w["y"]) + float(w["height"]) for w in g) + 0.5 * hm))
            ra.append((g, (x0, y0, x1, y1)))
    return ra


def _doc_vung(exe, tep, vs, hm, ngon_ngu, moi_truong, nhi_phan=0):
    """GD68: o chong nhau chia nhieu lan doc (moi lan cac o khong chong nhau) - moi tu doc duoc thuoc dung mot o."""
    bo = []
    for i, v in enumerate(vs):
        for b in bo:
            if all(v[2] < vs[j][0] or v[0] > vs[j][2] or v[3] < vs[j][1] or v[1] > vs[j][3] for j in b):
                b.append(i)
                break
        else:
            bo.append([i])
    ra = [[] for _ in vs]
    for b in bo:
        for j, r in zip(b, _doc_vung1(exe, tep, [vs[j] for j in b], hm, ngon_ngu, moi_truong, nhi_phan)):
            ra[j] = r
    return ra


def _doc_vung1(exe, tep, vs, hm, ngon_ngu, moi_truong, nhi_phan=0):
    """Tesseract doc rieng tung o (tep .uzn canh anh, psm 6, chi chu so; nhi_phan 2 = Sauvola) -> moi o: [chuoi tung dong]."""
    uzn = os.path.splitext(tep)[0] + ".uzn"
    with open(uzn, "w") as f:
        for x0, y0, x1, y1 in vs:
            f.write("%d %d %d %d Text\n" % (x0, y0, max(1, x1 - x0), max(1, y1 - y0)))
    try:
        r = subprocess.run([exe, tep, "stdout", "-l", ngon_ngu, "--psm", "6", "--dpi", "300", "-c", "tessedit_char_whitelist=0123456789,.",
                            "-c", "thresholding_method=%d" % nhi_phan, "tsv"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=300,
                           env=moi_truong, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        tr = _tsv_sang_trang((r.stdout or b"").decode("utf-8", "replace"), 0)
    finally:
        try:
            os.remove(uzn)
        except OSError:
            pass
    kq = [[] for _ in vs]
    for w in tr["words"]:
        cx, cy = w["x"] + w["width"] / 2.0, w["y"] + w["height"] / 2.0
        for i, (x0, y0, x1, y1) in enumerate(vs):
            if x0 <= cx <= x1 and y0 <= cy <= y1:
                kq[i].append(w)
                break
    ra = []
    for k in kq:
        dong_ = []
        for w in sorted(k, key=lambda w: w["y"] + w["height"] / 2.0):
            cy = w["y"] + w["height"] / 2.0
            if dong_ and abs(cy - dong_[-1][0]) < 0.6 * hm:
                dong_[-1][1].append(w)
            else:
                dong_.append([cy, [w]])
        ra.append(["".join(str(x["text"]) for x in sorted(ws_, key=lambda w: w["x"])) for _, ws_ in dong_])
    return ra


def _doc_lai_o_tien(exe, pg, tep_sach, tep_goc, ngon_ngu, moi_truong):
    """Gan w["alt"] = [cac ban doc lai o] (anh sach / anh goc x nhi phan Otsu / Sauvola) khac ban doc chinh. Tra ve so o."""
    ws = _o_tien_nghi(pg)
    try:
        nhan = _o_nhan(pg, ws)                          # GD68: gia tri tren dong so du dau / cuoi, tong phat sinh
    except Exception:
        nhan = []
    if not ws and not nhan:
        return 0
    vs, hm = _vung_o(ws, float(pg.get("width") or 1), float(pg.get("height") or 1))
    vs = vs + [v for _, v in nhan]
    ws_ = ws + [g[0] for g, _ in nhan]
    goc_ = [str(w["text"]).strip("|[]{}") for w in ws] + ["".join(str(x["text"]) for x in g) for g, _ in nhan]
    doc_ = []
    for tep in (tep_sach, tep_goc):
        if tep and os.path.exists(tep):
            for nhi_phan in (0, 2):
                try:
                    doc_.append(_doc_vung(exe, tep, vs, hm, ngon_ngu, moi_truong, nhi_phan))
                except Exception:
                    pass
    for k, w in enumerate(ws_):
        chinh = goc_[k]
        alt = []
        for d in doc_:
            for s in (d[k] if k < len(d) else []):
                if s and s != chinh and s not in alt:
                    alt.append(s)
        if alt:
            w["alt"] = (w.get("alt") or []) + [a for a in alt[:8] if a not in (w.get("alt") or [])]
    return len(ws_)


def _alt_tien(w, x):
    """Cac so doc lai (w["alt"]) khac so chinh x. Doc lai chi chu so hay mat dau phan cach (20595,000) -> lay day chu so."""
    ra = []
    for s in (w or {}).get("alt") or []:
        v = _tien_tok(s)
        if v is None and re.fullmatch(r"[\d.,]+", s) and sum(ch.isdigit() for ch in s) >= 4 and not re.search(r"[.,]\d{1,2}$", s):
            v = float(re.sub(r"\D", "", s))
        if v is not None and v > 0 and not bang(v, abs(x)) and all(not bang(v, u) for u in ra):
            ra.append(v)
    return ra


def chay_ocr_tesseract(path, thu_muc_tam, exe):
    """PDF -> PNG tung trang (PowerShell + Windows.Data.Pdf) -> tesseract ... tsv -> JSON dang Windows OCR. Anh PNG xoa sau khi doc."""
    os.makedirs(thu_muc_tam, exist_ok=True)
    bo_nho = _ocr_bo_nho(path, thu_muc_tam, "tesseract-lamsach-o2")
    if os.path.exists(bo_nho):
        try:
            with io.open(bo_nho, "r", encoding="utf-8-sig") as f:
                doc = json.load(f)
            if doc and doc.get("success") and doc.get("pages"):
                ghi("[OFFLINE] dung lai ket qua Tesseract da doc cua tep nay")
                os.utime(bo_nho, None)
                return doc
        except Exception:
            pass
    tam = os.path.join(thu_muc_tam, "anh_%s" % datetime.now().strftime("%Y%m%d%H%M%S"))
    os.makedirs(tam, exist_ok=True)
    try:
        # GD66: PDF / anh -> PNG da lam sach (xam max(R,G,B) bo con dau mau, xoa duong ke bang) roi moi dua Tesseract
        ds, lam_sach, goc = [], "", {}
        ps1 = os.path.join(thu_muc_tam, "Invoke-OcrOffline-UNESCO.ps1")
        with open(ps1, "wb") as f:
            f.write(b"\xef\xbb\xbf" + PS1_OFFLINE.encode("utf-8"))
        ra = os.path.join(tam, "trang.json")
        try:
            chay_ps_tien_do([_tim_powershell(), "-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", ps1,
                             "-InputPath", path, "-OutputJson", ra, "-XuatAnhDir", tam, "-LamSach", "1"], 1800, "Tesseract: ")
            with io.open(ra, "r", encoding="utf-8-sig") as f:
                kq = json.load(f)
            ds = [(int(p["page_number"]), p["file"]) for p in kq.get("pages") or []]
            goc = {int(p["page_number"]): p.get("goc") or "" for p in kq.get("pages") or []}
            lam_sach = "co" if kq.get("lam_sach") else ("khong (%s)" % str(kq.get("loi_lam_sach") or "")[:160])
        except Exception as e:
            if path.lower().endswith(".pdf"):
                raise
            ghi("[OFFLINE] khong lam sach duoc anh (%s) - doc anh goc" % e)
        if not ds and not path.lower().endswith(".pdf"):
            ds = [(1, path)]
        ngon_ngu = _tess_ngon_ngu(exe)
        luong = max(1, min(4, os.cpu_count() or 2))
        ghi("[OFFLINE] Tesseract (%s): %s - %d trang, lam sach anh: %s, %d luong" % (ngon_ngu, os.path.basename(path), len(ds),
                                                                                    lam_sach or "khong", luong))
        moi_truong = dict(os.environ, OMP_THREAD_LIMIT="1")        # moi tien trinh 1 luong, chay nhieu trang cung luc
        td = _tessdata_canh(exe)
        if td:
            moi_truong["TESSDATA_PREFIX"] = td            # GD104: Tesseract mang theo (khong cai) - tessdata canh tesseract.exe
        dem = {"xong": 0}
        import threading as _th
        khoa_dem = _th.Lock()

        def doc_trang(x):
            so, tep = x
            r = subprocess.run([exe, tep, "stdout", "-l", ngon_ngu, "--psm", "6", "--dpi", "300", "tsv"], stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, timeout=600, env=moi_truong,
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            with khoa_dem:
                dem["xong"] += 1
                if dem["xong"] == len(ds) or dem["xong"] % max(1, len(ds) // 10) == 0:
                    ghi("[OFFLINE] Tesseract doc xong %d/%d trang" % (dem["xong"], len(ds)))
            return _tsv_sang_trang((r.stdout or b"").decode("utf-8", "replace"), so)
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(luong) as ex:
            pages = list(ex.map(doc_trang, ds))
        # GD66: trang scan nguoc / nam ngang (chu doc duoc do tin cay thap) -> xoay 180 / 90 / 270, doc lai, lay ban tot nhat
        nghi = {ds[k][1]: k for k, pg in enumerate(pages) if _trang_nghi_xoay(pg) and ds[k][1] != path}      # khong ghi canh anh goc
        if nghi:
            try:
                ra2 = os.path.join(tam, "xoay.json")
                subprocess.run([_tim_powershell(), "-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", ps1,
                                "-InputPath", path, "-OutputJson", ra2, "-XoayAnh", "|".join("%s*%d" % (t, g) for t in nghi for g in (180, 90, 270))],
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=600, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                with io.open(ra2, "r", encoding="utf-8-sig") as f:
                    xoay = [x for x in json.load(f).get("pages") or [] if x.get("src") in nghi]
                with ThreadPoolExecutor(luong) as ex:
                    moi = list(ex.map(doc_trang, [(ds[nghi[x["src"]]][0], x["file"]) for x in xoay]))
                for x, pg2 in zip(xoay, moi):
                    k = nghi[x["src"]]
                    if _diem_trang(pg2) > _diem_trang(pages[k]) + 10:
                        pg2["xoay"] = int(x["goc"])
                        pg2["tep_xoay"] = x["file"]
                        pages[k] = pg2
                for k in sorted(nghi.values()):
                    if pages[k].get("xoay"):
                        ghi("[OFFLINE] trang %d scan xoay - da xoay %d do roi doc lai" % (ds[k][0], pages[k]["xoay"]))
            except Exception as e:
                ghi("[OFFLINE] khong xoay duoc trang nghi scan nguoc (%s)" % e)
        # GD67: doc lai tung o so tien tren anh sach + anh goc (trang da xoay: bo qua)
        try:
            def doc_o(k):
                so, tep = ds[k]
                if tep == path:                                 # anh goc cua nguoi dung (khong ghi .uzn canh anh)
                    return 0
                if pages[k].get("xoay"):                        # GD68: trang da xoay -> doc lai tren anh da xoay (khong co anh goc xoay)
                    return _doc_lai_o_tien(exe, pages[k], pages[k].get("tep_xoay") or "", "", ngon_ngu, moi_truong) if pages[k].get("tep_xoay") else 0
                return _doc_lai_o_tien(exe, pages[k], tep, goc.get(so) or "", ngon_ngu, moi_truong)
            with ThreadPoolExecutor(luong) as ex:
                so_o = sum(ex.map(doc_o, range(len(pages))))
            ghi("[OFFLINE] doc lai %d o so tien (anh sach + anh goc)" % so_o)
        except Exception as e:
            ghi("[OFFLINE] khong doc lai duoc o so tien (%s)" % e)
        doc = {"engine": "TESSERACT_UNESCO", "success": True, "language": ngon_ngu, "source": path, "pages": pages,
               "lam_sach": lam_sach == "co"}
        if any(p["words"] for p in pages):
            with io.open(bo_nho, "w", encoding="utf-8") as f:
                json.dump(doc, f, ensure_ascii=False)
            _ocr_don_bo_nho(thu_muc_tam)
        return doc
    finally:
        import shutil
        shutil.rmtree(tam, ignore_errors=True)          # anh trang sao ke - khong giu lai


# ---------------------------------------------------------------- ghi Excel (khong can thu vien)
def _x(s):
    s = str(s if s is not None else "")
    s = "".join(c for c in s if c in "\t\n\r" or ord(c) >= 32)
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def _cot_chu(i):
    s = ""
    i += 1
    while i:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s


# style: xf index = fill * 4 + kind ; fill: 0 none, 1 header, 2 XANH, 3 VANG, 4 DO_NHAT, 5 MOI ; kind: 0 text, 1 so, 2 ngay, 3 text dam
_FILL_IDX = {"": 0, "HEADER": 1, "XANH": 2, "VANG": 3, "DO_NHAT": 4, "MOI": 5}
_FILL_MAU = ["", "FFD9E1F2", MAU["XANH"], MAU["VANG"], MAU["DO_NHAT"], MAU["MOI"]]
XF_TITLE = 24


def _styles_xml():
    fonts = ['<font><sz val="10"/><name val="Arial"/></font>', '<font><b/><sz val="10"/><name val="Arial"/></font>',
             '<font><b/><sz val="13"/><color rgb="FF1F4E78"/><name val="Arial"/></font>']
    fills = ['<fill><patternFill patternType="none"/></fill>', '<fill><patternFill patternType="gray125"/></fill>']
    for m in _FILL_MAU[1:]:
        fills.append('<fill><patternFill patternType="solid"><fgColor rgb="%s"/><bgColor indexed="64"/></patternFill></fill>' % m)
    xfs = []
    for f in range(6):
        fid = 0 if f == 0 else f + 1
        for kind in range(4):
            font = 1 if kind == 3 or f == 1 else 0
            numfmt = {0: 0, 1: 164, 2: 165, 3: 0}[kind]
            can = ' applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf>' if kind in (0, 3) else '/>'
            xfs.append('<xf numFmtId="%d" fontId="%d" fillId="%d" borderId="1" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1"%s'
                       % (numfmt, font, fid, can))
    xfs.append('<xf numFmtId="0" fontId="2" fillId="0" borderId="0" applyFont="1"/>')     # 24: tieu de
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            '<numFmts count="2"><numFmt numFmtId="164" formatCode="#,##0;-#,##0;0"/><numFmt numFmtId="165" formatCode="dd/mm/yyyy"/></numFmts>'
            '<fonts count="%d">%s</fonts><fills count="%d">%s</fills>'
            '<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border>'
            '<border><left style="thin"><color rgb="FFBFBFBF"/></left><right style="thin"><color rgb="FFBFBFBF"/></right>'
            '<top style="thin"><color rgb="FFBFBFBF"/></top><bottom style="thin"><color rgb="FFBFBFBF"/></bottom><diagonal/></border></borders>'
            '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
            '<cellXfs count="%d">%s</cellXfs>'
            '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>'
            % (len(fonts), "".join(fonts), len(fills), "".join(fills), len(xfs), "".join(xfs)))


def _xf(mau, kind):
    return _FILL_IDX.get(mau, 0) * 4 + kind


def _ngay_serial(iso):
    try:
        y, m, d = [int(x) for x in iso.split("-")]
        return (date(y, m, d) - date(1899, 12, 30)).days
    except Exception:
        return None


def _sheet_xml(hang, rong, dong_dong_bang=0, gop=None, cao=None):
    """hang: danh sach dong; moi o = (gia tri, kind, mau) hoac None; kind 0 text 1 so 2 ngay(ISO) 3 dam, 'T' tieu de."""
    out = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
           '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
           '<sheetPr><pageSetUpPr fitToPage="1"/></sheetPr>']
    if dong_dong_bang:
        out.append('<sheetViews><sheetView workbookViewId="0"><pane ySplit="%d" topLeftCell="A%d" activePane="bottomLeft" state="frozen"/>'
                   '</sheetView></sheetViews>' % (dong_dong_bang, dong_dong_bang + 1))
    out.append('<cols>%s</cols>' % "".join('<col min="%d" max="%d" width="%s" customWidth="1"/>' % (i + 1, i + 1, w) for i, w in enumerate(rong)))
    out.append("<sheetData>")
    for r, cells in enumerate(hang):
        o = []
        for c, cell in enumerate(cells):
            if cell is None:
                continue
            v, kind, mau = cell
            ref = "%s%d" % (_cot_chu(c), r + 1)
            if kind == "T":
                o.append('<c r="%s" s="%d" t="inlineStr"><is><t xml:space="preserve">%s</t></is></c>' % (ref, XF_TITLE, _x(v)))
            elif kind == 1:
                if v is None or v == "":
                    o.append('<c r="%s" s="%d"/>' % (ref, _xf(mau, 1)))
                else:
                    o.append('<c r="%s" s="%d"><v>%s</v></c>' % (ref, _xf(mau, 1), repr(float(v)) if float(v) != int(float(v)) else int(float(v))))
            elif kind == 2:
                sr = _ngay_serial(v) if v else None
                if sr is None:
                    o.append('<c r="%s" s="%d" t="inlineStr"><is><t>%s</t></is></c>' % (ref, _xf(mau, 0), _x(v)))
                else:
                    o.append('<c r="%s" s="%d"><v>%d</v></c>' % (ref, _xf(mau, 2), sr))
            else:
                o.append('<c r="%s" s="%d" t="inlineStr"><is><t xml:space="preserve">%s</t></is></c>' % (ref, _xf(mau, kind), _x(v)))
        ht = ' ht="%s" customHeight="1"' % (cao or {}).get(r + 1, '') if (cao or {}).get(r + 1) else ''
        out.append('<row r="%d"%s>%s</row>' % (r + 1, ht, "".join(o)))
    out.append("</sheetData>")
    if gop:
        out.append('<mergeCells count="%d">%s</mergeCells>' % (len(gop), "".join('<mergeCell ref="%s"/>' % g for g in gop)))
    out.append('<pageMargins left="0.4" right="0.4" top="0.5" bottom="0.5" header="0.3" footer="0.3"/>'
               '<pageSetup orientation="landscape" fitToWidth="1" fitToHeight="0"/></worksheet>')
    return "".join(out)


def ghi_xlsx(duong, sheets):
    """sheets: [(ten, hang, rong, dong_dong_bang, gop[, cao {dong: chieu cao}])]."""
    ct = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
          '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
          '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
          '<Default Extension="xml" ContentType="application/xml"/>'
          '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
          '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>']
    for i in range(len(sheets)):
        ct.append('<Override PartName="/xl/worksheets/sheet%d.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' % (i + 1))
    ct.append("</Types>")
    wb = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
          '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>']
    rels = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">']
    for i, sh in enumerate(sheets):
        wb.append('<sheet name="%s" sheetId="%d" r:id="rId%d"/>' % (_x(sh[0][:31]), i + 1, i + 1))
        rels.append('<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet%d.xml"/>' % (i + 1, i + 1))
    wb.append("</sheets></workbook>")
    rels.append('<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>' % (len(sheets) + 1))
    tmp = duong + ".tmp"
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", "".join(ct))
        z.writestr("_rels/.rels", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        z.writestr("xl/workbook.xml", "".join(wb))
        z.writestr("xl/_rels/workbook.xml.rels", "".join(rels))
        z.writestr("xl/styles.xml", _styles_xml())
        for i, sh in enumerate(sheets):
            ten, hang, rong, dong_bang, gop = sh[:5]
            z.writestr("xl/worksheets/sheet%d.xml" % (i + 1), _sheet_xml(hang, rong, dong_bang, gop, sh[5] if len(sh) > 5 else None))
    os.replace(tmp, duong)
    return duong


TIEU_DE_COT = ("STT", "Ngày GD", "Số CT", "Nội dung", "Tiền ra", "Tiền vào", "Số dư", "Đối ứng", "Phí", "Thuế",
               "Trạng thái", "Lý do", "Trang", "Bằng chứng")
RONG_COT = (6, 12, 16, 60, 16, 16, 18, 30, 10, 10, 12, 60, 7, 30)


def lap_excel(dau, dong, duong, tep_goc):
    """Ghi file Excel: sheet 'So phu' (doc lai duoc bang Import so phu) + sheet 'Kiem tra'."""
    n = dem_mau(dong)
    kt = dau.get("kiem") or {}
    tt = "ĐÃ KIỂM TRA - mọi dòng XANH" if kt.get("trang_thai") == "DA_KIEM_TRA" else "CẦN XEM LẠI"
    h = []
    h.append([("SỔ PHỤ NGÂN HÀNG ĐỌC TỪ ẢNH / PDF - UNESCO AI (GĐ64) - KIỂM TRA TRƯỚC KHI NHẬP", "T", "")])
    h.append([("Ngân hàng: " + (dau.get("ngan_hang") or "chưa rõ"), 3, ""), None,
              ("Số tài khoản: " + (dau.get("so_tk") or "chưa rõ"), 3, ""), None, None,
              ("Loại tiền: " + (dau.get("loai_tien") or "VND"), 0, "")])
    h.append([("Kỳ sao kê: %s - %s" % (ngay_vn(dau.get("ky_tu")) or "?", ngay_vn(dau.get("ky_den")) or "?"), 0, ""), None,
              ("Số dư đầu kỳ (sao kê):", 0, ""), (dau.get("so_du_dau"), 1, ""), None, None,
              ("Tổng Nợ (sao kê):", 0, ""), (dau.get("tong_no"), 1, ""), ("Tổng Có (sao kê):", 0, ""), (dau.get("tong_co"), 1, ""),
              ("Số dư cuối kỳ (sao kê):", 0, ""), (dau.get("so_du_cuoi"), 1, "")])
    h.append([("File gốc: " + os.path.basename(tep_goc), 0, ""), None, ("Cách đọc: " + (dau.get("cach_doc") or ""), 0, ""), None, None,
              ("Trạng thái chung: " + tt, 3, "XANH" if kt.get("trang_thai") == "DA_KIEM_TRA" else "VANG")])
    xanh = ("số tiền + số dư OCR khớp chuỗi số dư / tổng phát sinh" if ("Offline" in (dau.get("cach_doc") or "") or "OCR" in (dau.get("cach_doc") or ""))
            else "hai lượt đọc thống nhất và chuỗi số dư khớp")
    h.append([("Cột Trạng thái: XANH = %s (%d) | VÀNG = cần xem lại (%d) | ĐỎ NHẠT = lệch số dư / thiếu ngày, tiền (%d) | MỚI = chỉ lượt đọc 2 thấy (%d). "
               "Kiểm xong dòng nào thì ghi OK vào cột Trạng thái; dòng chưa OK khi Import sẽ vào Cần xem lại." % (xanh, n["XANH"], n["VANG"], n["DO_NHAT"], n["MOI"]), 0, "")])
    h.append([])
    h.append([(t, 3, "HEADER") for t in TIEU_DE_COT])
    for i, d in enumerate(dong):
        tt_dong = d["trang_thai"]
        m = ""                      # GD66: khong to mau dong - chi can so lieu dung; cot Trang thai van ghi chu
        h.append([(i + 1, 1, m), (d["ngay"], 2, m), (d["so_ct"], 0, m), (d["noi_dung"], 0, m),
                  (d["tien_ra"], 1, m), (d["tien_vao"], 1, m), (d["so_du"], 1, m),
                  ((d["doi_ung_ten"] + (" " + d["doi_ung_stk"] if d["doi_ung_stk"] else "") + (" - " + d["doi_ung_nh"] if d["doi_ung_nh"] else "")).strip(), 0, m),
                  (d["phi"], 1, m), (d["thue"], 1, m), (TEN_MAU.get(tt_dong, tt_dong), 3, m), ("; ".join(d["ly_do"]), 0, m),
                  (d["trang"], 1, m), (d["bang_chung"], 0, m)])
    s_ra = sum(d["tien_ra"] for d in dong)
    s_vao = sum(d["tien_vao"] for d in dong)
    h.append([("TỔNG CỘNG", 3, "HEADER"), None, None, ("%d dòng" % len(dong), 3, "HEADER"), (s_ra, 1, "HEADER"), (s_vao, 1, "HEADER"), None, None,
              (sum(d["phi"] for d in dong), 1, "HEADER"), (sum(d["thue"] for d in dong), 1, "HEADER")])
    gop = ["A1:N1", "A2:B2", "C2:E2", "A3:B3", "A4:B4", "C4:E4", "F4:N4", "A5:N5"]
    # sheet kiem tra
    k = [[("KIỂM TRA TỰ ĐỘNG - " + os.path.basename(tep_goc), "T", "")], []]
    k.append([("Chỉ tiêu", 3, "HEADER"), ("Giá trị tính từ các dòng", 3, "HEADER"), ("Số trên sao kê", 3, "HEADER"), ("Kết quả", 3, "HEADER")])
    for x in kt.get("doi_chieu") or []:
        m = "" if x["khop"] is None else ("XANH" if x["khop"] else "DO_NHAT")
        k.append([(x["chi_tieu"], 0, m), (x["gia_tri"], 1, m), (x["so_sanh"], 1, m),
                  ("chưa có số trên sao kê để so" if x["khop"] is None else ("khớp" if x["khop"] else "LỆCH"), 0, m)])
    k.append([("Chuỗi số dư: đã kiểm", 0, ""), (kt.get("so_du_kiem", 0), 1, ""), None, ("lệch %d dòng" % kt.get("so_du_lech", 0), 0, "DO_NHAT" if kt.get("so_du_lech") else "XANH")])
    k.append([("Dòng trùng", 0, ""), (kt.get("trung", 0), 1, ""), None, ("", 0, "VANG" if kt.get("trung") else "XANH")])
    k.append([("Khoảng trống STT", 0, ""), (kt.get("stt_trong", 0), 1, ""), None, ("", 0, "VANG" if kt.get("stt_trong") else "XANH")])
    k.append([("Tài liệu đầy đủ (theo AI)", 0, ""), ("có" if dau.get("day_du", True) else "KHÔNG", 0, "" if dau.get("day_du", True) else "DO_NHAT")])
    k.append([("Số trang", 0, ""), (dau.get("so_trang", 0), 1, "")])
    k.append([])
    if dau.get("phan"):                       # GD64: doi chieu tung phan (moi khoi dau sao ke / thang)
        k.append([("Phần sao kê (trang) - kỳ", 3, "HEADER"), ("Số dư đầu", 3, "HEADER"), ("Tiền vào / Tiền ra (các dòng)", 3, "HEADER"),
                  ("Số dư cuối: tính / sao kê", 3, "HEADER")])
        for p in dau["phan"]:
            ds = [d for d in dong if p.get("trang_dau", 0) <= (d.get("trang") or 0) <= p.get("trang_cuoi", 0)]
            vao, ra = sum(d["tien_vao"] for d in ds), sum(d["tien_ra"] + d["phi"] + d["thue"] for d in ds)
            du0 = p.get("so_du_dau")
            if du0 is None:
                du0 = p.get("_dau_dung")
            tinh = None if du0 is None else du0 + vao - ra
            m = "" if (tinh is None or p.get("so_du_cuoi") is None) else ("XANH" if bang(tinh, p["so_du_cuoi"]) else "DO_NHAT")
            k.append([("Trang %s-%s: %s - %s (%d dòng)" % (p.get("trang_dau"), p.get("trang_cuoi"), ngay_vn(p.get("ky_tu")) or "?",
                                                         ngay_vn(p.get("ky_den")) or "?", len(ds)), 0, m),
                      (du0, 1, m), ("%s / %s" % (fmt(vao), fmt(ra)), 0, m),
                      ("%s / %s" % ("?" if tinh is None else fmt(tinh), "?" if p.get("so_du_cuoi") is None else fmt(p["so_du_cuoi"])), 0, m)])
            if p.get("tong_no") is not None:
                mt = "XANH" if (bang(ra, p["tong_no"]) and bang(vao, p["tong_co"])) else "DO_NHAT"
                k.append([("   Tổng phát sinh sao kê Nợ / Có", 0, mt), None, ("%s / %s" % (fmt(p["tong_co"]), fmt(p["tong_no"])), 0, mt),
                          ("khớp" if mt == "XANH" else "LỆCH - thiếu / thừa dòng hoặc đọc sai số", 0, mt)])
            if p.get("canh_bao_tong"):
                k.append([("   " + p["canh_bao_tong"], 0, "VANG")])
        k.append([])
    k.append([("Cảnh báo", 3, "HEADER")])
    for c in dau.get("canh_bao") or []:
        k.append([(c, 0, "")])
    k.append([])
    k.append([("Cách đọc", 0, ""), (dau.get("cach_doc", ""), 0, "")])
    k.append([("Sinh lúc", 0, ""), (datetime.now().strftime("%d/%m/%Y %H:%M:%S"), 0, "")])
    ghi_xlsx(duong, [("So phu", h, RONG_COT, 7, gop, {1: 24, 5: 42}), ("Kiem tra", k, (44, 22, 22, 40), 0, ["A1:D1"])])
    return duong


def ten_tep_ra(tep_goc, thu_muc_du_phong, duoi=""):
    """<thu muc file goc>/<ten ASCII>_SOPHU_EXCEL.xlsx (khong ghi de: _2, _3...); thu muc goc khong ghi duoc -> thu muc du phong."""
    goc = os.path.dirname(os.path.abspath(tep_goc))
    stem = os.path.splitext(os.path.basename(tep_goc))[0]
    stem = re.sub(r"[^A-Za-z0-9_.-]+", "_", bo_dau(stem)).strip("_") or "so_phu"
    for thu in (goc, thu_muc_du_phong):
        if not thu:
            continue
        try:
            os.makedirs(thu, exist_ok=True)
            thu_tm = os.path.join(thu, ".kiem_ghi_%d" % os.getpid())
            with open(thu_tm, "w") as f:
                f.write("x")
            os.remove(thu_tm)
        except Exception:
            continue
        for k in range(1, 100):
            duong = os.path.join(thu, "%s_SOPHU_EXCEL%s%s.xlsx" % (stem, re.sub(r"[^A-Za-z0-9_]", "", duoi), "" if k == 1 else "_%d" % k))
            if not os.path.exists(duong):
                return duong
    raise RuntimeError("Khong ghi duoc file Excel vao thu muc file goc lan thu muc du phong")


def tom_tat(dau, dong, duong_xlsx):
    """Chuoi cho VB6: OK|<xlsx>|<tong>|<xanh>|<vang>|<do>|<moi>|<trang thai>|<canh bao ngan>."""
    n = dem_mau(dong)
    kt = dau.get("kiem") or {}
    cb = " / ".join((dau.get("canh_bao") or [])[:3])[:400].replace("|", "/").replace("\n", " ")
    tt = "DA KIEM TRA" if kt.get("trang_thai") == "DA_KIEM_TRA" else "CAN XEM LAI"
    return "OK|%s|%d|%d|%d|%d|%d|%s|%s" % (duong_xlsx, len(dong), n["XANH"], n["VANG"], n["DO_NHAT"], n["MOI"], tt, cb)
