# -*- coding: utf-8 -*-
"""GD127 - BAN PYTHON GIONG HET ModXLUnicode.bas (dung de sinh bang ma cho VB va de kiem thu tren du lieu that).
Doan tung chuoi la Unicode / TCVN3 (ABC) / VNI Windows bang DO HOP LE AM TIET tieng Viet:
  - doi thu ca 3 cach (U = giu nguyen, ABC = ABCtoUNICODE theo AscW, VNI = VNItoUNICODE cua chuong trinh),
  - cham tung DOAN chu (chuoi ky tu chu / ma 0xA1-0xFE), cong diem ca chuoi -> cach thang W (hoa thi theo thu tu uu tien),
  - tung doan: cach khac HON HAN W thi lay cach do (chuoi tron TCVN3 + VNI), khong thi lay W.
  - doan co chu Unicode 'manh' (U+1EA0-1EF9, a( d- i~ u~ o+ u+) giu nguyen; chuoi co chu manh -> uu tien U.
Hoan toan khong doi chu ASCII."""
import unicodedata

GIOI_HAN = 8192          # bang tra chu cho ma < 8192 (VB: mang 0 To 8191)
STRONG = set(range(7840, 7930)) | {258, 259, 272, 273, 296, 297, 360, 361, 416, 417, 431, 432}
ABC = {181: 224, 184: 225, 182: 7843, 183: 227, 185: 7841, 162: 194, 169: 226, 199: 7847, 202: 7845, 200: 7849, 201: 7851,
       203: 7853, 161: 258, 168: 259, 187: 7857, 190: 7855, 188: 7859, 189: 7861, 198: 7863, 167: 272, 174: 273, 204: 232,
       208: 233, 206: 7867, 207: 7869, 209: 7865, 163: 202, 170: 234, 210: 7873, 213: 7871, 211: 7875, 212: 7877, 214: 7879,
       215: 236, 221: 237, 216: 7881, 220: 297, 222: 7883, 223: 242, 227: 243, 225: 7887, 226: 245, 228: 7885, 164: 212,
       171: 244, 229: 7891, 232: 7889, 230: 7893, 231: 7895, 233: 7897, 165: 416, 172: 417, 234: 7901, 237: 7899, 235: 7903,
       236: 7905, 238: 7907, 239: 249, 243: 250, 241: 7911, 242: 361, 244: 7909, 166: 431, 173: 432, 245: 7915, 248: 7913,
       246: 7917, 247: 7919, 249: 7921, 250: 7923, 251: 7927, 252: 7929, 254: 7925}
VOW = 'aăâeêioôơuưy'
CONS = 'bcdđghklmnpqrstvx'
TONEMARK = {'̀', '́', '̃', '̉', '̣'}
LOAI_DAU = {'\u0300': 1, '\u0301': 2, '\u0309': 3, '\u0303': 4, '\u0323': 5}
# van tieng Viet (khong dau) - thay cho luat am chinh + am cuoi chung chung (GD127b): loai 'cơng', 'tỉng', 'gĩc'...
VAN = ('a ac ach ai am an ang anh ao ap at au ay ăc ăm ăn ăng ăp ăt âc âm ân âng âp ât âu ây '
       'e ec em en eng eo ep et ê êch êm ên ênh êp êt êu '
       'i ia ich im in inh ip it iu iêc iêm iên iêng iêp iêt iêu '
       'o oc oi om on ong op ot oa oac oach oai oam oan oang oanh oao oap oat oay oăc oăm oăn oăng oăt '
       'oe oen oeo oet ooc oong ô ôc ôi ôm ôn ông ôp ôt ơ ơi ơm ơn ơp ơt '
       'u uc ui um un ung up ut ua uân uâng uât uây uê uêch uênh uơ uôc uôi uôm uôn uông uôt '
       'uy uya uych uyên uyêt uynh uyp uyt uyu ư ưc ưi ưm ưn ưng ưt ưu ưa ươc ươi ươm ươn ương ươp ươt ươu '
       'y yêm yên yêng yêt yêu ynh yt ych').split()
DAU_VAN = ['ngh', 'ng', 'nh', 'ch', 'gh', 'gi', 'kh', 'ph', 'qu', 'th', 'tr'] + list('bcdđghklmnprstvx') + ['']
HOA_DAU = {0xD9, 0xD8, 0xDB, 0xD5, 0xCF, 0xC2, 0xC1, 0xC0, 0xC5, 0xC3, 0xC4, 0xCA, 0xC9, 0xC8, 0xDA, 0xDC, 0xCB}


def _tach(ch):
    d = unicodedata.normalize('NFD', ch)
    tone = sum(1 for c in d if c in TONEMARK)
    base = unicodedata.normalize('NFC', ''.join(c for c in d if c not in TONEMARK))
    return base, tone


def _bang():
    lop = [0] * GIOI_HAN; goc = [0] * GIOI_HAN; dau = [0] * GIOI_HAN; hoa = [0] * GIOI_HAN; len_ = list(range(GIOI_HAN))
    for cp in range(GIOI_HAN):
        ch = chr(cp)
        if not ch.isalpha():
            continue
        hoa[cp] = 1 if ch.islower() else (2 if ch.isupper() else 0)
        lo = ch.lower()
        b, t = _tach(lo) if len(lo) == 1 else ('', 0)
        if t:
            t = [LOAI_DAU[c] for c in unicodedata.normalize('NFD', lo) if c in LOAI_DAU][0]
        if len(b) == 1 and (b in VOW or b in CONS or b in 'abcdefghijklmnopqrstuvwxyz'):
            lop[cp] = 1
            goc[cp] = ord(b)
            dau[cp] = t
        else:
            lop[cp] = 2
        up = ch.upper()
        if lop[cp] == 1 and len(up) == 1 and ord(up) < GIOI_HAN:
            len_[cp] = ord(up)
    return lop, goc, dau, hoa, len_


LOP, GOC, DAU, HOA, LEN = _bang()


def lop(cp):
    return LOP[cp] if cp < GIOI_HAN else 0


def la_chu_doan(cp):
    """ky tu thuoc mot DOAN chu: chu cai (moi bang chu) hoac ma 0xA1-0xFE (TCVN3 dung ca ky hieu ¬ ® § ...)"""
    return lop(cp) > 0 or 161 <= cp <= 254


# ---------------- 3 cach doi
def abc(s):
    return ''.join(chr(ABC.get(ord(c), ord(c))) for c in s)


def vni_vb(s):
    """giong HET Utilitie.VNItoUNICODE (chuoi cac lenh Replace theo dung thu tu)"""
    R = lambda s, a, b: s.replace(a, b)
    C = chr
    for a, b in ((209, 272), (241, 273), (198, 7880), (230, 7881), (211, 296), (243, 297), (210, 7882), (242, 7883),
                 (206, 7924), (238, 7925)):
        s = R(s, C(a), C(b))
    Tu = [C(x) for x in (216, 217, 219, 213, 207)]
    TL = [C(x) for x in (248, 249, 251, 245, 239)]
    oldCircU = (192, 193, 197, 195, 196); oldCircL = (224, 225, 229, 227, 228)
    oldBreveU = (200, 201, 218, 220, 203); oldBreveL = (232, 233, 250, 252, 235)
    outU = (7846, 7844, 7848, 7850, 7852); outL = (7847, 7845, 7849, 7851, 7853)
    for i in range(5):
        s = R(s, "A" + C(194) + Tu[i], C(outU[i])); s = R(s, "a" + C(226) + TL[i], C(outL[i]))
        s = R(s, "A" + C(oldCircU[i]), C(outU[i])); s = R(s, "a" + C(oldCircL[i]), C(outL[i]))
    s = R(s, "A" + C(194), C(194)); s = R(s, "a" + C(226), C(226))
    outU = (7856, 7854, 7858, 7860, 7862); outL = (7857, 7855, 7859, 7861, 7863)
    for i in range(5):
        s = R(s, "A" + C(202) + Tu[i], C(outU[i])); s = R(s, "a" + C(234) + TL[i], C(outL[i]))
        s = R(s, "A" + C(oldBreveU[i]), C(outU[i])); s = R(s, "a" + C(oldBreveL[i]), C(outL[i]))
    s = R(s, "A" + C(202), C(258)); s = R(s, "a" + C(234), C(259))
    outU = (7872, 7870, 7874, 7876, 7878); outL = (7873, 7871, 7875, 7877, 7879)
    for i in range(5):
        s = R(s, "E" + C(194) + Tu[i], C(outU[i])); s = R(s, "e" + C(226) + TL[i], C(outL[i]))
        s = R(s, "E" + C(oldCircU[i]), C(outU[i])); s = R(s, "e" + C(oldCircL[i]), C(outL[i]))
    s = R(s, "E" + C(194), C(202)); s = R(s, "e" + C(226), C(234))
    outU = (7900, 7898, 7902, 7904, 7906); outL = (7901, 7899, 7903, 7905, 7907)
    for i in range(5):
        s = R(s, C(212) + Tu[i], C(outU[i])); s = R(s, C(244) + TL[i], C(outL[i]))
    s = R(s, C(212), C(416)); s = R(s, C(244), C(417))
    outU = (7890, 7888, 7892, 7894, 7896); outL = (7891, 7889, 7893, 7895, 7897)
    for i in range(5):
        s = R(s, "O" + C(194) + Tu[i], C(outU[i])); s = R(s, "o" + C(226) + TL[i], C(outL[i]))
        s = R(s, "O" + C(oldCircU[i]), C(outU[i])); s = R(s, "o" + C(oldCircL[i]), C(outL[i]))
    s = R(s, "O" + C(194), C(212)); s = R(s, "o" + C(226), C(244))
    outU = (7914, 7912, 7916, 7918, 7920); outL = (7915, 7913, 7917, 7919, 7921)
    for i in range(5):
        s = R(s, C(214) + Tu[i], C(outU[i])); s = R(s, C(246) + TL[i], C(outL[i]))
    s = R(s, C(214), C(431)); s = R(s, C(246), C(432))
    for nguyen, ou, ol in (('A', (192, 193, 7842, 195, 7840), (224, 225, 7843, 227, 7841)),
                           ('E', (200, 201, 7866, 7868, 7864), (232, 233, 7867, 7869, 7865)),
                           ('I', (204, 205, 7880, 296, 7882), (236, 237, 7881, 297, 7883)),
                           ('O', (210, 211, 7886, 213, 7884), (242, 243, 7887, 245, 7885)),
                           ('U', (217, 218, 7910, 360, 7908), (249, 250, 7911, 361, 7909)),
                           ('Y', (7922, 221, 7926, 7928, 7924), (7923, 253, 7927, 7929, 7925))):
        for i in range(5):
            s = R(s, nguyen + Tu[i], C(ou[i])); s = R(s, nguyen.lower() + TL[i], C(ol[i]))
    return s


# ---------------- cham diem
def _vi_tri_dau(van, vi_tri, thanh):
    """dau thanh dat DUNG cho tren van (GD127b): co phu am cuoi -> nguyen am cuoi cua van; khong co -> oa oe uy (ca hai),
    uê uơ (chu sau), 2 nguyen am khac (chu dau: ai ao au ... ia ua ưa), 3 nguyen am (chu giua). 'giaù' (u) / 'tóan' bi loai"""
    if not thanh:
        return True
    if vi_tri < 0:
        return False                      # dau tren am dau (gi / qu)
    nv = 0
    while nv < len(van) and van[nv] in VOW:
        nv += 1
    if nv < len(van):
        return vi_tri == nv - 1
    if nv >= 3:
        return vi_tri == 1
    if nv == 2:
        if van in ('oa', 'oe', 'uy'):
            return True
        if van in ('uê', 'uơ'):
            return vi_tri == 1
        return vi_tri == 0
    return vi_tri == 0


def _van_hop_le(dau, van, thanh, vi_tri=-1):
    if van not in VAN:
        return False
    c0 = van[0]
    if dau == 'c' and c0 in 'ieêy': return False
    if dau == 'k' and c0 not in 'ieêy': return False
    if dau == 'g' and c0 in 'eê': return False
    if dau in ('gh', 'ngh') and c0 not in 'ieê': return False
    if dau == 'ng' and c0 in 'ieê': return False
    if dau == 'gi' and c0 == 'i': return False
    if dau == 'qu' and c0 == 'u': return False
    if thanh in (1, 3, 4) and (van.endswith('ch') or van[-1] in 'ptc'): return False   # van tac: chi sac / nang
    return _vi_tri_dau(van, vi_tri, thanh)


def tu_hop_le(w):
    b = ''; t = 0; thanh = 0; vt = -1
    for ch in w:
        cp = ord(ch)
        if lop(cp) != 1:
            return False
        b += chr(GOC[cp])
        if DAU[cp]:
            t += 1; thanh = DAU[cp]; vt = len(b) - 1
    if t > 1:
        return False
    for c in b:
        if c not in VOW and c not in CONS:
            return False
    for dau in DAU_VAN:
        if b.startswith(dau) and len(b) > len(dau) and _van_hop_le(dau, b[len(dau):], thanh, vt - len(dau)):
            return True
    return False


def viet_tat(w):
    """chu viet tat: toan chu HOA, khong co nguyen am (DT, TSCD, BDS...) -> coi la tu dung"""
    for ch in w:
        cp = ord(ch)
        if lop(cp) != 1 or HOA[cp] == 1:
            return False
        if chr(GOC[cp]) in VOW:
            return False
    return True


def diem_doan(c):
    hl = sai = rac = 0
    n = len(c)
    i = 0
    cps = [ord(x) for x in c]
    for k in range(n):
        cp = cps[k]
        if cp > 127:
            L = lop(cp)
            if L == 0 or L == 2:
                rac += 1
            elif not (chr(GOC[cp]) in VOW or GOC[cp] == 273):
                rac += 1
        if k + 1 < n:
            a, b = cps[k], cps[k + 1]
            if lop(a) > 0 and lop(b) > 0 and HOA[a] == 1 and HOA[b] == 2 and (a > 127 or b > 127):
                rac += 1        # chu thuong roi chu HOA trong mot tu (tiÕn, ẹT)
            if k > 0 and b > 0 and lop(cps[k - 1]) > 0 and lop(a) > 0 and lop(b) > 0 and a > 127 and HOA[a] == 2 and HOA[b] == 1:
                rac += 1        # chu HOA co dau giua tu roi chu thuong (TÊm)
    while i < n:
        if lop(cps[i]) > 0:
            j = i
            while j < n and lop(cps[j]) > 0:
                j += 1
            if any(x > 127 for x in cps[i:j]):
                if viet_tat(c[i:j]) or tu_hop_le(c[i:j]):      # chu viet tat HOA (ĐT, TSCĐ) coi la dung
                    hl += 1
                else:
                    sai += 1
            i = j
        else:
            i += 1
    return hl - 2 * sai - 3 * rac


TL_ = {248, 249, 251, 245, 239}
TU_ = {216, 217, 219, 213, 207}
MU_L = {224, 225, 229, 227, 228, 226}
MU_U = {192, 193, 197, 195, 196, 194}
TR_L = {232, 233, 250, 252, 235, 234}
TR_U = {200, 201, 218, 220, 203, 202}


def vni_mo_coi(raw):
    """so 'dau' VNI dung sai cho (VNItoUNICODE khong ghep duoc) - van ban VNI that khong bao gio co.
    Chu thuong + dau HOA da tinh o vni_lech -> khong tinh lai."""
    n = 0
    for k in range(len(raw)):
        cp = ord(raw[k])
        tr = raw[k - 1] if k > 0 else ''
        tc = ord(tr) if tr else 0
        if cp in TL_:
            ok = tr in 'aeiouy' and tr != '' or tc in (226, 234, 244, 246)
        elif cp in TU_:
            ok = (tr != '' and tr in 'AEIOUYaeiouy') or tc in (194, 202, 212, 214)
        elif cp in MU_L:
            ok = tr != '' and tr in 'aeo'
        elif cp in MU_U:
            ok = tr != '' and tr in 'AEOaeo'
        elif cp in TR_L:
            ok = tr == 'a'
        elif cp in TR_U:
            ok = tr in ('A', 'a')
        else:
            continue
        if not ok:
            n += 1
    return n


def abc_la(raw):
    """chu Latin-1 (192-255) TCVN3 khong bao gio dung (À Á Â Ã Ä Å Ù Ú Û à ý ...) -> chuoi khong phai TCVN3"""
    return sum(1 for ch in raw if 192 <= ord(ch) <= 255 and ord(ch) not in ABC and lop(ord(ch)) > 0)


def vni_la(raw):
    """Ý ý: VNI viet YÙ / yù - khong bao gio co ma 221 / 253"""
    return sum(1 for ch in raw if ord(ch) in (221, 253))


def vni_lech(raw):
    n = 0
    for k in range(len(raw) - 1):
        if raw[k] in 'aeiouy' and ord(raw[k + 1]) in HOA_DAU:
            n += 1
    return n


def tach_doan(s):
    """[(la_doan_chu, text)] xen ke"""
    out = []
    i = 0; n = len(s)
    while i < n:
        w = la_chu_doan(ord(s[i]))
        j = i
        while j < n and la_chu_doan(ord(s[j])) == w:
            j += 1
        out.append((w, s[i:j]))
        i = j
    return out


def co_cao(s):
    return any(ord(c) > 127 for c in s)


def co_manh(s):
    return any(ord(c) in STRONG for c in s)


def doi(s, thu_tu=('U', 'ABC', 'VNI'), chi_tiet=False):
    """thu_tu: uu tien khi hoa diem. Tra ve chuoi Unicode (chi_tiet: (chuoi, W, tong diem))"""
    if not co_cao(s):
        return (s, 'ASCII', {}) if chi_tiet else s
    manh = co_manh(s)
    if manh:
        thu_tu = ['U'] + [x for x in thu_tu if x != 'U']
    dr = tach_doan(s)
    da = tach_doan(abc(s))
    dv = tach_doan(vni_vb(s))
    if len(dv) != len(dr) or any(a[0] != b[0] or (not a[0] and a[1] != b[1]) for a, b in zip(dr, dv)):
        dv = [(w, vni_vb(t) if w else t) for w, t in dr]
    if len(da) != len(dr):
        da = [(w, abc(t) if w else t) for w, t in dr]
    tong = {'U': 0, 'ABC': 0, 'VNI': 0}
    cham = []
    for k, (w, t) in enumerate(dr):
        if not w or not co_cao(t) or co_manh(t):
            cham.append(None)
            continue
        ung = {'U': t, 'ABC': da[k][1], 'VNI': dv[k][1]}
        d = {x: diem_doan(ung[x]) for x in ung}
        d['VNI'] -= 3 * (vni_lech(t) + vni_mo_coi(t) + vni_la(t))
        d['ABC'] -= 3 * abc_la(t)
        for x in d:
            tong[x] += d[x]
        cham.append((ung, d))
    tot = max(tong.values())
    W = [x for x in thu_tu if tong[x] == tot][0]
    out = []
    ctx = ''                             # cach doc cua doan ro rang gan nhat ben trai (chuoi tron TCVN3 + VNI)
    for k, (w, t) in enumerate(dr):
        if cham[k] is None:
            out.append(t)
            continue
        ung, d = cham[k]
        b = max(d.values())
        B = [x for x in thu_tu if d[x] == b]
        if b > 0 and b - d[W] >= 2:      # doan khac chi thay khi no HOP LE (diem > 0) va hon cach chung tu 2 diem
            c = B[0]
        elif d[W] == b and ctx and ctx != W and b > 0 and d[ctx] == b:
            c = ctx                      # doan hoa diem: theo doan ro rang ngay truoc
        else:
            c = W
        if len(B) == 1:
            ctx = B[0]
        out.append(ung[c])
    r = ''.join(out)
    return (r, W, tong) if chi_tiet else r


def thu_tu_du_lieu(p):
    """thu tu uu tien cho DU LIEU (XLGan / XLU_VNI) theo bang ma cua so p"""
    return {'ABC': ('ABC', 'VNI', 'U'), 'VNI': ('VNI', 'U', 'ABC')}.get(p, ('U', 'VNI', 'ABC'))


def hoa(s):
    """chu HOA (font .VnTimeH...): chi doi chu cai tieng Viet / ASCII theo bang LEN"""
    return ''.join(chr(LEN[ord(c)]) if ord(c) < GIOI_HAN else c for c in s)
