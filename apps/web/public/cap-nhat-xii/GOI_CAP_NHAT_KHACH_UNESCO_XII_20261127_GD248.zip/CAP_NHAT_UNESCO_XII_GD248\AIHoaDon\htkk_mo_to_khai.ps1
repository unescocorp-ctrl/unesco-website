﻿# GD197 (anh Thang 11/10/2026): xuat mau nao thi HTKK tu mo ngay mau do + phu luc, dung ky.
# Goi tu htkk_dua_vao.mo_to_khai_htkk sau khi HTKK da dang nhap MST cong ty.
#   1. Tim cua so chinh HTKK (theo tien trinh), bam lan luot menu theo Menu.xml cua chinh HTKK (vd "Kê khai" ->
#      "Thuế Giá Trị Gia Tăng" -> "Tờ khai thuế GTGT khấu trừ (01/GTGT)").
#   2. Hop chon ky hien ra: chon Thang / Quy, dien thang / quy / nam, Lan dau / Bo sung, tick cac phu luc co so lieu.
#      Doc lai: dung ky thi bam Dong y (HTKK mo to khai da duoc UNESCO ghi vao DataFiles -> thay so lieu).
#      Khong chac (khong doc duoc o ky) -> KHONG bam, de nguoi dung kiem roi bam.
#   3. Moi lan chay ghi cay giao dien hop chon ky vao tep (de soat / sua neu HTKK doi giao dien).
# Khong go mat khau, khong ky, khong nop. Chi dung UI Automation co san cua Windows (.NET Framework).
param([string]$Thamso, [string]$Ra)

$ErrorActionPreference = 'Continue'
$kq = New-Object System.Collections.ArrayList
function Ghi([string]$s) { [void]$kq.Add($s) }
function Xong([string]$trangThai) {
    Ghi ("KET_QUA " + $trangThai)
    try { [System.IO.File]::WriteAllLines($Ra, [string[]]$kq, (New-Object System.Text.UTF8Encoding($false))) } catch { }
    exit 0
}

try {
    Add-Type -AssemblyName UIAutomationClient
    Add-Type -AssemblyName UIAutomationTypes
} catch {
    Ghi ("Khong nap duoc UI Automation: " + $_.Exception.Message)
    Xong "KHONG_UIA"
}

$ts = Get-Content -LiteralPath $Thamso -Raw -Encoding UTF8 | ConvertFrom-Json
$AE = [System.Windows.Automation.AutomationElement]
$TS = [System.Windows.Automation.TreeScope]
$CT = [System.Windows.Automation.ControlType]

function BoDau([string]$s) {
    if (-not $s) { return '' }
    $n = $s.Normalize([System.Text.NormalizationForm]::FormD)
    $b = New-Object System.Text.StringBuilder
    foreach ($c in $n.ToCharArray()) {
        if ([System.Globalization.CharUnicodeInfo]::GetUnicodeCategory($c) -ne [System.Globalization.UnicodeCategory]::NonSpacingMark) { [void]$b.Append($c) }
    }
    $r = $b.ToString().Replace([string][char]0x0111, 'd').Replace([string][char]0x0110, 'D').ToLower()
    return ([regex]::Replace($r, '\s+', ' ')).Trim()
}

function CuaSoTienTrinh([int[]]$pids) {
    $ds = @()
    $con = $AE::RootElement.FindAll($TS::Children, [System.Windows.Automation.Condition]::TrueCondition)
    foreach ($w in $con) {
        try { if ($pids -contains $w.Current.ProcessId) { $ds += $w } } catch { }
    }
    return $ds
}

function TimTen($goc, [string]$ten, $loai) {
    # tim phan tu co Name khop (bo dau, khong phan biet hoa thuong); uu tien dung loai control
    $muc = BoDau $ten
    $tat = $goc.FindAll($TS::Descendants, [System.Windows.Automation.Condition]::TrueCondition)
    $gan = $null
    foreach ($e in $tat) {
        try {
            $n = BoDau $e.Current.Name
            if (-not $n) { continue }
            if ($n -eq $muc) {
                if ($loai -eq $null -or $e.Current.ControlType -eq $loai) { return $e }
                if ($gan -eq $null) { $gan = $e }
            }
        } catch { }
    }
    return $gan
}

function BamMuc($e, [bool]$cuoi) {
    $p = $null
    if (-not $cuoi -and $e.TryGetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern, [ref]$p)) {
        try { $p.Expand(); return 'mo' } catch { }
    }
    if ($e.TryGetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern, [ref]$p)) {
        try { $p.Invoke(); return 'bam' } catch { }
    }
    if ($e.TryGetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern, [ref]$p)) {
        try { $p.Expand(); return 'mo' } catch { }
    }
    if ($e.TryGetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern, [ref]$p)) {
        try { $p.Select(); return 'chon' } catch { }
    }
    return ''
}

function DatGiaTri($e, [string]$v) {
    $p = $null
    if ($e.TryGetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern, [ref]$p)) {
        try { if (-not $p.Current.IsReadOnly) { $p.SetValue($v); return $true } } catch { }
    }
    # combobox: chon muc co ten khop
    if ($e.Current.ControlType -eq $CT::ComboBox) {
        $ec = $null
        if ($e.TryGetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern, [ref]$ec)) { try { $ec.Expand(); Start-Sleep -Milliseconds 300 } catch { } }
        $ms = $e.FindAll($TS::Descendants, (New-Object System.Windows.Automation.PropertyCondition($AE::ControlTypeProperty, $CT::ListItem)))
        foreach ($m in $ms) {
            $t = ($m.Current.Name).Trim()
            if ($t -eq $v -or $t.TrimStart('0') -eq $v.TrimStart('0') -or (BoDau $t).EndsWith(' ' + $v.TrimStart('0'))) {
                $sp = $null
                if ($m.TryGetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern, [ref]$sp)) { try { $sp.Select() } catch { } }
                if ($ec) { try { $ec.Collapse() } catch { } }
                return $true
            }
        }
        if ($ec) { try { $ec.Collapse() } catch { } }
    }
    return $false
}

function DocGiaTri($e) {
    $p = $null
    if ($e.TryGetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern, [ref]$p)) { try { return [string]$p.Current.Value } catch { } }
    if ($e.TryGetCurrentPattern([System.Windows.Automation.SelectionPattern]::Pattern, [ref]$p)) {
        try { $s = $p.Current.GetSelection(); if ($s.Length -gt 0) { return [string]$s[0].Current.Name } } catch { }
    }
    return [string]$e.Current.Name
}

function ChonO($e) {
    $p = $null
    if ($e.TryGetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern, [ref]$p)) { try { $p.Select(); return $true } catch { } }
    if ($e.TryGetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern, [ref]$p)) { try { $p.Invoke(); return $true } catch { } }
    return $false
}

function TickO($e) {
    $p = $null
    if ($e.TryGetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern, [ref]$p)) {
        try { if ($p.Current.ToggleState -ne [System.Windows.Automation.ToggleState]::On) { $p.Toggle() }; return $true } catch { }
    }
    return $false
}

function GhiCay($goc, [string]$tep) {
    $dong = New-Object System.Collections.ArrayList
    $tat = $goc.FindAll($TS::Descendants, [System.Windows.Automation.Condition]::TrueCondition)
    foreach ($e in $tat) {
        try {
            $v = ''
            $p = $null
            if ($e.TryGetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern, [ref]$p)) { $v = [string]$p.Current.Value }
            $r = $e.Current.BoundingRectangle
            [void]$dong.Add(("{0}|{1}|{2}|{3}|{4},{5}" -f $e.Current.ControlType.ProgrammaticName, $e.Current.AutomationId, $e.Current.Name, $v, [int]$r.X, [int]$r.Y))
        } catch { }
    }
    try { [System.IO.File]::WriteAllLines($tep, [string[]]$dong, (New-Object System.Text.UTF8Encoding($true))) } catch { }
}

# ---------------------------------------------------------------- 1. cua so chinh HTKK
$pids = @()
foreach ($p in Get-Process -ErrorAction SilentlyContinue) {
    try {
        if ($ts.exe -and $p.Path -and ($p.Path -ieq $ts.exe)) { $pids += $p.Id }
        elseif (-not $ts.exe -and $p.ProcessName -match '^HTKK') { $pids += $p.Id }
    } catch { }
}
if ($pids.Count -eq 0) { foreach ($p in Get-Process -Name 'HTKK*' -ErrorAction SilentlyContinue) { $pids += $p.Id } }
if ($pids.Count -eq 0) { Ghi 'Khong thay tien trinh HTKK'; Xong 'KHONG_THAY_HTKK' }

$chinh = $null
for ($i = 0; $i -lt 20 -and $chinh -eq $null; $i++) {
    $ws = CuaSoTienTrinh $pids
    $lon = 0
    foreach ($w in $ws) {
        $r = $w.Current.BoundingRectangle
        $dt = $r.Width * $r.Height
        $menu = $w.FindFirst($TS::Descendants, (New-Object System.Windows.Automation.PropertyCondition($AE::ControlTypeProperty, $CT::MenuBar)))
        if ($menu -ne $null -and $dt -gt $lon) { $chinh = $w; $lon = $dt }
    }
    if ($chinh -eq $null) { Start-Sleep -Milliseconds 700 }
}
if ($chinh -eq $null) { Ghi 'Khong thay cua so lam viec HTKK (con o man hinh dang nhap?)'; Xong 'CHUA_VAO_HTKK' }
Ghi ('Cua so HTKK: ' + $chinh.Current.Name)
try { $chinh.SetFocus() } catch { }

# cac hop dang mo truoc khi bam menu (de nhan ra hop chon ky moi)
$truoc = @{}
foreach ($w in (CuaSoTienTrinh $pids)) { try { $truoc[[string]$w.Current.NativeWindowHandle] = 1 } catch { } }
foreach ($w in $chinh.FindAll($TS::Children, (New-Object System.Windows.Automation.PropertyCondition($AE::ControlTypeProperty, $CT::Window)))) {
    try { $truoc[[string]$w.Current.NativeWindowHandle] = 1 } catch { }
}

# ---------------------------------------------------------------- 2. bam menu
$duong = @($ts.duong)
for ($i = 0; $i -lt $duong.Count; $i++) {
    $ten = [string]$duong[$i]
    $cuoi = ($i -eq $duong.Count - 1)
    $e = $null
    for ($k = 0; $k -lt 12 -and $e -eq $null; $k++) {
        $e = TimTen $chinh $ten $CT::MenuItem
        if ($e -eq $null) {
            foreach ($w in (CuaSoTienTrinh $pids)) { $e = TimTen $w $ten $CT::MenuItem; if ($e -ne $null) { break } }
        }
        if ($e -eq $null) {
            foreach ($w in $AE::RootElement.FindAll($TS::Children, (New-Object System.Windows.Automation.PropertyCondition($AE::ClassNameProperty, '#32768')))) {
                $e = TimTen $w $ten $null; if ($e -ne $null) { break }
            }
        }
        if ($e -eq $null) { Start-Sleep -Milliseconds 400 }
    }
    if ($e -eq $null) { Ghi ('Khong thay menu: ' + $ten); Xong 'KHONG_THAY_MENU' }
    $cach = BamMuc $e $cuoi
    Ghi ('Menu ' + $ten + ': ' + $cach)
    if (-not $cach) { Xong 'KHONG_BAM_DUOC_MENU' }
    Start-Sleep -Milliseconds 700
}

# ---------------------------------------------------------------- 3. hop chon ky
$hop = $null
for ($k = 0; $k -lt 25 -and $hop -eq $null; $k++) {
    Start-Sleep -Milliseconds 400
    $ung = @()
    $ung += CuaSoTienTrinh $pids
    $ung += @($chinh.FindAll($TS::Children, (New-Object System.Windows.Automation.PropertyCondition($AE::ControlTypeProperty, $CT::Window))))
    foreach ($w in $ung) {
        try {
            $h = [string]$w.Current.NativeWindowHandle
            if ($truoc.ContainsKey($h) -or $w.Equals($chinh)) { continue }
            $hop = $w; break
        } catch { }
    }
}
if ($hop -eq $null) { Ghi 'Da bam menu nhung khong thay hop chon ky (co the HTKK mo thang to khai)'; Xong 'DA_BAM_MENU' }
Ghi ('Hop chon ky: ' + $hop.Current.Name)
if ($ts.cay) { GhiCay $hop ([string]$ts.cay) }

$tat = @($hop.FindAll($TS::Descendants, [System.Windows.Automation.Condition]::TrueCondition))
$radio = @(); $o = @(); $tick = @(); $nut = @()
foreach ($e in $tat) {
    try {
        $t = $e.Current.ControlType
        if ($t -eq $CT::RadioButton) { $radio += $e }
        elseif ($t -eq $CT::CheckBox) { $tick += $e }
        elseif ($t -eq $CT::Button) { $nut += $e }
        elseif ($t -eq $CT::ComboBox -or $t -eq $CT::Edit -or $t -eq $CT::Spinner) { $o += $e }
    } catch { }
}

# Thang / Quy
$kieu = [string]$ts.kieu
foreach ($r in $radio) {
    $n = BoDau $r.Current.Name
    if (($kieu -eq 'M' -and $n -match 'thang') -or ($kieu -eq 'Q' -and $n -match 'quy') -or ($kieu -eq 'Y' -and $n -match '^(to khai )?nam')) { if (ChonO $r) { Ghi ('Chon ' + $r.Current.Name) } }
}
Start-Sleep -Milliseconds 400
# Lan dau / Bo sung
foreach ($r in $radio) {
    $n = BoDau $r.Current.Name
    if (($ts.lan_dau -and $n -match 'lan dau') -or ((-not $ts.lan_dau) -and $n -match 'bo sung')) { if (ChonO $r) { Ghi ('Chon ' + $r.Current.Name) } }
}
# o ky: lam moi danh sach (doi thang / quy co the doi o)
$o = @()
foreach ($e in @($hop.FindAll($TS::Descendants, [System.Windows.Automation.Condition]::TrueCondition))) {
    try { $t = $e.Current.ControlType; if ($t -eq $CT::ComboBox -or $t -eq $CT::Edit -or $t -eq $CT::Spinner) { $o += $e } } catch { }
}
$nam = [string]$ts.nam
$ky = [string]$ts.ky        # thang (1-12) hoac quy (1-4); rong voi to khai nam
$daNam = $false; $daKy = $ts.ky -eq $null -or $ky -eq ''
foreach ($e in $o) {
    $v = (DocGiaTri $e).Trim()
    if (-not $daNam -and $v -match '^(19|20)\d\d$') {
        if ($v -ne $nam) { [void](DatGiaTri $e $nam) }
        $daNam = ((DocGiaTri $e).Trim() -eq $nam); Ghi ('O nam: ' + $v + ' -> ' + (DocGiaTri $e))
        continue
    }
    if (-not $daKy -and ($v -match '^(0?[1-9]|1[0-2])$' -or (BoDau $v) -match '^(thang|quy) ?\d')) {
        $so = [regex]::Match($v, '\d+').Value
        if ($so.TrimStart('0') -ne $ky.TrimStart('0')) { [void](DatGiaTri $e $ky) }
        $sau = [regex]::Match((DocGiaTri $e), '\d+').Value
        $daKy = ($sau.TrimStart('0') -eq $ky.TrimStart('0')); Ghi ('O ky: ' + $v + ' -> ' + (DocGiaTri $e))
    }
}
# phu luc co so lieu
foreach ($pl in @($ts.pl)) {
    $m = BoDau ([string]$pl)
    foreach ($c in $tick) {
        $n = BoDau $c.Current.Name
        if ($n -and ($n -eq $m -or $n.Contains($m) -or $m.Contains($n))) { if (TickO $c) { Ghi ('Tick phu luc ' + $c.Current.Name) } }
    }
}
if (-not ($daNam -and $daKy)) {
    Ghi ('Chua chac ky (nam ' + $daNam + ', ky ' + $daKy + ') - de nguoi dung kiem roi bam Dong y')
    Xong 'CHO_NGUOI_DUNG'
}
foreach ($b in $nut) {
    $n = BoDau $b.Current.Name
    if ($n -match '^(dong y|chap nhan|ok|mo to khai|tiep tuc)$') {
        $p = $null
        if ($b.TryGetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern, [ref]$p)) { $p.Invoke(); Ghi ('Bam ' + $b.Current.Name); Xong 'DA_MO' }
    }
}
Ghi 'Khong thay nut Dong y'
Xong 'CHO_NGUOI_DUNG'
