# -*- coding: utf-8 -*-
"""GD50 - Doc noi dung giao dich so phu cho dung:

  * nguoi tra + ngan hang nguoi tra (mau Sacombank "... CKN <so> [ma] - TEN - Ngan hang NH",
    ten co dau " - " ben trong van lay nguyen ven)
  * so hoa don: mot so, DANH SACH ("HD 521 528 555", "TTHD 803. 850. 862", "0706 -0712-0726-0743")
    va DAY ("tt hd 270-301", "tu 189 den 212", "tthd 246 den 269")
  * khoang ngay ghi trong noi dung ("tu 4/6 - 20/6/26", "ngay 20/5 den 3/6/26")
  * nhom goi y: luong viet tat ("lg t5", "tra lg"), hoan tien cho khach (chuyen nham / hoan tra)

Chi dung thu vien chuan. Moi ham tra ve gia tri rong khi khong doc duoc - khong bao gio nem loi
ra ngoai (mot dong hong khong duoc lam hong ca file so phu).
"""
import re
import unicodedata

__all__ = ["bo_dau", "nguoi_tra", "ma_ngan_hang", "so_hd_tokens", "khoang_ngay", "ngay_don",
           "loai_them", "doc_noi_dung"]


def bo_dau(s):
    s = str(s or "").replace("\u0110", "D").replace("\u0111", "d")
    return "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")


def _up(s):
    return re.sub(r"\s+", " ", bo_dau(s).upper()).strip()


# ------------------------------------------------------------------ ngan hang
# (mau trong ten ngan hang da bo dau, viet HOA) -> ma ngan. Thu tu quan trong: mau dai / rieng truoc.
_NH = [
    (r"SAI GON THUONG TIN|SACOMBANK", "STB"),
    (r"SAI GON CONG THUONG|SAIGONBANK", "SGB"),
    (r"SAI GON\s*-?\s*HA NOI|\bSHB\b", "SHB"),
    (r"\bA CHAU\b|\bACB\b", "ACB"),
    (r"NGOAI THUONG|VIETCOMBANK|\bVCB\b", "VCB"),
    (r"CONG THUONG|VIETINBANK|\bCTG\b|\bICB\b", "CTG"),
    (r"DAU TU VA PHAT TRIEN|\bBIDV\b", "BIDV"),
    (r"NONG NGHIEP|AGRIBANK|\bVBA\b", "AGR"),
    (r"KY THUONG|TECHCOMBANK|\bTCB\b", "TCB"),
    (r"QUAN DOI|\bMB\s*BANK\b|\bMBB\b|\bMB\b", "MB"),
    (r"THINH VUONG VA PHAT TRIEN|XANG DAU PETROLIMEX|PG\s*BANK", "PGB"),
    (r"VIET NAM THINH VUONG|VPBANK|\bVPB\b", "VPB"),
    (r"TIEN PHONG|TPBANK|\bTPB\b", "TPB"),
    (r"PHAT TRIEN (THANH PHO |TP\.? )?HO CHI MINH|HD\s*BANK|\bHDB\b", "HDB"),
    (r"\bQUOC TE\b|\bVIB\b", "VIB"),
    (r"HANG HAI|\bMSB\b|MARITIME", "MSB"),
    (r"PHUONG DONG|\bOCB\b", "OCB"),
    (r"DONG NAM A|SEABANK", "SEAB"),
    (r"XUAT NHAP KHAU|EXIMBANK|\bEIB\b", "EIB"),
    (r"LIEN VIET|LOC PHAT|LPBANK|\bLPB\b", "LPB"),
    (r"\bAN BINH\b|ABBANK", "ABB"),
    (r"\bBAC A\b|BACABANK", "BAB"),
    (r"\bNAM A\b|NAMABANK", "NAB"),
    (r"\bVIET A\b|VIETABANK", "VAB"),
    (r"BAN VIET|VIET CAPITAL|BVBANK", "BVB"),
    (r"KIEN LONG|KIENLONGBANK", "KLB"),
    (r"\bQUOC DAN\b|\bNCB\b", "NCB"),
    (r"DAI CHUNG|PVCOMBANK", "PVCB"),
    (r"BAO VIET", "BAOVIET"),
    (r"\bDONG A\b|DONGABANK", "DAB"),
    (r"DAI DUONG|OCEANBANK", "OJB"),
    (r"DAU KHI TOAN CAU|\bGPBANK\b", "GPB"),
    (r"XAY DUNG VIET NAM|\bCBBANK\b", "CBB"),
    (r"HOP TAC XA|CO-?OP\s*BANK", "COOP"),
    (r"VIET NAM THUONG TIN|VIETBANK", "VIETBANK"),
    (r"\bSAI GON\b|\bSCB\b", "SCB"),
    (r"SHINHAN", "SHBVN"),
    (r"WOORI", "WVN"),
    (r"\bUOB\b", "UOB"),
    (r"\bCIMB\b", "CIMB"),
    (r"\bHSBC\b", "HSBC"),
    (r"STANDARD CHARTERED", "SCVN"),
    (r"PUBLIC BANK", "PBVN"),
    (r"HONG LEONG", "HLBVN"),
    (r"INDOVINA", "IVB"),
    (r"CAKE", "CAKE"),
    (r"TIMO", "TIMO"),
]


def ma_ngan_hang(ten):
    """Ten ngan hang tren sao ke -> ma ngan (STB, ACB, VCB...). Khong nhan ra -> ten da bo dau, HOA, <= 40 ky tu."""
    u = _up(ten)
    if not u:
        return ""
    for rx, ma in _NH:
        if re.search(rx, u):
            return ma
    u = re.sub(r"^(NGAN HANG|NH)\s+", "", u)
    u = re.sub(r"^(TMCP|TM CP|THUONG MAI CO PHAN|TNHH MTV|TNHH)\s+", "", u)
    return u[:40]


# ------------------------------------------------------------------ nguoi tra
_TEN_RAC = {"TRANSFER", "CHUYEN TIEN", "CHUYEN KHOAN", "IBFT", "NAPAS", "QR", "KHACH HANG", "CUSTOMER", "UNKNOWN"}
_RX_CKN = re.compile(r"\bCKN\s*\d+\s*(?:[A-Za-z0-9]{6,14}\s*)?-\s*(.+?)\s*-\s*Ngan\s*hang\s*(.*)$", re.I)
_RX_NH_DUOI = re.compile(r"-\s*([^-]{3,80}?)\s*-\s*Ngan\s*hang\s*(.*)$", re.I)


def nguoi_tra(nd):
    """-> (ten, ngan_hang_text). Rong neu khong theo mau co ngan hang doi ung."""
    try:
        t = bo_dau(nd)
        m = _RX_CKN.search(t)
        if not m:
            m = _RX_NH_DUOI.search(t)
        if not m:
            return "", ""
        ten = re.sub(r"\s+", " ", m.group(1)).strip(" -.,")
        nh = re.sub(r"\s+", " ", m.group(2)).strip(" -.,")
        # Techcombank ghi them loai tien / loai TK truoc ten: "VND-TGTT-NGO VAN DUNG", "VND-HKD-HO KINH DOANH X"
        # (co dong lap ten hai lan: "X VND-HKD-X") -> lay manh cuoi
        ten = re.split(r"\s+(?=(?:VND|USD|EUR)\s*-)", ten, flags=re.I)[-1]
        while True:
            t2 = re.sub(r"^(?:VND|USD|EUR|TGTT|TKTT|HKD|CN|DN)\s*-\s*", "", ten, flags=re.I)
            if t2 == ten:
                break
            ten = t2
        if _up(ten) in _TEN_RAC:
            return "", nh[:60]
        # ten chi toan so / qua ngan -> khong phai ten
        if len(re.sub(r"[^A-Za-z]", "", ten)) < 3:
            return "", nh[:60]
        return ten[:120], nh[:60]
    except Exception:
        return "", ""


# ------------------------------------------------------------------ lam sach dau vet ngan hang
def _sach(nd):
    s = " " + bo_dau(nd).lower() + " "
    # Sacombank: -ddmmyy-hh:mm:ss <ma> CKN ... (ngan hang co khi chen dau cach vao giua: "-290 526-14:19:50")
    s = re.sub(r"-\s*\d[\d ]{4,8}\d\s*-\s*\d\d:\d\d:\d\d.*$", " ", s)
    # ky hieu hoa don dung truoc so: "1C26TRC 296", "C26TAA-123" -> coi nhu chu "hd"
    s = re.sub(r"\b\d?[a-z]\d{2}[a-z]{2,3}\b\s*[-/]?\s*(?=\d)", " hd ", s)
    s = re.sub(r"\bckn\b.*$", " ", s)
    s = re.sub(r"\bft\d{6,}\w*", " ", s)
    s = re.sub(r"\bewx\d+", " ", s)
    s = re.sub(r"\bmbvcb[.\d]*", " ", s)
    s = re.sub(r"\bibps\b.*$", " ", s)
    s = re.sub(r"(?<!\d)\d{9,}(?!\d)", " ", s)                # so TK, MST, ma giao dich dai
    # tach chu dinh so: "001ngay" -> "001 ngay", "hd1106" -> "hd 1106", "tthd0000424" -> "tthd 0000424"
    s = re.sub(r"(\d)([a-z])", r"\1 \2", s)
    s = re.sub(r"([a-z])(\d)", r"\1 \2", s)
    return s


def _nam(y, mac_dinh):
    if not y:
        return mac_dinh
    y = int(y)
    if y < 100:
        y += 2000
    return y if 2000 <= y <= 2099 else 0


def _ngay_hop_le(d, m, y):
    import datetime
    try:
        return datetime.date(int(y), int(m), int(d))
    except Exception:
        return None


_D = r"(?<!\d)(\d{1,2})\s*[/.\-]\s*(\d{1,2})(?:\s*[/.\-]\s*(\d{4}|\d{2}))?(?!\d)"
_RX_KHOANG = re.compile(r"(?:\btu\s*|\bngay\s*)?" + _D + r"\s*(?:-|den|toi|->|~)\s*(?:ngay\s*)?" + _D)
_RX_NGAY = [
    re.compile(r"\bngay\s*(\d{1,2})\s*[/.\-]\s*(\d{1,2})\s*[/.\-]\s*(\d{2,4})(?!\d)"),
    re.compile(r"\bngay\s*(\d{1,2})\s+(\d{1,2})\s+(\d{4})(?!\d)"),
    re.compile(r"\bngay\s*(\d{2})(\d{2})(\d{4})(?!\d)"),
    re.compile(r"(?<!\d)(\d{1,2})/(\d{1,2})/(\d{4})(?!\d)"),
    re.compile(r"(?<!\d)(\d{1,2})-(\d{1,2})-(\d{4})(?!\d)"),
    re.compile(r"\bngay\s*(\d{1,2})\s*[/.\-]\s*(\d{1,2})()(?![\d/.\-])"),
]


def khoang_ngay(nd, nam_gd=0, _s=None):
    """-> (tu_iso, den_iso, s_da_bo) : khoang ngay trong noi dung ("tu 4/6 - 20/6/26")."""
    s = _s if _s is not None else _sach(nd)
    try:
        for m in _RX_KHOANG.finditer(s):
            d1, m1, y1, d2, m2, y2 = m.groups()
            yy2 = _nam(y2, 0) or _nam(y1, 0) or nam_gd
            yy1 = _nam(y1, 0) or yy2
            if not yy1 or not yy2:
                continue
            a = _ngay_hop_le(d1, m1, yy1)
            b = _ngay_hop_le(d2, m2, yy2)
            if a and b and not y1 and a > b:
                a = _ngay_hop_le(d1, m1, yy1 - 1)       # "tu 20/12 den 5/1/27"
            if a and b and a <= b and (b - a).days <= 400:
                return a.isoformat(), b.isoformat(), s[:m.start()] + " " + s[m.end():]
    except Exception:
        pass
    return "", "", s


def ngay_don(nd, nam_gd=0, _s=None):
    """-> (iso, s_da_bo): mot ngay ghi trong noi dung (ngay hoa don)."""
    s = _s if _s is not None else _sach(nd)
    try:
        for rx in _RX_NGAY:
            m = rx.search(s)
            if not m:
                continue
            dd, mm, yy = m.group(1), m.group(2), m.group(3)
            y = _nam(yy, nam_gd) if yy else nam_gd
            if not y:
                continue
            d = _ngay_hop_le(dd, mm, y) or _ngay_hop_le(mm, dd, y)
            if d:
                return d.isoformat(), s[:m.start()] + " " + s[m.end():]
    except Exception:
        pass
    return "", s


# ------------------------------------------------------------------ so hoa don
_KW = (r"(?:tt\s*hd|tthd|thanh\s*toan\s*hd|so\s*hd|hd|h\s*\.\s*d|hoa\s*don|don\s*hang|"
       r"don|dh|hop\s*dong|invoice|inv)(?:\s*(?:gtgt|vat|dien\s*tu|ban\s*hang))?(?:\s*so)?")
_RX_KW = re.compile(r"\b" + _KW + r"\b\s*[:#]?\s*(?:tu\s+)?")
_RX_SO = re.compile(r"\s*(0*\d{1,7})(?!\d)")
_RX_NOI = re.compile(r"\s*(,|;|\.|\+|&|->|-|~|/|den\b|toi\b|va\b)?\s*")
_RX_TRUOC = re.compile(r"((?:(?<!\d)0*\d{1,7}(?!\d)[\s,;.]+){2,40})(?:tthd|hd)\b")
_DAI = ("-", "den", "toi", "->", "~")


def _day_so(s, i):
    """Doc chuoi so bat dau tu vi tri i: -> (danh sach so (str), danh sach dau noi giua cac so)."""
    so, noi = [], []
    while True:
        m = _RX_SO.match(s, i)
        if not m:
            break
        so.append(m.group(1))
        i = m.end()
        n = _RX_NOI.match(s, i)
        j = n.end()
        if not _RX_SO.match(s, j) or len(so) >= 40:
            break
        # dau cach tron khong co so theo sau ngay -> "83 cty 3s": dung o day
        noi.append((n.group(1) or " ").strip() or " ")
        i = j
    return so, noi


def _chuan_so(x):
    v = x.lstrip("0")
    return v if v and len(v) <= 7 else ""


def _noi_so_gay(so, noi):
    """"0428,044 3,0449": so bi chen dau cach o giua -> ghep lai khi do dai hai manh bang do dai pho bien."""
    if len(so) < 3:
        return so, noi
    dem = {}
    for x in so:
        dem[len(x)] = dem.get(len(x), 0) + 1
    w = max(dem, key=lambda k: (dem[k], k))
    if w < 3:
        return so, noi
    out, on = [so[0]], []
    for i in range(1, len(so)):
        if noi[i - 1] == " " and len(out[-1]) < w and len(out[-1]) + len(so[i]) == w:
            out[-1] = out[-1] + so[i]
        else:
            out.append(so[i])
            on.append(noi[i - 1])
    return out, on


def _token_tu_day(so, noi, co_tu=False):
    so, noi = _noi_so_gay(so, noi)
    so = [_chuan_so(x) for x in so]
    if not all(so):
        so = [x for x in so if x]
        noi = [" "] * max(0, len(so) - 1)
    if not so:
        return []
    if len(so) == 2 and (noi and noi[0] in _DAI or co_tu):
        a, b = int(so[0]), int(so[1])
        if 0 < b - a <= 500:
            return ["%d-%d" % (a, b)]
    return so


def so_hd_tokens(nd, _s=None):
    """-> chuoi "a,b,c-d" (so le va day so). Rong neu khong co."""
    try:
        s = _s if _s is not None else _sach(nd)
        # bo cum ngay con sot (dd/mm, dd.mm) - chi khi la ngay hop le
        def _bo(m):
            d, mth = int(m.group(1)), int(m.group(2))
            return " " if (1 <= d <= 31 and 1 <= mth <= 12) else m.group(0)
        s = re.sub(r"(?<!\d)(\d{1,2})\s*[/]\s*(\d{1,2})(?:\s*/\s*\d{2,4})?(?!\d)", _bo, s)
        s = re.sub(r"(?<!\d)(\d{1,2})\.(\d{1,2})\.(\d{2,4})(?!\d)", " ", s)
        # "hd67 26.2" : dd.mm dinh lien (khong dau cach sau dau cham) la NGAY, khong phai hai so hoa don
        s = re.sub(r"(?<![\d.])(\d{1,2})\.(\d{1,2})(?![\d.])", _bo, s)
        out = []
        for m in _RX_KW.finditer(s):
            co_tu = bool(re.search(r"\btu\s+$", m.group(0)))
            so, noi = _day_so(s, m.end())
            for t in _token_tu_day(so, noi, co_tu):
                if t not in out:
                    out.append(t)
        for m in _RX_TRUOC.finditer(s):
            so = re.findall(r"\d+", m.group(1))
            for t in _token_tu_day(so, [" "] * (len(so) - 1)):
                if t not in out:
                    out.append(t)
        kq = ""
        for t in out:
            if len(kq) + len(t) + 1 > 120:
                break
            kq = kq + ("," if kq else "") + t
        return kq
    except Exception:
        return ""


# ------------------------------------------------------------------ nhom goi y bo sung
_RX_LG = re.compile(r"\bLG\s*T\s*\d{1,2}\b|\b(?:TT|TRA|CHI|THANH TOAN)\s+LG\b|\bLG\s+THANG\b|\bTIEN\s+LG\b")
_RX_LUONG_DAU = re.compile(r"^(?:TRA |CHI |TT |THANH TOAN )?(?:LUONG|LG)\b")
_RX_HOAN = re.compile(r"\b(?:HOAN TIEN|HOAN TRA|HOAN LAI TIEN|TRA LAI TIEN(?! GUI)|TRA LAI KHACH|"
                      r"CHUYEN NHAM|CK NHAM|CHUYEN KHOAN NHAM|NHAM TAI KHOAN|NHAM TK|TRA LAI TIEN THUA)\b")
_RX_UNG = re.compile(r"\bUNG LUONG\b|\bTAM UNG\b|\bUNG TRUOC\b|\bHOAN UNG\b")


def loai_them(nd, chieu="", loai_cu=""):
    """Bo sung cho phan loai cu: LUONG (viet tat "lg t5", "tra lg"; tien RA bat dau bang "luong"),
       HOAN_TIEN (tra lai tien khach chuyen nham). Giu nguyen loai cu neu da co."""
    if loai_cu:
        return loai_cu
    try:
        u = re.sub(r"[^A-Z0-9 ]+", " ", _up(nd))
        u = re.sub(r"\s+", " ", u).strip()
        if _RX_UNG.search(u):
            return ""
        if _RX_LG.search(u):
            return "LUONG"
        if chieu == "RA" and _RX_LUONG_DAU.search(u):
            return "LUONG"
        if _RX_HOAN.search(u):
            return "HOAN_TIEN"
    except Exception:
        pass
    return ""


# ------------------------------------------------------------------ tong hop
def doc_noi_dung(nd, chieu="", nam_gd=0):
    """-> dict: ten_tra, nh_tra, ma_nh_tra, so_hd, ngay_tu, ngay_den, ngay_hd."""
    kq = {"ten_tra": "", "nh_tra": "", "ma_nh_tra": "", "so_hd": "", "ngay_tu": "", "ngay_den": "", "ngay_hd": ""}
    try:
        ten, nh = nguoi_tra(nd)
        kq["ten_tra"], kq["nh_tra"] = ten, nh
        kq["ma_nh_tra"] = ma_ngan_hang(nh) if nh else ""
        s = _sach(nd)
        tu, den, s = khoang_ngay(nd, nam_gd, s)
        kq["ngay_tu"], kq["ngay_den"] = tu, den
        if not tu:
            d, s = ngay_don(nd, nam_gd, s)
            kq["ngay_hd"] = d
        kq["so_hd"] = so_hd_tokens(nd, s)
    except Exception:
        pass
    return kq
