# -*- coding: utf-8 -*-
"""GD121 - TO KHAI DANG KY THUE TONG HOP CUA CA NHAN CO THU NHAP TU TIEN LUONG, TIEN CONG - mau 05-DKT-TH (Thong tu
90/2026/TT-BTC, ap dung tu 01/7/2026, thay 05-DK-TH-TCT cua Thong tu 86/2024/TT-BTC). To chuc tra thu nhap dang ky thue thay
cho nguoi lao dong uy quyen. Thay lua chon "Danh sach dang ky thue" cu cua man hinh Bao cao (mau noi bo, cot CMND / quan-huyen,
INNER JOIN danh muc dia danh -> in trong khi nhan vien chua co ma dia danh).
Hop dong xuat_1_lan.py: lap(dl, "DK_TNCN", kieu, thumuc) -> {"tep": [...], "canh_bao": [...]}. CHI DOC SO.
So lieu: dl["tncn"]["nv"] (ho so nhan vien) + dl["tncn"]["nv_dk"] (GD121: gioi tinh, ngay cap, noi cap, dia chi thuong tru /
hien tai theo ten xa-phuong / tinh, dien thoai, email) + bang luong (nguoi co thu nhap trong nam).
Lap: nguoi dang lam viec (khong danh dau nghi viec) CHUA co ma so thue trong ho so. Cong dan Viet Nam co so dinh danh trong
CSDL quoc gia ve dan cu chi can so dinh danh (co quan thue tu lay dia chi) - mau van ghi dia chi phan mem co de tham khao.
Chi lap Excel: HTKK 5.7.7 co to nay voi ten 05-DK-TH-TCT (TT90/2026, maTKhai 1135, 3.0.8) nhung phan mem chua lap XML cho to nay
(chua doi chieu khuon) - nhap danh sach tren HTKK / Cong thue dien tu.
Khong ghi so CCCD / MST vao nhat ky (chi co trong tep)."""
import os
import re

import qtt_tncn as Q
from qtt_tncn import _ds, _dn, _ngay_lap, _nguoi_ky, _kieu, _cot_chia

COT = ["STT", "Họ và tên", "Mã số thuế\n(ghi khi thay đổi thông tin)", "Ngày, tháng, năm sinh", "Giới tính", "Quốc tịch",
       "Số định danh cá nhân\n(công dân Việt Nam)", "Hộ chiếu: số, ngày cấp, nơi cấp\n(người nước ngoài)",
       "Địa chỉ thường trú\n(số nhà / đường; xã, phường, đặc khu; tỉnh, thành phố)",
       "Địa chỉ hiện tại\n(số nhà / đường; xã, phường, đặc khu; tỉnh, thành phố)", "Điện thoại", "Email"]
RONG = [5, 24, 13, 11, 7, 11, 15, 18, 34, 34, 12, 20]


def _dk(r):
    r = list(r) + [""] * 14
    return {"manv": Q._nguyen(r[0]), "phai": Q._ten_sach(r[1]), "ngay_cap": str(r[2] or ""), "noi_cap": Q._ten_sach(r[3]),
            "dc_hk": Q._ten_sach(r[4]), "xa_hk": Q._ten_sach(r[5]), "tinh_hk": Q._ten_sach(r[6]), "dc_ct": Q._ten_sach(r[7]),
            "xa_ct": Q._ten_sach(r[8]), "tinh_ct": Q._ten_sach(r[9]), "tel": str(r[10] or "").strip(), "mail": str(r[11] or "").strip(),
            "huyen_hk": Q._ten_sach(r[12]), "huyen_ct": Q._ten_sach(r[13])}


def _dia_chi(*phan):
    return ", ".join(p for p in phan if p and p not in (".", "...", "0"))


def _gioi(s):
    k = Q.khoa_ten(s)
    if k.startswith("nam"):
        return "Nam"
    if k.startswith("nu"):
        return "Nữ"
    return s or ""


def tong_hop(dl):
    t = dl.get("tncn")
    if not isinstance(t, dict):
        raise RuntimeError("JSON không có phần \"tncn\" (bản phần mềm chưa có GĐ78 ModHDDTTNCN?)")
    if t.get("loi"):
        raise RuntimeError("Phần mềm không lấy được hồ sơ nhân viên: %s" % t["loi"])
    nam = Q._nguyen(t.get("nam")) or Q._nguyen((dl.get("x1l") or {}).get("nam_tc"))
    dk = {}
    for r in t.get("nv_dk") or []:
        d = _dk(r)
        if d["manv"]:
            dk[d["manv"]] = d
    co_luong = {Q._nguyen((list(r) + [0])[0]) for r in t.get("thang") or []}
    ds, co_mst, nghi, thieu, nn, cu9, ko_dk = [], 0, [], [], [], [], []
    for r in t.get("nv") or []:
        v = Q._nv(r)
        if not v["manv"]:
            continue
        mst = re.sub(r"[^0-9-]", "", v["mst"]).strip("-")
        if Q.RE_TIN.fullmatch(mst or ""):
            co_mst += 1
            continue
        if v["nghi"]:
            nghi.append(v["ten"])
            continue
        d = dk.get(v["manv"]) or _dk([v["manv"]])
        if v["manv"] not in dk:
            ko_dk.append(v["ten"])
        g = re.sub(r"[^0-9A-Za-z]", "", v["cccd"]).upper()
        vn = Q.la_viet_nam(v["quoc_tich"])
        so_dd, ho_chieu = "", ""
        if vn:
            if g.isdigit() and len(g) == 12:
                so_dd = g
            elif g:
                cu9.append(v["ten"])
                so_dd = g
            else:
                thieu.append(v["ten"])
        else:
            nn.append(v["ten"])
            hc = [g] if g else []
            if d["ngay_cap"]:
                hc.append("cấp " + d["ngay_cap"])
            if d["noi_cap"]:
                hc.append(d["noi_cap"])
            ho_chieu = ", ".join(hc)
            if not g:
                thieu.append(v["ten"])
        qt = v["quoc_tich"]
        if not qt or qt.isdigit():
            qt = "Việt Nam" if vn else qt
        ds.append({"ten": v["ten"], "mst": "", "ngay_sinh": v["ngay_sinh"], "gioi": _gioi(d["phai"]), "qt": qt, "so_dd": so_dd,
                   "ho_chieu": ho_chieu, "dc_hk": _dia_chi(d["dc_hk"], d["xa_hk"], d["tinh_hk"]),
                   "dc_ct": _dia_chi(d["dc_ct"], d["xa_ct"], d["tinh_ct"]), "tel": d["tel"], "mail": d["mail"],
                   "co_luong": v["manv"] in co_luong, "co_huyen": bool(d["huyen_hk"] or d["huyen_ct"]),
                   "manv": v["manv"], "d": d, "giay_to": g})          # XII: raw fields for the HTKK XML (xii_dk_tncn_xml.py)
    cb = []
    cb.append("05-ĐKT-TH: %d người lao động đang làm việc chưa có mã số thuế trong hồ sơ (%d người đã có MST - không kê)." % (len(ds), co_mst))
    if thieu:
        cb.append("%d người THIẾU số định danh cá nhân / hộ chiếu - bắt buộc trước khi nộp (bổ sung hồ sơ nhân viên; Trợ lý AI: nhập danh "
                  "sách tham gia BHXH để điền CCCD): %s." % (len(thieu), _ds(thieu)))
    if cu9:
        cb.append("Số giấy tờ không phải số định danh 12 số (CMND cũ 9 số?) - thay bằng số định danh cá nhân: %s." % _ds(cu9))
    if nn:
        cb.append("Người nước ngoài (kê hộ chiếu; kiểm tra quốc tịch, ngày cấp, nơi cấp): %s." % _ds(nn))
    if nghi:
        cb.append("Không kê %d người đã nghỉ việc chưa có MST: %s." % (len(nghi), _ds(nghi)))
    if ko_dk:
        cb.append("Phần mềm chưa gửi địa chỉ / liên hệ của nhân viên (bản VB chưa Make .exe GĐ121?) - cột địa chỉ để trống: %s." % _ds(ko_dk))
    if any(x["co_huyen"] for x in ds):
        cb.append("Hồ sơ nhân viên còn ghi quận / huyện - mẫu Thông tư 90/2026 chỉ ghi xã / phường / đặc khu và tỉnh, thành phố (chính quyền "
                  "hai cấp từ 01/7/2025) nên không đưa quận / huyện vào địa chỉ.")
    if any(not x["dc_hk"] and not x["dc_ct"] for x in ds):
        cb.append("Một số người chưa có địa chỉ trong hồ sơ: công dân Việt Nam đã có số định danh trong CSDL quốc gia về dân cư thì cơ quan "
                  "thuế tự lấy địa chỉ (chỉ cần số định danh).")
    khong_luong = [x["ten"] for x in ds if not x["co_luong"]]
    if khong_luong and len(khong_luong) < len(ds):
        cb.append("Chưa có bảng lương trong năm (mới tuyển?) - vẫn kê để đăng ký: %s." % _ds(khong_luong))
    return {"nam": nam, "ds": ds, "canh_bao": cb}


def lap_excel(dl, kq, duong, cb):
    from xlsx_viet import SoExcel
    wb = SoExcel(font="Times New Roman", co=11)
    K = _kieu(wb)
    dn = _dn(dl)
    so_cot = len(RONG)
    ws = wb.sheet("05-DKT-TH", cot=RONG)
    c_mau = _cot_chia(RONG, tu_phai=40)
    ws.gop(1, 1, 1, c_mau - 1, "CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM", K["qh"])
    ws.gop(2, 1, 2, c_mau - 1, "Độc lập - Tự do - Hạnh phúc", K["qh2"])
    ws.gop(1, c_mau, 3, so_cot, "Mẫu số: 05-ĐKT-TH\n(Ban hành kèm theo Thông tư số 90/2026/TT-BTC của Bộ trưởng Bộ Tài chính)\n"
                                "(trên HTKK: 05-ĐK-TH-TCT TT90/2026)", K["mau"])
    ws.cao(3, 42)
    r = 5
    ws.gop(r, 1, r, so_cot, "TỜ KHAI ĐĂNG KÝ THUẾ TỔNG HỢP CỦA CÁ NHÂN CÓ THU NHẬP TỪ TIỀN LƯƠNG, TIỀN CÔNG", K["td"])
    r += 1
    ws.gop(r, 1, r, so_cot, "(Dùng cho tổ chức trả thu nhập đăng ký thuế thay cho cá nhân có ủy quyền)", K["td2"])
    r += 2
    ws.gop(r, 1, r, so_cot, "[X] Đăng ký thuế                 [   ] Thay đổi thông tin đăng ký thuế", K["qh"])
    r += 2
    ws.gop(r, 1, r, so_cot, "Tên tổ chức trả thu nhập: %s" % dn.get("ten", ""), K["b"])
    r += 1
    ws.gop(r, 1, r, so_cot, "Mã số thuế: %s" % dn.get("mst", ""), K["b"])
    r += 1
    ws.gop(r, 1, r, so_cot, "Cơ quan thuế quản lý: %s" % (dn.get("ten_cqt") or ""), K["t"])
    r += 2
    ws.dong(r, 1, COT, K["h"])
    ws.cao(r, 60)
    r += 1
    ws.dong(r, 1, ["(%d)" % (i + 1) for i in range(so_cot)], K["hm"])
    r += 1
    dau = r
    for i, x in enumerate(kq["ds"], 1):
        ws.dong(r, 1, [(i, K["cg"]), (x["ten"], K["c"]), (x["mst"], K["txt"]), (x["ngay_sinh"], K["cg"]), (x["gioi"], K["cg"]),
                       (x["qt"], K["cg"]), (x["so_dd"], K["txt"]), (x["ho_chieu"], K["c"]), (x["dc_hk"], K["c"]), (x["dc_ct"], K["c"]),
                       (x["tel"], K["txt"]), (x["mail"], K["c"])])
        if max(len(x["dc_hk"]), len(x["dc_ct"])) > 40:
            ws.cao(r, 15 * ((max(len(x["dc_hk"]), len(x["dc_ct"])) + 39) // 40))
        r += 1
    if r == dau:
        ws.gop(r, 1, r, so_cot, "(Không có người lao động đang làm việc chưa có mã số thuế)", K["ghi"])
        r += 1
    r += 1
    ws.gop(r, 1, r, so_cot, "Ghi chú: Cá nhân là công dân Việt Nam có thông tin trong Cơ sở dữ liệu quốc gia về dân cư chỉ cần kê số định danh "
                            "cá nhân; cơ quan thuế tự tích hợp thông tin địa chỉ. Trường hợp thay đổi thông tin chỉ ghi các chỉ tiêu thay đổi.",
           K["ghi"])
    ws.cao(r, 30)
    r += 1
    ws.gop(r, 1, r, so_cot, "Tôi cam đoan những nội dung kê khai là đúng và chịu trách nhiệm trước pháp luật về những nội dung đã khai./.", K["ghi"])
    r += 2
    lap = _ngay_lap(dl)
    giua = _cot_chia(RONG, ty_le=0.55)
    ws.gop(r, giua, r, so_cot, "..., ngày %02d tháng %02d năm %d" % (lap.day, lap.month, lap.year), K["ky2"])
    r += 1
    ws.gop(r, giua, r, so_cot, "NGƯỜI NỘP THUẾ hoặc\nĐẠI DIỆN HỢP PHÁP CỦA NGƯỜI NỘP THUẾ", K["ky"])
    ws.cao(r, 45)
    r += 1
    ws.gop(r, giua, r, so_cot, "(Ký, ghi rõ họ tên; chức vụ và đóng dấu (nếu có)/Ký điện tử)", K["ky2"])
    r += 4
    ws.gop(r, giua, r, so_cot, _nguoi_ky(dl), K["ky"])
    ws.dong_bang(dau, 3)
    ws.in_trang(ngang=True, lap_dong=(dau - 2, dau - 1))
    ws2 = wb.sheet("Ghi chu", cot=[120])
    ws2.o(1, 1, "GHI CHÚ KHI LẬP 05-ĐKT-TH", K["qh"])
    rr = 3
    for c in cb:
        ws2.o(rr, 1, "- " + c, K["ghi"])
        ws2.cao(rr, 15 * max(1, (len(c) + 119) // 120))
        rr += 1
    wb.luu(duong)
    return duong


def lap(dl, ma="DK_TNCN", kieu="E", thumuc="."):
    kq = tong_hop(dl)
    cb = kq["canh_bao"]
    tep = []
    if (kieu or "E").upper().find("X") >= 0:          # XII: XML of 05-DK-TH-TCT (HTKK 5.8.1, TT90/2026, 3.0.8)
        import xii_dk_tncn_xml as XX
        px = XX.lap_xml(dl, kq, thumuc, cb)
        if px:
            tep.append(px)
    if (kieu or "E").upper().find("E") >= 0 or not tep:
        p = os.path.join(thumuc, "05_DKT_TH_%d.xlsx" % (kq["nam"] or 0))
        lap_excel(dl, kq, p, list(cb))
        tep.insert(0, p)
    return {"tep": tep, "canh_bao": cb}
