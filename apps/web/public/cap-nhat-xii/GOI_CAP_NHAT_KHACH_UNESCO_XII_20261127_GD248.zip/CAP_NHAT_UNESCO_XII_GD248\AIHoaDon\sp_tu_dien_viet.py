# -*- coding: utf-8 -*-
"""GD83 - tu dien cho bo dich noi dung so phu sang tieng Viet co dau (sp_dich_viet.py).

Du lieu nam trong file .py (khong phai .txt) de goi tu dong cap nhat (tao_ban_phat_hanh.py chi chep AIHoaDon/*.py)
mang theo. Sua tu dien: sua chuoi DU_LIEU ben duoi (dinh dang ghi o dau chuoi)."""

DU_LIEU = r"""
# sp_tu_dien_viet.py (DU_LIEU) - GD83: tu dien dich noi dung so phu ngan hang sang tieng Viet co dau (sp_dich_viet.py)
# Dinh dang:
#   [VIET]  moi dong mot cum tu co dau (dau thanh kieu cu: hóa, thủy, ủy); @<so> dat trong so cho cac dong ben duoi
#           (trong so = so lan "gap" cum tu - cang lon cang uu tien khi mot chu khong dau co nhieu cach dat dau)
#   [ANH]   cum tieng Anh => ban dich tieng Viet (bo trong ben phai = bo tu: for, of, the...)
#   [TAT]   viet tat khong dau => viet tat co dau (hd => hđ)
# Khong ghi ten khach hang / so tai khoan vao day - ten doi tac cua tung so sach lay tu danh muc (sp_ngu_lieu.txt).

[VIET]
@60
thanh toán
thanh toán tiền hàng
thanh toán tiền
thanh toán hóa đơn
thanh toán hóa đơn số
thanh toán tiền hàng theo hóa đơn
thanh toán tiền hàng theo hóa đơn số
thanh toán tiền hàng hóa đơn số
thanh toán hợp đồng
thanh toán công nợ
thanh toán cho
thanh toán tiền mua hàng
thanh toán tiền điện
thanh toán tiền nước
thanh toán lương
thanh toán tiền lương
thanh toán tiền thuê
thanh toán tiền cước
thanh toán phí
thanh toán đơn hàng
thanh toán thẻ
thanh toán thẻ tín dụng
thanh toán hộ
thanh toán lần
thanh toán đợt
thanh toán nốt
thanh toán hết
thanh toán một phần
thanh toán trước
tạm thanh toán
đã thanh toán
chưa thanh toán
chuyển khoản
chuyển tiền
chuyển tiền hàng
chuyển tiền mua hàng
chuyển tiền thanh toán
chuyển trả
chuyển trả tiền hàng
chuyển trả tiền
chuyển khoản nhanh
chuyển khoản nội bộ
chuyển tiền nội bộ
chuyển khoản ngoài hệ thống
chuyển tiền ngoài hệ thống
chuyển khoản liên ngân hàng
chuyển tiền liên ngân hàng
chuyển tiền nhanh
chuyển nhầm
chuyển trả lại tiền
chuyển trả lại tiền khách chuyển nhầm
trả lại tiền chuyển nhầm
chuyển sang tài khoản
chuyển về tài khoản
chuyển từ tài khoản
chuyển tiền từ
chuyển tiền đến
chuyển tiền cho
nhận tiền
nhận tiền từ
nhận tiền hàng
nhận chuyển khoản
nhận tiền chuyển khoản
tiền hàng
tiền điện
tiền nước
tiền thuê nhà
tiền thuê xưởng
tiền thuê văn phòng
tiền thuê kho
tiền thuê mặt bằng
tiền thuê xe
tiền cước
tiền cước vận chuyển
tiền cọc
tiền đặt cọc
đặt cọc
đặt cọc tiền hàng
đặt hàng
tiền lương
tiền thưởng
tiền lãi
tiền gửi
tiền gửi thanh toán
tiền gửi có kỳ hạn
tiền gửi không kỳ hạn
tiền mặt
nộp tiền
nộp tiền mặt
nộp tiền vào tài khoản
nộp tiền mặt vào tài khoản
nộp tiền mặt tại quầy
rút tiền
rút tiền mặt
rút tiền mặt tại quầy
rút tiền mặt nhập quỹ
rút tiền nhập quỹ
nhập quỹ tiền mặt
nhập quỹ
phí
phí dịch vụ
phí chuyển tiền
phí chuyển khoản
phí chuyển tiền ngoài hệ thống
phí chuyển khoản ngoài hệ thống
phí chuyển tiền trong hệ thống
phí chuyển khoản nhanh
phí quản lý tài khoản
phí duy trì tài khoản
phí dịch vụ tài khoản
phí thường niên
phí phát hành
phí phát hành thẻ
phí rút tiền
phí nộp tiền
phí kiểm đếm
phí ngân hàng
phí dịch vụ ngân hàng
phí dịch vụ tin nhắn
phí tin nhắn
phí dịch vụ ngân hàng điện tử
ngân hàng điện tử
ngân hàng số
thu phí
thu phí dịch vụ
thu phí chuyển tiền
thu phí quản lý tài khoản
thu phí dịch vụ tin nhắn chủ động
dịch vụ tin nhắn chủ động
tin nhắn chủ động
chủ động
thông báo số dư
thông báo biến động số dư
biến động số dư
số dư
số dư tài khoản
lãi
lãi tiền gửi
lãi tiền gửi thanh toán
lãi tiền gửi không kỳ hạn
lãi nhập gốc
trả lãi
trả lãi tiền gửi
trả lãi tài khoản
trả lãi tài khoản tiền gửi
trả lãi tiền vay
trả lãi vay
trả lãi hợp đồng
lãi vay
lãi vay hợp đồng
tiền lãi vay
thu lãi
thu lãi tiền vay
thu lãi vay
thu nợ
thu nợ gốc
thu nợ lãi
thu nợ gốc và lãi
trả nợ
trả nợ gốc
trả nợ vay
trả nợ gốc vay
trả gốc
trả gốc và lãi
nợ gốc
gốc vay
giải ngân
giải ngân khoản vay
giải ngân hợp đồng
giải ngân theo hợp đồng tín dụng
hợp đồng tín dụng
khế ước
khế ước nhận nợ
khoản vay
tất toán
tất toán tài khoản
tất toán sổ tiết kiệm
tất toán hợp đồng
tiết kiệm
sổ tiết kiệm
gửi tiết kiệm
ký quỹ
tiền ký quỹ
bảo lãnh
phí bảo lãnh
thư tín dụng
ngoại tệ
mua ngoại tệ
bán ngoại tệ
tỷ giá
trả lại
trả lại tiền
hoàn tiền
hoàn trả
hoàn trả tiền
hoàn lại
hoàn ứng
tạm ứng
tạm ứng lương
tạm ứng tiền
tạm ứng tiền hàng
ứng lương
ứng trước
ứng tiền
trả trước
trả trước tiền hàng
trả tiền
trả tiền hàng
trả tiền mua hàng
trả tiền cho
mua hàng
bán hàng
tiền bán hàng
tiền mua hàng
doanh thu
doanh số
công nợ
đối trừ công nợ
cấn trừ công nợ
bù trừ công nợ
hóa đơn
hóa đơn giá trị gia tăng
hóa đơn điện tử
hóa đơn số
số hóa đơn
theo hóa đơn
theo hóa đơn số
các hóa đơn
đơn hàng
đơn đặt hàng
theo đơn hàng
phiếu xuất kho
phiếu nhập kho
phiếu chi
phiếu thu
biên bản
biên bản đối chiếu công nợ
biên bản bàn giao
biên lai
giấy báo có
giấy báo nợ
báo có
báo nợ
ủy nhiệm chi
lệnh chi
séc
chi lương
chi lương tháng
chi trả
chi hộ
thu hộ
lương tháng
lương cán bộ nhân viên
trả lương
trả lương tháng
trả lương nhân viên
thanh toán lương tháng
tiền lương tháng
thưởng tết
thưởng
tiền công
tiền làm thêm giờ
phụ cấp
tiền phụ cấp
công tác phí
tiền ăn
tiền ăn ca
bảo hiểm
bảo hiểm xã hội
bảo hiểm y tế
bảo hiểm thất nghiệp
bảo hiểm tai nạn
bảo hiểm cháy nổ
bảo hiểm xe
kinh phí công đoàn
đoàn phí công đoàn
nộp bảo hiểm xã hội
thuế
nộp thuế
tiền thuế
thuế giá trị gia tăng
thuế thu nhập doanh nghiệp
thuế thu nhập cá nhân
thuế môn bài
lệ phí môn bài
lệ phí
thuế nhập khẩu
thuế xuất khẩu
nộp ngân sách nhà nước
ngân sách nhà nước
kho bạc nhà nước
kho bạc
cục thuế
chi cục thuế
tiền chậm nộp
chậm nộp
tiền phạt
phạt chậm nộp
ngân hàng
ngân hàng thương mại cổ phần
chi nhánh
phòng giao dịch
tài khoản
số tài khoản
chủ tài khoản
tài khoản thanh toán
tài khoản tiền gửi
người chuyển
người nhận
người thụ hưởng
người hưởng
người nộp
mã giao dịch
giao dịch
ngày giao dịch
số tham chiếu
tham chiếu
số chứng từ
chứng từ
ngày
tháng
năm
quý
đợt
lần
kỳ
kỳ hạn
định kỳ
hàng tháng
hàng quý
hàng năm
cuối kỳ
đầu kỳ
cuối tháng
đầu tháng
còn lại
còn nợ
số tiền còn lại
tiền còn thiếu
thanh toán tiếp
theo
theo hợp đồng
theo hợp đồng số
hợp đồng số
hợp đồng kinh tế
hợp đồng mua bán
hợp đồng thuê
hợp đồng dịch vụ
hợp đồng vận chuyển
phụ lục hợp đồng
theo bảng kê
bảng kê
đối chiếu
xác nhận
cước vận chuyển
phí vận chuyển
vận chuyển
giao hàng
nhận hàng
tiền xe
tiền xăng
xăng dầu
tiền điện thoại
cước điện thoại
cước viễn thông
dịch vụ viễn thông
phí bảo trì
bảo trì
bảo dưỡng
sửa chữa
tiền sửa chữa
lắp đặt
thi công
nghiệm thu
mua vật tư
mua nguyên liệu
mua nguyên vật liệu
nguyên vật liệu
nguyên liệu
vật liệu
vật tư
hàng hóa
thành phẩm
sản phẩm
phế liệu
bán phế liệu
dịch vụ
cung cấp dịch vụ
cung cấp
cung ứng
góp vốn
vốn góp
góp vốn điều lệ
tăng vốn
vốn điều lệ
vay
cho vay
vay ngắn hạn
vay dài hạn
vay cá nhân
vay mượn
mượn tiền
tiền mượn
trả tiền mượn
nội bộ
chuyển nội bộ
tiền khách hàng
khách hàng
nhà cung cấp
đối tác
khách lẻ
người mua
người bán
bên mua
bên bán
giám đốc
kế toán
thủ quỹ
nhân viên
công nhân
cán bộ công nhân viên
tiếp khách
chi phí
chi phí khác
thu khác
chi khác
hoa hồng
chiết khấu
chiết khấu thương mại
giảm giá
khuyến mại
cổ tức
chia lợi nhuận
lợi nhuận
thanh lý
thanh lý tài sản
thanh lý hợp đồng
tài sản
mua tài sản
mua xe
mua máy
thiết bị
máy móc
máy móc thiết bị
văn phòng phẩm
in ấn
quảng cáo
tên miền
phần mềm
phí phần mềm
chữ ký số
phí chữ ký số
phí gia hạn
gia hạn
hóa đơn tiền điện
hóa đơn tiền nước
tiền rác
tiền vệ sinh
tiền bảo vệ
phí quản lý
phí quản lý tòa nhà
tiền nhà
tiền đất
mua đất
học phí
viện phí
tiền thuốc
từ thiện
ủng hộ
quyên góp
sinh nhật
đám cưới
tiền mừng
tiền phúng điếu
hiếu hỉ
công đoàn
kinh phí
hỗ trợ
tiền hỗ trợ
bồi thường
tiền bồi thường
đền bù
nợ
còn nợ tiền hàng
trả nợ tiền hàng
thu tiền
thu tiền hàng
thu tiền bán hàng
thu tiền khách hàng
thu nợ khách hàng
khách chuyển
khách hàng chuyển
khách hàng thanh toán
khách thanh toán
tiền khách thanh toán
tiền khách chuyển
chuyển trả nhà cung cấp
@40
công ty
công ty trách nhiệm hữu hạn
công ty cổ phần
công ty trách nhiệm hữu hạn một thành viên
trách nhiệm hữu hạn
một thành viên
hai thành viên trở lên
cổ phần
doanh nghiệp
doanh nghiệp tư nhân
hộ kinh doanh
cửa hàng
đại lý
nhà máy
xưởng
xưởng sản xuất
tập đoàn
tổng công ty
hợp tác xã
văn phòng
văn phòng đại diện
chi nhánh công ty
trung tâm
cơ sở
cơ sở sản xuất
sản xuất
thương mại
dịch vụ
sản xuất thương mại
sản xuất thương mại dịch vụ
thương mại dịch vụ
thương mại và dịch vụ
thương mại dịch vụ xuất nhập khẩu
xây dựng
thương mại xây dựng
xuất nhập khẩu
xuất khẩu
nhập khẩu
đầu tư
phát triển
đầu tư phát triển
đầu tư và phát triển
kỹ thuật
công nghệ
kỹ thuật công nghệ
vận tải
giao nhận
giao nhận vận tải
kho vận
cơ khí
điện
điện tử
điện lạnh
điện máy
điện công nghiệp
tự động hóa
nhựa
bao bì
bao bì nhựa
nhôm
nhôm định hình
thép
sắt thép
inox
kim loại
tôn
tôn thép
giấy
bao bì giấy
in
in ấn
hóa chất
thực phẩm
nông sản
thủy sản
hải sản
dệt may
may mặc
dệt
may
gỗ
nội thất
vật liệu xây dựng
thiết bị
máy móc
phụ tùng
linh kiện
ô tô
xe máy
môi trường
tư vấn
tư vấn thuế
đại lý thuế
kế toán
dịch vụ kế toán
kiểm toán
thiết kế
quảng cáo
truyền thông
du lịch
lữ hành
khách sạn
nhà hàng
ăn uống
y tế
dược phẩm
thiết bị y tế
giáo dục
đào tạo
bất động sản
năng lượng
năng lượng mặt trời
xăng dầu
khí đốt
cao su
sơn
xi măng
gạch
đá
cát
thủy tinh
kính
đồ gỗ
mỹ phẩm
thời trang
giày dép
văn phòng phẩm
viễn thông
tin học
máy tính
phần mềm
công nghiệp
nông nghiệp
lâm nghiệp
chăn nuôi
thức ăn chăn nuôi
phân bón
thuốc bảo vệ thực vật
nước giải khát
bánh kẹo
cà phê
gạo
lương thực
bột
dầu
dầu nhớt
khuôn mẫu
khuôn
đúc
gia công
gia công cơ khí
chế biến
chế tạo
lắp ráp
tái chế
sơn tĩnh điện
xử lý
cấp thoát nước
phòng cháy chữa cháy
an ninh
bảo vệ
vệ sinh
vệ sinh công nghiệp
cây xanh
cảnh quan
trang trí
quà tặng
đồ chơi
dụng cụ
công cụ
thiết bị điện
dây cáp
dây điện
bóng đèn
chiếu sáng
ống nhựa
máy bơm
máy nén khí
khí công nghiệp
@15
thành phố
thành phố Hồ Chí Minh
Hồ Chí Minh
Hà Nội
Việt Nam
Sài Gòn
Đà Nẵng
Hải Phòng
Cần Thơ
Bình Dương
Đồng Nai
Long An
Bà Rịa Vũng Tàu
Vũng Tàu
Tây Ninh
Bình Phước
Tiền Giang
Bến Tre
Vĩnh Long
Trà Vinh
Đồng Tháp
An Giang
Kiên Giang
Hậu Giang
Sóc Trăng
Bạc Liêu
Cà Mau
Lâm Đồng
Đà Lạt
Khánh Hòa
Nha Trang
Ninh Thuận
Bình Thuận
Phú Yên
Bình Định
Quảng Ngãi
Quảng Nam
Thừa Thiên Huế
Huế
Quảng Trị
Quảng Bình
Hà Tĩnh
Nghệ An
Thanh Hóa
Ninh Bình
Nam Định
Thái Bình
Hà Nam
Hưng Yên
Hải Dương
Bắc Ninh
Bắc Giang
Quảng Ninh
Lạng Sơn
Cao Bằng
Hà Giang
Tuyên Quang
Thái Nguyên
Bắc Kạn
Phú Thọ
Vĩnh Phúc
Yên Bái
Lào Cai
Lai Châu
Điện Biên
Sơn La
Hòa Bình
Kon Tum
Gia Lai
Đắk Lắk
Đắk Nông
Tân Bình
Tân Phú
Bình Tân
Bình Thạnh
Gò Vấp
Phú Nhuận
Thủ Đức
Nhà Bè
Củ Chi
Hóc Môn
Bình Chánh
Cần Giờ
Thủ Dầu Một
Dĩ An
Thuận An
Bến Cát
Tân Uyên
Biên Hòa
Nhơn Trạch
Long Thành
Trảng Bom
Đức Hòa
Bến Lức
Cần Giuộc
quận
huyện
phường
xã
thị xã
thị trấn
tỉnh
đường
khu phố
ấp
thôn
khu công nghiệp
khu chế xuất
cụm công nghiệp
Tân Tạo
Vĩnh Lộc
Lê Minh Xuân
Tân Thới Hiệp
Sóng Thần
Việt Nam Singapore
Hiệp Phước
Tân Thuận
Linh Trung
Amata
@20
ngân hàng thương mại cổ phần
ngân hàng thương mại
Ngoại thương Việt Nam
Ngoại thương
Công thương Việt Nam
Công thương
Đầu tư và Phát triển Việt Nam
ngân hàng Nông nghiệp và Phát triển Nông thôn Việt Nam
Nông nghiệp và Phát triển Nông thôn
Kỹ thương Việt Nam
Kỹ thương
Quân đội
Á Châu
Sài Gòn Thương Tín
Việt Nam Thịnh Vượng
Tiên Phong
Sài Gòn Hà Nội
Xuất nhập khẩu Việt Nam
Phương Đông
Hàng hải Việt Nam
Hàng hải
Quốc tế Việt Nam
Quốc tế
Đông Nam Á
An Bình
Nam Á
Bưu điện Liên Việt
Liên Việt
Lộc Phát Việt Nam
Bản Việt
Bắc Á
Việt Á
Kiên Long
Sài Gòn Công Thương
Đông Á
Quốc Dân
Bảo Việt
Việt Nam Thương Tín
Đại Chúng
Xăng dầu
ngân hàng Chính sách xã hội
Chính sách xã hội
ngân hàng Hợp tác xã Việt Nam
Đại Dương
Dầu khí Toàn cầu
ngân hàng Shinhan Việt Nam
ngân hàng Woori Việt Nam
ngân hàng liên doanh Việt Nga
Việt Nga
@25
Nguyễn
Trần
Lê
Phạm
Hoàng
Huỳnh
Phan
Vũ
Võ
Đặng
Bùi
Đỗ
Hồ
Ngô
Dương
Lý
Đinh
Đoàn
Trương
Lâm
Mai
Tô
Tạ
Châu
Lương
Hà
Thái
Cao
Quách
Trịnh
Đào
Lưu
Vương
Tăng
Từ
Hứa
Kiều
Khương
La
Lục
Mạc
Nghiêm
Ông
Phùng
Quan
Thân
Triệu
Văn
Giang
Diệp
Doãn
Chu
Chung
Tống
Kha
Lạc
Âu
Âu Dương
Tiêu
Thạch
Lữ
Viên
Mã
Hầu
Khổng
Bạch
Đàm
Nông
Hàn
Lai
Vi
Đồng
Hoa
@12
Văn
Thị
Hữu
Đức
Minh
Ngọc
Thanh
Quốc
Xuân
Thu
Kim
Hoàng
Công
Tấn
Trọng
Đình
Quang
Bảo
Gia
Anh
Phương
Mỹ
Thùy
Hồng
Như
Khánh
Tuấn
Thành
Trung
Hải
Hoài
Nhật
Thế
Tiến
Mạnh
Duy
Việt
Hải
Chí
Phúc
Thái
Bích
Diệu
Cẩm
Tường
Thảo
Vĩnh
Trường
Hoàn
Thiện
Nguyên
Tuệ
Uyên
Yến
@10
An
Anh
Bảo
Bình
Cường
Chiến
Công
Cúc
Dũng
Dung
Duy
Dương
Đạt
Đông
Đức
Giang
Hà
Hải
Hạnh
Hằng
Hậu
Hiền
Hiếu
Hiệp
Hòa
Hoa
Hoàng
Hồng
Huệ
Hùng
Hưng
Hương
Hường
Huy
Huyền
Kha
Khanh
Khánh
Khoa
Kiên
Kiệt
Lan
Liên
Linh
Loan
Lộc
Long
Luân
Lực
Mai
Minh
My
Nam
Nga
Ngân
Nghĩa
Ngọc
Nguyệt
Nhàn
Nhân
Nhi
Nhung
Như
Oanh
Phát
Phong
Phú
Phúc
Phụng
Phương
Phượng
Quân
Quang
Quế
Quốc
Quyên
Quỳnh
Sang
Sơn
Tài
Tâm
Tân
Thái
Thắm
Thắng
Thanh
Thành
Thảo
Thiện
Thịnh
Thơ
Thu
Thủy
Thúy
Thùy
Thư
Thương
Tiến
Tín
Toàn
Trang
Trâm
Trí
Trinh
Trọng
Trung
Tú
Tuấn
Tùng
Tuyết
Uyên
Vân
Vi
Việt
Vinh
Vĩnh
Vũ
Vy
Xuân
Yến
Đào
Điệp
Hân
Hậu
Hiển
Hoan
Hợp
Kiều
Lành
Lâm
Lệ
Liễu
Luyến
Lý
Mẫn
Mến
Na
Ngà
Nhã
Nhẫn
Nhu
Ninh
Pha
Quý
Sương
Tám
Thạch
Thanh
Thoa
Thuận
Thụy
Tiên
Tình
Tịnh
Trà
Triều
Trúc
Tuyền
Út
Vàng
Vui
Ý
@6
văn an
văn anh
văn bình
văn cường
văn chiến
văn công
văn dũng
văn duy
văn đạt
văn đông
văn đức
văn giang
văn hà
văn hải
văn hậu
văn hiếu
văn hiệp
văn hòa
văn hoàng
văn hùng
văn hưng
văn huy
văn khánh
văn khoa
văn kiên
văn lâm
văn lộc
văn long
văn lợi
văn lực
văn mạnh
văn minh
văn nam
văn nghĩa
văn nhân
văn phát
văn phong
văn phú
văn phúc
văn phước
văn quang
văn quân
văn sang
văn sơn
văn tài
văn tâm
văn tân
văn thái
văn thắng
văn thanh
văn thành
văn thiện
văn thịnh
văn thuận
văn tiến
văn tín
văn toàn
văn trí
văn trọng
văn trung
văn tú
văn tuấn
văn tùng
văn vinh
văn việt
văn vũ
văn xuân
thị anh
thị bích
thị bình
thị cúc
thị diễm
thị dung
thị duyên
thị giang
thị hà
thị hạnh
thị hằng
thị hậu
thị hiền
thị hoa
thị hòa
thị hồng
thị huệ
thị hương
thị hường
thị huyền
thị kim
thị lan
thị liên
thị liễu
thị linh
thị loan
thị lụa
thị mai
thị minh
thị mỹ
thị nga
thị ngân
thị ngọc
thị nguyệt
thị nhàn
thị nhung
thị oanh
thị phương
thị phượng
thị quyên
thị quỳnh
thị tâm
thị thanh
thị thảo
thị thắm
thị thu
thị thủy
thị thúy
thị thùy
thị thư
thị thương
thị trang
thị trâm
thị tuyết
thị vân
thị xuân
thị yến
hữu phước
hữu nghĩa
hữu tài
hữu thắng
hữu trí
hữu hùng
đức anh
đức minh
đức thắng
đức huy
đức hùng
đức tài
đức thịnh
minh tuấn
minh hoàng
minh hải
minh trí
minh châu
minh tâm
minh anh
minh khoa
minh phát
minh quang
minh thư
ngọc anh
ngọc hân
ngọc lan
ngọc mai
ngọc trâm
ngọc hà
ngọc bích
thanh hải
thanh tùng
thanh hương
thanh tâm
thanh hà
thanh thảo
thanh bình
thanh phong
quốc anh
quốc bảo
quốc huy
quốc việt
quốc cường
quốc thắng
xuân mai
xuân hương
thu hà
thu hương
thu trang
thu thủy
kim anh
kim ngân
kim loan
kim oanh
kim chi
kim phượng
hoàng anh
hoàng nam
hoàng long
hoàng phúc
tấn phát
tấn tài
tấn lộc
tấn dũng
công danh
công minh
công thành
trọng nghĩa
đình phong
quang huy
quang minh
quang vinh
bảo ngọc
bảo anh
gia bảo
gia huy
gia hân
anh tuấn
anh thư
anh khoa
phương anh
phương thảo
phương linh
phương uyên
mỹ linh
mỹ duyên
thùy linh
thùy dung
thùy trang
hồng nhung
hồng nhung
khánh linh
khánh vy
tuấn anh
thành công
thành đạt
thành phát
thành long
trung kiên
trung hiếu
hải yến
hải đăng
@8
thành đạt
phát đạt
thịnh phát
hưng thịnh
hưng phát
phú hưng
phú thịnh
phú quý
vạn phát
vạn thịnh
vạn lợi
tân phát
tân tiến
tân hưng
thiên phát
thiên phúc
thiên long
hoàng phát
hoàng long
hoàng gia
kim long
kim phát
kim ngân
long phát
minh phát
minh long
nam phát
nam việt
đông á
đông nam
tây nam
việt phát
việt hưng
việt úc
việt nhật
việt hàn
việt đức
việt pháp
việt mỹ
việt thái
toàn phát
toàn thắng
thắng lợi
đại phát
đại lợi
đại thành
đại việt
đại nam
đại dương
an phát
an phú
an khang
an bình
bình an
bình minh
phúc an
phúc lộc
phúc thịnh
lộc phát
tài lộc
tài phát
sao mai
sao việt
hồng phát
hồng hà
thái bình
thái sơn
trường sơn
trường thịnh
trường phát
trường giang
vĩnh phát
vĩnh hưng
vĩnh thịnh
vĩnh tường
quang minh
quang trung
nhật minh
nhật quang
hòa phát
hòa bình
hòa thuận
hợp phát
hợp thành
thuận phát
thuận thành
thuận an
tiến phát
tiến thành
tiến đạt
tín phát
tín nghĩa
uy tín
chính nghĩa
nghĩa phát
đức phát
đức thành
gia phát
gia thịnh
gia nguyễn
khang thịnh
mạnh phát
ngọc phát
ngọc thịnh
quốc thịnh
sơn hà
sông hồng
sài gòn
tân sài gòn
miền nam
miền bắc
miền trung
toàn cầu
quốc tế
châu á
thế giới
hoàn cầu
@5
của
và
cho
từ
đến
về
tại
với
qua
theo
trong
ngoài
trên
dưới
được
đã
đang
sẽ
không
có
là
các
những
một
hai
ba
bốn
năm
sáu
bảy
tám
chín
mười
trăm
nghìn
ngàn
triệu
tỷ
đồng
người
anh
chị
em
ông
bà
cô
chú
bác
cháu
con
mẹ
bố
vợ
chồng
gia đình
bạn
nhà
mua
bán
gửi
nhận
trả
lấy
đưa
giao
đặt
còn
thiếu
thừa
dư
đủ
hết
nốt
tiếp
lại
mới
cũ
tổng
cộng
tổng cộng
khoản
mục
số
sổ
sở
tờ khai
khai
khai báo
báo cáo
quyết toán
đăng ký
đăng ký kinh doanh
giấy phép
mã số thuế
căn cước
căn cước công dân
chứng minh nhân dân
địa chỉ
điện thoại
số điện thoại
liên hệ
xin
cảm ơn
xin cảm ơn
chúc mừng
năm mới
tết
lễ
hội
quà
quà tết
đồ
ăn
uống
cơm
nước uống
đi
đường
công tác
khách
tiếp khách
hội nghị
họp
khóa học
học
phí học
chuyển đi
chuyển đến
chuyển
gửi đi
gửi tiền
nhận về
tiền về
tiền đi
thu
chi
thu chi
nhập
xuất
tồn
kho
hàng tồn kho
nhập kho
xuất kho
giá
giá trị
đơn giá
thành tiền
tổng tiền
số lượng
khối lượng
trọng lượng
chiếc
cái
bộ
kg
tấn
mét
lít
thùng
bao
cuộn
tấm
cây
hộp
gói
lô
lô hàng
chuyến
chuyến hàng
container
ngày làm việc
làm việc
làm thêm
làm hàng
thời hạn
hạn
hạn mức
hạn mức tín dụng
đến hạn
quá hạn
trước hạn
trễ hạn
gia hạn nợ
cơ cấu nợ
nợ quá hạn
xử lý nợ
thẻ
thẻ tín dụng
thẻ ghi nợ
thẻ ATM
máy ATM
rút tiền ATM
quẹt thẻ
máy quẹt thẻ
máy bán hàng
bán lẻ
bán buôn
bán sỉ
đại lý cấp
khách sỉ
khách lẻ
hàng mẫu
mẫu
bảo hành
đổi trả
trả hàng
hàng trả lại
hàng bán bị trả lại
giảm trừ
điều chỉnh
điều chỉnh giảm
điều chỉnh tăng
thay thế
hủy
hủy bỏ
hủy giao dịch
sai
sai sót
nhầm
nhầm lẫn
chuyển sai
ghi nhầm
ghi có
ghi nợ
ghi có tài khoản
ghi nợ tài khoản
tra soát
tra soát giao dịch
hoàn trả giao dịch
kiều hối
chuyển tiền quốc tế
chuyển tiền nước ngoài
nhận tiền nước ngoài
thanh toán quốc tế
bán ngoại tệ cho ngân hàng
mua ngoại tệ của ngân hàng
đô la
đô la Mỹ
nhân dân tệ
yên Nhật
won Hàn Quốc
@4
thành
thánh
thạnh
toàn
toán
tiến
tiện
tiên
chuyên
chuyện
khoan
khoán
phi
đích
vũ
vu
cộng
cống
tỷ
tý
hòa
hoa
đón
dọn
đồn
dồn
sở
sổ
so
sơ
ngay
thắng
thăng
thẳng
thang
nam
lượng
luồng
nhân
nhắn
nhãn
viện
tra
trà
lại
lãi
lai
lái
gùi
vây
vậy
váy
góc
thế
thể
tại
tải
tái
tai
ngắn
ngàn
ngăn
chí
chỉ
chị
nhanh
nhánh
diễn
diện
điền
thuê
thuế
tâm
tám
tấm
hoan
hoãn
cốc
đạt
đất
đắt
múa
mùa
mưa
bản
bàn
ban
bạn
hồ
họ
hỗ
kính
tư
tự
tủ
tứ
tử
đen
đèn
đền
chợ
chờ
chở
má
mà
ma
giáo
nơi
nối
nói
bổ
bỏ
bò
bố
dụng
dung
dùng
đúng
đựng
đứng
vận
vạn
vân
ván
vẫn
thi
thì
nguyên
trận
tràn
lệ
lễ
lẻ
phẩm
hoang
phần
phân
phấn
phản
vụ
vợ
vỏ
vô
đăng
đang
dạng
đảng
độ
đồ
đô
do
đó
hộ
đường
dưỡng
đương
ly
định
đình
đoạn
đoán
trưởng
làm
lắm
mại
tờ
tổ
tố
tô
tạ
cháu
hạ
thải
cáo
đúc
dục
thư
thủ
thứ
thú
thụ
tuần
hùng
hưng
hứng
hại
hái
hướng
hưởng
lần
lĩnh
tráng
trạng
phường
hạnh
hành
ánh
ảnh
phụ
phủ
cương
phạt
lọc
tấn
tận
tần
lòng
lông
quảng
viết
sài
sai
đài
dài
vật
liệu
máy
mây
mấy
mặc
mộc
bị
bì
bí
bao
bảo
báo
có
cơ
cổ
cố
khí
khi
nhóm
tồn
tổn
gỗ
gò
giấy
giày
ăn
ấn
ân
an
khẩu
khấu
đầu
dầu
dấu
ký
kỳ
kỹ
nghệ
nghề
cước
cuộc
đá
đã
da
đà
cát
cắt
thủy
thúy
thùy
sản
sân
thực
thức
nông
nóng
biến
biển
biên
tạo
gia
giá
già
giả


# ho + chu dem (ten nguoi): uu tien Nguyen Van / Tran Thi... khi dau dong la ten nguoi
@10
nguyễn văn
nguyễn thị
trần văn
trần thị
lê văn
lê thị
phạm văn
phạm thị
hoàng văn
hoàng thị
huỳnh văn
huỳnh thị
phan văn
phan thị
vũ văn
vũ thị
võ văn
võ thị
đặng văn
đặng thị
bùi văn
bùi thị
đỗ văn
đỗ thị
hồ văn
hồ thị
ngô văn
ngô thị
dương văn
dương thị
lý văn
lý thị
đinh văn
đinh thị
đoàn văn
đoàn thị
trương văn
trương thị
lâm văn
lâm thị
mai văn
mai thị
tô văn
tô thị
@3
tạ văn
tạ thị
châu văn
châu thị
lương văn
lương thị
hà văn
hà thị
thái văn
thái thị
cao văn
cao thị
quách văn
quách thị
trịnh văn
trịnh thị
đào văn
đào thị
lưu văn
lưu thị
vương văn
vương thị
tăng văn
tăng thị
từ văn
từ thị
hứa văn
hứa thị
kiều văn
kiều thị
phùng văn
phùng thị
triệu văn
triệu thị
chu văn
chu thị
tống văn
tống thị
thạch văn
thạch thị
diệp văn
diệp thị
doãn văn
doãn thị
giang văn
giang thị
la văn
la thị
lục văn
lục thị
mạc văn
mạc thị
đàm văn
đàm thị
@2
nguyễn hữu
nguyễn đức
nguyễn minh
nguyễn ngọc
nguyễn thanh
nguyễn quốc
nguyễn xuân
nguyễn thu
nguyễn kim
nguyễn hoàng
nguyễn công
nguyễn tấn
nguyễn trọng
nguyễn đình
nguyễn quang
nguyễn bảo
nguyễn gia
nguyễn anh
nguyễn phương
nguyễn mỹ
nguyễn thùy
nguyễn hồng
nguyễn như
nguyễn khánh
nguyễn tuấn
nguyễn thành
nguyễn trung
nguyễn hải
nguyễn hoài
nguyễn nhật
nguyễn thế
nguyễn tiến
nguyễn mạnh
nguyễn duy
nguyễn việt
nguyễn chí
nguyễn phúc
nguyễn bích
nguyễn diệu
nguyễn cẩm
nguyễn tường
nguyễn vĩnh
nguyễn trường
nguyễn thiện
nguyễn nguyên
nguyễn thúy
nguyễn thụy
nguyễn uyên
nguyễn yến
nguyễn bá
nguyễn khắc
nguyễn phước
nguyễn tú
nguyễn vân
nguyễn lệ
nguyễn ánh
nguyễn hạnh
nguyễn hoa
trần hữu
trần đức
trần minh
trần ngọc
trần thanh
trần quốc
trần xuân
trần thu
trần kim
trần hoàng
trần công
trần tấn
trần trọng
trần đình
trần quang
trần bảo
trần gia
trần anh
trần phương
trần mỹ
trần thùy
trần hồng
trần như
trần khánh
trần tuấn
trần thành
trần trung
trần hải
trần hoài
trần nhật
trần thế
trần tiến
trần mạnh
trần duy
trần việt
trần chí
trần phúc
trần bích
trần diệu
trần cẩm
trần tường
trần vĩnh
trần trường
trần thiện
trần nguyên
trần thúy
trần thụy
trần uyên
trần yến
trần bá
trần khắc
trần phước
trần tú
trần vân
trần lệ
trần ánh
trần hạnh
trần hoa
lê hữu
lê đức
lê minh
lê ngọc
lê thanh
lê quốc
lê xuân
lê thu
lê kim
lê hoàng
lê công
lê tấn
lê trọng
lê đình
lê quang
lê bảo
lê gia
lê anh
lê phương
lê mỹ
lê thùy
lê hồng
lê như
lê khánh
lê tuấn
lê thành
lê trung
lê hải
lê hoài
lê nhật
lê thế
lê tiến
lê mạnh
lê duy
lê việt
lê chí
lê phúc
lê bích
lê diệu
lê cẩm
lê tường
lê vĩnh
lê trường
lê thiện
lê nguyên
lê thúy
lê thụy
lê uyên
lê yến
lê bá
lê khắc
lê phước
lê tú
lê vân
lê lệ
lê ánh
lê hạnh
lê hoa
phạm hữu
phạm đức
phạm minh
phạm ngọc
phạm thanh
phạm quốc
phạm xuân
phạm thu
phạm kim
phạm hoàng
phạm công
phạm tấn
phạm trọng
phạm đình
phạm quang
phạm bảo
phạm gia
phạm anh
phạm phương
phạm mỹ
phạm thùy
phạm hồng
phạm như
phạm khánh
phạm tuấn
phạm thành
phạm trung
phạm hải
phạm hoài
phạm nhật
phạm thế
phạm tiến
phạm mạnh
phạm duy
phạm việt
phạm chí
phạm phúc
phạm bích
phạm diệu
phạm cẩm
phạm tường
phạm vĩnh
phạm trường
phạm thiện
phạm nguyên
phạm thúy
phạm thụy
phạm uyên
phạm yến
phạm bá
phạm khắc
phạm phước
phạm tú
phạm vân
phạm lệ
phạm ánh
phạm hạnh
phạm hoa
hoàng hữu
hoàng đức
hoàng minh
hoàng ngọc
hoàng thanh
hoàng quốc
hoàng xuân
hoàng thu
hoàng kim
hoàng hoàng
hoàng công
hoàng tấn
hoàng trọng
hoàng đình
hoàng quang
hoàng bảo
hoàng gia
hoàng anh
hoàng phương
hoàng mỹ
hoàng thùy
hoàng hồng
hoàng như
hoàng khánh
hoàng tuấn
hoàng thành
hoàng trung
hoàng hải
hoàng hoài
hoàng nhật
hoàng thế
hoàng tiến
hoàng mạnh
hoàng duy
hoàng việt
hoàng chí
hoàng phúc
hoàng bích
hoàng diệu
hoàng cẩm
hoàng tường
hoàng vĩnh
hoàng trường
hoàng thiện
hoàng nguyên
hoàng thúy
hoàng thụy
hoàng uyên
hoàng yến
hoàng bá
hoàng khắc
hoàng phước
hoàng tú
hoàng vân
hoàng lệ
hoàng ánh
hoàng hạnh
hoàng hoa
huỳnh hữu
huỳnh đức
huỳnh minh
huỳnh ngọc
huỳnh thanh
huỳnh quốc
huỳnh xuân
huỳnh thu
huỳnh kim
huỳnh hoàng
huỳnh công
huỳnh tấn
huỳnh trọng
huỳnh đình
huỳnh quang
huỳnh bảo
huỳnh gia
huỳnh anh
huỳnh phương
huỳnh mỹ
huỳnh thùy
huỳnh hồng
huỳnh như
huỳnh khánh
huỳnh tuấn
huỳnh thành
huỳnh trung
huỳnh hải
huỳnh hoài
huỳnh nhật
huỳnh thế
huỳnh tiến
huỳnh mạnh
huỳnh duy
huỳnh việt
huỳnh chí
huỳnh phúc
huỳnh bích
huỳnh diệu
huỳnh cẩm
huỳnh tường
huỳnh vĩnh
huỳnh trường
huỳnh thiện
huỳnh nguyên
huỳnh thúy
huỳnh thụy
huỳnh uyên
huỳnh yến
huỳnh bá
huỳnh khắc
huỳnh phước
huỳnh tú
huỳnh vân
huỳnh lệ
huỳnh ánh
huỳnh hạnh
huỳnh hoa
phan hữu
phan đức
phan minh
phan ngọc
phan thanh
phan quốc
phan xuân
phan thu
phan kim
phan hoàng
phan công
phan tấn
phan trọng
phan đình
phan quang
phan bảo
phan gia
phan anh
phan phương
phan mỹ
phan thùy
phan hồng
phan như
phan khánh
phan tuấn
phan thành
phan trung
phan hải
phan hoài
phan nhật
phan thế
phan tiến
phan mạnh
phan duy
phan việt
phan chí
phan phúc
phan bích
phan diệu
phan cẩm
phan tường
phan vĩnh
phan trường
phan thiện
phan nguyên
phan thúy
phan thụy
phan uyên
phan yến
phan bá
phan khắc
phan phước
phan tú
phan vân
phan lệ
phan ánh
phan hạnh
phan hoa
vũ hữu
vũ đức
vũ minh
vũ ngọc
vũ thanh
vũ quốc
vũ xuân
vũ thu
vũ kim
vũ hoàng
vũ công
vũ tấn
vũ trọng
vũ đình
vũ quang
vũ bảo
vũ gia
vũ anh
vũ phương
vũ mỹ
vũ thùy
vũ hồng
vũ như
vũ khánh
vũ tuấn
vũ thành
vũ trung
vũ hải
vũ hoài
vũ nhật
vũ thế
vũ tiến
vũ mạnh
vũ duy
vũ việt
vũ chí
vũ phúc
vũ bích
vũ diệu
vũ cẩm
vũ tường
vũ vĩnh
vũ trường
vũ thiện
vũ nguyên
vũ thúy
vũ thụy
vũ uyên
vũ yến
vũ bá
vũ khắc
vũ phước
vũ tú
vũ vân
vũ lệ
vũ ánh
vũ hạnh
vũ hoa
võ hữu
võ đức
võ minh
võ ngọc
võ thanh
võ quốc
võ xuân
võ thu
võ kim
võ hoàng
võ công
võ tấn
võ trọng
võ đình
võ quang
võ bảo
võ gia
võ anh
võ phương
võ mỹ
võ thùy
võ hồng
võ như
võ khánh
võ tuấn
võ thành
võ trung
võ hải
võ hoài
võ nhật
võ thế
võ tiến
võ mạnh
võ duy
võ việt
võ chí
võ phúc
võ bích
võ diệu
võ cẩm
võ tường
võ vĩnh
võ trường
võ thiện
võ nguyên
võ thúy
võ thụy
võ uyên
võ yến
võ bá
võ khắc
võ phước
võ tú
võ vân
võ lệ
võ ánh
võ hạnh
võ hoa
đặng hữu
đặng đức
đặng minh
đặng ngọc
đặng thanh
đặng quốc
đặng xuân
đặng thu
đặng kim
đặng hoàng
đặng công
đặng tấn
đặng trọng
đặng đình
đặng quang
đặng bảo
đặng gia
đặng anh
đặng phương
đặng mỹ
đặng thùy
đặng hồng
đặng như
đặng khánh
đặng tuấn
đặng thành
đặng trung
đặng hải
đặng hoài
đặng nhật
đặng thế
đặng tiến
đặng mạnh
đặng duy
đặng việt
đặng chí
đặng phúc
đặng bích
đặng diệu
đặng cẩm
đặng tường
đặng vĩnh
đặng trường
đặng thiện
đặng nguyên
đặng thúy
đặng thụy
đặng uyên
đặng yến
đặng bá
đặng khắc
đặng phước
đặng tú
đặng vân
đặng lệ
đặng ánh
đặng hạnh
đặng hoa
bùi hữu
bùi đức
bùi minh
bùi ngọc
bùi thanh
bùi quốc
bùi xuân
bùi thu
bùi kim
bùi hoàng
bùi công
bùi tấn
bùi trọng
bùi đình
bùi quang
bùi bảo
bùi gia
bùi anh
bùi phương
bùi mỹ
bùi thùy
bùi hồng
bùi như
bùi khánh
bùi tuấn
bùi thành
bùi trung
bùi hải
bùi hoài
bùi nhật
bùi thế
bùi tiến
bùi mạnh
bùi duy
bùi việt
bùi chí
bùi phúc
bùi bích
bùi diệu
bùi cẩm
bùi tường
bùi vĩnh
bùi trường
bùi thiện
bùi nguyên
bùi thúy
bùi thụy
bùi uyên
bùi yến
bùi bá
bùi khắc
bùi phước
bùi tú
bùi vân
bùi lệ
bùi ánh
bùi hạnh
bùi hoa
đỗ hữu
đỗ đức
đỗ minh
đỗ ngọc
đỗ thanh
đỗ quốc
đỗ xuân
đỗ thu
đỗ kim
đỗ hoàng
đỗ công
đỗ tấn
đỗ trọng
đỗ đình
đỗ quang
đỗ bảo
đỗ gia
đỗ anh
đỗ phương
đỗ mỹ
đỗ thùy
đỗ hồng
đỗ như
đỗ khánh
đỗ tuấn
đỗ thành
đỗ trung
đỗ hải
đỗ hoài
đỗ nhật
đỗ thế
đỗ tiến
đỗ mạnh
đỗ duy
đỗ việt
đỗ chí
đỗ phúc
đỗ bích
đỗ diệu
đỗ cẩm
đỗ tường
đỗ vĩnh
đỗ trường
đỗ thiện
đỗ nguyên
đỗ thúy
đỗ thụy
đỗ uyên
đỗ yến
đỗ bá
đỗ khắc
đỗ phước
đỗ tú
đỗ vân
đỗ lệ
đỗ ánh
đỗ hạnh
đỗ hoa
hồ hữu
hồ đức
hồ minh
hồ ngọc
hồ thanh
hồ quốc
hồ xuân
hồ thu
hồ kim
hồ hoàng
hồ công
hồ tấn
hồ trọng
hồ đình
hồ quang
hồ bảo
hồ gia
hồ anh
hồ phương
hồ mỹ
hồ thùy
hồ hồng
hồ như
hồ khánh
hồ tuấn
hồ thành
hồ trung
hồ hải
hồ hoài
hồ nhật
hồ thế
hồ tiến
hồ mạnh
hồ duy
hồ việt
hồ chí
hồ phúc
hồ bích
hồ diệu
hồ cẩm
hồ tường
hồ vĩnh
hồ trường
hồ thiện
hồ nguyên
hồ thúy
hồ thụy
hồ uyên
hồ yến
hồ bá
hồ khắc
hồ phước
hồ tú
hồ vân
hồ lệ
hồ ánh
hồ hạnh
hồ hoa
ngô hữu
ngô đức
ngô minh
ngô ngọc
ngô thanh
ngô quốc
ngô xuân
ngô thu
ngô kim
ngô hoàng
ngô công
ngô tấn
ngô trọng
ngô đình
ngô quang
ngô bảo
ngô gia
ngô anh
ngô phương
ngô mỹ
ngô thùy
ngô hồng
ngô như
ngô khánh
ngô tuấn
ngô thành
ngô trung
ngô hải
ngô hoài
ngô nhật
ngô thế
ngô tiến
ngô mạnh
ngô duy
ngô việt
ngô chí
ngô phúc
ngô bích
ngô diệu
ngô cẩm
ngô tường
ngô vĩnh
ngô trường
ngô thiện
ngô nguyên
ngô thúy
ngô thụy
ngô uyên
ngô yến
ngô bá
ngô khắc
ngô phước
ngô tú
ngô vân
ngô lệ
ngô ánh
ngô hạnh
ngô hoa
dương hữu
dương đức
dương minh
dương ngọc
dương thanh
dương quốc
dương xuân
dương thu
dương kim
dương hoàng
dương công
dương tấn
dương trọng
dương đình
dương quang
dương bảo
dương gia
dương anh
dương phương
dương mỹ
dương thùy
dương hồng
dương như
dương khánh
dương tuấn
dương thành
dương trung
dương hải
dương hoài
dương nhật
dương thế
dương tiến
dương mạnh
dương duy
dương việt
dương chí
dương phúc
dương bích
dương diệu
dương cẩm
dương tường
dương vĩnh
dương trường
dương thiện
dương nguyên
dương thúy
dương thụy
dương uyên
dương yến
dương bá
dương khắc
dương phước
dương tú
dương vân
dương lệ
dương ánh
dương hạnh
dương hoa
lý hữu
lý đức
lý minh
lý ngọc
lý thanh
lý quốc
lý xuân
lý thu
lý kim
lý hoàng
lý công
lý tấn
lý trọng
lý đình
lý quang
lý bảo
lý gia
lý anh
lý phương
lý mỹ
lý thùy
lý hồng
lý như
lý khánh
lý tuấn
lý thành
lý trung
lý hải
lý hoài
lý nhật
lý thế
lý tiến
lý mạnh
lý duy
lý việt
lý chí
lý phúc
lý bích
lý diệu
lý cẩm
lý tường
lý vĩnh
lý trường
lý thiện
lý nguyên
lý thúy
lý thụy
lý uyên
lý yến
lý bá
lý khắc
lý phước
lý tú
lý vân
lý lệ
lý ánh
lý hạnh
lý hoa
đinh hữu
đinh đức
đinh minh
đinh ngọc
đinh thanh
đinh quốc
đinh xuân
đinh thu
đinh kim
đinh hoàng
đinh công
đinh tấn
đinh trọng
đinh đình
đinh quang
đinh bảo
đinh gia
đinh anh
đinh phương
đinh mỹ
đinh thùy
đinh hồng
đinh như
đinh khánh
đinh tuấn
đinh thành
đinh trung
đinh hải
đinh hoài
đinh nhật
đinh thế
đinh tiến
đinh mạnh
đinh duy
đinh việt
đinh chí
đinh phúc
đinh bích
đinh diệu
đinh cẩm
đinh tường
đinh vĩnh
đinh trường
đinh thiện
đinh nguyên
đinh thúy
đinh thụy
đinh uyên
đinh yến
đinh bá
đinh khắc
đinh phước
đinh tú
đinh vân
đinh lệ
đinh ánh
đinh hạnh
đinh hoa
đoàn hữu
đoàn đức
đoàn minh
đoàn ngọc
đoàn thanh
đoàn quốc
đoàn xuân
đoàn thu
đoàn kim
đoàn hoàng
đoàn công
đoàn tấn
đoàn trọng
đoàn đình
đoàn quang
đoàn bảo
đoàn gia
đoàn anh
đoàn phương
đoàn mỹ
đoàn thùy
đoàn hồng
đoàn như
đoàn khánh
đoàn tuấn
đoàn thành
đoàn trung
đoàn hải
đoàn hoài
đoàn nhật
đoàn thế
đoàn tiến
đoàn mạnh
đoàn duy
đoàn việt
đoàn chí
đoàn phúc
đoàn bích
đoàn diệu
đoàn cẩm
đoàn tường
đoàn vĩnh
đoàn trường
đoàn thiện
đoàn nguyên
đoàn thúy
đoàn thụy
đoàn uyên
đoàn yến
đoàn bá
đoàn khắc
đoàn phước
đoàn tú
đoàn vân
đoàn lệ
đoàn ánh
đoàn hạnh
đoàn hoa
trương hữu
trương đức
trương minh
trương ngọc
trương thanh
trương quốc
trương xuân
trương thu
trương kim
trương hoàng
trương công
trương tấn
trương trọng
trương đình
trương quang
trương bảo
trương gia
trương anh
trương phương
trương mỹ
trương thùy
trương hồng
trương như
trương khánh
trương tuấn
trương thành
trương trung
trương hải
trương hoài
trương nhật
trương thế
trương tiến
trương mạnh
trương duy
trương việt
trương chí
trương phúc
trương bích
trương diệu
trương cẩm
trương tường
trương vĩnh
trương trường
trương thiện
trương nguyên
trương thúy
trương thụy
trương uyên
trương yến
trương bá
trương khắc
trương phước
trương tú
trương vân
trương lệ
trương ánh
trương hạnh
trương hoa
lâm hữu
lâm đức
lâm minh
lâm ngọc
lâm thanh
lâm quốc
lâm xuân
lâm thu
lâm kim
lâm hoàng
lâm công
lâm tấn
lâm trọng
lâm đình
lâm quang
lâm bảo
lâm gia
lâm anh
lâm phương
lâm mỹ
lâm thùy
lâm hồng
lâm như
lâm khánh
lâm tuấn
lâm thành
lâm trung
lâm hải
lâm hoài
lâm nhật
lâm thế
lâm tiến
lâm mạnh
lâm duy
lâm việt
lâm chí
lâm phúc
lâm bích
lâm diệu
lâm cẩm
lâm tường
lâm vĩnh
lâm trường
lâm thiện
lâm nguyên
lâm thúy
lâm thụy
lâm uyên
lâm yến
lâm bá
lâm khắc
lâm phước
lâm tú
lâm vân
lâm lệ
lâm ánh
lâm hạnh
lâm hoa
mai hữu
mai đức
mai minh
mai ngọc
mai thanh
mai quốc
mai xuân
mai thu
mai kim
mai hoàng
mai công
mai tấn
mai trọng
mai đình
mai quang
mai bảo
mai gia
mai anh
mai phương
mai mỹ
mai thùy
mai hồng
mai như
mai khánh
mai tuấn
mai thành
mai trung
mai hải
mai hoài
mai nhật
mai thế
mai tiến
mai mạnh
mai duy
mai việt
mai chí
mai phúc
mai bích
mai diệu
mai cẩm
mai tường
mai vĩnh
mai trường
mai thiện
mai nguyên
mai thúy
mai thụy
mai uyên
mai yến
mai bá
mai khắc
mai phước
mai tú
mai vân
mai lệ
mai ánh
mai hạnh
mai hoa
tô hữu
tô đức
tô minh
tô ngọc
tô thanh
tô quốc
tô xuân
tô thu
tô kim
tô hoàng
tô công
tô tấn
tô trọng
tô đình
tô quang
tô bảo
tô gia
tô anh
tô phương
tô mỹ
tô thùy
tô hồng
tô như
tô khánh
tô tuấn
tô thành
tô trung
tô hải
tô hoài
tô nhật
tô thế
tô tiến
tô mạnh
tô duy
tô việt
tô chí
tô phúc
tô bích
tô diệu
tô cẩm
tô tường
tô vĩnh
tô trường
tô thiện
tô nguyên
tô thúy
tô thụy
tô uyên
tô yến
tô bá
tô khắc
tô phước
tô tú
tô vân
tô lệ
tô ánh
tô hạnh
tô hoa
@1
tạ hữu
tạ đức
tạ minh
tạ ngọc
tạ thanh
tạ quốc
tạ xuân
tạ thu
tạ kim
tạ hoàng
tạ công
tạ tấn
tạ trọng
tạ đình
tạ quang
tạ bảo
tạ gia
tạ anh
tạ phương
tạ mỹ
châu hữu
châu đức
châu minh
châu ngọc
châu thanh
châu quốc
châu xuân
châu thu
châu kim
châu hoàng
châu công
châu tấn
châu trọng
châu đình
châu quang
châu bảo
châu gia
châu anh
châu phương
châu mỹ
lương hữu
lương đức
lương minh
lương ngọc
lương thanh
lương quốc
lương xuân
lương thu
lương kim
lương hoàng
lương công
lương tấn
lương trọng
lương đình
lương quang
lương bảo
lương gia
lương anh
lương phương
lương mỹ
hà hữu
hà đức
hà minh
hà ngọc
hà thanh
hà quốc
hà xuân
hà thu
hà kim
hà hoàng
hà công
hà tấn
hà trọng
hà đình
hà quang
hà bảo
hà gia
hà anh
hà phương
hà mỹ
thái hữu
thái đức
thái minh
thái ngọc
thái thanh
thái quốc
thái xuân
thái thu
thái kim
thái hoàng
thái công
thái tấn
thái trọng
thái đình
thái quang
thái bảo
thái gia
thái anh
thái phương
thái mỹ
cao hữu
cao đức
cao minh
cao ngọc
cao thanh
cao quốc
cao xuân
cao thu
cao kim
cao hoàng
cao công
cao tấn
cao trọng
cao đình
cao quang
cao bảo
cao gia
cao anh
cao phương
cao mỹ
quách hữu
quách đức
quách minh
quách ngọc
quách thanh
quách quốc
quách xuân
quách thu
quách kim
quách hoàng
quách công
quách tấn
quách trọng
quách đình
quách quang
quách bảo
quách gia
quách anh
quách phương
quách mỹ
trịnh hữu
trịnh đức
trịnh minh
trịnh ngọc
trịnh thanh
trịnh quốc
trịnh xuân
trịnh thu
trịnh kim
trịnh hoàng
trịnh công
trịnh tấn
trịnh trọng
trịnh đình
trịnh quang
trịnh bảo
trịnh gia
trịnh anh
trịnh phương
trịnh mỹ
đào hữu
đào đức
đào minh
đào ngọc
đào thanh
đào quốc
đào xuân
đào thu
đào kim
đào hoàng
đào công
đào tấn
đào trọng
đào đình
đào quang
đào bảo
đào gia
đào anh
đào phương
đào mỹ
lưu hữu
lưu đức
lưu minh
lưu ngọc
lưu thanh
lưu quốc
lưu xuân
lưu thu
lưu kim
lưu hoàng
lưu công
lưu tấn
lưu trọng
lưu đình
lưu quang
lưu bảo
lưu gia
lưu anh
lưu phương
lưu mỹ
vương hữu
vương đức
vương minh
vương ngọc
vương thanh
vương quốc
vương xuân
vương thu
vương kim
vương hoàng
vương công
vương tấn
vương trọng
vương đình
vương quang
vương bảo
vương gia
vương anh
vương phương
vương mỹ
tăng hữu
tăng đức
tăng minh
tăng ngọc
tăng thanh
tăng quốc
tăng xuân
tăng thu
tăng kim
tăng hoàng
tăng công
tăng tấn
tăng trọng
tăng đình
tăng quang
tăng bảo
tăng gia
tăng anh
tăng phương
tăng mỹ
từ hữu
từ đức
từ minh
từ ngọc
từ thanh
từ quốc
từ xuân
từ thu
từ kim
từ hoàng
từ công
từ tấn
từ trọng
từ đình
từ quang
từ bảo
từ gia
từ anh
từ phương
từ mỹ
hứa hữu
hứa đức
hứa minh
hứa ngọc
hứa thanh
hứa quốc
hứa xuân
hứa thu
hứa kim
hứa hoàng
hứa công
hứa tấn
hứa trọng
hứa đình
hứa quang
hứa bảo
hứa gia
hứa anh
hứa phương
hứa mỹ
kiều hữu
kiều đức
kiều minh
kiều ngọc
kiều thanh
kiều quốc
kiều xuân
kiều thu
kiều kim
kiều hoàng
kiều công
kiều tấn
kiều trọng
kiều đình
kiều quang
kiều bảo
kiều gia
kiều anh
kiều phương
kiều mỹ
phùng hữu
phùng đức
phùng minh
phùng ngọc
phùng thanh
phùng quốc
phùng xuân
phùng thu
phùng kim
phùng hoàng
phùng công
phùng tấn
phùng trọng
phùng đình
phùng quang
phùng bảo
phùng gia
phùng anh
phùng phương
phùng mỹ
triệu hữu
triệu đức
triệu minh
triệu ngọc
triệu thanh
triệu quốc
triệu xuân
triệu thu
triệu kim
triệu hoàng
triệu công
triệu tấn
triệu trọng
triệu đình
triệu quang
triệu bảo
triệu gia
triệu anh
triệu phương
triệu mỹ
chu hữu
chu đức
chu minh
chu ngọc
chu thanh
chu quốc
chu xuân
chu thu
chu kim
chu hoàng
chu công
chu tấn
chu trọng
chu đình
chu quang
chu bảo
chu gia
chu anh
chu phương
chu mỹ
tống hữu
tống đức
tống minh
tống ngọc
tống thanh
tống quốc
tống xuân
tống thu
tống kim
tống hoàng
tống công
tống tấn
tống trọng
tống đình
tống quang
tống bảo
tống gia
tống anh
tống phương
tống mỹ
thạch hữu
thạch đức
thạch minh
thạch ngọc
thạch thanh
thạch quốc
thạch xuân
thạch thu
thạch kim
thạch hoàng
thạch công
thạch tấn
thạch trọng
thạch đình
thạch quang
thạch bảo
thạch gia
thạch anh
thạch phương
thạch mỹ
diệp hữu
diệp đức
diệp minh
diệp ngọc
diệp thanh
diệp quốc
diệp xuân
diệp thu
diệp kim
diệp hoàng
diệp công
diệp tấn
diệp trọng
diệp đình
diệp quang
diệp bảo
diệp gia
diệp anh
diệp phương
diệp mỹ
doãn hữu
doãn đức
doãn minh
doãn ngọc
doãn thanh
doãn quốc
doãn xuân
doãn thu
doãn kim
doãn hoàng
doãn công
doãn tấn
doãn trọng
doãn đình
doãn quang
doãn bảo
doãn gia
doãn anh
doãn phương
doãn mỹ
giang hữu
giang đức
giang minh
giang ngọc
giang thanh
giang quốc
giang xuân
giang thu
giang kim
giang hoàng
giang công
giang tấn
giang trọng
giang đình
giang quang
giang bảo
giang gia
giang anh
giang phương
giang mỹ
la hữu
la đức
la minh
la ngọc
la thanh
la quốc
la xuân
la thu
la kim
la hoàng
la công
la tấn
la trọng
la đình
la quang
la bảo
la gia
la anh
la phương
la mỹ
lục hữu
lục đức
lục minh
lục ngọc
lục thanh
lục quốc
lục xuân
lục thu
lục kim
lục hoàng
lục công
lục tấn
lục trọng
lục đình
lục quang
lục bảo
lục gia
lục anh
lục phương
lục mỹ
mạc hữu
mạc đức
mạc minh
mạc ngọc
mạc thanh
mạc quốc
mạc xuân
mạc thu
mạc kim
mạc hoàng
mạc công
mạc tấn
mạc trọng
mạc đình
mạc quang
mạc bảo
mạc gia
mạc anh
mạc phương
mạc mỹ
đàm hữu
đàm đức
đàm minh
đàm ngọc
đàm thanh
đàm quốc
đàm xuân
đàm thu
đàm kim
đàm hoàng
đàm công
đàm tấn
đàm trọng
đàm đình
đàm quang
đàm bảo
đàm gia
đàm anh
đàm phương
đàm mỹ

# ngu canh so (<so>): quy 2, thang 5, tu 189 den 192, lan 2, so 123...
@30
tháng 5
tháng 12
tháng 6 năm 2026
năm 2026
quý 1
quý 2
quý 3
quý 4
lần 1
lần 2
đợt 1
đợt 2
kỳ 1
kỳ 2
tuần 2
số 123
hóa đơn 123
hóa đơn số 123
hóa đơn số 123 ngày 5
hợp đồng số 01
hợp đồng 01
đơn hàng 15
đơn hàng số 15
phiếu xuất kho số 14
từ 189 đến 192
từ ngày 1 đến ngày 30
từ 01 đến 30
từ 5 đến 20
ngày 12
ngày 5 tháng 6
đến ngày 30
đến 192
đến hết 2026
tới 192
từ 1 tới 5
chuyển tới
gửi tới
mã giao dịch 123
mã số thuế 123
mã số 123
mã GD 123
mã KH 123
mã số
mã khách hàng
mã hàng
mã
tài khoản 123
tài khoản số 123
số tài khoản 123
số tiền 123
còn 123
lương tháng 5
chi lương tháng 5
trả lương tháng 5
lương tháng 5 năm 2026
thanh toán lần 2
thanh toán đợt 2
nộp thuế quý 2
thuế GTGT quý 2
thuế TNDN quý 2
tờ khai quý 2
tiền điện tháng 5
tiền nước tháng 5
tiền thuê nhà tháng 5
cước tháng 5
phí tháng 5
lãi tháng 5
kỳ lãi tháng 5
thu phí tháng 5
trả lãi tháng 5
lãi vay tháng 5
lãi vay hợp đồng số 01

# uu tien khi dung mot minh (khong co ngu canh): tu / den / nam / an / quang / dat...
@150
từ
đến
@60
năm
quang
trích
trích tiền
trích nộp
trích lập
đạt
nguyễn
đỗ
phạm
dũng
an
mã
quý
tới
@40
phong thủy
thành đạt
tiến đạt
phát đạt
đại phát
hoàng phát
@5
nội dung
nội dung chuyển tiền
nội dung chuyển khoản
@20
hằng
hồ
ngay
phan
phong
vân
vạn
chí
quyền

# tu chuc nang / tu hay gap khi dung mot minh (khong co ngu canh)
@100
của
cho
và
với
tại
về
sang
cùng
các
được
@40
chuyển sang
sang tài khoản
sang TK
chuyển sang TK
cùng công ty
cùng chủ tài khoản
cùng ngân hàng
cùng tên
hàng của
tiền của
mua hàng của
đến từ
chuyển tiền đến từ
nhận từ
gửi từ
từ NAPAS
từ TK
tại NH
tại VCB
tại ngân hàng
tại chi nhánh
tại KBNN
tại quầy
hoa mai
hoa hồng
hoa sen
mai

[ANH]
# cum dai truoc (tool tu tim cum dai nhat); ben phai de trong = bo tu.
# Tu DON le chi dich khi ca dong la tieng Anh, tru cac tu giao dich trong danh sach MANH cua sp_dich_viet.py
# (ten cong ty tieng Anh nhu "... GLOBAL SERVICE" khong bi dich).
sms banking service => dịch vụ SMS Banking
sms service => dịch vụ SMS
charge for => phí
fee for => phí
fees for => phí
as per => theo
according to => theo
per => theo
overpayment => trả thừa
over payment => trả thừa
outward remittance => chuyển tiền đi
inward remittance => chuyển tiền đến
outgoing transfer => chuyển tiền đi
incoming transfer => nhận tiền chuyển đến
debit card => thẻ ghi nợ
credit card => thẻ tín dụng
credit card payment => thanh toán thẻ tín dụng
loan interest payment => trả lãi vay
partial payment => thanh toán một phần
final payment => thanh toán lần cuối
full payment => thanh toán toàn bộ
cash in => nộp tiền mặt
cash out => rút tiền mặt
top up => nạp tiền
topup => nạp tiền
e-wallet => ví điện tử
ewallet => ví điện tử
wallet => ví điện tử
purchase at => mua hàng tại
vat => thuế GTGT
tax code => mã số thuế
tax id => mã số thuế
joint stock company => công ty cổ phần
limited liability company => công ty TNHH
january => tháng 1
february => tháng 2
march => tháng 3
april => tháng 4
june => tháng 6
july => tháng 7
august => tháng 8
september => tháng 9
october => tháng 10
november => tháng 11
december => tháng 12
credit interest => lãi tiền gửi
interest credit => lãi tiền gửi
deposit interest => lãi tiền gửi
interest payment => trả lãi
interest paid => trả lãi
interest income => lãi tiền gửi
loan interest => lãi vay
interest on loan => lãi vay
loan repayment => trả nợ vay
principal repayment => trả nợ gốc
loan disbursement => giải ngân khoản vay
disbursement => giải ngân
account maintenance fee => phí duy trì tài khoản
account maintenance => duy trì tài khoản
maintenance fee => phí duy trì
management fee => phí quản lý
account management fee => phí quản lý tài khoản
annual fee => phí thường niên
monthly fee => phí hàng tháng
service fee => phí dịch vụ
service charge => phí dịch vụ
service charges => phí dịch vụ
bank charge => phí ngân hàng
bank charges => phí ngân hàng
bank fee => phí ngân hàng
transaction fee => phí giao dịch
transfer fee => phí chuyển khoản
remittance fee => phí chuyển tiền
sms fee => phí SMS
sms banking fee => phí SMS Banking
sms banking => SMS Banking
internet banking fee => phí Internet Banking
ebanking fee => phí ngân hàng điện tử
e-banking fee => phí ngân hàng điện tử
card fee => phí thẻ
card annual fee => phí thường niên thẻ
issuance fee => phí phát hành
vat on fee => thuế GTGT của phí
vat for fee => thuế GTGT của phí
fee vat => thuế GTGT của phí
cash deposit => nộp tiền mặt
cash withdrawal => rút tiền mặt
cash withdraw => rút tiền mặt
atm withdrawal => rút tiền ATM
funds transfer => chuyển tiền
fund transfer => chuyển tiền
money transfer => chuyển tiền
internal transfer => chuyển khoản nội bộ
interbank transfer => chuyển khoản liên ngân hàng
fast transfer => chuyển khoản nhanh
transfer to => chuyển tiền cho
transfer from => chuyển tiền từ
transfer out => chuyển tiền đi
transfer in => nhận tiền chuyển đến
transferred to => chuyển cho
transferred from => chuyển từ
received from => nhận tiền từ
receive from => nhận tiền từ
payment to => thanh toán cho
payment from => thanh toán từ
payment for => thanh toán
pay for => thanh toán
paid for => thanh toán
payment of => thanh toán
payment invoice => thanh toán hóa đơn
payment for invoice => thanh toán hóa đơn
invoice payment => thanh toán hóa đơn
bill payment => thanh toán hóa đơn
payment for goods => thanh toán tiền hàng
goods payment => thanh toán tiền hàng
payment for order => thanh toán đơn hàng
advance payment => tạm ứng
prepayment => trả trước
down payment => đặt cọc
deposit for => đặt cọc
salary payment => chi lương
salary for => lương
payroll => chi lương
salary => lương
bonus => thưởng
allowance => phụ cấp
tax payment => nộp thuế
pay tax => nộp thuế
tax => thuế
value added tax => thuế GTGT
corporate income tax => thuế TNDN
personal income tax => thuế TNCN
social insurance => bảo hiểm xã hội
health insurance => bảo hiểm y tế
unemployment insurance => bảo hiểm thất nghiệp
insurance premium => phí bảo hiểm
insurance => bảo hiểm
refund => hoàn tiền
refund for => hoàn tiền
reversal => hoàn trả giao dịch
reversed => hoàn trả
return => trả lại
returned => trả lại
adjustment => điều chỉnh
correction => điều chỉnh
foreign exchange => mua bán ngoại tệ
fx => ngoại tệ
buy usd => mua USD
sell usd => bán USD
exchange rate => tỷ giá
term deposit => tiền gửi có kỳ hạn
time deposit => tiền gửi có kỳ hạn
saving deposit => tiền gửi tiết kiệm
savings => tiết kiệm
saving => tiết kiệm
settlement => tất toán
closing account => tất toán tài khoản
account closing => tất toán tài khoản
opening balance => số dư đầu kỳ
closing balance => số dư cuối kỳ
balance => số dư
capital contribution => góp vốn
contribution => góp vốn
dividend => cổ tức
commission => hoa hồng
discount => chiết khấu
rental => tiền thuê
rent => tiền thuê
office rent => tiền thuê văn phòng
electricity bill => tiền điện
electricity => tiền điện
water bill => tiền nước
telephone bill => cước điện thoại
phone bill => cước điện thoại
internet bill => cước internet
freight => cước vận chuyển
shipping fee => phí vận chuyển
shipping => vận chuyển
delivery => giao hàng
purchase => mua hàng
purchasing => mua hàng
sales => bán hàng
sale => bán hàng
goods => hàng hóa
order => đơn hàng
contract => hợp đồng
contract no => hợp đồng số
invoice => hóa đơn
invoices => hóa đơn
inv => hóa đơn
bill => hóa đơn
receipt => biên lai
debit note => giấy báo nợ
credit note => giấy báo có
debit => ghi nợ
credit => ghi có
interest => lãi
loan => khoản vay
principal => gốc
repayment => trả nợ
fee => phí
fees => phí
charge => phí
charges => phí
payment => thanh toán
pay => thanh toán
paid => đã thanh toán
transfer => chuyển khoản
remittance => chuyển tiền
deposit => nộp tiền
withdrawal => rút tiền
withdraw => rút tiền
cash => tiền mặt
account => tài khoản
acc => tài khoản
card => thẻ
customer => khách hàng
supplier => nhà cung cấp
company => công ty
branch => chi nhánh
bank => ngân hàng
service => dịch vụ
services => dịch vụ
monthly => hàng tháng
annual => thường niên
month => tháng
year => năm
other => khác
advance => tạm ứng
partial => một phần
full => toàn bộ
remaining => còn lại
balance payment => thanh toán phần còn lại
first => lần đầu
installment => đợt
instalment => đợt
debt => nợ
overdue => quá hạn
penalty => tiền phạt
late payment => chậm thanh toán
collection => thu hộ
collect => thu
and => và
for => 
of => 
the => 
to => cho
from => từ
by => bởi
with => với
at => tại
on => ngày
in => trong
no => số
number => số
ref => tham chiếu
reference => tham chiếu

[TAT]
hd => hđ
hdkt => hđkt
hdmb => hđmb
hddt => hđđt
hdgtgt => hđgtgt
hdtc => hđtc
hdld => hđlđ
sdt => sđt
qd => qđ
dkkd => đkkd
gdkd => gđkd
"""
