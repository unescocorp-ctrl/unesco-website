# -*- coding: utf-8 -*-
"""GD128 - MAU BIEU LAO DONG - BHXH ra Excel (chu Unicode) cho cua so "Ket noi BHXH" (bhxh_unesco.py).

Nguon so lieu: JSON do VB6 lap (ModHDDTBHXH.HDDT_BHXH_Json - CHI DOC so): thong tin don vi (License), danh sach nhan vien
(QuanLyNhanVien), bang luong phan mem (BangLuong / ThongSoLuong) va bang luong da Import (HDDT_BL_*). Cac thong tin so ke toan
KHONG co (ma don vi BHXH, noi KCB, ngay bat dau HD, vi tri viec lam...) nguoi dung nhap o cua so Ket noi BHXH va luu RIENG
trong <thu muc khach>\\bhxh\\ho_so_bhxh.json - KHONG ghi vao so ke toan (quy tac 18).

Mau lap ra (moi lan mot thu muc moi trong <chuong trinh>\\Excels\\BHXH\\ - khong ghi de tep cu):
  D02-LT   Danh sach tham gia, dieu chinh dong BHXH, BHYT, BHTN (QD 366/QD-BHXH ngay 29/4/2026, cot A, B, 1-19)
  TK1-TS   To khai dang ky, dieu chinh thong tin tham gia BHXH, BHYT (moi nguoi mot sheet - Phan A / Phan B)
  TK3-TS   To khai don vi dang ky, dieu chinh thong tin tham gia BHXH, BHYT, BHTN
  01/PLI   Bao cao tinh hinh thay doi ve lao dong (Phu luc I ND 145/2020/ND-CP, 27 cot) - han truoc 05/6 va 05/12
  BangTinhDong  Bang tinh so phai dong BHXH, BHYT, BHTN thang (cong thuc song) - doi chieu thong bao C12-TS
  KiemTra  Danh sach lao dong + kiem tra ho so BHXH (thieu ma BHXH, CCCD, ngay sinh, noi KCB, ngay HD, luong < toi thieu vung...)
  TheoMau  Dien danh sach vao dung cac cot cua mot tep mau Excel (tai tu cong / phan mem ke khai) - doc dong tieu de, ghep cot

Ma phuong an, dia chi cong, ty le dong: mac dinh trong ma; muon sua thi chep AIHoaDon\\bhxh\\mau_bhxh_mau.json thanh
mau_bhxh.json (goi cap nhat khong ghi de tep nay) roi sua. Ty le dong, tran dong, luong toi thieu vung con o sheet ThamSo
cua Bang tinh dong (sua duoc - cong thuc tinh lai). Python chuan + xlsx_viet (khong can openpyxl / Excel).
"""
import datetime as _dt
import io
import json
import os
import re
import unicodedata

from xlsx_viet import SoExcel, CT, Chu, SO_TIEN, dia_chi

PHIEN_BAN = "GD128"
THU_MUC = os.path.dirname(os.path.abspath(__file__))
TEP_CAU_HINH = os.path.join(THU_MUC, "bhxh", "mau_bhxh.json")

CAN_CU_D02 = "Ban hành kèm theo Quyết định số 366/QĐ-BHXH ngày 29/4/2026 của BHXH Việt Nam"
CAN_CU_PLI = "Phụ lục I ban hành kèm theo Nghị định số 145/2020/NĐ-CP"
GHI_CHU_PLI = ("Từ 01/07/2026 người sử dụng lao động báo cáo tình hình thay đổi lao động qua Nền tảng hợp đồng lao động điện tử "
               "(Thông tư 08/2026/TT-BNV) - tệp này dùng để đối chiếu / nhập liệu.")
GHI_CHU_TK = ("Bố cục chỉ tiêu theo QĐ 366/QĐ-BHXH (Phần A - đăng ký tham gia, Phần B - điều chỉnh thông tin); "
              "đối chiếu với mẫu cơ quan BHXH đang phát hành trước khi ký.")

# ma phuong an (cot 18 D02-LT): (ma, ten, nhom T = tang / G = giam / D = dieu chinh)
PA_MAC_DINH = [
    ("TM", "Tăng mới (lao động mới vào làm)", "T"),
    ("TC", "Tăng do chuyển từ tỉnh khác đến", "T"),
    ("TD", "Tăng do chuyển từ đơn vị khác trong tỉnh", "T"),
    ("ON", "Đi làm lại sau nghỉ thai sản / ốm đau / không lương", "T"),
    ("GH", "Giảm hẳn (nghỉ việc, chấm dứt hợp đồng)", "G"),
    ("GC", "Giảm do chuyển sang tỉnh khác", "G"),
    ("GD", "Giảm do chuyển đơn vị trong tỉnh", "G"),
    ("TS", "Nghỉ thai sản", "G"),
    ("OF", "Nghỉ ốm đau từ 14 ngày trở lên trong tháng", "G"),
    ("KL", "Nghỉ không lương từ 14 ngày trở lên trong tháng", "G"),
    ("DC", "Điều chỉnh tiền lương đóng", "D"),
    ("CD", "Điều chỉnh chức danh, nơi làm việc", "D"),
]

CONG_TRUC_TUYEN = [
    ("Cổng Dịch vụ công BHXH Việt Nam", "https://dichvucong.baohiemxahoi.gov.vn/",
     "Kê khai, nộp hồ sơ tham gia / điều chỉnh (D02-LT, TK1-TS, TK3-TS), tra cứu C12-TS, kết quả hồ sơ. Đăng nhập bằng "
     "tài khoản đơn vị hoặc VNeID."),
    ("Tra cứu mã số BHXH", "https://baohiemxahoi.gov.vn/tracuu/Pages/tra-cuu-ho-gia-dinh.aspx",
     "Tra mã số BHXH của người lao động chưa có mã (cần họ tên, ngày sinh, nơi cấp khai sinh, tự nhập mã xác nhận)."),
    ("Nền tảng hợp đồng lao động điện tử", "https://hopdonglaodong.moha.gov.vn/",
     "Từ 01/07/2026: báo cáo tình hình thay đổi lao động (thay mẫu 01/PLI), quản lý HĐLĐ điện tử. Đăng nhập VNeID tổ chức."),
    ("Cổng Dịch vụ công quốc gia", "https://dichvucong.gov.vn/",
     "Nộp báo cáo tình hình sử dụng lao động (01/PLI) nơi địa phương còn nhận qua cổng, các thủ tục lao động khác."),
]

VUNG_2026 = {"I": 5310000, "II": 4730000, "III": 4140000, "IV": 3700000}     # ND 293/2025/ND-CP tu 01/01/2026
VUNG_2024 = {"I": 4960000, "II": 4410000, "III": 3860000, "IV": 3450000}     # ND 74/2024/ND-CP tu 01/07/2024
TY_LE = {"nld_xh": 8.0, "nld_yt": 1.5, "nld_tn": 1.0, "dn_xh": 17.5, "dn_yt": 3.0, "dn_tn": 1.0, "kpcd": 2.0}
VI_TRI = [("QL", "Nhà quản lý"), ("CAO", "Chuyên môn kỹ thuật bậc cao"), ("TRUNG", "Chuyên môn kỹ thuật bậc trung"), ("KHAC", "Khác")]
LOAI_HD = [("KXD", "HĐLĐ không xác định thời hạn"), ("XD", "HĐLĐ xác định thời hạn"), ("KHAC", "HĐ khác (dưới 1 tháng, thử việc)")]


# ====================================================================== tien ich
def bo_dau(s):
    s = unicodedata.normalize("NFD", str(s or ""))
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    return s.replace("đ", "d").replace("Đ", "D")


def khoa(s):
    """khoa so khop: chu thuong, bo dau, chi giu chu + so."""
    return re.sub(r"[^a-z0-9]+", " ", bo_dau(s).lower()).strip()


def chu(s):
    """chuoi sach: bo khoang trang thua, '...' (o trong cua man hinh cu) = rong."""
    if s is None:
        return ""
    s = re.sub(r"\s+", " ", str(s)).strip()
    return "" if s.strip(". ") == "" else s


def so(v, mac_dinh=0.0):
    if v is None or v == "":
        return mac_dinh
    if isinstance(v, bool):
        return float(v)
    if isinstance(v, (int, float)):
        return float(v)
    try:
        return float(str(v).replace(",", "").strip())
    except ValueError:
        return mac_dinh


def lam_tron(x):
    """ROUND(x, 0) kieu Excel (nua ra xa so 0)."""
    x = float(x or 0)
    return int(x + 0.5) if x >= 0 else -int(-x + 0.5)


def ngay(s):
    """'dd/mm/yyyy' | 'yyyy-mm-dd' | date -> date; ngay rong / 30/12/1899 / nam < 1901 -> None."""
    if s is None or s == "":
        return None
    if isinstance(s, _dt.datetime):
        s = s.date()
    if isinstance(s, _dt.date):
        return s if s.year > 1900 else None
    t = str(s).strip()
    for m in ("%d/%m/%Y", "%Y-%m-%d", "%d-%m-%Y", "%Y/%m/%d", "%d/%m/%Y %H:%M:%S", "%Y-%m-%d %H:%M:%S"):
        try:
            d = _dt.datetime.strptime(t, m).date()
            return d if d.year > 1900 else None
        except ValueError:
            pass
    m = re.match(r"^(\d{1,2})/(\d{4})$", t)
    if m:
        try:
            return _dt.date(int(m.group(2)), int(m.group(1)), 1)
        except ValueError:
            return None
    return None


def ngay_vn(d):
    d = ngay(d)
    return d.strftime("%d/%m/%Y") if d else ""


def thang_vn(y, m):
    return "%02d/%04d" % (m, y) if y and m else ""


def thang_truoc(y, m):
    return (y - 1, 12) if m == 1 else (y, m - 1)


def thang_sau(y, m):
    return (y + 1, 1) if m == 12 else (y, m + 1)


def cuoi_thang(y, m):
    y2, m2 = thang_sau(y, m)
    return _dt.date(y2, m2, 1) - _dt.timedelta(days=1)


def trong_thang(d, y, m):
    d = ngay(d)
    return bool(d) and d.year == y and d.month == m


def ngay_lam_truoc(d):
    """so ngay lam viec (tru Chu nhat) tu mung 1 den truoc ngay d - quy tac 14 ngay lam viec trong thang."""
    d = ngay(d)
    if not d:
        return 0
    return sum(1 for i in range(1, d.day) if _dt.date(d.year, d.month, i).weekday() != 6)


def gioi_tinh(s):
    k = khoa(s)
    if k.startswith("nu") or k in ("f", "female", "0 nu"):
        return "Nữ"
    if k.startswith("nam") or k in ("m", "male"):
        return "Nam"
    return chu(s)


def che_so(s, giu=4):
    """che so CCCD / tai khoan khi HIEN (chi giu 4 so cuoi) - tep Excel nop van du so."""
    s = re.sub(r"\s+", "", str(s or ""))
    if len(s) <= giu:
        return s
    return "•" * (len(s) - giu) + s[-giu:]


def luong_co_so(d):
    try:
        import doi_chieu_luong
        return doi_chieu_luong.luong_co_so(d)
    except Exception:
        return (2530000, "Nghị định 161/2026/NĐ-CP") if d >= _dt.date(2026, 7, 1) else (2340000, "Nghị định 73/2024/NĐ-CP")


def luong_toi_thieu_vung(d, vung="I"):
    vung = (vung or "I").upper()
    if vung not in VUNG_2026:
        vung = "I"
    if d >= _dt.date(2026, 1, 1):
        return VUNG_2026[vung], "Nghị định 293/2025/NĐ-CP (từ 01/01/2026)"
    return VUNG_2024[vung], "Nghị định 74/2024/NĐ-CP (từ 01/07/2024)"


def doc_cau_hinh():
    """mau_bhxh.json (tuy chon): {"phuong_an": [[ma, ten, nhom]], "cong": [[ten, url, mo_ta]], "ty_le": {...}, "vung": {...}}."""
    ch = {"phuong_an": PA_MAC_DINH, "cong": CONG_TRUC_TUYEN, "ty_le": dict(TY_LE)}
    try:
        with io.open(TEP_CAU_HINH, encoding="utf-8-sig") as f:
            d = json.load(f)
        pa = [tuple(x[:3]) for x in d.get("phuong_an") or [] if len(x) >= 3 and str(x[2]) in ("T", "G", "D")]
        if pa:
            ch["phuong_an"] = pa
        cg = [tuple(x[:3]) for x in d.get("cong") or [] if len(x) >= 3 and str(x[1]).startswith("https://")]
        if cg:
            ch["cong"] = cg
        for k, v in (d.get("ty_le") or {}).items():
            if k in TY_LE and 0 <= so(v, -1) <= 100:
                ch["ty_le"][k] = so(v)
    except Exception:
        pass
    return ch


# ====================================================================== ho so BHXH luu rieng (khong ghi so ke toan)
class HoSo(object):
    """<thu muc khach>\\bhxh\\ho_so_bhxh.json: {"don_vi": {...}, "nv": {sohieu: {...}}, "phat_sinh": {"yyyy-mm": [...]}}."""

    def __init__(self, duong):
        self.duong = duong
        self.d = {"phien_ban": 128, "don_vi": {}, "nv": {}, "phat_sinh": {}}
        self.loi = ""
        if duong and not os.path.isfile(duong) and os.path.isfile(duong + ".bak"):
            self.loi = "Tệp hồ sơ BHXH không còn - đã dùng bản sao lưu gần nhất (.bak); bấm Lưu để ghi lại."
            duong_doc = duong + ".bak"
        else:
            duong_doc = duong
        if duong_doc and os.path.isfile(duong_doc):
            try:
                with io.open(duong_doc, encoding="utf-8-sig") as f:
                    x = json.load(f)
                if isinstance(x, dict):
                    for k in ("don_vi", "nv", "phat_sinh"):
                        if isinstance(x.get(k), dict):
                            self.d[k] = x[k]
            except Exception as e:
                self.loi = "Không đọc được hồ sơ BHXH đã lưu (%s) - dùng hồ sơ trống, tệp cũ giữ nguyên." % e

    @property
    def don_vi(self):
        return self.d["don_vi"]

    def nv(self, sh):
        return self.d["nv"].get(str(sh), {})

    def dat_nv(self, sh, gt):
        gt = {k: v for k, v in (gt or {}).items() if v not in (None, "")}
        if gt:
            self.d["nv"][str(sh)] = gt
        else:
            self.d["nv"].pop(str(sh), None)

    def phat_sinh(self, y, m):
        return self.d["phat_sinh"].get("%04d-%02d" % (y, m))

    def dat_phat_sinh(self, y, m, ds):
        k = "%04d-%02d" % (y, m)
        if ds is None:
            self.d["phat_sinh"].pop(k, None)
        else:
            self.d["phat_sinh"][k] = ds

    def luu(self):
        if not self.duong:
            return False
        if self.loi:                           # tep cu hong: giu ban cu canh ten khac, khong ghi de
            if os.path.isfile(self.duong):
                try:
                    os.replace(self.duong, self.duong + ".hong_" + _dt.datetime.now().strftime("%Y%m%d%H%M%S"))
                except Exception:
                    pass
            self.loi = ""
        os.makedirs(os.path.dirname(self.duong), exist_ok=True)
        self.d["phien_ban"] = 128
        self.d["ngay_luu"] = _dt.datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        tam = self.duong + ".tam"
        with io.open(tam, "w", encoding="utf-8") as f:
            json.dump(self.d, f, ensure_ascii=False, indent=1)
        if os.path.isfile(self.duong):
            try:
                import shutil
                shutil.copy2(self.duong, self.duong + ".bak")
            except Exception:
                pass
        os.replace(tam, self.duong)
        return True


# ====================================================================== du lieu tu JSON cua VB6
NV_KHOA = ["ma", "sh", "ten", "phai", "ns", "cccd", "ngay_cap", "noi_cap", "tel", "mail", "dc_ct", "xa_ct", "huyen_ct", "tinh_ct",
           "dc_hk", "xa_hk", "huyen_hk", "tinh_hk", "quoc_tich", "bp", "cv", "bac", "nghi_viec", "ngay_nghi", "thai_san", "ts_tu",
           "ts_den", "khong_bh", "loai_hd", "loai_luong", "giam_ld", "tu_thang", "den_thang", "tang_ld", "thang_tang_ld", "so_hd",
           "so_bhxh", "so_bhyt", "tang_bh", "thang_tang_bh", "mst"]


def doc_json(duong):
    with io.open(duong, encoding="utf-8-sig") as f:
        return json.loads(f.read(), strict=False)


def _doi_unicode(dl):
    """JSON khong danh dau "unicode" (chu doc thang tu so cu TCVN3 / VNI): doi moi chuoi ve Unicode bang xlu_mau (GD127)."""
    try:
        import xlu_mau
    except Exception:
        return dl
    tt = xlu_mau.thu_tu_du_lieu(dl.get("bang_ma") or "")

    def d(x):
        if isinstance(x, str):
            return xlu_mau.doi(x, tt) if xlu_mau.co_cao(x) else x
        if isinstance(x, list):
            return [d(v) for v in x]
        if isinstance(x, dict):
            return {k: d(v) for k, v in x.items()}
        return x
    ra = d(dl)
    ra["unicode"] = 1
    return ra


class DuLieu(object):
    """Gop so lieu so ke toan (JSON) + ho so BHXH luu rieng; tinh luong dong BH tung thang, nhan biet phat sinh."""

    def __init__(self, dl, ho_so):
        self.dl = dl or {}
        if self.dl and not self.dl.get("unicode"):
            self.dl = _doi_unicode(self.dl)
        self.hs = ho_so if ho_so is not None else HoSo("")
        self.ch = doc_cau_hinh()
        self.cty = dict(self.dl.get("cty") or {})
        self.nam_tc = int(so(self.dl.get("nam_tc"), 0)) or _dt.date.today().year
        self.thang_dau = int(so(self.dl.get("thang_dau_ky"), 1)) or 1
        self.bo_phan = {int(so(x[0])): chu(x[2] if len(x) > 2 else "") for x in self.dl.get("bo_phan") or [] if x}
        self.chuc_vu = {int(so(x[0])): chu(x[2] if len(x) > 2 else "") for x in self.dl.get("chuc_vu") or [] if x}
        self.nv = []
        for r in self.dl.get("nv") or []:
            if isinstance(r, list):
                r = dict(zip(NV_KHOA, r))
            if not isinstance(r, dict):
                continue
            n = {k: r.get(k) for k in NV_KHOA}
            n["ma"] = int(so(n["ma"]))
            n["sh"] = chu(n["sh"])
            n["ten"] = chu(n["ten"])
            if not n["ten"]:
                continue
            for k in ("nghi_viec", "thai_san", "khong_bh", "giam_ld", "tang_ld", "tang_bh"):
                n[k] = 1 if so(n[k]) else 0
            for k in ("loai_hd", "loai_luong", "tu_thang", "den_thang", "thang_tang_ld", "thang_tang_bh", "bac", "bp", "cv"):
                n[k] = int(so(n[k]))
            n["so_hd"] = chu(n["so_hd"]) if not isinstance(n["so_hd"], (int, float)) else (str(int(n["so_hd"])) if n["so_hd"] else "")
            for k in ("phai", "cccd", "noi_cap", "tel", "mail", "dc_ct", "xa_ct", "huyen_ct", "tinh_ct", "dc_hk", "xa_hk", "huyen_hk",
                      "tinh_hk", "quoc_tich", "so_bhxh", "so_bhyt", "mst"):
                n[k] = chu(n[k])
            n["phai"] = gioi_tinh(n["phai"])
            n["cccd"] = re.sub(r"\s+", "", n["cccd"])
            n["so_bhxh"] = re.sub(r"\s+", "", n["so_bhxh"])
            n["ns"] = ngay(n["ns"])
            for k in ("ngay_cap", "ngay_nghi", "ts_tu", "ts_den"):
                n[k] = ngay(n[k])
            if n["tang_bh"] and n["thang_tang_bh"]:
                n["khong_bh"] = 0                        # man hinh cu: Tang BH chi bat khi tich Khong BH -> tu thang tang van dong (bang luong quyet dinh)
            if n["so_hd"] in ("0", "0.0"):
                n["so_hd"] = ""                          # SoHD so, mac dinh 0 = chua co
            n["bp_ten"] = self.bo_phan.get(n["bp"], "")
            n["cv_ten"] = self.chuc_vu.get(n["cv"], "")
            self.nv.append(n)
        self.nv.sort(key=lambda x: (x["sh"], x["ma"]))
        self._theo_ma = {n["ma"]: n for n in self.nv}
        # bang luong phan mem: [manv, thang, ngaycong, luongcoban, luongchinh, thunhapkhac, tongthunhap, BHXH, BHYT, BHTN, DNBHXH, DNBHYT, DNBHTN]
        self.bl = {}
        for r in self.dl.get("bl") or []:
            if len(r) < 13:
                continue
            y, m = self.nam_cua_thang(int(so(r[1])))
            if not m:
                continue
            k = (int(so(r[0])), y, m)
            cu = self.bl.get(k)
            moi = {"cb": so(r[3]), "lc": so(r[4]), "tn": so(r[6]), "xh": so(r[7]), "yt": so(r[8]), "tnn": so(r[9]),
                   "dxh": so(r[10]), "dyt": so(r[11]), "dtn": so(r[12]), "nc": so(r[2])}
            if cu:                                   # nhieu dong cung nguoi cung thang: cong so tien (luong lay dong lon nhat)
                for kk in ("xh", "yt", "tnn", "dxh", "dyt", "dtn", "tn"):
                    cu[kk] += moi[kk]
                cu["cb"] = max(cu["cb"], moi["cb"])
            else:
                self.bl[k] = moi
        # ThongSoLuong: ["sohieu", thang, LuongCB, Heso, PCCV, PCTN, PCLD, PCK, BHXH, BHYT, BHTN, DNBHXH, DNBHYT, DNBHTN]
        self.tsl = {}
        for r in self.dl.get("tsl") or []:
            if len(r) < 14:
                continue
            y, m = self.nam_cua_thang(int(so(r[1])))
            if m:                                    # BHXH / BHYT / BHTN cua ThongSoLuong la TY LE (%), luong = (LuongCB hoac 1) x He so
                cb = (so(r[2]) or 1) * so(r[3]) if so(r[3]) else so(r[2])
                tx, ty, tt = so(r[8]), so(r[9]), so(r[10])
                self.tsl[(chu(r[0]), y, m)] = {"cb": cb, "pccv": so(r[4]), "xh": lam_tron(cb * tx / 100) if tx > 0 else 0,
                                               "yt": lam_tron(cb * ty / 100) if ty > 0 else 0, "tnn": lam_tron(cb * tt / 100) if tt > 0 else 0}
        # bang luong Import (AI): [MaNV, thang, nam, LuongCB, PhuCap, TongThuNhap, BHXH_NV, BHYT_NV, BHTN_NV, BHXH_DN, BHYT_DN, BHTN_DN]
        self.ble = {}
        for r in self.dl.get("bl_excel") or []:
            if len(r) < 12:
                continue
            t, y = int(so(r[1])), int(so(r[2]))
            if not (1 <= t <= 12) or y < 1900 or not int(so(r[0])):
                continue
            k = (int(so(r[0])), y, t)
            cu = self.ble.get(k)
            moi = {"cb": so(r[3]), "pc": so(r[4]), "tn": so(r[5]), "xh": so(r[6]), "yt": so(r[7]), "tnn": so(r[8])}
            if cu:
                for kk in ("xh", "yt", "tnn", "tn"):
                    cu[kk] += moi[kk]
                cu["cb"] = max(cu["cb"], moi["cb"])
            else:
                self.ble[k] = moi
        self._thang_co = set((y, m) for (_, y, m) in list(self.bl) + list(self.ble)) | set((y, m) for (_, y, m) in self.tsl)

    # ------------------------------------------------------------------ thang / nam
    def nam_cua_thang(self, thang):
        if not (1 <= thang <= 12):
            return (0, 0)
        if self.thang_dau > 1 and thang < self.thang_dau:
            return (self.nam_tc + 1, thang)
        return (self.nam_tc, thang)

    def co_so_lieu(self, y, m):
        return (y, m) in self._thang_co

    def cac_thang(self):
        return sorted(self._thang_co)

    # ------------------------------------------------------------------ don vi (so ke toan + ho so luu rieng)
    def don_vi(self):
        dv = dict(self.hs.don_vi)
        c = self.cty
        mac = {"ten": c.get("ten", ""), "mst": c.get("mst", ""), "dia_chi": ", ".join(x for x in (chu(c.get("dia_chi")), chu(c.get("quan")),
               chu(c.get("tinh"))) if x), "tel": c.get("tel", ""), "email": c.get("email", ""), "nganh": c.get("nganh", ""),
               "thu_truong": c.get("nguoi_ky", ""), "nhan_kq": "Điện tử", "vung": "I", "phuong_thuc": "Hằng tháng",
               "kinh_gui_pli": "Sở Nội vụ", "loai_hinh": "Công ty trách nhiệm hữu hạn"}
        for k, v in mac.items():
            if not chu(dv.get(k)):
                dv[k] = chu(v)
        return dv

    # ------------------------------------------------------------------ ho so nhan vien da gop
    def ho_so(self, n, goc=False):
        """ho so BHXH da gop: ho so luu rieng (nhap o cua so) ghi de so lieu so ke toan. goc=True: chi so lieu so ke toan."""
        h = {} if goc else self.hs.nv(n["sh"])
        hd = h.get("loai_hd") or {1: "KXD", 2: "XD", 3: "XD"}.get(n["loai_hd"], "")
        dc = n["dc_ct"] or n["dc_hk"]
        dc_day = ", ".join(x for x in (dc, n["xa_ct"] if n["dc_ct"] else n["xa_hk"], n["huyen_ct"] if n["dc_ct"] else n["huyen_hk"],
                                       n["tinh_ct"] if n["dc_ct"] else n["tinh_hk"]) if x)
        return {
            "ma_bhxh": chu(h.get("ma_bhxh")) or n["so_bhxh"],
            "noi_kcb": chu(h.get("noi_kcb")) or chu(self.don_vi().get("noi_kcb")),
            "nhan_kq": chu(h.get("nhan_kq")) or chu(self.don_vi().get("nhan_kq")) or "Điện tử",
            "vi_tri": chu(h.get("vi_tri")) or "KHAC",
            "chuc_danh": chu(h.get("chuc_danh")) or n["cv_ten"],
            "noi_lam_viec": chu(h.get("noi_lam_viec")) or n["bp_ten"],
            "loai_hd": hd,
            "hd_tu": ngay(h.get("hd_tu")),
            "hd_den": ngay(h.get("hd_den")),
            "luong_bh": so(h.get("luong_bh")),
            "pc_cv": so(h.get("pc_cv")), "pc_tnvk": so(h.get("pc_tnvk")), "pc_tnn": so(h.get("pc_tnn")),
            "pc_luong": so(h.get("pc_luong")), "bo_sung": so(h.get("bo_sung")),
            "nn_tu": ngay(h.get("nn_tu")), "nn_den": ngay(h.get("nn_den")),
            "bat_dau_dong": chu(h.get("bat_dau_dong")),
            "dan_toc": chu(h.get("dan_toc")) or "Kinh",
            "quoc_tich": chu(h.get("quoc_tich")) or n["quoc_tich"] or "Việt Nam",
            "dia_chi": chu(h.get("dia_chi")) or dc_day,
            "ghi_chu": chu(h.get("ghi_chu")),
            "khong_bh": bool(h.get("khong_bh")) if "khong_bh" in h else bool(n["khong_bh"]),
        }

    # ------------------------------------------------------------------ luong dong BH
    def luong_bh(self, n, y, m):
        """(muc luong dong BH, nguon, so BH NLD da trich tren bang luong). 0 = thang do khong dong."""
        h = self.hs.nv(n["sh"])
        da = 0.0
        for nguon, r in (("Bảng lương phần mềm", self.bl.get((n["ma"], y, m))), ("Bảng lương Import", self.ble.get((n["ma"], y, m))),
                         ("Thông số lương", self.tsl.get((n["sh"], y, m)))):
            if not r:
                continue
            xh = r.get("xh", 0)
            if xh > 0:
                da = xh + r.get("yt", 0) + r.get("tnn", 0)
                cb = r.get("cb", 0)
                tl = (self.ch["ty_le"].get("nld_xh") or 8.0) / 100.0
                if cb > 0 and abs(lam_tron(cb * tl) - xh) <= 1.0:
                    muc = cb
                else:
                    muc = lam_tron(xh / tl)
                if so(h.get("luong_bh")) > 0:
                    return so(h.get("luong_bh")), "Hồ sơ BHXH (nhập tay)", da
                return muc, nguon, da
        if so(h.get("luong_bh")) > 0 and self.dang_lam(n, y, m) and not self.ho_so(n)["khong_bh"] and not self.co_so_lieu(y, m):
            return so(h.get("luong_bh")), "Hồ sơ BHXH (nhập tay)", 0.0
        return 0.0, "", 0.0

    def thang_dong_dau(self, n):
        """thoi diem don vi bat dau dong BHXH cho nguoi nay: ho so luu rieng > thang tang BH > thang dau tien co trich BH
        (chi khi KHONG phai thang dau tien co so lieu - con co the da dong tu truoc). None = chua biet."""
        hs = self.hs.nv(n["sh"])
        d = ngay(hs.get("bat_dau_dong"))
        if d:
            return d
        if n["tang_bh"] and n["thang_tang_bh"]:
            y, m = self.nam_cua_thang(n["thang_tang_bh"])
            if y and (y, m) != (self.nam_tc, self.thang_dau):     # thang dau so: chua chac la thang bat dau dong
                return _dt.date(y, m, 1)
        ds = self.cac_thang()
        for i, (y, m) in enumerate(ds):
            if self.tham_gia(n, y, m):
                return _dt.date(y, m, 1) if i > 0 else None
        return None

    def dang_lam(self, n, y, m):
        """nhan vien con lam viec trong thang (chua nghi viec truoc dau thang)."""
        nn = n["ngay_nghi"] if (n["nghi_viec"] or n["giam_ld"]) else None
        return not (nn and nn < _dt.date(y, m, 1))

    def tham_gia(self, n, y, m):
        return self.luong_bh(n, y, m)[0] > 0

    # ------------------------------------------------------------------ nhan biet phat sinh tang / giam / dieu chinh
    def phat_sinh_tu_dong(self, y, m):
        ra = []
        yp, mp = thang_truoc(y, m)
        co_truoc = self.co_so_lieu(yp, mp)
        co_nay = self.co_so_lieu(y, m)
        for n in self.nv:
            hs = self.ho_so(n)
            if hs["khong_bh"]:
                continue
            l_nay = self.luong_bh(n, y, m)[0] if co_nay else 0
            l_truoc = self.luong_bh(n, yp, mp)[0] if co_truoc else 0
            ts_bat_dau = n["thai_san"] and n["ts_tu"] and trong_thang(n["ts_tu"], y, m)
            ts_ve = n["thai_san"] and n["ts_den"] and trong_thang(n["ts_den"] + _dt.timedelta(days=1), y, m)
            nghi = (n["nghi_viec"] or n["giam_ld"]) and n["ngay_nghi"]
            dau = _dt.date(y, m, 1)
            da_bao = bool((nghi and n["ngay_nghi"] < dau) or
                          (n["thai_san"] and n["ts_tu"] and n["ts_tu"] < dau and (not n["ts_den"] or n["ts_den"] >= dau)))
            e = None
            if ts_bat_dau:
                e = ("TS", "Nghỉ thai sản từ " + ngay_vn(n["ts_tu"]) + (" đến " + ngay_vn(n["ts_den"]) if n["ts_den"] else ""))
            elif ts_ve:
                e = ("ON", "Đi làm lại sau thai sản từ " + ngay_vn(n["ts_den"] + _dt.timedelta(days=1)))
            elif nghi and trong_thang(n["ngay_nghi"], y, m):
                e = ("GH", "Nghỉ việc từ " + ngay_vn(n["ngay_nghi"]))
            elif n["tang_bh"] and self.nam_cua_thang(n["thang_tang_bh"]) == (y, m) and (not co_truoc or not l_truoc) and (l_nay or not co_nay):
                e = ("TM", "Tăng BH tháng %02d (danh sách nhân viên)" % m)
            elif co_nay and co_truoc and l_nay and not l_truoc and not da_bao:
                e = ("TM", "Bắt đầu đóng BH tháng này (bảng lương)")
            elif co_nay and co_truoc and l_truoc and not l_nay and not da_bao:
                e = ("GH", "Không còn đóng BH tháng này (bảng lương) - kiểm tra lý do giảm")
            elif co_nay and co_truoc and l_nay and l_truoc and abs(l_nay - l_truoc) >= 1:
                e = ("DC", "Lương đóng BH %s -> %s" % ("{:,.0f}".format(l_truoc), "{:,.0f}".format(l_nay)))
            nghi_ngo = False
            if e and e[0] == "TM" and not co_truoc and (y, m) == (self.nam_tc, self.thang_dau):
                nghi_ngo = True                      # thang dau so (khong co thang truoc): co dau Tang BH thuong la chuyen tu so nam truoc
                e = ("TM", "Tháng đầu năm tài chính, sổ không có tháng trước: nhiều khả năng đã tham gia từ năm trước - "
                           "kiểm tra, đúng là tăng mới thì tích chọn")
            if e:
                tu = (y, m)
                if e[0] == "GH" and nghi and trong_thang(n["ngay_nghi"], y, m) and ngay_lam_truoc(n["ngay_nghi"]) >= 14:
                    tu = thang_sau(y, m)             # da lam du 14 ngay trong thang -> van dong thang nay, giam tu thang sau
                if e[0] == "TS" and ngay_lam_truoc(n["ts_tu"]) >= 14:
                    tu = thang_sau(y, m)
                ra.append({"sh": n["sh"], "pa": e[0], "tu": thang_vn(*tu), "den": "", "ghi_chu": e[1], "chon": 0 if nghi_ngo else 1, "tu_dong": 1,
                           "luong_cu": l_truoc, "luong_moi": l_nay})
        return ra

    def phat_sinh(self, y, m):
        """phat sinh cua thang: ban nguoi dung da luu (sua / them) neu co, khong thi tu nhan biet."""
        ds = self.hs.phat_sinh(y, m)
        if ds is None:
            return self.phat_sinh_tu_dong(y, m)
        return [dict(x) for x in ds if isinstance(x, dict) and x.get("sh")]

    def nhom_pa(self, ma):
        for x in self.ch["phuong_an"]:
            if x[0] == ma:
                return x[2]
        return "D"

    def ten_pa(self, ma):
        for x in self.ch["phuong_an"]:
            if x[0] == ma:
                return x[1]
        return ""

    def tim(self, sh):
        for n in self.nv:
            if n["sh"] == sh:
                return n
        return None

    # ------------------------------------------------------------------ kiem tra ho so
    def kiem_tra(self, n, y, m):
        hs = self.ho_so(n)
        loi = []
        if hs["khong_bh"]:
            return ["Không tham gia BH (đánh dấu Không BH)"]
        mb = hs["ma_bhxh"]
        if not mb:
            loi.append("Chưa có mã số BHXH")
        elif not re.fullmatch(r"\d{10}", mb):
            loi.append("Mã số BHXH không đủ 10 chữ số")
        if not n["cccd"]:
            loi.append("Thiếu số CCCD")
        elif not re.fullmatch(r"\d{12}", n["cccd"]):
            loi.append("Số CCCD không phải 12 chữ số")
        if not n["ns"]:
            loi.append("Thiếu ngày sinh")
        if n["phai"] not in ("Nam", "Nữ"):
            loi.append("Thiếu giới tính")
        if not hs["noi_kcb"]:
            loi.append("Chưa có nơi KCB ban đầu")
        if not hs["hd_tu"]:
            loi.append("Chưa có ngày bắt đầu HĐLĐ")
        if hs["loai_hd"] == "XD" and not hs["hd_den"]:
            loi.append("HĐ xác định thời hạn chưa có ngày kết thúc")
        l = self.luong_bh(n, y, m)[0]
        if l > 0:
            d = _dt.date(y, m, 1)
            v, _ = luong_toi_thieu_vung(d, self.don_vi().get("vung"))
            if l < v:
                loi.append("Lương đóng BH %s < lương tối thiểu vùng %s" % ("{:,.0f}".format(l), "{:,.0f}".format(v)))
        return loi


# ====================================================================== kieu o dung chung
class _K(object):
    def __init__(self, wb):
        self.td = wb.kieu(dam=True, co=14, can="giua")
        self.td2 = wb.kieu(dam=True, co=12, can="giua")
        self.nghieng = wb.kieu(nghieng=True, co=10, can="giua")
        self.nghieng_trai = wb.kieu(nghieng=True, co=10)
        self.dam = wb.kieu(dam=True)
        self.dam_giua = wb.kieu(dam=True, can="giua")
        self.thuong = wb.kieu()
        self.giua = wb.kieu(can="giua")
        self.phai = wb.kieu(can="phai")
        self.dau = wb.kieu(dam=True, co=10, can="giua", xuong=True, khung=True, nen="D9E1F2")
        self.so_cot = wb.kieu(nghieng=True, co=9, can="giua", khung=True, nen="F2F2F2")
        self.o = wb.kieu(khung=True, xuong=True, co=10)
        self.o_giua = wb.kieu(khung=True, can="giua", co=10)
        self.o_so = wb.kieu(khung=True, so="#,##0", co=10)
        self.o_ty = wb.kieu(khung=True, so="0.0#", can="giua", co=10)
        self.o_ngay = wb.kieu(khung=True, so="dd/mm/yyyy", can="giua", co=10)
        self.nhom = wb.kieu(khung=True, dam=True, co=10, nen="EEF5E9")
        self.cong = wb.kieu(khung=True, dam=True, co=10, nen="FFF2CC")
        self.cong_so = wb.kieu(khung=True, dam=True, so="#,##0", co=10, nen="FFF2CC")
        self.do = wb.kieu(khung=True, xuong=True, co=10, mau="9C0006", nen="FFC7CE")
        self.vang = wb.kieu(khung=True, so="#,##0", co=10, nen="FFFF99")
        self.chu_ky = wb.kieu(dam=True, can="giua")
        self.chu_ky2 = wb.kieu(nghieng=True, co=10, can="giua")


def _chu_ky(ws, K, r, c_trai, c_phai, rong, dv, nguoi_lap=True):
    """dong ky: ngay thang ben phai; Nguoi lap bieu (trai) - Thu truong don vi (phai)."""
    hn = _dt.date.today()
    ws.gop(r, c_phai, r, c_phai + rong - 1, "..........., ngày %02d tháng %02d năm %d" % (hn.day, hn.month, hn.year), K.nghieng)
    r += 1
    if nguoi_lap:
        ws.gop(r, c_trai, r, c_trai + rong - 1, "NGƯỜI LẬP BIỂU", K.chu_ky)
        ws.gop(r + 1, c_trai, r + 1, c_trai + rong - 1, "(Ký, ghi rõ họ tên)", K.chu_ky2)
        ws.gop(r + 5, c_trai, r + 5, c_trai + rong - 1, chu(dv.get("nguoi_lap")), K.chu_ky)
    ws.gop(r, c_phai, r, c_phai + rong - 1, "THỦ TRƯỞNG ĐƠN VỊ", K.chu_ky)
    ws.gop(r + 1, c_phai, r + 1, c_phai + rong - 1, "(Ký, ghi rõ họ tên, đóng dấu)", K.chu_ky2)
    ws.gop(r + 5, c_phai, r + 5, c_phai + rong - 1, chu(dv.get("thu_truong")), K.chu_ky)
    return r + 6


# ====================================================================== D02-LT
D02_COT = [  # (so cot hien, tieu de, rong)
    ("A", "STT", 5), ("B", "Họ và tên", 22), ("1", "Mã số BHXH", 12), ("2", "Ngày, tháng, năm sinh", 11),
    ("3", "Chức vụ, công việc (chức danh nghề), địa chỉ nơi làm việc", 22),
    ("4", "Tiền lương / hệ số lương", 12), ("5", "Hệ số chênh lệch bảo lưu", 8), ("6", "Phụ cấp chức vụ", 9),
    ("7", "Phụ cấp thâm niên vượt khung (%)", 8), ("8", "Phụ cấp thâm niên nghề (%)", 8),
    ("9", "Phụ cấp lương và các khoản bổ sung", 10),
    ("10", "Không xác định thời hạn", 7), ("11", "Xác định thời hạn", 7), ("12", "HĐ khác / thử việc", 7),
    ("13", "Ngày HĐLĐ / quyết định có hiệu lực", 11), ("14", "Từ tháng, năm", 9), ("15", "Đến tháng, năm", 9),
    ("16", "Nơi đăng ký KCB ban đầu", 16), ("17", "Hình thức nhận kết quả", 9), ("18", "Loại tăng / giảm / điều chỉnh", 9),
    ("19", "Ghi chú", 24),
]


# kieu o tung cot du lieu D02-LT (cot 1..21 = A, B, 1..19)
D02_KIEU = {1: "o_giua", 3: "o_giua", 4: "o_ngay", 6: "o_so", 7: "o_ty", 8: "o_so", 9: "o_ty", 10: "o_ty", 11: "o_so",
            12: "o_giua", 13: "o_giua", 14: "o_giua", 15: "o_ngay", 16: "o_giua", 17: "o_giua", 19: "o_giua", 20: "o_giua"}


def _d02_dong(du, e, n, y, m):
    hs = du.ho_so(n)
    pa = e.get("pa") or ""
    nhom = du.nhom_pa(pa)
    if nhom == "G":
        luong = so(e.get("luong_cu")) or du.luong_bh(n, *thang_truoc(y, m))[0] or du.luong_bh(n, y, m)[0] or hs["luong_bh"]
    else:
        luong = so(e.get("luong_moi")) or du.luong_bh(n, y, m)[0] or hs["luong_bh"]
    cv = "; ".join(x for x in (hs["chuc_danh"], hs["noi_lam_viec"]) if x)
    gc = [chu(e.get("ghi_chu"))]
    if nhom == "T" and not hs["ma_bhxh"] and n["cccd"]:
        gc.append("CCCD: " + n["cccd"])
    if nhom == "T" and n["so_hd"]:
        gc.append("HĐLĐ số " + n["so_hd"])
    hd = hs["loai_hd"]
    return [None, n["ten"], hs["ma_bhxh"], n["ns"], cv, luong or None, None, hs["pc_cv"] or None, hs["pc_tnvk"] or None,
            hs["pc_tnn"] or None, (hs["pc_luong"] + hs["bo_sung"]) or None,
            "x" if hd == "KXD" else "", "x" if hd == "XD" else "", "x" if hd == "KHAC" else "",
            hs["hd_tu"], chu(e.get("tu")), chu(e.get("den")),
            hs["noi_kcb"] if nhom == "T" else "", hs["nhan_kq"] if nhom == "T" else "", pa,
            "; ".join(x for x in gc if x)]


def lap_d02lt(du, y, m, ra):
    dv = du.don_vi()
    ds = [e for e in du.phat_sinh(y, m) if e.get("chon", 1)]
    wb = SoExcel(font="Times New Roman", co=11)
    K = _K(wb)
    nc = len(D02_COT)
    ws = wb.sheet("D02-LT", cot=[w for _, _, w in D02_COT])
    ws.gop(1, 1, 1, 8, "Tên đơn vị: " + chu(dv.get("ten")), K.dam)
    ws.gop(1, 16, 1, nc, "Mẫu D02-LT", K.dam_giua)
    ws.gop(2, 1, 2, 8, "Mã đơn vị: " + chu(dv.get("ma_dv")), K.thuong)
    ws.gop(2, 14, 3, nc, "(" + CAN_CU_D02 + ")", wb.kieu(nghieng=True, co=9, can="giua", xuong=True))
    ws.gop(3, 1, 3, 8, "Mã số thuế: " + chu(dv.get("mst")), K.thuong)
    ws.gop(4, 1, 4, 12, "Địa chỉ: " + chu(dv.get("dia_chi")), K.thuong)
    ws.gop(5, 1, 5, 12, "Điện thoại: " + chu(dv.get("tel")) + "      Email: " + chu(dv.get("email")), K.thuong)
    ws.gop(7, 1, 7, nc, "DANH SÁCH THAM GIA, ĐIỀU CHỈNH ĐÓNG BẢO HIỂM XÃ HỘI, BẢO HIỂM Y TẾ, BẢO HIỂM THẤT NGHIỆP", K.td)
    ws.gop(8, 1, 8, nc, "Số: ........ tháng %02d năm %d" % (m, y), K.giua)
    if chu(dv.get("co_quan_bhxh")):
        ws.gop(9, 1, 9, nc, "Kính gửi: " + chu(dv.get("co_quan_bhxh")), K.giua)
    r0 = 10
    for i, (sh, td, _) in enumerate(D02_COT, start=1):
        if i in range(6, 12) or i in range(12, 15) or i in (16, 17):
            continue
        ws.gop(r0, i, r0 + 1, i, td, K.dau)
    ws.gop(r0, 6, r0, 11, "Tiền lương, phụ cấp", K.dau)
    for i in range(6, 12):
        ws.o(r0 + 1, i, D02_COT[i - 1][1], K.dau)
    ws.gop(r0, 12, r0, 14, "Loại hợp đồng lao động", K.dau)
    for i in range(12, 15):
        ws.o(r0 + 1, i, D02_COT[i - 1][1], K.dau)
    ws.gop(r0, 16, r0, 17, "Thời gian", K.dau)
    for i in (16, 17):
        ws.o(r0 + 1, i, D02_COT[i - 1][1], K.dau)
    ws.cao(r0 + 1, 66)
    for i, (sh, _, _) in enumerate(D02_COT, start=1):
        ws.o(r0 + 2, i, "(%s)" % sh, K.so_cot)
    r = r0 + 3
    tong = {}
    stt = 0
    for nhom, ten_nhom in (("T", "I. TĂNG"), ("G", "II. GIẢM"), ("D", "III. ĐIỀU CHỈNH")):
        dong = [e for e in ds if du.nhom_pa(e.get("pa")) == nhom]
        ws.o(r, 1, None, K.nhom)
        ws.o(r, 2, ten_nhom, K.nhom)
        for c in range(3, nc + 1):
            ws.o(r, c, None, K.nhom)
        r += 1
        r_dau = r
        for e in dong:
            n = du.tim(e.get("sh"))
            if not n:
                continue
            stt += 1
            gt = _d02_dong(du, e, n, y, m)
            gt[0] = stt
            for c, v in enumerate(gt, start=1):
                ws.o(r, c, v, getattr(K, D02_KIEU.get(c, "o")))
            r += 1
        sl = r - r_dau
        ws.o(r, 1, None, K.cong)
        ws.o(r, 2, "Cộng %s (%d người)" % (ten_nhom.split(".")[0], sl), K.cong)
        for c in range(3, nc + 1):
            ws.o(r, c, None, K.cong)
        v = sum(so(_d02_dong(du, e, du.tim(e.get("sh")), y, m)[5]) for e in dong if du.tim(e.get("sh")))
        ws.o(r, 6, CT("SUM(%s:%s)" % (dia_chi(r_dau, 6), dia_chi(max(r_dau, r - 1), 6)), v) if sl else 0, K.cong_so)
        tong[nhom] = (sl, v)
        r += 1
    r += 1
    ws.gop(r, 1, r, 6, "TỔNG HỢP (từ danh sách trên)", K.dam)
    r += 1
    for nhom, ten in (("T", "Tăng"), ("G", "Giảm"), ("D", "Điều chỉnh")):
        sl, v = tong.get(nhom, (0, 0))
        ws.gop(r, 2, r, 4, "- %s: %d người, quỹ lương đóng BH" % (ten, sl), K.thuong)
        ws.o(r, 6, v, wb.kieu(so="#,##0"))
        r += 1
    r += 1
    r = _chu_ky(ws, K, r, 2, 15, 5, dv)
    ws.in_trang(ngang=True, vua_rong=True, lap_dong=(r0, r0 + 2), le=(0.3, 0.3, 0.5, 0.5))
    ws.dong_bang(r0 + 3, 3)
    tep = os.path.join(ra, "D02-LT_%04d%02d.xlsx" % (y, m))
    wb.luu(tep)
    return tep, stt


# ====================================================================== 01/PLI
def _ky_pli(y, ky):
    """ky 1 = 6 thang dau nam (01-06), 2 = cuoi nam (07-12)."""
    return (_dt.date(y, 1, 1), _dt.date(y, 6, 30)) if ky == 1 else (_dt.date(y, 7, 1), _dt.date(y, 12, 31))


def ds_pli(du, y, ky):
    """nguoi lao dong cua ky bao cao: chua nghi viec truoc dau ky; ky da co bang luong thi chi lay nguoi co ten tren bang luong
    trong ky (nguoi trong danh muc ma khong co luong ca ky thuong la ho so cu chua danh dau nghi). Tra ve [(nv, [thang co BH])]."""
    d1, d2 = _ky_pli(y, ky)
    thang = [(y, mm) for mm in range(d1.month, d2.month + 1)]
    co_dl = any(du.co_so_lieu(*t) for t in thang)
    ra = []
    for n in du.nv:
        if (n["nghi_viec"] or n["giam_ld"]) and n["ngay_nghi"] and n["ngay_nghi"] < d1:
            continue
        co_bh = [t for t in thang if du.tham_gia(n, *t)]
        co_luong = any(((n["ma"],) + t) in du.bl or ((n["ma"],) + t) in du.ble or ((n["sh"],) + t) in du.tsl for t in thang)
        ts_trong_ky = n["thai_san"] and n["ts_tu"] and n["ts_tu"] <= d2 and (not n["ts_den"] or n["ts_den"] >= d1)
        if co_dl and not co_luong and not co_bh and not ts_trong_ky:
            continue
        ra.append((n, co_bh))
    return ra


def lap_01pli(du, y, ky, ra):
    dv = du.don_vi()
    d1, d2 = _ky_pli(y, ky)
    wb = SoExcel(font="Times New Roman", co=11)
    K = _K(wb)
    rong = [5, 22, 12, 11, 7, 14, 20, 8, 8, 8, 8, 11, 9, 7, 7, 9, 9, 10, 10, 11, 10, 10, 10, 10, 10, 10, 18]
    ws = wb.sheet("01-PLI", cot=rong)
    nc = 27
    ws.gop(1, 1, 1, 7, chu(dv.get("ten")).upper(), K.dam_giua)
    ws.gop(1, 16, 1, nc, "CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM", K.dam_giua)
    ws.gop(2, 16, 2, nc, "Độc lập - Tự do - Hạnh phúc", K.dam_giua)
    ws.gop(3, 1, 3, 7, "Số: ......../BC", K.giua)
    hn = _dt.date.today()
    ws.gop(3, 16, 3, nc, "..........., ngày %02d tháng %02d năm %d" % (hn.day, hn.month, hn.year), K.nghieng)
    ws.gop(1, 9, 1, 14, "Mẫu số 01/PLI", K.dam_giua)
    ws.gop(2, 9, 2, 14, "(" + CAN_CU_PLI + ")", wb.kieu(nghieng=True, co=9, can="giua"))
    ws.gop(5, 1, 5, nc, "BÁO CÁO TÌNH HÌNH THAY ĐỔI VỀ LAO ĐỘNG", K.td)
    ws.gop(6, 1, 6, nc, "(6 tháng đầu năm %d)" % y if ky == 1 else "(Cuối năm %d)" % y, K.nghieng)
    ws.gop(7, 1, 7, nc, "Kính gửi: " + chu(dv.get("kinh_gui_pli")), K.giua)
    ws.gop(9, 1, 9, nc, "1. Tên doanh nghiệp / tổ chức: " + chu(dv.get("ten")) + "      Mã số doanh nghiệp: " + chu(dv.get("mst")), K.thuong)
    ws.gop(10, 1, 10, nc, "2. Loại hình doanh nghiệp / tổ chức: " + chu(dv.get("loai_hinh")), K.thuong)
    ws.gop(11, 1, 11, nc, "3. Lĩnh vực hoạt động / ngành nghề kinh doanh chính: " + chu(dv.get("nganh")), K.thuong)
    ws.gop(12, 1, 12, nc, "4. Địa chỉ: " + chu(dv.get("dia_chi")) + "      Điện thoại: " + chu(dv.get("tel")) + "      Email: " +
           chu(dv.get("email")), K.thuong)
    r0 = 14
    for c, td in ((1, "STT"), (2, "Họ và tên"), (3, "Mã số BHXH"), (4, "Ngày, tháng, năm sinh"), (5, "Giới tính"),
                  (6, "Số CCCD / CMND / Hộ chiếu"), (7, "Cấp bậc, chức vụ, chức danh nghề, nơi làm việc"),
                  (25, "Thời điểm đơn vị bắt đầu đóng BHXH"), (26, "Thời điểm đơn vị kết thúc đóng BHXH"), (27, "Ghi chú")):
        ws.gop(r0, c, r0 + 2, c, td, K.dau)
    ws.gop(r0, 8, r0, 11, "Vị trí việc làm", K.dau)
    for i, (_, td) in enumerate(VI_TRI):
        ws.gop(r0 + 1, 8 + i, r0 + 2, 8 + i, td, K.dau)
    ws.gop(r0, 12, r0, 17, "Tiền lương", K.dau)
    ws.gop(r0 + 1, 12, r0 + 2, 12, "Hệ số / Mức lương", K.dau)
    ws.gop(r0 + 1, 13, r0 + 1, 17, "Phụ cấp", K.dau)
    for i, td in enumerate(("Chức vụ", "Thâm niên VK (%)", "Thâm niên nghề (%)", "Phụ cấp lương", "Các khoản bổ sung")):
        ws.o(r0 + 2, 13 + i, td, K.dau)
    ws.gop(r0, 18, r0, 19, "Ngành / nghề nặng nhọc, độc hại", K.dau)
    ws.gop(r0 + 1, 18, r0 + 2, 18, "Ngày bắt đầu", K.dau)
    ws.gop(r0 + 1, 19, r0 + 2, 19, "Ngày kết thúc", K.dau)
    ws.gop(r0, 20, r0, 24, "Loại và hiệu lực hợp đồng lao động", K.dau)
    ws.gop(r0 + 1, 20, r0 + 2, 20, "Ngày bắt đầu HĐLĐ không xác định thời hạn", K.dau)
    ws.gop(r0 + 1, 21, r0 + 1, 22, "Hiệu lực HĐLĐ xác định thời hạn", K.dau)
    ws.o(r0 + 2, 21, "Ngày bắt đầu", K.dau)
    ws.o(r0 + 2, 22, "Ngày kết thúc", K.dau)
    ws.gop(r0 + 1, 23, r0 + 1, 24, "Hiệu lực HĐ khác (dưới 1 tháng, thử việc)", K.dau)
    ws.o(r0 + 2, 23, "Ngày bắt đầu", K.dau)
    ws.o(r0 + 2, 24, "Ngày kết thúc", K.dau)
    ws.cao(r0 + 1, 30)
    ws.cao(r0 + 2, 54)
    for c in range(1, nc + 1):
        ws.o(r0 + 3, c, "(%d)" % c, K.so_cot)
    r = r0 + 4
    stt = 0
    for n, co_bh in ds_pli(du, y, ky):
        hs = du.ho_so(n)
        stt += 1
        luong = 0
        for t in reversed([(y, mm) for mm in range(d1.month, d2.month + 1)]):
            luong = du.luong_bh(n, *t)[0]
            if luong:
                break
        luong = luong or hs["luong_bh"]
        bd = du.thang_dong_dau(n) if not hs["khong_bh"] else None
        kt = n["ngay_nghi"] if ((n["nghi_viec"] or n["giam_ld"]) and n["ngay_nghi"] and n["ngay_nghi"] <= d2) else None
        vt = hs["vi_tri"]
        hd = hs["loai_hd"]
        gc = []
        if kt:
            gc.append("Nghỉ việc " + ngay_vn(kt))
        if hs["khong_bh"]:
            gc.append("Không tham gia BHXH")
        if hs["ghi_chu"]:
            gc.append(hs["ghi_chu"])
        gt = [stt, n["ten"], hs["ma_bhxh"], n["ns"], n["phai"], n["cccd"],
              "; ".join(x for x in (hs["chuc_danh"], hs["noi_lam_viec"]) if x),
              "x" if vt == "QL" else "", "x" if vt == "CAO" else "", "x" if vt == "TRUNG" else "", "x" if vt == "KHAC" else "",
              luong or None, hs["pc_cv"] or None, hs["pc_tnvk"] or None, hs["pc_tnn"] or None, hs["pc_luong"] or None,
              hs["bo_sung"] or None, hs["nn_tu"], hs["nn_den"],
              hs["hd_tu"] if hd == "KXD" else None, hs["hd_tu"] if hd == "XD" else None, hs["hd_den"] if hd == "XD" else None,
              hs["hd_tu"] if hd == "KHAC" else None, hs["hd_den"] if hd == "KHAC" else None,
              bd.strftime("%m/%Y") if bd else "", kt.strftime("%m/%Y") if kt else "", "; ".join(gc)]
        for c, v in enumerate(gt, start=1):
            k = K.o
            if c in (1, 3, 5, 6, 8, 9, 10, 11, 25, 26):
                k = K.o_giua
            if c in (12, 13, 16, 17):
                k = K.o_so
            if c in (14, 15):
                k = K.o_ty
            if c in (4, 18, 19, 20, 21, 22, 23, 24):
                k = K.o_ngay
            ws.o(r, c, v, k)
        r += 1
    ws.gop(r, 1, r, 2, "Tổng số: %d người" % stt, K.cong)
    for c in range(3, nc + 1):
        ws.o(r, c, None, K.cong)
    r += 2
    ws.gop(r, 1, r, nc, GHI_CHU_PLI, K.nghieng_trai)
    r += 2
    _chu_ky(ws, K, r, 2, 19, 7, dv)
    ws.in_trang(ngang=True, vua_rong=True, lap_dong=(r0, r0 + 3), le=(0.3, 0.3, 0.5, 0.5))
    ws.dong_bang(r0 + 4, 3)
    tep = os.path.join(ra, "01-PLI_%d_%s.xlsx" % (y, "6ThangDau" if ky == 1 else "CuoiNam"))
    wb.luu(tep)
    return tep, stt


# ====================================================================== GD170: Mau so 33 - Thong bao ve tinh hinh bien dong lao dong (ND 374/2025)
CAN_CU_M33 = "Mẫu số 33 ban hành kèm theo Nghị định số 374/2025/NĐ-CP ngày 31/12/2025 của Chính phủ"
GHI_CHU_M33 = ("Nghị định 374/2025/NĐ-CP (hiệu lực 01/01/2026) Điều 32: khi có biến động lao động, người sử dụng lao động thông báo với tổ chức "
               "dịch vụ việc làm công nơi đặt trụ sở (khoản 6); tăng hoặc giảm từ 50 lao động trở lên phải thông báo theo Mẫu số 33 (khoản 10). "
               "Thông lệ trước đây (Thông tư 28/2015): gửi trước ngày 03 tháng sau. Cột trình độ chuyên môn (8a-8e), lý do giảm, thời gian đã "
               "tham gia BHTN phần mềm không có số liệu - điền tay trước khi nộp. Tệp để đối chiếu / nhập liệu, không phải bản nộp.")
TRINH_DO_M33 = [("8a", "Công nhân kỹ thuật không có bằng"), ("8b", "Chứng chỉ nghề ngắn hạn dưới 3 tháng"), ("8c", "Sơ cấp"),
                ("8d", "Trung cấp"), ("8đ", "Cao đẳng"), ("8e", "Đại học trở lên")]
LOAI_HD_M33 = [("9a", "HĐLĐ không xác định thời hạn"), ("9b", "HĐLĐ xác định thời hạn từ đủ 12 tháng đến dưới 36 tháng"),
               ("9c", "HĐLĐ xác định thời hạn từ đủ 1 tháng đến dưới 12 tháng")]
PA_GIAM_M33 = ("GH", "GC", "GD")           # giam lao dong (nghi viec / chuyen di); TS, OF khong phai giam; KL -> tam hoan (muc IV)
PA_TANG_M33 = ("TM", "TC", "TD")           # tang lao dong (ON = di lam lai: khong phai tang moi)
PA_HOAN_M33 = ("KL",)


def ma_hd_m33(hs):
    """loai HĐ theo ma 9a / 9b / 9c cua Mau 33 (XD: theo thoi han hd_tu -> hd_den; khong ro -> 9b)."""
    hd = hs.get("loai_hd") or ""
    if hd == "KXD":
        return "9a"
    if hd == "XD":
        a, b = hs.get("hd_tu"), hs.get("hd_den")
        if a and b:
            thang = (b.year - a.year) * 12 + (b.month - a.month)
            return "9c" if thang < 12 else "9b"
        return "9b"
    return "9c" if hd == "KHAC" else ""


def ds_bien_dong(du, y, m):
    """phat sinh thang -> (tang [(nv, e)], giam [(nv, e)], tam hoan [(nv, e)]) - chi dong da tich chon."""
    tang, giam, hoan = [], [], []
    for e in du.phat_sinh(y, m):
        if not e.get("chon", 1):
            continue
        n = du.tim(e.get("sh"))
        if n is None:
            continue
        pa = e.get("pa") or ""
        if pa in PA_TANG_M33:
            tang.append((n, e))
        elif pa in PA_GIAM_M33:
            giam.append((n, e))
        elif pa in PA_HOAN_M33:
            hoan.append((n, e))
    return tang, giam, hoan


def _nu(n):
    return "x" if bo_dau(chu(n.get("phai"))).upper().startswith("NU") else ""


def lap_mau33(du, y, m, ra):
    """Mau so 33 (ND 374/2025) thang y/m -> (tep, so dong tang + giam + tam hoan). Khong co bien dong -> van lap (bang trong) de doi chieu."""
    dv = du.don_vi()
    tang, giam, hoan = ds_bien_dong(du, y, m)
    yp, mp = thang_truoc(y, m)
    sh_tang = set(x[0]["sh"] for x in tang)
    sh_giam = set(x[0]["sh"] for x in giam)
    # dau ky = dang lam tu dau thang (chua nghi truoc dau thang), khong ke nguoi tang moi trong thang; cuoi ky = dau ky - giam + tang
    dau_ky = [n for n in du.nv if du.dang_lam(n, y, m) and n["sh"] not in sh_tang]
    wb = SoExcel(font="Times New Roman", co=11)
    K = _K(wb)
    nc = 14
    ws = wb.sheet("Mau 33", cot=[5, 24, 11, 6, 9, 14, 12, 9, 9, 12, 12, 12, 12, 22])
    ws.gop(1, 1, 1, 6, chu(dv.get("ten")).upper(), K.dam)
    ws.gop(2, 1, 2, 6, "Địa chỉ: " + chu(dv.get("dia_chi")), K.thuong)
    ws.gop(3, 1, 3, 6, "Điện thoại: " + chu(dv.get("tel")) + "    Mã số thuế: " + chu(dv.get("mst")), K.thuong)
    ws.gop(1, 8, 1, nc, "CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM", K.dam_giua)
    ws.gop(2, 8, 2, nc, "Độc lập - Tự do - Hạnh phúc", K.dam_giua)
    hn = _dt.date.today()
    ws.gop(3, 8, 3, nc, "..........., ngày %02d tháng %02d năm %d" % (hn.day, hn.month, hn.year), K.nghieng)
    ws.gop(4, 8, 4, nc, "Mẫu số 33", K.dam_giua)
    ws.gop(5, 8, 5, nc, "(" + CAN_CU_M33 + ")", wb.kieu(nghieng=True, co=9, can="giua", xuong=True))
    ws.gop(7, 1, 7, nc, "THÔNG BÁO VỀ TÌNH HÌNH BIẾN ĐỘNG LAO ĐỘNG", K.td)
    ws.gop(8, 1, 8, nc, "Tháng %02d năm %d" % (m, y), K.giua)
    ws.gop(9, 1, 9, nc, "Kính gửi: " + (chu(dv.get("kinh_gui_m33")) or "Tổ chức dịch vụ việc làm công (Trung tâm Dịch vụ việc làm) ............"), K.giua)
    # ---- I. so lao dong dau ky - tang - giam - cuoi ky
    r = 11
    ws.gop(r, 1, r, nc, "I. SỐ LAO ĐỘNG ĐẦU KỲ, TĂNG, GIẢM, CUỐI KỲ", K.dam)
    r += 1
    ws.gop(r, 1, r + 1, 2, "Chỉ tiêu", K.dau)
    ws.gop(r, 3, r + 1, 3, "Tổng số lao động", K.dau)
    ws.gop(r, 4, r + 1, 4, "Trong đó nữ", K.dau)
    ws.gop(r, 5, r, 10, "Trình độ chuyên môn kỹ thuật (8a - 8e: điền tay)", K.dau)
    for i, (ma, _) in enumerate(TRINH_DO_M33):
        ws.o(r + 1, 5 + i, ma, K.dau)
    ws.gop(r, 11, r, 13, "Loại hợp đồng", K.dau)
    for i, (ma, _) in enumerate(LOAI_HD_M33):
        ws.o(r + 1, 11 + i, ma, K.dau)
    ws.gop(r, 14, r + 1, 14, "Số người tham gia BHTN", K.dau)
    ws.cao(r, 30)
    ws.cao(r + 1, 30)
    r += 2

    def _tong(ds):
        hd = {"9a": 0, "9b": 0, "9c": 0}
        bhtn = 0
        nu = 0
        for n in ds:
            hs = du.ho_so(n)
            k = ma_hd_m33(hs)
            if k in hd:
                hd[k] += 1
            if not hs["khong_bh"]:
                bhtn += 1
            if _nu(n):
                nu += 1
        return [len(ds), nu, None, None, None, None, None, None, hd["9a"], hd["9b"], hd["9c"], bhtn]
    cuoi = [n for n in dau_ky if n["sh"] not in sh_giam] + [x[0] for x in tang]
    for ten, ds in (("Số lao động đầu kỳ", dau_ky), ("Số tăng trong kỳ", [x[0] for x in tang]), ("Số giảm trong kỳ", [x[0] for x in giam]),
                    ("Số lao động cuối kỳ", cuoi)):
        ws.gop(r, 1, r, 2, ten, K.o)
        for c, v in enumerate(_tong(ds), start=3):
            ws.o(r, c, v if v else None, K.o_so if v is not None else K.o_giua)
        r += 1
    r += 1
    # ---- II / III / IV danh sach
    cot = ("STT", "Họ và tên", "Ngày sinh", "Nữ", "Dân tộc", "Số định danh / CCCD", "Số sổ BHXH", "Trình độ (8a-8e)", "Loại HĐ (9a-9c)",
           "Ngày HĐ có hiệu lực", "Ngày chấm dứt / bắt đầu tạm hoãn", "Vị trí việc làm / kết thúc tạm hoãn", "Lương đóng BHTN (nghìn đồng)",
           "Lý do giảm / thời gian đã tham gia BHTN (tháng) / ghi chú")
    so_dong = 0
    for tieu, ds, loai in (("II. DANH SÁCH LAO ĐỘNG GIẢM", giam, "G"), ("III. DANH SÁCH LAO ĐỘNG TĂNG", tang, "T"),
                           ("IV. TẠM HOÃN HỢP ĐỒNG LAO ĐỘNG", hoan, "H")):
        ws.gop(r, 1, r, nc, tieu, K.dam)
        r += 1
        for c, td in enumerate(cot, start=1):
            ws.o(r, c, td, K.dau)
        ws.cao(r, 54)
        r += 1
        if not ds:
            ws.gop(r, 1, r, nc, "(không có)", K.o)
            r += 1
        for stt, (n, e) in enumerate(ds, start=1):
            hs = du.ho_so(n)
            luong = e.get("luong_moi") or hs["luong_bh"] or du.luong_bh(n, y, m)[0]
            if loai == "G":
                c11, c12, c13, c14 = n["ngay_nghi"], "", None, "Lý do giảm: ........ (nghỉ hưu / đơn phương chấm dứt / thoả thuận / khác)"
            elif loai == "T":
                c11, c12, c13, c14 = None, hs["chuc_danh"] or hs["noi_lam_viec"], (luong / 1000.0) if (luong and not hs["khong_bh"]) else None, \
                    "Đã tham gia BHTN: ...... tháng" if not hs["khong_bh"] else "Không thuộc đối tượng BHTN"
            else:
                c11, c12, c13, c14 = hs["nn_tu"], hs["nn_den"], None, e.get("ghi_chu") or ""
            gt = [stt, n["ten"], n["ns"], _nu(n), hs["dan_toc"], n["cccd"], hs["ma_bhxh"], "", ma_hd_m33(hs), hs["hd_tu"], c11, c12, c13, c14]
            for c, v in enumerate(gt, start=1):
                k = K.o
                if c in (1, 4, 5, 7, 8, 9):
                    k = K.o_giua
                if c in (3, 10) or (c == 11 and loai != "T") or (c == 12 and loai == "H"):
                    k = K.o_ngay
                if c == 13:
                    k = K.o_so
                ws.o(r, c, v, k)
            r += 1
            so_dong += 1
        ws.gop(r, 1, r, 2, "Tổng số: %d người" % len(ds), K.cong)
        for c in range(3, nc + 1):
            ws.o(r, c, None, K.cong)
        r += 2
    ws.gop(r, 1, r, nc, "Ghi chú: " + "; ".join("%s = %s" % x for x in TRINH_DO_M33) + ". " + "; ".join("%s = %s" % x for x in LOAI_HD_M33) + ".",
           K.nghieng_trai)
    ws.cao(r, 42)
    r += 1
    ws.gop(r, 1, r, nc, GHI_CHU_M33, K.nghieng_trai)
    ws.cao(r, 54)
    r += 2
    _chu_ky(ws, K, r, 2, 11, 4, dv, nguoi_lap=True)
    ws.in_trang(ngang=True, vua_rong=True, le=(0.3, 0.3, 0.5, 0.5))
    tep = os.path.join(ra, "Mau33_BienDongLD_%04d%02d.xlsx" % (y, m))
    wb.luu(tep)
    return tep, so_dong


def bien_dong_nam(du):
    """[(y, m, so tang, so giam, so tam hoan)] cac thang cua nam tai chinh den thang hien tai (de lich cong viec VB6 biet thang nao co bien dong)."""
    ra = []
    hn = _dt.date.today()
    for k in range(12):
        y, m = du.nam_cua_thang(((du.thang_dau - 1 + k) % 12) + 1)
        if (y, m) > (hn.year, hn.month):
            continue
        try:
            tang, giam, hoan = ds_bien_dong(du, y, m)
        except Exception:
            continue
        ra.append((y, m, len(tang), len(giam), len(hoan)))
    return ra


def ghi_bien_dong(du, thu_kq=None):
    """ket-qua\\lao_dong_bien_dong.txt: MST;<mst>;<ngay>  roi T;yyyy-mm;tang;giam;tam hoan (VB6 ModMauMoi170 doc, chi khi dung MST)."""
    thu_kq = thu_kq or os.path.join(os.path.dirname(os.path.abspath(__file__)), "ket-qua")
    try:
        os.makedirs(thu_kq, exist_ok=True)
        mst = re.sub(r"[^0-9\-]", "", chu(du.don_vi().get("mst")))
        d = ["MST;%s;%s" % (mst, _dt.datetime.now().strftime("%d/%m/%Y %H:%M"))]
        for y, m, t, g, h in bien_dong_nam(du):
            d.append("T;%04d-%02d;%d;%d;%d" % (y, m, t, g, h))
        p = os.path.join(thu_kq, "lao_dong_bien_dong.txt")
        with io.open(p + ".tam", "w", encoding="utf-8") as f:
            f.write("\n".join(d) + "\n")
        os.replace(p + ".tam", p)
        return p
    except Exception:
        return ""


# ====================================================================== TK1-TS (moi nguoi mot sheet)
def _tk_dong(ws, K, r, ma, nhan, gt, nc=8):
    ws.o(r, 1, ma, K.dam)
    ws.gop(r, 2, r, 4, nhan, K.thuong)
    ws.gop(r, 5, r, nc, gt if gt not in (None, "") else "....................................................", K.dam if gt else K.thuong)
    return r + 1


def lap_tk1ts(du, ds_sh, y, m, ra):
    dv = du.don_vi()
    wb = SoExcel(font="Times New Roman", co=12)
    K = _K(wb)
    dem = 0
    for sh in ds_sh:
        n = du.tim(sh)
        if not n:
            continue
        hs = du.ho_so(n)
        dem += 1
        ws = wb.sheet(("%02d_" % dem) + re.sub(r"[^A-Za-z0-9]+", "", bo_dau(n["ten"]))[:24], cot=[7, 14, 14, 14, 14, 14, 14, 14])
        ws.gop(1, 1, 1, 4, "BẢO HIỂM XÃ HỘI VIỆT NAM", K.dam_giua)
        ws.gop(1, 5, 1, 8, "CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM", K.dam_giua)
        ws.gop(2, 5, 2, 8, "Độc lập - Tự do - Hạnh phúc", K.dam_giua)
        ws.gop(3, 7, 3, 8, "Mẫu TK1-TS", K.dam_giua)
        ws.gop(5, 1, 5, 8, "TỜ KHAI ĐĂNG KÝ, ĐIỀU CHỈNH THÔNG TIN THAM GIA", K.td)
        ws.gop(6, 1, 6, 8, "BẢO HIỂM XÃ HỘI, BẢO HIỂM Y TẾ", K.td)
        r = 8
        ws.gop(r, 1, r, 8, "A. ĐĂNG KÝ THAM GIA", K.td2)
        r += 1
        dc = hs["dia_chi"]
        cv = "; ".join(x for x in (hs["chuc_danh"], hs["noi_lam_viec"], chu(dv.get("ten"))) if x)
        luong = du.luong_bh(n, y, m)[0] or hs["luong_bh"]
        for ma, nhan, gt in (("[01]", "Họ và tên (viết chữ in hoa)", n["ten"].upper()), ("[02]", "Giới tính", n["phai"]),
                             ("[03]", "Ngày, tháng, năm sinh", ngay_vn(n["ns"])), ("[04]", "Quốc tịch", hs["quoc_tich"]),
                             ("[05]", "Dân tộc", hs["dan_toc"]), ("[06]", "Số định danh cá nhân / CCCD / Hộ chiếu", n["cccd"]),
                             ("[07]", "Số điện thoại liên hệ", n["tel"]), ("[08]", "Thư điện tử (email)", n["mail"]),
                             ("[09]", "Địa chỉ liên hệ (nhận kết quả)", dc), ("[10]", "Mã số BHXH (nếu đã có)", hs["ma_bhxh"]),
                             ("[11]", "Chức vụ / công việc, đơn vị làm việc", cv),
                             ("[12]", "Mức tiền lương đóng BHXH", "{:,.0f} đồng".format(luong) if luong else ""),
                             ("[13]", "Nơi đăng ký KCB BHYT ban đầu", hs["noi_kcb"]),
                             ("[14]", "Hình thức nhận kết quả", hs["nhan_kq"]),
                             ("[15]", "Phương thức đóng / mức đóng (BHXH tự nguyện)", "")):
            r = _tk_dong(ws, K, r, ma, nhan, gt)
        r += 1
        ws.gop(r, 1, r, 8, "B. ĐIỀU CHỈNH THÔNG TIN (người đã có mã số BHXH)", K.td2)
        r += 1
        r = _tk_dong(ws, K, r, "[16]", "Nội dung thay đổi, yêu cầu (cũ -> mới)", "")
        r = _tk_dong(ws, K, r, "", "", "")
        r = _tk_dong(ws, K, r, "[17]", "Hồ sơ kèm theo (nếu có)", "")
        r += 1
        ws.gop(r, 1, r + 1, 8, "Tôi cam đoan những nội dung kê khai là đúng và chịu trách nhiệm trước pháp luật về những nội dung đã kê khai.",
               wb.kieu(nghieng=True, xuong=True))
        r += 3
        hn = _dt.date.today()
        ws.gop(r, 5, r, 8, "..........., ngày %02d tháng %02d năm %d" % (hn.day, hn.month, hn.year), K.nghieng)
        ws.gop(r + 1, 5, r + 1, 8, "NGƯỜI KÊ KHAI", K.chu_ky)
        ws.gop(r + 2, 5, r + 2, 8, "(Ký, ghi rõ họ tên)", K.chu_ky2)
        ws.gop(r + 6, 5, r + 6, 8, n["ten"], K.chu_ky)
        ws.gop(r + 8, 1, r + 9, 8, GHI_CHU_TK, wb.kieu(nghieng=True, co=9, xuong=True, mau="595959"))
        ws.in_trang(ngang=False, vua_rong=True, le=(0.6, 0.4, 0.5, 0.5))
    if not dem:
        return "", 0
    tep = os.path.join(ra, "TK1-TS_%04d%02d.xlsx" % (y, m))
    wb.luu(tep)
    return tep, dem


# ====================================================================== TK3-TS (don vi)
def lap_tk3ts(du, ra):
    dv = du.don_vi()
    wb = SoExcel(font="Times New Roman", co=12)
    K = _K(wb)
    ws = wb.sheet("TK3-TS", cot=[7, 14, 14, 14, 14, 14, 14, 14])
    ws.gop(1, 1, 1, 4, "BẢO HIỂM XÃ HỘI VIỆT NAM", K.dam_giua)
    ws.gop(1, 5, 1, 8, "CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM", K.dam_giua)
    ws.gop(2, 5, 2, 8, "Độc lập - Tự do - Hạnh phúc", K.dam_giua)
    ws.gop(3, 7, 3, 8, "Mẫu TK3-TS", K.dam_giua)
    ws.gop(5, 1, 5, 8, "TỜ KHAI ĐƠN VỊ ĐĂNG KÝ, ĐIỀU CHỈNH THÔNG TIN THAM GIA", K.td)
    ws.gop(6, 1, 6, 8, "BẢO HIỂM XÃ HỘI, BẢO HIỂM Y TẾ, BẢO HIỂM THẤT NGHIỆP", K.td)
    if chu(dv.get("co_quan_bhxh")):
        ws.gop(7, 1, 7, 8, "Kính gửi: " + chu(dv.get("co_quan_bhxh")), K.giua)
    r = 9
    ws.gop(r, 1, r, 8, "A. ĐĂNG KÝ THAM GIA", K.td2)
    r += 1
    for ma, nhan, gt in (("[01]", "Tên đơn vị", dv.get("ten")), ("[02]", "Mã số thuế / mã số doanh nghiệp", dv.get("mst")),
                         ("[03]", "Mã đơn vị BHXH (nếu đã có)", dv.get("ma_dv")), ("[04]", "Loại hình đơn vị", dv.get("loai_hinh")),
                         ("[05]", "Ngành nghề kinh doanh chính", dv.get("nganh")), ("[06]", "Địa chỉ trụ sở chính", dv.get("dia_chi")),
                         ("[07]", "Địa chỉ liên hệ (nhận thông báo, kết quả)", dv.get("dia_chi_lh") or dv.get("dia_chi")),
                         ("[08]", "Số điện thoại", dv.get("tel")), ("[09]", "Thư điện tử (email)", dv.get("email")),
                         ("[10]", "Người đại diện theo pháp luật", dv.get("thu_truong")),
                         ("[11]", "Số định danh cá nhân của người đại diện", dv.get("dai_dien_cccd")),
                         ("[12]", "Phương thức đóng (hằng tháng / 03 tháng / 06 tháng)", dv.get("phuong_thuc")),
                         ("[13]", "Hình thức nhận kết quả", dv.get("nhan_kq"))):
        r = _tk_dong(ws, K, r, ma, nhan, chu(gt))
    r += 1
    ws.gop(r, 1, r, 8, "B. ĐIỀU CHỈNH THÔNG TIN", K.td2)
    r += 1
    r = _tk_dong(ws, K, r, "[14]", "Nội dung thay đổi, yêu cầu (cũ -> mới)", "")
    r = _tk_dong(ws, K, r, "", "", "")
    r = _tk_dong(ws, K, r, "[15]", "Hồ sơ kèm theo (nếu có)", "")
    r += 1
    ws.gop(r, 1, r + 1, 8, "Đơn vị cam kết những nội dung kê khai là đúng và chịu trách nhiệm trước pháp luật về những nội dung đã kê khai.",
           wb.kieu(nghieng=True, xuong=True))
    r += 3
    _chu_ky(ws, K, r, 1, 5, 4, dv, nguoi_lap=False)
    ws.gop(r + 8, 1, r + 9, 8, GHI_CHU_TK, wb.kieu(nghieng=True, co=9, xuong=True, mau="595959"))
    ws.in_trang(ngang=False, vua_rong=True, le=(0.6, 0.4, 0.5, 0.5))
    tep = os.path.join(ra, "TK3-TS.xlsx")
    wb.luu(tep)
    return tep, 1


# ====================================================================== bang tinh so phai dong (doi chieu C12-TS)
def lap_bang_dong(du, y, m, ra):
    dv = du.don_vi()
    d = _dt.date(y, m, 1)
    lcs, cc_lcs = luong_co_so(d)
    vung = (dv.get("vung") or "I").upper()
    lv, cc_lv = luong_toi_thieu_vung(d, vung)
    tl = du.ch["ty_le"]
    wb = SoExcel(font="Times New Roman", co=11)
    K = _K(wb)
    ws = wb.sheet("TinhDong", cot=[5, 9, 22, 12, 13, 13, 13, 11, 10, 10, 12, 12, 11, 11, 12, 13, 12, 12, 12, 11, 22])
    ts = wb.sheet("ThamSo", cot=[46, 16, 50])
    # ---- ThamSo
    ts.gop(1, 1, 1, 3, "THAM SỐ TÍNH ĐÓNG BHXH, BHYT, BHTN - THÁNG %02d/%d (sửa ô vàng, bảng tính tự tính lại)" % (m, y), K.td2)
    dong_ts = [("TS_LCS", "Mức lương cơ sở / mức tham chiếu (trần BHXH, BHYT = 20 lần)", lcs, cc_lcs),
               ("TS_LTTV", "Lương tối thiểu vùng %s (trần BHTN = 20 lần; mức đóng tối thiểu)" % vung, lv, cc_lv),
               ("TS_NLD_XH", "Người lao động - BHXH (%)", tl["nld_xh"], "Luật BHXH 2024"),
               ("TS_NLD_YT", "Người lao động - BHYT (%)", tl["nld_yt"], "Luật BHYT"),
               ("TS_NLD_TN", "Người lao động - BHTN (%)", tl["nld_tn"], "Luật Việc làm"),
               ("TS_DN_XH", "Doanh nghiệp - BHXH (%) = hưu trí 14 + ốm đau thai sản 3 + TNLĐ-BNN 0,5", tl["dn_xh"], "Luật BHXH 2024, NĐ 58/2020"),
               ("TS_DN_YT", "Doanh nghiệp - BHYT (%)", tl["dn_yt"], "Luật BHYT"),
               ("TS_DN_TN", "Doanh nghiệp - BHTN (%)", tl["dn_tn"], "Luật Việc làm"),
               ("TS_KPCD", "Kinh phí công đoàn (%) - nộp công đoàn, không nộp BHXH", tl["kpcd"], "Luật Công đoàn"),
               ("TS_SAI_SO", "Sai số cho phép khi so với bảng lương (đồng)", 1000, "")]
    for i, (ten, nhan, gt, cc) in enumerate(dong_ts, start=3):
        ts.o(i, 1, nhan, K.o)
        ts.o(i, 2, gt, K.vang)
        ts.o(i, 3, cc, K.o)
        wb.ten(ten, "ThamSo!$B$%d" % i)
    # ---- TinhDong
    nc = 21
    ws.gop(1, 1, 1, 10, chu(dv.get("ten")), K.dam)
    ws.gop(2, 1, 2, 10, "Mã đơn vị BHXH: " + chu(dv.get("ma_dv")) + "     MST: " + chu(dv.get("mst")), K.thuong)
    ws.gop(4, 1, 4, nc, "BẢNG TÍNH SỐ PHẢI ĐÓNG BHXH, BHYT, BHTN THÁNG %02d/%d" % (m, y), K.td)
    ws.gop(5, 1, 5, nc, "(Đối chiếu với Thông báo kết quả đóng BHXH, BHYT, BHTN - mẫu C12-TS của cơ quan BHXH)", K.nghieng)
    r0 = 7
    dau = ["STT", "Mã NV", "Họ và tên", "Mã số BHXH", "Lương đóng BH", "Lương tính BHXH, BHYT (≤ trần)", "Lương tính BHTN (≤ trần)",
           "NLĐ BHXH", "NLĐ BHYT", "NLĐ BHTN", "Cộng NLĐ", "DN BHXH", "DN BHYT", "DN BHTN", "Cộng DN", "Tổng phải đóng",
           "NLĐ đã trích trên bảng lương", "Chênh lệch NLĐ", "KPCĐ (nộp công đoàn)", "Nguồn lương", "Ghi chú"]
    for c, t in enumerate(dau, start=1):
        ws.o(r0, c, t, K.dau)
    ws.cao(r0, 48)
    r = r0 + 1
    r_dau = r
    stt = 0
    tong = {}
    for n in du.nv:
        if du.ho_so(n)["khong_bh"]:
            continue
        l, nguon, da = du.luong_bh(n, y, m)
        if not l:
            continue
        stt += 1
        ltx = min(l, 20 * lcs)
        ltn = min(l, 20 * lv)
        v = {}
        v["xh"] = lam_tron(ltx * tl["nld_xh"] / 100)
        v["yt"] = lam_tron(ltx * tl["nld_yt"] / 100)
        v["tn"] = lam_tron(ltn * tl["nld_tn"] / 100)
        v["dxh"] = lam_tron(ltx * tl["dn_xh"] / 100)
        v["dyt"] = lam_tron(ltx * tl["dn_yt"] / 100)
        v["dtn"] = lam_tron(ltn * tl["dn_tn"] / 100)
        R = lambda c: dia_chi(r, c)
        gc = []
        if l < lv:
            gc.append("Thấp hơn lương tối thiểu vùng")
        if l > 20 * lcs:
            gc.append("Vượt trần - tính theo trần")
        gt_cot = {5: l, 8: v["xh"], 9: v["yt"], 10: v["tn"], 11: v["xh"] + v["yt"] + v["tn"], 12: v["dxh"], 13: v["dyt"], 14: v["dtn"],
                  15: v["dxh"] + v["dyt"] + v["dtn"], 16: v["xh"] + v["yt"] + v["tn"] + v["dxh"] + v["dyt"] + v["dtn"],
                  17: da, 18: (da - (v["xh"] + v["yt"] + v["tn"])) if da else 0, 19: lam_tron(ltx * tl["kpcd"] / 100)}
        for c, x in gt_cot.items():
            tong[c] = tong.get(c, 0) + x
        ws.dong(r, 1, [(stt, K.o_giua), (n["sh"], K.o_giua), (n["ten"], K.o), (du.ho_so(n)["ma_bhxh"], K.o_giua), (l, K.o_so),
                       (CT("MIN(%s,20*TS_LCS)" % R(5), ltx), K.o_so), (CT("MIN(%s,20*TS_LTTV)" % R(5), ltn), K.o_so),
                       (CT("ROUND(%s*TS_NLD_XH/100,0)" % R(6), v["xh"]), K.o_so),
                       (CT("ROUND(%s*TS_NLD_YT/100,0)" % R(6), v["yt"]), K.o_so),
                       (CT("ROUND(%s*TS_NLD_TN/100,0)" % R(7), v["tn"]), K.o_so),
                       (CT("SUM(%s:%s)" % (R(8), R(10)), v["xh"] + v["yt"] + v["tn"]), K.o_so),
                       (CT("ROUND(%s*TS_DN_XH/100,0)" % R(6), v["dxh"]), K.o_so),
                       (CT("ROUND(%s*TS_DN_YT/100,0)" % R(6), v["dyt"]), K.o_so),
                       (CT("ROUND(%s*TS_DN_TN/100,0)" % R(7), v["dtn"]), K.o_so),
                       (CT("SUM(%s:%s)" % (R(12), R(14)), v["dxh"] + v["dyt"] + v["dtn"]), K.o_so),
                       (CT("%s+%s" % (R(11), R(15)), v["xh"] + v["yt"] + v["tn"] + v["dxh"] + v["dyt"] + v["dtn"]), K.o_so),
                       (da if da else None, K.o_so),
                       (CT("IF(%s=\"\",\"\",%s-%s)" % (R(17), R(17), R(11)), (da - (v["xh"] + v["yt"] + v["tn"])) if da else ""), K.o_so),
                       (CT("ROUND(%s*TS_KPCD/100,0)" % R(6), lam_tron(ltx * tl["kpcd"] / 100)), K.o_so),
                       (nguon, K.o), ("; ".join(gc), K.o)])
        r += 1
    r_cuoi = r - 1
    ws.o(r, 1, None, K.cong)
    ws.gop(r, 2, r, 4, "Cộng (%d người)" % stt, K.cong)
    for c in range(5, 20):
        if c in (6, 7):
            ws.o(r, c, None, K.cong)
            continue
        ws.o(r, c, CT("SUM(%s:%s)" % (dia_chi(r_dau, c), dia_chi(max(r_dau, r_cuoi), c)), tong.get(c, 0)) if stt else 0, K.cong_so)
    for c in (20, 21):
        ws.o(r, c, None, K.cong)
    r_tong = r
    if stt:
        ws.to_mau(r_dau, 18, r_cuoi, 18, "AND(%s<>\"\",ABS(%s)>TS_SAI_SO)" % (dia_chi(r_dau, 18), dia_chi(r_dau, 18)))
        ws.loc(r0, 1, r_cuoi, nc)
    r += 2
    ws.gop(r, 2, r, 8, "ĐỐI CHIẾU VỚI THÔNG BÁO C12-TS (nhập số trên C12-TS vào ô vàng)", K.dam)
    r += 1
    ws.gop(r, 2, r, 7, "Số phải đóng tháng này theo bảng tính (cột Tổng phải đóng)", K.o)
    ws.o(r, 8, CT("%s" % dia_chi(r_tong, 16), tong.get(16, 0)), K.o_so)
    r += 1
    ws.gop(r, 2, r, 7, "Số phải đóng trên Thông báo C12-TS (số phát sinh trong tháng)", K.o)
    ws.o(r, 8, None, K.vang)
    r += 1
    ws.gop(r, 2, r, 7, "Chênh lệch (bảng tính - C12-TS)", K.o)
    ws.o(r, 8, CT("IF(%s=\"\",\"\",%s-%s)" % (dia_chi(r - 1, 8), dia_chi(r - 2, 8), dia_chi(r - 1, 8)), ""), K.o_so)
    ws.to_mau(r, 8, r, 8, "AND(%s<>\"\",ABS(%s)>TS_SAI_SO)" % (dia_chi(r, 8), dia_chi(r, 8)))
    r += 2
    ws.gop(r, 1, r, nc, "Ghi chú: lương đóng BH lấy theo số BHXH 8% đã trích trên bảng lương tháng (hoặc mức nhập ở hồ sơ BHXH). "
           "Chênh lệch với C12-TS thường do: tăng / giảm chưa báo, truy thu, điều chỉnh lương, lãi chậm đóng.", K.nghieng_trai)
    ws.in_trang(ngang=True, vua_rong=True, lap_dong=(r0, r0), le=(0.3, 0.3, 0.5, 0.5))
    ws.dong_bang(r0 + 1, 4)
    tep = os.path.join(ra, "BangTinhDongBHXH_%04d%02d.xlsx" % (y, m))
    wb.luu(tep)
    return tep, stt


# ====================================================================== danh sach + kiem tra ho so
def lap_kiem_tra(du, y, m, ra):
    dv = du.don_vi()
    wb = SoExcel(font="Times New Roman", co=11)
    K = _K(wb)
    dau = ["STT", "Mã NV", "Họ và tên", "Ngày sinh", "Giới tính", "Số CCCD", "Mã số BHXH", "Số thẻ BHYT", "Chức vụ / chức danh",
           "Bộ phận / nơi làm việc", "Loại HĐ", "Ngày bắt đầu HĐ", "Ngày kết thúc HĐ", "Lương đóng BH tháng %02d" % m,
           "Nơi KCB ban đầu", "Trạng thái", "Cần bổ sung / kiểm tra"]
    ws = wb.sheet("KiemTra", cot=[5, 9, 22, 11, 7, 14, 12, 15, 16, 16, 10, 11, 11, 13, 18, 14, 46])
    ws.gop(1, 1, 1, 10, chu(dv.get("ten")) + " - MST " + chu(dv.get("mst")), K.dam)
    ws.gop(2, 1, 2, len(dau), "DANH SÁCH LAO ĐỘNG VÀ KIỂM TRA HỒ SƠ BHXH - THÁNG %02d/%d" % (m, y), K.td)
    r0 = 4
    for c, t in enumerate(dau, start=1):
        ws.o(r0, c, t, K.dau)
    ws.cao(r0, 32)
    r = r0 + 1
    so_loi = 0
    for i, n in enumerate(du.nv, start=1):
        hs = du.ho_so(n)
        loi = du.kiem_tra(n, y, m)
        tt = []
        if (n["nghi_viec"] or n["giam_ld"]) and n["ngay_nghi"]:
            tt.append("Nghỉ việc " + ngay_vn(n["ngay_nghi"]))
        if n["thai_san"]:
            tt.append("Thai sản")
        if hs["khong_bh"]:
            tt.append("Không BH")
        if not tt:
            tt.append("Đang làm")
        if loi and not hs["khong_bh"]:
            so_loi += 1
        hd = dict(LOAI_HD).get(hs["loai_hd"], "")
        ws.dong(r, 1, [(i, K.o_giua), (n["sh"], K.o_giua), (n["ten"], K.o), (n["ns"], K.o_ngay), (n["phai"], K.o_giua),
                       (n["cccd"], K.o_giua), (hs["ma_bhxh"], K.o_giua), (n["so_bhyt"], K.o_giua), (hs["chuc_danh"], K.o),
                       (hs["noi_lam_viec"], K.o), (hd, K.o), (hs["hd_tu"], K.o_ngay), (hs["hd_den"], K.o_ngay),
                       (du.luong_bh(n, y, m)[0] or None, K.o_so), (hs["noi_kcb"], K.o), ("; ".join(tt), K.o),
                       ("; ".join(loi), K.do if (loi and not hs["khong_bh"]) else K.o)])
        r += 1
    ws.gop(r + 1, 1, r + 1, len(dau), "%d người, %d người cần bổ sung / kiểm tra hồ sơ. Bổ sung ở cửa sổ Kết nối BHXH (thẻ Lao động) "
           "hoặc Danh sách nhân viên của phần mềm." % (len(du.nv), so_loi), K.nghieng_trai)
    if du.nv:
        ws.loc(r0, 1, r - 1, len(dau))
    ws.in_trang(ngang=True, vua_rong=True, lap_dong=(r0, r0))
    ws.dong_bang(r0 + 1, 4)
    tep = os.path.join(ra, "KiemTraHoSoBHXH_%04d%02d.xlsx" % (y, m))
    wb.luu(tep)
    return tep, so_loi


# ====================================================================== dien vao tep mau (cong / phan mem ke khai)
# khoa ten cot (bo dau) -> truong du lieu; thu tu: cum dai / dac thu truoc
GHEP_COT = [
    (("ho va ten", "ho ten", "hoten"), "ten"),
    (("ma so bhxh", "ma bhxh", "so so bhxh", "so bhxh", "ma so bao hiem"), "ma_bhxh"),
    (("ngay thang nam sinh", "ngay sinh", "nam sinh"), "ns"),
    (("gioi tinh", "nu x", "nu", "phai"), "phai"),
    (("so dinh danh", "cccd", "cmnd", "can cuoc", "ho chieu"), "cccd"),
    (("so the bhyt", "the bhyt"), "so_bhyt"),
    (("so hop dong", "so hdld", "so hd"), "so_hd"),
    (("dien thoai", "so dt"), "tel"),
    (("email", "thu dien tu"), "mail"),
    (("quoc tich",), "quoc_tich"),
    (("dan toc",), "dan_toc"),
    (("he so chenh lech",), "_trong"),
    (("phu cap chuc vu", "pc chuc vu"), "pc_cv"),
    (("tham nien vuot khung", "tn vuot khung", "vk"), "pc_tnvk"),
    (("tham nien nghe",), "pc_tnn"),
    (("phu cap luong", "khoan bo sung", "bo sung"), "pc_ls"),
    (("chuc vu cong viec", "chuc vu chuc danh nghe noi lam viec", "cap bac chuc vu"), "cv_noi"),
    (("noi lam viec", "dia chi noi lam viec"), "noi_lam_viec"),
    (("chuc vu", "chuc danh", "cong viec", "nghe nghiep", "vi tri"), "chuc_danh"),
    (("muc luong", "tien luong", "he so luong", "luong"), "luong"),
    (("khong xac dinh thoi han",), "hd_kxd"),
    (("xac dinh thoi han",), "hd_xd"),
    (("hd khac", "thu viec", "hop dong khac"), "hd_khac"),
    (("loai hop dong", "loai hd"), "loai_hd"),
    (("ngay ky", "ngay hieu luc", "co hieu luc", "ngay bat dau"), "hd_tu"),
    (("ngay ket thuc",), "hd_den"),
    (("tu thang", "tu ngay", "thang bat dau"), "tu"),
    (("den thang", "den ngay"), "den"),
    (("noi dang ky kcb", "noi kcb", "kham chua benh", "benh vien", "kcb"), "noi_kcb"),
    (("hinh thuc nhan",), "nhan_kq"),
    (("phuong an", "loai tang", "tang giam", "ma pa"), "pa"),
    (("dia chi",), "dia_chi"),
    (("ma nv", "ma nhan vien"), "sh"),
    (("ghi chu",), "ghi_chu"),
    (("stt", "tt", "so tt"), "stt"),
]


def ghep_cot(tieu_de):
    k = khoa(tieu_de)
    if not k:
        return ""
    for tu, truong in GHEP_COT:
        for t in tu:
            if k == t or (" " + t + " ") in (" " + k + " "):
                return truong
    return ""


def doc_mau(tep):
    """doc tep mau (.xlsx / .xls): (ten sheet, cac dong dau, dong tieu de, {cot: truong}). Dong tieu de = dong co nhieu cot ghep."""
    from tool_trich_xuat_so_phu import doc_excel
    bang = doc_excel(tep)
    an = getattr(bang, "an_sheet", set())
    for ten, dong in bang.items():
        if ten in an:
            continue
        tot, r_tot, gh_tot = 0, -1, {}
        for ri, row in enumerate(dong[:30]):
            gh = {}
            for ci, v in enumerate(row or []):
                if isinstance(v, str) and v.strip():
                    t = ghep_cot(v)
                    if t and t not in gh.values():
                        gh[ci] = t
            # dong tieu de 2 tang: cot con o dong duoi (Khong xac dinh thoi han...) thang tieu de nhom gop o phia tren
            if ri + 1 < len(dong):
                con = {}
                for ci, v in enumerate(dong[ri + 1] or []):
                    if isinstance(v, str) and v.strip() and not re.fullmatch(r"\(?\w{1,3}\)?", v.strip()):
                        t = ghep_cot(v)
                        if t:
                            con[ci] = t
                if con:
                    gh = {ci: t for ci, t in gh.items() if ci not in con and t not in con.values()}
                    gh.update(con)
            if len(gh) > tot:
                tot, r_tot, gh_tot = len(gh), ri, gh
        if tot >= 3:
            return ten, dong[:r_tot + 2], r_tot, gh_tot
    return None, [], -1, {}


def lap_theo_mau(du, tep_mau, y, m, ra):
    """dien danh sach phat sinh thang (khong co: nguoi dang dong BH) vao dung cot cua tep mau -> tep moi (khong sua tep mau)."""
    ten_sh, dau, r_td, gh = doc_mau(tep_mau)
    if not gh:
        raise ValueError("Không nhận ra dòng tiêu đề cột trong tệp mẫu (cần ít nhất 3 cột như Họ và tên, Mã số BHXH, Ngày sinh...).")
    ds = [e for e in du.phat_sinh(y, m) if e.get("chon", 1)]
    if not ds:
        ds = [{"sh": n["sh"], "pa": "", "tu": thang_vn(y, m), "den": "", "ghi_chu": ""} for n in du.nv if du.tham_gia(n, y, m)]
    wb = SoExcel(font="Times New Roman", co=11)
    K = _K(wb)
    nc = max(len(r or []) for r in dau) if dau else max(gh) + 1
    ws = wb.sheet(ten_sh or "DanhSach", cot=[14] * nc)
    # chep cac dong dau + dong tieu de (chi chu); dong ngay duoi la tieu de con / so thu tu cot (1), (2)... cung chep
    hang_dau = r_td + 1
    if r_td + 1 < len(dau):
        row = dau[r_td + 1] or []
        gt_dong = [v for v in row if v not in (None, "")]
        la_so = bool(gt_dong) and all(isinstance(v, (int, float)) or re.fullmatch(r"\(?[A-Za-z0-9]{1,3}\)?", str(v).strip()) for v in gt_dong)
        if la_so or any(isinstance(v, str) and ghep_cot(v) for v in row):
            hang_dau = r_td + 2
    for ri in range(hang_dau):
        for ci, v in enumerate(dau[ri] or []):
            if v not in (None, ""):
                ws.o(ri + 1, ci + 1, Chu(v) if isinstance(v, str) else v, K.dau if ri >= r_td else K.thuong)
    r_ra = hang_dau
    r = r_ra + 1
    for i, e in enumerate(ds, start=1):
        n = du.tim(e.get("sh"))
        if not n:
            continue
        hs = du.ho_so(n)
        nhom = du.nhom_pa(e.get("pa"))
        luong = so(e.get("luong_cu") if nhom == "G" else e.get("luong_moi")) or \
            du.luong_bh(n, *(thang_truoc(y, m) if nhom == "G" else (y, m)))[0] or du.luong_bh(n, y, m)[0] or hs["luong_bh"]
        gt = {"stt": i, "ten": n["ten"], "ma_bhxh": hs["ma_bhxh"], "ns": ngay_vn(n["ns"]), "phai": n["phai"], "cccd": n["cccd"],
              "so_bhyt": n["so_bhyt"], "tel": n["tel"], "mail": n["mail"], "quoc_tich": hs["quoc_tich"], "dan_toc": hs["dan_toc"],
              "noi_lam_viec": hs["noi_lam_viec"], "chuc_danh": hs["chuc_danh"], "pc_cv": hs["pc_cv"] or "",
              "cv_noi": "; ".join(x for x in (hs["chuc_danh"], hs["noi_lam_viec"]) if x),
              "pc_tnvk": hs["pc_tnvk"] or "", "pc_tnn": hs["pc_tnn"] or "", "pc_ls": (hs["pc_luong"] + hs["bo_sung"]) or "",
              "luong": luong or "", "hd_kxd": "x" if hs["loai_hd"] == "KXD" else "", "hd_xd": "x" if hs["loai_hd"] == "XD" else "",
              "hd_khac": "x" if hs["loai_hd"] == "KHAC" else "", "loai_hd": dict(LOAI_HD).get(hs["loai_hd"], ""),
              "so_hd": n["so_hd"], "hd_tu": ngay_vn(hs["hd_tu"]), "hd_den": ngay_vn(hs["hd_den"]), "tu": chu(e.get("tu")),
              "den": chu(e.get("den")), "noi_kcb": hs["noi_kcb"], "nhan_kq": hs["nhan_kq"], "pa": chu(e.get("pa")),
              "dia_chi": hs["dia_chi"], "sh": n["sh"], "ghi_chu": chu(e.get("ghi_chu")), "_trong": ""}
        for ci, truong in gh.items():
            v = gt.get(truong, "")
            if truong == "phai" and khoa(dau[r_td][ci] if ci < len(dau[r_td] or []) else "").startswith("nu"):
                v = "x" if n["phai"] == "Nữ" else ""
            ws.o(r, ci + 1, v if not isinstance(v, str) else Chu(v), K.o)
        r += 1
    goc = re.sub(r"[^A-Za-z0-9_-]+", "_", bo_dau(os.path.splitext(os.path.basename(tep_mau))[0]))[:30]
    tep = os.path.join(ra, "TheoMau_%s_%04d%02d.xlsx" % (goc or "Mau", y, m))
    wb.luu(tep)
    khong_ghep = [str(v) for row in dau[r_td:r_td + 1] for ci, v in enumerate(row or [])
                  if isinstance(v, str) and v.strip() and ci not in gh]
    return tep, r - r_ra - 1, khong_ghep


# ====================================================================== lap nhieu mau mot lan
def thu_muc_ra(goc_excels, mst, y, m):
    """<Excels>\\BHXH\\<MST>_<yyyymm>_<hhmmss> - thu muc MOI moi lan (khong ghi de tep cu)."""
    mst = re.sub(r"[^0-9A-Za-z-]+", "", mst or "") or "CTY"
    goc = os.path.join(goc_excels, "BHXH")
    ten = "%s_%04d%02d_%s" % (mst, y, m, _dt.datetime.now().strftime("%H%M%S"))
    p, i = os.path.join(goc, ten), 1
    while os.path.exists(p):
        i += 1
        p = os.path.join(goc, "%s_%d" % (ten, i))
    os.makedirs(p)
    return p


def lap(du, chon, y, m, goc_excels, ky_pli=None, ds_tk1=None, tep_mau=None, ghi_log=None, thu_kq=None):
    """chon: tap ma mau {"D02", "TK1", "TK3", "PLI", "M33", "DONG", "KT", "MAU"}. Tra ve (thu muc, [(ma, tep, so dong / loi)]).
    GD170: M33 = Mau so 33 bien dong lao dong; moi lan lap ghi ket-qua\\lao_dong_bien_dong.txt (thu_kq, mac dinh AIHoaDon\\ket-qua) cho lich VB6."""
    ra = thu_muc_ra(goc_excels, du.don_vi().get("mst"), y, m)
    kq = []

    def _chay(ma, ham, *ts):
        try:
            x = ham(*ts)
            kq.append((ma, x[0], x[1]) if len(x) == 2 else (ma, x[0], x[1], x[2]))
            if ghi_log:
                ghi_log("OK %s: %s" % (ma, os.path.basename(x[0]) if x[0] else "(không có người)"))
        except Exception as e:
            kq.append((ma, "", "LỖI: %s" % e))
            if ghi_log:
                ghi_log("LOI %s: %s" % (ma, e))

    if "D02" in chon:
        _chay("D02", lap_d02lt, du, y, m, ra)
    if "TK1" in chon:
        ds = ds_tk1
        if ds is None:
            ds = [e["sh"] for e in du.phat_sinh(y, m) if e.get("chon", 1) and e.get("pa") in ("TM", "TC", "TD")]
        _chay("TK1", lap_tk1ts, du, ds, y, m, ra)
    if "TK3" in chon:
        _chay("TK3", lap_tk3ts, du, ra)
    if "PLI" in chon:
        _chay("PLI", lap_01pli, du, y, ky_pli or (1 if m <= 6 else 2), ra)
    if "M33" in chon:
        _chay("M33", lap_mau33, du, y, m, ra)
    ghi_bien_dong(du, thu_kq)
    if "DONG" in chon:
        _chay("DONG", lap_bang_dong, du, y, m, ra)
    if "KT" in chon:
        _chay("KT", lap_kiem_tra, du, y, m, ra)
    if "MAU" in chon and tep_mau:
        _chay("MAU", lap_theo_mau, du, tep_mau, y, m, ra)
    try:
        with io.open(os.path.join(ra, "0_KET_QUA.txt"), "w", encoding="utf-8") as f:
            f.write("UNESCO XI + AI - Kết nối BHXH (%s) - tháng %02d/%d - lập lúc %s\r\n"
                    % (PHIEN_BAN, m, y, _dt.datetime.now().strftime("%d/%m/%Y %H:%M:%S")))
            for x in kq:
                f.write("%-5s %s  %s\r\n" % (x[0], os.path.basename(x[1]) if x[1] else "-", x[2]))
    except Exception:
        pass
    return ra, kq
