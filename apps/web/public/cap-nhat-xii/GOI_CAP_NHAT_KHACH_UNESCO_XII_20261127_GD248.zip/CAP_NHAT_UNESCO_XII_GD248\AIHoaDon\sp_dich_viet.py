# -*- coding: utf-8 -*-
"""GD83 - Dich noi dung so phu (dien giai ngan hang) sang TIENG VIET CO DAU - chay offline, khong thu vien ngoai.

  * Chu KHONG DAU (THANH TOAN TIEN HANG, Cty Doan Gia ck mua hang) -> them dau theo mo hinh ba tieng (trigram)
    hoc tu tu dien san (sp_tu_dien_viet.py: cum tu ngan hang / ke toan / ten dat / ten nguoi / ngan hang)
    + ngu lieu cua CHINH so sach khach (sp_ngu_lieu.txt do chuong trinh ghi: ten khach hang, ten nhan vien,
    dien giai chung tu da co dau) -> ten doi tac trong so sach duoc dat dau dung nhu danh muc.
  * TIENG ANH (Credit interest, Account maintenance fee, TRANSFER...) -> dich theo cum tu / tu (muc [ANH]).
  * GIU NGUYEN: so, ma (FT26131583485067, CKN, IBFT, TMCP, MST...), ky tu, dau cau; kieu chu hoa / thuong
    cua tung ky tu (THU PHI -> THU PHÍ, Thanh toan -> Thanh toán); dong da co dau (>= 50% so tieng) de nguyen.
  * Chi dung de HIEN THI / lam dien giai chung tu: noi dung goc cua ngan hang van giu (phan tich, chong trung
    van theo noi dung goc).
"""
import io
import math
import os
import re
import sys
import unicodedata

THU_MUC = os.path.dirname(os.path.abspath(__file__))

_NGUYEN_AM = ("aàáảãạăằắẳẵặâầấẩẫậeèéẻẽẹêềếểễệiìíỉĩịoòóỏõọôồốổỗộơờớởỡợuùúủũụưừứửữựyỳýỷỹỵ")


def _tao_bang_bo_dau():
    b = {}
    for c in _NGUYEN_AM + "đ":
        if c == "đ":
            g = "d"
        else:
            g = "".join(x for x in unicodedata.normalize("NFD", c) if unicodedata.category(x) != "Mn")
        b[c] = g
        b[c.upper()] = g.upper()
    return b


BO_DAU = _tao_bang_bo_dau()
CO_DAU = set(c for c, g in BO_DAU.items() if c != g)
_AM_TIET = re.compile(r"^(ngh|ng|nh|ch|gh|gi|kh|ph|qu|th|tr|[bcdghklmnprstvx])?[aeiouy]{1,3}(ng|nh|ch|[cmnpt])?$")
_TOKEN = re.compile(r"[^\W_]+", re.UNICODE)


GIA_TU = ("<so>", "<ma>")
# tu tieng Anh DON dich ca khi dong la tieng Viet (tu giao dich ngan hang); tu khac chi dich khi ca dong la tieng Anh
MANH = set("transfer transferred payment fee fees charge charges interest deposit withdrawal withdraw refund salary payroll "
           "remittance reversal disbursement repayment invoice invoices inv acc credit debit bonus allowance prepayment "
           "overpayment vat".split())


def _gia_tu(t):
    """tu thuan so -> <so>; chu khong phai tieng Viet (TNHH, SMS, GTGT, 1 chu cai) -> <ma>; lan chu va so -> "" (ngat);
       tieng Viet -> None"""
    if t.isdigit():
        return "<so>"
    if any(ch.isdigit() for ch in t):
        return ""
    if len(t) == 1 or not la_am_tiet(khong_dau(t.lower())):
        return "<ma>"
    return None


def khong_dau(s):
    return "".join(BO_DAU.get(c, c) for c in s)


def co_dau(s):
    return any(c in CO_DAU for c in s)


def la_am_tiet(tu_khong_dau):
    """tieng Viet hop le (dang khong dau, chu thuong)"""
    return bool(_AM_TIET.match(tu_khong_dau))


def _theo_kieu_chu(goc, moi):
    """giu kieu hoa / thuong cua tung ky tu goc (hai chuoi cung do dai: dau tieng Viet 1 - 1)"""
    if len(goc) != len(moi):
        return moi
    return "".join(m.upper() if g.isupper() else m for g, m in zip(goc, moi))


def _kieu_cum(goc, dich):
    """kieu chu cho ban dich tieng Anh: CA CUM HOA -> HOA; tu dau viet hoa chu dau (Payment) -> hoa chu dau; con lai thuong"""
    chu = [c for c in goc if c.isalpha()]
    if chu and all(c.isupper() for c in chu) and len(chu) > 1:
        return dich.upper()
    tu_dau = goc.split()[0] if goc.split() else ""
    if tu_dau[:1].isupper() and (len(tu_dau) == 1 or tu_dau[1:].islower()):
        return dich[:1].upper() + dich[1:]
    return dich


class MoHinh(object):
    LAM = 0.5         # noi suy: ngu canh chua gap chi bi giam toi da 2 lan (khong "phat" nang tu hay gap nhu dirichlet)
    K = 2.0
    TOI_DA_UNG_VIEN = 6

    def __init__(self):
        self.c1, self.c2, self.c3 = {}, {}, {}
        self.h1, self.h2 = {}, {}
        self.ung_vien = {}
        self.anh = {}           # tuple tu tieng Anh (thuong) -> ban dich
        self.anh_dai = 1
        self.tat = {}           # viet tat khong dau -> co dau (hd -> hđ)
        self.n = 0.0
        self._uv_cache = {}

    # ------------------------------------------------------------ nap
    def them_cum(self, text, w=1.0):
        """them mot cau / cum co dau: dem 1, 2, 3 tieng lien nhau. So thuan (12, 2026) = <so>, ma / chu khong phai
           tieng Viet (TNHH, GTGT, SMS) = <ma> - van noi ngu canh (quy 2, thue GTGT quy); ngat o dau cau / ma lan so."""
        text = unicodedata.normalize("NFC", text or "").lower()
        doan, truoc = [], None
        for m in _TOKEN.finditer(text):
            t = m.group(0)
            ngat = truoc is not None and text[truoc:m.start()].strip() != ""
            truoc = m.end()
            if ngat:
                self._them_doan(doan, w)
                doan = []
            gia = _gia_tu(t)
            if gia == "":
                self._them_doan(doan, w)
                doan = []
                continue
            doan.append(gia or t)
        self._them_doan(doan, w)

    def _them_doan(self, doan, w):
        if not doan:
            return
        if all(t in GIA_TU for t in doan):
            return
        for i, t in enumerate(doan):
            self.c1[t] = self.c1.get(t, 0) + w
            self.n += w
            if t not in GIA_TU:
                uv = self.ung_vien.setdefault(khong_dau(t), {})
                uv[t] = uv.get(t, 0) + w
            if i >= 1:
                k2 = (doan[i - 1], t)
                self.c2[k2] = self.c2.get(k2, 0) + w
                self.h1[doan[i - 1]] = self.h1.get(doan[i - 1], 0) + w
            if i >= 2:
                k3 = (doan[i - 2], doan[i - 1], t)
                self.c3[k3] = self.c3.get(k3, 0) + w
                k2 = (doan[i - 2], doan[i - 1])
                self.h2[k2] = self.h2.get(k2, 0) + w
        self._uv_cache = {}

    def nap_tu_dien(self, duong=None):
        """tu dien: tep duong (neu co) hoac chuoi DU_LIEU cua sp_tu_dien_viet.py (mac dinh - di kem goi tu dong cap nhat)"""
        if duong:
            with io.open(duong, "r", encoding="utf-8-sig") as f:
                van_ban = f.read()
        else:
            if THU_MUC not in sys.path:
                sys.path.insert(0, THU_MUC)
            import sp_tu_dien_viet
            van_ban = sp_tu_dien_viet.DU_LIEU
        self._nap_van_ban(van_ban)

    def _nap_van_ban(self, van_ban):
        muc, w = "VIET", 10.0
        for dong in van_ban.splitlines():
            s = dong.strip()
            if not s or s.startswith("#"):
                continue
            if s.startswith("[") and s.endswith("]"):
                muc = s[1:-1].strip().upper()
                continue
            if s.startswith("@"):
                try:
                    w = float(s[1:].split()[0])
                except ValueError:
                    pass
                continue
            if muc == "VIET":
                self.them_cum(s, w)
            elif "=>" in s:
                a, b = [x.strip() for x in s.split("=>", 1)]
                if muc == "ANH":
                    k = tuple(a.lower().split())
                    self.anh[k] = b
                    self.anh_dai = max(self.anh_dai, len(k))
                elif muc == "TAT":
                    self.tat[a.lower()] = b.lower()

    def nap_ngu_lieu(self, duong):
        """sp_ngu_lieu.txt (chuong trinh ghi): K|ten khach hang  N|ten nhan vien  D|dien giai  T|ten tai khoan.
           Chi hoc dong THAT SU co dau (>= 30% so tieng co dau) - dien giai chep nguyen noi dung ngan hang khong dau thi bo."""
        if not duong or not os.path.exists(duong):
            return 0
        n = 0
        trong_so = {"K": 6.0, "N": 6.0, "D": 3.0, "T": 1.0}
        with io.open(duong, "r", encoding="utf-8-sig", errors="replace") as f:
            for dong in f:
                dong = dong.rstrip("\r\n")
                if len(dong) < 3 or dong[1] != "|":
                    continue
                s = dong[2:]
                if any(ord(c) < 32 for c in s) or "�" in s:
                    continue
                if _ty_le_co_dau(s) < 0.3:
                    continue
                self.them_cum(s, trong_so.get(dong[0], 1.0))
                n += 1
        return n

    # ------------------------------------------------------------ xac suat
    def _p1(self, w):
        return (self.c1.get(w, 0) + 0.5) / (self.n + 0.5 * (len(self.c1) + 1))

    def _p2(self, v, w):
        h = self.h1.get(v, 0)
        if h <= 0:
            return self._p1(w)
        lam = self.LAM * h / (h + self.K)
        return lam * self.c2.get((v, w), 0) / h + (1 - lam) * self._p1(w)

    def _p3(self, u, v, w):
        h = self.h2.get((u, v), 0)
        if h <= 0:
            return self._p2(v, w)
        lam = self.LAM * h / (h + self.K)
        return lam * self.c3.get((u, v, w), 0) / h + (1 - lam) * self._p2(v, w)

    def ung_vien_cua(self, k):
        if k in self._uv_cache:
            return self._uv_cache[k]
        d = self.ung_vien.get(k)
        kq = sorted(d, key=lambda x: -d[x])[:self.TOI_DA_UNG_VIEN] if d else []
        self._uv_cache[k] = kq
        return kq

    def viterbi(self, ds):
        """ds: danh sach ung vien cho tung vi tri -> chuoi tot nhat (trigram)"""
        if not ds:
            return []
        if len(ds) == 1:
            return [max(ds[0], key=self._p1)]
        # trang thai (truoc, nay) -> (diem, duong)
        tt = {}
        for a in ds[0]:
            la = math.log(self._p1(a))
            for b in ds[1]:
                d = la + math.log(self._p2(a, b))
                tt[(a, b)] = (d, [a, b])
        for i in range(2, len(ds)):
            moi = {}
            for (u, v), (d, duong) in tt.items():
                for w in ds[i]:
                    d2 = d + math.log(self._p3(u, v, w))
                    k = (v, w)
                    if k not in moi or d2 > moi[k][0]:
                        moi[k] = (d2, duong + [w])
            tt = moi
        return max(tt.values(), key=lambda x: x[0])[1]


def _ty_le_co_dau(s):
    tong = co = 0
    for m in _TOKEN.finditer(unicodedata.normalize("NFC", s)):
        t = m.group(0)
        if any(ch.isdigit() for ch in t):
            continue
        k = khong_dau(t).lower()
        if len(k) < 2 or not la_am_tiet(k):
            continue
        tong += 1
        if co_dau(t):
            co += 1
    return (co / float(tong)) if tong else 0.0


_MH = {"mh": None, "ngu_lieu": None}


def mo_hinh(ngu_lieu=None, tu_dien=None):
    """mo hinh dung chung (nap 1 lan / ngu lieu). tu_dien: tep rieng (thu nghiem) - mac dinh sp_tu_dien_viet.py"""
    if _MH["mh"] is None or _MH["ngu_lieu"] != ngu_lieu:
        mh = MoHinh()
        mh.nap_tu_dien(tu_dien)          # thieu / hong tu dien -> bao loi (tool khong ghi ban dich rong - lan sau dich lai)
        if ngu_lieu:
            mh.nap_ngu_lieu(ngu_lieu)
        _MH["mh"], _MH["ngu_lieu"] = mh, ngu_lieu
    return _MH["mh"]


# ---------------------------------------------------------------- dich mot dong
def dich(text, mh=None):
    """noi dung ngan hang -> tieng Viet co dau (giu so / ma / ky tu / kieu chu). Loi -> tra lai nguyen van."""
    try:
        return _dich(text, mh or mo_hinh())
    except Exception:
        return text


def _dich(text, mh):
    if not text:
        return text
    s = unicodedata.normalize("NFC", str(text))
    if _ty_le_co_dau(s) >= 0.5:
        return s
    toks = [(m.start(), m.end(), m.group(0)) for m in _TOKEN.finditer(s)]
    if not toks:
        return s
    # 1) phan loai tung tu
    loai = []
    so_anh = so_viet = 0
    for (_, _, t) in toks:
        tl = t.lower()
        k = khong_dau(tl)
        if any(ch.isdigit() for ch in t):
            loai.append("CO_DINH")
        elif co_dau(t):
            loai.append("CO_DAU")
        elif k in mh.tat:
            loai.append("TAT")
        elif len(t) == 1:
            loai.append("CO_DINH")
        else:
            la_anh = (tl,) in mh.anh
            la_viet = bool(mh.ung_vien_cua(k))
            if la_anh and not la_viet:
                loai.append("ANH")
                so_anh += 1
            elif la_viet:
                loai.append("VIET_ANH" if la_anh else "VIET")
                if not la_anh:
                    so_viet += 1
            else:
                loai.append("ANH?" if _la_chu_anh(tl, mh) else "CO_DINH")
    che_do_anh = (so_anh >= 2 and so_anh >= so_viet) or (so_anh >= 1 and so_viet == 0)
    # 2) cum tieng Anh (dai nhat truoc) -> thay the
    thay = {}           # chi so tu dau -> (chi so tu cuoi, ban dich)
    i = 0
    while i < len(toks):
        if loai[i] in ("ANH", "VIET_ANH", "ANH?") or (loai[i] == "VIET" and che_do_anh):
            tim = None
            for dai in range(min(mh.anh_dai, len(toks) - i), 0, -1):
                j = i + dai - 1
                if any(loai[x] in ("CO_DINH", "CO_DAU", "TAT") for x in range(i, j + 1)):
                    continue
                if any(s[toks[x][1]:toks[x + 1][0]].strip(" -") != "" for x in range(i, j)):
                    continue
                k = tuple(toks[x][2].lower() for x in range(i, j + 1))
                if k not in mh.anh:
                    continue
                co_anh_rieng = any(loai[x] in ("ANH", "ANH?") for x in range(i, j + 1))
                if dai == 1 and not che_do_anh and k[0] not in MANH:
                    co_anh_rieng = False          # tu don khong phai tu giao dich (service, company...) trong dong tieng Viet: de nguyen
                if co_anh_rieng or che_do_anh:
                    tim = (j, mh.anh[k])
                    break
            if tim:
                thay[i] = tim
                for x in range(i, tim[0] + 1):
                    loai[x] = "DA_DICH"
                i = tim[0] + 1
                continue
        i += 1
    # 2b) "X fee" / "X charge" (tieng Anh dat phi sau) -> "phi X"
    for i0 in sorted(thay):
        if i0 not in thay:
            continue
        j0, d0 = thay[i0]
        i1 = j0 + 1
        if i1 in thay and thay[i1][1] == "phí" and s[toks[j0][1]:toks[i1][0]].strip() == "" and d0 and not d0.startswith("phí"):
            thay[i0] = (thay[i1][0], "phí " + d0[:1].lower() + d0[1:])
            del thay[i1]
    # 3) tieng Viet khong dau -> Viterbi theo tung doan lien tiep (ngat o ma, so, dau cau, tu da dich)
    ket = {}
    doan = []

    def xu_ly_doan():
        if not any(loai[x] in ("VIET", "VIET_ANH") for x in doan):
            del doan[:]
            return
        ds = []
        for x in doan:
            t = toks[x][2].lower()
            if loai[x] == "CO_DAU":
                ds.append([t])
            elif loai[x] in ("VIET", "VIET_ANH"):
                uv = mh.ung_vien_cua(khong_dau(t))
                ds.append(uv or [t])
            else:
                ds.append([_gia_tu(t) or "<ma>"])
        chon = mh.viterbi(ds)
        for x, c in zip(doan, chon):
            if loai[x] in ("VIET", "VIET_ANH"):
                ket[x] = _theo_kieu_chu(toks[x][2], c)
        del doan[:]

    for x in range(len(toks)):
        if loai[x] == "TAT":
            ket[x] = _theo_kieu_chu(toks[x][2], mh.tat[khong_dau(toks[x][2].lower())])
        noi = loai[x] in ("VIET", "VIET_ANH", "CO_DAU", "TAT", "ANH?") or (loai[x] == "CO_DINH" and _gia_tu(toks[x][2]) != "")
        if noi:
            if doan and s[toks[doan[-1]][1]:toks[x][0]].strip() != "":
                xu_ly_doan()
            doan.append(x)
        else:
            xu_ly_doan()
    xu_ly_doan()
    # 4) ghep lai: giu nguyen moi thu nam giua cac tu
    ra, vt, x = [], 0, 0
    while x < len(toks):
        a, b, t = toks[x]
        if x in thay:
            j, d = thay[x]
            b = toks[j][1]
            goc = s[a:b]
            ra.append(s[vt:a])
            if d:
                ra.append(_kieu_cum(goc, d))
            else:
                # tu bo di (for, of, the...): bo luon mot dau cach thua
                if ra and ra[-1].endswith(" ") and s[b:b + 1] == " ":
                    b += 1
            vt = b
            x = j + 1
            continue
        if x in ket:
            ra.append(s[vt:a])
            ra.append(ket[x])
            vt = b
        x += 1
    ra.append(s[vt:])
    kq = "".join(ra)
    kq = re.sub(r"  +", " ", kq).strip() if kq != s else kq
    return kq


def _la_chu_anh(tl, mh):
    return any(len(k) > 1 and tl in k for k in mh.anh)


def dich_nhieu(ds, ngu_lieu=None):
    mh = mo_hinh(ngu_lieu)
    return [dich(x, mh) for x in ds]


if __name__ == "__main__":
    import sys
    mh = mo_hinh(sys.argv[2] if len(sys.argv) > 2 else None)
    if len(sys.argv) > 1 and os.path.exists(sys.argv[1]):
        for d in io.open(sys.argv[1], encoding="utf-8"):
            d = d.rstrip("\n")
            print(d, "=>", dich(d, mh))
