# -*- coding: utf-8 -*-
"""
bhxh_unesco.py - GD128: cua so "KET NOI BHXH" (mo tu man hinh AI, the Bang luong & chung tu khac).

  1. Don vi        - ma don vi BHXH, co quan BHXH, nguoi ky... (luu rieng, khong ghi so ke toan)
  2. Lao dong      - danh sach nhan vien tu so + ho so BHXH bo sung (noi KCB, ngay HD, vi tri viec lam...), canh bao thieu
  3. Phat sinh     - tang / giam / dieu chinh cua thang: tu nhan biet tu bang luong + danh sach nhan vien, sua / them duoc
  4. Lap mau bieu  - D02-LT, TK1-TS, TK3-TS, 01/PLI, Bang tinh dong BHXH (doi chieu C12-TS), Kiem tra ho so, Dien tep mau
  5. Cong truc tuyen - mo Cong DVC BHXH Viet Nam, tra cuu ma so BHXH, Nen tang HDLD dien tu, Cong DVC quoc gia

Goi tu VB6 (ModHDDTBHXH.HDDT_BHXH_MoCong):  bhxh_unesco.py /json:"<bhxh_*.json>" /cty:"<ten>" /mst:"<mst>"
Chay khong giao dien (kiem thu):            bhxh_unesco.py /json:"..." /lap:D02,PLI,DONG /thang:9 /nam:2026 /ra:"<Excels>"
JSON tam co so CCCD / ma BHXH -> doc xong XOA NGAY. Nhat ky (nhat-ky-bhxh.txt) chi ghi so nguoi / ten tep, khong ghi CCCD.
Quy tac 17: KHONG luu mat khau, KHONG dien ma xac nhan, KHONG ky, KHONG nop ho so thay - chi mo trang cong cho nguoi dung.
Quy tac 18: KHONG ghi vao so ke toan - thong tin bo sung luu o <thu muc khach>\\bhxh\\ho_so_bhxh.json.
"""
import datetime as dt
import io
import os
import re
import sys
import traceback
import webbrowser

THU_MUC = os.path.dirname(os.path.abspath(__file__))
if THU_MUC not in sys.path:
    sys.path.insert(0, THU_MUC)

import bhxh_mau as B  # noqa: E402

TEP_LOG = os.path.join(THU_MUC, "nhat-ky-bhxh.txt")


def _gd167_ico(cs):
    """GD167: bieu tuong cua so = logo UNESCO (AIHoaDon/giao-dien/unesco.ico); thieu tep / loi -> bo qua"""
    try:
        p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "giao-dien", "unesco.ico")
        if os.path.exists(p):
            cs.iconbitmap(default=p)
    except Exception:
        pass


def ghi_log(s):
    try:
        with io.open(TEP_LOG, "a", encoding="utf-8") as f:
            f.write("%s %s\n" % (dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), s))
    except Exception:
        pass


# ---------------------------------------------------------------------------------------------- tham so dong lenh
def _tach_dong_lenh(s):
    ra, cur, trong = [], "", False
    for c in s:
        if c == '"':
            trong = not trong
        elif c.isspace() and not trong:
            if cur:
                ra.append(cur)
                cur = ""
        else:
            cur += c
    if cur:
        ra.append(cur)
    return ra


def doc_tham_so(argv):
    ds = []
    for a in argv:
        if a.startswith("/thamso:"):
            tep = a[len("/thamso:"):].strip('"')
            try:
                with io.open(tep, "r", encoding="utf-8-sig") as f:
                    ds.extend(_tach_dong_lenh(f.read()))
            except Exception as e:
                ghi_log("LOI doc tham so: %s" % e)
        else:
            ds.append(a)
    ts = {"json": "", "cty": "", "mst": "", "excels": "", "khach": "", "lap": "", "thang": "", "nam": "", "ra": "", "mau": "",
          "ky": "", "giu": False}
    for a in ds:
        for k in ("json", "cty", "mst", "excels", "khach", "lap", "thang", "nam", "ra", "mau", "ky"):
            if a.lower().startswith("/" + k + ":"):
                ts[k] = a[len(k) + 2:].strip('"')
        if a.lower() == "/giu":
            ts["giu"] = True
    return ts


def doc_so(v):
    """so nhap tay: 5.500.000 / 5,500,000 (phan nghin) -> 5500000; 0,4 / 2.34 (he so, %) -> so le. Sai -> -1."""
    t = re.sub(r"\s+", "", str(v or ""))
    if not t:
        return 0.0
    if re.fullmatch(r"\d{1,3}([.,]\d{3})+", t):
        return float(re.sub(r"[.,]", "", t))
    if t.count(",") + t.count(".") == 1:
        return float(t.replace(",", ".")) if re.fullmatch(r"\d+[.,]\d+", t) else -1.0
    return float(t) if re.fullmatch(r"\d+", t) else -1.0


def duong_ho_so(khach, mst):
    if khach and os.path.isdir(khach):
        return os.path.join(khach, "bhxh", "ho_so_bhxh.json")
    mst = re.sub(r"[^0-9A-Za-z-]+", "", mst or "") or "CTY"
    return os.path.join(THU_MUC, "bhxh", "ho_so_" + mst + ".json")


def thu_muc_excels(ts, dl):
    for p in (ts.get("ra"), ts.get("excels"), dl.get("excels")):
        if p:
            return p
    return os.path.join(os.path.dirname(THU_MUC), "Excels")


def mo_tep(p):
    try:
        if hasattr(os, "startfile"):
            os.startfile(p)                      # noqa - chi co tren Windows
        else:
            webbrowser.open("file://" + p)
        return True
    except Exception as e:
        ghi_log("LOI mo tep: %s" % e)
        return False


def nap(ts):
    """doc JSON cua VB (roi xoa), tao DuLieu. Tra ve (du, thu muc Excels)."""
    tep = ts["json"]
    try:
        dl = B.doc_json(tep)
    finally:
        if not ts.get("giu"):
            try:
                os.remove(tep)                   # co CCCD / ma BHXH: khong de lai tren may (ca khi doc loi)
            except Exception:
                pass
    mst = (dl.get("cty") or {}).get("mst") or ts.get("mst")
    hs = B.HoSo(duong_ho_so(ts.get("khach") or dl.get("khach"), mst))
    du = B.DuLieu(dl, hs)
    if dl.get("loi_doc"):
        ghi_log("JSON co loi doc: %s" % dl.get("loi_doc"))
    ghi_log("Mo du lieu: %d nhan vien, %d thang co bang luong" % (len(du.nv), len(du.cac_thang())))
    return du, thu_muc_excels(ts, dl)


def ky_mac_dinh(du, ts):
    """thang / nam mac dinh: tham so > thang moi nhat co bang luong > thang hien tai."""
    try:
        if ts.get("thang") and ts.get("nam"):
            return int(ts["nam"]), int(ts["thang"])
    except ValueError:
        pass
    ds = du.cac_thang()
    hn = dt.date.today()
    if (hn.year, hn.month) in ds:
        return hn.year, hn.month
    truoc = [t for t in ds if t <= (hn.year, hn.month)]
    if truoc:
        return truoc[-1]                       # bang luong tinh truoc cho cac thang sau: lay thang gan nhat <= hom nay
    if ds:
        return ds[-1]
    return hn.year, hn.month


def chay_khong_giao_dien(ts):
    du, excels = nap(ts)
    y, m = ky_mac_dinh(du, ts)
    chon = set(x.strip().upper() for x in ts["lap"].split(",") if x.strip())
    if "ALL" in chon:
        chon = {"D02", "TK1", "TK3", "PLI", "M33", "DONG", "KT"}
    ky = int(ts["ky"]) if ts.get("ky") in ("1", "2") else None
    ra, kq = B.lap(du, chon, y, m, excels, ky_pli=ky, tep_mau=ts.get("mau") or None, ghi_log=ghi_log)
    loi = [x for x in kq if not x[1]]
    print(("OK " if not loi else "LOI ") + ra)
    for x in kq:
        print("%s\t%s\t%s" % (x[0], x[1], x[2]))
    return 0 if not loi else 1


# ---------------------------------------------------------------------------------------------- giao dien
MAU = {"nen": "#f4f7fc", "the": "#ffffff", "vien": "#d6e2f0", "chu": "#22314f", "nhat": "#5f6d84", "xanh_dam": "#0d2f7c",
       "xanh": "#1667d9", "la": "#13924b", "cam": "#f08a00", "do": "#c62828", "banner": "#0a3f91", "banner2": "#03214f",
       "nen_do": "#fde7e7", "nen_vang": "#fff6d6", "nen_la": "#e5f6ea"}

HUONG_DAN = (
    "KẾT NỐI BHXH - cách dùng\n\n"
    "1. Thẻ Đơn vị: nhập Mã đơn vị BHXH, cơ quan BHXH quản lý, người lập biểu, vùng lương tối thiểu - bấm Lưu (lưu một lần cho sổ này).\n"
    "2. Thẻ Lao động: dòng có chữ đỏ là hồ sơ còn thiếu (mã số BHXH, CCCD, nơi KCB, ngày bắt đầu HĐ...). Bấm đúp một dòng để bổ sung. "
    "Thông tin bổ sung lưu riêng cho cửa sổ này, KHÔNG sửa danh sách nhân viên của phần mềm.\n"
    "3. Thẻ Phát sinh tháng: phần mềm tự nhận biết tăng mới, nghỉ việc, thai sản, đi làm lại, đổi lương đóng BH từ bảng lương "
    "và danh sách nhân viên. Sửa / thêm / bỏ chọn rồi bấm Lưu phát sinh.\n"
    "4. Thẻ Lập mẫu biểu: tích các mẫu cần lập, bấm Lập mẫu biểu. Tệp Excel (chữ Unicode) nằm trong thư mục Excels\\BHXH\\<MST>_<tháng>_<giờ> - "
    "mỗi lần một thư mục mới, không ghi đè tệp cũ.\n"
    "5. Thẻ Cổng BHXH trực tuyến: mở Cổng dịch vụ công BHXH, tự đăng nhập (tài khoản đơn vị / VNeID, tự nhập mã xác nhận), "
    "kê khai hoặc tải tệp lên, tự ký số và nộp. Tra cứu C12-TS rồi đối chiếu bằng Bảng tính đóng BHXH.\n\n"
    "Phần mềm KHÔNG lưu mật khẩu, KHÔNG điền mã xác nhận, KHÔNG ký, KHÔNG nộp hồ sơ thay bạn.\n"
    "Mẫu D02-LT theo QĐ 366/QĐ-BHXH (29/4/2026); 01/PLI theo Phụ lục I NĐ 145/2020 (từ 01/7/2026 báo cáo qua Nền tảng HĐLĐ điện tử). "
    "TK1-TS / TK3-TS: đối chiếu mẫu cơ quan BHXH trước khi ký.")


class CuaSo(object):
    def __init__(self, root, du, excels, ts):
        import tkinter as tk
        from tkinter import ttk, messagebox, filedialog
        from tkinter import font as tkfont
        self.tk, self.ttk, self.mb, self.fd = tk, ttk, messagebox, filedialog
        self.root, self.du, self.excels, self.ts = root, du, excels, ts
        self.y, self.m = ky_mac_dinh(du, ts)
        self.thu_muc_cuoi = ""
        self.tep_cuoi = ""
        self.tep_mau = ""
        ho = dict((f.lower(), f) for f in tkfont.families())
        fam = next((ho[f.lower()] for f in ("Segoe UI", "Tahoma", "Arial", "DejaVu Sans") if f.lower() in ho), "TkDefaultFont")
        self.F = lambda co=10, dam=False: (fam, co, "bold" if dam else "normal")
        root.title("UNESCO XI + AI - Kết nối BHXH")
        sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
        w, h = min(1240, sw - 40), min(800, sh - 110)
        root.geometry("%dx%d+%d+%d" % (w, h, max(0, (sw - w) // 2), max(0, (sh - h - 60) // 2)))
        root.minsize(960, 600)
        root.configure(bg=MAU["nen"])
        st = ttk.Style(root)
        try:
            st.theme_use("clam")
        except Exception:
            pass
        st.configure(".", font=self.F(10))
        st.configure("Treeview", rowheight=24, font=self.F(10))
        st.configure("Treeview.Heading", font=self.F(9, True), background="#e6eef9")
        st.configure("TNotebook.Tab", font=self.F(10, True), padding=(14, 6))
        st.configure("Nut.TButton", font=self.F(10, True), padding=(12, 5))
        st.configure("Chinh.TButton", font=self.F(11, True), padding=(16, 8), foreground="#ffffff", background=MAU["la"])
        st.map("Chinh.TButton", background=[("active", "#0e7a3d")])
        self._banner()
        self._thanh_ky()
        self.nb = ttk.Notebook(root)
        self.nb.pack(fill="both", expand=True, padx=10, pady=(4, 0))
        self._the_don_vi()
        self._the_lao_dong()
        self._the_phat_sinh()
        self._the_lap()
        self._the_cong()
        self.trang_thai = tk.Label(root, text="", anchor="w", font=self.F(9), bg=MAU["nen"], fg=MAU["nhat"])
        self.trang_thai.pack(fill="x", padx=12, pady=(2, 6))
        root.bind("<Escape>", lambda e: root.destroy())
        root.bind("<F1>", lambda e: self.huong_dan())
        self.lam_moi()
        if du.hs.loi:
            self.mb.showwarning("Kết nối BHXH", du.hs.loi)
        if not du.don_vi().get("ma_dv"):
            self.nb.select(0)
            self.bao("Chưa có Mã đơn vị BHXH - nhập ở thẻ Đơn vị rồi bấm Lưu.")
        else:
            self.nb.select(2)

    # ------------------------------------------------------------------ chung
    def bao(self, s, loi=False):
        self.trang_thai.configure(text=s, fg=MAU["do"] if loi else MAU["nhat"])

    def huong_dan(self):
        self.mb.showinfo("Kết nối BHXH - Hướng dẫn", HUONG_DAN)

    def _the(self, cha):
        f = self.tk.Frame(cha, bg=MAU["the"], highlightbackground=MAU["vien"], highlightthickness=1)
        return f

    def _banner(self):
        tk = self.tk
        b = tk.Frame(self.root, bg=MAU["banner"], height=64)
        b.pack(fill="x")
        trai = tk.Frame(b, bg=MAU["banner"])
        trai.pack(side="left", padx=14, pady=8)
        tk.Label(trai, text="KẾT NỐI BHXH", font=self.F(16, True), fg="#ffffff", bg=MAU["banner"]).pack(anchor="w")
        tk.Label(trai, text="UNESCO XI + AI  ·  Lập mẫu biểu Lao động - BHXH  ·  Mở cổng BHXH trực tuyến", font=self.F(9),
                 fg="#c7d9f5", bg=MAU["banner"]).pack(anchor="w")
        phai = tk.Frame(b, bg=MAU["banner2"])
        phai.pack(side="right", padx=12, pady=8)
        dv = self.du.don_vi()
        self.lbl_cty = tk.Label(phai, text=dv.get("ten") or self.ts.get("cty") or "", font=self.F(10, True), fg="#ffffff",
                                bg=MAU["banner2"], wraplength=460, justify="left")
        self.lbl_cty.pack(anchor="w", padx=10, pady=(4, 0))
        self.lbl_mst = tk.Label(phai, text="", font=self.F(9), fg="#cfe0fb", bg=MAU["banner2"])
        self.lbl_mst.pack(anchor="w", padx=10, pady=(0, 4))
        tk.Button(b, text="?  Hướng dẫn", command=self.huong_dan, font=self.F(10, True), bg=MAU["cam"], fg="#ffffff",
                  relief="flat", padx=12, cursor="hand2").pack(side="right", padx=6)

    def _cap_nhat_banner(self):
        dv = self.du.don_vi()
        self.lbl_cty.configure(text=dv.get("ten") or "")
        self.lbl_mst.configure(text="MST: %s     Mã đơn vị BHXH: %s" % (dv.get("mst") or "-", dv.get("ma_dv") or "(chưa nhập)"))

    def _thanh_ky(self):
        tk, ttk = self.tk, self.ttk
        f = tk.Frame(self.root, bg=MAU["nen"])
        f.pack(fill="x", padx=10, pady=(8, 2))
        tk.Label(f, text="Kỳ làm việc:  tháng", font=self.F(10, True), bg=MAU["nen"], fg=MAU["chu"]).pack(side="left")
        self.cb_thang = ttk.Combobox(f, values=["%02d" % i for i in range(1, 13)], width=4, state="readonly")
        self.cb_thang.set("%02d" % self.m)
        self.cb_thang.pack(side="left", padx=4)
        tk.Label(f, text="năm", font=self.F(10, True), bg=MAU["nen"], fg=MAU["chu"]).pack(side="left")
        nam = sorted(set([self.du.nam_tc - 1, self.du.nam_tc, self.du.nam_tc + 1] + [y for y, _ in self.du.cac_thang()]))
        self.cb_nam = ttk.Combobox(f, values=[str(x) for x in nam], width=6, state="readonly")
        self.cb_nam.set(str(self.y))
        self.cb_nam.pack(side="left", padx=4)
        self.cb_thang.bind("<<ComboboxSelected>>", lambda e: self.doi_ky())
        self.cb_nam.bind("<<ComboboxSelected>>", lambda e: self.doi_ky())
        self.lbl_ky = tk.Label(f, text="", font=self.F(9), bg=MAU["nen"], fg=MAU["nhat"])
        self.lbl_ky.pack(side="left", padx=12)

    def doi_ky(self):
        self.y, self.m = int(self.cb_nam.get()), int(self.cb_thang.get())
        self.lam_moi()

    def lam_moi(self):
        self._cap_nhat_banner()
        co = self.du.co_so_lieu(self.y, self.m)
        self.lbl_ky.configure(text=("Tháng %02d/%d có bảng lương trong sổ." % (self.m, self.y)) if co else
                              ("Tháng %02d/%d CHƯA có bảng lương trong sổ - phát sinh chỉ lấy theo danh sách nhân viên." % (self.m, self.y)))
        self.nap_lao_dong()
        self.nap_phat_sinh()

    # ------------------------------------------------------------------ 1. don vi
    DV_O = [("ten", "Tên đơn vị"), ("mst", "Mã số thuế / mã số DN"), ("ma_dv", "Mã đơn vị BHXH"),
            ("co_quan_bhxh", "Cơ quan BHXH quản lý (Kính gửi)"), ("dia_chi", "Địa chỉ trụ sở"), ("dia_chi_lh", "Địa chỉ liên hệ"),
            ("tel", "Điện thoại"), ("email", "Email"), ("loai_hinh", "Loại hình doanh nghiệp"), ("nganh", "Ngành nghề kinh doanh chính"),
            ("thu_truong", "Thủ trưởng / người đại diện"), ("dai_dien_cccd", "Số định danh người đại diện"),
            ("nguoi_lap", "Người lập biểu"), ("kinh_gui_pli", "Kính gửi (báo cáo 01/PLI)"), ("noi_kcb", "Nơi KCB mặc định (người mới)"),
            ("nhan_kq", "Hình thức nhận kết quả"), ("phuong_thuc", "Phương thức đóng"), ("vung", "Vùng lương tối thiểu (I, II, III, IV)")]

    def _the_don_vi(self):
        tk, ttk = self.tk, self.ttk
        f = tk.Frame(self.nb, bg=MAU["nen"])
        self.nb.add(f, text=" 1. Đơn vị ")
        k = self._the(f)
        k.pack(fill="both", expand=True, padx=8, pady=8)
        tk.Label(k, text="THÔNG TIN ĐƠN VỊ THAM GIA BHXH", font=self.F(11, True), bg=MAU["the"], fg=MAU["xanh_dam"]).grid(
            row=0, column=0, columnspan=4, sticky="w", padx=12, pady=(10, 6))
        self.o_dv = {}
        dv = self.du.don_vi()
        for i, (ma, nhan) in enumerate(self.DV_O):
            r, c = 1 + i // 2, (i % 2) * 2
            tk.Label(k, text=nhan, font=self.F(10), bg=MAU["the"], fg=MAU["chu"], anchor="w").grid(row=r, column=c, sticky="w", padx=(12, 6), pady=4)
            if ma == "nhan_kq":
                o = ttk.Combobox(k, values=["Điện tử", "Bản giấy", "Điện tử và bản giấy"], width=42)
            elif ma == "phuong_thuc":
                o = ttk.Combobox(k, values=["Hằng tháng", "03 tháng một lần", "06 tháng một lần"], width=42)
            elif ma == "vung":
                o = ttk.Combobox(k, values=["I", "II", "III", "IV"], width=42, state="readonly")
            else:
                o = ttk.Entry(k, width=46)
            o.grid(row=r, column=c + 1, sticky="we", padx=(0, 16), pady=4)
            v = dv.get(ma) or ""
            if isinstance(o, ttk.Combobox) and str(o.cget("state")) == "readonly":
                o.set(v or "I")
            else:
                o.insert(0, v)
            self.o_dv[ma] = o
        k.grid_columnconfigure(1, weight=1)
        k.grid_columnconfigure(3, weight=1)
        n = 2 + len(self.DV_O) // 2
        tk.Label(k, text="Tên, MST, địa chỉ, điện thoại lấy sẵn từ sổ kế toán; sửa ở đây chỉ dùng cho mẫu BHXH (lưu riêng, không sửa sổ).",
                 font=self.F(9), bg=MAU["the"], fg=MAU["nhat"]).grid(row=n, column=0, columnspan=4, sticky="w", padx=12, pady=(8, 4))
        ttk.Button(k, text="Lưu thông tin đơn vị", style="Nut.TButton", command=self.luu_don_vi).grid(
            row=n + 1, column=0, columnspan=2, sticky="w", padx=12, pady=(4, 12))

    def luu_don_vi(self):
        dv = {}
        goc = B.DuLieu(self.du.dl, B.HoSo("")).don_vi()
        for ma, o in self.o_dv.items():
            v = B.chu(o.get())
            if v and v != B.chu(goc.get(ma)):
                dv[ma] = v
        if dv.get("vung") and dv["vung"] not in ("I", "II", "III", "IV"):
            self.mb.showwarning("Kết nối BHXH", "Vùng lương tối thiểu chỉ nhận I, II, III hoặc IV.")
            return
        if dv.get("ma_dv") and not re.fullmatch(r"[A-Za-z0-9]{3,12}", dv["ma_dv"]):
            if not self.mb.askyesno("Kết nối BHXH", "Mã đơn vị BHXH thường gồm chữ và số (ví dụ TZ1234A). Vẫn lưu?"):
                return
        self.du.hs.d["don_vi"] = dv
        try:
            self.du.hs.luu()
            ghi_log("Luu thong tin don vi (%d o)" % len(dv))
            self.bao("Đã lưu thông tin đơn vị.")
        except Exception as e:
            self.bao("Không lưu được: %s" % e, True)
        self.lam_moi()

    # ------------------------------------------------------------------ 2. lao dong
    LD_COT = [("sh", "Mã NV", 70), ("ten", "Họ và tên", 170), ("tt", "Trạng thái", 86), ("loi", "Cần bổ sung", 250),
              ("ns", "Ngày sinh", 82), ("phai", "Giới", 44), ("cccd", "CCCD", 100), ("ma_bhxh", "Mã số BHXH", 92),
              ("cv", "Chức vụ", 110), ("bp", "Bộ phận", 100), ("luong", "Lương đóng BH", 100), ("hd", "Loại HĐ", 64),
              ("hd_tu", "Ngày HĐ", 82), ("kcb", "Nơi KCB", 120)]

    def _the_lao_dong(self):
        tk, ttk = self.tk, self.ttk
        f = tk.Frame(self.nb, bg=MAU["nen"])
        self.nb.add(f, text=" 2. Lao động ")
        tren = tk.Frame(f, bg=MAU["nen"])
        tren.pack(fill="x", padx=8, pady=(8, 4))
        tk.Label(tren, text="Lọc:", font=self.F(10), bg=MAU["nen"]).pack(side="left")
        self.cb_loc = ttk.Combobox(tren, values=["Tất cả", "Cần bổ sung hồ sơ", "Đang đóng BH tháng này", "Không tham gia BH",
                                                 "Đã nghỉ việc"], width=24, state="readonly")
        self.cb_loc.set("Tất cả")
        self.cb_loc.pack(side="left", padx=6)
        self.cb_loc.bind("<<ComboboxSelected>>", lambda e: self.nap_lao_dong())
        ttk.Button(tren, text="Bổ sung hồ sơ BHXH...", style="Nut.TButton", command=self.sua_nv).pack(side="left", padx=6)
        ttk.Button(tren, text="Áp nơi KCB cho người chưa có...", command=self.ap_kcb).pack(side="left", padx=6)
        self.lbl_ld = tk.Label(tren, text="", font=self.F(9), bg=MAU["nen"], fg=MAU["nhat"])
        self.lbl_ld.pack(side="left", padx=10)
        khung = tk.Frame(f, bg=MAU["nen"])
        khung.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self.tv_ld = ttk.Treeview(khung, columns=[c for c, _, _ in self.LD_COT], show="headings", selectmode="extended")
        for c, t, w in self.LD_COT:
            self.tv_ld.heading(c, text=t)
            self.tv_ld.column(c, width=w, stretch=(c in ("ten", "loi")), anchor="center" if c in ("sh", "ns", "phai", "hd", "hd_tu") else "w")
        self.tv_ld.column("luong", anchor="e")
        self.tv_ld.tag_configure("loi", foreground=MAU["do"])
        self.tv_ld.tag_configure("nghi", foreground="#8a8a8a")
        sy = ttk.Scrollbar(khung, orient="vertical", command=self.tv_ld.yview)
        sx = ttk.Scrollbar(khung, orient="horizontal", command=self.tv_ld.xview)
        self.tv_ld.configure(yscrollcommand=sy.set, xscrollcommand=sx.set)
        self.tv_ld.grid(row=0, column=0, sticky="nsew")
        sy.grid(row=0, column=1, sticky="ns")
        sx.grid(row=1, column=0, sticky="we")
        khung.grid_rowconfigure(0, weight=1)
        khung.grid_columnconfigure(0, weight=1)
        self.tv_ld.bind("<Double-1>", lambda e: self.sua_nv())

    def nap_lao_dong(self):
        tv = self.tv_ld
        tv.delete(*tv.get_children())
        loc = self.cb_loc.get()
        dem = so_loi = 0
        for n in self.du.nv:
            hs = self.du.ho_so(n)
            loi = self.du.kiem_tra(n, self.y, self.m)
            nghi = (n["nghi_viec"] or n["giam_ld"]) and n["ngay_nghi"] and n["ngay_nghi"] < dt.date(self.y, self.m, 1)
            luong = self.du.luong_bh(n, self.y, self.m)[0]
            if loc == "Cần bổ sung hồ sơ" and (not loi or hs["khong_bh"] or nghi):
                continue
            if loc == "Đang đóng BH tháng này" and not luong:
                continue
            if loc == "Không tham gia BH" and not hs["khong_bh"]:
                continue
            if loc == "Đã nghỉ việc" and not nghi:
                continue
            tt = "Nghỉ việc" if nghi else ("Không BH" if hs["khong_bh"] else ("Thai sản" if n["thai_san"] else "Đang làm"))
            if loi and not hs["khong_bh"] and not nghi:
                so_loi += 1
            dem += 1
            tv.insert("", "end", iid=str(n["ma"]), values=(
                n["sh"], n["ten"], tt, "; ".join(loi) if not nghi else "", B.ngay_vn(n["ns"]), n["phai"], B.che_so(n["cccd"]),
                hs["ma_bhxh"], hs["chuc_danh"], hs["noi_lam_viec"], "{:,.0f}".format(luong) if luong else "",
                {"KXD": "KXĐ", "XD": "XĐ", "KHAC": "Khác"}.get(hs["loai_hd"], ""), B.ngay_vn(hs["hd_tu"]), hs["noi_kcb"]),
                tags=(("nghi",) if nghi else (("loi",) if (loi and not hs["khong_bh"]) else ())))
        goi_y = (" · Thiếu CCCD / mã BHXH nhiều người: dùng nút Hồ sơ NV từ DS BHXH... (màn hình AI, thẻ Lương & BHXH) để điền "
                 "từ danh sách của cơ quan BHXH") if so_loi >= 3 else ""
        self.lbl_ld.configure(text="%d người đang hiện · %d người cần bổ sung hồ sơ (chữ đỏ) · CCCD chỉ hiện 4 số cuối%s" % (dem, so_loi, goi_y))

    def ap_kcb(self):
        from tkinter import simpledialog
        v = simpledialog.askstring("Kết nối BHXH", "Nơi đăng ký KCB ban đầu (ví dụ: 79-024 Bệnh viện Quận X) áp cho mọi người\n"
                                   "đang đóng BH mà CHƯA có nơi KCB:", parent=self.root)
        v = B.chu(v)
        if not v:
            return
        dem = 0
        for n in self.du.nv:
            hs = self.du.ho_so(n)
            if hs["noi_kcb"] or hs["khong_bh"]:
                continue
            h = dict(self.du.hs.nv(n["sh"]))
            h["noi_kcb"] = v
            self.du.hs.dat_nv(n["sh"], h)
            dem += 1
        if dem:
            self.du.hs.luu()
            ghi_log("Ap noi KCB cho %d nguoi" % dem)
        self.bao("Đã áp nơi KCB cho %d người." % dem)
        self.nap_lao_dong()

    NV_O = [("ma_bhxh", "Mã số BHXH (10 số)"), ("noi_kcb", "Nơi đăng ký KCB ban đầu"), ("nhan_kq", "Hình thức nhận kết quả"),
            ("vi_tri", "Vị trí việc làm (01/PLI)"), ("chuc_danh", "Chức vụ, chức danh nghề"), ("noi_lam_viec", "Nơi làm việc / bộ phận"),
            ("loai_hd", "Loại hợp đồng lao động"), ("hd_tu", "Ngày bắt đầu HĐLĐ (dd/mm/yyyy)"), ("hd_den", "Ngày kết thúc HĐLĐ"),
            ("luong_bh", "Lương đóng BH (trống = theo bảng lương)"), ("pc_cv", "Phụ cấp chức vụ"), ("pc_tnvk", "Thâm niên vượt khung (%)"),
            ("pc_tnn", "Thâm niên nghề (%)"), ("pc_luong", "Phụ cấp lương"), ("bo_sung", "Các khoản bổ sung"),
            ("nn_tu", "Nghề nặng nhọc độc hại - từ ngày"), ("nn_den", "Nghề nặng nhọc độc hại - đến ngày"),
            ("bat_dau_dong", "Bắt đầu đóng BHXH tại đơn vị (mm/yyyy)"), ("dan_toc", "Dân tộc"), ("quoc_tich", "Quốc tịch"),
            ("dia_chi", "Địa chỉ liên hệ"), ("ghi_chu", "Ghi chú")]

    def sua_nv(self):
        tk, ttk = self.tk, self.ttk
        sel = self.tv_ld.selection()
        if not sel:
            self.bao("Chọn một người ở lưới rồi bấm Bổ sung hồ sơ BHXH (hoặc bấm đúp dòng).", True)
            return
        n = next((x for x in self.du.nv if str(x["ma"]) == sel[0]), None)
        if not n:
            return
        hs = self.du.ho_so(n)
        goc = self.du.ho_so(n, goc=True)
        w = tk.Toplevel(self.root)
        w.title("Hồ sơ BHXH - %s %s" % (n["sh"], n["ten"]))
        w.configure(bg=MAU["the"])
        w.transient(self.root)
        w.grab_set()
        tk.Label(w, text="%s  -  %s" % (n["sh"], n["ten"]), font=self.F(12, True), bg=MAU["the"], fg=MAU["xanh_dam"]).grid(
            row=0, column=0, columnspan=4, sticky="w", padx=12, pady=(10, 2))
        tk.Label(w, text="Ngày sinh %s · %s · CCCD %s · HĐ số %s   (thông tin của Danh sách nhân viên - sửa ở phần mềm)"
                 % (B.ngay_vn(n["ns"]) or "-", n["phai"] or "-", n["cccd"] or "-", n["so_hd"] or "-"),
                 font=self.F(9), bg=MAU["the"], fg=MAU["nhat"]).grid(row=1, column=0, columnspan=4, sticky="w", padx=12, pady=(0, 8))
        o = {}
        for i, (ma, nhan) in enumerate(self.NV_O):
            r, c = 2 + i // 2, (i % 2) * 2
            tk.Label(w, text=nhan, font=self.F(9), bg=MAU["the"], fg=MAU["chu"], anchor="w").grid(row=r, column=c, sticky="w", padx=(12, 6), pady=3)
            if ma == "vi_tri":
                e = ttk.Combobox(w, values=[t for _, t in B.VI_TRI], width=34, state="readonly")
                e.set(dict(B.VI_TRI).get(hs["vi_tri"], "Khác"))
            elif ma == "loai_hd":
                e = ttk.Combobox(w, values=[t for _, t in B.LOAI_HD], width=34, state="readonly")
                e.set(dict(B.LOAI_HD).get(hs["loai_hd"], ""))
            elif ma == "nhan_kq":
                e = ttk.Combobox(w, values=["Điện tử", "Bản giấy", "Điện tử và bản giấy"], width=34)
                e.set(hs["nhan_kq"])
            else:
                e = ttk.Entry(w, width=36)
                v = hs.get(ma)
                if isinstance(v, (dt.date,)):
                    v = B.ngay_vn(v)
                elif isinstance(v, float):
                    v = ("{:,.0f}".format(v) if v >= 100 else ("%g" % v)) if v else ""
                e.insert(0, v or "")
            e.grid(row=r, column=c + 1, sticky="we", padx=(0, 14), pady=3)
            o[ma] = e
        kb = tk.BooleanVar(value=bool(hs["khong_bh"]))
        r = 3 + len(self.NV_O) // 2
        tk.Checkbutton(w, text="Không tham gia BHXH (không đưa vào D02-LT, bảng tính đóng)", variable=kb, bg=MAU["the"],
                       font=self.F(9)).grid(row=r, column=0, columnspan=4, sticky="w", padx=12, pady=(6, 2))

        def luu():
            gt = {}
            for ma, e in o.items():
                v = B.chu(e.get())
                if ma == "vi_tri":
                    v = next((k for k, t in B.VI_TRI if t == v), "KHAC")
                if ma == "loai_hd":
                    v = next((k for k, t in B.LOAI_HD if t == v), "")
                if ma in ("hd_tu", "hd_den", "nn_tu", "nn_den") and v and not B.ngay(v):
                    self.mb.showwarning("Kết nối BHXH", "Ngày không hợp lệ (dd/mm/yyyy): %s" % v, parent=w)
                    return
                if ma == "bat_dau_dong" and v and not re.fullmatch(r"\d{1,2}/\d{4}", v):
                    self.mb.showwarning("Kết nối BHXH", "Bắt đầu đóng BHXH nhập dạng mm/yyyy (ví dụ 03/2024).", parent=w)
                    return
                if ma in ("luong_bh", "pc_cv", "pc_tnvk", "pc_tnn", "pc_luong", "bo_sung") and v:
                    x = doc_so(v)
                    if x < 0:
                        self.mb.showwarning("Kết nối BHXH", "Số không hợp lệ: %s" % v, parent=w)
                        return
                    v = x
                if ma == "ma_bhxh" and v and not re.fullmatch(r"\d{10}", v):
                    if not self.mb.askyesno("Kết nối BHXH", "Mã số BHXH thường gồm 10 chữ số. Vẫn lưu '%s'?" % v, parent=w):
                        return
                g = goc.get(ma)
                if isinstance(g, dt.date):
                    g = B.ngay_vn(g)
                if v in ("", None, 0) or (str(v) == str(g if g is not None else "") and ma not in ("vi_tri",)):
                    continue
                if ma == "vi_tri" and v == "KHAC":
                    continue
                if ma in ("hd_tu", "hd_den", "nn_tu", "nn_den"):
                    v = B.ngay_vn(v)
                gt[ma] = v
            if kb.get() != bool(goc["khong_bh"]):
                gt["khong_bh"] = 1 if kb.get() else 0
            self.du.hs.dat_nv(n["sh"], gt)
            try:
                self.du.hs.luu()
                ghi_log("Luu ho so BHXH nhan vien %s (%d o)" % (n["sh"], len(gt)))
            except Exception as e:
                self.mb.showerror("Kết nối BHXH", "Không lưu được: %s" % e, parent=w)
                return
            w.destroy()
            self.nap_lao_dong()
            self.nap_phat_sinh()
            self.bao("Đã lưu hồ sơ BHXH của %s." % n["ten"])

        nut = tk.Frame(w, bg=MAU["the"])
        nut.grid(row=r + 1, column=0, columnspan=4, sticky="e", padx=12, pady=(6, 12))
        ttk.Button(nut, text="Lưu", style="Nut.TButton", command=luu).pack(side="right", padx=4)
        ttk.Button(nut, text="Đóng", command=w.destroy).pack(side="right", padx=4)
        w.bind("<Escape>", lambda e: w.destroy())

    # ------------------------------------------------------------------ 3. phat sinh
    PS_COT = [("chon", "Chọn", 50), ("sh", "Mã NV", 70), ("ten", "Họ và tên", 170), ("pa", "Phương án", 210), ("tu", "Từ tháng", 74),
              ("den", "Đến tháng", 74), ("cu", "Lương cũ", 92), ("moi", "Lương mới", 92), ("gc", "Ghi chú", 300), ("ng", "Nguồn", 90)]

    def _the_phat_sinh(self):
        tk, ttk = self.tk, self.ttk
        f = tk.Frame(self.nb, bg=MAU["nen"])
        self.nb.add(f, text=" 3. Phát sinh tháng ")
        tren = tk.Frame(f, bg=MAU["nen"])
        tren.pack(fill="x", padx=8, pady=(8, 4))
        for t, h, st in (("Thêm...", self.them_ps, "Nut.TButton"), ("Sửa...", self.sua_ps, "TButton"), ("Chọn / bỏ chọn", self.dao_chon, "TButton"),
                         ("Xoá dòng", self.xoa_ps, "TButton"), ("Nhận biết lại từ bảng lương", self.nhan_biet_lai, "TButton"),
                         ("Lưu phát sinh tháng", self.luu_ps, "Nut.TButton")):
            ttk.Button(tren, text=t, style=st, command=h).pack(side="left", padx=4)
        self.lbl_ps = tk.Label(f, text="", font=self.F(9), bg=MAU["nen"], fg=MAU["nhat"], anchor="w", justify="left")
        self.lbl_ps.pack(fill="x", padx=10)
        khung = tk.Frame(f, bg=MAU["nen"])
        khung.pack(fill="both", expand=True, padx=8, pady=(2, 8))
        self.tv_ps = ttk.Treeview(khung, columns=[c for c, _, _ in self.PS_COT], show="headings", selectmode="extended")
        for c, t, w in self.PS_COT:
            self.tv_ps.heading(c, text=t)
            self.tv_ps.column(c, width=w, stretch=(c in ("gc",)), anchor="center" if c in ("chon", "sh", "tu", "den") else ("e" if c in ("cu", "moi") else "w"))
        self.tv_ps.tag_configure("bo", foreground="#9a9a9a")
        self.tv_ps.tag_configure("T", foreground=MAU["la"])
        self.tv_ps.tag_configure("G", foreground=MAU["do"])
        sy = ttk.Scrollbar(khung, orient="vertical", command=self.tv_ps.yview)
        self.tv_ps.configure(yscrollcommand=sy.set)
        self.tv_ps.grid(row=0, column=0, sticky="nsew")
        sy.grid(row=0, column=1, sticky="ns")
        khung.grid_rowconfigure(0, weight=1)
        khung.grid_columnconfigure(0, weight=1)
        self.tv_ps.bind("<Double-1>", lambda e: self.sua_ps())
        self.ps = []

    def nap_phat_sinh(self, ds=None):
        self.ps = ds if ds is not None else self.du.phat_sinh(self.y, self.m)
        tv = self.tv_ps
        tv.delete(*tv.get_children())
        da_luu = self.du.hs.phat_sinh(self.y, self.m) is not None
        for i, e in enumerate(self.ps):
            n = self.du.tim(e.get("sh"))
            pa = e.get("pa") or ""
            tv.insert("", "end", iid=str(i), values=(
                "✓" if e.get("chon", 1) else "", e.get("sh"), n["ten"] if n else "(không có trong danh sách)",
                pa + " - " + self.du.ten_pa(pa), e.get("tu"), e.get("den"),
                "{:,.0f}".format(B.so(e.get("luong_cu"))) if B.so(e.get("luong_cu")) else "",
                "{:,.0f}".format(B.so(e.get("luong_moi"))) if B.so(e.get("luong_moi")) else "",
                e.get("ghi_chu"), "Tự nhận biết" if e.get("tu_dong") else "Nhập tay"),
                tags=(("bo",) if not e.get("chon", 1) else (self.du.nhom_pa(pa),)))
        self.lbl_ps.configure(text="Tháng %02d/%d: %d phát sinh (%s). Tăng = xanh, giảm = đỏ. Dòng bỏ chọn không đưa vào D02-LT." % (
            self.m, self.y, len(self.ps), "đã lưu - sửa tay" if da_luu else "tự nhận biết, chưa lưu"))

    def _hop_ps(self, e=None):
        tk, ttk = self.tk, self.ttk
        e = dict(e or {"sh": "", "pa": "TM", "tu": B.thang_vn(self.y, self.m), "den": "", "ghi_chu": "", "chon": 1})
        w = tk.Toplevel(self.root)
        w.title("Phát sinh tháng %02d/%d" % (self.m, self.y))
        w.configure(bg=MAU["the"])
        w.transient(self.root)
        w.grab_set()
        ds_nv = ["%s - %s" % (n["sh"], n["ten"]) for n in self.du.nv]
        ds_pa = ["%s - %s" % (x[0], x[1]) for x in self.du.ch["phuong_an"]]
        o = {}
        for i, (ma, nhan) in enumerate((("sh", "Người lao động"), ("pa", "Phương án"), ("tu", "Từ tháng, năm (mm/yyyy)"),
                                        ("den", "Đến tháng, năm (truy thu / truy giảm)"), ("ghi_chu", "Ghi chú"))):
            tk.Label(w, text=nhan, font=self.F(10), bg=MAU["the"]).grid(row=i, column=0, sticky="w", padx=12, pady=4)
            if ma == "sh":
                c = ttk.Combobox(w, values=ds_nv, width=48)
                c.set(next((x for x in ds_nv if x.startswith(e["sh"] + " - ")), "") if e.get("sh") else "")
            elif ma == "pa":
                c = ttk.Combobox(w, values=ds_pa, width=48, state="readonly")
                c.set(next((x for x in ds_pa if x.startswith((e.get("pa") or "") + " - ")), ds_pa[0]))
            else:
                c = ttk.Entry(w, width=50)
                c.insert(0, e.get(ma) or "")
            c.grid(row=i, column=1, sticky="we", padx=(0, 12), pady=4)
            o[ma] = c
        kq = {}

        def ok():
            sh = o["sh"].get().split(" - ")[0].strip()
            if not self.du.tim(sh):
                self.mb.showwarning("Kết nối BHXH", "Chọn người lao động trong danh sách.", parent=w)
                return
            for k in ("tu", "den"):
                v = B.chu(o[k].get())
                if v and not re.fullmatch(r"\d{1,2}/\d{4}", v):
                    self.mb.showwarning("Kết nối BHXH", "Tháng nhập dạng mm/yyyy: %s" % v, parent=w)
                    return
            kq.update(e)
            pa = o["pa"].get().split(" - ")[0].strip()
            if sh != e.get("sh") or pa != e.get("pa"):
                kq.pop("luong_cu", None)             # doi nguoi / phuong an: luong tinh lai theo bang luong
                kq.pop("luong_moi", None)
            kq.update({"sh": sh, "pa": pa, "tu": B.chu(o["tu"].get()),
                       "den": B.chu(o["den"].get()), "ghi_chu": B.chu(o["ghi_chu"].get()), "tu_dong": 0})
            w.destroy()

        nut = tk.Frame(w, bg=MAU["the"])
        nut.grid(row=6, column=0, columnspan=2, sticky="e", padx=12, pady=10)
        ttk.Button(nut, text="Đồng ý", style="Nut.TButton", command=ok).pack(side="right", padx=4)
        ttk.Button(nut, text="Huỷ", command=w.destroy).pack(side="right", padx=4)
        w.bind("<Escape>", lambda ev: w.destroy())
        self.root.wait_window(w)
        return kq or None

    def them_ps(self):
        e = self._hop_ps()
        if e:
            self.ps.append(e)
            self.nap_phat_sinh(self.ps)
            self.bao("Đã thêm - bấm Lưu phát sinh tháng để giữ lại.")

    def sua_ps(self):
        sel = self.tv_ps.selection()
        if not sel:
            return
        i = int(sel[0])
        e = self._hop_ps(self.ps[i])
        if e:
            self.ps[i] = e
            self.nap_phat_sinh(self.ps)
            self.bao("Đã sửa - bấm Lưu phát sinh tháng để giữ lại.")

    def dao_chon(self):
        for s in self.tv_ps.selection():
            e = self.ps[int(s)]
            e["chon"] = 0 if e.get("chon", 1) else 1
        self.nap_phat_sinh(self.ps)

    def xoa_ps(self):
        sel = sorted((int(s) for s in self.tv_ps.selection()), reverse=True)
        if not sel or not self.mb.askyesno("Kết nối BHXH", "Xoá %d dòng phát sinh khỏi danh sách tháng này?" % len(sel)):
            return
        for i in sel:
            del self.ps[i]
        self.nap_phat_sinh(self.ps)

    def nhan_biet_lai(self):
        if self.du.hs.phat_sinh(self.y, self.m) is not None:
            if not self.mb.askyesno("Kết nối BHXH", "Bỏ danh sách phát sinh đã lưu (sửa tay) của tháng %02d/%d và nhận biết lại từ bảng lương?"
                                    % (self.m, self.y)):
                return
            self.du.hs.dat_phat_sinh(self.y, self.m, None)
            self.du.hs.luu()
        self.nap_phat_sinh()
        self.bao("Đã nhận biết lại phát sinh tháng %02d/%d." % (self.m, self.y))

    def luu_ps(self):
        self.du.hs.dat_phat_sinh(self.y, self.m, [dict(e) for e in self.ps])
        try:
            self.du.hs.luu()
            ghi_log("Luu phat sinh %02d/%d: %d dong" % (self.m, self.y, len(self.ps)))
            self.bao("Đã lưu %d phát sinh tháng %02d/%d." % (len(self.ps), self.m, self.y))
        except Exception as e:
            self.bao("Không lưu được: %s" % e, True)
        self.nap_phat_sinh()

    # ------------------------------------------------------------------ 4. lap mau bieu
    MAU_DS = [("D02", "D02-LT  Danh sách tham gia, điều chỉnh đóng BHXH, BHYT, BHTN (QĐ 366/QĐ-BHXH) - theo phát sinh tháng", True),
              ("DONG", "Bảng tính số phải đóng BHXH, BHYT, BHTN tháng (công thức sống) - đối chiếu Thông báo C12-TS", True),
              ("KT", "Danh sách lao động và kiểm tra hồ sơ BHXH (thiếu mã BHXH, CCCD, nơi KCB, ngày HĐ, lương < tối thiểu vùng)", True),
              ("TK1", "TK1-TS  Tờ khai đăng ký, điều chỉnh thông tin tham gia BHXH, BHYT (mỗi người một trang)", False),
              ("TK3", "TK3-TS  Tờ khai đơn vị đăng ký, điều chỉnh thông tin tham gia BHXH, BHYT, BHTN", False),
              ("PLI", "01/PLI  Báo cáo tình hình thay đổi về lao động (NĐ 145/2020; hạn trước 05/6 và 05/12)", False),
              ("M33", "Mẫu số 33  Thông báo về tình hình biến động lao động (NĐ 374/2025) - tháng có tăng / giảm, gửi tổ chức DVVL công", False),
              ("MAU", "Điền danh sách vào tệp mẫu Excel (tải từ cổng / phần mềm kê khai) - đọc dòng tiêu đề, ghép cột", False)]

    def _the_lap(self):
        tk, ttk = self.tk, self.ttk
        f = tk.Frame(self.nb, bg=MAU["nen"])
        self.nb.add(f, text=" 4. Lập mẫu biểu ")
        k = self._the(f)
        k.pack(fill="both", expand=True, padx=8, pady=8)
        tk.Label(k, text="CHỌN MẪU CẦN LẬP (Excel chữ Unicode, lưu trong thư mục Excels\\BHXH)", font=self.F(11, True),
                 bg=MAU["the"], fg=MAU["xanh_dam"]).grid(row=0, column=0, columnspan=3, sticky="w", padx=12, pady=(10, 6))
        self.chon = {}
        r = 1
        for ma, nhan, mac in self.MAU_DS:
            v = tk.BooleanVar(value=mac)
            tk.Checkbutton(k, text=nhan, variable=v, bg=MAU["the"], font=self.F(10), anchor="w").grid(
                row=r, column=0, columnspan=3, sticky="w", padx=14, pady=2)
            self.chon[ma] = v
            r += 1
            if ma == "TK1":
                self.tk1 = tk.StringVar(value="TANG")
                fr = tk.Frame(k, bg=MAU["the"])
                fr.grid(row=r, column=0, columnspan=3, sticky="w", padx=42)
                for gt, t in (("TANG", "người tăng mới trong tháng"), ("THIEU", "người chưa có mã số BHXH"),
                              ("CHON", "người đang chọn ở thẻ Lao động")):
                    tk.Radiobutton(fr, text=t, value=gt, variable=self.tk1, bg=MAU["the"], font=self.F(9)).pack(side="left", padx=6)
                r += 1
            if ma == "PLI":
                self.ky = tk.IntVar(value=1 if self.m <= 6 else 2)
                fr = tk.Frame(k, bg=MAU["the"])
                fr.grid(row=r, column=0, columnspan=3, sticky="w", padx=42)
                tk.Radiobutton(fr, text="6 tháng đầu năm", value=1, variable=self.ky, bg=MAU["the"], font=self.F(9)).pack(side="left", padx=6)
                tk.Radiobutton(fr, text="Cuối năm (tháng 7 - 12)", value=2, variable=self.ky, bg=MAU["the"], font=self.F(9)).pack(side="left", padx=6)
                r += 1
            if ma == "MAU":
                fr = tk.Frame(k, bg=MAU["the"])
                fr.grid(row=r, column=0, columnspan=3, sticky="w", padx=42)
                ttk.Button(fr, text="Chọn tệp mẫu...", command=self.chon_mau).pack(side="left", padx=6)
                self.lbl_mau = tk.Label(fr, text="(chưa chọn tệp mẫu)", bg=MAU["the"], fg=MAU["nhat"], font=self.F(9))
                self.lbl_mau.pack(side="left", padx=6)
                r += 1
        nut = tk.Frame(k, bg=MAU["the"])
        nut.grid(row=r, column=0, columnspan=3, sticky="w", padx=12, pady=(12, 6))
        ttk.Button(nut, text="Lập mẫu biểu (Excel)", style="Chinh.TButton", command=self.lap).pack(side="left", padx=4)
        ttk.Button(nut, text="Mở thư mục kết quả", command=self.mo_thu_muc).pack(side="left", padx=8)
        self.kq = tk.Listbox(k, height=8, font=self.F(10), activestyle="none", relief="flat", highlightthickness=1,
                             highlightbackground=MAU["vien"])
        self.kq.grid(row=r + 1, column=0, columnspan=3, sticky="nsew", padx=12, pady=(4, 12))
        self.kq.bind("<Double-1>", lambda e: self.mo_tep_chon())
        k.grid_rowconfigure(r + 1, weight=1)
        k.grid_columnconfigure(0, weight=1)
        self.kq_tep = []

    def chon_mau(self):
        p = self.fd.askopenfilename(parent=self.root, title="Chọn tệp mẫu Excel (tải từ cổng BHXH / phần mềm kê khai)",
                                    filetypes=[("Excel", "*.xlsx *.xls"), ("Tất cả", "*.*")])
        if p:
            self.tep_mau = p
            self.lbl_mau.configure(text=os.path.basename(p))
            self.chon["MAU"].set(True)

    def lap(self):
        chon = set(k for k, v in self.chon.items() if v.get())
        if not chon:
            self.bao("Chưa chọn mẫu nào.", True)
            return
        if "MAU" in chon and not self.tep_mau:
            self.mb.showwarning("Kết nối BHXH", "Chọn tệp mẫu Excel trước (nút Chọn tệp mẫu...).")
            return
        if not self.du.don_vi().get("ma_dv") and ("D02" in chon or "TK3" in chon):
            if not self.mb.askyesno("Kết nối BHXH", "Chưa có Mã đơn vị BHXH (thẻ Đơn vị). Vẫn lập mẫu?"):
                return
        ds_tk1 = None
        if "TK1" in chon:
            if self.tk1.get() == "THIEU":
                ds_tk1 = [n["sh"] for n in self.du.nv if not self.du.ho_so(n)["ma_bhxh"] and not self.du.ho_so(n)["khong_bh"]
                          and self.du.dang_lam(n, self.y, self.m)]
            elif self.tk1.get() == "CHON":
                chon_ma = set(self.tv_ld.selection())
                ds_tk1 = [n["sh"] for n in self.du.nv if str(n["ma"]) in chon_ma]
        self.root.configure(cursor="watch")
        self.root.update()
        try:
            ra, kq = B.lap(self.du, chon, self.y, self.m, self.excels, ky_pli=self.ky.get(), ds_tk1=ds_tk1,
                           tep_mau=self.tep_mau or None, ghi_log=ghi_log)
        except Exception as e:
            self.root.configure(cursor="")
            ghi_log("LOI lap mau: %s" % e)
            self.mb.showerror("Kết nối BHXH", "Không lập được mẫu biểu: %s" % e)
            return
        self.root.configure(cursor="")
        self.thu_muc_cuoi = ra
        self.kq.delete(0, "end")
        self.kq_tep = []
        ten = {"D02": "D02-LT", "DONG": "Bảng tính đóng BHXH", "KT": "Kiểm tra hồ sơ", "TK1": "TK1-TS", "TK3": "TK3-TS",
               "PLI": "01/PLI", "M33": "Mẫu số 33", "MAU": "Tệp theo mẫu"}
        loi = 0
        for x in kq:
            if x[1]:
                them = ""
                if x[0] == "MAU" and len(x) > 3 and x[3]:
                    them = "  - cột chưa ghép: " + ", ".join(x[3][:6])
                self.kq.insert("end", "✓ %s: %s  (%s dòng)%s" % (ten.get(x[0], x[0]), os.path.basename(x[1]), x[2], them))
                self.kq_tep.append(x[1])
            else:
                loi += 1
                self.kq.insert("end", "✗ %s: %s" % (ten.get(x[0], x[0]), x[2] if x[2] else "không có người để lập"))
                self.kq_tep.append("")
        self.kq.insert("end", "Thư mục: " + ra)
        self.kq_tep.append(ra)
        self.bao("Đã lập %d tệp vào %s%s - bấm đúp một dòng để mở." % (len([t for t in self.kq_tep[:-1] if t]), ra,
                                                                    (" (%d mẫu lỗi)" % loi) if loi else ""), bool(loi))
        if len([t for t in self.kq_tep[:-1] if t]) == 1:
            mo_tep(next(t for t in self.kq_tep if t))
        else:
            mo_tep(ra)

    def mo_thu_muc(self):
        p = self.thu_muc_cuoi or os.path.join(self.excels, "BHXH")
        if not os.path.isdir(p):
            os.makedirs(p, exist_ok=True)
        mo_tep(p)

    def mo_tep_chon(self):
        s = self.kq.curselection()
        if s and s[0] < len(self.kq_tep) and self.kq_tep[s[0]]:
            mo_tep(self.kq_tep[s[0]])

    # ------------------------------------------------------------------ 5. cong truc tuyen
    def _the_cong(self):
        tk, ttk = self.tk, self.ttk
        f = tk.Frame(self.nb, bg=MAU["nen"])
        self.nb.add(f, text=" 5. Cổng BHXH trực tuyến ")
        tk.Label(f, text="Các bước nộp hồ sơ trực tuyến:  (1) Lập mẫu biểu ở thẻ 4  ->  (2) Mở cổng, TỰ đăng nhập (tài khoản đơn vị / VNeID, tự nhập "
                 "mã xác nhận)  ->  (3) Kê khai trên cổng hoặc tải tệp lên  ->  (4) TỰ ký số và nộp  ->  (5) Tra cứu kết quả, C12-TS; "
                 "đối chiếu bằng Bảng tính đóng BHXH.", font=self.F(10), bg=MAU["nen"], fg=MAU["chu"], wraplength=1100,
                 justify="left").pack(fill="x", padx=12, pady=(10, 4))
        for ten, url, mo_ta in self.du.ch["cong"]:
            k = self._the(f)
            k.pack(fill="x", padx=10, pady=5)
            tk.Label(k, text=ten, font=self.F(11, True), bg=MAU["the"], fg=MAU["xanh_dam"]).grid(row=0, column=0, sticky="w", padx=12, pady=(8, 0))
            tk.Label(k, text=mo_ta, font=self.F(9), bg=MAU["the"], fg=MAU["chu"], wraplength=820, justify="left").grid(
                row=1, column=0, sticky="w", padx=12, pady=(0, 2))
            tk.Label(k, text=url, font=self.F(9), bg=MAU["the"], fg=MAU["xanh"]).grid(row=2, column=0, sticky="w", padx=12, pady=(0, 8))
            ttk.Button(k, text="Mở cổng", style="Nut.TButton", command=lambda u=url, t=ten: self.mo_cong(u, t)).grid(
                row=0, column=1, rowspan=3, sticky="e", padx=14)
            k.grid_columnconfigure(0, weight=1)
        tk.Label(f, text="Phần mềm chỉ mở trang cổng: KHÔNG lưu mật khẩu, KHÔNG điền mã xác nhận, KHÔNG ký, KHÔNG nộp hồ sơ thay bạn.",
                 font=self.F(9, True), bg=MAU["nen"], fg=MAU["do"]).pack(anchor="w", padx=12, pady=(8, 4))

    def mo_cong(self, url, ten):
        try:
            webbrowser.open(url, new=2)
            ghi_log("Mo cong: %s" % url)
            self.bao("Đã mở %s trong trình duyệt - tự đăng nhập để kê khai / nộp." % ten)
        except Exception as e:
            self.bao("Không mở được trình duyệt: %s" % e, True)


def an_cua_so_console():
    """Windows: cua so console mo kem (py.exe goi tu phan mem) -> an; chay tu cmd (nhieu tien trinh dung chung) -> giu."""
    try:
        import ctypes
        k32 = ctypes.windll.kernel32
        hw = k32.GetConsoleWindow()
        if not hw:
            return
        ds = (ctypes.c_uint * 8)()
        if k32.GetConsoleProcessList(ds, 8) <= 2:
            ctypes.windll.user32.ShowWindow(hw, 0)
    except Exception:
        pass


def chay_giao_dien(ts):
    import tkinter as tk
    from tkinter import messagebox
    an_cua_so_console()
    try:
        du, excels = nap(ts)
    except Exception as e:
        ghi_log("LOI nap du lieu: %s" % e)
        r = tk.Tk()
        r.withdraw()
        messagebox.showerror("Kết nối BHXH", "Không đọc được số liệu từ phần mềm: %s" % e)
        r.destroy()
        return 1
    root = tk.Tk()
    _gd167_ico(root)
    try:
        CuaSo(root, du, excels, ts)
    except Exception:
        ghi_log("LOI giao dien: %s" % traceback.format_exc().replace("\n", " | "))
        root.destroy()
        raise
    root.mainloop()
    return 0


def main(argv=None):
    ts = doc_tham_so(argv if argv is not None else sys.argv[1:])
    if not ts["json"] or not os.path.isfile(ts["json"]):
        print("LOI thieu /json:<tep so lieu cua phan mem>")
        ghi_log("LOI thieu JSON: %s" % ts["json"])
        return 2
    if ts["lap"]:
        return chay_khong_giao_dien(ts)
    return chay_giao_dien(ts)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except SystemExit:
        raise
    except Exception:
        ghi_log("LOI: %s" % traceback.format_exc().replace("\n", " | "))
        raise
