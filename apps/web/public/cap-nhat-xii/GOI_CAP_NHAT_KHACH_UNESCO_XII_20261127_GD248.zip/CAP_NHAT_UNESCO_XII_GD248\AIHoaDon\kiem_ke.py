# -*- coding: utf-8 -*-
"""GD252 - KIEM KE CO MAY HO TRO (viec vat ly cua nguoi, may lam phan con lai):
   1) lap:  python kiem_ke.py lap <bo so .mdb> <thang 1-12> [tep xlsx ra]
            -> phieu kiem ke Excel in san so so (TonKho cuoi thang: luong, gia tri, don gia) theo kho / ma vat tu cua cac TK 15*;
               cot "So dem" de trong cho nguoi dem ghi vao (Excel hoac giay roi go lai).
   2) doc:  python kiem_ke.py doc <tep xlsx da dien> [thu muc ra]
            -> chenh lech (dem - so) tung ma, gia tri, va BUT TOAN DE XUAT: thieu -> No 1381 / Co 15x ; thua -> No 15x / Co 3381
               (ke toan quyet xu ly: 632 / 711 / boi thuong; may khong ghi so). Ket qua: Excel + kiem_ke.txt trong thu muc ra.
   Chi doc bo so (jet_doc), khong ghi gi vao .MDB."""
import io
import os
import sys
import datetime as _dt

CO_SO_DEM = 7                 # cot "So dem" (0-based) trong sheet Kiem ke


def _f(x):
    try:
        return float(x or 0)
    except Exception:
        return 0.0


def _s(x):
    return str(x if x is not None else "").strip()


def doc_ton(duong, thang):
    """-> [dict kho, ma, ten, dvt, tk, luong, tien, ma_vt, ma_kho, ma_tk] cua TK 15* co luong hoac tien khac 0."""
    import jet_doc
    m = jet_doc.Mdb(duong)
    try:
        tk = {int(r.get("MaSo") or 0): _s(r.get("SoHieu")) for r in m.doc("HethongTK")}
        vt = {int(r.get("MaSo") or 0): (_s(r.get("SoHieu")), _s(r.get("TenVattu")), _s(r.get("DonVi"))) for r in m.doc("Vattu")}
        kho = {}
        if "khohang" in {k.lower() for k in m.bang()}:
            kho = {int(r.get("MaSo") or 0): _s(r.get("TenKho")) for r in m.doc("KhoHang")}
        out = []
        cl, ct = "Luong_%d" % thang, "Tien_%d" % thang
        for r in m.doc("TonKho"):
            sh = tk.get(int(r.get("MaTaiKhoan") or 0), "")
            if not sh.startswith("15"):
                continue
            L, T = _f(r.get(cl)), _f(r.get(ct))
            if abs(L) < 1e-9 and abs(T) < 1:
                continue
            v = vt.get(int(r.get("MaVatTu") or 0), ("?", "", ""))
            out.append({"kho": kho.get(int(r.get("MaSoKho") or 0), str(r.get("MaSoKho") or "")), "ma": v[0], "ten": v[1], "dvt": v[2], "tk": sh,
                        "luong": L, "tien": T, "ma_vt": int(r.get("MaVatTu") or 0), "ma_kho": int(r.get("MaSoKho") or 0), "ma_tk": int(r.get("MaTaiKhoan") or 0)})
        out.sort(key=lambda d: (d["kho"], d["tk"], d["ma"]))
        return out
    finally:
        try:
            m.dong()
        except Exception:
            pass


def _xl():
    import tool_htkk_unesco as H
    return H


def lap_phieu(duong, thang, ra, ten_cty=""):
    H = _xl()
    X = H
    ds = doc_ton(duong, thang)
    T = [[("PHIẾU KIỂM KÊ HÀNG TỒN KHO - cuối tháng %d" % thang, X.X_TITLE)],
         [("Đơn vị: %s    Số sổ lấy từ bộ sổ lúc %s. Người đếm ghi số thực tế vào cột SỐ ĐẾM; để trống = chưa đếm." % (
             ten_cty or os.path.basename(duong), _dt.datetime.now().strftime("%d/%m/%Y %H:%M")), X.X_THUONG)], [],
         [(c, X.X_TIEUDE) for c in ("Kho", "Mã", "Tên vật tư, hàng hoá", "ĐVT", "TK", "Số sổ", "Giá trị sổ", "SỐ ĐẾM", "Ghi chú", "id_vt", "id_kho", "id_tk")]]
    for d in ds:
        T.append([(d["kho"], X.X_CHU), (d["ma"], X.X_CHU), (d["ten"], X.X_CHU), (d["dvt"], X.X_CHU), (d["tk"], X.X_CHU), (d["luong"], X.X_SO),
                  (round(d["tien"]), X.X_SO), ("", X.X_CHU), ("", X.X_CHU), (d["ma_vt"], X.X_SO), (d["ma_kho"], X.X_SO), (d["ma_tk"], X.X_SO)])
    T.append([])
    T.append([("Người đếm: ................    Thủ kho: ................    Kế toán: ................", X.X_THUONG)])
    os.makedirs(os.path.dirname(os.path.abspath(ra)), exist_ok=True)
    H.viet_xlsx_o(ra, [("Kiem ke", [16, 12, 40, 8, 8, 14, 16, 14, 24, 8, 8, 8], T, 4)])
    return ra, len(ds)


def doc_ket_qua(xlsx):
    """-> (dong chenh lech [[kho, ma, ten, dvt, tk, so, dem, chenh, don gia, gia tri]], so dong da dem, so dong tat ca)"""
    import tool_trich_xuat_so_phu as TX
    wb = TX.doc_xlsx(xlsx)
    sh = wb.get("Kiem ke") or (list(wb.values())[0] if wb else [])
    bat_dau = None
    for i, r in enumerate(sh):
        if r and _s(r[0]) == "Kho" and len(r) > CO_SO_DEM:
            bat_dau = i + 1
            break
    if bat_dau is None:
        raise ValueError("Khong thay dong tieu de 'Kho' trong sheet Kiem ke")
    dong, n_dem, n_all = [], 0, 0
    for r in sh[bat_dau:]:
        if not r or not _s(r[1]) or _s(r[0]).startswith("Người đếm"):
            continue
        n_all += 1
        dem = r[CO_SO_DEM] if len(r) > CO_SO_DEM else None
        if dem is None or _s(dem) == "":
            continue
        n_dem += 1
        so, tien = _f(r[5]), _f(r[6])
        dg = tien / so if abs(so) > 1e-9 else 0.0
        ch = _f(dem) - so
        if abs(ch) < 1e-9:
            continue
        dong.append([_s(r[0]), _s(r[1]), _s(r[2]), _s(r[3]), _s(r[4]), so, _f(dem), ch, round(dg), round(ch * dg)])
    return dong, n_dem, n_all


def but_toan(dong):
    """gop theo TK: thieu -> No 1381 / Co 15x ; thua -> No 15x / Co 3381."""
    thieu, thua = {}, {}
    for d in dong:
        if d[9] < 0:
            thieu[d[4]] = thieu.get(d[4], 0) - d[9]
        elif d[9] > 0:
            thua[d[4]] = thua.get(d[4], 0) + d[9]
    bt = []
    for tk, v in sorted(thieu.items()):
        bt.append(["Thiếu chờ xử lý", "1381", tk, round(v), "Sau khi có quyết định: Nợ 632 / 1388 (bồi thường) / Có 1381"])
    for tk, v in sorted(thua.items()):
        bt.append(["Thừa chờ xử lý", tk, "3381", round(v), "Sau khi có quyết định: Nợ 3381 / Có 711 (hoặc trả lại NCC)"])
    return bt


def lap_bao_cao(xlsx, thu_muc_ra=None):
    H = _xl()
    X = H
    dong, n_dem, n_all = doc_ket_qua(xlsx)
    thu_muc_ra = thu_muc_ra or os.path.join(os.path.dirname(os.path.abspath(xlsx)), "kiem_ke_" + _dt.datetime.now().strftime("%Y%m%d_%H%M%S"))
    os.makedirs(thu_muc_ra, exist_ok=True)
    bt = but_toan(dong)
    T = [[("KẾT QUẢ KIỂM KÊ - chênh lệch giữa số đếm và số sổ", X.X_TITLE)],
         [("Đã đếm %d / %d dòng; %d dòng lệch. Tệp nguồn: %s" % (n_dem, n_all, len(dong), xlsx), X.X_THUONG)], [],
         [(c, X.X_TIEUDE) for c in ("Kho", "Mã", "Tên", "ĐVT", "TK", "Số sổ", "Số đếm", "Chênh (đếm - sổ)", "Đơn giá sổ", "Giá trị chênh")]]
    for d in dong:
        T.append([(d[0], X.X_CHU), (d[1], X.X_CHU), (d[2], X.X_CHU), (d[3], X.X_CHU), (d[4], X.X_CHU), (d[5], X.X_SO), (d[6], X.X_SO), (d[7], X.X_SO), (d[8], X.X_SO), (d[9], X.X_SO)])
    B = [[("BÚT TOÁN ĐỀ XUẤT (máy không ghi sổ - kế toán quyết cách xử lý rồi lập chứng từ)", X.X_TITLE)], [],
         [(c, X.X_TIEUDE) for c in ("Nội dung", "Nợ", "Có", "Số tiền", "Bước tiếp")]]
    for b in bt:
        B.append([(b[0], X.X_CHU), (b[1], X.X_CHU), (b[2], X.X_CHU), (b[3], X.X_SO), (b[4], X.X_CHU)])
    ra = os.path.join(thu_muc_ra, "ket_qua_kiem_ke.xlsx")
    H.viet_xlsx_o(ra, [("Chenh lech", [16, 12, 40, 8, 8, 12, 12, 16, 14, 16], T, 4), ("But toan", [28, 8, 8, 16, 60], B, 3)])
    with io.open(os.path.join(thu_muc_ra, "kiem_ke.txt"), "w", encoding="utf-8") as f:
        f.write("KIEM_KE;%s;%d;%d;%d;%s\n" % (_dt.datetime.now().strftime("%d/%m/%Y %H:%M"), n_dem, n_all, len(dong), ra))
        for d in dong:
            f.write("D;%s;%s;%s;%s;%s;%s\n" % (d[0], d[1], d[4], d[5], d[6], d[9]))
        for b in bt:
            f.write("BT;%s;%s;%s;%s\n" % (b[0], b[1], b[2], b[3]))
    return ra, dong, bt


if __name__ == "__main__":
    a = sys.argv[1:]
    if len(a) >= 3 and a[0] == "lap":
        ra = a[3] if len(a) > 3 else os.path.join(os.path.dirname(os.path.abspath(__file__)), "ket-qua", "PhieuKiemKe_T%02d_%s.xlsx" % (int(a[2]), _dt.datetime.now().strftime("%Y%m%d_%H%M%S")))
        p, n = lap_phieu(a[1], int(a[2]), ra)
        print("Da lap phieu kiem ke %d dong: %s" % (n, p))
    elif len(a) >= 2 and a[0] == "doc":
        ra, dong, bt = lap_bao_cao(a[1], a[2] if len(a) > 2 else None)
        print("Chenh lech %d dong, %d but toan de xuat: %s" % (len(dong), len(bt), ra))
    else:
        print(__doc__)
