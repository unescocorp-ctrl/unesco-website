# -*- coding: utf-8 -*-
"""GD29b - BO RANG BUOC TO KHAI 03/TNDN (TT80/2021, HTKK maTKhai 892).
Moi cong thuc duoi day da doi chieu voi to khai THAT da nop nam 2025 cua doanh nghiep
(tham_khao/htkk/MAU_THAT_03TNDN_2025.xml): 0 rang buoc lech. Dung sai 0 dong.
Chay:  python kiem_03tndn.py <file 03_TNDN.xml>      (khong tham so -> kiem file mau that)
Chi DOC file XML; khong sua, khong nop thay."""
import os, re, sys
import xml.etree.ElementTree as ET

NS = "{http://kekhaithue.gdt.gov.vn/TKhaiThue}"


def _so(x):
    try:
        return float(str(x or "0").replace(",", ""))
    except ValueError:
        return 0.0


def doc(duong):
    goc = ET.parse(duong).getroot()
    tk = goc.find(".//%sCTieuTKhaiChinh" % NS)
    if tk is None:
        raise ValueError("Khong phai file to khai HTKK (thieu CTieuTKhaiChinh)")
    ma = goc.findtext(".//%smaTKhai" % NS)
    C = {e.tag.replace(NS, ""): _so(e.text) for e in tk if len(e) == 0}
    pl = goc.find(".//%sPLuc_03_1A_TNDN" % NS)
    P = {e.tag.replace(NS, ""): _so(e.text) for e in pl} if pl is not None else {}
    lo = []
    p2 = goc.find(".//%sPLuc_03_2_TNDN" % NS)
    if p2 is not None:
        for nhom in p2:
            ten = nhom.tag.replace(NS, "")
            dong = []
            for e in nhom.iter():
                if re.match(r"noiDungNamThu\d+$", e.tag.replace(NS, "")):
                    dong.append({c.tag.replace(NS, ""): _so(c.text) for c in e})
            lo.append((ten, dong, _so(nhom.findtext("%stongCong" % NS))))
    return ma, C, P, lo


def rang_buoc(C, P, lo):
    """-> [(ma, mo ta, ve trai, ve phai)]"""
    g = lambda d, k: d.get(k, 0.0)
    R = []
    if P:
        R += [("1A-06", "PL 03-1A [06] = [07]+[08]+[09] (cac khoan giam tru)", g(P, "ct06"), g(P, "ct07") + g(P, "ct08") + g(P, "ct09")),
              ("1A-12", "PL 03-1A [12] = [13]+[14]+[15] (gia von + CPBH + CPQLDN)", g(P, "ct12"), g(P, "ct13") + g(P, "ct14") + g(P, "ct15")),
              ("1A-18", "PL 03-1A [18] = [04]-[06]+[10]-[12]-[16] (loi nhuan thuan)", g(P, "ct18"),
               g(P, "ct04") - g(P, "ct06") + g(P, "ct10") - g(P, "ct12") - g(P, "ct16")),
              ("1A-21", "PL 03-1A [21] = [19]-[20] (loi nhuan khac)", g(P, "ct21"), g(P, "ct19") - g(P, "ct20")),
              ("1A-22", "PL 03-1A [22] = [18]+[21] (tong loi nhuan truoc thue)", g(P, "ct22"), g(P, "ct18") + g(P, "ct21")),
              ("A1", "To khai [A1] = PL 03-1A [22]", g(C, "ctA1"), g(P, "ct22"))]
    R += [("B1", "[B1] = [B2]+...+[B7] (dieu chinh tang)", g(C, "ctB1"), sum(g(C, "ctB%d" % i) for i in range(2, 8))),
          ("B8", "[B8] = [B9]+...+[B12] (dieu chinh giam)", g(C, "ctB8"), sum(g(C, "ctB%d" % i) for i in range(9, 13))),
          ("B13", "[B13] = [A1]+[B1]-[B8] (thu nhap chiu thue)", g(C, "ctB13"), g(C, "ctA1") + g(C, "ctB1") - g(C, "ctB8")),
          ("B13b", "[B13] = [B14]+[B15] (SXKD + chuyen nhuong BDS)", g(C, "ctB13"), g(C, "ctB14") + g(C, "ctB15")),
          ("C1", "[C1] = [B14]", g(C, "ctC1"), g(C, "ctB14")),
          ("C3", "[C3] = [C3a]+[C3b] (lo duoc chuyen)", g(C, "ctC3"), g(C, "ctC3a") + g(C, "ctC3b")),
          ("C4", "[C4] = [C1]-[C2]-[C3] (thu nhap tinh thue)", g(C, "ctC4"), g(C, "ctC1") - g(C, "ctC2") - g(C, "ctC3")),
          ("G", "[G] = [G1]+[G2]+[G3]+[G4]+[G5] (thue da tam nop)", g(C, "ctG"), sum(g(C, "ctG%d" % i) for i in range(1, 6))),
          ("I", "[I] = [I1]+[I2]", g(C, "ctI"), g(C, "ctI1") + g(C, "ctI2"))]
    tong_sx = None
    for ten, dong, tong in lo:
        for d in dong:
            nam = int(d.get("ct2", 0))
            R.append(("03-2/%s/%d" % (ten, nam), "PL 03-2 %s nam %d: [6] = [3]-[4]-[5] (lo con duoc chuyen)" % (ten, nam),
                      d.get("ct6", 0), d.get("ct3", 0) - d.get("ct4", 0) - d.get("ct5", 0)))
        R.append(("03-2/%s/tong" % ten, "PL 03-2 %s: tong cong = tong cot [5] (lo chuyen ky nay)" % ten, tong, sum(d.get("ct5", 0) for d in dong)))
        if ten == "Lo_HDSXKD":
            tong_sx = tong
    if tong_sx is not None:
        R.append(("C3a", "[C3a] = PL 03-2 tong lo SXKD chuyen ky nay", g(C, "ctC3a"), tong_sx))
    return R


def canh_bao(C, P, lo):
    """Khong phai loi so hoc nhung can nguoi xem."""
    cb = []
    g = lambda d, k: d.get(k, 0.0)
    if P and g(P, "ct11") > g(P, "ct10"):
        cb.append("PL 03-1A [11] (trong do) lon hon [10] doanh thu hoat dong tai chinh")
    if P and g(P, "ct17") > g(P, "ct16"):
        cb.append("PL 03-1A [17] chi phi lai vay lon hon [16] chi phi tai chinh")
    if P and g(P, "ct05") > g(P, "ct04"):
        cb.append("PL 03-1A [05] doanh thu xuat khau lon hon [04] doanh thu")
    if g(C, "ctC3") > max(g(C, "ctC1") - g(C, "ctC2"), 0):
        cb.append("[C3] lo chuyen ky nay lon hon thu nhap con lai [C1]-[C2] - khong duoc chuyen lo qua thu nhap")
    for ten, dong, tong in lo:
        for d in dong:
            if d.get("ct6", 0) < 0:
                cb.append("PL 03-2 %s nam %d: lo con duoc chuyen AM" % (ten, int(d.get("ct2", 0))))
    return cb


def kiem(duong):
    ma, C, P, lo = doc(duong)
    R = rang_buoc(C, P, lo)
    lech = [(m, t, a, b) for m, t, a, b in R if abs(a - b) > 0]
    return ma, R, lech, canh_bao(C, P, lo)


if __name__ == "__main__":
    duong = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(os.path.abspath(__file__)), "tham_khao", "htkk", "MAU_THAT_03TNDN_2025.xml")
    ma, R, lech, cb = kiem(duong)
    print("File: %s  (maTKhai %s)" % (os.path.basename(duong), ma))
    for m, t, a, b in R:
        print("  %-5s %-78s %18s %18s" % ("LECH" if abs(a - b) > 0 else "ok", t[:78], format(a, ",.0f"), format(b, ",.0f")))
    for c in cb:
        print("  CANH BAO: " + c)
    print("Da kiem %d rang buoc: %d lech, %d canh bao." % (len(R), len(lech), len(cb)))
    sys.exit(1 if lech else 0)
