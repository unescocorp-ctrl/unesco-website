# -*- coding: utf-8 -*-
"""GD154 - BANG DIEU HANH KHACH HANG (lo trinh A1) - doc CHI DOC nhieu bo so .MDB bang jet_doc (Python thuan, mo 'rb'), khong dung DAO,
khong doi bo so dang mo. Moi dong mot bo so: chung tu, hoa don dien tu, so phu, thang da khoa, diem san sang, soat rui ro, to khai
ky gan nhat da nop (Cong DVC), han gan nhat -> muc DO / VANG / XANH + ghi chu. Ket qua: tep TAB cho VB6 (FrmDieuHanh) + HTML.

JSON vao (VB6 ModDieuHanh.DH154_Lap): {"thu_muc": [..], "sau": 3, "hom_nay": "dd/mm/yyyy", "dang_mo": "<duong MDB dang mo>",
                                        "tep": [..] (tuy chon: danh sach MDB chon tay)}
Tep ra (TAB): TONG\tn\tdo\tvang\txanh\thtml
              B\tmuc\tduong\tten\tmst\tnam\tct_cuoi\tct_thang\tct_ngay\thddt_den\thddt_chua\thddt_xem\tsp_den\tsp_chua\tkhoa\tdiem\trr\tky\tda_nop\than\tghi_chu\tdang_mo (22 cot)
Han nop (nhu ModCongViec GD137): 01/GTGT thang -> 20 thang sau; quy -> ngay cuoi thang dau quy sau; 05/KK-TNCN tu 01/7/2026 theo quy;
quyet toan TNDN + BCTC -> ngay cuoi thang thu 3 sau nam tai chinh; trung T7 / CN / le -> ngay lam viec tiep theo.
Khong ghi gi vao .MDB. Khong ghi ten khach / MST vao nhat ky.
"""
import datetime as _dt
import html
import io
import json
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
MOC_252 = _dt.date(2026, 7, 1)                    # tu 01/7/2026: 05/KK-TNCN chi quy
LE = {(1, 1), (30, 4), (1, 5), (2, 9)}
DO, VANG, XANH = "DO", "VANG", "XANH"
TEN_MUC = {DO: "ĐỎ", VANG: "VÀNG", XANH: "XANH"}
BO_QUA_TEN = ("MAU", "BCTC", "DEMO", "MAU BCTC", "KETOAN_MAU")


def _so(x):
    try:
        return float(x or 0)
    except (TypeError, ValueError):
        return 0.0


def _ngay(x):
    """datetime / 'dd/mm/yyyy' / 'yyyy-mm-dd' -> date | None."""
    if isinstance(x, _dt.datetime):
        return x.date()
    if isinstance(x, _dt.date):
        return x
    s = str(x or "").strip()
    m = re.match(r"^(\d{1,2})/(\d{1,2})/(\d{4})", s)
    if m:
        try:
            return _dt.date(int(m.group(3)), int(m.group(2)), int(m.group(1)))
        except ValueError:
            return None
    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})", s)
    if m:
        try:
            return _dt.date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except ValueError:
            return None
    return None


def vn(d):
    return d.strftime("%d/%m/%Y") if d else ""


def cuoi_thang(y, m):
    while m > 12:
        y, m = y + 1, m - 12
    while m < 1:
        y, m = y - 1, m + 12
    if m == 12:
        return _dt.date(y, 12, 31)
    return _dt.date(y, m + 1, 1) - _dt.timedelta(days=1)


def ngay_lam_viec(d, le=()):
    if d is None:
        return None
    le = set(le) | LE
    while d.weekday() >= 5 or (d.day, d.month) in le:
        d += _dt.timedelta(days=1)
    return d


def doc_ngay_nghi(tep=None):
    """AIHoaDon\\ngay-nghi-le.txt (dong dd/mm[/yyyy]) -> {(ngay, thang)} ; khong co -> rong."""
    tep = tep or os.path.join(HERE, "ngay-nghi-le.txt")
    kq = set()
    try:
        with io.open(tep, "r", encoding="utf-8-sig") as f:
            for d in f.read().splitlines():
                m = re.match(r"\s*(\d{1,2})/(\d{1,2})", d)
                if m:
                    kq.add((int(m.group(1)), int(m.group(2))))
    except (IOError, OSError):
        pass
    return kq


# ============================================================ ky ke khai / han
def ky_t(y, m):
    return "T%d-%02d" % (y, m)


def ky_q(y, q):
    return "Q%d-%d" % (y, q)


def khoa_ky_chu(s):
    """Chu ky tren Cong DVC ('Q3/2026', 'Quý 3/2026', '09/2026', '01/07/2026-30/09/2026', 'Năm 2026') -> khoa 'Qyyyy-q' / 'Tyyyy-mm' / 'Nyyyy' / ''."""
    t = re.sub(r"\s+", "", str(s or "")).upper()
    so = [int(x) for x in re.findall(r"\d+", t)]
    if not so:
        return ""
    if t.startswith("Q"):
        return ky_q(so[1], so[0]) if len(so) >= 2 and 1 <= so[0] <= 4 and so[1] > 1900 else ""
    if len(so) >= 6 and so[2] > 1900 and so[5] > 1900:
        try:
            a, b = _dt.date(so[2], so[1], so[0]), _dt.date(so[5], so[4], so[3])
        except ValueError:
            return ""
        if (b - a).days <= 31:
            return ky_t(a.year, a.month)
        if (b - a).days <= 92:
            return ky_q(a.year, (a.month - 1) // 3 + 1)
        return "N%d" % a.year
    if len(so) >= 2 and 1 <= so[0] <= 12 and so[1] > 1900:
        return ky_t(so[1], so[0])
    if len(so) == 1 and so[0] > 1900:
        return "N%d" % so[0]
    return ""


def ky_chu(k):
    if k.startswith("T"):
        return "tháng %s/%s" % (k[6:8], k[1:5])
    if k.startswith("Q"):
        return "quý %s/%s" % (k[6:], k[1:5])
    if k.startswith("N"):
        return "năm %s" % k[1:]
    return k


def han_gtgt(k, le=()):
    """han nop 01/GTGT (va TNCN quy) cua ky k."""
    if k.startswith("T"):
        y, m = int(k[1:5]), int(k[6:8])
        c = cuoi_thang(y, m + 1)
        return ngay_lam_viec(_dt.date(c.year, c.month, 20), le)
    if k.startswith("Q"):
        y, q = int(k[1:5]), int(k[6:])
        return ngay_lam_viec(cuoi_thang(y, q * 3 + 1), le)
    return None


def ky_gan_nhat(ky_gtgt, nam_tc, thang_dau, hom_nay):
    """ky ke khai GTGT gan nhat DA KET THUC truoc hom_nay trong nam tai chinh (nhu KK142_KyGanNhat); chua ky nao -> ky dau; sau nam -> ky cuoi."""
    buoc = 1 if ky_gtgt == "T" else 3
    chon, dau = None, None
    for i in range(12):
        y, m = nam_tc + (thang_dau + i - 1) // 12, (thang_dau + i - 1) % 12 + 1
        if buoc == 1 or (m - 1) % 3 == 0:
            cuoi = cuoi_thang(y, m + buoc - 1)
            k = ky_t(y, m) if buoc == 1 else ky_q(y, (m - 1) // 3 + 1)
            if dau is None:
                dau = (k, cuoi)
            if cuoi < hom_nay:
                chon = (k, cuoi)
    return chon or dau


# ============================================================ doc mot bo so (jet_doc) -> bang
def doc_bang(duong, toi_da_ct=400000):
    """{License: dict, ChungTu: [..], HDDTTaiVe: [..], HDDT_SP_Dong: [..], HDDT_ThamSo: {k: v}, HDDT_DVC_Dong: [..], co: {ten bang: bool}}."""
    import jet_doc
    m = jet_doc.Mdb(duong)
    try:
        bang = {k.lower(): k for k in m.bang()}
        kq = {"co": {}}
        for t in ("License", "ChungTu", "HDDTTaiVe", "HDDT_SP_Dong", "HDDT_ThamSo", "HDDT_DVC_Dong", "HethongTK"):
            kq["co"][t] = t.lower() in bang
        if not (kq["co"]["License"] and kq["co"]["ChungTu"] and kq["co"]["HethongTK"]):
            return None
        lic = m.doc("License", 1)
        kq["License"] = lic[0] if lic else {}
        kq["ChungTu"] = [{"ThangCT": r.get("ThangCT"), "NgayCT": r.get("NgayCT")} for r in m.doc("ChungTu", toi_da_ct)]
        kq["HDDTTaiVe"] = []
        if kq["co"]["HDDTTaiVe"]:
            cot = {c["ten"].lower() for c in m.cot("HDDTTaiVe")}
            for r in m.doc("HDDTTaiVe"):
                kq["HDDTTaiVe"].append({"MaCT": r.get("MaCT"), "NgayLap": r.get("NgayLap"), "MaCTKeToan": r.get("MaCTKeToan") if "mactketoan" in cot else "",
                                        "AIValidationStatus": r.get("AIValidationStatus") if "aivalidationstatus" in cot else "",
                                        "HDBanRa": r.get("HDBanRa"), "MSTNguoiBanNguoiXuatHang": r.get("MSTNguoiBanNguoiXuatHang")})
        kq["HDDT_SP_Dong"] = []
        if kq["co"]["HDDT_SP_Dong"]:
            for r in m.doc("HDDT_SP_Dong"):
                kq["HDDT_SP_Dong"].append({"NgayGD": r.get("NgayGD"), "TrangThai": r.get("TrangThai")})
        kq["HDDT_ThamSo"] = {}
        if kq["co"]["HDDT_ThamSo"]:
            for r in m.doc("HDDT_ThamSo"):
                k = str(r.get("Khoa") or "")
                if k:
                    v = r.get("GiaTri")
                    kq["HDDT_ThamSo"][k] = v.decode("utf-16-le", "replace") if isinstance(v, bytes) else str(v or "")
        kq["HDDT_DVC_Dong"] = []
        if kq["co"]["HDDT_DVC_Dong"]:
            for r in m.doc("HDDT_DVC_Dong"):
                if str(r.get("Nhom") or "") in ("HSDVC", "HSK"):
                    kq["HDDT_DVC_Dong"].append({"TieuDe": r.get("TieuDe"), "Ky": r.get("Ky"), "TrangThai": r.get("TrangThai"), "Ngay": r.get("Ngay")})
        return kq
    finally:
        m.dong()


def ten_cty(lic):
    """License.TenCty (font cu VNI / TCVN3) -> Unicode."""
    s = lic.get("TenCty")
    if isinstance(s, bytes):
        s = s.decode("cp1252", "replace")
    s = str(s or "").strip()
    if not s or s == "...":
        return ""
    try:
        import bang_luong_gd78 as B
        f = str(lic.get("FontName") or "").upper()
        if f.startswith("VNI"):
            return B.vni_sang_u(s)
        if f.startswith(".VN") or f.startswith("VN"):
            return B.tcvn3_sang_u(s)
        loai = B.loai_ma([s])
        if loai == "VNI":
            return B.vni_sang_u(s)
        if loai == "TCVN3":
            return B.tcvn3_sang_u(s)
    except Exception:
        pass
    return s


def bo_dau(s):
    import unicodedata
    s = unicodedata.normalize("NFD", str(s or ""))
    return "".join(c for c in s if unicodedata.category(c) != "Mn").replace("đ", "d").replace("Đ", "D")


# ============================================================ chi so mot bo so
def tinh(bang, hom_nay, le=()):
    lic = bang.get("License") or {}
    nam = int(_so(lic.get("NamTC"))) or hom_nay.year
    thang_dau = int(_so(lic.get("Thang"))) or 1
    if thang_dau < 1 or thang_dau > 12:
        thang_dau = 1
    kq = {"ten": ten_cty(lic), "mst": str(lic.get("MaSoThue") or "").strip(), "nam": nam, "thang_dau": thang_dau, "ghi_chu": [], "muc": XANH}
    # thang da khoa (Lock<m> le = khoa)
    khoa = [m for m in range(1, 13) if int(_so(lic.get("Lock%d" % m))) % 10 == 1]
    kq["khoa"] = khoa
    # chung tu
    theo_thang, ngay_max = {}, None
    for r in bang.get("ChungTu") or []:
        t = int(_so(r.get("ThangCT")))
        if 1 <= t <= 12:
            theo_thang[t] = theo_thang.get(t, 0) + 1
        d = _ngay(r.get("NgayCT"))
        if d and (ngay_max is None or d > ngay_max):
            ngay_max = d
    kq["ct_so"] = sum(theo_thang.values())
    kq["ct_theo_thang"] = theo_thang
    kq["ct_ngay"] = ngay_max
    # thang (duong lich) cuoi co chung tu theo thu tu nam tai chinh
    cuoi = 0
    for i in range(12):
        m = (thang_dau + i - 1) % 12 + 1
        if theo_thang.get(m):
            cuoi = m
    kq["ct_cuoi"] = cuoi
    kq["ct_thang"] = theo_thang.get(hom_nay.month, 0)
    # hoa don dien tu
    ma, chua, xem, den = set(), set(), set(), None
    for r in bang.get("HDDTTaiVe") or []:
        k = str(r.get("MaCT") or "")
        if not k:
            continue
        ma.add(k)
        d = _ngay(r.get("NgayLap"))
        if d and (den is None or d > den):
            den = d
        tt = str(r.get("AIValidationStatus") or "").upper()
        if tt == "CAN_XEM_LAI":
            xem.add(k)
        if not str(r.get("MaCTKeToan") or "").strip() and tt not in ("BO_QUA", "LOI", "CAN_XEM_LAI"):
            chua.add(k)
    kq["hddt_so"], kq["hddt_chua"], kq["hddt_xem"], kq["hddt_den"] = len(ma), len(chua), len(xem), den
    # so phu
    sp_den, sp_chua = None, 0
    for r in bang.get("HDDT_SP_Dong") or []:
        d = _ngay(r.get("NgayGD"))
        if d and (sp_den is None or d > sp_den):
            sp_den = d
        if str(r.get("TrangThai") or "").upper() not in ("DA_HACH_TOAN", "BO_QUA", "LOI"):
            sp_chua += 1
    kq["sp_den"], kq["sp_chua"], kq["sp_co"] = sp_den, sp_chua, bool(bang.get("HDDT_SP_Dong"))
    # tham so: diem san sang, soat rui ro, ky GTGT
    ts = bang.get("HDDT_ThamSo") or {}
    ky_gtgt = str(ts.get("CV_KyGTGT") or "").strip().upper()
    if ky_gtgt not in ("T", "Q"):
        ky_gtgt = "Q"
    kq["ky_gtgt"] = ky_gtgt
    ss = str(ts.get("SS152_KetQua") or "").split("|")
    kq["ss"] = {"luc": ss[0], "thang": int(_so(ss[1])), "diem": int(_so(ss[2])), "loi": int(_so(ss[3]))} if len(ss) >= 6 else None
    rr = str(ts.get("RR153_KetQua") or "").split("|")
    kq["rr"] = {"luc": rr[0], "tu": rr[1], "den": rr[2], "loi": int(_so(rr[3])), "cb": int(_so(rr[4]))} if len(rr) >= 6 else None
    # GD174: ho so kem chung tu (lan soat gan nhat) + so tep khach gui chua doc (thu muc den)
    hs = str(ts.get("YC174_KetQua") or "").split("|")
    kq["hs"] = {"luc": hs[0], "tu": hs[1], "den": hs[2], "n": int(_so(hs[3])), "thieu": int(_so(hs[4])), "cho": int(_so(hs[5])),
                "tu_khai": int(_so(hs[6]))} if len(hs) >= 7 else None
    kq["den_moi"] = int(_so(ts.get("YC174_DenMoi")))
    # to khai da nop (Cong DVC)
    da_nop = {}
    for r in bang.get("HDDT_DVC_Dong") or []:
        tt = bo_dau(r.get("TrangThai")).upper()
        if "TU CHOI" in tt or "KHONG CHAP NHAN" in tt or "KHONG TIEP NHAN" in tt:
            continue
        k = khoa_ky_chu(r.get("Ky"))
        if not k:
            continue
        td = bo_dau(r.get("TieuDe")).upper()
        for mau in ("01/GTGT", "05/KK-TNCN", "03/TNDN", "05/QTT-TNCN"):
            if mau in td:
                da_nop.setdefault((mau, k), _ngay(r.get("Ngay")))
        if "BCTC" in td or "BAO CAO TAI CHINH" in td:
            da_nop.setdefault(("BCTC", k), _ngay(r.get("Ngay")))
    kq["da_nop"] = da_nop
    # ky gan nhat + han
    k, cuoi_ky = ky_gan_nhat(ky_gtgt, nam, thang_dau, hom_nay)
    kq["ky"] = k
    kq["ky_cuoi"] = cuoi_ky
    kq["han"] = han_gtgt(k, le)
    kq["gtgt_nop"] = ("01/GTGT", k) in da_nop
    viec = []                      # (han, ten, da_nop)
    viec.append((kq["han"], "01/GTGT " + ky_chu(k), kq["gtgt_nop"]))
    if cuoi_ky >= MOC_252 or ky_gtgt != "T":
        kqu = ky_q(cuoi_ky.year, (cuoi_ky.month - 1) // 3 + 1)
        viec.append((han_gtgt(kqu, le), "05/KK-TNCN " + ky_chu(kqu), ("05/KK-TNCN", kqu) in da_nop))
    cuoi_nam = cuoi_thang(nam + (1 if thang_dau > 1 else 0), thang_dau - 1 if thang_dau > 1 else 12)
    kq["nam_qua"] = (hom_nay - cuoi_nam).days > 180          # nam tai chinh da qua lau (da quyet toan): khong xet han nop nua
    if kq["nam_qua"]:
        viec = []
    elif cuoi_nam < hom_nay:
        han_qt = ngay_lam_viec(cuoi_thang(cuoi_nam.year, cuoi_nam.month + 3), le)
        viec.append((han_qt, "Quyết toán TNDN + BCTC năm %d" % nam, ("03/TNDN", "N%d" % nam) in da_nop or ("BCTC", "N%d" % nam) in da_nop))
    chua_nop = [v for v in viec if not v[2] and v[0]]
    kq["viec"] = viec
    kq["han_gan"] = min((v[0] for v in chua_nop), default=None)
    kq["han_ten"] = next((v[1] for v in sorted(chua_nop) if v[0] == kq["han_gan"]), "")
    # muc + ghi chu
    gc, do, vang = [], False, False
    for h, ten, _ in sorted(chua_nop):
        if h < hom_nay:
            do = True
            gc.append("QUÁ HẠN %s (%s) chưa thấy nộp" % (ten, vn(h)))
        elif (h - hom_nay).days <= 5:
            do = True
            gc.append("%s hạn %s (còn %d ngày) chưa nộp" % (ten, vn(h), (h - hom_nay).days))
        elif (h - hom_nay).days <= 15:
            vang = True
            gc.append("%s hạn %s chưa nộp" % (ten, vn(h)))
    if kq["hddt_xem"]:
        do = True
        gc.append("%d hoá đơn cần xem lại (huỷ / thay thế sau hạch toán)" % kq["hddt_xem"])
    if kq["rr"] and kq["rr"]["loi"]:
        do = True
        gc.append("soát rủi ro hoá đơn còn %d lỗi" % kq["rr"]["loi"])
    if kq["ss"] and kq["ss"]["diem"] < 70 and kq["ss"]["thang"] not in khoa:
        do = True
        gc.append("điểm sẵn sàng khoá sổ tháng %d: %d/100" % (kq["ss"]["thang"], kq["ss"]["diem"]))
    if kq["hddt_chua"]:
        vang = True
        gc.append("%d hoá đơn điện tử chưa hạch toán" % kq["hddt_chua"])
    if kq["sp_chua"]:
        vang = True
        gc.append("%d dòng sổ phụ chưa hạch toán" % kq["sp_chua"])
    if kq.get("hs") and kq["hs"]["thieu"]:
        vang = True
        gc.append("khách còn nợ chứng từ: %d giao dịch thiếu (hồ sơ kèm chứng từ kỳ %s - %s)" % (kq["hs"]["thieu"], kq["hs"]["tu"], kq["hs"]["den"]))
    if kq.get("den_moi"):
        vang = True
        gc.append("%d tệp khách gửi chưa đọc (thư mục nhận chứng từ)" % kq["den_moi"])
    if cuoi_ky < hom_nay:
        thang_cuoi_ky = cuoi_ky.month
        if thang_cuoi_ky not in khoa and not kq["gtgt_nop"]:
            vang = True
            gc.append("tháng %d (kỳ gần nhất) chưa khoá" % thang_cuoi_ky)
        if cuoi and _thu_tu(cuoi, thang_dau) < _thu_tu(thang_cuoi_ky, thang_dau) and not kq["gtgt_nop"]:
            vang = True
            gc.append("chứng từ mới đến tháng %d, kỳ gần nhất đến tháng %d" % (cuoi, thang_cuoi_ky))
        if not kq["gtgt_nop"] and (not kq["rr"] or kq["rr"]["den"] < cuoi_ky.strftime("%Y-%m-%d")):
            vang = True
            gc.append("chưa soát rủi ro hoá đơn kỳ %s" % ky_chu(k))
    if kq["hddt_so"] == 0:
        gc.append("chưa tải hoá đơn điện tử")
    if kq["nam_qua"]:
        gc.insert(0, "năm tài chính %d đã qua (không xét hạn nộp)" % nam)
    kq["muc"] = DO if do else (VANG if vang else XANH)
    kq["ghi_chu"] = gc
    return kq


def _thu_tu(m, thang_dau):
    return (m - thang_dau) % 12


# ============================================================ quet thu muc
def quet(thu_mucs, sau=3):
    kq, thay = [], set()
    for goc in thu_mucs or []:
        goc = str(goc or "").strip().strip('"')
        if not goc or not os.path.isdir(goc):
            continue
        goc_sau = goc.rstrip("\\/").count(os.sep) + goc.rstrip("\\/").count("/")
        for r, ds, fs in os.walk(goc):
            muc = r.count(os.sep) + r.count("/") - goc_sau
            ds[:] = [d for d in ds if muc < sau - 1 and d.lower() not in ("sao-luu", "_to_delete", "__pycache__", "excels", "ket-qua", "htkk-sao-luu")]
            for f in fs:
                if not f.lower().endswith(".mdb"):
                    continue
                goc_ten = os.path.splitext(f)[0].upper()
                if any(goc_ten.startswith(x) for x in BO_QUA_TEN) or goc_ten.startswith("~"):
                    continue
                p = os.path.join(r, f)
                k = os.path.normcase(os.path.abspath(p))
                if k in thay:
                    continue
                thay.add(k)
                kq.append(p)
    return sorted(kq, key=lambda x: x.lower())


def lap(dl, ra_txt, ra_html=None, ghi_log=None):
    hom_nay = _ngay(dl.get("hom_nay")) or _dt.date.today()
    le = doc_ngay_nghi()
    tep = list(dl.get("tep") or []) + quet(dl.get("thu_muc") or [], int(_so(dl.get("sau")) or 3))
    dang_mo = os.path.normcase(os.path.abspath(str(dl.get("dang_mo") or ""))) if dl.get("dang_mo") else ""
    dong, loi_doc = [], 0
    thay = set()
    for p in tep:
        k = os.path.normcase(os.path.abspath(p))
        if k in thay:
            continue
        thay.add(k)
        try:
            bang = doc_bang(p)
        except Exception as e:
            loi_doc += 1
            if ghi_log:
                ghi_log("[DIEU HANH] khong doc duoc mot tep MDB: %s" % type(e).__name__)
            continue
        if bang is None:
            continue
        try:
            r = tinh(bang, hom_nay, le)
        except Exception as e:
            loi_doc += 1
            if ghi_log:
                ghi_log("[DIEU HANH] loi tinh chi so: %s" % type(e).__name__)
            continue
        r["duong"] = p
        r["dang_mo"] = (k == dang_mo)
        try:                             # GD244: hang doi viec can lam cua lan Kiem tra truoc khoa so gan nhat
            import chinh_sach_so
            import hang_doi_viec
            tm, _ = chinh_sach_so._thu_muc_ra(p, tao=False)
            tt = hang_doi_viec.doc_tom_tat(tm)
            if tt and tt["n"]:
                r["ghi_chu"].append("Việc cần làm: %d (%d lỗi) - kiểm %s, kỳ %s" % (tt["n"], tt["loi"], tt["luc"], tt["ky"]))
                if tt["loi"] and r["muc"] == XANH:
                    r["muc"] = VANG
            import do_tu_dong            # GD249: muc tu dong (do o lan kiem gan nhat)
            md = do_tu_dong.doc_tom_tat(tm)
            if md and (md["hd_tu_dong"] or md["sua_sau_ghi"]):
                r["ghi_chu"].append("Tự động: HĐ máy hạch toán %s%%, người sửa %s%%, ngưỡng %s%s" % (
                    md["hd_tu_dong"] or "?", md["sua_sau_ghi"] or "?", md["nguong"] or "?",
                    (" → đề xuất " + md["nguong_de_xuat"]) if md["nguong_de_xuat"] and md["nguong_de_xuat"] != md["nguong"] else ""))
        except Exception:
            pass
        dong.append(r)
    thu_tu = {DO: 0, VANG: 1, XANH: 2}
    dong.sort(key=lambda r: (thu_tu[r["muc"]], r["han_gan"] or _dt.date(9999, 1, 1), r["ten"].lower()))
    if ra_html is None:
        ra_html = os.path.splitext(ra_txt)[0] + ".html"
    viet_html(dong, hom_nay, ra_html, len(tep), loi_doc)
    viet_txt(dong, ra_txt, ra_html)
    return ra_txt, {"n": len(dong), "do": sum(1 for r in dong if r["muc"] == DO), "vang": sum(1 for r in dong if r["muc"] == VANG),
                    "xanh": sum(1 for r in dong if r["muc"] == XANH), "loi": loi_doc}


def _s(x, n=200):
    return str(x if x is not None else "").replace("\t", " ").replace("\r", " ").replace("\n", " ")[:n]


def viet_txt(dong, ra, ra_html):
    os.makedirs(os.path.dirname(os.path.abspath(ra)), exist_ok=True)
    out = ["TONG\t%d\t%d\t%d\t%d\t%s" % (len(dong), sum(1 for r in dong if r["muc"] == DO), sum(1 for r in dong if r["muc"] == VANG),
                                       sum(1 for r in dong if r["muc"] == XANH), _s(ra_html, 400))]
    for r in dong:
        out.append("\t".join(["B", r["muc"], _s(r["duong"], 400), _s(r["ten"], 120), _s(r["mst"], 20), str(r["nam"]), str(r["ct_cuoi"]), str(r["ct_thang"]),
                              vn(r["ct_ngay"]), vn(r["hddt_den"]), str(r["hddt_chua"]), str(r["hddt_xem"]), vn(r["sp_den"]) if r["sp_co"] else "",
                              str(r["sp_chua"]) if r["sp_co"] else "", ",".join(str(m) for m in r["khoa"]),
                              ("%d" % r["ss"]["diem"]) if r["ss"] else "", ("%d/%d" % (r["rr"]["loi"], r["rr"]["cb"])) if r["rr"] else "",
                              ky_chu(r["ky"]), "1" if r["gtgt_nop"] else "0", vn(r["han_gan"]) + ((" " + r["han_ten"]) if r["han_ten"] else ""),
                              _s("; ".join(r["ghi_chu"]), 600), "1" if r.get("dang_mo") else "0"]))
    tmp = ra + ".tmp"
    with io.open(tmp, "w", encoding="utf-8") as f:
        f.write("\n".join(out) + "\n")
    os.replace(tmp, ra)
    return ra


def viet_html(dong, hom_nay, ra, n_tep, loi_doc):
    mau = {DO: "#f8d7da", VANG: "#fff3cd", XANH: "#d4edda"}
    cot = ["Mức", "Bộ sổ", "MST", "Năm TC", "CT đến tháng", "CT tháng này", "HĐĐT đến", "HĐ chưa HT", "HĐ xem lại", "Sổ phụ đến", "SP chưa HT",
           "Đã khoá", "Điểm SS", "Rủi ro HĐ (lỗi/xem)", "Kỳ gần nhất", "01/GTGT đã nộp", "Hạn gần nhất", "Ghi chú"]
    h = ["<!DOCTYPE html><html lang='vi'><head><meta charset='utf-8'><title>Bảng điều hành khách hàng</title>",
         "<style>body{font-family:Segoe UI,Arial,sans-serif;font-size:13px;margin:16px}table{border-collapse:collapse;width:100%}",
         "th,td{border:1px solid #bbb;padding:4px 6px;vertical-align:top}th{background:#3a5c14;color:#fff;position:sticky;top:0}",
         "td.n{text-align:right;white-space:nowrap}small{color:#555}</style></head><body>",
         "<h2>Bảng điều hành khách hàng - %s</h2>" % hom_nay.strftime("%d/%m/%Y"),
         "<p>%d bộ sổ (%d đỏ, %d vàng, %d xanh)%s. Chỉ đọc; không mở, không sửa bộ sổ nào.</p>" % (
             len(dong), sum(1 for r in dong if r["muc"] == DO), sum(1 for r in dong if r["muc"] == VANG), sum(1 for r in dong if r["muc"] == XANH),
             (" - %d tệp không đọc được" % loi_doc) if loi_doc else ""),
         "<table><thead><tr>" + "".join("<th>%s</th>" % c for c in cot) + "</tr></thead><tbody>"]
    for r in dong:
        o = [TEN_MUC[r["muc"]], html.escape(r["ten"] or os.path.basename(r["duong"])) + "<br><small>%s</small>" % html.escape(r["duong"]),
             html.escape(r["mst"]), str(r["nam"]), str(r["ct_cuoi"] or ""), str(r["ct_thang"]), vn(r["hddt_den"]), str(r["hddt_chua"]), str(r["hddt_xem"]),
             vn(r["sp_den"]) if r["sp_co"] else "-", str(r["sp_chua"]) if r["sp_co"] else "-", ", ".join(str(m) for m in r["khoa"]) or "-",
             ("%d" % r["ss"]["diem"]) if r["ss"] else "-", ("%d / %d" % (r["rr"]["loi"], r["rr"]["cb"])) if r["rr"] else "-", ky_chu(r["ky"]),
             "đã nộp" if r["gtgt_nop"] else "chưa thấy", (vn(r["han_gan"]) + "<br><small>%s</small>" % html.escape(r["han_ten"])) if r["han_gan"] else "-",
             html.escape("; ".join(r["ghi_chu"]))]
        h.append("<tr style='background:%s'>" % mau[r["muc"]] + "".join("<td%s>%s</td>" % (" class='n'" if i in (3, 4, 5, 7, 8, 10, 12) else "", x)
                                                                        for i, x in enumerate(o)) + "</tr>")
    h.append("</tbody></table><p><small>Mức ĐỎ: quá hạn / sắp hạn (5 ngày) chưa nộp, hoá đơn cần xem lại, soát rủi ro còn lỗi, điểm sẵn sàng dưới 70. "
             "VÀNG: còn hoá đơn / sổ phụ chưa hạch toán, tháng kỳ gần nhất chưa khoá, chưa soát rủi ro, hạn trong 15 ngày. "
             "'Đã nộp' theo hồ sơ đã tải từ Cổng DVC vào bộ sổ. Hạn nộp tính theo quy định hiện hành (ngày nghỉ dời sang ngày làm việc).</small></p></body></html>")
    os.makedirs(os.path.dirname(os.path.abspath(ra)), exist_ok=True)
    with io.open(ra, "w", encoding="utf-8") as f:
        f.write("\n".join(h))
    return ra


def chay(duong_json, ra, ghi_log=None):
    with io.open(duong_json, "r", encoding="utf-8-sig") as f:
        dl = json.loads(f.read(), strict=False)
    return lap(dl, ra, None, ghi_log)


if __name__ == "__main__":
    import sys
    if len(sys.argv) >= 2:
        print(chay(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else os.path.join(HERE, "ket-qua", "dieu_hanh.txt")))
