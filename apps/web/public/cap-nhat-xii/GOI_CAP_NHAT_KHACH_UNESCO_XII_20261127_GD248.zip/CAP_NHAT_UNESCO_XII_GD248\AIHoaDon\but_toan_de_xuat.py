# -*- coding: utf-8 -*-
"""GD263 - GOM BUT TOAN DE XUAT CO SO TIEN va TK CU THE tu K45 (3331/133, 511/521), K57 (3387, trich truoc, du phong), K59 (632/154x)
   thanh tep AIHoaDon\\ket-qua\\but_toan_de_xuat.txt (+ ban sao thu muc cua so) de VB (ModButToanDX, menu He thong > Lap but toan de xuat)
   hien tung but toan cho ke toan duyet Yes / No roi ghi qua ClsChungtu. Dong: BT;nguon;thang;TKNo;TKCo;tien;dien giai
   Thang = thang duong lich cua but toan (K45: thang cuoi ky). Khong ghi gi vao so o day."""
import io
import os


def _s(x):
    return str(x if x is not None else "").replace(";", ",").replace("\r", " ").replace("\n", " ").strip()


def gom(kq, S):
    """-> [[nguon, thang, no, co, tien, dien giai]]"""
    out = []
    th_cuoi = (S.t2 + S.dau_ky - 2) % 12 + 1
    for k in kq or []:
        ma, dong = k.get("ma"), k.get("dong") or []
        if ma == "K45":
            for d in dong:
                if len(d) >= 4 and str(d[0]).startswith(("1.", "2.")) and float(d[3] or 0) > 0:
                    out.append(["K45", th_cuoi, d[1], d[2], round(float(d[3])), _s(d[0])])
        elif ma == "K57":
            for d in dong:
                if len(d) >= 6 and float(d[4] or 0) > 0:
                    out.append(["K57", int(d[0]), d[2], d[3], round(float(d[4])), _s(d[1])])
        elif ma == "K59":
            for d in dong:
                if len(d) >= 8 and isinstance(d[6], (int, float)) and d[6] > 1000:
                    out.append(["K59", th_cuoi, "632", d[0], round(float(d[6])), _s("Ket chuyen gia von cong trinh %s theo %% hoan thanh" % d[1])])
    return out


def ghi(kq, S, thu_mucs):
    ds = gom(kq, S)
    for tm in thu_mucs:
        if not tm:
            continue
        try:
            os.makedirs(tm, exist_ok=True)
            with io.open(os.path.join(tm, "but_toan_de_xuat.txt"), "w", encoding="utf-8") as f:
                f.write("SO;%d\n" % len(ds))
                for d in ds:
                    f.write("BT;%s;%d;%s;%s;%d;%s\n" % (d[0], d[1], _s(d[2]), _s(d[3]), d[4], d[5]))
        except Exception:
            pass
    return ds
