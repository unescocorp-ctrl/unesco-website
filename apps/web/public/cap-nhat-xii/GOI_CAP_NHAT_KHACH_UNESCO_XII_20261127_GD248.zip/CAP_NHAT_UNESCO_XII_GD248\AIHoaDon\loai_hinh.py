# -*- coding: utf-8 -*-
"""GD243 - LOAI HINH DOANH NGHIEP LA THAM SO (lo trinh muc 9).
  Tu nhan loai hinh tu so lieu (co the nhieu loai cung luc): THUONG_MAI, SAN_XUAT, DICH_VU, XAY_DUNG, XNK.
  Ghi de bang tep tham so: AIHoaDon\\ket-qua\\chinh-sach\\<so>\\loai_hinh.txt (mot dong, vi du "XAY_DUNG, DICH_VU"),
  hoac dl["loai_hinh"] neu VB gui.
  K52 (THONG_TIN): loai hinh dang ap dung + can cu.
  K53: bat bien rieng theo loai hinh:
    THUONG_MAI  - thang co gia von (No 632) lon hon doanh thu ban hang (Co 511 thuan) -> CANH_BAO (ban duoi gia von / thieu doanh thu)
    DICH_VU     - 3387 doanh thu chua thuc hien con du Co ma khong ket chuyen (No 3387 = 0) trong ky -> CANH_BAO
    XAY_DUNG    - thang co doanh thu nhung khong ket chuyen chi phi cong trinh (Co 154 = 0) trong khi 154 con du -> CANH_BAO
    XNK         - 1562 chi phi mua hang con du cuoi ky -> CANH_BAO; TK ngoai te (1112, 1122) con du ma ky den thang cuoi nam
                  khong co danh gia chenh lech ty gia (No/Co 413) -> CANH_BAO
    SAN_XUAT    - da kiem o cong G6 (K21 - K28, K47 - K49).
  Chi doc, khong sua so lieu.
"""
import io
import os

LOAI = ("THUONG_MAI", "SAN_XUAT", "DICH_VU", "XAY_DUNG", "XNK")
TEN = {"THUONG_MAI": "Thương mại", "SAN_XUAT": "Sản xuất", "DICH_VU": "Dịch vụ", "XAY_DUNG": "Xây dựng / lắp đặt", "XNK": "Xuất nhập khẩu"}


def _ps(S, tien_to, t=None):
    """(No, Co) trong ky (t=None) hoac thang t (thu tu nam TC) cua TK la bat dau bang tien_to, KHONG tinh phan ket chuyen 911."""
    n = c = 0.0
    for m in S.la_theo(tien_to):
        p = S.ps.get(m) if hasattr(S.ps, "get") else None
        if not p:
            continue
        for k, x in p["thang"].items():
            if (t is None and S.t1 <= k <= S.t2) or k == t:
                n += x[0]
                c += x[1]
    return n, c


def _du(S, tien_to):
    return sum(S.du_cuoi(m) for m in S.la_theo(tien_to))


def doc_tham_so(S, duong=None):
    """loai hinh khai tay: dl['loai_hinh'] (VB) hoac tep loai_hinh.txt. -> list hoac None"""
    v = S.dl.get("loai_hinh")
    if not v and duong and os.path.isfile(duong):
        try:
            with io.open(duong, encoding="utf-8-sig") as f:
                v = f.read()
        except Exception:
            v = None
    if not v:
        return None
    if isinstance(v, (list, tuple)):
        v = ",".join(str(x) for x in v)
    ds = [x.strip().upper().replace(" ", "_") for x in str(v).replace(";", ",").split(",")]
    ds = [x for x in ds if x in LOAI]
    return ds or None


def tu_nhan(S):
    """-> [(loai, can cu)] theo so lieu trong ky."""
    kq = []
    gt = (S.dl.get("gt") or {}).get("phieu") or []
    n621, _ = _ps(S, "621")
    n154, c154 = _ps(S, "154")
    _, c155 = _ps(S, "155")
    n632, _ = _ps(S, "632")
    _, c5111 = _ps(S, "5111")
    _, c5113 = _ps(S, "5113")
    _, c511 = _ps(S, "511")
    _, c156 = _ps(S, "156")
    if gt or (n154 > 0 and c155 > 0):
        kq.append(("SAN_XUAT", "Có phiếu kết chuyển thành phẩm / xuất kho 155"))
    if c156 > 0 and n632 > 0:
        kq.append(("THUONG_MAI", "Có xuất kho hàng hóa 156 và giá vốn"))
    if c511 > 0 and c5113 >= 0.5 * c511 and c156 <= 0 and c155 <= 0:
        kq.append(("DICH_VU", "Doanh thu dịch vụ (5113) chiếm %d%% doanh thu" % round(100 * c5113 / c511)))
    if S.la_theo("3387") and abs(_du(S, "3387")) > 1:
        if not any(k == "DICH_VU" for k, _ in kq):
            kq.append(("DICH_VU", "Có doanh thu chưa thực hiện (3387)"))
    # xay dung: 154 nhieu TK chi tiet (theo cong trinh) hoac 154 nhan chi phi khong co phieu ket chuyen thanh pham ma Co 154 -> 632
    if not gt and n154 > 0 and (len(S.la_theo("154")) >= 3 or c154 > 0) and c155 <= 0:
        kq.append(("XAY_DUNG", "154 tập hợp chi phí (%d TK chi tiết), không qua thành phẩm 155" % len(S.la_theo("154"))))
    n1562, _ = _ps(S, "1562")
    nt = [m for m in S.la_theo("1112", "1122") if abs(S.du_cuoi(m)) > 1 or sum(_ps(S, S.tk[m]["sh"])) > 0]
    if n1562 > 0 or nt:
        kq.append(("XNK", "Có %s" % ", ".join(x for x in ("chi phí mua hàng 1562" if n1562 > 0 else "", "tiền ngoại tệ 1112 / 1122" if nt else "") if x)))
    if not kq and c511 > 0:
        kq.append(("THUONG_MAI", "Mặc định (có doanh thu, không nhận ra loại khác)"))
    return kq


def _thang_dl(S, t):
    return (t + S.dau_ky - 2) % 12 + 1


def bat_bien(S, loai):
    """-> [[Loại hình, Tháng / Kỳ, Tài khoản, Số liệu, Vấn đề, Cách xử lý]]"""
    dong = []
    if "THUONG_MAI" in loai:
        for t in range(S.t1, S.t2 + 1):
            n632, c632 = _ps(S, "632", t)
            n511, c511 = _ps(S, "511", t)
            n521, c521 = _ps(S, "521", t)
            gv, dt = n632 - c632, c511 - n511 - (n521 - c521)
            if gv > 1 and gv > dt * 1.0 + 1:
                dong.append([TEN["THUONG_MAI"], _thang_dl(S, t), "632 / 511", "Giá vốn %s > doanh thu thuần %s" % (_d(gv), _d(dt)),
                             "Bán dưới giá vốn hoặc thiếu hóa đơn bán ra / giá xuất kho sai", "Xem Kiểm tra giá vốn - giá bán theo mặt hàng"])
    if "DICH_VU" in loai and S.la_theo("3387"):
        du = _du(S, "3387")
        n3387, _ = _ps(S, "3387")
        if du < -1 and n3387 <= 0:
            dong.append([TEN["DICH_VU"], "Cả kỳ", "3387", "Dư Có %s, không kết chuyển trong kỳ" % _d(-du),
                         "Doanh thu chưa thực hiện không phân bổ theo kỳ cung cấp dịch vụ", "Lập bút toán Nợ 3387 / Có 511 theo hợp đồng"])
    if "XAY_DUNG" in loai:
        du154 = _du(S, "154")
        for t in range(S.t1, S.t2 + 1):
            _, c511 = _ps(S, "511", t)
            _, c154 = _ps(S, "154", t)
            if c511 > 1 and c154 <= 0 and du154 > 1:
                dong.append([TEN["XAY_DUNG"], _thang_dl(S, t), "511 / 154", "Doanh thu %s, Có 154 = 0" % _d(c511),
                             "Ghi nhận doanh thu (nghiệm thu) nhưng chưa kết chuyển giá vốn công trình", "Kết chuyển 154 → 632 theo công trình đã nghiệm thu"])
    if "XNK" in loai:
        d1562 = _du(S, "1562")
        if abs(d1562) > 1:
            dong.append([TEN["XNK"], "Cuối kỳ", "1562", "Dư %s" % _d(d1562), "Chi phí mua hàng (logistic) chưa phân bổ hết vào hàng nhập / giá vốn",
                         "Phân bổ 1562 theo hàng đã nhập / đã bán"])
        if S.t2 >= 12:
            n413, c413 = _ps(S, "413")
            for m in S.la_theo("1112", "1122"):
                if abs(S.du_cuoi(m)) > 1 and n413 + c413 <= 0:
                    dong.append([TEN["XNK"], "Cuối năm", S.tk[m]["sh"], "Dư %s" % _d(S.du_cuoi(m)),
                                 "Chưa đánh giá lại số dư ngoại tệ cuối năm (413)", "Đánh giá lại theo tỷ giá chuyển khoản ngày cuối năm, kết chuyển 413 → 515 / 635"])
    return dong


def _d(x):
    return "{:,.0f}".format(x).replace(",", ".")


def k_loai_hinh(S, _kq, DAT, CANH_BAO, LOI, THONG_TIN, tep_tham_so=None):
    if tep_tham_so is None:
        try:
            import chinh_sach_so
            duong = S.dl.get("duong_so") or ""
            if duong:
                tm, _ = chinh_sach_so._thu_muc_ra(duong)
                tep_tham_so = os.path.join(tm, "loai_hinh.txt")
        except Exception:
            tep_tham_so = None
    khai = doc_tham_so(S, tep_tham_so)
    nhan = tu_nhan(S)
    if khai:
        loai = khai
        cc = "Khai tay (%s): %s. Máy tự nhận: %s." % (tep_tham_so or "VB", ", ".join(TEN[x] for x in khai),
                                                     ", ".join("%s (%s)" % (TEN[k], c) for k, c in nhan) or "không rõ")
    else:
        loai = [k for k, _ in nhan]
        cc = "Máy tự nhận: %s." % ("; ".join("%s - %s" % (TEN[k], c) for k, c in nhan) or "chưa đủ số liệu")
        if tep_tham_so:
            cc += " Muốn khai cố định: ghi vào tệp %s một dòng, ví dụ: XAY_DUNG, DICH_VU (các mã: %s)." % (tep_tham_so, ", ".join(LOAI))
    kq = [_kq("K52", "Loại hình doanh nghiệp đang áp dụng cho kiểm tra", THONG_TIN, cc)]
    if not loai:
        return kq
    dong = bat_bien(S, loai)
    ten = "Bất biến riêng theo loại hình (%s)" % ", ".join(TEN[x] for x in loai)
    if dong:
        kq.append(_kq("K53", ten, CANH_BAO, "%d trường hợp không thỏa bất biến riêng của loại hình." % len(dong),
                      ["Loại hình", "Tháng / kỳ", "Tài khoản", "Số liệu", "Vấn đề", "Cách xử lý"], dong))
    else:
        kq.append(_kq("K53", ten, DAT, "Thỏa các bất biến riêng của loại hình%s." % (" (sản xuất kiểm ở cổng giá thành K21 - K28, K47 - K49)" if "SAN_XUAT" in loai else "")))
    return kq
