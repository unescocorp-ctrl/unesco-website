# -*- coding: utf-8 -*-
"""Kiem cau noi VB.NET <-> Python cua UNESCO XII (Dot 0).

Di dung duong cua moi tool UNESCO XI:
  * nhan tham so qua /thamso:"<tep UTF-8>" (tham_so_du_phong.bu_tham_so nhan tep, doi ten *_dung.txt);
  * ghi ket qua <out>\\ket-qua\\kiem_cau_noi_<ts>.jsonl (ghi .tmp roi os.replace);
  * ghi moc <out>\\ket-qua\\DA_XONG_KIEM dong dau "OK <tep>" hoac "LOI <ly do>".
Chi doc tham so, khong doc so, khong ghi gi ngoai thu muc ket-qua. Dung de ban VB.NET chung minh
duong tham so / Unicode / moc da chay dung truoc khi chuyen cac tool that."""
import io
import json
import os
import platform
import sys
import time
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TEN_MOC = "DA_XONG_KIEM"


def _tach_dong_lenh(s):
    """Tach chuoi tham so theo khoang trang, giu nguyen phan trong dau nhay kep (giong mo_rong_tham_so)."""
    ra, hien, trong_nhay = [], [], False
    for ch in s:
        if ch == '"':
            trong_nhay = not trong_nhay
        elif ch.isspace() and not trong_nhay:
            if hien:
                ra.append("".join(hien))
                hien = []
        else:
            hien.append(ch)
    if hien:
        ra.append("".join(hien))
    return ra


def mo_rong_tham_so(argv):
    out, tu_tep = [], ""
    for a in argv:
        s = str(a).strip()
        if s.lower().startswith("/thamso:"):
            duong = s.split(":", 1)[1].strip().strip('"')
            with io.open(duong, "r", encoding="utf-8-sig") as f:
                out.extend(_tach_dong_lenh(f.read()))
            tu_tep = duong
        else:
            out.append(s)
    return out, tu_tep


def doc_tham_so(argv):
    ts = {}
    for a in argv:
        if not a.startswith("/"):
            continue
        if ":" in a:
            k, v = a[1:].split(":", 1)
        else:
            k, v = a[1:], "1"
        ts[k.lower().strip()] = v.strip().strip('"')
    return ts


def ghi_nhat_ky(dong):
    try:
        with io.open(os.path.join(BASE_DIR, "nhat-ky-kiem.txt"), "a", encoding="utf-8") as f:
            f.write(datetime.now().strftime("%d/%m/%Y %H:%M:%S ") + dong + "\n")
    except Exception:
        pass


def ghi_moc(kq, noi_dung):
    os.makedirs(kq, exist_ok=True)
    tam = os.path.join(kq, TEN_MOC + ".tmp")
    with io.open(tam, "w", encoding="utf-8") as f:
        f.write(noi_dung)
    os.replace(tam, os.path.join(kq, TEN_MOC))


def main():
    argv = sys.argv[1:]
    try:
        import tham_so_du_phong
        argv = tham_so_du_phong.bu_tham_so(sys.argv, BASE_DIR, phai_co=("/kiem:",))[1:]
    except Exception as e:          # thieu tham_so_du_phong.py thi van chay bang tham so tren dong lenh
        ghi_nhat_ky("khong dung tham_so_du_phong: %s" % e)
    kq = os.path.join(BASE_DIR, "ket-qua")
    try:
        argv, tu_tep = mo_rong_tham_so(argv)
        ts = doc_tham_so(argv)
        out = ts.get("out") or BASE_DIR
        kq = os.path.join(out, "ket-qua")
        os.makedirs(kq, exist_ok=True)
        ten = "kiem_cau_noi_%s.jsonl" % datetime.now().strftime("%Y%m%d%H%M%S")
        duong = os.path.join(kq, ten)
        dong = {
            "loai": "KIEM_CAU_NOI",
            "python": platform.python_version(),
            "thu_muc_tool": BASE_DIR,
            "thamso_tu_tep": tu_tep,
            "mst": ts.get("mst", ""),
            "unesco": ts.get("unesco", ""),
            "out": out,
            "luu": ts.get("luu", ""),
            "chu": ts.get("chu", ""),
            "so_tham_so": len(ts),
            "thoi_gian": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }
        tam = duong + ".tmp"
        with io.open(tam, "w", encoding="utf-8") as f:
            f.write(json.dumps(dong, ensure_ascii=False) + "\n")
        os.replace(tam, duong)
        if ts.get("cham"):
            time.sleep(float(ts["cham"]))
        ghi_moc(kq, "OK " + duong)
        ghi_nhat_ky("OK " + duong)
        return 0
    except Exception as e:
        try:
            ghi_moc(kq, "LOI " + str(e))
        except Exception:
            pass
        ghi_nhat_ky("LOI " + str(e))
        return 1


if __name__ == "__main__":
    sys.exit(main())
