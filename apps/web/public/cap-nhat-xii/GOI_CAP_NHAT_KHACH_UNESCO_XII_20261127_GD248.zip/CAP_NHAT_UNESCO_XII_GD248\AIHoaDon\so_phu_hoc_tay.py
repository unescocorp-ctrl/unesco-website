# -*- coding: utf-8 -*-
"""GD363 - SO PHU: HOC QUY TAC TU SO TAY (dung chung moi bo so) + de xuat cho dong sao ke chua ghi.
May CHI DOC so (.MDB qua jet_doc). Khong doan: moi quy tac deu lay tu chinh bo so (chung tu 112x da ghi tay cac thang truoc)
hoac tu he thong tai khoan cua so; khong co can cu -> de nguoi.

Hoc duoc tu so tay (bang ChungTu, TK 112x, MaLoai 0):
  - tai khoan 112 con cho tung so TK ngan hang (HDDT_SP_TaiKhoanNH.TK112 la TK tong -> chon TK con theo ten / so TK)
  - tien to so hieu chung tu theo tung TK ngan hang (NH08dd nn, MB08dd nn ...)
  - mau dien giai theo (chieu, TK doi ung) - lay mau pho bien nhat
  - ty le tach BHXH / BHYT / BHTN khi nop (tu chung tu nop BH da ghi), mac dinh 25.5 : 4.5 : 2
  - TK 'phai thu khac' (hoan tien chuyen nham), TK phi ngan hang, lai tien gui, nop tien mat - theo chung tu da ghi, neu chua co thi theo HDDT_QuyTac
Tieu chi dac thu tung bo so: them vao HDDT_SP_TuKhoa (tu khoa -> nhom, TK) nhu truoc; module nay chi bo sung khi so tay da lam.

Ket qua: ket-qua\\sp_hoc_tay.txt
  H;ten so
  QT;loai;khoa;gia tri;can cu                                  (quy tac hoc duoc - de xem / ghi nhat ky)
  SP;MaSo dong;TK doi ung;Ma KH (SoHieu);tin cay;nhom;goi y;tach   (de xuat tung dong sao ke chua ghi)
  SD;MaSo dong;OK|LECH                                          (kiem lai so du theo thu tu trong ngay)
"""
import io
import os
import re
from collections import Counter, defaultdict

import jet_doc

TEP = "sp_hoc_tay"
TIEU_MUC_KBNN = {"1052": "THUE_TNDN", "1053": "THUE_TNDN", "1701": "THUE_GTGT", "1702": "THUE_GTGT", "1001": "THUE_TNCN", "1003": "THUE_TNCN", "1004": "THUE_TNCN",
                 "1901": "THUE_NK", "1902": "THUE_NK", "1903": "THUE_NK", "2862": "THUE_KHAC", "2863": "THUE_KHAC", "2864": "THUE_KHAC", "1601": "THUE_KHAC", "1602": "THUE_KHAC",
                 "4917": "CHAM_NOP", "4918": "CHAM_NOP", "4931": "CHAM_NOP", "4944": "CHAM_NOP"}          # tieu muc ngan sach -> khoa TK hoc duoc
TY_LE_BH_MAC_DINH = (25.5, 4.5, 2.0)          # BHXH 17.5+8, BHYT 3+1.5, BHTN 1+1 (ca DN + NV)


def _s(x):
    return str(x if x is not None else "").strip()


def _vang(x):
    t = _s(x)
    return "" if t in ("...", "0") else t


def _f(x):
    try:
        return float(x or 0)
    except Exception:
        return 0.0


def _i(x):
    try:
        return int(float(x or 0))
    except Exception:
        return 0


def bo_dau(s):
    import unicodedata
    s = str(s or "").replace("Đ", "D").replace("đ", "d")
    return "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")


def _nd(s):
    return re.sub(r"\s+", " ", bo_dau(s).upper()).strip()


def _vni_u(s):
    try:
        import bang_luong_gd78 as BL
        return BL.khoa_ten(s)
    except Exception:
        return _nd(s)


def doc_bang(duong):
    m = jet_doc.Mdb(duong)
    try:
        b = {k.lower(): k for k in m.bang()}

        def tb(t):
            k = b.get(t.lower())
            return m.doc(k) if k else []
        return {t: tb(t) for t in ("ChungTu", "HeThongTK", "KhachHang", "HDDT_SP_Dong", "HDDT_SP_TaiKhoanNH", "HDDT_QuyTac", "License")}
    finally:
        try:
            m.dong()
        except Exception:
            pass


# ------------------------------------------------------------------ 1. hoc tu so tay
def hoc(B):
    tk = {r["MaSo"]: _s(r.get("SoHieu")) for r in B["HeThongTK"]}
    ten_tk = {_s(r.get("SoHieu")): _vni_u(r.get("Ten")) for r in B["HeThongTK"]}
    con_tk = {_s(r.get("SoHieu")): _i(r.get("TKCon")) for r in B["HeThongTK"]}
    qt = (B["HDDT_QuyTac"] or [{}])[0]
    Q = {"tk_112": {}, "tien_to": {}, "dien_giai": {}, "ty_le_bh": None, "tk": {}, "can_cu": []}
    # 1a. TK 112 con cho tung so TK ngan hang
    for r in B["HDDT_SP_TaiKhoanNH"]:
        goc, stk, nh = _s(r.get("TK112")), _s(r.get("SoTKNH")), _nd(r.get("NganHang"))
        chon, cc = goc, "theo khai bao"
        if con_tk.get(goc, 0) == 1 or not goc:
            ung = [s for s in ten_tk if s.startswith(goc or "112") and len(s) > len(goc or "112") and con_tk.get(s, 0) == 0]
            theo_so = [s for s in ung if stk and stk in ten_tk[s]]
            theo_ten = [s for s in ung if nh and (ten_tk[s].startswith(nh) or nh.startswith(ten_tk[s].split(" ")[0]) and len(ten_tk[s].split(" ")[0]) >= 2)]
            if len(theo_so) == 1:
                chon, cc = theo_so[0], "ten TK chua so tai khoan"
            elif len(theo_ten) == 1:
                chon, cc = theo_ten[0], "ten TK trung ma ngan hang"
            else:
                cc = "TK tong co nhieu TK con, khong xac dinh duoc"
        Q["tk_112"][stk] = (chon, cc)
        Q["can_cu"].append(("TK112", stk, chon, cc))
    # 1b. chung tu ngan hang da ghi tay
    dg = defaultdict(Counter)
    tien_to = defaultdict(Counter)
    bh = defaultdict(dict)
    tk_dung = defaultdict(Counter)
    tk_nh_dung = set()
    for r in B["ChungTu"]:
        if _i(r.get("MaLoai")) != 0:
            continue
        n, c = tk.get(r.get("MaTKNo"), ""), tk.get(r.get("MaTKCo"), "")
        if not (n.startswith("112") or c.startswith("112")):
            continue
        sh = _s(r.get("SoHieu"))
        tk_nh = n if n.startswith("112") else c
        tk_nh_dung.add(tk_nh)
        chieu = "VAO" if n.startswith("112") else "RA"
        doi = c if chieu == "VAO" else n
        m = re.match(r"^([A-Z]{1,4})(\d{2})(\d{2})(\d{2,3})$", sh)
        if m and _i(m.group(2)) == _i(r.get("ThangCT")):
            tien_to[tk_nh][m.group(1)] += 1
        if doi:
            dg[(chieu, doi[:4])][_s(r.get("DienGiai")).strip()] += 1
            tk_dung[(chieu, doi[:3])][doi] += 1
        if chieu == "RA" and doi[:3] == "338" and doi[:4] != "3382":
            bh[sh][doi] = bh[sh].get(doi, 0) + _f(r.get("SoPS"))
    # chung tu chi phi luong gan nhat (Co 334x, khong qua 112): ty le theo bo phan
    cp_luong = defaultdict(lambda: defaultdict(float))
    for r in B["ChungTu"]:
        c = tk.get(r.get("MaTKCo"), "")
        n = tk.get(r.get("MaTKNo"), "")
        if c.startswith("334") and not n.startswith("112") and _f(r.get("SoPS")) > 0:
            cp_luong[_i(r.get("ThangCT"))][c] += _f(r.get("SoPS"))
    if cp_luong:
        th = max(cp_luong)
        Q["luong_bo_phan"] = dict(cp_luong[th])
        Q["can_cu"].append(("LUONG_BO_PHAN", "thang %d" % th, " / ".join("%s %d" % (k, v) for k, v in sorted(cp_luong[th].items())), "chung tu luong gan nhat"))
    for tk_nh, c in tien_to.items():
        Q["tien_to"][tk_nh] = c.most_common(1)[0][0]
        Q["can_cu"].append(("TIEN_TO", tk_nh, c.most_common(1)[0][0], "%d chung tu" % c.most_common(1)[0][1]))
    for k, c in dg.items():
        Q["dien_giai"][k] = c.most_common(1)[0][0]
    # bao hiem: TK 338x theo TEN (xa hoi / y te / that nghiep) - so TT133 co the dung 3386 cho BHTN; ty le hoc tu chung tu nop BH da ghi
    def tk_bh(tu, mac_dinh):
        ds = [s for s, t in ten_tk.items() if s.startswith("338") and con_tk.get(s, 0) == 0 and tu in t]
        return ds[0] if len(ds) == 1 else (mac_dinh if mac_dinh in ten_tk else "")
    Q["tk_bh"] = (tk_bh("XA HOI", _s(qt.get("SP_TKBHXH")) or "3383"), tk_bh("Y TE", _s(qt.get("SP_TKBHYT")) or "3384"), tk_bh("THAT NGHIEP", _s(qt.get("SP_TKBHTN")) or "3385"))
    ds_bh = [v for v in bh.values() if len([k for k in v if k in Q["tk_bh"]]) == 3]
    if ds_bh:
        v = ds_bh[-1]
        t = sum(v[k] for k in Q["tk_bh"])
        Q["ty_le_bh"] = tuple(v[k] / t * 32 for k in Q["tk_bh"])
        Q["can_cu"].append(("TY_LE_BH", ":".join(Q["tk_bh"]), "%.2f:%.2f:%.2f" % Q["ty_le_bh"], "tu %d chung tu nop BH da ghi" % len(ds_bh)))
    else:
        Q["ty_le_bh"] = TY_LE_BH_MAC_DINH
        Q["can_cu"].append(("TY_LE_BH", ":".join(Q["tk_bh"]), "25.5:4.5:2", "mac dinh (so chua co chung tu nop BH)"))

    def chon_tk(ten, chieu, goc3, mac_dinh):
        c = Counter()
        for (ch, g3), cc in tk_dung.items():
            if ch == chieu and g3 == goc3[:3]:
                for t, n in cc.items():
                    if t.startswith(goc3):
                        c[t] += n
        if c:
            Q["can_cu"].append((ten, goc3, c.most_common(1)[0][0], "%d chung tu da ghi" % c.most_common(1)[0][1]))
            return c.most_common(1)[0][0]
        Q["can_cu"].append((ten, goc3, mac_dinh, "theo Quy tac hach toan"))
        return mac_dinh
    Q["tk"]["PHI"] = chon_tk("TK_PHI_NH", "RA", "642", _s(qt.get("SP_TKPhiNH")) or "6422")
    Q["tk"]["LAI"] = chon_tk("TK_LAI_TG", "VAO", "515", _s(qt.get("SP_TKLaiTG")) or "515")
    Q["tk"]["THU_KH"] = chon_tk("TK_THU_KH", "VAO", "131", "1311")
    Q["tk"]["CHI_NCC"] = chon_tk("TK_CHI_NCC", "RA", "331", "3311")
    Q["tk"]["TIEN_MAT"] = chon_tk("TK_TIEN_MAT", "VAO", "111", _s(qt.get("SP_TKTienMat")) or "1111")
    Q["tk"]["KPCD"] = chon_tk("TK_KPCD", "RA", "3382", _s(qt.get("SP_TKKPCD")) or "3382")
    Q["tk"]["LAI_VAY"] = chon_tk("TK_LAI_VAY", "RA", "635", _s(qt.get("SP_TKLaiVay")) or "635")
    Q["tk"]["VAY_RA"] = chon_tk("TK_TRA_NO_VAY", "RA", "341", _s(qt.get("SP_TKVay")) or "341")
    Q["tk"]["VAY_VAO"] = chon_tk("TK_GIAI_NGAN", "VAO", "341", Q["tk"]["VAY_RA"])
    Q["tk"]["RUT_TM"] = chon_tk("TK_RUT_TIEN_MAT", "RA", "111", Q["tk"]["TIEN_MAT"])
    Q["tk"]["THUE_GTGT"] = chon_tk("TK_NOP_GTGT", "RA", "3331", _s(qt.get("SP_TKThueGTGT")) or "33311")
    Q["tk"]["THUE_TNDN"] = chon_tk("TK_NOP_TNDN", "RA", "3334", _s(qt.get("SP_TKThueTNDN")) or "3334")
    Q["tk"]["THUE_TNCN"] = chon_tk("TK_NOP_TNCN", "RA", "3335", _s(qt.get("SP_TKThueTNCN")) or "3335")
    Q["tk"]["THUE_NK"] = chon_tk("TK_NOP_THUE_NK", "RA", "3333", "3333")
    Q["tk"]["THUE_KHAC"] = chon_tk("TK_NOP_THUE_KHAC", "RA", "3338", _s(qt.get("SP_TKThueKhac")) or "3338")
    Q["tk"]["TAM_UNG"] = chon_tk("TK_TAM_UNG", "RA", "141", _s(qt.get("SP_TKTamUng")) or "141")
    # chuyen noi bo giua cac TK ngan hang cua minh: TK 112 con dang dung trong so
    Q["tk_112_dung"] = sorted(tk_nh_dung | {v[0] for v in Q["tk_112"].values() if v[0]})
    for r in B["ChungTu"]:
        n, c = tk.get(r.get("MaTKNo"), ""), tk.get(r.get("MaTKCo"), "")
        if n.startswith("112") and c.startswith("112") and n != c:
            Q["tk_112_dung"] = sorted(set(Q["tk_112_dung"]) | {n, c})
    lic = (B.get("License") or [{}])[0]
    Q["ten_cty"] = _vni_u(lic.get("TenCty"))
    Q["so_tk_minh"] = {_s(r.get("SoTKNH")): v[0] for r, v in ((r, Q["tk_112"].get(_s(r.get("SoTKNH")), ("", ""))) for r in B["HDDT_SP_TaiKhoanNH"]) if _s(r.get("SoTKNH"))}
    # hoan tien chuyen nham: TK 3388x / 1388x so tay da dung, neu chua thi TK co ten 'PHAI THU KHAC'
    da_dung = Counter()
    for (ch, g3), cc in tk_dung.items():
        for t, n in cc.items():
            if t.startswith(("3388", "1388")):
                da_dung[t] += n
    ptk = [s for s, t in ten_tk.items() if s.startswith(("3388", "1388")) and "PHAI THU KHAC" in t and con_tk.get(s, 0) == 0]
    if da_dung:
        Q["tk"]["HOAN_TIEN"] = da_dung.most_common(1)[0][0]
        Q["can_cu"].append(("TK_HOAN_TIEN", "3388/1388", Q["tk"]["HOAN_TIEN"], "%d chung tu da ghi" % da_dung.most_common(1)[0][1]))
    else:
        Q["tk"]["HOAN_TIEN"] = ptk[0] if len(ptk) == 1 else (_s(qt.get("SP_TKKhac")) or "1388")
        Q["can_cu"].append(("TK_HOAN_TIEN", "3388/1388", Q["tk"]["HOAN_TIEN"], "TK co ten 'Phai thu khac'" if len(ptk) == 1 else "theo Quy tac hach toan"))
    cham = [s for s, t in ten_tk.items() if s.startswith("3338") and "CHAM NOP" in t]
    Q["tk"]["CHAM_NOP"] = cham[0] if len(cham) == 1 else "3338"
    Q["co_711"] = any(ch == "VAO" and g3 == "711" for (ch, g3) in tk_dung)          # so tay co tach phan le sang 711
    if Q["co_711"]:
        Q["can_cu"].append(("TACH_711", "VAO", "711", "so tay ghi phan le khach tra thua vao 711 - may chi nhac"))
    Q["ten_tk"] = ten_tk
    Q["tk_ds"] = set(ten_tk)
    # TK mac dinh la TK tong (515, 1388...) ma so chi co TK con -> lay TK con duy nhat (hoac con dau tien theo so hieu)
    for k, v in list(Q["tk"].items()):
        if v and (v not in ten_tk or con_tk.get(v, 0) == 1):
            con = sorted(x for x in ten_tk if x.startswith(v) and len(x) > len(v) and con_tk.get(x, 0) == 0)
            if con:
                Q["tk"][k] = con[0]
                Q["can_cu"].append(("TK_CON", v, con[0], "TK tong -> TK con" + (" duy nhat" if len(con) == 1 else " dau tien")))
    return Q


# ------------------------------------------------------------------ 2. de xuat cho dong sao ke
def _tach_bh(tien, ty_le, tk_bh=("3383", "3384", "3385")):
    t = sum(ty_le)
    a = round(tien * ty_le[0] / t)
    b = round(tien * ty_le[1] / t)
    return [(tk_bh[0], a), (tk_bh[1], b), (tk_bh[2], round(tien) - a - b)]


def de_xuat_dong(Q, d, kh_theo_mst, kh_theo_so):
    """d = dong HDDT_SP_Dong. Tra (tk, ma_kh, tin_cay, nhom, goi_y, tach) hoac None (de nguoi)."""
    nd = _nd(d.get("NoiDung"))
    vao, ra = _f(d.get("TienVao")), _f(d.get("TienRa"))
    chieu = "VAO" if vao > 0 else "RA"
    tien = vao if vao > 0 else ra
    tk_hien = _s(d.get("TKDoiUng"))
    ma_kh = _s(d.get("MaKH"))
    # 1. ro rang theo noi dung
    if chieu == "RA" and re.search(r"\bPHI\b", nd) and tien <= 500000:
        return (Q["tk"]["PHI"], "", 96, "PHI_NH", "phi ngan hang (so tay: %s)" % Q["dien_giai"].get(("RA", Q["tk"]["PHI"][:4]), ""), "")
    if chieu == "VAO" and re.search(r"\b(LAI|LAI TK|TRA LAI|CHI LAI|LAI NHAP)\b", nd) and tien < 5000000:
        return (Q["tk"]["LAI"], "", 96, "LAI_TG", "lai tien gui", "")
    if chieu == "VAO" and re.search(r"NOP (TM|TIEN MAT)|NOP TM TK", nd):
        return (Q["tk"]["TIEN_MAT"], "", 95, "TIEN_MAT", "nop tien mat vao tai khoan", "")
    if chieu == "RA" and re.search(r"BHXH|BAO HIEM XA HOI|BHYT", nd):
        tk_bh = Q.get("tk_bh") or ("3383", "3384", "3385")
        if all(tk_bh):
            tach = _tach_bh(tien, Q["ty_le_bh"], tk_bh)
            return (tk_bh[0], "", 92, "BHXH", "nop BHXH - tach 3 TK theo ty le so tay", " / ".join("%s %d" % x for x in tach))
        return None
    if chieu == "RA" and re.search(r"CONG DOAN|CDCS|KPCD|KINH PHI CD", nd):
        return (Q["tk"]["KPCD"], "", 93, "KPCD", "nop kinh phi cong doan", "")
    m = re.search(r"\bTM:(\d{4})\b", nd)
    if chieu == "RA" and ("KBNN" in nd or "NTDT" in nd) and m:
        tm = m.group(1)
        tk_t = Q["tk"].get(TIEU_MUC_KBNN.get(tm, ""), "")
        if tk_t and tk_t in Q["tk_ds"]:
            return (tk_t, "", 94, "THUE", "nop ngan sach, tieu muc %s" % tm, "")
        return None
    if chieu == "RA" and re.search(r"\bLUONG\b|TIEN LUONG", nd):
        # so tay chia theo bo phan (3341/3342/3343) theo bang luong - may khong tu chia, chi goi y ty le chung tu luong gan nhat
        cp = Q.get("luong_bo_phan") or {}
        if len(cp) >= 2:
            t = sum(cp.values())
            tach = " / ".join("%s %d" % (k, round(tien * v / t)) for k, v in sorted(cp.items()))
            return (sorted(cp)[0], "", 60, "LUONG", "tra luong - so tay chia theo bo phan, ty le chung tu luong gan nhat (nguoi sua theo bang luong)", tach)
        return None
    if d.get("_hoan_ncc"):
        return (Q["tk"]["CHI_NCC"], d["_hoan_ncc"], 92, "HOAN_NCC", "nha cung cap hoan lai tien da tra (cap voi dong tra ngay %s) - giam cong no" % d.get("_hoan_ngay", ""), "")
    if d.get("_cap_nham") or re.search(r"CHUYEN NHAM|TRA LAI DO|CHUYEN TRA LAI", nd):
        return (Q["tk"]["HOAN_TIEN"], "", 90, "HOAN_TIEN", "tien chuyen nham / hoan tra (cap vao - ra cung so tien)" if d.get("_cap_nham") else "hoan tien chuyen nham", "")
    if chieu == "VAO" and re.search(r"HOAN TRA|HOAN LAI|TRA LAI|NHAM", nd):
        return None          # hoan tra khong tim duoc dong tra goc -> nguoi xem
    # 1b. hoc tu 15 bo so khach (GD365): lai vay, no goc / giai ngan, rut tien mat, chuyen noi bo, nop thue theo tu khoa, tam ung
    if chieu == "RA" and re.search(r"LAI VAY|TRA LAI (KU|HD|HOP DONG)|LAI (KU|HD)\b|THU LAI|LAI TIEN VAY|INTEREST", nd):
        return (Q["tk"]["LAI_VAY"], "", 92, "LAI_VAY", "tra lai vay ngan hang", "")
    if chieu == "RA" and re.search(r"TRA (NO )?GOC|NO GOC|GOC VAY|TAT TOAN (KU|KHE UOC|KHOAN VAY)|THU NO (KU|VAY)|\bKU ?\d{6,}", nd):
        return (Q["tk"]["VAY_RA"], "", 90, "VAY", "tra no goc vay (khe uoc)", "")
    if chieu == "VAO" and re.search(r"GIAI NGAN|GN KU|GN KHE UOC|VAY NGAN HANG", nd):
        return (Q["tk"]["VAY_VAO"], "", 92, "VAY", "giai ngan khoan vay", "")
    if chieu == "RA" and re.search(r"RUT (TM|TIEN MAT|TIEN)|RUT TIEN|NOP (VAO )?QUY|CHI TIEN MAT", nd) and "NOP TIEN MAT" not in nd:
        return (Q["tk"]["RUT_TM"], "", 93, "RUT_TM", "rut tien mat ve quy", "")
    # chuyen noi bo: noi dung co so TK khac cua minh hoac ten cong ty minh (>= 2 tu khoa) - sang TK 112 con khac
    tk_minh = _s(Q.get("tk_112", {}).get(_s(d.get("SoTKNH")), ("",))[0])
    khac = [t for t in Q.get("tk_112_dung", []) if t != tk_minh and not (t.startswith("1122") and "USD" not in nd and "NGOAI TE" not in nd)]
    # so TK khac cua minh trong noi dung (bo qua khi dong chua biet so TK: ngan hang thuong ghi 'STB,<so TK nhan>' - la TK cua chinh dong nay)
    stk_khac = [k for k, v in Q.get("so_tk_minh", {}).items() if k and _s(d.get("SoTKNH")) and k != _s(d.get("SoTKNH")) and k in nd]
    # ten cong ty minh trong noi dung thuong la NGUOI NHAN (khach ghi) -> khong dung lam dau hieu noi bo; chi dung so TK khac cua minh hoac chu 'noi bo'
    noi_bo = bool(stk_khac) or re.search(r"CHUYEN NOI BO|NOI BO|CHUYEN TIEN GIUA (CAC )?TK|TU TK .* SANG TK", nd) is not None
    if noi_bo:
        if stk_khac and Q["so_tk_minh"].get(stk_khac[0]):
            return (Q["so_tk_minh"][stk_khac[0]], "", 94, "NOI_BO", "chuyen noi bo sang TK %s" % stk_khac[0], "")
        if tk_minh and len(khac) == 1:
            return (khac[0], "", 90, "NOI_BO", "chuyen noi bo (so chi co 2 TK ngan hang)", "")
        return None          # nhieu TK hoac chua biet TK cua dong nay -> nguoi
    if chieu == "RA" and re.search(r"THUE|NTDT|KBNN|NOP NS|NGAN SACH|TCT|CUC THUE|CHI CUC THUE", nd):
        if re.search(r"GTGT|GIA TRI GIA TANG|VAT\b", nd):
            return (Q["tk"]["THUE_GTGT"], "", 90, "THUE", "nop thue GTGT", "")
        if re.search(r"TNDN|THU NHAP DOANH NGHIEP", nd):
            return (Q["tk"]["THUE_TNDN"], "", 90, "THUE", "nop thue TNDN", "")
        if re.search(r"TNCN|THU NHAP CA NHAN", nd):
            return (Q["tk"]["THUE_TNCN"], "", 90, "THUE", "nop thue TNCN", "")
        if re.search(r"NHAP KHAU|THUE NK|XNK|HAI QUAN|TO KHAI", nd):
            return (Q["tk"]["THUE_NK"], "", 88, "THUE", "nop thue nhap khau / hai quan", "")
        if re.search(r"CHAM NOP|PHAT", nd):
            return (Q["tk"]["CHAM_NOP"], "", 88, "THUE", "tien cham nop / phat", "")
        if re.search(r"MON BAI|LE PHI", nd):
            return (Q["tk"]["THUE_KHAC"], "", 88, "THUE", "le phi mon bai / thue khac", "")
        return None          # nop thue khong ro loai -> nguoi chon
    if chieu == "RA" and re.search(r"TAM UNG", nd):
        return (Q["tk"]["TAM_UNG"], "", 85, "TAM_UNG", "tam ung nhan vien", "")
    # 2. thu khach / tra nha cung cap
    if chieu == "VAO":
        tk_t = Q["tk"]["THU_KH"]
        if tk_hien.startswith("131") and ma_kh:
            ghi_711 = " | so tay: phan le khach tra thua < 1.000 d ghi 711" if Q.get("co_711") and tien % 1000 == 0 else ""
            return (tk_t, ma_kh, max(_i(d.get("TinCay")), 90), "THU_KH", Q["dien_giai"].get(("VAO", tk_t[:4]), "thu tien hang") + ghi_711, "")
        return (tk_t, ma_kh, 88 if ma_kh else 80, "THU_KH", Q["dien_giai"].get(("VAO", tk_t[:4]), "thu tien hang") + ("" if ma_kh else " - chua ro khach"), "")
    tk_t = Q["tk"]["CHI_NCC"]
    if tk_hien.startswith("331") and ma_kh:
        return (tk_t, ma_kh, max(_i(d.get("TinCay")), 90), "CHI_NCC", Q["dien_giai"].get(("RA", tk_t[:4]), "tra tien hang"), "")
    if re.search(r"THANH TOAN|TT HD|TTHD|HD SO|HOA DON", nd):
        return (tk_t, ma_kh, 85 if ma_kh else 75, "CHI_NCC", Q["dien_giai"].get(("RA", tk_t[:4]), "tra tien hang") + ("" if ma_kh else " - chua ro nha cung cap"), "")
    return None


def kiem_so_du(ds):
    """Kiem lai so du theo tung ngay: trong mot ngay thu moi thu tu de chuoi so du lien tuc. Tra {MaSo: 'OK'|'LECH'}."""
    kq = {}
    theo_ngay = defaultdict(list)
    for d in ds:
        if d.get("SoDu") is None:
            continue
        theo_ngay[d["NgayGD"].date() if hasattr(d["NgayGD"], "date") else d["NgayGD"]].append(d)
    truoc = None
    for ng in sorted(theo_ngay):
        con = list(theo_ngay[ng])
        thu_tu = []
        while con:
            if truoc is None:
                x = con.pop(0)
            else:
                ok = [d for d in con if abs((_f(d["SoDu"]) - truoc) - (_f(d["TienVao"]) - _f(d["TienRa"]))) <= 1]
                x = ok[0] if ok else None
                if x is None:
                    for d in con:
                        kq[d["MaSo"]] = "LECH"
                    truoc = _f(con[-1]["SoDu"])
                    break
                con.remove(x)
            kq[x["MaSo"]] = "OK"
            truoc = _f(x["SoDu"])
            thu_tu.append(x)
    return kq


def de_xuat(B, Q):
    kh_theo_mst, kh_theo_so = {}, {}
    for r in B["KhachHang"]:
        m = re.sub(r"[^0-9\-]", "", _s(r.get("MST")))
        if m:
            kh_theo_mst.setdefault(m[:10], []).append(_s(r.get("SoHieu")))
        kh_theo_so[_s(r.get("SoHieu"))] = r
    cho = [d for d in B["HDDT_SP_Dong"] if _s(d.get("TrangThai")).upper() not in ("DA_HACH_TOAN", "BO_QUA")]
    sd = kiem_so_du(cho)
    # cap tien vao - tien ra cung ngay (hoac ngay ke) cung so tien, mot ben ghi 'chuyen nham / tra lai' -> ca hai la hoan tien
    tat_ca = list(B["HDDT_SP_Dong"])
    for a in cho:
        nda = _nd(a.get("NoiDung"))
        if _f(a.get("TienRa")) > 0 and re.search(r"CHUYEN NHAM|TRA LAI|HOAN TRA|NHAM", nda):
            # minh chuyen tra lai tien nhan nham -> dong tien vao cung so tien truoc do cung la nham
            for b in cho:
                if _f(b.get("TienVao")) == _f(a.get("TienRa")) and b is not a and 0 <= (a["NgayGD"] - b["NgayGD"]).days <= 5:
                    b["_cap_nham"] = True
                    a["_cap_nham"] = True
        elif _f(a.get("TienVao")) > 0 and re.search(r"HOAN TRA|HOAN LAI|TRA LAI|NHAM", nda):
            # doi tac hoan lai tien minh da tra -> giam cong no nha cung cap cua dong tra goc
            for b in tat_ca:
                if _f(b.get("TienRa")) == _f(a.get("TienVao")) and b is not a and 0 <= (a["NgayGD"] - b["NgayGD"]).days <= 10 and _vang(b.get("MaKH")) and _s(b.get("TKDoiUng")).startswith("331"):
                    a["_hoan_ncc"] = _s(b.get("MaKH"))
                    a["_hoan_ngay"] = str(b["NgayGD"].date()) if hasattr(b["NgayGD"], "date") else _s(b["NgayGD"])
    out = []
    for d in cho:
        x = de_xuat_dong(Q, d, kh_theo_mst, kh_theo_so)
        if not x:
            continue
        tk_t, ma_kh, tc, nhom, goi_y, tach = x
        if tk_t not in Q["tk_ds"]:
            continue
        if sd.get(d["MaSo"]) == "LECH":
            tc = min(tc, 60)
            goi_y += " | so du khong lien tuc (kiem tep sao ke)"
        out.append({"MaSo": d["MaSo"], "tk": tk_t, "ma_kh": ma_kh, "tin_cay": tc, "nhom": nhom, "goi_y": goi_y, "tach": tach})
    return out, sd


def ghi(so, Q, dx, sd, thu_muc):
    os.makedirs(thu_muc, exist_ok=True)
    p = os.path.join(thu_muc, TEP + ".txt")
    L = ["H;%s" % so.replace(";", ",")]
    for c in Q["can_cu"]:
        L.append("QT;%s" % ";".join(_s(x).replace(";", ",") for x in c))
    for tk_nh, (chon, cc) in Q["tk_112"].items():
        L.append("TK112;%s;%s;%s" % (tk_nh, chon, cc.replace(";", ",")))
    for x in dx:
        L.append("SP;%d;%s;%s;%d;%s;%s;%s" % (x["MaSo"], x["tk"], x["ma_kh"], x["tin_cay"], x["nhom"], x["goi_y"].replace(";", ","), x["tach"].replace(";", ",")))
    for k, v in sd.items():
        L.append("SD;%d;%s" % (k, v))
    with io.open(p, "w", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")
    return p


def chay(duong, thu_muc, so=""):
    B = doc_bang(duong)
    Q = hoc(B)
    dx, sd = de_xuat(B, Q)
    return Q, dx, sd, ghi(so or os.path.basename(duong), Q, dx, sd, thu_muc)


if __name__ == "__main__":
    import sys
    Q, dx, sd, p = chay(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else ".")
    for c in Q["can_cu"]:
        print("QT", c)
    print("tien to", Q["tien_to"], "dien giai", Q["dien_giai"])
    print("de xuat", len(dx), "so du", Counter(sd.values()))
    for x in dx[:60]:
        print(x)
