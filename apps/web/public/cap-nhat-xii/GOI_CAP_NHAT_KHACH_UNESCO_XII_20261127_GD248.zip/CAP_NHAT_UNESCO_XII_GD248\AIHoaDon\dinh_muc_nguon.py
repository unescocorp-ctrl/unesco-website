# -*- coding: utf-8 -*-
"""GD211 - NGUON DINH MUC / DU TOAN CUA KHACH: doc cac tep Excel / CSV trong thu muc nguoi dung chi dinh (mac dinh AIHoaDon\\dinh-muc-du-toan),
nhan dang bang dinh muc (san pham - nguyen vat lieu - DVT - so luong) hoac du toan cong trinh (khoi luong vat tu theo hang muc / san pham),
ghep ten san pham, nguyen vat lieu voi ma trong so, roi dua vao "Tro ly lap dinh muc" (dinh_muc_ai.buoc2) lam nguon uu tien (bo may H).
Chi DOC tep va so; khong ghi so, khong ghi MDB, khong dua noi dung tep len mang. Ten tep / ten khach khong ghi vao nhat ky.
Cach nhan dang:
  - Dong tieu de (trong 40 dong dau): cot ten vat tu (Ten vat tu / nguyen lieu / noi dung / dien giai ...), DVT, so luong (Dinh muc / So luong /
    Khoi luong), tuy chon: don gia, thanh tien, san pham (Cot San pham / Thanh pham / Cong trinh / Hang muc).
  - Khong co cot san pham: dong "San pham: ..." / "Thanh pham: ..." / "Cong trinh: ..." / "Hang muc: ..." mo mot khoi moi; khong co nua thi lay ten sheet
    (neu sheet ten chung chung thi ten tep).
  - "So luong san pham: N" / "Khoi luong cong trinh: N" trong khoi: dinh muc 1 san pham = so luong dong / N (du toan cho ca lo).
  - Dong nhan cong, may thi cong, chi phi chung, thue, loi nhuan, cong / tong khong dua vao dinh muc nguyen vat lieu (chi bao trong ket qua)."""
import csv
import io
import os
import re
import sys
import unicodedata
from collections import OrderedDict, defaultdict

GOC = os.path.dirname(os.path.abspath(__file__))
if GOC not in sys.path:
    sys.path.insert(0, GOC)

PHAN_MO_RONG = (".xlsx", ".xlsm", ".xls", ".csv", ".txt", ".tsv", ".docx", ".htm", ".html", ".pdf")   # GD213: + TXT, Word, HTML, PDF
TIN_CAY_H = 0.90

_KHAC = ("nhan cong", "cong nhan", "may thi cong", "chi phi may", "chi phi chung", "chi phi nhan cong", "thue", "loi nhuan", "lai ",
         "chi phi khac", "chi phi quan ly", "bao hiem", "van chuyen", "phu cap")
_TONG = ("cong ", "tong ", "cong:", "tong:", "cong cong", "tong cong", "cong tien", "tong tien")


def khong_dau(s):
    s = unicodedata.normalize("NFD", str(s if s is not None else ""))
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    return s.replace("đ", "d").replace("Đ", "D").lower()


def _chuan(s):
    return " ".join(re.findall(r"[a-z0-9]+", khong_dau(s)))


def _so_vn(v):
    """so tu o Excel hoac chuoi: 1.234,5 / 1,234.5 / 0,25 / '12 kg' (lay phan dau)."""
    if v is None or isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    t = str(v).strip().replace(" ", "").replace(" ", "")
    if not t or not re.match(r"^[-+]?[\d.,]+%?$", t):
        return None
    t = t.rstrip("%")
    if "," in t and "." in t:
        if t.rfind(",") > t.rfind("."):
            t = t.replace(".", "").replace(",", ".")
        else:
            t = t.replace(",", "")
    elif "," in t:
        t = t.replace(",", ".") if t.count(",") == 1 else t.replace(",", "")
    elif t.count(".") > 1:
        t = t.replace(".", "")
    try:
        return float(t)
    except ValueError:
        return None


# ------------------------------------------------------------------ nhan dang cot
_VAI_TRO = (
    ("sp", ("san pham", "thanh pham", "cong trinh", "ma sp", "ten sp", "ten san pham", "ten thanh pham")),
    ("ten", ("ten vat tu", "ten nguyen lieu", "ten vat lieu", "nguyen vat lieu", "vat tu", "vat lieu", "nguyen lieu", "nvl", "ten hang", "noi dung",
             "dien giai", "ten cong viec", "cong viec", "ten hang hoa", "ten mat hang")),
    ("dvt", ("dvt", "don vi tinh", "don vi")),
    ("sl", ("dinh muc", "so luong", "khoi luong", "luong", "sl", "dm")),
    ("dg", ("don gia", "gia")),
    ("tt", ("thanh tien", "tien")),
)


def _vai_tro_o(txt):
    t = _chuan(txt)
    if not t or len(t) > 40:
        return None
    for vt, ds in _VAI_TRO:
        for k in ds:
            if t == k or t.startswith(k + " ") or t.endswith(" " + k) or (len(k) > 3 and k in t):
                return vt, k
    return None


def _tim_tieu_de(rows):
    tot = None
    for i, r in enumerate(rows[:40]):
        vt = {}
        for c, v in enumerate(r):
            if isinstance(v, str):
                x = _vai_tro_o(v)
                if x and x[0] not in vt:
                    vt[x[0]] = (c, x[1])
        if "ten" in vt and "sl" in vt and len(vt) >= 3:
            tot = (i, vt)
            break
        if tot is None and "ten" in vt and "sl" in vt:
            tot = (i, vt)
    return tot


_RE_KHOI = re.compile(r"^(san pham|thanh pham|cong trinh|hang muc|sp)\b[^:]*:\s*\S")
_RE_SLSP = re.compile(r"(?:so luong|sl|khoi luong|san luong)\s+(?:san pham|thanh pham|cong trinh|sp|lo)\s*[:=]?\s*([\d.,]+)")


def _ten_goc(s):
    return re.sub(r"\s+", " ", str(s or "").strip())


def doc_bang(rows, ten_sheet, ten_tep):
    """rows: list list. Tra [(ten_sp, ma_sp, sl_sp, [dong])]; dong = dict(ten, dvt, sl, dg, tt, loai, dong_so)."""
    th = _tim_tieu_de(rows)
    if not th:
        return []
    i0, vt = th
    cot = {k: v[0] for k, v in vt.items()}
    khoi = OrderedDict()
    hien = None
    mac_dinh = ten_sheet if _chuan(ten_sheet) not in ("", "sheet1", "sheet", "dinh muc", "du toan", "bang dinh muc", "sheet2", "sheet3") else os.path.splitext(ten_tep)[0]
    sp_cot = None
    # GD213: dong "San pham: ..." / "So luong san pham: N" nam TREN dong tieu de (Word, trang du toan) mo khoi dau tien
    for r in rows[:i0]:
        for v in [v for v in r if isinstance(v, str) and v.strip()]:
            kd = khong_dau(v).strip()
            if ":" in v and _RE_KHOI.match(kd):
                hien = _ten_goc(v.split(":", 1)[1])
                khoi.setdefault(hien, {"ma": "", "sl_sp": None, "dong": []})
            m = _RE_SLSP.search(kd)
            if m and _so_vn(m.group(1)):
                khoi.setdefault(hien if hien is not None else mac_dinh, {"ma": "", "sl_sp": None, "dong": []})["sl_sp"] = _so_vn(m.group(1))
    for i in range(i0 + 1, len(rows)):
        r = rows[i]
        van = [v for v in r if isinstance(v, str) and v.strip()]
        # dong mo khoi moi: "San pham: ..." / "Cong trinh: ..." (co dau hai cham)
        mo = None
        for v in van:
            if ":" in v and _RE_KHOI.match(khong_dau(v).strip()):
                mo = v.split(":", 1)[1].strip()
                break
        if mo:
            hien = _ten_goc(mo)
            khoi.setdefault(hien, {"ma": "", "sl_sp": None, "dong": []})
            continue
        la_slsp = False
        for v in van:
            m = _RE_SLSP.search(khong_dau(v))
            if m:
                la_slsp = True
                n = _so_vn(m.group(1))
                if n:
                    khoi.setdefault(hien if hien is not None else mac_dinh, {"ma": "", "sl_sp": None, "dong": []})["sl_sp"] = n
                break
        if la_slsp:
            continue
        ten = r[cot["ten"]] if cot["ten"] < len(r) else None
        sl = _so_vn(r[cot["sl"]]) if cot["sl"] < len(r) else None
        if "sp" in cot and cot["sp"] < len(r) and isinstance(r[cot["sp"]], str) and r[cot["sp"]].strip():
            sp_cot = _ten_goc(r[cot["sp"]])
        sp = sp_cot if "sp" in cot else (hien if hien is not None else mac_dinh)
        if not isinstance(ten, str) or not ten.strip() or sl is None or sl <= 0:
            continue
        t = _chuan(ten)
        if any(t == k.strip() or t.startswith(k) for k in _TONG):
            continue
        loai = "KHAC" if any(t.startswith(k.strip()) or (" " + k.strip() + " ") in (" " + t + " ") for k in _KHAC) else "NVL"
        dvt = r[cot["dvt"]] if "dvt" in cot and cot["dvt"] < len(r) else ""
        dg = _so_vn(r[cot["dg"]]) if "dg" in cot and cot["dg"] < len(r) else None
        tt = _so_vn(r[cot["tt"]]) if "tt" in cot and cot["tt"] < len(r) else None
        kh = khoi.setdefault(sp, {"ma": "", "sl_sp": None, "dong": []})
        kh["dong"].append({"ten": _ten_goc(ten), "dvt": str(dvt or "").strip(), "sl": sl, "dg": dg or 0.0, "tt": tt or 0.0, "loai": loai, "dong_so": i + 1})
    return [(ten, kh["ma"], kh["sl_sp"], kh["dong"]) for ten, kh in khoi.items() if kh["dong"]]


# ------------------------------------------------------------------ doc thu muc
def liet_ke_tep(thu_muc):
    kq = []
    try:
        for ten in sorted(os.listdir(thu_muc)):
            if ten.startswith("~$") or ten.startswith("."):
                continue
            if ten.lower().endswith(PHAN_MO_RONG) and os.path.isfile(os.path.join(thu_muc, ten)):
                kq.append(ten)
    except OSError:
        pass
    return kq


def _rows_csv(duong):
    with io.open(duong, "r", encoding="utf-8-sig", errors="replace", newline="") as f:
        mau = f.read()
    try:
        dia = csv.Sniffer().sniff(mau[:4096], delimiters=";,\t|")
    except csv.Error:
        dia = csv.excel
    return [list(r) for r in csv.reader(io.StringIO(mau), dia)]


def _chu_html(x):
    import html as _h
    x = re.sub(r"(?is)<br\s*/?>", " ", x)
    x = re.sub(r"(?s)<[^>]+>", " ", x)
    return re.sub(r"\s+", " ", _h.unescape(x)).strip()


def _rows_html(duong):
    """Bang HTML (Excel / Word luu thanh trang web, trang du toan) -> rows; moi the <tr> mot dong."""
    with open(duong, "rb") as f:
        b = f.read()
    m = re.search(rb"charset=[\"']?([\w-]+)", b[:4000], re.I)
    try:
        t = b.decode(m.group(1).decode("ascii") if m else "utf-8", errors="replace")
    except LookupError:
        t = b.decode("utf-8", errors="replace")
    rows = []
    t = re.sub(r"(?is)<(script|style)\b.*?</\1>", " ", t)
    vi = 0
    for bang in list(re.finditer(r"(?is)<table\b.*?</table>", t)) + [None]:
        ngoai = t[vi:bang.start()] if bang else t[vi:]
        for k in re.finditer(r"(?is)<(p|h[1-6]|div|li)\b[^>]*>(.*?)</\1>", ngoai):      # doan van ngoai bang: "Cong trinh: ..."
            x = _chu_html(k.group(2))
            if x:
                rows.append([x])
        if bang is None:
            break
        for tr in re.finditer(r"(?is)<tr\b[^>]*>(.*?)</tr>", bang.group(0)):
            rows.append([_chu_html(c) for c in re.findall(r"(?is)<t[dh]\b[^>]*>(.*?)</t[dh]>", tr.group(1))])
        vi = bang.end()
    return rows


def _rows_docx(duong):
    """Word .docx: doan van ngoai bang (vd "San pham: ...") la dong 1 o; moi hang cua bang la mot dong - giu dung thu tu."""
    import zipfile
    from xml.etree import ElementTree as ET
    W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    with zipfile.ZipFile(duong) as z:
        goc = ET.fromstring(z.read("word/document.xml"))
    than = goc.find(W + "body")
    rows = []

    def chu(e):
        return re.sub(r"\s+", " ", "".join(t.text or "" for t in e.iter(W + "t"))).strip()
    for e in (than if than is not None else []):
        if e.tag == W + "p":
            x = chu(e)
            if x:
                rows.append([x])
        elif e.tag == W + "tbl":
            for tr in e.iter(W + "tr"):
                rows.append([chu(tc) for tc in tr.findall(W + "tc")])
    return rows


def _rows_pdf(duong):
    """PDF co lop chu (khong phai anh quet): can thu vien pdfplumber tren may. Khong co -> bao ro de chuyen sang Excel / Word."""
    try:
        import pdfplumber
    except ImportError:
        raise ValueError("may chua co thu vien pdfplumber de doc PDF - luu bang sang Excel / Word roi nhap lai")
    rows = []
    with pdfplumber.open(duong) as pdf:
        for trang in pdf.pages:
            bang = trang.extract_tables() or []
            if not bang:
                for d in (trang.extract_text() or "").splitlines():
                    rows.append([x for x in re.split(r"\s{2,}|\t", d.strip()) if x])
            for b in bang:
                rows += [[str(c or "").strip() for c in r] for r in b]
    if not rows:
        raise ValueError("PDF khong co lop chu (anh quet) - can chuyen sang Excel / Word")
    return rows


def doc_tep(duong):
    """Mot tep bat ky dang thong dung -> (loai, {ten sheet: rows}). Loi -> ValueError co mo ta."""
    ten = os.path.basename(duong)
    duoi = os.path.splitext(ten)[1].lower()
    goc = os.path.splitext(ten)[0]
    if duoi in (".csv", ".txt", ".tsv"):
        return duoi[1:].upper(), {goc: _rows_csv(duong)}
    if duoi == ".docx":
        return "WORD", {goc: _rows_docx(duong)}
    if duoi in (".htm", ".html"):
        return "HTML", {goc: _rows_html(duong)}
    if duoi == ".pdf":
        return "PDF", {goc: _rows_pdf(duong)}
    if duoi in (".xlsx", ".xlsm", ".xls"):
        try:
            import tool_trich_xuat_so_phu as TX
        except Exception:
            raise ValueError("thieu bo doc Excel (tool_trich_xuat_so_phu.py)")
        bang = TX.doc_excel(duong)
        an = getattr(bang, "an_sheet", set())
        return "EXCEL", OrderedDict((k, v) for k, v in bang.items() if k not in an)
    if duoi == ".doc":
        raise ValueError("Word cu (.doc) - mo bang Word, Luu thanh .docx roi nhap lai")
    raise ValueError("dang tep %s chua ho tro (dung Excel, CSV, TXT, Word .docx, HTML, PDF)" % (duoi or "?"))


def doc_thu_muc(thu_muc):
    """-> {"tep": [...], "sp": OrderedDict(ten_chuan -> {...}), "loi": [...]}; moi san pham: ten, sl_sp, dong, nguon."""
    kq = {"tep": [], "sp": OrderedDict(), "loi": []}
    if not thu_muc or not os.path.isdir(thu_muc):
        return kq
    try:
        import tool_trich_xuat_so_phu as TX
    except Exception:
        TX = None
    for ten in liet_ke_tep(thu_muc):
        duong = os.path.join(thu_muc, ten)
        kq["tep"].append(ten)
        try:
            _, bang = doc_tep(duong)
        except Exception as e:
            kq["loi"].append("%s: khong doc duoc (%s)" % (ten, str(e)[:80]))
            continue
        co = False
        for sheet, rows in bang.items():
            for ten_sp, ma_sp, sl_sp, dong in doc_bang(rows, sheet, ten):
                k = _chuan(ten_sp)
                m = kq["sp"].setdefault(k, {"ten": ten_sp, "sl_sp": sl_sp, "dong": [], "nguon": "%s / %s" % (ten, sheet)})
                if sl_sp and not m["sl_sp"]:
                    m["sl_sp"] = sl_sp
                m["dong"] += dong
                co = True
        if not co:
            kq["loi"].append("%s: khong nhan dang duoc bang dinh muc (can cot ten vat tu + so luong)" % ten)
    return kq


# ------------------------------------------------------------------ ghep ten voi ma trong so
_DVT_DOI = {("g", "kg"): 0.001, ("kg", "g"): 1000.0, ("ml", "l"): 0.001, ("l", "ml"): 1000.0, ("tan", "kg"): 1000.0, ("kg", "tan"): 0.001,
            ("cm", "m"): 0.01, ("m", "cm"): 100.0, ("mm", "m"): 0.001, ("m", "mm"): 1000.0, ("mg", "g"): 0.001, ("g", "mg"): 1000.0}
_DVT_DONG_NGHIA = {"lit": "l", "l": "l", "liter": "l", "chiec": "cai", "cai": "cai", "con": "cai", "kwh": "kwh", "kw/h": "kwh", "kg": "kg", "g": "g",
                   "gam": "g", "gram": "g", "tan": "tan", "m": "m", "met": "m", "m2": "m2", "m3": "m3"}


def _dvt(s):
    t = _chuan(s).replace(" ", "")
    return _DVT_DONG_NGHIA.get(t, t)


def he_so_dvt(dvt_file, dvt_so):
    """(he so, ghi chu): so luong theo DVT cua so = so luong file x he so. he so None = khong doi duoc."""
    a, b = _dvt(dvt_file), _dvt(dvt_so)
    if not a or not b or a == b:
        return 1.0, ""
    if (a, b) in _DVT_DOI:
        return _DVT_DOI[(a, b)], "doi %s -> %s" % (dvt_file, dvt_so)
    return None, "DVT bang '%s' khac DVT so '%s'" % (dvt_file, dvt_so)


def _tap(s):
    return set(_chuan(s).split())


def khop_ten(ten, vt, ma_loc=None):
    """ten (file) -> (ma vat tu, diem 0..1, mo_ho). vt: {ma: {"sh","ten",...}}. Chi khop khi cac con so trong ten giong nhau."""
    t = _chuan(ten)
    if not t:
        return 0, 0.0, False
    A = _tap(ten)
    so_a = {x for x in A if any(c.isdigit() for c in x)}
    tot, ds = (0, 0.0), []
    for ma, v in vt.items():
        if ma_loc is not None and not ma_loc(v):
            continue
        if _chuan(v["ten"]) == t or _chuan(v["sh"]) == t:
            ds.append((1.0, ma))
            continue
        B = _tap(v["ten"])
        if {x for x in B if any(c.isdigit() for c in x)} != so_a:
            continue
        hop = len(A | B)
        d = (len(A & B) / float(hop)) if hop else 0.0
        if d >= 0.8:
            ds.append((d, ma))
    if not ds:
        return 0, 0.0, False
    ds.sort(key=lambda x: (-x[0], x[1]))
    mo_ho = len(ds) > 1 and ds[0][0] < 1.0 and ds[1][0] >= ds[0][0] - 0.05
    if len(ds) > 1 and ds[0][0] == 1.0 and ds[1][0] == 1.0:
        mo_ho = True
    return (0, ds[0][0], True) if mo_ho else (ds[0][1], ds[0][0], False)


def nap(S):
    """doc thu muc S.dl["nguon_dm_thumuc"] (mot lan / lan chay) va ghep san pham voi ma trong so. Tra None neu khong co thu muc / tep."""
    if hasattr(S, "_nguon_dm"):
        return S._nguon_dm
    thu = str((S.dl or {}).get("nguon_dm_thumuc") or "").strip()
    kq = None
    if thu:
        d = doc_thu_muc(thu)
        sp_map, chua = {}, []
        for k, m in d["sp"].items():
            ma, diem, mo_ho = khop_ten(m["ten"], S.vt, lambda v: not S.la_nvl(v) or S.la_tp(v))
            if ma and not mo_ho:
                sp_map.setdefault(ma, m)
            else:
                chua.append((m["ten"], "mơ hồ (nhiều mã giống nhau)" if mo_ho else "chưa có mã thành phẩm trong sổ"))
        kq = {"tep": d["tep"], "loi": d["loi"], "sp_map": sp_map, "chua_khop": chua, "tong_sp": len(d["sp"])}
    S._nguon_dm = kq
    return kq


def de_xuat_tu_bang(S, nguon, ma_tp, lam_tron):
    """None neu bang khong co san pham nay. Tra dict giong de_xuat_ma: dong, tin_cay, tom_tat, bao_cao, muc."""
    if not nguon or ma_tp not in nguon["sp_map"]:
        return None
    m = nguon["sp_map"][ma_tp]
    chia = m["sl_sp"] if (m.get("sl_sp") and m["sl_sp"] > 0) else 1.0
    dong, bc, chua, khac, lech_dv = [], [], [], 0, 0
    gop = OrderedDict()
    for d in m["dong"]:
        if d["loai"] != "NVL":
            khac += 1
            continue
        ma, diem, mo_ho = khop_ten(d["ten"], S.vt, lambda v: S.la_nvl(v))
        if not ma or mo_ho:
            chua.append(d["ten"] + (" (mơ hồ)" if mo_ho else ""))
            continue
        hs, gc = he_so_dvt(d["dvt"], S.vt[ma]["dvt"])
        sl = d["sl"] / chia
        ghi = []
        muc = "XANH"
        if hs is None:
            lech_dv += 1
            muc = "VANG"
            ghi.append(gc + ": kiểm tra lại số lượng")
        else:
            sl *= hs
            if gc:
                ghi.append(gc)
        dg_so = S.don_gia(ma)
        if d["dg"] > 0 and dg_so > 0 and abs(d["dg"] - dg_so) / dg_so > 0.3:
            muc = "VANG"
            ghi.append("đơn giá bảng %s, sổ %s" % (_dd(round(d["dg"])), _dd(round(dg_so))))
        if ma in gop:
            gop[ma]["sl"] += sl
            gop[ma]["ghi"] += ghi
        else:
            gop[ma] = {"sl": sl, "muc": muc, "ghi": ghi, "dong_so": d["dong_so"]}
    for ma, g in gop.items():
        nguon_txt = "Bảng định mức / dự toán: %s, dòng %d" % (m["nguon"], g["dong_so"])
        if g["ghi"]:
            nguon_txt += " (" + "; ".join(g["ghi"]) + ")"
        dong.append({"nvl": ma, "sl": lam_tron(g["sl"]), "nguon": nguon_txt, "min": lam_tron(g["sl"]), "max": lam_tron(g["sl"]),
                     "muc": g["muc"], "tin_cay": TIN_CAY_H if g["muc"] == "XANH" else 0.6, "bo_may": "H"})
    if not dong:
        return None
    tong_dong = len(gop) + len(chua)
    ty = len(gop) / float(tong_dong) if tong_dong else 0.0
    tin_cay = round(TIN_CAY_H * ty, 2)
    bc.append("Nguồn: bảng định mức / dự toán của khách - %s (%d dòng vật tư%s)" % (m["nguon"], len(m["dong"]),
                                                                                  ", chia cho %s sản phẩm" % _dd(chia) if chia != 1.0 else ""))
    if chua:
        bc.append("Dòng chưa có mã nguyên vật liệu trong sổ (chưa đưa vào định mức): " + "; ".join(chua[:8]) + (" ..." if len(chua) > 8 else ""))
    if khac:
        bc.append("%d dòng nhân công / máy / chi phí chung / thuế trong bảng không đưa vào định mức nguyên vật liệu." % khac)
    if lech_dv:
        bc.append("%d dòng khác đơn vị tính với sổ, chưa đổi được: kiểm tra lại số lượng." % lech_dv)
    tom_tat = "Theo bảng định mức / dự toán: %d dòng NVL khớp mã sổ, %d dòng chưa khớp, độ tin cậy %d%%" % (len(gop), len(chua), round(tin_cay * 100))
    muc = "XANH" if tin_cay >= 0.65 and not chua and not lech_dv else ("VANG" if tin_cay >= 0.3 else "DO")
    return {"dong": dong, "tin_cay": tin_cay, "tom_tat": tom_tat, "bao_cao": bc, "muc": muc}


def _dd(x):
    return "{:,.0f}".format(x).replace(",", ".") if abs(x - round(x)) < 1e-9 else ("{:,.2f}".format(x).replace(",", "X").replace(".", ",").replace("X", "."))


def tom_tat_nguon(nguon):
    """dong chu cho bao cao: bao nhieu tep, san pham khop, san pham chua khop."""
    if not nguon:
        return []
    ra = ["Thư mục bảng định mức / dự toán: %d tệp, %d sản phẩm nhận dạng được, %d sản phẩm khớp mã trong sổ." % (len(nguon["tep"]), nguon["tong_sp"], len(nguon["sp_map"]))]
    for ten, ly in nguon["chua_khop"][:12]:
        ra.append("Chưa khớp: %s - %s" % (ten, ly))
    for e in nguon["loi"][:6]:
        ra.append("Tệp: " + e)
    return ra


# ------------------------------------------------------------------ GD213: nhap mot tep cho VB6 (luu vao bang HDDT_DMNguon* trong data)
def _s(x, n=250):
    return re.sub(r"\s+", " ", str(x if x is not None else "").replace(";", ",")).strip()[:n]


def nhap_tep(duong, ra):
    """Nhan dang mot tep (Excel / CSV / TXT / Word / HTML / PDF) -> tep ket qua UTF-8 cho VB6:
      KQ;OK|LOI;<loai tep>;<so san pham>;<so dong>;<mo ta>
      S;<so thu tu sp>;<ten san pham / cong trinh>;<so luong sp (0 = khong ghi)>;<sheet>
      D;<so thu tu sp>;<ten vat tu>;<dvt>;<so luong>;<don gia>;<thanh tien>;<NVL|KHAC>;<dong so>
    Chi doc tep; VB6 ghi bang va chep tep vao thu muc dinh muc cua bo so."""
    out = []
    try:
        loai, bang = doc_tep(duong)
    except Exception as e:
        out.append("KQ;LOI;;0;0;%s" % _s(e))
        loai, bang = "", {}
    if bang:
        nsp = ndong = 0
        than = []
        for sheet, rows in bang.items():
            for ten_sp, _, sl_sp, dong in doc_bang(rows, sheet, os.path.basename(duong)):
                nsp += 1
                than.append("S;%d;%s;%s;%s" % (nsp, _s(ten_sp), ("%g" % sl_sp) if sl_sp else "0", _s(sheet, 100)))
                for d in dong:
                    ndong += 1
                    than.append("D;%d;%s;%s;%g;%g;%g;%s;%d" % (nsp, _s(d["ten"]), _s(d["dvt"], 30), d["sl"], d["dg"] or 0, d["tt"] or 0, d["loai"], d["dong_so"]))
        if nsp:
            out.append("KQ;OK;%s;%d;%d;" % (loai, nsp, ndong))
            out += than
        else:
            out.append("KQ;LOI;%s;0;0;khong nhan dang duoc bang dinh muc / du toan (can dong tieu de co cot ten vat tu va so luong / dinh muc / khoi luong)" % loai)
    os.makedirs(os.path.dirname(os.path.abspath(ra)), exist_ok=True)
    with open(ra, "w", encoding="utf-8") as f:
        f.write("\n".join(out) + "\n")
    return ra
