# -*- coding: utf-8 -*-
"""GD105 - TO KHAI HAI QUAN NHAP KHAU (VNACCS / ECUS xuat Excel "To khai hang hoa nhap khau (thong quan)").

Doc tep Excel ban in to khai (sheet co dau "<IMP>", trang 1/n...) -> du lieu chuan:
  dau: so to khai, ma loai hinh, ngay dang ky, ngay cap phep (thong quan), nguoi nhap khau (MST, ten), nguoi xuat khau
       (ten, dia chi, ma nuoc), so van don, so hoa don thuong mai + ngay, phuong thuc thanh toan, dieu kien giao hang
       (CIF / FOB...), tien te, tong tri gia hoa don, tong tri gia tinh thue, ty gia tinh thue, cac sac thue tong.
  dong: <01>..<nn>: ma HS, mo ta (ma hang / hieu), so luong + DVT, tri gia hoa don (ngoai te), don gia, tri gia tinh thue
        (VND), thue nhap khau (thue suat, so tien), thue / thu khac (GTGT, TTDB, BVMT, chong ban pha gia...), xuat xu.
Kiem tra: tong tri gia hoa don, tong tri gia tinh thue, tong thue GTGT tung dong = so tren trang dau.

Phan bo gia nhap kho (phan_bo):
  gia tri hang = tri gia hoa don x ty gia (anh chon ty gia tinh thue cua to khai)
  + thue nhap khau, TTDB, BVMT, thue khac CUA DONG (lay dung tung dong, khong chia)
  + chi phi nhap hang (cuoc, local charge, phi HQ, van chuyen noi dia...) chia theo tieu thuc moi khoan
    (gia tri | so luong | thu cong), lam tron dong, chenh lech don ve dong cuoi.
  Thue GTGT hang nhap khau KHONG vao gia (khau tru: No 1331 / Co 33312).
Thu vien chuan Python, khong ghi so.
"""
import datetime as _dt
import io
import os
import re
import sys
import unicodedata

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)


# ------------------------------------------------------------------ tien ich
def khong_dau(s):
    s = unicodedata.normalize("NFD", str(s or ""))
    return "".join(c for c in s if unicodedata.category(c) != "Mn").replace("đ", "d").replace("Đ", "D")


def chuan(s):
    return re.sub(r"\s+", " ", re.sub(r"[^0-9a-z%()<>]+", " ", khong_dau(s).lower())).strip()


def chu(v):
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return re.sub(r"\s+", " ", str(v)).strip()


def sua_hoa(s):
    """VNACCS in hoa chu ASCII nhung de chu co dau thuong ("CôNG TY THươNG MạI") -> in hoa het."""
    s = chu(s)
    co_hoa = [c for c in s if c.isalpha() and c.isupper()]
    thuong = [c for c in s if c.isalpha() and c.islower()]
    if co_hoa and thuong and all(ord(c) > 127 for c in thuong):
        return s.upper()
    return s


def so(v):
    """So in to khai: '572.793.130', '45.823.450,4', '7,5', '26.143' (cham = nghin, phay = thap phan); so thuc giu nguyen."""
    if v is None or v == "" or isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip().replace("\xa0", "").replace(" ", "")
    s = s.rstrip("%")
    if not s or not re.match(r"^-?[0-9.,]+$", s):
        return None
    if "," in s:
        s = s.replace(".", "").replace(",", ".")
    elif s.count(".") >= 1:
        p = s.split(".")
        if all(len(x) == 3 for x in p[1:]):
            s = s.replace(".", "")
    try:
        return float(s)
    except ValueError:
        return None


def ngay(v):
    if isinstance(v, _dt.datetime):
        return v.date()
    if isinstance(v, _dt.date):
        return v
    if isinstance(v, (int, float)) and 20000 < v < 80000:
        return (_dt.datetime(1899, 12, 30) + _dt.timedelta(days=int(v))).date()
    m = re.search(r"(\d{1,2})/(\d{1,2})/(\d{4})", str(v or ""))
    if not m:
        return None
    try:
        return _dt.date(int(m.group(3)), int(m.group(2)), int(m.group(1)))
    except ValueError:
        return None


def mst(v):
    d = re.sub(r"\D", "", chu(v))
    if len(d) == 9:
        d = "0" + d
    return d if len(d) in (10, 12, 13) else chu(v)


def _o(row):
    """[(cot, chuoi)] cac o co chu trong dong (bo o rong)."""
    kq = []
    for c, v in enumerate(row or []):
        t = chu(v)
        if t != "":
            kq.append((c, t if not isinstance(v, float) else v))
    return kq


# ------------------------------------------------------------------ nhan
NHAN_DAU = {
    "so to khai": "so_tk", "ma loai hinh": "loai_hinh", "ngay dang ky": "ngay_dk", "ma phan loai kiem tra": "phan_luong",
    "ten co quan hai quan tiep nhan to khai": "hq", "so hoa don": "so_hd", "ngay phat hanh": "ngay_hd",
    "phuong thuc thanh toan": "pttt", "tong tri gia hoa don": "tong_tg_hd", "tong tri gia tinh thue": "tong_tg_tt",
    "ty gia tinh thue": "ty_gia", "tong tien thue phai nop": "tong_thue_nop", "ngay cap phep": "ngay_cap_phep",
    "ngay hoan thanh kiem tra": "ngay_ht_kt", "phi van chuyen": "phi_vc", "phi bao hiem": "phi_bh",
    "tong trong luong hang (gross)": "gross", "so luong container": "so_cont", "ngay hang den": "ngay_den",
    "dia diem do hang": "cang_do", "dia diem xep hang": "cang_xep", "phan ghi chu": "ghi_chu",
}
NHOM_BEN = {"nguoi nhap khau": "nk", "nguoi uy thac nhap khau": "ut", "nguoi xuat khau": "xk",
            "nguoi uy thac xuat khau": "utxk", "dai ly hai quan": "dl"}
SAC_THUE = (("gtgt", "vat"), ("tieu thu dac biet", "ttdb"), ("bao ve moi truong", "bvmt"), ("chong ban pha gia", "khac"),
            ("tu ve", "khac"), ("chong tro cap", "khac"), ("chong phan biet", "khac"))
# ky hieu sac thue o bang tong trang 1: N = nhap khau, V = GTGT, T = TTDB, M = BVMT, ...
KY_HIEU_THUE = {"N": "nk", "V": "vat", "T": "ttdb", "M": "bvmt"}


def _gia_tri_sau(cells, k):
    """o gia tri ngay sau nhan thu k (bo qua o la nhan khac)."""
    for c, t in cells[k + 1:]:
        if isinstance(t, str) and chuan(t) in NHAN_DAU:
            return None
        return t
    return None


def _so_trong(cells, tu=0):
    """so dau tien (khong phai '1.0' danh so) trong cac o tu vi tri tu."""
    for c, t in cells[tu:]:
        x = so(t)
        if x is not None:
            return x
    return None


def tim_bang(sheets):
    """chon sheet co ban in to khai nhap khau (co '<IMP>' / 'To khai hang hoa nhap khau' va so to khai)."""
    tot = None
    for ten, rows in sheets.items():
        dau = 0
        co_so = False
        for r in rows[:120]:
            for c, t in _o(r):
                if isinstance(t, str):
                    tt = chuan(t)
                    if t.strip().upper() in ("<IMP>", "<EXP>") or tt.startswith("to khai hang hoa nhap khau") or \
                            tt.startswith("to khai hang hoa xuat khau"):
                        dau += 1
            cells = _o(r)
            for k, (c, t) in enumerate(cells):
                if isinstance(t, str) and chuan(t) == "so to khai":
                    v = _gia_tri_sau(cells, k)
                    if v is not None and re.sub(r"\D", "", chu(v)):
                        co_so = True
        if dau and co_so:
            n = sum(1 for r in rows for c, t in _o(r) if isinstance(t, str) and re.match(r"^<\d{2,3}>$", t.strip()))
            if tot is None or n > tot[1]:
                tot = (ten, n)
    return tot[0] if tot else None


def doc_to_khai(sheets):
    """{sheet: [[o]]} -> (dau, dong, canh_bao). Loi -> ValueError."""
    ten = tim_bang(sheets)
    if not ten:
        raise ValueError("Không thấy bản in tờ khai hải quan (dấu <IMP>, 'Tờ khai hàng hóa nhập khẩu', Số tờ khai) trong tệp.")
    rows = sheets[ten]
    canh = []
    dau = {"sheet": ten, "xuat_khau": False, "thue_tong": {}, "ben": {}}
    dong = []
    hien = None          # dong hang dang doc
    nhom = None          # nhom ben (nguoi nhap khau...) dang doc
    muc_thue = None      # "nk" | dict thue khac dang doc
    doc_mo_ta = False
    sau_van_don = False
    sau_sac_thue = False
    for i, r in enumerate(rows):
        cells = _o(r)
        if not cells:
            continue
        texts = [(c, t) for c, t in cells if isinstance(t, str)]
        n0 = chuan(texts[0][1]) if texts else ""
        dau_dong = cells[0][1] if isinstance(cells[0][1], str) else ""
        # trang moi / lap lai dau trang
        if any(t.strip().upper() in ("<IMP>", "<EXP>") for c, t in texts):
            if any(t.strip().upper() == "<EXP>" for c, t in texts):
                dau["xuat_khau"] = True
            doc_mo_ta = False
            continue
        m = re.match(r"^<(\d{2,3})>$", dau_dong.strip()) if dau_dong else None
        if m:
            hien = {"stt": int(m.group(1)), "ma_hs": "", "mo_ta": "", "so_luong": None, "dvt": "", "sl2": None, "dvt2": "",
                    "tg_hd": None, "dg_hd": None, "tien_te": "", "tg_tt": None, "ts_nk": "", "thue_nk": 0.0,
                    "mien_nk": 0.0, "xuat_xu": "", "thue_khac": []}
            dong.append(hien)
            muc_thue, doc_mo_ta, nhom = None, False, None
            continue
        # ---- trong dong hang
        if hien is not None:
            nhan = [chuan(t) for c, t in texts]
            if doc_mo_ta and texts and not any(x in NHAN_DONG for x in nhan):
                if not any(x in NHAN_DAU for x in nhan):
                    hien["mo_ta"] = (hien["mo_ta"] + " " + " ".join(chu(t) for c, t in cells)).strip()
                    continue
            doc_mo_ta = False
            for k, (c, t) in enumerate(cells):
                if not isinstance(t, str):
                    continue
                n = chuan(t)
                if n == "ma so hang hoa":
                    hien["ma_hs"] = chu(_gia_tri_sau(cells, k) or "")
                elif n == "mo ta hang hoa":
                    hien["mo_ta"] = chu(_gia_tri_sau(cells, k) or "")
                    doc_mo_ta = True
                elif n in ("so luong (1)", "so luong (2)"):
                    gt = so(_gia_tri_sau(cells, k))
                    dv = chu(cells[k + 2][1]) if k + 2 < len(cells) else ""
                    if n.endswith("(1)"):
                        hien["so_luong"], hien["dvt"] = gt, dv
                    else:
                        hien["sl2"], hien["dvt2"] = gt, dv
                elif n == "tri gia hoa don":
                    hien["tg_hd"] = so(_gia_tri_sau(cells, k))
                elif n == "don gia hoa don":
                    hien["dg_hd"] = so(_gia_tri_sau(cells, k))
                    if k + 2 < len(cells) and re.match(r"^[A-Z]{3}$", chu(cells[k + 2][1])):
                        hien["tien_te"] = chu(cells[k + 2][1])
                elif n == "thue nhap khau":
                    muc_thue = "nk"
                elif n == "thue va thu khac":
                    muc_thue = None
                elif n == "ten" and k + 1 < len(cells):
                    ten_thue = chuan(cells[k + 1][1]) if isinstance(cells[k + 1][1], str) else ""
                    if ten_thue and not ten_thue.startswith("ma ap dung"):
                        loai = next((v for kh, v in SAC_THUE if kh in ten_thue), "khac")
                        muc_thue = {"loai": loai, "ten": chu(cells[k + 1][1]), "tg_tt": None, "ts": "", "tien": 0.0, "mien": 0.0}
                        hien["thue_khac"].append(muc_thue)
                    else:
                        muc_thue = {"loai": "", "ten": "", "tg_tt": None, "ts": "", "tien": 0.0, "mien": 0.0}
                elif n in ("tri gia tinh thue(s)", "tri gia tinh thue (s)"):
                    hien["tg_tt"] = so(_gia_tri_sau(cells, k))
                elif n == "tri gia tinh thue" and isinstance(muc_thue, dict):
                    muc_thue["tg_tt"] = so(_gia_tri_sau(cells, k))
                elif n == "thue suat":
                    pt = next((chu(x) for cc, x in cells[k + 1:] if re.search(r"%$", chu(x))), "")
                    if muc_thue == "nk":
                        hien["ts_nk"] = pt
                    elif isinstance(muc_thue, dict):
                        muc_thue["ts"] = pt
                elif n == "so tien thue":
                    v = so(_gia_tri_sau(cells, k))
                    if muc_thue == "nk":
                        hien["thue_nk"] = v or 0.0
                    elif isinstance(muc_thue, dict):
                        muc_thue["tien"] = v or 0.0
                elif n == "so tien mien giam":
                    v = so(_gia_tri_sau(cells, k)) or 0.0
                    if muc_thue == "nk":
                        hien["mien_nk"] = v
                    elif isinstance(muc_thue, dict):
                        muc_thue["mien"] = v
                elif n == "nuoc xuat xu":
                    hien["xuat_xu"] = chu(_gia_tri_sau(cells, k) or "")
            continue
        # ---- dau to khai (trang 1, 2)
        if n0 in NHOM_BEN:
            nhom = NHOM_BEN[n0]
            dau["ben"].setdefault(nhom, {})
            continue
        if nhom and n0 in ("ma", "ten", "dia chi", "ma buu chinh", "so dien thoai", "ma nuoc"):
            v = " ".join(chu(t) for c, t in cells[1:])
            b = dau["ben"][nhom]
            khoa = {"ma": "ma", "ten": "ten", "dia chi": "dia_chi", "ma buu chinh": "ma_buu_chinh", "so dien thoai": "dien_thoai",
                    "ma nuoc": "ma_nuoc"}[n0]
            b[khoa] = v
            continue
        if (nhom == "xk" and texts and texts[0][1].strip()[:1].isalpha() and n0 not in NHAN_DAU
                and dau["ben"].get("xk", {}).get("dia_chi") and cells[0][0] >= 5 and not dau["ben"]["xk"].get("ma_nuoc")):
            dau["ben"]["xk"]["dia_chi"] += " " + " ".join(chu(t) for c, t in cells)      # dia chi 2 dong
            continue
        if n0 in ("nguoi uy thac nhap khau",) or n0 in NHAN_DAU:
            nhom = None
        if n0 == "so van don":
            sau_van_don = True
        elif sau_van_don and re.match(r"^\d+(\.0)?$", chu(cells[0][1])) and len(cells) >= 2 and cells[1][0] < 12:
            v = chu(cells[1][1])
            if re.search(r"[A-Za-z0-9]{6,}", v):
                dau.setdefault("van_don", []).append(v)
        if n0 == "ten sac thue":
            sau_sac_thue = True
            continue
        if sau_sac_thue and re.match(r"^\d+(\.0)?$", chu(cells[0][1])) and len(cells) >= 3:
            ten_thue = chu(cells[1][1])
            m2 = re.match(r"^([A-Z])\s+(.*)$", ten_thue)
            tien = so(cells[2][1]) if len(cells) > 2 else None
            if m2 and tien is not None:
                dau["thue_tong"][KY_HIEU_THUE.get(m2.group(1), m2.group(1))] = tien
        for k, (c, t) in enumerate(cells):
            if not isinstance(t, str):
                continue
            n = chuan(t)
            key = NHAN_DAU.get(n)
            if not key or (key in dau and key not in ("phi_vc", "phi_bh")):
                continue
            if key == "ty_gia":
                dau["ty_gia"] = _so_trong(cells, k + 1)
                tt = [chu(x) for cc, x in cells[k + 1:] if re.match(r"^[A-Z]{3}$", chu(x))]
                if tt:
                    dau["ty_gia_tien_te"] = tt[0]
            elif key == "tong_tg_hd":
                v = chu(_gia_tri_sau(cells, k) or "")
                parts = [x.strip() for x in v.split("-")]
                dk = [x for x in parts if re.match(r"^[A-Z]{3}$", x)]
                dau["dieu_kien"] = next((x for x in dk if x in ("CIF", "FOB", "CFR", "EXW", "CIP", "CPT", "DAP", "DDP", "FCA", "DAT",
                                                                 "DPU", "FAS", "C&F", "CNF")), "")
                dau["tien_te"] = next((x for x in dk if x not in ("CIF", "FOB", "CFR", "EXW", "CIP", "CPT", "DAP", "DDP", "FCA",
                                                                  "DAT", "DPU", "FAS")), "")
                dau["tong_tg_hd"] = _so_trong(cells, k + 2)
            elif key in ("phi_vc", "phi_bh"):
                v = " ".join(chu(x) for cc, x in cells[k + 1:])
                x = _so_trong(cells, k + 1)
                if x:
                    tt = re.findall(r"\b([A-Z]{3})\b", v)
                    dau[key] = {"tien": x, "tien_te": tt[0] if tt else ""}
            elif key == "so_tk":
                dau["so_tk"] = re.sub(r"\D", "", chu(_gia_tri_sau(cells, k) or ""))
            elif key == "loai_hinh":
                dau["loai_hinh"] = (chu(_gia_tri_sau(cells, k) or "").split() or [""])[0]
            elif key in ("ngay_dk", "ngay_hd", "ngay_cap_phep", "ngay_ht_kt", "ngay_den"):
                d = ngay(_gia_tri_sau(cells, k))
                if d:
                    dau[key] = d
            elif key == "so_hd":
                v = chu(_gia_tri_sau(cells, k) or "")
                dau["so_hd"] = re.sub(r"^[A-Z]\s*-\s*", "", v).strip()
            elif key in ("tong_tg_tt", "tong_thue_nop", "gross"):
                dau[key] = _so_trong(cells, k + 1)
            else:
                v = _gia_tri_sau(cells, k)
                if v is not None:
                    dau[key] = chu(v)
    # ---- hoan thien
    nk = dau["ben"].get("nk", {})
    xk = dau["ben"].get("xk", {})
    dau["mst_nk"] = mst(nk.get("ma", ""))
    dau["ten_nk"] = sua_hoa(nk.get("ten", ""))
    dau["ten_xk"] = sua_hoa(xk.get("ten", ""))
    dau["dia_chi_xk"] = chu(xk.get("dia_chi", ""))
    dau["nuoc_xk"] = chu(xk.get("ma_nuoc", ""))
    if not dau.get("so_tk"):
        raise ValueError("Không đọc được Số tờ khai.")
    if not dong:
        raise ValueError("Tờ khai không có dòng hàng (<01>, <02>...).")
    for h in dong:
        h["mo_ta"] = chu(h["mo_ta"])
        m = re.search(r"m[aã] h[aà]ng[:\s]+([A-Za-z0-9][A-Za-z0-9./_-]*[A-Za-z0-9])", h["mo_ta"], re.I)
        h["ma_hang"] = m.group(1) if m else ""
        m = re.search(r"hi[eệ]u[:\s]+([A-Za-z0-9][A-Za-z0-9 &._-]{0,30}?)(?:[.,;]|$|\s+m[oớ]i)", h["mo_ta"], re.I)
        h["hieu"] = m.group(1).strip() if m else ""
        for t in h["thue_khac"]:
            t["tien"] = t["tien"] or 0.0
        h["vat"] = sum(t["tien"] for t in h["thue_khac"] if t["loai"] == "vat")
        h["ttdb"] = sum(t["tien"] for t in h["thue_khac"] if t["loai"] == "ttdb")
        h["bvmt"] = sum(t["tien"] for t in h["thue_khac"] if t["loai"] == "bvmt")
        h["thue_khac_vao_gia"] = sum(t["tien"] for t in h["thue_khac"] if t["loai"] == "khac")
        h["ts_vat"] = next((t["ts"] for t in h["thue_khac"] if t["loai"] == "vat"), "")
        if not h["tien_te"]:
            h["tien_te"] = dau.get("tien_te", "")
        if h["so_luong"] is None:
            canh.append("Dòng <%02d>: không đọc được số lượng." % h["stt"])
        if h["tg_hd"] is None:
            canh.append("Dòng <%02d>: không đọc được trị giá hoá đơn." % h["stt"])
    # ---- kiem tra tong
    def lech(a, b, nguong):
        return a is not None and b is not None and abs(a - b) > nguong
    s_hd = sum(h["tg_hd"] or 0 for h in dong)
    s_tt = sum(h["tg_tt"] or 0 for h in dong)
    s_vat = sum(h["vat"] for h in dong)
    s_nk = sum(h["thue_nk"] for h in dong)
    if lech(dau.get("tong_tg_hd"), s_hd, 0.05):
        canh.append("Tổng trị giá hoá đơn trên tờ khai %s khác cộng các dòng %s." % (_t(dau["tong_tg_hd"], 2), _t(s_hd, 2)))
    if lech(dau.get("tong_tg_tt"), s_tt, max(2, 0.5 * len(dong))):
        canh.append("Tổng trị giá tính thuế %s khác cộng các dòng %s." % (_t(dau["tong_tg_tt"]), _t(s_tt)))
    if "vat" in dau["thue_tong"] and lech(dau["thue_tong"]["vat"], s_vat, max(2, 1.0 * len(dong))):
        canh.append("Tổng thuế GTGT %s khác cộng các dòng %s." % (_t(dau["thue_tong"]["vat"]), _t(s_vat)))
    if "nk" in dau["thue_tong"] and lech(dau["thue_tong"]["nk"], s_nk, max(2, 1.0 * len(dong))):
        canh.append("Tổng thuế nhập khẩu %s khác cộng các dòng %s." % (_t(dau["thue_tong"]["nk"]), _t(s_nk)))
    so_dong_tk = None
    for r in rows[:200]:
        cells = _o(r)
        for k, (c, t) in enumerate(cells):
            if isinstance(t, str) and chuan(t) == "tong so dong hang cua to khai":
                so_dong_tk = _so_trong(cells, k + 1)
    if so_dong_tk and int(so_dong_tk) != len(dong):
        canh.append("Tờ khai ghi %d dòng hàng, đọc được %d dòng." % (int(so_dong_tk), len(dong)))
    dau["so_dong"] = len(dong)
    dau["ngay_ghi_so"] = dau.get("ngay_cap_phep") or dau.get("ngay_dk")
    if not dau.get("ngay_cap_phep"):
        canh.append("Chưa có ngày cấp phép thông quan - tạm lấy ngày đăng ký tờ khai.")
    return dau, dong, canh


NHAN_DONG = {"ma so hang hoa", "mo ta hang hoa", "so luong (1)", "so luong (2)", "tri gia hoa don", "don gia hoa don",
             "thue nhap khau", "thue va thu khac", "so cua muc khai khoan dieu chinh", "tri gia tinh thue(s)"}


def _t(x, le=0):
    try:
        s = ("{:,.%df}" % le).format(x)
        return s.replace(",", "X").replace(".", ",").replace("X", ".")
    except Exception:
        return str(x)


def doc_tep(path):
    import tool_trich_xuat_so_phu as CU
    b = CU.doc_excel(path)
    return doc_to_khai(dict(b))


# ------------------------------------------------------------------ phan bo
def phan_bo(dau, dong, chi_phi=None, ty_gia=None):
    """chi_phi: [{"ten", "tien" (VND chua thue), "tieu_thuc": "gia_tri"|"so_luong"|"thu_cong", "ty_le": [..] (thu cong)}]
       -> list dong ket qua (them: gia_tri_vnd, cp[k], cp_tong, gia_nhap, don_gia_nhap) + tong."""
    ty_gia = ty_gia or dau.get("ty_gia") or 1.0
    kq = []
    for h in dong:
        gt = round((h["tg_hd"] or 0.0) * ty_gia)
        kq.append(dict(h, gia_tri_vnd=gt, cp=[], cp_tong=0.0))
    for cp in chi_phi or []:
        tien = float(cp.get("tien") or 0)
        tt = cp.get("tieu_thuc") or "gia_tri"
        if tt == "so_luong":
            w = [x["so_luong"] or 0.0 for x in kq]
        elif tt == "thu_cong":
            w = list(cp.get("ty_le") or [])
            w += [0.0] * (len(kq) - len(w))
        else:
            w = [x["gia_tri_vnd"] for x in kq]
        tw = sum(w)
        phan = [round(tien * wi / tw) if tw else 0.0 for wi in w]
        if tw and phan:
            cuoi = max(i for i, wi in enumerate(w) if wi) if any(w) else len(w) - 1
            phan[cuoi] += round(tien) - sum(phan)          # chenh lech lam tron don ve dong co trong so cuoi cung
        for x, p in zip(kq, phan):
            x["cp"].append(p)
            x["cp_tong"] += p
    for x in kq:
        x["gia_nhap"] = x["gia_tri_vnd"] + x["thue_nk"] + x["ttdb"] + x["bvmt"] + x["thue_khac_vao_gia"] + x["cp_tong"]
        x["don_gia_nhap"] = x["gia_nhap"] / x["so_luong"] if x["so_luong"] else 0.0
    tong = {k: sum(x[k] for x in kq) for k in ("gia_tri_vnd", "thue_nk", "ttdb", "bvmt", "thue_khac_vao_gia", "cp_tong",
                                               "gia_nhap", "vat")}
    tong["tg_hd"] = sum(x["tg_hd"] or 0 for x in kq)
    return kq, tong


TK_MAC_DINH = {"kho": "1561", "cp": "1562", "nk": "3333", "ttdb": "3332", "ncc": "331", "vat": "1331", "vat_nop": "33312"}


def _tk(tk):
    d = dict(TK_MAC_DINH)
    d.update({k: v for k, v in (tk or {}).items() if v})
    return d


def but_toan(dau, kq, tong, chi_phi=None, tk_kho="1561", tk_cp="1562"):
    """But toan de xuat (TT133): mot chung tu theo to khai, ngay thong quan."""
    bt = []
    for x in kq:
        bt.append(("Nợ", tk_kho, x["gia_nhap"], "Dòng <%02d> %s" % (x["stt"], (x["ma_hang"] or x["mo_ta"])[:40])))
    bt.append(("Có", "331", tong["gia_tri_vnd"], "%s %s x tỷ giá %s - %s" % (_t(tong["tg_hd"], 2), dau.get("tien_te") or "",
                                                                          _t(dau.get("ty_gia") or 0), dau.get("ten_xk") or "")))
    if tong["thue_nk"]:
        bt.append(("Có", "3333", tong["thue_nk"], "Thuế nhập khẩu"))
    if tong["ttdb"]:
        bt.append(("Có", "3332", tong["ttdb"], "Thuế TTĐB hàng nhập khẩu"))
    if tong["bvmt"]:
        bt.append(("Có", "33381", tong["bvmt"], "Thuế bảo vệ môi trường"))
    if tong["thue_khac_vao_gia"]:
        bt.append(("Có", "3339", tong["thue_khac_vao_gia"], "Thuế / thu khác vào giá"))
    if tong["cp_tong"]:
        bt.append(("Có", tk_cp, tong["cp_tong"], "Chi phí nhập hàng phân bổ vào giá nhập kho"))
    if tong["vat"]:
        bt.append(("Nợ", "1331", tong["vat"], "Thuế GTGT hàng nhập khẩu (tờ khai %s)" % dau.get("so_tk", "")))
        bt.append(("Có", "33312", tong["vat"], "Thuế GTGT hàng nhập khẩu phải nộp"))
    return bt


# ------------------------------------------------------------------ Excel phan tich / phan bo (cong thuc song)
CP_MAU = ["Cước vận chuyển quốc tế (giá FOB / EXW)", "Phí local charge (THC, D/O, CIC, vệ sinh cont...)",
          "Phí dịch vụ khai hải quan, lệ phí hải quan", "Phí nâng hạ, lưu container / lưu kho bãi",
          "Phí kiểm hoá, giám định, kiểm tra chuyên ngành", "Vận chuyển nội địa (cảng -> kho)", "Chi phí khác"]


def xuat_excel(dau, dong, ra, chi_phi=None, canh=None, tk_kho="1561", tk_cp="1562", tk=None):
    """Excel 4 sheet: PhanBo (chi phi nhap tay -> cong thuc phan bo tung dong), ToKhai, ButToan, CachTinh.
       tk = {kho, cp, nk, ttdb, ncc, vat, vat_nop}: so hieu TK cua so (GD105: phan mem truyen TK la dang dung)."""
    from xlsx_viet import SoExcel, CT
    tk = _tk(dict({"kho": tk_kho, "cp": tk_cp}, **(tk or {})))
    tk_kho, tk_cp = tk["kho"], tk["cp"]
    chi_phi = list(chi_phi or [])
    ds_cp = chi_phi + [{"ten": t, "tien": 0, "tieu_thuc": "gia_tri"} for t in CP_MAU[len(chi_phi):]] if len(chi_phi) < len(CP_MAU) \
        else chi_phi
    kq, tong = phan_bo(dau, dong, ds_cp)
    nc = len(ds_cp)
    wb = SoExcel(font="Times New Roman", co=11)
    k_tieu = wb.kieu(dam=True, co=14)
    k_dam = wb.kieu(dam=True)
    k_td = wb.kieu(dam=True, nen="D9E1F2", khung=True, can="giua", xuong=True)
    k_ch = wb.kieu(khung=True, xuong=True)
    k_so = wb.kieu(so="#,##0", khung=True)
    k_so2 = wb.kieu(so="#,##0.00", khung=True)
    k_nhap = wb.kieu(so="#,##0", khung=True, nen="FFF2CC")
    k_nhap_ch = wb.kieu(khung=True, nen="FFF2CC", can="giua")
    k_tong = wb.kieu(so="#,##0", khung=True, dam=True, nen="E2EFDA")
    k_tong2 = wb.kieu(so="#,##0.00", khung=True, dam=True, nen="E2EFDA")
    k_nghieng = wb.kieu(nghieng=True, mau="595959")
    k_ngay = wb.kieu(so="dd/mm/yyyy")
    # ---- PhanBo
    w = [5, 11, 12, 46, 6, 9, 11, 13, 16, 13, 13] + [14] * nc + [15, 17, 15, 15, 16]
    ws = wb.sheet("PhanBo", cot=w)
    ws.o(1, 1, "BẢNG PHÂN BỔ GIÁ NHẬP KHO HÀNG NHẬP KHẨU - TỜ KHAI %s" % dau.get("so_tk", ""), k_tieu)
    ws.o(2, 1, "Người xuất khẩu: %s (%s)   |   Hoá đơn: %s ngày %s   |   Điều kiện giao hàng: %s   |   Ngày thông quan: %s" % (
        dau.get("ten_xk", ""), dau.get("nuoc_xk", ""), dau.get("so_hd", ""), dau["ngay_hd"].strftime("%d/%m/%Y") if dau.get("ngay_hd") else "",
        dau.get("dieu_kien", ""), dau["ngay_ghi_so"].strftime("%d/%m/%Y") if dau.get("ngay_ghi_so") else ""))
    ws.o(3, 1, "Tỷ giá ghi sổ (tỷ giá tính thuế tờ khai, %s):" % (dau.get("tien_te") or ""), k_dam)
    ws.o(3, 4, dau.get("ty_gia") or 0, k_nhap)
    ws.o(3, 5, "<- sửa được; giá trị VND = trị giá hoá đơn x tỷ giá", k_nghieng)
    r0 = 5
    ws.o(r0, 1, "CHI PHÍ NHẬP HÀNG - anh nhập số tiền CHƯA VAT (ô vàng); tiêu thức: GT = theo giá trị hàng, SL = theo số lượng",
         k_dam)
    ws.dong(r0 + 1, 1, [("STT", k_td), ("Khoản chi phí", k_td), (None, k_td), (None, k_td), ("Số tiền (VND)", k_td),
                        ("Tiêu thức", k_td), ("Nguồn (HĐ số, nhà cung cấp)", k_td)])
    ws.gop(r0 + 1, 2, r0 + 1, 4)
    cp_dong = []
    for k, cp in enumerate(ds_cp):
        r = r0 + 2 + k
        cp_dong.append(r)
        ws.o(r, 1, k + 1, k_ch)
        ws.gop(r, 2, r, 4)
        ws.dong(r, 2, [(cp.get("ten", ""), k_ch), (None, k_ch), (None, k_ch)])
        ws.o(r, 5, float(cp.get("tien") or 0), k_nhap)
        ws.o(r, 6, "SL" if cp.get("tieu_thuc") == "so_luong" else "GT", k_nhap_ch)
        ws.o(r, 7, cp.get("nguon", ""), k_nhap_ch)
    r_tong_cp = r0 + 2 + nc
    ws.o(r_tong_cp, 2, "Tổng chi phí nhập hàng", k_dam)
    ws.o(r_tong_cp, 5, CT("=SUM(E%d:E%d)" % (cp_dong[0], cp_dong[-1]), tong["cp_tong"]), k_tong)
    # bang dong hang
    rh = r_tong_cp + 2
    td = ["STT", "Mã HS", "Mã hàng", "Mô tả hàng hoá (theo tờ khai)", "ĐVT", "Số lượng", "Đơn giá HĐ (%s)" % (dau.get("tien_te") or "NT"),
          "Trị giá HĐ (%s)" % (dau.get("tien_te") or "NT"), "Giá trị hàng (VND)", "Thuế nhập khẩu", "TTĐB, BVMT, thuế khác"]
    td += ["CP %d" % (k + 1) for k in range(nc)]
    td += ["Tổng CP phân bổ", "GIÁ NHẬP KHO", "Đơn giá nhập kho", "Thuế GTGT NK (khấu trừ)", "Trị giá tính thuế (TK)"]
    ws.dong(rh, 1, [(t, k_td) for t in td])
    ws.cao(rh, 45)
    d1 = rh + 1
    dn = rh + len(kq)
    from xlsx_viet import dia_chi as _dc

    def cot(c):
        return re.sub(r"\d", "", _dc(1, c))
    c_sl, c_gt, c_nk, c_tk = 6, 9, 10, 11
    c_cp0 = 12
    c_tcp = c_cp0 + nc
    c_gn = c_tcp + 1
    for i, x in enumerate(kq):
        r = d1 + i
        ws.dong(r, 1, [(x["stt"], k_ch), (x["ma_hs"], k_ch), (x["ma_hang"], k_ch), (x["mo_ta"], k_ch), (x["dvt"], k_ch),
                       (x["so_luong"] or 0, k_so2), (x["dg_hd"] or 0, k_so2), (x["tg_hd"] or 0, k_so2)])
        ws.o(r, c_gt, CT("=ROUND(H%d*$D$3,0)" % r, x["gia_tri_vnd"]), k_so)
        ws.o(r, c_nk, x["thue_nk"], k_so)
        ws.o(r, c_tk, x["ttdb"] + x["bvmt"] + x["thue_khac_vao_gia"], k_so)
        for k in range(nc):
            ck = cot(c_cp0 + k)
            ok = "$E$%d" % cp_dong[k]
            tc = "$F$%d" % cp_dong[k]
            if r < dn:
                f = ('=IF(%s=0,0,ROUND(%s*IF(%s="SL",%s%d/SUM($%s$%d:$%s$%d),%s%d/SUM($%s$%d:$%s$%d)),0))'
                     % (ok, ok, tc, cot(c_sl), r, cot(c_sl), d1, cot(c_sl), dn, cot(c_gt), r, cot(c_gt), d1, cot(c_gt), dn))
            else:
                f = "=%s-SUM(%s%d:%s%d)" % (ok, ck, d1, ck, dn - 1) if dn > d1 else "=%s" % ok
            ws.o(r, c_cp0 + k, CT(f, x["cp"][k]), k_so)
        ws.o(r, c_tcp, CT("=SUM(%s%d:%s%d)" % (cot(c_cp0), r, cot(c_tcp - 1), r), x["cp_tong"]), k_so)
        ws.o(r, c_gn, CT("=%s%d+%s%d+%s%d+%s%d" % (cot(c_gt), r, cot(c_nk), r, cot(c_tk), r, cot(c_tcp), r), x["gia_nhap"]), k_tong)
        ws.o(r, c_gn + 1, CT("=IF(%s%d=0,0,%s%d/%s%d)" % (cot(c_sl), r, cot(c_gn), r, cot(c_sl), r), x["don_gia_nhap"]), k_so2)
        ws.o(r, c_gn + 2, round(x["vat"]), k_so)
        ws.o(r, c_gn + 3, x["tg_tt"] or 0, k_so)
    rt = dn + 1
    ws.o(rt, 4, "CỘNG", k_dam)
    for c in [c_sl, 8, c_gt, c_nk, c_tk] + list(range(c_cp0, c_gn + 1)) + [c_gn + 2, c_gn + 3]:
        ws.o(rt, c, CT("=SUM(%s%d:%s%d)" % (cot(c), d1, cot(c), dn), 0), k_tong2 if c in (c_sl, 8) else k_tong)
    ws.dong_bang(rh + 1, 5)
    # ---- ButToan
    wbt = wb.sheet("ButToan", cot=[6, 12, 18, 60])
    wbt.o(1, 1, "BÚT TOÁN ĐỀ XUẤT (TT133) - một chứng từ nhập kho theo tờ khai, ngày thông quan", k_tieu)
    wbt.dong(3, 1, [(t, k_td) for t in ("Nợ/Có", "Tài khoản", "Số tiền", "Diễn giải")])
    tong_ref = lambda c: "PhanBo!%s%d" % (cot(c), rt)
    vat_tk = round(dau.get("thue_tong", {}).get("vat", tong["vat"]))          # so thue GTGT tong tren to khai (so nop)
    dong_bt = [("Nợ", tk_kho, "=" + tong_ref(c_gn), tong["gia_nhap"], "Hàng nhập kho từng mã (giá nhập kho cột GIÁ NHẬP KHO)"),
               ("Có", tk["ncc"], "=" + tong_ref(c_gt), tong["gia_tri_vnd"], "Phải trả %s: %s %s x tỷ giá" % (
                   dau.get("ten_xk", ""), _t(tong["tg_hd"], 2), dau.get("tien_te", ""))),
               ("Có", tk["nk"], "=" + tong_ref(c_nk), tong["thue_nk"], "Thuế nhập khẩu"),
               ("Có", tk["ttdb"] + " / 33381 / 3339", "=" + tong_ref(c_tk), tong["ttdb"] + tong["bvmt"] + tong["thue_khac_vao_gia"],
                "TTĐB / BVMT / thuế khác (nếu có)"),
               ("Có", tk_cp, "=" + tong_ref(c_tcp), tong["cp_tong"], "Chi phí nhập hàng đã ghi Nợ %s (chờ phân bổ) -> vào giá nhập kho" % tk_cp),
               ("Nợ", tk["vat"], vat_tk, vat_tk, "Thuế GTGT hàng nhập khẩu theo tờ khai %s (cộng từng dòng lệch làm tròn: %s)" % (
                   dau.get("so_tk", ""), _t(round(tong["vat"])))),
               ("Có", tk["vat_nop"], vat_tk, vat_tk, "Thuế GTGT hàng nhập khẩu phải nộp")]
    for i, (nc_, tk_d, f, v, dg) in enumerate(dong_bt):
        r = 4 + i
        wbt.dong(r, 1, [(nc_, k_ch), (tk_d, k_ch)])
        wbt.o(r, 3, CT(f, v) if isinstance(f, str) else v, k_so)
        wbt.o(r, 4, dg, k_ch)
    r = 4 + len(dong_bt) + 1
    for s in ["Khi nhận hoá đơn chi phí nhập hàng (trước hoặc sau ngày thông quan): Nợ %s (Mã hợp đồng = số tờ khai %s) / Nợ %s / Có %s, 111, 112."
              % (tk_cp, dau.get("so_tk", ""), tk["vat"], tk["ncc"]),
              "Trong phần mềm: Kho > Chi phí và giá vốn hàng nhập khẩu - chọn tháng, tờ khai -> Phân bổ (theo giá trị / số lượng) -> Xử lý "
              "(lập chứng từ nhập kho) -> Ghi.",
              "Nộp thuế: Nợ %s, %s / Có 112. Trả tiền người bán nước ngoài: Nợ %s (tỷ giá ghi sổ) / Có 1122 (tỷ giá thực tế), chênh lệch "
              "vào 515 / 635." % (tk["nk"], tk["vat_nop"], tk["ncc"]),
              "Chi phí đến sau khi đã xuất bán một phần: phần của hàng còn tồn vào 156, phần của hàng đã bán vào 632."]:
        wbt.o(r, 1, s)
        r += 1
    # ---- ToKhai
    wt = wb.sheet("ToKhai", cot=[34, 70])
    wt.o(1, 1, "THÔNG TIN TỜ KHAI", k_tieu)
    tt = [("Số tờ khai", dau.get("so_tk")), ("Mã loại hình", dau.get("loai_hinh")), ("Phân luồng / mã kiểm tra", dau.get("phan_luong")),
          ("Hải quan tiếp nhận", dau.get("hq")), ("Ngày đăng ký", dau.get("ngay_dk")), ("Ngày cấp phép (thông quan)", dau.get("ngay_cap_phep")),
          ("Ngày ghi sổ đề xuất", dau.get("ngay_ghi_so")), ("Người nhập khẩu", "%s - MST %s" % (dau.get("ten_nk", ""), dau.get("mst_nk", ""))),
          ("Người xuất khẩu", "%s (%s)" % (dau.get("ten_xk", ""), dau.get("nuoc_xk", ""))), ("Địa chỉ người xuất khẩu", dau.get("dia_chi_xk")),
          ("Số vận đơn", ", ".join(dau.get("van_don") or [])), ("Hoá đơn thương mại", "%s ngày %s" % (
              dau.get("so_hd", ""), dau["ngay_hd"].strftime("%d/%m/%Y") if dau.get("ngay_hd") else "")),
          ("Phương thức thanh toán", dau.get("pttt")), ("Điều kiện giao hàng", dau.get("dieu_kien")),
          ("Tổng trị giá hoá đơn", "%s %s" % (_t(dau.get("tong_tg_hd") or 0, 2), dau.get("tien_te", ""))),
          ("Tỷ giá tính thuế", _t(dau.get("ty_gia") or 0)), ("Tổng trị giá tính thuế (VND)", _t(dau.get("tong_tg_tt") or 0)),
          ("Thuế GTGT hàng NK (tờ khai)", _t(dau.get("thue_tong", {}).get("vat", tong["vat"]))),
          ("Thuế nhập khẩu (cộng dòng)", _t(tong["thue_nk"])), ("Tổng thuế phải nộp", _t(dau.get("tong_thue_nop") or 0)),
          ("Số dòng hàng", len(kq)), ("Cảng xếp / dỡ", "%s -> %s" % (dau.get("cang_xep", ""), dau.get("cang_do", ""))),
          ("Tổng trọng lượng (gross, kg)", dau.get("gross")), ("Ghi chú tờ khai", dau.get("ghi_chu"))]
    for i, (a, b) in enumerate(tt):
        wt.o(3 + i, 1, a, k_dam)
        wt.o(3 + i, 2, b, k_ngay if isinstance(b, _dt.date) else None)
    r = 4 + len(tt)
    wt.o(r, 1, "Kiểm tra", k_dam)
    for s in (canh or ["Tổng trị giá hoá đơn, trị giá tính thuế, thuế GTGT khớp cộng các dòng."]):
        wt.o(r, 2, s)
        r += 1
    # ---- CachTinh
    wc = wb.sheet("CachTinh", cot=[110])
    for i, s in enumerate([
            "CÁCH TÍNH GIÁ NHẬP KHO HÀNG NHẬP KHẨU",
            "1. Giá trị hàng = trị giá hoá đơn (ngoại tệ) x tỷ giá ghi sổ (tỷ giá tính thuế trên tờ khai - lựa chọn của anh).",
            "2. Thuế nhập khẩu, TTĐB, BVMT, chống bán phá giá... tính TỪNG DÒNG trên tờ khai -> cộng thẳng vào giá dòng đó (không chia lại).",
            "3. Chi phí nhập hàng (cước quốc tế nếu giá FOB/EXW, local charge, phí hải quan, nâng hạ, kiểm hoá, vận chuyển nội địa...) là chi phí",
            "   chung của cả lô -> chia cho từng dòng theo tiêu thức: GT = tỷ lệ giá trị hàng (mặc định, hợp lý khi hàng nhiều loại, nhiều ĐVT),",
            "   SL = tỷ lệ số lượng (chỉ khi các dòng cùng đơn vị, kích cỡ gần nhau). Làm tròn đồng; chênh lệch làm tròn dồn vào dòng cuối.",
            "4. Giá nhập kho = giá trị hàng + thuế NK + thuế khác vào giá + chi phí phân bổ. Đơn giá nhập kho = giá nhập kho / số lượng.",
            "5. Thuế GTGT hàng nhập khẩu KHÔNG vào giá (được khấu trừ): Nợ 1331 / Có 33312; hoá đơn GTGT đầu vào là chính tờ khai.",
            "6. Giá CIF đã gồm cước và bảo hiểm quốc tế -> không cộng thêm cước quốc tế; chỉ cộng chi phí phát sinh tại Việt Nam.",
            "7. Ngày chứng từ nhập kho = ngày thông quan (cấp phép) - lựa chọn của anh; thiếu ngày cấp phép thì lấy ngày đăng ký.",
            "8. Ô vàng sửa được; các cột còn lại là công thức, sửa ô vàng thì bảng tự tính lại."]):
        wc.o(1 + i, 1, s, k_tieu if i == 0 else None)
    tam = ra + ".tmp.xlsx"
    wb.luu(tam)
    os.replace(tam, ra)
    return kq, tong


# ------------------------------------------------------------------ GD105: giao tiep voi phan mem (VB6)
DVT_HQ = {"PCE": "Cái", "PCS": "Cái", "SET": "Bộ", "KIT": "Bộ", "KGM": "Kg", "KG": "Kg", "GRM": "Gam", "TNE": "Tấn", "MTR": "Mét",
          "M": "Mét", "MTK": "m2", "SQM": "m2", "MTQ": "m3", "CBM": "m3", "LTR": "Lít", "PR": "Đôi", "NPR": "Đôi", "UNT": "Chiếc",
          "UNIT": "Chiếc", "BX": "Hộp", "BOX": "Hộp", "CT": "Thùng", "CTN": "Thùng", "CS": "Thùng", "ROL": "Cuộn", "RO": "Cuộn",
          "BG": "Bao", "BAG": "Bao", "PK": "Gói", "PAC": "Gói", "SHT": "Tờ", "ST": "Tờ", "DZN": "Tá", "DOZ": "Tá", "BTL": "Chai",
          "BO": "Chai", "CAN": "Lon", "CA": "Lon", "PAL": "Pallet", "PL": "Pallet", "DR": "Phuy", "LOT": "Lô", "TU": "Tuýp",
          "TUB": "Tuýp", "BLL": "Thùng", "VI": "Lọ", "AMP": "Ống", "CAR": "Thùng", "PAI": "Đôi", "BUN": "Bó", "BE": "Bó"}


def dvt_viet(ma):
    """Ma don vi tinh VNACCS (PCE, SET, KGM...) -> ten tieng Viet de tao vat tu; khong biet -> giu nguyen."""
    m = str(ma or "").strip()
    return DVT_HQ.get(m.upper(), m)


def ten_vt(mo_ta):
    """Mo ta hang tren to khai -> ten vat tu gon: bo 'hang moi 100%', khoang trang thua; toi da 150 ky tu."""
    t = re.sub(r"[,;.]?\s*(?:hàng\s+)?(?:mới|moi|new)\s*100\s*%\.?", "", str(mo_ta or ""), flags=re.I)
    t = re.sub(r"\s+", " ", t).strip(" ,.;:-")
    if len(t) > 150:
        k = max(t.rfind(",", 0, 150), t.rfind(" ", 0, 150))
        t = t[:k if k > 60 else 150].rstrip(" ,.;:-")
    return t


def _sach(v):
    return re.sub(r"[\r\n|]+", " ", str(v if v is not None else "")).strip()


def _so_vb(x):
    """So cho VB6 Val(): dau cham thap phan, khong phan cach nghin, khong dang mu."""
    try:
        x = float(x or 0)
    except Exception:
        return "0"
    if x == int(x) and abs(x) < 1e15:
        return str(int(x))
    return ("%.6f" % x).rstrip("0").rstrip(".")


def _ngay_vb(d):
    return d.strftime("%d/%m/%Y") if isinstance(d, (_dt.date, _dt.datetime)) else _sach(d)


def ket_qua_vb(dau, dong, canh):
    """-> chuoi UTF-8 cho phan mem: OK|so dong|so canh bao ; DAU|khoa|gia tri ; DONG|... ; CANH|..."""
    tg = dau.get("ty_gia") or 0.0
    tt = dau.get("thue_tong") or {}
    out = ["OK|%d|%d" % (len(dong), len(canh or []))]
    dd = [("so_tk", dau.get("so_tk")), ("loai_hinh", dau.get("loai_hinh")), ("phan_luong", dau.get("phan_luong")),
          ("hq", dau.get("hq")), ("ngay_dk", _ngay_vb(dau.get("ngay_dk"))), ("ngay_cap_phep", _ngay_vb(dau.get("ngay_cap_phep"))),
          ("ngay_ghi_so", _ngay_vb(dau.get("ngay_ghi_so") or dau.get("ngay_dk"))), ("mst_nk", dau.get("mst_nk")),
          ("ten_nk", dau.get("ten_nk")), ("ten_xk", dau.get("ten_xk")), ("dia_chi_xk", dau.get("dia_chi_xk")),
          ("nuoc_xk", dau.get("nuoc_xk")), ("tien_te", dau.get("tien_te")), ("ty_gia", _so_vb(tg)),
          ("tong_tg_hd", _so_vb(dau.get("tong_tg_hd"))), ("tong_tg_tt", _so_vb(dau.get("tong_tg_tt"))),
          ("thue_nk", _so_vb(sum(h.get("thue_nk") or 0 for h in dong))), ("thue_vat", _so_vb(round(tt.get("vat", sum(h.get("vat") or 0 for h in dong))))),
          ("thue_ttdb", _so_vb(sum(h.get("ttdb") or 0 for h in dong))), ("thue_bvmt", _so_vb(sum(h.get("bvmt") or 0 for h in dong))),
          ("thue_khac", _so_vb(sum(h.get("thue_khac_vao_gia") or 0 for h in dong))), ("tong_thue_nop", _so_vb(dau.get("tong_thue_nop"))),
          ("so_hd", dau.get("so_hd")), ("ngay_hd", _ngay_vb(dau.get("ngay_hd"))), ("van_don", ", ".join(dau.get("van_don") or [])),
          ("dieu_kien", dau.get("dieu_kien")), ("pttt", dau.get("pttt")), ("ghi_chu", dau.get("ghi_chu")), ("so_dong", str(len(dong)))]
    out += ["DAU|%s|%s" % (k, _sach(v)) for k, v in dd]
    for h in dong:
        tg_vnd = round((h.get("tg_hd") or 0.0) * tg)
        out.append("|".join(["DONG", str(h.get("stt") or 0), _sach(h.get("ma_hang")), _sach(h.get("ma_hs")), _sach(h.get("mo_ta")),
                             _sach(ten_vt(h.get("mo_ta"))), _sach(h.get("dvt")), _sach(dvt_viet(h.get("dvt"))), _so_vb(h.get("so_luong")),
                             _so_vb(h.get("dg_hd")), _so_vb(h.get("tg_hd")), _so_vb(tg_vnd), _so_vb(h.get("tg_tt")), _sach(h.get("ts_nk")),
                             _so_vb(h.get("thue_nk")), _sach(h.get("ts_vat")), _so_vb(h.get("vat")), _so_vb(h.get("ttdb")),
                             _so_vb(h.get("bvmt")), _so_vb(h.get("thue_khac_vao_gia")), _sach(h.get("xuat_xu")), _sach(h.get("hieu"))]))
    out += ["CANH|%s" % _sach(c) for c in canh or []]
    return "\r\n".join(out) + "\r\n"


def doc_tep_chi_phi(p):
    """Tep phan mem ghi (UTF-8): TK|kho|cp|nk|ttdb|ncc|vat|vat_nop ; TG|ty gia ; CP|ten|tien|gia_tri/so_luong|nguon."""
    tk, cp, tg = {}, [], None
    if not p or not os.path.isfile(p):
        return tk, cp, tg
    with io.open(p, "r", encoding="utf-8-sig") as f:
        for dong in f:
            o = dong.rstrip("\r\n").split("|")
            if o[0] == "TK" and len(o) >= 8:
                tk = dict(zip(("kho", "cp", "nk", "ttdb", "ncc", "vat", "vat_nop"), [x.strip() for x in o[1:8]]))
            elif o[0] == "TG" and len(o) >= 2:
                try:
                    tg = float(o[1].strip().replace(",", ".")) or None          # VB6 Str$(): dau cham thap phan
                except ValueError:
                    tg = None
            elif o[0] == "CP" and len(o) >= 3:
                cp.append({"ten": o[1], "tien": float((o[2] or "0").strip().replace(",", ".")), "tieu_thuc": (o[3] if len(o) > 3 and o[3] else "gia_tri"),
                           "nguon": o[4] if len(o) > 4 else ""})
    return tk, cp, tg


def chay_cho_vb(xlsx, ra, excel_ra="", cp_tep=""):
    """GD105: phan mem goi (tool_so_phu_unesco /to_khai): doc to khai -> ra (UTF-8, OK|... / LOI|...); co excel_ra thi
       lap them Excel phan tich phan bo (chi phi + TK lay tu cp_tep). Ghi tam roi doi ten (phan mem doi tep xuat hien)."""
    def ghi_ra(nd):
        tam = ra + ".tam"
        with io.open(tam, "w", encoding="utf-8", newline="") as f:
            f.write(nd)
        os.replace(tam, ra)
    try:
        dau, dong, canh = doc_tep(xlsx)
        if dau.get("xuat_khau"):
            raise ValueError("Đây là tờ khai XUẤT khẩu - chức năng này chỉ nhận tờ khai NHẬP khẩu.")
        if not dong:
            raise ValueError("Không đọc được dòng hàng nào trong tờ khai.")
        if not dau.get("ty_gia") and (dau.get("tien_te") or "VND").upper() == "VND":
            dau["ty_gia"] = 1.0          # hoa don bang VND: khong co ty gia
        if not dau.get("ty_gia"):
            raise ValueError("Không đọc được tỷ giá tính thuế trên tờ khai.")
        nd = ket_qua_vb(dau, dong, canh)
        if excel_ra:
            tk, cp, tg = doc_tep_chi_phi(cp_tep)
            if tg:
                dau = dict(dau, ty_gia=tg)
            xuat_excel(dau, dong, excel_ra, cp or None, canh, tk=tk)
        ghi_ra(nd)
        return True
    except Exception as e:
        ghi_ra("LOI|%s\r\n" % _sach(e))
        return False


if __name__ == "__main__":
    if len(sys.argv) >= 3 and sys.argv[1] == "--vb":
        ok = chay_cho_vb(sys.argv[2], sys.argv[3], sys.argv[4] if len(sys.argv) > 4 else "", sys.argv[5] if len(sys.argv) > 5 else "")
        sys.exit(0 if ok else 1)
    d, dg, cb = doc_tep(sys.argv[1])
    print(d.get("so_tk"), d.get("ten_xk"), len(dg), cb)
