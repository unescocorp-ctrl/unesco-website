# -*- coding: utf-8 -*-
"""TASK271_280 (UNESCO XII) - bo kiem CHU KY Ed25519 cua mo ta goi cap nhat, goi tu VB.NET (AiUpdateService.UpdVerifySignature).

Chi la lop noi (adapter): dung NGUYEN ky_so_ed25519.kiem (RFC 8032, Python thuan) va cap_nhat_online.doc_khoa / tham_so (khoa cong
khai AIHoaDon\\cap_nhat_khoa_cong_khai.txt, tham so /thamso:"<tep UTF-8>") - KHONG co ban cai dat Ed25519 thu hai, KHONG sua cac tool
GD143. Khong tai, khong cai, khong ghi gi ngoai moc ket qua.

  python xii_kiem_chu_ky.py --tep <unesco_cap_nhat.json> --chu-ky <unesco_cap_nhat.json.sig> [--khoa <64 hex>] [--ket-qua <thu muc>]
Moc: <ket-qua>\\DA_XONG_KIEMKY (mac dinh AIHoaDon\\ket-qua) dong dau "OK <tep>" (chu ky dung) hoac "LOI <ly do>". Ma thoat 0 / 1.
"""
import io
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)
MOC = "DA_XONG_KIEMKY"


def ghi_moc(thu_muc, noi_dung):
    os.makedirs(thu_muc, exist_ok=True)
    p = os.path.join(thu_muc, MOC)
    tam = "%s.%d.tam" % (p, os.getpid())
    with io.open(tam, "w", encoding="utf-8") as f:
        f.write(noi_dung)
    os.replace(tam, p)


def kiem_tep(tep, tep_ky, khoa_hex=None):
    """-> '' (chu ky dung) hoac ly do. Khong bao gio nem loi."""
    import ky_so_ed25519 as K
    try:
        if khoa_hex:
            khoa = bytes.fromhex(khoa_hex) if re.match(r"^[0-9a-fA-F]{64}$", khoa_hex) else None
        else:
            import cap_nhat_online as C
            khoa = C.doc_khoa()
        if khoa is None:
            return "chua co khoa kiem chu ky (AIHoaDon\\cap_nhat_khoa_cong_khai.txt)"
        with open(tep, "rb") as f:
            du_lieu = f.read((1 << 20) + 1)
        if len(du_lieu) > (1 << 20):
            return "mo ta goi qua lon"
        with open(tep_ky, "rb") as f:
            ck = f.read(4097)
        if len(ck) > 4096:
            return "tep chu ky qua lon"
        try:
            sig = bytes.fromhex(ck.decode("ascii", "replace").strip())
        except ValueError:
            sig = b""
        return "" if K.kiem(khoa, du_lieu, sig) else "chu ky KHONG dung khoa cua nha phat hanh"
    except Exception as e:  # noqa: BLE001 - every failure is a refusal
        return "khong kiem duoc: %s" % e


def main(argv=None):
    a = list(sys.argv[1:] if argv is None else argv)
    try:
        import cap_nhat_online as C
        a = C.tham_so(a)
    except Exception:
        pass

    def lay(k):
        return a[a.index(k) + 1] if k in a and a.index(k) + 1 < len(a) else ""
    kq = lay("--ket-qua") or os.path.join(HERE, "ket-qua")
    tep, tep_ky = lay("--tep"), lay("--chu-ky")
    if not tep or not tep_ky:
        ghi_moc(kq, "LOI thieu --tep / --chu-ky")
        return 1
    ly_do = kiem_tep(tep, tep_ky, lay("--khoa") or None)
    ghi_moc(kq, ("OK " + tep) if not ly_do else ("LOI " + ly_do))
    return 0 if not ly_do else 1


if __name__ == "__main__":
    sys.exit(main())
