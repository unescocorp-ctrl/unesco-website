# -*- coding: utf-8 -*-
"""GD330 - TO KHAI DANG KY THUE TONG HOP NGUOI PHU THUOC CUA CA NHAN CO THU NHAP TU TIEN LUONG, TIEN CONG - mau 20/DK-TH-TCT
(Thong tu 86/2024/TT-BTC; HTKK: 20-DK-TH-TCT TT86/2024, maTKhai 1137, XML 2.8.3, XSD 20_TH_DK_TCT_TT86). To chuc tra thu nhap dang
ky thay cho nguoi phu thuoc (NPT) cua nguoi lao dong. Thay mau Crystal GiaCanh.RPT (man hinh Giam tru gia canh -> Xem).
Hop dong xuat_1_lan.py: lap(dl, "DK_NPT", kieu, thumuc) -> {"tep": [...], "canh_bao": [...]}. CHI DOC SO.
So lieu: dl["tncn"]["npt"] (GiaCanh: manv, ten, ngaysinh, mst, cmnd, quanhe, tuthang, denthang) + dl["tncn"]["nv"] (ho so NV).
Lap Excel dung mau (in / ky) + XML HSoThueDTu theo khuon HTKK, tu kiem XSD cua HTKK tren may (neu co).
Muc I: NPT co MST hoac so dinh danh / ho chieu. Muc II: NPT chua co MST / dinh danh (ke giay khai sinh).
Khong ghi so CCCD / MST vao nhat ky (chi co trong tep)."""
import os
import re
import xml.etree.ElementTree as ET

import qtt_tncn as Q
from qtt_tncn import _ds, _dn, _ngay_lap, _nguoi_ky, _kieu, _cot_chia

MA_TKHAI = "1137"
MA_FILE = "20_TH_DK_TCT_TT86"
PBAN_XML = "2.8.3"
TEN_TKHAI = "Tờ khai đăng ký thuế tổng hợp NPT của CN có thu nhập từ tiền lương, tiền công"
MO_TA = "(Kèm theo Thông tư số 86/2024/TT-BTC ngày 23/12/2024 của Bộ Trưởng Bộ Tài chính)"

COT1 = ["STT", "Họ và tên người phụ thuộc", "MST người phụ thuộc\n(nếu có)", "Ngày sinh", "Quốc tịch", "Số định danh cá nhân",
        "Hộ chiếu\n(số, ngày cấp, nơi cấp)", "Địa chỉ thường trú", "Địa chỉ hiện tại", "Quan hệ với cá nhân có thu nhập",
        "Họ và tên cá nhân có thu nhập", "MST của cá nhân có thu nhập", "Thời điểm bắt đầu tính giảm trừ\n(tháng/năm)",
        "Thời điểm kết thúc tính giảm trừ\n(tháng/năm)"]
RONG1 = [5, 24, 13, 11, 10, 15, 14, 18, 18, 13, 22, 14, 12, 12]
COT2 = ["STT", "Họ và tên người phụ thuộc", "Ngày sinh", "Giấy khai sinh: Số", "Ngày cấp", "Nơi đăng ký khai sinh\n(quốc gia, tỉnh, huyện, xã)",
        "Quốc tịch", "Quan hệ với cá nhân có thu nhập", "Họ và tên cá nhân có thu nhập", "MST của cá nhân có thu nhập"]


def _thang_nam(s, nam, cuoi):
    """'3' | '03/2025' | '3/25' -> 'MM/YYYY'; thieu nam -> nam dang lap; rong / khong doc duoc -> '' (den: chua ket thuc)."""
    m = re.match(r"\s*(\d{1,2})(?:\D+(\d{2,4}))?", str(s or ""))
    if not m or not 1 <= int(m.group(1)) <= 12:
        return "" if cuoi else "01/%d" % nam
    y = int(m.group(2)) if m.group(2) else nam
    if y < 100:
        y += 2000
    return "%02d/%d" % (int(m.group(1)), y)


def _giao_nam(tu, den, nam):
    """NPT co giam tru trong nam dang lap?"""
    def ym(s):
        m = re.match(r"(\d{2})/(\d{4})", s or "")
        return (int(m.group(2)), int(m.group(1))) if m else None
    a, b = ym(tu), ym(den)
    if a and a > (nam, 12):
        return False
    if b and b < (nam, 1):
        return False
    return True


def tong_hop(dl):
    t = dl.get("tncn")
    if not isinstance(t, dict):
        raise RuntimeError("JSON không có phần \"tncn\" (bản phần mềm chưa có GĐ78 ModHDDTTNCN?)")
    nam = Q._nguyen(t.get("nam")) or Q._nguyen((dl.get("x1l") or {}).get("nam_tc"))
    nv = {}
    for r in t.get("nv") or []:
        v = Q._nv(r)
        if v["manv"]:
            nv[v["manv"]] = v
    ds1, ds2, cb, ngoai, thieu_nnt, cu9, khong_ns = [], [], [], [], [], [], []
    for r in t.get("npt") or []:
        r = list(r) + [""] * 8
        manv, ten = Q._nguyen(r[0]), Q._ten_sach(r[1])
        if not ten:
            continue
        tu, den = _thang_nam(r[6], nam, False), _thang_nam(r[7], nam, True)
        if not _giao_nam(tu, den, nam):
            ngoai.append(ten)
            continue
        v = nv.get(manv) or {"ten": "", "mst": "", "cccd": "", "quoc_tich": "", "nghi": 0}
        dd_nnt = Q.dinh_danh(v.get("mst"), v.get("cccd"), v.get("quoc_tich"), nam)
        mst_nnt = dd_nnt["ct08"]
        if not mst_nnt:
            thieu_nnt.append(v.get("ten") or ("NV %d" % manv))
        mst = re.sub(r"[^0-9-]", "", str(r[3] or "")).strip("-")
        if not Q.RE_TIN.fullmatch(mst or ""):
            mst = ""
        goc = str(r[4] or "").strip()
        g = re.sub(r"[^0-9A-Za-z]", "", goc).upper()
        if set(g) <= {"0"}:
            g = ""
        qm, qt = Q.quan_he_npt(r[5])
        ns = Q._ngay_iso_npt(r[2])
        if not ns:
            khong_ns.append(ten)
        ns_hien = "%s/%s/%s" % (ns[8:10], ns[5:7], ns[:4]) if ns else str(r[2] or "").strip()
        x = {"ten": ten, "ngay_sinh": ns_hien, "ns_iso": ns, "mst": mst, "qh_ma": qm, "qh": qt,
             "nnt": v.get("ten") or "", "mst_nnt": mst_nnt, "tu": tu, "den": den, "so_dd": "", "ho_chieu": "", "gks": ""}
        if g.isdigit() and len(g) == 12:
            x["so_dd"] = g
            ds1.append(x)
        elif mst:
            if g.isdigit() and len(g) == 9:
                cu9.append(ten)
            ds1.append(x)
        elif g and not g.isdigit() and re.search(r"[A-Z]", g) and not re.search(r"GKS|KHAISINH|/", Q._bo_dau_hoa(goc).replace(" ", "")):
            x["ho_chieu"] = g
            ds1.append(x)
        else:
            if g.isdigit() and len(g) == 9:
                cu9.append(ten)
            x["gks"] = goc if not (g.isdigit() and len(g) == 9) else ""
            ds2.append(x)
    cb.append("20/ĐK-TH-TCT năm %d: %d người phụ thuộc mục I (có MST / số định danh / hộ chiếu), %d người mục II (chưa có, kê giấy khai sinh)."
              % (nam, len(ds1), len(ds2)))
    cb.append("Chỉ nộp cho người phụ thuộc ĐĂNG KÝ LẦN ĐẦU hoặc THAY ĐỔI thông tin; người đã đăng ký các năm trước thì xoá dòng đó trên HTKK "
              "trước khi nộp.")
    if ngoai:
        cb.append("Không kê %d người phụ thuộc có thời gian giảm trừ ngoài năm %d: %s." % (len(ngoai), nam, _ds(ngoai)))
    if thieu_nnt:
        cb.append("Người lao động CHƯA có MST / số định danh trong hồ sơ (cột MST cá nhân có thu nhập để trống): %s." % _ds(thieu_nnt))
    if cu9:
        cb.append("Người phụ thuộc còn CMND 9 số - thay bằng số định danh cá nhân 12 số: %s." % _ds(cu9))
    if khong_ns:
        cb.append("Thiếu / sai ngày sinh người phụ thuộc (bắt buộc): %s." % _ds(khong_ns))
    if ds2:
        cb.append("Mục II: bổ sung nơi đăng ký khai sinh (quốc gia, tỉnh, huyện, xã) và ngày cấp giấy khai sinh trên HTKK - phần mềm chưa "
                  "lưu các thông tin này.")
    cb.append("Địa chỉ người phụ thuộc: công dân Việt Nam có số định danh thì cơ quan thuế tự lấy theo CSDL dân cư (để trống).")
    return {"nam": nam, "ds1": ds1, "ds2": ds2, "canh_bao": cb}


# ------------------------------------------------------------------ Excel
def lap_excel(dl, kq, duong, cb):
    from xlsx_viet import SoExcel
    wb = SoExcel(font="Times New Roman", co=11)
    K = _kieu(wb)
    dn = _dn(dl)
    so_cot = len(RONG1)
    ws = wb.sheet("20-DK-TH-TCT", cot=RONG1)
    c_mau = _cot_chia(RONG1, tu_phai=40)
    ws.gop(1, 1, 1, c_mau - 1, "CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM", K["qh"])
    ws.gop(2, 1, 2, c_mau - 1, "Độc lập - Tự do - Hạnh phúc", K["qh2"])
    ws.gop(1, c_mau, 3, so_cot, "Mẫu số: 20/ĐK-TH-TCT\n(Ban hành kèm theo Thông tư số 86/2024/TT-BTC ngày 23/12/2024\ncủa Bộ trưởng Bộ Tài chính)", K["mau"])
    ws.cao(3, 42)
    r = 5
    ws.gop(r, 1, r, so_cot, "TỜ KHAI ĐĂNG KÝ THUẾ TỔNG HỢP NGƯỜI PHỤ THUỘC CỦA CÁ NHÂN CÓ THU NHẬP TỪ TIỀN LƯƠNG, TIỀN CÔNG", K["td"])
    r += 1
    ws.gop(r, 1, r, so_cot, "(Dùng cho tổ chức, cá nhân trả thu nhập đăng ký thuế thay cho người phụ thuộc của cá nhân có thu nhập)", K["td2"])
    r += 2
    ws.gop(r, 1, r, so_cot, "[X] Đăng ký thuế                 [   ] Thay đổi thông tin đăng ký thuế", K["qh"])
    r += 2
    ws.gop(r, 1, r, so_cot, "1. Tên tổ chức, cá nhân trả thu nhập: %s" % dn.get("ten", ""), K["b"])
    r += 1
    ws.gop(r, 1, r, so_cot, "2. Mã số thuế: %s" % dn.get("mst", ""), K["b"])
    r += 2
    ws.gop(r, 1, r, so_cot, "3. Thông tin về người phụ thuộc và cá nhân có thu nhập:", K["b"])
    r += 1
    ws.gop(r, 1, r, so_cot, "I. Người phụ thuộc đã có mã số thuế, hoặc chưa có mã số thuế nhưng có số định danh cá nhân / hộ chiếu", K["b"])
    r += 1
    ws.dong(r, 1, COT1, K["h"])
    ws.cao(r, 60)
    r += 1
    ws.dong(r, 1, ["(%d)" % (i + 1) for i in range(so_cot)], K["hm"])
    r += 1
    dau = r
    for i, x in enumerate(kq["ds1"], 1):
        ws.dong(r, 1, [(i, K["cg"]), (x["ten"], K["c"]), (x["mst"], K["txt"]), (x["ngay_sinh"], K["cg"]), ("Việt Nam", K["cg"]),
                       (x["so_dd"], K["txt"]), (x["ho_chieu"], K["c"]), ("", K["c"]), ("", K["c"]), (x["qh"], K["cg"]), (x["nnt"], K["c"]),
                       (x["mst_nnt"], K["txt"]), (x["tu"], K["cg"]), (x["den"], K["cg"])])
        r += 1
    if r == dau:
        ws.gop(r, 1, r, so_cot, "(Không có)", K["ghi"])
        r += 1
    r += 1
    ws.gop(r, 1, r, so_cot, "II. Người phụ thuộc chưa có mã số thuế, số định danh cá nhân, hộ chiếu (kê theo giấy khai sinh)", K["b"])
    r += 1
    ws.dong(r, 1, COT2, K["h"])
    ws.cao(r, 60)
    r += 1
    ws.dong(r, 1, ["(%d)" % (i + 23) for i in range(len(COT2))], K["hm"])
    r += 1
    dau2 = r
    for i, x in enumerate(kq["ds2"], 1):
        ws.dong(r, 1, [(i, K["cg"]), (x["ten"], K["c"]), (x["ngay_sinh"], K["cg"]), (x["gks"], K["txt"]), ("", K["cg"]), ("", K["c"]),
                       ("Việt Nam", K["cg"]), (x["qh"], K["cg"]), (x["nnt"], K["c"]), (x["mst_nnt"], K["txt"])])
        r += 1
    if r == dau2:
        ws.gop(r, 1, r, len(COT2), "(Không có)", K["ghi"])
        r += 1
    r += 1
    ws.gop(r, 1, r, so_cot, "Tôi cam đoan những nội dung kê khai là đúng và chịu trách nhiệm trước pháp luật về những nội dung đã khai./.", K["ghi"])
    r += 2
    lap = _ngay_lap(dl)
    giua = _cot_chia(RONG1, ty_le=0.55)
    ws.gop(r, giua, r, so_cot, "..., ngày %02d tháng %02d năm %d" % (lap.day, lap.month, lap.year), K["ky2"])
    r += 1
    ws.gop(r, giua, r, so_cot, "NGƯỜI NỘP THUẾ hoặc\nĐẠI DIỆN HỢP PHÁP CỦA NGƯỜI NỘP THUẾ", K["ky"])
    ws.cao(r, 45)
    r += 1
    ws.gop(r, giua, r, so_cot, "(Ký, ghi rõ họ tên; chức vụ và đóng dấu (nếu có)/Ký điện tử)", K["ky2"])
    r += 4
    ws.gop(r, giua, r, so_cot, _nguoi_ky(dl), K["ky"])
    ws.in_trang(ngang=True, lap_dong=(dau - 2, dau - 1))
    ws2 = wb.sheet("Ghi chu", cot=[120])
    ws2.o(1, 1, "GHI CHÚ KHI LẬP 20/ĐK-TH-TCT", K["qh"])
    rr = 3
    for c in cb:
        ws2.o(rr, 1, "- " + c, K["ghi"])
        ws2.cao(rr, 15 * max(1, (len(c) + 119) // 120))
        rr += 1
    wb.luu(duong)
    return duong


# ------------------------------------------------------------------ XML HTKK
def _e(cha, ten, gt=None):
    return Q._e(cha, ten, gt)


def _nil(cha, ten, gt=""):
    n = Q._e(cha, ten)
    if gt:
        n.text = str(gt)
    else:
        n.set("{%s}nil" % Q.NS_XSI, "true")
    return n


def lap_xml_goc(dl, kq, cb):
    dn = _dn(dl)
    hd, pb = Q._htkk(dl)
    lap = _ngay_lap(dl)
    goc = ET.Element("{%s}HSoThueDTu" % Q.NS)
    hs = _e(goc, "HSoKhaiThue")
    hs.set("id", "ID_1")
    tc = _e(hs, "TTinChung")
    dv = _e(tc, "TTinDVu")
    _e(dv, "maDVu", "HTKK")
    _e(dv, "tenDVu", "HỖ TRỢ KÊ KHAI THUẾ")
    _e(dv, "pbanDVu", pb or "5.8.1")
    _e(dv, "ttinNhaCCapDVu", Q._ttin_nha_ccap())
    tt = _e(tc, "TTinTKhaiThue")
    _e(tt, "maTKhai", MA_TKHAI)
    _e(tt, "tenTKhai", TEN_TKHAI)
    _e(tt, "moTaBMau", MO_TA)
    _e(tt, "pbanTKhaiXML", PBAN_XML)
    mst = re.sub(r"[^0-9-]", "", str(dn.get("mst") or hd.get("mst") or "")).strip("-")
    _nil(tt, "mst", mst if Q.RE_TIN.fullmatch(mst or "") else "")
    _e(tt, "tenNNT", str(dn.get("ten") or hd.get("tenNNT") or ""))
    ma_cqt, ten_cqt = hd.get("maCQTNoiNop", ""), hd.get("tenCQTNoiNop", "")
    if not ma_cqt:
        ma_cqt, ten_cqt = str(dn.get("ma_cqt") or ""), str(dn.get("ten_cqt") or "")
    if not ma_cqt:
        cb.append("XML 20/ĐK-TH-TCT: thiếu mã cơ quan thuế quản lý - chọn lại trên HTKK trước khi nộp.")
    _nil(tt, "maCQTQuanLy", ma_cqt)
    _nil(tt, "tenCQTQuanLy", ten_cqt)
    _nil(tt, "ngayNhanTKhai")
    _nil(tt, "noiNhanTKhai")
    _nil(tt, "soGiayTo_id")
    _nil(tt, "nghiepVuCapMST")
    _e(tt, "ngayKy", lap.strftime("%Y-%m-%d"))
    _nil(tt, "nguoiKy", _nguoi_ky(dl))
    _e(tt, "nhanKQQuaBuuDien", "false")
    dly = _e(tt, "DLyThue")
    _nil(dly, "tenDLyThue")
    _nil(dly, "mstDLyThue")
    _nil(dly, "soHDongDLyThue")
    _nil(dly, "ngayKyHDDLyThue")
    nv = _e(dly, "NVienDLy")
    _nil(nv, "tenNVienDLyThue")
    _nil(nv, "cchiHNghe")
    ct = _e(hs, "CTieuTKhaiChinh")
    _e(ct, "dangKyThue", "true")
    _e(ct, "thayDoiTTin", "false")
    for i, x in enumerate(kq["ds1"], 1):
        b = _e(ct, "DSachNPTDaCoMST")
        b.set("id", "ID_%d" % i)
        _e(b, "recordID", str(i))
        _e(b, "ct2", x["ten"])
        _nil(b, "ct3", x["ns_iso"])
        _nil(b, "ct4", x["mst"])
        _e(b, "ct5_ma", "VN")
        _e(b, "ct5", "Việt Nam")
        _e(b, "songNuocNgoai", "false")
        _e(b, "cmndKeKhaiSai", "false")
        _nil(b, "soDinhDanh", x["so_dd"])
        c6 = _e(b, "CT6")
        if x["ho_chieu"]:
            _e(c6, "ct6_ma", "02")
            _e(c6, "ct6_soGiayTo", x["ho_chieu"])
            _e(c6, "ct6_ten", "Hộ chiếu")
        else:
            _nil(c6, "ct6_ma")
            _nil(c6, "ct6_soGiayTo")
            _nil(c6, "ct6_ten")
        _nil(c6, "ct6_ngayCap")
        _nil(c6, "ct6_noiCap_ma")
        _nil(c6, "ct6_noiCap_ten")
        for ten_dc, ma in (("DCThuongTru", ("ct25", "ct26_ma", "ct26", "ct27_ma", "ct27", "ct28_ma", "ct28")),
                           ("DCHienTai", ("ct29", "ct30_ma", "ct30", "ct31_ma", "ct31", "ct32_ma", "ct32"))):
            d = _e(b, ten_dc)
            for m in ma:
                _nil(d, m)
        _e(b, "ct7_ma", x["qh_ma"])
        _e(b, "ct7", x["qh"])
        _nil(b, "ct8", x["nnt"])
        _nil(b, "ct9", x["mst_nnt"])
        _nil(b, "tuThangGiamTru", x["tu"])
        _nil(b, "denThangGiamTru", x["den"])
    for i, x in enumerate(kq["ds2"], 1):
        b = _e(ct, "DSachNPTChuaCoMST")
        b.set("id", "ID_%d" % i)
        _e(b, "recordID", str(i))
        _e(b, "ct13", x["ten"])
        _nil(b, "ct13_mst")
        _nil(b, "ct14", x["ns_iso"])
        _nil(b, "ct15", x["gks"])
        _nil(b, "ct16")
        _e(b, "ct17_ma", "VN")
        _e(b, "ct17", "Việt Nam")
        for m in ("ct18_ma", "ct18", "ct19_ma", "ct19", "ct20_ma", "ct20"):
            _nil(b, m)
        _e(b, "ct21_ma", "VN")
        _e(b, "ct21", "Việt Nam")
        _e(b, "ct22_ma", x["qh_ma"])
        _e(b, "ct22", x["qh"])
        _nil(b, "ct23", x["nnt"])
        _nil(b, "ct24", x["mst_nnt"])
    return goc


def lap(dl, ma="DK_NPT", kieu="EX", thumuc="."):
    kieu = (kieu or "EX").upper()
    kq = tong_hop(dl)
    cb = kq["canh_bao"]
    nam = kq["nam"] or 0
    tep = []
    if not kq["ds1"] and not kq["ds2"]:
        cb.insert(0, "Không có người phụ thuộc nào cần kê trong năm %d (màn hình Giảm trừ gia cảnh chưa nhập)." % nam)
    p = os.path.join(thumuc, "20_DK_TH_TCT_NPT_%d.xml" % nam)
    goc = lap_xml_goc(dl, kq, cb)
    Q.ghi_xml(goc, p)
    try:                                                     # XSD cua HTKK tren may
        import tool_htkk_unesco as X
        cach, lx = X.kiem_xsd_htkk(p, MA_FILE)
        if cach == "xsd":
            cb.append("XML 20/ĐK-TH-TCT: " + ("HỢP LỆ theo XSD của HTKK." if not lx else "CHƯA HỢP LỆ theo XSD của HTKK: %s" % "; ".join(lx[:4])))
    except Exception:
        pass
    tep.append(p)
    if "E" in kieu or "X" not in kieu:
        p2 = os.path.join(thumuc, "20_DK_TH_TCT_NPT_%d.xlsx" % nam)
        lap_excel(dl, kq, p2, list(cb))
        tep.insert(0, p2)
    return {"tep": tep, "canh_bao": cb}
