# -*- coding: utf-8 -*-
"""GD353 - KIEM SOAT NO PHAI THU KHO DOI: tuoi no, du phong, ho so trich lap / xoa no (xem truoc, chi DOC .MDB qua jet_doc).

Can cu (doi chieu van ban goc truoc khi ky):
  - Thong tu 48/2019/TT-BTC (sua doi, bo sung boi Thong tu 24/2022/TT-BTC; VBHN 16/VBHN-BTC 07/07/2022) Dieu 6:
      khoan 1 dieu kien: chung tu goc (hop dong, khe uoc, cam ket no, bien ban doi chieu, bang ke cong no...); no qua han tu 6 thang
              (theo han tra no goc, khong tinh gia han) da doi chieu / don doc / gui van ban doi no ma chua thu duoc; no chua den han
              nhung co bang chung doi tuong no pha san, giai the, mat tich, bo tron, bi truy to / giam giu / xet xu / thi hanh an, da chet.
      khoan 2 muc trich: 30 % (6 thang - < 1 nam), 50 % (1 - < 2 nam), 70 % (2 - < 3 nam), 100 % (>= 3 nam); chua den han: doanh nghiep
              tu du kien muc ton that, toi da bang gia tri khoan no.
      khoan 4 xu ly no khong thu hoi duoc: dieu kien (pha san / giai the / ngung hoat dong; ca nhan chet, mat tich, truy to...; duoc xoa no
              theo quyet dinh co tham quyen; da trich 100 % du phong sau 3 nam ke tu ngay trich 100 % van khong thu duoc va da thuc hien
              bien phap thu hoi); ho so: bien ban Hoi dong xu ly no (gia tri tung khoan, da thu hoi, thiet hai thuc te), bang ke chi tiet,
              so ke toan / chung tu, giay to phap ly; tham quyen HDQT / HDTV / Chu tich / Giam doc / chu so huu; nguon bu dap = du phong da
              trich, phan thieu tinh vao chi phi; no da xu ly van theo doi rieng >= 10 nam (toi da 15 nam), thu hoi duoc -> thu nhap khac.
  - Dieu 3: thoi diem trich lap / hoan nhap = thoi diem lap BCTC nam.
  - TT133 / TT99: Trich Nợ 642 (6422) / Có 2293; hoan nhap nguoc lai; xoa no Nợ 2293 (phan da trich) + Nợ 642 (phan thieu) / Có 131, 138;
    thu hoi no da xoa Nợ 111, 112 / Có 711. Chi phi trich dung quy dinh la chi phi duoc tru (TT96/2015 Dieu 4), sai / thieu ho so -> loai.

Tuoi no: FIFO theo doi tuong (tien thu tru dan khoan no cu nhat). Du dau nam: truy nguoc so nam truoc cung MST (toi da 3 nam) trong
thu muc so va DATA; khong co -> 'chua ro tuoi' (ghi NGAY_NO_CU trong tep ho so). Han thanh toan: ChungTu.HanTT; khong co -> HAN_NGAY
cua doi tuong (tep ho so) hoac HAN_MAC_DINH ngay (ghi ro 'gia dinh').
Tep ho so theo so (nguoi dung dien, may chi doc): <chinh-sach cua so>\\no_kho_doi_ho_so.txt
  MA_KH;TEN;HAN_NGAY;HOP_DONG;DOI_CHIEU;DOI_NO;TINH_TRANG;VAN_BAN;TON_THAT_PCT;NGAY_NO_CU;GHI_CHU
  TINH_TRANG: PHA_SAN, GIAI_THE, NGUNG_HD, MAT_TICH, CHET, TRUY_TO, XOA_NO_QD (trong = binh thuong).
Ra: ket-qua\\no_kho_doi.txt (';', dong dau TONG), no_kho_doi.html, thu muc ho so no_kho_doi_ho_so\\ (bang ke, bien ban, quyet dinh, thu
doi no, bien ban doi chieu, so theo doi no da xu ly - HTML A4, mo bang Word duoc). K61 trong Kiem tra truoc khoa so (k_no_kho_doi).
May KHONG ghi but toan: chi de xuat, nguoi lap phieu sau khi Giam doc ky quyet dinh."""
import datetime as _dt
import glob
import html
import io
import os
import re
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
TEP = "no_kho_doi"
TEP_HS = "no_kho_doi_ho_so.txt"
HAN_MAC_DINH = 30                    # ngay, khi chung tu khong co HanTT va doi tuong chua khai HAN_NGAY
MUC_TRICH = ((36, 1.0), (24, 0.7), (12, 0.5), (6, 0.3))      # (so thang qua han toi thieu, ty le) - TT48 Dieu 6 khoan 2 diem a
NAM_SAU_100 = 3                      # xoa no: da trich 100 % sau 3 nam van chua thu duoc
NAM_THEO_DOI = 10                    # theo doi no da xu ly toi thieu 10 nam
SO_NAM_TRUY = 3
TINH_TRANG = {"PHA_SAN": "đã phá sản / đang làm thủ tục phá sản", "GIAI_THE": "đã giải thể / đang giải thể",
              "NGUNG_HD": "ngừng hoạt động, không có khả năng chi trả", "MAT_TICH": "mất tích / bỏ trốn",
              "CHET": "cá nhân đã chết", "TRUY_TO": "bị truy tố, giam giữ, xét xử, thi hành án",
              "XOA_NO_QD": "được xoá nợ theo quyết định của cơ quan có thẩm quyền"}
COT_HS = ("MA_KH", "TEN", "HAN_NGAY", "HOP_DONG", "DOI_CHIEU", "DOI_NO", "TINH_TRANG", "VAN_BAN", "TON_THAT_PCT", "NGAY_NO_CU", "GHI_CHU")


def _f(x):
    try:
        return float(x or 0)
    except (TypeError, ValueError):
        return 0.0


def _i(x):
    try:
        return int(_f(x))
    except (TypeError, ValueError):
        return 0


def _s(x):
    return str(x if x is not None else "").replace(";", ",").replace("\r", " ").replace("\n", " ").strip()


def _dd(v):
    try:
        return "{:,.0f}".format(round(float(v))).replace(",", ".")
    except (TypeError, ValueError):
        return ""


def _ngay(v):
    if isinstance(v, _dt.datetime):
        d = v.date()
    elif isinstance(v, _dt.date):
        d = v
    else:
        m = re.match(r"\s*(\d{1,2})/(\d{1,2})/(\d{4})", str(v or ""))
        if not m:
            m2 = re.match(r"\s*(\d{4})-(\d{1,2})-(\d{1,2})", str(v or ""))
            if not m2:
                return None
            try:
                d = _dt.date(int(m2.group(1)), int(m2.group(2)), int(m2.group(3)))
            except ValueError:
                return None
        else:
            try:
                d = _dt.date(int(m.group(3)), int(m.group(2)), int(m.group(1)))
            except ValueError:
                return None
    return d if d.year > 1990 else None


def _nd(d):
    return d.strftime("%d/%m/%Y") if d else ""


def cong_thang(d, n):
    y, m = divmod(d.month - 1 + n, 12)
    y += d.year
    m += 1
    import calendar
    return _dt.date(y, m, min(d.day, calendar.monthrange(y, m)[1]))


def so_thang(tu, den):
    """so thang tron tu 'tu' den 'den' (den >= cong_thang(tu, n))."""
    if not tu or not den or den <= tu:
        return 0
    n = (den.year - tu.year) * 12 + den.month - tu.month
    while n > 0 and cong_thang(tu, n) > den:
        n -= 1
    return max(n, 0)


def ty_le_tuoi(thang_qh):
    for t, tl in MUC_TRICH:
        if thang_qh >= t:
            return tl
    return 0.0


def _u(d, s):
    s = str(s if s is not None else "").strip()
    if not s or s == "...":
        return ""
    try:
        import bang_luong_gd78 as B
        f = d.get("_font")
        if f is None:
            f = str((d.get("lic") or {}).get("FontName") or "").upper()
            d["_font"] = f
        if f.startswith("VNI"):
            return B.vni_sang_u(s)
        if f.startswith(".VN") or f.startswith("VN"):
            return B.tcvn3_sang_u(s)
        loai = B.loai_ma([s])
        if loai == "VNI":
            return B.vni_sang_u(s)
        if loai == "TCVN3":
            return B.tcvn3_sang_u(s)
    except Exception:
        pass
    return s


# ------------------------------------------------------------------ doc so
def doc(duong, chi_license=False):
    import jet_doc
    m = jet_doc.Mdb(duong)
    try:
        bang = {b.lower(): b for b in m.bang()}

        def tb(t, n=None):
            k = bang.get(t.lower())
            return m.doc(k, n) if k else []
        lic = (tb("License", 1) or [{}])[0]
        d = {"duong": duong, "lic": lic, "nam": _i(lic.get("NamTC")) or _dt.date.today().year, "dau_ky": _i(lic.get("Thang")) or 1,
             "mst": re.sub(r"\D", "", str(lic.get("MaSoThue") or ""))}
        if not 1 <= d["dau_ky"] <= 12:
            d["dau_ky"] = 1
        if chi_license:
            return d
        htk = tb("HeThongTK")
        d["tk"] = {r["MaSo"]: str(r.get("SoHieu") or "").strip() for r in htk}
        d["tk_dau"] = {r["MaSo"]: (_f(r.get("DuNo_0")), _f(r.get("DuCo_0"))) for r in htk}
        d["kh"] = {r["MaSo"]: r for r in tb("KhachHang")}
        d["cn_dau"] = tb("CNDauNam")
        d["hd"] = tb("DoituongCT")
        keep = []
        for r in tb("ChungTu"):
            n, c = d["tk"].get(r.get("MaTKNo"), ""), d["tk"].get(r.get("MaTKCo"), "")
            if n.startswith(("131", "1388", "2293", "711")) or c.startswith(("131", "1388", "2293", "711")):
                keep.append({k: r.get(k) for k in ("MaCT", "MaLoai", "ThangCT", "SoHieu", "NgayCT", "DienGiai", "MaTKNo", "MaTKCo", "SoPS", "MaKH", "MaKHC", "HanTT")})
        d["ct"] = keep
        return d
    finally:
        try:
            m.dong()
        except Exception:
            pass


def ngay_cuoi_nam(d):
    """ngay cuoi nam tai chinh (ngay lap BCTC nam)."""
    dau = _dt.date(d["nam"], d["dau_ky"], 1)
    return cong_thang(dau, 12) - _dt.timedelta(days=1)


def ngay_dau_nam(d):
    return _dt.date(d["nam"], d["dau_ky"], 1)


def che_do(d):
    c = str((d.get("lic") or {}).get("CheDoTT") or "")
    return "TT99" if "99" in c or "200" in c else "TT133"


def tk_chi_phi(d):
    co = set(d["tk"].values())
    if che_do(d) == "TT99":
        return "6426" if "6426" in co else "642"
    return "6422" if "6422" in co else "642"


def _la(d, tien_to):
    return {m for m, sh in d["tk"].items() if sh.startswith(tien_to)}


def _kh_khoa(d, ma):
    k = d["kh"].get(ma) or {}
    return str(k.get("SoHieu") or "").strip().upper(), re.sub(r"\D", "", str(k.get("MST") or ""))


# ------------------------------------------------------------------ FIFO
def khoan_mo(d, den=None, tien_to="131", dau_kh=None):
    """-> {MaKH: {"hd": [[ngay|None, con, sh, dg, han]], "thua": x, "dau": x}} tai ngay 'den'.
       dau_kh: {MaKH: [[ngay, con, sh, dg, han], ...]} khoan du dau nam da truy tuoi (thay cho dong du dau nam)."""
    la = _la(d, tien_to)
    den = den or ngay_cuoi_nam(d)
    dau = defaultdict(float)
    for r in d["cn_dau"]:
        if r.get("MaTaiKhoan") in la:
            dau[_i(r.get("MaKhachHang"))] += _f(r.get("DuNo_0")) - _f(r.get("DuCo_0"))
    ps = defaultdict(list)
    for r in d["ct"]:
        ng = _ngay(r.get("NgayCT"))
        if not ng or ng > den:
            continue
        p = _f(r.get("SoPS"))
        if not p:
            continue
        han = _ngay(r.get("HanTT"))
        sh, dg = _u(d, r.get("SoHieu")), _u(d, r.get("DienGiai"))
        if r.get("MaTKNo") in la:
            ps[_i(r.get("MaKH"))].append((ng, 0, p, sh, dg, han))
        if r.get("MaTKCo") in la:
            ps[_i(r.get("MaKHC"))].append((ng, 1, p, sh, dg, han))
    ra = {}
    for kh in set(dau) | set(ps):
        hd = []
        d0 = dau.get(kh, 0.0)
        thua = 0.0
        if d0 > 0.5:
            tr = (dau_kh or {}).get(kh)
            if tr:
                con = d0
                for x in sorted(tr, key=lambda v: v[0] or _dt.date(1900, 1, 1), reverse=True):   # FIFO: phan con lai la khoan moi nhat
                    if con <= 0.5:
                        break
                    a = min(con, x[1])
                    hd.insert(0, [x[0], a, x[2], x[3], x[4]])
                    con -= a
                if con > 0.5:
                    hd.insert(0, [None, con, "Dư đầu năm", "chưa rõ tuổi (sổ năm trước không đủ)", None])
            else:
                hd.append([None, d0, "Dư đầu năm", "chưa rõ tuổi", None])
        elif d0 < -0.5:
            thua = -d0
        for ng, loai, p, sh, dg, han in sorted(ps.get(kh, []), key=lambda v: (v[0], v[1])):
            if loai == 0:
                if thua > 0:
                    x = min(thua, p)
                    thua -= x
                    p -= x
                if p > 0.5:
                    hd.append([ng, p, sh, dg, han])
            else:
                for h in hd:
                    if p <= 0:
                        break
                    x = min(h[1], p)
                    h[1] -= x
                    p -= x
                if p > 0.5:
                    thua += p
        hd = [h for h in hd if h[1] > 0.5]
        ra[kh] = {"hd": hd, "thua": thua, "dau": d0}
    return ra


# ------------------------------------------------------------------ so nam truoc
def tim_so_nam_truoc(d, thu_muc_them=()):
    """so cung MST, nam TC = nam - 1, trong thu muc cua so, DATA, thu muc them. -> duong | None"""
    if not d.get("mst"):
        return None
    tm = [os.path.dirname(os.path.abspath(d["duong"])), os.path.join(os.path.dirname(HERE), "DATA")] + list(thu_muc_them)
    ung = []
    da = set()
    for t in tm:
        for p in glob.glob(os.path.join(t, "*.MDB")) + glob.glob(os.path.join(t, "*.mdb")):
            k = os.path.abspath(p).lower()
            if k in da or k == os.path.abspath(d["duong"]).lower() or len(da) > 80:
                continue
            da.add(k)
            try:
                x = doc(p, chi_license=True)
            except Exception:
                continue
            if x["mst"] == d["mst"] and x["nam"] == d["nam"] - 1:
                ung.append((os.path.getmtime(p), p))
    return max(ung)[1] if ung else None


def truy_dau_nam(d, sau=SO_NAM_TRUY, nhat_ky=None):
    """-> {MaKH hien tai: [[ngay, con, sh, dg, han]]} khoan con mo cuoi nam truoc (truy tiep sau nam)."""
    if sau <= 0:
        return {}
    p = tim_so_nam_truoc(d)
    if not p:
        return {}
    try:
        t = doc(p)
    except Exception:
        return {}
    if nhat_ky is not None:
        nhat_ky.append((t["nam"], p))
    dau_t = truy_dau_nam(t, sau - 1, nhat_ky)
    mo = khoan_mo(t, ngay_cuoi_nam(t), "131", dau_t)
    theo_sh, theo_mst = {}, {}
    for ma in d["kh"]:
        sh, mst = _kh_khoa(d, ma)
        if sh:
            theo_sh[sh] = ma
        if mst:
            theo_mst.setdefault(mst, ma)
    ra = {}
    for ma_t, v in mo.items():
        sh, mst = _kh_khoa(t, ma_t)
        ma = theo_sh.get(sh) if sh else None
        if ma is None and mst:
            ma = theo_mst.get(mst)
        if ma is None:
            continue
        ra.setdefault(ma, []).extend([list(h) for h in v["hd"] if h[0] is not None])
    return ra


# ------------------------------------------------------------------ tep ho so (nguoi dung dien)
def tep_ho_so(duong):
    try:
        import chinh_sach_so
        tm = chinh_sach_so._thu_muc_ra(duong)[0]
    except Exception:
        tm = os.path.join(HERE, "ket-qua")
    return os.path.join(tm, TEP_HS)


def doc_ho_so(p):
    ra = {}
    if not p or not os.path.isfile(p):
        return ra
    with io.open(p, "r", encoding="utf-8-sig", errors="replace") as f:
        for dong in f:
            dong = dong.rstrip("\r\n")
            if not dong.strip() or dong.lstrip().startswith("#"):
                continue
            c = [x.strip() for x in dong.split(";")] + [""] * len(COT_HS)
            if not c[0] or c[0].upper() == "MA_KH":
                continue
            ra[c[0].upper()] = dict(zip(COT_HS, c[:len(COT_HS)]))
    return ra


def ghi_mau_ho_so(p, d, kq, cu):
    """them dong mau cho doi tuong can ho so ma chua co trong tep (giu nguyen dong nguoi dung da dien)."""
    moi = [x for x in kq["kh"] if x["can_ho_so"] and x["sh"].upper() not in cu]
    if not moi and os.path.isfile(p):
        return 0
    os.makedirs(os.path.dirname(p), exist_ok=True)
    co = os.path.isfile(p)
    with io.open(p, "a" if co else "w", encoding="utf-8") as f:
        if not co:
            f.write("# GĐ353 - Hồ sơ nợ khó đòi của sổ %s. Máy chỉ đọc tệp này; kế toán điền rồi chạy lại Kiểm tra trước khoá sổ.\n" % os.path.basename(d["duong"]))
            f.write("# Ngày ghi dd/mm/yyyy. HAN_NGAY = số ngày được nợ theo hợp đồng. HOP_DONG = số/ngày hợp đồng hoặc cam kết nợ.\n")
            f.write("# DOI_CHIEU = ngày biên bản đối chiếu có xác nhận của khách; DOI_NO = ngày gửi văn bản đòi nợ (có dấu bưu điện / email).\n")
            f.write("# TINH_TRANG: %s.\n" % ", ".join(TINH_TRANG))
            f.write("# VAN_BAN = số/ngày quyết định phá sản, giải thể, xác nhận của cơ quan có thẩm quyền... TON_THAT_PCT = %% tổn thất dự kiến khi nợ chưa đến hạn.\n")
            f.write("# NGAY_NO_CU = ngày phát sinh của số dư đầu năm khi không có sổ năm trước.\n")
            f.write(";".join(COT_HS) + "\n")
        for x in moi:
            f.write("%s;%s;;;;;;;;;\n" % (_s(x["sh"]), _s(x["ten"])[:60]))
    return len(moi)


# ------------------------------------------------------------------ phan tich
def _du_2293(d, den):
    la = _la(d, "2293")
    tong = sum(d["tk_dau"].get(m, (0, 0))[1] - d["tk_dau"].get(m, (0, 0))[0] for m in la)
    theo = defaultdict(float)
    for r in d["cn_dau"]:
        if r.get("MaTaiKhoan") in la:
            theo[_i(r.get("MaKhachHang"))] += _f(r.get("DuCo_0")) - _f(r.get("DuNo_0"))
    xoa = []
    for r in d["ct"]:
        ng = _ngay(r.get("NgayCT"))
        if not ng or ng > den:
            continue
        p = _f(r.get("SoPS"))
        if r.get("MaTKCo") in la:
            tong += p
            theo[_i(r.get("MaKHC"))] += p
        if r.get("MaTKNo") in la:
            tong -= p
            theo[_i(r.get("MaKH"))] -= p
    co_ct = sum(abs(v) for k, v in theo.items() if k) > 0.5
    return tong, (dict(theo) if co_ct else {}), xoa


def da_xu_ly(d):
    """but toan xoa no trong so: Nợ 2293 / Có 131 (hoac Nợ 642x / Có 131 dien giai xoa no) -> [(ngay, MaKH, tien, sh, dg)]; thu hoi Có 711."""
    la131, la2293 = _la(d, "131") | _la(d, "1388"), _la(d, "2293")
    la642 = _la(d, "642")
    xoa, thu = [], []
    for r in d["ct"]:
        ng = _ngay(r.get("NgayCT"))
        dg = _u(d, r.get("DienGiai"))
        if r.get("MaTKCo") in la131 and (r.get("MaTKNo") in la2293 or (r.get("MaTKNo") in la642 and re.search(r"x[oó]a\s*n[oợ]|xoa so|xóa sổ", dg, re.I))):
            xoa.append((ng, _i(r.get("MaKHC")), _f(r.get("SoPS")), _u(d, r.get("SoHieu")), dg))
        if d["tk"].get(r.get("MaTKCo"), "").startswith("711") and re.search(r"n[oợ]\s*(kh[oó]\s*đ[oò]i|kho doi|đã xoá|da xoa|đã xóa)", dg, re.I):
            thu.append((ng, _i(r.get("MaKHC")), _f(r.get("SoPS")), _u(d, r.get("SoHieu")), dg))
    return xoa, thu


def moc_mac_dinh(d):
    """cuoi thang co chung tu cong no gan nhat (khong qua cuoi nam TC): so giua nam khong bi tinh 'qua han' cho cac thang chua nhap."""
    ng = [_ngay(r.get("NgayCT")) for r in d["ct"]]
    ng = [x for x in ng if x]
    cn = ngay_cuoi_nam(d)
    if not ng:
        return cn
    m = max(ng)
    return min(cong_thang(_dt.date(m.year, m.month, 1), 1) - _dt.timedelta(days=1), cn)


def phan_tich(d, moc=None, ho_so=None, dau_kh=None, so_truoc=None):
    moc = moc or moc_mac_dinh(d)
    cuoi_nam = ngay_cuoi_nam(d)
    ho_so = ho_so or {}
    mo = khoan_mo(d, moc, "131", dau_kh)
    du_tong, du_kh, _ = _du_2293(d, moc)
    tk_cp = tk_chi_phi(d)
    hd_kh = defaultdict(list)
    for r in d["hd"]:
        hd_kh[_i(r.get("MaKhachHang"))].append("%s %s" % (_u(d, r.get("DienGiai")), _nd(_ngay(r.get("NgayKy")))))
    khs = []
    tong = defaultdict(float)
    n_khong_ro, n_han_md = 0, 0
    for ma, v in mo.items():
        k = d["kh"].get(ma) or {}
        sh = str(k.get("SoHieu") or ma).strip()
        hs = ho_so.get(sh.upper(), {})
        tt = hs.get("TINH_TRANG", "").upper().replace(" ", "_")
        tt = tt if tt in TINH_TRANG else ""
        han_ngay = _i(hs.get("HAN_NGAY")) if str(hs.get("HAN_NGAY") or "").strip() else None
        ngay_cu = _ngay(hs.get("NGAY_NO_CU"))
        dc, dn = _ngay(hs.get("DOI_CHIEU")), _ngay(hs.get("DOI_NO"))
        co_doi = bool((dc and dc <= moc) or (dn and dn <= moc))
        co_hd = bool(hs.get("HOP_DONG") or hd_kh.get(ma))
        vb = hs.get("VAN_BAN", "")
        try:
            tt_pct = min(max(float(str(hs.get("TON_THAT_PCT") or "").replace(",", ".") or "nan"), 0.0), 100.0) / 100.0
        except ValueError:
            tt_pct = None
        if tt_pct != tt_pct:
            tt_pct = None
        dong = []
        for ng, con, shc, dg, han in v["hd"]:
            ro = ng is not None
            if not ro and ngay_cu:
                ng, ro = ngay_cu, True
            if not ro:
                n_khong_ro += 1
                ng_tinh = ngay_dau_nam(d) - _dt.timedelta(days=1)      # it nhat da phat sinh truoc dau nam
            else:
                ng_tinh = ng
            if han:
                hn, nguon = han, "HanTT"
            elif han_ngay is not None:
                hn, nguon = ng_tinh + _dt.timedelta(days=han_ngay), "hợp đồng %d ngày" % han_ngay
            else:
                hn, nguon = ng_tinh + _dt.timedelta(days=HAN_MAC_DINH), "giả định %d ngày" % HAN_MAC_DINH
                n_han_md += 1
            qh = so_thang(hn, moc)
            tl = ty_le_tuoi(qh) if ro else 0.0          # chua ro ngay phat sinh -> khong tu trich theo tuoi (thieu chung cu), bao viec NKD_TUOI
            ly_do = ("quá hạn %d tháng" % qh) if tl else ("chưa rõ ngày phát sinh - chưa tính dự phòng" if not ro else "")
            if tt and tt != "XOA_NO_QD":
                tl2 = tt_pct if tt_pct is not None else 1.0
                if tl2 > tl:
                    tl, ly_do = tl2, "%s (%s)" % (TINH_TRANG[tt], "tự ước tính %.0f%%" % (100 * tl2) if tt_pct is not None else "chưa ghi TON_THAT_PCT - tạm 100%")
            # ngay trich du 100 % (BCTC nam dau tien sau khi qua han 36 thang) -> du dieu kien xoa sau 3 nam
            mo100 = cong_thang(hn, 36)
            bctc100 = _dt.date(mo100.year if (mo100.month, mo100.day) <= (cuoi_nam.month, cuoi_nam.day) else mo100.year + 1, cuoi_nam.month, cuoi_nam.day)
            xoa_100 = moc >= cong_thang(bctc100, 12 * NAM_SAU_100)
            dong.append({"ngay": ng, "ro": ro, "con": con, "sh": shc, "dg": dg, "han": hn, "nguon_han": nguon, "qh": qh, "tl": tl,
                         "dp": round(con * tl), "ly_do": ly_do, "bctc100": bctc100, "xoa_100": xoa_100})
        no = sum(x["con"] for x in dong)
        dp_tuoi = sum(x["dp"] for x in dong)
        qh6 = sum(x["con"] for x in dong if x["qh"] >= 6 and x["ro"])
        khong_ro_tien = sum(x["con"] for x in dong if not x["ro"])
        # dieu kien ho so (TT48 Dieu 6 khoan 1)
        thieu = []
        if dp_tuoi > 0:
            if not co_hd and not dc:
                thieu.append("chứng từ gốc: hợp đồng / cam kết nợ / biên bản đối chiếu")
            if qh6 > 0 and not co_doi:
                thieu.append("biên bản đối chiếu hoặc văn bản đòi nợ")
            if tt and not vb:
                thieu.append("văn bản chứng minh tình trạng (%s)" % TINH_TRANG[tt])
            if any(not x["ro"] for x in dong if x["dp"]):
                thieu.append("chứng từ gốc của dư đầu năm (chưa rõ ngày phát sinh)")
        du_hs = dp_tuoi > 0 and not thieu
        # xoa no (khoan 4)
        xoa_ly_do = ""
        if no > 0.5:
            if tt in ("PHA_SAN", "GIAI_THE", "NGUNG_HD", "MAT_TICH", "CHET", "TRUY_TO", "XOA_NO_QD") and vb:
                xoa_ly_do = TINH_TRANG[tt] + " - " + vb
            elif dong and all(x["xoa_100"] for x in dong):
                xoa_ly_do = "đã đủ 100%% dự phòng từ BCTC %d, sau %d năm chưa thu hồi được" % (min(x["bctc100"] for x in dong).year, NAM_SAU_100)
        x2293 = du_kh.get(ma, 0.0) if du_kh else None
        ten = _u(d, k.get("Ten"))
        rec = {"ma": ma, "sh": sh, "ten": ten, "mst": str(k.get("MST") or "").strip(), "dc": _u(d, k.get("DiaChi")), "dai_dien": _u(d, k.get("DaiDien")),
               "no": no, "thua": v["thua"], "dong": dong, "dp_tuoi": dp_tuoi, "dp_hs": dp_tuoi if du_hs else 0, "qh6": qh6, "thieu": thieu,
               "tt": tt, "vb": vb, "co_doi": co_doi, "dc_ngay": dc, "dn_ngay": dn, "hop_dong": hs.get("HOP_DONG") or "; ".join(hd_kh.get(ma, [])[:2]),
               "xoa": xoa_ly_do, "du2293": x2293, "can_ho_so": dp_tuoi > 0 or qh6 > 0 or any(not x["ro"] for x in dong),
               "khong_ro": khong_ro_tien > 0.5, "khong_ro_tien": khong_ro_tien, "han_md": any(x["nguon_han"].startswith("giả") for x in dong)}
        if no > 0.5:
            khs.append(rec)
            tong["no"] += no
            tong["dp_tuoi"] += dp_tuoi
            tong["dp_hs"] += rec["dp_hs"]
            tong["qh6"] += qh6
            tong["khong_ro_tien"] += khong_ro_tien
    khs.sort(key=lambda x: (-x["dp_tuoi"], -x["no"]))
    # but toan de xuat
    bt = []
    xoa = [x for x in khs if x["xoa"]]
    dung_2293 = 0.0
    for x in xoa:
        tu_dp = min(x["no"], max(x["du2293"], 0.0)) if x["du2293"] is not None else min(x["no"], x["dp_tuoi"])
        dung_2293 += tu_dp
        if tu_dp > 0.5:
            bt.append(("XOA", "2293", "131", round(tu_dp), "Xoá nợ %s - phần đã lập dự phòng" % x["ten"][:50], x["sh"]))
        if x["no"] - tu_dp > 0.5:
            bt.append(("XOA", tk_cp, "131", round(x["no"] - tu_dp), "Xoá nợ %s - phần chưa lập dự phòng tính vào chi phí" % x["ten"][:50], x["sh"]))
    dp_can = sum(x["dp_hs"] for x in khs if not x["xoa"])
    du_con = du_tong - dung_2293
    chenh = round(dp_can - du_con)
    if chenh > 0:
        bt.append(("TRICH", tk_cp, "2293", chenh, "Trích lập bổ sung dự phòng phải thu khó đòi tại %s" % _nd(moc), ""))
    elif chenh < 0:
        bt.append(("HOAN", "2293", tk_cp, -chenh, "Hoàn nhập dự phòng phải thu khó đòi tại %s" % _nd(moc), ""))
    xoa_so, thu_hoi = da_xu_ly(d)
    so_dk = []
    for ng, ma, tien, sh, dg in xoa_so:
        k = d["kh"].get(ma) or {}
        so_dk.append({"ngay": ng, "sh_kh": str(k.get("SoHieu") or ma), "ten": _u(d, k.get("Ten")), "tien": tien, "ct": sh, "dg": dg,
                      "den": cong_thang(ng, 12 * NAM_THEO_DOI) if ng else None})
    # viec can lam
    viec = []
    la_cuoi = moc >= cuoi_nam
    if chenh:
        viec.append(("VUA" if la_cuoi else "NHE", "NKD_TRICH" if chenh > 0 else "NKD_HOAN",
                     ("Trích bổ sung dự phòng %s đ (cần %s, đang có %s)" if chenh > 0 else "Hoàn nhập dự phòng %s đ (cần %s, đang có %s)") % (_dd(abs(chenh)), _dd(dp_can), _dd(du_con))
                     + ("" if la_cuoi else " - dự kiến tại BCTC năm %s" % _nd(cuoi_nam)),
                     "Giám đốc ký Quyết định trích lập (hồ sơ 03) rồi lập phiếu kế toán theo bút toán đề xuất", abs(chenh)))
    for x in khs:
        if x["thieu"] and x["dp_tuoi"]:
            viec.append(("VUA", "NKD_HS:%s" % x["sh"], "%s: nợ %s, dự phòng theo tuổi %s chưa đủ hồ sơ - thiếu %s" % (x["ten"][:50], _dd(x["no"]), _dd(x["dp_tuoi"]), ", ".join(x["thieu"])),
                         "Gửi thư đòi nợ / biên bản đối chiếu (đã lập sẵn trong hồ sơ 06, 07), rồi ghi ngày vào tệp hồ sơ", x["dp_tuoi"]))
    for x in xoa:
        viec.append(("VUA", "NKD_XOA:%s" % x["sh"], "%s: đủ điều kiện xử lý xoá nợ %s - %s" % (x["ten"][:50], _dd(x["no"]), x["xoa"]),
                     "Họp Hội đồng xử lý nợ (biên bản 02), Giám đốc ký Quyết định xoá nợ (04, 05), theo dõi 10 năm (08)", x["no"]))
    if n_khong_ro:
        nk = [x for x in khs if x["khong_ro"]]
        viec.append(("VUA" if la_cuoi else "NHE", "NKD_TUOI", "%d đối tượng có dư đầu năm chưa rõ ngày phát sinh (%s đ) - tuổi nợ có thể cao hơn số máy tính" % (len(nk), _dd(sum(sum(y["con"] for y in x["dong"] if not y["ro"]) for x in nk))),
                     "Đặt sổ năm trước cùng MST vào thư mục sổ / DATA, hoặc ghi NGAY_NO_CU trong tệp hồ sơ", 0))
    if n_han_md:
        nk = [x for x in khs if x["han_md"] and x["dp_tuoi"]]
        if nk:
            viec.append(("NHE", "NKD_HAN", "%d đối tượng đang có dự phòng nhưng hạn thanh toán là giả định %d ngày (chưa có hạn hợp đồng)" % (len(nk), HAN_MAC_DINH),
                         "Ghi HAN_NGAY theo hợp đồng trong tệp hồ sơ hoặc nhập Hạn thanh toán trên chứng từ", 0))
    for r in so_dk:
        if r["den"] and r["den"] > moc:
            pass
    muc = "CANH_BAO" if any(v[0] == "VUA" for v in viec) else ("THONG_TIN" if viec else "DAT")
    return {"moc": moc, "cuoi_nam": cuoi_nam, "la_cuoi": la_cuoi, "kh": khs, "bt": bt, "viec": viec, "so_dk": so_dk, "thu_hoi": thu_hoi,
            "tong": {"no": tong["no"], "dp_tuoi": tong["dp_tuoi"], "dp_hs": tong["dp_hs"], "qh6": tong["qh6"], "khong_ro_tien": tong["khong_ro_tien"], "du2293": du_tong, "dp_can": dp_can,
                     "chenh": chenh, "so_kh": len(khs), "so_kh_dp": sum(1 for x in khs if x["dp_tuoi"]), "so_xoa": len(xoa), "so_viec": len(viec), "muc": muc,
                     "tk_cp": tk_cp, "che_do": che_do(d), "khong_ro": n_khong_ro, "so_truoc": so_truoc or []}}


# ------------------------------------------------------------------ ghi
def _cty(d):
    l = d["lic"]
    return {"ten": _u(d, l.get("TenCty")), "dc": _u(d, l.get("DiaChi")), "mst": str(l.get("MaSoThue") or "").strip(), "gd": _u(d, l.get("NguoiKy")) or "",
            "tinh": _u(d, l.get("ThanhPho")) or ""}


def ghi(d, kq, thu_muc, p_hs=""):
    os.makedirs(thu_muc, exist_ok=True)
    t = kq["tong"]
    dong = ["TONG;%s;%s;%s;%s;%s;%s;%s;%s;%d;%d;%d;%d;%s" % (_nd(kq["moc"]), t["muc"], _dd(t["no"]), _dd(t["qh6"]), _dd(t["dp_tuoi"]), _dd(t["dp_hs"]),
                                                       _dd(t["du2293"]), _dd(t["chenh"]), t["so_kh"], t["so_kh_dp"], t["so_xoa"], t["so_viec"], _s(p_hs))]
    for v in kq["viec"]:
        dong.append("V;%s;%s;%s;%s;%s" % (v[0], v[1], _s(v[2])[:300], _s(v[3])[:200], _dd(v[4]) if v[4] else ""))
    for x in kq["kh"]:
        dong.append("KH;%s;%s;%s;%s;%s;%s;%s;%s" % (_s(x["sh"]), _s(x["ten"])[:60], _dd(x["no"]), _dd(x["qh6"]), _dd(x["dp_tuoi"]), _dd(x["dp_hs"]),
                                                    _s(", ".join(x["thieu"]))[:200], _s(x["xoa"])[:150]))
    for b in kq["bt"]:
        dong.append("BT;%s;%s;%s;%s;%s;%s" % (b[0], b[1], b[2], _dd(b[3]), _s(b[4]), _s(b[5])))
    p_txt = os.path.join(thu_muc, TEP + ".txt")
    with io.open(p_txt, "w", encoding="utf-8") as f:
        f.write("\n".join(dong) + "\n")
    tm_hs = os.path.join(thu_muc, "no_kho_doi_ho_so")
    ds_hs = ghi_ho_so(d, kq, tm_hs)
    p_html = os.path.join(thu_muc, TEP + ".html")
    with io.open(p_html, "w", encoding="utf-8") as f:
        f.write(_html(d, kq, p_hs, ds_hs))
    return p_txt, p_html


CSS_A4 = ("<style>body{font-family:'Times New Roman',serif;font-size:13pt;line-height:1.45;color:#000;background:#fff;max-width:19cm;margin:1.2cm auto;padding:0 .6cm}"
          "h1{font-size:15pt;text-align:center;margin:.6em 0 .2em}h2{font-size:13pt;margin:1em 0 .3em}.c{text-align:center}.r{text-align:right}"
          "table{border-collapse:collapse;width:100%;font-size:11.5pt}th,td{border:1px solid #000;padding:3px 5px;vertical-align:top}th{background:#eee}"
          ".n{text-align:right;white-space:nowrap}.hd{display:flex;justify-content:space-between;gap:1em}.hd div{text-align:center;width:48%}"
          ".ky{display:flex;justify-content:space-around;margin-top:1.2em;text-align:center}.ky div{width:30%}.ky i{display:block;height:4.5em}"
          ".g{color:#555;font-size:10.5pt}@media print{.g{display:none}}</style>")


def _dau_vb(cty, so_vb=""):
    e = html.escape
    return ("<div class='hd'><div><b>%s</b><br>MST: %s<br>Số: %s</div><div><b>CỘNG HOÀ XÃ HỘI CHỦ NGHĨA VIỆT NAM</b><br><b>Độc lập - Tự do - Hạnh phúc</b><br>"
            "<i>%s, ngày ..... tháng ..... năm .......</i></div></div>" % (e(cty["ten"].upper()), e(cty["mst"]), e(so_vb or "......../......."), e(cty["tinh"] or "..............")))


def _trang(ten, than):
    return "<!doctype html><html lang='vi'><head><meta charset='utf-8'><title>%s</title>%s</head><body>%s</body></html>" % (html.escape(ten), CSS_A4, than)


def ghi_ho_so(d, kq, tm):
    """bo ho so HTML A4 -> [(ten hien, duong tuong doi)]"""
    e = html.escape
    os.makedirs(tm, exist_ok=True)
    cty = _cty(d)
    moc = kq["moc"]
    t = kq["tong"]
    ds = []

    def viet(ten_tep, tieu, than):
        p = os.path.join(tm, ten_tep)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with io.open(p, "w", encoding="utf-8") as f:
            f.write(_trang(tieu, than))
        ds.append((tieu, os.path.relpath(p, os.path.dirname(tm)).replace(os.sep, "/")))
    kh_dp = [x for x in kq["kh"] if x["dp_tuoi"] > 0 and not x["xoa"]]
    kh_xoa = [x for x in kq["kh"] if x["xoa"]]
    # 00 danh muc kiem tra ho so
    r = []
    for x in [y for y in kq["kh"] if y["can_ho_so"] or y["xoa"]]:
        ok = lambda b: "✔" if b else "✘"
        r.append("<tr><td>%s</td><td>%s</td><td class='n'>%s</td><td class='n'>%s</td><td class='c'>%s</td><td class='c'>%s</td><td class='c'>%s</td><td class='c'>%s</td><td>%s</td></tr>" % (
            e(x["sh"]), e(x["ten"]), _dd(x["no"]), _dd(x["dp_tuoi"]), ok(bool(x["hop_dong"] or x["dc_ngay"])), ok(not x["khong_ro"]), ok(x["co_doi"] or x["qh6"] <= 0),
            ok(bool(x["vb"])) if x["tt"] else "–", e("; ".join(x["thieu"]) or ("Xoá nợ: " + x["xoa"] if x["xoa"] else "Đủ"))))
    viet("00_Danh_muc_kiem_tra_ho_so.html", "Danh mục kiểm tra hồ sơ nợ khó đòi",
         "<h1>DANH MỤC KIỂM TRA HỒ SƠ NỢ PHẢI THU KHÓ ĐÒI</h1><p class='c'>Tại ngày %s – %s</p>"
         "<p>Theo Thông tư 48/2019/TT-BTC Điều 6 (sửa đổi bởi Thông tư 24/2022/TT-BTC). Mỗi khoản phải có: chứng từ gốc (hợp đồng, khế ước, cam kết nợ, hoá đơn); "
         "với nợ quá hạn từ 6 tháng: biên bản đối chiếu hoặc văn bản đòi nợ đã gửi; với nợ có tình trạng đặc biệt: văn bản của cơ quan có thẩm quyền.</p>"
         "<table><tr><th>Mã</th><th>Khách nợ</th><th>Nợ còn</th><th>Dự phòng theo tuổi</th><th>HĐ / cam kết / đối chiếu</th><th>Rõ ngày PS</th><th>Đối chiếu / đòi nợ</th><th>Văn bản tình trạng</th><th>Còn thiếu</th></tr>%s</table>"
         "<p class='g'>✘ = chưa có trong tệp hồ sơ. Bổ sung xong, ghi ngày vào tệp hồ sơ rồi chạy lại để máy cập nhật.</p>" % (_nd(moc), e(cty["ten"]), "".join(r) or "<tr><td colspan=9>Không có khoản cần hồ sơ</td></tr>"))
    # 01 bang ke trich lap
    r, stt = [], 0
    for x in kh_dp:
        for y in x["dong"]:
            if not y["dp"]:
                continue
            stt += 1
            r.append("<tr><td class='c'>%d</td><td>%s<br><span class='g'>MST %s</span></td><td>%s %s</td><td class='n'>%s</td><td class='c'>%s</td><td class='c'>%s</td><td class='c'>%s</td><td class='c'>%.0f%%</td><td class='n'>%s</td><td>%s</td></tr>" % (
                stt, e(x["ten"]), e(x["mst"]), e(y["sh"]), _nd(y["ngay"]), _dd(y["con"]), _nd(y["han"]), e(y["nguon_han"]), y["qh"], 100 * y["tl"], _dd(y["dp"]),
                e(y["ly_do"] + ("" if not x["thieu"] else " – chưa đủ hồ sơ: " + ", ".join(x["thieu"])))))
    viet("01_Bang_ke_trich_lap_du_phong.html", "Bảng kê trích lập dự phòng nợ phải thu khó đòi",
         _dau_vb(cty) + "<h1>BẢNG KÊ CHI TIẾT CÁC KHOẢN NỢ PHẢI THU KHÓ ĐÒI VÀ MỨC TRÍCH LẬP DỰ PHÒNG</h1><p class='c'>Tại ngày %s</p>"
         "<table><tr><th>STT</th><th>Khách nợ</th><th>Chứng từ</th><th>Số tiền còn nợ</th><th>Hạn thanh toán</th><th>Căn cứ hạn</th><th>Quá hạn (tháng)</th><th>Mức trích</th><th>Số trích</th><th>Ghi chú</th></tr>%s"
         "<tr><th colspan=3>Cộng</th><th class='n'>%s</th><th colspan=4></th><th class='n'>%s</th><th></th></tr></table>"
         "<p>Trong đó đủ hồ sơ để trích (chi phí được trừ): <b>%s đ</b>. Phần chưa đủ hồ sơ: %s đ – chỉ trích khi đã bổ sung.</p>"
         "<div class='ky'><div><b>Người lập</b><i></i></div><div><b>Kế toán trưởng</b><i></i></div><div><b>Giám đốc</b><i></i>%s</div></div>" % (
             _nd(moc), "".join(r) or "<tr><td colspan=10>Không có khoản phải trích</td></tr>", _dd(sum(x["no"] for x in kh_dp)), _dd(sum(x["dp_tuoi"] for x in kh_dp)),
             _dd(sum(x["dp_hs"] for x in kh_dp)), _dd(sum(x["dp_tuoi"] - x["dp_hs"] for x in kh_dp)), e(cty["gd"])))
    # 02 bien ban hoi dong
    bt = "".join("<tr><td>%s</td><td class='c'>%s</td><td class='c'>%s</td><td class='n'>%s</td><td>%s</td></tr>" % (
        {"TRICH": "Trích lập", "HOAN": "Hoàn nhập", "XOA": "Xoá nợ"}[b[0]], b[1], b[2], _dd(b[3]), e(b[4])) for b in kq["bt"])
    xoa_t = "".join("<tr><td>%s</td><td>%s</td><td class='n'>%s</td><td class='n'>0</td><td class='n'>%s</td><td>%s</td></tr>" % (
        e(x["sh"]), e(x["ten"]), _dd(x["no"]), _dd(x["no"]), e(x["xoa"])) for x in kh_xoa)
    viet("02_Bien_ban_Hoi_dong_xu_ly_no.html", "Biên bản họp Hội đồng xử lý nợ",
         _dau_vb(cty) + "<h1>BIÊN BẢN HỌP HỘI ĐỒNG XỬ LÝ NỢ</h1><p class='c'>V/v trích lập dự phòng và xử lý nợ phải thu khó đòi năm %d</p>"
         "<p>Hôm nay, ngày ..... / ..... / ......., tại %s, Hội đồng xử lý nợ gồm:</p>"
         "<p>1. Ông/Bà %s – Giám đốc – Chủ tịch Hội đồng<br>2. Ông/Bà .............................. – Kế toán trưởng – Thành viên<br>"
         "3. Ông/Bà .............................. – Phụ trách kinh doanh / bán hàng – Thành viên<br>4. Ông/Bà .............................. – Thư ký</p>"
         "<h2>I. Tình hình nợ phải thu tại ngày %s</h2><p>Tổng nợ phải thu khách hàng: %s đ; quá hạn từ 6 tháng: %s đ; dự phòng theo tuổi nợ: %s đ; "
         "đủ hồ sơ: %s đ; số dư dự phòng đang có (TK 2293): %s đ. Chi tiết theo Bảng kê (hồ sơ 01).</p>"
         "<h2>II. Các khoản đề nghị xoá nợ</h2><table><tr><th>Mã</th><th>Khách nợ</th><th>Giá trị khoản nợ</th><th>Đã thu hồi được</th><th>Thiệt hại thực tế</th><th>Căn cứ</th></tr>%s</table>"
         "<h2>III. Kết luận của Hội đồng</h2><p>Hội đồng thống nhất đề nghị Giám đốc phê duyệt các bút toán sau (theo Thông tư 48/2019/TT-BTC Điều 6, chế độ kế toán %s):</p>"
         "<table><tr><th>Nội dung</th><th>Nợ TK</th><th>Có TK</th><th>Số tiền</th><th>Diễn giải</th></tr>%s</table>"
         "<p>Các khoản nợ sau khi xoá được theo dõi riêng trong thời hạn tối thiểu 10 năm kể từ ngày xử lý và tiếp tục áp dụng biện pháp thu hồi; số thu hồi được hạch toán vào thu nhập khác (TK 711).</p>"
         "<p>Biên bản lập xong lúc ..... giờ cùng ngày, đã đọc lại cho các thành viên cùng nghe và nhất trí ký tên.</p>"
         "<div class='ky'><div><b>Thư ký</b><i></i></div><div><b>Kế toán trưởng</b><i></i></div><div><b>Chủ tịch Hội đồng</b><i></i>%s</div></div>" % (
             moc.year, e(cty["dc"] or "trụ sở công ty"), e(cty["gd"] or ".............................."), _nd(moc), _dd(t["no"]), _dd(t["qh6"]), _dd(t["dp_tuoi"]),
             _dd(t["dp_hs"]), _dd(t["du2293"]), xoa_t or "<tr><td colspan=6>Không có</td></tr>", t["che_do"], bt or "<tr><td colspan=5>Không phát sinh bút toán</td></tr>", e(cty["gd"])))
    # 03 quyet dinh trich lap
    trich = [b for b in kq["bt"] if b[0] in ("TRICH", "HOAN")]
    viet("03_Quyet_dinh_trich_lap_du_phong.html", "Quyết định trích lập dự phòng nợ phải thu khó đòi",
         _dau_vb(cty, "......./QĐ-GĐ") + "<h1>QUYẾT ĐỊNH</h1><p class='c'><b>V/v trích lập dự phòng nợ phải thu khó đòi năm %d</b></p><p class='c'><b>GIÁM ĐỐC %s</b></p>"
         "<p><i>Căn cứ Thông tư số 48/2019/TT-BTC ngày 08/8/2019 của Bộ Tài chính, đã được sửa đổi, bổ sung bởi Thông tư số 24/2022/TT-BTC ngày 07/4/2022;<br>"
         "Căn cứ Điều lệ công ty và Quy chế tài chính;<br>Căn cứ Biên bản họp Hội đồng xử lý nợ ngày ..... / ..... / .......;<br>Xét đề nghị của Kế toán trưởng,</i></p>"
         "<p class='c'><b>QUYẾT ĐỊNH:</b></p><p><b>Điều 1.</b> %s dự phòng nợ phải thu khó đòi tại ngày %s với số tiền <b>%s đồng</b>, chi tiết theo Bảng kê đính kèm. "
         "Tổng số dư dự phòng sau điều chỉnh: %s đồng.</p><p><b>Điều 2.</b> Khoản trích lập được hạch toán vào chi phí quản lý doanh nghiệp (TK %s) năm %d.</p>"
         "<p><b>Điều 3.</b> Phòng Kế toán, bộ phận kinh doanh tiếp tục đối chiếu, đòi nợ đối với các khoản đã trích lập. Quyết định có hiệu lực kể từ ngày ký.</p>"
         "<div class='ky'><div></div><div></div><div><b>GIÁM ĐỐC</b><i></i>%s</div></div>" % (
             moc.year, e(cty["ten"].upper()), "Trích lập bổ sung" if t["chenh"] >= 0 else "Hoàn nhập", _nd(moc), _dd(abs(t["chenh"])), _dd(t["dp_can"]), t["tk_cp"], moc.year, e(cty["gd"])))
    if kh_xoa:
        rr = "".join("<tr><td class='c'>%d</td><td>%s<br><span class='g'>MST %s – %s</span></td><td class='n'>%s</td><td class='n'>%s</td><td class='n'>%s</td><td>%s</td></tr>" % (
            i + 1, e(x["ten"]), e(x["mst"]), e(x["dc"]), _dd(x["no"]), _dd(min(x["no"], max(x["du2293"] or 0, 0)) if x["du2293"] is not None else x["dp_tuoi"]),
            _dd(x["no"] - (min(x["no"], max(x["du2293"] or 0, 0)) if x["du2293"] is not None else x["dp_tuoi"])), e(x["xoa"])) for i, x in enumerate(kh_xoa))
        viet("04_Quyet_dinh_xoa_no.html", "Quyết định xử lý xoá nợ phải thu không có khả năng thu hồi",
             _dau_vb(cty, "......./QĐ-GĐ") + "<h1>QUYẾT ĐỊNH</h1><p class='c'><b>V/v xử lý các khoản nợ phải thu không có khả năng thu hồi</b></p>"
             "<p><i>Căn cứ Thông tư số 48/2019/TT-BTC (sửa đổi bởi Thông tư số 24/2022/TT-BTC) Điều 6 khoản 4;<br>Căn cứ Biên bản họp Hội đồng xử lý nợ ngày ..... / ..... / .......; "
             "hồ sơ chứng minh của từng khoản nợ,</i></p><p class='c'><b>QUYẾT ĐỊNH:</b></p><p><b>Điều 1.</b> Xử lý xoá sổ %d khoản nợ phải thu không có khả năng thu hồi, tổng giá trị "
             "<b>%s đồng</b>, chi tiết theo Bảng kê (hồ sơ 05).</p><p><b>Điều 2.</b> Nguồn bù đắp: dự phòng đã trích lập (TK 2293); phần còn thiếu hạch toán vào chi phí quản lý doanh nghiệp (TK %s).</p>"
             "<p><b>Điều 3.</b> Phòng Kế toán mở sổ theo dõi riêng các khoản nợ đã xử lý trong thời hạn tối thiểu 10 năm, tiếp tục các biện pháp thu hồi; số thu hồi được ghi thu nhập khác.</p>"
             "<div class='ky'><div></div><div></div><div><b>GIÁM ĐỐC</b><i></i>%s</div></div>" % (len(kh_xoa), _dd(sum(x["no"] for x in kh_xoa)), t["tk_cp"], e(cty["gd"])))
        viet("05_Bang_ke_no_xoa_so.html", "Bảng kê chi tiết các khoản nợ phải thu đã xoá sổ",
             _dau_vb(cty) + "<h1>BẢNG KÊ CHI TIẾT CÁC KHOẢN NỢ PHẢI THU XOÁ SỔ</h1><p class='c'>Kèm theo Quyết định số ......./QĐ-GĐ ngày ..... / ..... / .......</p>"
             "<table><tr><th>STT</th><th>Khách nợ</th><th>Giá trị khoản nợ</th><th>Bù đắp từ dự phòng</th><th>Tính vào chi phí</th><th>Căn cứ xử lý</th></tr>%s</table>"
             "<p>Hồ sơ kèm: sổ kế toán chi tiết TK 131, chứng từ gốc, biên bản đối chiếu / văn bản đòi nợ, giấy tờ pháp lý của từng khách nợ.</p>"
             "<div class='ky'><div><b>Người lập</b><i></i></div><div><b>Kế toán trưởng</b><i></i></div><div><b>Giám đốc</b><i></i>%s</div></div>" % (rr, e(cty["gd"])))
    # 06 thu doi no, 07 bien ban doi chieu - doi tuong qua han 6 thang hoac thieu doi chieu
    for x in [y for y in kq["kh"] if y["qh6"] > 0 or (y["dp_tuoi"] and not y["co_doi"])][:200]:
        ten_t = re.sub(r"[^A-Za-z0-9_-]+", "_", x["sh"])[:30] or str(x["ma"])
        ds_hd = "".join("<tr><td>%s</td><td class='c'>%s</td><td class='n'>%s</td><td class='c'>%s</td><td class='c'>%d</td></tr>" % (
            e(y["sh"]), _nd(y["ngay"]) or "trước " + _nd(ngay_dau_nam(d)), _dd(y["con"]), _nd(y["han"]), y["qh"]) for y in x["dong"])
        viet("06_Thu_doi_no/%s.html" % ten_t, "Thư đòi nợ - %s" % x["ten"],
             _dau_vb(cty, "......./CV") + "<h1>THƯ ĐỀ NGHỊ THANH TOÁN CÔNG NỢ QUÁ HẠN</h1><p>Kính gửi: <b>%s</b><br>Địa chỉ: %s<br>Mã số thuế: %s</p>"
             "<p>%s trân trọng thông báo: đến ngày %s, Quý công ty còn nợ chúng tôi số tiền <b>%s đồng</b> (%s), trong đó quá hạn thanh toán từ 6 tháng trở lên: %s đồng. Chi tiết:</p>"
             "<table><tr><th>Chứng từ</th><th>Ngày</th><th>Số tiền còn nợ</th><th>Hạn thanh toán</th><th>Quá hạn (tháng)</th></tr>%s</table>"
             "<p>Đề nghị Quý công ty thanh toán hoặc phản hồi xác nhận số nợ trong vòng 15 ngày kể từ ngày nhận thư. Quá thời hạn trên, chúng tôi sẽ áp dụng các biện pháp thu hồi theo hợp đồng và quy định của pháp luật.</p>"
             "<div class='ky'><div></div><div></div><div><b>GIÁM ĐỐC</b><i></i>%s</div></div><p class='g'>Gửi bằng thư bảo đảm / email có xác nhận; lưu bản chụp phiếu gửi, rồi ghi ngày gửi vào cột DOI_NO của tệp hồ sơ.</p>" % (
                 e(x["ten"]), e(x["dc"]), e(x["mst"]), e(cty["ten"]), _nd(moc), _dd(x["no"]), _so_chu(x["no"]), _dd(x["qh6"]), ds_hd, e(cty["gd"])))
        viet("07_Bien_ban_doi_chieu/%s.html" % ten_t, "Biên bản đối chiếu công nợ - %s" % x["ten"],
             _dau_vb(cty) + "<h1>BIÊN BẢN ĐỐI CHIẾU VÀ XÁC NHẬN CÔNG NỢ</h1><p class='c'>Đến ngày %s</p>"
             "<p><b>Bên A (bên bán):</b> %s – MST %s – %s<br><b>Bên B (bên mua):</b> %s – MST %s – %s</p>"
             "<p>Hai bên cùng đối chiếu công nợ phát sinh theo hợp đồng / hoá đơn: %s. Số Bên B còn phải thanh toán cho Bên A đến ngày %s là <b>%s đồng</b> (%s). Chi tiết:</p>"
             "<table><tr><th>Chứng từ</th><th>Ngày</th><th>Số tiền còn nợ</th><th>Hạn thanh toán</th><th>Quá hạn (tháng)</th></tr>%s</table>"
             "<p>Bên B xác nhận số nợ trên là đúng / ghi rõ số chênh lệch: ................................................</p>"
             "<div class='ky'><div><b>ĐẠI DIỆN BÊN A</b><i></i>%s</div><div></div><div><b>ĐẠI DIỆN BÊN B</b><i></i>%s</div></div>" % (
                 _nd(moc), e(cty["ten"]), e(cty["mst"]), e(cty["dc"]), e(x["ten"]), e(x["mst"]), e(x["dc"]), e(x["hop_dong"] or "......................"), _nd(moc), _dd(x["no"]),
                 _so_chu(x["no"]), ds_hd, e(cty["gd"]), e(x["dai_dien"])))
    # thu / bien ban cua lan chay truoc ma nay khong con can -> xoa (thu muc ket qua cua may, khong phai tep nguoi dung)
    con = {p for _n, p in ds}
    for sub in ("06_Thu_doi_no", "07_Bien_ban_doi_chieu"):
        for p in glob.glob(os.path.join(tm, sub, "*.html")):
            if os.path.relpath(p, os.path.dirname(tm)).replace(os.sep, "/") not in con:
                try:
                    os.remove(p)
                except OSError:
                    pass
    for p in ("04_Quyet_dinh_xoa_no.html", "05_Bang_ke_no_xoa_so.html"):
        if not kh_xoa and os.path.isfile(os.path.join(tm, p)):
            try:
                os.remove(os.path.join(tm, p))
            except OSError:
                pass
    # 08 so theo doi no da xu ly
    r = "".join("<tr><td class='c'>%s</td><td>%s</td><td>%s</td><td class='n'>%s</td><td>%s %s</td><td class='c'>%s</td><td></td></tr>" % (
        _nd(x["ngay"]), e(x["sh_kh"]), e(x["ten"]), _dd(x["tien"]), e(x["ct"]), e(x["dg"]), _nd(x["den"])) for x in kq["so_dk"])
    r += "".join("<tr><td class='c'>(dự kiến)</td><td>%s</td><td>%s</td><td class='n'>%s</td><td>Theo Quyết định xoá nợ năm %d</td><td class='c'>%s</td><td></td></tr>" % (
        e(x["sh"]), e(x["ten"]), _dd(x["no"]), moc.year, _nd(cong_thang(moc, 12 * NAM_THEO_DOI))) for x in kh_xoa)
    viet("08_So_theo_doi_no_da_xu_ly.html", "Sổ theo dõi nợ phải thu khó đòi đã xử lý",
         _dau_vb(cty) + "<h1>SỔ THEO DÕI NỢ PHẢI THU KHÓ ĐÒI ĐÃ XỬ LÝ</h1><p class='c'>Theo dõi tối thiểu 10 năm kể từ ngày xử lý (TT48/2019 Điều 6 khoản 4)</p>"
         "<table><tr><th>Ngày xử lý</th><th>Mã</th><th>Khách nợ</th><th>Số đã xoá</th><th>Chứng từ / quyết định</th><th>Theo dõi đến</th><th>Đã thu hồi (TK 711)</th></tr>%s</table>"
         "<p class='g'>Đọc từ bút toán Nợ 2293 / Có 131 (hoặc Nợ 642 / Có 131 có chữ 'xoá nợ') trong sổ. TT133 không có tài khoản ngoài bảng – sổ này là sổ theo dõi riêng.</p>" % (
             r or "<tr><td colspan=7>Chưa có khoản nợ đã xử lý</td></tr>"))
    return ds


def _so_chu(v):
    try:
        from so_sach_mau import so_thanh_chu
        return "bằng chữ: " + so_thanh_chu(round(v))
    except Exception:
        return "bằng chữ: ......................................"


def _html(d, kq, p_hs, ds_hs):
    e = html.escape
    t = kq["tong"]
    cty = _cty(d)
    css = ("<style>:root{--bg:#f6f7f8;--fg:#17212b;--mu:#5a6672;--ln:#d6dce2;--ac:#0d5c8c;--w:#9a5b00;--b:#a3262a;--ok:#1d6b34}"
           "body{font-family:Segoe UI,Arial,sans-serif;background:var(--bg);color:var(--fg);margin:0;padding:16px;font-size:14px}"
           "h1{font-size:22px;margin:4px 0}h2{font-size:17px;margin:22px 0 8px}.mu{color:var(--mu)}.tiles{display:flex;flex-wrap:wrap;gap:10px;margin:12px 0}"
           ".t{background:#fff;border:1px solid var(--ln);border-radius:8px;padding:10px 14px;min-width:150px}.t b{display:block;font-size:19px}"
           "table{border-collapse:collapse;width:100%;background:#fff}th,td{border-bottom:1px solid var(--ln);padding:6px 8px;text-align:left;vertical-align:top}"
           "th{font-size:12px;color:var(--mu);text-transform:uppercase}.n{text-align:right;white-space:nowrap;font-variant-numeric:tabular-nums}"
           ".tag{border-radius:4px;padding:1px 7px;font-size:12px;font-weight:600}.VUA{background:#fbeed3;color:var(--w)}.NHE{background:#e3eef6;color:var(--ac)}"
           ".sc{overflow-x:auto}a{color:var(--ac)}</style>")
    v = "".join("<tr><td><span class='tag %s'>%s</span></td><td>%s</td><td>%s</td><td>%s</td><td class='n'>%s</td></tr>" % (
        x[0], x[0], e(x[1]), e(x[2]), e(x[3]), _dd(x[4]) if x[4] else "") for x in kq["viec"])
    b = "".join("<tr><td>%s</td><td>%s</td><td>%s</td><td class='n'>%s</td><td>%s</td></tr>" % (
        {"TRICH": "Trích lập", "HOAN": "Hoàn nhập", "XOA": "Xoá nợ"}[x[0]], x[1], x[2], _dd(x[3]), e(x[4])) for x in kq["bt"])
    ds_k = [x for x in kq["kh"] if x["qh6"] > 0 or x["dp_tuoi"] or x["xoa"]]
    ds_k += sorted([x for x in kq["kh"] if x["khong_ro"] and x not in ds_k], key=lambda x: -x["khong_ro_tien"])[:max(0, 60 - len(ds_k))]
    k = "".join("<tr><td>%s</td><td>%s</td><td class='n'>%s</td><td class='n'>%s</td><td class='n'>%s</td><td class='n'>%s</td><td class='n'>%s</td><td>%s</td></tr>" % (
        e(x["sh"]), e(x["ten"]), _dd(x["no"]), _dd(x["qh6"]), _dd(x["khong_ro_tien"]), _dd(x["dp_tuoi"]), _dd(x["dp_hs"]),
        e(("Xoá nợ: " + x["xoa"]) if x["xoa"] else ("Thiếu: " + ", ".join(x["thieu"]) if x["thieu"] else ""))) for x in ds_k)
    hs = "".join("<li><a href='%s'>%s</a></li>" % (e(p), e(n)) for n, p in ds_hs if "/0" not in p[-40:] or True)
    truoc = "; ".join("%d: %s" % (n, os.path.basename(p)) for n, p in t["so_truoc"]) or "không tìm thấy (dư đầu năm chưa rõ tuổi)"
    return ("<!doctype html><html lang='vi'><head><meta charset='utf-8'><title>Nợ khó đòi %s</title>%s</head><body>"
            "<h1>Nợ phải thu khó đòi – %s</h1><p class='mu'>Tính tại %s (%s) · chế độ %s · sổ năm trước: %s · máy chỉ đề xuất, không ghi sổ.</p>"
            "<div class='tiles'><div class='t'>Nợ phải thu<b>%s</b></div><div class='t'>Quá hạn từ 6 tháng<b>%s</b></div><div class='t'>Dư đầu năm chưa rõ tuổi<b>%s</b></div><div class='t'>Dự phòng theo tuổi<b>%s</b></div>"
            "<div class='t'>Đủ hồ sơ để trích<b>%s</b></div><div class='t'>Đang có (2293)<b>%s</b></div><div class='t'>Chênh lệch cần điều chỉnh<b>%s</b></div></div>"
            "<h2>Việc cần làm (%d)</h2><div class='sc'><table><tr><th>Mức</th><th>Mã</th><th>Nội dung</th><th>Làm ở đâu</th><th>Số tiền</th></tr>%s</table></div>"
            "<h2>Bút toán đề xuất (người lập phiếu sau khi Giám đốc ký)</h2><div class='sc'><table><tr><th>Loại</th><th>Nợ</th><th>Có</th><th>Số tiền</th><th>Diễn giải</th></tr>%s</table></div>"
            "<h2>Khách nợ cần xem (quá hạn, có dự phòng, rồi tối đa 60 khách có dư đầu năm chưa rõ tuổi lớn nhất)</h2><div class='sc'><table><tr><th>Mã</th><th>Khách</th><th>Nợ còn</th><th>Quá hạn ≥ 6 tháng</th><th>Chưa rõ tuổi</th><th>Dự phòng theo tuổi</th><th>Đủ hồ sơ</th><th>Ghi chú</th></tr>%s</table></div>"
            "<h2>Bộ hồ sơ đã lập sẵn</h2><ul>%s</ul><p class='mu'>Tệp hồ sơ kế toán điền (ngày đối chiếu, đòi nợ, tình trạng pháp lý): %s</p>"
            "<p class='mu'>Căn cứ: TT48/2019/TT-BTC Điều 6 (sửa đổi bởi TT24/2022/TT-BTC); mức trích 30%% / 50%% / 70%% / 100%% theo thời gian quá hạn 6 tháng / 1 / 2 / 3 năm; "
            "trích tại thời điểm lập BCTC năm; xoá nợ khi có căn cứ pháp lý hoặc đã trích 100%% sau 3 năm; nợ đã xoá theo dõi tối thiểu 10 năm. Đối chiếu văn bản gốc trước khi ký.</p>"
            "</body></html>" % (e(cty["ten"]), css, e(cty["ten"]), _nd(kq["moc"]), "ngày lập BCTC năm" if kq["la_cuoi"] else "giữa năm – dự kiến", t["che_do"], e(truoc),
                                _dd(t["no"]), _dd(t["qh6"]), _dd(t["khong_ro_tien"]), _dd(t["dp_tuoi"]), _dd(t["dp_hs"]), _dd(t["du2293"]), _dd(t["chenh"]), t["so_viec"],
                                v or "<tr><td colspan=5>Không có</td></tr>", b or "<tr><td colspan=5>Không cần điều chỉnh</td></tr>",
                                k or "<tr><td colspan=8>Không có khách nợ quá hạn</td></tr>", hs, e(p_hs)))


# ------------------------------------------------------------------ chay
def chay(duong, moc=None, thu_muc=None, truy=True):
    d = doc(duong)
    so_truoc = []
    dau_kh = truy_dau_nam(d, SO_NAM_TRUY, so_truoc) if truy else {}
    if moc and moc > moc_mac_dinh(d):
        moc = moc_mac_dinh(d)              # so moi nhap den thang nay: khong tinh 'qua han' cho cac thang chua co chung tu
    p_hs = tep_ho_so(duong)
    ho_so = doc_ho_so(p_hs)
    kq = phan_tich(d, moc, ho_so, dau_kh, so_truoc)
    try:
        ghi_mau_ho_so(p_hs, d, kq, ho_so)
    except Exception:
        pass
    tm = thu_muc or os.path.join(HERE, "ket-qua")
    p_txt, p_html = ghi(d, kq, tm, p_hs)
    return kq, p_txt, p_html, p_hs


def k_no_kho_doi(S, _kq, DAT, CANH_BAO, LOI, THONG_TIN):
    ten = "Nợ phải thu khó đòi: tuổi nợ, dự phòng, hồ sơ trích lập / xoá nợ (TT48/2019) - xem trước"
    duong = (S.dl or {}).get("duong_so") or ""
    if not duong or not os.path.isfile(duong):
        return None
    moc = None
    try:
        ky = (S.dl or {}).get("ky") or {}
        den = _ngay(ky.get("den"))
        t2 = int(getattr(S, "t2", 0) or 0)
        if den and t2 == 12:
            moc = den                       # ky kiem den thang cuoi nam TC -> tinh tai ngay lap BCTC
    except Exception:
        moc = None
    try:
        kq, _p1, p_html, _ph = chay(duong, moc, os.path.join(HERE, "ket-qua"))
    except Exception as ex:
        return [_kq("K61", ten, THONG_TIN, "Không lập được phân tích nợ khó đòi: %s" % type(ex).__name__)]
    t = kq["tong"]
    if not t["so_kh"]:
        return None
    dong = [[v[1], v[0], v[2], v[3], _dd(v[4]) if v[4] else ""] for v in kq["viec"][:60]]
    muc = {"CANH_BAO": CANH_BAO, "THONG_TIN": THONG_TIN}.get(t["muc"], DAT)
    kl = ("Tại %s: nợ phải thu %s, quá hạn ≥ 6 tháng %s; dự phòng theo tuổi %s (đủ hồ sơ %s), đang có 2293 %s, chênh %s; %d khách đủ điều kiện xoá nợ. "
          "%d việc - xem: %s" % (_nd(kq["moc"]), _dd(t["no"]), _dd(t["qh6"]), _dd(t["dp_tuoi"]), _dd(t["dp_hs"]), _dd(t["du2293"]), _dd(t["chenh"]), t["so_xoa"], t["so_viec"], p_html))
    return [_kq("K61", ten, muc, kl, ["Mã", "Mức", "Nội dung", "Làm ở đâu", "Số tiền"], dong)]


def main(argv):
    import sys
    t = {}
    for a in argv[1:]:
        if a.startswith("/") and ":" in a:
            k, v = a[1:].split(":", 1)
            t[k.lower()] = v.strip('"')
    so = t.get("so")
    if not so:
        print("python no_kho_doi.py /so:\"<so.MDB>\" [/ngay:dd/mm/yyyy] [/ra:<thu muc>] [/truy:0]")
        return 1
    kq, p1, p2, ph = chay(so, _ngay(t.get("ngay")), t.get("ra"), t.get("truy", "1") != "0")
    tg = kq["tong"]
    print("Tai %s: %d khach no, no %s, qua han>=6T %s, DP tuoi %s, du HS %s, 2293 %s, chenh %s, xoa %d, %d viec, muc %s -> %s" % (
        _nd(kq["moc"]), tg["so_kh"], _dd(tg["no"]), _dd(tg["qh6"]), _dd(tg["dp_tuoi"]), _dd(tg["dp_hs"]), _dd(tg["du2293"]), _dd(tg["chenh"]), tg["so_xoa"], tg["so_viec"], tg["muc"], p2))
    return 0


if __name__ == "__main__":
    import sys
    sys.exit(main(sys.argv))
