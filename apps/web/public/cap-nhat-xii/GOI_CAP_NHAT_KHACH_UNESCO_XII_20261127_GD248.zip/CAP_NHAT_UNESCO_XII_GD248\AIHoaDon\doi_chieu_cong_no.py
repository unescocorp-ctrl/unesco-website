# -*- coding: utf-8 -*-
"""GD236 - BIEN BAN DOI CHIEU CONG NO theo doi tac + TUOI NO + NHAC NO soan san (C1 / C2 lo trinh). Chi doc so.

Chay trong Kiem tra truoc khoa so (kiem_khoa_so -> k_lap_bien_ban, K43): so lieu lay tu cung JSON
  - so du / phat sinh 131, 331 theo doi tuong: kiem_khoa_so._cong_no(S) (cung cach tinh K08)
  - hoa don con no + tuoi no: doi_chieu_3c.phan_tich(dl) (GD235: hoa don - phieu thanh toan - so phu)
Ghi vao <thu muc khach>\\ket-qua\\doi-chieu-cong-no\\<yyyymmdd_hhmm>\\
  bien_ban.html   moi doi tac mot trang (In / Luu PDF), co cho ky hai ben
  nhac_no.txt     tin nhan nhac no cho khach co hoa don qua han (> HAN ngay) - phan mem KHONG tu gui
  tong_hop.csv    doi tac, TK, dau ky, phat sinh, cuoi ky, no qua han theo nhom tuoi
"""
import html
import io
import os
from datetime import datetime, date

HAN_TT = 30            # ngay - hoa don qua han khi tuoi no > HAN_TT
NHOM = ((0, 30, "0-30"), (31, 60, "31-60"), (61, 90, "61-90"), (91, 10 ** 6, ">90"))


def _iso(s):
    s = str(s or "").strip()
    try:
        if "/" in s:
            d, m, y = s[:10].split("/")
            return date(int(y), int(m), int(d))
        return date(int(s[:4]), int(s[5:7]), int(s[8:10]))
    except Exception:
        return None


def _tien(v):
    try:
        return "{:,.0f}".format(float(v)).replace(",", ".")
    except Exception:
        return str(v)


def _e(s):
    return html.escape(str(s or ""))


def nhom_tuoi(ngay_hd, ngay_moc):
    if not ngay_hd or not ngay_moc:
        return "?"
    n = (ngay_moc - ngay_hd).days
    for a, b, ten in NHOM:
        if a <= n <= b:
            return ten
    return "0-30"


def thu_thap(S, dt, cong_no, phan_tich_hd):
    """-> danh sach doi tac: {ma, ten, mst, tk, la_thu, dau, no, co, cuoi, hd:[{so, ngay, tong, con, tuoi, ngay_tuoi}]}"""
    la_cn, d = cong_no(S)
    den = _iso(((S.dl.get("ky") or {}).get("den")) or "") or date.today()
    hd, _, _ = phan_tich_hd(S.dl) if "hd3" in S.dl else ({}, [], [])
    theo_dt = {}
    for h in hd.values():
        con = h["tong"] - h["tt"] - h["sp"]
        if h["huy"] or con <= 1000:
            continue
        nd = _iso(h["ngay"])
        theo_dt.setdefault(h["dt"], []).append({"so": h["so"], "ngay": nd.strftime("%d/%m/%Y") if nd else h["ngay"], "iso": h["ngay"], "tong": h["tong"], "con": con,
                                                "chieu": h["chieu"], "tuoi": (den - nd).days if nd else None,
                                                "nhom": nhom_tuoi(nd, den)})
    kq = []
    for m in sorted(la_cn, key=lambda x: S.tk[x]["sh"]):
        sh = S.tk[m]["sh"]
        la_thu = sh.startswith("131") or S.tk[m].get("id") == 3500
        for kh, v in d[m].items():
            if not kh:
                continue
            dau, no, co = v
            cuoi = dau + no - co
            if abs(cuoi) <= 1 and abs(no) <= 1 and abs(co) <= 1:
                continue
            x = dt.get(kh) or ["", "", ""]
            hds = [h for h in theo_dt.get(x[0], []) if (h["chieu"] == "ban") == la_thu]
            kq.append({"ma": x[0], "ten": x[1], "mst": x[2], "tk": sh, "la_thu": la_thu, "dau": dau, "no": no, "co": co,
                       "cuoi": cuoi, "hd": sorted(hds, key=lambda h: h["iso"])})
    return kq, den


def _ben_du(x, la_thu):
    """so du (No - Co) -> (Nợ, Có) de in."""
    return (x, 0.0) if x >= 0 else (0.0, -x)


CSS = """
body{font-family:Arial,Helvetica,sans-serif;color:#1d2433;background:#eef1f5;margin:0}
.thanh{position:sticky;top:0;background:#1f4e79;color:#fff;padding:10px 18px;display:flex;gap:14px;align-items:center}
.thanh button{background:#fff;color:#1f4e79;border:0;border-radius:4px;padding:6px 14px;font-weight:bold;cursor:pointer}
.tom,.trang{background:#fff;max-width:900px;margin:14px auto;padding:18px 30px;border-radius:6px}
h1{font-size:19px;text-align:center;margin:10px 0 2px}.phu{text-align:center;color:#555;margin-bottom:14px}
table{width:100%;border-collapse:collapse;margin:8px 0}th,td{border:1px solid #9aa5b1;padding:5px 7px}th{background:#e8eef5}
td.so{text-align:right;white-space:nowrap}tr.tong td{font-weight:bold;background:#f6f8fa}.qh{color:#b3261e;font-weight:bold}
.kyten{display:flex;justify-content:space-around;margin-top:30px;text-align:center;min-height:110px}
@media print{body{background:#fff}.thanh,.tom{display:none}.trang{margin:0;max-width:none;page-break-after:always;border-radius:0}}
"""


def ghi_bien_ban(ds, den, cty, ky, duong):
    trang, tom = [], []
    for i, x in enumerate(ds, 1):
        dn, dc = _ben_du(x["dau"], x["la_thu"])
        cn, cc = _ben_du(x["cuoi"], x["la_thu"])
        nd_cuoi = ("%s còn nợ %s %s đ" % ("Quý khách" if x["la_thu"] else "Chúng tôi", "chúng tôi" if x["la_thu"] else "Quý công ty", _tien(abs(x["cuoi"]))))
        if (x["la_thu"] and x["cuoi"] < 0) or (not x["la_thu"] and x["cuoi"] > 0):
            nd_cuoi = "Số trả trước / trả thừa còn lại: %s đ" % _tien(abs(x["cuoi"]))
        dong_hd = "".join("<tr><td>%d</td><td>%s</td><td>%s</td><td class='so'>%s</td><td class='so'>%s</td><td class='so %s'>%s</td></tr>"
                          % (j, _e(h["so"]), _e(h["ngay"]), _tien(h["tong"]), _tien(h["con"]),
                             "qh" if (h["tuoi"] or 0) > HAN_TT else "", "%s ngày" % h["tuoi"] if h["tuoi"] is not None else "")
                          for j, h in enumerate(x["hd"], 1))
        bang_hd = ("<div>Chi tiết hóa đơn chưa thanh toán (tuổi nợ tính đến %s):</div><table><tr><th>STT</th><th>Số hóa đơn</th><th>Ngày</th>"
                   "<th>Giá trị</th><th>Còn lại</th><th>Tuổi nợ</th></tr>%s</table>" % (den.strftime("%d/%m/%Y"), dong_hd)) if dong_hd else ""
        trang.append(
            "<div class='trang' id='dt%d'><div><b>%s</b><br>MST: %s</div><h1>BIÊN BẢN ĐỐI CHIẾU CÔNG NỢ</h1>"
            "<div class='phu'>Kỳ đối chiếu: %s - %s</div>"
            "<div>Bên A: <b>%s</b> (MST %s)</div><div>Bên B: <b>%s</b>%s</div>"
            "<div>Tài khoản: %s - %s</div>"
            "<table><tr><th rowspan='2'>Chỉ tiêu</th><th colspan='2'>Số tiền (đ)</th></tr><tr><th>Nợ</th><th>Có</th></tr>"
            "<tr><td>Số dư đầu kỳ</td><td class='so'>%s</td><td class='so'>%s</td></tr>"
            "<tr><td>Phát sinh trong kỳ</td><td class='so'>%s</td><td class='so'>%s</td></tr>"
            "<tr class='tong'><td>Số dư cuối kỳ</td><td class='so'>%s</td><td class='so'>%s</td></tr></table>"
            "<div>Kết luận: <b>%s</b>.</div>%s"
            "<div style='margin-top:10px'>Hai bên đối chiếu và thống nhất số liệu trên. Nếu có chênh lệch, đề nghị Bên B phản hồi "
            "trong vòng 07 ngày kể từ ngày nhận biên bản; quá thời hạn trên, số liệu được coi là đã xác nhận.</div>"
            "<div class='kyten'><div><b>ĐẠI DIỆN BÊN A</b><br>(Ký, ghi rõ họ tên, đóng dấu)</div>"
            "<div><b>ĐẠI DIỆN BÊN B</b><br>(Ký, ghi rõ họ tên, đóng dấu)</div></div></div>"
            % (i, _e(cty.get("ten")), _e(cty.get("mst")), _e(ky.get("tu")), _e(ky.get("den")), _e(cty.get("ten")), _e(cty.get("mst")),
               _e(x["ten"] or x["ma"]), (" (MST %s)" % _e(x["mst"])) if x["mst"] else "", _e(x["tk"]),
               "Phải thu khách hàng" if x["la_thu"] else "Phải trả người bán",
               _tien(dn), _tien(dc), _tien(x["no"]), _tien(x["co"]), _tien(cn), _tien(cc), _e(nd_cuoi), bang_hd))
        qh = sum(h["con"] for h in x["hd"] if (h["tuoi"] or 0) > HAN_TT)
        tom.append("<tr><td>%d</td><td><a href='#dt%d'>%s</a></td><td>%s</td><td>%s</td><td class='so'>%s</td><td class='so qh'>%s</td></tr>"
                   % (i, i, _e(x["ten"] or x["ma"]), _e(x["ma"]), _e(x["tk"]), _tien(x["cuoi"]), _tien(qh) if qh else ""))
    doc = ("<!doctype html><html lang='vi'><head><meta charset='utf-8'><title>Biên bản đối chiếu công nợ</title><style>%s</style></head><body>"
           "<div class='thanh'><b>BIÊN BẢN ĐỐI CHIẾU CÔNG NỢ</b><span>%s</span><button onclick='window.print()'>In / Lưu PDF</button></div>"
           "<div class='tom'><b>%d đối tác</b><table><tr><th>STT</th><th>Đối tác</th><th>Mã</th><th>TK</th><th>Số dư cuối (Nợ - Có)</th>"
           "<th>Quá hạn &gt; %d ngày</th></tr>%s</table></div>%s</body></html>"
           % (CSS, _e(cty.get("ten")), len(ds), HAN_TT, "".join(tom), "".join(trang)))
    with io.open(duong, "w", encoding="utf-8") as f:
        f.write(doc)


def ghi_nhac_no(ds, den, cty, duong, tien_to="TTCN"):
    """Tin nhan (Zalo / email) cho khach hang co hoa don qua han. Tra ve so khach."""
    khoi = []
    for x in ds:
        if not x["la_thu"]:
            continue
        qh = [h for h in x["hd"] if (h["tuoi"] or 0) > HAN_TT]
        if not qh:
            continue
        tong = sum(h["con"] for h in qh)
        dong = ["Kính gửi %s," % (x["ten"] or x["ma"]),
                "%s xin thông báo các hóa đơn đã quá hạn thanh toán (tính đến %s):" % (cty.get("ten") or "Chúng tôi", den.strftime("%d/%m/%Y"))]
        for h in qh:
            dong.append("  - HĐ số %s ngày %s: còn %s đ (quá %d ngày)" % (h["so"], h["ngay"], _tien(h["con"]), (h["tuoi"] or 0) - HAN_TT))
        dong.append("Tổng cộng: %s đ." % _tien(tong))
        dong.append("Khi chuyển khoản xin ghi nội dung: %s%s" % (tien_to, "".join(c for c in str(x["ma"]).upper() if c.isalnum())))
        dong.append("Nếu Quý khách đã thanh toán, xin bỏ qua tin nhắn này. Trân trọng cảm ơn.")
        khoi.append("===== %s (%s) =====\n%s" % (x["ten"] or x["ma"], x["ma"], "\n".join(dong)))
    with io.open(duong, "w", encoding="utf-8") as f:
        f.write(("\n\n".join(khoi) + "\n") if khoi else "Không có khách hàng quá hạn.\n")
    return len(khoi)


def ghi_tong_hop(ds, duong):
    cot = ["Ma", "Ten", "MST", "TK", "Dau ky (No-Co)", "PS No", "PS Co", "Cuoi ky (No-Co)"] + ["Con no %s ngay" % t for _, _, t in NHOM]
    with io.open(duong, "w", encoding="utf-8-sig") as f:
        f.write(";".join(cot) + "\n")
        for x in ds:
            nh = {t: 0.0 for _, _, t in NHOM}
            for h in x["hd"]:
                nh[h["nhom"]] = nh.get(h["nhom"], 0.0) + h["con"]
            f.write(";".join(str(v).replace(";", ",") for v in [x["ma"], x["ten"], x["mst"], x["tk"], round(x["dau"]), round(x["no"]),
                                                                  round(x["co"]), round(x["cuoi"])] + [round(nh[t]) for _, _, t in NHOM]) + "\n")


def lap(S, dt, cong_no, phan_tich_hd, thu_muc_ra):
    ds, den = thu_thap(S, dt, cong_no, phan_tich_hd)
    if not ds:
        return None, 0, 0
    os.makedirs(thu_muc_ra, exist_ok=True)
    cty = S.dl.get("cty") or {}
    ky = S.dl.get("ky") or {}
    ghi_bien_ban(ds, den, cty, ky, os.path.join(thu_muc_ra, "bien_ban.html"))
    n_nhac = ghi_nhac_no(ds, den, cty, os.path.join(thu_muc_ra, "nhac_no.txt"))
    ghi_tong_hop(ds, os.path.join(thu_muc_ra, "tong_hop.csv"))
    return thu_muc_ra, len(ds), n_nhac


def k_lap_bien_ban(S, dt, cong_no, _kq, DAT, CANH_BAO, LOI, THONG_TIN):
    ten = "Biên bản đối chiếu công nợ và nhắc nợ (đã lập sẵn)"
    goc = str(S.dl.get("thu_muc_khach") or "")
    if not goc:
        return [_kq("K43", ten, THONG_TIN, "Bản phần mềm chưa gửi thư mục khách (cần bản GĐ234 trở lên) - chưa lập biên bản.")]
    import doi_chieu_3c
    ra = os.path.join(goc, "ket-qua", "doi-chieu-cong-no", datetime.now().strftime("%Y%m%d_%H%M"))
    duong, n, n_nhac = lap(S, dt, cong_no, doi_chieu_3c.phan_tich, ra)
    if not duong:
        return [_kq("K43", ten, THONG_TIN, "Không có đối tác 131 / 331 có số dư hoặc phát sinh trong kỳ.")]
    return [_kq("K43", ten, THONG_TIN, "Đã lập biên bản đối chiếu cho %d đối tác (bien_ban.html - In / Lưu PDF gửi đối tác), nhắc nợ %d khách "
                "quá hạn > %d ngày (nhac_no.txt - phần mềm không tự gửi), tổng hợp tuổi nợ (tong_hop.csv) tại: %s" % (n, n_nhac, HAN_TT, duong))]
