# -*- coding: utf-8 -*-
"""GD174 - HO SO KEM CHUNG TU (H2) + YEU CAU CHUNG TU TU KHACH (F1) - chi DOC so, chi DANH DAU, khong ghi so.

VB6 (ModHoSoCT174.HS174_Json) gui JSON:
  loai "HOSOCT", phien_ban 174, cty {ten, mst}, ky {tu, den} dd/mm/yyyy, hom_nay, thong_tu, nam_tc, thu_muc_khach, nguoi_ky
  dt      : [MaSo, SoHieu, Ten, MST]                                    (KhachHang)
  hdm     : [so, ky hieu, MaKH, ngay, chua thue, thue, TK Co nho nhat, MaCT, so hieu CT, MST, ten]   (HoaDon Loai = -1, gop)
  hdb     : [so, ky hieu, MaKH, ngay, chua thue, thue, TK No nho nhat, MaCT, so hieu CT, MST, ten, ty le, KCT]  (Loai = 1)
  ct      : [MaCT, MaLoai, ngay, so hieu, dien giai, TK No, TK Co, SoPS, MaKH, MaVattu, MaKho, MaDT, lien ket]  (ChungTu trong ky)
  tt      : [MaKH, ngay, tien, TK Co, MaCT]        tra NCC (No 331x) tu dau ky den hom nay
  thu     : [MaKH, ngay, tien, TK No, MaCT]        thu khach (Co 131x) tu dau ky den hom nay
  hddt    : [MaCT HDDT, so, ky hieu, ngay, MST ban, tong, hinh thuc TT, loai CT, MaCTKeToan, ban ra]  (HDDTTaiVe trong ky, gop)
  hopdong : [MaSo, SoHieu, DienGiai, NgayKy, MaKH, TriGia]              (DoituongCT)
  ts_ct   : [MaCTKT]  chung tu da co the TSCD;  cc_ct: [MaCTKT] chung tu da co the CCDC / 242
  bl      : [thang...] thang co bang luong;  nv: so nhan vien;  sp_thang: [[thang, so dong]] so phu da nhap
  dau     : [khoa, trang thai (CO / KHONG), ghi chu]                    (HDDT_HS_DanhDau - nguoi dung danh dau ngoai so)
Nghiep vu nhan ra tu so: MUA_HH (hang hoa / NVL), MUA_DV (dich vu, chi phi), TSCD, CCDC, TIEP_KHACH, BAN_HANG, XUAT_KHAU,
LUONG (theo thang), VAY (giai ngan). Moi nghiep vu co bo chung tu kem theo; tung muc: CO (thay trong so / da danh dau),
THIEU (phai co ma khong thay), CHO (chua phat sinh - vd chua tra tien), TU_KHAI (so khong kiem duoc - nguoi dung tu tich), KAD (khong ap dung).
Ket qua: Excel (Tong hop / Chi tiet / Thieu / Giai trinh / Yeu cau khach / Can cu) + tep ';' cho VB:
  TONG;174;n_gd;n_du;n_thieu;n_cho;n_tu_khai;xlsx;html;txt
  NV;loai;ten;n;du;thieu;cho
  T;loai;ma_gd;MaCT;so_hd;ngay;MaKH;mst;doi_tac;tien;muc;thieu;cho;tu_khai
  M;khoa;ten;trang_thai;ghi_chu
  YC;nhom;noi_dung
Thu yeu cau chung tu (F1): <thu_muc_khach>\\ket-qua\\yeu-cau-chung-tu\\YEU_CAU_CHUNG_TU_<tu>_<den>.html + .txt (Zalo / email - nguoi dung tu gui);
thu muc nhan: <thu_muc_khach>\\den\\{hoadon, sophu, luong, khac} + HUONG_DAN_GUI_CHUNG_TU.txt. nhan_chung_tu(): quet tep moi trong den\\.
Moc thanh toan khong dung tien mat: tham_so_nam MOC_TT_KHONG_TM (mac dinh 5.000.000). Khong goi Claude API; khong ghi MDB;
khong ghi ten khach / MST vao nhat ky.
"""
import datetime
import io
import json
import os
import re
import unicodedata
from collections import OrderedDict, defaultdict

GOC = os.path.dirname(os.path.abspath(__file__))
MOC_MAC_DINH = 5000000.0
CO, THIEU, CHO, TU_KHAI, KAD = "CO", "THIEU", "CHO", "TU_KHAI", "KAD"
TEN_TT = {CO: "Đã có", THIEU: "THIẾU", CHO: "Chờ phát sinh", TU_KHAI: "Tự khai", KAD: "Không áp dụng"}
TEN_LOAI = OrderedDict([("MUA_HH", "Mua hàng hoá / nguyên vật liệu"), ("MUA_DV", "Mua dịch vụ / chi phí"), ("TSCD", "Mua sắm tài sản cố định"),
                        ("CCDC", "Công cụ dụng cụ / chi phí trả trước"), ("TIEP_KHACH", "Tiếp khách / hội nghị / quà tặng"),
                        ("BAN_HANG", "Bán hàng / cung cấp dịch vụ"), ("XUAT_KHAU", "Xuất khẩu (thuế suất 0%)"), ("LUONG", "Tiền lương tháng"),
                        ("VAY", "Vay vốn / giải ngân")])
TK_HANG = ("152", "153", "155", "156", "157", "611")
TK_TSCD = ("211", "213", "2411", "2412", "2413")
TK_CCDC = ("242",)
TU_TIEP_KHACH = ("tiếp khách", "tiep khach", "ăn uống", "an uong", "hội nghị", "hoi nghi", "quà tặng", "qua tang", "nhà hàng", "nha hang",
                 "khách sạn", "khach san", "tiệc", "tiec", "liên hoan", "lien hoan", "cafe", "cà phê")
TU_XUAT_KHAU = ("xuất khẩu", "xuat khau", "export", "tờ khai", "to khai")

# bo chung tu theo nghiep vu: (ma muc, ten, kieu kiem, yc) - kieu: HD, HDDT, HOPDONG, HOPDONG_BB (bat buoc), PNK, PXK, TT, THU, THU_NH,
#   THE_TS, THE_CC, BL, CHILUONG, BHXH, TU (so khong kiem duoc); yc = True: muc Tu khai cung dua vao thu yeu cau khach (giay to quan trong)
BO_CT = {
    "MUA_HH": [("HD", "Hoá đơn mua hàng", "HD", 0), ("HDDT", "Bản điện tử (XML / PDF) của hoá đơn", "HDDT", 1),
               ("HOPDONG", "Hợp đồng / đơn đặt hàng / báo giá", "HOPDONG", 0), ("PNK", "Phiếu nhập kho", "PNK", 0),
               ("BBGN", "Biên bản giao nhận hàng / phiếu giao hàng", "TU", 0), ("TT", "Chứng từ thanh toán không dùng tiền mặt", "TT", 1)],
    "MUA_DV": [("HD", "Hoá đơn dịch vụ", "HD", 0), ("HDDT", "Bản điện tử (XML / PDF) của hoá đơn", "HDDT", 1),
               ("HOPDONG", "Hợp đồng / đề nghị cung cấp dịch vụ", "HOPDONG", 0), ("NGHIEMTHU", "Biên bản nghiệm thu / bàn giao dịch vụ", "TU", 1),
               ("TT", "Chứng từ thanh toán không dùng tiền mặt", "TT", 1)],
    "TSCD": [("HD", "Hoá đơn mua tài sản", "HD", 0), ("HDDT", "Bản điện tử (XML / PDF) của hoá đơn", "HDDT", 1),
             ("HOPDONG", "Hợp đồng mua bán tài sản", "HOPDONG", 1), ("BBGN", "Biên bản bàn giao tài sản", "TU", 1),
             ("THE_TS", "Thẻ TSCĐ / ghi tăng tài sản trên phần mềm", "THE_TS", 0), ("QDSD", "Quyết định đưa tài sản vào sử dụng", "TU", 1),
             ("TT", "Chứng từ thanh toán không dùng tiền mặt", "TT", 1)],
    "CCDC": [("HD", "Hoá đơn mua CCDC", "HD", 0), ("HDDT", "Bản điện tử (XML / PDF) của hoá đơn", "HDDT", 1), ("PNK", "Phiếu nhập kho", "PNK", 0),
             ("THE_CC", "Thẻ CCDC / bảng phân bổ trên phần mềm", "THE_CC", 0), ("TT", "Chứng từ thanh toán không dùng tiền mặt", "TT", 1)],
    "TIEP_KHACH": [("HD", "Hoá đơn", "HD", 0), ("HDDT", "Bản điện tử (XML / PDF) của hoá đơn", "HDDT", 1),
                   ("BANGKE", "Bảng kê / danh sách khách, mục đích tiếp khách", "TU", 1), ("DENGHI", "Giấy đề nghị thanh toán có duyệt", "TU", 1),
                   ("TT", "Chứng từ thanh toán không dùng tiền mặt", "TT", 1)],
    "BAN_HANG": [("HD", "Hoá đơn bán ra", "HD", 0), ("HOPDONG", "Hợp đồng / đơn đặt hàng của khách", "HOPDONG", 0),
                 ("PXK", "Phiếu xuất kho / giá vốn", "PXK", 0), ("BBGN", "Biên bản giao hàng / nghiệm thu", "TU", 0), ("THU", "Chứng từ thu tiền", "THU", 0)],
    "XUAT_KHAU": [("HD", "Hoá đơn bán ra (0%)", "HD", 0), ("HOPDONG", "Hợp đồng ngoại thương", "HOPDONG_BB", 1),
                  ("TKHQ", "Tờ khai hải quan đã thông quan", "TU", 1), ("VANDON", "Vận đơn / chứng từ vận chuyển", "TU", 1),
                  ("THU", "Chứng từ thanh toán qua ngân hàng", "THU_NH", 1)],
    "LUONG": [("BL", "Bảng lương", "BL", 1), ("CHAMCONG", "Bảng chấm công", "TU", 1), ("HDLD", "Hợp đồng lao động từng người", "TU", 1),
              ("CHILUONG", "Chứng từ chi lương (phiếu chi / UNC)", "CHILUONG", 1), ("BHXH", "Chứng từ nộp BHXH", "BHXH", 0)],
    "VAY": [("HDVAY", "Hợp đồng vay / khế ước", "HOPDONG_BB", 1), ("GIAINGAN", "Chứng từ giải ngân", "HD", 0),
            ("LAI", "Bảng tính lãi / chứng từ trả lãi", "TU", 1)],
}
CAN_CU = [
    "CĂN CỨ BỘ CHỨNG TỪ (GĐ174 - tham khảo; kế toán đối chiếu lại văn bản hiện hành)",
    "Luật Thuế TNDN 67/2025/QH15 (Điều 9) và nghị định hướng dẫn: khoản chi được trừ phải liên quan hoạt động SXKD, có đủ hoá đơn, chứng từ; "
    "hoá đơn mua hàng hoá, dịch vụ từng lần từ mốc quy định (bộ tham số năm MOC_TT_KHONG_TM, hiện 5.000.000 đ) phải có chứng từ thanh toán không dùng tiền mặt.",
    "Luật Thuế GTGT 48/2024/QH15 (Điều 14) và NĐ 181/2025/NĐ-CP (Điều 26): khấu trừ thuế GTGT đầu vào cần hoá đơn hợp pháp + chứng từ thanh toán "
    "không dùng tiền mặt với hoá đơn từ 5 triệu đồng (đã gồm thuế); mua nhiều lần cùng ngày cùng người bán tính gộp.",
    "NĐ 254/2026/NĐ-CP và TT 91/2026/TT-BTC về hoá đơn: hoá đơn điện tử lập đúng thời điểm; lưu bản XML là chứng từ gốc.",
    "Luật Kế toán và NĐ 174/2016/NĐ-CP: chứng từ kế toán (phiếu thu, chi, nhập, xuất kho, bảng chấm công, bảng lương) do doanh nghiệp lập theo mẫu "
    "TT 133/2016 hoặc TT 99/2025; lưu trữ tối thiểu 10 năm.",
    "TSCĐ: TT 45/2013/TT-BTC (hoặc văn bản thay thế): hoá đơn, hợp đồng, biên bản bàn giao, quyết định đưa vào sử dụng, thẻ TSCĐ.",
    "Xuất khẩu 0% (Luật GTGT 48/2024, Điều 9): hợp đồng, tờ khai hải quan đã thông quan, chứng từ thanh toán qua ngân hàng.",
    "Tiền lương: hợp đồng lao động, bảng chấm công, bảng lương, chứng từ chi, chứng từ nộp BHXH; TNCN khấu trừ theo biểu luỹ tiến.",
    "Tiếp khách, hội nghị, quà tặng: không khống chế từ 2015 nhưng phải có hoá đơn, chứng từ thanh toán và liên quan SXKD; quà tặng phải xuất hoá đơn.",
    "Vay vốn: hợp đồng vay, chứng từ giải ngân qua ngân hàng, bảng tính lãi; lãi vay của cá nhân không vượt 150% lãi suất cơ bản.",
    "Dấu 'Tự khai': phần mềm không kiểm được từ sổ - kế toán tích 'Đã có ngoài sổ' sau khi tập hợp giấy tờ (bảng HDDT_HS_DanhDau).",
]


# ============================================================ tien ich
def _so(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return 0.0


def _int(v):
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return 0


def _ngay(s):
    s = str(s or "").strip()
    for f in ("%d/%m/%Y", "%Y-%m-%d", "%d-%m-%Y"):
        try:
            return datetime.datetime.strptime(s[:10], f).date()
        except ValueError:
            pass
    return None


def vn(d):
    return d.strftime("%d/%m/%Y") if d else ""


def bo_dau(s):
    s = unicodedata.normalize("NFD", str(s or ""))
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    return s.replace("đ", "d").replace("Đ", "D")


def khong_dau(s):
    return bo_dau(s).lower()


def _chu(v, n=300):
    return str(v or "").replace(";", ",").replace("\r", " ").replace("\n", " ").strip()[:n]


def tien(x):
    try:
        return "{:,.0f}".format(float(x)).replace(",", ".")
    except (TypeError, ValueError):
        return "0"


def _moc(ngay):
    try:
        import tham_so_nam
        v = tham_so_nam.lay("MOC_TT_KHONG_TM", ngay)
        if v is not None and _so(v) > 0:
            return _so(v)
    except Exception:
        pass
    return MOC_MAC_DINH


# ============================================================ so lieu
class SoLieu(object):
    def __init__(self, dl):
        self.dl = dl or {}
        ky = self.dl.get("ky") or {}
        self.tu = _ngay(ky.get("tu")) or datetime.date.today().replace(day=1)
        self.den = _ngay(ky.get("den")) or datetime.date.today()
        self.hom_nay = _ngay(self.dl.get("hom_nay")) or datetime.date.today()
        self.cty = dict(self.dl.get("cty") or {})
        self.nguoi_ky = self.dl.get("nguoi_ky") or {}
        if not isinstance(self.nguoi_ky, dict):
            self.nguoi_ky = {}
        self.thu_muc_khach = str(self.dl.get("thu_muc_khach") or "")
        self.dt = {}
        for r in self.dl.get("dt") or []:
            r = list(r) + [""] * 4
            if _int(r[0]) > 0:
                self.dt[_int(r[0])] = {"sh": str(r[1] or "").strip(), "ten": str(r[2] or "").strip(), "mst": str(r[3] or "").strip()}
        self.ct = OrderedDict()
        for r in self.dl.get("ct") or []:
            r = list(r) + [""] * 13
            ma = _int(r[0])
            if ma <= 0:
                continue
            c = self.ct.get(ma)
            if c is None:
                c = {"ma": ma, "loai": _int(r[1]), "ngay": _ngay(r[2]), "sh": _chu(r[3], 60), "dg": str(r[4] or "").strip(),
                     "dong": [], "dt": _int(r[11]), "lk": str(r[12] or "").strip()}
                self.ct[ma] = c
            c["dong"].append({"no": str(r[5] or "").strip(), "co": str(r[6] or "").strip(), "ps": _so(r[7]), "kh": _int(r[8]),
                              "vt": _int(r[9]), "kho": _int(r[10])})
            if _int(r[11]) > c["dt"]:
                c["dt"] = _int(r[11])
            if not c["lk"] and str(r[12] or "").strip():
                c["lk"] = str(r[12] or "").strip()
        self.hdm = [self._hd(r, False) for r in (self.dl.get("hdm") or [])]
        self.hdb = [self._hd(r, True) for r in (self.dl.get("hdb") or [])]
        self.tt = [{"kh": _int(r[0]), "ngay": _ngay(r[1]), "ps": _so(r[2]), "tk": str(r[3] or "").strip(), "ma": _int(r[4])}
                   for r in (self.dl.get("tt") or []) if len(r) >= 5]
        self.thu = [{"kh": _int(r[0]), "ngay": _ngay(r[1]), "ps": _so(r[2]), "tk": str(r[3] or "").strip(), "ma": _int(r[4])}
                    for r in (self.dl.get("thu") or []) if len(r) >= 5]
        self.hddt_kt, self.hddt_so = {}, {}
        for r in self.dl.get("hddt") or []:
            r = list(r) + [""] * 10
            h = {"ma": str(r[0] or ""), "so": str(r[1] or "").strip().lstrip("0"), "kh": str(r[2] or "").strip(), "ngay": _ngay(r[3]),
                 "mst": str(r[4] or "").strip(), "tong": _so(r[5]), "tt": str(r[6] or "").strip(), "loai_ct": str(r[7] or "").strip().upper(),
                 "kt": _int(r[8]), "ban": _int(r[9])}
            if h["kt"] > 0:
                self.hddt_kt[h["kt"]] = h
            self.hddt_so[(h["so"], h["mst"])] = h
        self.co_hddt = any(h["ban"] == 0 for h in self.hddt_so.values())        # da tai hoa don MUA (dau vao) -> moi kiem "ban dien tu"
        self.hopdong = []
        for r in self.dl.get("hopdong") or []:
            r = list(r) + [""] * 6
            self.hopdong.append({"ma": _int(r[0]), "sh": _chu(r[1], 60), "dg": str(r[2] or "").strip(), "ngay": _ngay(r[3]), "kh": _int(r[4]), "tri_gia": _so(r[5])})
        self.ts_ct = set(_int(x[0] if isinstance(x, (list, tuple)) else x) for x in (self.dl.get("ts_ct") or []))
        self.cc_ct = set(_int(x[0] if isinstance(x, (list, tuple)) else x) for x in (self.dl.get("cc_ct") or []))
        self.bl = set(_int(x) for x in (self.dl.get("bl") or []))
        self.nv = _int(self.dl.get("nv"))
        self.sp_thang = {_int(r[0]): _int(r[1]) for r in (self.dl.get("sp_thang") or []) if len(r) >= 2}
        self.tt_kh, self.thu_kh, self.pnk_kh = defaultdict(list), defaultdict(list), defaultdict(list)
        for t in self.tt:
            if t["ngay"]:
                self.tt_kh[t["kh"]].append(t)
        for t in self.thu:
            if t["ngay"]:
                self.thu_kh[t["kh"]].append(t)
        for c in self.ct.values():
            if c["loai"] == 1 and c["ngay"]:
                for kh in set(d["kh"] for d in c["dong"] if d["kh"] > 0):
                    self.pnk_kh[kh].append(c)
        self.pb_tt, self.pb_thu = None, None      # phan bo FIFO (lap khi can): (makh, mact, so) -> {"nh", "tm", "cuoi"}
        self.dau = {}
        for r in self.dl.get("dau") or []:
            r = list(r) + [""] * 3
            if str(r[0] or "").strip():
                self.dau[str(r[0]).strip()] = (str(r[1] or "").strip().upper(), str(r[2] or "").strip())
        self.moc_cache = {}

    def _hd(self, r, ban):
        r = list(r) + [""] * 13
        return {"so": _chu(r[0], 60), "kh": _chu(r[1], 30), "makh": _int(r[2]), "ngay": _ngay(r[3]), "gt": _so(r[4]), "thue": _so(r[5]),
                "tk": str(r[6] or "").strip(), "mact": _int(r[7]), "sh": _chu(r[8], 60), "mst": _chu(r[9], 20),
                "ten": _chu(r[10], 120), "tyle": _so(r[11]) if ban else None, "kct": _int(r[12]) if ban else 0, "ban": ban}

    def phan_bo(self, ban):
        """Phan bo FIFO khoan tra NCC (tt) / thu khach (thu) len hoa don cua tung doi tac theo ngay (ung truoc toi da 30 ngay) - moi khoan
        chi dung mot lan, khong cong don cho moi hoa don. -> {(makh, mact, so): {"nh": tien qua NH, "tm": tien mat, "cuoi": ngay NH cuoi}}."""
        kq = {}
        hds = sorted([h for h in (self.hdb if ban else self.hdm) if h["ngay"]], key=lambda h: (h["makh"], h["ngay"], h["mact"]))
        nguon = self.thu_kh if ban else self.tt_kh
        for makh in set(h["makh"] for h in hds):
            khoan = sorted(nguon.get(makh, []), key=lambda t: t["ngay"])
            con = [t["ps"] for t in khoan]
            for h in [x for x in hds if x["makh"] == makh]:
                tong = h["gt"] + h["thue"]
                r = {"nh": 0.0, "tm": 0.0, "cuoi": None}
                for i, t in enumerate(khoan):
                    if tong <= 0.5 or con[i] <= 0 or t["ngay"] < h["ngay"] - datetime.timedelta(days=30):
                        continue
                    lay = min(con[i], tong)
                    con[i] -= lay
                    tong -= lay
                    if t["tk"].startswith(("112", "113", "341")):
                        r["nh"] += lay
                        r["cuoi"] = max(r["cuoi"], t["ngay"]) if r["cuoi"] else t["ngay"]
                    elif t["tk"].startswith("111"):
                        r["tm"] += lay
                kq[(makh, h["mact"], h["so"])] = r
        return kq

    def moc(self, ngay):
        k = (ngay or self.den).strftime("%Y-%m")
        if k not in self.moc_cache:
            self.moc_cache[k] = _moc(ngay or self.den)
        return self.moc_cache[k]

    def ten_dt(self, makh):
        d = self.dt.get(makh)
        return d["ten"] if d else ""

    def mst_dt(self, makh):
        d = self.dt.get(makh)
        return d["mst"] if d else ""

    def thang_ky(self):
        ra, d = [], self.tu.replace(day=1)
        while d <= self.den:
            ra.append(d.month)
            d = (d.replace(day=28) + datetime.timedelta(days=4)).replace(day=1)
        return ra


# ============================================================ nhan ra nghiep vu
def loai_hd_mua(S, hd):
    c = S.ct.get(hd["mact"])
    h = S.hddt_kt.get(hd["mact"]) or S.hddt_so.get((hd["so"].lstrip("0"), hd["mst"]))
    nos = set()
    co_vt = False
    dg = ""
    if c:
        dg = khong_dau(c["dg"])
        for d in c["dong"]:
            if d["no"] and not d["no"].startswith("133"):
                nos.add(d["no"])
                if d["vt"] > 0:
                    co_vt = True
    lc = (h or {}).get("loai_ct", "")
    if any(n.startswith(TK_TSCD) for n in nos) or lc == "TSCD":
        return "TSCD"
    if any(n.startswith(TK_CCDC) for n in nos) or lc == "CCDC" or (hd["mact"] in S.cc_ct):
        return "CCDC"
    if any(n.startswith(TK_HANG) for n in nos) and (co_vt or lc in ("HH", "NVL", "TP")):
        return "MUA_HH"
    if any(t in dg for t in (khong_dau(x) for x in TU_TIEP_KHACH)):
        return "TIEP_KHACH"
    return "MUA_DV"


def loai_hd_ban(S, hd):
    c = S.ct.get(hd["mact"])
    dg = khong_dau(c["dg"]) if c else ""
    if (hd["tyle"] is not None and hd["tyle"] == 0 and not hd["kct"]) and any(khong_dau(t) in dg for t in TU_XUAT_KHAU):
        return "XUAT_KHAU"
    if hd["tyle"] is not None and hd["tyle"] == 0 and not hd["kct"] and ("usd" in dg or "eur" in dg):
        return "XUAT_KHAU"
    return "BAN_HANG"


def _hop_dong(S, makh, ngay, mact):
    c = S.ct.get(mact)
    if c and c["dt"] > 1:
        hd = next((x for x in S.hopdong if x["ma"] == c["dt"]), None)
        return "hợp đồng %s trên chứng từ" % (hd["sh"] if hd else c["dt"])
    for x in S.hopdong:
        if x["kh"] == makh and makh > 0 and x["ngay"] and ngay and x["ngay"] <= ngay + datetime.timedelta(days=30) and x["ngay"] >= ngay - datetime.timedelta(days=400):
            return "hợp đồng %s ngày %s (cùng đối tác)" % (x["sh"], vn(x["ngay"]))
    return ""


def _thanh_toan(S, hd, tong, qua_nh_bat_buoc, tong_cung_ngay=0.0):
    """-> (trang thai, ghi chu). TK Co tren dong hoa don = cach tra; 331 / 338 -> khoan tra NCC phan bo FIFO (S.phan_bo). tong_cung_ngay: tong
    cac hoa don cung nguoi ban cung ngay (Luat GTGT: gop lai tu moc van phai khong dung tien mat)."""
    moc = S.moc(hd["ngay"])
    tk = hd["tk"]
    gop = ""
    if not qua_nh_bat_buoc and tong < moc:
        if tong_cung_ngay < moc:
            return KAD, "dưới mốc %s - được trả tiền mặt" % tien(moc)
        gop = " (gộp hoá đơn cùng người bán cùng ngày %s - từ mốc)" % tien(tong_cung_ngay)
    if tk.startswith("111"):
        return THIEU, "trả TIỀN MẶT %s (từ mốc %s phải không dùng tiền mặt)%s" % (tien(tong), tien(moc), gop)
    if tk.startswith(("112", "113", "341")):
        return CO, "thanh toán qua ngân hàng ngay trên chứng từ (TK %s)" % tk
    if tk.startswith("141"):
        return TU_KHAI, "trả qua tạm ứng nhân viên - kiểm chứng từ nhân viên thanh toán không dùng tiền mặt" + gop
    if tk.startswith(("331", "338")):
        if S.pb_tt is None:
            S.pb_tt = S.phan_bo(False)
        r = S.pb_tt.get((hd["makh"], hd["mact"], hd["so"])) or {"nh": 0.0, "tm": 0.0, "cuoi": None}
        if r["nh"] >= tong * 0.98:
            return CO, "đã trả qua ngân hàng %s (đến %s, phân bổ theo thứ tự ngày)%s" % (tien(r["nh"]), vn(r["cuoi"]), gop)
        if r["tm"] >= tong * 0.98 and r["nh"] == 0:
            return THIEU, "đã trả TIỀN MẶT %s cho hoá đơn này (phân bổ theo thứ tự ngày - phải qua ngân hàng)%s" % (tien(r["tm"]), gop)
        if r["nh"] + r["tm"] > 0:
            return CHO, "mới trả %s qua ngân hàng, %s tiền mặt / %s - phần còn lại khi trả phải qua ngân hàng%s" % (tien(r["nh"]), tien(r["tm"]), tien(tong), gop)
        return CHO, "còn nợ đối tác - khi trả phải qua ngân hàng (UNC) và giữ chứng từ" + gop
    return TU_KHAI, "TK đối ứng %s - kiểm chứng từ thanh toán" % (tk or "?")


def _thu_tien(S, hd, tong, qua_nh_bat_buoc):
    tk = hd["tk"]
    if tk.startswith(("111", "112", "113")):
        if qua_nh_bat_buoc and tk.startswith("111"):
            return THIEU, "thu TIỀN MẶT - xuất khẩu phải thanh toán qua ngân hàng"
        return CO, "thu tiền ngay trên chứng từ (TK %s)" % tk
    if S.pb_thu is None:
        S.pb_thu = S.phan_bo(True)
    r = S.pb_thu.get((hd["makh"], hd["mact"], hd["so"])) or {"nh": 0.0, "tm": 0.0, "cuoi": None}
    thu_nh, thu_tm, cuoi = r["nh"], r["tm"], r["cuoi"]
    if qua_nh_bat_buoc:
        if thu_nh >= tong * 0.98:
            return CO, "đã thu qua ngân hàng (đến %s, phân bổ theo thứ tự ngày)" % vn(cuoi)
        if thu_tm >= tong * 0.98 and thu_nh == 0:
            return THIEU, "thu TIỀN MẶT %s - xuất khẩu phải thanh toán qua ngân hàng" % tien(thu_tm)
        return CHO, "chưa thấy thu đủ qua ngân hàng (%s / %s) - xuất khẩu phải thu qua ngân hàng" % (tien(thu_nh), tien(tong))
    if thu_nh + thu_tm >= tong * 0.98:
        return CO, "đã thu %s (phân bổ theo thứ tự ngày)" % tien(thu_nh + thu_tm)
    if thu_nh + thu_tm > 0:
        return CHO, "mới thu %s / %s" % (tien(thu_nh + thu_tm), tien(tong))
    return CHO, "khách chưa trả - theo dõi công nợ"


def _phieu_nhap(S, hd, loai=""):
    c = S.ct.get(hd["mact"])
    if c and c["loai"] == 1 and any(d["vt"] > 0 for d in c["dong"]):
        return CO, "phiếu nhập kho %s (cùng chứng từ)" % c["sh"]
    if loai == "CCDC" and c and not any(d["vt"] > 0 for d in c["dong"]):
        return KAD, "chi phí trả trước / CCDC không qua kho"
    for x in S.pnk_kh.get(hd["makh"], []):
        if hd["ngay"] and abs((x["ngay"] - hd["ngay"]).days) <= 3:
            return CO, "phiếu nhập kho %s ngày %s" % (x["sh"], vn(x["ngay"]))
    return THIEU, "chưa có phiếu nhập kho (chứng từ nhập vật tư) cho hoá đơn"


def _phieu_xuat(S, hd):
    c = S.ct.get(hd["mact"])
    if not c:
        return TU_KHAI, "không thấy chứng từ"
    if any(d["co"].startswith(("155", "156", "157", "152")) and d["vt"] > 0 for d in c["dong"]):
        return CO, "phiếu xuất kho / giá vốn trên chứng từ %s" % c["sh"]
    if any(d["vt"] > 0 for d in c["dong"]):
        return THIEU, "bán hàng hoá nhưng chứng từ chưa có dòng giá vốn / phiếu xuất kho"
    return KAD, "dịch vụ - không xuất kho"


def _dau_cua(S, khoa):
    d = S.dau.get(khoa)
    if not d:
        return None
    if d[0] == "KHONG":
        return KAD, "người dùng: không áp dụng" + (" - " + d[1] if d[1] else "")
    return CO, "người dùng xác nhận đã có ngoài sổ" + (" - " + d[1] if d[1] else "")


def kiem_hoa_don(S, hd, loai, tong_cung_ngay=0.0):
    tong = hd["gt"] + hd["thue"]
    ma_gd = "%s|%s|%s" % (loai, hd["mact"], hd["so"])
    muc = []
    for ma, ten, kieu, yc in BO_CT[loai]:
        khoa = ma_gd + "|" + ma
        d = _dau_cua(S, khoa)
        if d:
            tt, gc = d
        elif kieu == "HD":
            tt, gc = CO, "số %s ký hiệu %s ngày %s - chứng từ %s" % (hd["so"], hd["kh"], vn(hd["ngay"]), hd["sh"])
        elif kieu == "HDDT":
            h = S.hddt_kt.get(hd["mact"]) or S.hddt_so.get((hd["so"].lstrip("0"), hd["mst"]))
            if h:
                tt, gc = CO, "đã tải hoá đơn điện tử (%s)" % h["ma"]
            elif S.co_hddt and hd["mst"]:
                tt, gc = THIEU, "chưa có bản điện tử trong hoá đơn đã tải - xin XML / PDF từ người bán hoặc tải lại"
            elif not hd["mst"]:
                tt, gc = TU_KHAI, "người bán không có MST (hoá đơn lẻ / giấy) - giữ bản giấy"
            else:
                tt, gc = TU_KHAI, "sổ chưa tải hoá đơn điện tử - tự kiểm"
        elif kieu in ("HOPDONG", "HOPDONG_BB"):
            g = _hop_dong(S, hd["makh"], hd["ngay"], hd["mact"])
            if g:
                tt, gc = CO, g
            elif kieu == "HOPDONG_BB":
                tt, gc = THIEU, "bắt buộc - chưa thấy hợp đồng gắn chứng từ / cùng đối tác"
            else:
                tt, gc = TU_KHAI, "không thấy hợp đồng trong sổ - xác nhận nếu có hợp đồng / đơn hàng giấy"
        elif kieu == "PNK":
            tt, gc = _phieu_nhap(S, hd, loai)
        elif kieu == "PXK":
            tt, gc = _phieu_xuat(S, hd)
        elif kieu == "TT":
            tt, gc = _thanh_toan(S, hd, tong, False, tong_cung_ngay)
        elif kieu == "THU":
            tt, gc = _thu_tien(S, hd, tong, False)
        elif kieu == "THU_NH":
            tt, gc = _thu_tien(S, hd, tong, True)
        elif kieu == "THE_TS":
            tt, gc = (CO, "đã có thẻ TSCĐ gắn chứng từ") if hd["mact"] in S.ts_ct else (THIEU, "chưa ghi tăng TSCĐ (màn hình Nhập tăng TS) cho chứng từ này")
        elif kieu == "THE_CC":
            tt, gc = (CO, "đã có thẻ CCDC / 242 gắn chứng từ") if hd["mact"] in S.cc_ct else (THIEU, "chưa ghi thẻ CCDC / chi phí trả trước để phân bổ")
        else:
            tt, gc = TU_KHAI, "phần mềm không kiểm được từ sổ - tích Đã có ngoài sổ khi đã tập hợp"
        muc.append({"ma": ma, "ten": ten, "tt": tt, "gc": gc, "khoa": khoa, "yc": yc})
    return {"loai": loai, "ma_gd": ma_gd, "mact": hd["mact"], "so_hd": hd["so"], "ngay": hd["ngay"], "makh": hd["makh"], "mst": hd["mst"],
            "doi_tac": hd["ten"] or S.ten_dt(hd["makh"]), "tien": tong, "muc": muc, "sh": hd["sh"]}


def kiem_luong(S):
    ra = []
    if S.nv <= 0 and not S.bl:
        return ra
    for m in S.thang_ky():
        ma_gd = "LUONG|%d" % m
        muc = []
        for ma, ten, kieu, yc in BO_CT["LUONG"]:
            khoa = ma_gd + "|" + ma
            d = _dau_cua(S, khoa)
            if d:
                tt, gc = d
            elif kieu == "BL":
                tt, gc = (CO, "bảng lương tháng %d đã có" % m) if m in S.bl else (THIEU, "chưa có bảng lương tháng %d (Bảng lương trên màn hình AI)" % m)
            elif kieu == "CHILUONG":
                co = any(x["ngay"] and x["ngay"].month in (m, m % 12 + 1) and d2["no"].startswith("334") and d2["co"].startswith(("111", "112"))
                         for x in S.ct.values() for d2 in x["dong"])
                tt, gc = (CO, "có chứng từ chi lương") if co else ((THIEU, "chưa thấy chứng từ chi lương (Nợ 334 / Có 111, 112)") if m in S.bl else (CHO, "chưa có bảng lương"))
            elif kieu == "BHXH":
                co = any(x["ngay"] and x["ngay"].month in (m, m % 12 + 1) and d2["no"].startswith("338") and d2["co"].startswith(("111", "112"))
                         for x in S.ct.values() for d2 in x["dong"])
                tt, gc = (CO, "có chứng từ nộp BHXH") if co else (TU_KHAI, "chưa thấy nộp BHXH tháng %d - xác nhận nếu không có lao động tham gia" % m)
            else:
                tt, gc = TU_KHAI, "phần mềm không kiểm được từ sổ - tích Đã có ngoài sổ khi đã tập hợp"
            muc.append({"ma": ma, "ten": ten, "tt": tt, "gc": gc, "khoa": khoa, "yc": yc})
        ra.append({"loai": "LUONG", "ma_gd": ma_gd, "mact": 0, "so_hd": "tháng %d" % m, "ngay": None, "makh": 0, "mst": "",
                   "doi_tac": "Người lao động", "tien": 0.0, "muc": muc, "sh": ""})
    return ra


def kiem_vay(S):
    ra = []
    for c in S.ct.values():
        if not c["ngay"] or c["ngay"] < S.tu or c["ngay"] > S.den:
            continue
        gn = [d for d in c["dong"] if d["co"].startswith("341") and d["no"].startswith(("111", "112", "331"))]
        if not gn:
            continue
        tong = sum(d["ps"] for d in gn)
        makh = next((d["kh"] for d in gn if d["kh"] > 0), 0)
        ma_gd = "VAY|%d|%s" % (c["ma"], c["sh"])
        muc = []
        for ma, ten, kieu, yc in BO_CT["VAY"]:
            khoa = ma_gd + "|" + ma
            d = _dau_cua(S, khoa)
            if d:
                tt, gc = d
            elif kieu == "HOPDONG_BB":
                g = _hop_dong(S, makh, c["ngay"], c["ma"])
                tt, gc = (CO, g) if g else (THIEU, "bắt buộc - chưa thấy hợp đồng vay gắn chứng từ / cùng đối tác")
            elif kieu == "HD":
                tt, gc = CO, "chứng từ %s ngày %s (TK %s)" % (c["sh"], vn(c["ngay"]), gn[0]["no"])
            else:
                tt, gc = TU_KHAI, "phần mềm không kiểm được từ sổ"
            muc.append({"ma": ma, "ten": ten, "tt": tt, "gc": gc, "khoa": khoa, "yc": yc})
        ra.append({"loai": "VAY", "ma_gd": ma_gd, "mact": c["ma"], "so_hd": c["sh"], "ngay": c["ngay"], "makh": makh, "mst": S.mst_dt(makh),
                   "doi_tac": S.ten_dt(makh) or "Bên cho vay", "tien": tong, "muc": muc, "sh": c["sh"]})
    return ra


def muc_gd(gd):
    tts = [m["tt"] for m in gd["muc"]]
    if THIEU in tts:
        return THIEU
    if CHO in tts:
        return CHO
    return "DU"


def lap(S):
    """-> danh sach giao dich (moi giao dich: loai, ma_gd, ..., muc [...], ket)."""
    ds = []
    cung_ngay = defaultdict(float)             # (nguoi ban, ngay) -> tong cac hoa don mua cung ngay (gop khi xet moc khong dung tien mat)
    for hd in S.hdm:
        if hd["ngay"]:
            cung_ngay[(hd["makh"], hd["ngay"])] += hd["gt"] + hd["thue"]
    for hd in S.hdm:
        ds.append(kiem_hoa_don(S, hd, loai_hd_mua(S, hd), cung_ngay.get((hd["makh"], hd["ngay"]), 0.0)))
    for hd in S.hdb:
        ds.append(kiem_hoa_don(S, hd, loai_hd_ban(S, hd)))
    ds.extend(kiem_luong(S))
    ds.extend(kiem_vay(S))
    for gd in ds:
        gd["ket"] = muc_gd(gd)
        gd["thieu"] = [m["ten"] for m in gd["muc"] if m["tt"] == THIEU]
        gd["cho"] = [m["ten"] for m in gd["muc"] if m["tt"] == CHO]
        gd["tu_khai"] = [m["ten"] for m in gd["muc"] if m["tt"] == TU_KHAI]
    ds.sort(key=lambda g: (0 if g["ket"] == THIEU else (1 if g["ket"] == CHO else 2), -g["tien"]))
    return ds


def tong_hop(ds):
    th = OrderedDict()
    for loai in TEN_LOAI:
        g = [x for x in ds if x["loai"] == loai]
        if g:
            th[loai] = {"ten": TEN_LOAI[loai], "n": len(g), "du": sum(1 for x in g if x["ket"] == "DU"), "thieu": sum(1 for x in g if x["ket"] == THIEU),
                        "cho": sum(1 for x in g if x["ket"] == CHO)}
    return th


# ============================================================ thu yeu cau chung tu (F1)
def noi_dung_yeu_cau(S, ds):
    """-> [(nhom, noi dung)] - thu gon theo doi tac / thang; chi cac muc THIEU + TU_KHAI (chua danh dau)."""
    ra = []
    luong_tk = OrderedDict()
    for gd in ds:
        if gd["loai"] == "LUONG":
            for m in gd["muc"]:
                if m["tt"] == THIEU:
                    ra.append(("Tiền lương", "%s %s" % (m["ten"], gd["so_hd"])))
                elif m["tt"] == TU_KHAI and m.get("yc"):
                    luong_tk.setdefault(m["ten"], []).append(gd["so_hd"].replace("tháng ", ""))
            continue
        th = [m for m in gd["muc"] if m["tt"] == THIEU and m["ma"] not in ("THE_TS", "THE_CC", "PXK", "PNK")]
        tk = [m for m in gd["muc"] if m["tt"] == TU_KHAI and m.get("yc") and not (m["ma"] == "HDDT" and not gd["mst"])]
        if not th and not tk:
            continue
        dau = "%s - %s số %s ngày %s%s (%s đ)" % (TEN_LOAI.get(gd["loai"], gd["loai"]), "hoá đơn" if gd["loai"] != "VAY" else "chứng từ",
                                                 gd["so_hd"], vn(gd["ngay"]), (" - " + gd["doi_tac"]) if gd["doi_tac"] else "", tien(gd["tien"]))
        chi = ["THIẾU: " + m["ten"] + (" (%s)" % m["gc"] if m["ma"] == "TT" else "") for m in th] + ["nếu có: " + m["ten"] for m in tk]
        ra.append((gd["doi_tac"] or TEN_LOAI.get(gd["loai"], gd["loai"]), dau + " -> " + "; ".join(chi)))
    tt_thang = {str(m): i for i, m in enumerate(S.thang_ky())}
    for ten, ths in luong_tk.items():
        ra.append(("Tiền lương", "%s các tháng %s (nếu chưa gửi)" % (ten, ", ".join(sorted(ths, key=lambda x: tt_thang.get(x, 99))))))
    # so phu / hoa don dien tu thang chua co
    thang = S.thang_ky()
    co_112 = set()
    for c in S.ct.values():
        if c["ngay"] and any(d["no"].startswith("112") or d["co"].startswith("112") for d in c["dong"]):
            co_112.add(c["ngay"].month)
    for m in thang:
        if m in co_112 and S.sp_thang and S.sp_thang.get(m, 0) == 0:
            ra.append(("Sổ phụ ngân hàng", "Sổ phụ / sao kê ngân hàng tháng %d (sổ đã có phát sinh 112 nhưng chưa nhập sổ phụ)" % m))
    return ra


def _ten_cty(S):
    return S.cty.get("ten") or "Quý công ty"


def lap_thu(S, ds, thu_muc_ra):
    """-> (html, txt) duong tep da ghi ('' neu khong co gi de yeu cau)."""
    yc = noi_dung_yeu_cau(S, ds)
    nhom = OrderedDict()
    for n, nd in yc:
        nhom.setdefault(n, []).append(nd)
    if not nhom:
        return "", "", yc
    os.makedirs(thu_muc_ra, exist_ok=True)
    ten_goc = "YEU_CAU_CHUNG_TU_%s_%s_%s" % (S.tu.strftime("%Y%m%d"), S.den.strftime("%Y%m%d"), datetime.datetime.now().strftime("%H%M%S"))
    ky = "%s - %s" % (vn(S.tu), vn(S.den))
    den = S.thu_muc_khach and os.path.join(S.thu_muc_khach, "den") or "(thư mục nhận chứng từ)"
    kt = S.nguoi_ky.get("ke_toan_truong") or S.nguoi_ky.get("nguoi_lap") or S.nguoi_ky.get("ke_toan") or ""
    # TXT (Zalo / email)
    d = ["YÊU CẦU BỔ SUNG CHỨNG TỪ KỲ %s" % ky, "Kính gửi: %s" % _ten_cty(S), "",
         "Để hoàn thiện hồ sơ kế toán - thuế kỳ %s, kế toán cần quý công ty bổ sung các chứng từ sau:" % ky, ""]
    i = 0
    for n, lst in nhom.items():
        d.append("* %s:" % n)
        for nd in lst:
            i += 1
            d.append("  %d. %s" % (i, nd))
        d.append("")
    d += ["Cách gửi: chụp ảnh / scan hoặc gửi tệp (XML, PDF, Excel) qua Zalo / email, hoặc chép vào thư mục nhận chứng từ:",
          "  %s" % den, "  (hoadon = hoá đơn XML / PDF; sophu = sao kê ngân hàng; luong = bảng lương, chấm công, HĐLĐ; khac = hợp đồng, biên bản, tờ khai)",
          "", "Xin gửi trước ngày %s để kịp kỳ kê khai. Cảm ơn quý công ty." % vn(S.hom_nay + datetime.timedelta(days=7)),
          ("Kế toán phụ trách: %s" % kt) if kt else "Kế toán phụ trách: ..................", "(Nội dung lập bởi UNESCO AI - GĐ174; kế toán sửa trước khi gửi)"]
    txt = os.path.join(thu_muc_ra, ten_goc + ".txt")
    with io.open(txt, "w", encoding="utf-8-sig", newline="\r\n") as f:
        f.write("\n".join(d) + "\n")
    # HTML
    h = ["<!DOCTYPE html><html lang='vi'><head><meta charset='utf-8'><title>Yêu cầu bổ sung chứng từ</title>",
         "<style>body{font-family:Times New Roman,serif;font-size:13pt;max-width:900px;margin:30px auto;color:#222}h2{text-align:center;color:#1a4e8a}",
         "h3{margin:18px 0 6px;color:#444}ol{margin:4px 0 8px 24px}li{margin:3px 0}.k{background:#f3f6fb;border:1px solid #cfd8e6;padding:10px 14px;border-radius:6px}",
         "table{border-collapse:collapse;width:100%}td,th{border:1px solid #bbb;padding:5px 8px;vertical-align:top}th{background:#e8eef7}.n{font-size:10.5pt;color:#666}</style></head><body>",
         "<h2>YÊU CẦU BỔ SUNG CHỨNG TỪ<br><span style='font-size:12pt'>kỳ %s</span></h2>" % ky,
         "<p>Kính gửi: <b>%s</b>%s</p>" % (_ten_cty(S), (" (MST %s)" % S.cty.get("mst")) if S.cty.get("mst") else ""),
         "<p>Để hoàn thiện hồ sơ kế toán - thuế kỳ %s, kế toán cần quý công ty bổ sung các chứng từ sau:</p>" % ky]
    i = 0
    for n, lst in nhom.items():
        h.append("<h3>%s</h3><table><tr><th style='width:40px'>STT</th><th>Chứng từ cần bổ sung</th><th style='width:90px'>Đã gửi</th></tr>" % n)
        for nd in lst:
            i += 1
            h.append("<tr><td>%d</td><td>%s</td><td>&#9744;</td></tr>" % (i, nd.replace("<", "&lt;")))
        h.append("</table>")
    h += ["<div class='k'><b>Cách gửi:</b> chụp ảnh / scan hoặc gửi tệp (XML, PDF, Excel) qua Zalo / email, hoặc chép vào thư mục nhận chứng từ: "
          "<code>%s</code><br><span class='n'>hoadon = hoá đơn XML / PDF &middot; sophu = sao kê ngân hàng &middot; luong = bảng lương, chấm công, HĐLĐ &middot; khac = hợp đồng, biên bản, tờ khai</span></div>" % den,
          "<p>Xin gửi trước ngày <b>%s</b> để kịp kỳ kê khai. Cảm ơn quý công ty.</p>" % vn(S.hom_nay + datetime.timedelta(days=7)),
          "<p style='text-align:right'>Kế toán phụ trách: <b>%s</b></p>" % (kt or "...................."),
          "<p class='n'>Nội dung lập bởi UNESCO AI (GĐ174) từ số liệu sổ; kế toán sửa trước khi gửi. Phần mềm không tự gửi.</p></body></html>"]
    html = os.path.join(thu_muc_ra, ten_goc + ".html")
    with io.open(html, "w", encoding="utf-8") as f:
        f.write("\n".join(h))
    return html, txt, yc


THU_MUC_DEN = ("hoadon", "sophu", "luong", "khac")
TEP_DA_BIET = "_da_biet.json"
HUONG_DAN_DEN = """THU MUC NHAN CHUNG TU TU KHACH (UNESCO AI - GD174)
  hoadon\\  : hoa don XML / ZIP / PDF nguoi ban gui (phan mem doc XML / ZIP bang nut Nhap XML tren man hinh AI)
  sophu\\   : sao ke / so phu ngan hang (Excel, CSV, PDF, anh) - Import so phu AI
  luong\\   : bang luong, bang cham cong, hop dong lao dong
  khac\\    : hop dong, bien ban, to khai, giay to khac
Khong xoa tep cua khach; phan mem chi ghi moc tep da xem (_da_biet.json).
"""


def tao_thu_muc_den(thu_muc_khach):
    if not thu_muc_khach:
        return ""
    den = os.path.join(thu_muc_khach, "den")
    for t in THU_MUC_DEN:
        os.makedirs(os.path.join(den, t), exist_ok=True)
    p = os.path.join(den, "HUONG_DAN_GUI_CHUNG_TU.txt")
    if not os.path.isfile(p):
        with io.open(p, "w", encoding="utf-8-sig", newline="\r\n") as f:
            f.write(HUONG_DAN_DEN)
    return den


def nhan_chung_tu(den, da_xem=False, duong_ra=""):
    """Quet tep moi / doi trong <den>\\ so voi moc _da_biet.json -> tep ';' cho VB: TONG;n_moi;n_tong;hoadon;sophu;luong;khac | F;nhom;tep;kB;ngay.
    da_xem: ghi moc = hien trang (lan sau khong bao lai). Khong xoa / doi tep cua khach."""
    den = den or ""
    if den and not os.path.isdir(den):
        os.makedirs(den, exist_ok=True)
    if den:
        tao_thu_muc_den(os.path.dirname(den))
    p_db = os.path.join(den, TEP_DA_BIET) if den else ""
    cu = {}
    if p_db and os.path.isfile(p_db):
        try:
            with io.open(p_db, "r", encoding="utf-8-sig") as f:
                cu = json.load(f).get("tep") or {}
        except Exception:
            cu = {}
    hien = {}
    if den:
        for r, _d, fs in os.walk(den):
            for fn in fs:
                if fn == TEP_DA_BIET or fn.upper().startswith("HUONG_DAN"):
                    continue
                p = os.path.join(r, fn)
                rel = os.path.relpath(p, den).replace("\\", "/")
                try:
                    st = os.stat(p)
                except OSError:
                    continue
                hien[rel] = [int(st.st_size), int(st.st_mtime)]
    moi = [(rel, v) for rel, v in sorted(hien.items()) if cu.get(rel) != v]
    dem = {t: 0 for t in THU_MUC_DEN}
    dem["khac"] = 0
    d = []
    for rel, v in moi:
        nhom = rel.split("/")[0].lower() if "/" in rel else "khac"
        if nhom not in dem:
            nhom = "khac"
        dem[nhom] += 1
        d.append("F;%s;%s;%d;%s" % (nhom, _chu(rel), (v[0] + 1023) // 1024, datetime.datetime.fromtimestamp(v[1]).strftime("%d/%m/%Y %H:%M")))
    d.insert(0, "TONG;%d;%d;%d;%d;%d;%d;%s" % (len(moi), len(hien), dem["hoadon"], dem["sophu"], dem["luong"], dem["khac"], _chu(den)))
    if da_xem and p_db:
        with io.open(p_db + ".tmp", "w", encoding="utf-8") as f:
            json.dump({"ngay": datetime.datetime.now().strftime("%d/%m/%Y %H:%M"), "tep": hien}, f, ensure_ascii=False)
        os.replace(p_db + ".tmp", p_db)
    if duong_ra:
        os.makedirs(os.path.dirname(os.path.abspath(duong_ra)), exist_ok=True)
        with io.open(duong_ra, "w", encoding="utf-8-sig", newline="\r\n") as f:
            f.write("\n".join(d) + "\n")
    return d


# ============================================================ ghi ket qua
def ghi_txt(S, ds, duong, xlsx="", html="", txt="", yc=()):
    th = tong_hop(ds)
    n_tk = sum(1 for g in ds for m in g["muc"] if m["tt"] == TU_KHAI)
    d = ["TONG;174;%d;%d;%d;%d;%d;%s;%s;%s" % (len(ds), sum(1 for g in ds if g["ket"] == "DU"), sum(1 for g in ds if g["ket"] == THIEU),
                                               sum(1 for g in ds if g["ket"] == CHO), n_tk, _chu(xlsx), _chu(html), _chu(txt))]
    for loai, t in th.items():
        d.append("NV;%s;%s;%d;%d;%d;%d" % (loai, t["ten"], t["n"], t["du"], t["thieu"], t["cho"]))
    for g in ds:
        d.append("T;%s;%s;%d;%s;%s;%d;%s;%s;%s;%s;%s;%s;%s" % (g["loai"], g["ma_gd"], g["mact"], _chu(g["so_hd"], 60), vn(g["ngay"]), g["makh"], _chu(g["mst"], 20),
                                                        _chu(g["doi_tac"], 120), tien(g["tien"]), g["ket"], _chu(", ".join(g["thieu"])), _chu(", ".join(g["cho"])),
                                                        _chu(", ".join(g["tu_khai"]))))
        for m in g["muc"]:
            if m["tt"] in (THIEU, TU_KHAI, CHO):
                d.append("M;%s;%s;%s;%s" % (m["khoa"], _chu("%s - %s %s: %s" % (TEN_LOAI.get(g["loai"], g["loai"]), g["so_hd"], g["doi_tac"], m["ten"]), 200), m["tt"], _chu(m["gc"], 200)))
    for n, nd in yc:
        d.append("YC;%s;%s" % (_chu(n, 80), _chu(nd, 400)))
    os.makedirs(os.path.dirname(os.path.abspath(duong)), exist_ok=True)
    with io.open(duong, "w", encoding="utf-8-sig", newline="\r\n") as f:
        f.write("\n".join(d) + "\n")
    return duong


def ghi_excel(S, ds, duong, yc=()):
    try:
        from xlsx_viet import SoExcel
    except Exception:
        return ""
    wb = SoExcel(font="Times New Roman", co=11)
    k_td = wb.kieu(dam=True, co=13)
    k_dau = wb.kieu(dam=True, co=10, can="giua", xuong=True, khung=True, nen="D9E1F2")
    k_o = wb.kieu(khung=True, co=10, xuong=True)
    k_tien = wb.kieu(khung=True, co=10, so="#,##0")
    k_mau = {CO: wb.kieu(khung=True, co=10, nen="E2F0D9"), THIEU: wb.kieu(khung=True, co=10, nen="F8CBAD"), CHO: wb.kieu(khung=True, co=10, nen="FFF2CC"),
             TU_KHAI: wb.kieu(khung=True, co=10, nen="EDEDED"), KAD: wb.kieu(khung=True, co=10, nen="FFFFFF"), "DU": wb.kieu(khung=True, co=10, nen="E2F0D9")}
    ky = "%s - %s" % (vn(S.tu), vn(S.den))
    th = tong_hop(ds)
    ws = wb.sheet("Tong hop", [34, 12, 12, 12, 12])
    ws.gop(1, 1, 1, 5, "HỒ SƠ KÈM CHỨNG TỪ - TỔNG HỢP kỳ %s (%s)" % (ky, S.cty.get("ten", "")), k_td)
    ws.gop(2, 1, 2, 5, "Mỗi nghiệp vụ một bộ chứng từ; THIẾU = phải có mà sổ không thấy; Chờ = chưa phát sinh (chưa trả / chưa thu); Tự khai = phần mềm không kiểm được - tích Đã có ngoài sổ.", wb.kieu(nghieng=True, co=10))
    for c, t in enumerate(("Nghiệp vụ", "Số giao dịch", "Đủ", "Thiếu", "Chờ"), 1):
        ws.o(4, c, t, k_dau)
    r = 5
    for loai, t in th.items():
        for c, v in enumerate((t["ten"], t["n"], t["du"], t["thieu"], t["cho"]), 1):
            ws.o(r, c, v, k_mau[THIEU] if (c == 4 and v) else k_o)
        r += 1
    ws.o(r, 1, "Cộng", wb.kieu(dam=True, khung=True))
    for c, v in enumerate((len(ds), sum(1 for g in ds if g["ket"] == "DU"), sum(1 for g in ds if g["ket"] == THIEU), sum(1 for g in ds if g["ket"] == CHO)), 2):
        ws.o(r, c, v, wb.kieu(dam=True, khung=True))
    ws = wb.sheet("Chi tiet", [24, 14, 12, 34, 14, 36, 12, 60])
    for c, t in enumerate(("Nghiệp vụ", "Hoá đơn / CT", "Ngày", "Đối tác", "Tiền", "Chứng từ kèm theo", "Trạng thái", "Ghi chú (thấy gì trong sổ)"), 1):
        ws.o(1, c, t, k_dau)
    r = 2
    for g in ds:
        ws.gop(r, 1, r, 8, "%s - %s %s - %s - %s đ - %s" % (TEN_LOAI.get(g["loai"], g["loai"]), g["so_hd"], vn(g["ngay"]), g["doi_tac"], tien(g["tien"]),
                                                       {"DU": "ĐỦ", THIEU: "THIẾU", CHO: "CHỜ"}.get(g["ket"], g["ket"])), k_mau.get(g["ket"], k_o))
        r += 1
        for m in g["muc"]:
            for c, v, k in ((1, TEN_LOAI.get(g["loai"], g["loai"]), k_o), (2, g["so_hd"], k_o), (3, vn(g["ngay"]), k_o), (4, g["doi_tac"], k_o),
                            (5, g["tien"], k_tien), (6, m["ten"], k_o), (7, TEN_TT.get(m["tt"], m["tt"]), k_mau.get(m["tt"], k_o)), (8, m["gc"], k_o)):
                ws.o(r, c, v, k)
            r += 1
    ws = wb.sheet("Thieu", [24, 14, 12, 34, 14, 36, 12, 60])
    for c, t in enumerate(("Nghiệp vụ", "Hoá đơn / CT", "Ngày", "Đối tác", "Tiền", "Chứng từ", "Trạng thái", "Ghi chú"), 1):
        ws.o(1, c, t, k_dau)
    r = 2
    for g in ds:
        for m in g["muc"]:
            if m["tt"] in (THIEU, CHO, TU_KHAI):
                for c, v, k in ((1, TEN_LOAI.get(g["loai"], g["loai"]), k_o), (2, g["so_hd"], k_o), (3, vn(g["ngay"]), k_o), (4, g["doi_tac"], k_o),
                                (5, g["tien"], k_tien), (6, m["ten"], k_o), (7, TEN_TT.get(m["tt"], m["tt"]), k_mau.get(m["tt"], k_o)), (8, m["gc"], k_o)):
                    ws.o(r, c, v, k)
                r += 1
    ws = wb.sheet("Giai trinh", [6, 24, 16, 12, 34, 14, 70, 20])
    ws.gop(1, 1, 1, 8, "HỒ SƠ GIẢI TRÌNH CHỨNG TỪ kỳ %s - %s" % (ky, S.cty.get("ten", "")), k_td)
    ws.gop(2, 1, 2, 8, "Dùng khi thanh tra / kiểm tra: mỗi dòng một nghiệp vụ, cột Bộ chứng từ liệt kê giấy tờ kèm theo (tích khi đã kẹp vào hồ sơ).", wb.kieu(nghieng=True, co=10))
    for c, t in enumerate(("STT", "Nghiệp vụ", "Hoá đơn / CT gốc", "Ngày", "Đối tác", "Tiền", "Bộ chứng từ kèm theo", "Ghi chú"), 1):
        ws.o(4, c, t, k_dau)
    r = 5
    for i, g in enumerate(ds, 1):
        bo = "; ".join("%s %s" % ("[x]" if m["tt"] == CO else ("[ ]" if m["tt"] in (THIEU, TU_KHAI, CHO) else "[-]"), m["ten"]) for m in g["muc"])
        for c, v, k in ((1, i, k_o), (2, TEN_LOAI.get(g["loai"], g["loai"]), k_o), (3, "%s (CT %s)" % (g["so_hd"], g["sh"]) if g["sh"] else g["so_hd"], k_o),
                        (4, vn(g["ngay"]), k_o), (5, g["doi_tac"], k_o), (6, g["tien"], k_tien), (7, bo, k_o),
                        (8, "THIẾU: " + ", ".join(g["thieu"]) if g["thieu"] else "", k_mau[THIEU] if g["thieu"] else k_o)):
            ws.o(r, c, v, k)
        r += 1
    ws = wb.sheet("Yeu cau khach", [24, 110])
    ws.gop(1, 1, 1, 2, "CHỨNG TỪ CẦN YÊU CẦU KHÁCH (%s) BỔ SUNG - kỳ %s" % (S.cty.get("ten", ""), ky), k_td)
    ws.o(3, 1, "Nhóm", k_dau)
    ws.o(3, 2, "Nội dung", k_dau)
    r = 4
    for n, nd in yc:
        ws.o(r, 1, n, k_o)
        ws.o(r, 2, nd, k_o)
        r += 1
    if r == 4:
        ws.o(r, 1, "(không có gì cần yêu cầu)", k_o)
    ws = wb.sheet("Can cu", [130])
    for i, chu in enumerate(CAN_CU, 1):
        ws.o(i, 1, chu, wb.kieu(dam=True) if i == 1 else wb.kieu(xuong=True))
    wb.luu(duong)
    return duong


# ============================================================ entry
def chay(duong_json, duong_ra="", ghi_log=None):
    """/hosoct:<json> /ra:<txt> -> tep txt (TONG;174;...). Excel + thu yeu cau ghi canh tep txt / thu muc khach."""
    log = ghi_log or (lambda s: None)
    with io.open(duong_json, "r", encoding="utf-8-sig") as f:
        dl = json.loads(f.read(), strict=False)
    S = SoLieu(dl)
    thu = os.path.dirname(os.path.abspath(duong_ra)) if duong_ra else os.path.join(GOC, "ket-qua")
    os.makedirs(thu, exist_ok=True)
    gio = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
    p = duong_ra or os.path.join(thu, "ho_so_chung_tu_%s.txt" % gio)
    ds = lap(S)
    thu_yc = os.path.join(S.thu_muc_khach, "ket-qua", "yeu-cau-chung-tu") if S.thu_muc_khach else os.path.join(thu, "yeu-cau-chung-tu")
    html, txt, yc = "", "", []
    try:
        html, txt, yc = lap_thu(S, ds, thu_yc)
        if S.thu_muc_khach:
            tao_thu_muc_den(S.thu_muc_khach)
    except Exception as e:
        log("[HO SO CT] thu yeu cau loi: %s" % e)
        yc = noi_dung_yeu_cau(S, ds)
    xlsx = ""
    try:
        xlsx = ghi_excel(S, ds, os.path.splitext(p)[0] + ".xlsx", yc)
    except Exception as e:
        log("[HO SO CT] Excel loi: %s" % e)
    ghi_txt(S, ds, p, xlsx, html, txt, yc)
    log("[HO SO CT] ky %s - %s: %d giao dich, %d thieu, %d cho, %d yeu cau" % (vn(S.tu), vn(S.den), len(ds), sum(1 for g in ds if g["ket"] == THIEU),
                                                                              sum(1 for g in ds if g["ket"] == CHO), len(yc)))
    return p
