# -*- coding: utf-8 -*-
"""GD156 - DU BAO DONG TIEN 4-13 TUAN (lo trinh C1) - chi doc, UOC TINH. JSON = BC_Json(dau nam TC .. hom nay, "CONGNO") cua VB6 (tk, ps,
doi_ung, kh_dau, cn_ct [tk, kh, ngay, no, co, so hieu, dien giai, han TT, TK doi ung], dt) + khoi "dt156": {hom_nay, so_tuan, lui_tra_ncc,
thu_qua_han_tuan, ky_gtgt}.
Cach tinh (moi tuan i = [hom nay + 7(i-1), hom nay + 7i - 1]):
  * So du tien dau = du cuoi TK 111 + 112 + 113 (den het thang hien tai theo so).
  * PHAI THU 131 con lai theo tung khoan (FIFO tung khach): ngay du kien thu = han TT tren chung tu; khong co han -> ngay chung tu + so ngay
    tra binh quan HOC TU LICH SU cua chinh khach do (it nhat 2 lan); khong co -> trung vi chung / 30 ngay. Khoan da QUA HAN / du dau nam
    khong ro ngay: KHONG tinh vao du bao co so (than trong) - liet ke rieng; kich ban "thu no qua han trong k tuan" chia deu.
  * PHAI TRA 331 con lai tuong tu (thoi quen tra NCC hoc tu lich su); qua han <= 180 ngay -> tuan 1 (phai tra ngay); cu hon / du dau nam
    khong ro ngay -> liet ke rieng. Kich ban "lui tra NCC N ngay" doi moi ngay du kien tra.
  * Ban chiu / mua chiu MOI (binh quan 3 thang du lieu gan nhat No 131 / Co 331 theo thang) -> thu / tra sau so ngay binh quan.
  * Luong (No 334 / Co 11x), thue (No 333 / Co 11x), BHXH - KPCD (No 338 / Co 11x): so du Co hien tai cua 334 / 333x / 338x tra o han gan
    nhat (luong ngay 10, GTGT ngay 20 thang sau hoac cuoi thang dau quy sau, BHXH cuoi thang sau); cac thang sau = binh quan 3 thang.
  * Thu khac / chi khac bang tien (doi ung khong thuoc cong no, luong, thue, BHXH, vay, von, chuyen tien noi bo): binh quan 3 thang, chia deu.
Ket qua: Excel (Du bao, Phai thu, Phai tra, Thoi quen tra, Can cu) + HTML (bieu do so du cuoi tuan) + ket-qua\\dong_tien.txt cho VB6.
GD176: HTML thanh trang phan tich bang bieu do (the chi so + so du cuoi tuan + tien vao / tien ra theo tuan). Bo ve bieu do SVG dung chung
(bd_*) dat o day vi phan_tich_kd / thue_chu_dn deu da goi dong_tien: chi SVG + CSS noi tuyen, khong JavaScript, khong URL ngoai."""
import datetime as _dt
import html
import io
import json
import math
import os
import re
from collections import defaultdict

import bao_cao_bo_sung as BS
import kiem_khoa_so as K

HERE = os.path.dirname(os.path.abspath(__file__))
NGAY_MD = 30
QUA_HAN_CU = 180
DONG = ("Thu nợ phải thu (131) đến hạn", "Thu từ bán chịu mới (ước)", "Thu khác bằng tiền (bình quân)", "Thu nợ quá hạn (kịch bản)",
        "Trả nhà cung cấp (331) đến hạn", "Trả mua chịu mới (ước)", "Lương (334)", "Thuế (333)", "BHXH, KPCĐ (338)", "Chi khác bằng tiền (bình quân)")
VAO = DONG[:4]
RA = DONG[4:]


def _so(x):
    try:
        return float(x or 0)
    except (TypeError, ValueError):
        return 0.0


def _dd(x):
    return "{:,.0f}".format(x).replace(",", ".")


def _ngay(s):
    m = re.match(r"^\s*(\d{1,2})/(\d{1,2})/(\d{4})", str(s or ""))
    if not m:
        return None
    try:
        return _dt.date(int(m.group(3)), int(m.group(2)), int(m.group(1)))
    except ValueError:
        return None


def cuoi_thang(y, m):
    while m > 12:
        y, m = y + 1, m - 12
    while m < 1:
        y, m = y - 1, m + 12
    return (_dt.date(y, 12, 31) if m == 12 else _dt.date(y, m + 1, 1) - _dt.timedelta(days=1))


def ngay_trong_thang(y, m, d):
    c = cuoi_thang(y, m)
    return _dt.date(c.year, c.month, min(d, c.day))


def trung_vi(ds):
    ds = sorted(ds)
    if not ds:
        return None
    n = len(ds)
    return ds[n // 2] if n % 2 else (ds[n // 2 - 1] + ds[n // 2]) / 2.0


# ============================================================ FIFO cong no co han + hoc thoi quen
def fifo(S, ben_no, hom_nay):
    """-> ({kh: [khoan mo {ngay, con, sh, han}]}, {kh: [so ngay da tra (trong so tien)]}, {kh: tra thua})."""
    tt = "131" if ben_no else "331"
    la = {m for m in S.la if S.sh(m).startswith(tt)}
    dau = defaultdict(float)
    for r in S.dl.get("kh_dau") or []:
        m = int(_so(r[0]))
        if m in la:
            v = _so(r[2]) - _so(r[3])
            dau[int(_so(r[1]))] += v if ben_no else -v
    ct = defaultdict(list)
    for r in S.dl.get("cn_ct") or []:
        r = list(r) + [None] * (9 - len(r))
        m = int(_so(r[0]))
        if m not in la:
            continue
        ng = _ngay(r[2])
        if not ng or ng > hom_nay + _dt.timedelta(days=31):
            continue
        no, co = _so(r[3]), _so(r[4])
        tang, giam = (no, co) if ben_no else (co, no)
        ct[int(_so(r[1]))].append((ng, tang, giam, str(r[5] or ""), _ngay(r[7])))
    mo, hoc, thua = {}, defaultdict(list), {}
    for kh in set(dau) | set(ct):
        hd = []
        d0 = dau.get(kh, 0.0)
        if d0 > 0:
            hd.append({"ngay": None, "con": d0, "sh": "Dư đầu năm", "han": None})
        tra_thua = max(-d0, 0.0)
        for ng, tang, giam, sh, han in sorted(ct.get(kh, []), key=lambda x: x[0]):
            if tang > 0:
                if tra_thua > 0:
                    x = min(tra_thua, tang)
                    tra_thua -= x
                    tang -= x
                if tang > 0:
                    hd.append({"ngay": ng, "con": tang, "sh": sh, "han": han if han and han >= ng else None})
            if giam > 0:
                for h in hd:
                    if giam <= 0:
                        break
                    if h["con"] <= 0:
                        continue
                    x = min(h["con"], giam)
                    h["con"] -= x
                    giam -= x
                    if h["ngay"] is not None:
                        hoc[kh].append(((ng - h["ngay"]).days, x))
                if giam > 0:
                    tra_thua += giam
        mo[kh] = [h for h in hd if h["con"] > 0.5]
        thua[kh] = tra_thua
    return mo, hoc, thua


def so_ngay_tb(hoc_kh):
    """so ngay tra binh quan (trong so tien) cua mot doi tuong; None neu < 2 lan."""
    if len(hoc_kh) < 2:
        return None
    tong = sum(x for _, x in hoc_kh)
    if tong <= 0:
        return None
    return max(0, int(round(sum(d * x for d, x in hoc_kh) / tong)))


def du_kien(mo, hoc, hom_nay, ben_no, lui=0):
    """-> (danh sach khoan co ngay du kien, danh sach qua han / khong ro, thoi quen {kh: (ngay tb, so lan)}, so ngay chung)."""
    chung = trung_vi([so_ngay_tb(v) for v in hoc.values() if so_ngay_tb(v) is not None])
    chung = int(chung) if chung is not None else NGAY_MD
    thoi_quen = {kh: (so_ngay_tb(v), len(v)) for kh, v in hoc.items()}
    ok, qua = [], []
    for kh, ds in mo.items():
        tb = so_ngay_tb(hoc.get(kh, []))
        for h in ds:
            if h["ngay"] is None:
                qua.append(dict(h, kh=kh, du_kien=None, cach="dư đầu năm - không rõ ngày", qua_ngay=None))
                continue
            if h["han"]:
                d, cach = h["han"], "hạn thanh toán trên chứng từ"
            elif tb is not None:
                d, cach = h["ngay"] + _dt.timedelta(days=tb), "thói quen %d ngày (học %d lần)" % (tb, len(hoc[kh]))
            else:
                d, cach = h["ngay"] + _dt.timedelta(days=chung), "mặc định %d ngày" % chung
            if not ben_no and lui:
                d = d + _dt.timedelta(days=lui)
                cach += " + lùi %d ngày (kịch bản)" % lui
            if d < hom_nay:
                qua.append(dict(h, kh=kh, du_kien=d, cach=cach, qua_ngay=(hom_nay - d).days))
            else:
                ok.append(dict(h, kh=kh, du_kien=d, cach=cach))
    return ok, qua, thoi_quen, chung


# ============================================================ binh quan 3 thang tu doi ung
def binh_quan(S, hom_nay):
    """binh quan thang (3 thang du lieu gan nhat truoc thang hien tai) cua cac dong doi ung tien / cong no."""
    t_hien = K.thang_tc(hom_nay.month, S.dau_ky)
    ds_t = [t for t in range(max(1, t_hien - 3), t_hien) if t >= 1]
    if not ds_t:
        ds_t = [t_hien]
    n = float(len(ds_t))

    def tong(no, co, bo_no=(), bo_co=()):
        s = 0.0
        for (a, b), th in S.du.items():
            sa, sb = S.sh(a), S.sh(b)
            if any(sa.startswith(x) for x in no) and any(sb.startswith(x) for x in co):
                if any(sa.startswith(x) for x in bo_no) or any(sb.startswith(x) for x in bo_co):
                    continue
                s += sum(v for t, v in th.items() if t in ds_t)
        return s / n
    tien = ("111", "112", "113")
    noi_bo = tien + ("131", "331", "334", "333", "338", "341", "411", "113", "128", "121", "1281", "136", "336")
    return {"ban_chiu": tong(("131",), ("5", "711", "3331")), "mua_chiu": tong(("15", "6", "133", "2", "8", "242", "142"), ("331",)),
            "luong": tong(("334",), tien), "thue": tong(("333",), tien), "bhxh": tong(S.tk_bhxh(), tien),                                  # GD179: BHTN = 3385 (TT133) / 3386 (TT99)
            "thu_khac": tong(tien, ("5", "7", "3331", "711", "515", "1388", "141")),
            "chi_khac": tong(("6", "8", "15", "2", "242", "142", "133", "141", "1388", "811", "635", "642", "641", "627", "621", "622"), tien,
                             bo_no=noi_bo),
            "thang": ds_t}


# ============================================================ nghia vu tu so du
def han_gtgt(hom_nay, ky):
    """han nop GTGT gan nhat >= hom nay (thang: 20 thang sau; quy: cuoi thang dau quy sau)."""
    if ky == "T":
        d = ngay_trong_thang(hom_nay.year, hom_nay.month, 20)
        return d if d >= hom_nay else ngay_trong_thang(hom_nay.year, hom_nay.month + 1, 20)
    for i in range(0, 15):
        y, m = hom_nay.year + (hom_nay.month - 1 + i) // 12, (hom_nay.month - 1 + i) % 12 + 1
        if (m - 1) % 3 == 0:
            d = cuoi_thang(y, m)
            if d >= hom_nay:
                return d
    return hom_nay


def lap_lich(dl, hom_nay=None):
    S = BS.SoLieuBS(dl)
    cfg = dl.get("dt156") or {}
    hom_nay = _ngay(cfg.get("hom_nay")) or hom_nay or _dt.date.today()
    so_tuan = max(1, min(26, int(_so(cfg.get("so_tuan")) or 13)))
    lui = int(_so(cfg.get("lui_tra_ncc")))
    thu_qh = int(_so(cfg.get("thu_qua_han_tuan")))
    ky = str(cfg.get("ky_gtgt") or "Q").upper()
    het = hom_nay + _dt.timedelta(days=7 * so_tuan - 1)

    def tuan(d):
        if d is None or d < hom_nay or d > het:
            return None
        return (d - hom_nay).days // 7

    tien_dau = sum(S.du_cuoi(m) for m in S.la_theo("111", "112", "113"))
    bang = {k: [0.0] * so_tuan for k in DONG}
    # cong no
    mo_t, hoc_t, thua_t = fifo(S, True, hom_nay)
    mo_p, hoc_p, thua_p = fifo(S, False, hom_nay)
    thu_ok, thu_qua, tq_t, chung_t = du_kien(mo_t, hoc_t, hom_nay, True)
    tra_ok, tra_qua, tq_p, chung_p = du_kien(mo_p, hoc_p, hom_nay, False, lui)
    for h in thu_ok:
        w = tuan(h["du_kien"])
        if w is not None:
            bang[DONG[0]][w] += h["con"]
        h["tuan"] = w
    for h in tra_ok:
        w = tuan(h["du_kien"])
        if w is not None:
            bang[DONG[4]][w] += h["con"]
        h["tuan"] = w
    tra_ngay, tra_cu = [], []
    for h in tra_qua:
        if h["du_kien"] is not None and h["qua_ngay"] is not None and h["qua_ngay"] <= QUA_HAN_CU:
            bang[DONG[4]][0] += h["con"]
            h["tuan"] = 0
            tra_ngay.append(h)
        else:
            h["tuan"] = None
            tra_cu.append(h)
    tong_thu_qua = sum(h["con"] for h in thu_qua)
    if thu_qh > 0 and tong_thu_qua > 0:
        k = min(thu_qh, so_tuan)
        for w in range(k):
            bang[DONG[3]][w] += tong_thu_qua / k
    # binh quan
    bq = binh_quan(S, hom_nay)
    tuan_trong_thang = 52.0 / 12.0
    for w in range(so_tuan):
        bang[DONG[2]][w] += bq["thu_khac"] / tuan_trong_thang
        bang[DONG[9]][w] += bq["chi_khac"] / tuan_trong_thang
    # ban / mua chiu moi: phat sinh deu tu hom nay, thu / tra sau so ngay chung
    for w in range(so_tuan):
        d_ps = hom_nay + _dt.timedelta(days=7 * w)
        wt = tuan(d_ps + _dt.timedelta(days=chung_t))
        if wt is not None:
            bang[DONG[1]][wt] += bq["ban_chiu"] / tuan_trong_thang
        wp = tuan(d_ps + _dt.timedelta(days=chung_p + lui))
        if wp is not None:
            bang[DONG[5]][wp] += bq["mua_chiu"] / tuan_trong_thang
    # luong / thue / BHXH: so du Co hien tai -> han gan nhat; cac thang sau -> binh quan
    du_334 = -sum(S.du_cuoi(m) for m in S.la_theo("334"))
    du_333 = -sum(S.du_cuoi(m) for m in S.la_theo("333"))
    du_338 = -sum(S.du_cuoi(m) for m in S.la_theo(*S.tk_bhxh()))          # GD179: BHTN = 3385 (TT133) / 3386 (TT99)
    nghia_vu = []
    d_luong = ngay_trong_thang(hom_nay.year, hom_nay.month, 10)
    if d_luong < hom_nay:
        d_luong = ngay_trong_thang(hom_nay.year, hom_nay.month + 1, 10)
    d_thue = han_gtgt(hom_nay, ky)
    d_bh = cuoi_thang(hom_nay.year, hom_nay.month)
    for ten, du, d, dong in (("Lương còn phải trả (dư Có 334)", du_334, d_luong, DONG[6]), ("Thuế còn phải nộp (dư Có 333)", du_333, d_thue, DONG[7]),
                             ("BHXH, BHYT, BHTN, KPCĐ còn phải nộp (dư Có 338x)", du_338, d_bh, DONG[8])):
        if du > 0.5:
            w = tuan(d)
            if w is not None:
                bang[dong][w] += du
            nghia_vu.append((ten, d, du, "số dư hiện tại"))
    for i in range(1, 8):
        y, m = hom_nay.year + (hom_nay.month - 1 + i) // 12, (hom_nay.month - 1 + i) % 12 + 1
        for ten, v, d, dong in (("Lương tháng (bình quân)", bq["luong"], ngay_trong_thang(y, m, 10), DONG[6]),
                                ("Thuế (bình quân tháng)", bq["thue"], ngay_trong_thang(y, m, 20), DONG[7]),
                                ("BHXH, KPCĐ (bình quân tháng)", bq["bhxh"], cuoi_thang(y, m), DONG[8])):
            w = tuan(d)
            if w is not None and v > 0.5:
                bang[dong][w] += v
                nghia_vu.append((ten, d, v, "bình quân 3 tháng"))
    # tong hop
    vao = [sum(bang[k][w] for k in VAO) for w in range(so_tuan)]
    ra = [sum(bang[k][w] for k in RA) for w in range(so_tuan)]
    du = []
    s = tien_dau
    for w in range(so_tuan):
        s = s + vao[w] - ra[w]
        du.append(s)
    am = [w for w in range(so_tuan) if du[w] < 0]
    thap = min(range(so_tuan), key=lambda w: du[w]) if so_tuan else 0
    return {"S": S, "hom_nay": hom_nay, "so_tuan": so_tuan, "lui": lui, "thu_qh": thu_qh, "ky": ky, "tien_dau": tien_dau, "bang": bang,
            "vao": vao, "ra": ra, "du": du, "am": am, "thap": thap, "thu_ok": thu_ok, "thu_qua": thu_qua, "tra_ok": tra_ok, "tra_ngay": tra_ngay,
            "tra_cu": tra_cu, "tq_t": tq_t, "tq_p": tq_p, "chung_t": chung_t, "chung_p": chung_p, "bq": bq, "nghia_vu": nghia_vu,
            "tong_thu_qua": tong_thu_qua, "thua_t": sum(thua_t.values()), "thua_p": sum(thua_p.values())}


def ten_tuan(L, w):
    a = L["hom_nay"] + _dt.timedelta(days=7 * w)
    b = a + _dt.timedelta(days=6)
    return "T%d %s-%s" % (w + 1, a.strftime("%d/%m"), b.strftime("%d/%m"))


# ============================================================ ket qua
def ghi_ket_qua(L, ra=None):
    if ra is None:
        ra = os.path.join(HERE, "ket-qua", "dong_tien.txt")
    os.makedirs(os.path.dirname(ra), exist_ok=True)
    w_am = (L["am"][0] + 1) if L["am"] else 0
    dong = ["TONG;%d;%d;%d;%d;%d;%d;%d;%d" % (round(L["tien_dau"]), w_am, round(L["du"][L["thap"]]), L["thap"] + 1, round(L["tong_thu_qua"]),
                                             round(sum(h["con"] for h in L["tra_ngay"])), round(L["du"][-1]), L["so_tuan"])]
    for w in range(L["so_tuan"]):
        dong.append("W;%d;%s;%d;%d;%d" % (w + 1, ten_tuan(L, w).split(" ", 1)[1], round(L["vao"][w]), round(L["ra"][w]), round(L["du"][w])))
    with io.open(ra + ".tmp", "w", encoding="utf-8") as f:
        f.write("\n".join(dong) + "\n")
    os.replace(ra + ".tmp", ra)
    return ra


def lap_excel(dl, ra):
    import tool_htkk_unesco as X
    L = lap_lich(dl)
    S = L["S"]
    cty = dl.get("cty") or {}
    nt = L["so_tuan"]
    kb = []
    if L["lui"]:
        kb.append("lùi trả nhà cung cấp %d ngày" % L["lui"])
    if L["thu_qh"]:
        kb.append("thu hết nợ quá hạn trong %d tuần" % L["thu_qh"])
    T = [[("DỰ BÁO DÒNG TIỀN %d TUẦN TỪ %s - ƯỚC TÍNH TỪ SỔ KẾ TOÁN (CHỈ ĐỌC)" % (nt, L["hom_nay"].strftime("%d/%m/%Y")), X.X_TITLE)],
         [("Đơn vị: %s    MST: %s    Kịch bản: %s" % (cty.get("ten") or "", cty.get("mst") or "", ", ".join(kb) or "cơ sở (không thu nợ quá hạn, trả đúng thói quen)"),
           X.X_THUONG)],
         [(("CẢNH BÁO: số dư tiền ÂM từ tuần %d (%s) - thấp nhất %s ở tuần %d" % (L["am"][0] + 1, ten_tuan(L, L["am"][0]), _dd(L["du"][L["thap"]]), L["thap"] + 1))
           if L["am"] else ("Không tuần nào âm tiền; thấp nhất %s ở tuần %d" % (_dd(L["du"][L["thap"]]), L["thap"] + 1)), X.X_DAM)], [],
         [("Khoản mục", X.X_TIEUDE)] + [(ten_tuan(L, w), X.X_TIEUDE) for w in range(nt)] + [("Cộng", X.X_TIEUDE)]]
    T.append([("Số dư tiền đầu tuần", X.X_DAM)] + [((L["tien_dau"] if w == 0 else L["du"][w - 1]), X.X_SO) for w in range(nt)] + [("", X.X_CHU)])
    for k in DONG:
        if k == DONG[4]:
            T.append([("Cộng tiền vào", X.X_MUC)] + [(L["vao"][w], X.X_SOMUC) for w in range(nt)] + [(sum(L["vao"]), X.X_SOMUC)])
        T.append([(("  + " if k in VAO else "  - ") + k, X.X_CHU)] + [(L["bang"][k][w], X.X_SO) for w in range(nt)] + [(sum(L["bang"][k]), X.X_SO)])
    T.append([("Cộng tiền ra", X.X_MUC)] + [(L["ra"][w], X.X_SOMUC) for w in range(nt)] + [(sum(L["ra"]), X.X_SOMUC)])
    T.append([("Dòng tiền thuần", X.X_DAM)] + [(L["vao"][w] - L["ra"][w], X.X_SO) for w in range(nt)] + [(sum(L["vao"]) - sum(L["ra"]), X.X_SO)])
    T.append([("SỐ DƯ TIỀN CUỐI TUẦN", X.X_DAM)] + [(L["du"][w], X.X_DO if L["du"][w] < 0 else X.X_XANH) for w in range(nt)] + [("", X.X_CHU)])
    T.append([])
    T.append([("Số dư tiền đầu kỳ dự báo (111 + 112 + 113): %s. Nợ phải thu QUÁ HẠN chưa tính: %s. Nợ phải trả quá hạn đưa vào tuần 1: %s; nợ phải trả cũ "
               "(quá %d ngày / dư đầu năm) chưa tính: %s. Khách ứng trước: %s; trả trước NCC: %s." % (
                   _dd(L["tien_dau"]), _dd(L["tong_thu_qua"]), _dd(sum(h["con"] for h in L["tra_ngay"])), QUA_HAN_CU,
                   _dd(sum(h["con"] for h in L["tra_cu"])), _dd(L["thua_t"]), _dd(L["thua_p"])), X.X_GHICHU)])
    T.append([("Thói quen chung: khách trả sau %d ngày, công ty trả NCC sau %d ngày (trung vị học từ lịch sử năm). Bình quân tháng (tháng tài chính %s): bán chịu %s, "
               "mua chịu %s, lương %s, thuế %s, BHXH %s, thu khác %s, chi khác %s." % (
                   L["chung_t"], L["chung_p"], ", ".join(str(t) for t in L["bq"]["thang"]), _dd(L["bq"]["ban_chiu"]), _dd(L["bq"]["mua_chiu"]),
                   _dd(L["bq"]["luong"]), _dd(L["bq"]["thue"]), _dd(L["bq"]["bhxh"]), _dd(L["bq"]["thu_khac"]), _dd(L["bq"]["chi_khac"])), X.X_GHICHU)])
    T.append([("Đây là ƯỚC TÍNH từ số liệu đã ghi sổ; không thay kế hoạch tài chính. Doanh thu / mua hàng chưa phát sinh chỉ ước theo bình quân 3 tháng.", X.X_GHICHU)])
    sheets = [("Du bao", [40] + [15] * nt + [16], T, 5)]

    def bang_khoan(ds, tieu, la_thu):
        D = [[(tieu, X.X_TITLE)], [], [(c, X.X_TIEUDE) for c in ("Đối tượng", "MST", "Chứng từ", "Ngày", "Hạn TT", "Còn lại", "Ngày dự kiến", "Tuần", "Cách xác định")]]
        for h in sorted(ds, key=lambda h: (h.get("du_kien") or _dt.date(1900, 1, 1), -h["con"])):
            D.append([(S.ten_dt(h["kh"]), X.X_CHU), ((S.dt.get(h["kh"]) or ["", "", ""])[2], X.X_CHU), (h["sh"], X.X_CHU),
                      (h["ngay"].strftime("%d/%m/%Y") if h["ngay"] else "", X.X_CHU), (h["han"].strftime("%d/%m/%Y") if h["han"] else "", X.X_CHU),
                      (h["con"], X.X_SO), (h["du_kien"].strftime("%d/%m/%Y") if h.get("du_kien") else "", X.X_CHU),
                      (("T%d" % (h["tuan"] + 1)) if h.get("tuan") is not None else ("quá hạn %s ngày" % h["qua_ngay"] if h.get("qua_ngay") else "-"),
                       X.X_VANG if h.get("qua_ngay") else X.X_CHU), (h["cach"], X.X_CHU)])
        if len(D) == 3:
            D.append([("(không có)", X.X_CHU)])
        return D
    sheets.append(("Phai thu", [36, 14, 14, 11, 11, 16, 12, 16, 50], bang_khoan(L["thu_ok"] + L["thu_qua"], "PHẢI THU 131 CÒN LẠI - NGÀY DỰ KIẾN THU (quá hạn: không tính trong kịch bản cơ sở)", True), 3))
    sheets.append(("Phai tra", [36, 14, 14, 11, 11, 16, 12, 16, 50], bang_khoan(L["tra_ok"] + L["tra_ngay"] + L["tra_cu"], "PHẢI TRẢ 331 CÒN LẠI - NGÀY DỰ KIẾN TRẢ", False), 3))
    Q = [[("THÓI QUEN THANH TOÁN HỌC TỪ LỊCH SỬ (số ngày từ chứng từ phát sinh nợ đến khi thu / trả, bình quân theo số tiền)", X.X_TITLE)], [],
         [(c, X.X_TIEUDE) for c in ("Chiều", "Đối tượng", "MST", "Số ngày bình quân", "Số lần học")]]
    for chieu, tq in (("Khách trả (131)", L["tq_t"]), ("Trả NCC (331)", L["tq_p"])):
        for kh, (tb, n) in sorted(tq.items(), key=lambda kv: -(kv[1][1])):
            Q.append([(chieu, X.X_CHU), (S.ten_dt(kh), X.X_CHU), ((S.dt.get(kh) or ["", "", ""])[2], X.X_CHU), (tb if tb is not None else "", X.X_SO), (n, X.X_SO)])
    sheets.append(("Thoi quen tra", [16, 40, 14, 16, 12], Q, 3))
    N = [[("NGHĨA VỤ LƯƠNG, THUẾ, BHXH DỰ KIẾN", X.X_TITLE)], [], [(c, X.X_TIEUDE) for c in ("Khoản", "Ngày dự kiến", "Số tiền", "Căn cứ")]]
    for ten, d, v, cc in sorted(L["nghia_vu"], key=lambda x: x[1]):
        N.append([(ten, X.X_CHU), (d.strftime("%d/%m/%Y"), X.X_CHU), (v, X.X_SO), (cc, X.X_CHU)])
    if len(N) == 3:
        N.append([("(không có)", X.X_CHU)])
    N.append([])
    N.append([("Lương trả ngày 10; thuế: GTGT %s (tháng: ngày 20 tháng sau; quý: ngày cuối tháng đầu quý sau), các tháng sau ngày 20; BHXH, KPCĐ: ngày cuối tháng. "
               "Ngày nghỉ không dời (ước tính)." % ("theo tháng" if L["ky"] == "T" else "theo quý"), X.X_GHICHU)])
    sheets.append(("Nghia vu", [48, 14, 18, 20], N, 3))
    os.makedirs(os.path.dirname(os.path.abspath(ra)), exist_ok=True)
    X.viet_xlsx_o(ra, sheets)
    try:
        viet_html(L, dl, os.path.splitext(ra)[0] + ".html")
    except Exception:
        pass
    ghi_ket_qua(L)
    return ra, {"am": L["am"], "thap": L["du"][L["thap"]]}


# ============================================================ GD176 - BO VE BIEU DO SVG DUNG CHUNG
# Dung cho dong_tien, phan_tich_kd, thue_chu_dn (hai tep sau goi "import dong_tien" khi lap HTML). Chi SVG + CSS noi tuyen: khong JavaScript,
# khong URL ngoai, khong anh; in A4 duoc (SVG co viewBox, rong 100%). Cot / thanh moi ve bang <path> (dau du lieu bo tron 4 px, goc vuong o truc);
# <rect> chi con o cac bieu do cu (GD156 / 159 / 160 dem so <rect>). Moi chu deu qua html.escape; khong co so lieu -> "Không có số liệu.".
BD_XANH, BD_DO, BD_VANG, BD_XAM = "#2563eb", "#dc2626", "#f59e0b", "#9ca3af"
BD_XANH_NHAT = "#dbeafe"
BD_LUOI, BD_TRUC, BD_CHU, BD_MO = "#e5e7eb", "#9ca3af", "#1f2937", "#6b7280"
BD_RONG = "Không có số liệu."
BD_CSS = (".bd-kpi{display:grid;grid-template-columns:repeat(auto-fit,minmax(125px,1fr));gap:8px;margin:10px 0 4px}"
          ".bd-the{border:1px solid #e5e7eb;border-radius:8px;padding:7px 10px;background:#f9fafb}"
          ".bd-n{font-size:12px;color:#6b7280}.bd-v{font-size:17px;font-weight:600;color:#1f2937;margin-top:2px;overflow-wrap:anywhere}"
          ".bd-v.am{color:#b91c1c}.bd-p{font-size:11.5px;color:#6b7280;margin-top:1px}"
          ".bd{margin:4px 0 10px;break-inside:avoid;page-break-inside:avoid}"
          "h2.bd-t{font-size:16px;margin:14px 0 3px;color:#0b3d91;border:0}.bd-ghi{font-size:12px;color:#6b7280;margin:0 0 4px}"
          ".bd-rong{font-size:13px;color:#6b7280;font-style:italic;margin:2px 0 6px}"
          ".bd svg{display:block;width:100%;height:auto}"
          ".bd-cg{display:flex;flex-wrap:wrap;gap:2px 14px;font-size:12px;color:#374151;margin:0 0 2px}"
          ".bd-cg i{display:inline-block;width:10px;height:10px;border-radius:2px;margin-right:5px;vertical-align:-1px}"
          ".bd,.bd-kpi{-webkit-print-color-adjust:exact;print-color-adjust:exact}")
BD_IN = "@page{size:A4 portrait;margin:12mm}@media print{body{margin:0}.bd-kpi{break-inside:avoid}}"
BD_VIEN = "stroke='#fff' stroke-width='3' paint-order='stroke' stroke-linejoin='round'"     # vien trang cho chu nam tren vach / cot


def bd_e(s):
    return html.escape(str(s if s is not None else ""), quote=True)


def bd_cat(s, n):
    s = str(s or "")
    return s if len(s) <= n else s[:n - 1].rstrip() + "…"


def bd_gon(v):
    """so gon cho moc truc: 1,2 tỷ / 350 tr / 12 nghìn."""
    a = abs(v)
    for nguong, dv in ((1e9, " tỷ"), (1e6, " tr"), (1e3, " nghìn")):
        if a >= nguong:
            x = v / nguong
            s = ("%.1f" % x) if abs(x) < 10 and abs(x - round(x)) >= 0.05 else ("%.0f" % x)
            return s.replace(".", ",") + dv
    return "%.0f" % v


def bd_pt(v):
    return ("%.0f%%" % (v * 100)).replace(".", ",") if abs(v * 100 - round(v * 100)) < 0.05 else ("%.1f%%" % (v * 100)).replace(".", ",")


def bd_moc(lo, hi, n=4):
    """truc tron so: (dau, cuoi, [cac moc]) bao [lo, hi]."""
    if hi - lo <= 1e-12:
        hi = lo + (abs(lo) or 1.0)
    tho = (hi - lo) / float(n)
    mu = 10 ** math.floor(math.log10(tho))
    buoc = 10 * mu
    for m in (1, 2, 2.5, 5, 10):
        if m * mu >= tho - 1e-12:
            buoc = m * mu
            break
    a = math.floor(lo / buoc + 1e-9) * buoc
    b = math.ceil(hi / buoc - 1e-9) * buoc
    if b - a < 1e-12:
        b = a + buoc
    ds, i = [], 0
    while a + i * buoc <= b + buoc * 1e-6:
        ds.append(a + i * buoc)
        i += 1
    return a, b, ds


def bd_thanh(x0, x1, y, h, mau, tip, r=4.0):
    """thanh ngang tu truc x0 den dau du lieu x1 (bo tron), kem <title>."""
    w = abs(x1 - x0)
    if w < 1e-9:
        return ""
    if w < 1:
        x1 = x0 + (1 if x1 >= x0 else -1)
        w = 1
    r = min(r, h / 2.0, w)
    s = 1 if x1 >= x0 else -1
    d = "M%.1f %.1fH%.1fQ%.1f %.1f %.1f %.1fV%.1fQ%.1f %.1f %.1f %.1fH%.1fZ" % (
        x0, y, x1 - s * r, x1, y, x1, y + r, y + h - r, x1, y + h, x1 - s * r, y + h, x0)
    return "<path d='%s' fill='%s'><title>%s</title></path>" % (d, mau, bd_e(tip))


def bd_cot1(x, w, y0, y1, mau, tip, r=4.0):
    """cot dung tu truc y0 den dau du lieu y1 (bo tron), kem <title>."""
    h = abs(y1 - y0)
    if h < 1e-9:
        return ""
    if h < 1:
        y1 = y0 + (-1 if y1 < y0 else 1)
        h = 1
    r = min(r, w / 2.0, h)
    s = -1 if y1 < y0 else 1
    d = "M%.1f %.1fV%.1fQ%.1f %.1f %.1f %.1fH%.1fQ%.1f %.1f %.1f %.1fV%.1fZ" % (
        x, y0, y1 - s * r, x, y1, x + r, y1, x + w - r, x + w, y1, x + w, y1 - s * r, y0)
    return "<path d='%s' fill='%s'><title>%s</title></path>" % (d, mau, bd_e(tip))


def bd_svg(W, H, aria, noi, fs=12):
    return ("<svg viewBox='0 0 %d %d' width='%d' height='%d' style='max-width:%dpx' role='img' aria-label='%s' font-size='%s' fill='%s'>%s</svg>"
            % (W, H, W, H, W, bd_e(aria), fs, BD_CHU, "".join(noi)))


def bd_khung(tieu, than, ghi=None, chu_giai=None):
    h = ["<div class='bd'><h2 class='bd-t'>%s</h2>" % bd_e(tieu)]
    if ghi:
        h.append("<p class='bd-ghi'>%s</p>" % bd_e(ghi))
    if chu_giai:
        h.append("<div class='bd-cg'>%s</div>" % "".join("<span><i style='background:%s'></i>%s</span>" % (m, bd_e(t)) for t, m in chu_giai))
    h.append(than)
    h.append("</div>")
    return "".join(h)


def bd_rong(tieu, ly_do=None, ghi=None):
    return bd_khung(tieu, "<p class='bd-rong'>%s</p>" % bd_e(ly_do or BD_RONG), ghi)


def bd_an_toan(tieu, ham, *a, **k):
    """bieu do loi (so lieu la) khong lam hong ca trang."""
    try:
        return ham(*a, **k)
    except Exception as e:
        return bd_rong(tieu, "Chưa vẽ được biểu đồ (%s)." % type(e).__name__)


def bd_kpi(the):
    """hang the chi so: [(nhan, gia tri da dinh dang, ghi phu, am)]."""
    h = ["<div class='bd-kpi'>"]
    for x in the:
        nhan, gt, phu, am = (list(x) + [None, None])[:4]
        h.append("<div class='bd-the'><div class='bd-n'>%s</div><div class='bd-v%s'>%s</div>%s</div>" % (
            bd_e(nhan), " am" if am else "", bd_e(gt), ("<div class='bd-p'>%s</div>" % bd_e(phu)) if phu else ""))
    h.append("</div>")
    return "".join(h)


def _bd_luoi(noi, moc, trai, phai, Y, fs, fmt_truc):
    for t in moc:
        noi.append("<line x1='%.1f' y1='%.1f' x2='%.1f' y2='%.1f' stroke='%s' stroke-width='1'/>" % (trai, Y(t), phai, Y(t), BD_LUOI))
        noi.append("<text x='%.1f' y='%.1f' text-anchor='end' font-size='%s' fill='%s'>%s</text>" % (trai - 5, Y(t) + fs * 0.35, fs, BD_MO, bd_e(fmt_truc(t))))


def _bd_nhan_x(noi, nhan, trai, phai, H, fs):
    n = len(nhan)
    band = (phai - trai) / float(n)
    rong = fs * 0.6 * max(len(str(x)) for x in nhan) + 6
    buoc = max(1, int(math.ceil(rong / band)))
    for i in range(n):
        if i % buoc == 0:
            noi.append("<text x='%.1f' y='%.1f' text-anchor='middle' font-size='%s' fill='%s'>%s</text>"
                       % (trai + band * (i + 0.5), H - 5, fs, BD_MO, bd_e(nhan[i])))


def bd_ngang(tieu, ds, fmt, aria=None, ghi=None, chu_giai=None, W=760, nhan_w=230, moc=None, rong=None, so_chu=34):
    """thanh ngang, truc 0 that (am ve trai, mau do). ds: [{"nhan", "v", "mau"?, "nhan_v"?, "tip"?}]; moc = (gia tri, chu): vach doc tham chieu."""
    ds = [x for x in ds if x.get("v") is not None]
    if not ds or (moc is None and all(abs(x["v"]) < 1e-9 for x in ds)):
        return bd_rong(tieu, rong, ghi)
    hang, day, tren = 24, 14, 4
    H = tren + hang * len(ds) + (20 if moc else 4)
    vs = [x["v"] for x in ds] + ([moc[0]] if moc else [])
    lo, hi = min(vs + [0.0]), max(vs + [0.0])
    if hi - lo < 1e-9:
        hi = lo + 1.0
    nv = [x.get("nhan_v") or fmt(x["v"]) for x in ds]
    cho = min(300, max(60, int(6.4 * max(len(s) for s in nv)) + 14))
    trai = nhan_w + (cho if lo < 0 else 6)
    phai = W - (cho if hi > 0 else 6)

    def X(v):
        return trai + (v - lo) / (hi - lo) * (phai - trai)
    x0 = X(0.0)
    y_het = tren + hang * len(ds)
    noi = []
    if moc:                                          # vach tham chieu ve truoc: thanh va chu (vien trang) nam tren
        xm = X(moc[0])
        neo = "end" if xm > W - 120 else ("start" if xm < 120 else "middle")
        noi.append("<line x1='%.1f' y1='%d' x2='%.1f' y2='%d' stroke='%s' stroke-width='1'/>" % (xm, tren - 2, xm, y_het + 4, BD_MO))
        noi.append("<text x='%.1f' y='%d' text-anchor='%s' font-size='11' fill='%s'>%s</text>" % (xm, H - 4, neo, BD_MO, bd_e(moc[1])))
    vien = BD_VIEN
    for i, x in enumerate(ds):
        y = tren + i * hang + (hang - day) / 2.0
        yc = y + day / 2.0 + 4
        v = x["v"]
        mau = x.get("mau") or (BD_XANH if v >= 0 else BD_DO)
        tip = "%s: %s%s" % (x["nhan"], nv[i], (" - " + x["tip"]) if x.get("tip") else "")
        noi.append("<text x='%d' y='%.1f' text-anchor='end'>%s<title>%s</title></text>" % (nhan_w - 8, yc, bd_e(bd_cat(x["nhan"], so_chu)), bd_e(x["nhan"])))
        noi.append(bd_thanh(x0, X(v), y, day, mau, tip))
        if v >= 0:
            noi.append("<text x='%.1f' y='%.1f' font-size='11.5' %s>%s</text>" % (X(v) + 5, yc, vien, bd_e(nv[i])))
        else:
            noi.append("<text x='%.1f' y='%.1f' font-size='11.5' text-anchor='end' %s>%s</text>" % (X(v) - 5, yc, vien, bd_e(nv[i])))
    noi.append("<line x1='%.1f' y1='%d' x2='%.1f' y2='%d' stroke='%s' stroke-width='1'/>" % (x0, tren - 2, x0, y_het + 2, BD_TRUC))
    return bd_khung(tieu, bd_svg(W, H, aria or tieu, noi), ghi, chu_giai)


def bd_cot(tieu, nhan, chuoi, fmt, aria=None, ghi=None, W=760, H=220, fs=11, nhan_tip=None, rong=None, moc=None, chu_giai=True):
    """cot nhom theo nhan truc x (mot truc so). chuoi: [{"ten", "v": [..], "mau", "mau_am"?}]; moc = (gia tri, chu): vach ngang tham chieu."""
    n, k = len(nhan), len(chuoi)
    if not n or not k or all(abs(v or 0) < 1e-9 for c in chuoi for v in c["v"]):
        return bd_rong(tieu, rong, ghi)
    vs = [v or 0.0 for c in chuoi for v in c["v"]] + ([moc[0]] if moc else [])
    a, b, moc_truc = bd_moc(min(vs + [0.0]), max(vs + [0.0]), 4 if H >= 150 else 2)
    trai = 10 + fs * 4.8
    phai = W - (78 if moc else 6)
    tren, duoi = 8, H - fs - 9

    def Y(v):
        return duoi - (v - a) / (b - a) * (duoi - tren)
    noi = []
    _bd_luoi(noi, moc_truc, trai, phai, Y, fs, bd_gon)
    band = (phai - trai) / float(n)
    bw = max(2.0, min(24.0, (band * 0.76 - 2 * (k - 1)) / k))
    nhom = bw * k + 2 * (k - 1)
    for i in range(n):
        cx = trai + band * (i + 0.5)
        tn = nhan_tip[i] if nhan_tip else nhan[i]
        for j, c in enumerate(chuoi):
            v = c["v"][i]
            if v is None:
                continue
            mau = c["mau"] if v >= 0 else c.get("mau_am", c["mau"])
            noi.append(bd_cot1(cx - nhom / 2.0 + j * (bw + 2), bw, Y(0), Y(v), mau, "%s - %s: %s" % (tn, c["ten"], fmt(v))))
    noi.append("<line x1='%.1f' y1='%.1f' x2='%.1f' y2='%.1f' stroke='%s' stroke-width='1'/>" % (trai, Y(0), phai, Y(0), BD_TRUC))
    if moc:
        noi.append("<line x1='%.1f' y1='%.1f' x2='%.1f' y2='%.1f' stroke='%s' stroke-width='1'/>" % (trai, Y(moc[0]), phai + 4, Y(moc[0]), BD_MO))
        noi.append("<text x='%.1f' y='%.1f' font-size='%s' fill='%s'>%s</text>" % (phai + 6, Y(moc[0]) + fs * 0.35, fs, BD_MO, bd_e(moc[1])))
    _bd_nhan_x(noi, nhan, trai, phai, H, fs)
    cg = [(c["ten"], c["mau"]) for c in chuoi] if (chu_giai and k >= 2) else None
    return bd_khung(tieu, bd_svg(W, H, aria or tieu, noi, fs), ghi, cg)


def bd_duong(tieu, nhan, vals, fmt, fmt_truc=None, aria=None, ghi=None, W=760, H=200, fs=11, mau=BD_XANH, moc=None, rong=None, kep=None):
    """duong 2 px + diem (vien trang 2 px); bo trong o gia tri None; nhan so chon loc (cuoi, cao nhat, thap nhat); moc = (gia tri, chu);
    kep = (thap, cao): diem ngoai khoang ve sat bien (nhan / title van ghi so that) de mot thang bat thuong khong lam det ca duong."""
    n = len(nhan)
    co = [(i, v) for i, v in enumerate(vals) if v is not None]
    if not n or not co:
        return bd_rong(tieu, rong, ghi)
    fmt_truc = fmt_truc or bd_gon

    def K_(v):
        return min(max(v, kep[0]), kep[1]) if kep else v
    vs = [K_(v) for _, v in co] + ([moc[0]] if moc else [])
    a, b, moc_truc = bd_moc(min(vs + [0.0]), max(vs + [0.0]), 4)
    trai = 10 + fs * 4.8
    phai = W - 96
    tren, duoi = 16, H - fs - 9

    def Y(v):
        return duoi - (v - a) / (b - a) * (duoi - tren)

    def X(i):
        return trai + (phai - trai) / float(n) * (i + 0.5)
    noi = []
    _bd_luoi(noi, moc_truc, trai, phai, Y, fs, fmt_truc)
    if a < 0 < b:
        noi.append("<line x1='%.1f' y1='%.1f' x2='%.1f' y2='%.1f' stroke='%s' stroke-width='1'/>" % (trai, Y(0), phai, Y(0), BD_TRUC))
    if moc:
        noi.append("<line x1='%.1f' y1='%.1f' x2='%.1f' y2='%.1f' stroke='%s' stroke-width='1'/>" % (trai, Y(moc[0]), phai + 4, Y(moc[0]), BD_MO))
        noi.append("<text x='%.1f' y='%.1f' font-size='%s' fill='%s'>%s</text>" % (phai + 6, Y(moc[0]) + fs * 0.35, fs, BD_MO, bd_e(moc[1])))
    d, truoc = [], None
    for i, v in co:
        d.append(("L%.1f %.1f" if truoc == i - 1 else "M%.1f %.1f") % (X(i), Y(K_(v))))
        truoc = i
    noi.append("<path d='%s' fill='none' stroke='%s' stroke-width='2' stroke-linejoin='round' stroke-linecap='round'/>" % ("".join(d), mau))
    for i, v in co:
        noi.append("<circle cx='%.1f' cy='%.1f' r='4' fill='%s' stroke='#fff' stroke-width='2'><title>%s: %s</title></circle>"
                   % (X(i), Y(K_(v)), mau if v >= 0 else BD_DO, bd_e(nhan[i]), bd_e(fmt(v))))
    chon = {co[-1][0], max(co, key=lambda t: t[1])[0], min(co, key=lambda t: t[1])[0]}
    for i, v in co:
        if i in chon:
            y = Y(K_(v)) - 9 if Y(K_(v)) - 9 > tren else Y(K_(v)) + 16
            noi.append("<text x='%.1f' y='%.1f' text-anchor='middle' font-size='%s' %s>%s</text>" % (X(i), y, fs, BD_VIEN, bd_e(fmt(v))))
    _bd_nhan_x(noi, nhan, trai, phai, H, fs)
    return bd_khung(tieu, bd_svg(W, H, aria or tieu, noi, fs), ghi)


def bd_tien_do(tieu, da, muc, fmt, nhan_da, nhan_muc, ghi=None, W=760):
    """thanh tien do (meter): phan da dat tren nen cung tong mau nhat, vach muc can dat."""
    if muc <= 0.5 and da <= 0.5:
        return bd_rong(tieu, None, ghi)
    H, y, h = 46, 6, 14
    tong = max(muc, da, 1.0)

    def X(v):
        return 2 + v / tong * (W - 4)
    noi = [bd_thanh(X(0), X(tong), y, h, BD_XANH_NHAT, "%s: %s" % (nhan_muc, fmt(muc)))]
    noi.append(bd_thanh(X(0), X(da), y, h, BD_XANH if da >= muc else BD_VANG, "%s: %s" % (nhan_da, fmt(da))))
    noi.append("<line x1='%.1f' y1='%d' x2='%.1f' y2='%d' stroke='%s' stroke-width='2'/>" % (X(muc), y - 3, X(muc), y + h + 3, BD_CHU))
    ty = (da / muc) if muc > 0.5 else 1.0
    noi.append("<text x='2' y='%d' font-size='12'>%s: %s (%s)</text>" % (H - 6, bd_e(nhan_da), bd_e(fmt(da)), bd_e(bd_pt(ty))))
    noi.append("<text x='%d' y='%d' font-size='12' text-anchor='end' fill='%s'>%s: %s</text>" % (W - 2, H - 6, BD_MO, bd_e(nhan_muc), bd_e(fmt(muc))))
    return bd_khung(tieu, bd_svg(W, H, tieu, noi), ghi)


def _bd_so_du(L):
    """bieu do so du tien cuoi tuan (co tu GD156, moi tuan mot <rect>): truc 0 that, vach so du hien co, nhan tuan thap nhat / tuan cuoi."""
    nt = L["so_tuan"]
    tieu = "Số dư tiền cuối tuần"
    vs = [L["du"][w] for w in range(nt)]
    if not vs or (all(abs(v) < 0.5 for v in vs) and abs(L["tien_dau"]) < 0.5):
        return bd_rong(tieu)
    W, H, fs = 760, 250, 11
    a, b, moc = bd_moc(min(vs + [0.0, L["tien_dau"]]), max(vs + [0.0, L["tien_dau"]]))
    trai, phai, tren, duoi = 10 + fs * 4.8, W - 96, 18, H - fs - 9

    def Y(v):
        return duoi - (v - a) / (b - a) * (duoi - tren)
    noi = []
    _bd_luoi(noi, moc, trai, phai, Y, fs, bd_gon)
    band = (phai - trai) / float(nt)
    bw = min(24.0, band * 0.62)
    for w in range(nt):
        v = vs[w]
        noi.append("<rect x='%.1f' y='%.1f' width='%.1f' height='%.1f' fill='%s'><title>%s: %s</title></rect>" % (
            trai + band * (w + 0.5) - bw / 2, min(Y(v), Y(0)), bw, abs(Y(v) - Y(0)), BD_XANH if v >= 0 else BD_DO, bd_e(ten_tuan(L, w)), _dd(v)))
    for w in sorted({L["thap"], nt - 1}):
        v = vs[w]
        y = Y(v) - 5 if v >= 0 else Y(v) + 13
        noi.append("<text x='%.1f' y='%.1f' text-anchor='middle' font-size='%s' %s>%s</text>" % (trai + band * (w + 0.5), y, fs, BD_VIEN, bd_e(bd_gon(v))))
    noi.append("<line x1='%.1f' y1='%.1f' x2='%.1f' y2='%.1f' stroke='%s' stroke-width='1'/>" % (trai, Y(0), phai, Y(0), BD_TRUC))
    yd = Y(L["tien_dau"])
    noi.append("<line x1='%.1f' y1='%.1f' x2='%.1f' y2='%.1f' stroke='%s' stroke-width='1'/>" % (trai, yd, phai + 4, yd, BD_MO))
    noi.append("<text x='%.1f' y='%.1f' font-size='%s' fill='%s'>Hiện có<tspan x='%.1f' dy='%s'>%s</tspan></text>" % (
        phai + 6, yd - 2, fs, BD_MO, phai + 6, fs + 1, bd_e(bd_gon(L["tien_dau"]))))
    _bd_nhan_x(noi, ["T%d" % (w + 1) for w in range(nt)], trai, phai, H, fs)
    ghi = "Cột đỏ: tuần dự kiến âm tiền. Vạch ngang: số dư tiền hiện có. Rê chuột lên cột để xem số tiền."
    return bd_khung(tieu, bd_svg(W, H, "Số dư tiền cuối tuần", noi, fs), ghi)


def viet_html(L, dl, ra):
    cty = dl.get("cty") or {}
    nt = L["so_tuan"]
    thap = L["thap"]
    am = L["am"]
    the = [("Số dư tiền hiện tại", _dd(L["tien_dau"]), "111 + 112 + 113 ngày %s" % L["hom_nay"].strftime("%d/%m/%Y"), L["tien_dau"] < 0),
           ("Thấp nhất trong kỳ dự báo", _dd(L["du"][thap]), "Tuần %d (%s)" % (thap + 1, ten_tuan(L, thap).split(" ", 1)[1]), L["du"][thap] < 0),
           ("Tuần âm tiền đầu tiên", ("Tuần %d" % (am[0] + 1)) if am else "Không có",
            ten_tuan(L, am[0]).split(" ", 1)[1] if am else "Không tuần nào âm tiền", bool(am)),
           ("Số dư cuối kỳ dự báo", _dd(L["du"][-1]), "Sau %d tuần" % nt, L["du"][-1] < 0),
           ("Nợ phải thu quá hạn", _dd(L["tong_thu_qua"]), "Chưa tính vào dự báo cơ sở", False)]
    h = ["<!DOCTYPE html><html lang='vi'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>Dự báo dòng tiền</title>",
         "<style>body{font-family:Segoe UI,Arial,sans-serif;font-size:13px;margin:16px;color:#1f2937;max-width:900px}h1{font-size:19px;color:#0b3d91;margin:0 0 2px}"
         ".g{color:#555;font-style:italic}table{border-collapse:collapse;margin:8px 0}",
         "th,td{border:1px solid #bbb;padding:3px 6px}th{background:#3a5c14;color:#fff}td.n{text-align:right}td.am{background:#f8d7da}" + BD_CSS + BD_IN
         + "</style></head><body>",
         "<h1>Dự báo dòng tiền %d tuần - %s</h1>" % (nt, html.escape(cty.get("ten") or "")),
         "<p>Số dư tiền hiện tại: <b>%s</b>. %s</p>" % (_dd(L["tien_dau"]), ("<b style='color:#c62828'>Âm tiền từ tuần %d</b>." % (am[0] + 1)) if am else "Không tuần nào âm tiền."),
         bd_kpi(the), bd_an_toan("Số dư tiền cuối tuần", _bd_so_du, L),
         bd_an_toan("Tiền vào / tiền ra theo tuần", bd_cot, "Tiền vào / tiền ra theo tuần", ["T%d" % (w + 1) for w in range(nt)],
                    [{"ten": "Tiền vào", "v": L["vao"][:nt], "mau": BD_XANH}, {"ten": "Tiền ra", "v": L["ra"][:nt], "mau": BD_VANG}], _dd,
                    nhan_tip=[ten_tuan(L, w) for w in range(nt)], ghi="Cùng một trục số tiền; chi tiết từng khoản ở bảng dưới và tệp Excel."),
         "<h2 class='bd-t'>Bảng dòng tiền theo tuần</h2><table><tr><th>Tuần</th><th>Tiền vào</th><th>Tiền ra</th><th>Số dư cuối</th></tr>"]
    for w in range(nt):
        h.append("<tr><td>%s</td><td class='n'>%s</td><td class='n'>%s</td><td class='n%s'>%s</td></tr>" % (
            ten_tuan(L, w), _dd(L["vao"][w]), _dd(L["ra"][w]), " am" if L["du"][w] < 0 else "", _dd(L["du"][w])))
    h.append("</table><p><small>Ước tính từ sổ kế toán: phải thu / phải trả theo hạn hoặc thói quen thanh toán học từ lịch sử; lương, thuế, BHXH theo số dư và bình quân "
             "3 tháng. Nợ phải thu quá hạn chưa tính (%s).</small></p></body></html>" % _dd(L["tong_thu_qua"]))
    with io.open(ra, "w", encoding="utf-8") as f:
        f.write("\n".join(h))
    return ra


def chay(duong_json, ra):
    with open(duong_json, "r", encoding="utf-8-sig") as f:
        dl = json.loads(f.read(), strict=False)
    d, _ = lap_excel(dl, ra)
    return d, ""


if __name__ == "__main__":
    import sys
    if len(sys.argv) >= 2:
        print(chay(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else re.sub(r"\.json$", ".xlsx", sys.argv[1])))
