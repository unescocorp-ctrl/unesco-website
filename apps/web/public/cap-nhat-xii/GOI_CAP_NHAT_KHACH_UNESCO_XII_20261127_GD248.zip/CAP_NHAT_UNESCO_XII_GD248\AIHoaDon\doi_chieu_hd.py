# -*- coding: utf-8 -*-
"""GD69 - DOI CHIEU HOA DON DIEN TU VOI SO KE TOAN THEO TUNG HOA DON (TT133) - chi DOC so, khong ghi so.

VB6 (ModHDDTHTKK: HDDT_DCHD_Excel) lay:
  hddt : hoa don dien tu da tai (HDDTTaiVe, gop theo MaCT) ngay lap trong ky + cua so truoc / sau (de doi chieu nguoc);
  ct   : chung tu con trong so ma hoa don tro toi (HDDTTaiVe.MaCTKeToan) hoac tro toi hoa don (ChungTu.MaCTHDDTTaiVe);
  hd   : bang ke thue trong so (HoaDon + ChungTu dong thue + KhachHang) ngay phat hanh trong cua so;
ghi JSON UTF-8, goi tool_htkk_unesco.py /doichieuhd:<json> /ra:<xlsx>. Tep nay doi chieu + lap Excel.

Moi hoa don dien tu trong ky -> mot ket luan:
  DAT (khop so tien), CANH_BAO (chua hach toan, lech tien, chua len bang ke, HD bi dieu chinh, nhieu chung tu),
  LOI (da hach toan nhung HD da bi huy / bi thay the, hach toan trung), THONG_TIN (HD huy / bi thay the chua hach toan -
  khong can hach toan; HD khong mang MST cong ty).
Chieu nguoc: dong bang ke trong so (trong ky) khong thay hoa don dien tu nao da tai -> CANH_BAO (chi khi chieu do da tai HDDT).
"""
import json
import os
import re
import unicodedata
from collections import defaultdict

LOI, CANH_BAO, DAT, THONG_TIN = "LOI", "CANH_BAO", "DAT", "THONG_TIN"
TEN_MUC = {LOI: "LỖI", CANH_BAO: "CẦN XEM", DAT: "KHỚP", THONG_TIN: "THÔNG TIN"}
SAI_SO = 10.0                        # dong: lech tu 10 dong tro xuong coi la khop (lam tron)
TEN_CHIEU = {"mua": "Mua vào", "ban": "Bán ra", "khac": "Không mang MST công ty"}


def _so(x):
    try:
        return float(x or 0)
    except (TypeError, ValueError):
        try:
            return float(str(x).replace(",", ""))
        except ValueError:
            return 0.0


def _dd(x):
    return "{:,.0f}".format(x).replace(",", ".")


def bo_dau(s):
    s = unicodedata.normalize("NFD", str(s or ""))
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    return s.replace("đ", "d").replace("Đ", "D")


def mst10(s):
    d = re.sub(r"\D", "", str(s or ""))
    return d[:10]


def so_hd(s):
    d = re.sub(r"\D", "", str(s or ""))
    return d.lstrip("0") or ("0" if d else "")


def ky_hieu(s):
    return re.sub(r"[^A-Z0-9]", "", bo_dau(s).upper())


def ngay_iso(s):
    """'dd/mm/yyyy' -> 'yyyy-mm-dd' ('' neu khong doc duoc)."""
    m = re.match(r"\s*(\d{1,2})/(\d{1,2})/(\d{4})", str(s or ""))
    return "%s-%02d-%02d" % (m.group(3), int(m.group(2)), int(m.group(1))) if m else ""


def trang_thai(s):
    """Trang thai hoa don tren he thong HDDT -> HUY / BI_THAY_THE / BI_DIEU_CHINH / THAY_THE / DIEU_CHINH / MOI."""
    t = bo_dau(s).upper()
    if "HUY" in t:
        return "HUY"
    if "BI THAY THE" in t:
        return "BI_THAY_THE"
    if "BI DIEU CHINH" in t:
        return "BI_DIEU_CHINH"
    if "THAY THE" in t:
        return "THAY_THE"
    if "DIEU CHINH" in t:
        return "DIEU_CHINH"
    return "MOI"


def _ma_ct(x):
    try:
        v = int(round(_so(x)))
    except (TypeError, ValueError, OverflowError):
        return 0
    return v if v > 0 else 0


class SoLieu(object):
    def __init__(self, dl):
        self.dl = dl
        cty = dl.get("cty") or {}
        self.mst = mst10(cty.get("mst"))
        ky = dl.get("ky") or {}
        self.tu, self.den = ngay_iso(ky.get("tu")), ngay_iso(ky.get("den"))
        # hoa don dien tu
        self.hddt = []
        for r in dl.get("hddt") or []:
            r = list(r) + [None] * (19 - len(r))
            tg = _so(r[17]) or 1.0
            e = {"ma": str(r[0] or ""), "mau": str(r[1] or ""), "kh": str(r[2] or ""), "so": str(r[3] or ""), "ngay": ngay_iso(r[4]),
                 "ngay_vn": str(r[4] or ""), "cqt": str(r[5] or ""), "mst_ban": str(r[6] or ""), "ten_ban": str(r[7] or ""),
                 "mst_mua": str(r[8] or ""), "ten_mua": str(r[9] or ""), "tien": _so(r[10]) * tg, "thue": _so(r[11]) * tg,
                 "tong": _so(r[12]) * tg, "tt": str(r[13] or ""), "ps": str(r[14] or ""), "ma_kt": _ma_ct(r[15]), "ts": str(r[16] or ""),
                 "ngay_ky": ngay_iso(r[18])}                     # GD170: ngay nguoi ban ky so (hddt[18], co the rong)
            if mst10(e["mst_mua"]) == self.mst and self.mst:
                e["chieu"], e["doi_tac_mst"], e["doi_tac"] = "mua", e["mst_ban"], e["ten_ban"]
            elif mst10(e["mst_ban"]) == self.mst and self.mst:
                e["chieu"], e["doi_tac_mst"], e["doi_tac"] = "ban", e["mst_mua"], e["ten_mua"]
            else:
                e["chieu"], e["doi_tac_mst"], e["doi_tac"] = "khac", e["mst_ban"], e["ten_ban"]
            e["trong_ky"] = bool(e["ngay"]) and self.tu <= e["ngay"] <= self.den
            self.hddt.append(e)
        # chung tu con song
        self.ct = {}
        self.ct_lk = defaultdict(set)
        for r in dl.get("ct") or []:
            r = list(r) + [None] * (4 - len(r))
            ma = _ma_ct(r[0])
            if not ma:
                continue
            self.ct[ma] = {"sh": str(r[1] or "").strip(), "ngay": str(r[2] or "")}
            lk = str(r[3] or "").strip()
            if lk and lk != "...":
                self.ct_lk[lk].add(ma)
        # bang ke thue: gop dong theo (loai, so HD, MST doi tac)
        nhom = {}
        for r in dl.get("hd") or []:
            r = list(r) + [None] * (19 - len(r))
            loai = int(_so(r[1]))
            if loai not in (1, -1):
                continue
            k = (loai, so_hd(r[3]), mst10(r[15]))
            g = nhom.get(k)
            if g is None:
                g = nhom[k] = {"loai": loai, "so": so_hd(r[3]), "so_goc": str(r[3] or "").strip(), "mst": mst10(r[15]), "kh": set(),
                               "tien": 0.0, "thue": 0.0, "ct": set(), "ct_sh": {}, "ngay": "", "ngay_vn": "", "key": set(), "cqt": set(),
                               "ten": str(r[17] or "").strip(), "ma_kh": str(r[16] or "").strip(), "ke_khai": False}
            g["kh"].add(ky_hieu(r[2]))
            g["tien"] += _so(r[5])
            g["thue"] += _so(r[18])
            ma = _ma_ct(r[12])
            if ma:
                g["ct"].add(ma)
                g["ct_sh"][ma] = (str(r[13] or "").strip(), str(r[14] or ""))
            nd = ngay_iso(r[4])
            if nd and (not g["ngay"] or nd < g["ngay"]):
                g["ngay"], g["ngay_vn"] = nd, str(r[4] or "")
            if str(r[10] or "").strip() not in ("", "..."):
                g["key"].add(str(r[10]).strip())
            if str(r[11] or "").strip() not in ("", "..."):
                g["cqt"].add(str(r[11]).strip())
            if int(_so(r[8])) == 0 or int(_so(r[9])) == 1:
                g["ke_khai"] = True
        self.nhom = list(nhom.values())
        self.theo_so_mst = defaultdict(list)
        self.theo_so = defaultdict(list)
        self.theo_key = defaultdict(list)
        self.theo_cqt = defaultdict(list)
        for g in self.nhom:
            self.theo_so[(g["loai"], g["so"])].append(g)
            if g["mst"]:
                self.theo_so_mst[(g["loai"], g["so"], g["mst"])].append(g)
            for x in g["key"]:
                self.theo_key[x].append(g)
            for x in g["cqt"]:
                self.theo_cqt[x].append(g)


def _gan(S, e):
    """Hoa don dien tu e -> (nhom bang ke khop, chung tu con song, ghi chu)."""
    loai = -1 if e["chieu"] == "mua" else 1
    ds, thay = [], set()

    def them(gs):
        for g in gs:
            if id(g) not in thay and g["loai"] == loai:
                thay.add(id(g))
                ds.append(g)
    them(S.theo_key.get(e["ma"], []))
    if e["cqt"]:
        them(S.theo_cqt.get(e["cqt"], []))
    so = so_hd(e["so"])
    dt = mst10(e["doi_tac_mst"])
    if so and dt:
        them(S.theo_so_mst.get((loai, so, dt), []))
    if so and not ds:
        # doi tac khong MST (ban le cho ca nhan) / so ghi MST khac: cung so + cung ky hieu, duy nhat
        kh = ky_hieu(e["kh"])
        ung = [g for g in S.theo_so.get((loai, so), []) if kh and any(k and (k.endswith(kh) or kh.endswith(k)) and len(k) >= 4 for k in g["kh"])
               and (not dt or not g["mst"])]
        if len(ung) == 1:
            them(ung)
    ct = set()
    for g in ds:
        ct |= g["ct"]
    ghi = []
    if e["ma_kt"]:
        if e["ma_kt"] in S.ct:
            ct.add(e["ma_kt"])
        else:
            ghi.append("chứng từ đã gắn (MaCT %d) không còn trong sổ" % e["ma_kt"])
    ct |= S.ct_lk.get(e["ma"], set())
    return ds, ct, ghi


def doi_chieu(dl):
    S = SoLieu(dl)
    kq = []
    dung = set()
    for e in S.hddt:
        if e["chieu"] == "khac":
            if e["trong_ky"]:
                kq.append(dict(e, muc=THONG_TIN, loai_kq="khac", nhom=[], ct=[], tien_so=0.0, thue_so=0.0,
                               ket_luan="Hoá đơn không mang MST công ty (người bán / người mua khác) - kiểm tài khoản tra cứu hoá đơn"))
            continue
        ds, ct, ghi = _gan(S, e)
        for g in ds:
            dung.add(id(g))
        if not e["trong_ky"]:
            continue
        st = trang_thai(e["tt"])
        tien_so = sum(g["tien"] for g in ds)
        thue_so = sum(g["thue"] for g in ds)
        r = dict(e, nhom=ds, ct=sorted(ct), tien_so=tien_so, thue_so=thue_so, st=st)
        if not ct:
            if st in ("HUY", "BI_THAY_THE"):
                r.update(muc=THONG_TIN, loai_kq="khong_can", ket_luan="Hoá đơn %s - không cần hạch toán" % (
                    "đã bị huỷ" if st == "HUY" else "đã bị thay thế"))
            else:
                r.update(muc=CANH_BAO, loai_kq="chua_ht", ket_luan="Chưa hạch toán" + ("" if not ghi else " (" + "; ".join(ghi) + ")") +
                         (" - hoá đơn đã bị điều chỉnh, hạch toán kèm hoá đơn điều chỉnh" if st == "BI_DIEU_CHINH" else ""))
            kq.append(r)
            continue
        muc, loai_kq, kl = DAT, "khop", []
        if st == "HUY":
            muc, loai_kq = LOI, "huy_da_ht"
            kl.append("Hoá đơn đã bị HUỶ trên hệ thống HĐĐT nhưng đã hạch toán - huỷ / điều chỉnh bút toán, bỏ khỏi bảng kê thuế")
        elif st == "BI_THAY_THE":
            muc, loai_kq = LOI, "huy_da_ht"
            kl.append("Hoá đơn đã bị THAY THẾ - bút toán, bảng kê phải theo hoá đơn thay thế")
        elif st == "BI_DIEU_CHINH":
            muc, loai_kq = CANH_BAO, "dieu_chinh"
            kl.append("Hoá đơn đã bị điều chỉnh - kiểm hoá đơn điều chỉnh đã hạch toán chưa")
        n_ct, trung = len(ct), False
        if n_ct >= 2:
            k = int(round(tien_so / e["tien"])) if e["tien"] else 0
            if k >= 2 and abs(tien_so - k * e["tien"]) <= SAI_SO * k:
                muc, loai_kq, trung = LOI, "trung", True
                kl.append("HẠCH TOÁN TRÙNG: hoá đơn có ở %d chứng từ, bảng kê cộng %d lần giá trị hoá đơn - bỏ bút toán thừa" % (n_ct, k))
            else:
                if muc == DAT:
                    muc, loai_kq = CANH_BAO, "nhieu_ct"
                kl.append("Hoá đơn nằm ở %d chứng từ - kiểm có hạch toán trùng không" % n_ct)
        if not ds:
            if e["chieu"] == "ban" or abs(e["thue"]) > SAI_SO:
                if muc == DAT:
                    muc, loai_kq = CANH_BAO, "chua_bk"
                kl.append("Đã hạch toán nhưng CHƯA lên bảng kê thuế (%s)" % (
                    "chưa kê khai thuế đầu ra" if e["chieu"] == "ban" else "chưa khấu trừ thuế đầu vào"))
            else:
                kl.append("Đã hạch toán, không lên bảng kê (hoá đơn không có thuế GTGT)")
        else:
            lt, lh = tien_so - e["tien"], thue_so - e["thue"]
            if (abs(lt) > SAI_SO or abs(lh) > SAI_SO) and not trung:
                if muc == DAT:
                    muc, loai_kq = CANH_BAO, "lech"
                kl.append("LỆCH TIỀN: hoá đơn %s / thuế %s - sổ %s / thuế %s (lệch %s / %s)" % (
                    _dd(e["tien"]), _dd(e["thue"]), _dd(tien_so), _dd(thue_so), _dd(lt), _dd(lh)))
            if not any(g["ke_khai"] for g in ds):
                kl.append("dòng bảng kê đánh dấu không kê khai")
            ky_bk = sorted({g["ngay"][:7] for g in ds if g["ngay"]})
            if ky_bk and ky_bk != [e["ngay"][:7]]:
                kl.append("bảng kê ghi ngày %s (kê khai kỳ %s)" % (", ".join(g["ngay_vn"] for g in ds if g["ngay_vn"]),
                                                                  ", ".join("%s/%s" % (k[5:7], k[:4]) for k in ky_bk)))
        if ghi:
            kl.extend(ghi)
        if muc == DAT and not kl:
            kl.append("Khớp")
        elif muc == DAT:
            kl.insert(0, "Khớp")
        r.update(muc=muc, loai_kq=loai_kq, ket_luan="; ".join(kl))
        kq.append(r)
    # chieu nguoc: bang ke trong ky khong thay HDDT
    co_hddt = {c: any(e["chieu"] == c and e["trong_ky"] for e in S.hddt) for c in ("mua", "ban")}     # chieu da tai HDDT trong ky
    nguoc, chua_tai = [], {"mua": 0, "ban": 0}
    for g in S.nhom:
        if id(g) in dung or not g["ke_khai"] or not g["ngay"] or not (S.tu <= g["ngay"] <= S.den):
            continue
        c = "mua" if g["loai"] == -1 else "ban"
        if not co_hddt[c]:
            chua_tai[c] += 1
            continue
        nguoc.append(g)
    return S, kq, nguoc, chua_tai


# ============================================================ Excel
def _xl():
    import tool_htkk_unesco as H
    return H


def _ct_chu(S, r):
    ds = []
    for m in r["ct"]:
        c = S.ct.get(m)
        if c:
            ds.append("%s %s" % (c["sh"], c["ngay"]))
        else:
            sh = next((g["ct_sh"][m] for g in r["nhom"] if m in g["ct_sh"]), None)
            ds.append("%s %s" % sh if sh else "MaCT %d" % m)
    return "; ".join(ds)


def lap_excel(dl, ra):
    H = _xl()
    X = H
    S, kq, nguoc, chua_tai = doi_chieu(dl)
    cty = dl.get("cty") or {}
    ky = dl.get("ky") or {}
    kieu_muc = {LOI: X.X_DO, CANH_BAO: X.X_VANG, DAT: X.X_XANH, THONG_TIN: X.X_CHU}
    n_loi = sum(1 for r in kq if r["muc"] == LOI)
    n_cx = sum(1 for r in kq if r["muc"] == CANH_BAO) + len(nguoc)
    T = [[("ĐỐI CHIẾU HOÁ ĐƠN ĐIỆN TỬ VỚI SỔ KẾ TOÁN THEO TỪNG HOÁ ĐƠN - CHỈ ĐỌC, KHÔNG GHI SỔ", X.X_TITLE)],
         [("Đơn vị: %s    MST: %s    Kỳ: %s - %s (theo ngày lập hoá đơn)" % (cty.get("ten") or "", cty.get("mst") or "", ky.get("tu") or "",
                                                                              ky.get("den") or ""), X.X_THUONG)],
         [(("CÓ %d HOÁ ĐƠN LỖI (đã hạch toán hoá đơn huỷ / thay thế, hạch toán trùng)" % n_loi) if n_loi else
           ("KHÔNG CÓ LỖI%s" % ((" - %d dòng cần xem" % n_cx) if n_cx else "")), X.X_DAM)], [],
         [(c, X.X_TIEUDE) for c in ("Chiều", "Hoá đơn trong kỳ", "Khớp", "Chưa hạch toán", "Lệch tiền / chưa lên bảng kê / khác",
                                    "LỖI (huỷ, thay thế, trùng)", "Không cần hạch toán", "Sổ có - HĐĐT không có")]]
    for c in ("mua", "ban", "khac"):
        ds = [r for r in kq if r["chieu"] == c]
        if not ds and c == "khac":
            continue
        dem = defaultdict(int)
        for r in ds:
            dem[r["loai_kq"]] += 1
        T.append([(TEN_CHIEU[c], X.X_CHU), (len(ds), X.X_SO), (dem["khop"], X.X_SO), (dem["chua_ht"], X.X_SO),
                  (dem["lech"] + dem["chua_bk"] + dem["nhieu_ct"] + dem["dieu_chinh"], X.X_SO), (dem["huy_da_ht"] + dem["trung"], X.X_SO),
                  (dem["khong_can"], X.X_SO), (sum(1 for g in nguoc if (g["loai"] == -1) == (c == "mua")) if c != "khac" else 0, X.X_SO)])
    T.append([])
    for c in ("mua", "ban"):
        n_e = sum(1 for r in kq if r["chieu"] == c)
        n_bk = sum(1 for g in S.nhom if g["ke_khai"] and g["ngay"] and S.tu <= g["ngay"] <= S.den and (g["loai"] == -1) == (c == "mua"))
        if 0 < n_e < 0.5 * n_bk:
            T.append([("%s: hoá đơn điện tử đã tải trong kỳ (%d) ít hơn nhiều số hoá đơn trên bảng kê (%d) - có thể chưa tải đủ hoá đơn kỳ này." % (
                TEN_CHIEU[c], n_e, n_bk), X.X_GHICHU)])
        if chua_tai[c]:
            T.append([("%s: sổ có %d hoá đơn trong kỳ nhưng chưa tải hoá đơn điện tử %s nào - tải hoá đơn rồi đối chiếu lại." % (
                TEN_CHIEU[c], chua_tai[c], TEN_CHIEU[c].lower()), X.X_GHICHU)])
    T.append([("Khớp: hoá đơn có chứng từ trong sổ và bảng kê thuế cùng số tiền chưa thuế, tiền thuế (lệch không quá %d đồng). "
               "Tìm theo liên kết AI (MaCT), khoá hoá đơn / mã CQT trên bảng kê, rồi theo số hoá đơn + MST đối tác "
               "(người mua không MST: số + ký hiệu, chỉ khi duy nhất). Không kiểm tình trạng hoạt động của người bán "
               "(cần tra cứu MST trên cổng thuế)." % SAI_SO, X.X_GHICHU)])
    cot = ("Mức", "Chiều", "Ký hiệu", "Số HĐ", "Ngày HĐ", "MST đối tác", "Đối tác", "Chưa thuế (HĐĐT)", "Thuế (HĐĐT)",
           "Trạng thái HĐĐT", "Chứng từ trong sổ", "Chưa thuế (sổ)", "Thuế (sổ)", "Kết luận / cách xử lý")
    rong = [11, 10, 12, 10, 12, 14, 40, 17, 15, 18, 26, 17, 15, 90]

    def dong(r):
        return [(TEN_MUC[r["muc"]], kieu_muc[r["muc"]]), (TEN_CHIEU[r["chieu"]], X.X_CHU), (r["mau"] + r["kh"], X.X_CHU), (r["so"], X.X_CHU),
                (r["ngay_vn"], X.X_CHU), (r["doi_tac_mst"], X.X_CHU), (r["doi_tac"], X.X_CHU), (r["tien"], X.X_SO), (r["thue"], X.X_SO),
                (r["tt"], X.X_CHU), (_ct_chu(S, r), X.X_CHU), (r["tien_so"] if r["nhom"] else None, X.X_SO),
                (r["thue_so"] if r["nhom"] else None, X.X_SO), (r["ket_luan"], X.X_CHU)]
    thu_tu = {LOI: 0, CANH_BAO: 1, THONG_TIN: 2, DAT: 3}
    kq.sort(key=lambda r: (thu_tu[r["muc"]], r["chieu"], r["ngay"], so_hd(r["so"]).zfill(12)))
    import kiem_khoa_so
    T += kiem_khoa_so.khoi_ky(dl, X, 8)          # GD70
    sheets = [("Tong hop", [26, 16, 12, 16, 30, 24, 20, 22], T, 5)]
    for ten, loc, tieu in (("Can xu ly", lambda r: r["muc"] in (LOI, CANH_BAO) and r["loai_kq"] != "chua_ht",
                            "HOÁ ĐƠN CẦN XỬ LÝ: lỗi, lệch tiền, chưa lên bảng kê, nhiều chứng từ, bị điều chỉnh"),
                           ("Chua hach toan", lambda r: r["loai_kq"] == "chua_ht", "HOÁ ĐƠN ĐIỆN TỬ CHƯA HẠCH TOÁN"),
                           ("Khop", lambda r: r["muc"] in (DAT, THONG_TIN), "HOÁ ĐƠN KHỚP SỔ / KHÔNG CẦN HẠCH TOÁN")):
        D = [[(tieu, X.X_TITLE)], [], [(c, X.X_TIEUDE) for c in cot]]
        ds = [r for r in kq if loc(r)]
        for r in ds:
            D.append(dong(r))
        if ds:
            D.append([("", X.X_MUC), ("Cộng", X.X_MUC)] + [("", X.X_MUC)] * 5 + [(sum(r["tien"] for r in ds), X.X_SOMUC),
                                                                               (sum(r["thue"] for r in ds), X.X_SOMUC)])
        else:
            D.append([("(không có)", X.X_CHU)])
        sheets.append((ten, rong, D, 3))
    N = [[("SỔ CÓ (BẢNG KÊ THUẾ TRONG KỲ) - KHÔNG THẤY HOÁ ĐƠN ĐIỆN TỬ ĐÃ TẢI", X.X_TITLE)],
         [("Kiểm số hoá đơn, ký hiệu, MST đối tác trên bảng kê; hoá đơn giấy / hoá đơn chưa tải thì tải lại rồi đối chiếu.", X.X_THUONG)], [],
         [(c, X.X_TIEUDE) for c in ("Chiều", "Ký hiệu (sổ)", "Số HĐ (sổ)", "Ngày HĐ (sổ)", "MST đối tác", "Mã / tên đối tác", "Chưa thuế",
                                    "Thuế", "Chứng từ")]]
    for g in sorted(nguoc, key=lambda g: (g["loai"], g["ngay"], g["so"].zfill(12))):
        N.append([(TEN_CHIEU["mua" if g["loai"] == -1 else "ban"], X.X_CHU), (", ".join(sorted(k for k in g["kh"] if k)), X.X_CHU),
                  (g["so_goc"], X.X_CHU), (g["ngay_vn"], X.X_CHU), (g["mst"], X.X_CHU), ((g["ma_kh"] + " " + g["ten"]).strip(), X.X_CHU),
                  (g["tien"], X.X_SO), (g["thue"], X.X_SO), ("; ".join("%s %s" % v for v in g["ct_sh"].values()), X.X_CHU)])
    if not nguoc:
        N.append([("(không có)", X.X_CHU)])
    sheets.append(("So co - HDDT khong", [12, 14, 12, 12, 14, 44, 17, 15, 30], N, 4))
    os.makedirs(os.path.dirname(os.path.abspath(ra)), exist_ok=True)
    H.viet_xlsx_o(ra, sheets)
    return ra, {"loi": n_loi, "can_xem": n_cx, "hddt": len(kq)}


def chay(duong_json, ra):
    """-> (duong xlsx, loi)."""
    with open(duong_json, "r", encoding="utf-8-sig") as f:
        dl = json.loads(f.read(), strict=False)
    d, _ = lap_excel(dl, ra)
    return d, ""


if __name__ == "__main__":
    import sys
    if len(sys.argv) >= 2:
        print(chay(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else re.sub(r"\.json$", ".xlsx", sys.argv[1])))
