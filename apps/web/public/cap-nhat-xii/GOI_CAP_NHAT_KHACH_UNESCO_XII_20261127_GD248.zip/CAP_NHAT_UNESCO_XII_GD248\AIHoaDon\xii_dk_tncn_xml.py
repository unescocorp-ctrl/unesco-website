# -*- coding: utf-8 -*-
"""XII (31/10/2026) - XML HTKK cua to khai 05-DK-TH-TCT (Thong tu 90/2026/TT-BTC): to khai dang ky thue tong hop cua ca nhan co thu nhap tu
tien luong, tien cong, do to chuc tra thu nhap dang ky thay. Chu doanh nghiep dan "Cap nhat bieu mau dung HTKK cua Tong cuc thue" (F:\\HTKK 5.8.1):
HTKK 5.8.1 co to nay (MaFile 05_DK_TH_TCT_TT86, maTKhai 1135, XML 3.0.8, XSD 05_DK_TH_TCT_TT86) nhung dk_tncn.py (ban XI) chi lap Excel.

Chi them phan XML; dk_tncn.py chi goi lap_xml(dl, kq, thumuc, cb) sau khi lap Excel. CHI DOC SO. Khong ghi so CCCD / MST vao nhat ky (chi co trong tep).
Khung: HTKK InterfaceTemplates\\xml\\05_DK_TH_TCT_TT86_xml_308.xml (cung ho TKhaiDkyThue.xsd voi 20/DK-TH-TCT cua dk_npt.py XI GD330).
Ma danh muc lay tu InterfaceIni cua chinh HTKK: Catalogue_DM_Gioi_Tinh (2 Nam, 1 Nu), Catalogue_Quoc_Gia_full (quoc tich, quoc gia, noi cap ho chieu),
Catalogue_Dia_Ban_Tinh_Moi (tinh / thanh pho sau sap xep), Catalogue_Dia_Ban_Xa (xa / phuong / dac khu theo tinh; bo dong "het hieu luc").
Ten khong khop danh muc thi de trong ca ma lan ten (HTKK se bao chon lai) va ghi canh bao - khong tu doan ma."""
import html
import io
import os
import re
import xml.etree.ElementTree as ET

import qtt_tncn as Q
from qtt_tncn import _dn, _ngay_lap, _nguoi_ky

MA_FILE = "05_DK_TH_TCT_TT86"
MA_TKHAI = "1135"
PBAN_XML = "3.0.8"
TEN_TKHAI = "TỜ KHAI ĐĂNG KÝ THUẾ Tổng hợp của cá nhân có thu nhập từ tiền lương, tiền công"
MO_TA = "(Kèm theo Thông tư số 90/2026/TT-BTC ngày 30 tháng 6 năm 2026 của Bộ trưởng Bộ Tài chính)"

_CACHE = {}
_RE_TIEN_TO_TINH = re.compile(r"^\s*(thành\s+phố|tỉnh|tp\s*\.?|t\s*\.)\s*", re.I)
_RE_TIEN_TO_XA = re.compile(r"^\s*(phường|xã|thị\s+trấn|đặc\s+khu|p\s*\.|x\s*\.|tt\s*\.)\s*", re.I)


def _muc(goc, ten):
    """Danh muc cua HTKK (InterfaceIni\\<ten>): list cac dong tach theo '###'. Thieu HTKK / thieu tep -> []."""
    k = (goc or "", ten)
    if k not in _CACHE:
        rows = []
        try:
            with io.open(os.path.join(goc, "InterfaceIni", ten), encoding="utf-8-sig", errors="replace") as f:
                txt = f.read()
            for v in re.findall(r"<Item\s+Value\s*=\s*\"([^\"]*)\"", txt):
                rows.append([html.unescape(p) for p in v.split("###")])
        except (OSError, TypeError):
            rows = []
        _CACHE[k] = rows
    return _CACHE[k]


def _khoa(s, tien_to=None):
    s = Q._ten_sach(s)
    if tien_to is not None:
        s = tien_to.sub("", s)
    return Q.khoa_ten(s)


def _tinh(goc, ten):
    """(ma, ten theo danh muc) cua tinh / thanh pho trong danh muc moi cua HTKK; khong khop -> None."""
    k = _khoa(ten, _RE_TIEN_TO_TINH)
    if not k:
        return None
    for r in _muc(goc, "Catalogue_Dia_Ban_Tinh_Moi.xml"):
        if len(r) >= 3 and _khoa(r[2], _RE_TIEN_TO_TINH) == k:
            return r[1], r[2]
    return None


def _xa(goc, ma_tinh, ten):
    """(ma, ten theo danh muc) cua xa / phuong / dac khu thuoc tinh ma_tinh; khop ca ten (co tien to) hoac ten bo tien to neu duy nhat."""
    if not ma_tinh or not Q._ten_sach(ten):
        return None
    day_du, bo = _khoa(ten), _khoa(ten, _RE_TIEN_TO_XA)
    ung = [r for r in _muc(goc, "Catalogue_Dia_Ban_Xa.xml") if len(r) >= 5 and r[1] == ma_tinh and "hết hiệu lực" not in r[4].lower()]
    kq = [r for r in ung if _khoa(r[4]) == day_du]
    if len(kq) != 1:
        kq = [r for r in ung if _khoa(r[4], _RE_TIEN_TO_XA) == bo]
    return (kq[0][3], kq[0][4]) if len(kq) == 1 else None


# Ten khac cua danh sach quoc gia san co cua XI (bang QuocGia) so voi danh muc cua HTKK: khoa ten -> ma quoc gia (ten chinh thuc lay tu danh muc HTKK)
_BIET_DANH_NUOC = {"chlbnga": "RU", "lienbangnga": "RU", "nhatban": "JP", "my": "US", "hiepchungquochoaky": "US", "italia": "IT", "ita": "IT",
                   "sinhgapo": "SG", "malaixia": "MY", "campuchia": "KH", "dailoan": "TW", "hanquoc": "KR", "trungquoc": "CN"}


def _nuoc(goc, ten):
    """(ma, ten) quoc gia theo Catalogue_Quoc_Gia_full; khong khop -> None."""
    k = _khoa(ten)
    if not k:
        return None
    if k in ("vietnam", "vn"):
        return "VN", "Việt Nam"
    rows = _muc(goc, "Catalogue_Quoc_Gia_full.xml")
    for r in rows:
        if len(r) >= 2 and _khoa(r[1]) == k:
            return r[0], r[1]
    ma = _BIET_DANH_NUOC.get(k)
    for r in rows:
        if ma and len(r) >= 2 and r[0] == ma:
            return r[0], r[1]
    return None


def _e(cha, ten, gt=None):
    return Q._e(cha, ten, gt)


def _nil(cha, ten, gt=""):
    n = Q._e(cha, ten)
    if gt:
        n.text = str(gt)
    else:
        n.set("{%s}nil" % Q.NS_XSI, "true")
    return n


def _cat(s, so):
    s = Q._ten_sach(s)
    return s[:so].strip() if so else s


def _menu(goc):
    """Dong Menu.xml cua HTKK cho MaFile 05_DK_TH_TCT_TT86 -> {MaToKhai, VersionXML, TenToKhai, MoTaBieuMau}; thieu thi {}."""
    try:
        with io.open(os.path.join(goc, "Project", "Menu.xml"), encoding="utf-8-sig", errors="replace") as f:
            txt = re.sub(r"<!--.*?-->", "", f.read(), flags=re.S)
    except (OSError, TypeError):
        return {}
    for m in re.finditer(r"<Menu\b[^>]*>", txt):
        if 'MaFile="%s"' % MA_FILE in m.group(0):
            return {k: html.unescape(v) for k, v in re.findall(r'(MaToKhai|VersionXML|TenToKhai|MoTaBieuMau)="([^"]*)"', m.group(0))}
    return {}


def _dia_chi(goc, so_nha, xa, tinh, ghi):
    """-> (so nha, (ma tinh, ten) | None, (ma xa, ten) | None, co dia chi); ghi: list ten xa / tinh khong khop de bao."""
    ts, xs = _tinh(goc, tinh), None
    if ts:
        xs = _xa(goc, ts[0], xa)
    co_chu = bool(Q._ten_sach(tinh) or Q._ten_sach(xa))
    if co_chu and not ts:
        ghi.append("tinh")
    elif Q._ten_sach(xa) and not xs:
        ghi.append("xa")
    return _cat(so_nha, 60), ts, xs, bool(Q._ten_sach(so_nha) or ts)


def lap_xml_goc(dl, kq, cb, goc_htkk):
    dn = _dn(dl)
    hd, pb = Q._htkk(dl)
    lap = _ngay_lap(dl)
    mn = _menu(goc_htkk)
    root = ET.Element("{%s}HSoThueDTu" % Q.NS)
    hs = _e(root, "HSoKhaiThue")
    hs.set("id", "ID_1")
    tc = _e(hs, "TTinChung")
    dv = _e(tc, "TTinDVu")
    _e(dv, "maDVu", "HTKK")
    _e(dv, "tenDVu", "HỖ TRỢ KÊ KHAI THUẾ")
    _e(dv, "pbanDVu", pb or "5.8.1")
    _e(dv, "ttinNhaCCapDVu", Q._ttin_nha_ccap())
    tt = _e(tc, "TTinTKhaiThue")
    _e(tt, "maTKhai", mn.get("MaToKhai") or MA_TKHAI)
    _e(tt, "tenTKhai", mn.get("TenToKhai") or TEN_TKHAI)
    _e(tt, "moTaBMau", mn.get("MoTaBieuMau") or MO_TA)
    _e(tt, "pbanTKhaiXML", mn.get("VersionXML") or PBAN_XML)
    mst = re.sub(r"[^0-9-]", "", str(dn.get("mst") or hd.get("mst") or "")).strip("-")
    _nil(tt, "mst", mst if Q.RE_TIN.fullmatch(mst or "") else "")
    _e(tt, "tenNNT", str(dn.get("ten") or hd.get("tenNNT") or ""))
    ma_cqt, ten_cqt = hd.get("maCQTNoiNop", ""), hd.get("tenCQTNoiNop", "")
    if not ma_cqt:
        ma_cqt, ten_cqt = str(dn.get("ma_cqt") or ""), str(dn.get("ten_cqt") or "")
    if not ma_cqt:
        cb.append("XML 05-ĐK-TH-TCT: thiếu mã cơ quan thuế quản lý - chọn lại trên HTKK trước khi nộp.")
    _nil(tt, "maCQTQuanLy", ma_cqt)
    _nil(tt, "tenCQTQuanLy", ten_cqt)
    _nil(tt, "ngayNhanTKhai")
    _nil(tt, "noiNhanTKhai")
    _nil(tt, "soGiayTo_id")
    _nil(tt, "nghiepVuCapMST")
    _e(tt, "ngayKy", lap.strftime("%Y-%m-%d"))
    _nil(tt, "nguoiKy", _nguoi_ky(dl))
    _e(tt, "nhanKQQuaBuuDien", "false")
    dly = _e(tt, "DLyThue")
    for ten in ("tenDLyThue", "mstDLyThue", "soHDongDLyThue", "ngayKyHDDLyThue"):
        _nil(dly, ten)
    nv = _e(dly, "NVienDLy")
    _nil(nv, "tenNVienDLyThue")
    _nil(nv, "cchiHNghe")
    ct = _e(hs, "CTieuTKhaiChinh")
    _e(ct, "dangKyThue", "true")
    _e(ct, "thayDoiTTin", "false")
    khong_tinh, khong_xa, khong_qt, khong_noi, khong_gt, khong_ns, khong_ngay_cap = [], [], [], [], [], [], []
    for i, x in enumerate(kq["ds"], 1):
        d = x.get("d") or {}
        b = _e(ct, "DSachCNDangkyMST")
        b.set("id", "ID_%d" % i)
        _e(b, "recordID", str(i))
        _e(b, "ct07", _cat(x["ten"], 0))
        _nil(b, "ct08")
        ns = Q._ngay_iso_npt(x.get("ngay_sinh"))
        if not ns:
            khong_ns.append(x["ten"])
        _nil(b, "ct09", ns)
        gt = {"nam": ("2", "Nam"), "nu": ("1", "Nữ")}.get(Q.khoa_ten(x.get("gioi")))
        if not gt:
            khong_gt.append(x["ten"])
        _nil(b, "ct10_ma", gt[0] if gt else "")
        _nil(b, "ct10", gt[1] if gt else "")
        qt = _nuoc(goc_htkk, x.get("qt")) if Q.la_viet_nam(x.get("qt")) is False else ("VN", "Việt Nam")
        if not qt:
            khong_qt.append(x["ten"])
        _nil(b, "ct11_ma", qt[0] if qt else "")
        _nil(b, "ct11", qt[1] if qt else "")
        _e(b, "songNuocNgoai", "false")
        _e(b, "cmndKeKhaiSai", "false")
        vn = bool(qt) and qt[0] == "VN"
        _nil(b, "soDinhDanh", x.get("so_dd") if vn else "")
        hc = (not vn) and bool(x.get("giay_to"))
        _nil(b, "ct12_ma", "02" if hc else "")
        _nil(b, "ct12_ten", "Hộ chiếu" if hc else "")
        _nil(b, "ct13", _cat(x.get("giay_to"), 30) if hc else "")
        nc = Q._ngay_iso_npt(d.get("ngay_cap")) if hc else ""
        if hc and not nc:
            khong_ngay_cap.append(x["ten"])
        _nil(b, "ct14", nc)
        noi = _nuoc(goc_htkk, d.get("noi_cap")) if hc and Q._ten_sach(d.get("noi_cap")) else None
        if hc and not noi:
            khong_noi.append(x["ten"])
        _nil(b, "ct15_ma", noi[0] if noi else "")
        _nil(b, "ct15_ten", noi[1] if noi else "")
        ghi = []
        so1, t1, x1, co1 = _dia_chi(goc_htkk, d.get("dc_hk"), d.get("xa_hk"), d.get("tinh_hk"), ghi)
        so2, t2, x2, co2 = _dia_chi(goc_htkk, d.get("dc_ct"), d.get("xa_ct"), d.get("tinh_ct"), ghi)
        if "tinh" in ghi:
            khong_tinh.append(x["ten"])
        elif "xa" in ghi:
            khong_xa.append(x["ten"])
        hk = _e(b, "DChokhau")
        _nil(hk, "ct18", so1)
        _nil(hk, "ct19_ma", t1[0] if t1 else "")
        _nil(hk, "ct19", t1[1] if t1 else "")
        _nil(hk, "ct20_ma")
        _nil(hk, "ct20")
        _nil(hk, "ct21_ma", x1[0] if x1 else "")
        _nil(hk, "ct21", x1[1] if x1 else "")
        _nil(hk, "ct22_ma", "VN" if co1 else "")
        _nil(hk, "ct22", "Việt Nam" if co1 else "")
        ct_ = _e(b, "DCcutru")
        _nil(ct_, "ct23", so2)
        _nil(ct_, "ct24_ma", t2[0] if t2 else "")
        _nil(ct_, "ct24", t2[1] if t2 else "")
        _nil(ct_, "ct25_ma")
        _nil(ct_, "ct25")
        _nil(ct_, "ct26_ma", x2[0] if x2 else "")
        _nil(ct_, "ct26", x2[1] if x2 else "")
        _nil(b, "ct27", _cat(x.get("tel"), 30))
        _nil(b, "ct28", _cat(x.get("mail"), 241))
        _nil(b, "ct29")
    for ten, ds, msg in (
            ("ngày sinh", khong_ns, "không có ngày sinh hợp lệ trong hồ sơ"),
            ("giới tính", khong_gt, "không có giới tính trong hồ sơ"),
            ("quốc tịch", khong_qt, "quốc tịch không khớp danh mục quốc gia của HTKK"),
            ("ngày cấp hộ chiếu", khong_ngay_cap, "không có ngày cấp hộ chiếu hợp lệ"),
            ("nơi cấp hộ chiếu", khong_noi, "nơi cấp không khớp danh mục quốc gia của HTKK"),
            ("tỉnh / thành phố", khong_tinh, "tỉnh, thành phố trong hồ sơ không khớp danh mục mới của HTKK (tên cũ trước khi sáp nhập?)"),
            ("xã / phường / đặc khu", khong_xa, "xã, phường không khớp danh mục của HTKK theo tỉnh đã chọn")):
        if ds:
            cb.append("XML 05-ĐK-TH-TCT: để trống %s của %d người (%s) - chọn trên HTKK trước khi Ghi: %s." % (ten, len(ds), msg, Q._ds(ds) if hasattr(Q, "_ds") else ", ".join(ds[:6])))
    if not _muc(goc_htkk, "Catalogue_Dia_Ban_Xa.xml"):
        cb.append("XML 05-ĐK-TH-TCT: không đọc được danh mục địa bàn của HTKK (InterfaceIni) - mã tỉnh, xã để trống; chọn trên HTKK.")
    return root


def lap_xml(dl, kq, thumuc, cb):
    """Lap <thumuc>\\05_DK_TH_TCT_TT90_<nam>.xml; tra ve duong dan (hoac '' neu khong lap duoc). Tu kiem XSD cua HTKK khi may co lxml."""
    goc_htkk = ""
    try:
        import tool_htkk_unesco as X
        h = X.tim_htkk()
        goc_htkk = (h or {}).get("goc") or ""
    except Exception:
        X = None
    if not kq.get("ds"):
        cb.append("XML 05-ĐK-TH-TCT: không có người lao động nào cần đăng ký - không lập XML.")
        return ""
    if not goc_htkk:
        cb.append("XML 05-ĐK-TH-TCT: không tìm thấy HTKK trên máy (khung, danh mục tỉnh / xã) - mở HTKK một lần hoặc khai đường dẫn HTKK rồi xuất lại.")
        return ""
    p = os.path.join(thumuc, "05_DK_TH_TCT_TT90_%d.xml" % (kq.get("nam") or 0))
    goc = lap_xml_goc(dl, kq, cb, goc_htkk)
    Q.ghi_xml(goc, p)
    try:
        cach, lx = X.kiem_xsd_htkk(p, MA_FILE)
        if cach == "xsd":
            cb.append("XML 05-ĐK-TH-TCT: " + ("HỢP LỆ theo XSD của HTKK." if not lx else "CHƯA HỢP LỆ theo XSD của HTKK: %s" % "; ".join(lx[:4])))
    except Exception:
        pass
    return p
