# -*- coding: utf-8 -*-
"""GD111: bu tham so VB6 khi lien ket .py BO MAT tham so.

Python install manager (pymanager) / Python cai tu Microsoft Store dang ky lien ket .py qua goi MSIX: phan mem mo tep .py
bang ShellExecute (nhu VB6 ban cu) thi Windows CHI truyen duong dan tep, BO MAT tham so -> tool khong thay /thamso:"..."
nen mo giao dien web thay vi doc so phu / tai hoa don / xuat HTKK.

VB6 luon ghi tham so vao <thu muc tool>\\thamso_<yyyymmddhhnnss>.txt ngay truoc khi chay tool. Khi tool chay KHONG co tham
so nao: lay tep thamso_*.txt MOI NHAT (ghi trong HAN_GIAY giay, chua tien trinh nao nhan) trong thu muc tool.
Tep da nhan doi ten thamso_<...>_dung.txt (VB6 van don sau 7 ngay theo mau thamso_*.txt) de khong chay lai lan hai -
ca khi tool nhan tham so binh thuong (nhap dup tool ngay sau do khong lay lai viec cu).
Chi goi tu khoi `if __name__ == "__main__"` cua tool (import trong bai kiem thu khong bi anh huong)."""
import os
import re
import time

MAU = re.compile(r"^thamso_(\d{14})\.txt$", re.I)
HAN_GIAY = 90
TRANG_THAI = {"bu": None}          # duong dan tep tham so da lay bu (de tool ghi nhat ky)


def _nhan(duong):
    """Doi ten tep tham so sang ..._dung.txt (nhan tep). Tra duong dan moi; None neu tien trinh khac da nhan truoc."""
    moi = duong[:-4] + "_dung.txt"
    try:
        os.replace(duong, moi)
        return moi
    except FileNotFoundError:
        return None
    except OSError:
        return duong if os.path.isfile(duong) else None


def _dung_tool(p, phai_co, khong_co):
    """Noi dung tep tham so co danh cho tool nay? (Tro ly chay song song voi tool khac: tep Tro ly co /hoi:)"""
    if not phai_co and not khong_co:
        return True
    try:
        with open(p, "r", encoding="utf-8-sig", errors="replace") as f:
            nd = f.read().lower()
    except OSError:
        return False
    if phai_co and not any(k.lower() in nd for k in phai_co):
        return False
    return not any(k.lower() in nd for k in khong_co)


def bu_tham_so(argv, thu_muc, bay_gio=None, phai_co=(), khong_co=()):
    """Tra argv moi. Co tham so: nhan (doi ten) tep /thamso: cua VB6. Khong co tham so: lay bu tep thamso_ moi nhat
       (trong HAN_GIAY giay, dung tool theo phai_co / khong_co, chua tien trinh nao nhan)."""
    try:          # GD118: moi tool deu qua day -> giu khoa Google cua may (tu khoi phuc docai_goi.dat) + ghi noi cai
        import giu_may
        giu_may.chay(thu_muc)
    except Exception:
        pass
    argv = [str(a) for a in (argv or [])]
    if len(argv) > 1:
        ra = []
        for a in argv:
            if a.lower().startswith("/thamso:"):
                duong = a.split(":", 1)[1].strip().strip('"')
                if MAU.match(os.path.basename(duong)) and os.path.isfile(duong):
                    moi = _nhan(duong)
                    if moi:
                        a = "/thamso:" + moi
            ra.append(a)
        return ra
    bay_gio = time.time() if bay_gio is None else bay_gio
    try:
        ds = []
        for ten in os.listdir(thu_muc):
            if MAU.match(ten):
                p = os.path.join(thu_muc, ten)
                try:
                    t = os.path.getmtime(p)
                except OSError:
                    continue
                ds.append((t, ten, p))
        for t, ten, p in sorted(ds, reverse=True):
            if bay_gio - t > HAN_GIAY:
                break                 # tep cu (khong phai VB6 vua chay tool) -> giu che do khong tham so
            if bay_gio - t < -5:
                continue              # gio tep lech tuong lai - bo qua
            if not _dung_tool(p, phai_co, khong_co):
                continue
            moi = _nhan(p)
            if moi:
                TRANG_THAI["bu"] = moi
                return (argv or [""]) + ["/thamso:" + moi]
    except Exception:
        pass
    return argv
