# -*- coding: utf-8 -*-
"""
TOOL TAI HOA DON DIEN TU HANG LOAT - BAN TICH HOP UNESCO XI
Chay trong trinh duyet Chrome. Duoc phan mem UNESCO goi voi tham so:
  /unesco:"<duong dan MDB>" /mst:"<MST>" /huong:mua|ban|ca /tu:yyyy-mm-dd /den:yyyy-mm-dd
  /out:"<thu muc>" /nhap:"<thu muc XML/ZIP>" /kiemtra:"<file danh sach>" /tudong
Khong co tham so -> chay nhu tool thuong.

Cach dung: bam doi vao file nay (hoac chay: python tool_tai_hoa_don.py)
Tool se tu mo Chrome. Muon dong tool thi dong cua so den (Command Prompt).

Khong can cai them thu vien nao - chi dung thu vien co san cua Python.
"""

APP_VERSION = "3.12-UNESCO"          # GD145: dang nhap trang thue / thoat cung trang tai

import base64
import gzip
import http.cookiejar
import http.server
import json
import os
import platform
import queue
import random
import re
import shutil
import socket
import ssl
import subprocess
import sys
import tempfile
import threading
import time
import traceback
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
import xml.etree.ElementTree as ET
import zipfile
import io
from datetime import datetime, timedelta

try:
    import tkinter as tk
    from tkinter import filedialog
    TK_OK = True
except Exception:
    TK_OK = False

# ==========================================================================
#  DUONG DAN
# ==========================================================================
if getattr(sys, "frozen", False):
    BASE_DIR = os.path.dirname(sys.executable)
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))

if __name__ == "__main__":          # GD111: lien ket .py cua Python install manager / Store bo mat tham so VB6
    try:
        import tham_so_du_phong as _TSDP
        sys.argv = _TSDP.bu_tham_so(sys.argv, BASE_DIR, khong_co=("/hoi:",))
    except Exception:
        pass


LOG_PATH = os.path.join(BASE_DIR, "nhat-ky.txt")
LOG_OLD_PATH = os.path.join(BASE_DIR, "nhat-ky-cu.txt")
SETTINGS_PATH = os.path.join(BASE_DIR, "cai-dat.json")
LOG_MAX_BYTES = 5 * 1024 * 1024  # 5 MB


def _gd167_ico(cs):
    """GD167: bieu tuong cua so = logo UNESCO (AIHoaDon/giao-dien/unesco.ico); thieu tep / loi -> bo qua"""
    try:
        p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "giao-dien", "unesco.ico")
        if os.path.exists(p):
            cs.iconbitmap(default=p)
    except Exception:
        pass


def _dang_kiem_thu():
    """GD94: tool dang duoc nap tu tep kiem thu (python test_*.py) -> nhat ky / cai dat ghi vao thu muc tam, KHONG ghi vao
    nhat-ky.txt / cai-dat.json that canh tool (truoc day moi lan chay kiem thu tren may khach deu ghi them vao nhat ky that)."""
    try:
        m = sys.modules.get("__main__")
        return os.path.basename(str(getattr(m, "__file__", "") or "")).lower().startswith("test_")
    except Exception:
        return False


if _dang_kiem_thu():
    try:
        _THU_MUC_KIEM_THU = os.path.join(tempfile.gettempdir(), "unesco_tool_kiem_thu_%d" % os.getpid())
        os.makedirs(_THU_MUC_KIEM_THU, exist_ok=True)
        LOG_PATH = os.path.join(_THU_MUC_KIEM_THU, "nhat-ky.txt")
        LOG_OLD_PATH = os.path.join(_THU_MUC_KIEM_THU, "nhat-ky-cu.txt")
        SETTINGS_PATH = os.path.join(_THU_MUC_KIEM_THU, "cai-dat.json")
    except Exception:
        pass


# ==========================================================================
#  CHE THONG TIN NHAY CAM  (yeu cau muc 5)
# ==========================================================================
_SECRET_KEYS = (
    "password", "matkhau", "mat_khau", "pass", "pwd",
    "token", "access_token", "refresh_token", "authorization", "bearer",
    "apikey", "api_key", "key", "ckey", "cvalue", "captcha", "cccd",
    "sotaikhoan", "cardnumber", "cmnd",
)


def mask_tail(value):
    """Che het, chi de lo 3 ky tu cuoi."""
    try:
        s = str(value)
    except Exception:
        return "***"
    if len(s) <= 3:
        return "*" * len(s)
    return "*" * (len(s) - 3) + s[-3:]


def scrub(text):
    """Xoa/che moi thong tin nhay cam truoc khi ghi vao nhat ky."""
    try:
        s = str(text)
    except Exception:
        return "<khong doc duoc noi dung>"
    try:
        # dang JSON:  "password":"abc123"
        for k in _SECRET_KEYS:
            s = re.sub(
                r'("%s"\s*:\s*")([^"]*)(")' % re.escape(k),
                lambda m: m.group(1) + mask_tail(m.group(2)) + m.group(3),
                s, flags=re.IGNORECASE)
            # dang tham so URL:  password=abc123
            s = re.sub(
                r'(\b%s=)([^&\s"\']+)' % re.escape(k),
                lambda m: m.group(1) + mask_tail(m.group(2)),
                s, flags=re.IGNORECASE)
        # header Authorization: Bearer xxxxx
        s = re.sub(r'(Bearer\s+)([A-Za-z0-9\.\-_]+)',
                   lambda m: m.group(1) + mask_tail(m.group(2)), s)
        # chuoi so dai tu 12 chu so tro len (CCCD, so the, so tai khoan)
        s = re.sub(r'(?<!\d)(\d{12,25})(?!\d)', lambda m: mask_tail(m.group(1)), s)
    except Exception:
        return "<loi khi che thong tin nhay cam>"
    return s


# ==========================================================================
#  NHAT KY  (yeu cau muc 1-4)
# ==========================================================================
class NhatKy:
    def __init__(self, path, old_path, max_bytes):
        self.path = path
        self.old_path = old_path
        self.max_bytes = max_bytes
        self.lock = threading.Lock()

    def _rotate_if_needed(self):
        try:
            if os.path.exists(self.path) and os.path.getsize(self.path) > self.max_bytes:
                if os.path.exists(self.old_path):
                    os.remove(self.old_path)
                os.rename(self.path, self.old_path)
                self._raw("[HE THONG] File nhat ky cu da doi ten thanh nhat-ky-cu.txt, bat dau file moi.")
        except Exception:
            pass  # khong duoc de viec ghi nhat ky lam chet tool

    def _raw(self, line):
        try:
            stamp = datetime.now().strftime("[%d/%m/%Y %H:%M:%S]")
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(stamp + " " + line.rstrip("\n") + "\n")
        except Exception:
            try:
                print("Khong ghi duoc nhat ky:", traceback.format_exc()[:300])
            except Exception:
                pass

    def ghi(self, line):
        with self.lock:
            self._rotate_if_needed()
            self._raw(scrub(line))

    def phan_cach(self, tieu_de):
        with self.lock:
            self._rotate_if_needed()
            self._raw("")
            self._raw("=" * 62)
            self._raw("===== " + tieu_de + " =====")
            self._raw("=" * 62)

    def loi(self, mo_ta, exc=None):
        """Ghi day du traceback - khong bao gio de tool chet im lang."""
        with self.lock:
            self._rotate_if_needed()
            self._raw("[LOI] " + scrub(mo_ta))
            try:
                tb = traceback.format_exc() if exc is None else "".join(
                    traceback.format_exception(type(exc), exc, exc.__traceback__))
                for ln in scrub(tb).splitlines():
                    self._raw("       " + ln)
            except Exception:
                self._raw("       (khong lay duoc chi tiet loi)")


LOG = NhatKy(LOG_PATH, LOG_OLD_PATH, LOG_MAX_BYTES)


# ==========================================================================
#  THIET LAP - luu vao cai-dat.json, chinh duoc het qua giao dien
# ==========================================================================
DEFAULT_SETTINGS = {
    "thu_muc_luu": "",
    "mst": "",
    "mat_khau_ma_hoa": "",
    "nho_dang_nhap": True,
    "dinh_dang": ["xml"],         # loai file muon tai: xml va/hoac pdf
    "may_chu_da_chay": "",        # dia chi may chu dung duoc lan truoc
    "duong_tai_da_chay": {},      # duong dan tai xml dung duoc lan truoc
    "duong_pdf_da_chay": {},      # duong dan tai pdf dung duoc lan truoc
    "khong_co_duong_pdf": False,  # may chu khong co san PDF -> tu in
    "tai_khoan": {},              # GD29: KHONG con dung (quy tac 17 - khong luu mat khau); luon rong
    "goi_nho": [],                # GD29: tai khoan goi nho [{"nhan": ten nguoi dung dat, "mst": ...}] - KHONG co mat khau
    "chi_tai_moi": True,          # GD29: bam Tai chi tai hoa don chua co trong phan mem / chua tung tai
    "anthropic_key": "",          # khoa Claude API (tuy chon, GD7)
    "anthropic_model": "claude-sonnet-4-5",
    "hen_gio_cho_phut": 10,       # GD369: chay hen gio - khong ai dang nhap cong thue sau N phut -> ghi moc CHO_NGUOI, tat tool
    "tls_khong_kiem": False,      # GD65: True = BO kiem chung chi TLS may chu thue (chi dat khi may thieu chung chi goc)
}


def _cd_doc_tho(duong):
    """GD63: doc cai-dat.json (utf-8-sig: Notepad hay luu kem BOM). -> (dict, ok). Tep hong -> giu ban sao .hong-<ngay>."""
    if not os.path.exists(duong):
        return {}, True
    try:
        with open(duong, "r", encoding="utf-8-sig") as f:
            d = json.load(f)
        return (d if isinstance(d, dict) else {}), isinstance(d, dict)
    except Exception:
        try:
            import shutil
            shutil.copy2(duong, duong + ".hong-" + datetime.now().strftime("%Y%m%d%H%M%S"))
        except Exception:
            pass
        return {}, False


def _cd_ghi_gop(duong, thay_doi, xoa=()):
    """GD63: doc lai tep HIEN TAI, chi doi / xoa cac khoa cua tool nay roi ghi tam + os.replace (khong xoa khoa tool khac)."""
    hien, _ok = _cd_doc_tho(duong)
    hien.update(thay_doi)
    for k in xoa:
        hien.pop(k, None)
    tam = duong + ".%d.tmp" % os.getpid()
    with open(tam, "w", encoding="utf-8") as f:
        json.dump(hien, f, ensure_ascii=False, indent=1)
    os.replace(tam, duong)
    return hien


_CD_GOC = {}          # GD63: ban da doc luc mo tool - de chi ghi khoa tool NAY doi


def doc_thiet_lap():
    s = dict(DEFAULT_SETTINGS)
    d, ok = _cd_doc_tho(SETTINGS_PATH)
    if not ok:
        LOG.loi("Khong doc duoc file cai-dat.json (da giu ban sao .hong), dung thiet lap mac dinh.")
    s.update(d)
    _CD_GOC.clear()
    _CD_GOC.update(json.loads(json.dumps(s, ensure_ascii=False)))
    # GD29 - quy tac 17: khong luu mat khau. Mat khau (da giau bang base64 - khong phai ma hoa)
    # tung luu o ban truoc bi xoa ngay lan chay dau tien.
    if s.get("mat_khau_ma_hoa") or s.get("tai_khoan"):
        s["mat_khau_ma_hoa"] = ""
        s["tai_khoan"] = {}
        try:
            _cd_ghi_gop(SETTINGS_PATH, {"mat_khau_ma_hoa": "", "tai_khoan": {}})
            LOG.ghi("[THIET LAP] GD29: da xoa mat khau luu o ban truoc khoi cai-dat.json (quy tac khong luu mat khau).")
        except Exception:
            LOG.loi("Khong ghi lai duoc cai-dat.json sau khi xoa mat khau.")
    return s


_CD_KHOA = threading.Lock()


def luu_thiet_lap(s):
    """GD63: chi ghi cac khoa tool nay DA DOI so voi luc doc (gop vao tep hien tai, co khoa luong) - truoc day ghi DE ca tep
       bang ban doc luc mo tool -> mat thay doi cua tool HTKK / DVC / so phu trong luc dang mo."""
    try:
        with _CD_KHOA:
            doi = {k: v for k, v in s.items() if _CD_GOC.get(k, object()) != v}
            if doi:
                _cd_ghi_gop(SETTINGS_PATH, doi)
                _CD_GOC.update(json.loads(json.dumps(doi, ensure_ascii=False)))
    except Exception:
        LOG.loi("Khong luu duoc file cai-dat.json.")


def giau(text):
    try:
        return base64.b64encode(text.encode("utf-8")).decode("ascii")
    except Exception:
        return ""


def hien(text):
    try:
        return base64.b64decode(text.encode("ascii")).decode("utf-8")
    except Exception:
        return ""


SETTINGS = doc_thiet_lap()


# ==========================================================================
#  TICH HOP UNESCO XI  - tham so dong lenh, thu muc theo khach, xuat JSONL
# ==========================================================================
UNESCO = {"bat": False, "mdb": "", "mst": "", "huong": "", "tu": "", "den": "",
          "out": "", "nhap": "", "kiemtra": "", "tudong": False, "goi_ai": "", "excel": False, "hengio": False,
          "luu": "", "huvisoft": "", "mst_them": [],          # mst_them: dot 4 (18/11/2026) MST chi nhanh so nay nhan HD (/mst_them:)
          "nhung": 0}          # 26/11/2026: /nhung:<cong> = cong go loi cua cua so nhung (WebView2) do UNESCO XII mo; 0 = tu mo Chrome nhu truoc


def _tach_dong_lenh(s):
    """Tach chuoi tham so thanh danh sach, ton trong dau nhay kep."""
    kq, cur, trong = [], "", False
    for ch in s:
        if ch == '"':
            trong = not trong
            cur += ch
        elif ch in " \t\r\n" and not trong:
            if cur:
                kq.append(cur)
                cur = ""
        else:
            cur += ch
    if cur:
        kq.append(cur)
    return kq


THAM_SO_LOI = []   # GD63: /thamso khong doc duoc -> thoat, khong mo giao dien an duoi pythonw


def mo_rong_tham_so(argv):
    """GD15: /thamso:"<file UTF-8>" -> doc file roi tach thanh cac tham so that.
       VB6 goi tool bang ShellExecute (ANSI) nen duong dan co dau tieng Viet
       (vi du "bang luong 2026.xlsx") bi doi thanh dau hoi neu truyen thang tren dong lenh."""
    out = []
    for a in argv:
        s = str(a).strip()
        if s.lower().startswith("/thamso:"):
            duong = s.split(":", 1)[1].strip().strip('"')
            try:
                with io.open(duong, "r", encoding="utf-8") as f:
                    out.extend(_tach_dong_lenh(f.read()))
            except Exception as e:
                THAM_SO_LOI.append("%s: %s" % (duong, e))      # GD63
                try:
                    print("Khong doc duoc file tham so %s: %s" % (duong, e))
                except Exception:
                    pass
        else:
            out.append(a)
    return out


def unesco_doc_tham_so(argv):
    """/unesco:"C:\\..\\3S.MDB" /mst:0319318647 /huong:mua /tu:2026-09-01 /den:2026-09-30 ..."""
    for a in argv[1:]:
        a = a.strip()
        if not a.startswith("/"):
            continue
        if ":" in a:
            k, v = a[1:].split(":", 1)
        else:
            k, v = a[1:], ""
        k = k.lower().strip()
        v = v.strip().strip('"')
        if k == "unesco":
            UNESCO["mdb"] = v; UNESCO["bat"] = True
        elif k == "mst":
            UNESCO["mst"] = re.sub(r"[^0-9\-]", "", v)
        elif k == "mst_them":
            # dot 4 (chu quyet 18/11/2026): MST chi nhanh ma ke toan khai «so nay nhan HD» (Ho so khach hang, HSK_MST_NhanThem)
            UNESCO["mst_them"] = [x for x in (re.sub(r"\D", "", t) for t in re.split(r"[,;\s]+", v)) if len(x) >= 10]
        elif k == "huong":
            UNESCO["huong"] = v.lower() if v.lower() in ("mua", "ban", "ca") else "ca"
        elif k == "tu":
            UNESCO["tu"] = v
        elif k == "den":
            UNESCO["den"] = v
        elif k == "out":
            UNESCO["out"] = v
        elif k == "nhap":
            UNESCO["nhap"] = v; UNESCO["bat"] = True
        elif k == "kiemtra":
            UNESCO["kiemtra"] = v
        elif k == "tudong":
            UNESCO["tudong"] = True
        elif k == "excel":
            UNESCO["excel"] = True
        elif k == "luu":
            # thu muc luu file hoa don tai ve (HDDTTAIVE\<TEN CONG TY>\<yyyy-mm>) do phan mem truyen sang
            UNESCO["luu"] = v
        elif k == "hengio":
            # chay theo lich Windows: tu dong, khoang ngay = dau thang (<= ngay 5: dau thang truoc) -> hom nay
            UNESCO["hengio"] = True; UNESCO["tudong"] = True
            hom_nay = datetime.now()
            dau = hom_nay.replace(day=1)
            if hom_nay.day <= 5:
                dau = (dau - timedelta(days=1)).replace(day=1)
            UNESCO["tu"] = dau.strftime("%Y-%m-%d"); UNESCO["den"] = hom_nay.strftime("%Y-%m-%d")
        elif k == "huvisoft":
            # GD344: thu muc goc huvisoft-vao (tep tai tu app.huvisoft.com nam trong <goc>\<MST>)
            UNESCO["huvisoft"] = v; UNESCO["bat"] = True
        elif k == "goi_ai":
            UNESCO["goi_ai"] = v; UNESCO["bat"] = True
        elif k == "nhung":
            # 26/11/2026: UNESCO XII da mo trang thue trong cua so nhung (WebView2, ho so rieng theo MST) va cho cong go loi
            #   127.0.0.1:<cong>. Tool KHONG mo Chrome: noi vao cua so do dung nhu noi vao Chrome (CDP), loi tai giu nguyen.
            try:
                c = int(re.sub(r"\D", "", v) or 0)
            except Exception:
                c = 0
            UNESCO["nhung"] = c if 1024 <= c <= 65535 else 0
    if UNESCO["bat"] and not UNESCO["out"]:
        goc = os.path.dirname(UNESCO["mdb"]) if UNESCO["mdb"] else BASE_DIR
        UNESCO["out"] = os.path.join(goc, "AIHoaDon", UNESCO["mst"] or "CHUNG")
    return UNESCO


def unesco_thu_muc(ten):
    """xml / pdf / ket-qua trong thu muc cua khach; tu tao.
    Neu phan mem truyen /luu: thi FILE HOA DON (xml, pdf, excel) luu vao thu muc do
    (HDDTTAIVE\\<TEN CONG TY>\\<yyyy-mm>); rieng ket-qua van nam trong thu muc du lieu."""
    if ten == "xml" and UNESCO.get("luu"):
        d = UNESCO["luu"]
    else:
        d = os.path.join(UNESCO["out"], ten)
    try:
        os.makedirs(d, exist_ok=True)
    except Exception as e:
        LOG.loi("Khong tao duoc thu muc " + d, e)
    return d


def unesco_ap_dung_thiet_lap():
    """Goi sau khi doc cai-dat.json: dien MST, mat khau theo MST, thu muc luu."""
    if not UNESCO["bat"]:
        return
    if UNESCO["mst"]:
        SETTINGS["mst"] = UNESCO["mst"]
        SETTINGS["mat_khau_ma_hoa"] = ""
        SETTINGS["nho_dang_nhap"] = True
    SETTINGS["thu_muc_luu"] = unesco_thu_muc("xml")
    unesco_thu_muc("pdf"); unesco_thu_muc("ket-qua")
    SETTINGS["dinh_dang"] = ["xml"]
    LOG.ghi("[UNESCO] MDB: %s | MST: %s | huong: %s | tu %s den %s | out: %s | tudong: %s"
            % (UNESCO["mdb"], mask_tail(UNESCO["mst"]) if UNESCO["mst"] else "", UNESCO["huong"],
               UNESCO["tu"], UNESCO["den"], UNESCO["out"], UNESCO["tudong"]))


TEN_TTHAI = {"1": "Hóa đơn mới", "2": "Hóa đơn thay thế", "3": "Hóa đơn điều chỉnh",
             "4": "Hóa đơn đã bị thay thế", "5": "Hóa đơn đã bị điều chỉnh", "6": "Hóa đơn đã bị hủy"}


def _so_an_toan(v):
    try:
        if v is None or v == "":
            return 0.0
        return float(str(v).replace(",", ""))
    except Exception:
        return 0.0


def unesco_so_hd(shd):
    """So hoa don chuan: bo so 0 dau ("0000498" -> "498") de XML va JSON tra cuu cho cung mot khoa."""
    s = str(shd or "").strip()
    if s.isdigit():
        s = s.lstrip("0") or "0"
    return s


def unesco_mst_so(v):
    """Chi giu chu so cua MST (bo '-', khoang trang)."""
    return re.sub(r"\D", "", str(v or ""))


def unesco_hd_thuoc_cty(mst_ban, mst_mua):
    """GD43: hoa don co NGUOI BAN hoac NGUOI MUA la cong ty cua bo so dang mo? Bo so chua khai MST -> coi la thuoc."""
    so = unesco_mst_so(UNESCO.get("mst"))
    if not UNESCO.get("bat") or not so:
        return True
    cua_so = {so} | set(UNESCO.get("mst_them") or [])          # dot 4: + MST chi nhanh so nay nhan HD (ke toan khai)
    return unesco_mst_so(mst_ban) in cua_so or unesco_mst_so(mst_mua) in cua_so


def unesco_loi_khac_mst(mst_dang_nhap=None):
    """GD43: tai khoan dang dang nhap co phai MST cua bo so? Tra ve chuoi loi (rong = hop le)."""
    if not UNESCO.get("bat"):
        return ""
    so = unesco_mst_so(UNESCO.get("mst"))
    dn = unesco_mst_so(mst_dang_nhap if mst_dang_nhap is not None else STATE.get("mst"))
    if not so or so == dn:
        return ""
    if not dn:
        if not STATE.get("token"):
            return ""          # chua dang nhap: cac buoc sau tu bao 'can dang nhap truoc'
        # P0 18/11/2026: co phien ma KHONG doc duoc MST -> khong mac dinh la dung cong ty
        return ("Không đọc được MST của tài khoản đang đăng nhập cổng thuế, nên tool KHÔNG xác nhận được đây là công ty của "
                "bộ sổ đang mở (MST %s). Tool chưa tra cứu / tải để hoá đơn của công ty khác không bị ghi vào sổ này. "
                "Đăng xuất trên trang thuế rồi đăng nhập lại đúng tài khoản; nếu vẫn báo, gửi tệp nhat-ky.txt cho người quản trị." % so)
    return ("Tài khoản đang đăng nhập là MST %s, nhưng bộ sổ đang mở trong UNESCO là MST %s (CÔNG TY KHÁC). "
            "Tool KHÔNG tra cứu / tải để hoá đơn của công ty khác không bị ghi vào sổ này. "
            "Đóng cửa sổ này, mở đúng bộ sổ (hoặc đăng nhập đúng MST của bộ sổ) rồi tải lại." % (dn, so))


def unesco_bao_khac_mst(noi_dung):
    """Ghi ket-qua\\KHAC_MST de VB6 hien thong bao (VB6 doc xong tu xoa)."""
    LOG.ghi("[UNESCO] KHAC MST: " + noi_dung)
    try:
        with open(os.path.join(unesco_thu_muc("ket-qua"), "KHAC_MST"), "w", encoding="utf-8") as f:
            f.write(noi_dung)
    except Exception:
        pass


def unesco_mst_khoa(v):
    """Dot 4 (chu quyet 18/11/2026 «chuan hoa, doc kep»): MST trong khoa hoa don ve MOT dang: 13 so -> '0123456789-001',
    10 / 12 so (MST / so dinh danh) -> chi chu so; dang la (co chu) -> giu nguyen sau khi bo khoang trang dau cuoi.
    Do tren 222 so (1.283 khoa dang co): dang chuan nay TRUNG khoa cu o moi dong -> khong lech voi du lieu da nhap."""
    s = str(v or "").strip()
    so = re.sub(r"\D", "", s)
    if not re.fullmatch(r"[0-9\s.\-]*", s):
        return s
    if len(so) == 13:
        return so[:10] + "-" + so[10:]
    if len(so) in (10, 12):
        return so
    return s


def unesco_khoa(mst_ban, khms, khhd, shd):
    """Khoa hoa don 'MST ban|mau so|ky hieu|so HD'. Dot 4 (18/11/2026): MST chuan (unesco_mst_khoa), ky hieu bo khoang trang + viet hoa
    (nhu NormalizeSymbol cua VB) - cung mot hoa don tu cong / XML / Excel luon cung mot khoa."""
    return "%s|%s|%s|%s" % (unesco_mst_khoa(mst_ban), str(khms or "").strip(),
                            re.sub(r"\s+", "", str(khhd or "")).upper(), unesco_so_hd(shd))


def _ten_nguoi_mua(ten_don_vi, ten_nguoi):
    """GD60: nguoi mua la CA NHAN: XML khong co <NMua><Ten> (ten don vi), chi co <HVTNMHang> (ho ten nguoi mua hang)
       -> lay ho ten nguoi mua. Co ten don vi thi giu ten don vi (nguoi mua hang cua cong ty chi la nguoi nhan)."""
    return (str(ten_don_vi or "").strip() or str(ten_nguoi or "").strip())


def unesco_dong_tu_xml(hd, huong, kind, hd_cong=None, tep_xml=""):
    """hd = ket qua doc_xml_hoa_don. Tra ve danh sach dong (moi dong hang = 1 dong JSONL)."""
    hd_cong = hd_cong or {}
    tthai = str(hd_cong.get("tthai") or "")
    ttxly = str(hd_cong.get("ttxly") or "")
    mst_login = UNESCO["mst"]
    chung = {
        "KyHieuMauSo": hd["mau_so"], "KyHieuHoaDon": hd["ky_hieu"], "SoHoaDon": unesco_so_hd(hd["so_hd"]),
        "NgayLap": (hd["ngay_lap"] or "")[:10],
        "NgayNguoiBanKySo": ngay_vn(hd_cong.get("nky")) if hd_cong else "",         # GD94: gio VN
        "MCCQT": hd["mccqt"],
        "NgayCQTKySo": ngay_vn(hd_cong.get("ncma")) if hd_cong else "",
        "DonViTienTe": hd["don_vi_tien"] or "VND", "TyGia": hd["ty_gia"] or 1,
        "TenNguoiBanNguoiXuatHang": hd["nban_ten"], "MSTNguoiBanNguoiXuatHang": hd["nban_mst"],
        "DiaChiNguoiBan": hd["nban_dchi"],
        "TenNguoiMuaNguoiNhanHang": _ten_nguoi_mua(hd["nmua_ten"], hd.get("nmua_nguoi")), "MSTNguoiMuaNguoiNhanHang": hd["nmua_mst"],   # GD60
        "DiaChiNguoiMua": hd["nmua_dchi"],
        "TongTienChietKhauThuongMai": hd["chiet_khau"], "TongTienPhi": 0,
        "TongTienThanhToan": hd["thanh_toan"],
        "TrangThaiHoaDon": TEN_TTHAI.get(tthai, "Hóa đơn mới" if not tthai else tthai),
        "KetQuaKiemTraHoaDon": TEN_TTXLY.get(ttxly, "" if not ttxly else ttxly),
        "XML": True, "HDBanRa": (huong == "ban"), "MaSoLoaiCT": "8" if huong == "ban" else "1",
        "MSTLogin": STATE.get("mst") or mst_login,
        "khoa": unesco_khoa(hd["nban_mst"], hd["mau_so"], hd["ky_hieu"], hd["so_hd"]),
        "huong": huong, "tep_xml": tep_xml, "tthai": tthai, "ttxly": ttxly,
        "mtt": (kind == "mtt"), "loai_hd": hd.get("loai_hd", ""), "httt": hd.get("hinh_thuc_tt", ""),
        "lien_quan": hd.get("lien_quan") or None,
        "tong_chua_thue": hd["chua_thue"], "tong_thue": hd["tien_thue"],
    }
    dong = []
    hang = [h for h in hd["hang_hoa"] if str(h.get("tchat_ma", "1")) != "4"]
    if not hang:  # hoa don khong co dong hang (vi du MTT tong hop) -> 1 dong tong
        hang = [{"stt": "1", "tchat_ma": "1", "ma_hang": "", "ten_hang": hd.get("ghi_chu_dong") or "Hàng hóa, dịch vụ",
                 "dvt": "", "so_luong": 0, "don_gia": 0, "chiet_khau": 0,
                 "thanh_tien": hd["chua_thue"], "thue_suat": (hd["thue_suat"][0]["thue_suat"] if hd["thue_suat"] else ""),
                 "tien_thue": hd["tien_thue"]}]
    n_dong = len(hang)
    for i, h in enumerate(hang):
        ts = str(h.get("thue_suat") or "")
        tien_thue = h.get("tien_thue")
        if tien_thue is None:
            # phan bo tien thue theo thue suat cua dong; dong cuoi don phan lech
            tien_thue = 0.0
            m = re.search(r"(\d+(?:[\.,]\d+)?)\s*%", ts)
            if m:
                tien_thue = round(_so_an_toan(h.get("thanh_tien")) * _so_an_toan(m.group(1).replace(",", ".")) / 100.0)
        d = dict(chung)
        d.update({
            "stt_dong": i + 1, "so_dong": n_dong,
            "tchat": str(h.get("tchat_ma") or "1"),
            "MaVT": h.get("ma_hang", ""), "TenHangHoaDichVu": h.get("ten_hang", ""),
            "DonViTinh": h.get("dvt", ""), "SoLuong": h.get("so_luong", 0), "DonGia": h.get("don_gia", 0),
            "ChietKhau": h.get("chiet_khau", 0), "ThueSuat": ts,
            "ThanhTienChuaThue": h.get("thanh_tien", 0), "TienThue": tien_thue,
            "giam2": ts.upper().startswith("KHAC"),
        })
        dong.append(d)
    # don lech tien thue tong ve dong cuoi (neu XML co tong thue)
    try:
        tong = sum(_so_an_toan(x["TienThue"]) for x in dong)
        lech = _so_an_toan(hd["tien_thue"]) - tong
        if dong and abs(lech) >= 1 and abs(lech) < 1000 * n_dong:
            dong[-1]["TienThue"] = _so_an_toan(dong[-1]["TienThue"]) + lech
    except Exception:
        pass
    return dong


def unesco_dong_tu_cong(hd, huong, kind):
    """Khong tai duoc XML: dung ket qua tra cuu cua cong thue (1 dong tong)."""
    tdlap = ngay_vn(hd.get("tdlap"))         # GD94: gio VN (truoc day lui 1 ngay - HD khong XML ghi ngay 31/08 thay 01/09)
    tthai = str(hd.get("tthai") or ""); ttxly = str(hd.get("ttxly") or "")
    return [{
        "KyHieuMauSo": str(hd.get("khmshdon") or ""), "KyHieuHoaDon": hd.get("khhdon") or "",
        "SoHoaDon": unesco_so_hd(hd.get("shdon")), "NgayLap": tdlap,
        "NgayNguoiBanKySo": ngay_vn(hd.get("nky")), "MCCQT": hd.get("mhdon") or "",
        "NgayCQTKySo": ngay_vn(hd.get("ncma")), "DonViTienTe": hd.get("dvtte") or "VND",
        "TyGia": _so_an_toan(hd.get("tgia")) or 1,
        "TenNguoiBanNguoiXuatHang": hd.get("nbten") or "", "MSTNguoiBanNguoiXuatHang": hd.get("nbmst") or "",
        "DiaChiNguoiBan": hd.get("nbdchi") or "",
        "TenNguoiMuaNguoiNhanHang": _ten_nguoi_mua(hd.get("nmten"), hd.get("nmtnmua") or hd.get("nmtnhang") or hd.get("nmhvtnmhang")),   # GD60
        "MSTNguoiMuaNguoiNhanHang": hd.get("nmmst") or "",
        "DiaChiNguoiMua": hd.get("nmdchi") or "",
        "MaVT": "", "TenHangHoaDichVu": "", "DonViTinh": "", "SoLuong": 0, "DonGia": 0, "ChietKhau": 0,
        "ThueSuat": "", "ThanhTienChuaThue": _so_an_toan(hd.get("tgtcthue")), "TienThue": _so_an_toan(hd.get("tgtthue")),
        "TongTienChietKhauThuongMai": _so_an_toan(hd.get("ttcktmai")), "TongTienPhi": 0,
        "TongTienThanhToan": _so_an_toan(hd.get("tgtttbso")),
        "TrangThaiHoaDon": TEN_TTHAI.get(tthai, tthai), "KetQuaKiemTraHoaDon": TEN_TTXLY.get(ttxly, ttxly),
        "XML": False, "HDBanRa": (huong == "ban"), "MaSoLoaiCT": "8" if huong == "ban" else "1",
        "MSTLogin": STATE.get("mst") or UNESCO["mst"],
        "khoa": unesco_khoa(hd.get("nbmst"), hd.get("khmshdon"), hd.get("khhdon"), hd.get("shdon")),
        "huong": huong, "tep_xml": "", "tthai": tthai, "ttxly": ttxly, "mtt": (kind == "mtt"),
        "loai_hd": "", "httt": hd.get("thtttoan") or "", "lien_quan": None,
        "tong_chua_thue": _so_an_toan(hd.get("tgtcthue")), "tong_thue": _so_an_toan(hd.get("tgtthue")),
        "stt_dong": 1, "so_dong": 1, "tchat": "1", "giam2": False,
    }]


CHI_TIET_NHO = {}          # GD94: chi tiet dong hang da hoi trong 1 lan tai (JSONL + Excel khong hoi cong 2 lan)


def unesco_chi_tiet_tu_cong(hd, kind):
    """Hoa don khong co XML goc: hoi cong thue chi tiet dong hang (/query/invoices/detail).
    Tra ve danh sach dong hang (list dict cua cong) hoac None. GD94: nho ket qua trong lan tai; cong dang chan -> khong hoi."""
    k = khoa_cua(hd)
    if k in CHI_TIET_NHO:
        return CHI_TIET_NHO[k]
    if not STATE.get("may_chu") or not STATE.get("token") or LY_DO_TAI.get("bi_chan"):
        return None
    CHI_TIET_NHO[k] = _chi_tiet_hoi_cong(hd, kind)
    return CHI_TIET_NHO[k]


def _chi_tiet_hoi_cong(hd, kind):
    duong = "/sco-query/invoices/detail" if kind == "mtt" else "/query/invoices/detail"
    params = {"nbmst": hd.get("nbmst") or "", "khhdon": hd.get("khhdon") or "",
              "shdon": hd.get("shdon") or "", "khmshdon": hd.get("khmshdon") or ""}
    kq = goi_mang_kien_nhan(STATE["may_chu"] + duong + "?" + urllib.parse.urlencode(params), token=STATE["token"], timeout=60)
    if not kq.ok:
        LOG.ghi("[CHI TIET] Khong lay duoc chi tiet HD %s/%s tu cong: %s" % (params["khhdon"], params["shdon"], (kq.loi or "")[:120]))
        return None
    j = kq.json() or {}
    ds = j.get("hdhhdvu") or j.get("chitiet") or []
    if not isinstance(ds, list) or not ds:
        LOG.ghi("[CHI TIET] Cong thue tra ve khong co dong hang cho HD %s/%s" % (params["khhdon"], params["shdon"]))
        return None
    LOG.ghi("[CHI TIET] Lay duoc %d dong hang cua HD %s/%s tu cong thue (khong co XML)" % (len(ds), params["khhdon"], params["shdon"]))
    return ds


def unesco_dong_tu_chi_tiet(hd, ds, huong, kind):
    """Ket hop dau HD (tra cuu) + dong hang (chi tiet cong thue) -> cac dong JSONL, giong dong tu XML."""
    dau = unesco_dong_tu_cong(hd, huong, kind)[0]
    dong = []
    hang = [h for h in ds if str(h.get("tchat", "1")) != "4"]
    if not hang:
        return [dau]
    n = len(hang)
    for i, h in enumerate(hang):
        ts = str(h.get("ltsuat") or h.get("tsuat") or "")
        if ts and "%" not in ts and ts.replace(".", "").isdigit():
            ts = ts + "%"
        thtien = _so_an_toan(h.get("thtien"))
        tthue = h.get("tthue")
        if tthue is None:
            tthue = 0.0
            m = re.search(r"(\d+(?:[\.,]\d+)?)\s*%", ts)
            if m:
                tthue = round(thtien * _so_an_toan(m.group(1).replace(",", ".")) / 100.0)
        d = dict(dau)
        d.update({
            "stt_dong": i + 1, "so_dong": n, "tchat": str(h.get("tchat") or "1"),
            "MaVT": h.get("mhhdvu") or "", "TenHangHoaDichVu": h.get("ten") or "",
            "DonViTinh": h.get("dvtinh") or "", "SoLuong": _so_an_toan(h.get("sluong")),
            "DonGia": _so_an_toan(h.get("dgia")), "ChietKhau": _so_an_toan(h.get("stckhau")),
            "ThueSuat": ts, "ThanhTienChuaThue": thtien, "TienThue": _so_an_toan(tthue),
            "giam2": ts.upper().startswith("KHAC"),
        })
        dong.append(d)
    try:
        tong = sum(_so_an_toan(x["TienThue"]) for x in dong)
        lech = _so_an_toan(dau.get("tong_thue")) - tong
        if abs(lech) >= 1 and abs(lech) < 1000 * n:
            dong[-1]["TienThue"] = _so_an_toan(dong[-1]["TienThue"]) + lech
    except Exception:
        pass
    return dong


def unesco_ghi_jsonl(cac_dong, nhan):
    """Ghi ket-qua\\hddt_<MST>_<ts>_<nhan>.jsonl + _tong.json. Tra ve duong dan."""
    kq = unesco_thu_muc("ket-qua")
    ts = datetime.now().strftime("%Y%m%d%H%M%S")
    ten = "hddt_%s_%s_%s" % (UNESCO["mst"] or "CHUNG", ts, nhan)
    lan = 2
    while os.path.exists(os.path.join(kq, ten + ".jsonl")):       # GD91: khong ghi de tep cung ten (cung giay)
        ten = "hddt_%s_%s_%s_%d" % (UNESCO["mst"] or "CHUNG", ts, nhan, lan)
        lan += 1
    duong = os.path.join(kq, ten + ".jsonl.tmp")
    so_hd = set()
    tong = {"so_dong": 0, "tong_chua_thue": 0.0, "tong_thue": 0.0, "tong_tt": 0.0, "loi": []}
    with open(duong, "w", encoding="utf-8") as f:
        for d in cac_dong:
            f.write(json.dumps(d, ensure_ascii=False) + "\n")
            tong["so_dong"] += 1
            if d["khoa"] not in so_hd:
                so_hd.add(d["khoa"])
                tong["tong_chua_thue"] += _so_an_toan(d.get("tong_chua_thue"))
                tong["tong_thue"] += _so_an_toan(d.get("tong_thue"))
                tong["tong_tt"] += _so_an_toan(d.get("TongTienThanhToan"))
    tong["so_hd"] = len(so_hd)
    cuoi = duong[:-4]
    os.replace(duong, cuoi)   # doi ten sau khi ghi xong -> VB6 khong doc file dang ghi do
    with open(os.path.join(kq, ten + "_tong.json"), "w", encoding="utf-8") as f:
        json.dump(tong, f, ensure_ascii=False, indent=2)
    try:
        with open(os.path.join(kq, "DA_XONG"), "w", encoding="utf-8") as f:
            f.write(cuoi)
    except Exception:
        pass
    LOG.ghi("[UNESCO] Da ghi %s: %d hoa don, %d dong, tong TT %.0f"
            % (os.path.basename(cuoi), tong["so_hd"], tong["so_dong"], tong["tong_tt"]))
    return cuoi


# GD234: cong G1 "day du" - nho DANH SACH HOA DON CONG THUE tra ve (nguon doc lap de doi chieu voi so: day_du_hd.py / K39-K40)
#   <thu muc du lieu>\ds-cqt.txt  TAB: khoa, huong, kind, ngay, tthai, tong_tt, khoa_goc, loai_lq, luc  (gop theo khoa, ban moi thay ban cu)
def _goc_tu_cong(hd):
    """HD thay the / dieu chinh: khoa HD goc tu dong danh sach cong (neu cong co tra cac truong HD goc)."""
    sh = hd.get("shdgoc") or hd.get("shdclquan") or ""
    if not sh:
        return ""
    return unesco_khoa(hd.get("nbmst"), hd.get("khmshdgoc") or hd.get("khmshdclquan") or "", hd.get("khhdgoc") or hd.get("khhdclquan") or "", sh)


def ghi_ds_cqt(danh_sach, thu_thap, direction, kind):
    try:
        d = os.path.join(_thu_muc_du_lieu(), "ds-cqt.txt")
        cu = {}
        if os.path.exists(d):
            with open(d, "r", encoding="utf-8-sig") as f:
                for dong in f:
                    p = dong.rstrip("\r\n").split("\t")
                    if p and p[0]:
                        cu[p[0]] = dong.rstrip("\r\n")
        lq = {}
        for hd in (thu_thap or []):
            l = hd.get("lien_quan") or None
            if l and l.get("shd"):
                lq[unesco_khoa(hd.get("nban_mst"), hd.get("mau_so"), hd.get("ky_hieu"), hd.get("so_hd"))] = (
                    unesco_khoa(hd.get("nban_mst"), l.get("khms"), l.get("khhd"), l.get("shd")), str(l.get("loai") or ""))
        luc = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        n = 0
        for hd in (danh_sach or []):
            if not unesco_hd_thuoc_cty(hd.get("nbmst"), hd.get("nmmst")):
                continue
            k = unesco_khoa(hd.get("nbmst"), hd.get("khmshdon"), hd.get("khhdon"), hd.get("shdon"))
            goc, loai = lq.get(k) or (_goc_tu_cong(hd), "")
            cu[k] = "\t".join(str(x).replace("\t", " ").replace("\n", " ") for x in (
                k, direction, kind, ngay_vn(hd.get("tdlap")), str(hd.get("tthai") or ""), _so_an_toan(hd.get("tgtttbso")), goc, loai, luc,
                _so_an_toan(hd.get("tgtcthue")), _so_an_toan(hd.get("tgtthue"))))          # GD239: chua thue, thue (khop cheo to khai)
            n += 1
        if not n:
            return 0
        with open(d + ".tmp", "w", encoding="utf-8") as f:
            f.write("\n".join(cu[k] for k in sorted(cu)) + "\n")
        os.replace(d + ".tmp", d)
        LOG.ghi("[GD234] ds-cqt.txt: ghi %d hoa don cong thue (%s/%s), tong %d" % (n, direction, kind, len(cu)))
        return n
    except Exception as e:
        LOG.loi("GD234: khong ghi duoc ds-cqt.txt", e)
        return 0


def unesco_xuat_sau_khi_tai(thu_thap, danh_sach, direction, kind, thu_muc, xac_nhan=False):
    """Gop XML da doc + hoa don khong co XML thanh JSONL cho VB6."""
    ghi_ds_cqt(danh_sach, thu_thap, direction, kind)     # GD234
    cong = {}
    for hd in danh_sach:
        cong[unesco_khoa(hd.get("nbmst"), hd.get("khmshdon"), hd.get("khhdon"), hd.get("shdon"))] = hd
    dong, da_co = [], set()
    bo_khac = 0     # GD43: hoa don khong thuoc cong ty cua bo so (dang nhap nham tai khoan cong ty khac)
    c_bl = tai_chua_nhap_bat() if bl_se_giu(direction, xac_nhan) else None        # GD109
    for hd in (thu_thap or []):
        k = unesco_khoa(hd["nban_mst"], hd["mau_so"], hd["ky_hieu"], hd["so_hd"])
        if not unesco_hd_thuoc_cty(hd.get("nban_mst"), hd.get("nmua_mst")):
            bo_khac += 1; da_co.add(k); continue
        tep = hd.get("duong_xml") or os.path.join(thu_muc, hd.get("ten_file") or "")     # GD94: noi that cua file XML
        dong.extend(unesco_dong_tu_xml(hd, direction, kind, cong.get(k), tep))
        da_co.add(k)
    for k, hd in cong.items():
        if k not in da_co:
            if not unesco_hd_thuoc_cty(hd.get("nbmst"), hd.get("nmmst")):
                bo_khac += 1; continue
            if c_bl is not None and not unesco_mst_so(hd.get("nmmst")) and bl_giu_duoc(k, ngay_vn(hd.get("tdlap")), c_bl):
                ct = None           # GD109: HD ban le se bi giu - khong hoi chi tiet cong (lan gui / tong hop sau moi hoi)
            else:
                ct = unesco_chi_tiet_tu_cong(hd, kind)
            if ct:
                dong.extend(unesco_dong_tu_chi_tiet(hd, ct, direction, kind))
            else:
                dong.extend(unesco_dong_tu_cong(hd, direction, kind))
    if bo_khac:
        unesco_bao_khac_mst("Da BO %d hoa don KHONG thuoc cong ty cua bo so (MST %s): ca nguoi ban lan nguoi mua deu la "
                            "MST khac. Tai khoan dang nhap tai hoa don: %s. Kiem tra lai bo so dang mo va tai khoan dang nhap."
                            % (bo_khac, unesco_mst_so(UNESCO.get("mst")), unesco_mst_so(STATE.get("mst")) or "?"))
    dong = th_loc_thanh_vien(dong, "tai ve")          # GD91
    dong = bl_loc_giu(dong, danh_sach, direction, kind, xac_nhan)       # GD109: khoa HD ban le
    if not dong:
        LOG.ghi("[UNESCO] Khong co dong nao de xuat JSONL.")
        return None
    kq = unesco_ghi_jsonl(dong, direction)
    th_nho_gui([d.get("khoa") for d in dong], kq)     # GD91 + GD116: nho ca ten tep
    return kq


def unesco_nhap_thu_muc(thu_muc):
    """/nhap: doc *.xml va *.zip (invoice.xml ben trong) -> JSONL. Khong can dang nhap."""
    LOG.ghi("[UNESCO] Nhap tu thu muc: " + thu_muc)
    dong, loi = [], []
    if not os.path.isdir(thu_muc):
        LOG.ghi("[UNESCO] Thu muc khong ton tai."); return None
    dich = unesco_thu_muc("xml")
    # Neu thu muc DICH trung voi thu muc DANG DOC thi KHONG chep lai.
    #   Phan mem goi /nhap:<thu muc nguoi dung chon> kem /luu:<cung thu muc do>, ma
    #   unesco_thu_muc("xml") lai tra ve chinh /luu. Truoc day moi lan nhap la moi hoa
    #   don duoc ghi them mot ban sao MANG TEN KHAC (ten_moi dat theo ngay_lap, con ban
    #   tai ve dat theo ngay khac va co kem ten nguoi ban) -> thu muc phinh gap doi va
    #   lan nhap sau doc moi hoa don HAI LAN.
    #   Da thay tren may that ngay 19/09/2026: 20260902_..._00001023_HO-KINH-DOANH-LAN-PHAT.xml
    #   va 20260903_..._00001023.xml la cung mot hoa don.
    tu_chep = os.path.abspath(dich) != os.path.abspath(thu_muc)
    if not tu_chep:
        LOG.ghi("[UNESCO] Thu muc luu trung thu muc dang doc -> khong chep lai ban sao.")
    da_co_khoa = set()
    bo_trung = 0
    bo_khac = 0     # GD43
    for ten in sorted(os.listdir(thu_muc)):
        duong = os.path.join(thu_muc, ten)
        try:
            cac_xml = []
            if ten.lower().endswith(".xml"):
                with open(duong, "rb") as f:
                    cac_xml.append((ten, f.read()))
            elif ten.lower().endswith(".zip"):
                with zipfile.ZipFile(duong) as z:
                    for n in z.namelist():
                        if n.lower().endswith(".xml"):
                            cac_xml.append((os.path.splitext(ten)[0] + "_" + os.path.basename(n), z.read(n)))
            for ten_xml, raw in cac_xml:
                hd = doc_xml_hoa_don(raw, ten_xml)
                if hd is None:
                    loi.append(ten_xml); continue
                if not unesco_hd_thuoc_cty(hd.get("nban_mst"), hd.get("nmua_mst")):
                    bo_khac += 1
                    LOG.ghi("[UNESCO] Bo %s: hoa don KHONG thuoc cong ty cua bo so (ban %s, mua %s)"
                            % (ten_xml, hd.get("nban_mst"), hd.get("nmua_mst")))
                    continue
                cua_so = {re.sub(r"\D", "", UNESCO["mst"])} | set(UNESCO.get("mst_them") or [])          # dot 4: + MST chi nhanh nhan HD
                huong = "mua" if (UNESCO["mst"] and re.sub(r"\D", "", hd["nmua_mst"]) in cua_so) else "ban"
                if UNESCO["huong"] in ("mua", "ban"):
                    huong = UNESCO["huong"]
                # Mot hoa don chi lay MOT lan trong moi lan nhap, du thu muc dang co
                # hai ban sao mang ten khac nhau (xem ghi chu o tren).
                khoa_hd = unesco_khoa(hd["nban_mst"], hd["mau_so"], hd["ky_hieu"], hd["so_hd"])
                if khoa_hd in da_co_khoa:
                    bo_trung += 1
                    LOG.ghi("[UNESCO] Bo ban sao trung: %s (hoa don %s da doc roi)" % (ten_xml, khoa_hd))
                    continue
                da_co_khoa.add(khoa_hd)
                ten_moi = "%s_%s_%s.xml" % (_phan_ten_tep((hd["ngay_lap"] or "")[:10].replace("-", "")), _phan_ten_tep(hd["ky_hieu"]) or "XX",
                                            (_phan_ten_tep(hd["so_hd"]) or "0").zfill(8))          # P1: ten tep khong lay nguyen van tu XML
                if tu_chep:
                    # chep XML vao thu muc xml cua khach de VB6 mo xem duoc
                    d_moi = os.path.join(dich, ten_moi)
                    if not os.path.exists(d_moi):
                        ghi_tep_nguyen_tu(d_moi, raw)          # P1: nguyen tu
                else:
                    d_moi = duong
                    ten_moi = ten
                hd["ten_file"] = ten_moi
                dong.extend(unesco_dong_tu_xml(hd, huong, "dt", None, d_moi))
        except Exception as e:
            LOG.loi("Loi khi nhap file " + ten, e); loi.append(ten)
    dong = th_loc_thanh_vien(dong, "nhap thu muc")    # GD91: HD da nam trong chung tu tong hop ban le
    if bo_trung:
        LOG.ghi("[UNESCO] Da bo %d file la ban sao trung cua hoa don khac trong cung thu muc." % bo_trung)
    if bo_khac:
        unesco_bao_khac_mst("Da BO %d file XML/ZIP: hoa don KHONG thuoc cong ty cua bo so (MST %s) - ca nguoi ban lan "
                            "nguoi mua deu la MST khac. Kiem tra lai bo so dang mo." % (bo_khac, unesco_mst_so(UNESCO.get("mst"))))
    if not dong:
        LOG.ghi("[UNESCO] Khong doc duoc hoa don nao trong thu muc.")
        try:
            with open(os.path.join(unesco_thu_muc("ket-qua"), "DA_XONG"), "w") as f:
                f.write("KHONG_CO_DU_LIEU")
        except Exception:
            pass
        return None
    return unesco_ghi_jsonl(dong, "nhap")


def unesco_huvisoft(goc):
    """GD344: nhan hoa don tai tu Huvisoft qua thu muc (xem huvisoft_vao.py). Khong dang nhap, khong goi mang."""
    if BASE_DIR not in sys.path:
        sys.path.insert(0, BASE_DIR)
    import huvisoft_vao as HV
    nk_dir = os.path.join(UNESCO["out"], "huvisoft")
    try:
        os.makedirs(nk_dir, exist_ok=True)
    except Exception:
        pass

    def ghi(s):
        LOG.ghi(s)
        try:
            with open(os.path.join(nk_dir, "nhat-ky-huvisoft.txt"), "a", encoding="utf-8") as f:
                f.write(datetime.now().strftime("%Y-%m-%d %H:%M:%S") + "  " + s + "\n")
        except Exception:
            pass
    ghi("[HUVISOFT] Bat dau. Thu muc: %s | MST: %s" % (goc, UNESCO.get("mst")))
    try:
        tt = HV.xu_ly(goc, UNESCO.get("mst") or "", UNESCO["out"], unesco_thu_muc("pdf"),
                      unesco_nhap_thu_muc, doc_xml_hoa_don, unesco_khoa, ghi)
        dong = HV.dong_tom_tat(tt)
    except Exception as e:
        LOG.loi("GD344 loi xu ly thu muc Huvisoft", e)
        dong = "LOI|" + str(e)[:200]
    ghi("[HUVISOFT] " + dong)
    try:
        with open(os.path.join(unesco_thu_muc("ket-qua"), "HUVISOFT_TOM_TAT"), "w", encoding="utf-8") as f:
            f.write(dong)
    except Exception:
        pass


def unesco_kiem_tra_trang_thai(duong_ds):
    """/kiemtra: file danh sach moi dong 'khoa<TAB>huong<TAB>ngay'. Can da dang nhap."""
    kq = []
    try:
        with open(duong_ds, "r", encoding="utf-8") as f:
            ds = [l.rstrip("\n").split("\t") for l in f if l.strip()]
    except Exception as e:
        LOG.loi("Khong doc duoc file danh sach kiem tra", e); return None, "Không đọc được file danh sách."
    for phan in ds:
        khoa = phan[0]; huong = phan[1] if len(phan) > 1 else "mua"; ngay = phan[2] if len(phan) > 2 else ""
        if th_la_khoa_ct(khoa):
            continue            # GD91: chung tu tong hop ban le - khong co tren cong thue
        mst_ban, khms, khhd, shd = (khoa.split("|") + ["", "", "", ""])[:4]
        p = {"kind": "dt", "direction": huong, "tu_ngay": ngay or "2020-01-01", "den_ngay": ngay or datetime.now().strftime("%Y-%m-%d"),
             "ky_hieu": khhd, "so_hoa_don": shd, "mau_so": khms,
             "khong_chia": True}   # GD20: tim theo so hoa don - chia doan chi lam cham gap hang chuc lan
        rows, loi = tra_cuu(p)
        if loi:
            return None, loi
        if not rows:
            p["kind"] = "mtt"; rows, loi = tra_cuu(p)
        for hd in (rows or []):
            if str(hd.get("nbmst") or "") != mst_ban and mst_ban:
                continue
            kq.append({"khoa": khoa, "huong": huong, "tthai": str(hd.get("tthai") or ""), "ttxly": str(hd.get("ttxly") or ""),
                       "TrangThaiHoaDon": TEN_TTHAI.get(str(hd.get("tthai") or ""), ""),
                       "KetQuaKiemTraHoaDon": TEN_TTXLY.get(str(hd.get("ttxly") or ""), ""), "chi_kiem_tra": True})
    if not kq:
        return None, "Không tìm thấy hóa đơn nào trên cổng theo danh sách."
    return unesco_ghi_jsonl(kq, "kiemtra"), None


# ---------------------------------------------------------------- Claude API (tuy chon, GD7)
def unesco_goi_claude(duong_vao):
    """Doc can_goi_ai.jsonl, goi Claude, ghi ket_qua_ai_<ts>.jsonl + DA_XONG_AI. Khong gui mat khau."""
    key = SETTINGS.get("anthropic_key", "")
    model = SETTINGS.get("anthropic_model") or "claude-sonnet-4-5"
    kq_dir = unesco_thu_muc("ket-qua")
    ket = []
    if not key:
        LOG.ghi("[AI] Chua co khoa Claude API - bo qua.")
    else:
        try:
            with open(duong_vao, "r", encoding="utf-8") as f:
                dong = []
                for l in f:
                    if not l.strip():
                        continue
                    try:
                        dong.append(json.loads(l))
                    except ValueError:
                        # GD96: phan mem cu ghi so dang "65000." (Format VB6) - sua roi doc lai, khong bo ca tep
                        dong.append(json.loads(re.sub(r"(\d)\.(?=\s*[,}\]])", r"\1", l)))
        except Exception as e:
            LOG.loi("Khong doc duoc file can_goi_ai", e); dong = []
        he_thong = ("Bạn là kế toán Việt Nam. Với mỗi mặt hàng trên hóa đơn, trả về JSON mảng, mỗi phần tử: "
                    '{"khoa":..., "stt_dong":..., "tinh_chat": "HH|NVL|CCDC|TSCD|DV", '
                    '"ma_goi_y": mã trong danh sách ung_vien hoặc null, "tk_no_goi_y": số hiệu TK Nợ gợi ý, '
                    '"do_tin_cay": 0-100, "ly_do": "ngắn gọn"}. Chỉ trả JSON, không giải thích.')
        for i in range(0, len(dong), 20):
            lo = dong[i:i + 20]
            body = {"model": model, "max_tokens": 4000, "system": he_thong,
                    "messages": [{"role": "user", "content": json.dumps(lo, ensure_ascii=False)}]}
            ok = False
            for lan in range(3):
                try:
                    req = urllib.request.Request("https://api.anthropic.com/v1/messages",
                                                 data=json.dumps(body).encode("utf-8"),
                                                 headers={"Content-Type": "application/json", "x-api-key": key,
                                                          "anthropic-version": "2023-06-01"}, method="POST")
                    with urllib.request.urlopen(req, timeout=120) as r:
                        raw = r.read().decode("utf-8")
                    LOG.ghi("[AI] POST /v1/messages lo %d: 200, %d byte" % (i // 20 + 1, len(raw)))
                    txt = "".join(c.get("text", "") for c in json.loads(raw).get("content", []))
                    m = re.search(r"\[.*\]", txt, re.S)
                    ket.extend(json.loads(m.group(0)) if m else [])
                    ok = True; break
                except urllib.error.HTTPError as e:
                    LOG.ghi("[AI] Loi HTTP %s: %s" % (e.code, (e.read() or b"")[:500].decode("utf-8", "replace")))
                    if e.code in (400, 401, 403):
                        break
                except Exception as e:
                    LOG.loi("[AI] Loi khi goi Claude (lan %d)" % (lan + 1), e)
                time.sleep(2)
            if not ok:
                LOG.ghi("[AI] Bo qua lo %d." % (i // 20 + 1))
    ts = datetime.now().strftime("%Y%m%d%H%M%S")
    duong = os.path.join(kq_dir, "ket_qua_ai_%s.jsonl" % ts)
    with open(duong, "w", encoding="utf-8") as f:
        for d in ket:
            f.write(json.dumps(d, ensure_ascii=False) + "\n")
    with open(os.path.join(kq_dir, "DA_XONG_AI"), "w", encoding="utf-8") as f:
        f.write(duong)
    LOG.ghi("[AI] Da ghi %d goi y vao %s" % (len(ket), os.path.basename(duong)))
    return duong


unesco_doc_tham_so(mo_rong_tham_so(sys.argv))
unesco_ap_dung_thiet_lap()


# ==========================================================================
#  GOI RA MANG  (yeu cau muc 3 + muc 7: tu do khi khong chac)
# ==========================================================================
MAY_CHU_UNG_VIEN = [
    "https://hoadondientu.gdt.gov.vn/api",
    "https://hoadondientu.gdt.gov.vn",
]

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36")
TRANG_WEB = "https://hoadondientu.gdt.gov.vn"

# Cookie: may chu Cuc Thue co the cap cookie o buoc lay captcha va doi hoi gui lai
# khi dang nhap (neu khong -> 403 "hanh vi khong hop le"). Dung chung 1 bo cookie.
_COOKIES = http.cookiejar.CookieJar()

# GD65: KIEM chung chi TLS cua may chu thue (truoc day tat hoan toan - de bi nghe len / gia mao phien dang nhap tren mang
#   khong tin cay). Co goi 'truststore' thi dung kho chung chi Windows (tu lay chung chi trung gian nhu trinh duyet).
#   Chi khi nguoi dung TU dat "tls_khong_kiem": true trong cai-dat.json moi bo kiem (ghi nhat ky moi lan goi).
try:
    import truststore as _truststore
    _ssl_ctx = _truststore.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
except Exception:
    _ssl_ctx = ssl.create_default_context()
_ssl_ctx_bo_kiem = ssl.create_default_context()
_ssl_ctx_bo_kiem.check_hostname = False
_ssl_ctx_bo_kiem.verify_mode = ssl.CERT_NONE


def _ngu_canh_tls():
    if (globals().get("SETTINGS") or {}).get("tls_khong_kiem"):
        return _ssl_ctx_bo_kiem
    return _ssl_ctx


def _loi_chung_chi(e):
    ly_do = getattr(e, "reason", e)
    return isinstance(ly_do, ssl.SSLCertVerificationError) or "CERTIFICATE_VERIFY_FAILED" in str(ly_do)


class KetQuaMang:
    def __init__(self, ok, status=0, data=b"", ctype="", loi="", retry_after=""):
        self.ok = ok
        self.status = status
        self.data = data
        self.ctype = ctype
        self.loi = loi
        self.retry_after = retry_after          # P2 18/11/2026: header Retry-After (giay hoac ngay gio HTTP), "" khi khong co

    def json(self):
        try:
            return json.loads(self.data.decode("utf-8"))
        except Exception:
            return None


def goi_mang_kien_nhan(url, token=None, timeout=60, so_lan=4):
    """GD30b: cong thue tra 429 (Too Many Requests) khi hoi don dap. Cho roi hoi lai: 4s, 8s, 16s.
    Loi khac thi tra ve ngay nhu goi_mang."""
    kq = None
    for lan in range(so_lan):
        kq = goi_mang(url, token=token, timeout=timeout)
        if getattr(kq, "status", 0) != 429:
            return kq
        if lan + 1 >= so_lan:          # P2 18/11/2026: het luot thi tra ve ngay (truoc day van ngu them 32 giay vo ich)
            LOG.ghi("[MANG] Cong thue van bao qua nhieu yeu cau (429) sau %d lan - thoi." % so_lan)
            break
        cho = _cho_retry_after(getattr(kq, "retry_after", ""))          # P2: cong noi ro thi cho dung bay nhieu (co tran)
        if cho is None:
            cho = 4 * (2 ** lan) + random.uniform(0, 1.5)          # P2: lech ngau nhien nho, khong hoi dong loat
        LOG.ghi("[MANG] Cong thue bao qua nhieu yeu cau (429) - cho %.0f giay roi hoi lai (lan %d/%d)." % (cho, lan + 1, so_lan))
        _bao_cho("Cổng thuế báo quá nhiều yêu cầu - chờ %.0f giây rồi hỏi lại (lần %d/%d)" % (cho, lan + 1, so_lan - 1))
        ngu_du = ngu_huy_duoc(cho)
        _bao_cho("")
        if not ngu_du:
            LOG.ghi("[MANG] Nguoi dung bam Dung trong luc cho - thoi hoi lai.")
            break
    return kq


def _bao_cho(noi_dung):
    """26/11/2026: bao ra /api/tien-trinh (khoa 'cho') la tool dang CHO cong thue (429 / 502-504) - cua so nhung cua
    UNESCO XII hien 'dang cho vi cong qua tai'. '' = het cho. Chi la chu hien thi, khong doi cach cho / hoi lai."""
    try:
        STATE["tai"]["cho"] = noi_dung
    except Exception:
        pass


CHO_TOI_DA = 120          # P2 18/11/2026: tran thoi gian cho mot lan hoi lai (giay), ke ca khi cong xin cho lau hon


def _cho_retry_after(gia_tri, bay_gio=None):
    """P2 18/11/2026: header Retry-After -> so giay cho (1..CHO_TOI_DA), None khi khong co / sai. Nhan dang so giay va ngay gio HTTP."""
    s = str(gia_tri or "").strip()
    if not s:
        return None
    try:
        if s.isdigit():
            return float(min(max(int(s), 1), CHO_TOI_DA))
        import email.utils
        moc = email.utils.parsedate_to_datetime(s)
        if moc is None:
            return None
        con = moc.timestamp() - (bay_gio if bay_gio is not None else time.time())
        return float(min(max(con, 1), CHO_TOI_DA))
    except Exception:
        return None


def ngu_huy_duoc(giay):
    """P2 18/11/2026: ngu tung doan ngan, thoi ngay khi nguoi dung bam Dung (STATE['tai']['dung']). -> True ngu du, False bi dung."""
    con = max(0.0, float(giay))
    while con > 0:
        try:
            t = STATE.get("tai") or {}
            if t.get("dang_chay") and t.get("dung"):          # chi khi dang tai va nguoi da bam Dung (co cu khong lam hong lan sau)
                return False
        except Exception:
            pass
        b = min(1.0, con)
        time.sleep(b)
        con -= b
    return True


def goi_mang(url, method="GET", body=None, token=None, timeout=60, ghi_log=True):
    """Goi mot dia chi tren mang. Luon ghi lai day du vao nhat ky."""
    if url.startswith(TRANG_WEB) and CHROME.get("trang_thai") == "da_dang_nhap" and CHROME.get("kenh") is not None:
        return goi_mang_qua_chrome(url, method, body, token, timeout, ghi_log)
    # Header giong trinh duyet Chrome dang mo trang hoadondientu.gdt.gov.vn
    headers = {
        "User-Agent": UA,
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7",
        "Accept-Encoding": "gzip, deflate",
        "Origin": TRANG_WEB,
        "Referer": TRANG_WEB + "/",
        "Sec-Fetch-Site": "same-origin",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Dest": "empty",
        "sec-ch-ua": '"Chromium";v="128", "Not;A=Brand";v="24", "Google Chrome";v="128"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "Connection": "keep-alive",
    }
    data = None
    if body is not None:
        data = json.dumps(body, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json;charset=UTF-8"
    if token:
        headers["Authorization"] = "Bearer " + token

    if ghi_log:
        LOG.ghi("[MANG] %s %s" % (method, url))

    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    ngu_canh = _ngu_canh_tls()
    if ngu_canh is _ssl_ctx_bo_kiem and ghi_log:
        LOG.ghi("[MANG] CANH BAO: dang BO KIEM chung chi TLS (tls_khong_kiem = true trong cai-dat.json)")
    opener = urllib.request.build_opener(urllib.request.HTTPSHandler(context=ngu_canh),
                                         urllib.request.HTTPCookieProcessor(_COOKIES))
    t0 = time.time()
    try:
        with opener.open(req, timeout=timeout) as resp:
            raw = resp.read()
            if (resp.headers.get("Content-Encoding") or "").lower() == "gzip":
                try:
                    raw = gzip.decompress(raw)
                except Exception:
                    pass
            ctype = resp.headers.get("Content-Type", "")
            if ghi_log:
                LOG.ghi("[MANG] -> ma tra ve %s | kieu du lieu: %s | dung luong: %d byte | mat %.1f giay"
                        % (resp.status, ctype or "khong ro", len(raw), time.time() - t0))
            return KetQuaMang(True, resp.status, raw, ctype)
    except urllib.error.HTTPError as e:
        try:
            raw_err = e.read()
            if (e.headers.get("Content-Encoding") or "").lower() == "gzip":
                try:
                    raw_err = gzip.decompress(raw_err)
                except Exception:
                    pass
            body_err = raw_err.decode("utf-8", "replace")
        except Exception:
            body_err = ""
        if ghi_log:
            LOG.ghi("[MANG] -> ma tra ve %s | dung luong loi: %d byte" % (e.code, len(body_err)))
            LOG.ghi("[MANG] -> NGUYEN VAN loi tu may chu: " + body_err[:500])
        kq_loi = KetQuaMang(False, e.code, b"", "", body_err[:500])
        try:
            kq_loi.retry_after = (e.headers.get("Retry-After") or "").strip()          # P2 18/11/2026: 429 / 503 cho biet nen cho bao lau
        except Exception:
            pass
        return kq_loi
    except urllib.error.URLError as e:
        mo_ta = str(getattr(e, "reason", e))
        if _loi_chung_chi(e):
            # GD65: chung chi may chu khong kiem duoc - KHONG tu bo kiem; bao cach sua
            mo_ta = ("Khong kiem duoc chung chi TLS cua may chu thue (%s). Cach sua: cap nhat Windows (chung chi goc), mo "
                     "https://hoadondientu.gdt.gov.vn bang Chrome / Edge mot lan roi thu lai. Neu van loi va chac chan mang an toan: "
                     "dat \"tls_khong_kiem\": true trong AIHoaDon\\cai-dat.json (khong khuyen dung)." % mo_ta[:200])
        if ghi_log:
            LOG.ghi("[MANG] -> khong ket noi duoc. NGUYEN VAN: " + mo_ta[:700])
        return KetQuaMang(False, 0, b"", "", mo_ta[:700])
    except socket.timeout:
        if ghi_log:
            LOG.ghi("[MANG] -> qua thoi gian cho (%d giay)" % timeout)
        return KetQuaMang(False, 0, b"", "", "Qua thoi gian cho phan hoi tu may chu.")
    except Exception as e:
        LOG.loi("Loi khong luong truoc khi goi %s" % url, e)
        return KetQuaMang(False, 0, b"", "", str(e)[:500])


def tim_may_chu():
    """Thu lan luot cac dia chi may chu, cai nao chay duoc thi nho lai."""
    uu_tien = []
    if SETTINGS.get("may_chu_da_chay"):
        uu_tien.append(SETTINGS["may_chu_da_chay"])
    for m in MAY_CHU_UNG_VIEN:
        if m not in uu_tien:
            uu_tien.append(m)

    LOG.ghi("[DO TIM] Bat dau do tim dia chi may chu, co %d dia chi de thu." % len(uu_tien))
    for m in uu_tien:
        kq = goi_mang(m + "/captcha", timeout=20)
        if kq.ok and kq.data:
            LOG.ghi("[DO TIM] -> DUNG DUOC: " + m + " (da nho lai cho lan sau)")
            SETTINGS["may_chu_da_chay"] = m
            luu_thiet_lap(SETTINGS)
            return m
        LOG.ghi("[DO TIM] -> khong dung duoc: " + m)
    LOG.ghi("[DO TIM] Khong dia chi nao dung duoc.")
    return None


# ==========================================================================
#  BANG QUY DOI CAC LUA CHON TREN GIAO DIEN
# ==========================================================================
MA_TRANG_THAI = {
    "Tất cả": None, "Hóa đơn mới": "1", "Hóa đơn thay thế": "2",
    "Hóa đơn điều chỉnh": "3", "Hóa đơn đã bị thay thế": "4",
    "Hóa đơn đã bị điều chỉnh": "5", "Hóa đơn đã bị hủy": "6",
}
MA_KET_QUA = {
    "Tất cả": None, "Cục Thuế đã nhận": "0",
    "Đang tiến hành kiểm tra điều kiện cấp mã": "1",
    "CQT từ chối hóa đơn theo từng lần phát sinh": "2",
    "Hóa đơn đủ điều kiện cấp mã": "3",
    "Hóa đơn không đủ điều kiện cấp mã": "4",
    "Đã cấp mã hóa đơn": "5",
    "Cục Thuế đã nhận không mã": "6",
    "Đã kiểm tra định kỳ HĐĐT không có mã": "7",
    "Cục Thuế đã nhận hóa đơn có mã khởi tạo từ máy tính tiền": "8",
}


def duong_tra_cuu(kind, direction):
    """kind: dt / mtt   |   direction: ban / mua"""
    goc = "/sco-query" if kind == "mtt" else "/query"
    duoi = "/invoices/sold" if direction == "ban" else "/invoices/purchase"
    return goc + duoi


def duong_tai_ung_vien(kind):
    if kind == "mtt":
        return ["/sco-query/invoices/export-xml",
                "/query/invoices/export-xml",
                "/resource/export-xml"]
    return ["/query/invoices/export-xml",
            "/sco-query/invoices/export-xml",
            "/resource/export-xml"]


def duong_pdf_ung_vien(kind):
    if kind == "mtt":
        return ["/sco-query/invoices/export-pdf",
                "/query/invoices/export-pdf",
                "/resource/export-pdf"]
    return ["/query/invoices/export-pdf",
            "/sco-query/invoices/export-pdf",
            "/resource/export-pdf"]


# ==========================================================================
#  TRANG THAI CHUNG CUA TOOL
# ==========================================================================
STATE = {
    "may_chu": None,
    "token": None,
    "ckey": None,
    "mst": "",
    "ket_qua": {"dt": [], "mtt": []},
    "tai": {"dang_chay": False, "dung": False, "tong": 0, "xong": 0,
            "ok": 0, "bo_qua": 0, "loi": 0, "hien_tai": "", "ket_thuc": "", "tep_mo": ""},
}
STATE_LOCK = threading.Lock()

# hop thu de yeu cau mo cua so chon thu muc (tkinter phai chay o luong chinh)
HOP_THU_CHON_THU_MUC = queue.Queue()
HOP_THU_CHON_TEP = queue.Queue()          # GD359b: hop thoai chon tep Excel cong thue (luong chinh tkinter)




# ==========================================================================
#  DANG NHAP & GOI MANG QUA CHROME THAT (CDP - Chrome DevTools Protocol)
#  Ly do: may chu Cuc Thue tra 403 "hanh vi khong hop le" voi moi ket noi
#  khong phai trinh duyet. Cach nay: mo Chrome (ho so rieng), nguoi dung dang
#  nhap ngay tren trang thue; sau do MOI lenh tra cuu / tai deu chay ben trong
#  trang web (fetch) nen may chu thay dung la Chrome.
#  Chi dung thu vien chuan cua Python (socket, struct, json).
# ==========================================================================
import struct
import select
import collections

CHROME_HO_SO = os.path.join(BASE_DIR, "chrome-ho-so")


def chrome_ho_so_cho(mst):
    """GD29: moi MST mot ho so Chrome rieng (chrome-ho-so\\<MST>). Ke toan dich vu lam nhieu
    khach: ho so rieng thi Chrome nho dang nhap / tu dien mat khau CUA DUNG khach do, lan sau
    chi go captcha. Mat khau do CHROME giu (nguoi dung tu bam Luu trong Chrome), tool khong
    doc va khong luu. Chua biet MST -> dung ho so chung nhu truoc."""
    m = re.sub(r"[^0-9\-]", "", str(mst or ""))
    return os.path.join(CHROME_HO_SO, m) if m else CHROME_HO_SO


def goi_nho_ds():
    ds = []
    for x in (SETTINGS.get("goi_nho") or []):
        if isinstance(x, dict) and x.get("mst"):
            ds.append({"nhan": str(x.get("nhan") or "")[:60], "mst": str(x.get("mst"))[:20]})
    return ds


def goi_nho_luu(nhan, mst):
    mst = re.sub(r"[^0-9\-]", "", str(mst or ""))
    nhan = str(nhan or "").strip()[:60]
    if not mst:
        return False, "Thiếu mã số thuế."
    ds = [x for x in goi_nho_ds() if x["mst"] != mst]
    ds.append({"nhan": nhan or mst, "mst": mst})
    ds.sort(key=lambda x: x["nhan"].lower())
    SETTINGS["goi_nho"] = ds
    luu_thiet_lap(SETTINGS)
    LOG.ghi("[GOI NHO] Luu tai khoan goi nho cho MST " + mask_tail(mst))
    return True, ""


def goi_nho_xoa(mst):
    SETTINGS["goi_nho"] = [x for x in goi_nho_ds() if x["mst"] != str(mst or "")]
    luu_thiet_lap(SETTINGS)
    return True, ""


class KenhCDP:
    """Ket noi websocket toi 1 tab Chrome, goi lenh DevTools. Rat gon, du dung."""

    def __init__(self, ws_url, timeout=120):
        u = urllib.parse.urlparse(ws_url)
        self.sock = socket.create_connection((u.hostname, u.port), timeout=timeout)
        self.sock.settimeout(timeout)
        key = base64.b64encode(os.urandom(16)).decode("ascii")
        req = ("GET %s HTTP/1.1\r\nHost: %s:%d\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
               "Sec-WebSocket-Key: %s\r\nSec-WebSocket-Version: 13\r\n\r\n" % (u.path, u.hostname, u.port, key))
        self.sock.sendall(req.encode("ascii"))
        dau = b""
        while b"\r\n\r\n" not in dau:
            phan = self.sock.recv(4096)
            if not phan:
                raise IOError("Chrome dong ket noi khi bat tay websocket")
            dau += phan
        if b" 101 " not in dau.split(b"\r\n")[0]:
            raise IOError("Chrome tu choi websocket: " + dau.split(b"\r\n")[0].decode("ascii", "replace"))
        self.id = 0
        self.khoa_gui = threading.Lock()
        self.su_kien = collections.deque(maxlen=2000)
        self.timeout = timeout
        self.dang_cho = {}
        self.loi_ket_noi = None
        self.sock.settimeout(None)
        threading.Thread(target=self._vong_doc, daemon=True).start()

    def _doc_du(self, n):
        buf = b""
        while len(buf) < n:
            phan = self.sock.recv(min(1 << 20, n - len(buf)))
            if not phan:
                raise IOError("Chrome dong ket noi")
            buf += phan
        return buf

    def _gui_khung(self, opcode, du_lieu):
        mask = os.urandom(4)
        n = len(du_lieu)
        dau = bytes([0x80 | opcode])
        if n < 126:
            dau += bytes([0x80 | n])
        elif n < 65536:
            dau += bytes([0x80 | 126]) + struct.pack(">H", n)
        else:
            dau += bytes([0x80 | 127]) + struct.pack(">Q", n)
        than = bytes(b ^ mask[i % 4] for i, b in enumerate(du_lieu))
        with self.khoa_gui:
            self.sock.sendall(dau + mask + than)

    def _nhan_khung(self):
        """Tra ve (opcode, payload) cua 1 thong diep hoan chinh (gop cac manh)."""
        du_lieu = b""
        opcode_dau = None
        while True:
            b1, b2 = self._doc_du(2)
            fin = b1 & 0x80
            opcode = b1 & 0x0F
            n = b2 & 0x7F
            if n == 126:
                n = struct.unpack(">H", self._doc_du(2))[0]
            elif n == 127:
                n = struct.unpack(">Q", self._doc_du(8))[0]
            mask = self._doc_du(4) if (b2 & 0x80) else None
            than = self._doc_du(n) if n else b""
            if mask:
                than = bytes(b ^ mask[i % 4] for i, b in enumerate(than))
            if opcode == 0x9:              # ping -> pong
                self._gui_khung(0xA, than)
                continue
            if opcode == 0x8:
                raise IOError("Chrome dong websocket")
            if opcode in (0x1, 0x2):
                opcode_dau = opcode
            du_lieu += than
            if fin:
                return opcode_dau, du_lieu

    def _vong_doc(self):
        """Luong doc rieng: tra loi lenh -> danh thuc nguoi cho; su kien -> xep hang."""
        try:
            while True:
                _, than = self._nhan_khung()
                try:
                    msg = json.loads(than.decode("utf-8"))
                except Exception:
                    continue
                if "id" in msg:
                    o = self.dang_cho.get(msg["id"])
                    if o is not None:
                        o[1] = msg
                        o[0].set()
                elif "method" in msg:
                    rq = (msg.get("params") or {}).get("request")
                    if isinstance(rq, dict):          # GD145: bo than yeu cau (form dang nhap co mat khau) - quy tac 17
                        rq.pop("postData", None)
                        rq.pop("postDataEntries", None)
                    self.su_kien.append(msg)
        except Exception as e:
            self.loi_ket_noi = str(e)[:200]
            for o in list(self.dang_cho.values()):
                o[0].set()

    def goi(self, phuong_thuc, tham_so=None, timeout=None):
        if self.loi_ket_noi:
            raise IOError("Mat ket noi Chrome: " + self.loi_ket_noi)
        with self.khoa_gui:
            self.id += 1
            mid = self.id
        cho = [threading.Event(), None]
        self.dang_cho[mid] = cho
        try:
            self._gui_khung(0x1, json.dumps({"id": mid, "method": phuong_thuc, "params": tham_so or {}}).encode("utf-8"))
            if not cho[0].wait(timeout or self.timeout):
                raise IOError("CDP %s: qua thoi gian cho" % phuong_thuc)
        finally:
            self.dang_cho.pop(mid, None)
        if cho[1] is None:
            raise IOError("Mat ket noi Chrome: " + (self.loi_ket_noi or ""))
        msg = cho[1]
        if "error" in msg:
            raise IOError("CDP %s: %s" % (phuong_thuc, msg["error"].get("message", "")))
        return msg.get("result", {})

    def hut_su_kien(self, cho=0.3):
        """(giu de tuong thich) Su kien da duoc luong doc xep san; chi kiem tra ket noi."""
        if self.loi_ket_noi:
            raise IOError("Mat ket noi Chrome: " + self.loi_ket_noi)

    def chay_js(self, bieu_thuc, cho_promise=False, timeout=None):
        kq = self.goi("Runtime.evaluate", {"expression": bieu_thuc, "awaitPromise": cho_promise,
                                           "returnByValue": True})
        if kq.get("exceptionDetails"):
            raise IOError("JS loi: " + json.dumps(kq["exceptionDetails"].get("exception", {}).get("description", ""))[:300])
        return kq.get("result", {}).get("value")

    def dong(self):
        try:
            self.sock.close()
        except Exception:
            pass


CHROME = {"tien_trinh": None, "cong": 0, "kenh": None, "trang_thai": "chua_mo", "loi": "", "mst": "",
          "header_mau": None, "so_yeu_cau_bat": 0,
          "tab_id": "", "the_he": 0, "menu_xong": False, "co_yc_moi": False, "tk_moi_nhat": "", "tk_cu": set(),
          "nhan_token": False, "luc_mo": 0.0}          # GD145
# Header KHONG chep lai tu yeu cau that (trinh duyet tu dat / khong duoc phep dat)
_HEADER_BO = {"host", "content-length", "cookie", "connection", "accept-encoding", "origin", "referer",
              "sec-fetch-site", "sec-fetch-mode", "sec-fetch-dest", "user-agent", "content-type"}


CHROME_LOCK = threading.Lock()

# GD87: lay MOI token dang JWT co trong tab (localStorage / sessionStorage / cookie), tra ve JSON danh sach.
#   Ho so Chrome rieng theo MST GIU LAI token cu cua lan truoc -> ban cu (lay token dau tien tim thay, khong xet
#   han) tung nhan nham token het han la "da dang nhap" ngay khi mo trang, roi tool nhay sang trang Tra cuu giua
#   luc nguoi dung dang go captcha -> trang thue bao 403 "khong co quyen truy cap" va bat dang nhap lai
#   (anh Thang 27/09). Nhat ky cac phien truoc cung cho thay token "nhan" luc dau LUON khac token that cua trang.
_JS_TIM_MOI_TOKEN = r"""
(() => {
  const re = /^eyJ[\w-]+\.[\w-]+\.[\w-]+$/;
  const ds = [];
  const xet = (v) => { if (typeof v !== 'string') return; v = v.trim().replace(/^"|"$/g,'');
    if (re.test(v)) { if (ds.indexOf(v) < 0) ds.push(v); return; }
    try { const o = JSON.parse(v); if (o && typeof o === 'object') { for (const k in o) xet(o[k]); } } catch(e) {} };
  for (const st of [window.localStorage, window.sessionStorage]) {
    for (let i = 0; i < st.length; i++) xet(st.getItem(st.key(i)));
  }
  for (const c of document.cookie.split(';')) xet(c.split('=').slice(1).join('='));
  return JSON.stringify(ds);
})()
"""

# GD87: hop dang nhap cua trang thue dang mo? (co o mat khau dang hien) - dang mo thi CHUA the coi la da dang nhap
_JS_HOP_DANG_NHAP_MO = r"""
(() => Array.from(document.querySelectorAll('input[type=password]')).some(e => e.offsetParent !== null))()
"""

# GD87: trang hien thong bao 403 "Rat tiec, ban khong co quyen truy cap trang nay"?
_JS_LA_TRANG_403 = r"""
(() => { const t = (document.body && document.body.innerText) || ''; return /không có quyền truy cập/i.test(t) && /\b403\b/.test(t); })()
"""

# GD87: bam lien ket trong ung dung toi trang Tra cuu hoa don (Angular router - KHONG tai lai ca trang,
#   giu nguyen phien vua dang nhap). Khong thay lien ket -> tra ve 'khong_thay'.
_JS_BAM_LINK_TRA_CUU = r"""
(() => {
  const ds = Array.from(document.querySelectorAll('a[href]')).filter(x => (x.getAttribute('href') || '').indexOf('/tra-cuu/tra-cuu-hoa-don') >= 0);
  const a = ds.find(x => x.offsetParent !== null) || ds[0];
  if (!a) return 'khong_thay';
  a.click(); return 'da_bam';
})()
"""

# GD145: menu quyen da nap (co lien ket Tra cuu hoa don, ke ca trong menu con dang an)?
_JS_CO_LINK_TRA_CUU = r"""
(() => Array.from(document.querySelectorAll('a[href]')).some(x => (x.getAttribute('href') || '').indexOf('/tra-cuu/tra-cuu-hoa-don') >= 0))()
"""


def _jwt_payload(tk):
    """GD87: doc phan payload cua JWT (khong xac thuc chu ky - chi de doc exp/iat/sub). Loi -> {}."""
    try:
        phan = tk.split(".")[1]
        phan += "=" * (-len(phan) % 4)
        o = json.loads(base64.urlsafe_b64decode(phan).decode("utf-8", "replace"))
        return o if isinstance(o, dict) else {}
    except Exception:
        return {}


def _token_con_han(tk, du=30):
    """GD87: token con han (exp > bay gio + du giay)? Khong co exp -> coi la con han."""
    exp = _jwt_payload(tk).get("exp")
    try:
        return exp is None or float(exp) > time.time() + du
    except Exception:
        return True


def _chrome_lay_tokens(kenh):
    """GD87: danh sach token trong tab (co the rong). Loi JS -> []."""
    try:
        return [x for x in json.loads(kenh.chay_js(_JS_TIM_MOI_TOKEN) or "[]") if isinstance(x, str)]
    except IOError:
        raise
    except Exception:
        return []


def _chrome_hop_dang_nhap_mo(kenh):
    try:
        return bool(kenh.chay_js(_JS_HOP_DANG_NHAP_MO))
    except IOError:
        raise
    except Exception:
        return False


def _chrome_chon_token_moi(kenh, cu, t_noi):
    """GD87: chon token DA DANG NHAP THAT: con han, KHONG phai token da co san luc mo trang (cu), hop dang nhap
    dang dong, va van con sau 2 giay (on dinh). Token co san tu truoc chi duoc nhan sau >= 8 giay neu con han va
    hop dang nhap khong mo (nguoi dung van dang trong phien cu hop le). Tra ve '' neu chua."""
    ds = _chrome_lay_tokens(kenh)
    con_han = [t for t in ds if _token_con_han(t)]
    if not con_han:
        return ""
    if _chrome_hop_dang_nhap_mo(kenh):
        return ""
    moi = [t for t in con_han if t not in cu]
    if moi:
        ung = max(moi, key=lambda t: float(_jwt_payload(t).get("exp") or 0))
    elif time.time() - t_noi >= 8:
        ung = max(con_han, key=lambda t: float(_jwt_payload(t).get("exp") or 0))
    else:
        return ""
    time.sleep(2)
    if ung not in _chrome_lay_tokens(kenh) or _chrome_hop_dang_nhap_mo(kenh):
        return ""
    return ung

_JS_FETCH = r"""
(async () => {
  try {
    const r = await fetch(%s, %s);
    const u = new Uint8Array(await r.arrayBuffer());
    let s = ''; const CH = 0x8000;
    for (let i = 0; i < u.length; i += CH) s += String.fromCharCode.apply(null, u.subarray(i, i + CH));
    return JSON.stringify({s: r.status, t: r.headers.get('content-type') || '', d: btoa(s)});
  } catch (e) { return JSON.stringify({s: 0, e: String(e)}); }
})()
"""


def _cong_ranh():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    cong = s.getsockname()[1]
    s.close()
    return cong


def _chrome_ds_tab(cong=None):
    """GD145: danh sach tab cua Chrome trang thue (/json/list); None = cong go loi khong tra loi (Chrome da dong)."""
    cong = cong or CHROME.get("cong")
    if not cong:
        return None
    try:
        with urllib.request.urlopen("http://127.0.0.1:%d/json/list" % cong, timeout=3) as r:
            return json.loads(r.read().decode("utf-8"))
    except Exception:
        return None


def _chrome_song():
    """GD145: Chrome trang thue con chay (cong go loi con tra loi)?"""
    return _chrome_ds_tab() is not None


def _chrome_cong_tu_ho_so(ho_so):
    """GD145: Chrome ghi cong go loi vao <ho so>\\DevToolsActivePort. Chrome cua lan truoc con mo (giu ho so) ->
    dung lai chinh no (mo Chrome moi cung ho so se bi Chrome cu 'nuot', cong moi khong bao gio mo -> treo)."""
    for ten in ("DevToolsActivePort", "unesco_cong.txt"):      # unesco_cong.txt: tool tu ghi (Chrome khong phai luc nao cung ghi tep kia)
        try:
            with io.open(os.path.join(ho_so, ten), "r") as f:
                c = int((f.readline() or "0").strip() or 0)
        except Exception:
            continue
        if c and _chrome_ds_tab(c) is not None:
            return c
    return 0


def _chrome_tab_moi(url):
    """GD145: mo them 1 tab toi url (Chrome con chay nhung tab trang thue da bi dong)."""
    if UNESCO.get("nhung"):
        return None                   # 26/11/2026: cua so nhung - trang do UNESCO XII mo / mo lai, tool khong tao tab
    q ="http://127.0.0.1:%d/json/new?%s" % (CHROME["cong"], urllib.parse.quote(url, safe=":/?=&"))
    for m in ("PUT", "GET"):
        try:
            with urllib.request.urlopen(urllib.request.Request(q, method=m), timeout=5) as r:
                return json.loads(r.read().decode("utf-8"))
        except Exception:
            continue
    return None


def _chrome_trinh_duyet_goi(phuong_thuc, tham_so=None):
    """GD145: goi 1 lenh CDP muc TRINH DUYET (Browser.*) qua /json/version. Loi -> IOError."""
    with urllib.request.urlopen("http://127.0.0.1:%d/json/version" % CHROME["cong"], timeout=3) as r:
        ws = json.loads(r.read().decode("utf-8")).get("webSocketDebuggerUrl")
    if not ws:
        raise IOError("Chrome khong cho cong trinh duyet")
    k = KenhCDP(ws, timeout=10)
    try:
        return k.goi(phuong_thuc, tham_so or {})
    finally:
        k.dong()


def _chrome_cua_so(che_do):
    """GD145: 'minimized' = thu nho cua so trang thue xuong thanh tac vu (sau khi dang nhap xong);
    'normal' = hien lai + dua len truoc (mat phien, can dang nhap lai / nguoi dung bam Hien trang thue). Loi -> False."""
    if UNESCO.get("nhung"):
        # 26/11/2026: cua so nhung khong co cua so Chrome de thu nho - bao cho UNESCO XII (qua /api/nhip) doi sang
        #   bang tai ('minimized') hoac trang thue ('normal'); so thu tu tang moi lan de XII biet la yeu cau moi.
        CHROME["nhung_cua_so"] = [che_do, int((CHROME.get("nhung_cua_so") or ["", 0])[1]) + 1]
        return True
    try:
        w = _chrome_trinh_duyet_goi("Browser.getWindowForTarget", {"targetId": CHROME.get("tab_id") or ""})
        _chrome_trinh_duyet_goi("Browser.setWindowBounds", {"windowId": w["windowId"], "bounds": {"windowState": che_do}})
        if che_do == "normal" and CHROME.get("kenh") is not None:
            try:
                CHROME["kenh"].goi("Page.bringToFront")
            except Exception:
                pass
        LOG.ghi("[CHROME] Cua so trang thue: %s" % ("thu nho" if che_do == "minimized" else "hien lai"))
        return True
    except Exception as e:
        LOG.ghi("[CHROME] Khong doi duoc cua so trang thue (%s): %s" % (che_do, str(e)[:150]))
        return False


def _chrome_bat_mang(kenh):
    """GD145: theo doi mang NGAY KHI noi tab (truoc khi dang nhap) de bat cac yeu cau trang tu goi ngay sau dang nhap
    (ho so, menu quyen) -> hoc header + phien THAT ma khong phai chuyen trang som (nguyen nhan trang bao 403 lan dau).
    maxPostDataSize = 1 (0 = khong gioi han!) + KenhCDP bo than yeu cau khoi su kien: tool KHONG giu than yeu cau POST
    (form dang nhap co mat khau) - quy tac 17."""
    try:
        kenh.goi("Network.enable", {"maxTotalBufferSize": 20000000, "maxResourceBufferSize": 10000000, "maxPostDataSize": 1})
        return True
    except Exception as e:
        LOG.ghi("[CHROME] Chua bat duoc theo doi mang: " + str(e)[:150])
        return False


def _chrome_da_dong(ly_do=""):
    """GD145: Chrome trang thue da bi dong (nguoi dung bam X / Chrome thoat): bo phien, cho phep bam Dang nhap mo lai."""
    k = CHROME.get("kenh")
    CHROME["kenh"] = None
    CHROME["tab_id"] = ""
    if k is not None:
        try:
            k.dong()
        except Exception:
            pass
    STATE["token"] = ""
    CHROME["trang_thai"] = "dong"
    CHROME["loi"] = "Cửa sổ trang thuế đã đóng. Bấm “Đăng nhập qua Chrome” để mở lại."
    LOG.ghi("[CHROME] Cua so trang thue da dong%s - cho nguoi dung bam mo lai." % ((" (" + ly_do + ")") if ly_do else ""))


def _chrome_dong_han(cho=5.0):
    """GD145: dong Chrome trang thue cua tool (Browser.close - Chrome luu ho so binh thuong); khong dong duoc thi
    ket thuc tien trinh. Chi dong Chrome do TOOL mo / dang dieu khien (cong go loi), khong dung Chrome cua nguoi dung."""
    if not CHROME.get("cong"):
        return
    if UNESCO.get("nhung"):
        return                        # 26/11/2026: cua so nhung la cua UNESCO XII - XII tu dong, tool khong dong
    try:
        if _chrome_song():
            try:
                _chrome_trinh_duyet_goi("Browser.close")
            except Exception:
                pass
            t0 = time.time()
            while time.time() - t0 < cho and _chrome_song():
                time.sleep(0.25)
        p = CHROME.get("tien_trinh")
        if p is not None and p.poll() is None:
            if os.name == "nt":
                subprocess.run(["taskkill", "/PID", str(p.pid), "/T", "/F"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                               timeout=10, creationflags=0x08000000)
            else:
                p.terminate()
        LOG.ghi("[CHROME] Da dong cua so trang thue cua tool.")
    except Exception as e:
        LOG.ghi("[CHROME] Loi khi dong Chrome trang thue: " + str(e)[:150])


HEN_GIO = {"canh": False}


def hen_gio_moc():
    return os.path.join(unesco_thu_muc("ket-qua"), "HEN_GIO_CHO_NGUOI")


def hen_gio_xoa_moc():
    """GD369: da dang nhap duoc -> bo moc 'cho nguoi' cua lan hen gio truoc (phan mem khong nhac nua)."""
    try:
        if UNESCO.get("bat") and os.path.exists(hen_gio_moc()):
            os.remove(hen_gio_moc())
    except Exception:
        pass


def _hen_gio_canh(phut):
    """GD369: chay hen gio (Task Scheduler 07:30) - cong thue bat go ma xac nhan nen MAY KHONG TU DANG NHAP DUOC.
    Truoc day tool mo Chrome roi cho nguoi dang nhap hang gio (nhat ky 06/10 -> 02/11: 'Dang cho nguoi dung dang nhap'
    moi sang, khong tai duoc hoa don nao). Nay: khong ai dang nhap sau N phut -> ghi ket-qua\HEN_GIO_CHO_NGUOI
    (phan mem doc: Trung tam / Tai hoa don / AI_AUTO nhac 'bam de dang nhap, may tu tai'), dong Chrome, tat tool."""
    het = time.time() + max(1, phut) * 60
    while time.time() < het:
        time.sleep(5)
        if CHROME["trang_thai"] == "da_dang_nhap" or STATE.get("token"):
            return
    if CHROME["trang_thai"] == "da_dang_nhap" or STATE.get("token"):
        return
    try:
        with io.open(hen_gio_moc(), "w", encoding="utf-8") as f:
            f.write("%s|%s|%s|%s|Khong co nguoi dang nhap cong thue sau %d phut (hen gio)" % (
                time.strftime("%Y-%m-%d %H:%M"), UNESCO.get("tu") or "", UNESCO.get("den") or "", UNESCO.get("huong") or "ca", phut))
    except Exception as e:
        LOG.loi("Khong ghi duoc moc HEN_GIO_CHO_NGUOI", e)
    LOG.ghi("[HEN GIO] Sau %d phut khong co ai dang nhap cong thue (can go ma xac nhan - may khong tu lam duoc). "
            "Da ghi moc CHO_NGUOI de phan mem nhac khi mo (Trung tam dieu hanh / Tai hoa don / AI_AUTO); dong Chrome, tat tool." % phut)
    thoat_tool("Hen gio: khong co nguoi dang nhap")


def chrome_mo_trang_thue():
    """Mo Chrome (ho so rieng, co cong go loi) toi trang thue; bat dau cho nguoi dung dang nhap.
    GD145: Chrome / tab cua lan truoc da bi dong -> mo lai (truoc day trang thai ket 'dang_cho' voi ket noi chet: bam
    Dang nhap khong co tac dung, phai tat ca tool). Chrome giu ho so MST nay con mo tu lan truoc -> dung lai."""
    with CHROME_LOCK:
        k = CHROME.get("kenh")
        if CHROME["trang_thai"] in ("dang_cho", "da_dang_nhap") and k is not None and not k.loi_ket_noi and _chrome_song():
            _chrome_cua_so("normal")
            return True, ""
        if CHROME["trang_thai"] == "dang_cho" and k is None and _chrome_song() and time.time() - CHROME.get("luc_mo", 0) < 60:
            return True, ""                   # dang mo / dang noi tab (bam lien 2 lan)
        CHROME["the_he"] = CHROME.get("the_he", 0) + 1
        if k is not None:
            try:
                k.dong()
            except Exception:
                pass
        CHROME["kenh"] = None
        CHROME["tab_id"] = ""
        nhung = int(UNESCO.get("nhung") or 0)          # 26/11/2026: cua so nhung cua UNESCO XII (khong can Chrome)
        chrome = "" if nhung else tim_chrome()
        if not nhung and not chrome:
            CHROME["trang_thai"] = "loi"; CHROME["loi"] = "Khong tim thay Chrome tren may."
            return False, CHROME["loi"]
        if nhung:
            if _chrome_ds_tab(nhung) is None:
                CHROME["trang_thai"] = "loi"
                CHROME["loi"] = "Cửa sổ đăng nhập cổng thuế trong phần mềm chưa sẵn sàng. Đóng cửa sổ Tải hoá đơn rồi mở lại."
                LOG.ghi("[NHUNG] Cong go loi %d cua cua so nhung khong tra loi." % nhung)
                return False, CHROME["loi"]
            cu = nhung
        else:
            ho_so = chrome_ho_so_cho(UNESCO.get("mst") or SETTINGS.get("mst"))
            try:
                os.makedirs(ho_so, exist_ok=True)
            except Exception:
                pass
            cu = _chrome_cong_tu_ho_so(ho_so) if not _chrome_song() else CHROME["cong"]
        if cu:
            if CHROME.get("cong") != cu:
                CHROME["tien_trinh"] = None       # Chrome con mo tu phien tool truoc (khong phai tien trinh nay mo)
            CHROME["cong"] = cu
            ds = _chrome_ds_tab() or []
            if not any(t.get("type") == "page" and (t.get("url") or "").startswith(TRANG_WEB) for t in ds):
                _chrome_tab_moi(TRANG_WEB + "/")
            if nhung:
                LOG.ghi("[NHUNG] Noi vao cua so nhung cua UNESCO XII (cong go loi %d) - khong mo Chrome." % cu)
            else:
                LOG.ghi("[CHROME] Dung lai Chrome trang thue dang mo (cong go loi %d)" % cu)
        else:
            cong = _cong_ranh()
            lenh = [chrome, "--remote-debugging-port=%d" % cong, "--user-data-dir=" + ho_so,
                    "--no-first-run", "--no-default-browser-check", "--disable-sync",
                    "--window-size=1200,900", "--new-window"]
            lenh += [x for x in os.environ.get("UNESCO_CHROME_THEM", "").split() if x]      # GD145: chi bai kiem
            lenh.append(TRANG_WEB + "/")
            LOG.ghi("[CHROME] Mo Chrome ho so rieng, cong go loi %d" % cong)
            try:
                CHROME["tien_trinh"] = subprocess.Popen(lenh, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except Exception as e:
                CHROME["trang_thai"] = "loi"; CHROME["loi"] = "Khong mo duoc Chrome: " + str(e)
                LOG.loi("Khong mo duoc Chrome", e)
                return False, CHROME["loi"]
            CHROME["cong"] = cong
            try:
                io.open(os.path.join(ho_so, "unesco_cong.txt"), "w", encoding="ascii").write(str(cong))
            except Exception:
                pass
        CHROME["trang_thai"] = "dang_cho"
        CHROME["loi"] = ""
        CHROME["luc_mo"] = time.time()
        CHROME["menu_xong"] = False
        CHROME["co_yc_moi"] = False
        CHROME["nhan_token"] = False
        CHROME["tk_moi_nhat"] = ""
        threading.Thread(target=_chrome_cho_dang_nhap, args=(CHROME["the_he"],), daemon=True).start()
        if UNESCO.get("hengio") and not HEN_GIO["canh"]:          # GD369
            HEN_GIO["canh"] = True
            try:
                _phut = int(SETTINGS.get("hen_gio_cho_phut", 10) or 10)
            except Exception:
                _phut = 10
            LOG.ghi("[HEN GIO] Cho nguoi dang nhap toi da %d phut (cai-dat.json: hen_gio_cho_phut); qua gio -> ghi moc CHO_NGUOI va tat." % _phut)
            threading.Thread(target=_hen_gio_canh, args=(_phut,), daemon=True).start()
        return True, ""


def _chrome_noi_tab(ds=None):
    """Tim tab trang thue va noi websocket. Tra ve KenhCDP hoac None. GD145: nho id tab (thu nho / hien cua so)."""
    if ds is None:
        ds = _chrome_ds_tab()
    for t in ds or []:
        if t.get("type") == "page" and (t.get("url") or "").startswith(TRANG_WEB):
            try:
                k = KenhCDP(t["webSocketDebuggerUrl"])
                CHROME["tab_id"] = t.get("id") or ""
                return k
            except Exception as e:
                LOG.ghi("[CHROME] Chua noi duoc tab: " + str(e)[:200])
                return None
    return None


def _chrome_noi_lai(the_he, ly_do):
    """GD145: tab mat ket noi -> noi lai. Chrome da dong -> 'dong' (cho bam mo lai), khong treo cho mai nhu truoc;
    Chrome con nhung khong con tab trang thue -> mo tab moi. Tra ve KenhCDP hoac None (dung cho)."""
    LOG.ghi("[CHROME] Mat ket noi tab, noi lai: " + str(ly_do)[:120])
    t_mat = time.time()
    da_mo_tab = False
    lan_ghi = 0
    while CHROME.get("the_he") == the_he and CHROME["trang_thai"] in ("dang_cho", "da_dang_nhap"):
        time.sleep(1.5)
        ds = _chrome_ds_tab()
        if ds is None:
            if time.time() - t_mat > 4:
                _chrome_da_dong("Chrome khong con chay")
                return None
            continue
        kenh = _chrome_noi_tab(ds)
        if kenh is not None:
            _chrome_bat_mang(kenh)
            try:
                kenh.goi("Runtime.enable")
            except Exception:
                pass
            return kenh
        if time.time() - t_mat > 6 and not da_mo_tab:
            trang = [(t.get("url") or "")[:60] for t in ds if t.get("type") == "page"]
            LOG.ghi("[CHROME] Khong con tab trang thue (cac tab: %s) - mo tab moi." % (", ".join(trang) or "khong co"))
            _chrome_tab_moi(TRANG_WEB + "/")
            da_mo_tab = True
        if time.time() - t_mat > 60 + lan_ghi * 60:
            lan_ghi += 1
            LOG.ghi("[CHROME] Van chua noi lai duoc tab trang thue (%d giay)." % int(time.time() - t_mat))
    return None


def _chrome_cho_dang_nhap(the_he=None):
    """Chay nen: doi Chrome mo tab, roi doi den khi trong tab co token dang nhap.
    GD145: bat mang ngay khi noi tab; the_he: lan bam mo moi lam luong cu tu dung."""
    if the_he is None:
        the_he = CHROME.get("the_he", 0)
    t0 = time.time()
    kenh = None
    while time.time() - t0 < 60 and kenh is None and CHROME.get("the_he") == the_he:
        time.sleep(1.5)
        ds = _chrome_ds_tab()
        if ds is None:
            p = CHROME.get("tien_trinh")
            if time.time() - t0 > 15 and (p is None or p.poll() is not None):
                _chrome_da_dong("Chrome thoat ngay khi mo")
                return
            continue
        kenh = _chrome_noi_tab(ds)
        if kenh is None and time.time() - t0 > 10 and not CHROME.get("_da_mo_tab_dau"):
            CHROME["_da_mo_tab_dau"] = True
            _chrome_tab_moi(TRANG_WEB + "/")
    CHROME["_da_mo_tab_dau"] = False
    if CHROME.get("the_he") != the_he:
        if kenh is not None:
            kenh.dong()
        return
    if kenh is None:
        CHROME["trang_thai"] = "loi"
        CHROME["loi"] = "Chrome khong mo duoc trang thue (qua 60 giay)."
        LOG.ghi("[CHROME] " + CHROME["loi"])
        return
    try:
        kenh.goi("Runtime.enable")
    except Exception:
        pass
    _chrome_bat_mang(kenh)                    # GD145: bat mang TRUOC khi nguoi dung dang nhap
    if CHROME.get("kenh") is not None and CHROME["kenh"] is not kenh:
        try:
            CHROME["kenh"].dong()             # GD87: dang nhap lai sau khi mat phien - dong ket noi cu
        except Exception:
            pass
    CHROME["kenh"] = kenh
    LOG.ghi("[CHROME] Da noi voi tab trang thue. Dang cho nguoi dung dang nhap...")
    # GD87: token da co san trong ho so Chrome luc mo trang (lan truoc de lai) KHONG duoc coi la dang nhap moi
    t_noi = time.time()
    try:
        cu = set(_chrome_lay_tokens(kenh))
    except Exception:
        cu = set()
    CHROME["tk_cu"] = set(cu)
    if cu:
        LOG.ghi("[CHROME] Ho so Chrome con %d token cu tu lan truoc (%s) - bo qua, cho dang nhap moi."
                % (len(cu), ", ".join(("con han" if _token_con_han(t) else "het han") for t in cu)))
    while CHROME["trang_thai"] == "dang_cho" and CHROME.get("the_he") == the_he:
        time.sleep(1)
        try:
            _chrome_bat_yeu_cau_that(kenh)    # GD145: rut su kien mang (hoc header trang tu goi)
            token = _chrome_chon_token_moi(kenh, cu, t_noi)
        except IOError as e:
            kenh.dong()
            kenh = _chrome_noi_lai(the_he, e)
            if kenh is None:
                return
            CHROME["kenh"] = kenh
            continue
        except Exception:
            continue
        if token:
            tk_yc = CHROME.get("tk_moi_nhat") or ""
            if tk_yc and tk_yc not in cu and _token_con_han(tk_yc) and tk_yc != token:
                LOG.ghi("[CHROME] Lay phien lam viec THAT tu yeu cau trang vua goi: %s" % mask_tail(tk_yc))
                token = tk_yc
            STATE["token"] = token
            if not STATE["may_chu"]:
                STATE["may_chu"] = TRANG_WEB + "/api"
            mst = ""
            try:
                phan = token.split(".")[1]
                phan += "=" * (-len(phan) % 4)
                payload = json.loads(base64.urlsafe_b64decode(phan).decode("utf-8", "replace"))
                for k in ("sub", "username", "user_name", "mst", "taxCode", "tin"):
                    v = payload.get(k)
                    if isinstance(v, str) and re.fullmatch(r"\d{10}(-\d{3})?", v.strip()):
                        mst = v.strip(); break
            except Exception:
                pass
            if not mst:
                # P0 18/11/2026: KHONG lay MST cua bo so / cai dat thay vao (truoc day phep so 'khac MST' vi the luon khop).
                #   Phien khong doc duoc MST -> unesco_loi_khac_mst chan (che do UNESCO); lo tai hoi nguoi xac nhan.
                LOG.ghi("[CHROME] KHONG doc duoc MST tu phien dang nhap - chua xac nhan duoc dung cong ty.")
            STATE["mst"] = mst
            CHROME["mst"] = mst
            LOG.ghi("[CHROME] DANG NHAP THANH CONG qua Chrome. MST: %s | phien: %s" % (mst, mask_tail(token)))
            try:                                  # GD369: ghi han phien (hoc thoi gian song cua token - quyet dinh co tai lai dung duoc khong)
                _pl = _jwt_payload(token)
                if _pl.get("exp"):
                    _iat = float(_pl.get("iat") or time.time())
                    LOG.ghi("[CHROME] Phien cap luc %s, het han %s (song %.0f phut)." % (
                        time.strftime("%d/%m %H:%M", time.localtime(_iat)), time.strftime("%d/%m %H:%M", time.localtime(float(_pl["exp"]))),
                        (float(_pl["exp"]) - _iat) / 60.0))
            except Exception:
                pass
            hen_gio_xoa_moc()
            loi_mst = unesco_loi_khac_mst(mst)      # GD43: phien Chrome cua cong ty khac -> bao ngay, cac buoc sau bi chan
            if loi_mst:
                CHROME["loi"] = loi_mst
                unesco_bao_khac_mst(loi_mst)
            CHROME["nhan_token"] = True
            _chrome_hoc_cach_goi(kenh)
            if CHROME.get("the_he") != the_he:
                return
            # 26/11/2026 dot 4: DA BO buoc «dua the Trang thue ve muc Tra cuu» them o dot 2. Thu that (20:08-20:17): nap thang duong
            #   /tra-cuu/tra-cuu-hoa-don lam cong tra trang 403 «khong co quyen truy cap», trang mat phien -> bat dang nhap lai lien tuc,
            #   trong khi lenh goi dich vu van 200. Sau dang nhap KHONG dieu huong gi them (nhu loi Chrome truoc dot 2).
            CHROME["da_bao_trang_403"] = False
            CHROME["trang_thai"] = "da_dang_nhap"
            if SETTINGS.get("thu_nho_trang_thue", True):
                _chrome_cua_so("minimized")     # GD145: dang nhap xong -> trang thue tu thu nho (tool chay ben trong)
            threading.Thread(target=_chrome_theo_doi, args=(the_he,), daemon=True).start()
            return


def _chrome_bat_yeu_cau_that(kenh):
    """(giu ten cu) Doc va xu ly su kien cua tab Chrome."""
    try:
        kenh.hut_su_kien(0.2)
    except Exception:
        return
    _chrome_xu_ly_su_kien(kenh)


import uuid

# Cong viec "muon tay trang": tool muon trang thue tu gui 1 yeu cau, roi doi URL cua yeu cau do
CHROME_VIEC = {"cho": None, "khoa": threading.Lock()}
_HEADER_LOG_DAY_DU = ("action", "end-point", "request-id", "accept-language")


def _mau_tu_header(h):
    return {k: v for k, v in h.items() if k.lower() not in _HEADER_BO and not k.startswith(":")}


def _chrome_xu_ly_su_kien(kenh):
    while kenh.su_kien:
        ev = kenh.su_kien.popleft()
        pt = ev.get("method")
        p = ev.get("params", {})
        try:
            if pt == "Fetch.requestPaused":
                _xu_ly_tam_dung(kenh, p)
            elif pt == "Network.requestWillBeSent":
                _xu_ly_yeu_cau(p)
            elif pt == "Network.responseReceived":
                r = p.get("response", {})
                CHROME.setdefault("dap", {})[p.get("requestId")] = (int(r.get("status") or 0), r.get("mimeType", ""))
                if "/privileges/menu" in (r.get("url") or "") and int(r.get("status") or 0) == 200:
                    CHROME["menu_xong"] = True          # GD145: trang da nap menu quyen sau dang nhap
            elif pt in ("Network.loadingFinished", "Network.loadingFailed"):
                _xu_ly_xong(kenh, p, pt == "Network.loadingFailed")
        except Exception as e:
            LOG.ghi("[CHROME] Loi xu ly su kien %s: %s" % (pt, str(e)[:200]))
    if len(CHROME.get("dap", {})) > 5000:
        CHROME["dap"] = {}


def _xu_ly_yeu_cau(p):
    rq = p.get("request", {})
    url = rq.get("url", "")
    if not url.startswith(TRANG_WEB + "/api/") or "/captcha" in url:
        return
    h = rq.get("headers") or {}
    thap = {k.lower(): v for k, v in h.items()}
    if "x-unesco-tool" in thap:
        return                                  # yeu cau do chinh tool gui -> khong hoc
    auth = thap.get("authorization", "")
    if not auth:
        return
    tk = auth.split(" ", 1)[-1].strip()
    # GD145: mang duoc theo doi tu truoc khi dang nhap - yeu cau mang token CU (ho so lan truoc) khong hoc, khong lay phien
    if tk in (CHROME.get("tk_cu") or ()):
        return
    duong = url.split("?")[0][len(TRANG_WEB):]
    mau = _mau_tu_header(h)
    CHROME.setdefault("mau_theo_duong", {})[duong] = mau
    CHROME["header_mau"] = mau
    CHROME["so_yeu_cau_bat"] += 1
    CHROME["co_yc_moi"] = True
    if tk:
        CHROME["tk_moi_nhat"] = tk
    if tk and tk != STATE.get("token") and CHROME.get("nhan_token"):
        STATE["token"] = tk
        LOG.ghi("[CHROME] Lay phien lam viec THAT tu yeu cau cua trang: %s" % mask_tail(tk))
    chi_tiet = []
    for k, v in mau.items():
        kl = k.lower()
        if kl == "authorization":
            chi_tiet.append(k + "=***")
        elif kl in _HEADER_LOG_DAY_DU:
            chi_tiet.append("%s=%s" % (k, str(v)[:300]))
        else:
            chi_tiet.append(k + ("=" + str(v) if len(str(v)) < 40 else "=…"))
    LOG.ghi("[CHROME] Trang tu goi: %s %s | header: %s" % (rq.get("method"), duong, ", ".join(chi_tiet)))


def _xu_ly_tam_dung(kenh, p):
    """Fetch.requestPaused: neu tool dang cho 'muon tay trang' thi doi URL; neu khong thi cho di tiep."""
    rid = p.get("requestId")
    rq = p.get("request", {})
    url = rq.get("url", "")
    thap = {k.lower(): v for k, v in (rq.get("headers") or {}).items()}
    viec = None
    with CHROME_VIEC["khoa"]:
        v = CHROME_VIEC["cho"]
        if (v and v.get("trang_thai") == "cho" and url.startswith(TRANG_WEB + "/api/")
                and "/captcha" not in url and "x-unesco-tool" not in thap and thap.get("authorization")):
            viec = v
            v["trang_thai"] = "da_doi"
            v["network_id"] = p.get("networkId")
    if viec is None:
        kenh.goi("Fetch.continueRequest", {"requestId": rid})
        return
    tham_so = {"requestId": rid, "url": viec["url"], "method": viec["method"]}
    hd = [{"name": k, "value": v} for k, v in (rq.get("headers") or {}).items()]
    if viec.get("body") is not None:
        tham_so["postData"] = base64.b64encode(viec["body"].encode("utf-8")).decode("ascii")
        hd = [x for x in hd if x["name"].lower() != "content-type"] + [{"name": "Content-Type", "value": "application/json;charset=UTF-8"}]
    tham_so["headers"] = hd
    LOG.ghi("[CHROME] Muon yeu cau cua trang (%s) -> doi thanh %s %s" % (url.split("?")[0][len(TRANG_WEB):], viec["method"], viec["url"].split("?")[0][len(TRANG_WEB):]))
    kenh.goi("Fetch.continueRequest", tham_so)


def _xu_ly_xong(kenh, p, that_bai):
    rid = p.get("requestId")
    with CHROME_VIEC["khoa"]:
        v = CHROME_VIEC["cho"]
        if not (v and v.get("trang_thai") == "da_doi" and v.get("network_id") == rid):
            return
    if that_bai:
        v["kq"] = (0, "", b"", p.get("errorText", "loi tai"))
        v["xong"].set()
        return
    st, mime = CHROME.get("dap", {}).get(rid, (0, ""))
    try:
        r = kenh.goi("Network.getResponseBody", {"requestId": rid})
        raw = base64.b64decode(r.get("body", "")) if r.get("base64Encoded") else (r.get("body") or "").encode("utf-8")
    except Exception as e:
        raw = b""
        if st == 0:
            v["kq"] = (0, "", b"", "khong doc duoc noi dung: " + str(e)[:150])
            v["xong"].set()
            return
    v["kq"] = (st, mime, raw, "")
    v["xong"].set()


_JS_BAM_TIM_KIEM = r"""
(() => {
  const bs = Array.from(document.querySelectorAll('button'));
  const b = bs.find(x => (x.textContent || '').trim().toLowerCase() === 'tìm kiếm');
  if (!b) return 'khong_thay_nut';
  b.click(); return 'da_bam';
})()
"""


def _chrome_url(kenh):
    try:
        return kenh.chay_js("location.href") or ""
    except Exception:
        return ""


def _chrome_la_trang_403(kenh):
    try:
        return bool(kenh.chay_js(_JS_LA_TRANG_403))
    except Exception:
        return False


def _chrome_ve_trang_tra_cuu(kenh):
    """Mo trang Tra cuu hoa don. GD87: uu tien bam LIEN KET trong ung dung (khong tai lai ca trang -> giu phien
    vua dang nhap); khong thay lien ket moi dat location.href. Neu trang bao 403 'khong co quyen truy cap'
    (phien chua on dinh) -> ve trang chu, doi, thu lai dung 1 lan.
    GD145: CHO menu quyen nap xong (lien ket Tra cuu xuat hien, ke ca trong menu dang an) toi 12 giay roi moi bam -
    nhat ky cac phien truoc: tool dat location.href 2-4 giay sau dang nhap khi menu chua co -> trang bao 403 lan 1."""
    if "/tra-cuu/tra-cuu-hoa-don" in _chrome_url(kenh):
        return
    for lan in (1, 2):
        t0 = time.time()
        while time.time() - t0 < 12:
            try:
                _chrome_bat_yeu_cau_that(kenh)
                if kenh.chay_js(_JS_CO_LINK_TRA_CUU):
                    break
            except IOError:
                raise
            except Exception:
                pass
            time.sleep(0.5)
        cach = "khong_thay"
        try:
            cach = kenh.chay_js(_JS_BAM_LINK_TRA_CUU)
        except Exception:
            pass
        if cach != "da_bam":
            try:
                kenh.chay_js("location.href = %s" % json.dumps(TRANG_WEB + "/tra-cuu/tra-cuu-hoa-don"))
            except Exception:
                pass
        t0 = time.time()
        while time.time() - t0 < 8 and "/tra-cuu/tra-cuu-hoa-don" not in _chrome_url(kenh):
            time.sleep(0.5)
        time.sleep(3)
        if not _chrome_la_trang_403(kenh):
            LOG.ghi("[CHROME] Da mo trang Tra cuu hoa don (%s)." % ("lien ket trong trang" if cach == "da_bam" else "location.href"))
            return
        LOG.ghi("[CHROME] Trang thue bao 403 'khong co quyen truy cap' sau khi mo Tra cuu (lan %d) - ve trang chu, doi roi thu lai." % lan)
        if lan == 2:
            return
        try:
            kenh.chay_js("location.href = %s" % json.dumps(TRANG_WEB + "/"))
        except Exception:
            pass
        time.sleep(6)


def _chrome_hoc_cach_goi(kenh):
    """Sau dang nhap: bat chan yeu cau (de 'muon tay trang'), hoc header that cua trang.
    GD145: mang da theo doi tu luc noi tab -> CHO toi 15 giay cac yeu cau trang tu goi ngay sau dang nhap (ho so, menu
    quyen). Hoc duoc header tu do thi KHONG chuyen trang (het 403 lan dau); chua hoc duoc moi mo Tra cuu (bang lien ket
    trong trang, sau khi menu nap xong) va bam 'Tim kiem'."""
    _chrome_bat_mang(kenh)
    try:
        kenh.goi("Fetch.enable", {"patterns": [{"urlPattern": TRANG_WEB + "/api/*", "requestStage": "Request"}]})
    except Exception as e:
        LOG.ghi("[CHROME] Khong bat duoc chan yeu cau: " + str(e)[:150])
    t0 = time.time()
    while time.time() - t0 < 15:
        _chrome_bat_yeu_cau_that(kenh)
        if CHROME.get("co_yc_moi") and CHROME.get("mau_theo_duong") and (CHROME.get("menu_xong") or time.time() - t0 > 6):
            LOG.ghi("[CHROME] Da hoc duoc cach goi tu yeu cau trang tu goi sau dang nhap (%d yeu cau) - khong can mo trang Tra cuu."
                    % CHROME["so_yeu_cau_bat"])
            return
        time.sleep(0.5)
    try:
        _chrome_ve_trang_tra_cuu(kenh)
    except Exception as e:
        LOG.ghi("[CHROME] Chua mo duoc trang Tra cuu: " + str(e)[:150])
    t0 = time.time()
    da_bam = False
    while time.time() - t0 < 25:
        time.sleep(0.5)
        _chrome_bat_yeu_cau_that(kenh)
        if CHROME.get("co_yc_moi") and CHROME.get("mau_theo_duong"):
            LOG.ghi("[CHROME] Da hoc duoc cach goi cua trang (%d yeu cau)." % CHROME["so_yeu_cau_bat"])
            return
        if not da_bam and time.time() - t0 > 2:
            try:
                kq = kenh.chay_js(_JS_BAM_TIM_KIEM)
                LOG.ghi("[CHROME] Tu bam 'Tim kiem' tren trang: " + str(kq))
                da_bam = (kq == "da_bam")
            except Exception as e:
                LOG.ghi("[CHROME] Chua bam duoc 'Tim kiem': " + str(e)[:120])
    LOG.ghi("[CHROME] Chua bat duoc yeu cau nao cua trang - se goi voi header mac dinh.")


def _phien_con_song(kenh):
    """26/11/2026 dot 4: phien dang giu (STATE['token']) con dung duoc khong - hoi cong MOT lenh nhe ma trang thue tu goi sau dang
    nhap (/security-taxpayer/profile), gui tu trong trang nhu moi lenh khac. True chi khi cong tra 200. Chua tung thay trang goi
    duong nay / token het han / loi -> False (xu ly nhu truoc: doi dang nhap lai)."""
    try:
        tk = STATE.get("token") or ""
        if not tk or not _token_con_han(tk):
            return False
        duong = "/api/security-taxpayer/profile"
        if duong not in (CHROME.get("mau_theo_duong") or {}):
            return False
        st, _ctype, _raw, _loi = _goi_fetch_trong_tab(kenh, TRANG_WEB + duong, "GET", None, tk, False)
        LOG.ghi("[CHROME] Kiem phien bang lenh nhe (profile): ma tra ve %s" % st)
        return st == 200
    except Exception as e:
        LOG.ghi("[CHROME] Khong kiem duoc phien bang lenh nhe: " + str(e)[:120])
        return False


def _chrome_theo_doi(the_he=None):
    """Chay nen suot phien: xu ly su kien (hoc header, cho yeu cau tam dung di tiep, nhan ket qua).
    GD87: cu 5 giay kiem tra phien con khong (token con han, hop dang nhap khong mo); mat phien (trang thue
    dang xuat / 403 / het han) -> quay ve trang thai 'dang_cho' va cho nguoi dung dang nhap lai, thay vi
    ke tiep goi voi token chet.
    GD145: Chrome bi dong -> 'dong' (bam mo lai duoc); mat phien -> HIEN LAI cua so trang thue de dang nhap lai."""
    if the_he is None:
        the_he = CHROME.get("the_he", 0)
    t_kiem = time.time()
    mat = 0
    while CHROME["trang_thai"] == "da_dang_nhap" and CHROME["kenh"] is not None and CHROME.get("the_he") == the_he:
        kenh = CHROME["kenh"]
        if kenh.loi_ket_noi:
            if not _chrome_song():
                time.sleep(2)
                if not _chrome_song():
                    _chrome_da_dong("nguoi dung dong Chrome")
                    return
            k2 = _chrome_noi_lai(the_he, kenh.loi_ket_noi)
            if k2 is None:
                return
            CHROME["kenh"] = k2
            try:
                k2.goi("Fetch.enable", {"patterns": [{"urlPattern": TRANG_WEB + "/api/*", "requestStage": "Request"}]})
            except Exception:
                pass
            continue
        try:
            _chrome_bat_yeu_cau_that(kenh)
        except Exception:
            pass
        time.sleep(0.25)
        if time.time() - t_kiem < 5:
            continue
        t_kiem = time.time()
        try:
            with CHROME_VIEC["khoa"]:
                dang_muon = CHROME_VIEC["cho"] is not None
            if dang_muon:
                continue                      # dang 'muon tay trang' - khong chen JS vao giua
            con = any(_token_con_han(t) for t in _chrome_lay_tokens(kenh)) and not _chrome_hop_dang_nhap_mo(kenh)
        except Exception:
            continue                          # tab dang chuyen trang: bo qua lan nay
        if con:
            mat = 0
            continue
        mat += 1
        if mat < 2:
            continue                          # can 2 lan lien tiep (10 giay) de tranh bao nham luc trang dang tai
        # 26/11/2026 dot 4: GIAO DIEN trang thue trong nhu mat phien (trang 403 «khong co quyen truy cap», trang bi nap lai mat token
        #   trong trang...) CHUA chac la mat phien: hoi cong mot lenh nhe ma chinh trang van goi (profile) bang phien dang giu.
        #   Cong tra 200 -> phien con dung duoc: de yen trang, KHONG doi dang nhap lai, tiep tuc tai bang lenh goi; kiem lai moi phut.
        #   Cong tra 401 / 403 / khong goi duoc -> mat phien that, xu ly nhu truoc.
        #   Lenh kiem chay o luong RIENG: chinh vong lap nay la noi cho cac yeu cau dang bi tam dung (Fetch.requestPaused) di tiep,
        #   goi thang tu day thi lenh kiem tu khoa chinh no.
        kq_song = []
        luong_kiem = threading.Thread(target=lambda: kq_song.append(_phien_con_song(kenh)), daemon=True)
        luong_kiem.start()
        t_cho = time.time()
        while luong_kiem.is_alive() and time.time() - t_cho < 30:
            try:
                _chrome_bat_yeu_cau_that(kenh)
            except Exception:
                pass
            time.sleep(0.1)
        if kq_song and kq_song[0]:
            if not CHROME.get("da_bao_trang_403"):
                CHROME["da_bao_trang_403"] = True
                LOG.ghi("[CHROME] Trang thue khong con hien dang nhap (trang 403 / da nap lai) nhung lenh goi dich vu van duoc (200) - "
                        "giu phien, KHONG doi dang nhap lai.")
            mat = 0
            t_kiem = time.time() + 55          # lan kiem ke tiep sau ~60 giay (khong hoi cong don dap)
            continue
        LOG.ghi("[CHROME] Phien tren trang thue da mat (dang xuat / 403 / het han) - cho nguoi dung dang nhap lai.")
        STATE["token"] = ""
        CHROME["nhan_token"] = False
        CHROME["co_yc_moi"] = False
        CHROME["trang_thai"] = "dang_cho"
        CHROME["loi"] = "Phiên trang thuế đã hết - cửa sổ trang thuế đã hiện lại, hãy đăng nhập lại."
        _chrome_cua_so("normal")
        threading.Thread(target=_chrome_cho_dang_nhap, args=(the_he,), daemon=True).start()
        return


def chrome_dang_bat():
    return CHROME["trang_thai"] == "da_dang_nhap" and CHROME["kenh"] is not None


def _chon_mau_header(url):
    """Chon bo header mau gan nhat voi duong dan can goi."""
    duong = url.split("?")[0][len(TRANG_WEB):]
    ds = CHROME.get("mau_theo_duong") or {}
    if duong in ds:
        return dict(ds[duong])
    # cung nhom (query/invoices, sco-query/invoices, invoice/...)
    nhom = "/".join(duong.split("/")[:3])
    for k, v in ds.items():
        if k.startswith(nhom):
            return dict(v)
    for k, v in ds.items():             # bat ky yeu cau nao co Action
        if any(kk.lower() == "action" and vv for kk, vv in v.items()):
            return dict(v)
    return dict(CHROME.get("header_mau") or {})


def _goi_fetch_trong_tab(kenh, url, method, body, token, ghi_log):
    headers = {"Accept": "application/json, text/plain, */*", "Accept-Language": "vi"}
    headers.update(_chon_mau_header(url))
    # cac header "song": moi yeu cau mot ma rieng + duong dan man hinh hien tai
    for k in list(headers.keys()):
        if k.lower() == "request-id":
            headers[k] = str(uuid.uuid4())
        elif k.lower() == "end-point":
            headers[k] = "/tra-cuu/tra-cuu-hoa-don"
    if "request-id" not in {k.lower() for k in headers}:
        headers["request-id"] = str(uuid.uuid4())
    if "end-point" not in {k.lower() for k in headers}:
        headers["End-Point"] = "/tra-cuu/tra-cuu-hoa-don"
    headers["X-Unesco-Tool"] = "1"
    if token:
        headers["Authorization"] = "Bearer " + token
    tuy_chon = {"method": method, "headers": headers, "credentials": "include"}
    if body is not None:
        headers["Content-Type"] = "application/json;charset=UTF-8"
        tuy_chon["body"] = json.dumps(body, ensure_ascii=False)
    js = _JS_FETCH % (json.dumps(url), json.dumps(tuy_chon))
    kq_txt = kenh.chay_js(js, cho_promise=True)
    kq = json.loads(kq_txt or "{}")
    st = int(kq.get("s") or 0)
    if st == 0:
        return 0, "", b"", str(kq.get("e", ""))[:300]
    return st, kq.get("t") or "", base64.b64decode(kq.get("d") or ""), ""


def _goi_muon_tay_trang(kenh, url, method, body, timeout, ghi_log):
    """Bam 'Tim kiem' de trang tu gui 1 yeu cau (co du chu ky cua trang), roi doi URL cua yeu cau do."""
    viec = {"url": url, "method": method, "body": json.dumps(body, ensure_ascii=False) if body is not None else None,
            "trang_thai": "cho", "xong": threading.Event(), "kq": None, "network_id": None}
    with CHROME_VIEC["khoa"]:
        CHROME_VIEC["cho"] = viec
    try:
        _chrome_ve_trang_tra_cuu(kenh)
        kq = kenh.chay_js(_JS_BAM_TIM_KIEM)
        if kq != "da_bam":
            LOG.ghi("[CHROME] Khong thay nut 'Tim kiem' tren trang (%s)" % kq)
        if not viec["xong"].wait(timeout):
            return 0, "", b"", "Trang thue khong gui yeu cau nao trong %d giay" % timeout
        return viec["kq"]
    finally:
        with CHROME_VIEC["khoa"]:
            CHROME_VIEC["cho"] = None


def goi_mang_qua_chrome(url, method="GET", body=None, token=None, timeout=60, ghi_log=True):
    """Goi mang BEN TRONG tab Chrome -> KetQuaMang. Thu 'fetch' truoc; bi 403 thi 'muon tay trang'."""
    kenh = CHROME["kenh"]
    if ghi_log:
        LOG.ghi("[MANG/CHROME] %s %s" % (method, url))
    t0 = time.time()
    cach = CHROME.get("cach") or "fetch"
    try:
        if cach == "fetch":
            st, ctype, raw, loi = _goi_fetch_trong_tab(kenh, url, method, body, token, ghi_log)
            if st == 403 and "/api/" in url:
                LOG.ghi("[MANG/CHROME] -> fetch bi 403, chuyen sang 'muon tay trang'...")
                st, ctype, raw, loi = _goi_muon_tay_trang(kenh, url, method, body, timeout, ghi_log)
                if 200 <= st < 300:
                    CHROME["cach"] = "muon"
                    LOG.ghi("[CHROME] 'Muon tay trang' thanh cong - dung cach nay cho cac lenh sau.")
        else:
            st, ctype, raw, loi = _goi_muon_tay_trang(kenh, url, method, body, timeout, ghi_log)
    except Exception as e:
        if ghi_log:
            LOG.ghi("[MANG/CHROME] -> loi goi qua Chrome: " + str(e)[:300])
        return KetQuaMang(False, 0, b"", "", "Mat ket noi voi Chrome: " + str(e)[:200])
    if st == 0:
        if ghi_log:
            LOG.ghi("[MANG/CHROME] -> khong goi duoc: " + loi)
        return KetQuaMang(False, 0, b"", "", loi)
    if 200 <= st < 300:
        if ghi_log:
            LOG.ghi("[MANG/CHROME] -> ma tra ve %s | kieu du lieu: %s | dung luong: %d byte | mat %.1f giay"
                    % (st, ctype or "khong ro", len(raw), time.time() - t0))
        return KetQuaMang(True, st, raw, ctype)
    loi = raw.decode("utf-8", "replace")[:500]
    if ghi_log:
        LOG.ghi("[MANG/CHROME] -> ma tra ve %s | dung luong loi: %d byte" % (st, len(raw)))
        LOG.ghi("[MANG/CHROME] -> NGUYEN VAN loi tu may chu: " + loi)
    return KetQuaMang(False, st, b"", "", loi)


# ==========================================================================
#  CAC VIEC CHINH
# ==========================================================================
def lay_captcha():
    if not STATE["may_chu"]:
        STATE["may_chu"] = tim_may_chu()
    if not STATE["may_chu"]:
        return None, "Không kết nối được tới máy chủ của Cục Thuế. Kiểm tra lại mạng Internet rồi thử lại."

    kq = goi_mang(STATE["may_chu"] + "/captcha", timeout=25)
    if not kq.ok:
        return None, "Không lấy được mã captcha. Máy chủ trả về: " + (kq.loi or "không rõ lý do")
    j = kq.json()
    if not j:
        return None, "Máy chủ trả về dữ liệu captcha không đọc được."
    STATE["ckey"] = j.get("key")
    LOG.ghi("[CAPTCHA] Da lay duoc anh captcha moi.")
    return j.get("content", ""), None


def dang_nhap(mst, mat_khau, ma_captcha):
    loi_mst = unesco_loi_khac_mst(mst)      # GD43: khong cho dang nhap tai khoan cong ty khac
    if loi_mst:
        LOG.ghi("[DANG NHAP] TU CHOI: MST %s khac bo so %s" % (mst, UNESCO.get("mst")))
        return False, loi_mst
    if not STATE["may_chu"]:
        STATE["may_chu"] = tim_may_chu()
    if not STATE["may_chu"]:
        return False, "Không kết nối được tới máy chủ của Cục Thuế. Kiểm tra lại mạng Internet rồi thử lại."

    LOG.ghi("[DANG NHAP] Bat dau dang nhap voi ma so thue %s" % mst)
    body = {"ckey": STATE["ckey"], "cvalue": ma_captcha,
            "username": mst, "password": mat_khau}
    kq = goi_mang(STATE["may_chu"] + "/security-taxpayer/authenticate",
                  method="POST", body=body, timeout=40)
    if not kq.ok:
        thong_bao = "Đăng nhập không thành công."
        if kq.status == 400:
            thong_bao = "Sai mã số thuế, mật khẩu hoặc mã captcha. Bấm vào ảnh captcha để lấy mã mới rồi nhập lại."
        elif kq.status == 403:
            thong_bao = ("Máy chủ Cục Thuế chặn đăng nhập từ công cụ (403). Cách đăng nhập trực tiếp này KHÔNG còn dùng được. "
                         "Hãy bấm nút xanh \"Đăng nhập qua Chrome (khuyên dùng)\" ở đầu Bước 1, rồi đăng nhập ngay trên trang thuế "
                         "trong cửa sổ Chrome vừa mở — tool sẽ tự nhận phiên và tải tiếp.")
        elif kq.status == 0:
            thong_bao = "Không kết nối được tới máy chủ Cục Thuế. Kiểm tra lại mạng Internet."
        return False, thong_bao + " (Máy chủ báo: " + (kq.loi[:200] or "không rõ") + ")"

    j = kq.json() or {}
    token = j.get("token")
    if not token:
        LOG.ghi("[DANG NHAP] May chu tra ve khong co token.")
        return False, "Máy chủ không cấp phiên làm việc. Thử lấy mã captcha mới rồi đăng nhập lại."

    STATE["token"] = token
    STATE["mst"] = mst
    LOG.ghi("[DANG NHAP] THANH CONG. Ma so thue: %s | phien lam viec: %s" % (mst, mask_tail(token)))
    return True, None


def _ngay_thue(d, cuoi_ngay=False):
    """'2026-08-19' -> '19/08/2026T23:59:59'"""
    y, m, dd = d.split("-")
    gio = "23:59:59" if cuoi_ngay else "00:00:00"
    return "%s/%s/%sT%s" % (dd, m, y, gio)


# ---------------------------------------------------------------- GD20: chia khoang ngay
# Cong Thue gioi han khoang tra cuu moi lan (thuong 31 ngay) va moi lan chi lat toi da
# 60 trang x 50 = 3000 hoa don. Chon "theo nam" ma goi mot phat thi hoac bi tu choi,
# hoac bi cat bot ma KHONG bao gi - nen luon chia nho khoang ngay roi gop lai.
CHIA_NGAY_MAC_DINH = 31


def _ngay_tu_chuoi(s):
    s = str(s or "").strip()[:10]
    for m in ("%Y-%m-%d", "%d/%m/%Y"):
        try:
            return datetime.strptime(s, m).date()
        except Exception:
            pass
    return None


def chia_khoang_ngay(tu, den, so_ngay=None):
    """Chia [tu, den] thanh cac doan <= so_ngay. Tra ve list (chuoi_tu, chuoi_den) yyyy-mm-dd."""
    if so_ngay is None:
        try:
            so_ngay = int(SETTINGS.get("so_ngay_moi_lan") or CHIA_NGAY_MAC_DINH)
        except Exception:
            so_ngay = CHIA_NGAY_MAC_DINH
    if so_ngay < 1:
        so_ngay = CHIA_NGAY_MAC_DINH
    d1 = _ngay_tu_chuoi(tu)
    d2 = _ngay_tu_chuoi(den)
    if d1 is None or d2 is None or d2 < d1:
        return [(tu, den)]
    if (d2 - d1).days + 1 <= so_ngay:
        return [(tu, den)]
    ra = []
    cur = d1
    # >= 28 ngay thi cat theo BIEN THANG cho de doi chieu voi so sach
    theo_thang = so_ngay >= 28
    while cur <= d2:
        if theo_thang:
            if cur.month == 12:
                cuoi_thang = cur.replace(month=12, day=31)
            else:
                cuoi_thang = cur.replace(month=cur.month + 1, day=1) - timedelta(days=1)
            het = min(cuoi_thang, d2)
        else:
            het = min(cur + timedelta(days=so_ngay - 1), d2)
        ra.append((cur.strftime("%Y-%m-%d"), het.strftime("%Y-%m-%d")))
        cur = het + timedelta(days=1)
    return ra


def _khoa_hoa_don(hd):
    return "|".join(str(hd.get(k) or "") for k in ("nbmst", "khmshdon", "khhdon", "shdon", "tdlap"))


# GD112: cong thue qua tai (502 / 503 / 504 "Gateway Time-out" sau 60 giay) - hay gap khi lat nhieu trang HD may tinh tien
QUA_TAI = (502, 503, 504)
CHO_QUA_TAI = (10, 30)          # hoi lai CUNG trang sau 10 giay, roi 30 giay
TRA_CUU_CANH_BAO = []           # canh bao cua lan tra_cuu gan nhat (ngay chua lay duoc...) - dong bo / tim kiem hien ra
# P0 18/11/2026: tran so trang MOT lan tra cuu (x 50 HD/trang) - chan an toan cua tool, KHONG phai quy dinh cua cong.
#   Cham tran ma cong con trang -> _tra_cuu_doan chia theo ngay; mot ngay van cham tran -> canh bao "chua lay duoc du" (khong bao du).
TRA_CUU_TRAN_TRANG = 400
TRA_CUU_CO_TRANG = 50


def _ds_tra_cuu(j):
    """P0 18/11/2026: kiem cau truc mot trang ket qua tra cuu cua cong. -> (rows, None) hoac (None, mo_ta_loi).
    Truoc day JSON hong / trang HTML tra 200 / thieu 'datas' deu thanh danh sach RONG = 'cong khong co hoa don'."""
    if not isinstance(j, dict):
        return None, "không phải dữ liệu JSON (có thể là trang HTML / trang lỗi)"
    if "datas" in j:
        ds = j.get("datas")
        if ds is None:
            ds = []
        if not isinstance(ds, list) or any(not isinstance(x, dict) for x in ds):
            return None, "trường 'datas' không phải danh sách hoá đơn"
        return ds, None
    if j.get("total") == 0 and not any(k in j for k in ("message", "error", "errors", "code")):
        return [], None          # cong noi ro tong = 0 (khong kem 'datas')
    return None, "thiếu danh sách hoá đơn ('datas'); các khoá nhận được: %s" % ", ".join(sorted(str(k) for k in j)[:8])
TEN_NHOM_HD = {("mua", "dt"): "Mua vào - HĐ điện tử", ("mua", "mtt"): "Mua vào - HĐ máy tính tiền",
               ("ban", "dt"): "Bán ra - HĐ điện tử", ("ban", "mtt"): "Bán ra - HĐ máy tính tiền"}


def _la_qua_tai(kq):
    """GD112: cong thue qua tai / khong tra loi kip (khong phai het phien, sai tham so)."""
    st = getattr(kq, "status", 0) or 0
    if st in QUA_TAI:
        return True
    # P2 18/11/2026: them "qua thoi gian" - chinh chuoi goi_mang tra khi socket.timeout (truoc day khong khop -> khong hoi lai / chia ngay)
    return st == 0 and bool(re.search(r"time ?out|timed out|het thoi gian|het gio|hết thời gian|qua thoi gian|quá thời gian",
                                      str(getattr(kq, "loi", "") or ""), re.I))


def _loi_may_chu(kq):
    """GD112: loi may chu -> cau ngan (bo the HTML cua trang loi gateway)."""
    st = getattr(kq, "status", 0) or 0
    if _la_qua_tai(kq):
        return "Máy chủ Cục Thuế quá tải, không trả lời kịp (%s)" % (("mã %d" % st) if st else "hết thời gian chờ")
    loi = re.sub(r"<[^>]+>", " ", str(getattr(kq, "loi", "") or ""))
    loi = re.sub(r"\s+", " ", loi).strip()
    return loi[:200] or "không rõ"


def _hoi_lai_khi_qua_tai(kq, url, trang):
    """GD112: trang tra cuu loi qua tai -> hoi lai CUNG dia chi (cung con tro state) sau 10s, 30s."""
    for lan, cho in enumerate(CHO_QUA_TAI):
        if kq.ok or not _la_qua_tai(kq):
            return kq
        cho = _cho_retry_after(getattr(kq, "retry_after", "")) or cho          # P2 18/11/2026: 503 co Retry-After thi theo cong
        LOG.ghi("[TRA CUU] Cong thue qua tai (%s) o trang %d - cho %d giay roi hoi lai trang nay (lan %d/%d)."
                % (getattr(kq, "status", 0) or "het gio", trang, cho, lan + 1, len(CHO_QUA_TAI)))
        _bao_cho("Cổng thuế quá tải - chờ %d giây rồi hỏi lại trang %d (lần %d/%d)" % (cho, trang, lan + 1, len(CHO_QUA_TAI)))
        ngu_du = ngu_huy_duoc(cho)
        _bao_cho("")
        if not ngu_du:          # P2: bam Dung trong luc cho -> thoi ngay
            return kq
        kq = goi_mang_kien_nhan(url, token=STATE["token"], timeout=60)
    return kq


def _dd_mm(d):
    try:
        y, m, dd = str(d)[:10].split("-")
        return "%s/%s" % (dd, m)
    except Exception:
        return str(d)


def _tra_cuu_doan(p):
    """GD112: tra cuu MOT doan ngay; cong qua tai (sau khi da hoi lai) -> chia tung NGAY. Ngay van loi -> bo CA ngay do
       (khong tra ve ngay thieu: khoa 'Chi tong hop ngay' se gop sai) va ghi TRA_CUU_CANH_BAO."""
    p1 = dict(p)
    rows, loi = tra_cuu_mot_doan(p1)
    tran = not loi and bool(p1.get("_cham_tran"))          # P0 18/11/2026: cham tran trang -> cung chia ngay nhu khi qua tai
    if not tran and (not loi or not p1.get("_qua_tai")):
        return rows, loi
    ly_do_tran = "quá %d hoá đơn - vượt trần %d trang của một lần tra cứu" % (TRA_CUU_TRAN_TRANG * TRA_CUU_CO_TRANG, TRA_CUU_TRAN_TRANG)
    ngay = chia_khoang_ngay(p.get("tu_ngay"), p.get("den_ngay"), 1)
    if p.get("khong_chia") or len(ngay) <= 1:
        p["_da_bao"] = True
        if tran:          # khong chia duoc nua: giu phan da lay, bao CHUA DU (khong im lang coi la du)
            TRA_CUU_CANH_BAO.append("chưa lấy được đủ %s (%s) - đã lấy %d hoá đơn"
                                    % ("ngày " + _dd_mm(p.get("tu_ngay")) if len(ngay) == 1 else "kết quả", ly_do_tran, len(rows or [])))
            return rows, None
        TRA_CUU_CANH_BAO.append("chưa lấy được %s (máy chủ Cục Thuế quá tải) - bấm lại sau ít phút"
                                % ("ngày " + _dd_mm(p.get("tu_ngay")) if len(ngay) == 1 else "kết quả"))
        return None, loi
    LOG.ghi("[TRA CUU] %s - chia %s -> %s thanh %d ngay (moi ngay it trang hon), ngay nao van loi thi bo ca ngay."
            % ("Cham tran trang" if tran else "Cong thue qua tai", p.get("tu_ngay"), p.get("den_ngay"), len(ngay)))
    tat_ca, da_co, thieu, tran_ngay, loi_ngay = [], set(), [], [], loi
    for d1, d2 in ngay:
        p2 = dict(p)
        p2["tu_ngay"], p2["den_ngay"] = d1, d2
        r2, l2 = tra_cuu_mot_doan(p2)
        if l2:
            if not p2.get("_qua_tai"):
                return None, l2          # het phien / loi khac: bao ngay, khong tra so lieu thieu
            thieu.append(d1)
            loi_ngay = l2
            LOG.ghi("[TRA CUU] Ngay %s van qua tai - BO ca ngay nay (bao nguoi dung dong bo lai)." % d1)
            continue
        if p2.get("_cham_tran"):
            tran_ngay.append(d1)
            LOG.ghi("[TRA CUU] Ngay %s van cham tran trang - giu phan da lay, bao CHUA DU." % d1)
        for hd in (r2 or []):
            k = _khoa_hoa_don(hd)
            if k not in da_co:
                da_co.add(k)
                tat_ca.append(hd)
    if thieu:
        p["_da_bao"] = True
        TRA_CUU_CANH_BAO.append("chưa lấy được ngày %s (máy chủ Cục Thuế quá tải) - bấm lại sau ít phút, các ngày khác đã đủ"
                                % ", ".join(_dd_mm(x) for x in thieu))
        if not tat_ca:
            return None, loi_ngay
    if tran_ngay:
        p["_da_bao"] = True
        TRA_CUU_CANH_BAO.append("chưa lấy được đủ ngày %s (%s)" % (", ".join(_dd_mm(x) for x in tran_ngay), ly_do_tran))
    LOG.ghi("[TRA CUU] Chia ngay: %d hoa don, %d ngay chua lay duoc, %d ngay cham tran." % (len(tat_ca), len(thieu), len(tran_ngay)))
    return tat_ca, None


def tra_cuu(p):
    """Lay hoa don theo bo loc. Khoang ngay dai -> tu chia thanh nhieu doan roi gop,
       khu trung theo khoa hoa don. Mot doan loi thi bao loi, khong tra ve so lieu thieu
       ma im lang."""
    del TRA_CUU_CANH_BAO[:]          # GD112
    doan = [] if p.get("khong_chia") else chia_khoang_ngay(p.get("tu_ngay"), p.get("den_ngay"))
    if len(doan) <= 1:
        return _tra_cuu_doan(p)          # GD112: qua tai -> chia ngay
    LOG.ghi("[TRA CUU] Khoang ngay dai - chia thanh %d doan de khong bi cong cat bot." % len(doan))
    tat_ca, da_co, loi_cuoi = [], set(), None
    for i, (d1, d2) in enumerate(doan):
        p2 = dict(p)
        p2["tu_ngay"], p2["den_ngay"] = d1, d2
        rows, loi = _tra_cuu_doan(p2)          # GD112: qua tai -> chia ngay
        if loi:
            loi_cuoi = loi
            LOG.ghi("[TRA CUU] Doan %d/%d (%s - %s) loi: %s" % (i + 1, len(doan), d1, d2, loi))
            if not p2.get("_da_bao"):          # GD112: bao ra giao dien (doan chia ngay da tu bao ngay nao thieu)
                TRA_CUU_CANH_BAO.append("chưa lấy được %s - %s: %s" % (_dd_mm(d1), _dd_mm(d2), loi))
            if "hết hạn" in loi or "het han" in loi or "đang CHẶN" in loi:          # P2: cong chan -> khong hoi them doan nao
                break
            continue
        moi = 0
        for hd in (rows or []):
            k = _khoa_hoa_don(hd)
            if k in da_co:
                continue
            da_co.add(k)
            tat_ca.append(hd)
            moi += 1
        LOG.ghi("[TRA CUU] Doan %d/%d (%s - %s): %d hoa don (%d moi, tong %d)."
                % (i + 1, len(doan), d1, d2, len(rows or []), moi, len(tat_ca)))
    if not tat_ca and loi_cuoi:
        return None, loi_cuoi
    if loi_cuoi:
        LOG.ghi("[TRA CUU] CANH BAO: co doan loi - so lieu co the chua du. Loi cuoi: " + str(loi_cuoi))
    return tat_ca, None


# GD359: tu cuoi 10/2026 cong thue bat CAPTCHA cho moi lan tra cuu (ke ca lat trang) hoa don MAY TINH TIEN
#   (/sco-query/invoices/sold|purchase can tham so ckey + cvalue). Tool KHONG tu giai captcha: hoi nguoi dung qua trang tool
#   (trang thai /api/captcha-mtt, gui /api/captcha-mtt-gui). Chay hen gio (khong co nguoi) -> bo qua phan MTT, bao lai.
CHO_CAPTCHA_MTT = {"can": False, "cho": False, "anh": "", "mo_ta": "", "loi": "", "cvalue": None, "huy": False, "bo_qua": False}
_SU_KIEN_CAPTCHA_MTT = threading.Event()


# 26/11/2026 dot 3: NHO theo so (tep mtt-nho.json trong thu muc du lieu cua khach) «so nay co hoa don may tinh tien khong» de khoi
#   bat nguoi dung go ma cho so khong bao gio co HD may tinh tien.
#     chon : "co" / "khong" = nguoi dung tu chon tren trang (thang moi suy doan);  "" = de may tu suy
#     mua / ban : {"n": so HD lan tim gan nhat (khoang >= 28 ngay, tim tron ven), "ngay": yyyy-mm-dd}
#   Tu suy: CA mua va ban deu n = 0 trong MTT_NHO_NGAY ngay gan day -> tam khong tra HD may tinh tien (o tick tren trang bo san).
MTT_NHO_TEP = "mtt-nho.json"
MTT_NHO_NGAY = 30


# 26/11/2026 dot 5: co trang ('size') cho lenh tim HD may tinh tien. Cong doi mot ma cho moi trang -> trang cang lon cang it lan go ma.
#   Thu lan luot 500 -> 200 -> 100 -> 50; nho THEO MAY (cai-dat.json, khoa mtt_co_trang) muc cong da nhan / da tu choi de luot sau dung luon.
#   Khong lien quan toi ma xac nhan: moi lenh van kem dung ma nguoi dung vua go.
MTT_CO_THU = (500, 200, 100, 50)


def mtt_co_trang():
    try:
        d = SETTINGS.get("mtt_co_trang") or {}
        if int(d.get("nhan") or 0) in MTT_CO_THU:
            return int(d["nhan"])
        tc = int(d.get("tu_choi") or 0)
        for c in MTT_CO_THU:
            if not tc or c < tc:
                return c
    except Exception:
        pass
    return TRA_CUU_CO_TRANG


def mtt_co_trang_nho(co, ly_do):
    d = dict(SETTINGS.get("mtt_co_trang") or {})
    if d.get("nhan") == co:
        return
    d["nhan"], d["ly_do"], d["ngay"] = int(co), ly_do, datetime.now().strftime("%Y-%m-%d")
    SETTINGS["mtt_co_trang"] = d
    luu_thiet_lap(SETTINGS)
    LOG.ghi("[TRA CUU] Nho co trang HD may tinh tien = %d (%s)." % (co, ly_do))


def mtt_co_trang_tu_choi(co):
    """Cong khong nhan co trang 'co' -> nho, tra ve muc ke tiep nho hon (thap nhat 50)."""
    d = dict(SETTINGS.get("mtt_co_trang") or {})
    d.pop("nhan", None)
    d["tu_choi"], d["ngay"] = int(co), datetime.now().strftime("%Y-%m-%d")
    SETTINGS["mtt_co_trang"] = d
    luu_thiet_lap(SETTINGS)
    return mtt_co_trang()


def mtt_nho_doc():
    d = _doc_json(MTT_NHO_TEP, {})
    return d if isinstance(d, dict) else {}


def mtt_nho_bo_qua():
    """-> (bo_qua, ly_do). bo_qua=True: mac dinh KHONG tra HD may tinh tien cho so nay (nguoi dung tick lai duoc)."""
    if not UNESCO.get("bat"):
        return False, ""
    d = mtt_nho_doc()
    if UNESCO.get("nhung"):
        # 26/11/2026 dot 5 (chu DN chot): cua so trong chuong trinh danh cho so KHONG co HD may tinh tien -> mac dinh khong tim loai nay,
        #   khong hoi ma lan nao. So da biet la co thi chi bao mot dong, chi sang loi Chrome / Huvisoft.
        try:
            co = d.get("chon") == "co" or any(int((d.get(k) or {}).get("n") or 0) > 0 for k in ("mua", "ban"))
        except Exception:
            co = False
        if co:
            return True, "SỔ NÀY CÓ hoá đơn máy tính tiền - cửa sổ trong chương trình không tải loại này: dùng lối Chrome hoặc Huvisoft để lấy phần đó"
        return True, "cửa sổ trong chương trình không tải hoá đơn máy tính tiền (khỏi gõ mã); sổ có loại này thì dùng lối Chrome hoặc Huvisoft"
    d = mtt_nho_doc()
    if d.get("chon") == "khong":
        return True, "bạn đã chọn không tải hoá đơn máy tính tiền cho sổ này"
    if d.get("chon") == "co":
        return False, ""
    try:
        moc = (datetime.now() - timedelta(days=MTT_NHO_NGAY)).strftime("%Y-%m-%d")
        hai = [d.get("mua") or {}] if d.get("chi_mua") else [d.get("mua") or {}, d.get("ban") or {}]          # dot 5: chi mua vao -> chi xet mua
        if all(x.get("ngay") and str(x.get("ngay")) >= moc and int(x.get("n") or 0) == 0 for x in hai):
            cu = min(str(x.get("ngay")) for x in hai)
            den = (datetime.strptime(cu, "%Y-%m-%d") + timedelta(days=MTT_NHO_NGAY)).strftime("%d/%m/%Y")
            return True, "lần tìm gần nhất sổ này không có hoá đơn máy tính tiền nào - tạm không tìm (tự tìm lại sau ngày %s)" % den
    except Exception:
        pass
    return False, ""


def mtt_nho_ghi(direction, so_hd, tu, den):
    """Ghi ket qua mot lan tim HD may tinh tien TRON VEN (khong loi, khong canh bao). Khoang < 28 ngay ma ra 0 thi khong ket luan."""
    try:
        if not UNESCO.get("bat") or direction not in ("mua", "ban"):
            return
        d1, d2 = _ngay_tu_chuoi(tu), _ngay_tu_chuoi(den)
        if not so_hd and (d1 is None or d2 is None or (d2 - d1).days + 1 < 28):
            return
        d = mtt_nho_doc()
        d[direction] = {"n": int(so_hd), "ngay": datetime.now().strftime("%Y-%m-%d")}
        _ghi_json(MTT_NHO_TEP, d)
    except Exception as e:
        LOG.ghi("[MTT NHO] Khong ghi duoc: " + str(e)[:150])


def xin_captcha_mtt(mo_ta, loi_truoc=""):
    """-> (ckey, cvalue) hoac (None, None) khi nguoi dung bo qua / het 5 phut / chay hen gio."""
    if CHO_CAPTCHA_MTT.get("bo_qua") or UNESCO.get("hengio"):
        return None, None
    # 26/11/2026 dot 2: moi anh ma mot so thu tu 'lan' (trang chi ve lai anh khi 'lan' doi - truoc day so theo mo ta nen anh moi
    #   cung mo ta co the khong duoc ve lai); nguoi dung bam «Lấy mã khác» ('doi') -> lay anh moi, tinh lai 5 phut; han cho 'het'.
    while True:
        anh, loi = lay_captcha()
        if loi:
            LOG.ghi("[CAPTCHA MTT] Khong lay duoc anh captcha: " + str(loi))
            return None, None
        ckey = STATE.get("ckey")
        _SU_KIEN_CAPTCHA_MTT.clear()
        CHO_CAPTCHA_MTT.update(cho=True, anh=anh, mo_ta=mo_ta, loi=loi_truoc, cvalue=None, huy=False, doi=False,
                               lan=int(CHO_CAPTCHA_MTT.get("lan") or 0) + 1, het=time.time() + 300)
        LOG.ghi("[CAPTCHA MTT] Cho nguoi dung nhap captcha: " + mo_ta)
        xong = _SU_KIEN_CAPTCHA_MTT.wait(300)
        CHO_CAPTCHA_MTT["cho"] = False
        if xong and CHO_CAPTCHA_MTT.get("doi") and not CHO_CAPTCHA_MTT.get("huy"):
            LOG.ghi("[CAPTCHA MTT] Nguoi dung xin anh ma khac.")
            loi_truoc = ""
            continue
        break
    if not xong or CHO_CAPTCHA_MTT.get("huy") or not CHO_CAPTCHA_MTT.get("cvalue"):
        LOG.ghi("[CAPTCHA MTT] Nguoi dung bo qua / het gio - khong tra cuu HD may tinh tien.")
        return None, None
    return ckey, CHO_CAPTCHA_MTT["cvalue"]


def _captcha_mtt_sai(kq):
    # 23/11/2026: cong thue tra 500 (khong phai 400) kem "Required request parameter 'ckey'..." -> xet theo NOI DUNG loi, moi ma loi
    if getattr(kq, "ok", False):
        return False
    s = ((getattr(kq, "loi", "") or "") + " " + str(getattr(kq, "status", ""))).lower()
    return "captcha" in s or "ckey" in s or "cvalue" in s or "mã xác" in s


def _mtt_doi_ckey(kq):
    """23/11/2026: tra cuu HD may tinh tien khong kem captcha -> cong bao thieu 'ckey' (thuc te ma 500, truoc la 400)."""
    return (not getattr(kq, "ok", False)) and "ckey" in (getattr(kq, "loi", "") or "").lower()


def nhap_excel_cong(tep):
    """GD359b: Excel 'Xuat chi tiet' cua cong thue (HD may tinh tien / HD thuong) -> JSONL cho UNESCO qua dung duong tai ve
    (dong hang lay tu Excel, khong hoi cong, khong can captcha). -> dict ket qua."""
    import excel_cong_thue as ECT
    if not UNESCO.get("bat"):
        return {"ok": False, "loi": "Mở Tải hoá đơn từ phần mềm UNESCO (bộ sổ đang mở) rồi nhập lại."}
    if not ECT.la_excel_cong(tep):
        return {"ok": False, "loi": "Tệp không đúng mẫu 'Xuất chi tiết' của trang hoadondientu.gdt.gov.vn (thiếu cột Ký hiệu / Số hoá đơn / MST người bán / Tên hàng)."}
    ds, n = ECT.doc(tep, UNESCO.get("mst") or STATE.get("mst") or "")
    if not ds:
        return {"ok": False, "loi": "Tệp không có hoá đơn."}
    so_cty = unesco_mst_so(UNESCO.get("mst"))
    khac = [o for o in ds if so_cty and not unesco_hd_thuoc_cty(o["hd"]["nbmst"], o["hd"]["nmmst"])]
    if khac and len(khac) == len(ds):
        return {"ok": False, "loi": "Hoá đơn trong tệp không thuộc công ty của bộ sổ đang mở (MST %s)." % so_cty}
    nhom = {}
    for o in ds:
        CHI_TIET_NHO[khoa_cua(o["hd"])] = o["ds"]
        nhom.setdefault((o["huong"], o["kind"]), []).append(o["hd"])
    tep_ra, tom = [], []
    for (huong, kind), danh_sach in nhom.items():
        kq = unesco_xuat_sau_khi_tai([], danh_sach, huong, kind, unesco_thu_muc("xml"), False)
        if kq:
            tep_ra.append(kq)
        tom.append("%d HĐ %s%s" % (len(danh_sach), "bán ra" if huong == "ban" else "mua vào", " máy tính tiền" if kind == "mtt" else ""))
    LOG.ghi("[EXCEL CONG] %s: %d dong hang, %s -> %s" % (os.path.basename(tep), n, "; ".join(tom), [os.path.basename(x) for x in tep_ra]))
    return {"ok": bool(tep_ra), "so_hd": len(ds), "so_dong": n, "tom_tat": "; ".join(tom), "tep": [os.path.basename(x) for x in tep_ra],
            "loi": "" if tep_ra else "Không có hoá đơn mới để đưa vào phần mềm (đã có / bị giữ theo khoá bán lẻ)."}


def tra_cuu_mot_doan(p):
    """Lay hoa don cua MOT doan ngay (<= gioi han cua cong), tu dong lat trang."""
    kind = p.get("kind", "dt")
    direction = p.get("direction", "ban")

    dieu_kien = ["tdlap=ge=" + _ngay_thue(p["tu_ngay"]),
                 "tdlap=le=" + _ngay_thue(p["den_ngay"], True)]
    ma_tt = MA_TRANG_THAI.get(p.get("trang_thai", "Tất cả"))
    if ma_tt:
        dieu_kien.append("tthai==" + ma_tt)
    ma_kq = MA_KET_QUA.get(p.get("ket_qua", "Tất cả"))
    if ma_kq is not None:
        dieu_kien.append("ttxly==" + ma_kq)
    if p.get("mst_nguoi_mua"):
        dieu_kien.append("nmmst==" + p["mst_nguoi_mua"].strip())
    if p.get("ky_hieu"):
        dieu_kien.append("khhdon==" + p["ky_hieu"].strip())
    if p.get("so_hoa_don"):
        dieu_kien.append("shdon==" + p["so_hoa_don"].strip())
    if p.get("mau_so") and p["mau_so"] != "Tất cả":
        dieu_kien.append("khmshdon==" + p["mau_so"])

    search = ";".join(dieu_kien)
    duong = STATE["may_chu"] + duong_tra_cuu(kind, direction)

    LOG.ghi("[TRA CUU] Bo loc: " + search)
    tat_ca, state_cursor, trang = [], None, 0
    da_co, con_tro_da_gap = set(), set()          # P0 18/11/2026: khu trung trong doan + chan con tro 'state' lap
    # 26/11/2026 dot 5: cong doi MOT ma cho MOI trang HD may tinh tien (thu that 20:38) -> xin trang LON nhat cong chiu de it trang nhat.
    #   co = 'size' gui di; co_thuc = so HD cong thuc su tra moi trang (cong co the cat ve 50 du xin nhieu hon).
    co = mtt_co_trang() if kind == "mtt" else TRA_CUU_CO_TRANG
    co_thuc, tong_trang, nghi_cat = co, 0, False

    while trang < TRA_CUU_TRAN_TRANG:  # GD63: chan an toan 400 trang (20.000 HD) - truoc day 60 trang (3.000 HD) cat bot khong bao
        trang += 1
        params = {"sort": "tdlap:desc", "size": str(co), "search": search}
        if state_cursor:
            params["state"] = state_cursor
        url = duong + "?" + urllib.parse.urlencode(params)
        kq = None
        # 26/11/2026 dot 3 (chu DN: «chi nhap ma lan dau»): trang SAU cua cung mot lan tim (lat bang con tro 'state') duoc hoi KHONG kem ma
        #   truoc - cong tra du lieu thi khoi hoi nguoi dung; cong doi 'ckey' thi nho lai (trang_sau_can) va hoi nguoi dung nhu truoc.
        #   Khong dung lai ma cu, khong doan ma: chi la hoi cong xem trang sau co can ma khong.
        thu_trang_sau = bool(state_cursor) and CHO_CAPTCHA_MTT.get("can") and not CHO_CAPTCHA_MTT.get("trang_sau_can")
        if kind == "mtt" and (not CHO_CAPTCHA_MTT.get("can") or thu_trang_sau):          # GD359: thu khong captcha truoc (cong co the bo yeu cau)
            kq = goi_mang_kien_nhan(url, token=STATE["token"], timeout=60)
            if _mtt_doi_ckey(kq):          # 23/11/2026: cong tra 500 chu khong phai 400 -> truoc day khong bao gio hoi captcha
                if thu_trang_sau:
                    CHO_CAPTCHA_MTT["trang_sau_can"] = True
                    LOG.ghi("[CAPTCHA MTT] Cong thue doi ma ca khi lat trang (trang %d) - tu day moi trang hoi nguoi dung mot ma." % trang)
                else:
                    CHO_CAPTCHA_MTT["can"] = True
                    LOG.ghi("[CAPTCHA MTT] Cong thue doi ckey cho tra cuu HD may tinh tien - hoi nguoi dung nhap captcha.")
                kq = None
            elif thu_trang_sau and getattr(kq, "ok", False):
                LOG.ghi("[CAPTCHA MTT] Trang %d lat bang con tro KHONG can ma moi." % trang)
        if kind == "mtt" and CHO_CAPTCHA_MTT.get("can") and kq is None:          # GD359: moi trang mot captcha (nguoi dung nhap tren trang tool)
            loi_cap = ""
            for _lan in range(4):
                ck, cv = xin_captcha_mtt("%s - trang %d%s" % ("Bán ra" if direction == "ban" else "Mua vào", trang,
                                         (" / %d (còn %d mã)" % (tong_trang, tong_trang - trang + 1)) if tong_trang >= trang else ""), loi_cap)
                if not ck:
                    if tat_ca:
                        TRA_CUU_CANH_BAO.append("HĐ máy tính tiền %s: dừng ở trang %d (chưa nhập captcha) - đã lấy %d hoá đơn"
                                                % ("bán ra" if direction == "ban" else "mua vào", trang, len(tat_ca)))
                        return tat_ca, None
                    return None, ("Cổng thuế bắt nhập mã captcha cho hoá đơn máy tính tiền - chưa nhập (bấm Đồng bộ lại rồi gõ mã)"
                                  if not UNESCO.get("hengio") else "Chạy hẹn giờ: HĐ máy tính tiền cần nhập captcha - mở Tải hoá đơn để lấy")
                params["ckey"], params["cvalue"] = ck, cv
                url = duong + "?" + urllib.parse.urlencode(params)
                kq_thu = goi_mang_kien_nhan(url, token=STATE["token"], timeout=60)
                if _captcha_mtt_sai(kq_thu):
                    loi_cap = "Mã xác nhận chưa đúng - gõ lại theo ảnh mới (gõ đủ mọi ký tự trong ảnh)"
                    continue
                break
            params.pop("ckey", None)
            params.pop("cvalue", None)
            kq = kq_thu
            if _captcha_mtt_sai(kq):          # 26/11/2026 dot 2: go sai 4 lan - truoc day bao nham «Phiên làm việc đã hết hạn» (cong tra 401)
                LOG.ghi("[CAPTCHA MTT] Ma nhap sai 4 lan lien - bo phan HD may tinh tien nay.")
                return None, "Mã xác nhận hoá đơn máy tính tiền gõ sai 4 lần - chưa lấy được phần này (bấm Đồng bộ lại rồi gõ mã)"

        # GD89: tra cuu (nhat la khi dong bo lien tuc 4 to hop mua/ban x dt/mtt) hay bi 429
        # "Too Many Requests" o to hop cuoi cung (thuong la ban/mtt) - truoc day dung goi_mang
        # (khong cho roi thu lai) nen gap 429 la bao loi ngay, trong khi duong tai chi tiet /
        # export XML da dung goi_mang_kien_nhan (cho 4/8/16/32s roi thu lai) tu GD30b. Doi sang
        # goi_mang_kien_nhan cho dong bo voi duong tai kia, tranh bao loi oan khi cong thue chi
        # tam thoi qua tai.
        if kq is None:
            kq = goi_mang_kien_nhan(url, token=STATE["token"], timeout=60)
        # dot 5: xin trang lon ma cong bao loi tham so (khong phai thieu / sai ma, khong phai qua tai, khong phai chan) o TRANG DAU ->
        #   coi la cong khong nhan co trang nay: nho lai, ha xuong muc ke va hoi lai trang nay (ma vua go coi nhu da dung - phai go ma moi).
        if (kind == "mtt" and co > TRA_CUU_CO_TRANG and trang == 1 and not kq.ok and getattr(kq, "status", 0) in (400, 422, 500)
                and not _captcha_mtt_sai(kq) and "sort" not in (kq.loi or "").lower()):
            co_cu, co = co, mtt_co_trang_tu_choi(co)
            co_thuc = co
            LOG.ghi("[TRA CUU] Cong khong nhan co trang %d cho HD may tinh tien (ma %s) - ha xuong %d va hoi lai." % (co_cu, kq.status, co))
            trang -= 1
            continue
        kq = _hoi_lai_khi_qua_tai(kq, url, trang)          # GD112: 502 / 503 / 504 -> hoi lai cung trang
        if not kq.ok:
            if _la_qua_tai(kq):          # GD112: da hoi lai van qua tai -> _tra_cuu_doan chia ngay
                p["_qua_tai"] = True
                LOG.ghi("[TRA CUU] Trang %d van qua tai sau %d lan hoi lai (da lay %d hoa don cua doan nay - bo, lay lai theo ngay)."
                        % (trang, len(CHO_QUA_TAI), len(tat_ca)))
                return None, _loi_may_chu(kq) + " ở trang %d" % trang
            if la_bi_chan(kq):          # P2 18/11/2026: 403 'hanh vi khong hop le' = cong CHAN, khong phai het phien (dang nhap lai vo ich)
                LY_DO_TAI["bi_chan"], LY_DO_TAI["chan_luc"] = True, time.time()
                LOG.ghi("[TRA CUU] Cong thue CHAN (403 'hanh vi khong hop le') - dung, khong hoi them.")
                return None, ("Cổng thuế đang CHẶN truy cập (“hành vi không hợp lệ”) - đã dừng tra cứu. "
                              "Đợi khoảng 30 phút rồi làm lại; đăng nhập lại không giúp được.")
            if kq.status in (401, 403):
                return None, "Phiên làm việc đã hết hạn. Đăng nhập lại rồi tìm kiếm tiếp."
            if kq.status == 500 and "sort" in (kq.loi or "").lower():
                LOG.ghi("[TRA CUU] May chu tu choi cach sap xep, thu lai khong sap xep.")
                params.pop("sort", None)
                kq = goi_mang_kien_nhan(duong + "?" + urllib.parse.urlencode(params),
                                         token=STATE["token"], timeout=60)
                if not kq.ok:
                    return None, "Máy chủ Cục Thuế báo lỗi khi tìm kiếm: " + _loi_may_chu(kq)          # GD112: bo the HTML
            else:
                return None, "Máy chủ Cục Thuế báo lỗi khi tìm kiếm: " + _loi_may_chu(kq)

        j = kq.json()
        rows, loi_ct = _ds_tra_cuu(j)          # P0 18/11/2026: tra 200 ma sai cau truc -> LOI, khong phai 'khong co hoa don'
        if loi_ct:
            LOG.ghi("[TRA CUU] Trang %d: cong tra du lieu SAI CAU TRUC (%s) - khong coi la da tra cuu du." % (trang, loi_ct))
            return None, ("Cổng thuế trả dữ liệu không đúng cấu trúc danh sách hoá đơn ở trang %d (%s) - chưa coi là đã tra cứu đủ. "
                          "Thử lại sau ít phút; nếu lặp lại thì cổng có thể đã đổi cách trả kết quả." % (trang, loi_ct))
        moi = 0
        for hd in rows:
            k = _khoa_hoa_don(hd)
            if k.strip("|"):
                if k in da_co:
                    continue
                da_co.add(k)
            tat_ca.append(hd)
            moi += 1
        LOG.ghi("[TRA CUU] Trang %d: nhan duoc %d hoa don%s (tong cong %d)."
                % (trang, len(rows), (" (%d trung trang truoc - bo)" % (len(rows) - moi)) if moi < len(rows) else "", len(tat_ca)))
        state_cursor = j.get("state")
        if kind == "mtt" and co > TRA_CUU_CO_TRANG:          # dot 5: cong co that su tra trang lon khong
            if trang == 1 and len(rows) > TRA_CUU_CO_TRANG:
                mtt_co_trang_nho(co, "cong tra %d HD trong mot trang" % len(rows))
            elif trang == 1 and len(rows) == TRA_CUU_CO_TRANG and state_cursor:
                co_thuc, nghi_cat = TRA_CUU_CO_TRANG, True          # xin nhieu ma chi duoc 50 va con trang sau: nghi cong cat ve 50
            elif nghi_cat and trang == 2 and rows:
                mtt_co_trang_nho(TRA_CUU_CO_TRANG, "xin %d nhung cong chi tra %d HD moi trang" % (co, TRA_CUU_CO_TRANG))
        try:
            tong_hd = int(j.get("total") or 0)
            if tong_hd > 0 and co_thuc > 0:
                tong_trang = -(-tong_hd // co_thuc)
        except Exception:
            pass
        if not rows or not state_cursor or len(rows) < co_thuc:
            break
        if state_cursor in con_tro_da_gap:          # P0 18/11/2026: cong tra lai con tro da gap -> lat mai cung trang
            LOG.ghi("[TRA CUU] Trang %d: cong tra lai con tro trang da gap - dung de khong lap vo han." % trang)
            return None, ("Cổng thuế trả lại cùng một con trỏ trang ở trang %d (lật trang bị lặp) - đã dừng, chưa coi là đã tra cứu đủ. "
                          "Thử lại sau ít phút." % trang)
        con_tro_da_gap.add(state_cursor)
        if trang >= TRA_CUU_TRAN_TRANG:
            p["_cham_tran"] = True          # P0 18/11/2026: _tra_cuu_doan chia ngay / bao 'chua lay duoc du' (truoc day chi ghi log)
            LOG.ghi("[TRA CUU] CANH BAO: cham tran %d trang (%d hoa don) cho khoang %s - %s, cong con trang sau - CHUA du."
                    % (TRA_CUU_TRAN_TRANG, len(tat_ca), p["tu_ngay"], p["den_ngay"]))

    LOG.ghi("[TRA CUU] Ket thuc: tim duoc %d hoa don%s." % (len(tat_ca), " (CHUA DU - cham tran trang)" if p.get("_cham_tran") else ""))
    return tat_ca, None


def bo_dau(s):
    bang = {"àáạảãâầấậẩẫăằắặẳẵ": "a", "èéẹẻẽêềếệểễ": "e", "ìíịỉĩ": "i",
            "òóọỏõôồốộổỗơờớợởỡ": "o", "ùúụủũưừứựửữ": "u", "ỳýỵỷỹ": "y", "đ": "d"}
    out = []
    for ch in s:
        low = ch.lower()
        thay = None
        for nguon, dich in bang.items():
            if low in nguon:
                thay = dich.upper() if ch.isupper() else dich
                break
        out.append(thay if thay else ch)
    return "".join(out)


def ngay_vn(s):
    """GD94: ngay tren cong thue (tdlap / nky / ncma) la gio UTC: '2026-08-31T17:00:00Z' = 00:00 ngay 01/09/2026 gio Viet
    Nam. Truoc day cat [:10] -> LUI 1 NGAY (ten file, thu muc thang, ngay lap HD khong co XML, cot Ngay lap tren bang).
    Tra ve 'yyyy-mm-dd' theo gio Viet Nam (+07): chuoi co mui gio (Z / +hh:mm) -> doi; khong ghi mui gio ma dung 17:00:00
    (nua dem VN viet theo UTC) -> +7 gio; con lai giu nguyen ngay. Tham so tai XML (export-xml) VAN gui nguyen chuoi cong."""
    s = str(s or "").strip()
    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2})(?::(\d{2}))?(?:\.\d+)?)?\s*(Z|z|[+-]\d{2}:?\d{2})?$", s)
    if not m:
        return s[:10]
    y, mo, d, hh, mi, ss, tz = m.groups()
    if hh is None:
        return s[:10]
    try:
        t = datetime(int(y), int(mo), int(d), int(hh), int(mi), int(ss or 0))
    except ValueError:
        return s[:10]
    if tz:
        lech = 0
        if tz not in ("Z", "z"):
            so = tz[1:].replace(":", "")
            lech = (int(so[:2]) * 60 + int(so[2:4])) * (-1 if tz[0] == "-" else 1)
        t = t - timedelta(minutes=lech) + timedelta(hours=7)
    elif (hh, mi, ss or "00") == ("17", "00", "00"):
        t = t + timedelta(hours=7)
    return t.strftime("%Y-%m-%d")


def _ngay_hd(hd, cu=False):
    """Ngay lap cua dong tra cuu: gio VN (GD94); cu=True: cach cu truoc GD94 (cat [:10] chuoi UTC) - de tim file da tai."""
    s = (hd or {}).get("tdlap") or ""
    return str(s)[:10] if cu else ngay_vn(s)


_SO_TAI_NHO = {"moc": None, "so": {}}


def _so_tai_nhanh():
    """GD94: da-tai.json, chi doc lai khi tep doi (tai 16.000 HD: khong doc lai tep lon cho moi HD)."""
    try:
        d = os.path.join(_thu_muc_du_lieu(), "da-tai.json")
        st = os.stat(d)
        moc = (d, st.st_mtime_ns, st.st_size, st.st_ino)
    except Exception:
        return {}
    if _SO_TAI_NHO["moc"] != moc:
        so = _doc_json("da-tai.json", {})
        _SO_TAI_NHO.update({"moc": moc, "so": so if isinstance(so, dict) else {}})
    return _SO_TAI_NHO["so"]


# ---------------------------------------------------------------- P1 18/11/2026: tep tai ve an toan
# Tep XML / PDF ghi NGUYEN TU (tep tam cung thu muc -> fsync -> os.replace): may tat giua chung khong de lai tep cut do ma
# lan sau coi la 'da co'. Tep 'da co' chi duoc bo qua tai khi doc duoc va dung hoa don; tep hong chuyen sang cach_ly\ (khong xoa).
XML_TOI_DA = 20 * 1024 * 1024          # XML hoa don thuc te vai chuc KB; lon hon the nay la bat thuong
THU_MUC_CACH_LY = "cach_ly"
_KIEM_XML_NHO = {}                      # duong dan -> (mtime, size, ly_do) - khong parse lai tep khong doi


def ghi_tep_nguyen_tu(dich, du_lieu):
    """Ghi bytes vao tep tam cung thu muc, flush + fsync, roi os.replace sang tep dich (tep dich khong bao gio do dang)."""
    tam = "%s.tmp-%d" % (dich, os.getpid())
    try:
        with open(tam, "wb") as f:
            f.write(du_lieu)
            f.flush()
            try:
                os.fsync(f.fileno())
            except Exception:
                pass
        os.replace(tam, dich)
    finally:
        if os.path.exists(tam):
            try:
                os.remove(tam)
            except Exception:
                pass


def _ten_cuc_bo(tag):
    return tag.rsplit("}", 1)[-1] if isinstance(tag, str) else ""


def kiem_xml_hoa_don(du_lieu, hd=None):
    """P1 18/11/2026: '' khi bytes la XML doc duoc (va, neu co hd, dung so / ky hieu cua hd); nguoc lai ly do (tieng Viet).
    Khong nhan DOCTYPE / ENTITY (hoa don khong can; chan XML doc hai). Khong coi trang HTML / XML cut do la hoa don."""
    if not du_lieu:
        return "tệp rỗng (0 byte)"
    if len(du_lieu) > XML_TOI_DA:
        return "tệp quá lớn (%d byte)" % len(du_lieu)
    dau = du_lieu[:4096]
    if b"<!DOCTYPE" in dau.upper() or b"<!ENTITY" in dau.upper():
        return "XML có khai báo DOCTYPE / ENTITY (không nhận)"
    if not dau.lstrip(b"\xef\xbb\xbf \t\r\n").startswith(b"<"):
        return "không phải XML"
    try:
        goc = ET.fromstring(du_lieu)
    except Exception as e:
        return "XML hỏng / bị cắt dở (%s)" % str(e)[:80]
    if _ten_cuc_bo(goc.tag).lower() in ("html", "body", "head"):
        return "trang HTML, không phải hoá đơn"
    if not hd:
        return ""
    gt = {}
    for e in goc.iter():
        t = _ten_cuc_bo(e.tag)
        if t in ("SHDon", "KHHDon") and t not in gt and e.text and e.text.strip():
            gt[t] = e.text.strip()
    so_h = str(hd.get("shdon") or "").strip()
    if gt.get("SHDon") and so_h and unesco_so_hd(gt["SHDon"]) != unesco_so_hd(so_h):
        return "XML là hoá đơn số %s, không phải số %s" % (gt["SHDon"], so_h)
    kh_h = str(hd.get("khhdon") or "").strip().upper()
    if gt.get("KHHDon") and kh_h and gt["KHHDon"].upper() != kh_h:
        return "XML là hoá đơn ký hiệu %s, không phải %s" % (gt["KHHDon"], kh_h)
    return ""


def kiem_tep_xml(p, hd=None):
    """'' khi tep XML p dung la hoa don (doc duoc, dung so / ky hieu); nguoc lai ly do. Nho ket qua theo (mtime, size)."""
    try:
        st = os.stat(p)
    except Exception:
        return "không có tệp"
    khoa = (os.path.normcase(os.path.abspath(p)), str(hd.get("shdon") if hd else ""), str(hd.get("khhdon") if hd else ""))
    nho = _KIEM_XML_NHO.get(khoa)
    if nho and nho[0] == st.st_mtime and nho[1] == st.st_size:
        return nho[2]
    if st.st_size > XML_TOI_DA:
        ly_do = "tệp quá lớn (%d byte)" % st.st_size
    else:
        try:
            with open(p, "rb") as f:
                ly_do = kiem_xml_hoa_don(f.read(), hd)
        except Exception as e:
            ly_do = "không đọc được tệp (%s)" % str(e)[:80]
    _KIEM_XML_NHO[khoa] = (st.st_mtime, st.st_size, ly_do)
    return ly_do


def cach_ly_tep(p, ly_do):
    """Chuyen tep hong sang <thu muc>\\cach_ly\\ (KHONG xoa) kem tep ghi ly do. -> duong dan moi hoac ''."""
    try:
        d = os.path.join(os.path.dirname(p), THU_MUC_CACH_LY)
        os.makedirs(d, exist_ok=True)
        moi = os.path.join(d, "%s.%s" % (os.path.basename(p), datetime.now().strftime("%Y%m%d_%H%M%S")))
        os.replace(p, moi)
        with io.open(moi + ".ly_do.txt", "w", encoding="utf-8") as f:
            f.write("%s\n%s\nTool tải lại hoá đơn này ở lần tải sau.\n" % (p, ly_do))
        LOG.ghi("[TAI] CACH LY tep hong %s -> %s (%s)" % (p, moi, bo_dau(ly_do)))
        return moi
    except Exception as e:
        LOG.loi("Khong cach ly duoc tep hong " + str(p), e)
        return ""


def tim_xml_co_san(hd, direction, thu_muc, so_tai=None):
    """GD94: file XML cua HD DA CO tren may: dia chi da nho (Lam moi / lan xu ly truoc), ten moi (ngay gio VN), ten cu
    truoc GD94 (ngay UTC - co the nam o thu muc thang truoc), dia chi trong da-tai.json. Khong co -> ''.
    P1 18/11/2026: tep chi duoc nhan khi DOC DUOC va dung hoa don (kiem_tep_xml); tep hong -> cach_ly\\ roi tai lai."""
    ung = [str(hd.get("_xml") or "")]
    try:
        ung.append(os.path.join(thu_muc_theo_ky(thu_muc, hd, tao=False), ten_file(hd, direction) + ".xml"))
        ung.append(os.path.join(thu_muc_theo_ky(thu_muc, hd, cu=True, tao=False), ten_file(hd, direction, cu=True) + ".xml"))
    except Exception:
        pass
    v = (so_tai if so_tai is not None else _so_tai_nhanh()).get(khoa_cua(hd))
    if isinstance(v, dict):
        ung.append(str(v.get("xml") or ""))
    da_xet = set()
    for p in ung:
        try:
            if not p or not os.path.isfile(p):
                continue
            k = os.path.normcase(os.path.abspath(p))
            if k in da_xet:
                continue
            da_xet.add(k)
            ly_do = kiem_tep_xml(p, hd)
            if not ly_do:
                return p
            cach_ly_tep(p, ly_do)          # P1: tep cut do / HTML / sai hoa don -> khong coi la 'da co'
        except Exception:
            pass
    return ""


def la_bi_chan(kq):
    """GD94: cong thue tra 403 'He thong phat hien hanh vi khong hop le. Yeu cau da bi chan.' -> dang CHAN tai: thu tiep
    chi bi chan lau hon (anh Thang 27/09: 1 HD thu 3 duong x 3 lan, 220 HD lien tiep)."""
    if getattr(kq, "status", 0) != 403:
        return False
    t = bo_dau(str(getattr(kq, "loi", "") or "")).lower()
    return "hanh vi khong hop le" in t or "yeu cau da bi chan" in t


def _phan_ten_tep(v):
    """P1 18/11/2026: mot phan ten tep lay tu du lieu cong / XML: chi giu chu, so, '_' , '-' (ky hieu, so HD thuc te deu vay)."""
    return re.sub(r"[^0-9A-Za-z_\-]", "", str(v if v is not None else "").strip())


def ten_file(hd, direction, cu=False):
    """20260816_C26TYY_00000202_CTY-4CORE.xml"""
    try:
        tdlap = _ngay_hd(hd, cu)  # 2026-08-16 - GD94: ngay gio VN (cu=True: cach cu, ngay UTC)
        ngay = tdlap.replace("-", "") if "-" in tdlap else "00000000"
        kh = _phan_ten_tep(hd.get("khhdon")) or "XX"          # P1 18/11/2026: du lieu cong khong duoc lam duong dan (\ / .. :)
        so = (_phan_ten_tep(hd.get("shdon")) or "0").zfill(8)
        doi_tac = hd.get("nmten") if direction == "ban" else hd.get("nbten")
        ten = bo_dau(str(doi_tac or "")).upper()
        la_cong_ty = bool(re.match(r"^\s*(CONG TY|CTY|CT)\b", ten))
        # bo cac tu chi loai hinh doanh nghiep o dau ten
        for _ in range(6):
            moi = re.sub(r"^\s*(CONG TY|CTY|CT|TNHH|MTV|MOT THANH VIEN|CO PHAN|CP|"
                         r"DOANH NGHIEP TU NHAN|DNTN|TM VA DV|TM & DV|THUONG MAI VA DICH VU)\b",
                         "", ten).strip(" -&")
            if moi == ten:
                break
            ten = moi
        tu = [t for t in re.sub(r"[^A-Z0-9]+", " ", ten).split() if t]
        slug, do_dai = "", 0
        for t in tu:
            if slug and do_dai + 1 + len(t) > 22:
                break
            slug = t if not slug else slug + "-" + t
            do_dai = len(slug)
        slug = slug[:26].strip("-")
        if not slug:
            slug = "KHONG-RO"
        elif la_cong_ty:
            slug = "CTY-" + slug
        return "%s_%s_%s_%s" % (ngay, kh, so, slug)
    except Exception as e:
        LOG.loi("Khong tao duoc ten file cho mot hoa don", e)
        return "hoa-don-%d" % int(time.time() * 1000)


def thu_muc_theo_ky(thu_muc, hd, cu=False, tao=True):
    """GD30: chay tu UNESCO thi phan mem truyen thu muc ...\\<CONG TY>\\<yyyy-mm> theo NGAY BAT DAU tra cuu.
    Tai ca quy / ca nam thi moi hoa don deu roi vao thu muc cua thang dau -> kho tim.
    O day dua tung hoa don ve dung thu muc THANG LAP cua chinh no: ...\\<CONG TY>\\<yyyy-mm cua hoa don>.
    Khong phai che do UNESCO, hoac thu muc khong co dang yyyy-mm, thi giu nguyen."""
    try:
        if not UNESCO.get("bat") or not thu_muc:
            return thu_muc
        t = thu_muc.rstrip("\\/")
        if not re.match(r"^\d{4}-\d{2}$", os.path.basename(t)):
            return thu_muc
        ky = _ngay_hd(hd, cu)[:7]               # GD94: thang lap theo gio VN (cu=True: cach cu, de tim file da tai)
        if not re.match(r"^\d{4}-\d{2}$", ky):
            return thu_muc
        d = os.path.join(os.path.dirname(t), ky)
        if tao:
            os.makedirs(d, exist_ok=True)
        return d
    except Exception as e:
        LOG.loi("Khong tao duoc thu muc theo thang lap hoa don", e)
        return thu_muc


def tai_mot_hoa_don(hd, kind, direction, thu_muc, dinh_dang, thu_thap=None):
    """dinh_dang: danh sach ['xml'] / ['pdf'] / ['xml','pdf']
       thu_thap : neu la danh sach thi doc them du lieu de gop vao file Excel
       Tra ve: 'ok' / 'bo_qua' / 'loi'"""
    thu_muc_goc = thu_muc
    thu_muc = thu_muc_theo_ky(thu_muc, hd)
    goc = ten_file(hd, direction)
    dich = {"xml": os.path.join(thu_muc, goc + ".xml"),
            "pdf": os.path.join(thu_muc, goc + ".pdf")}
    can_excel = thu_thap is not None
    co_san = tim_xml_co_san(hd, direction, thu_muc_goc)       # GD94: da tai truoc (ten cu ngay UTC / dia chi da nho)
    if co_san and os.path.normcase(os.path.abspath(co_san)) != os.path.normcase(os.path.abspath(dich["xml"])):
        dich["xml"] = co_san
        pdf_cu = os.path.splitext(co_san)[0] + ".pdf"
        if os.path.exists(pdf_cu):
            dich["pdf"] = pdf_cu

    # nhung dinh dang thuc su con thieu - P1 18/11/2026: XML phai doc duoc + dung hoa don, PDF phai la PDF (khong chi > 0 byte)
    def _da_co(d):
        p = dich[d]
        if not (os.path.exists(p) and os.path.getsize(p) > 0):
            return False
        if d == "xml":
            ly_do = kiem_tep_xml(p, hd)
            if ly_do:
                cach_ly_tep(p, ly_do)
                return False
            return True
        try:
            with open(p, "rb") as f:
                if f.read(5) == b"%PDF-":
                    return True
        except Exception:
            return False
        cach_ly_tep(p, "không phải tệp PDF")
        return False
    con_thieu = [d for d in dinh_dang if not _da_co(d)]

    if not con_thieu:
        # da co du file roi - nhung neu can lam Excel thi van phai doc noi dung XML
        if os.path.exists(dich["xml"]):
            hd["_xml"] = dich["xml"]              # GD94: nho noi file (so da-tai, lan sau)
        if can_excel:
            noi_dung = doc_xml_co_san(dich["xml"], goc)
            if noi_dung is not None:
                noi_dung["duong_xml"] = dich["xml"]
                thu_thap.append(noi_dung)
                LOG.ghi("[TAI] Bo qua tai (da co san), da doc du lieu cho Excel: " + goc)
                return "bo_qua"
        else:
            LOG.ghi("[TAI] Bo qua vi da co san: " + goc)
            return "bo_qua"

    params = {
        "nbmst": hd.get("nbmst", ""),
        "khhdon": hd.get("khhdon", ""),
        "shdon": hd.get("shdon", ""),
        "khmshdon": hd.get("khmshdon", ""),
        "tdlap": (hd.get("tdlap") or "")[:10],
    }

    # ---- 1. Tai goi tin chinh (chua XML va ban in HTML) ----
    LY_DO_TAI["khong_ho_so"] = False
    goi_tin = tai_goi_tin(params, kind, goc)
    if goi_tin is None and LY_DO_TAI.get("bi_chan"):
        return "chan"               # GD94: cong thue dang chan - dung ca lo (HD nay chua tai, lan sau tai tiep)

    da_luu = []
    xml_bytes = None
    if goi_tin is not None:
        try:
            xml_bytes = lay_xml(goi_tin)
        except Exception as e:
            LOG.loi("Loi khi lay file XML tu goi tin " + goc, e)

    # ---- 2. Luu file XML ----
    if "xml" in con_thieu:
        ly_do_xml = kiem_xml_hoa_don(xml_bytes, hd) if xml_bytes else ""
        if xml_bytes and ly_do_xml:          # P1 18/11/2026: XML cong tra ve hong / sai hoa don -> KHONG luu, khong coi la da tai
            LOG.ghi("[TAI] XML tai ve KHONG dung (%s) - khong luu: %s" % (bo_dau(ly_do_xml), goc))
            xml_bytes = None
        if xml_bytes:
            try:
                ghi_tep_nguyen_tu(dich["xml"], xml_bytes)          # P1: nguyen tu (tam -> fsync -> replace)
                LOG.ghi("[TAI] THANH CONG XML: %s.xml (%d byte)" % (goc, len(xml_bytes)))
                da_luu.append("xml")
                hd["_xml"] = dich["xml"]
            except Exception as e:
                LOG.loi("Loi khi luu file XML " + goc, e)
        elif not ly_do_xml:
            LOG.ghi("[TAI] Goi tin tai ve khong chua file .xml: " + goc)

    # ---- 3. Luu file PDF ----
    if "pdf" in con_thieu:
        try:
            noi_dung_pdf = lay_pdf(goi_tin) if goi_tin else None

            if noi_dung_pdf is None:
                noi_dung_pdf = tai_pdf_may_chu(params, kind, goc)

            if noi_dung_pdf is None and goi_tin is not None:
                html = gop_html(goi_tin)
                if html:
                    tam_pdf = "%s.tmp-%d.pdf" % (dich["pdf"], os.getpid())          # P1: Chrome in ra tep tam roi moi doi ten
                    try:
                        ok, loi = in_ra_pdf(html, tam_pdf)
                        if ok:
                            os.replace(tam_pdf, dich["pdf"])
                    finally:
                        if os.path.exists(tam_pdf):
                            try:
                                os.remove(tam_pdf)
                            except Exception:
                                pass
                    if ok:
                        LOG.ghi("[TAI] THANH CONG PDF (in tu ban in hoa don): %s.pdf (%d byte)"
                                % (goc, os.path.getsize(dich["pdf"])))
                        da_luu.append("pdf")
                    else:
                        LOG.ghi("[TAI] Khong tao duoc PDF cho %s: %s" % (goc, loi))
                else:
                    LOG.ghi("[TAI] Goi tin tai ve khong co ban in de tao PDF: " + goc)
            elif noi_dung_pdf:
                ghi_tep_nguyen_tu(dich["pdf"], noi_dung_pdf)          # P1: nguyen tu
                LOG.ghi("[TAI] THANH CONG PDF (may chu cap san): %s.pdf (%d byte)"
                        % (goc, len(noi_dung_pdf)))
                da_luu.append("pdf")
        except Exception as e:
            LOG.loi("Loi khi tao file PDF " + goc, e)

    # ---- 4. Boc tach du lieu cho file Excel ----
    if can_excel:
        noi_dung = None
        if xml_bytes:
            noi_dung = doc_xml_hoa_don(xml_bytes, goc + ".xml")
        elif os.path.exists(dich["xml"]):
            noi_dung = doc_xml_co_san(dich["xml"], goc)
        if noi_dung is not None:
            if os.path.exists(dich["xml"]):
                noi_dung["duong_xml"] = dich["xml"]
            thu_thap.append(noi_dung)
        else:
            LOG.ghi("[EXCEL] Khong lay duoc du lieu de gop Excel cho: " + goc)

    if not con_thieu:
        return "bo_qua"
    if "xml" in con_thieu and "xml" not in da_luu:
        # P1 18/11/2026: can XML ma chua co XML -> KHONG phai 'ok' du da luu duoc PDF (truoc day: luu duoc bat ky dinh dang nao la ok)
        if LY_DO_TAI.get("khong_ho_so"):
            LOG.ghi("[TAI] Khong co XML goc (khong phai loi) - dung du lieu tra cuu%s: %s"
                    % (" (da luu PDF)" if da_luu else "", goc))
            return "khong_xml"
        LOG.ghi("[TAI] LOI: chua lay duoc XML cho %s%s - lan sau tai lai XML." % (goc, " (da luu PDF)" if da_luu else ""))
        return "loi"
    if da_luu:
        thieu = [d for d in con_thieu if d not in da_luu]
        if thieu:
            LOG.ghi("[TAI] Chi lay duoc %s cho %s, thieu %s"
                    % (", ".join(da_luu), goc, ", ".join(thieu)))
        return "ok"
    if LY_DO_TAI.get("khong_ho_so"):
        # GD30b: KHONG phai loi. Hoa don khong ma (ngan hang, dien, nuoc...) cong thue khong giu XML goc;
        # du lieu cua no van sang phan mem qua ket qua tra cuu / chi tiet. Ghi so de lan sau khong tai lai.
        LOG.ghi("[TAI] Khong co XML goc (khong phai loi) - dung du lieu tra cuu: " + goc)
        return "khong_xml"
    LOG.ghi("[TAI] LOI: khong lay duoc file nao cho " + goc)
    return "loi"


def doc_xml_co_san(duong_xml, goc):
    """Doc lai file XML da tai truoc do de lay du lieu cho Excel."""
    try:
        if os.path.exists(duong_xml) and os.path.getsize(duong_xml) > 0:
            with open(duong_xml, "rb") as f:
                return doc_xml_hoa_don(f.read(), os.path.basename(duong_xml))
    except Exception as e:
        LOG.loi("Loi khi doc lai file XML da co " + goc, e)
    return None


LY_DO_TAI = {"khong_ho_so": False,   # GD30b: lan tai gan nhat that bai vi cong thue KHONG LUU ho so goc (khong phai loi)
             "bi_chan": False,      # GD94: cong thue tra 403 'hanh vi khong hop le' -> dung ca lo, khong goi them
             "chan_luc": 0}         #       luc bi chan (TAI_CHAN_CHO phut sau moi goi lai cong)


def tai_goi_tin(params, kind, goc):
    """Tai goi tin .zip cua mot hoa don, tu do duong dan, thu lai toi da 3 lan.
    GD94: cong thue CHAN (403 'hanh vi khong hop le') -> dung ngay, khong thu duong khac / lan khac. Chua dang nhap
    (Lam moi / dua HD da tai vao phan mem khong can mang) -> khong goi."""
    if LY_DO_TAI.get("bi_chan") or not STATE.get("may_chu"):
        return None
    ung_vien = duong_tai_ung_vien(kind)
    da_chay = SETTINGS.get("duong_tai_da_chay", {}).get(kind)
    if da_chay and da_chay in ung_vien:
        ung_vien.remove(da_chay)
        ung_vien.insert(0, da_chay)

    for lan in range(1, 4):
        for duong in ung_vien:
            url = STATE["may_chu"] + duong + "?" + urllib.parse.urlencode(params)
            kq = goi_mang_kien_nhan(url, token=STATE["token"], timeout=90)
            if kq.ok and kq.data:
                if SETTINGS.get("duong_tai_da_chay", {}).get(kind) != duong:
                    SETTINGS.setdefault("duong_tai_da_chay", {})[kind] = duong
                    luu_thiet_lap(SETTINGS)
                    LOG.ghi("[DO TIM] Da nho duong tai dung duoc cho lan sau: " + duong)
                return kq.data
            if la_bi_chan(kq):
                LY_DO_TAI["bi_chan"], LY_DO_TAI["chan_luc"] = True, time.time()
                LOG.ghi("[TAI] Cong thue CHAN tai (403 'hanh vi khong hop le') o %s - DUNG ca lo, khong thu lai (thu lai chi bi chan lau hon)." % goc)
                return None
            if kq.status == 401:          # P2 18/11/2026: het phien -> thu lai 3 vong x moi duong chi them yeu cau vo ich
                LOG.ghi("[TAI] Phien het han (401) khi tai %s - dung thu lai, dang nhap lai roi tai tiep." % goc)
                return None
            # May chu noi ro: khong co ho so goc (hoa don khong ma / nguoi ban khong gui XML) -> thu lai vo ich
            if kq.status == 500 and "h\u1ed3 s\u01a1 g\u1ed1c" in (kq.loi or "") or "kh\u00f4ng t\u1ed3n t\u1ea1i h\u1ed3 s\u01a1 g\u1ed1c" in (kq.loi or "").lower():
                LOG.ghi("[TAI] Co quan Thue khong luu XML goc cua %s (hoa don khong ma / chua nhan XML) - dung du lieu tra cuu." % goc)
                LY_DO_TAI["khong_ho_so"] = True
                return None
        LOG.ghi("[TAI] Lan thu %d that bai cho %s, cho 2 giay roi thu lai." % (lan, goc))
        if not ngu_huy_duoc(2):          # P2 18/11/2026: bam Dung -> thoi thu lai
            return None
    LOG.ghi("[TAI] Khong tai duoc goi tin cua %s sau 3 lan thu." % goc)
    return None


def tai_pdf_may_chu(params, kind, goc):
    """Thu xin file PDF san co tu may chu (neu co duong dan nay)."""
    if SETTINGS.get("khong_co_duong_pdf") or LY_DO_TAI.get("bi_chan") or not STATE.get("may_chu"):
        return None  # lan truoc da do het roi, khong do lai cho nhanh; GD94: cong dang chan / chua dang nhap

    ung_vien = duong_pdf_ung_vien(kind)
    da_chay = SETTINGS.get("duong_pdf_da_chay", {}).get(kind)
    if da_chay and da_chay in ung_vien:
        ung_vien.remove(da_chay)
        ung_vien.insert(0, da_chay)

    for duong in ung_vien:
        url = STATE["may_chu"] + duong + "?" + urllib.parse.urlencode(params)
        kq = goi_mang(url, token=STATE["token"], timeout=90)
        if kq.ok and kq.data:
            noi_dung = lay_pdf(kq.data)
            if noi_dung:
                if SETTINGS.get("duong_pdf_da_chay", {}).get(kind) != duong:
                    SETTINGS.setdefault("duong_pdf_da_chay", {})[kind] = duong
                    luu_thiet_lap(SETTINGS)
                    LOG.ghi("[DO TIM] Da nho duong tai PDF dung duoc cho lan sau: " + duong)
                return noi_dung

    if not SETTINGS.get("duong_pdf_da_chay"):
        SETTINGS["khong_co_duong_pdf"] = True
        luu_thiet_lap(SETTINGS)
        LOG.ghi("[DO TIM] May chu khong co duong tai PDF san. Tu gio se tu in PDF tu ban in hoa don.")
    return None


def lay_xml(du_lieu):
    """Tu goi .zip tai ve, lay ra file .xml duy nhat."""
    if du_lieu[:2] == b"PK":
        with zipfile.ZipFile(io.BytesIO(du_lieu)) as z:
            for ten in z.namelist():
                if ten.lower().endswith(".xml"):
                    return z.read(ten)
        return None
    if du_lieu.lstrip()[:5].lower().startswith(b"<?xml") or du_lieu.lstrip()[:1] == b"<":
        return du_lieu
    return None


def lay_pdf(du_lieu):
    """Neu goi tin tai ve da co san file PDF thi lay ra luon."""
    if du_lieu[:4] == b"%PDF":
        return du_lieu
    if du_lieu[:2] == b"PK":
        try:
            with zipfile.ZipFile(io.BytesIO(du_lieu)) as z:
                for ten in z.namelist():
                    if ten.lower().endswith(".pdf"):
                        return z.read(ten)
        except Exception:
            return None
    return None


# --------------------------------------------------------------------------
#  TAO PDF TU BAN IN HTML CO SAN TRONG GOI TIN
# --------------------------------------------------------------------------
DUONG_CHROME = [
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/usr/bin/google-chrome", "/usr/bin/chromium", "/usr/bin/chromium-browser",
]
_CHROME_DA_TIM = {"duong": None, "da_tim": False}


def tim_chrome():
    if _CHROME_DA_TIM["da_tim"]:
        return _CHROME_DA_TIM["duong"]
    _CHROME_DA_TIM["da_tim"] = True
    for d in DUONG_CHROME:
        if d and os.path.exists(d):
            _CHROME_DA_TIM["duong"] = d
            LOG.ghi("[PDF] Dung trinh duyet de in PDF: " + d)
            return d
    LOG.ghi("[PDF] KHONG tim thay Chrome/Edge tren may - khong tao duoc file PDF.")
    return None


def gop_html(du_lieu_zip):
    """Gop invoice.html + jQuery + anh thanh MOT file HTML doc lap."""
    try:
        with zipfile.ZipFile(io.BytesIO(du_lieu_zip)) as z:
            ten_html = next((n for n in z.namelist() if n.lower().endswith(".html")), None)
            if not ten_html:
                return None
            html = z.read(ten_html).decode("utf-8", "replace")

            for ten in z.namelist():
                thap = ten.lower()
                goc = os.path.basename(ten)
                if thap.endswith(".js"):
                    ma = z.read(ten).decode("utf-8", "replace")
                    html = html.replace('<script type="text/javascript" src="%s"></script>' % goc,
                                        "<script>\n" + ma + "\n</script>")
                    html = html.replace('src="%s"' % goc, 'src="%s"' % goc)  # phong truong hop khac dinh dang
                elif thap.endswith((".jpg", ".jpeg", ".png", ".gif")):
                    kieu = "png" if thap.endswith(".png") else ("gif" if thap.endswith(".gif") else "jpeg")
                    b64 = base64.b64encode(z.read(ten)).decode("ascii")
                    uri = "data:image/%s;base64,%s" % (kieu, b64)
                    for mau in ('url("%s")' % goc, "url('%s')" % goc, "url(%s)" % goc, 'src="%s"' % goc):
                        thay = mau.replace(goc, uri)
                        html = html.replace(mau, thay)
        return html.encode("utf-8")
    except Exception as e:
        LOG.loi("Loi khi gop ban in HTML", e)
        return None


def in_ra_pdf(html_bytes, dich_pdf):
    """Dung Chrome o che do nen de in ban in HTML ra file PDF."""
    chrome = tim_chrome()
    if not chrome:
        return False, "Máy chưa cài Chrome nên tool không tạo được file PDF. Cài Google Chrome rồi thử lại."

    thu_muc_tam = tempfile.mkdtemp(prefix="hoadon-")
    duong_html = os.path.join(thu_muc_tam, "ban-in.html")
    try:
        with open(duong_html, "wb") as f:
            f.write(html_bytes)
        url = "file:///" + duong_html.replace("\\", "/")

        bo_tham_so = [
            ["--headless=new", "--no-pdf-header-footer"],
            ["--headless=new"],
            ["--headless"],
        ]
        for tham_so in bo_tham_so:
            lenh = [chrome] + tham_so + [
                "--disable-gpu", "--no-sandbox", "--disable-extensions",
                "--run-all-compositor-stages-before-draw",
                "--virtual-time-budget=8000",
                "--print-to-pdf=" + dich_pdf, url,
            ]
            try:
                kq = subprocess.run(lenh, timeout=90,
                                    stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            except subprocess.TimeoutExpired:
                LOG.ghi("[PDF] Chrome in qua lau (90 giay), bo qua cach nay.")
                continue
            except Exception as e:
                LOG.loi("Loi khi goi Chrome de in PDF", e)
                continue

            if os.path.exists(dich_pdf) and os.path.getsize(dich_pdf) > 1000:
                return True, None
            loi_chrome = (kq.stderr or b"").decode("utf-8", "replace")[:500]
            LOG.ghi("[PDF] Cach in %s khong ra file. Chrome bao: %s"
                    % (" ".join(tham_so), loi_chrome or "(khong co thong bao)"))

        return False, "Chrome không in được hóa đơn ra PDF."
    except Exception as e:
        LOG.loi("Loi khi tao file PDF", e)
        return False, "Có lỗi khi tạo file PDF."
    finally:
        try:
            shutil.rmtree(thu_muc_tam, ignore_errors=True)
        except Exception:
            pass


# ==========================================================================
#  DOC DU LIEU TU FILE XML HOA DON
# ==========================================================================
TEN_TCHAT = {"1": "Hàng hóa, dịch vụ", "2": "Khuyến mại",
             "3": "Chiết khấu thương mại", "4": "Ghi chú / diễn giải"}


def _chu(e, ten, mac_dinh=""):
    if e is None:
        return mac_dinh
    con = e.find(ten)
    if con is None or con.text is None:
        return mac_dinh
    return con.text.strip()


def _so(e, ten):
    txt = _chu(e, ten, "")
    if not txt:
        return 0
    try:
        return float(txt.replace(",", ""))
    except Exception:
        return 0


def doc_xml_hoa_don(xml_bytes, ten_file_xml=""):
    """Boc tach thong tin quan trong trong mot file XML hoa don."""
    try:
        goc = ET.fromstring(xml_bytes)
    except Exception as e:
        LOG.loi("Khong doc duoc file XML " + ten_file_xml, e)
        return None

    try:
        chung = goc.find(".//DLHDon/TTChung")
        nban = goc.find(".//NDHDon/NBan")
        nmua = goc.find(".//NDHDon/NMua")
        ttoan = goc.find(".//NDHDon/TToan")

        hd = {
            "mau_so": _chu(chung, "KHMSHDon"),
            "ky_hieu": _chu(chung, "KHHDon"),
            "so_hd": _chu(chung, "SHDon"),
            "ngay_lap": _chu(chung, "NLap"),
            "loai_hd": _chu(chung, "THDon"),
            "hinh_thuc_tt": _chu(chung, "HTTToan"),
            "don_vi_tien": _chu(chung, "DVTTe", "VND"),
            "ty_gia": _so(chung, "TGia") or 1,
            "nban_mst": _chu(nban, "MST"),
            "nban_ten": _chu(nban, "Ten"),
            "nban_dchi": _chu(nban, "DChi"),
            "nmua_mst": _chu(nmua, "MST"),
            "nmua_ten": _chu(nmua, "Ten"),
            "nmua_dchi": _chu(nmua, "DChi"),
            "nmua_nguoi": _chu(nmua, "HVTNMHang"),
            "chua_thue": _so(ttoan, "TgTCThue"),
            "tien_thue": _so(ttoan, "TgTThue"),
            "chiet_khau": _so(ttoan, "TTCKTMai"),
            "thanh_toan": _so(ttoan, "TgTTTBSo"),
            "bang_chu": _chu(ttoan, "TgTTTBChu"),
            "mccqt": _chu(goc, "MCCQT"),
            "ten_file": ten_file_xml,
            "hang_hoa": [],
            "thue_suat": [],
            "lien_quan": None,
        }
        lq = chung.find("TTHDLQuan") if chung is not None else None
        if lq is not None:
            hd["lien_quan"] = {"loai": _chu(lq, "TCHDon"), "lhd": _chu(lq, "LHDCLQuan"),
                               "khms": _chu(lq, "KHMSHDCLQuan"), "khhd": _chu(lq, "KHHDCLQuan"),
                               "shd": _chu(lq, "SHDCLQuan"), "ngay": _chu(lq, "NLHDCLQuan")}

        for hh in goc.iter("HHDVu"):
            hd["hang_hoa"].append({
                "stt": _chu(hh, "STT"),
                "tinh_chat": TEN_TCHAT.get(_chu(hh, "TChat"), _chu(hh, "TChat")),
                "tchat_ma": _chu(hh, "TChat") or "1",
                "tien_thue": (_so(hh, "TThue") if hh.find("TThue") is not None else None),
                "ma_hang": _chu(hh, "MHHDVu"),
                "ten_hang": _chu(hh, "THHDVu"),
                "dvt": _chu(hh, "DVTinh"),
                "so_luong": _so(hh, "SLuong"),
                "don_gia": _so(hh, "DGia"),
                "chiet_khau": _so(hh, "STCKhau"),
                "thanh_tien": _so(hh, "ThTien"),
                "thue_suat": _chu(hh, "TSuat"),
            })

        for ls in goc.iter("LTSuat"):
            hd["thue_suat"].append({
                "thue_suat": _chu(ls, "TSuat"),
                "chua_thue": _so(ls, "ThTien"),
                "tien_thue": _so(ls, "TThue"),
            })

        return hd
    except Exception as e:
        LOG.loi("Loi khi boc tach du lieu tu XML " + ten_file_xml, e)
        return None


# ==========================================================================
#  GHI FILE EXCEL (.xlsx) - khong can cai them thu vien
# ==========================================================================
def _thoat(s):
    return (str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace('"', "&quot;"))


def _o_excel(cot, dong, gia_tri, kieu):
    """kieu: 'chu' / 'so' / 'tieu_de'"""
    vi_tri = ""
    n = cot
    while n > 0:
        n, du = divmod(n - 1, 26)
        vi_tri = chr(65 + du) + vi_tri
    vi_tri += str(dong)

    if kieu == "tieu_de":
        return '<c r="%s" s="1" t="inlineStr"><is><t xml:space="preserve">%s</t></is></c>' % (
            vi_tri, _thoat(gia_tri))
    if kieu in ("so", "so4"):
        try:
            gt = float(gia_tri)
            chuoi = str(int(gt)) if gt == int(gt) else repr(gt)
            return '<c r="%s" s="%d"><v>%s</v></c>' % (vi_tri, 3 if kieu == "so" else 4, chuoi)
        except Exception:
            return '<c r="%s" s="2" t="inlineStr"><is><t/></is></c>' % vi_tri
    if kieu == "thang":
        # gia_tri: 'yyyy-mm-dd' -> so serial Excel, hien mm/yyyy
        try:
            d = datetime.strptime(str(gia_tri)[:10], "%Y-%m-%d")
            serial = (d - datetime(1899, 12, 30)).days
            return '<c r="%s" s="5"><v>%d</v></c>' % (vi_tri, serial)
        except Exception:
            return '<c r="%s" s="2" t="inlineStr"><is><t/></is></c>' % vi_tri
    if kieu == "text":
        return '<c r="%s" s="6" t="inlineStr"><is><t xml:space="preserve">%s</t></is></c>' % (vi_tri, _thoat(gia_tri))
    return '<c r="%s" s="2" t="inlineStr"><is><t xml:space="preserve">%s</t></is></c>' % (
        vi_tri, _thoat(gia_tri))


class DongTong(list):
    """GD92: dong tong cong trong bang Excel - chu dam, nen mau (muc 1 vang nhat: tong ngay / tuan; muc 2 cam nhat: thang)."""
    def __init__(self, gia_tri, muc=1):
        list.__init__(self, gia_tri)
        self.muc = muc


def _o_dam(o, muc):
    """Doi kieu o (s=2 chu, 3 so, 4 so le, 6 van ban) sang kieu dam cua dong tong."""
    bang = {"2": 7, "3": 8, "4": 9, "6": 10} if muc == 1 else {"2": 11, "3": 12, "4": 13, "6": 14}
    return re.sub(r' s="(\d+)"', lambda m: ' s="%d"' % bang.get(m.group(1), int(m.group(1))), o)


def viet_xlsx(duong, cac_bang):
    """cac_bang: danh sach (ten_sheet, tieu_de[], kieu_cot[], do_rong[], cac_dong[]). Dong la DongTong -> chu dam, nen mau."""
    STYLES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<numFmts count="3"><numFmt numFmtId="164" formatCode="#,##0"/><numFmt numFmtId="165" formatCode="#,##0.####"/><numFmt numFmtId="166" formatCode="mm/yyyy"/></numFmts>
<fonts count="3">
<font><sz val="11"/><name val="Calibri"/></font>
<font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>
<font><b/><sz val="11"/><name val="Calibri"/></font>
</fonts>
<fills count="5">
<fill><patternFill patternType="none"/></fill>
<fill><patternFill patternType="gray125"/></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FF1D5FD6"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFFFF2CC"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFFCE4D6"/><bgColor indexed="64"/></patternFill></fill>
</fills>
<borders count="2">
<border><left/><right/><top/><bottom/><diagonal/></border>
<border><left style="thin"><color rgb="FFD0D7E5"/></left><right style="thin"><color rgb="FFD0D7E5"/></right><top style="thin"><color rgb="FFD0D7E5"/></top><bottom style="thin"><color rgb="FFD0D7E5"/></bottom><diagonal/></border>
</borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="15">
<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf>
<xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="top"/></xf>
<xf numFmtId="165" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="top"/></xf>
<xf numFmtId="166" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="top"/></xf>
<xf numFmtId="49" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment vertical="top"/></xf>
<xf numFmtId="0" fontId="2" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf>
<xf numFmtId="164" fontId="2" fillId="3" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="top"/></xf>
<xf numFmtId="165" fontId="2" fillId="3" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="top"/></xf>
<xf numFmtId="49" fontId="2" fillId="3" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="top"/></xf>
<xf numFmtId="0" fontId="2" fillId="4" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf>
<xf numFmtId="164" fontId="2" fillId="4" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="top"/></xf>
<xf numFmtId="165" fontId="2" fillId="4" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="top"/></xf>
<xf numFmtId="49" fontId="2" fillId="4" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="top"/></xf>
</cellXfs>
<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>"""

    sheets_xml = []
    for ten, tieu_de, kieu_cot, do_rong, cac_dong in cac_bang:
        cols = "".join('<col min="%d" max="%d" width="%d" customWidth="1"/>' % (i + 1, i + 1, w)
                       for i, w in enumerate(do_rong))
        rows = ['<row r="1" ht="30" customHeight="1">' +
                "".join(_o_excel(i + 1, 1, t, "tieu_de") for i, t in enumerate(tieu_de)) +
                "</row>"]
        for so_dong, dong in enumerate(cac_dong, start=2):
            o = "".join(_o_excel(i + 1, so_dong, gt, kieu_cot[i] if i < len(kieu_cot) else "chu")
                        for i, gt in enumerate(dong))
            if isinstance(dong, DongTong):
                o = _o_dam(o, dong.muc)
            rows.append('<row r="%d">%s</row>' % (so_dong, o))

        cuoi = len(tieu_de)
        chu_cuoi, n = "", cuoi
        while n > 0:
            n, du = divmod(n - 1, 26)
            chu_cuoi = chr(65 + du) + chu_cuoi

        sheets_xml.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>
<cols>%s</cols>
<sheetData>%s</sheetData>
<autoFilter ref="A1:%s1"/>
</worksheet>""" % (cols, "".join(rows), chu_cuoi))

    ten_sheets = "".join(
        '<sheet name="%s" sheetId="%d" r:id="rId%d"/>' % (_thoat(b[0]), i + 1, i + 1)
        for i, b in enumerate(cac_bang))
    rels = "".join(
        '<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet%d.xml"/>'
        % (i + 1, i + 1) for i in range(len(cac_bang)))
    n = len(cac_bang)

    with zipfile.ZipFile(duong, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
%s
<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
</Types>""" % "".join(
            '<Override PartName="/xl/worksheets/sheet%d.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' % (i + 1)
            for i in range(n)))
        z.writestr("_rels/.rels", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>""")
        z.writestr("xl/workbook.xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheets>%s</sheets></workbook>""" % ten_sheets)
        z.writestr("xl/_rels/workbook.xml.rels", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
%s<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>""" % (rels, n + 1))
        z.writestr("xl/styles.xml", STYLES)
        for i, sx in enumerate(sheets_xml):
            z.writestr("xl/worksheets/sheet%d.xml" % (i + 1), sx)


def xuat_excel(danh_sach_hd, thu_muc):
    """Gop danh muc tat ca hoa don thanh MOT file Excel 3 sheet."""
    if not danh_sach_hd:
        return None, "Không có hóa đơn nào để gộp vào file Excel."

    # ---- Sheet 1: bang ke hoa don, moi hoa don mot dong ----
    tieu_de_1 = ["STT", "Mẫu số", "Ký hiệu", "Số hóa đơn", "Ngày lập", "Loại hóa đơn",
                 "MST người bán", "Tên người bán", "Địa chỉ người bán",
                 "MST người mua", "Tên người mua", "Địa chỉ người mua",
                 "Hình thức TT", "Tiền tệ", "Tổng chưa thuế", "Tiền thuế",
                 "Chiết khấu", "Tổng thanh toán", "Mã CQT", "Tên file"]
    kieu_1 = ["so", "chu", "chu", "chu", "chu", "chu", "chu", "chu", "chu", "chu",
              "chu", "chu", "chu", "chu", "so", "so", "so", "so", "chu", "chu"]
    rong_1 = [5, 7, 10, 12, 11, 22, 15, 34, 34, 15, 34, 34, 12, 8, 15, 13, 12, 15, 34, 38]
    dong_1 = []
    for i, h in enumerate(danh_sach_hd, 1):
        dong_1.append([i, h["mau_so"], h["ky_hieu"], h["so_hd"], h["ngay_lap"], h["loai_hd"],
                       h["nban_mst"], h["nban_ten"], h["nban_dchi"],
                       h["nmua_mst"], _ten_nguoi_mua(h["nmua_ten"], h.get("nmua_nguoi")), h["nmua_dchi"],
                       h["hinh_thuc_tt"], h["don_vi_tien"], h["chua_thue"], h["tien_thue"],
                       h["chiet_khau"], h["thanh_toan"], h["mccqt"], h["ten_file"]])

    # ---- Sheet 2: chi tiet tung mat hang ----
    tieu_de_2 = ["STT", "Ký hiệu", "Số hóa đơn", "Ngày lập", "MST người bán", "Tên người bán",
                 "MST người mua", "Tên người mua", "Dòng", "Tính chất", "Mã hàng",
                 "Tên hàng hóa, dịch vụ", "ĐVT", "Số lượng", "Đơn giá",
                 "Chiết khấu", "Thành tiền", "Thuế suất"]
    kieu_2 = ["so", "chu", "chu", "chu", "chu", "chu", "chu", "chu", "chu", "chu",
              "chu", "chu", "chu", "so4", "so4", "so", "so", "chu"]
    rong_2 = [5, 10, 12, 11, 15, 30, 15, 30, 6, 20, 12, 42, 8, 10, 14, 12, 15, 9]
    dong_2, stt = [], 0
    for h in danh_sach_hd:
        for hh in h["hang_hoa"]:
            stt += 1
            dong_2.append([stt, h["ky_hieu"], h["so_hd"], h["ngay_lap"],
                           h["nban_mst"], h["nban_ten"], h["nmua_mst"], _ten_nguoi_mua(h["nmua_ten"], h.get("nmua_nguoi")),
                           hh["stt"], hh["tinh_chat"], hh["ma_hang"], hh["ten_hang"],
                           hh["dvt"], hh["so_luong"], hh["don_gia"], hh["chiet_khau"],
                           hh["thanh_tien"], hh["thue_suat"]])

    # ---- Sheet 3: tong hop theo thue suat ----
    gom = {}
    for h in danh_sach_hd:
        muc = h["thue_suat"] or [{"thue_suat": "Không rõ",
                                  "chua_thue": h["chua_thue"], "tien_thue": h["tien_thue"]}]
        for m in muc:
            k = m["thue_suat"] or "Không rõ"
            g = gom.setdefault(k, {"so_hd": 0, "chua_thue": 0.0, "tien_thue": 0.0})
            g["so_hd"] += 1
            g["chua_thue"] += m["chua_thue"]
            g["tien_thue"] += m["tien_thue"]

    tieu_de_3 = ["Thuế suất", "Số dòng hóa đơn", "Tiền chưa thuế", "Tiền thuế", "Tổng cộng"]
    kieu_3 = ["chu", "so", "so", "so", "so"]
    rong_3 = [14, 16, 18, 18, 18]
    dong_3 = []
    for k in sorted(gom.keys()):
        g = gom[k]
        dong_3.append([k, g["so_hd"], g["chua_thue"], g["tien_thue"],
                       g["chua_thue"] + g["tien_thue"]])
    dong_3.append(["TỔNG CỘNG", sum(g["so_hd"] for g in gom.values()),
                   sum(g["chua_thue"] for g in gom.values()),
                   sum(g["tien_thue"] for g in gom.values()),
                   sum(g["chua_thue"] + g["tien_thue"] for g in gom.values())])

    ten = "Bang-ke-hoa-don_%s.xlsx" % datetime.now().strftime("%Y%m%d-%H%M%S")
    duong = os.path.join(thu_muc, ten)
    lan = 2
    while os.path.exists(duong):
        ten = "Bang-ke-hoa-don_%s_%d.xlsx" % (datetime.now().strftime("%Y%m%d-%H%M%S"), lan)
        duong = os.path.join(thu_muc, ten)
        lan += 1
    try:
        viet_xlsx(duong, [
            ("Bảng kê hóa đơn", tieu_de_1, kieu_1, rong_1, dong_1),
            ("Chi tiết hàng hóa", tieu_de_2, kieu_2, rong_2, dong_2),
            ("Tổng hợp theo thuế suất", tieu_de_3, kieu_3, rong_3, dong_3),
        ])
        LOG.ghi("[EXCEL] Da tao file: %s (%d hoa don, %d dong hang hoa, %d muc thue suat)"
                % (ten, len(dong_1), len(dong_2), len(dong_3) - 1))
        return ten, None
    except Exception as e:
        LOG.loi("Loi khi tao file Excel", e)
        return None, "Không tạo được file Excel. Xem chi tiết trong file nhật ký."


# ---- 4 mau Excel theo dinh dang nhap cua UNESCO: MUAVAO/BANRA x TONGHOP/CHITIET ----
COT_HDDT = ["Ký hiệu mẫu số", "Ký hiệu hóa đơn", "Số hóa đơn", "Ngày lập", "Ngày người bán ký số", "MCCQT",
            "Ngày CQT ký số", "Đơn vị tiền tệ", "Tỷ giá", "Tên người bán/Tên người xuất hàng",
            "MST người bán/MST người xuất hàng", "Địa chỉ người bán", "Tên người mua/Tên người nhận hàng",
            "MST người mua/MST người nhận hàng", "Địa chỉ người mua", "Mã VT", "Tên hàng hóa, dịch vụ",
            "Đơn vị tính", "Số lượng", "Đơn giá", "Chiết khấu", "Thuế suất", "Thành tiền chưa thuế", "Tiền thuế",
            "Tổng tiền chiết khấu thương mại", "Tổng tiền phí", "Tổng tiền thanh toán", "Trạng thái hóa đơn",
            "Kết quả kiểm tra hóa đơn", "Tài khoản", "PHÂN LOẠI", "THANH TOÁN", "THÁNG CT"]
KIEU_HDDT = ["text", "text", "text", "chu", "chu", "chu", "chu", "chu", "so4", "chu", "text", "chu", "chu", "text", "chu",
             "text", "chu", "chu", "so4", "so4", "so", "chu", "so", "so", "so", "so", "so", "chu", "chu",
             "text", "text", "text", "thang"]
RONG_HDDT = [9, 9, 10, 11, 12, 30, 12, 8, 6, 40, 14, 30, 40, 14, 30, 10, 42, 8, 9, 12, 10, 9, 15, 13, 12, 10, 15, 16, 20, 9, 10, 10, 10]
TU_KHOA_DV = ("dich vu", "dịch vụ", "phi ", "phí ", "cuoc ", "cước ", "tien dien", "tiền điện", "tien nuoc", "tiền nước",
              "van chuyen", "vận chuyển", "thue ", "thuê ", "sua chua", "sửa chữa", "bao tri", "bảo trì", "tu van", "tư vấn",
              "quang cao", "quảng cáo", "internet", "vien thong", "viễn thông", "dao tao", "đào tạo", "kiem dinh", "kiểm định",
              "bao hiem", "bảo hiểm", "hoa hong", "hoa hồng", "gia cong", "gia công", "in an", "in ấn", "logistics", "cang ",
              "cảng ", "luu kho", "lưu kho", "boc xep", "bốc xếp", "ve may bay", "vé máy bay", "khach san", "khách sạn",
              "an uong", "ăn uống", "phong ", "phòng ", "tien phong", "tiền phòng", "xang", "xăng", "dau diesel", "dầu diesel",
              "khoa hoc", "khóa học", "hoc phi", "học phí", "le phi", "lệ phí", "cong tac", "công tác", "tiep khach", "tiếp khách")
BANG_MA_UNESCO = [["LOẠI CT", "Cách nhập liệu", "", "Thanh toán", "Cách nhập liệu", "", "Tháng CT", "Cách nhập liệu"],
                  ["Tổng hợp", "0", "", "Phải trả khách hàng", "PTR", "", "Định dạng tháng/năm", "mm/yyyy"],
                  ["Nhập vật tư", "1", "", "Phải thu khách hàng", "PTH", "", "", ""],
                  ["", "", "", "Theo dõi tiền mặt", "TM", "", "", ""],
                  ["", "", "", "", "", "", "", ""],
                  ["", "", "", "Phân loại", "Cách nhập liệu", "Tài khoản", "", ""],
                  ["", "", "", "Hàng hóa", "HH", "1561", "", ""],
                  ["", "", "", "Công cụ dụng cụ", "CCDC", "1531", "", ""],
                  ["", "", "", "Hàng khuyến mãi", "KM", "1561", "", ""],
                  ["", "", "", "Nguyên vật liệu", "NVL", "1521", "", ""],
                  ["", "", "", "Thành phẩm", "TP", "155", "", ""],
                  ["", "", "", "Nguyên vật liệu phụ", "NVP", "1522", "", ""],
                  ["", "", "", "Dịch vụ / chi phí kinh doanh", "CPKD", "6422", "", ""]]


def _la_dich_vu(ten):
    t = " " + str(ten or "").lower() + " "
    return any(k in t for k in TU_KHOA_DV)


def _phan_loai_dong(d, huong):
    """Tra ve (tai_khoan, phan_loai, thanh_toan, loai_ct) cho mot dong hang."""
    tchat = str(d.get("tchat") or "1")
    dv = _la_dich_vu(d.get("TenHangHoaDichVu"))
    if huong == "ban":
        return ("5113", "DV", "PTH", "0") if dv else ("5111", "HH", "PTH", "1")
    if not d.get("XML") and not d.get("TenHangHoaDichVu"):
        dv = True          # khong co XML / khong co dong hang: de dang tong hop (chi phi), nguoi dung sua sau
    if tchat == "2":
        return ("1561", "KM", "PTR", "1")
    if dv:
        return ("6422", "CPKD", "PTR", "0")
    return ("1561", "HH", "PTR", "1")


def _dong_hddt(d, huong, tong_hop, thu_tu):
    """Mot dong Excel theo COT_HDDT (+ cot cuoi: LOAI CT / THU TU BANG KE)."""
    tk, pl, tt, loai = _phan_loai_dong(d, huong)
    ngay = str(d.get("NgayLap") or "")[:10]
    hien_ngay = lambda x: ("%s/%s/%s" % (x[8:10], x[5:7], x[0:4])) if len(x or "") >= 10 else (x or "")
    row = [d.get("KyHieuMauSo", ""), d.get("KyHieuHoaDon", ""), d.get("SoHoaDon", ""), hien_ngay(ngay),
           hien_ngay(str(d.get("NgayNguoiBanKySo") or "")[:10]), d.get("MCCQT", ""), hien_ngay(str(d.get("NgayCQTKySo") or "")[:10]),
           d.get("DonViTienTe", "VND"), d.get("TyGia", 1),
           d.get("TenNguoiBanNguoiXuatHang", ""), d.get("MSTNguoiBanNguoiXuatHang", ""), d.get("DiaChiNguoiBan", ""),
           d.get("TenNguoiMuaNguoiNhanHang", ""), d.get("MSTNguoiMuaNguoiNhanHang", ""), d.get("DiaChiNguoiMua", ""),
           "" if tong_hop else d.get("MaVT", ""),
           d.get("TenHangHoaDichVu", ""),
           "" if tong_hop else d.get("DonViTinh", ""),
           "" if tong_hop else d.get("SoLuong", 0),
           "" if tong_hop else d.get("DonGia", 0),
           d.get("ChietKhau", 0), d.get("ThueSuat", ""), d.get("ThanhTienChuaThue", 0), d.get("TienThue", 0),
           d.get("TongTienChietKhauThuongMai", 0), d.get("TongTienPhi", 0), d.get("TongTienThanhToan", 0),
           d.get("TrangThaiHoaDon", ""), d.get("KetQuaKiemTraHoaDon", ""),
           tk, pl, tt, ngay]
    if huong == "ban" and not tong_hop:
        row.append(thu_tu)
    elif huong != "ban":
        row.append(loai)
    return row


def xuat_excel_4_mau(cac_dong, huong, thu_muc):
    """cac_dong: dong JSONL (unesco_dong_tu_xml / _tu_cong). Tao MUAVAO|BANRA _TONGHOP + _CHITIET.
    Tra ve danh sach ten file da tao."""
    if not cac_dong:
        return []
    nhan = "BANRA" if huong == "ban" else "MUAVAO"
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    # gom theo hoa don (giu thu tu)
    theo_hd, thu_tu = {}, []
    for d in cac_dong:
        k = d.get("khoa") or "%s|%s|%s" % (d.get("KyHieuMauSo"), d.get("KyHieuHoaDon"), d.get("SoHoaDon"))
        if k not in theo_hd:
            theo_hd[k] = []; thu_tu.append(k)
        theo_hd[k].append(d)
    chi_tiet, tong_hop = [], []
    for i, k in enumerate(thu_tu, 1):
        ds = theo_hd[k]
        for d in ds:
            chi_tiet.append(_dong_hddt(d, huong, False, i))
        # dong tong hop: 1 dong / hoa don
        t = dict(ds[0])
        ten = [str(x.get("TenHangHoaDichVu") or "") for x in ds if x.get("TenHangHoaDichVu")]
        t["TenHangHoaDichVu"] = (ten[0] + (" (+%d dòng)" % (len(ten) - 1) if len(ten) > 1 else "")) if ten else "Hàng hóa, dịch vụ theo hóa đơn"
        t["ChietKhau"] = sum(_so_an_toan(x.get("ChietKhau")) for x in ds)
        t["ThanhTienChuaThue"] = _so_an_toan(t.get("tong_chua_thue")) if t.get("tong_chua_thue") is not None and t.get("XML") else sum(_so_an_toan(x.get("ThanhTienChuaThue")) for x in ds)
        t["TienThue"] = _so_an_toan(t.get("tong_thue")) if t.get("tong_thue") is not None and t.get("XML") else sum(_so_an_toan(x.get("TienThue")) for x in ds)
        # phan loai tong hop: theo dong hang dau tien (neu co dich vu thi CPKD)
        if huong != "ban" and any(_phan_loai_dong(x, huong)[1] == "CPKD" for x in ds) and not any(_phan_loai_dong(x, huong)[1] == "HH" for x in ds):
            t["TenHangHoaDichVu"] = t["TenHangHoaDichVu"]
        tong_hop.append(_dong_hddt(t, huong, True, i))
    cot_ct = COT_HDDT + (["THỨ TỰ BẢNG KÊ"] if huong == "ban" else ["LOẠI CT"])
    cot_th = COT_HDDT + ([] if huong == "ban" else ["LOẠI CT"])
    kieu_ct = KIEU_HDDT + (["so"] if huong == "ban" else ["text"])
    kieu_th = KIEU_HDDT + ([] if huong == "ban" else ["text"])
    rong_ct = RONG_HDDT + [10]
    rong_th = RONG_HDDT + ([] if huong == "ban" else [10])
    bang_ma = ("Trang_tính1", BANG_MA_UNESCO[0], ["chu"] * 8, [14, 14, 3, 26, 14, 10, 20, 14], BANG_MA_UNESCO[1:])
    tep = []
    for ten, cot, kieu, rong, dong in (("%s_TONGHOP_%s.xlsx" % (nhan, ts), cot_th, kieu_th, rong_th, tong_hop),
                                        ("%s_CHITIET_%s.xlsx" % (nhan, ts), cot_ct, kieu_ct, rong_ct, chi_tiet)):
        duong = os.path.join(thu_muc, ten)
        try:
            viet_xlsx(duong, [("Sheet1", cot, kieu, rong, dong), bang_ma])
            LOG.ghi("[EXCEL] Da tao %s (%d dong)" % (ten, len(dong)))
            tep.append(ten)
        except Exception as e:
            LOG.loi("Loi khi tao " + ten, e)
    return tep


def unesco_gom_dong(thu_thap, danh_sach, direction, kind, thu_muc):
    """Gop XML da doc + hoa don khong co XML thanh danh sach dong (dung cho JSONL va Excel 4 mau)."""
    cong = {}
    for hd in danh_sach:
        cong[unesco_khoa(hd.get("nbmst"), hd.get("khmshdon"), hd.get("khhdon"), hd.get("shdon"))] = hd
    dong, da_co = [], set()
    bo_khac = 0     # GD43: hoa don khong thuoc cong ty cua bo so (dang nhap nham tai khoan cong ty khac)
    for hd in (thu_thap or []):
        k = unesco_khoa(hd["nban_mst"], hd["mau_so"], hd["ky_hieu"], hd["so_hd"])
        if not unesco_hd_thuoc_cty(hd.get("nban_mst"), hd.get("nmua_mst")):
            bo_khac += 1; da_co.add(k); continue
        tep = hd.get("duong_xml") or os.path.join(thu_muc, hd.get("ten_file") or "")     # GD94: noi that cua file XML
        dong.extend(unesco_dong_tu_xml(hd, direction, kind, cong.get(k), tep))
        da_co.add(k)
    for k, hd in cong.items():
        if k not in da_co:
            if not unesco_hd_thuoc_cty(hd.get("nbmst"), hd.get("nmmst")):
                bo_khac += 1; continue
            ct = unesco_chi_tiet_tu_cong(hd, kind)
            if ct:
                dong.extend(unesco_dong_tu_chi_tiet(hd, ct, direction, kind))
            else:
                dong.extend(unesco_dong_tu_cong(hd, direction, kind))
    return dong


# ==========================================================================
#  GD91 - TONG HOP HOA DON BAN LE THANH 1 CHUNG TU (don vi ban le, luong hoa don ban ra rat lon)
#  Gom hoa don BAN RA da chon theo ky (1..6 ngay tinh tu ngay 1, hoac tuan Thu Hai -> Chu Nhat; KHONG
#  vuot qua cuoi thang) + mau so + ky hieu. Moi nhom -> MOT "hoa don tong hop" gui sang phan mem
#  (JSONL) - phan mem lap 1 chung tu. Dong hang cong theo tung mat hang (ma / ten + DVT + thue suat +
#  tinh chat): so luong va tien cong lai, don gia binh quan -> van xuat kho dung tung mat hang.
#  So chung tu BKBL<thang>.<ngay> (vd BKBL07.01 = bang ke ban le ngay 01/07); so hoa don tren bang ke
#  thue = so HD nho nhat trong nhom. Kem file Excel chi tiet tung hoa don.
#  Chong trung (quy tac 18 - lop CHAN): so dang ky tong-hop-ban-le.json (HD thanh vien -> chung tu tong
#  hop). HD da co trong phan mem / da gui trong phien / da nam trong chung tu tong hop con song ->
#  KHONG gop lai, KHONG gui rieng lan nua. Chung tu tong hop bi xoa khoi phan mem -> HD lai gop duoc.
# ==========================================================================
TH_TEP_SO = "tong-hop-ban-le.json"
TH_TEN_KH = "Người tiêu dùng"          # GD60/61: ten chung -> ma khach le chung NTD_
TH_DA_GUI = set()                       # khoa (HD le + chung tu tong hop) da ghi JSONL cho phan mem trong PHIEN nay
TH_DA_GUI_TEP = {}                      # GD116: khoa -> (ten tep ket-qua, luc gui) - phan mem da doc tep roi XOA HD -> bo khoi TH_DA_GUI
TH_SO_NGAY = (1, 2, 3, 4, 5, 6, 7)      # 7 = 1 tuan Thu Hai -> Chu Nhat
TH_TEN_TCHAT = {"1": "Hàng hóa, dịch vụ", "2": "Khuyến mại", "3": "Chiết khấu thương mại", "4": "Ghi chú"}


def th_ngay(s):
    """'yyyy-mm-dd...' -> date (None neu khong doc duoc)."""
    try:
        return datetime.strptime(str(s or "")[:10], "%Y-%m-%d").date()
    except Exception:
        return None


def th_ky_gop(ngay, so_ngay):
    """Ky gop cua mot ngay: so_ngay 1..6 = khoi so_ngay ngay tinh tu ngay 1 cua thang; 7 = tuan Thu Hai ->
    Chu Nhat. Khong bao gio vuot qua dau / cuoi thang (chung tu nam dung ky ke toan, ky thue).
    ngay: date. Tra ve (tu, den) kieu date."""
    so_ngay = int(so_ngay) if int(so_ngay) in TH_SO_NGAY else 1
    dau = ngay.replace(day=1)
    cuoi = (dau + timedelta(days=32)).replace(day=1) - timedelta(days=1)
    if so_ngay == 7:
        tu = ngay - timedelta(days=ngay.weekday())          # Thu Hai
        den = tu + timedelta(days=6)                        # Chu Nhat
    else:
        k = (ngay.day - 1) // so_ngay
        tu = dau + timedelta(days=k * so_ngay)
        den = tu + timedelta(days=so_ngay - 1)
    return max(tu, dau), min(den, cuoi)


def th_ten_cach_gop(so_ngay):
    return "1 tuần (Thứ Hai → Chủ Nhật)" if int(so_ngay) == 7 else "%d ngày" % int(so_ngay)


def th_chuan_ten(s):
    """Khoa so sanh ten hang / DVT: Unicode dung san (NFC), khong phan biet hoa thuong, gon khoang trang."""
    import unicodedata
    return re.sub(r"\s+", " ", unicodedata.normalize("NFC", str(s or ""))).strip().casefold()


def th_ts_so(ts):
    """Thue suat dang so ('8%' -> 8.0); chu (KCT, KKKNT, KHAC...) hoac rong -> None. Giong HDDT_TSExcelSo cua VB."""
    t = str(ts or "").strip().replace("%", "").replace(",", ".")
    try:
        return float(t) if t else None
    except Exception:
        return None


def _th_so_sx(so):
    s = str(so or "").strip()
    return (0, int(s), s) if s.isdigit() else (1, 0, s)


def th_so_ct(ngay, da_dung):
    """So chung tu tong hop: BKBL<thang>.<ngay> (vd BKBL07.01); cung nam da co thi them B, C, ...
    da_dung: tap "<nam>|<so CT>" cua cac chung tu tong hop con song (tu ghi them so vua cap)."""
    goc = "BKBL%02d.%02d" % (ngay.month, ngay.day)
    for hau in [""] + [chr(c) for c in range(ord("B"), ord("Z") + 1)]:
        so = goc + hau
        if "%d|%s" % (ngay.year, so) not in da_dung:
            da_dung.add("%d|%s" % (ngay.year, so))
            return so
    so = "%s-%d" % (goc, len(da_dung))
    da_dung.add("%d|%s" % (ngay.year, so))
    return so


def th_ly_do_rieng(ds, pham_vi, ck_xu_ly=1):
    """Ly do mot hoa don (ds = cac dong cua no) KHONG gop (nhap rieng tung to nhu truoc). Rong = gop duoc."""
    d0 = ds[0]
    if (d0.get("huong") or "ban") != "ban":
        return "Không phải hóa đơn bán ra"
    tthai = str(d0.get("tthai") or "").strip()
    if tthai not in ("", "1"):
        return "%s - nhập riêng để phần mềm xử lý đúng" % (TEN_TTHAI.get(tthai) or d0.get("TrangThaiHoaDon") or ("trạng thái " + tthai))
    if d0.get("lien_quan"):
        return "Hóa đơn thay thế / điều chỉnh cho hóa đơn khác - nhập riêng"
    tien = str(d0.get("DonViTienTe") or "VND").strip().upper()
    if tien not in ("", "VND"):
        return "Hóa đơn ngoại tệ (%s) - nhập riêng" % tien
    if th_ngay(d0.get("NgayLap")) is None:
        return "Không đọc được ngày lập - nhập riêng"
    if pham_vi != "tat_ca" and unesco_mst_so(d0.get("MSTNguoiMuaNguoiNhanHang")):
        return "Người mua có MST - nhập riêng từng tờ (chọn “Toàn bộ hóa đơn” nếu muốn gộp cả hóa đơn có MST)"
    if any(not str(d.get("TenHangHoaDichVu") or "").strip() for d in ds):
        return "Không có chi tiết dòng hàng (cổng thuế không lưu XML gốc) - nhập riêng như trước"
    if not int(ck_xu_ly or 0) and any(str(d.get("tchat") or "1") == "3" for d in ds):
        return "Có dòng chiết khấu thương mại mà Quy tắc hạch toán đang để lập tay - nhập riêng"
    return ""


def th_cong_dong(cac_dong):
    """Cong dong hang cua nhieu hoa don theo tung mat hang: (tinh chat, ma hang, ten, DVT, thue suat).
    Tra ve danh sach dict (giu thu tu gap dau tien)."""
    gop, thu_tu = {}, []
    for d in cac_dong:
        tchat = str(d.get("tchat") or "1")
        ma = str(d.get("MaVT") or "").strip()
        ten = str(d.get("TenHangHoaDichVu") or "").strip()
        dvt = str(d.get("DonViTinh") or "").strip()
        ts = str(d.get("ThueSuat") or "").strip()
        k = (tchat, ma.upper(), th_chuan_ten(ten), th_chuan_ten(dvt), ts.upper().replace(" ", ""))
        g = gop.get(k)
        if g is None:
            g = {"tchat": tchat, "MaVT": ma, "TenHangHoaDichVu": ten, "DonViTinh": dvt, "ThueSuat": ts,
                 "SoLuong": 0.0, "ThanhTienChuaThue": 0.0, "TienThue": 0.0, "ChietKhau": 0.0,
                 "giam2": bool(d.get("giam2")), "_hd": set(), "_dg": set()}
            gop[k] = g
            thu_tu.append(k)
        g["SoLuong"] += _so_an_toan(d.get("SoLuong"))
        g["ThanhTienChuaThue"] += _so_an_toan(d.get("ThanhTienChuaThue"))
        g["TienThue"] += _so_an_toan(d.get("TienThue"))
        g["ChietKhau"] += _so_an_toan(d.get("ChietKhau"))
        g["_hd"].add(d.get("khoa") or "")
        g["_dg"].add(round(_so_an_toan(d.get("DonGia")), 4))
    kq = []
    for k in thu_tu:
        g = gop[k]
        for c in ("SoLuong",):
            g[c] = round(g[c], 4)
        for c in ("ThanhTienChuaThue", "TienThue", "ChietKhau"):
            g[c] = round(g[c], 2)
        if g["SoLuong"]:
            g["DonGia"] = round(g["ThanhTienChuaThue"] / g["SoLuong"], 4)
        else:
            g["DonGia"] = list(g["_dg"])[0] if len(g["_dg"]) == 1 else 0
        g["so_hd_co"] = len(g.pop("_hd"))
        g.pop("_dg")
        kq.append(g)
    return kq


def _th_chia_thue_suat(cac_dong):
    """Phan mem lap chung tu ban hang chi nhan toi da 2 thue suat khac 0 moi hoa don. Nhom co > 2 thue suat
    -> chia thanh nhieu 'goi' (moi goi toi da 2 thue suat; dong 0% / KCT / KKKNT theo goi dau)."""
    ts = sorted({v for v in (th_ts_so(d.get("ThueSuat")) for d in cac_dong) if v})
    if len(ts) <= 2:
        return [list(cac_dong)]
    cap = [ts[i:i + 2] for i in range(0, len(ts), 2)]
    goi = [[] for _ in cap]
    hang_hd = {}            # (khoa HD, goi) -> tien hang: dong CK / KM khong ghi thue suat theo goi co nhieu hang nhat cua HD do
    cho = []
    for d in cac_dong:
        v = th_ts_so(d.get("ThueSuat"))
        vi = 0
        for i, c in enumerate(cap):
            if v in c:
                vi = i
                break
        if not v and str(d.get("tchat") or "1") in ("2", "3"):
            cho.append(d)
            continue
        goi[vi].append(d)
        k = (d.get("khoa") or "", vi)
        hang_hd[k] = hang_hd.get(k, 0) + abs(_so_an_toan(d.get("ThanhTienChuaThue")))
    for d in cho:
        kh = d.get("khoa") or ""
        vi = max(range(len(cap)), key=lambda i: (hang_hd.get((kh, i), 0), -i))
        goi[vi].append(d)
    return [g for g in goi if g]


def _th_ghep_so(ung_vien):
    """ung_vien: moi goi 1 danh sach so HD (tang dan). Chon cho moi goi 1 so KHAC NHAU (ghep cap Kuhn).
    Tra ve danh sach so (theo thu tu goi) hoac None neu khong ghep duoc."""
    gan = {}

    def thu(i, da_xem):
        for so in ung_vien[i]:
            if so in da_xem:
                continue
            da_xem.add(so)
            if so not in gan or thu(gan[so], da_xem):
                gan[so] = i
                return True
        return False
    for i in range(len(ung_vien)):
        if not thu(i, set()):
            return None
    kq = [None] * len(ung_vien)
    for so, i in gan.items():
        kq[i] = so
    return kq


def _th_lap_goi(ds_hd, theo_hd):
    """Chia nhom HD thanh cac goi thue suat va chon so HD dai dien khac nhau. -> [(dong, tv, so, nha)] hoac None.
    nha: HD 'o nha' goi nay (goi co nhieu tien hang nhat cua HD) - phan lech dau HD / dong tinh vao goi nay."""
    tat_ca = [d for k in ds_hd for d in theo_hd[k]]
    goi = _th_chia_thue_suat(tat_ca)
    tv_goi = [sorted({d.get("khoa") for d in g}, key=lambda k: _th_so_sx(theo_hd[k][0].get("SoHoaDon"))) for g in goi]
    so = _th_ghep_so([[str(theo_hd[k][0].get("SoHoaDon")) for k in tv] for tv in tv_goi])
    if so is None:
        return None
    tien = {}
    for i, g in enumerate(goi):
        for d in g:
            if str(d.get("tchat") or "1") != "3":
                kk = (d.get("khoa"), i)
                tien[kk] = tien.get(kk, 0) + abs(_so_an_toan(d.get("ThanhTienChuaThue")))
    nha = [[] for _ in goi]
    for k in ds_hd:
        co = [i for i in range(len(goi)) if k in tv_goi[i]]
        if co:
            nha[max(co, key=lambda i: (tien.get((k, i), 0), -i))].append(k)
    return [(goi[i], tv_goi[i], so[i], nha[i]) for i in range(len(goi))]


def th_tong_hop(cac_dong, so_ngay, pham_vi, so_ct_da_dung=None, lay_tep_excel="", ck_xu_ly=1):
    """cac_dong: dong JSONL tung hoa don (unesco_gom_dong). Tra ve dict:
      ct   : danh sach chung tu tong hop {khoa, so_ct, so_hd, ngay, tu, den, mau, kh, hd:[khoa HD], dong:[dong JSONL gop], ...}
      rieng: danh sach {khoa, ly_do, dong} - hoa don nhap rieng tung to
      theo_hd: {khoa HD: [dong]}"""
    da_dung = set(so_ct_da_dung or ())
    theo_hd, thu_tu, da_gap = {}, [], set()
    for d in cac_dong:
        k = d.get("khoa") or ""
        if d.get("stt_dong") not in (None, ""):
            kd = (k, str(d.get("stt_dong")))
            if kd in da_gap:
                continue        # cung dong (cung so thu tu) cua cung HD lap lai (tra cuu / tai lai) - chi cong 1 lan
            da_gap.add(kd)
        if k not in theo_hd:
            theo_hd[k] = []
            thu_tu.append(k)
        theo_hd[k].append(d)
    nhom, rieng = {}, []
    for k in thu_tu:
        d0 = theo_hd[k][0]
        ly_do = th_ly_do_rieng(theo_hd[k], pham_vi, ck_xu_ly)
        if ly_do:
            rieng.append({"khoa": k, "ly_do": ly_do, "dong": theo_hd[k]})
            continue
        tu, den = th_ky_gop(th_ngay(d0.get("NgayLap")), so_ngay)
        gk = (unesco_mst_so(d0.get("MSTNguoiBanNguoiXuatHang")), str(d0.get("KyHieuMauSo") or "").strip(),
              str(d0.get("KyHieuHoaDon") or "").strip(), tu, den)
        nhom.setdefault(gk, []).append(k)
    ct = []
    for gk in sorted(nhom, key=lambda x: (x[3], x[1], x[2], x[0])):
        ds_hd = sorted(nhom[gk], key=lambda k: _th_so_sx(theo_hd[k][0].get("SoHoaDon")))
        lap = _th_lap_goi(ds_hd, theo_hd)
        if lap is None:
            # khong du so HD khac nhau cho tung goi thue suat: tach rieng cac HD co tu 3 thue suat tro len roi thu lai
            nhieu = [k for k in ds_hd if len({v for v in (th_ts_so(d.get("ThueSuat")) for d in theo_hd[k]) if v}) >= 3]
            con = [k for k in ds_hd if k not in nhieu]
            lap = _th_lap_goi(con, theo_hd) if (nhieu and con) else None
            if lap is None:
                nhieu, con = ds_hd, []
            for k in nhieu:
                rieng.append({"khoa": k, "ly_do": "Hóa đơn / nhóm có hơn 2 thuế suất, không tách được chứng từ - nhập riêng", "dong": theo_hd[k]})
            if not con:
                continue
        for g, tv, so_dd, nha in lap:
            ct.append(_th_lap_ct(gk, g, tv, so_dd, theo_hd, len(lap) == 1, da_dung, lay_tep_excel, nha))
    return {"ct": ct, "rieng": rieng, "theo_hd": theo_hd}


def _th_tong_dong_hd(ds):
    """Tong theo DONG cua 1 HD: (chua thue, thue) = hang - chiet khau (dong tinh chat 3 luon la giam)."""
    ct = th = 0.0
    for d in ds:
        a, b = _so_an_toan(d.get("ThanhTienChuaThue")), _so_an_toan(d.get("TienThue"))
        if str(d.get("tchat") or "1") == "3":
            ct -= abs(a)
            th -= abs(b)
        else:
            ct += a
            th += b
    return ct, th


def _th_lap_ct(gk, cac_dong, tv, so_dd, theo_hd, nguyen_hd, da_dung, tep_excel, nha=()):
    """Mot chung tu tong hop -> dict + cac dong JSONL (giong dong tu XML, them so_ct / tong_hop)."""
    mst, mau, kh, tu, den = gk
    d0 = theo_hd[tv[0]][0]
    ngay_ct = max(th_ngay(theo_hd[k][0].get("NgayLap")) for k in tv)
    so_ct = th_so_ct(ngay_ct, da_dung)
    so = [str(theo_hd[k][0].get("SoHoaDon") or "") for k in tv]
    so_tu, so_den = so[0], so[-1]
    gop = th_cong_dong(cac_dong)
    # dong chiet khau (tinh chat 3) GIAM tien: tong dong = hang - CK (so am / duong tren XML deu tinh la giam)
    ck_tien = round(sum(abs(x["ThanhTienChuaThue"]) for x in gop if x["tchat"] == "3"), 2)
    ck_thue = round(sum(abs(x["TienThue"]) for x in gop if x["tchat"] == "3"), 2)
    tong_ct = round(sum(x["ThanhTienChuaThue"] for x in gop if x["tchat"] != "3") - ck_tien, 2)
    tong_th = round(sum(x["TienThue"] for x in gop if x["tchat"] != "3") - ck_thue, 2)
    if nguyen_hd:           # ca hoa don nam tron trong chung tu nay: tong theo dau hoa don (giong nhap tung to)
        dau = [theo_hd[k][0] for k in tv]
        tong_ct_hd = round(sum(_so_an_toan(x.get("tong_chua_thue")) for x in dau), 2)
        tong_th_hd = round(sum(_so_an_toan(x.get("tong_thue")) for x in dau), 2)
        tong_tt = round(sum(_so_an_toan(x.get("TongTienThanhToan")) for x in dau), 2)
        tong_ck = round(sum(_so_an_toan(x.get("TongTienChietKhauThuongMai")) for x in dau), 2)
    else:
        # tach thue suat (HD nam o nhieu chung tu): tong theo dong cua goi (hang - CK) + phan lech giua dau HD va dong cua
        # cac HD 'o nha' goi nay -> tong cac chung tu = tong dau cac HD; phan mem phan bo CK cua tung chung tu dung nhu khi
        # nhap tung to (truoc day cong CK nhu hang: tong thanh toan thua 2 lan CK, CK khong duoc phan bo)
        l_ct = l_th = l_tt = 0.0
        for k in nha or ():
            h = theo_hd[k][0]
            a, b = _th_tong_dong_hd(theo_hd[k])
            if _so_an_toan(h.get("TongTienThanhToan")):
                l_tt += _so_an_toan(h.get("TongTienThanhToan")) - (a + b)
            if h.get("tong_chua_thue") not in (None, ""):
                l_ct += _so_an_toan(h.get("tong_chua_thue")) - a
            if h.get("tong_thue") not in (None, ""):
                l_th += _so_an_toan(h.get("tong_thue")) - b
        tong_ct_hd, tong_th_hd = round(tong_ct + l_ct, 2), round(tong_th + l_th, 2)
        tong_tt, tong_ck = round(tong_ct + tong_th + l_tt, 2), ck_tien
    httt, tien_tm, tien_khac = {}, 0.0, 0.0
    for k in tv:
        h = str(theo_hd[k][0].get("httt") or "")
        httt[h] = httt.get(h, 0) + 1
        if h.strip().upper() in ("TM", "TIỀN MẶT", "TIEN MAT"):
            tien_tm += _so_an_toan(theo_hd[k][0].get("TongTienThanhToan"))
        else:
            tien_khac += _so_an_toan(theo_hd[k][0].get("TongTienThanhToan"))
    khoa = unesco_khoa(d0.get("MSTNguoiBanNguoiXuatHang"), mau, kh, "BL" + unesco_so_hd(so_dd))
    ky = ("ngày %s" % den.strftime("%d/%m/%Y")) if tu == den else ("%s - %s" % (tu.strftime("%d/%m"), den.strftime("%d/%m/%Y")))
    mo_ta = "Tổng hợp %d HĐ bán lẻ số %s, %s (số CT %s)" % (len(tv), so_tu if so_tu == so_den else so_tu + "-" + so_den, ky, so_ct)
    ts_ds = sorted({str(x.get("ThueSuat") or "") for x in gop})
    chung = {
        "KyHieuMauSo": mau, "KyHieuHoaDon": kh, "SoHoaDon": unesco_so_hd(so_dd),
        "NgayLap": ngay_ct.strftime("%Y-%m-%d"), "NgayNguoiBanKySo": "", "MCCQT": "", "NgayCQTKySo": "",
        "DonViTienTe": "VND", "TyGia": 1,
        "TenNguoiBanNguoiXuatHang": d0.get("TenNguoiBanNguoiXuatHang", ""), "MSTNguoiBanNguoiXuatHang": d0.get("MSTNguoiBanNguoiXuatHang", ""),
        "DiaChiNguoiBan": d0.get("DiaChiNguoiBan", ""),
        "TenNguoiMuaNguoiNhanHang": TH_TEN_KH, "MSTNguoiMuaNguoiNhanHang": "", "DiaChiNguoiMua": "",
        "TongTienChietKhauThuongMai": tong_ck, "TongTienPhi": 0, "TongTienThanhToan": tong_tt,
        "TrangThaiHoaDon": "Hóa đơn mới", "KetQuaKiemTraHoaDon": mo_ta[:255],
        "XML": True, "HDBanRa": True, "MaSoLoaiCT": "8", "MSTLogin": d0.get("MSTLogin", ""),
        "khoa": khoa, "huong": "ban", "tep_xml": tep_excel, "tthai": "1", "ttxly": "",
        "mtt": any(theo_hd[k][0].get("mtt") for k in tv), "loai_hd": d0.get("loai_hd", ""),
        "httt": max(httt, key=httt.get) if httt else "", "lien_quan": None,
        "tong_chua_thue": tong_ct_hd, "tong_thue": tong_th_hd,
        "so_ct": so_ct, "tong_hop": True, "so_hd_gop": len(tv), "so_hd_tu": so_tu, "so_hd_den": so_den,
        "ky_tu": tu.strftime("%Y-%m-%d"), "ky_den": den.strftime("%Y-%m-%d"),
    }
    dong = []
    for i, g in enumerate(gop):
        d = dict(chung)
        d.update({"stt_dong": i + 1, "so_dong": len(gop), "tchat": g["tchat"], "MaVT": g["MaVT"],
                  "TenHangHoaDichVu": g["TenHangHoaDichVu"], "DonViTinh": g["DonViTinh"], "SoLuong": g["SoLuong"],
                  "DonGia": g["DonGia"], "ChietKhau": g["ChietKhau"], "ThueSuat": g["ThueSuat"],
                  "ThanhTienChuaThue": g["ThanhTienChuaThue"], "TienThue": g["TienThue"], "giam2": g["giam2"]})
        dong.append(d)
    return {"khoa": khoa, "so_ct": so_ct, "so_hd": unesco_so_hd(so_dd), "ngay": ngay_ct, "tu": tu, "den": den,
            "mau": mau, "kh": kh, "hd": list(tv), "so_tu": so_tu, "so_den": so_den, "dong": dong, "gop": gop,
            "tong_chua_thue": tong_ct_hd, "tong_thue": tong_th_hd, "tong_tt": tong_tt,
            "tong_dong_ct": tong_ct, "tong_dong_thue": tong_th, "thue_suat": ", ".join(t for t in ts_ds if t) or "(không ghi)",
            "mo_ta": mo_ta, "nguyen_hd": nguyen_hd, "tien_tm": round(tien_tm, 2), "tien_khac": round(tien_khac, 2)}


# ---------------- so dang ky + chong trung ----------------
#  Nguon su that la PHAN MEM: trang-thai-hd.txt (HD + chung tu tong hop + HD thanh vien dang co trong so, ghi luc mo
#  tool), da-doc-ket-qua.txt (tep ket-qua phan mem da doc; tep hddt_*.jsonl con lai = DANG CHO NHAP -> coi nhu da co).
#  So dang ky tong-hop-ban-le.json + TH_DA_GUI giu phan tool biet them (tong hop trong phien, chua kip vao so).
#  Lop chan cuoi cung nam o VB6 (bang HDDT_TongHopTV): trung thi CHAN, khong nhap.
def th_nho_gui(khoa_ds, tep):
    """GD116: ghi nho cac khoa vua ghi JSONL cho phan mem trong phien nay, kem ten tep ket-qua chua chung."""
    ten = os.path.basename(str(tep or ""))
    luc = time.time()
    for k in khoa_ds:
        if k:
            TH_DA_GUI.add(k)
            if ten:
                TH_DA_GUI_TEP[k] = (ten, luc)


def _th_don_da_gui(goc):
    """GD116: khoa da gui trong phien ma phan mem DA DOC tep chua no (da-doc-ket-qua.txt) va danh sach HD phan mem ghi SAU
    lan gui (trang-thai-hd.txt - phan mem ghi lai ngay sau khi Huy / Xoa khoi danh sach AI) KHONG con khoa do -> nguoi dung da
    xoa trong phan mem: bo khoi TH_DA_GUI. Truoc day tool van coi la 'da gui trong lan lam viec nay' / chung tu tong hop con
    song -> Tong hop HD ban le bo qua het (chi gop duoc HD moi) cho toi khi dong tool mo lai. Tra ve so khoa da bo."""
    if not TH_DA_GUI_TEP:
        return 0
    try:
        thu = _thu_muc_du_lieu()
        moc = min(os.path.getmtime(os.path.join(thu, "trang-thai-hd.txt")),
                  os.path.getmtime(os.path.join(thu, "da-doc-ket-qua.txt")))
    except Exception:
        return 0
    da_doc = th_doc_da_doc()
    if not da_doc:
        return 0
    bo = [k for k, (ten, luc) in list(TH_DA_GUI_TEP.items()) if ten in da_doc and moc > luc + 1 and k not in goc]
    for k in bo:
        TH_DA_GUI.discard(k)
        TH_DA_GUI_TEP.pop(k, None)
    if bo:
        ct = sum(1 for k in bo if th_la_khoa_ct(k))
        LOG.ghi("[TONG HOP] Phan mem da XOA %d khoa da gui trong phien nay (%d chung tu tong hop BKBL, %d hoa don) - coi nhu "
                "CHUA CO, tong hop / tai lai duoc" % (len(bo), ct, len(bo) - ct))
    return len(bo)


def th_la_khoa_ct(k):
    """Khoa chung tu tong hop: '<MST>|<mau so>|<ky hieu>|BL<so HD nho nhat>'."""
    p = str(k or "").split("|")
    return len(p) == 4 and bool(re.match(r"^BL\d+$", p[3]))


def th_doc_so():
    so = _doc_json(TH_TEP_SO, {})
    if not isinstance(so, dict):
        so = {}
    so.setdefault("ct", {})
    so.setdefault("tv", {})
    return so


def th_doc_da_doc():
    """da-doc-ket-qua.txt (phan mem GD91+ ghi luc mo tool): ten cac tep ket-qua DA DOC. None = khong co (phan mem cu)."""
    d = os.path.join(_thu_muc_du_lieu(), "da-doc-ket-qua.txt")
    if not os.path.exists(d):
        return None
    try:
        with open(d, "r", encoding="utf-8-sig") as f:
            return {x.strip() for x in f if x.strip()}
    except Exception as e:
        LOG.loi("Khong doc duoc da-doc-ket-qua.txt", e)
        return None


def th_cho_nhap(da_doc):
    """Tep hddt_*.jsonl trong ket-qua ma phan mem CHUA doc -> (tap khoa HD / chung tu, {HD le: {chung tu tong hop}},
    {chung tu tong hop: '<nam>|<so CT>'}). da_doc None -> rong."""
    khoa, tv, so_ct = set(), {}, {}
    if da_doc is None:
        return khoa, tv, so_ct
    kq = os.path.join(_thu_muc_du_lieu(), "ket-qua")
    try:
        ten_ds = os.listdir(kq)
    except Exception:
        return khoa, tv, so_ct
    for ten in ten_ds:
        if not (ten.lower().startswith("hddt_") and ten.lower().endswith(".jsonl")) or ten in da_doc:
            continue
        try:
            with open(os.path.join(kq, ten), "r", encoding="utf-8") as f:
                for dong in f:
                    if '"khoa"' not in dong:
                        continue
                    j = json.loads(dong)
                    k = j.get("khoa") or ""
                    if j.get("tv_th"):
                        tv.setdefault(j["tv_th"], set()).add(k)
                    elif not j.get("chi_kiem_tra"):
                        khoa.add(k)
                        if j.get("so_ct"):
                            so_ct[k] = "%s|%s" % (str(j.get("NgayLap") or "")[:4], j["so_ct"])
        except Exception as e:
            LOG.loi("Khong doc duoc tep cho nhap " + ten, e)
    return khoa, tv, so_ct


def th_ngu_canh():
    """Anh chup de chong trung: tt (khoa -> True da hach toan / False da co hoac dang cho nhap), tv (HD le -> tap chung
    tu tong hop), song (chung tu tong hop con / co the con trong phan mem), so, so_ct (nam|so CT dang dung)."""
    goc = _doc_trang_thai_ma()      # GD94: HD dang co trong phan mem (anh chup luc mo tool): ma 1 / 0 / 2 (khoa)
    tt = {k: v == "1" for k, v in goc.items()}
    da_doc = th_doc_da_doc()
    cho, tv_cho, so_ct_cho = th_cho_nhap(da_doc)
    for k in cho:
        tt.setdefault(k, False)
    so = th_doc_so()
    tv = {}
    for k, v in so["tv"].items():
        tv[k] = {x for x in str(v).split(";") if x}
    for k, v in tv_cho.items():
        tv.setdefault(k, set()).update(v)
    ung = set(so["ct"]) | {p for v in tv.values() for p in v} | set(TH_DA_GUI)
    song = {pk for pk in ung if th_la_khoa_ct(pk) and (pk in tt or pk in TH_DA_GUI)}
    so_ct = {"%s|%s" % (str(v.get("ngay") or "")[:4], v.get("so_ct") or "") for pk, v in so["ct"].items() if pk in song}
    so_ct |= set(so_ct_cho.values())
    return {"tt": tt, "tv": tv, "song": song, "so": so, "so_ct": so_ct, "co_da_doc": da_doc is not None, "goc": goc, "cho": cho}


def th_tv_bi_khoa(k, nc):
    """HD k dang nam trong chung tu tong hop con song -> khoa chung tu do; khong -> ''."""
    for pk in sorted(nc["tv"].get(k, ())):
        if pk in nc["song"]:
            return pk
    return ""


def th_loc_thanh_vien(cac_dong, nhan):
    """Bo cac dong cua HD da nam trong chung tu tong hop con song (khong gui rieng lan nua -> khong nhan doi)."""
    if not cac_dong:
        return cac_dong
    nc = th_ngu_canh()
    if not nc["tv"]:
        return cac_dong
    giu, bo = [], set()
    for d in cac_dong:
        k = d.get("khoa") or ""
        if k in bo or (k in nc["tv"] and th_tv_bi_khoa(k, nc)):
            bo.add(k)
            continue
        giu.append(d)
    if bo:
        LOG.ghi("[TONG HOP] %s: bo %d hoa don da nam trong chung tu tong hop ban le (khong gui rieng lan nua)" % (nhan, len(bo)))
    return giu


def th_canh_bao_tv(rows):
    """HD da tong hop (chung tu tong hop con song) nay tren cong la bi thay the / bi dieu chinh / bi huy -> canh bao."""
    try:
        nc = th_ngu_canh()
        if not nc["tv"]:
            return ""
        xau = []
        for hd in rows or []:
            if str(hd.get("tthai") or "") in ("4", "5", "6"):
                pk = th_tv_bi_khoa(khoa_cua(hd), nc)
                if pk:
                    xau.append("%s (%s, trong %s)" % (hd.get("shdon"), TEN_TTHAI.get(str(hd.get("tthai")), ""),
                                                      (nc["so"]["ct"].get(pk) or {}).get("so_ct") or pk))
        if not xau:
            return ""
        return ("%d hóa đơn đã nằm trong chứng từ tổng hợp bán lẻ nay bị thay thế / điều chỉnh / hủy trên cổng thuế: %s — "
                "sửa chứng từ tổng hợp tương ứng bằng tay." % (len(xau), ", ".join(xau[:20]) + (" ..." if len(xau) > 20 else "")))
    except Exception as e:
        LOG.loi("Loi khi kiem HD da tong hop bi huy / thay the", e)
        return ""


def th_quy_tac():
    """quy-tac-tool.json do phan mem ghi (CK_XuLy, KM_XuLy). Khong co -> coi CK la lap tay (than trong)."""
    q = _doc_json("quy-tac-tool.json", {})
    return q if isinstance(q, dict) else {}


TH_KHOA_HET = 10 * 60      # GD94: tep khoa khong duoc cham lai qua 10 phut -> cua so giu khoa da tat / treo


def _pid_con_song(pid):
    """GD94: tien trinh pid con chay (va la tool - so PID Windows co the dung lai)? True / False / None (khong biet)."""
    try:
        pid = int(str(pid).strip())
    except Exception:
        return None
    if pid <= 0:
        return False
    if os.name == "nt":
        try:
            import ctypes
            from ctypes import wintypes
            k32 = ctypes.WinDLL("kernel32", use_last_error=True)
            k32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
            k32.OpenProcess.restype = wintypes.HANDLE
            k32.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
            k32.CloseHandle.argtypes = [wintypes.HANDLE]
            k32.QueryFullProcessImageNameW.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
            h = k32.OpenProcess(0x1000, False, pid)             # PROCESS_QUERY_LIMITED_INFORMATION
            if not h:
                return ctypes.get_last_error() == 5             # 5 = khong du quyen (van dang chay); 87 = khong co tien trinh
            try:
                ma = wintypes.DWORD(0)
                if not k32.GetExitCodeProcess(h, ctypes.byref(ma)):
                    return None
                if ma.value != 259:                             # STILL_ACTIVE
                    return False
                buf = ctypes.create_unicode_buffer(1024)
                n = wintypes.DWORD(1024)
                if k32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(n)):
                    ten = os.path.basename(buf.value).lower()
                    return "python" in ten or ten == os.path.basename(sys.executable).lower()
                return True
            finally:
                k32.CloseHandle(h)
        except Exception:
            return None
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except Exception:
        return None


def _may_nay():
    """Ten may (chu so + chu, khong dau cach) - khoa tong hop tren thu muc mang dung chung nhieu may."""
    try:
        return re.sub(r"[^A-Za-z0-9._-]", "", socket.gethostname())[:60] or "may"
    except Exception:
        return "may"


def _doc_khoa(d):
    """-> (pid, may) ghi trong tep khoa ('pid ngay gio may'); tep cu (truoc GD94) khong co ten may -> may = ''."""
    try:
        with open(d, "r", encoding="ascii", errors="replace") as f:
            x = f.read().split()
    except Exception:
        return None, ""
    return (x[0] if x else None), (x[3] if len(x) > 3 else "")


def th_khoa_phien(mo):
    """Chi 1 lan tong hop moi luc cho 1 bo so (2 cua so tool). mo=True: lay khoa (False neu dang co nguoi giu).
    GD94: khoa bo quen (tool bi tat ngang giua luc tong hop - may anh Thang 27/09) truoc day chan nut Tong hop toi 6 gio.
    Nay: khoa cua CUNG MAY ma tien trinh ghi khoa da tat (kiem PID) / khoa cua chinh cua so nay, hoac khoa khong duoc cham
    lai qua 10 phut (cua so dang tong hop cham khoa moi 30 giay) -> bo khoa cu, tong hop duoc ngay. Khoa cua may khac (thu
    muc du lieu dung chung qua mang) chi xet theo nhip. Tra khoa (mo=False): chi xoa khoa cua chinh cua so nay."""
    d = os.path.join(_thu_muc_du_lieu(), "dang-tong-hop.lock")
    if not mo:
        try:
            pid, may = _doc_khoa(d)
            if str(pid or "").strip() == str(os.getpid()) and may in ("", _may_nay()):
                os.remove(d)
        except Exception:
            pass
        return True
    try:
        if os.path.exists(d):
            pid, may = _doc_khoa(d)
            tuoi = time.time() - os.path.getmtime(d)
            cung_may = may in ("", _may_nay())
            if pid is None or not cung_may:
                song = None
            elif str(pid).strip() == str(os.getpid()):
                song = False            # khoa cua chinh cua so nay (lan truoc loi giua chung) - 1 cua so chi 1 lan tong hop
            else:
                song = _pid_con_song(pid)
            if song is False or tuoi > (TH_KHOA_HET if cung_may else 3 * TH_KHOA_HET):     # may khac: dong ho co the lech
                LOG.ghi("[TONG HOP] Bo khoa tong hop cu (PID %s may %s %s, %d phut chua cham lai) - cua so giu khoa da tat / treo."
                        % (pid, may or "?", "da tat" if song is False else "?", int(tuoi // 60)))
                os.remove(d)
        fd = os.open(d, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.write(fd, ("%d %s %s" % (os.getpid(), datetime.now().strftime("%Y-%m-%d %H:%M:%S"), _may_nay())).encode("ascii"))
        os.close(fd)
        return True
    except FileExistsError:
        return False
    except Exception as e:
        LOG.loi("Khong tao duoc khoa tong hop", e)
        return True


def _th_nhip_khoa(dung_ev):
    """GD94: dang tong hop -> cham gio tep khoa moi 30 giay (cua so khac biet khoa con song, ke ca khi 1 HD tai rat lau)."""
    d = os.path.join(_thu_muc_du_lieu(), "dang-tong-hop.lock")
    while not dung_ev.wait(30):
        try:
            os.utime(d, None)
        except Exception:
            pass


def th_ghi_so(kq, tep_excel, so_ngay, pham_vi, lan=""):
    so = th_doc_so()
    luc = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    moi = {c["khoa"] for c in kq["ct"]}
    for k in list(so["tv"]):
        # khoa chung tu tong hop dung lai (lan truoc bi chan / bi xoa, khong con trong so): HD cua lan truoc khong con
        # thuoc khoa nay nua - khong thi HD khong nam trong lan moi bi khoa vinh vien
        con = [x for x in str(so["tv"][k] or "").split(";") if x and x not in moi]
        if con:
            so["tv"][k] = ";".join(con)
        else:
            del so["tv"][k]
    for c in kq["ct"]:
        so["ct"][c["khoa"]] = {"so_ct": c["so_ct"], "so_hd": c["so_hd"], "ngay": c["ngay"].strftime("%Y-%m-%d"),
                               "tu": c["tu"].strftime("%Y-%m-%d"), "den": c["den"].strftime("%Y-%m-%d"),
                               "so_hd_gop": len(c["hd"]), "tong_tt": c["tong_tt"], "excel": tep_excel,
                               "cach": so_ngay, "pham_vi": pham_vi, "luc": luc, "lan": lan}
        for k in c["hd"]:
            cu = [x for x in str(so["tv"].get(k) or "").split(";") if x and x != c["khoa"] and x in so["ct"]]
            so["tv"][k] = ";".join(cu + [c["khoa"]])
    return _ghi_json(TH_TEP_SO, so)


def so_tai_ghi_nhieu(ds, direction, thu_muc, khong_xml=()):
    """Nhu so_tai_ghi cho CA danh sach - doc / ghi da-tai.json MOT lan (16.000 HD: tranh doc ghi 16.000 lan)."""
    try:
        so = _doc_json("da-tai.json", {})
        luc = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        kx = set(khong_xml)
        for hd in ds:
            k = khoa_cua(hd)
            so[k] = {"xml": "" if k in kx else (tim_xml_co_san(hd, direction, thu_muc, so) or
                                                os.path.join(thu_muc_theo_ky(thu_muc, hd), ten_file(hd, direction) + ".xml")), "luc": luc,
                     "mdb": _bo_so_hien()}
            if k in kx:
                so[k]["khong_xml"] = True
        _ghi_json("da-tai.json", so)
    except Exception as e:
        LOG.loi("Khong ghi duoc so da tai", e)


# ---------------- file Excel chi tiet ----------------
def _th_ngay_vn(x):
    if hasattr(x, "strftime"):
        return x.strftime("%d/%m/%Y")
    s = str(x or "")[:10]
    return ("%s/%s/%s" % (s[8:10], s[5:7], s[0:4])) if len(s) == 10 and s[4] == "-" else s


TH_COT_CHI_TIET = ["Ký hiệu mẫu số", "Ký hiệu hóa đơn", "Số hóa đơn", "Ngày lập", "Ngày người bán ký số", "Tên hàng hóa, dịch vụ",
                   "Đơn vị tính", "Số lượng", "Đơn giá", "Chiết khấu", "Thuế suất", "Thành tiền chưa thuế", "Tiền thuế",
                   "Tổng tiền chiết khấu thương mại", "Tổng tiền phí", "Tổng tiền thanh toán"]


def th_bang_chi_tiet(ct, ct_cua, theo_hd, so_ngay):
    """GD92: bang chi tiet cac HD da gop (16 cot TH_COT_CHI_TIET) theo ky gop: dong hang tung HD, roi DongTong 'Tong ngay'
    (1 ngay) / 'Tong tuan' (1 tuan) / 'Tong <tu> - <den>' sau moi ky, 'Tong thang mm/yyyy' cuoi thang, 'TONG CONG'.
    Dong chiet khau (tinh chat 3) ghi am; tong tien CKTM / phi / thanh toan chi ghi o dong dau moi HD (cong cot khong trung)."""
    nhom = {}
    for c in ct:
        g = nhom.setdefault((c["tu"], c["den"]), {"hd": [], "ct": []})
        g["ct"].append(c["so_ct"])
        for k in c["hd"]:
            if ct_cua.get(k, [None])[0] == c["so_ct"] and k not in g["hd"]:
                g["hd"].append(k)

    def moi_tong():
        return {"ck": 0.0, "tien": 0.0, "thue": 0.0, "cktm": 0.0, "phi": 0.0, "tt": 0.0, "hd": 0}

    def dong_tong(nhan, t, muc):
        return DongTong(["", "", "", "", "", "%s (%d HĐ)" % (nhan, t["hd"]), "", "", "", round(t["ck"], 2), "",
                         round(t["tien"], 2), round(t["thue"], 2), round(t["cktm"], 2), round(t["phi"], 2), round(t["tt"], 2)], muc)

    def cong(dich, t):
        for x in dich:
            dich[x] += t[x]
    kq, thang, t_thang, t_all = [], None, moi_tong(), moi_tong()
    for (tu, den) in sorted(nhom):
        g = nhom[(tu, den)]
        th = tu.strftime("%m/%Y")
        if thang is not None and th != thang:
            kq.append(dong_tong("Tổng tháng " + thang, t_thang, 2))
            t_thang = moi_tong()
        thang = th
        t_ky = moi_tong()
        ds = sorted(g["hd"], key=lambda k: (str(theo_hd[k][0].get("NgayLap") or "")[:10], str(theo_hd[k][0].get("KyHieuMauSo") or ""),
                                            str(theo_hd[k][0].get("KyHieuHoaDon") or ""), _th_so_sx(theo_hd[k][0].get("SoHoaDon"))))
        for k in ds:
            dau = True
            for d in theo_hd[k]:
                am = -1 if str(d.get("tchat") or "1") == "3" else 1
                tien = am * abs(_so_an_toan(d.get("ThanhTienChuaThue"))) if am < 0 else _so_an_toan(d.get("ThanhTienChuaThue"))
                thue = am * abs(_so_an_toan(d.get("TienThue"))) if am < 0 else _so_an_toan(d.get("TienThue"))
                ck = _so_an_toan(d.get("ChietKhau"))
                h = [_so_an_toan(d.get("TongTienChietKhauThuongMai")), _so_an_toan(d.get("TongTienPhi")),
                     _so_an_toan(d.get("TongTienThanhToan"))] if dau else ["", "", ""]
                kq.append([d.get("KyHieuMauSo", ""), d.get("KyHieuHoaDon", ""), d.get("SoHoaDon", ""), _th_ngay_vn(d.get("NgayLap")),
                           _th_ngay_vn(str(d.get("NgayNguoiBanKySo") or "")[:10]), d.get("TenHangHoaDichVu", ""), d.get("DonViTinh", ""),
                           _so_an_toan(d.get("SoLuong")), _so_an_toan(d.get("DonGia")), ck, d.get("ThueSuat", ""), tien, thue] + h)
                t_ky["ck"] += ck
                t_ky["tien"] += tien
                t_ky["thue"] += thue
                if dau:
                    t_ky["cktm"] += h[0]
                    t_ky["phi"] += h[1]
                    t_ky["tt"] += h[2]
                    t_ky["hd"] += 1
                dau = False
        if tu == den:
            nhan = "Tổng ngày " + _th_ngay_vn(tu)
        elif so_ngay == 7:
            nhan = "Tổng tuần %s - %s" % (tu.strftime("%d/%m"), _th_ngay_vn(den))
        else:
            nhan = "Tổng %s - %s" % (tu.strftime("%d/%m"), _th_ngay_vn(den))
        kq.append(dong_tong(nhan + " - chứng từ " + ", ".join(g["ct"]), t_ky, 1))
        cong(t_thang, t_ky)
        cong(t_all, t_ky)
    if thang is not None:
        kq.append(dong_tong("Tổng tháng " + thang, t_thang, 2))
        kq.append(dong_tong("TỔNG CỘNG", t_all, 2))
    return kq


def th_xuat_excel(kq, bo_qua, thu_muc, so_ngay, pham_vi, so_chon, duong=None):
    """File Excel chi tiet cua lan tong hop. bo_qua: [(hd cong thue, ly do)]. Tra ve duong dan (None neu loi).
    GD94: duong = file cua lan tong hop nay (ghi lai sau moi dot chuyen sang phan mem); ghi khong duoc (dang mo trong
    Excel) -> ghi sang ten moi."""
    ct, rieng, theo_hd = kq["ct"], kq["rieng"], kq["theo_hd"]
    ct_cua = {}
    for c in ct:
        for k in c["hd"]:
            ct_cua.setdefault(k, []).append(c["so_ct"])
    # 1. Tom tat
    tong_ct_tt = sum(c["tong_tt"] for c in ct)
    tong_hd_gop = sum(_so_an_toan(theo_hd[k][0].get("TongTienThanhToan")) for k in ct_cua)
    tong_dong = round(sum(c["tong_dong_ct"] + c["tong_dong_thue"] for c in ct), 2)
    ten_cty = ""
    for ds in theo_hd.values():
        ten_cty = "%s - MST %s" % (ds[0].get("TenNguoiBanNguoiXuatHang", ""), ds[0].get("MSTNguoiBanNguoiXuatHang", ""))
        break
    ngay_all = [th_ngay(ds[0].get("NgayLap")) for ds in theo_hd.values() if th_ngay(ds[0].get("NgayLap"))]
    ky = ("%s - %s" % (_th_ngay_vn(min(ngay_all)), _th_ngay_vn(max(ngay_all)))) if ngay_all else ""
    lech = round(tong_dong - tong_hd_gop, 2)
    tom = [["Đơn vị bán", ten_cty], ["Kỳ hóa đơn", ky],
           ["Gộp", th_ten_cach_gop(so_ngay) + " thành 1 chứng từ (không gộp qua cuối tháng; tách theo mẫu số, ký hiệu)"],
           ["Phạm vi", "Chỉ hóa đơn người mua KHÔNG có MST" if pham_vi != "tat_ca" else "Toàn bộ hóa đơn (người mua có MST và không MST)"],
           ["Số hóa đơn đã chọn", so_chon],
           ["Số hóa đơn gộp vào chứng từ tổng hợp", len(ct_cua)],
           ["Số chứng từ tổng hợp", len(ct)],
           ["Số hóa đơn nhập riêng từng tờ", len(rieng)],
           ["Số hóa đơn bỏ qua (đã có / đã gửi / đã tổng hợp / tải lỗi)", len(bo_qua)],
           ["Tổng thanh toán theo đầu các hóa đơn đã gộp", round(tong_hd_gop, 2)],
           ["Tổng dòng hàng + thuế của các chứng từ tổng hợp (vào sổ)", tong_dong],
           ["Đối chiếu", "KHỚP" if abs(lech) < 1 else ("LỆCH %s (chiết khấu / làm tròn trên hóa đơn gốc - phần mềm xử lý như "
                                                     "khi nhập từng tờ; xem cột Chênh lệch sheet Chứng từ tổng hợp)" % lech)],
           ["Tiền mặt (TM) / khác (chuyển khoản, thẻ...)", "%s / %s - chứng từ ghi theo hình thức thanh toán của đa số hóa đơn trong nhóm"
            % (round(sum(c["tien_tm"] for c in ct), 2), round(sum(c["tien_khac"] for c in ct), 2))],
           ["Số chứng từ", "BKBL<tháng>.<ngày> = ngày chứng từ (ngày cuối trong nhóm có hóa đơn); trùng ngày thêm B, C..."],
           ["Số HĐ trên bảng kê thuế", "Số hóa đơn nhỏ nhất trong nhóm"],
           ["Khách hàng", TH_TEN_KH + " (mã khách lẻ chung của phần mềm)"],
           ["Sheet Chi tiết hóa đơn tổng hợp", "Từng dòng hàng của từng hóa đơn đã gộp; dòng chiết khấu thương mại ghi số âm; Tổng tiền "
            "chiết khấu thương mại / phí / thanh toán ghi ở dòng đầu mỗi hóa đơn; dòng Tổng %s sau mỗi kỳ gộp, Tổng tháng, TỔNG CỘNG"
            % ("ngày" if so_ngay == 1 else ("tuần" if so_ngay == 7 else "kỳ %d ngày" % so_ngay))]]
    # 2. Chung tu tong hop
    s_ct = []
    for i, c in enumerate(ct, 1):
        dong_so = round(c["tong_dong_ct"] + c["tong_dong_thue"], 2)
        s_ct.append([i, c["so_ct"], _th_ngay_vn(c["ngay"]), _th_ngay_vn(c["tu"]), _th_ngay_vn(c["den"]), c["mau"], c["kh"],
                     c["so_hd"], c["so_tu"], c["so_den"], len(c["hd"]), len(c["gop"]), c["thue_suat"],
                     c["tong_chua_thue"], c["tong_thue"], c["tong_tt"], dong_so, round(dong_so - c["tong_tt"], 2),
                     c["tien_tm"], c["tien_khac"],
                     "" if c["nguyen_hd"] else "Tách theo thuế suất (nhóm có hơn 2 thuế suất)"])
    s_ct.append(["", "TỔNG CỘNG", "", "", "", "", "", "", "", "", sum(len(c["hd"]) for c in ct), sum(len(c["gop"]) for c in ct), "",
                 round(sum(c["tong_chua_thue"] for c in ct), 2), round(sum(c["tong_thue"] for c in ct), 2), round(tong_ct_tt, 2),
                 tong_dong, round(tong_dong - tong_ct_tt, 2), round(sum(c["tien_tm"] for c in ct), 2),
                 round(sum(c["tien_khac"] for c in ct), 2), ""])
    # 3. Hang theo chung tu
    s_hang = []
    for c in ct:
        for j, g in enumerate(c["gop"], 1):
            s_hang.append([c["so_ct"], _th_ngay_vn(c["ngay"]), c["kh"], j, TH_TEN_TCHAT.get(g["tchat"], g["tchat"]), g["MaVT"],
                           g["TenHangHoaDichVu"], g["DonViTinh"], g["SoLuong"], g["DonGia"], g["ThanhTienChuaThue"],
                           g["ChietKhau"], g["ThueSuat"], g["TienThue"], g["so_hd_co"]])
    # GD92: chi tiet hoa don tong hop - 16 cot theo mau HDDT, dong Tong ngay / tuan sau moi ky gop, Tong thang, TONG CONG
    s_cthd = th_bang_chi_tiet(ct, ct_cua, theo_hd, so_ngay)
    # 4. Bang ke tung hoa don
    s_hd, stt = [], 0
    for c in ct:
        for k in c["hd"]:
            if ct_cua.get(k, [None])[0] != c["so_ct"]:
                continue            # HD nam trong 2 goi thue suat: ghi 1 lan
            ds = theo_hd[k]
            d0 = ds[0]
            stt += 1
            s_hd.append([stt, "; ".join(ct_cua[k]), d0.get("KyHieuMauSo", ""), d0.get("KyHieuHoaDon", ""), d0.get("SoHoaDon", ""),
                         _th_ngay_vn(d0.get("NgayLap")), d0.get("MSTNguoiMuaNguoiNhanHang", ""), d0.get("TenNguoiMuaNguoiNhanHang", ""),
                         _so_an_toan(d0.get("tong_chua_thue")), _so_an_toan(d0.get("tong_thue")), _so_an_toan(d0.get("TongTienThanhToan")),
                         d0.get("TrangThaiHoaDon", ""), d0.get("MCCQT", ""), len(ds),
                         "" if d0.get("XML") else "Không có XML gốc - dùng dữ liệu cổng thuế", os.path.basename(str(d0.get("tep_xml") or ""))])
    # 6. Nhap rieng / bo qua
    s_rieng = []
    for r in rieng:
        d0 = r["dong"][0]
        s_rieng.append([d0.get("KyHieuMauSo", ""), d0.get("KyHieuHoaDon", ""), d0.get("SoHoaDon", ""), _th_ngay_vn(d0.get("NgayLap")),
                        d0.get("MSTNguoiMuaNguoiNhanHang", ""), d0.get("TenNguoiMuaNguoiNhanHang", ""),
                        _so_an_toan(d0.get("TongTienThanhToan")), "Nhập riêng từng tờ", r["ly_do"]])
    for hd, ly_do in bo_qua:
        s_rieng.append([str(hd.get("khmshdon") or ""), hd.get("khhdon") or "", unesco_so_hd(hd.get("shdon")), _th_ngay_vn(ngay_vn(hd.get("tdlap"))),
                        hd.get("nmmst") or "", _ten_nguoi_mua(hd.get("nmten"), hd.get("nmtnmua") or hd.get("nmtnhang") or hd.get("nmhvtnmhang")),
                        _so_an_toan(hd.get("tgtttbso")), "Bỏ qua", ly_do])
    tu_all = min(ngay_all).strftime("%Y%m%d") if ngay_all else "x"
    den_all = max(ngay_all).strftime("%Y%m%d") if ngay_all else "x"
    if duong:
        ten = os.path.basename(duong)
    else:
        ten = "TONG_HOP_BAN_LE_%s_%s_%s.xlsx" % (tu_all, den_all, datetime.now().strftime("%Y%m%d-%H%M%S"))
        duong = os.path.join(thu_muc, ten)
        lan = 2
        while os.path.exists(duong):
            ten = "TONG_HOP_BAN_LE_%s_%s_%s_%d.xlsx" % (tu_all, den_all, datetime.now().strftime("%Y%m%d-%H%M%S"), lan)
            duong = os.path.join(thu_muc, ten)
            lan += 1
    bang = [
            ("Tóm tắt", ["Nội dung", "Giá trị"], ["chu", "chu"], [48, 90], tom),
            ("Chi tiết hóa đơn tổng hợp", TH_COT_CHI_TIET,
             ["text", "text", "text", "chu", "chu", "chu", "chu", "so4", "so4", "so", "chu", "so", "so", "so", "so", "so"],
             [9, 11, 11, 11, 12, 46, 9, 10, 13, 12, 9, 16, 14, 15, 11, 16], s_cthd),
            ("Chứng từ tổng hợp", ["STT", "Số chứng từ", "Ngày CT", "Kỳ từ", "Kỳ đến", "Mẫu số", "Ký hiệu", "Số HĐ trên bảng kê",
                                   "Số HĐ từ", "Số HĐ đến", "Số lượng HĐ", "Số dòng hàng", "Thuế suất", "Tiền chưa thuế (đầu HĐ)",
                                   "Tiền thuế (đầu HĐ)", "Tổng thanh toán (đầu HĐ)", "Dòng hàng + thuế (vào sổ)", "Chênh lệch",
                                   "Tiền mặt (TM)", "Khác (CK, thẻ...)", "Ghi chú"],
             ["so", "text", "chu", "chu", "chu", "text", "text", "text", "text", "text", "so", "so", "chu", "so", "so", "so",
              "so", "so", "so", "so", "chu"],
             [5, 12, 11, 11, 11, 7, 10, 12, 11, 11, 10, 10, 12, 16, 14, 16, 16, 12, 15, 15, 34], s_ct),
            ("Hàng theo chứng từ", ["Số chứng từ", "Ngày CT", "Ký hiệu", "Dòng", "Tính chất", "Mã hàng", "Tên hàng hóa, dịch vụ", "ĐVT",
                                    "Số lượng", "Đơn giá bình quân", "Thành tiền", "Chiết khấu", "Thuế suất", "Tiền thuế", "Số HĐ có mặt hàng"],
             ["text", "chu", "text", "so", "chu", "text", "chu", "chu", "so4", "so4", "so", "so", "chu", "so", "so"],
             [12, 11, 10, 6, 18, 12, 42, 8, 11, 14, 15, 12, 9, 13, 12], s_hang),
            ("Bảng kê từng hóa đơn", ["STT", "Chứng từ tổng hợp", "Mẫu số", "Ký hiệu", "Số hóa đơn", "Ngày lập", "MST người mua",
                                      "Tên người mua", "Tiền chưa thuế", "Tiền thuế", "Thanh toán", "Trạng thái", "Mã CQT",
                                      "Số dòng", "Ghi chú", "File XML"],
             ["so", "text", "text", "text", "text", "chu", "text", "chu", "so", "so", "so", "chu", "chu", "so", "chu", "chu"],
             [6, 14, 7, 10, 11, 11, 14, 30, 14, 12, 14, 14, 30, 7, 26, 40], s_hd),
            ("HĐ nhập riêng - bỏ qua", ["Mẫu số", "Ký hiệu", "Số hóa đơn", "Ngày lập", "MST người mua", "Tên người mua",
                                        "Thanh toán", "Xử lý", "Lý do"],
             ["text", "text", "text", "chu", "text", "chu", "so", "chu", "chu"],
             [7, 10, 11, 11, 14, 30, 14, 18, 70], s_rieng),
        ]
    for lan in range(2):
        try:
            viet_xlsx(duong, bang)
            LOG.ghi("[TONG HOP] Da ghi %s: %d chung tu, %d HD gop, %d HD rieng, %d bo qua" % (ten, len(ct), len(ct_cua), len(rieng), len(bo_qua)))
            return duong
        except Exception as e:
            LOG.loi("Loi khi ghi file Excel tong hop ban le " + ten, e)
            if lan:
                return None
            goc, duoi = os.path.splitext(duong)          # GD94: file dang mo trong Excel -> ghi sang ten moi
            duong = "%s_%s%s" % (goc, datetime.now().strftime("%H%M%S"), duoi)
            ten = os.path.basename(duong)
    return None


# ---------------- chay (nut Tong hop HD ban le) ----------------
TH_LO_GUI = 300             # GD94: ky gop da tai du -> gom ~300 HD (hoac 2 phut) thi chuyen sang phan mem 1 dot
TH_LO_GIAY = 120
TAI_CHAN_CHO = 30 * 60     # GD94: cong thue chan -> 30 phut sau moi goi lai cong (tai lai ngay chi bi chan lau hon)


def _tb_chan():
    luc = LY_DO_TAI.get("chan_luc") or time.time()
    return ("Cổng thuế đang CHẶN tải (“Hệ thống phát hiện hành vi không hợp lệ”, lúc %s) - tool đã DỪNG NGAY để không bị "
            "chặn lâu hơn. Đợi tới khoảng %s rồi bấm lại (đăng nhập lại nếu cần): hóa đơn đã tải / đã gộp được bỏ qua, không tải lại. "
            % (time.strftime("%H:%M", time.localtime(luc)), time.strftime("%H:%M", time.localtime(luc + 30 * 60))))


def _bat_dau_lo():
    """GD94: dau moi lan tai / tong hop: quen chi tiet da hoi cong; bo co chan chi khi da qua TAI_CHAN_CHO (trong thoi gian
    cho: HD co file tren may van dua vao phan mem duoc, HD phai tai thi dung ngay - khong goi cong)."""
    CHI_TIET_NHO.clear()
    if LY_DO_TAI.get("bi_chan") and time.time() - (LY_DO_TAI.get("chan_luc") or 0) >= TAI_CHAN_CHO:
        LY_DO_TAI["bi_chan"] = False


def _dang_tai(bat):
    """GD94: tep DANG_TAI (thu muc ket-qua) trong luc tool dang tai / tong hop (ghi ket qua dan tung dot) -> phan mem nap tung dot
    nhung khong hien hop thong bao moi dot. Xong / dung / loi -> xoa."""
    if not UNESCO.get("bat"):
        return
    try:
        d = os.path.join(unesco_thu_muc("ket-qua"), "DANG_TAI")
        if bat:
            with open(d, "w", encoding="ascii") as f:
                f.write("%d %s %s" % (os.getpid(), datetime.now().strftime("%Y-%m-%d %H:%M:%S"), _may_nay()))
        elif os.path.exists(d):
            pid, may = _doc_khoa(d)
            if str(pid or "").strip() == str(os.getpid()) and may in ("", _may_nay()):
                os.remove(d)            # chi xoa tep cua chinh cua so nay
    except Exception:
        pass


def _khoa_mst_mod():
    try:
        import khoa_tai_mst
        return khoa_tai_mst
    except Exception as e:
        LOG.loi("Khong nap duoc khoa_tai_mst.py (khoa tai theo MST)", e)
        return None


# 18/11/2026: hoa don TAI LOI cua lan tai gan nhat (hd, kind, direction) - nut «Tải lại HĐ lỗi»; STATE['tai']['ds_loi'] = ten tep de hien.
TAI_LOI = []
TAI_LOI_CAU_HINH = {}


def _tai_loi_xoa():
    del TAI_LOI[:]
    with STATE_LOCK:
        STATE["tai"]["ds_loi"] = []


def _tai_loi_ghi(hd, kind, direction):
    TAI_LOI.append((hd, kind, direction))
    with STATE_LOCK:
        ds = STATE["tai"].setdefault("ds_loi", [])
        if len(ds) < 200:
            ds.append(ten_file(hd, direction))


def tai_lai_loi():
    """18/11/2026: tai lai DUNG cac hoa don loi cua lan truoc (cung thu muc / dinh dang), mot thanh tien trinh. -> so HD (0 = khong co)."""
    ds = list(TAI_LOI)
    cfg = dict(TAI_LOI_CAU_HINH)
    if not ds or not cfg.get("thu_muc"):
        return 0
    nhom, thu_tu = {}, []
    for hd, kind, direction in ds:
        k = (kind, direction)
        if k not in nhom:
            nhom[k] = []
            thu_tu.append(k)
        nhom[k].append(hd)

    def _chay():
        ok_k, tb_k, khoa = khoa_mst_lay("cửa sổ Tải hoá đơn (tải lại HĐ lỗi)")
        if not ok_k:
            with STATE_LOCK:
                STATE["tai"].update({"dang_chay": False, "hien_tai": "", "ket_thuc": tb_k})
            return
        try:
            with STATE_LOCK:
                STATE["tai"].update({"dang_chay": True, "dung": False, "tong": len(ds), "xong": 0, "ok": 0, "bo_qua": 0, "loi": 0,
                                     "khong_xml": 0, "hien_tai": "", "ket_thuc": "", "tep_mo": "", "tep_ds": [], "bi_chan": False,
                                     "loi_gui": 0, "giu_bl": 0, "bl_khong_giu": 0})
            _tai_loi_xoa()
            _bat_dau_lo()
            _dang_tai(True)
            for i, (kind, direction) in enumerate(thu_tu):
                if STATE["tai"]["dung"] or STATE["tai"].get("bi_chan"):
                    break
                chay_tai(nhom[(kind, direction)], kind, direction, cfg["thu_muc"], cfg.get("dinh_dang") or ["xml"], cfg.get("lam_excel", False),
                         noi_tiep=True, con_nua=(i < len(thu_tu) - 1))
            t = STATE["tai"]
            ket = (_tb_chan() if t.get("bi_chan") else ("Đã dừng. " if t["dung"] else "Xong tải lại. ")) + \
                "Tải lại %d hóa đơn lỗi: thành công %d · đã có %d · không có XML gốc %d · vẫn lỗi %d." % (
                    len(ds), t["ok"], t["bo_qua"], t.get("khong_xml", 0), t["loi"])
            with STATE_LOCK:
                t["dang_chay"] = False
                t["ket_thuc"] = ket
                t["hien_tai"] = ""
        except Exception as e:
            LOG.loi("Loi khi tai lai HD loi", e)
            with STATE_LOCK:
                STATE["tai"].update({"dang_chay": False, "hien_tai": "", "ket_thuc": "Lỗi khi tải lại: " + str(e)[:200]})
        finally:
            khoa_mst_tra(khoa)
            _dang_tai(False)
    threading.Thread(target=_chay, daemon=True).start()
    return len(ds)


def khoa_mst_kiem():
    """18/11/2026: '' khi khong co tien trinh KHAC tren may dang goi cong cho MST nay; nguoc lai thong bao (khong lay khoa)."""
    m = _khoa_mst_mod()
    return m.kiem(STATE.get("mst") or UNESCO.get("mst")) if m else ""


def khoa_mst_lay(viec):
    """18/11/2026: lay khoa tai theo MST (cung tien trinh lay lai duoc). -> (ok, thong bao, khoa de tra)."""
    m = _khoa_mst_mod()
    if not m:
        return True, "", None
    mst = STATE.get("mst") or UNESCO.get("mst")
    ok, tb = m.lay(mst, viec)
    if not ok:
        LOG.ghi("[KHOA MST] Tu choi %s: %s" % (bo_dau(viec), bo_dau(tb)))
    return ok, tb, (mst if ok else None)


def khoa_mst_tra(khoa):
    m = _khoa_mst_mod()
    if m and khoa:
        m.tra(khoa)


def _dang_tai_don():
    """GD94 (luc mo tool): tep DANG_TAI cua cua so da tat (tool bi tat ngang) -> xoa; cua so khac con chay -> giu."""
    try:
        d = os.path.join(unesco_thu_muc("ket-qua"), "DANG_TAI")
        if UNESCO.get("bat") and os.path.exists(d):
            pid, may = _doc_khoa(d)
            if (may in ("", _may_nay()) and _pid_con_song(pid) is not True) or time.time() - os.path.getmtime(d) > 12 * 3600:
                os.remove(d)
    except Exception:
        pass


def th_ky_cua_hd(hd, so_ngay):
    """GD94: ky gop (tu, den) cua dong tra cuu theo ngay lap gio VN; None neu khong doc duoc ngay."""
    d = th_ngay(ngay_vn(hd.get("tdlap")))
    return th_ky_gop(d, so_ngay) if d else None


def _th_khoa_xml(x):
    return unesco_khoa(x.get("nban_mst"), x.get("mau_so"), x.get("ky_hieu"), x.get("so_hd"))


def chay_tong_hop_ban_le(danh_sach, kind, thu_muc, so_ngay, pham_vi, giu_chay=False):
    """Tai / doc XML cac HD ban ra da chon, tong hop theo ky, ghi Excel chi tiet va (UNESCO) JSONL cho phan mem.
    GD94: xu ly LAN LUOT tung ky gop (ngay / tuan theo ngay lap); cac ky DA TAI DU duoc tong hop + chuyen sang phan mem
    theo dot (~300 HD / 2 phut) -> tool bi tat ngang / bam Dung / cong thue chan giua chung van giu cac ky da xong (truoc
    day: 6.088 HD tai 8 phut roi tat -> khong gui duoc gi). Chi ghi so 'da tai' / so dang ky cua mot dot SAU khi dot do da
    gui sang phan mem. HD da nhap tung to vao phan mem nhung CHUA lap chung tu (anh chot GD94): gop luon, dong thanh vien
    mang 'thay_rieng' -> phan mem xoa dong HD le chua lap CT roi nhan chung tu tong hop; HD da lap CT -> phan mem chan."""
    so_chon = len(danh_sach)
    ket = "Xong."
    co_khoa = False
    nhip = threading.Event()
    try:
        # khoa phien TRUOC, anh chup chong trung SAU: cua so khac vua tong hop xong thi thay ngay tep no vua ghi
        if not th_khoa_phien(True):
            ket = "Chưa tổng hợp: đang có một cửa sổ tool khác tổng hợp hóa đơn của bộ sổ này. Đợi xong rồi bấm lại."
            return
        co_khoa = True
        threading.Thread(target=_th_nhip_khoa, args=(nhip,), daemon=True).start()
        _bat_dau_lo()
        _dang_tai(True)
        if UNESCO.get("bat"):
            nc = th_ngu_canh()
            if not nc["co_da_doc"]:
                ket = ("Chưa tổng hợp: phần mềm UNESCO chưa cập nhật bản GĐ91 (thiếu da-doc-ket-qua.txt). Chạy FIX_TU_DONG.bat, "
                       "Full Compile, Make .exe rồi mở lại màn hình Tải hóa đơn từ phần mềm.")
                return
        else:
            nc = {"tt": {}, "tv": {}, "song": set(), "so": th_doc_so(), "so_ct": set(), "co_da_doc": True, "goc": {}, "cho": set()}
        # ma lan tong hop: phan mem chi coi la "doc lai cung tep" khi CUNG ma lan (khac lan cung khoa -> chan)
        lan = "%s-%d-%s" % (datetime.now().strftime("%Y%m%d%H%M%S"), os.getpid(), os.urandom(3).hex())
        ck_xu_ly = int(th_quy_tac().get("CK_XuLy") or 0)
        can, bo_qua, da_chon, thay = [], [], set(), set()
        for hd in danh_sach:
            k = khoa_cua(hd)
            if k in da_chon:
                continue            # cung HD lap lai trong danh sach tra cuu
            da_chon.add(k)
            pk = th_tv_bi_khoa(k, nc)
            if nc["tt"].get(k) is True:
                bo_qua.append((hd, "Đã có trong phần mềm và đã lập chứng từ - không gộp, không gửi lại"))
            elif k in TH_DA_GUI:
                bo_qua.append((hd, "Đã gửi sang phần mềm trong lần làm việc này"))
            elif pk:
                bo_qua.append((hd, "Đã nằm trong chứng từ tổng hợp %s" % ((nc["so"]["ct"].get(pk) or {}).get("so_ct") or pk)))
            elif k in nc["tt"] and (k not in nc["goc"] or k in nc["cho"]):
                bo_qua.append((hd, "Đang chờ phần mềm nhập - không gộp, không gửi lại"))
            elif k in nc["tt"] and nc["goc"].get(k) not in ("0", "3"):       # GD108: 3 = tu bang ke Excel, nhu 0
                bo_qua.append((hd, "Đã có trong phần mềm (Bỏ qua / Cần xem lại / lập tay / đã bị thay thế, hủy / thuộc chứng từ khác) - không gộp"))
            else:
                can.append(hd)
                if k in nc["tt"]:
                    thay.add(k)     # GD94: da nhap tung to, CHUA lap chung tu (ma 0) -> gop luon (phan mem thay dong HD le)
        can.sort(key=lambda h: (ngay_vn(h.get("tdlap")), str(h.get("khhdon") or ""), _th_so_sx(unesco_so_hd(h.get("shdon")))))
        with STATE_LOCK:
            moi_tt = {"dang_chay": True, "dung": False, "tong": len(can), "xong": 0, "ok": 0, "bo_qua": 0, "loi": 0, "khong_xml": 0,
                      "hien_tai": "", "ket_thuc": "", "tep_mo": "", "tep_ds": [], "bi_chan": False}
            if giu_chay:            # GD109: tu gop trong luong tai - giu co Dung, file Excel, bao cao cua lan tai
                for k_ in ("dung", "ket_thuc", "tep_mo", "tep_ds", "bi_chan"):
                    moi_tt.pop(k_)
            STATE["tai"].update(moi_tt)
        LOG.ghi("[TONG HOP] ===== Bat dau: %d HD da chon, %d can xu ly (%d da nhap tung to chua lap CT - gop thay), %d bo qua | "
                "gop %s | pham vi %s | CK_XuLy %s | %s" % (so_chon, len(can), len(thay), len(bo_qua), so_ngay, pham_vi, ck_xu_ly, thu_muc))
        if not can:
            ket = ("Không có hóa đơn nào cần tổng hợp: %d hóa đơn đã chọn đều đã có trong phần mềm, đang chờ phần mềm nhập, "
                   "đã gửi trong lần làm việc này hoặc đã nằm trong chứng từ tổng hợp (không gộp lại để tránh nhân đôi)." % so_chon)
            return
        # file Excel chi tiet: 1 file cho ca lan tong hop (ten theo khoang ngay da chon), ghi lai sau moi dot
        ngay_can = sorted(n for n in (ngay_vn(h.get("tdlap")) for h in can) if th_ngay(n))
        tep_excel = [os.path.join(thu_muc, "TONG_HOP_BAN_LE_%s_%s_%s.xlsx" % (
            ngay_can[0].replace("-", "") if ngay_can else "x", ngay_can[-1].replace("-", "") if ngay_can else "x",
            datetime.now().strftime("%Y%m%d-%H%M%S")))]
        so_ct_dd = set(nc["so_ct"])
        tong = {"ct": [], "rieng": [], "theo_hd": {}}
        dem = {"dot": 0, "hd_gop": set(), "ct": 0, "rieng": 0, "thay": 0}
        thu_thap, cho_hd, cho_kx, ky_xong = [], [], [], set()
        hd_cua = {khoa_cua(h): h for h in can}

        def gui_dot(cuoi):
            """Tong hop + chuyen sang phan mem cac HD da tai cua cac ky DA XONG (cuoi=True: tat ca)."""
            if not cho_hd:
                return
            khoa_cho = {khoa_cua(h) for h in cho_hd}
            tt_cho = [x for x in thu_thap if _th_khoa_xml(x) in khoa_cho]
            dong = unesco_gom_dong(tt_cho, cho_hd, "ban", kind, thu_muc)
            hoan = set()
            if not cuoi:
                # HD co ngay lap (theo XML) roi vao ky CHUA tai xong -> de dot sau (1 ky khong bi tach 2 chung tu)
                for d in dong:
                    nd = th_ngay(d.get("NgayLap"))
                    if nd is not None and th_ky_gop(nd, so_ngay) not in ky_xong:
                        hoan.add(d.get("khoa"))
                dong = [d for d in dong if d.get("khoa") not in hoan]
            gui_hd = [h for h in cho_hd if khoa_cua(h) not in hoan]
            if not gui_hd:
                return
            with STATE_LOCK:
                STATE["tai"]["hien_tai"] = "Đang tổng hợp %d hóa đơn của các kỳ đã tải xong…" % len(gui_hd)
            kq = th_tong_hop(dong, so_ngay, pham_vi, so_ct_dd, "", ck_xu_ly)
            con = []
            for r in kq["rieng"]:
                if r["khoa"] in thay:       # da co trong phan mem tung to, van phai nhap rieng -> giu nguyen, khong gui lai
                    bo_qua.append((hd_cua.get(r["khoa"]) or {}, "Đã có trong phần mềm (từng tờ) - giữ nguyên: " + r["ly_do"]))
                else:
                    con.append(r)
            kq["rieng"] = con
            so_ct_dd.update("%d|%s" % (c["ngay"].year, c["so_ct"]) for c in kq["ct"])
            tong["ct"] += kq["ct"]
            tong["rieng"] += kq["rieng"]
            tong["theo_hd"].update(kq["theo_hd"])
            with STATE_LOCK:
                STATE["tai"]["hien_tai"] = "Đang ghi file Excel chi tiết…"
            tep = th_xuat_excel(tong, bo_qua, thu_muc, so_ngay, pham_vi, so_chon, duong=tep_excel[0])
            if tep:
                tep_excel[0] = tep
            for c in kq["ct"]:
                for d in c["dong"]:
                    d["tep_xml"] = tep or ""
            if UNESCO.get("bat"):
                tv_dong = []
                for c in kq["ct"]:
                    for k in c["hd"]:
                        x = {"tv_th": k, "khoa": c["khoa"], "so_ct": c["so_ct"], "lan_th": lan, "huong": "ban"}
                        if k in thay:
                            x["thay_rieng"] = True
                        tv_dong.append(x)
                    for d in c["dong"]:
                        d["lan_th"] = lan
                ds_gui = tv_dong + [d for c in kq["ct"] for d in c["dong"]] + [d for r in kq["rieng"] for d in r["dong"]]
                if len(ds_gui) > len(tv_dong):
                    with STATE_LOCK:
                        STATE["tai"]["hien_tai"] = "Đang chuyển sang phần mềm UNESCO…"
                    if kq["ct"]:
                        th_ghi_so(kq, tep or "", so_ngay, pham_vi, lan)       # ghi so TRUOC khi ghi JSONL: loi giua chung van chan duoc
                    tep_gui = unesco_ghi_jsonl(ds_gui, "tonghop")
                    th_nho_gui([d.get("khoa") for d in ds_gui], tep_gui)      # GD116: nho ca ten tep
            khoa_gui = {khoa_cua(h) for h in gui_hd}
            so_tai_ghi_nhieu(gui_hd, "ban", thu_muc, [k for k in cho_kx if k in khoa_gui])      # sau khi da gui
            dem["dot"] += 1
            dem["ct"] += len(kq["ct"])
            dem["rieng"] += len(kq["rieng"])
            gop = {k for c in kq["ct"] for k in c["hd"]}
            dem["hd_gop"].update(gop)
            dem["thay"] += len(gop & thay)
            cho_hd[:] = [h for h in cho_hd if khoa_cua(h) in hoan]
            thu_thap[:] = [x for x in thu_thap if _th_khoa_xml(x) in hoan]
            cho_kx[:] = [k for k in cho_kx if k in hoan]

        ky_dang, luc_gui = None, time.time()
        for hd in can:
            if STATE["tai"]["dung"]:
                break
            ky = th_ky_cua_hd(hd, so_ngay)
            if ky != ky_dang:
                if ky_dang is not None:
                    ky_xong.add(ky_dang)
                    if len(cho_hd) >= TH_LO_GUI or time.time() - luc_gui >= TH_LO_GIAY:
                        gui_dot(False)
                        luc_gui = time.time()
                ky_dang = ky
            goc = ten_file(hd, "ban")
            with STATE_LOCK:
                STATE["tai"]["hien_tai"] = goc
            try:
                kq = tai_mot_hoa_don(hd, kind, "ban", thu_muc, ["xml"], thu_thap)
            except Exception as e:
                LOG.loi("Loi khong luong truoc khi tai " + goc, e)
                kq = "loi"
            if kq == "chan":            # GD94: cong thue chan -> dung ngay, khong danh cong lien tuc
                with STATE_LOCK:
                    STATE["tai"]["bi_chan"] = True
                break
            if kq in ("ok", "bo_qua", "khong_xml"):
                cho_hd.append(hd)
                if kq == "khong_xml":
                    cho_kx.append(khoa_cua(hd))
            else:
                bo_qua.append((hd, "Tải lỗi - chưa gộp, bấm Tổng hợp lại lần sau"))
            with STATE_LOCK:
                STATE["tai"]["xong"] += 1
                STATE["tai"][kq] = STATE["tai"].get(kq, 0) + 1
        het = not STATE["tai"]["dung"] and not STATE["tai"].get("bi_chan")
        if het and ky_dang is not None:
            ky_xong.add(ky_dang)
        gui_dot(het)                        # dung / bi chan giua chung: chi gui cac ky DA tai du
        so_hd_gop = len(dem["hd_gop"])
        if not het:
            if dem["dot"] == 0:
                ket = ("Đã dừng. CHƯA tổng hợp, chưa gửi gì sang phần mềm (XML đã tải giữ lại, lần sau không tải lại). "
                       "Bấm “Tổng hợp HĐ bán lẻ” lần nữa để làm tiếp.")
            else:
                ket = ("Đã dừng giữa chừng. ĐÃ tổng hợp và chuyển các kỳ tải đủ: gộp %d hóa đơn thành %d chứng từ (%s / chứng từ). "
                       "Phần còn lại CHƯA tổng hợp - bấm “Tổng hợp HĐ bán lẻ” lần nữa để làm tiếp (hóa đơn đã gộp tự bỏ qua)."
                       % (so_hd_gop, dem["ct"], th_ten_cach_gop(so_ngay)))
            if STATE["tai"].get("bi_chan"):
                ket = _tb_chan() + ket
        else:
            ket = "Xong. Gộp %d hóa đơn bán lẻ thành %d chứng từ (%s / chứng từ)" % (so_hd_gop, dem["ct"], th_ten_cach_gop(so_ngay))
            if dem["rieng"]:
                ket += "; %d hóa đơn nhập riêng từng tờ" % dem["rieng"]
            if bo_qua:
                ket += "; %d hóa đơn bỏ qua (đã có / đã tổng hợp / tải lỗi - xem Excel)" % len(bo_qua)
            if UNESCO.get("bat") and dem["dot"]:
                ket += " — Đã chuyển sang phần mềm UNESCO, quay lại phần mềm để phân tích và lập chứng từ."
        if dem["thay"]:
            ket += (" — %d hóa đơn đã nhập từng tờ (chưa lập chứng từ) được gộp luôn vào chứng từ tổng hợp: phần mềm thay "
                    "dòng hóa đơn lẻ bằng chứng từ tổng hợp." % dem["thay"])
        if dem["dot"] and tep_excel[0] and os.path.exists(tep_excel[0]):
            ket += " — File Excel chi tiết: " + os.path.basename(tep_excel[0])
            with STATE_LOCK:
                STATE["tai"]["tep_mo"] = tep_excel[0]
    except Exception as e:
        LOG.loi("Loi khi tong hop hoa don ban le", e)
        ket = "Lỗi khi tổng hợp: " + str(e)[:200] + ". Các kỳ đã gửi (nếu có) vẫn giữ; phần còn lại chưa gửi. Xem file nhật ký."
    finally:
        nhip.set()
        if co_khoa:
            if not giu_chay:            # GD109: tu gop trong luong tai - luong tai tu xoa DANG_TAI khi xong ca chuoi
                _dang_tai(False)
            th_khoa_phien(False)
        LOG.ghi("[TONG HOP] ===== Ket thuc: " + ket)
        with STATE_LOCK:
            STATE["tai"]["ket_th"] = ket          # GD109
            if not giu_chay:            # GD109: tu gop sau khi tai - luong tai tu bao xong
                STATE["tai"]["dang_chay"] = False
                STATE["tai"]["ket_thuc"] = ket
            STATE["tai"]["hien_tai"] = ""


TAI_LO_GUI = 200            # GD94: cu 200 HD (hoac 90 giay) chuyen sang phan mem 1 dot - tool bi tat ngang khong mat HD da tai
TAI_LO_GIAY = 90


def _tai_gui_dot(thu_thap, tu, cho, direction, kind, thu_muc, xac_nhan=False):
    """GD94: chuyen sang phan mem cac HD vua xu ly (tai xong / doc lai file co san / khong co XML goc / loi mang):
    thu_thap[tu:] (XML doc duoc) + cho [(hd, ket qua)]. Ghi so da-tai SAU khi ghi JSONL. -> (tep JSONL | None, so HD)."""
    ten = None
    ds = [h for h, _ in cho]
    giu0 = STATE["tai"].get("giu_bl", 0)            # GD109: HD ban le giu lai khong tinh la da chuyen
    if UNESCO.get("bat") and ds:
        try:
            ten = unesco_xuat_sau_khi_tai((thu_thap or [])[tu:], ds, direction, kind, thu_muc, xac_nhan)
        except Exception as e:
            LOG.loi("Loi khi xuat JSONL cho UNESCO - %d HD CHUA sang phan mem, KHONG ghi so da tai (Lam moi se thay lai)" % len(ds), e)
            with STATE_LOCK:
                STATE["tai"]["loi_gui"] = STATE["tai"].get("loi_gui", 0) + len(ds)
            return None, 0
    tai = [h for h, kq in cho if kq in ("ok", "bo_qua", "khong_xml")]
    if tai:
        so_tai_ghi_nhieu(tai, direction, thu_muc, [khoa_cua(h) for h, kq in cho if kq == "khong_xml"])
    return ten, (max(0, len(ds) - (STATE["tai"].get("giu_bl", 0) - giu0)) if ten else 0)


def chay_tai(danh_sach, kind, direction, thu_muc, dinh_dang, lam_excel=False, noi_tiep=False, con_nua=False,
             xac_nhan=False):
    """GD94: bao _chay_tai_than - loi bat ngo van tra trang thai 'dang chay' va xoa tep DANG_TAI.
    GD109: xac_nhan = nut Dua HD da tai vao phan mem; khoa 'Chi tong hop ngay' -> tu gop ngay da qua sau khi tai.
    18/11/2026: giu khoa tai theo MST (khoa_tai_mst) trong luc chay - cua so / lo khac cung MST khong goi cong song song."""
    khoa = None
    try:
        ok_k, tb_k, khoa = khoa_mst_lay("cửa sổ Tải hoá đơn")
        if not ok_k:
            with STATE_LOCK:
                STATE["tai"].update({"dang_chay": False, "hien_tai": "", "ket_thuc": tb_k})
            return
        ket = _chay_tai_than(danh_sach, kind, direction, thu_muc, dinh_dang, lam_excel, noi_tiep, con_nua, xac_nhan)
        if ket is not None:         # GD109: con HD ban le cho gop (STATE dang_chay van bat)
            tb = ""
            try:
                tb = bl_tu_gop(thu_muc)
            except Exception as e:
                LOG.loi("Loi khi tu tong hop ngay HD ban le", e)
                tb = "Lỗi khi tự tổng hợp ngày: " + str(e)[:150] + " - hóa đơn bán lẻ vẫn giữ trên máy, bấm Tổng hợp HĐ bán lẻ."
            finally:
                with STATE_LOCK:
                    STATE["tai"]["dang_chay"] = False
                    STATE["tai"]["ket_thuc"] = ket + ((" — " + tb) if tb else "")
                    STATE["tai"]["hien_tai"] = ""
    except Exception as e:
        LOG.loi("Loi bat ngo khi tai hoa don", e)
        with STATE_LOCK:
            STATE["tai"]["dang_chay"] = False
            STATE["tai"]["hien_tai"] = ""
            STATE["tai"]["ket_thuc"] = ("Lỗi khi tải: " + str(e)[:200] + ". Hóa đơn đã chuyển sang phần mềm (nếu có) vẫn giữ - "
                                        "bấm Làm mới để xem hóa đơn đã tải chưa vào phần mềm. Xem file nhật ký.")
    finally:
        khoa_mst_tra(khoa)
        if not noi_tiep:
            _dang_tai(False)


def _chay_tai_than(danh_sach, kind, direction, thu_muc, dinh_dang, lam_excel=False, noi_tiep=False, con_nua=False,
                   xac_nhan=False):
    """noi_tiep=True: KHONG dat lai bo dem (dang tai nhieu nhom lien nhau - 'Tai ve' sau khi Dong bo).
       con_nua=True : sau nhom nay con nhom khac -> chua bao la da xong.
       GD94: ket qua cho phan mem ghi DAN (200 HD / 90 giay mot dot) thay vi chi o cuoi; cong thue chan -> dung ngay."""
    with STATE_LOCK:
        t = STATE["tai"]
        if noi_tiep:
            t.update({"dang_chay": True, "hien_tai": ""})
        else:
            t.update({"dang_chay": True, "dung": False, "tong": len(danh_sach),
                      "xong": 0, "ok": 0, "bo_qua": 0, "loi": 0, "khong_xml": 0,
                      "hien_tai": "", "ket_thuc": "", "tep_mo": "", "tep_ds": [], "bi_chan": False, "loi_gui": 0,
                      "giu_bl": 0, "bl_khong_giu": 0})          # GD109
    if not noi_tiep:
        _tai_loi_xoa()          # 18/11/2026: danh sach HD loi cua lan tai nay
    TAI_LOI_CAU_HINH.update({"thu_muc": thu_muc, "dinh_dang": list(dinh_dang), "lam_excel": bool(lam_excel)})
    if not noi_tiep:
        BL_CHO_GOP.clear()
    if not noi_tiep:
        _bat_dau_lo()
        _dang_tai(True)

    nhan = " + ".join([d.upper() for d in dinh_dang] + (["EXCEL"] if lam_excel else []))
    LOG.ghi("[TAI] ===== Bat dau xu ly %d hoa don (%s) vao: %s"
            % (len(danh_sach), nhan or "chi gop Excel", thu_muc))
    if "pdf" in dinh_dang:
        tim_chrome()

    thu_thap = [] if (lam_excel or UNESCO["bat"]) else None
    xu_ly, cho, da_gui_tt, so_gui, luc_gui = [], [], 0, 0, time.time()

    for hd in danh_sach:
        if STATE["tai"]["dung"]:
            break
        goc = ten_file(hd, direction)
        with STATE_LOCK:
            STATE["tai"]["hien_tai"] = goc
        try:
            kq = tai_mot_hoa_don(hd, kind, direction, thu_muc, dinh_dang, thu_thap)
        except Exception as e:
            LOG.loi("Loi khong luong truoc khi tai " + goc, e)
            kq = "loi"
        if kq == "chan":            # GD94: cong thue chan -> KHONG goi cong nua (HD can tai bo qua ngay); HD co file tren may van xu ly
            with STATE_LOCK:
                STATE["tai"]["bi_chan"] = True
            continue
        xu_ly.append(hd)
        cho.append((hd, kq))
        if kq == "loi":
            _tai_loi_ghi(hd, kind, direction)          # 18/11/2026: nut «Tải lại HĐ lỗi»
        with STATE_LOCK:
            STATE["tai"]["xong"] += 1
            STATE["tai"][kq] = STATE["tai"].get(kq, 0) + 1
        if len(cho) >= TAI_LO_GUI or time.time() - luc_gui >= TAI_LO_GIAY:
            if UNESCO.get("bat"):
                with STATE_LOCK:
                    STATE["tai"]["hien_tai"] = "Đang chuyển %d hóa đơn vừa tải sang phần mềm UNESCO…" % len(cho)
            _, n = _tai_gui_dot(thu_thap, da_gui_tt, cho, direction, kind, thu_muc, xac_nhan)
            so_gui += n
            da_gui_tt, cho, luc_gui = len(thu_thap or []), [], time.time()

    # 24/11/2026 (tai HD VTP thieu): dong trang tai / bam Dung GIUA CHUNG -> truoc day chi ghi «Ket thuc: thanh cong 85 | loi 0»,
    #   11 HD ban ra thang 01/2026 (cong tra 96) roi mat khong dau vet: nhat ky khong ke, ds-cqt.txt chi ghi HD da xu ly nen doi
    #   chieu cong thue / so cung khong thay thieu. Nay: ke ro HD chua tai vao nhat ky + ghi chung vao ds-cqt (danh sach cong).
    _da_xl = set(id(x) for x in xu_ly)
    chua_tai = [hd for hd in danh_sach if id(hd) not in _da_xl] if (STATE["tai"]["dung"] or STATE["tai"].get("bi_chan")) else []
    if chua_tai:
        LOG.ghi("[TAI] CANH BAO: DUNG GIUA CHUNG (%s) - con %d / %d hoa don %s CHUA TAI: %s"
                % ("cong chan" if STATE["tai"].get("bi_chan") else "dong trang / bam Dung", len(chua_tai), len(danh_sach),
                   "ban ra" if direction == "ban" else "mua vao",
                   ", ".join(unesco_khoa(h.get("nbmst"), h.get("khmshdon"), h.get("khhdon"), h.get("shdon")) for h in chua_tai[:200])))
        ghi_ds_cqt(chua_tai, None, direction, kind)          # GD234: danh sach cong du, ke ca HD chua tai
    # ---- UNESCO: dot cuoi (ke ca khi bam Dung / cong chan: HD da xu ly van sang phan mem) ----
    if cho:
        if UNESCO.get("bat"):
            with STATE_LOCK:
                STATE["tai"]["hien_tai"] = "Đang ghi kết quả cho phần mềm UNESCO…"
        _, n = _tai_gui_dot(thu_thap, da_gui_tt, cho, direction, kind, thu_muc, xac_nhan)
        so_gui += n

    # ---- Gop danh muc thanh file Excel: bang ke 3 sheet (GD109: bo 4 mau UNESCO MUAVAO/BANRA x TONGHOP/CHITIET) ----
    ten_excel, loi_excel, tep_ds = None, None, []
    if lam_excel and thu_thap:
        with STATE_LOCK:
            STATE["tai"]["hien_tai"] = "Đang gộp danh mục vào file Excel…"
        ten_excel, loi_excel = xuat_excel(thu_thap, thu_muc)
        if ten_excel:
            tep_ds.append(os.path.join(thu_muc, ten_excel))
    elif lam_excel:
        loi_excel = "Không đọc được dữ liệu hóa đơn nào để gộp vào Excel."
        LOG.ghi("[EXCEL] " + loi_excel)
    # GD109: KHONG con tao 2 mau UNESCO MUAVAO/BANRA _TONGHOP/_CHITIET (tep Import Excel kieu cu, de hieu nham la phai import
    #   -> nhap trung voi AI). Hoa don vao phan mem qua man hinh AI; Import bang ke Excel o man hinh AI (GD108).

    t = STATE["tai"]
    if t.get("bi_chan"):
        ket = _tb_chan() + "Đã xử lý %d hóa đơn, còn %d hóa đơn chưa tải." % (t["xong"], t["tong"] - t["xong"])
    elif t["dung"]:
        ket = "Đã dừng. Xử lý xong %d hóa đơn, còn %d hóa đơn chưa tải." % (t["ok"], t["tong"] - t["xong"])
    elif dinh_dang:
        noi_luu = thu_muc
        if UNESCO.get("bat") and re.match(r"^\d{4}-\d{2}$", os.path.basename((thu_muc or "").rstrip("\\/"))):
            noi_luu = os.path.dirname(thu_muc.rstrip("\\/")) + " (mỗi hóa đơn vào thư mục THÁNG LẬP của nó)"
        ket = "Xong. Đã tải %d hóa đơn (%s) vào %s" % (t["ok"], " + ".join(d.upper() for d in dinh_dang), noi_luu)
        if t.get("bo_qua"):
            ket += " — %d hóa đơn đã có file trên máy (không tải lại)" % t["bo_qua"]
        if t.get("khong_xml"):
            ket += " — %d hóa đơn KHÔNG CÓ XML gốc trên cổng thuế (hóa đơn không mã: ngân hàng, điện, nước…), dùng dữ liệu tra cứu, không phải lỗi" % t["khong_xml"]
    else:
        ket = "Xong. Đã đọc %d hóa đơn." % t["xong"]
    if so_gui:
        ket += " — Đã chuyển %d hóa đơn sang phần mềm UNESCO, quay lại phần mềm để phân tích." % so_gui
    if not noi_tiep:
        ket += bl_tb_giu(t.get("giu_bl", 0), t.get("bl_khong_giu", 0))          # GD109
    if t.get("loi_gui"):
        ket += (" — CHÚ Ý: %d hóa đơn CHƯA chuyển được sang phần mềm (lỗi ghi kết quả, xem nhật ký) - bấm Làm mới để đưa vào lại."
                % t["loi_gui"])
    if t.get("loi") and not noi_tiep:
        ket += " — %d hóa đơn tải LỖI: bấm «Tải lại HĐ lỗi» bên dưới." % t["loi"]          # 18/11/2026
    if ten_excel:
        ket += " — File Excel: " + ten_excel
    elif loi_excel:
        ket += " — " + loi_excel

    LOG.ghi("[TAI] ===== Ket thuc: thanh cong %d | bo qua %d | khong co XML goc %d | loi %d | da chuyen phan mem %d%s%s"
            % (t["ok"], t["bo_qua"], t.get("khong_xml", 0), t["loi"], so_gui, " | CONG THUE CHAN" if t.get("bi_chan") else "",
               (" | DUNG GIUA CHUNG: CHUA TAI %d" % len(chua_tai)) if chua_tai else ""))          # 24/11/2026 (tai HD VTP thieu)
    # GD109: khoa 'Chi tong hop ngay' con HD ban le cho gop -> giu dang_chay, chay_tai tu gop roi moi bao xong. Dang tai noi
    #   tiep (Tai ve sau Dong bo): giu dang_chay toi khi ca chuoi xong (truoc day nhom cuoi tat som -> giao dien bao xong som).
    gop = (not noi_tiep) and bl_can_gop() and not t["dung"] and not t.get("bi_chan")
    if not noi_tiep and not gop:
        BL_CHO_GOP.clear()
    with STATE_LOCK:
        STATE["tai"]["dang_chay"] = ((bool(con_nua) or noi_tiep) and not t["dung"] and not t.get("bi_chan")) or gop
        STATE["tai"]["ket_thuc"] = "" if gop else ket
        STATE["tai"]["hien_tai"] = "Đang tự tổng hợp ngày hóa đơn bán lẻ…" if gop else ""
        if tep_ds:
            STATE["tai"]["tep_ds"] = list(STATE["tai"].get("tep_ds") or []) + tep_ds
    return ket if gop else None


def dong_bo_chay(p):
    """GD30b - DONG BO: lay danh sach hoa don cua CA HAI chieu (mua vao + ban ra) trong ky da chon,
    giu lai trong STATE["dong_bo"]. Khong tai file nao. Tra ve (tom_tat, canh_bao)."""
    loai = [k for k in ("dt", "mtt") if k in (p.get("loai") or ["dt", "mtt"])] or ["dt", "mtt"]
    kq = {"mua": {"dt": [], "mtt": []}, "ban": {"dt": [], "mtt": []}}
    canh_bao = []
    for huong in ("mua", "ban"):
        for kind in loai:
            if kind == "mtt" and huong == "ban" and p.get("mtt_chi_mua"):          # 26/11/2026 dot 5: chi tai HD may tinh tien MUA VAO
                canh_bao.append("không tra cứu HĐ máy tính tiền bán ra (đang chọn «Chỉ tải hoá đơn máy tính tiền MUA VÀO»)")
                continue
            p2 = dict(p); p2["kind"] = kind; p2["direction"] = huong
            rows, loi = tra_cuu(p2)
            ten = TEN_NHOM_HD.get((huong, kind), "%s/%s" % (huong, kind))          # GD112: ten nhom de hieu
            if loi:
                canh_bao.append("%s: %s" % (ten, "; ".join(TRA_CUU_CANH_BAO) or loi))
                LOG.ghi("[DONG BO] %s/%s bao loi: %s" % (huong, kind, loi))
            else:
                kq[huong][kind] = rows or []
                if kind == "mtt" and not TRA_CUU_CANH_BAO:
                    mtt_nho_ghi(huong, len(rows or []), p.get("tu_ngay"), p.get("den_ngay"))          # 26/11/2026 dot 3
                canh_bao.extend("%s: %s" % (ten, x) for x in TRA_CUU_CANH_BAO)          # GD112: ngay chua lay duoc
    if "mtt" not in loai:          # P0 18/11/2026: chi dong bo HD dien tu -> thang KHONG duoc ghi 'du' (GD370 du_thang)
        canh_bao.append("chưa tra cứu HĐ máy tính tiền (lần đồng bộ này chỉ chọn HĐ điện tử) - tháng chưa coi là đủ")
    elif "dt" not in loai:
        canh_bao.append("chưa tra cứu HĐ điện tử (lần đồng bộ này chỉ chọn HĐ máy tính tiền) - tháng chưa coi là đủ")
    loc = [ten for ten, co in (("trạng thái", MA_TRANG_THAI.get(p.get("trang_thai", "Tất cả"))),
                               ("kết quả kiểm tra", MA_KET_QUA.get(p.get("ket_qua", "Tất cả")) is not None),
                               ("mẫu số", (p.get("mau_so") or "Tất cả") != "Tất cả"),
                               ("MST / ký hiệu / số HĐ", p.get("mst_nguoi_mua") or p.get("ky_hieu") or p.get("so_hoa_don"))) if co]
    if loc:          # P0 18/11/2026: dong bo co LOC chi la mot phan cua thang -> khong ghi 'du thang'
        canh_bao.append("đồng bộ có lọc theo %s - chỉ là một phần của tháng, chưa coi là đủ" % ", ".join(loc))
    with STATE_LOCK:
        STATE["dong_bo"] = kq
        STATE["dong_bo_ky"] = {"tu": p.get("tu_ngay"), "den": p.get("den_ngay")}
    cb_th = th_canh_bao_tv(kq["ban"]["dt"] + kq["ban"]["mtt"])      # GD91
    STATE["dong_bo_cb"] = "; ".join(canh_bao)          # GD370: loi tra cuu / ngay chua lay duoc / MTT dung o trang -> thang chua du
    ghi_doi_chieu_cong_thue(STATE["dong_bo_cb"])
    if cb_th:
        canh_bao.append(cb_th)
    return dong_bo_tom_tat(), "; ".join(canh_bao)


def dong_bo_tom_tat():
    tt_pm, so_tai = doc_trang_thai_phan_mem(), _doc_json("da-tai.json", {})
    ra = {}
    for huong, nhom in (STATE.get("dong_bo") or {}).items():
        d = {"tong": 0, "moi": 0, "co": 0, "ht": 0, "khong_xml": 0, "tai": 0}       # GD94: tai = da tai, chua vao phan mem
        for kind in ("dt", "mtt"):
            for hd in nhom.get(kind, []):
                d["tong"] += 1
                d[trang_thai_dong(hd, tt_pm, so_tai)] += 1
                if (so_tai.get(khoa_cua(hd)) or {}).get("khong_xml"):
                    d["khong_xml"] += 1
        ra[huong] = d
    if "ban" in ra:          # GD112b
        ra["ban"]["bl_cu"] = sum(len(v) for v in bl_tung_to_dong_bo().values())
    return ra


def _so_tien_cong(v):
    try:
        return float(str(v).replace(",", "")) if v not in (None, "") else 0.0
    except Exception:
        return 0.0


def _ghi_csv_chua_co(p, dong):
    """Dot 8 (18/11/2026): CSV (UTF-8 BOM, ';') tung HD tren cong thue CHUA co trong phan mem cua mot thang. Ghi nguyen tu."""
    ten_tt = {"moi": "chưa tải", "tai": "đã tải về máy, chưa vào phần mềm"}
    ra = ["Chieu;Loai;TrangThai;KyHieuMau;KyHieu;SoHD;NgayLap;MSTNguoiBan;TenNguoiBan;MSTNguoiMua;TenNguoiMua;TienHang;TienThue;ThanhToan;TrangThaiCong"]
    for huong, kind, tt, hd, ng, h_, t_, tt_ in sorted(dong, key=lambda x: (x[0], x[4], str(x[3].get("khhdon")), str(x[3].get("shdon")))):
        o = ["mua vào" if huong == "mua" else "bán ra", "máy tính tiền" if kind == "mtt" else "điện tử", ten_tt.get(tt, tt),
             hd.get("khmshdon"), hd.get("khhdon"), hd.get("shdon"), (ng or "")[:10], hd.get("nbmst"), hd.get("nbten"), hd.get("nmmst"),
             hd.get("nmten"), "%.0f" % h_, "%.0f" % t_, "%.0f" % tt_, hd.get("tthai")]
        ra.append(";".join(str(x if x is not None else "").replace(";", ",").replace("\r", " ").replace("\n", " ") for x in o))
    tmp = p + ".tmp"
    with io.open(tmp, "w", encoding="utf-8-sig", newline="\r\n") as f:
        f.write("\n".join(ra) + "\n")
    os.replace(tmp, p)


def ghi_doi_chieu_cong_thue(canh_bao=""):
    """GD370: doi chieu SO LUONG hoa don tren cong thue voi phan mem, theo thang -> <thu muc khach>\\ket-qua\\cong_thue_thang.json
    {"yyyy-mm": {"luc", "tu", "den", "du_thang", "canh_bao", "mua": {tong, ht, co, tai, moi}, "ban": {...}}}. Gop voi lan truoc
    (thang ngoai ky lan nay giu nguyen). AI_AUTO (ai_auto_dieu_phoi.py) doc de chi coi buoc 'Nhan hoa don' xong khi DU hoa don
    cua thang (truoc day: co >= 1 hoa don la coi nhu xong). du_thang = lan dong bo phu tu ngay 1 den cuoi thang (thang hien tai:
    den hom nay) va khong co canh bao 'chua lay duoc'."""
    if not UNESCO.get("bat"):
        return
    try:
        db = STATE.get("dong_bo") or {}
        ky = STATE.get("dong_bo_ky") or {}
        tu, den = str(ky.get("tu") or "")[:10], str(ky.get("den") or "")[:10]
        tt_pm, so_tai = doc_trang_thai_phan_mem(), _doc_json("da-tai.json", {})
        moi = {}
        chua_co = {}          # dot 8 (chu quyet 18/11/2026): tung HD tren cong CHUA co trong phan mem, theo thang -> CSV
        for huong in ("mua", "ban"):
            for kind in ("dt", "mtt"):
                for hd in (db.get(huong) or {}).get(kind, []):
                    ng = ngay_vn(hd.get("tdlap"))
                    if not re.match(r"^\d{4}-\d{2}", ng or ""):
                        continue
                    m = moi.setdefault(ng[:7], {"mua": {"tong": 0, "ht": 0, "co": 0, "tai": 0, "moi": 0},
                                                "ban": {"tong": 0, "ht": 0, "co": 0, "tai": 0, "moi": 0}})
                    m[huong]["tong"] += 1
                    tt = trang_thai_dong(hd, tt_pm, so_tai)
                    tt = tt if tt in ("ht", "co", "tai", "moi") else "co"
                    m[huong][tt] += 1
                    # dot 8: so tien cong thue tra (tien hang chua thue / thue / thanh toan) - tong ca chieu va phan CHUA co trong phan mem
                    tien = m[huong].setdefault("tien", {"hang": 0.0, "thue": 0.0, "thanh_toan": 0.0,
                                                         "hang_chua_co": 0.0, "thue_chua_co": 0.0, "thanh_toan_chua_co": 0.0})
                    h_, t_, tt_ = _so_tien_cong(hd.get("tgtcthue")), _so_tien_cong(hd.get("tgtthue")), _so_tien_cong(hd.get("tgtttbso"))
                    tien["hang"] += h_; tien["thue"] += t_; tien["thanh_toan"] += tt_
                    if tt in ("moi", "tai"):
                        tien["hang_chua_co"] += h_; tien["thue_chua_co"] += t_; tien["thanh_toan_chua_co"] += tt_
                        chua_co.setdefault(ng[:7], []).append((huong, kind, tt, hd, ng, h_, t_, tt_))
        # thang trong ky nhung cong thue khong co hoa don nao -> van ghi (tong 0) de biet 'da doi chieu, khong phat sinh'
        if re.match(r"^\d{4}-\d{2}-\d{2}$", tu) and re.match(r"^\d{4}-\d{2}-\d{2}$", den):
            y, mo = int(tu[:4]), int(tu[5:7])
            while "%04d-%02d" % (y, mo) <= den[:7]:
                moi.setdefault("%04d-%02d" % (y, mo), {"mua": {"tong": 0, "ht": 0, "co": 0, "tai": 0, "moi": 0},
                                                      "ban": {"tong": 0, "ht": 0, "co": 0, "tai": 0, "moi": 0}})
                mo += 1
                if mo > 12:
                    y, mo = y + 1, 1
        p = os.path.join(unesco_thu_muc("ket-qua"), "cong_thue_thang.json")
        cu = _doc_json_tep(p)
        hom = datetime.now().strftime("%Y-%m-%d")
        for th, v in moi.items():
            cuoi = (datetime(int(th[:4]) + (th[5:7] == "12"), int(th[5:7]) % 12 + 1, 1) - timedelta(days=1)).strftime("%Y-%m-%d")
            du_ky = bool(tu) and tu <= th + "-01" and den >= min(cuoi, hom)
            if not du_ky and (cu.get(th) or {}).get("du_thang"):
                continue          # lan dong bo mot doan ngay le khong de len ket qua da doi chieu du ca thang
            du = du_ky and not canh_bao
            v.update({"luc": datetime.now().strftime("%Y-%m-%d %H:%M"), "tu": tu, "den": den, "du_thang": du, "canh_bao": (canh_bao or "")[:300]})
            cu[th] = v
        tmp = p + ".tmp"
        with io.open(tmp, "w", encoding="utf-8") as f:
            json.dump(cu, f, ensure_ascii=False, indent=1, sort_keys=True)
        os.replace(tmp, p)
        for th in moi:          # dot 8: chi tiet tung HD tren cong chua co trong phan mem (thang khong con HD thieu -> tep chi co dong tieu de)
            _ghi_csv_chua_co(os.path.join(unesco_thu_muc("ket-qua"), "cong_thue_chua_co_%s.csv" % th), chua_co.get(th, []))
        LOG.ghi("[DOI CHIEU] Cong thue theo thang: " + "; ".join("%s mua %d/%d ban %d/%d%s" % (
            th, v["mua"]["tong"] - v["mua"]["moi"] - v["mua"]["tai"], v["mua"]["tong"], v["ban"]["tong"] - v["ban"]["moi"] - v["ban"]["tai"],
            v["ban"]["tong"], "" if v["du_thang"] else " (chua du thang)") for th, v in sorted(moi.items())))
    except Exception as e:
        LOG.loi("Khong ghi duoc doi chieu cong thue theo thang", e)


def _doc_json_tep(p):
    try:
        with io.open(p, encoding="utf-8") as f:
            o = json.load(f)
        return o if isinstance(o, dict) else {}
    except Exception:
        return {}


def dong_bo_tai(thu_muc, dinh_dang, lam_excel):
    """GD30b - TAI VE: tai moi hoa don da dong bo ma CHUA co (chua trong phan mem, chua tung tai),
    lan luot mua/ban x dt/mtt, mot thanh tien trinh chung."""
    tt_pm, so_tai = doc_trang_thai_phan_mem(), _doc_json("da-tai.json", {})
    nhom = []
    for huong in ("mua", "ban"):
        for kind in ("dt", "mtt"):
            ds = loc_hoa_don_moi(((STATE.get("dong_bo") or {}).get(huong) or {}).get(kind, []), tt_pm, so_tai)
            if ds:
                nhom.append((huong, kind, ds))
    cu = bl_tung_to_dong_bo()          # GD112b: HD ban le dang nam tung to, chua lap CT -> khoa Gop moi ngay: tu gop thay
    so_cu = sum(len(v) for v in cu.values())
    if not nhom and not so_cu:
        return 0
    tong = sum(len(x[2]) for x in nhom)

    def _chay():
        ok_k, tb_k, khoa = khoa_mst_lay("cửa sổ Tải hoá đơn (tải sau đồng bộ)")          # 18/11/2026: ca chuoi giu mot khoa MST
        if not ok_k:
            with STATE_LOCK:
                STATE["tai"].update({"dang_chay": False, "hien_tai": "", "ket_thuc": tb_k})
            return
        try:
            _chay_than()
        finally:
            khoa_mst_tra(khoa)

    def _chay_than():
        with STATE_LOCK:
            STATE["tai"].update({"dang_chay": True, "dung": False, "tong": tong, "xong": 0, "ok": 0, "bo_qua": 0,
                                 "loi": 0, "khong_xml": 0, "hien_tai": "", "ket_thuc": "", "tep_mo": "", "tep_ds": [], "bi_chan": False,
                                 "loi_gui": 0, "giu_bl": 0, "bl_khong_giu": 0})          # GD109
        _tai_loi_xoa()          # 18/11/2026: danh sach HD loi cua lan tai nay
        BL_CHO_GOP.clear()
        for kind_cu, ds_cu in cu.items():          # GD112b: gop thay cung cac HD ban le vua giu lai
            BL_CHO_GOP.setdefault(kind_cu, []).extend(ds_cu)
        if so_cu:
            LOG.ghi("[BAN LE] Khoa 'tong_hop': %d HD ban le DA NAM TUNG TO trong phan mem (chua lap CT) -> tu gop thay theo ngay"
                    % so_cu)
        _bat_dau_lo()
        _dang_tai(True)
        for i, (huong, kind, ds) in enumerate(nhom):
            if STATE["tai"]["dung"] or STATE["tai"].get("bi_chan"):
                break
            LOG.ghi("[DONG BO] Tai nhom %s/%s: %d hoa don" % (huong, kind, len(ds)))
            chay_tai(ds, kind, huong, thu_muc, dinh_dang, lam_excel, noi_tiep=True, con_nua=(i < len(nhom) - 1))
        t = STATE["tai"]
        ket = (_tb_chan() if t.get("bi_chan") else ("Đã dừng. " if t["dung"] else "Xong cả kỳ. ")) + \
            "Tải %d · đã có %d · không có XML gốc %d · lỗi %d (trên %d hóa đơn mới của cả mua vào và bán ra)." % (
                t["ok"], t["bo_qua"], t.get("khong_xml", 0), t["loi"], tong) + \
            (" Quay lại phần mềm UNESCO để phân tích." if UNESCO.get("bat") else "") + \
            ((" CHÚ Ý: %d hóa đơn CHƯA chuyển được sang phần mềm (lỗi ghi kết quả) - bấm Làm mới để đưa vào lại." % t["loi_gui"])
             if t.get("loi_gui") else "") + bl_tb_giu(t.get("giu_bl", 0), t.get("bl_khong_giu", 0))          # GD109
        if not nhom:          # GD112b: chi con HD ban le tung to can gop
            ket = "Không có hóa đơn mới cần tải: mọi hóa đơn của kỳ đã có trong phần mềm."
        if so_cu:
            ket += (" Có %d HĐ bán lẻ (người mua không MST) đang nằm TỪNG TỜ trong phần mềm, chưa lập chứng từ (nhập trước khi "
                    "chọn Gộp mỗi ngày / chứng từ từng tờ vừa bị xoá) → tự gộp thay thành chứng từ bán lẻ theo ngày." % so_cu)
        tb = ""
        try:
            if bl_can_gop() and not t["dung"] and not t.get("bi_chan"):
                with STATE_LOCK:
                    STATE["tai"]["dang_chay"] = True
                tb = bl_tu_gop(thu_muc)          # GD109: khoa Chi tong hop ngay
        except Exception as e:
            LOG.loi("Loi khi tu tong hop ngay HD ban le", e)
            tb = "Lỗi khi tự tổng hợp ngày: " + str(e)[:150]
        finally:
            BL_CHO_GOP.clear()
            with STATE_LOCK:
                t["dang_chay"] = False
                t["ket_thuc"] = ket + ((" — " + tb) if tb else "")
                t["hien_tai"] = ""
        _dang_tai(False)
        ghi_doi_chieu_cong_thue(STATE.get("dong_bo_cb", ""))          # GD370: sau khi tai - so 'moi' con lai = chua tai duoc
    threading.Thread(target=_chay, daemon=True).start()
    return tong + so_cu          # GD112b: > 0 khi chi con HD ban le tung to can gop (API khong bao 'khong co gi can tai')


# ==========================================================================
#  GD54: TAB "HO SO THUE - CONG DVC" (doi chieu so lieu, xac nhan ho so da nop,
#  thong bao, so thue phai nop). Xu ly o hstk_dvc.py - chi nap khi mo tab.
# ==========================================================================
_HSTK = {"mod": None, "loi": ""}


def _hstk_mst():
    return UNESCO.get("mst") or SETTINGS.get("mst") or CHROME.get("mst") or ""


def hstk_mod():
    if _HSTK["mod"] is not None:
        return _HSTK["mod"]
    try:
        if BASE_DIR not in sys.path:
            sys.path.insert(0, BASE_DIR)
        import hstk_dvc as m
        m.cau_hinh(log=LOG,
                   ho_so_chrome=lambda: chrome_ho_so_cho(_hstk_mst()) + "-dvc",
                   tim_chrome=tim_chrome,
                   thu_muc=lambda: UNESCO["out"] if (UNESCO.get("bat") and UNESCO.get("out")) else "",
                   mst=_hstk_mst)
        _HSTK["mod"] = m
        _HSTK["loi"] = ""
    except Exception as e:
        _HSTK["loi"] = str(e)[:300]
        LOG.loi("Khong nap duoc hstk_dvc.py", e)
    return _HSTK["mod"]


def hstk_api(duong, p):
    m = hstk_mod()
    if m is None:
        return {"ok": False, "loi": "Thiếu hoặc lỗi tệp AIHoaDon\\hstk_dvc.py (" + _HSTK["loi"] + "). Cài lại gói cập nhật GĐ54."}
    return m.xu_ly_api(duong, p or {})


# ==========================================================================
#  MAY CHU NOI BO - phuc vu giao dien trong Chrome
# ==========================================================================
def _yeu_cau_hop_le(h):
    """GD63: chi nhan yeu cau tu CHINH giao dien 127.0.0.1 - chan trang web la goi vao may chu cuc bo
       (doi khoa API, xoa ho so, tai hoa don... qua CSRF / DNS rebinding)."""
    host = (h.headers.get("Host") or "").rsplit(":", 1)[0].strip("[]").lower()
    if host not in ("127.0.0.1", "localhost", "::1"):
        return False
    goc = (h.headers.get("Origin") or "").strip()
    if goc and goc != "null":
        g = (urllib.parse.urlparse(goc).hostname or "").lower()
        if g not in ("127.0.0.1", "localhost", "::1"):
            return False
    if (h.headers.get("Sec-Fetch-Site") or "").lower() == "cross-site":
        return False
    return True


class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass  # khong in ra man hinh den

    def _tra(self, doi_tuong, ma=200):
        try:
            raw = json.dumps(doi_tuong, ensure_ascii=False).encode("utf-8")
            self.send_response(ma)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)
        except Exception as e:
            LOG.loi("Khong tra duoc du lieu ve giao dien", e)

    def do_GET(self):
        if not _yeu_cau_hop_le(self):
            self._tra({"loi": "Yeu cau khong den tu giao dien cua tool"}, 403)
            return
        try:
            duong = urllib.parse.urlparse(self.path).path
            if duong in ("/", "/index.html"):
                raw = GIAO_DIEN.encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)
                return

            if duong.startswith("/api/hstk/"):      # GD54
                self._tra(hstk_api(duong, {}))
                return

            if duong == "/api/chrome-mo":
                ok, loi = chrome_mo_trang_thue()
                self._tra({"ok": ok, "loi": loi})
                return

            if duong == "/api/chrome-trang-thai":
                self._tra({"trang_thai": CHROME["trang_thai"], "loi": CHROME["loi"], "mst": CHROME["mst"]})
                return

            if duong == "/api/chrome-hien":           # GD145: hien lai cua so trang thue da thu nho
                self._tra({"ok": _chrome_cua_so("normal")})
                return

            if duong == "/api/nhip":                  # GD145: trang tai hoa don con mo
                q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
                thoat_ghi_nhip((q.get("id") or [""])[0])
                self._tra({"ok": True, "chrome": CHROME["trang_thai"], "loi": CHROME["loi"],
                           "dang_tai": bool(STATE["tai"]["dang_chay"]),
                           "mst": CHROME.get("mst") or "",                      # 26/11/2026: cua so nhung cua UNESCO XII doc
                           "cho_ma": max(1, int((CHO_CAPTCHA_MTT.get("het") or 0) - time.time())) if CHO_CAPTCHA_MTT.get("cho") else 0,
                           "cua_so": CHROME.get("nhung_cua_so") or ["", 0]})
                return

            if duong == "/api/thiet-lap":
                self._tra({
                    "thu_muc_luu": SETTINGS.get("thu_muc_luu", ""),
                    "mst": SETTINGS.get("mst", ""),
                    "mat_khau": "",
                    "goi_nho": goi_nho_ds(),
                    "chi_tai_moi": bool(SETTINGS.get("chi_tai_moi", True)),
                    "nho_dang_nhap": SETTINGS.get("nho_dang_nhap", True),
                    "dinh_dang": SETTINGS.get("dinh_dang", ["xml"]),
                    "co_chrome": bool(UNESCO.get("nhung") or tim_chrome()),          # 26/11/2026: cua so nhung khong can Chrome
                    "mtt_bo_qua": mtt_nho_bo_qua()[0], "mtt_ly_do": mtt_nho_bo_qua()[1], "mtt_chi_mua": bool(UNESCO.get("bat") and mtt_nho_doc().get("chi_mua")),          # 26/11/2026 dot 3
                    "duong_nhat_ky": LOG_PATH,
                    "phien_ban": APP_VERSION,
                    "unesco": dict(UNESCO),
                    "co_khoa_ai": bool(SETTINGS.get("anthropic_key")),
                    "model_ai": SETTINGS.get("anthropic_model", ""),
                    "khoa_bl": bl_che_do(),          # GD109
                })
                return

            if duong == "/api/hen-gio-xong":
                # che do hen gio: viec da xong -> tu dong tat tool sau 60 giay
                LOG.ghi("[HEN GIO] Da tai xong theo lich, tool se tu dong sau 60 giay.")
                def _tat():
                    time.sleep(60)
                    LOG.ghi("[HEN GIO] Tat tool.")
                    thoat_tool("Hen gio: da tai xong")      # GD145: dong ca Chrome trang thue
                threading.Thread(target=_tat, daemon=True).start()
                self._tra({"ok": True})
                return

            if duong == "/api/captcha":
                anh, loi = lay_captcha()
                self._tra({"ok": loi is None, "anh": anh, "loi": loi})
                return

            if duong == "/api/captcha-mtt":          # GD359: trang tool hoi dinh ky - co dang cho captcha MTT khong
                c = CHO_CAPTCHA_MTT
                self._tra({"ok": True, "cho": bool(c.get("cho")), "anh": c.get("anh") if c.get("cho") else "",
                           "mo_ta": c.get("mo_ta", ""), "loi": c.get("loi", ""),
                           "lan": int(c.get("lan") or 0),                                      # 26/11/2026 dot 2
                           "con": max(0, int((c.get("het") or 0) - time.time())) if c.get("cho") else 0})
                return

            if duong == "/api/tien-trinh":
                with STATE_LOCK:
                    self._tra(dict(STATE["tai"]))
                return

            if duong == "/api/chon-thu-muc":
                tra_loi = queue.Queue()
                HOP_THU_CHON_THU_MUC.put(tra_loi)
                try:
                    thu_muc = tra_loi.get(timeout=300)
                except Exception:
                    thu_muc = ""
                if thu_muc:
                    SETTINGS["thu_muc_luu"] = thu_muc
                    luu_thiet_lap(SETTINGS)
                    LOG.ghi("[THIET LAP] Thu muc luu moi: " + thu_muc)
                self._tra({"ok": bool(thu_muc), "thu_muc": thu_muc})
                return

            if duong == "/api/mo-nhat-ky":
                try:
                    if platform.system() == "Windows":
                        os.startfile(LOG_PATH)
                    elif platform.system() == "Darwin":
                        os.system('open "%s"' % LOG_PATH)
                    else:
                        os.system('xdg-open "%s"' % LOG_PATH)
                    self._tra({"ok": True})
                except Exception as e:
                    LOG.loi("Khong mo duoc file nhat ky", e)
                    self._tra({"ok": False, "loi": "Không mở được file nhật ký. Bạn mở thủ công tại: " + LOG_PATH})
                return

            self._tra({"loi": "Không có đường dẫn này."}, 404)
        except Exception as e:
            LOG.loi("Loi khi xu ly yeu cau GET " + str(self.path), e)
            self._tra({"ok": False, "loi": "Tool gặp lỗi bên trong. Xem chi tiết trong file nhật ký."}, 500)

    def do_POST(self):
        if not _yeu_cau_hop_le(self):
            self._tra({"loi": "Yeu cau khong den tu giao dien cua tool"}, 403)
            return
        try:
            duong = urllib.parse.urlparse(self.path).path
            do_dai = int(self.headers.get("Content-Length") or 0)
            p = json.loads(self.rfile.read(do_dai).decode("utf-8")) if do_dai else {}

            if duong == "/api/thoat":               # GD145: dong trang (beacon) / nut Thoat
                thoat_yeu_cau(p.get("id") if isinstance(p, dict) else "", bool(isinstance(p, dict) and p.get("ngay")))
                self._tra({"ok": True})
                return

            if duong.startswith("/api/hstk/"):      # GD54
                self._tra(hstk_api(duong, p))
                return

            if duong == "/api/nhap-excel-cong":          # GD359b: nhap Excel 'Xuat chi tiet' tai cong thue
                tep = str(p.get("duong") or "")
                if not tep:
                    tra_loi = queue.Queue()
                    HOP_THU_CHON_TEP.put(tra_loi)
                    try:
                        tep = tra_loi.get(timeout=300)
                    except Exception:
                        tep = ""
                if not tep:
                    self._tra({"ok": False, "huy": True}); return
                try:
                    self._tra(nhap_excel_cong(tep))
                except Exception as e:
                    LOG.loi("Loi nhap Excel cong thue", e)
                    self._tra({"ok": False, "loi": "Lỗi đọc tệp: %s" % e})
                return

            if duong == "/api/captcha-mtt-gui":          # GD359: nguoi dung go captcha / bo qua HD may tinh tien
                if p.get("bo_qua_phien"):
                    CHO_CAPTCHA_MTT["bo_qua"] = True
                CHO_CAPTCHA_MTT["huy"] = bool(p.get("huy") or p.get("bo_qua_phien"))
                CHO_CAPTCHA_MTT["doi"] = bool(p.get("doi"))          # 26/11/2026 dot 2: «Lấy mã khác»
                CHO_CAPTCHA_MTT["cvalue"] = str(p.get("cvalue") or "").strip() or None
                CHO_CAPTCHA_MTT["cho"] = False          # dot 2: het cho NGAY (truoc day trang co the hoi lai va ve lai anh cu)
                _SU_KIEN_CAPTCHA_MTT.set()
                self._tra({"ok": True})
                return

            if duong == "/api/khoa-ban-le":         # GD109: khoa HD ban le theo cong ty
                cd = str(p.get("che_do") or "")
                if cd not in BL_CHE_DO:
                    self._tra({"ok": False, "loi": "Chế độ không hợp lệ."}); return
                if not UNESCO.get("bat"):
                    self._tra({"ok": False, "loi": "Khoá hóa đơn bán lẻ chỉ dùng khi mở tool từ phần mềm UNESCO (lưu theo từng công ty)."}); return
                if STATE["tai"]["dang_chay"]:
                    self._tra({"ok": False, "loi": "Tool đang tải dở. Đợi tải xong rồi đổi khoá."}); return
                if not bl_luu(cd):
                    self._tra({"ok": False, "loi": "Không lưu được (xem nhật ký)."}); return
                self._tra({"ok": True, "che_do": cd, "ten": BL_TEN[cd]})
                return

            if duong == "/api/dang-nhap":
                # Nho MST + mat khau ngay khi bam Dang nhap (ke ca khi captcha sai),
                # de lan sau / lan thu lai khong phai go lai mat khau.
                mst_dn = p.get("mst", "").strip()
                SETTINGS["mst"] = mst_dn
                SETTINGS["nho_dang_nhap"] = bool(p.get("nho", True))
                # GD29 - quy tac 17: chi nho MST, KHONG luu mat khau
                SETTINGS["mat_khau_ma_hoa"] = ""
                SETTINGS["tai_khoan"] = {}
                luu_thiet_lap(SETTINGS)
                ok, loi = dang_nhap(mst_dn, p.get("mat_khau", ""), p.get("captcha", "").strip())
                self._tra({"ok": ok, "loi": loi, "mst": mst_dn})
                return

            if duong == "/api/mtt-nho":          # 26/11/2026 dot 3: nguoi dung tick / bo tick «Tải cả hoá đơn máy tính tiền»
                d = mtt_nho_doc()
                if "tai" in p:
                    d["chon"] = "co" if p.get("tai") else "khong"
                    LOG.ghi("[MTT NHO] Nguoi dung chon: %s tai HD may tinh tien cho so nay." % ("CO" if p.get("tai") else "KHONG"))
                if "chi_mua" in p:          # dot 5: «Chỉ tải hoá đơn máy tính tiền MUA VÀO»
                    d["chi_mua"] = bool(p.get("chi_mua"))
                    LOG.ghi("[MTT NHO] HD may tinh tien: %s." % ("CHI MUA VAO" if d["chi_mua"] else "ca mua vao va ban ra"))
                _ghi_json(MTT_NHO_TEP, d)
                self._tra({"ok": True})
                return

            if duong == "/api/tra-cuu":
                if not p.get("giu_bo_qua_mtt"):          # dot 3: tu dong - da bam «Bỏ qua» o chieu truoc thi chieu sau khong hoi lai
                    CHO_CAPTCHA_MTT["bo_qua"] = False          # GD359
                if not STATE["token"]:
                    self._tra({"ok": False, "loi": "Bạn cần đăng nhập trước khi tìm kiếm."})
                    return
                loi_mst = unesco_loi_khac_mst()      # GD43
                if loi_mst:
                    unesco_bao_khac_mst(loi_mst)
                    self._tra({"ok": False, "loi": loi_mst}); return
                loai = p.get("loai")
                if loai is None:
                    loai = ["dt", "mtt"]
                loai = [k for k in ("dt", "mtt") if k in loai]
                if not loai:
                    self._tra({"ok": False, "loi": "Chưa chọn loại hóa đơn cần tra cứu. Tick vào “Hóa đơn điện tử” hoặc “Hóa đơn có mã khởi tạo từ máy tính tiền” ở Bước 3."})
                    return
                LOG.ghi("[TRA CUU] Loai hoa don duoc chon: " + ", ".join(loai))
                tb_k = khoa_mst_kiem()          # 18/11/2026: tien trinh khac cung MST dang goi cong -> khong tra song song
                if tb_k:
                    self._tra({"ok": False, "loi": tb_k}); return
                ket_qua = {"dt": [], "mtt": []}
                loi_cuoi = None
                for kind in loai:
                    p2 = dict(p); p2["kind"] = kind
                    rows, loi = tra_cuu(p2)
                    if loi:
                        loi_cuoi = "; ".join(TRA_CUU_CANH_BAO) or loi          # GD112: ngay nao chua lay duoc
                        LOG.ghi("[TRA CUU] Nhom %s bao loi: %s" % (kind, loi))
                    else:
                        ket_qua[kind] = rows
                        if kind == "mtt" and not TRA_CUU_CANH_BAO and not any(p.get(k) for k in ("mst_nguoi_mua", "ky_hieu", "so_hoa_don")):
                            mtt_nho_ghi(p.get("direction", "ban"), len(rows or []), p.get("tu_ngay"), p.get("den_ngay"))          # dot 3
                        if TRA_CUU_CANH_BAO:          # GD112: ngay chua lay duoc (cong qua tai)
                            ten = TEN_NHOM_HD.get((p.get("direction", "ban"), kind), kind)
                            loi_cuoi = "; ".join(([loi_cuoi] if loi_cuoi else []) + ["%s: %s" % (ten, x) for x in TRA_CUU_CANH_BAO])
                with STATE_LOCK:
                    STATE["ket_qua"] = ket_qua
                if not ket_qua["dt"] and not ket_qua["mtt"] and loi_cuoi:
                    self._tra({"ok": False, "loi": loi_cuoi})
                    return
                tt_pm, so_tai, dd = doc_trang_thai_phan_mem(), _doc_json("da-tai.json", {}), _doc_json("danh-dau.json", {})
                cb_th = th_canh_bao_tv(ket_qua["dt"] + ket_qua["mtt"])      # GD91
                if cb_th:
                    loi_cuoi = (loi_cuoi + " | " if loi_cuoi else "") + cb_th
                self._tra({"ok": True,
                           "dt": [gon(h, p.get("direction", "ban"), tt_pm, so_tai, dd) for h in ket_qua["dt"]],
                           "mtt": [gon(h, p.get("direction", "ban"), tt_pm, so_tai, dd) for h in ket_qua["mtt"]],
                           "co_trang_thai_pm": bool(tt_pm),
                           "canh_bao": loi_cuoi})
                return

            if duong == "/api/dong-bo":
                CHO_CAPTCHA_MTT["bo_qua"] = False          # GD359: moi lan dong bo hoi lai captcha HD may tinh tien
                if not STATE["token"]:
                    self._tra({"ok": False, "loi": "Bạn cần đăng nhập trước khi đồng bộ."}); return
                loi_mst = unesco_loi_khac_mst()      # GD43
                if loi_mst:
                    unesco_bao_khac_mst(loi_mst)
                    self._tra({"ok": False, "loi": loi_mst}); return
                if STATE["tai"]["dang_chay"]:
                    self._tra({"ok": False, "loi": "Tool đang tải dở. Đợi tải xong hoặc bấm Dừng lại."}); return
                ok_k, tb_k, khoa = khoa_mst_lay("cửa sổ Tải hoá đơn (đồng bộ)")          # 18/11/2026: khoa theo MST
                if not ok_k:
                    self._tra({"ok": False, "loi": tb_k}); return
                try:
                    tom_tat, canh_bao = dong_bo_chay(p)
                finally:
                    khoa_mst_tra(khoa)
                self._tra({"ok": True, "tom_tat": tom_tat, "canh_bao": canh_bao})
                return

            if duong == "/api/dong-bo-xem":
                # dua danh sach da dong bo cua MOT chieu len bang (va lam nguon cho Xem / Danh dau / Tai theo dong chon)
                huong = p.get("direction", "mua")
                nhom = (STATE.get("dong_bo") or {}).get(huong)
                if nhom is None:
                    self._tra({"ok": False, "loi": "Chưa đồng bộ."}); return
                with STATE_LOCK:
                    STATE["ket_qua"] = {"dt": list(nhom.get("dt", [])), "mtt": list(nhom.get("mtt", []))}
                tt_pm, so_tai, dd = doc_trang_thai_phan_mem(), _doc_json("da-tai.json", {}), _doc_json("danh-dau.json", {})
                self._tra({"ok": True,
                           "dt": [gon(h, huong, tt_pm, so_tai, dd) for h in STATE["ket_qua"]["dt"]],
                           "mtt": [gon(h, huong, tt_pm, so_tai, dd) for h in STATE["ket_qua"]["mtt"]],
                           "tom_tat": dong_bo_tom_tat()})
                return

            if duong == "/api/tai-lai-loi":          # 18/11/2026: tai lai dung cac HD loi cua lan tai truoc
                if STATE["tai"]["dang_chay"]:
                    self._tra({"ok": False, "loi": "Tool đang tải dở. Đợi tải xong hoặc bấm Dừng lại."}); return
                loi_mst = unesco_loi_khac_mst()
                if loi_mst:
                    unesco_bao_khac_mst(loi_mst)
                    self._tra({"ok": False, "loi": loi_mst}); return
                tb_k = khoa_mst_kiem()
                if tb_k:
                    self._tra({"ok": False, "loi": tb_k}); return
                with STATE_LOCK:
                    ban = STATE["tai"]["dang_chay"]
                    if not ban:
                        STATE["tai"]["dang_chay"] = True
                if ban:
                    self._tra({"ok": False, "loi": "Tool đang tải dở. Đợi tải xong hoặc bấm Dừng lại."}); return
                tong = 0
                try:
                    tong = tai_lai_loi()
                finally:
                    if not tong:
                        with STATE_LOCK:
                            STATE["tai"]["dang_chay"] = False
                if not tong:
                    self._tra({"ok": False, "loi": "Không còn hóa đơn lỗi nào của lần tải trước để tải lại."}); return
                self._tra({"ok": True, "tong": tong})
                return

            if duong == "/api/tai-dong-bo":
                if STATE["tai"]["dang_chay"]:
                    self._tra({"ok": False, "loi": "Tool đang tải dở. Đợi tải xong hoặc bấm Dừng lại."}); return
                if not STATE.get("dong_bo"):
                    self._tra({"ok": False, "loi": "Chưa đồng bộ. Chọn kỳ rồi bấm “Đồng bộ hóa đơn” trước."}); return
                tb_k = khoa_mst_kiem()          # 18/11/2026: khoa theo MST
                if tb_k:
                    self._tra({"ok": False, "loi": tb_k}); return
                thu_muc = SETTINGS.get("thu_muc_luu", "")
                if not thu_muc or not os.path.isdir(thu_muc):
                    self._tra({"ok": False, "loi": "Chưa chọn thư mục lưu, hoặc thư mục đã bị xóa."}); return
                dd0 = p.get("dinh_dang") or ["xml"]
                with STATE_LOCK:        # GD109: kiem + dat trong CUNG mot khoa
                    ban = STATE["tai"]["dang_chay"]
                    if not ban:
                        STATE["tai"]["dang_chay"] = True
                if ban:
                    self._tra({"ok": False, "loi": "Tool đang tải dở. Đợi tải xong hoặc bấm Dừng lại."}); return
                tong = 0
                try:
                    tong = dong_bo_tai(thu_muc, [d for d in ("xml", "pdf") if d in dd0], "excel" in dd0)          # GD112b: + HD ban le tung to
                finally:
                    if not tong:
                        with STATE_LOCK:
                            STATE["tai"]["dang_chay"] = False
                self._tra({"ok": True, "tong": tong, "khong_co_moi": tong == 0, "tom_tat": dong_bo_tom_tat()})
                return

            if duong == "/api/danh-dau":
                kind = p.get("kind", "dt")
                nguon = STATE["ket_qua"].get(kind, [])
                chon = [nguon[i] for i in p.get("chi_so", []) if isinstance(i, int) and 0 <= i < len(nguon)]
                if not chon:
                    self._tra({"ok": False, "loi": "Chưa chọn hóa đơn nào để đánh dấu."}); return
                if p.get("direction") != "mua":
                    self._tra({"ok": False, "loi": "Chỉ đánh dấu Chi phí / NVL / Hàng hoá cho hóa đơn MUA VÀO."}); return
                tt_pm = doc_trang_thai_phan_mem()
                khoa_ok = [khoa_cua(h) for h in chon if tt_pm.get(khoa_cua(h)) is not True]
                bo_qua = len(chon) - len(khoa_ok)
                try:
                    n, tep = danh_dau_luu(khoa_ok, p.get("loai", ""))
                except Exception as e:
                    LOG.loi("Loi khi danh dau", e)
                    self._tra({"ok": False, "loi": str(e)}); return
                self._tra({"ok": True, "so": n, "bo_qua": bo_qua, "da_gui_pm": bool(tep)})
                return

            if duong == "/api/xem":
                kind = p.get("kind", "dt")
                nguon = STATE["ket_qua"].get(kind, [])
                i = p.get("i", -1)
                if not (isinstance(i, int) and 0 <= i < len(nguon)):
                    self._tra({"ok": False, "loi": "Không tìm thấy hóa đơn."}); return
                try:
                    self._tra(xem_hoa_don(nguon[i], kind, p.get("direction", "ban")))
                except Exception as e:
                    LOG.loi("Loi khi xem hoa don", e)
                    self._tra({"ok": False, "loi": "Không đọc được hóa đơn: " + str(e)[:200]})
                return

            if duong == "/api/mo-tep":
                tep = str(p.get("tep") or "")
                hop_le = tep_duoc_mo(tep)
                if not hop_le:
                    self._tra({"ok": False, "loi": "Không mở được file này."}); return
                try:
                    os.startfile(tep)
                    self._tra({"ok": True})
                except Exception as e:
                    self._tra({"ok": False, "loi": str(e)[:200]})
                return

            if duong == "/api/goi-nho-luu":
                ok, loi = goi_nho_luu(p.get("nhan"), p.get("mst"))
                self._tra({"ok": ok, "loi": loi, "goi_nho": goi_nho_ds()})
                return

            if duong == "/api/goi-nho-xoa":
                goi_nho_xoa(p.get("mst"))
                self._tra({"ok": True, "goi_nho": goi_nho_ds()})
                return

            if duong == "/api/goi-nho-chon":
                mst = re.sub(r"[^0-9\-]", "", str(p.get("mst") or ""))
                if UNESCO.get("bat") and UNESCO.get("mst") and mst != UNESCO["mst"]:
                    self._tra({"ok": False, "loi": "Đang chạy cho bộ sổ MST %s của phần mềm UNESCO nên không đổi sang MST khác được." % UNESCO["mst"]})
                    return
                if CHROME["trang_thai"] in ("dang_cho", "da_dang_nhap") and mst != (SETTINGS.get("mst") or ""):
                    self._tra({"ok": False, "loi": "Chrome đang mở cho MST khác. Đóng cửa sổ Chrome đó và mở lại tool để đổi tài khoản."})
                    return
                SETTINGS["mst"] = mst
                luu_thiet_lap(SETTINGS)
                self._tra({"ok": True, "mst": mst})
                return

            if duong == "/api/tai":
                if STATE["tai"]["dang_chay"]:
                    self._tra({"ok": False, "loi": "Tool đang tải dở. Đợi tải xong hoặc bấm Dừng lại."})
                    return
                loi_mst = unesco_loi_khac_mst()      # GD43
                if loi_mst:
                    unesco_bao_khac_mst(loi_mst)
                    self._tra({"ok": False, "loi": loi_mst}); return
                tb_k = khoa_mst_kiem()          # 18/11/2026: khoa theo MST (chay_tai lay khoa that)
                if tb_k:
                    self._tra({"ok": False, "loi": tb_k}); return
                thu_muc = SETTINGS.get("thu_muc_luu", "")
                if not thu_muc or not os.path.isdir(thu_muc):
                    self._tra({"ok": False, "loi": "Chưa chọn thư mục lưu, hoặc thư mục đã bị xóa. Bấm “Chọn thư mục lưu” rồi thử lại."})
                    return
                dinh_dang = p.get("dinh_dang")
                if dinh_dang is None:
                    dinh_dang = ["xml"]
                lam_excel = "excel" in dinh_dang
                dinh_dang = [d for d in ("xml", "pdf") if d in dinh_dang]
                if not dinh_dang and not lam_excel:
                    self._tra({"ok": False, "loi": "Chưa chọn việc cần làm. Tick vào “File XML”, “File PDF” hoặc “Gộp danh mục và tải file Excel” rồi thử lại."})
                    return
                if "pdf" in dinh_dang and not tim_chrome():
                    self._tra({"ok": False, "loi": "Máy chưa cài Google Chrome nên tool không tạo được file PDF. Cài Chrome rồi thử lại, hoặc bỏ tick “File PDF” để chỉ tải XML."})
                    return
                SETTINGS["dinh_dang"] = dinh_dang + (["excel"] if lam_excel else [])
                luu_thiet_lap(SETTINGS)
                kind = p.get("kind", "dt")
                direction = p.get("direction", "ban")
                chi_so = p.get("chi_so", [])
                nguon = STATE["ket_qua"].get(kind, [])
                danh_sach = [nguon[i] for i in chi_so if 0 <= i < len(nguon)]
                if not danh_sach:
                    self._tra({"ok": False, "loi": "Chưa chọn hóa đơn nào để tải."})
                    return
                # GD29: chi tai hoa don MOI (chua co trong phan mem, chua tung tai)
                chi_moi = bool(p.get("chi_moi", SETTINGS.get("chi_tai_moi", True)))
                SETTINGS["chi_tai_moi"] = chi_moi
                if chi_moi:
                    truoc = len(danh_sach)
                    danh_sach = loc_hoa_don_moi(danh_sach, doc_trang_thai_phan_mem(), _doc_json("da-tai.json", {}))
                    LOG.ghi("[TAI] Chi tai hoa don moi: %d / %d hoa don da chon la moi." % (len(danh_sach), truoc))
                    if not danh_sach:
                        luu_thiet_lap(SETTINGS)
                        with STATE_LOCK:
                            if not STATE["tai"]["dang_chay"]:       # GD109: luong tai khac dang chay -> khong ghi de trang thai
                                STATE["tai"].update({"dang_chay": False, "tong": 0, "xong": 0, "ok": 0, "bo_qua": 0, "loi": 0,
                                                     "hien_tai": "", "ket_thuc": "Không có hóa đơn mới: %d hóa đơn đã chọn đều đã có trong phần mềm hoặc đã tải trước đó." % truoc})
                        self._tra({"ok": True, "tong": 0, "khong_co_moi": True, "da_chon": truoc})
                        return
                with STATE_LOCK:        # GD109: kiem + dat trong CUNG mot khoa (2 lan bam cung luc chi 1 luong chay)
                    ban = STATE["tai"]["dang_chay"]
                    if not ban:
                        STATE["tai"]["dang_chay"] = True
                if ban:
                    self._tra({"ok": False, "loi": "Tool đang tải dở. Đợi tải xong hoặc bấm Dừng lại."})
                    return
                threading.Thread(target=chay_tai,
                                 args=(danh_sach, kind, direction, thu_muc, dinh_dang, lam_excel),
                                 kwargs={"xac_nhan": bool(p.get("xac_nhan"))},          # GD109: nut Dua HD da tai vao phan mem
                                 daemon=True).start()
                self._tra({"ok": True, "tong": len(danh_sach)})
                return

            if duong == "/api/lam-moi":         # GD94: HD da tai ve may nhung chua vao phan mem
                if STATE["tai"]["dang_chay"]:
                    self._tra({"ok": False, "loi": "Tool đang tải dở. Đợi tải xong hoặc bấm Dừng lại."}); return
                if not UNESCO.get("bat"):
                    self._tra({"ok": False, "loi": "Làm mới so hóa đơn đã tải với hóa đơn đã có trong phần mềm - chỉ dùng khi mở tool từ phần mềm UNESCO."}); return
                if not tai_chua_nhap_bat()["bat"]:
                    self._tra({"ok": False, "loi": "Phần mềm chưa ghi danh sách hóa đơn đã có (trang-thai-hd.txt, da-doc-ket-qua.txt). "
                                                   "Đóng tool, mở lại màn hình Tải hóa đơn từ phần mềm UNESCO (bản GĐ91 trở lên) rồi bấm Làm mới."}); return
                huong = "ban" if p.get("direction") == "ban" else "mua"
                loai = [k for k in ("dt", "mtt") if k in (p.get("loai") or ["dt", "mtt"])] or ["dt", "mtt"]
                try:
                    ket_qua, tom = lam_moi_chua_nhap(huong, str(p.get("tu_ngay") or ""), str(p.get("den_ngay") or ""), loai)
                except Exception as e:
                    LOG.loi("Loi khi Lam moi", e)
                    self._tra({"ok": False, "loi": "Lỗi khi làm mới: " + str(e)[:200]}); return
                with STATE_LOCK:
                    STATE["ket_qua"] = ket_qua
                tt_pm, so_tai, dd = doc_trang_thai_phan_mem(), _doc_json("da-tai.json", {}), _doc_json("danh-dau.json", {})
                self._tra({"ok": True, "tom_tat": tom,
                           "dt": [gon(h, huong, tt_pm, so_tai, dd) for h in ket_qua["dt"]],
                           "mtt": [gon(h, huong, tt_pm, so_tai, dd) for h in ket_qua["mtt"]]})
                return

            if duong == "/api/dk-yeu-cau":      # GD106: bang ke dinh khoan AI
                self._tra(dk_yeu_cau(p)); return
            if duong == "/api/dk-ket-qua":
                self._tra(dk_ket_qua(p)); return
            if duong == "/api/dk-sua":
                self._tra(dk_sua(p)); return
            if duong == "/api/dk-excel":
                self._tra(dk_excel(p)); return

            if duong == "/api/mo-excel":        # GD94: nut Mo file Excel
                tep = str(p.get("tep") or "") or excel_moi_nhat()
                if not tep:
                    self._tra({"ok": False, "loi": "Chưa có file Excel nào. Tích “Gộp danh mục và tải file Excel” ở Bước 4 rồi tải "
                                                   "(hoặc Tổng hợp HĐ bán lẻ) - tool tạo file Excel trong thư mục lưu."}); return
                if not tep_duoc_mo(tep):
                    self._tra({"ok": False, "loi": "Không mở được file này."}); return
                try:
                    os.startfile(tep)
                    self._tra({"ok": True, "ten": os.path.basename(tep)})
                except Exception as e:
                    self._tra({"ok": False, "loi": str(e)[:200]})
                return

            if duong == "/api/tong-hop-ban-le":        # GD91
                if STATE["tai"]["dang_chay"]:
                    self._tra({"ok": False, "loi": "Tool đang tải dở. Đợi tải xong hoặc bấm Dừng lại."}); return
                if p.get("direction", "ban") != "ban":
                    self._tra({"ok": False, "loi": "Tổng hợp hóa đơn bán lẻ chỉ dùng cho hóa đơn BÁN RA."}); return
                loi_mst = unesco_loi_khac_mst()
                if loi_mst:
                    unesco_bao_khac_mst(loi_mst)
                    self._tra({"ok": False, "loi": loi_mst}); return
                thu_muc = SETTINGS.get("thu_muc_luu", "")
                if not thu_muc or not os.path.isdir(thu_muc):
                    self._tra({"ok": False, "loi": "Chưa chọn thư mục lưu, hoặc thư mục đã bị xóa. Bấm “Chọn thư mục lưu” rồi thử lại."}); return
                try:
                    so_ngay = int(p.get("so_ngay") or 1)
                except Exception:
                    so_ngay = 1
                if so_ngay not in TH_SO_NGAY:
                    self._tra({"ok": False, "loi": "Cách gộp không hợp lệ."}); return
                pham_vi = "tat_ca" if p.get("pham_vi") == "tat_ca" else "ntd"
                kind = p.get("kind", "dt")
                nguon = STATE["ket_qua"].get(kind, [])
                danh_sach = [nguon[i] for i in p.get("chi_so", []) if isinstance(i, int) and 0 <= i < len(nguon)]
                if not danh_sach:
                    self._tra({"ok": False, "loi": "Chưa chọn hóa đơn nào để tổng hợp."}); return
                with STATE_LOCK:        # kiem + dat trong CUNG mot khoa: 2 yeu cau cung luc chi 1 cai chay
                    ban = STATE["tai"]["dang_chay"]
                    if not ban:
                        STATE["tai"].update({"dang_chay": True, "dung": False, "tong": len(danh_sach), "xong": 0, "ok": 0,
                                             "bo_qua": 0, "loi": 0, "khong_xml": 0, "hien_tai": "Đang kiểm tra chống trùng…",
                                             "ket_thuc": "", "tep_mo": ""})
                if ban:
                    self._tra({"ok": False, "loi": "Tool đang tải dở. Đợi tải xong hoặc bấm Dừng lại."}); return
                threading.Thread(target=chay_tong_hop_ban_le, args=(danh_sach, kind, thu_muc, so_ngay, pham_vi), daemon=True).start()
                self._tra({"ok": True, "tong": len(danh_sach)})
                return

            if duong == "/api/kiem-tra-trang-thai":
                if not STATE["token"]:
                    self._tra({"ok": False, "loi": "Bạn cần đăng nhập trước."}); return
                duong_ds = p.get("tep") or UNESCO["kiemtra"]
                tep, loi = unesco_kiem_tra_trang_thai(duong_ds)
                self._tra({"ok": tep is not None, "tep": tep, "loi": loi})
                return

            if duong == "/api/luu-khoa-ai":
                SETTINGS["anthropic_key"] = p.get("khoa", "").strip()
                if p.get("model"):
                    SETTINGS["anthropic_model"] = p.get("model").strip()
                luu_thiet_lap(SETTINGS)
                LOG.ghi("[AI] Da luu khoa API (%s)." % mask_tail(SETTINGS["anthropic_key"]))
                self._tra({"ok": True})
                return

            if duong == "/api/kiem-tra-ai":
                kq_dir = unesco_thu_muc("ket-qua") if UNESCO["bat"] else BASE_DIR
                tmp = os.path.join(kq_dir, "can_goi_ai_test.jsonl")   # GD63: VB6 bo qua can_goi_ai* khi nap hoa don
                with open(tmp, "w", encoding="utf-8") as f:
                    f.write(json.dumps({"khoa": "test", "stt_dong": 1, "ten_hang": "Giấy A4 Double A 80gsm", "dvt": "Ram",
                                        "don_gia": 65000, "ten_ncc": "CTY TNHH VPP", "ung_vien": []}, ensure_ascii=False) + "\n")
                duong_kq = unesco_goi_claude(tmp)
                so = 0
                try:
                    with open(duong_kq, "r", encoding="utf-8") as f:
                        so = sum(1 for l in f if l.strip())
                except Exception:
                    pass
                self._tra({"ok": so > 0, "loi": None if so > 0 else "Không nhận được gợi ý. Kiểm tra khóa API và mạng; xem nhật ký."})
                return

            if duong == "/api/dung":
                with STATE_LOCK:
                    STATE["tai"]["dung"] = True
                if CHO_CAPTCHA_MTT.get("cho"):          # 26/11/2026 dot 2: dang cho go ma HD may tinh tien -> Dung = bo qua phan nay, di tiep
                    CHO_CAPTCHA_MTT.update(bo_qua=True, huy=True, doi=False, cvalue=None, cho=False)
                    _SU_KIEN_CAPTCHA_MTT.set()
                    LOG.ghi("[CAPTCHA MTT] Bam Dung khi dang cho ma - bo qua HD may tinh tien luot nay.")
                LOG.ghi("[TAI] Nguoi dung bam Dung lai.")
                self._tra({"ok": True})
                return

            self._tra({"loi": "Không có đường dẫn này."}, 404)
        except Exception as e:
            LOG.loi("Loi khi xu ly yeu cau POST " + str(self.path), e)
            self._tra({"ok": False, "loi": "Tool gặp lỗi bên trong. Xem chi tiết trong file nhật ký."}, 500)


# ==========================================================================
#  GD29 - TRANG THAI TRONG PHAN MEM, SO DA TAI, DANH DAU LOAI HOA DON
# ==========================================================================
def _thu_muc_du_lieu():
    """Noi de so da-tai.json / danh-dau.json: thu muc cua khach (UNESCO) hoac canh tool."""
    return UNESCO["out"] if (UNESCO.get("bat") and UNESCO.get("out")) else BASE_DIR


def _doc_json(ten, mac_dinh):
    try:
        d = os.path.join(_thu_muc_du_lieu(), ten)
        if os.path.exists(d):
            with open(d, "r", encoding="utf-8-sig") as f:
                return json.load(f)
    except Exception as e:
        LOG.loi("Khong doc duoc " + ten, e)
    return mac_dinh


def _ghi_json(ten, du_lieu):
    try:
        d = os.path.join(_thu_muc_du_lieu(), ten)
        with open(d + ".tmp", "w", encoding="utf-8") as f:
            json.dump(du_lieu, f, ensure_ascii=False)
        os.replace(d + ".tmp", d)
        return True
    except Exception as e:
        LOG.loi("Khong ghi duoc " + ten, e)
        return False


# ==========================================================================
#  GD109 - KHOA HD BAN LE (ban ra, nguoi mua KHONG MST) theo tung cong ty (tep khoa-ban-le.json trong thu muc du lieu
#  cua cong ty). Anh Thang: HD ban le cho nguoi tieu dung tai ve tu vao AI tung to, chua kip tong hop.
#    tu_dong  : chuyen tung to ngay khi tai (nhu truoc GD109)
#    xac_nhan : tai ve chi luu tren may ('Da tai, chua vao PM'); vao phan mem khi nguoi dung bam Dua HD da tai vao phan mem
#    tong_hop : chi chung tu tong hop NGAY; tu gop cac ngay DA QUA ngay sau khi tai (ca hen gio), HD hom nay de lan sau
#  Chi chan o day (noi duy nhat gui HD tai ve sang phan mem). Tong hop ban le, nhap thu muc XML, kiem tra trang thai: khong doi.
# ==========================================================================
TEP_KHOA_BL = "khoa-ban-le.json"
BL_CHE_DO = ("tu_dong", "xac_nhan", "tong_hop")
BL_TEN = {"tu_dong": "Đưa từng tờ vào phần mềm", "xac_nhan": "Tải về, chờ duyệt", "tong_hop": "Gộp mỗi ngày thành 1 chứng từ"}     # GD112
BL_CHO_GOP = {}         # kind -> [dong tra cuu cong thue] HD ban le vua giu lai o che do tong_hop (tu gop sau lan tai)


def bl_che_do():
    d = _doc_json(TEP_KHOA_BL, {})
    v = str(d.get("che_do") or "") if isinstance(d, dict) else ""
    return v if v in BL_CHE_DO else "tu_dong"


def bl_luu(che_do):
    if che_do not in BL_CHE_DO:
        return False
    ok = _ghi_json(TEP_KHOA_BL, {"che_do": che_do, "luc": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                                 "may": _may_nay(), "mst": unesco_mst_so(UNESCO.get("mst"))})
    LOG.ghi("[BAN LE] Khoa HD ban le -> %s (%s)" % (che_do, "da luu" if ok else "LOI ghi"))
    return ok


def la_ban_le(d):
    """Dong JSONL: hoa don BAN RA, nguoi mua khong co MST (nguoi tieu dung)."""
    return d.get("huong") == "ban" and not unesco_mst_so(d.get("MSTNguoiMuaNguoiNhanHang"))


def bl_se_giu(direction, xac_nhan=False):
    """Khoa hien tai co giu HD ban le cua lan gui nay khong (chua xet tung HD)."""
    if direction != "ban" or not UNESCO.get("bat"):
        return False
    cd = bl_che_do()
    return cd == "tong_hop" or (cd == "xac_nhan" and not xac_nhan)


def bl_giu_duoc(k, ngay, c):
    """HD khoa k (ngay lap 'yyyy-mm-dd' gio VN) giu lai duoc: tool biet chac no se hien 'Da tai, chua vao PM' (Lam moi / Dua
    HD da tai vao phan mem / tu gop thay lai) - c = tai_chua_nhap_bat(). HD bang ke cho XML (GD108 ma 3) khong giu: XML cua no
    la de phan mem thay dong bang ke, khong phai nhap moi tung to."""
    if not c.get("bat") or k in BK_CHO_XML or k in c.get("tv", ()):
        return False
    ngay = str(ngay or "")[:10]
    return not c.get("tu") or (c["tu"] <= ngay <= c["den"])


def bl_loc_giu(dong, danh_sach, direction, kind, xac_nhan=False):
    """Bo dong HD ban le khoi tep gui phan mem theo khoa (HD van ghi so da-tai -> 'Da tai, chua vao PM', Lam moi thay).
    xac_nhan=True (nut Dua HD da tai vao phan mem): che do xac_nhan cho qua; che do tong_hop van giu (chi tong hop)."""
    if direction != "ban" or not UNESCO.get("bat") or not dong:
        return dong
    cd = bl_che_do()
    if cd == "tu_dong" or (cd == "xac_nhan" and xac_nhan):
        return dong
    c = tai_chua_nhap_bat()
    le = {d.get("khoa"): d.get("NgayLap") for d in dong if la_ban_le(d)}
    giu = {k for k, ng in le.items() if bl_giu_duoc(k, ng, c)}
    khong = [k for k in le if k not in giu and k not in BK_CHO_XML]       # GD108 ma 3: XML thay bang ke - binh thuong
    if khong:
        with STATE_LOCK:
            STATE["tai"]["bl_khong_giu"] = STATE["tai"].get("bl_khong_giu", 0) + len(khong)
        LOG.ghi("[BAN LE] Khoa '%s' nhung %d HD ban le KHONG giu duoc (%s) - chuyen tung to nhu cu"
                % (cd, len(khong), "phan mem chua ghi trang-thai-hd.txt / da-doc-ket-qua.txt" if not c.get("bat")
                   else "ngoai nam tai chinh / tung nam trong chung tu tong hop"))
    if not giu:
        return dong
    with STATE_LOCK:
        STATE["tai"]["giu_bl"] = STATE["tai"].get("giu_bl", 0) + len(giu)
    if cd == "tong_hop":
        cong = {khoa_cua(h): h for h in (danh_sach or [])}
        BL_CHO_GOP.setdefault(kind, []).extend(cong[k] for k in sorted(giu) if k in cong)
    LOG.ghi("[BAN LE] Khoa '%s': giu lai %d HD ban le (nguoi mua khong MST), KHONG chuyen tung to sang phan mem"
            % (cd, len(giu)))
    return [d for d in dong if d.get("khoa") not in giu]


def bl_can_gop():
    return bool(UNESCO.get("bat")) and any(BL_CHO_GOP.values()) and bl_che_do() == "tong_hop"


def bl_tung_to_cu(ds):
    """GD112b - khoa 'Gop moi ngay thanh 1 chung tu': trong ds (dong cong thue BAN RA), cac HD ban le (nguoi mua khong MST)
    cua cong ty DA NAM TUNG TO trong phan mem - nhap truoc khi dat khoa, hoac chung tu tung to vua bi xoa - CHUA lap chung tu
    (trang-thai-hd.txt ma 0), khong nam trong chung tu tong hop con song, khong dang cho phan mem nhap, chua gui trong phien
    -> danh sach de TU GOP THAY (chay_tong_hop_ban_le: phan mem xoa dong HD le chua lap CT roi nhan chung tu BKBL theo ngay).
    Ma 3 (bang ke Excel cho XML) khong gop: XML cua no de thay dong bang ke. Khoa khac / khong chay tu UNESCO -> []."""
    if not ds or not UNESCO.get("bat") or bl_che_do() != "tong_hop":
        return []
    nc = th_ngu_canh()
    if not nc["co_da_doc"] or not nc["goc"]:
        return []
    cty = unesco_mst_so(UNESCO.get("mst"))
    ra, da = [], set()
    for hd in ds:
        k = khoa_cua(hd)
        if k in da or nc["goc"].get(k) != "0" or k in nc["cho"] or k in TH_DA_GUI or th_tv_bi_khoa(k, nc):
            continue
        if unesco_mst_so(hd.get("nmmst")) or (cty and unesco_mst_so(hd.get("nbmst")) != cty):
            continue
        da.add(k)
        ra.append(hd)
    return ra


def bl_tung_to_dong_bo():
    """GD112b: {kind: [HD ban le tung to cu]} cua danh sach BAN RA da dong bo (rong neu khoa khac / loi doc)."""
    kq = {}
    try:
        for kind in ("dt", "mtt"):
            ds = bl_tung_to_cu(((STATE.get("dong_bo") or {}).get("ban") or {}).get(kind, []))
            if ds:
                kq[kind] = ds
    except Exception as e:
        LOG.loi("Loi khi tim HD ban le dang nam tung to trong phan mem", e)
        return {}
    return kq


def bl_tb_giu(n, khong=0):
    """Cau bao HD ban le da giu lai trong lan tai (khong = so HD ban le khoa ma khong giu duoc, van chuyen tung to)."""
    cd = bl_che_do()
    if cd == "tu_dong":
        return ""
    if khong:
        return bl_tb_giu(n) + (" — CHÚ Ý: %d HĐ bán lẻ VẪN chuyển từng tờ dù đang chọn %s: tool không chắc giữ được (phần mềm chưa "
                               "ghi danh sách hóa đơn đã có - mở lại Tải hóa đơn từ màn hình AI; hoặc hóa đơn ngoài năm tài chính "
                               "của bộ sổ / từng nằm trong chứng từ tổng hợp). Xem nhật ký." % (khong, BL_TEN.get(cd, cd)))
    if not n:
        return ""
    if cd == "xac_nhan":
        return (" — Giữ lại %d HĐ bán lẻ (người mua không MST) CHƯA chuyển sang phần mềm (đang chọn Tải về, chờ duyệt): bấm Làm mới → "
                "Đưa HĐ đã tải vào phần mềm khi muốn đưa vào (từng tờ, hoặc tích Tổng hợp hóa đơn bán lẻ để gộp)." % n)
    return " — %d HĐ bán lẻ (người mua không MST) không chuyển từng tờ (đang chọn Gộp mỗi ngày thành 1 chứng từ)." % n


def bl_tu_gop(thu_muc):
    """GD109 - khoa 'Chi tong hop ngay': sau lan tai, tu tong hop 1 NGAY / nguoi tieu dung cac HD ban le vua giu lai co ngay
    lap (gio VN) TRUOC hom nay; HD hom nay giu lai (ngay chua het - lan tai sau gop). Chay trong luong tai (STATE dang_chay
    van bat). Tra ve cau bao (rong neu khong gop gi)."""
    cho = {k: list(v) for k, v in BL_CHO_GOP.items() if v}
    BL_CHO_GOP.clear()
    if not cho or bl_che_do() != "tong_hop" or not UNESCO.get("bat"):
        return ""
    hom_nay = datetime.now().date()
    tb = []
    for kind in ("dt", "mtt"):
        ds, da, con = [], set(), 0
        for h in cho.get(kind, []):
            k = khoa_cua(h)
            if k in da:
                continue
            da.add(k)
            d = th_ngay(ngay_vn(h.get("tdlap")))
            if d is None or d < hom_nay:            # khong doc duoc ngay: tong hop nhap rieng (khong giu mai)
                ds.append(h)
            else:
                con += 1
        ten = "HĐ điện tử" if kind == "dt" else "HĐ máy tính tiền"
        if ds:
            with STATE_LOCK:
                if STATE["tai"].get("dung") or STATE["tai"].get("bi_chan"):
                    break
                dem = {x: STATE["tai"].get(x, 0) for x in ("tong", "xong", "ok", "bo_qua", "loi", "khong_xml")}
                tep_ds = list(STATE["tai"].get("tep_ds") or [])
                STATE["tai"].update({"dang_chay": True, "tong": len(ds), "xong": 0, "ok": 0, "bo_qua": 0, "loi": 0,
                                     "khong_xml": 0, "ket_th": "",
                                     "hien_tai": "Tự tổng hợp ngày %d %s bán lẻ (Gộp mỗi ngày thành 1 chứng từ)…" % (len(ds), ten)})
            LOG.ghi("[BAN LE] Tu tong hop ngay %d HD ban le %s (ngay da qua), giu %d HD hom nay" % (len(ds), kind, con))
            try:
                chay_tong_hop_ban_le(ds, kind, thu_muc, 1, "ntd", giu_chay=True)
            finally:
                with STATE_LOCK:        # tra bo dem cua lan tai (giao dien / hoi dinh khoan AI theo so HD da tai)
                    STATE["tai"].update(dem)
                    mo = STATE["tai"].get("tep_mo") or ""
                    if mo and os.path.exists(mo) and mo not in tep_ds:
                        tep_ds.append(mo)
                    STATE["tai"]["tep_ds"] = tep_ds
            tb.append("TỰ TỔNG HỢP NGÀY %s: %s" % (ten, STATE["tai"].get("ket_th") or "xong"))
        if con:
            tb.append("%d %s bán lẻ ngày hôm nay giữ lại - gộp ở lần tải sau (hoặc bấm Tổng hợp HĐ bán lẻ)" % (con, ten))
    return " — ".join(tb)


BK_CHO_XML = set()      # GD108: khoa HD phan mem nap tu BANG KE EXCEL, chua co XML (ma 3) - tai XML de phan mem thay chi tiet


def doc_trang_thai_phan_mem():
    """GD91: nhu _doc_trang_thai_goc, them cac HD da nam trong chung tu tong hop ban le con song
    (trang thai theo chung tu tong hop) -> 'Chon hoa don moi' / 'Chi tai moi' khong lay lai chung."""
    try:
        nc = th_ngu_canh()
        tt = dict(nc["tt"])
        for k in nc["tv"]:
            if k not in tt:
                pk = th_tv_bi_khoa(k, nc)
                if pk:
                    tt[k] = bool(tt.get(pk))
        return tt
    except Exception as e:
        LOG.loi("Khong doc duoc so tong hop ban le", e)
        return _doc_trang_thai_goc()


def _doc_trang_thai_goc():
    """trang-thai-hd.txt do phan mem UNESCO ghi truoc khi mo tool: '<khoa>\t<1|0|2>' moi dong.
    -> {khoa: True (da hach toan) / False (da co, chua hach toan)}. Khong co file -> {}."""
    return {k: v == "1" for k, v in _doc_trang_thai_ma().items()}


def _doc_trang_thai_ma():
    """GD94: trang-thai-hd.txt -> {khoa: ma}: '1' da hach toan; '0' da co, chua hach toan; '2' (phan mem GD94) da co, chua
    hach toan nhung KHOA - Bo qua / Can xem lai / lap tay / HD da bi thay the, huy / thanh vien chung tu tong hop."""
    kq = {}
    try:
        d = os.path.join(_thu_muc_du_lieu(), "trang-thai-hd.txt")
        if os.path.exists(d):
            with open(d, "r", encoding="utf-8-sig") as f:
                for dong in f:
                    dong = dong.rstrip("\r\n")
                    if "\t" in dong:
                        k, v = dong.rsplit("\t", 1)
                        if k.strip():
                            kq[k.strip()] = v.strip()
    except Exception as e:
        LOG.loi("Khong doc duoc trang-thai-hd.txt", e)
    BK_CHO_XML.clear()
    BK_CHO_XML.update(k for k, v in kq.items() if v == "3")       # GD108
    try:
        _th_don_da_gui(kq)          # GD116: HD / chung tu da gui trong phien nhung phan mem da xoa -> khong con 'da gui'
    except Exception as e:
        LOG.loi("Loi khi don danh sach da gui trong phien", e)
    return kq


def khoa_cua(hd):
    return unesco_khoa(hd.get("nbmst"), hd.get("khmshdon"), hd.get("khhdon"), hd.get("shdon"))


_TCN = {"moc": None, "kq": None}


def _bo_so_hien():
    """GD94: ten bo so (MDB) dang mo trong UNESCO - ghi vao so da-tai de khong lay HD cua bo so nam khac (cung thu muc)."""
    return os.path.normcase(os.path.basename(str(UNESCO.get("mdb") or ""))) if UNESCO.get("bat") else ""


def tai_chua_nhap_bat():
    """GD94: {'bat', 'tu', 'den', 'tv', 'mdb'}. bat = biet chac HD nao DA vao phan mem: chay tu UNESCO va phan mem da ghi
    trang-thai-hd.txt + da-doc-ket-qua.txt (luc mo tool). tu / den = nam tai chinh cua bo so (quy-tac-tool.json TuNgayTC /
    DenNgayTC; NamTC; phan mem chua Full Compile GD94: nam cua ky dang tai) -> HD ngoai nam tai chinh (nam o bo so khac cung
    thu muc) khong bi coi la 'chua vao phan mem'. tv = HD da tung nam trong chung tu tong hop (so tong-hop-ban-le.json):
    khong tu dua vao phan mem tung to (dung Tong hop / Lam moi)."""
    rong = {"bat": False, "tu": "", "den": "", "tv": set(), "mdb": ""}
    try:
        if not UNESCO.get("bat"):
            return rong
        d = _thu_muc_du_lieu()
        moc = [d, UNESCO.get("tu"), UNESCO.get("den"), UNESCO.get("mdb")]
        for ten in ("trang-thai-hd.txt", "da-doc-ket-qua.txt", "quy-tac-tool.json", TH_TEP_SO):
            try:
                st = os.stat(os.path.join(d, ten))
                moc.append((st.st_mtime_ns, st.st_size, st.st_ino))
            except OSError:
                moc.append(None)
        moc = tuple(moc)
        if _TCN["moc"] == moc:
            return _TCN["kq"]
        kq = dict(rong, bat=moc[4] is not None and moc[5] is not None, mdb=_bo_so_hien())
        if kq["bat"]:
            q = th_quy_tac()
            tu, den, n = str(q.get("TuNgayTC") or ""), str(q.get("DenNgayTC") or ""), str(q.get("NamTC") or "").strip()
            if th_ngay(tu) and th_ngay(den) and tu[:4] >= "2000" and den[:10] >= tu[:10]:
                kq["tu"], kq["den"] = tu[:10], den[:10]
            elif re.match(r"^\d{4}$", n) and n != "0000":
                kq["tu"], kq["den"] = n + "-01-01", n + "-12-31"
            else:
                nam = sorted(str(UNESCO.get(x))[:4] for x in ("tu", "den") if re.match(r"^\d{4}-", str(UNESCO.get(x) or "")))
                if nam:
                    kq["tu"], kq["den"] = nam[0] + "-01-01", nam[-1] + "-12-31"
            kq["tv"] = set(th_doc_so()["tv"])
        _TCN.update({"moc": moc, "kq": kq})
        return kq
    except Exception as e:
        LOG.loi("Khong xac dinh duoc HD da vao phan mem", e)
        return rong


def _tai_cung_bo(v, ngay, c):
    """GD94: HD da tai (muc v cua da-tai.json) thuoc bo so dang mo: cung ten bo so (neu so co ghi) va ngay lap trong nam tai
    chinh cua bo so."""
    if isinstance(v, dict) and v.get("mdb") and c["mdb"] and v["mdb"] != c["mdb"]:
        return False
    return not c["tu"] or (c["tu"] <= str(ngay or "")[:10] <= c["den"])


def trang_thai_dong(hd, tt_pm, so_tai):
    """-> 'ht' (da hach toan) / 'co' (da co trong phan mem, dang cho phan mem nhap, da gui trong phien - hoac da tai khi
    khong biet chac phan mem da co chua) / 'tai' (GD94: DA TAI ve may nhung CHUA vao phan mem - lan tai / tong hop truoc
    bi ngat giua chung; 'Chi tai HD moi' / 'Tai ve HD chua co' dua vao phan mem tu file tren may, khong tai lai) / 'moi'."""
    k = khoa_cua(hd)
    if tt_pm.get(k) is True:
        return "ht"
    if k in BK_CHO_XML and k not in TH_DA_GUI:
        return "moi"        # GD108: phan mem dang co HD nay tu BANG KE EXCEL (chua lap chung tu) -> tai XML de thay bang chi tiet
    if k in tt_pm or k in TH_DA_GUI:
        return "co"
    if k in so_tai:
        c = tai_chua_nhap_bat()
        if (c["bat"] and k not in c["tv"] and unesco_hd_thuoc_cty(hd.get("nbmst"), hd.get("nmmst")) and
                _tai_cung_bo(so_tai.get(k), ngay_vn(hd.get("tdlap")), c)):
            return "tai"
        return "co"
    return "moi"


def trang_thai_hien(hd, tt_pm, so_tai):
    """GD94: nhu trang_thai_dong; dong Lam moi (file tren may, nguoi dung chu dong xem) chua vao phan mem -> luon 'tai'."""
    pm = trang_thai_dong(hd, tt_pm, so_tai)
    if hd.get("_tu_may") and pm in ("moi", "co"):
        k = khoa_cua(hd)
        if k not in tt_pm and k not in TH_DA_GUI:
            pm = "tai"
    return pm


def loc_hoa_don_moi(danh_sach, tt_pm, so_tai):
    """HD can tai / dua vao phan mem: 'moi' + 'tai' (GD94: da tai ma chua vao phan mem - doc file tren may, khong tai lai)."""
    return [hd for hd in danh_sach if trang_thai_hien(hd, tt_pm, so_tai) in ("moi", "tai")]


LOAI_DANH_DAU = ("CP", "NVL", "HH", "")


def danh_dau_luu(cac_khoa, loai):
    """Ghi danh-dau.json (de giao dien nho) va, khi chay cho UNESCO, danhdau_<MST>_<ts>.jsonl
    trong ket-qua de phan mem nhap. Tra ve (so hoa don, duong dan jsonl hoac None)."""
    loai = (loai or "").upper()
    if loai not in LOAI_DANH_DAU:
        raise ValueError("Loai danh dau khong hop le: " + loai)
    dd = _doc_json("danh-dau.json", {})
    for k in cac_khoa:
        if loai:
            dd[k] = loai
        else:
            dd.pop(k, None)
    _ghi_json("danh-dau.json", dd)
    duong = None
    if UNESCO.get("bat") and cac_khoa:
        kq = unesco_thu_muc("ket-qua")
        ts = datetime.now().strftime("%Y%m%d%H%M%S%f")[:17]
        duong = os.path.join(kq, "danhdau_%s_%s.jsonl" % (UNESCO["mst"] or "CHUNG", ts))
        with open(duong + ".tmp", "w", encoding="utf-8") as f:
            for k in cac_khoa:
                f.write(json.dumps({"khoa": k, "loai": loai}, ensure_ascii=False) + "\n")
        os.replace(duong + ".tmp", duong)      # doi ten sau khi ghi xong -> VB6 khong doc file dang ghi do
    LOG.ghi("[DANH DAU] %d hoa don -> %s" % (len(cac_khoa), loai or "(bo danh dau)"))
    return len(cac_khoa), duong


def so_tai_ghi(hd, direction, thu_muc, khong_xml=False):
    """Ghi nhan mot hoa don da tai xong vao da-tai.json (khoa -> noi luu XML).
    khong_xml=True: cong thue khong giu XML goc - van ghi so de khong bi coi la 'moi' mai mai."""
    try:
        so = _doc_json("da-tai.json", {})
        so[khoa_cua(hd)] = {"xml": "" if khong_xml else (tim_xml_co_san(hd, direction, thu_muc, so) or
                                                        os.path.join(thu_muc_theo_ky(thu_muc, hd), ten_file(hd, direction) + ".xml")),
                            "mdb": _bo_so_hien(),       # GD94: bo so dang mo (HD cua bo so nam khac khong bi coi la chua vao)
                            "luc": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
        if khong_xml:
            so[khoa_cua(hd)]["khong_xml"] = True
        _ghi_json("da-tai.json", so)
    except Exception as e:
        LOG.loi("Khong ghi duoc so da tai", e)


def tep_duoc_mo(tep):
    """Chi mo file .xml / .pdf nam trong thu muc luu hoa don cua tool (khong mo file bat ky)."""
    try:
        la_th = bool(TEN_EXCEL_TOOL.match(os.path.basename(tep or "")))   # GD91 tong hop ban le; GD94 bang ke / mau UNESCO
        if not tep or not (tep.lower().endswith((".xml", ".pdf")) or la_th) or not os.path.exists(tep):
            return False
        t = os.path.normcase(os.path.abspath(tep))
        goc = [SETTINGS.get("thu_muc_luu", ""), UNESCO.get("luu") or "", UNESCO.get("out") or ""]
        # GD30: hoa don nam o thu muc thang lap cua no -> cho phep ca thu muc cong ty (cha cua <yyyy-mm>)
        for g0 in list(goc[:2]):
            g1 = (g0 or "").rstrip("\\/")
            if g1 and re.match(r"^\d{4}-\d{2}$", os.path.basename(g1)):
                goc.append(os.path.dirname(g1))
        goc += [os.path.dirname((v or {}).get("xml", "")) for v in _doc_json("da-tai.json", {}).values()]
        for g in goc:
            if g and t.startswith(os.path.normcase(os.path.abspath(g)) + os.sep):
                return True
    except Exception:
        pass
    return False


TEN_EXCEL_TOOL = re.compile(r"^(Bang-ke-hoa-don_|MUAVAO_|BANRA_|TONG_HOP_BAN_LE_|BANG_KE_DINH_KHOAN_).*\.xlsx$", re.I)      # GD94; GD106


def excel_moi_nhat():
    """GD94 - nut 'Mo file Excel': file Excel cua lan tai / tong hop vua xong; chua co thi file Excel tool tao moi nhat
    trong thu muc luu (va cac thu muc thang yyyy-mm canh no). '' neu chua co."""
    for x in list(STATE["tai"].get("tep_ds") or []) + [STATE["tai"].get("tep_mo") or ""]:
        if x and os.path.isfile(x):
            return x
    g = (SETTINGS.get("thu_muc_luu") or "").rstrip("\\/")
    goc = [g] if g else []
    if g and re.match(r"^\d{4}-\d{2}$", os.path.basename(g)):
        cha = os.path.dirname(g)
        try:
            goc = [os.path.join(cha, x) for x in os.listdir(cha) if re.match(r"^\d{4}-\d{2}$", x)] + [cha]
        except Exception:
            pass
    tot, moc = "", -1.0
    for d in goc:
        try:
            for ten in os.listdir(d):
                if TEN_EXCEL_TOOL.match(ten):
                    p = os.path.join(d, ten)
                    m = os.path.getmtime(p)
                    if m > moc:
                        tot, moc = p, m
        except Exception:
            pass
    return tot


_LM_NHO = {}        # GD94: duong XML -> ((mtime, size), tom tat) - bam Lam moi nhieu lan khong doc lai


def _lm_doc_xml(duong):
    try:
        st = os.stat(duong)
    except Exception:
        return None
    moc = (st.st_mtime, st.st_size)
    nho = _LM_NHO.get(duong)
    if nho and nho[0] == moc:
        return nho[1]
    x = doc_xml_co_san(duong, os.path.basename(duong))
    _LM_NHO[duong] = (moc, x)
    return x


def _lm_thu_muc_quet(tu, den):
    """Thu muc chua XML da tai co the co HD trong [tu, den]: thu muc luu; dang ...\\<yyyy-mm> thi cac thu muc thang tu
    (thang truoc tu) toi den (ten cu truoc GD94 theo ngay UTC: HD ngay 1 nam o thu muc thang truoc)."""
    g = (SETTINGS.get("thu_muc_luu") or UNESCO.get("luu") or "").rstrip("\\/")
    if not g:
        return []
    if not re.match(r"^\d{4}-\d{2}$", os.path.basename(g)):
        return [g] if os.path.isdir(g) else []
    cha = os.path.dirname(g)
    d1, d2 = th_ngay(tu), th_ngay(den)
    if d1 is None or d2 is None or d2 < d1:
        return [g] if os.path.isdir(g) else []
    ra, cur = [], (d1.replace(day=1) - timedelta(days=1)).replace(day=1)
    while cur <= d2 and len(ra) < 40:
        p = os.path.join(cha, cur.strftime("%Y-%m"))
        if os.path.isdir(p):
            ra.append(p)
        cur = (cur + timedelta(days=32)).replace(day=1)
    return ra


def lam_moi_chua_nhap(direction, tu, den, loai):
    """GD94 - nut Lam moi: HD DA TAI ve may (so da-tai.json + file XML trong thu muc luu - ke ca lan tai / tong hop bi
    ngat giua chung chua kip ghi so) ma CHUA vao phan mem, ngay lap trong [tu, den], chieu direction. KHONG goi mang.
    Tra ve ({"dt": [...], "mtt": [...]} dang dong tra cuu (them '_xml', '_tu_may'), tom tat)."""
    tt = doc_trang_thai_phan_mem()
    so_tai = _so_tai_nhanh()
    c = tai_chua_nhap_bat()
    mst = unesco_mst_so(UNESCO.get("mst") or STATE.get("mst") or SETTINGS.get("mst"))
    d1, d2 = th_ngay(tu), th_ngay(den)
    kq, da_co = {"dt": [], "mtt": []}, set()
    tom = {"so": 0, "khong_xml": 0, "nam_tc": [c["tu"], c["den"]]}

    def chua_vao(k):
        v = so_tai.get(k)
        khac_bo = isinstance(v, dict) and v.get("mdb") and c["mdb"] and v["mdb"] != c["mdb"]
        return k not in tt and k not in TH_DA_GUI and not khac_bo

    def hop_ngay(ngay):
        n = th_ngay(ngay)
        return (n is not None and (d1 is None or n >= d1) and (d2 is None or n <= d2) and
                (not c["tu"] or c["tu"] <= str(ngay)[:10] <= c["den"]))

    # 1. dong dong bo cua chieu nay (du du lieu cong thue: trang thai HD...) co file tren may
    nhom = (STATE.get("dong_bo") or {}).get(direction) or {}
    for kind in ("dt", "mtt"):
        for hd in nhom.get(kind, []):
            k = khoa_cua(hd)
            if kind not in loai or k in da_co or not chua_vao(k) or not hop_ngay(ngay_vn(hd.get("tdlap"))):
                continue
            p = tim_xml_co_san(hd, direction, SETTINGS.get("thu_muc_luu", ""), so_tai)
            v = so_tai.get(k)
            if p:
                hd["_xml"] = p
            elif not (isinstance(v, dict) and v.get("khong_xml")):
                continue
            kq[kind].append(hd)
            da_co.add(k)
    # 2. file XML: so da-tai.json + quet thu muc luu
    ung = {}
    for k, v in so_tai.items():
        if k in da_co or not chua_vao(k) or not isinstance(v, dict):
            continue
        p = str(v.get("xml") or "")
        if p and os.path.isfile(p):
            ung.setdefault(os.path.normcase(os.path.abspath(p)), p)
        elif v.get("khong_xml"):
            tom["khong_xml"] += 1
    co_roi = set()          # HD BAN RA da co (khoa co MST cong ty) -> khoi doc file cung ky hieu + so (HD mua: doc het)
    if direction == "ban" and mst:
        for k in list(tt) + list(TH_DA_GUI):
            x = str(k).split("|")
            if len(x) == 4 and unesco_mst_so(x[0]) == mst:
                co_roi.add((x[2].strip().upper(), unesco_so_hd(x[3])))
    tu_ten = (d1 - timedelta(days=1)).strftime("%Y%m%d") if d1 else ""
    den_ten = d2.strftime("%Y%m%d") if d2 else "99999999"
    for thu in _lm_thu_muc_quet(tu, den):
        try:
            ds = os.listdir(thu)
        except Exception:
            continue
        for ten in ds:
            if not ten.lower().endswith(".xml"):
                continue
            m = re.match(r"^(\d{8})_([A-Za-z0-9]+)_(\d+)", ten)
            if m:
                if not (tu_ten <= m.group(1) <= den_ten):
                    continue        # ten GD94 theo ngay VN, ten cu som hon 1 ngay -> nhan [tu - 1, den]
                if (m.group(2).upper(), unesco_so_hd(m.group(3))) in co_roi:
                    continue        # da co trong phan mem (cung ky hieu + so) - khoi doc file
            p = os.path.join(thu, ten)
            ung.setdefault(os.path.normcase(os.path.abspath(p)), p)
    for p in sorted(ung.values()):
        x = _lm_doc_xml(p)
        if not x:
            continue
        k = unesco_khoa(x.get("nban_mst"), x.get("mau_so"), x.get("ky_hieu"), x.get("so_hd"))
        if k in da_co or not chua_vao(k) or not unesco_hd_thuoc_cty(x.get("nban_mst"), x.get("nmua_mst")):
            continue
        huong = "ban" if (mst and unesco_mst_so(x.get("nban_mst")) == mst) else "mua"
        ngay = str(x.get("ngay_lap") or "")[:10]
        kh = str(x.get("ky_hieu") or "")
        kind = "mtt" if len(kh) >= 4 and kh[3].upper() == "M" else "dt"
        if huong != direction or kind not in loai or not hop_ngay(ngay):
            continue
        kq[kind].append({"nbmst": x.get("nban_mst") or "", "khmshdon": x.get("mau_so") or "", "khhdon": kh,
                         "shdon": x.get("so_hd") or "", "tdlap": ngay, "nbten": x.get("nban_ten") or "",
                         "nbdchi": x.get("nban_dchi") or "", "nmten": _ten_nguoi_mua(x.get("nmua_ten"), x.get("nmua_nguoi")),
                         "nmmst": x.get("nmua_mst") or "", "nmdchi": x.get("nmua_dchi") or "",
                         "tgtcthue": x.get("chua_thue") or 0, "tgtthue": x.get("tien_thue") or 0,
                         "tgtttbso": x.get("thanh_toan") or 0, "mhdon": x.get("mccqt") or "", "tthai": "", "ttxly": "",
                         "_xml": p, "_tu_may": True})
        da_co.add(k)
    for kind in kq:
        kq[kind].sort(key=lambda h: (ngay_vn(h.get("tdlap")), str(h.get("khhdon") or ""), _th_so_sx(unesco_so_hd(h.get("shdon")))))
    tom["so"] = len(kq["dt"]) + len(kq["mtt"])
    tom["dt"], tom["mtt"] = len(kq["dt"]), len(kq["mtt"])
    LOG.ghi("[LAM MOI] %s %s -> %s: %d HD da tai chua vao phan mem (dt %d, mtt %d), %d HD khong XML goc chua vao (can dong bo)"
            % (direction, tu, den, tom["so"], tom["dt"], tom["mtt"], tom["khong_xml"]))
    return kq, tom


def xem_hoa_don(hd, kind, direction):
    """Du lieu de hien hop 'Xem': uu tien XML da tai, khong co thi hoi chi tiet tu cong thue."""
    so = _doc_json("da-tai.json", {})
    ung_vien = [os.path.join(thu_muc_theo_ky(SETTINGS.get("thu_muc_luu", "") or "", hd), ten_file(hd, direction) + ".xml"),
                os.path.join(SETTINGS.get("thu_muc_luu", "") or "", ten_file(hd, direction) + ".xml"),
                (so.get(khoa_cua(hd)) or {}).get("xml", "")]
    dong, nguon, tep = None, "", ""
    for d in ung_vien:
        if d and os.path.exists(d):
            noi_dung = doc_xml_co_san(d, os.path.basename(d))
            if noi_dung is not None:
                dong, nguon, tep = unesco_dong_tu_xml(noi_dung, direction, kind, hd, d), "XML đã tải", d
                break
    if dong is None:
        ct = unesco_chi_tiet_tu_cong(hd, kind)
        if ct:
            dong, nguon = unesco_dong_tu_chi_tiet(hd, ct, direction, kind), "Chi tiết từ cổng thuế"
        else:
            dong, nguon = unesco_dong_tu_cong(hd, direction, kind), "Dòng tổng từ kết quả tra cứu (chưa có chi tiết)"
    dau = dong[0] if dong else {}
    return {"ok": True, "nguon": nguon, "tep": tep, "co_pdf": bool(tep) and os.path.exists(tep[:-4] + ".pdf"),
            "dau": {k: dau.get(k, "") for k in ("KyHieuMauSo", "KyHieuHoaDon", "SoHoaDon", "NgayLap", "MCCQT",
                                                 "TenNguoiBanNguoiXuatHang", "MSTNguoiBanNguoiXuatHang", "DiaChiNguoiBan",
                                                 "TenNguoiMuaNguoiNhanHang", "MSTNguoiMuaNguoiNhanHang",
                                                 "TongTienThanhToan", "tong_chua_thue", "tong_thue",
                                                 "TrangThaiHoaDon", "KetQuaKiemTraHoaDon")},
            "dong": [{"ten": x.get("TenHangHoaDichVu", ""), "dvt": x.get("DonViTinh", ""), "sl": x.get("SoLuong", 0),
                      "dg": x.get("DonGia", 0), "tt": x.get("ThanhTienChuaThue", 0), "ts": x.get("ThueSuat", ""),
                      "thue": x.get("TienThue", 0)} for x in dong]}


def gon(hd, direction, tt_pm=None, so_tai=None, dd=None):
    """Rut gon mot hoa don de gui ra giao dien."""
    try:
        tdlap = ngay_vn(hd.get("tdlap"))       # GD94: gio VN (cong thue ghi UTC -> truoc day lui 1 ngay)
        ngay = "/".join(reversed(tdlap.split("-"))) if "-" in tdlap else tdlap
        pm = trang_thai_hien(hd, tt_pm or {}, so_tai or {})       # GD94: + 'tai' (da tai, chua vao phan mem)
        return {
            "mst": hd.get("nbmst", ""),
            "mau": str(hd.get("khmshdon", "")),
            "kh": hd.get("khhdon", ""),
            "so": str(hd.get("shdon", "")),
            "ngay": ngay,
            "ten": (hd.get("nmten") if direction == "ban" else hd.get("nbten")) or "",
            "file": os.path.splitext(os.path.basename(hd["_xml"]))[0] if hd.get("_xml") else ten_file(hd, direction),
            "base": hd.get("tgtcthue") or 0,
            "vat": hd.get("tgtthue") or 0,
            "total": hd.get("tgtttbso") or 0,
            "trang_thai": "Đã tải về máy" if hd.get("_tu_may") else TEN_TTXLY.get(str(hd.get("ttxly")), "Không rõ"),
            "khoa": khoa_cua(hd),
            "pm": pm, "tu_may": bool(hd.get("_tu_may")),
            "loai": (dd or {}).get(khoa_cua(hd), ""),
        }
    except Exception as e:
        LOG.loi("Loi khi rut gon mot hoa don", e)
        return {"mst": "", "mau": "", "kh": "", "so": "", "ngay": "", "ten": "(lỗi đọc dữ liệu)",
                "file": "", "base": 0, "vat": 0, "total": 0, "trang_thai": "", "khoa": "", "pm": "moi", "loai": ""}


# ==========================================================================
#  GD106: BANG KE DINH KHOAN AI - phan mem UNESCO phan tich, ke toan xem / sua dinh khoan truoc khi lap chung tu
# ==========================================================================
_BKDK = {"mod": None}


def bkdk():
    if _BKDK["mod"] is None:
        if BASE_DIR not in sys.path:
            sys.path.insert(0, BASE_DIR)
        import bang_ke_dk as m
        _BKDK["mod"] = m
    return _BKDK["mod"]


def _dk_duong():
    return os.path.join(_thu_muc_du_lieu(), bkdk().TEP_BANG_KE)


_DK_CHUA_UNESCO = ("Bảng kê định khoản AI chỉ dùng khi mở công cụ từ phần mềm UNESCO (màn hình AI - Hoá đơn điện tử, "
                   "nút Tải hoá đơn từ Cơ quan Thuế): AI của phần mềm phân tích hoá đơn và gửi định khoản sang đây.")


def dk_yeu_cau(p):
    """Hoi phan mem bang ke dinh khoan cho huong + khoang ngay dang chon."""
    if not UNESCO.get("bat"):
        return {"ok": False, "loi": _DK_CHUA_UNESCO}
    huong = "ban" if p.get("direction") == "ban" else "mua"
    try:
        ma = bkdk().ghi_yeu_cau(unesco_thu_muc("ket-qua"), huong, p.get("tu_ngay"), p.get("den_ngay"))
    except Exception as e:
        return {"ok": False, "loi": str(e)[:200]}
    LOG.ghi("[DINH KHOAN] yeu cau %s: %s %s -> %s" % (ma, huong, p.get("tu_ngay"), p.get("den_ngay")))
    return {"ok": True, "id": ma}


def dk_ket_qua(p):
    """Doc dinh-khoan-ai.jsonl. p: id (cho tra loi yeu cau) / id_sua (cho lan sua) / chi_dau (chi dong dau)."""
    try:
        m = bkdk()
        d = _dk_duong()
        dau = m.doc_dau(d)
        if not dau:
            return {"ok": True, "co": False}
        xong = ((not p.get("id") or dau.get("id") == p.get("id")) and
                (not p.get("id_sua") or (dau.get("sua") or {}).get("id") == p.get("id_sua")))
        if p.get("chi_dau") or not xong:
            return {"ok": True, "co": True, "xong": xong, "dau": dau}
        bk = m.doc_bang_ke(d)
        if not bk:
            return {"ok": True, "co": False}
        r = m.rut_gon(bk)
        r.update({"ok": True, "co": True, "xong": True})
        return r
    except Exception as e:
        LOG.loi("Loi doc bang ke dinh khoan", e)
        return {"ok": False, "loi": "Không đọc được bảng kê định khoản: " + str(e)[:200]}


def dk_sua(p):
    """Ghi dinhkhoan_<MST>_<ts>.jsonl cho phan mem ap dung."""
    if not UNESCO.get("bat"):
        return {"ok": False, "loi": _DK_CHUA_UNESCO}
    huong = "ban" if p.get("direction") == "ban" else "mua"
    try:
        ma, n, loi = bkdk().ghi_sua(unesco_thu_muc("ket-qua"), UNESCO.get("mst"), huong, p.get("tu_ngay"), p.get("den_ngay"),
                                    p.get("muc") or [])
    except Exception as e:
        LOG.loi("Loi ghi sua dinh khoan", e)
        return {"ok": False, "loi": str(e)[:200]}
    if not n:
        return {"ok": False, "loi": "; ".join(loi)[:600]}
    # danh dau ca hoa don (CP / NVL / HH): nho de cot Loai o Buoc 3 hien dung
    try:
        dd = _doc_json("danh-dau.json", {})
        doi = False
        for x0 in p.get("muc") or []:
            x, e = bkdk().kiem_muc_sua(x0, huong)
            if not e and "loai" in x:
                if x.get("loai"):
                    dd[str(x.get("khoa"))] = x["loai"]
                else:
                    dd.pop(str(x.get("khoa")), None)
                doi = True
        if doi:
            _ghi_json("danh-dau.json", dd)
    except Exception as e:
        LOG.loi("Khong cap nhat duoc danh-dau.json", e)
    LOG.ghi("[DINH KHOAN] gui %d sua (%s)%s" % (n, ma, (" - bo %d muc sai" % len(loi)) if loi else ""))
    return {"ok": True, "id_sua": ma, "so": n, "loi": loi}


def dk_excel(p):
    """Xuat bang ke dinh khoan dang co ra Excel (3 sheet) trong thu muc luu hoa don."""
    try:
        m = bkdk()
        bk = m.doc_bang_ke(_dk_duong())
        if not bk or not bk["hd"]:
            return {"ok": False, "loi": "Chưa có bảng kê định khoản - bấm “AI định khoản kỳ đang chọn” trước."}
        thu = SETTINGS.get("thu_muc_luu") or (unesco_thu_muc("xml") if UNESCO.get("bat") else BASE_DIR)
        os.makedirs(thu, exist_ok=True)
        duong = os.path.join(thu, m.ten_tep_excel(bk["dau"]))
        n = m.xuat_excel(bk, duong, viet_xlsx, DongTong)
        LOG.ghi("[DINH KHOAN] Excel %s (%d hoa don)" % (duong, n))
        return {"ok": True, "tep": duong, "so": n}
    except Exception as e:
        LOG.loi("Loi xuat Excel dinh khoan", e)
        return {"ok": False, "loi": "Không tạo được file Excel: " + str(e)[:200]}


TEN_TTXLY = {
    "0": "Cục Thuế đã nhận", "1": "Đang kiểm tra điều kiện cấp mã",
    "2": "CQT từ chối", "3": "Đủ điều kiện cấp mã",
    "4": "Không đủ điều kiện cấp mã", "5": "Đã cấp mã hóa đơn",
    "6": "Cục Thuế đã nhận không mã", "7": "Đã kiểm tra định kỳ",
    "8": "Đã nhận HĐ máy tính tiền",
}


# ==========================================================================
#  GIAO DIEN (giong het ban artifact da duyet)
# ==========================================================================
GIAO_DIEN = r"""<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Tải hóa đơn hàng loạt</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
<style>
/* 18/11/2026 (chu: «thiet ke lai mau cho dong nhat voi UNESCO XII xanh la - trang»): BANG MAU CHUNG XII (Forms\Shell\XiiTheme.vb, chu 12/11):
   nen TRANG, chu gan den #111827, chu phu #374151, vien #CBD5E1; THANH xanh la #0A7A3A / #08632F (chu trang); nut chinh xanh ngoc #007C89 /
   #005C66; hoan tat xanh la #0A8A3E; muc dang chon #E0F4F5; canh bao #9A6700; loi #B42318. Khong dai mau chuyen, khong anh sang tim / xanh duong.
   (Ban truoc: giao dien TOI GD112 - nen 7,27,51, xanh duong / tim.) Ten bien cu (--blue, --cyan, --violet) giu nguyen, tro sang mau XII. */
:root{
  --bg:#FFFFFF; --surface:#FFFFFF; --surface-2:#FFFFFF; --in-bg:#FFFFFF; --ink:#111827; --ink-soft:#374151;
  --line:#CBD5E1; --line-strong:#A9B6C6; --blue:#007C89; --blue-deep:#005C66;
  --blue-tint:#E0F4F5; --green:#0A8A3E; --green-tint:#E4F6EA;
  --amber:#9A6700; --amber-tint:#FFF4D6; --red:#B42318; --red-tint:#FDECEA;
  --violet:#005C66; --cyan:#007C89;
  --bar:#0A7A3A; --bar-dark:#08632F; --bar-soft:#D6F5E0; --sel:#E0F4F5; --sel-strong:#C8EAEC;
  --radius:12px; --radius-sm:8px;
  --shadow:0 1px 2px rgba(16,24,40,.06),0 1px 3px rgba(16,24,40,.06);
  --mono:'JetBrains Mono', ui-monospace, monospace;
  color-scheme:light;
}
/* vung luoi / hop thoai: cung bang mau (giu khoi de cac bien con dung) */
.tablewrap,.modal,#hopGD29>div{color-scheme:light;color:var(--ink)}
*{box-sizing:border-box}
html,body{margin:0;padding:0}
body{background:var(--bg);color:var(--ink);font-family:'Be Vietnam Pro',system-ui,'Segoe UI',sans-serif;font-size:14px;line-height:1.55;-webkit-font-smoothing:antialiased;min-height:100vh}
button,input,select{font-family:inherit;font-size:inherit;color:inherit}
:focus-visible{outline:2px solid var(--blue);outline-offset:2px;border-radius:4px}
::selection{background:var(--sel-strong);color:var(--ink)}
.wrap{max-width:1280px;margin:0 auto;padding:0 20px 64px}

/* ---- dai tieu de: thanh XANH LA nhu thanh tren / thanh trai cua XII ---- */
.topbar{position:sticky;top:0;z-index:40;background:var(--bar);border-bottom:1px solid var(--bar-dark);box-shadow:0 2px 6px -2px rgba(16,24,40,.25)}
.topbar-in{max-width:1280px;margin:0 auto;padding:12px 20px;display:flex;align-items:center;gap:10px 12px;flex-wrap:wrap}
.brand{display:flex;align-items:center;gap:13px;margin-right:auto}
.mark{width:44px;height:44px;border-radius:10px;flex:none;display:grid;place-items:center;background:var(--bar-dark);box-shadow:0 0 0 1px rgba(255,255,255,.22) inset}
.mark svg{display:block}
.brand h1{margin:0;font-size:17px;font-weight:800;letter-spacing:-.2px;color:#fff;display:flex;align-items:center;gap:9px;flex-wrap:wrap}
.ai-badge{font-size:10.5px;font-weight:800;letter-spacing:.08em;padding:3px 9px;border-radius:999px;color:var(--bar);background:#fff}
.brand p{margin:2px 0 0;font-size:12px;color:var(--bar-soft)}
.topbar .linkbtn{color:#fff;padding:6px 13px;border:1px solid rgba(255,255,255,.55);border-radius:999px;background:rgba(255,255,255,.08);font-size:12.5px}
.topbar .linkbtn:hover{text-decoration:none;background:rgba(255,255,255,.2);border-color:#fff;color:#fff}
.un-banner{order:20;flex-basis:100%;margin:2px 0 0;padding:9px 14px;border-radius:10px;background:rgba(255,255,255,.14);border:1px solid rgba(255,255,255,.4);color:#fff;font-weight:600;font-size:13px}
#aiKeyState{color:var(--green)}

/* ---- the trang thai ---- */
.chip{display:inline-flex;align-items:center;gap:7px;padding:6px 12px;border-radius:999px;font-size:12.5px;font-weight:600;border:1px solid var(--line);background:#fff;color:var(--ink-soft)}
.chip .dot{width:8px;height:8px;border-radius:50%;background:#94A3B8;flex:none}
.chip.on{background:var(--green-tint);border-color:#9ED4B2;color:var(--green)}
.chip.on .dot{background:var(--green);box-shadow:0 0 0 3px rgba(10,138,62,.18)}
.topbar .chip{background:rgba(255,255,255,.1);border-color:rgba(255,255,255,.45);color:#fff}
.topbar .chip .dot{background:rgba(255,255,255,.6)}
.topbar .chip.on{background:#fff;border-color:#fff;color:var(--bar)}
.topbar .chip.on .dot{background:var(--green)}

/* ---- the (card): nen trang, phan vung bang vien ---- */
.card{background:#fff;border:1px solid var(--line);border-radius:var(--radius);box-shadow:var(--shadow);margin-top:18px;position:relative}
.card::before{content:none}
.card-head{padding:14px 20px;border-bottom:1px solid var(--line);display:flex;align-items:center;gap:12px;flex-wrap:wrap}
.card-head h2{margin:0;font-size:15px;font-weight:700;letter-spacing:-.1px;color:var(--ink)}
.card-body{padding:18px 20px}
.eyebrow{display:inline-flex;align-items:center;padding:3px 11px;border-radius:999px;font-size:10.5px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:#fff;font-family:var(--mono);background:var(--bar)}

/* ---- o nhap ---- */
.grid{display:grid;gap:14px 22px}
.g3{grid-template-columns:repeat(3,minmax(0,1fr))}
.field{display:flex;flex-direction:column;gap:6px;min-width:0}
label{font-size:12.5px;font-weight:600;color:var(--ink-soft)}
label .req{color:var(--red);font-weight:700}
input[type=text],input[type=password],input[type=date],input[type=number],select{width:100%;padding:9px 11px;border:1px solid var(--line-strong);border-radius:var(--radius-sm);background:var(--in-bg);color:var(--ink);transition:border-color .15s,box-shadow .15s,background .15s}
input::placeholder{color:#6B7280}
input:hover,select:hover{border-color:var(--blue)}
input:focus,select:focus{outline:none;border-color:var(--blue);box-shadow:0 0 0 3px var(--blue-tint)}
select{appearance:none;background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='%23374151' stroke-width='2.5' stroke-linecap='round'><path d='M6 9l6 6 6-6'/></svg>");background-repeat:no-repeat;background-position:right 10px center;padding-right:32px;cursor:pointer}
select:disabled,input:disabled{opacity:.55;cursor:not-allowed;background-color:#F8FAFC}
.daterow{display:flex;align-items:center;gap:8px}
.daterow span{font-size:12.5px;color:var(--ink-soft);white-space:nowrap}
.check{display:flex;align-items:center;gap:9px;font-size:13.5px;cursor:pointer;user-select:none;color:var(--ink)}
input[type=checkbox],input[type=radio]{width:17px;height:17px;accent-color:var(--blue);cursor:pointer;margin:0;flex:none}
details summary,.sum-mo{cursor:pointer;color:var(--ink-soft);margin-bottom:10px}
.mo{color:var(--ink-soft)}

/* ---- nut: nut chinh xanh ngoc, nut xanh la = hoan tat / tai ve (nhu XII) ---- */
.btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:10px 18px;border-radius:var(--radius-sm);border:1px solid transparent;font-weight:600;cursor:pointer;transition:background .15s,border-color .15s,box-shadow .15s,transform .05s;background:transparent;color:var(--ink)}
.btn:active{transform:translateY(1px)}
.btn:disabled{opacity:.45;cursor:not-allowed;transform:none;box-shadow:none}
.btn-primary{background:var(--blue);border-color:var(--blue);color:#fff}
.btn-primary:hover:not(:disabled){background:var(--blue-deep);border-color:var(--blue-deep)}
.btn-xanh{background:var(--green);border-color:var(--green);color:#fff}
.btn-xanh:hover:not(:disabled){background:var(--bar-dark);border-color:var(--bar-dark)}
.btn-cam{background:var(--amber);border-color:var(--amber);color:#fff}
.btn-cam:hover:not(:disabled){background:#7A5200;border-color:#7A5200}
.btn-tim{background:var(--blue-deep);border-color:var(--blue-deep);color:#fff}
.btn-tim:hover:not(:disabled){background:#00454D;border-color:#00454D}
.btn-ghost{border-color:var(--line-strong);color:var(--ink);background:#fff}
.btn-ghost:hover:not(:disabled){background:var(--blue-tint);border-color:var(--blue)}
.btn-lg{padding:13px 26px;font-size:15px;border-radius:10px}
.btn-row{display:flex;gap:10px;flex-wrap:wrap;align-items:center}
.linkbtn{background:none;border:none;color:var(--blue);font-weight:600;cursor:pointer;padding:4px 2px}
.linkbtn:hover{text-decoration:underline}

/* ---- the chon ---- */
.tabs{display:flex;gap:6px;padding:5px;background:#fff;border:1px solid var(--line);border-radius:10px;flex-wrap:wrap}
.tab{padding:9px 18px;border-radius:8px;border:none;background:transparent;font-weight:600;color:var(--ink-soft);cursor:pointer;white-space:nowrap}
.tab:hover{color:var(--ink);background:var(--sel)}
.tab[aria-selected=true]{background:var(--blue);color:#fff}
.toptabs{margin-top:20px}
.ttab{padding:10px 22px;border-radius:8px;border:none;background:transparent;font-weight:700;font-size:14.5px;color:var(--ink-soft);cursor:pointer;white-space:nowrap}
.ttab:hover{color:var(--ink);background:var(--sel)}
.ttab[aria-selected=true]{background:var(--bar);color:#fff}
.subtabs{display:flex;gap:22px;border-bottom:1px solid var(--line);padding:0 20px;flex-wrap:wrap;align-items:center}
.subtab-item{display:flex;align-items:center;gap:9px}
.subtab{padding:12px 2px;border:none;background:none;cursor:pointer;font-weight:600;color:var(--ink-soft);border-bottom:2px solid transparent;margin-bottom:-1px}
.subtab:hover{color:var(--ink)}
.subtab[aria-selected=true]{color:var(--blue-deep);border-bottom-color:var(--blue)}
.subtab:disabled{opacity:.4;cursor:not-allowed;color:var(--ink-soft);border-bottom-color:transparent}
.loai-note{margin-left:auto;font-size:12px;color:var(--ink-soft);padding:12px 0}
.subtab .count,.hstab .count{font-family:var(--mono);font-size:11.5px;margin-left:6px;padding:1px 8px;border-radius:999px;background:#F1F5F9;color:var(--ink-soft)}
.subtab[aria-selected=true] .count,.hstab[aria-selected=true] .count{background:var(--sel);color:var(--blue-deep)}
.hstab{padding:12px 2px;border:none;background:none;cursor:pointer;font-weight:600;color:var(--ink-soft);border-bottom:2px solid transparent;margin-bottom:-1px}
.hstab:hover{color:var(--ink)}
.hstab[aria-selected=true]{color:var(--blue-deep);border-bottom-color:var(--blue)}

/* ---- thanh chon + luoi ---- */
.toolbar{padding:12px 20px;display:flex;align-items:center;gap:14px;flex-wrap:wrap;background:#fff;border-bottom:1px solid var(--line)}
.selected-count{font-size:13px;color:var(--ink-soft)}
.selected-count b{color:var(--blue-deep);font-family:var(--mono);font-size:14px}
.tablewrap{max-height:430px;overflow:auto;background:#fff;border:1px solid var(--line);border-radius:10px;margin:14px 16px 16px}
table{width:100%;border-collapse:collapse;font-size:13px}
thead th{position:sticky;top:0;z-index:2;background:var(--sel);padding:11px 12px;text-align:left;font-size:11.5px;font-weight:700;letter-spacing:.04em;text-transform:uppercase;color:var(--ink);border-bottom:1px solid var(--line-strong);white-space:nowrap}
tbody td{padding:11px 12px;border-bottom:1px solid var(--line);vertical-align:top;color:var(--ink)}
tbody tr:hover{background:#F5FBFB}
tbody tr.picked{background:var(--sel)}
tbody tr.picked:hover{background:var(--sel-strong)}
.num{font-family:var(--mono);text-align:right;white-space:nowrap;font-size:12.5px}
.mono{font-family:var(--mono);font-size:12.5px;white-space:nowrap}
.seller{font-weight:600;display:block}
.seller-mst{font-size:12px;color:var(--ink-soft);font-family:var(--mono)}
.tag{display:inline-block;padding:3px 9px;border-radius:6px;font-size:11.5px;font-weight:600;white-space:nowrap;background:var(--green-tint);color:var(--green)}
.col-check{width:44px}
.an-dk .col-dk,.an-dk #cardDK{display:none!important}
.empty{padding:56px 20px;text-align:center;color:var(--ink-soft)}
.empty strong{display:block;color:var(--ink);font-size:15px;margin-bottom:5px}

/* ---- tom tat dong bo ---- */
.tom-tat{margin-top:16px}
.tt-ky{font-size:12.5px;color:var(--ink-soft);margin-bottom:8px}
.tt-luoi{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}
.tt-o{padding:12px 16px;border-radius:10px;border:1px solid var(--line);background:#fff}
.tt-o.mua{box-shadow:inset 3px 0 0 var(--green)}
.tt-o.ban{box-shadow:inset 3px 0 0 var(--blue)}
.tt-ten{font-size:11.5px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--ink-soft)}
.tt-so{font-family:var(--mono);font-size:24px;font-weight:700;color:var(--ink);line-height:1.25}
.tt-so span{font-family:'Be Vietnam Pro',system-ui,sans-serif;font-size:13px;font-weight:500;color:var(--ink-soft)}
.tt-ct{display:flex;flex-wrap:wrap;gap:4px 14px;font-size:12.5px;color:var(--ink-soft);margin-top:4px}
.tt-moi{color:var(--green);font-weight:700}
.tt-cho{color:var(--amber);font-weight:700}
.tt-canh{margin-top:10px;padding:9px 12px;border-radius:8px;background:var(--amber-tint);border:1px solid #E8CF8A;color:#6B4800;font-size:12.5px}
.ghi-chu-tim{font-size:12.5px;color:var(--ink-soft);flex-basis:100%}
.ghi-chu-tim:empty{display:none}

/* ---- hoa don ban le ---- */
.hang-bl{display:flex;gap:12px;flex-wrap:wrap;align-items:stretch;margin-top:14px}
.khoa-bl{align-items:center;gap:10px 12px;flex-wrap:wrap;padding:10px 14px;border-radius:10px;border:1px solid #E8CF8A;background:var(--amber-tint);flex:1 1 520px}
.khoa-bl b{color:#6B4800;font-size:13px;white-space:nowrap}
.khoa-bl select{width:auto;min-width:270px;margin:0;font-weight:600}
.khoa-bl-giai{font-size:12.5px;color:var(--ink-soft);flex:1 1 240px}
.o-thbl{margin:0;padding:10px 16px;border:1px solid #9BD3D8;border-radius:10px;background:var(--sel);color:var(--blue-deep);font-weight:600;white-space:nowrap}
.khung-thbl{margin-top:16px;padding:12px 14px;border:1px solid #9BD3D8;border-radius:10px;background:var(--sel)}
.th-tieu-de{font-weight:700;color:var(--blue-deep);margin-bottom:8px}
.th-chi-ban{margin-bottom:8px;color:var(--amber);font-weight:600}

/* ---- khung dang nhap ---- */
.khung{border:1px solid var(--line);border-radius:10px;padding:12px 16px;margin-bottom:12px;background:#fff}
.khung b{color:var(--ink)}
.khung-nhan{padding:14px 16px;margin-bottom:16px;background:var(--sel);border-color:#9BD3D8}

/* ---- tai ve ---- */
.folder{display:flex;align-items:center;gap:12px;padding:12px 14px;border:1px dashed var(--line-strong);border-radius:var(--radius-sm);background:#fff;flex-wrap:wrap}
.dinh-dang{display:flex;align-items:center;gap:22px;flex-wrap:wrap;padding:12px 14px;background:var(--sel);border:1px solid #9BD3D8;border-radius:var(--radius-sm)}
.dd-label{font-size:12.5px;font-weight:700;color:var(--blue-deep);text-transform:uppercase;letter-spacing:.05em;font-family:var(--mono)}
.dd-hint{color:var(--ink-soft);font-weight:400;font-size:12.5px}
.dd-note{margin-left:auto;font-size:12px;color:var(--amber);font-weight:600}
.folder .path{font-family:var(--mono);font-size:12.5px;color:var(--ink-soft);word-break:break-all;flex:1;min-width:180px}
.folder .path.set{color:var(--ink)}
.progress-block{margin-top:18px;display:none;padding:14px 16px;border-radius:10px;border:1px solid var(--line);background:#fff}
.progress-block.show{display:block}
.progress-top{display:flex;align-items:baseline;justify-content:space-between;gap:12px;margin-bottom:9px;flex-wrap:wrap}
.progress-figure{font-family:var(--mono);font-size:26px;font-weight:700;letter-spacing:-1px;line-height:1;color:var(--ink)}
.progress-figure .of{color:var(--ink-soft);font-weight:400;font-size:17px}
.progress-pct{font-family:var(--mono);font-size:14px;font-weight:700;color:var(--green)}
.rail{height:12px;border-radius:999px;background:#EEF2F6;overflow:hidden;border:1px solid var(--line)}
.rail-fill{height:100%;width:0%;border-radius:999px;transition:width .28s ease;background:var(--green)}
.progress-meta{display:flex;gap:18px;flex-wrap:wrap;margin-top:10px;font-size:12.5px;color:var(--ink-soft)}
.progress-meta b{font-family:var(--mono)}
.progress-meta .ok b{color:var(--green)}
.progress-meta .skip b{color:var(--amber)}
.progress-meta .err b{color:var(--red)}
.current-file{margin-top:10px;font-family:var(--mono);font-size:12px;color:var(--ink-soft);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.note{margin-top:16px;padding:13px 15px;background:var(--sel);border:1px solid #9BD3D8;border-radius:10px;font-size:12.5px;color:var(--ink)}
.note b{color:var(--ink)}
.note ul{margin:7px 0 0;padding-left:18px}
.note li{margin:3px 0}
#captchaBox{width:118px;height:44px;border:1px solid var(--line-strong);border-radius:8px;display:grid;place-items:center;background:#fff;color:var(--ink);flex:none;cursor:pointer;overflow:hidden}
#captchaBox svg{max-width:100%;max-height:100%}

/* ---- hop thoai ---- */
.overlay{position:fixed;inset:0;background:rgba(17,24,39,.45);display:none;place-items:center;z-index:1001;padding:20px}
.overlay.show{display:grid}
.modal{background:#fff;border-radius:12px;max-width:520px;width:100%;padding:24px;border:1px solid var(--line);box-shadow:0 20px 50px -20px rgba(16,24,40,.45)}
.modal h3{margin:0 0 10px;font-size:17px}
.modal p{margin:0 0 12px;color:var(--ink)}
.modal .small{font-size:12.5px;color:var(--ink-soft);word-break:break-all}
#hopGD29{background:rgba(17,24,39,.45)!important}
#hopGD29>div{border-radius:12px!important;border:1px solid var(--line);box-shadow:0 20px 50px -20px rgba(16,24,40,.45)!important}

/* ---- ho so thue ---- */
.hs-tag{display:inline-block;padding:3px 9px;border-radius:6px;font-size:11.5px;font-weight:600;white-space:nowrap}
.hs-ok{background:var(--green-tint);color:var(--green)}
.hs-cho{background:var(--amber-tint);color:var(--amber)}
.hs-loi{background:var(--red-tint);color:var(--red)}
.hs-lech{color:var(--red);font-weight:700}
.hs-nhom td{background:#F5FBFB;font-weight:700;border-top:2px solid var(--line-strong)}
.hs-mo{background:none;border:none;color:var(--blue);cursor:pointer;padding:0;font-weight:600}
.hs-mo:hover{text-decoration:underline}
.hs-nho{font-size:12px;color:var(--ink-soft)}
::-webkit-scrollbar{width:11px;height:11px}
::-webkit-scrollbar-thumb{background:#B8C4D2;border-radius:8px;border:2px solid #fff;background-clip:padding-box}
::-webkit-scrollbar-track{background:transparent}
@media (max-width:900px){.g3{grid-template-columns:repeat(2,minmax(0,1fr))}.tt-luoi{grid-template-columns:1fr}}
@media (max-width:620px){.g3{grid-template-columns:1fr}.wrap{padding:0 12px 48px}.card-body{padding:14px}.khoa-bl select{min-width:0;width:100%}}
@media (prefers-reduced-motion:reduce){*{transition:none!important}}
</style>
</head>
<body>

<div class="topbar"><div class="topbar-in">
  <div class="brand">
    <div class="mark" aria-hidden="true"><svg viewBox="0 0 24 24" width="26" height="26" fill="#fff" stroke="none"><path d="M13.2 2.5 5.6 13.1c-.3.4 0 1 .5 1h4.6l-1.3 7.2c-.1.6.7.9 1 .4l7.6-10.6c.3-.4 0-1-.5-1h-4.6l1.3-7.2c.1-.6-.7-.9-1-.4z"/></svg></div>
    <div><h1>Tải hóa đơn hàng loạt <span class="ai-badge">AI UNESCO</span></h1>
    <p>hoadondientu.gdt.gov.vn — đồng bộ mua vào · bán ra, tải XML / PDF nhiều hóa đơn cùng lúc</p></div>
  </div>
  <div id="unBanner" class="un-banner" style="display:none"></div>
<button class="linkbtn" id="btnKiemTra" style="display:none" title="Tra lại trạng thái các hóa đơn đã tải theo danh sách phần mềm gửi">Kiểm tra lại trạng thái</button>
<button class="linkbtn" id="btnAI" title="Khóa Claude API (tùy chọn)">AI gợi ý</button><span id="aiKeyState" style="font-size:12px;margin-left:6px"></span>
<button class="linkbtn" id="btnLog">Mở file nhật ký</button>
<button class="linkbtn" id="btnHienThue" style="display:none" title="Hiện lại cửa sổ trang thuế (tự thu nhỏ sau khi đăng nhập)">Hiện trang thuế</button>
<button class="linkbtn" id="btnThoat" title="Đóng trang thuế và tắt tool tải hóa đơn">Thoát</button>
  <span class="chip" id="statusChip"><span class="dot"></span><span id="statusText">Chưa đăng nhập</span></span>
</div></div>

<div class="wrap">

  <nav class="tabs toptabs" id="tabChinh" role="tablist">
    <button class="ttab" role="tab" aria-selected="true" data-pane="paneHD">Hóa đơn điện tử</button>
    <button class="ttab" role="tab" aria-selected="false" data-pane="paneHS">Hồ sơ thuế - Cổng dịch vụ công</button>
  </nav>

  <div id="paneHD">
  <section class="card">
    <div class="card-head"><span class="eyebrow">Bước 1</span><h2>Đăng nhập trang thuế</h2></div>
    <div class="card-body">
      <div id="khungGoiNho" class="khung">
        <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
          <b>Tài khoản gợi nhớ</b>
          <select id="gnChon" style="width:auto;min-width:260px"><option value="">— chọn tài khoản đã lưu —</option></select>
          <input type="text" id="gnNhan" placeholder="Tên gợi nhớ (ví dụ: Nhựa VTP)" style="width:230px" autocomplete="off">
          <input type="text" id="gnMst" placeholder="Mã số thuế" style="width:150px" autocomplete="off">
          <button class="btn btn-ghost" id="gnLuu">Lưu</button>
          <button class="btn btn-ghost" id="gnXoa">Xoá</button>
        </div>
        <div class="mo" style="font-size:12.5px;margin-top:6px">Tool chỉ nhớ TÊN và MÃ SỐ THUẾ, không lưu mật khẩu. Mỗi mã số thuế dùng một hồ sơ Chrome riêng: lần đầu đăng nhập, bấm “Lưu mật khẩu” của Chrome; các lần sau Chrome tự điền, bạn chỉ gõ mã captcha.</div>
      </div>
      <div id="khungChrome" class="khung khung-nhan">
        <div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap">
          <button class="btn btn-primary" id="btnChrome">Đăng nhập qua Chrome (khuyên dùng)</button>
          <span id="chromeTrangThai" class="mo">Trang thuế đang chặn đăng nhập từ công cụ. Bấm nút này: tool mở Chrome tới trang thuế, bạn đăng nhập như bình thường, tool tự nhận phiên làm việc và tải tiếp.</span>
        </div>
      </div>
      <details><summary class="sum-mo">Đăng nhập trực tiếp (cách cũ — hiện bị máy chủ chặn 403, chỉ để thử)</summary>
      <div class="grid g3">
        <div class="field"><label for="mst">Mã số thuế <span class="req">*</span></label>
          <input type="text" id="mst" placeholder="0700922112" autocomplete="off"></div>
        <div class="field"><label for="pwd">Mật khẩu <span class="req">*</span></label>
          <div class="daterow" style="gap:6px">
            <input type="password" id="pwd" placeholder="Nhập mật khẩu" style="flex:1">
            <button type="button" class="btn btn-ghost" id="btnHienMk" title="Hiện / ẩn mật khẩu" style="white-space:nowrap">Hiện</button>
          </div></div>
        <div class="field"><label for="captcha">Mã captcha <span class="req">*</span> — bấm vào ảnh để đổi mã</label>
          <div class="daterow">
            <input type="text" id="captcha" placeholder="Nhập mã bên cạnh" style="flex:1" autocomplete="off">
            <div id="captchaBox" title="Bấm để lấy mã khác">…</div>
          </div></div>
      </div>
      <div class="btn-row" style="margin-top:16px">
        <button class="btn btn-primary" id="btnLogin">Đăng nhập</button>
        <label class="check"><input type="checkbox" id="remember" checked> Nhớ mã số thuế cho lần sau (không lưu mật khẩu)</label>
      </div>
      </details>
    </div>
  </section>

  <section class="card">
    <div class="card-head" style="justify-content:space-between">
      <div style="display:flex;align-items:center;gap:12px"><span class="eyebrow">Bước 2</span><h2>Tra cứu hóa đơn</h2></div>
      <div class="tabs" role="tablist">
        <button class="tab" role="tab" aria-selected="true" data-dir="ban">Hóa đơn bán ra</button>
        <button class="tab" role="tab" aria-selected="false" data-dir="mua">Hóa đơn mua vào</button>
      </div>
    </div>
    <div class="card-body">
      <div class="grid g3">
        <div class="field"><label for="fStatus">Trạng thái hóa đơn <span class="req">*</span></label>
          <select id="fStatus">
            <option>Tất cả</option><option>Hóa đơn mới</option><option>Hóa đơn thay thế</option>
            <option>Hóa đơn điều chỉnh</option><option>Hóa đơn đã bị thay thế</option>
            <option>Hóa đơn đã bị điều chỉnh</option><option>Hóa đơn đã bị hủy</option>
          </select></div>
        <div class="field"><label for="fCheck">Kết quả kiểm tra <span class="req">*</span></label>
          <select id="fCheck">
            <option>Tất cả</option><option>Cục Thuế đã nhận</option>
            <option>Đang tiến hành kiểm tra điều kiện cấp mã</option>
            <option>CQT từ chối hóa đơn theo từng lần phát sinh</option>
            <option>Hóa đơn đủ điều kiện cấp mã</option><option>Hóa đơn không đủ điều kiện cấp mã</option>
            <option>Đã cấp mã hóa đơn</option><option>Cục Thuế đã nhận không mã</option>
            <option>Đã kiểm tra định kỳ HĐĐT không có mã</option>
            <option>Cục Thuế đã nhận hóa đơn có mã khởi tạo từ máy tính tiền</option>
          </select></div>
        <div class="field"><label>Ngày lập hóa đơn <span class="req">*</span></label>
          <div class="daterow"><span>Từ</span><input type="date" id="fFrom">
          <span>đến</span><input type="date" id="fTo"></div>
          <div class="daterow" style="margin-top:6px"><span>Kỳ</span>
            <select id="fKy" onchange="chonKy()" style="min-width:110px">
              <option value="">(tự chọn ngày)</option>
              <option value="T1">Tháng 1</option><option value="T2">Tháng 2</option><option value="T3">Tháng 3</option>
              <option value="T4">Tháng 4</option><option value="T5">Tháng 5</option><option value="T6">Tháng 6</option>
              <option value="T7">Tháng 7</option><option value="T8">Tháng 8</option><option value="T9">Tháng 9</option>
              <option value="T10">Tháng 10</option><option value="T11">Tháng 11</option><option value="T12">Tháng 12</option>
              <option value="Q1">Quý 1</option><option value="Q2">Quý 2</option><option value="Q3">Quý 3</option><option value="Q4">Quý 4</option>
              <option value="N">Cả năm</option>
            </select>
            <span>năm</span><input type="number" id="fNam" min="2015" max="2100" style="width:84px" onchange="chonKy()"></div></div>
        <div class="field"><label for="fMst">Mã số thuế người mua</label>
          <input type="text" id="fMst" placeholder="Để trống nếu lấy tất cả"></div>
        <div class="field"><label for="fCccd">CCCD người mua</label>
          <input type="text" id="fCccd" placeholder="Để trống nếu lấy tất cả"></div>
        <div class="field"><label for="fMau">Ký hiệu mẫu số hóa đơn</label>
          <select id="fMau"><option>Tất cả</option><option>1</option><option>2</option>
          <option>3</option><option>4</option><option>5</option><option>6</option></select></div>
        <div class="field"><label for="fKh">Ký hiệu hóa đơn</label>
          <input type="text" id="fKh" placeholder="Ví dụ: C26TYY"></div>
        <div class="field"><label for="fSo">Số hóa đơn</label>
          <input type="text" id="fSo" placeholder="Ví dụ: 00000202"></div>
        <div class="field" style="justify-content:flex-end">
          <label class="check" style="padding-bottom:9px"><input type="checkbox" id="fUyNhiem"> Chỉ lấy hóa đơn ủy nhiệm</label></div>
      </div>
      <div id="syncTomTat" class="tom-tat" style="display:none"></div>
      <div class="btn-row" style="margin-top:18px">
        <button class="btn btn-primary" id="btnSync" title="Lấy danh sách hóa đơn MUA VÀO + BÁN RA của cả kỳ đã chọn. Chưa tải file nào.">Đồng bộ hóa đơn (mua + bán)</button>
        <button class="btn btn-primary btn-xanh" id="btnSyncTai" title="Tải toàn bộ hóa đơn đã đồng bộ mà chưa có trong phần mềm; hóa đơn đã tải về máy nhưng chưa vào phần mềm được đưa vào từ file trên máy (không tải lại).">Tải về hóa đơn chưa có</button>
        <button class="btn btn-primary btn-cam" id="btnLamMoi" title="Tải bị lỗi / bị ngắt giữa chừng: hiện các hóa đơn ĐÃ TẢI về máy nhưng CHƯA vào phần mềm (không cần mạng) để đưa vào phần mềm, không tải lại.">Làm mới (HĐ đã tải chưa vào phần mềm)</button>
        <button class="btn btn-ghost" id="btnExcelCong" title="Hoá đơn máy tính tiền: trên trang hoadondientu.gdt.gov.vn, thẻ 'Hoá đơn có mã khởi tạo từ máy tính tiền' - Tìm kiếm (gõ captcha 1 lần) - Xuất Excel chi tiết; rồi bấm nút này chọn tệp vừa tải. Đưa thẳng vào phần mềm, không cần gõ captcha từng trang.">Nhập Excel từ cổng thuế</button>
        <button class="btn btn-ghost" id="btnSearch">Tìm kiếm (1 chiều)</button>
        <button class="btn btn-ghost" id="btnReset">Xóa bộ lọc</button>
        <span id="searchNote" class="ghi-chu-tim"></span>
      </div>
      <div class="hang-bl">
        <div id="lblKhoaBL" class="khoa-bl" style="display:none" title="Cách xử lý hóa đơn BÁN LẺ (bán ra, người mua KHÔNG có MST) của công ty này, lưu theo từng công ty. Đưa từng tờ vào phần mềm: tải về là chuyển vào phần mềm như trước. Tải về, chờ duyệt: tải về chỉ lưu trên máy, vào phần mềm khi bấm Làm mới → Đưa HĐ đã tải vào phần mềm. Gộp mỗi ngày thành 1 chứng từ: không vào phần mềm từng tờ - tải xong (cả hẹn giờ) tự gộp mỗi ngày đã qua thành 1 chứng từ BKBL, hóa đơn hôm nay gộp ở lần tải sau.">
          <b>HĐ bán lẻ (khách không MST)</b>
          <select id="selKhoaBL"><option value="tu_dong">Đưa từng tờ vào phần mềm</option><option value="xac_nhan">Tải về, chờ duyệt</option><option value="tong_hop">Gộp mỗi ngày thành 1 chứng từ</option></select>
          <span class="khoa-bl-giai" id="khoaBLGiai"></span>
        </div>
        <label class="check o-thbl" id="lblTHBL" title="Tích vào để mở khung tổng hợp hóa đơn bán ra (bán lẻ nhiều hóa đơn) thành 1 chứng từ. Không tích thì tải / chuyển hóa đơn từng tờ như bình thường."><input type="checkbox" id="chkTHBL"> Tổng hợp hóa đơn bán lẻ</label>
      </div>
    </div>
  </section>

  <section class="card">
    <div class="card-head"><span class="eyebrow">Bước 3</span><h2>Chọn hóa đơn cần tải</h2></div>
    <div class="subtabs" role="tablist">
      <div class="subtab-item">
        <input type="checkbox" id="useDt" checked title="Tick để tra cứu loại hóa đơn này">
        <button class="subtab" role="tab" aria-selected="true" data-kind="dt">Hóa đơn điện tử <span class="count" id="cntDt">0</span></button>
      </div>
      <div class="subtab-item">
        <input type="checkbox" id="useMtt" checked title="Tick để tra cứu loại hóa đơn này">
        <button class="subtab" role="tab" aria-selected="false" data-kind="mtt">Tải cả hoá đơn máy tính tiền (phải gõ mã xác nhận) <span class="count" id="cntMtt">0</span></button>
      </div>
      <label class="check" id="lblMttChiMua" style="display:none;margin-left:8px" title="Hoá đơn máy tính tiền BÁN RA của chính công ty thường đã có trong phần mềm bán hàng. Tick: chỉ tìm chiều mua vào - đỡ phải gõ mã cho chiều bán ra. Lựa chọn được nhớ theo sổ."><input type="checkbox" id="mttChiMua"> Chỉ tải hoá đơn máy tính tiền MUA VÀO</label>
      <span class="loai-note" id="loaiNote"></span>
    </div>
    <div class="toolbar">
      <span class="selected-count">Đã chọn <b id="selCount">0</b> / <span id="totalCount">0</span> hóa đơn</span>
      <button class="linkbtn" id="btnSelectAll">Chọn tất cả</button>
      <button class="linkbtn" id="btnSelectNew" title="Chỉ chọn hóa đơn chưa có trong phần mềm và chưa từng tải">Chọn hóa đơn mới</button>
      <button class="linkbtn" id="btnClearAll">Bỏ chọn tất cả</button>
      <span id="khungDanhDau" style="display:none;margin-left:14px">Đánh dấu cả hóa đơn đã chọn là:
        <button class="linkbtn" data-dd="CP" title="Ghi gộp vào TK chi phí, không tạo mã hàng">Chi phí</button>
        <button class="linkbtn" data-dd="NVL" title="Nhập kho nguyên vật liệu (152)">NVL</button>
        <button class="linkbtn" data-dd="HH" title="Nhập kho hàng hoá (156)">Hàng hoá</button>
        <button class="linkbtn" data-dd="" title="Để phần mềm tự nhận">Bỏ đánh dấu</button>
      </span>
      <span style="margin-left:auto;font-size:12.5px;color:var(--ink-soft)" id="sumMoney"></span>
    </div>
    <div class="tablewrap">
      <table><thead><tr>
        <th class="col-check"><input type="checkbox" id="checkAll" title="Chọn tất cả hóa đơn"></th>
        <th>STT</th><th>Mã số thuế</th><th>Mẫu số</th><th>Ký hiệu</th><th>Số hóa đơn</th>
        <th>Ngày lập</th><th>Thông tin hóa đơn</th>
        <th style="text-align:right">Chưa thuế</th><th style="text-align:right">Tiền thuế</th>
        <th style="text-align:right">Thanh toán</th><th>Trạng thái</th>
        <th>Trong phần mềm</th><th>Loại</th><th class="col-dk" title="GD106: định khoản AI của phần mềm (bấm để xem / sửa)">Định khoản AI</th><th></th>
      </tr></thead><tbody id="tbody"></tbody></table>
      <div class="empty" id="emptyBox"><strong>Chưa có kết quả</strong>
      Chọn khoảng ngày rồi bấm “Tìm kiếm” để lấy danh sách hóa đơn.</div>
    </div>
  </section>

  <section class="card">
    <div class="card-head"><span class="eyebrow">Bước 4</span><h2>Tải file về máy</h2></div>
    <div class="card-body">
      <div class="dinh-dang">
        <span class="dd-label">Loại file muốn tải</span>
        <label class="check"><input type="checkbox" id="ddXml" checked> File XML <span class="dd-hint">(bản gốc để kê khai)</span></label>
        <label class="check"><input type="checkbox" id="ddPdf"> File PDF <span class="dd-hint">(bản in để xem, lưu trữ)</span></label>
        <label class="check"><input type="checkbox" id="ddExcel" checked> Gộp danh mục và tải file Excel <span class="dd-hint">(bảng kê danh sách hóa đơn - hóa đơn vào phần mềm qua màn hình AI)</span></label>
        <span class="dd-note" id="ddNote"></span>
      </div>
      <div style="margin-top:10px">
        <label class="check"><input type="checkbox" id="chiMoi" checked> Chỉ tải hóa đơn mới <span class="dd-hint">(bỏ qua hóa đơn đã có trong phần mềm hoặc đã tải trước đó)</span></label>
      </div>
      <div class="folder" style="margin-top:14px">
        <button class="btn btn-ghost" id="btnFolder">Chọn thư mục lưu</button>
        <span class="path" id="folderPath">Chưa chọn thư mục lưu</span>
      </div>
      <div id="khungTHBL" style="display:none;" class="khung-thbl">
        <div id="thChiBan" class="th-chi-ban" style="display:none">Tổng hợp hóa đơn bán lẻ chỉ dùng cho hóa đơn BÁN RA - chọn thẻ “Hóa đơn bán ra”, tìm kiếm rồi chọn hóa đơn.</div>
        <div class="th-tieu-de">Bán lẻ nhiều hóa đơn: tổng hợp hóa đơn bán ra thành 1 chứng từ trước khi chuyển vào phần mềm</div>
        <div style="display:flex;flex-wrap:wrap;gap:8px 18px;align-items:center">
          <label style="display:inline-flex;align-items:center;gap:6px;margin:0;font-weight:600">Gộp hóa đơn trong
            <select id="thSoNgay" style="width:auto;min-width:200px;margin:0">
              <option value="1">1 ngày</option><option value="2">2 ngày</option><option value="3">3 ngày</option>
              <option value="4">4 ngày</option><option value="5">5 ngày</option><option value="6">6 ngày</option>
              <option value="7">1 tuần (Thứ Hai → Chủ Nhật)</option>
            </select> thành 1 chứng từ</label>
          <span class="dd-hint">không gộp qua cuối tháng · tách theo mẫu số, ký hiệu · số chứng từ BKBL&lt;tháng&gt;.&lt;ngày&gt; (vd BKBL07.01)</span>
        </div>
        <div style="margin-top:8px;display:flex;flex-direction:column;gap:4px">
          <label class="check"><input type="radio" name="thPhamVi" value="ntd" checked> Chỉ hóa đơn bán cho người tiêu dùng <b>không có MST</b> <span class="dd-hint">(hóa đơn người mua có MST vẫn nhập riêng từng tờ)</span></label>
          <label class="check"><input type="radio" name="thPhamVi" value="tat_ca"> <b>Toàn bộ</b> hóa đơn trong kỳ <span class="dd-hint">(cả người mua có MST và không MST - gộp chung khách “Người tiêu dùng”)</span></label>
        </div>
        <div class="btn-row" style="margin-top:10px">
          <button class="btn btn-primary btn-tim" id="btnTongHop" disabled title="Tải / đọc XML các hóa đơn bán ra đã chọn, cộng theo từng mặt hàng, tạo file Excel chi tiết và chuyển chứng từ tổng hợp sang phần mềm">Tổng hợp HĐ bán lẻ → 1 chứng từ</button>
          <span class="dd-hint">Hóa đơn thay thế / điều chỉnh / hủy, ngoại tệ luôn nhập riêng. Hóa đơn đã có trong phần mềm hoặc đã tổng hợp trước đó được bỏ qua (không nhân đôi).</span>
        </div>
      </div>
      <div class="btn-row" style="margin-top:16px">
        <button class="btn btn-primary btn-lg" id="btnDownload" disabled>Tải hàng loạt</button>
        <button class="btn btn-primary btn-lg btn-cam" id="btnDuaVaoPM" style="display:none" title="Đưa các hóa đơn đã chọn (đã tải về máy) vào phần mềm từ file trên máy - không tải lại. Đang tích “Tổng hợp hóa đơn bán lẻ” (thẻ Bán ra) thì tổng hợp theo cách gộp đã chọn.">Đưa HĐ đã tải vào phần mềm</button>
        <button class="btn btn-ghost" id="btnStop" style="display:none">Dừng lại</button>
        <button class="btn btn-ghost" id="btnMoExcel" title="Mở file Excel mới nhất tool đã tạo (bảng kê hóa đơn / tổng hợp bán lẻ)">Mở file Excel</button>
      </div>
      <div class="progress-block" id="progressBlock">
        <div class="progress-top">
          <div class="progress-figure"><span id="pDone">0</span><span class="of"> / <span id="pTotal">0</span> hóa đơn</span></div>
          <div class="progress-pct" id="pPct">0%</div>
        </div>
        <div class="rail"><div class="rail-fill" id="railFill"></div></div>
        <div class="progress-meta">
          <span class="ok">Thành công <b id="pOk">0</b></span>
          <span class="skip">Bỏ qua vì đã có <b id="pSkip">0</b></span>
          <span class="skip" title="Hóa đơn không mã (ngân hàng, điện, nước…): cổng thuế không giữ XML gốc. Dữ liệu vẫn sang phần mềm. Không phải lỗi.">Không có XML gốc <b id="pNoXml">0</b></span>
          <span class="err">Lỗi <b id="pErr">0</b></span>
        </div>
        <div class="current-file" id="pCurrent"></div>
        <div class="btn-row" style="margin-top:8px"><button class="btn btn-ghost" id="btnMoExcelTH" style="display:none">Mở file Excel chi tiết</button><span id="dsExcel" style="display:contents"></span></div>
        <div id="khungLoi" class="tt-canh" style="display:none">
          <div class="btn-row"><b id="loiTieuDe"></b><button class="btn btn-primary" id="btnTaiLaiLoi" type="button" title="Chỉ tải lại các hóa đơn bị lỗi của lần tải vừa rồi (cùng thư mục, cùng loại file)">Tải lại HĐ lỗi</button></div>
          <details style="margin-top:6px"><summary class="sum-mo">Xem danh sách hóa đơn lỗi</summary><div id="dsLoi" class="mono" style="white-space:normal;line-height:1.7"></div></details>
        </div>
      </div>
      <div class="note"><b>Tool sẽ tự làm giúp bạn:</b>
        <ul>
          <li>Tải file .zip của từng hóa đơn rồi giải nén, chỉ giữ lại file bạn cần</li>
          <li>File PDF được in ra từ chính bản in hóa đơn của Cục Thuế, giống hệt bản bạn tải thủ công</li>
          <li>Đặt tên file theo dạng <span style="font-family:var(--mono)">20260816_C26TYY_00000202_CTY-4CORE.xml</span> (bản PDF cùng tên, đuôi .pdf)</li>
          <li>File nào đã có sẵn trong thư mục thì bỏ qua, không tải lại; cứ 200 hóa đơn tool chuyển sang phần mềm một lần (tắt tool giữa chừng không mất hóa đơn đã tải)</li>
          <li>Tải lỗi / bị ngắt: bấm “Làm mới” để thấy hóa đơn đã tải về máy mà chưa vào phần mềm, rồi “Đưa HĐ đã tải vào phần mềm”</li>
          <li>Cổng thuế báo chặn (“hành vi không hợp lệ”): tool dừng ngay, đợi khoảng 30 phút rồi tải tiếp</li>
          <li>Hóa đơn nào lỗi mạng sẽ thử lại tối đa 3 lần</li>
          <li>Bán lẻ nhiều hóa đơn: nút “Tổng hợp HĐ bán lẻ” gộp hóa đơn bán ra 1 ngày / nhiều ngày / 1 tuần thành 1 chứng từ (cộng theo từng mặt hàng), kèm file Excel chi tiết từng hóa đơn</li>
          <li>File Excel gồm 3 sheet: Bảng kê hóa đơn · Chi tiết hàng hóa · Tổng hợp theo thuế suất</li>
        </ul>
      </div>
    </div>
  </section>

  <section class="card" id="cardDK">
    <div class="card-head"><span class="eyebrow">Bước 5</span><h2>Bảng kê định khoản AI — xem, sửa trước khi lập chứng từ</h2>
      <span class="chip" id="dkChip" style="margin-left:auto"><span class="dot"></span><span id="dkChipText">Chưa có</span></span></div>
    <div class="card-body">
      <div class="btn-row">
        <button class="btn btn-primary" id="btnDK" title="Phần mềm UNESCO gửi định khoản AI (mã đối tượng, mã hàng, tính chất, TK Nợ / Có, thuế, thanh toán) của các hóa đơn đã vào phần mềm trong kỳ đang chọn ở Bước 2, theo thẻ Mua vào / Bán ra đang xem">AI định khoản kỳ đang chọn</button>
        <button class="btn btn-ghost" id="btnDKExcel" title="Xuất bảng kê định khoản ra Excel: Định khoản từng dòng hàng · Bút toán từng hóa đơn · Tổng hợp theo cặp TK">Xuất Excel định khoản</button>
        <select id="dkLoc" style="width:auto;min-width:200px;margin:0">
          <option value="">Tất cả hóa đơn</option><option value="chua">Chưa hạch toán</option>
          <option value="can">Cần xử lý (thiếu mã / cần xem / lỗi)</option><option value="san">Sẵn sàng lập chứng từ</option>
          <option value="ht">Đã hạch toán</option></select>
        <input type="text" id="dkTim" placeholder="Tìm số HĐ, đối tác, MST, tên hàng, TK…" style="width:240px;margin:0">
        <span id="dkNote" style="font-size:12.5px;color:var(--ink-soft)"></span>
      </div>
      <div id="dkTomTat" style="display:none;margin-top:12px;padding:10px 12px;border-radius:8px;background:#F1F5F9;font-size:13px;line-height:1.6"></div>
      <div class="tablewrap" style="margin-top:12px">
        <table><thead><tr>
          <th>STT</th><th>Ngày</th><th>Ký hiệu · Số HĐ</th><th>Đối tác</th><th>Mã ĐT</th>
          <th style="text-align:right">Chưa thuế</th><th style="text-align:right">Thuế</th>
          <th>Định khoản AI (Nợ / Có : số tiền)</th><th>Thanh toán</th><th>Trạng thái AI</th><th></th>
        </tr></thead><tbody id="dkBody"></tbody></table>
        <div class="empty" id="dkEmpty"><strong>Chưa có bảng kê định khoản</strong>
        Chọn kỳ ở Bước 2, thẻ Mua vào / Bán ra, rồi bấm “AI định khoản kỳ đang chọn”. Công cụ tự hỏi lại phần mềm sau mỗi lần tải xong.</div>
      </div>
      <div class="note"><b>Định khoản trước khi lập chứng từ:</b>
        <ul>
          <li>Hóa đơn tải về được chuyển sang phần mềm UNESCO; AI của phần mềm phân tích (mã đối tượng, mã hàng, tính chất, TK) theo Quy tắc hạch toán và những gì đã học</li>
          <li>Bấm “Sửa” ở một hóa đơn (hoặc ô Định khoản AI ở bảng Bước 3) để đổi TK Nợ / TK doanh thu, tính chất dòng hàng, thanh toán (công nợ / tiền mặt), hoặc đánh dấu cả hóa đơn là Chi phí / NVL / Hàng hóa</li>
          <li>TK, tính chất áp cho mọi dòng CÙNG TÊN + ĐVT của đối tác đó chưa hạch toán và AI ghi nhớ cho lần sau; phần mềm phân tích lại rồi gửi bảng kê mới về đây</li>
          <li>Hóa đơn đã hạch toán chỉ xem. Lập chứng từ vẫn ở màn hình AI của phần mềm (Bước 2 - xem trước từng phiếu); Thiếu mã: tạo mã ở Bước 1</li>
        </ul>
      </div>
    </div>
  </section>
  </div>

  <div id="paneHS" hidden>
  <section class="card">
    <div class="card-head"><span class="eyebrow">Bước 1</span><h2>Mở Cổng dịch vụ công và đăng nhập</h2>
      <span class="chip" id="hsChip" style="margin-left:auto"><span class="dot"></span><span id="hsChipText">Chưa mở</span></span></div>
    <div class="card-body">
      <div class="btn-row">
        <button class="btn btn-primary" id="hsMo">Mở Cổng dịch vụ công (Chrome)</button>
        <span class="hs-nho">Chrome mở trang Tra cứu hồ sơ của dichvucong.gdt.gov.vn. Anh/chị tự đăng nhập (tên đăng nhập MST-QL, mật khẩu, mã xác nhận). Tool không đọc, không lưu mật khẩu; mỗi mã số thuế một hồ sơ Chrome riêng nên lần sau Chrome tự điền.</span>
      </div>
    </div>
  </section>

  <section class="card">
    <div class="card-head"><span class="eyebrow">Bước 2</span><h2>Nhận kết quả tra cứu hồ sơ đã nộp</h2></div>
    <div class="card-body">
      <div class="btn-row">
        <button class="btn btn-primary" id="hsNghe">Bắt đầu nhận kết quả</button>
        <button class="btn btn-ghost" id="hsDungNghe" style="display:none">Dừng nhận</button>
        <span id="hsBao" class="hs-nho"></span>
      </div>
      <div class="note"><b>Trên cửa sổ Chrome, anh/chị làm như khi tra cứu bình thường:</b>
        <ul>
          <li>Bấm TRA CỨU HỒ SƠ, chọn Từ ngày và Đến ngày (nên tra cả năm để tool biết kỳ nào chưa nộp)</li>
          <li>Gõ mã xác nhận rồi bấm Tìm kiếm - tool tự đọc bảng kết quả hiện trên trang</li>
          <li>Kết quả nhiều trang: bấm sang từng trang, tool đọc tiếp</li>
          <li>Hồ sơ nộp qua hệ thống Thuế điện tử: tra ở tab thứ hai, rồi mở chi tiết một hồ sơ bằng tay để tool học đường mở chi tiết</li>
        </ul>
      </div>
      <div class="hs-nho" style="margin-top:10px">Tool không đọc được bảng / trang chi tiết (Cổng đổi giao diện)? Mở đúng trang đó trên Chrome rồi bấm
        <button class="hs-mo" id="hsChanDoan">Lưu cấu trúc trang</button> và gửi tệp vừa lưu cho người hỗ trợ.
        Tệp không có mật khẩu, mã xác nhận, ảnh captcha; có tên và mã số thuế của doanh nghiệp đang xem.</div>
    </div>
  </section>

  <section class="card">
    <div class="card-head"><span class="eyebrow">Bước 3</span><h2>Lấy chi tiết, thông báo và tờ khai</h2></div>
    <div class="card-body">
      <div class="btn-row">
        <button class="btn btn-primary" id="hsChiTiet">Lấy chi tiết các hồ sơ mới</button>
        <label class="check"><input type="checkbox" id="hsLamLai"> Lấy lại cả hồ sơ đã lấy</label>
        <button class="btn btn-ghost" id="hsDung" style="display:none">Dừng</button>
      </div>
      <div class="hs-nho" style="margin-top:8px">Tool lần lượt mở trang chi tiết từng hồ sơ (trang này không hỏi mã xác nhận), đọc trạng thái, bấm Xem thông báo / Xem tài liệu và tải các tệp về. Tờ khai XML được đọc để đối chiếu và tính số phải nộp.</div>
      <div class="progress-block" id="hsTienDo">
        <div class="progress-top">
          <div class="progress-figure"><span id="hsXong">0</span><span class="of"> / <span id="hsTong">0</span> hồ sơ</span></div>
          <div class="progress-pct" id="hsPct">0%</div>
        </div>
        <div class="rail"><div class="rail-fill" id="hsRail"></div></div>
        <div class="current-file" id="hsHienTai"></div>
      </div>
    </div>
  </section>

  <section class="card">
    <div class="card-head"><span class="eyebrow">Kết quả</span><h2>Hồ sơ thuế</h2>
      <div class="btn-row" style="margin-left:auto">
        <button class="btn btn-ghost" id="hsLamMoi">Làm mới</button>
        <button class="btn btn-primary" id="hsXuat">Xuất báo cáo và gửi sang UNESCO</button>
      </div>
    </div>
    <div class="subtabs" id="hsTabs">
      <div class="subtab-item"><button class="hstab" aria-selected="true" data-v="hs">Hồ sơ đã nộp<span class="count" id="hsC1">0</span></button></div>
      <div class="subtab-item"><button class="hstab" aria-selected="false" data-v="dc">Đối chiếu số liệu<span class="count" id="hsC2">0</span></button></div>
      <div class="subtab-item"><button class="hstab" aria-selected="false" data-v="tb">Thông báo<span class="count" id="hsC3">0</span></button></div>
      <div class="subtab-item"><button class="hstab" aria-selected="false" data-v="pn">Số thuế phải nộp<span class="count" id="hsC4">0</span></button></div>
      <span class="loai-note" id="hsGhiChu"></span>
    </div>
    <div class="tablewrap" id="hsBang" style="max-height:560px"></div>
  </section>
  </div>
</div>

<div class="overlay" id="overlay"><div class="modal">
  <h3 id="mTitle">Thông báo</h3>
  <p id="mBody"></p>
  <p class="small" id="mLog"></p>
  <div class="btn-row" style="margin-top:16px">
    <button class="btn btn-primary" id="mClose">Đã hiểu</button>
    <button class="btn btn-ghost" id="mOpenLog">Mở file nhật ký</button>
  </div>
</div></div>

<script>
const $ = id => document.getElementById(id);
// GD112: an phan dinh khoan AI tren man hinh tai hoa don (anh Thang 03/10/2026): the Buoc 5, cot Dinh khoan AI, tu hoi phan mem.
//   Doi thanh false de hien lai (ma GD106 giu nguyen).
var AN_DINH_KHOAN = true;
document.body.classList.toggle("an-dk", AN_DINH_KHOAN);
// GD30: chon nhanh ky tra cuu theo thang / quy / ca nam. Ngay ket thuc khong vuot qua hom nay.
function kyKhoang(ky, nam){
  let m1, m2;
  if(ky === "N"){ m1 = 1; m2 = 12; }
  else if(ky[0] === "Q"){ const q = parseInt(ky.slice(1)); m1 = (q-1)*3+1; m2 = q*3; }
  else { m1 = m2 = parseInt(ky.slice(1)); }
  const p = n => String(n).padStart(2,"0");
  const cuoi = new Date(nam, m2, 0).getDate();
  return [nam+"-"+p(m1)+"-01", nam+"-"+p(m2)+"-"+p(cuoi)];
}
function chonKy(){
  const ky = $("fKy").value, nam = parseInt($("fNam").value);
  if(!ky || !nam) return;
  let [tu, den] = kyKhoang(ky, nam);
  const n = new Date(), hn = n.getFullYear()+"-"+String(n.getMonth()+1).padStart(2,"0")+"-"+String(n.getDate()).padStart(2,"0");
  if(den > hn && tu <= hn) den = hn;
  $("fFrom").value = tu; $("fTo").value = den;
}
let DATA = {dt:[], mtt:[]};
let kind = "dt", direction = "ban";
let picked = new Set();
let timer = null;
let DUONG_NHAT_KY = "";

const money = n => (Number(n)||0).toLocaleString('vi-VN');

function baoLoi(tieuDe, noiDung){
  $("mTitle").textContent = tieuDe;
  $("mBody").textContent = noiDung + "\n\nNếu lỗi lặp lại, gửi file nhat-ky.txt cho người hỗ trợ.";
  $("mLog").textContent = "File nhật ký: " + DUONG_NHAT_KY;
  $("overlay").classList.add("show");
}
$("mClose").onclick = () => $("overlay").classList.remove("show");
$("mOpenLog").onclick = () => fetch("/api/mo-nhat-ky");
$("btnLog").onclick = () => fetch("/api/mo-nhat-ky");
$("btnKiemTra").onclick = async () => {
  $("btnKiemTra").disabled = true;
  const r = await goi("/api/kiem-tra-trang-thai", {});
  $("btnKiemTra").disabled = false;
  if(r.ok) $("searchNote").textContent = "Đã kiểm tra lại trạng thái, kết quả đã gửi về phần mềm UNESCO.";
  else baoLoi("Không kiểm tra được", r.loi || "Không rõ lý do.");
};
$("btnAI").onclick = async () => {
  const k = prompt("Nhập khóa Claude API (để trống = xóa khóa). Khóa chỉ lưu trên máy này, không ghi vào nhật ký:");
  if(k === null) return;
  const m = prompt("Model (Enter để giữ mặc định claude-sonnet-4-5):", "claude-sonnet-4-5") || "";
  await goi("/api/luu-khoa-ai", {khoa:k, model:m});
  if(k){ const r = await goi("/api/kiem-tra-ai", {}); if(r.ok){ $("aiKeyState").textContent = "Đã lưu khóa Claude API · kết nối OK"; }
         else baoLoi("Chưa kết nối được Claude", r.loi || ""); }
  else $("aiKeyState").textContent = "";
};

async function goi(duong, body){
  try{
    const opt = body ? {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(body)} : {};
    const r = await fetch(duong, opt);
    return await r.json();
  }catch(e){
    baoLoi("Không liên lạc được với tool",
      "Cửa sổ đen của tool có thể đã bị đóng. Mở lại file tool rồi thử lại.");
    return {ok:false};
  }
}

/* ---- nạp thiết lập đã lưu ---- */
(async function init(){
  const s = await goi("/api/thiet-lap");
  DUONG_NHAT_KY = s.duong_nhat_ky || "";
  if(s.mst) $("mst").value = s.mst;
  if(s.mat_khau) $("pwd").value = s.mat_khau;
  $("remember").checked = !!s.nho_dang_nhap;
  GOI_NHO = s.goi_nho || []; veGoiNho((s.unesco && s.unesco.mst) || s.mst || "");
  if(s.unesco && s.unesco.bat && s.unesco.mst && !$("gnMst").value) $("gnMst").value = s.unesco.mst;
  $("chiMoi").checked = s.chi_tai_moi !== false;
  const dd = s.dinh_dang || ["xml", "excel"];      // GD94: mac dinh kem Excel
  $("ddXml").checked = dd.includes("xml");
  $("ddPdf").checked = dd.includes("pdf");
  $("ddExcel").checked = dd.includes("excel");
  COC_CHROME = s.co_chrome !== false;
  capNhatDinhDang();
  if(s.thu_muc_luu){ $("folderPath").textContent = s.thu_muc_luu; $("folderPath").classList.add("set"); }
  const to = new Date(), from = new Date(); from.setDate(from.getDate()-30);
  const iso = d => d.toISOString().slice(0,10);
  $("fFrom").value = iso(from); $("fTo").value = iso(to);
  $("fNam").value = to.getFullYear();
  UN = s.unesco || null;
  $("cardDK").style.display = (UN && UN.bat) && !AN_DINH_KHOAN ? "" : "none";     // GD106: bang ke dinh khoan chi khi mo tu UNESCO
  if(UN && UN.bat){
    if(UN.tu) $("fFrom").value = UN.tu;
    if(UN.den) $("fTo").value = UN.den;
    if(UN.tu) $("fNam").value = UN.tu.slice(0,4);
    HUONG_QUEUE = UN.huong === "ca" ? ["mua","ban"] : [UN.huong || "mua"];
    chonHuong(HUONG_QUEUE[0]);
    $("useDt").checked = true; $("useMtt").checked = !s.mtt_bo_qua; capNhatLoai();     // đợt 3: sổ không có HĐ máy tính tiền -> không tra, khỏi gõ mã
    MTT_LY_DO = s.mtt_bo_qua ? (s.mtt_ly_do || "") : ""; capNhatLoai();
    $("lblMttChiMua").style.display = "inline-flex"; $("mttChiMua").checked = !!s.mtt_chi_mua;     // đợt 5
    $("mttChiMua").onchange = () => goi("/api/mtt-nho", {chi_mua: $("mttChiMua").checked});
    $("ddXml").checked = true; $("ddPdf").checked = false; $("ddExcel").checked = true; capNhatDinhDang();   // GD94: mac dinh gop Excel
    $("btnFolder").disabled = true;
    $("unBanner").style.display = "block";
    // Chay tu UNESCO: tu mo Chrome de dang nhap (cach duy nhat qua duoc chan 403)
    if(COC_CHROME) setTimeout(() => $("btnChrome").click(), 800);
    $("unBanner").textContent = "Đang chạy cho phần mềm UNESCO · MST " + (UN.mst||"") +
      (UN.tudong ? " · Tự động: chỉ cần gõ mã captcha rồi bấm Đăng nhập, tool sẽ tự tra cứu và tải toàn bộ hóa đơn." : "");
    if(UN.kiemtra){ $("btnKiemTra").style.display = "inline-flex"; }
  }
  if(s.co_khoa_ai) $("aiKeyState").textContent = "Đã lưu khóa Claude API";
  if(UN && UN.bat){ $("lblKhoaBL").style.display = "inline-flex"; apKhoaBL(s.khoa_bl || "tu_dong"); }     // GD109
  if(laNhung()) apNhung(); else moiCaptcha();       // 26/11/2026: cua so nhung khong co o mat khau / ma xac nhan tren trang nay
})();
/* ---- 26/11/2026: chạy trong cửa sổ nhúng của UNESCO XII (/nhung:) - đăng nhập ở thẻ «Trang thuế» của chính cửa sổ đó ---- */
function laNhung(){ return !!(UN && UN.nhung); }
function tenNutDN(){ return laNhung() ? "Đăng nhập cổng thuế trong phần mềm" : "Đăng nhập qua Chrome (khuyên dùng)"; }
function apNhung(){
  try{
    const dt = $("btnLogin").closest("details"); if(dt) dt.style.display = "none";      // không có ô mật khẩu trên trang này
    $("khungGoiNho").style.display = "none"; $("btnThoat").style.display = "none";
    $("btnHienThue").title = "Chuyển sang thẻ «Trang thuế»";
    if(!$("btnChrome").disabled) $("btnChrome").textContent = tenNutDN();
    $("chromeTrangThai").textContent = "Đăng nhập cổng thuế ở thẻ «Trang thuế» ngay trong phần mềm: mã số thuế đã điền sẵn, bạn tự gõ mật khẩu và mã xác nhận rồi bấm Đăng nhập. Chương trình không lưu và không đọc mật khẩu.";
    $("unBanner").textContent = "Đang chạy cho phần mềm UNESCO · MST " + (UN.mst||"") +
      (UN.tudong ? " · Tự động: đăng nhập xong ở thẻ «Trang thuế» là chương trình tự tra cứu và tải toàn bộ hóa đơn." : "");
  }catch(e){}
  try{ vietHoaTrang(); }catch(e){}
}
/* 26/11/2026 đợt 2: lối nhúng không có Chrome và người dùng không biết «tool», «captcha» - đổi chữ HIỂN THỊ (kể cả chữ hiện ra sau này),
   không đổi dữ liệu, không đổi ô nhập. Câu nào chỉ nói về Chrome thì ẩn. */
function vietHoaChu(s){
  // đợt 5: «lối Chrome» / «dùng Chrome» là TÊN LỐI tải (hộp chọn lối của chương trình) - giữ nguyên, không đổi thành «trang thuế trong phần mềm»
  return s.replace(/(lối|dùng) Chrome/g, "$1 §C§").replace(/mã\s+captcha/gi, "mã xác nhận").replace(/captcha/gi, "mã xác nhận")
          .replace(/\bTool\b/g, "Chương trình").replace(/\btool\b/g, "chương trình").replace(/\bTOOL\b/g, "CHƯƠNG TRÌNH")
          .replace(/Hiện trang thuế/g, "Trang thuế").replace(/cửa sổ trang thuế/gi, "thẻ «Trang thuế»")
          .replace(/qua Chrome/g, "trong phần mềm").replace(/\(Chrome\)/g, "").replace(/hồ sơ Chrome/gi, "hồ sơ trình duyệt")
          .replace(/cửa sổ Chrome/gi, "thẻ «Trang thuế»").replace(/\bChrome\b/g, "trang thuế trong phần mềm").replace(/§C§/g, "Chrome");
}
function vietHoaNut(n){
  if(n.nodeType === 3){
    const p = n.parentNode && n.parentNode.nodeName;
    if(p === "SCRIPT" || p === "STYLE" || p === "TEXTAREA") return;
    const cu = n.nodeValue; if(!cu || !/captcha|tool|Chrome/i.test(cu)) return;
    const moi = vietHoaChu(cu); if(moi !== cu) n.nodeValue = moi;
    return;
  }
  if(n.nodeType !== 1 || n.nodeName === "SCRIPT" || n.nodeName === "STYLE" || n.nodeName === "svg") return;
  for(const a of ["title", "placeholder"]){
    const v = n.getAttribute && n.getAttribute(a);
    if(v && /captcha|tool|Chrome/i.test(v)){ const m = vietHoaChu(v); if(m !== v) n.setAttribute(a, m); }
  }
  for(let c = n.firstChild; c; c = c.nextSibling) vietHoaNut(c);
}
function vietHoaTrang(){
  vietHoaNut(document.body);
  new MutationObserver(ds => { for(const d of ds){
    if(d.type === "characterData") vietHoaNut(d.target);
    else for(const x of d.addedNodes) vietHoaNut(x);
  } }).observe(document.body, {subtree: true, childList: true, characterData: true});
}
/* ---- GD109: khoá hóa đơn bán lẻ (bán ra, người mua không MST) theo công ty ---- */
var KHOA_BL = "tu_dong";        // var: khong TDZ (capNhat co the goi truoc)
var TEN_KHOA_BL = {tu_dong:"Đưa từng tờ vào phần mềm", xac_nhan:"Tải về, chờ duyệt", tong_hop:"Gộp mỗi ngày thành 1 chứng từ"};     // GD112: ten de hieu
var GIAI_KHOA_BL = {tu_dong:"Tải về là chuyển vào phần mềm từng hóa đơn (như trước).",
  xac_nhan:"Tải về chỉ lưu trên máy; vào phần mềm khi bấm Làm mới → Đưa HĐ đã tải vào phần mềm.",
  tong_hop:"Không vào phần mềm từng tờ: tải xong tự gộp mỗi ngày đã qua thành 1 chứng từ BKBL (hóa đơn hôm nay gộp ở lần tải sau)."};
function apKhoaBL(cd){
  KHOA_BL = TEN_KHOA_BL[cd] ? cd : "tu_dong";
  $("selKhoaBL").value = KHOA_BL;
  if($("khoaBLGiai")) $("khoaBLGiai").textContent = GIAI_KHOA_BL[KHOA_BL] || "";          // GD112
  const th = KHOA_BL === "tong_hop";
  if(!th && $("chkTHBL").disabled) $("chkTHBL").checked = false;     // roi khoa Chi tong hop ngay: tra o Tong hop ve chua tich
  if(th){ $("chkTHBL").checked = true; $("thSoNgay").value = "1";
    const ntd = document.querySelector('input[name="thPhamVi"][value="ntd"]'); if(ntd) ntd.checked = true; }
  $("chkTHBL").disabled = th; $("thSoNgay").disabled = th;
  document.querySelectorAll('input[name="thPhamVi"]').forEach(x => x.disabled = th);
  if($("unBanner") && UN && UN.bat){
    $("unBanner").dataset.goc = $("unBanner").dataset.goc || $("unBanner").textContent;
    $("unBanner").textContent = $("unBanner").dataset.goc + (KHOA_BL !== "tu_dong" ? " · HĐ bán lẻ: " + TEN_KHOA_BL[KHOA_BL] : "");
  }
  if(typeof capNhat === "function") capNhat();
}
$("selKhoaBL").onchange = async () => {
  const moi = $("selKhoaBL").value, cu = KHOA_BL;
  const giai = {tu_dong:"Hóa đơn bán lẻ tải về được chuyển vào phần mềm TỪNG TỜ ngay (như trước).",
    xac_nhan:"Hóa đơn bán lẻ tải về CHỈ LƯU TRÊN MÁY; vào phần mềm khi anh/chị bấm Làm mới → Đưa HĐ đã tải vào phần mềm (từng tờ hoặc tích Tổng hợp để gộp).",
    tong_hop:"Hóa đơn bán lẻ KHÔNG BAO GIỜ vào phần mềm từng tờ: tải xong tool tự gộp mỗi NGÀY đã qua thành 1 chứng từ BKBL (kèm Excel tổng hợp), kể cả khi tải theo hẹn giờ; hóa đơn hôm nay gộp ở lần tải sau."};
  if(!confirm("Đổi cách xử lý hóa đơn bán lẻ (bán ra, người mua KHÔNG có MST) của công ty này sang: " + TEN_KHOA_BL[moi] + "?\n\n" + giai[moi] +
      "\n\nHóa đơn mua vào và hóa đơn bán có MST người mua không đổi.")){ $("selKhoaBL").value = cu; return; }
  const r = await goi("/api/khoa-ban-le", {che_do: moi});
  if(!r.ok){ $("selKhoaBL").value = cu; baoLoi("Chưa đổi được khoá", r.loi || "Không rõ lý do."); return; }
  apKhoaBL(r.che_do);
  $("searchNote").textContent = "Đã chọn cách xử lý hóa đơn bán lẻ: " + r.ten + ".";
};
let UN = null, HUONG_QUEUE = [];
function chonHuong(dir){
  document.querySelectorAll(".tab").forEach(x=>x.setAttribute("aria-selected", x.dataset.dir===dir ? "true":"false"));
  direction = dir; xoaKetQua();
}
let DANG_TU_DONG = false;
/* 26/11/2026 đợt 3 (chủ DN: «làm gì có thời gian ngồi nhập mã hoài»): tự động chạy HAI PHA.
   Pha "dt": hoá đơn điện tử thường của mọi chiều - tìm và tải XONG trước, không phải chờ ai gõ mã.
   Pha "mtt": sau cùng mới tới hoá đơn máy tính tiền (chỉ khi ô «Tải cả hoá đơn máy tính tiền» đang tick) - lúc này mới hỏi mã;
   bấm «Bỏ qua» ở một chiều thì các chiều còn lại không hỏi nữa. Phần đã tải vẫn giữ, lượt sau tải bù. */
var TD_PHA = "", TD_HUONG_GOC = [], TD_MUON_MTT = false, TD_CO_TAI = false, TD_DA_HOI_MTT = false;
async function chayTuDong(){
  if(!UN || !UN.tudong){ DANG_TU_DONG = false; return; }
  if(!TD_PHA){
    if(!HUONG_QUEUE.length){ DANG_TU_DONG = false; return; }
    TD_PHA = "dt"; TD_HUONG_GOC = HUONG_QUEUE.slice(); TD_MUON_MTT = $("useMtt").checked; TD_CO_TAI = false; TD_DA_HOI_MTT = false;
  }
  if(!HUONG_QUEUE.length) return tdHetHuong();
  DANG_TU_DONG = true;
  chonHuong(HUONG_QUEUE[0]);
  $("useDt").checked = TD_PHA === "dt"; $("useMtt").checked = TD_PHA === "mtt"; capNhatLoai();
  await $("btnSearch").onclick();
  if(TD_PHA === "mtt") TD_DA_HOI_MTT = true;
  const co = (DATA.dt||[]).length + (DATA.mtt||[]).length;
  if(co === 0){ HUONG_QUEUE.shift(); return chayTuDong(); }
  // tai lan luot dt roi mtt
  TU_DONG_KIND = ["dt","mtt"].filter(k => (DATA[k]||[]).length);
  await taiKindTiepTheo();
}
async function tdHetHuong(){
  if(TD_PHA === "mtt") TD_PHA = "het";
  if(TD_PHA === "dt" && TD_MUON_MTT && !(UN && UN.hengio)){
    TD_PHA = "mtt"; HUONG_QUEUE = TD_HUONG_GOC.filter(h => h === "mua" || !$("mttChiMua").checked);     // đợt 5: «Chỉ … MUA VÀO»
    if(!HUONG_QUEUE.length) return tdHetHuong();
    $("searchNote").textContent = "Hoá đơn điện tử thường đã xong. Còn hoá đơn máy tính tiền: cổng thuế bắt gõ mã xác nhận cho mỗi chiều…";
    return chayTuDong();
  }
  const coTai = TD_CO_TAI;
  $("useDt").checked = true; $("useMtt").checked = TD_MUON_MTT; capNhatLoai();
  TD_PHA = ""; DANG_TU_DONG = false;
  if(!coTai){
    $("searchNote").textContent = "Không có hóa đơn mới trong khoảng ngày đã chọn. Bạn có thể đóng cửa sổ này.";
    if(UN && UN.hengio){ try{ await goi("/api/hen-gio-xong"); }catch(e){} }
    return;
  }
  $("searchNote").textContent = "Đã tải xong toàn bộ. Quay lại phần mềm UNESCO để phân tích. Có thể đóng cửa sổ này." +
    (laNhung() && /CÓ hoá đơn máy tính tiền/.test(MTT_LY_DO) ? " Lưu ý: sổ này có hoá đơn máy tính tiền – dùng Chrome hoặc Huvisoft để lấy phần đó." : "");     // đợt 5
  if(!(UN && UN.hengio)) setTimeout(() => dkYeuCau(true), 5000);     // GD106: bảng kê định khoản AI (Bước 5)
  if(UN && UN.hengio){ try{ await goi("/api/hen-gio-xong"); $("searchNote").textContent += " (Chạy theo lịch hẹn giờ: tool tự đóng sau 60 giây.)"; }catch(e){} }
}
let TU_DONG_KIND = [];
async function taiKindTiepTheo(){
  if(!TU_DONG_KIND.length){
    HUONG_QUEUE.shift();
    return chayTuDong();
  }
  TD_CO_TAI = true;
  kind = TU_DONG_KIND.shift();
  document.querySelectorAll(".subtab").forEach(x => x.setAttribute("aria-selected", x.dataset.kind===kind ? "true":"false"));
  picked.clear(); ve();
  $("btnSelectAll").onclick();
  await $("btnDownload").onclick();
}

/* ---- GD145: nhịp sống - đóng trang này (hoặc bấm Thoát) thì tool đóng trang thuế và tự tắt ---- */
const PAGE_ID = Math.random().toString(36).slice(2, 10);
let DANG_TAI_TOOL = false, CHROME_TT_CU = "";
async function guiNhip(){
  try{
    const r = await (await fetch("/api/nhip?id=" + PAGE_ID)).json();
    DANG_TAI_TOOL = !!r.dang_tai;
    $("btnHienThue").style.display = (r.chrome === "da_dang_nhap" || r.chrome === "dang_cho") ? "inline-flex" : "none";
    if(CHROME_TT_CU === "da_dang_nhap" && r.chrome !== "da_dang_nhap"){
      $("statusChip").classList.remove("on");
      $("statusText").textContent = r.chrome === "dong" ? "Trang thuế đã đóng" : "Phiên trang thuế đã hết";
      $("chromeTrangThai").textContent = r.loi || "Phiên trang thuế đã hết — đăng nhập lại trong cửa sổ trang thuế.";
      if(r.chrome === "dong"){ $("btnChrome").disabled = false; $("btnChrome").textContent = tenNutDN(); }
      else theoDoiChrome();
    }
    CHROME_TT_CU = r.chrome;
  }catch(e){}
}
guiNhip(); setInterval(guiNhip, 5000);
window.addEventListener("pagehide", () => { try{ navigator.sendBeacon("/api/thoat", JSON.stringify({id: PAGE_ID})); }catch(e){} });
window.addEventListener("beforeunload", e => { if(DANG_TAI_TOOL){ e.preventDefault(); e.returnValue = ""; } });
$("btnHienThue").onclick = () => goi("/api/chrome-hien");
$("btnThoat").onclick = async () => {
  if(!confirm(DANG_TAI_TOOL ? "Tool đang tải hóa đơn. Dừng tải, đóng trang thuế và tắt tool?" : "Đóng trang thuế và tắt tool tải hóa đơn?")) return;
  try{ await fetch("/api/thoat", {method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({id: PAGE_ID, ngay: true})}); }catch(e){}
  document.body.innerHTML = '<div style="padding:40px;font:16px sans-serif">Đã đóng trang thuế và tắt tool tải hóa đơn. Có thể đóng thẻ này.</div>';
  setTimeout(() => { try{ window.close(); }catch(e){} }, 300);
};

/* ---- captcha ---- */
async function moiCaptcha(){
  $("captchaBox").innerHTML = "…";
  const r = await goi("/api/captcha");
  if(r.ok && r.anh){ $("captchaBox").innerHTML = r.anh; }
  else { $("captchaBox").textContent = "Lỗi"; if(r.loi) baoLoi("Không lấy được mã captcha", r.loi); }
}
$("captchaBox").onclick = () => { $("captcha").value=""; moiCaptcha(); };

/* ---- đăng nhập ---- */
let CHROME_POLL = null, DA_TU_DONG_1 = false;
function theoDoiChrome(){          // GD145: theo dõi đến khi đăng nhập xong / lỗi / cửa sổ trang thuế bị đóng
  if(CHROME_POLL) clearInterval(CHROME_POLL);
  CHROME_POLL = setInterval(async () => {
    const t = await goi("/api/chrome-trang-thai");
    if(t.trang_thai === "da_dang_nhap"){
      clearInterval(CHROME_POLL); CHROME_POLL = null;
      $("btnChrome").disabled = true; $("btnChrome").textContent = laNhung() ? "Đã đăng nhập cổng thuế" : "Đã đăng nhập qua Chrome";
      $("chromeTrangThai").textContent = laNhung()
        ? "Đã nhận phiên làm việc. Việc tra cứu / tải chạy bên trong thẻ «Trang thuế» của cửa sổ này — đừng đóng cửa sổ khi đang tải."
        : "Đã nhận phiên làm việc. Cửa sổ trang thuế đã thu nhỏ xuống thanh tác vụ (bấm “Hiện trang thuế” trên cùng nếu cần xem) — tool tra cứu / tải bên trong cửa sổ đó, đừng đóng nó khi đang tải. Bấm “Thoát” để đóng cả trang thuế lẫn tool.";
      $("statusChip").classList.add("on");
      $("statusText").textContent = (laNhung() ? "Đã đăng nhập · " : "Đã đăng nhập (Chrome) · ") + (t.mst || "");
      CHROME_TT_CU = "da_dang_nhap";
      if(UN && UN.tudong && !DA_TU_DONG_1){ DA_TU_DONG_1 = true; chayTuDong(); }
    } else if(t.trang_thai === "loi" || t.trang_thai === "dong"){
      clearInterval(CHROME_POLL); CHROME_POLL = null;
      $("btnChrome").disabled = false; $("btnChrome").textContent = tenNutDN();
      if(t.trang_thai === "loi") baoLoi(laNhung() ? "Không đăng nhập được cổng thuế" : "Không đăng nhập được qua Chrome", t.loi || "Không rõ lý do.");
      else $("chromeTrangThai").textContent = t.loi || "Cửa sổ trang thuế đã đóng. Bấm nút để mở lại.";
    }
  }, 2000);
}
$("btnChrome").onclick = async () => {
  $("btnChrome").disabled = true; $("btnChrome").textContent = laNhung() ? "Đang chờ đăng nhập…" : "Đang mở Chrome…";
  const r = await goi("/api/chrome-mo");
  if(!r.ok){ baoLoi(laNhung() ? "Chưa nối được trang thuế trong phần mềm" : "Không mở được Chrome", r.loi || "Không rõ lý do."); $("btnChrome").disabled=false; $("btnChrome").textContent=tenNutDN(); return; }
  $("chromeTrangThai").textContent = laNhung()
    ? "Đang chờ bạn đăng nhập ở thẻ «Trang thuế» (tự gõ mật khẩu và mã xác nhận). Đăng nhập xong chờ vài giây — chương trình tự nhận phiên làm việc và chuyển về bảng tải."
    : "Đã mở cửa sổ Chrome tới trang thuế. Đăng nhập (MST / mật khẩu / captcha) MỘT lần trong cửa sổ đó rồi chờ vài giây — tool tự nhận phiên, tự mở trang tra cứu và tự thu nhỏ cửa sổ trang thuế.";
  theoDoiChrome();
};
$("btnHienMk").onclick = () => {
  const o = $("pwd"); const hien = o.type === "password";
  o.type = hien ? "text" : "password"; $("btnHienMk").textContent = hien ? "Ẩn" : "Hiện";
};
$("btnLogin").onclick = async () => {
  if(!$("mst").value.trim() || !$("pwd").value || !$("captcha").value.trim()){
    baoLoi("Thiếu thông tin","Nhập đủ mã số thuế, mật khẩu và mã captcha rồi bấm Đăng nhập."); return;
  }
  $("btnLogin").disabled = true; $("btnLogin").textContent = "Đang đăng nhập…";
  const r = await goi("/api/dang-nhap", {mst:$("mst").value.trim(), mat_khau:$("pwd").value,
                                          captcha:$("captcha").value.trim(), nho:$("remember").checked});
  $("btnLogin").disabled = false; $("btnLogin").textContent = "Đăng nhập";
  if(r.ok){
    $("statusChip").classList.add("on");
    $("statusText").textContent = "Đã đăng nhập · " + r.mst;
    if(UN && UN.tudong) chayTuDong();
  } else {
    baoLoi("Đăng nhập không thành công", r.loi || "Không rõ lý do.");
    $("captcha").value=""; moiCaptcha();
  }
};

/* ---- tabs ---- */
document.querySelectorAll(".tab").forEach(t => t.onclick = () => {
  document.querySelectorAll(".tab").forEach(x=>x.setAttribute("aria-selected","false"));
  t.setAttribute("aria-selected","true"); direction = t.dataset.dir;
  if(DA_DONG_BO) hienDongBo(direction); else xoaKetQua();
});

/* ---- GD30b: Đồng bộ cả kỳ (mua + bán) rồi Tải về những hóa đơn chưa có ---- */
let DA_DONG_BO = false, DANG_SYNC_TAI = false;
function veTomTat(tt){          // GD112: o so lieu Mua vao / Ban ra (giao dien toi)
  if(!tt){ $("syncTomTat").style.display = "none"; return; }
  const o = (ten, d, lop) => !d ? "" : ('<div class="tt-o ' + lop + '"><div class="tt-ten">' + ten + '</div>' +
      '<div class="tt-so">' + d.tong + '<span> hóa đơn</span></div><div class="tt-ct">' +
      '<span class="tt-moi">mới ' + d.moi + '</span>' + (d.tai ? '<span class="tt-cho">đã tải, chưa vào phần mềm ' + d.tai + '</span>' : '') +
      '<span>đã có ' + d.co + '</span><span>đã hạch toán ' + d.ht + '</span>' + (d.khong_xml ? '<span>không có XML gốc ' + d.khong_xml + '</span>' : '') +
      '</div></div>');
  $("syncTomTat").innerHTML = '<div class="tt-ky">Đã đồng bộ kỳ ' + esc(ngayVN($("fFrom").value)) + ' → ' + esc(ngayVN($("fTo").value)) + '</div>' +
      '<div class="tt-luoi">' + o("Mua vào", tt.mua, "mua") + o("Bán ra", tt.ban, "ban") + '</div>' +
      ((tt.ban||{}).bl_cu ? '<div class="tt-canh" id="ttBlCu">Bán ra: ' + tt.ban.bl_cu + ' HĐ bán lẻ (người mua không MST) đang nằm TỪNG TỜ trong phần mềm, chưa lập chứng từ (nhập trước khi chọn Gộp mỗi ngày). Bấm “Tải về hóa đơn chưa có”: tool tự gộp thay thành chứng từ bán lẻ theo ngày.</div>' : '') +
      (((tt.mua||{}).tai || (tt.ban||{}).tai) ? '<div class="tt-canh">Hóa đơn đã tải nhưng chưa vào phần mềm (lần tải trước bị lỗi / bị ngắt): bấm “Tải về hóa đơn chưa có” - tool đưa vào phần mềm từ file trên máy, không tải lại.</div>' : '');
  $("syncTomTat").style.display = "block";
}
async function hienDongBo(dir){
  const r = await goi("/api/dong-bo-xem", {direction: dir});
  if(!r.ok) return;
  DATA = {dt:r.dt||[], mtt:r.mtt||[]}; picked.clear();
  $("cntDt").textContent = DATA.dt.length; $("cntMtt").textContent = DATA.mtt.length;
  if((DATA[kind]||[]).length === 0 && (DATA.dt.length || DATA.mtt.length)){
    kind = DATA.dt.length ? "dt" : "mtt";
    document.querySelectorAll(".subtab").forEach(x => x.setAttribute("aria-selected", x.dataset.kind===kind ? "true" : "false"));
  }
  $("khungDanhDau").style.display = dir==="mua" ? "inline" : "none";
  (DATA[kind]||[]).forEach((x,i)=>{ if(x.pm==="moi"||x.pm==="tai") picked.add(i); });
  veTomTat(r.tom_tat); ve();
}
$("btnSync").onclick = async () => {
  if(!$("fFrom").value || !$("fTo").value){ baoLoi("Thiếu khoảng ngày","Chọn Kỳ (tháng / quý / năm) hoặc Từ ngày – Đến ngày rồi bấm Đồng bộ."); return false; }
  const loai = layLoai();
  $("btnSync").disabled = true; $("btnSync").textContent = "Đang đồng bộ…";
  $("searchNote").textContent = "Đang lấy danh sách mua vào + bán ra của cả kỳ (kỳ dài được chia theo từng tháng rồi gộp lại)…";
  const r = await goi("/api/dong-bo", {mtt_chi_mua: $("mttChiMua").checked, loai: loai.length ? loai : ["dt","mtt"], tu_ngay:$("fFrom").value, den_ngay:$("fTo").value,
    trang_thai:$("fStatus").value, ket_qua:$("fCheck").value, mau_so:$("fMau").value});
  $("btnSync").disabled = false; $("btnSync").textContent = "Đồng bộ hóa đơn (mua + bán)"; $("searchNote").textContent = "";
  if(!r.ok){ baoLoi("Không đồng bộ được", r.loi || "Không rõ lý do."); return false; }
  DA_DONG_BO = true;
  if(r.canh_bao) $("searchNote").textContent = "Lưu ý: " + r.canh_bao;
  await hienDongBo(direction);
  return true;
};
$("btnSyncTai").onclick = async () => {
  if(!DA_DONG_BO){ const ok = await $("btnSync").onclick(); if(!ok) return; }
  const dinh_dang = layDinhDang();
  if(dinh_dang.length === 0){ baoLoi("Chưa chọn việc cần làm","Tick “File XML” ở Bước 4 rồi bấm lại."); return; }
  const r = await goi("/api/tai-dong-bo", {dinh_dang});
  if(!r.ok){ baoLoi("Chưa tải được", r.loi || "Không rõ lý do."); return; }
  veTomTat(r.tom_tat);
  if(r.khong_co_moi){ $("searchNote").textContent = "Không có hóa đơn nào cần tải: mọi hóa đơn của kỳ này đã có trong phần mềm hoặc đã tải trước đó."; return; }
  DANG_SYNC_TAI = true;
  $("progressBlock").classList.add("show"); $("pTotal").textContent = r.tong;
  $("btnDownload").disabled = true; $("btnStop").style.display = "inline-flex";
  if(timer) clearInterval(timer);
  timer = setInterval(theoDoi, 500);
};
document.querySelectorAll(".subtab").forEach(t => t.onclick = () => {
  if(t.disabled) return;
  document.querySelectorAll(".subtab").forEach(x=>x.setAttribute("aria-selected","false"));
  t.setAttribute("aria-selected","true"); kind = t.dataset.kind; picked.clear(); ve();
});

/* ---- 2 ô tick chọn loại hóa đơn cần tra cứu ---- */
function layLoai(){
  const ds = [];
  if($("useDt").checked) ds.push("dt");
  if($("useMtt").checked) ds.push("mtt");
  return ds;
}
function capNhatLoai(){
  const ds = layLoai();
  document.querySelectorAll(".subtab").forEach(t => {
    t.disabled = !ds.includes(t.dataset.kind);
  });
  // neu the dang xem bi bo tick thi chuyen sang the con lai
  if(ds.length && !ds.includes(kind)){
    kind = ds[0];
    document.querySelectorAll(".subtab").forEach(x =>
      x.setAttribute("aria-selected", x.dataset.kind===kind ? "true" : "false"));
    picked.clear(); ve();
  }
  if(ds.length === 0) $("loaiNote").textContent = "Chưa chọn loại hóa đơn nào — tick ít nhất 1 ô";
  else if(ds.length === 2) $("loaiNote").textContent = "Sẽ tra cứu cả 2 loại hóa đơn (hoá đơn máy tính tiền: cổng thuế bắt gõ mã xác nhận)";
  else $("loaiNote").textContent = "Chỉ tra cứu: " + (ds[0]==="dt" ? "Hóa đơn điện tử" : "Hóa đơn máy tính tiền") +
    (ds[0]==="dt" && MTT_LY_DO ? " — " + MTT_LY_DO + (laNhung() ? "." : ". Muốn tìm lại: tick ô «Tải cả hoá đơn máy tính tiền».") : "");
}
var MTT_LY_DO = "";          // đợt 3: vì sao ô hoá đơn máy tính tiền đang bỏ sẵn (var: init có thể gọi trước dòng này)
$("useMtt").title = "Tải cả hoá đơn máy tính tiền (phải gõ mã xác nhận). Bỏ tick: không tìm loại này, không phải gõ mã. Lựa chọn được nhớ theo sổ.";
$("useDt").onchange = capNhatLoai;
$("useMtt").onchange = () => {          // người dùng tự chọn -> nhớ theo sổ (thắng mọi suy đoán của máy)
  MTT_LY_DO = "";
  if(UN && UN.bat) goi("/api/mtt-nho", {tai: $("useMtt").checked});
  capNhatLoai();
};

/* ---- tìm kiếm ---- */
$("btnSearch").onclick = async () => {
  DA_DONG_BO = false; veTomTat(null);
  if(!$("fFrom").value || !$("fTo").value){
    baoLoi("Thiếu khoảng ngày","Chọn Từ ngày và Đến ngày rồi bấm Tìm kiếm."); return; }
  let loai = layLoai();
  if(direction === "ban" && $("mttChiMua").checked && loai.includes("mtt")){          // đợt 5
    loai = loai.filter(k => k !== "mtt");
    if(!loai.length){ $("searchNote").textContent = "Đang chọn «Chỉ tải hoá đơn máy tính tiền MUA VÀO» nên không tìm hoá đơn máy tính tiền bán ra."; return; }
  }
  if(loai.length === 0){
    baoLoi("Chưa chọn loại hóa đơn",
      "Xuống Bước 3 và tick vào “Hóa đơn điện tử” hoặc “Hóa đơn có mã khởi tạo từ máy tính tiền” rồi tìm lại."); return; }
  $("btnSearch").disabled = true; $("btnSearch").textContent = "Đang tìm…";
  $("searchNote").textContent = "Đang lấy dữ liệu từ máy chủ Cục Thuế, vui lòng đợi…";
  const r = await goi("/api/tra-cuu", {
    direction, loai, tu_ngay:$("fFrom").value, den_ngay:$("fTo").value,
    trang_thai:$("fStatus").value, ket_qua:$("fCheck").value,
    mst_nguoi_mua:$("fMst").value, ky_hieu:$("fKh").value,
    so_hoa_don:$("fSo").value, mau_so:$("fMau").value,
    giu_bo_qua_mtt: TD_PHA === "mtt" && TD_DA_HOI_MTT          // đợt 3: đã bấm «Bỏ qua» ở chiều trước thì chiều này không hỏi mã nữa
  });
  $("btnSearch").disabled = false; $("btnSearch").textContent = "Tìm kiếm (1 chiều)"; $("searchNote").textContent = "";
  if(!r.ok && TD_PHA === "mtt"){          // đợt 3: pha hoá đơn máy tính tiền của tự động - không bật hộp lỗi chặn màn hình
    DATA = {dt:[], mtt:[]}; picked.clear(); ve();
    $("searchNote").textContent = "Hoá đơn máy tính tiền: " + (r.loi || "chưa lấy được") + " — hoá đơn điện tử thường đã tải xong vẫn giữ.";
    return; }
  if(!r.ok){ baoLoi("Không tìm được hóa đơn", r.loi || "Không rõ lý do."); return; }
  DATA = {dt:r.dt||[], mtt:r.mtt||[]};
  picked.clear();
  $("cntDt").textContent = DATA.dt.length; $("cntMtt").textContent = DATA.mtt.length;
  // tu chuyen sang the co ket qua
  if(!loai.includes(kind) || (DATA[kind].length === 0 && loai.some(k=>DATA[k].length))){
    kind = loai.find(k => DATA[k].length) || loai[0];
    document.querySelectorAll(".subtab").forEach(x =>
      x.setAttribute("aria-selected", x.dataset.kind===kind ? "true" : "false"));
  }
  if(r.canh_bao) $("searchNote").textContent = "Lưu ý: " + r.canh_bao;
  $("khungDanhDau").style.display = direction==="mua" ? "inline" : "none";
  (DATA[kind]||[]).forEach((x,i)=>{ if(x.pm==="moi"||x.pm==="tai") picked.add(i); });   // GD29: mặc định chỉ chọn hóa đơn mới (GD94: + đã tải chưa vào PM)
  ve();
};
$("btnReset").onclick = () => {
  ["fMst","fCccd","fKh","fSo"].forEach(i=>$(i).value="");
  $("fStatus").selectedIndex=0; $("fCheck").selectedIndex=0; $("fMau").selectedIndex=0;
  $("fUyNhiem").checked=false; xoaKetQua();
};
function xoaKetQua(){
  DATA={dt:[],mtt:[]}; picked.clear();
  $("cntDt").textContent="0"; $("cntMtt").textContent="0";
  $("progressBlock").classList.remove("show"); $("searchNote").textContent=""; ve();
}

/* ---- vẽ bảng ---- */
function ve(){
  const rows = DATA[kind] || [];
  const tb = $("tbody"); tb.innerHTML = "";
  $("emptyBox").style.display = rows.length ? "none" : "block";
  rows.forEach((r,i)=>{
    const tr = document.createElement("tr");
    if(picked.has(i)) tr.className="picked";
    tr.innerHTML =
      '<td><input type="checkbox" data-i="'+i+'" '+(picked.has(i)?"checked":"")+'></td>'+
      '<td class="mono">'+(i+1)+'</td><td class="mono">'+r.mst+'</td>'+
      '<td class="mono">'+r.mau+'</td><td class="mono">'+r.kh+'</td>'+
      '<td class="mono">'+r.so+'</td><td class="mono">'+r.ngay+'</td>'+
      '<td><span class="seller"></span><span class="seller-mst"></span></td>'+
      '<td class="num">'+money(r.base)+'</td><td class="num">'+money(r.vat)+'</td>'+
      '<td class="num"><b>'+money(r.total)+'</b></td>'+
      '<td><span class="tag"></span></td>'+
      '<td><span class="pm"></span></td><td><span class="loai"></span></td>'+
      '<td class="col-dk"><button class="linkbtn dkc" style="white-space:nowrap;font-family:var(--mono);font-size:12px"></button></td>'+
      '<td style="white-space:nowrap"><button class="linkbtn" data-xem="'+i+'">Xem</button> <button class="linkbtn" data-tc="'+i+'">Tra cứu</button></td>';
    tr.querySelector(".seller").textContent = r.ten;
    tr.querySelector(".seller-mst").textContent = r.file;
    tr.querySelector(".tag").textContent = r.trang_thai;
    const pm = tr.querySelector(".pm");
    pm.textContent = TEN_PM[r.pm] || "Mới";
    pm.style.cssText = "padding:2px 8px;border-radius:10px;font-size:12px;font-weight:600;" + (MAU_PM[r.pm] || MAU_PM.moi);
    tr.querySelector(".loai").textContent = TEN_LOAI[r.loai] || "";
    const dk = (typeof dkCua === "function") ? dkCua(r.khoa) : null, bdk = tr.querySelector(".dkc");     // GD106
    if(dk){ bdk.textContent = dk.dk || TEN_TT_DK[dk.tt] || "Xem"; bdk.title = (TEN_TT_DK[dk.tt] || "") + (dk.ghi ? " - " + dk.ghi : "") + " · bấm để xem / sửa định khoản";
      bdk.style.color = (dk.tt === "SAN_SANG" || dk.tt === "DA_HACH_TOAN") ? "" : "#B45309"; bdk.onclick = () => moHopDK(dk); }
    else bdk.style.display = "none";
    tb.appendChild(tr);
  });
  tb.querySelectorAll("button[data-xem]").forEach(b => b.onclick = () => xemHoaDon(Number(b.dataset.xem)));
  tb.querySelectorAll("button[data-tc]").forEach(b => b.onclick = () => traCuuHoaDon(Number(b.dataset.tc)));
  tb.querySelectorAll("input[type=checkbox]").forEach(cb=>{
    cb.onchange = () => {
      const i = Number(cb.dataset.i);
      cb.checked ? picked.add(i) : picked.delete(i);
      cb.closest("tr").classList.toggle("picked", cb.checked);
      capNhat();
    };
  });
  capNhat();
}
function capNhat(){
  const rows = DATA[kind] || [];
  $("selCount").textContent = picked.size;
  $("totalCount").textContent = rows.length;
  $("checkAll").checked = rows.length>0 && picked.size===rows.length;
  $("checkAll").indeterminate = picked.size>0 && picked.size<rows.length;
  let sum = 0; picked.forEach(i => { if(rows[i]) sum += Number(rows[i].total)||0; });
  $("sumMoney").textContent = picked.size ? "Tổng thanh toán đã chọn: " + money(sum) + " ₫" : "";
  $("btnDownload").disabled = picked.size===0;
  const batTHBL = $("chkTHBL").checked;       // GD92: chi khi tich "Tong hop hoa don ban le" moi hien / dung duoc
  $("khungTHBL").style.display = batTHBL ? "block" : "none";
  $("thChiBan").style.display = batTHBL && direction !== "ban" ? "block" : "none";
  $("btnTongHop").disabled = !batTHBL || picked.size===0 || direction !== "ban";
  if(typeof capNhatDuaVao === "function") capNhatDuaVao();       // GD94
}
/* ---- GD94: nút Đưa HĐ đã tải vào phần mềm (theo ô tích Tổng hợp hóa đơn bán lẻ) ---- */
function capNhatDuaVao(){
  const co = ["dt","mtt"].some(k => (DATA[k]||[]).some(x => x.pm==="tai"));
  $("btnDuaVaoPM").style.display = co ? "inline-flex" : "none";
  $("btnDuaVaoPM").textContent = ($("chkTHBL").checked && direction === "ban") ? "Đưa HĐ đã tải vào phần mềm (tổng hợp bán lẻ)" : "Đưa HĐ đã tải vào phần mềm";
  if(typeof KHOA_BL !== "undefined" && KHOA_BL === "tong_hop" && direction === "ban") $("btnDuaVaoPM").textContent = "Đưa HĐ đã tải vào phần mềm (gộp mỗi ngày)";
}
$("checkAll").onchange = e => e.target.checked ? chonHet() : boHet();
$("btnSelectAll").onclick = chonHet;
$("btnClearAll").onclick = boHet;
function chonHet(){ (DATA[kind]||[]).forEach((_,i)=>picked.add(i)); ve(); }
function boHet(){ picked.clear(); ve(); }

/* ---- GD29: trạng thái trong phần mềm, chọn hóa đơn mới, đánh dấu, Xem / Tra cứu ---- */
const TEN_PM = {ht:"Đã hạch toán", co:"Đã có", moi:"Mới", tai:"Đã tải, chưa vào PM"};
const MAU_PM = {ht:"background:#E0F4F5;color:#1D4ED8", co:"background:#EEF1F5;color:#475569", moi:"background:#E6F6EC;color:#15803D",
                tai:"background:#FFF4E5;color:#B45309"};
const TEN_LOAI = {CP:"Chi phí", NVL:"NVL", HH:"Hàng hoá"};
function chonMoi(){ picked.clear(); (DATA[kind]||[]).forEach((r,i)=>{ if(r.pm==="moi"||r.pm==="tai") picked.add(i); }); ve(); }
$("btnSelectNew").onclick = chonMoi;
document.querySelectorAll("#khungDanhDau button[data-dd]").forEach(b => b.onclick = async () => {
  if(picked.size===0){ baoLoi("Chưa chọn hóa đơn","Tick các hóa đơn cần đánh dấu rồi bấm lại."); return; }
  const r = await goi("/api/danh-dau", {kind, direction, loai:b.dataset.dd, chi_so:Array.from(picked)});
  if(!r.ok){ baoLoi("Chưa đánh dấu được", r.loi || "Không rõ lý do."); return; }
  const rows = DATA[kind]||[];
  picked.forEach(i => { if(rows[i] && rows[i].pm!=="ht") rows[i].loai = b.dataset.dd; });
  ve();
  $("searchNote").textContent = "Đã đánh dấu " + r.so + " hóa đơn" + (r.bo_qua ? (", bỏ qua " + r.bo_qua + " hóa đơn đã hạch toán") : "") +
    (r.da_gui_pm ? ". Phần mềm UNESCO sẽ tự nhận và phân tích lại." : ".");
});
function hopThoai(tieuDe, html){
  let o = $("hopGD29");
  if(!o){ o = document.createElement("div"); o.id = "hopGD29";
    o.style.cssText = "position:fixed;inset:0;background:rgba(15,23,42,.45);z-index:999;display:flex;align-items:center;justify-content:center";
    o.innerHTML = '<div style="background:#fff;border-radius:12px;max-width:1000px;width:94%;max-height:88vh;overflow:auto;padding:20px 24px;box-shadow:0 20px 60px rgba(0,0,0,.3)">'+
      '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px"><h2 id="hopGD29T" style="margin:0;font-size:18px"></h2><button class="btn btn-ghost" id="hopGD29X">Đóng</button></div><div id="hopGD29N"></div></div>';
    document.body.appendChild(o);
    o.onclick = e => { if(e.target===o) o.style.display="none"; };
    $("hopGD29X").onclick = () => o.style.display="none";
  }
  $("hopGD29T").textContent = tieuDe; $("hopGD29N").innerHTML = html; o.style.display = "flex";
}
function esc(x){ const d=document.createElement("div"); d.textContent = (x===null||x===undefined) ? "" : String(x); return d.innerHTML; }
async function xemHoaDon(i){
  const r0 = (DATA[kind]||[])[i]; if(!r0) return;
  hopThoai("Hóa đơn " + r0.kh + " số " + r0.so, "Đang đọc hóa đơn…");
  const r = await goi("/api/xem", {kind, direction, i});
  if(!r.ok){ hopThoai("Không xem được hóa đơn", esc(r.loi||"")); return; }
  const d = r.dau||{};
  let h = '<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px 24px;font-size:13.5px;margin-bottom:12px">'+
    '<div><b>Người bán:</b> '+esc(d.TenNguoiBanNguoiXuatHang)+'<br>MST '+esc(d.MSTNguoiBanNguoiXuatHang)+'<br>'+esc(d.DiaChiNguoiBan)+'</div>'+
    '<div><b>Người mua:</b> '+esc(d.TenNguoiMuaNguoiNhanHang)+'<br>MST '+esc(d.MSTNguoiMuaNguoiNhanHang)+'</div>'+
    '<div>Mẫu số '+esc(d.KyHieuMauSo)+' · Ký hiệu '+esc(d.KyHieuHoaDon)+' · Số '+esc(d.SoHoaDon)+' · Ngày '+esc(d.NgayLap)+'</div>'+
    '<div>'+esc(d.TrangThaiHoaDon)+' · '+esc(d.KetQuaKiemTraHoaDon)+'</div></div>'+
    '<table style="width:100%;font-size:13px"><thead><tr><th>#</th><th>Tên hàng hóa, dịch vụ</th><th>ĐVT</th><th style="text-align:right">SL</th><th style="text-align:right">Đơn giá</th><th style="text-align:right">Thành tiền</th><th>Thuế suất</th><th style="text-align:right">Tiền thuế</th></tr></thead><tbody>';
  (r.dong||[]).forEach((x,k)=>{ h += '<tr><td>'+(k+1)+'</td><td>'+esc(x.ten)+'</td><td>'+esc(x.dvt)+'</td><td class="num">'+money(x.sl)+'</td><td class="num">'+money(x.dg)+'</td><td class="num">'+money(x.tt)+'</td><td>'+esc(x.ts)+'</td><td class="num">'+money(x.thue)+'</td></tr>'; });
  h += '</tbody></table><div style="text-align:right;margin-top:10px;font-size:14px">Chưa thuế <b>'+money(d.tong_chua_thue)+'</b> · Thuế <b>'+money(d.tong_thue)+'</b> · Thanh toán <b>'+money(d.TongTienThanhToan)+'</b></div>'+
    '<div style="margin-top:10px;font-size:12.5px;color:var(--ink-soft)">Nguồn: '+esc(r.nguon)+'</div>';
  if(r.tep){ h += '<div class="btn-row" style="margin-top:12px"><button class="btn btn-ghost" id="xemMoXml">Mở file XML</button>'+(r.co_pdf?' <button class="btn btn-ghost" id="xemMoPdf">Mở file PDF</button>':'')+'</div>'; }
  hopThoai("Hóa đơn " + r0.kh + " số " + r0.so, h);
  if(r.tep){ $("xemMoXml").onclick = () => goi("/api/mo-tep", {tep:r.tep});
    if(r.co_pdf) $("xemMoPdf").onclick = () => goi("/api/mo-tep", {tep:r.tep.slice(0,-4)+".pdf"}); }
}
function traCuuHoaDon(i){
  const r = (DATA[kind]||[])[i]; if(!r) return;
  const o = (nhan, gt) => '<tr><td style="padding:4px 14px 4px 0;color:var(--ink-soft)">'+nhan+'</td><td class="mono" style="font-size:15px"><b>'+esc(gt)+'</b></td></tr>';
  hopThoai("Tra cứu hóa đơn trên cổng của Cục Thuế",
    '<p style="margin-top:0">Trang tra cứu công khai yêu cầu gõ mã captcha nên tool không tra thay được. Bấm nút dưới để mở trang, rồi nhập đúng các thông tin sau:</p><table>'+
    o("MST người bán", r.mst)+o("Loại hóa đơn", "Hóa đơn giá trị gia tăng / bán hàng (theo mẫu số "+r.mau+")")+o("Ký hiệu", r.kh)+o("Số hóa đơn", r.so)+
    o("Tổng tiền thuế", money(r.vat))+o("Tổng tiền thanh toán", money(r.total))+'</table>'+
    '<div class="btn-row" style="margin-top:14px"><a class="btn btn-primary" target="_blank" rel="noopener" href="https://hoadondientu.gdt.gov.vn/">Mở trang tra cứu hoadondientu.gdt.gov.vn</a></div>');
}
/* ---- GD106: Bảng kê định khoản AI - phần mềm UNESCO phân tích, kế toán xem / sửa trước khi lập chứng từ ---- */
var DK = {dau:null, hd:[], tk:[], tk_ten:{}, map:{}, huong:"", luc:"", dang:false};     // var: bang Buoc 3 co the ve truoc khi doan nay chay
const TEN_TT_DK = {SAN_SANG:"Sẵn sàng lập CT", THIEU_MA:"Thiếu mã", CAN_XEM_LAI:"Cần xem lại", LOI:"Không xử lý / lỗi",
                   MOI:"Chưa phân tích", DA_HACH_TOAN:"Đã hạch toán", BO_QUA:"Bỏ qua"};
const MAU_TT_DK = {SAN_SANG:"background:#E6F6EC;color:#15803D", THIEU_MA:"background:#FFF4E5;color:#B45309",
                   CAN_XEM_LAI:"background:#FCEDEB;color:#C0392B", LOI:"background:#FCEDEB;color:#C0392B",
                   DA_HACH_TOAN:"background:#E0F4F5;color:#1D4ED8", MOI:"background:#EEF1F5;color:#475569", BO_QUA:"background:#EEF1F5;color:#475569"};
const TEN_TC_DK = {HH:"Hàng hoá", NVL:"Nguyên vật liệu", CCDC:"Công cụ dụng cụ", DV:"Dịch vụ / chi phí", TP:"Thành phẩm",
                   TSCD:"Tài sản cố định", CK:"Chiết khấu", KM:"Khuyến mại"};
const TEN_NGUON_DK = {NGUOI:"Kế toán đã sửa", DA_HOC:"Đã học", DA_HOC_TK:"Đã học TK", TU_KHOA:"Từ khoá", TU_KHOA_TK:"Từ khoá TK",
                      MA_HD:"Mã trên HĐ", MA_HD_HOC:"Mã trên HĐ", MA_NCC:"Mã NCC", TEN_TUYET_DOI:"Trùng tên", CHI_PHI_AI:"AI: chi phí",
                      CHI_PHI_DA_HOC:"Chi phí đã học", SUY_RA:"Suy ra từ NCC", TUONG_TU:"Tên tương tự"};
const escA = x => esc(x).replace(/"/g, "&quot;").replace(/'/g, "&#39;");     // chuoi dat trong thuoc tinh value="..."
const ngayVN = s => (s && s.length >= 10) ? s.slice(8,10) + "/" + s.slice(5,7) + "/" + s.slice(0,4) : (s || "");
function dkKhoa(k){
  const a = String(k||"").trim().split("|");
  if(a.length < 4) return String(k||"").trim();
  let so = a[3].trim();
  if(/^\d+$/.test(so)) so = so.replace(/^0+/, "") || "0";
  else { const m = so.match(/^[A-Z0-9\/]+-0*(\d+)$/i); if(m) so = m[1].replace(/^0+/, "") || "0"; }
  return [a[0].trim(), a[1].trim(), a[2].trim(), so].concat(a.slice(4)).join("|");
}
function dkCua(khoa){ if(typeof DK === "undefined" || !DK || !DK.dau || DK.huong !== direction) return null; return DK.map[dkKhoa(khoa)] || null; }
function dkNap(r){
  DK.dau = r.dau || null; DK.hd = r.hd || []; DK.tk = r.tk || []; DK.tk_ten = r.tk_ten || {};
  DK.huong = (DK.dau||{}).huong || "mua"; DK.luc = (DK.dau||{}).luc || "";
  DK.map = {};
  DK.hd.forEach((h,i) => { h._i = i; DK.map[h.kc2 || dkKhoa(h.kc || h.khoa)] = h; DK.map[dkKhoa(h.khoa)] = h; });
  dkVe(); ve();
}
function dkBan(bat, chu){
  $("btnDK").disabled = bat;
  $("btnDK").textContent = bat ? "Đang chờ phần mềm…" : "AI định khoản kỳ đang chọn";
  if(chu !== undefined) $("dkNote").textContent = chu;
}
async function dkCho(q){
  const het = Date.now() + 75000;     // phan mem nhan moi 3 giay; dong ho nhan ket qua dang tat thi dong ho hen gio bat lai (toi 60 giay)
  while(Date.now() < het){
    const r = await goi("/api/dk-ket-qua", q);
    if(r && r.ok && r.co && r.xong && r.hd){ if(!dkHopMo()) dkNap(r); return r; }
    await new Promise(ok => setTimeout(ok, 1500));
  }
  return null;
}
const DK_CHUA_TRA_LOI = "Giữ màn hình AI - Hoá đơn điện tử của UNESCO đang mở (công cụ phải được mở từ nút “Tải hoá đơn từ Cơ quan Thuế” trên màn hình đó) và không để phiếu chứng từ / hộp thông báo nào đang mở trên màn hình AI, rồi bấm lại. Phần mềm nhận yêu cầu mỗi 3 giây.";
async function dkYeuCau(im){
  if(AN_DINH_KHOAN && im) return;          // GD112: dinh khoan dang an - khong tu hoi phan mem sau khi tai
  if(!UN || !UN.bat){ if(!im) baoLoi("Chưa dùng được bảng kê định khoản", "Bảng kê định khoản AI chỉ dùng khi mở công cụ từ phần mềm UNESCO (màn hình AI - Hoá đơn điện tử, nút Tải hoá đơn từ Cơ quan Thuế)."); return; }
  if(!$("fFrom").value || !$("fTo").value){ if(!im) baoLoi("Thiếu khoảng ngày", "Chọn kỳ (tháng / quý / năm) hoặc Từ ngày – Đến ngày ở Bước 2 rồi bấm lại."); return; }
  if(DK.dang) return;
  DK.dang = true;
  dkBan(true, "Đang chờ phần mềm UNESCO phân tích và gửi định khoản " + (direction === "ban" ? "bán ra" : "mua vào") + " " + ngayVN($("fFrom").value) + " → " + ngayVN($("fTo").value) + "…");
  const r = await goi("/api/dk-yeu-cau", {direction, tu_ngay:$("fFrom").value, den_ngay:$("fTo").value});
  if(!r.ok){ DK.dang = false; dkBan(false, ""); if(!im) baoLoi("Chưa gửi được yêu cầu", r.loi || "Không rõ lý do."); return; }
  const kq = await dkCho({id: r.id});
  DK.dang = false;
  if(kq) dkBan(false, "Đã nhận định khoản " + (kq.hd||[]).length + " hóa đơn từ phần mềm lúc " + String((kq.dau||{}).luc||"").slice(11,16) + ".");
  else { dkBan(false, "Phần mềm chưa trả lời."); if(!im) baoLoi("Phần mềm UNESCO chưa trả lời", DK_CHUA_TRA_LOI); }
}
function dkTomTat(){
  const d = DK.dau; if(!d){ $("dkTomTat").style.display = "none"; return; }
  const dem = {}; let tien = 0, thue = 0;
  DK.hd.forEach(h => { dem[h.tt] = (dem[h.tt]||0) + 1; if(h.tt !== "BO_QUA"){ tien += Number(h.tien)||0; thue += Number(h.thue)||0; } });
  let s = "<b>" + (DK.huong === "ban" ? "Bán ra" : "Mua vào") + "</b> " + esc(ngayVN(d.tu)) + " → " + esc(ngayVN(d.den)) + " · " + DK.hd.length +
      " hóa đơn · chưa thuế <b>" + money(tien) + "</b> · thuế <b>" + money(thue) + "</b> · TK thanh toán: công nợ " + esc((d.tk||{}).co_cn) +
      ", tiền mặt " + esc((d.tk||{}).co_tm) + " · TK thuế " + esc((d.tk||{}).thue) + "<br>" +
      Object.keys(TEN_TT_DK).filter(k => dem[k]).map(k => esc(TEN_TT_DK[k]) + ": <b>" + dem[k] + "</b>").join(" · ");
  if((dem.THIEU_MA||0) > 0) s += "<br>Hóa đơn Thiếu mã: tạo mã vật tư / đối tác ở Bước 1 trên màn hình AI của phần mềm rồi bấm lại “AI định khoản”.";
  if(Number(d.che_do_ghi) === 1) s += "<br><span style='color:#C0392B'>Quy tắc hạch toán đang ở chế độ TỰ ĐỘNG GHI NHẬN: hóa đơn đủ điều kiện được ghi sổ ngay khi tải về. Muốn xem / sửa định khoản trước khi ghi, đổi Chế độ ghi sang “Xác nhận trước khi ghi”.</span>";
  $("dkTomTat").innerHTML = s; $("dkTomTat").style.display = "block";
  $("dkChipText").textContent = (DK.huong === "ban" ? "Bán ra" : "Mua vào") + " · cập nhật " + String(d.luc||"").slice(11,16);
}
function dkVe(){
  const tb = $("dkBody"); tb.innerHTML = "";
  const loc = $("dkLoc").value, tim = $("dkTim").value.trim().toLowerCase();
  const ds = DK.hd.filter(h => {
    if(loc === "chua" && (h.tt === "DA_HACH_TOAN" || h.tt === "BO_QUA")) return false;
    if(loc === "can" && !["THIEU_MA","CAN_XEM_LAI","LOI","MOI"].includes(h.tt)) return false;
    if(loc === "san" && h.tt !== "SAN_SANG") return false;
    if(loc === "ht" && h.tt !== "DA_HACH_TOAN") return false;
    if(tim){
      const s = [h.so, h.kh, h.ten, h.mst, h.dt, h.dk, h.soct].concat((h.d||[]).map(x => x.ten + " " + x.tk + " " + x.vt)).join(" ").toLowerCase();
      if(!s.includes(tim)) return false;
    }
    return true;
  });
  $("dkEmpty").style.display = ds.length ? "none" : "block";
  ds.forEach((h,k) => {
    const tr = document.createElement("tr");
    const bt = (h.bt||[]).map(b => '<div class="mono" style="white-space:nowrap">N ' + esc(b[0]) + ' / C ' + esc(b[1]) +
        (b[2] === null ? ' <span style="color:var(--ink-soft)">(giá vốn khi lập CT)</span>' : ': ' + money(b[2])) + '</div>').join("");
    tr.innerHTML = '<td class="mono">' + (k+1) + '</td><td class="mono">' + esc(ngayVN(h.ngay)) + '</td>' +
      '<td class="mono">' + esc(h.kh) + ' · ' + esc(h.so) + (h.soct ? '<br><span style="font-size:11.5px;color:var(--ink-soft)">CT ' + esc(h.soct) + '</span>' : '') + '</td>' +
      '<td style="min-width:220px"><span class="seller"></span><span class="seller-mst"></span></td>' +
      '<td class="mono" style="white-space:nowrap">' + (h.dt ? esc(h.dt) : '<span style="color:#B45309">chưa có</span>') + '</td>' +
      '<td class="num">' + money(h.tien) + '</td><td class="num">' + money(h.thue) + '</td><td>' + bt + '</td>' +
      '<td>' + (h.ttoan === "TM" ? "Tiền mặt" : "Công nợ") + (h.ep_tt ? ' <span style="font-size:11px;color:var(--ink-soft)">(KT chọn)</span>' : '') + '</td>' +
      '<td><span class="dktt"></span>' + (h.ghi ? '<div style="font-size:11.5px;color:var(--ink-soft);max-width:280px"></div>' : '') + '</td>' +
      '<td><button class="linkbtn" data-dkh="' + Number(h._i) + '">' + (h.tt === "DA_HACH_TOAN" ? "Xem" : "Sửa") + '</button></td>';
    tr.querySelector(".seller").textContent = h.ten || "";
    tr.querySelector(".seller-mst").textContent = h.mst || "";
    const c = tr.querySelector(".dktt"); c.textContent = TEN_TT_DK[h.tt] || h.tt || "";
    c.style.cssText = "padding:2px 8px;border-radius:10px;font-size:12px;font-weight:600;white-space:nowrap;" + (MAU_TT_DK[h.tt] || MAU_TT_DK.MOI);
    if(h.ghi) c.parentNode.querySelector("div").textContent = h.ghi;
    tb.appendChild(tr);
  });
  tb.querySelectorAll("button[data-dkh]").forEach(b => b.onclick = () => moHopDK(DK.hd[Number(b.dataset.dkh)]));
  dkTomTat();
}
function dkHopMo(){ const o = $("hopGD29"); return !!(o && o.style.display !== "none" && $("dkLuu")); }
function moHopDK(h){
  if(!h || !DK.dau) return;
  const ban = DK.huong === "ban", daHT = h.tt === "DA_HACH_TOAN", tkmd = DK.dau.tk || {};
  const huong0 = DK.huong, tu0 = DK.dau.tu, den0 = DK.dau.den, tkTen0 = DK.tk_ten;     // giu huong / ky luc mo hop
  const tcDs = ban ? ["HH","TP","DV"] : ["HH","NVL","CCDC","DV","TSCD"];
  let html = '<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px 24px;font-size:13.5px;margin-bottom:10px">' +
    '<div><b>' + (ban ? "Người mua" : "Người bán") + ':</b> ' + esc(h.ten) + '<br>MST ' + esc(h.mst) + ' · Mã đối tượng: ' +
      (h.dt ? '<b>' + esc(h.dt) + '</b>' : '<span style="color:#B45309">chưa có (tạo ở Bước 1 trên màn hình AI)</span>') + '</div>' +
    '<div>Ký hiệu ' + esc(h.kh) + ' · Số ' + esc(h.so) + ' · Ngày ' + esc(ngayVN(h.ngay)) + (h.soct ? ' · CT ' + esc(h.soct) : '') +
      '<br>Trạng thái AI: <b>' + esc(TEN_TT_DK[h.tt] || h.tt || "") + '</b>' + (h.ghi ? ' — ' + esc(h.ghi) : '') + '</div></div>';
  if(daHT) html += '<div style="padding:8px 12px;border-radius:8px;background:#E0F4F5;margin-bottom:10px">Hóa đơn đã hạch toán: chỉ xem. Muốn sửa, hủy chứng từ của hóa đơn trên màn hình AI của phần mềm rồi làm lại.</div>';
  html += '<div class="btn-row" style="gap:18px;margin-bottom:10px">' +
    '<label style="margin:0;display:inline-flex;gap:6px;align-items:center">Thanh toán <select id="dkTT" style="width:auto;margin:0">' +
      '<option value="AI">Theo AI / quy tắc</option><option value="CN">Công nợ (' + (ban ? "Nợ " : "Có ") + esc(tkmd.co_cn) + ')</option>' +
      '<option value="TM">Tiền mặt (' + (ban ? "Nợ " : "Có ") + esc(tkmd.co_tm) + ')</option></select></label>' +
    (ban ? '' : '<label style="margin:0;display:inline-flex;gap:6px;align-items:center">Cả hóa đơn là <select id="dkLoai" style="width:auto;margin:0">' +
      '<option value="=">Giữ nguyên' + (h.ep ? ' (' + esc(h.ep === "CP" ? "Chi phí" : h.ep) + ')' : '') + '</option><option value="CP">Chi phí (không tạo mã hàng)</option>' +
      '<option value="NVL">Nguyên vật liệu</option><option value="HH">Hàng hóa</option><option value="">Để AI tự nhận</option></select></label>') + '</div>';
  html += '<datalist id="dkTKList">' + DK.tk.map(t => '<option value="' + escA(t[0]) + '">' + esc(t[1]) + '</option>').join("") + '</datalist>';
  html += '<div style="overflow:auto"><table style="width:100%;font-size:13px"><thead><tr><th>#</th><th>Tên hàng hóa, dịch vụ</th><th>ĐVT</th>' +
    '<th style="text-align:right">SL</th><th style="text-align:right">Thành tiền</th><th>TS</th><th style="text-align:right">Thuế</th><th>Mã VT</th>' +
    '<th>Tính chất</th><th>' + (ban ? "TK doanh thu (Có)" : "TK Nợ") + '</th><th>AI</th></tr></thead><tbody>';
  (h.d||[]).forEach((d,k) => {
    const bq = d.tt === "BO_QUA" || d.tc === "CK" || d.tc === "KM";
    const sua = !daHT && !bq;
    let ds = tcDs.slice();
    if(d.tc && !ds.includes(d.tc)) ds = [d.tc].concat(ds);
    const tcSel = sua ? '<select data-tc="' + k + '" style="width:auto;margin:0">' + (d.tc ? '' : '<option value="">(chưa)</option>') +
        ds.map(c => '<option value="' + escA(c) + '"' + (c === d.tc ? ' selected' : '') + '>' + esc(TEN_TC_DK[c] || c) + '</option>').join("") + '</select>'
      : esc(TEN_TC_DK[d.tc] || d.tc || "");
    const tkIn = sua ? '<input data-tk="' + k + '" list="dkTKList" value="' + escA(d.tk) + '" style="width:96px;margin:0">' : esc(d.tk);
    html += '<tr><td>' + (k+1) + '</td><td>' + esc(d.ten) + '</td><td>' + esc(d.dvt) + '</td><td class="num">' + money(d.sl) + '</td>' +
      '<td class="num">' + money(d.tien) + '</td><td>' + esc(d.ts) + '</td><td class="num">' + money(d.thue) + '</td>' +
      '<td class="mono">' + (d.vt ? esc(d.vt) : (bq ? '' : '<span style="color:#B45309">thiếu</span>')) + '</td><td>' + tcSel + '</td>' +
      '<td>' + tkIn + '<div style="font-size:11px;color:var(--ink-soft)" data-tkten="' + k + '">' + esc(DK.tk_ten[d.tk] || "") + '</div></td>' +
      '<td style="font-size:11.5px;white-space:nowrap">' + esc(TEN_NGUON_DK[d.ng] || d.ng || "") + (Number(d.tin) ? ' · ' + Number(d.tin) + '%' : '') +
      (bq ? '<br>bỏ qua / phân bổ' : '') + '</td></tr>';
  });
  html += '</tbody></table></div>';
  html += '<div style="margin-top:12px;font-size:13px"><b>Bút toán hiện tại</b> (theo AI, chưa ghi sổ):' + ((h.bt||[]).map(b => '<div class="mono">Nợ ' + esc(b[0]) +
    ' ' + esc(DK.tk_ten[b[0]] || "") + ' / Có ' + esc(b[1]) + ' ' + esc(DK.tk_ten[b[1]] || "") + ' : ' + (b[2] === null ? 'theo giá xuất kho khi lập chứng từ' : money(b[2])) +
    ' <span style="color:var(--ink-soft)">' + esc(b[3]) + '</span></div>').join("") || ' (không có dòng tiền)') + '</div>';
  if(!daHT) html += '<div class="btn-row" style="margin-top:14px"><button class="btn btn-primary" id="dkLuu">Lưu định khoản → phần mềm phân tích lại</button>' +
    '<span style="font-size:12.5px;color:var(--ink-soft)">TK / tính chất áp cho mọi dòng CÙNG TÊN + ĐVT của đối tác này chưa hạch toán; AI ghi nhớ cho lần sau.</span></div>';
  hopThoai("Định khoản hóa đơn " + (h.kh||"") + " số " + (h.so||""), html);
  $("dkTT").value = h.ep_tt || "AI";
  if(!ban) $("dkLoai").value = "=";
  if(daHT){ $("dkTT").disabled = true; if(!ban) $("dkLoai").disabled = true; return; }
  document.querySelectorAll("#hopGD29N input[data-tk]").forEach(e => e.oninput = () => {
    const o = document.querySelector('#hopGD29N [data-tkten="' + e.dataset.tk + '"]'); if(o) o.textContent = DK.tk_ten[e.value.trim()] || (e.value.trim() ? "không có trong TK chi tiết" : ""); });
  $("dkLuu").onclick = async () => {
    const muc = [], sai = [];
    if(!ban){ const v = $("dkLoai").value; if(v !== "=") muc.push({khoa:h.khoa, loai:v}); }
    const tt = $("dkTT").value; if(tt !== (h.ep_tt || "AI")) muc.push({khoa:h.khoa, tt: tt === "AI" ? "" : tt});
    (h.d||[]).forEach((d,k) => {
      const e1 = document.querySelector('#hopGD29N [data-tk="' + k + '"]'), e2 = document.querySelector('#hopGD29N [data-tc="' + k + '"]');
      if(!e1 || !e2) return;
      const tk = e1.value.trim(), tc = e2.value, m = {khoa:h.khoa, ms:d.ms};
      if(tk && tk !== d.tk){ if(!tkTen0[tk]) sai.push("Dòng " + (k+1) + ": TK " + tk + " không có trong hệ thống TK chi tiết của sổ"); else m.tk = tk; }
      if(tc && tc !== d.tc) m.tc = tc;
      if(m.tk || m.tc) muc.push(m);
    });
    if(sai.length){ baoLoi("TK không hợp lệ", sai.join("\n")); return; }
    if(!muc.length){ baoLoi("Chưa đổi gì", "Đổi TK, tính chất, thanh toán hoặc loại cả hóa đơn rồi bấm Lưu."); return; }
    $("dkLuu").disabled = true;
    const r = await goi("/api/dk-sua", {direction: huong0, tu_ngay: tu0, den_ngay: den0, muc});
    if(!r.ok){ $("dkLuu").disabled = false; baoLoi("Chưa gửi được định khoản", r.loi || "Không rõ lý do."); return; }
    $("hopGD29").style.display = "none";
    dkBan(true, "Đã gửi " + r.so + " sửa - đang chờ phần mềm áp dụng và phân tích lại…");
    DK.dang = true;
    const kq = await dkCho({id_sua: r.id_sua});
    DK.dang = false;
    if(!kq){ dkBan(false, "Phần mềm chưa trả lời."); baoLoi("Phần mềm UNESCO chưa nhận sửa", DK_CHUA_TRA_LOI + "\n\nTệp sửa vẫn nằm trong thư mục kết quả: phần mềm sẽ áp dụng khi màn hình AI mở lại."); return; }
    const s = (kq.dau||{}).sua || {};
    dkBan(false, "Phần mềm đã áp dụng " + (s.n||0) + " sửa" + (s.loi ? ", " + s.loi + " mục không sửa được" : "") + " · bảng kê đã cập nhật.");
    if(s.loi) baoLoi("Một số mục không sửa được", s.mo_ta || "");
    if(!s.loi && muc.some(x => "loai" in x)){
      const v = muc.find(x => "loai" in x).loai;
      ["dt","mtt"].forEach(k2 => (DATA[k2]||[]).forEach(x => { if(dkKhoa(x.khoa) === dkKhoa(h.khoa)) x.loai = v; }));
      ve();
    }
  };
}
$("btnDK").onclick = () => dkYeuCau(false);
$("dkLoc").onchange = dkVe;
$("dkTim").oninput = dkVe;
$("btnDKExcel").onclick = async () => {
  const r = await goi("/api/dk-excel", {});
  if(!r.ok){ baoLoi("Chưa xuất được Excel định khoản", r.loi || "Không rõ lý do."); return; }
  $("dkNote").textContent = "Đã tạo " + r.tep.split(/[\\/]/).pop() + " (" + r.so + " hóa đơn).";
  goi("/api/mo-tep", {tep: r.tep});
};
// mở công cụ: hiện bảng kê lần trước (nếu có); sau đó cứ 10 giây xem phần mềm có ghi bảng kê mới (sau mỗi lần nạp / sửa)
setTimeout(async () => { const r = await goi("/api/dk-ket-qua", {}); if(r && r.ok && r.co && r.hd) dkNap(r); }, 1500);
setInterval(async () => {
  if(!UN || !UN.bat || DK.dang || dkHopMo()) return;
  const r = await goi("/api/dk-ket-qua", {chi_dau: true});
  if(r && r.ok && r.co && r.dau && r.dau.luc !== DK.luc){
    const f = await goi("/api/dk-ket-qua", {}); if(f && f.ok && f.co && f.hd) dkNap(f);
  }
}, 10000);
/* ---- GD29: tài khoản gợi nhớ (chỉ tên + MST, không có mật khẩu) ---- */
let GOI_NHO = [];
function veGoiNho(mstDangDung){
  const c = $("gnChon"); c.innerHTML = '<option value="">— chọn tài khoản đã lưu —</option>';
  GOI_NHO.forEach(x => { const op = document.createElement("option"); op.value = x.mst; op.textContent = x.nhan + "  ·  " + x.mst; c.appendChild(op); });
  if(mstDangDung && GOI_NHO.some(x=>x.mst===mstDangDung)){ c.value = mstDangDung; const x = GOI_NHO.find(y=>y.mst===mstDangDung); $("gnNhan").value = x.nhan; $("gnMst").value = x.mst; }
}
$("gnChon").onchange = async () => {
  const mst = $("gnChon").value; if(!mst) return;
  const r = await goi("/api/goi-nho-chon", {mst});
  if(!r.ok){ baoLoi("Không đổi được tài khoản", r.loi||""); return; }
  const x = GOI_NHO.find(y=>y.mst===mst); if(x){ $("gnNhan").value = x.nhan; $("gnMst").value = x.mst; }
  $("mst").value = mst;
};
$("gnLuu").onclick = async () => {
  const r = await goi("/api/goi-nho-luu", {nhan:$("gnNhan").value.trim(), mst:$("gnMst").value.trim()});
  if(!r.ok){ baoLoi("Chưa lưu được", r.loi||""); return; }
  GOI_NHO = r.goi_nho||[]; veGoiNho($("gnMst").value.trim());
};
$("gnXoa").onclick = async () => {
  const mst = $("gnChon").value || $("gnMst").value.trim(); if(!mst) return;
  const r = await goi("/api/goi-nho-xoa", {mst}); GOI_NHO = r.goi_nho||[]; $("gnNhan").value=""; $("gnMst").value=""; veGoiNho("");
};

/* ---- 2 ô tick chọn loại file muốn tải ---- */
let COC_CHROME = true;
function layDinhDang(){
  const ds = [];
  if($("ddXml").checked) ds.push("xml");
  if($("ddPdf").checked) ds.push("pdf");
  if($("ddExcel").checked) ds.push("excel");
  return ds;
}
function capNhatDinhDang(){
  const ds = layDinhDang();
  let ghi = "";
  if(ds.length === 0) ghi = "Tick ít nhất 1 lựa chọn";
  else if($("ddPdf").checked && !COC_CHROME) ghi = "Máy chưa cài Chrome — không tạo được PDF";
  else {
    const luu = [];
    if($("ddXml").checked) luu.push(".xml");
    if($("ddPdf").checked) luu.push(".pdf");
    if(luu.length === 2) ghi = "Mỗi hóa đơn lưu 2 file: .xml và .pdf";
    if($("ddExcel").checked) ghi += (ghi ? " · " : "") + "Kèm Excel: bảng kê danh sách hóa đơn";
  }
  $("ddNote").textContent = ghi;
}
$("ddXml").onchange = capNhatDinhDang;
$("ddPdf").onchange = capNhatDinhDang;
$("ddExcel").onchange = capNhatDinhDang;

/* ---- chọn thư mục (mở hộp thoại Windows thật) ---- */
$("btnFolder").onclick = async () => {
  $("btnFolder").disabled = true; $("btnFolder").textContent = "Đang mở hộp thoại…";
  const r = await goi("/api/chon-thu-muc");
  $("btnFolder").disabled = false; $("btnFolder").textContent = "Chọn thư mục lưu";
  if(r.ok && r.thu_muc){
    $("folderPath").textContent = r.thu_muc; $("folderPath").classList.add("set");
  }
};

/* ---- tải hàng loạt ---- */
$("btnStop").onclick = () => goi("/api/dung", {});
$("btnTaiLaiLoi").onclick = async () => {          // 18/11/2026
  const r = await goi("/api/tai-lai-loi", {});
  if(!r.ok){ baoLoi("Chưa tải lại được", r.loi || "Không rõ lý do."); return; }
  $("khungLoi").style.display = "none";
  $("progressBlock").classList.add("show"); $("pTotal").textContent = r.tong;
  $("btnDownload").disabled = true; $("btnStop").style.display = "inline-flex";
  if(timer) clearInterval(timer);
  timer = setInterval(theoDoi, 500);
};
$("btnDownload").onclick = async () => {
  const dinh_dang = layDinhDang();
  if(dinh_dang.length === 0){
    baoLoi("Chưa chọn việc cần làm","Tick vào “File XML”, “File PDF” hoặc “Gộp danh mục và tải file Excel” ở Bước 4 rồi bấm lại."); return; }
  const r = await goi("/api/tai", {kind, direction, dinh_dang, chi_so: Array.from(picked), chi_moi: $("chiMoi").checked,
                                  xac_nhan: XAC_NHAN_PM});     // GD109
  if(!r.ok){ baoLoi("Chưa tải được", r.loi || "Không rõ lý do."); return; }
  if(r.khong_co_moi){
    $("searchNote").textContent = "Không có hóa đơn mới: " + r.da_chon + " hóa đơn đã chọn đều đã có trong phần mềm hoặc đã tải trước đó. Bỏ tick “Chỉ tải hóa đơn mới” nếu muốn tải lại.";
    if(DANG_TU_DONG){ setTimeout(taiKindTiepTheo, 300); }
    return;
  }
  $("progressBlock").classList.add("show");
  $("pTotal").textContent = r.tong;
  $("btnDownload").disabled = true; $("btnStop").style.display = "inline-flex";
  if(timer) clearInterval(timer);
  timer = setInterval(theoDoi, 500);
};
async function theoDoi(){
  const t = await goi("/api/tien-trinh");
  if(!t || t.tong===undefined) return;
  const pct = t.tong ? Math.round(t.xong/t.tong*100) : 0;
  $("pDone").textContent = t.xong; $("pTotal").textContent = t.tong;
  $("pPct").textContent = pct + "%"; $("railFill").style.width = pct + "%";
  $("pOk").textContent = t.ok; $("pSkip").textContent = t.bo_qua; $("pErr").textContent = t.loi;
  $("pNoXml").textContent = t.khong_xml || 0;
  $("pCurrent").textContent = t.dang_chay ? ("Đang tải: " + (t.hien_tai||"")) : (t.ket_thuc||"");
  $("btnMoExcelTH").style.display = (!t.dang_chay && t.tep_mo) ? "inline-flex" : "none";     // GD91
  $("btnMoExcelTH").onclick = () => goi("/api/mo-tep", {tep: t.tep_mo});
  const dsX = (!t.dang_chay && t.tep_ds) ? t.tep_ds : [];         // GD94: nút mở từng file Excel vừa tạo
  if($("dsExcel").dataset.v !== dsX.join("|")){
    $("dsExcel").dataset.v = dsX.join("|"); $("dsExcel").innerHTML = "";
    dsX.forEach(p => { const b = document.createElement("button"); b.className = "btn btn-ghost";
      b.textContent = "Mở " + p.split(/[\\/]/).pop(); b.onclick = () => goi("/api/mo-tep", {tep: p}); $("dsExcel").appendChild(b); });
  }
  const dsL = (!t.dang_chay && t.ds_loi) ? t.ds_loi : [];          // 18/11/2026: hóa đơn tải lỗi -> nút Tải lại HĐ lỗi
  $("khungLoi").style.display = dsL.length ? "block" : "none";
  if(dsL.length){
    $("loiTieuDe").textContent = (t.loi || dsL.length) + " hóa đơn tải lỗi (chưa có file) - lần tải sau vẫn tải lại, hoặc bấm:";
    $("dsLoi").textContent = dsL.join(" · ") + ((t.loi||0) > dsL.length ? " · …" : "");
  }
  if(!t.dang_chay){
    clearInterval(timer); timer = null;
    $("btnStop").style.display = "none"; capNhat();
    if(t.bi_chan){ DANG_TU_DONG = false; TU_DONG_KIND = []; HUONG_QUEUE = []; }     // GD94: cổng thuế chặn -> dừng cả chế độ tự động
    if(UN && UN.bat && !DANG_TU_DONG && (t.ok||0) > 0) setTimeout(() => dkYeuCau(true), 5000);     // GD106: tải xong -> hỏi định khoản AI
    if(DANG_SYNC_TAI){ DANG_SYNC_TAI = false; $("btnDownload").disabled = false; hienDongBo(direction); return; }
    if(DANG_TU_DONG){ setTimeout(taiKindTiepTheo, 300); }
  }
}
/* ---- GD94: Làm mới - hóa đơn đã tải về máy nhưng chưa vào phần mềm (tải lỗi / bị ngắt giữa chừng) ---- */
$("btnLamMoi").onclick = async () => {
  if(!$("fFrom").value || !$("fTo").value){ baoLoi("Thiếu khoảng ngày","Chọn Kỳ (tháng / quý / năm) hoặc Từ ngày – Đến ngày rồi bấm Làm mới."); return; }
  const loai = layLoai();
  $("btnLamMoi").disabled = true; $("btnLamMoi").textContent = "Đang kiểm tra…";
  $("searchNote").textContent = "Đang so hóa đơn đã tải về máy với hóa đơn đã có trong phần mềm (không cần mạng)…";
  const r = await goi("/api/lam-moi", {direction, loai: loai.length ? loai : ["dt","mtt"], tu_ngay:$("fFrom").value, den_ngay:$("fTo").value});
  $("btnLamMoi").disabled = false; $("btnLamMoi").textContent = "Làm mới (HĐ đã tải chưa vào phần mềm)"; $("searchNote").textContent = "";
  if(!r.ok){ baoLoi("Chưa làm mới được", r.loi || "Không rõ lý do."); return; }
  DA_DONG_BO = false;
  DATA = {dt:r.dt||[], mtt:r.mtt||[]}; picked.clear();
  $("cntDt").textContent = DATA.dt.length; $("cntMtt").textContent = DATA.mtt.length;
  if((DATA[kind]||[]).length === 0 && (DATA.dt.length || DATA.mtt.length)){
    kind = DATA.dt.length ? "dt" : "mtt";
    document.querySelectorAll(".subtab").forEach(x => x.setAttribute("aria-selected", x.dataset.kind===kind ? "true" : "false"));
  }
  $("khungDanhDau").style.display = direction==="mua" ? "inline" : "none";
  (DATA[kind]||[]).forEach((x,i)=>{ if(x.pm==="tai"||x.pm==="moi") picked.add(i); });
  const t = r.tom_tat || {}, tong = DATA.dt.length + DATA.mtt.length, chieu = direction === "ban" ? "bán ra" : "mua vào";
  $("searchNote").textContent = (tong ? ("Làm mới: " + tong + " hóa đơn " + chieu + " đã tải về máy nhưng CHƯA vào phần mềm (đã chọn sẵn). " +
      "Bấm “Đưa HĐ đã tải vào phần mềm” ở Bước 4 - đọc file trên máy, không tải lại.")
    : ("Làm mới: mọi hóa đơn " + chieu + " đã tải trong kỳ đều đã có trong phần mềm.")) +
    (t.khong_xml ? (" Còn " + t.khong_xml + " hóa đơn không có XML gốc chưa vào phần mềm: bấm Đồng bộ rồi “Tải về hóa đơn chưa có”.") : "");
  ve();
};
$("btnExcelCong").onclick = async () => {          /* GD359b */
  $("btnExcelCong").disabled = true; $("btnExcelCong").textContent = "Chọn tệp…";
  $("searchNote").textContent = "Chọn file Excel 'Xuất chi tiết' tải từ trang hoá đơn điện tử (cửa sổ chọn tệp có thể nằm sau trình duyệt)…";
  const r = await goi("/api/nhap-excel-cong", {});
  $("btnExcelCong").disabled = false; $("btnExcelCong").textContent = "Nhập Excel từ cổng thuế";
  if(r.huy){ $("searchNote").textContent = ""; return; }
  if(!r.ok){ $("searchNote").textContent = ""; baoLoi("Chưa nhập được Excel cổng thuế", r.loi || "Không rõ lý do."); return; }
  $("searchNote").textContent = "Đã đưa vào phần mềm từ Excel cổng thuế: " + r.tom_tat + " (" + r.so_dong + " dòng hàng). " +
    "Mở / quay lại màn hình AI hoá đơn để xem và hạch toán.";
};
$("btnDuaVaoPM").onclick = async () => {
  if(picked.size === 0){ baoLoi("Chưa chọn hóa đơn","Tick các hóa đơn cần đưa vào phần mềm rồi bấm lại."); return; }
  const rows = DATA[kind]||[], tuMay = Array.from(picked).filter(i => rows[i] && rows[i].tu_may).length;
  if(tuMay && !confirm(tuMay + " hóa đơn lấy từ file trên máy, CHƯA có trạng thái trên cổng thuế (có thể đã bị hủy / thay thế). " +
      "Nên bấm Đồng bộ trước rồi Làm mới. Vẫn đưa vào phần mềm?")) return;
  if($("chkTHBL").checked && direction === "ban") return $("btnTongHop").onclick();     // theo ô tích Tổng hợp HĐ bán lẻ
  XAC_NHAN_PM = true;           // GD109: nút này = XÁC NHẬN đưa vào phần mềm (chế độ Tải về, chờ duyệt cho qua)
  try{ return await $("btnDownload").onclick(); } finally { XAC_NHAN_PM = false; }
};
var XAC_NHAN_PM = false;
$("btnMoExcel").onclick = async () => {
  const r = await goi("/api/mo-excel", {});
  if(!r.ok){ baoLoi("Chưa mở được file Excel", r.loi || "Không rõ lý do."); return; }
  $("searchNote").textContent = "Đã mở file Excel: " + (r.ten || "");
};
/* ---- GD91: tổng hợp hóa đơn bán lẻ thành 1 chứng từ ---- */
$("chkTHBL").checked = false;
$("chkTHBL").onchange = () => capNhat();
$("btnTongHop").onclick = async () => {
  if(!$("chkTHBL").checked){ baoLoi("Chưa bật tổng hợp","Tích ô “Tổng hợp hóa đơn bán lẻ” (cạnh nút Xóa bộ lọc) rồi bấm lại."); return; }
  if(direction !== "ban"){ baoLoi("Chỉ dùng cho hóa đơn bán ra","Chọn thẻ “Hóa đơn bán ra”, tìm kiếm rồi chọn hóa đơn cần tổng hợp."); return; }
  if(picked.size === 0){ baoLoi("Chưa chọn hóa đơn","Tick các hóa đơn bán ra cần tổng hợp (hoặc Chọn tất cả) rồi bấm lại."); return; }
  const so_ngay = Number($("thSoNgay").value);
  const pv = document.querySelector('input[name="thPhamVi"]:checked');
  const pham_vi = pv ? pv.value : "ntd";
  const cach = $("thSoNgay").options[$("thSoNgay").selectedIndex].text;
  if(!confirm("Tổng hợp " + picked.size + " hóa đơn bán ra đã chọn: gộp " + cach + " thành 1 chứng từ, " +
      (pham_vi === "tat_ca" ? "gộp TOÀN BỘ hóa đơn (cả người mua có MST)." : "chỉ gộp hóa đơn người mua KHÔNG có MST (có MST nhập riêng từng tờ).") +
      "\n\nTool sẽ tải XML còn thiếu, tạo file Excel chi tiết và chuyển chứng từ tổng hợp sang phần mềm. Tiếp tục?")) return;
  const r = await goi("/api/tong-hop-ban-le", {kind, direction, chi_so: Array.from(picked), so_ngay, pham_vi});
  if(!r.ok){ baoLoi("Chưa tổng hợp được", r.loi || "Không rõ lý do."); return; }
  $("progressBlock").classList.add("show"); $("pTotal").textContent = r.tong;
  $("btnDownload").disabled = true; $("btnTongHop").disabled = true; $("btnStop").style.display = "inline-flex";
  if(timer) clearInterval(timer);
  timer = setInterval(theoDoi, 500);
};
capNhatLoai();
ve();

/* ===== GD54: tab Ho so thue - Cong dich vu cong ===== */
const HS = {v: "hs", d: null, timer: null, soCu: -1, xongCu: -1, daBaoLoi: false};
const hsEsc = s => String(s === null || s === undefined ? "" : s).replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const hsTien = v => (v === null || v === undefined || v === "") ? "" : money(Math.round(v));
const hsNgayVN = s => /^[0-9]{4}-[0-9]{2}-[0-9]{2}/.test(s || "") ? (s.slice(8, 10) + "/" + s.slice(5, 7) + "/" + s.slice(0, 4)) : (s || "");
document.querySelectorAll("#tabChinh .ttab").forEach(b => b.onclick = () => {
  document.querySelectorAll("#tabChinh .ttab").forEach(x => x.setAttribute("aria-selected", x === b ? "true" : "false"));
  $("paneHD").hidden = b.dataset.pane !== "paneHD";
  $("paneHS").hidden = b.dataset.pane !== "paneHS";
  if(b.dataset.pane === "paneHS"){ hsTrangThai(); hsNap(); if(!HS.timer) HS.timer = setInterval(() => { if(!$("paneHS").hidden) hsTrangThai(); }, 2000); }
});
document.querySelectorAll("#hsTabs .hstab").forEach(b => b.onclick = () => {
  document.querySelectorAll("#hsTabs .hstab").forEach(x => x.setAttribute("aria-selected", x === b ? "true" : "false"));
  HS.v = b.dataset.v; hsVe();
});
async function hsTrangThai(){
  const r = await goi("/api/hstk/trang-thai");
  if(!r || r.chrome === undefined){ if(r && r.loi && !HS.daBaoLoi){ HS.daBaoLoi = true; baoLoi("Tab Hồ sơ thuế chưa dùng được", r.loi); } return; }
  const ten = {chua_mo: "Chưa mở", dang_mo: "Đang mở Chrome...", da_mo: "Đã mở Cổng DVC", loi: "Lỗi mở Chrome"}[r.chrome] || r.chrome;
  $("hsChipText").textContent = ten;
  $("hsChip").classList.toggle("on", r.chrome === "da_mo");
  $("hsMo").disabled = r.chrome === "dang_mo";
  if(r.chrome === "loi" && r.loi && !HS.daBaoLoi){ HS.daBaoLoi = true; baoLoi("Không mở được Cổng dịch vụ công", r.loi); }
  if(r.chrome !== "loi") HS.daBaoLoi = false;
  $("hsBao").textContent = r.bao || "";
  $("hsNghe").style.display = r.nghe ? "none" : "";
  $("hsDungNghe").style.display = r.nghe ? "" : "none";
  const v = r.viec || {};
  const coTD = !!(v.dang_chay || v.ket_thuc);
  $("hsTienDo").classList.toggle("show", coTD);
  if(coTD){
    const pct = v.tong ? Math.round(v.xong / v.tong * 100) : 0;
    $("hsXong").textContent = v.xong || 0; $("hsTong").textContent = v.tong || 0;
    $("hsPct").textContent = pct + "%"; $("hsRail").style.width = pct + "%";
    $("hsHienTai").textContent = v.dang_chay ? ("Đang lấy: " + (v.hien_tai || "") + (v.loi ? ("  (lỗi " + v.loi + ")") : "")) : (v.ket_thuc || "");
  }
  $("hsChiTiet").disabled = !!v.dang_chay;
  $("hsDung").style.display = v.dang_chay ? "" : "none";
  if(HS.soCu !== r.so_ho_so || HS.xongCu !== (v.xong || 0) + "|" + !!v.dang_chay){
    HS.soCu = r.so_ho_so; HS.xongCu = (v.xong || 0) + "|" + !!v.dang_chay; hsNap();
  }
}
async function hsNap(){
  const r = await goi("/api/hstk/du-lieu");
  if(!r || r.ok === false) return;
  HS.d = r;
  $("hsC1").textContent = r.ho_so.length;
  $("hsC2").textContent = (r.doi_chieu.filter(x => x.so_lech > 0 && x.hieu_luc).length + (r.lien_ky || []).filter(x => x.co_lech).length)
    + "/" + r.doi_chieu.length;
  $("hsC3").textContent = r.thong_bao.length;
  $("hsC4").textContent = r.phai_nop.length + (r.ky_chua_thay.length ? (" + " + r.ky_chua_thay.length + " chưa nộp") : "");
  hsVe();
}
function hsTrong(tieuDe, noiDung){
  return '<div class="empty"><strong>' + hsEsc(tieuDe) + '</strong>' + hsEsc(noiDung) + '</div>';
}
function hsNutTep(duong, chu){
  if(!duong) return "";
  return '<button class="hs-mo" data-tep="' + hsEsc(duong) + '">' + hsEsc(chu || "Mở") + '</button>';
}
function hsVe(){
  const d = HS.d, el = $("hsBang");
  if(!d){ el.innerHTML = hsTrong("Chưa có dữ liệu", "Làm theo Bước 1 và Bước 2."); return; }
  let h = "";
  const tc = (d.tra_cuu || []).map(x => x.tu.split("-").reverse().join("/") + " - " + x.den.split("-").reverse().join("/")).join("; ");
  $("hsGhiChu").textContent = tc ? ("Đã tra cứu: " + tc) : "";
  if(HS.v === "hs"){
    if(!d.ho_so.length){ el.innerHTML = hsTrong("Chưa có hồ sơ nào", "Tra cứu trên Chrome (Bước 2), tool tự đọc bảng kết quả."); return; }
    h = '<table><thead><tr><th>Mã hồ sơ</th><th>Mẫu</th><th>Kỳ</th><th>Ngày nộp</th><th>Trạng thái</th><th>Lần</th><th class="num">Thông báo</th><th>Tờ khai XML</th><th></th></tr></thead><tbody>';
    for(const x of d.ho_so){
      const tt = x.trang_thai ? '<span class="hs-tag ' + (x.chap_nhan ? "hs-ok" : "hs-cho") + '">' + hsEsc(x.trang_thai) + '</span>' : "";
      h += '<tr><td class="mono">' + hsEsc(x.ma_hs) + (x.nguon === "TDT" ? ' <span class="hs-nho">(TĐT)</span>' : "") + '</td>'
        + '<td>' + hsEsc(x.mau || x.to_khai) + '</td><td class="mono">' + hsEsc(x.ky) + '</td><td class="mono">' + hsEsc(x.ngay_nop) + '</td>'
        + '<td>' + tt + (x.loi ? '<div class="hs-nho" style="color:var(--red)">' + hsEsc(x.loi) + '</div>' : "") + '</td>'
        + '<td>' + hsEsc(x.loai_tk) + (x.lan ? (" " + hsEsc(x.lan)) : "") + '</td>'
        + '<td class="num">' + (x.so_tb ? (x.canh_bao_tb ? '<span class="hs-lech">' + x.so_tb + ' (!)</span>' : x.so_tb) : (x.chi_tiet ? "0" : "")) + '</td>'
        + '<td>' + (x.co_to_khai ? '<span class="hs-tag hs-ok">Đã đọc</span>' : (x.chi_tiet ? '<span class="hs-nho">Không có XML</span>' : '<span class="hs-nho">Chưa lấy</span>')) + '</td>'
        + '<td><button class="hs-mo" data-lay="' + hsEsc(x.ma_hs) + '">' + (x.chi_tiet ? "Lấy lại" : "Lấy chi tiết") + '</button></td></tr>';
    }
    h += '</tbody></table>';
  } else if(HS.v === "dc"){
    if(!d.doi_chieu.length){ el.innerHTML = hsTrong("Chưa có tờ khai 01/GTGT đã đọc", "Bấm Lấy chi tiết (Bước 3) để tải và đọc tờ khai đã nộp."); return; }
    const sl = d.so_lieu || {};
    h = "";
    if((d.lien_ky || []).length){
      h += '<table><thead><tr><th colspan="2">Kiểm tra liên kỳ 01/GTGT</th><th class="num">[22] kỳ này</th><th>Kỳ trước</th><th class="num">[43] kỳ trước</th><th class="num">Lệch</th><th></th></tr></thead><tbody>';
      for(const x of d.lien_ky){
        h += '<tr><td class="mono">' + hsEsc(x.ky) + '</td><td class="mono hs-nho">' + hsEsc(x.ma_hs) + '</td><td class="num">' + hsTien(x.ct22) + '</td><td class="mono">' + hsEsc(x.ky_truoc)
          + '</td><td class="num">' + hsTien(x.ct43_truoc) + '</td><td class="num' + (x.co_lech ? ' hs-lech' : '') + '">' + hsTien(x.lech) + '</td><td>'
          + (x.co_lech ? '<span class="hs-tag hs-loi">Lệch</span>' : '<span class="hs-tag hs-ok">Khớp</span>') + '</td></tr>';
      }
      h += '</tbody></table><div class="hs-nho" style="padding:6px 18px 12px">[22] thuế còn được khấu trừ kỳ trước chuyển sang phải bằng [43] của tờ khai có hiệu lực kỳ liền trước. Lệch thường do nộp bổ sung kỳ trước mà chưa điều chỉnh kỳ sau.</div>';
    }
    h += '<div class="note" style="margin:12px 18px">' + (sl.co ? ("Số liệu sổ sách và hóa đơn điện tử do UNESCO ghi lúc " + hsEsc(sl.tao_luc) + " (năm " + hsEsc(sl.nam) + "). Mở lại màn hình tải hóa đơn từ UNESCO để cập nhật.")
      : "Chưa có số liệu sổ sách: mở màn hình tải hóa đơn từ phần mềm UNESCO (nút AI hóa đơn) để phần mềm ghi số liệu đối chiếu.") + ' Lệch trên 1.000 đ tô đỏ.'
      + (sl.dvc_nap_nham ? ('<br><b>Lưu ý:</b> bảng hóa đơn tải về của UNESCO có ' + sl.dvc_nap_nham + ' dòng là dữ liệu Cổng DVC bị nạp nhầm trước bản này (mã bắt đầu TB|, GNT|, HSDVC|, HSTDT|) - không phải hóa đơn, chương trình không tự xóa.') : '') + '</div>';
    h += '<table><thead><tr><th>Chỉ tiêu</th><th>Nội dung</th><th class="num">Tờ khai đã nộp</th><th class="num">Sổ sách UNESCO</th><th class="num">Lệch</th><th class="num">HĐĐT đã tải</th><th class="num">Lệch</th></tr></thead><tbody>';
    for(const x of d.doi_chieu){
      const nhan = (x.bo_sung ? ' bổ sung' + (x.lan && x.lan !== "0" ? ' lần ' + hsEsc(x.lan) : '') : ' chính thức')
        + (x.bi_tu_choi ? ' - BỊ TỪ CHỐI' : (x.hieu_luc ? '' : ' - đã có tờ khai nộp sau thay thế'));
      h += '<tr class="hs-nhom"><td colspan="7">01/GTGT ' + hsEsc(x.ky) + hsEsc(nhan) + ' - hồ sơ ' + hsEsc(x.ma_hs) + (x.so_lech ? ' <span class="hs-lech">(' + x.so_lech + ' chỉ tiêu lệch)</span>' : (x.co_so_lieu ? ' <span class="hs-tag hs-ok">Khớp</span>' : ' <span class="hs-nho">(chưa có số liệu sổ sách kỳ này)</span>')) + '</td></tr>';
      for(const r of x.dong){
        const l1 = r.lech_so === null ? "" : '<span class="' + (Math.abs(r.lech_so) > 1000 ? "hs-lech" : "") + '">' + hsTien(r.lech_so) + '</span>';
        const l2 = r.lech_hd === null ? "" : '<span class="' + (Math.abs(r.lech_hd) > 1000 ? "hs-lech" : "") + '">' + hsTien(r.lech_hd) + '</span>';
        h += '<tr><td class="mono">[' + hsEsc(r.ct) + ']</td><td>' + hsEsc(r.ten) + '</td><td class="num">' + hsTien(r.to_khai) + '</td><td class="num">' + hsTien(r.so_sach) + '</td><td class="num">' + l1
          + '</td><td class="num">' + hsTien(r.hddt) + '</td><td class="num">' + l2 + '</td></tr>';
      }
    }
    h += '</tbody></table>';
  } else if(HS.v === "tb"){
    if(!d.thong_bao.length){ el.innerHTML = hsTrong("Chưa có thông báo", "Bấm Lấy chi tiết (Bước 3): tool bấm Xem thông báo và tải từng thông báo về."); return; }
    h = '<table><thead><tr><th>Mã hồ sơ</th><th>Thông báo</th><th>Số</th><th>Ngày</th><th>Tệp</th></tr></thead><tbody>';
    for(const x of d.thong_bao){
      h += '<tr><td class="mono">' + hsEsc(x.ma_hs) + '</td><td>' + (x.canh_bao ? '<span class="hs-tag hs-loi">Cần xem</span> ' : "") + hsEsc(x.ten)
        + (x.noi_dung ? '<div class="hs-nho">' + hsEsc(x.noi_dung.slice(0, 220)) + '</div>' : "") + '</td><td class="mono">' + hsEsc(x.so) + '</td><td class="mono">' + hsEsc(hsNgayVN(x.ngay))
        + '</td><td>' + hsNutTep(x.tep, "Mở tệp") + '</td></tr>';
    }
    h += '</tbody></table>';
  } else {
    h = '<table><thead><tr><th>Mẫu</th><th>Kỳ</th><th>Mã hồ sơ</th><th>Trạng thái</th><th class="num">Thuế còn phải nộp</th><th>Hạn nộp</th><th class="num">Chuyển kỳ sau</th><th>Ghi chú</th></tr></thead><tbody>';
    for(const x of d.phai_nop){
      h += '<tr><td>' + hsEsc(x.mau) + (x.bo_sung ? ' <span class="hs-nho">(bổ sung)</span>' : "") + '</td><td class="mono">' + hsEsc(x.ky) + '</td><td class="mono">' + hsEsc(x.ma_hs)
        + '</td><td>' + hsEsc(x.trang_thai) + '</td><td class="num' + (x.qua_han ? ' hs-lech' : "") + '">' + hsTien(x.phai_nop) + '</td><td class="mono">' + hsEsc(x.han_nop)
        + '</td><td class="num">' + hsTien(x.chuyen_sau) + '</td><td class="hs-nho">' + hsEsc(x.ghi_chu) + '</td></tr>';
    }
    if(d.ky_chua_thay.length){
      h += '<tr class="hs-nhom"><td colspan="8">Kỳ đã đến hạn trong khoảng đã tra cứu nhưng CHƯA THẤY tờ khai</td></tr>';
      for(const x of d.ky_chua_thay){
        h += '<tr><td>' + hsEsc(x.mau) + '</td><td class="mono">' + hsEsc(x.ky) + '</td><td colspan="3"><span class="hs-tag hs-loi">Chưa thấy tờ khai</span></td><td class="mono">' + hsEsc(x.han_nop) + '</td><td colspan="2" class="hs-nho">Kiểm tra lại: có thể nộp ở hệ thống khác hoặc chưa tra cứu tới</td></tr>';
      }
    }
    if(!d.phai_nop.length && !d.ky_chua_thay.length){ el.innerHTML = hsTrong("Chưa có số liệu", "Tra cứu (Bước 2) rồi Lấy chi tiết (Bước 3)."); return; }
    h += '</tbody></table><div class="hs-nho" style="padding:10px 18px">Số phải nộp lấy theo tờ khai có hiệu lực của từng kỳ (bổ sung thay chính thức, bản bị từ chối không tính). Hạn nộp theo Luật Quản lý thuế, trùng thứ 7, chủ nhật hoặc ngày nghỉ lễ thì lùi sang ngày làm việc tiếp theo (lịch nghỉ các năm sau thêm vào tệp AIHoaDon\\ngay-nghi-le.txt). Số tô đỏ: đã qua hạn nộp.</div>';
    const nt = d.nop_tien || [];
    if(nt.length){
      h += '<table><thead><tr><th>Đối chiếu nộp tiền năm ' + hsEsc(nt[0].nam) + ' (tham khảo)</th><th class="num">Phải nộp theo tờ khai</th><th class="num">Đã nộp theo sổ sách</th><th class="num">Chênh</th><th class="num">Giấy nộp tiền (Cổng DVC)</th><th>Ghi chú</th></tr></thead><tbody>';
      for(const x of nt){
        const gc = [];
        if(x.loai === "GTGT") gc.push(x.so_ky + " kỳ có hạn nộp trong năm" + (x.ky.length ? " (" + x.ky.join(", ") + ")" : ""));
        else gc.push("TNDN tạm nộp theo quý không có tờ khai: chỉ liệt kê số đã nộp; phải nộp = [I] quyết toán có hạn trong năm");
        if(x.thieu_xml.length) gc.push("chưa đọc tờ khai: " + x.thieu_xml.join(", "));
        if(x.ky_chua_thay.length) gc.push("CHƯA THẤY tờ khai: " + x.ky_chua_thay.join(", "));
        if(!x.co_gnt) gc.push("chưa có giấy nộp tiền tải từ Cổng DVC");
        const ch = x.chenh_so === null ? "" : '<span class="' + (Math.abs(x.chenh_so) > 1000 ? "hs-lech" : "") + '">' + hsTien(x.chenh_so) + '</span>';
        h += '<tr><td><b>' + hsEsc(x.loai) + '</b></td><td class="num">' + hsTien(x.phai_nop) + '</td><td class="num">' + hsTien(x.da_nop_so)
          + ' <span class="hs-nho">(' + x.so_lan_so + ' lần)</span></td><td class="num">' + ch + '</td><td class="num">' + (x.co_gnt ? hsTien(x.da_nop_gnt) + (x.chenh_gnt !== null && Math.abs(x.chenh_gnt) > 1000 ? ' <span class="hs-lech">(chênh ' + hsTien(x.chenh_gnt) + ')</span>' : '') : "") + '</td><td class="hs-nho">' + hsEsc(gc.join("; ")) + '</td></tr>';
      }
      h += '</tbody></table><div class="hs-nho" style="padding:10px 18px">Đã nộp theo sổ sách = các bút toán Nợ 3331 / 3334, Có 111 / 112 trong năm tài chính đang mở của UNESCO. Chênh dương: có thể còn nợ thuế hoặc chưa ghi sổ giấy nộp tiền; chênh âm: nộp thừa hoặc nộp cho kỳ năm trước. Số dư nghĩa vụ chính xác xem trên thuedientu.gdt.gov.vn (Tra cứu nghĩa vụ thuế).</div>';
    }
  }
  el.innerHTML = h;
}
$("hsBang").addEventListener("click", async ev => {
  const t = ev.target.closest("button");
  if(!t) return;
  if(t.dataset.tep){ const r = await goi("/api/hstk/mo-tep", {duong: t.dataset.tep}); if(!r.ok) baoLoi("Không mở được tệp", r.loi || ""); }
  if(t.dataset.lay){ const r = await goi("/api/hstk/lay-chi-tiet", {ma: [t.dataset.lay], lam_lai: true}); if(!r.ok) baoLoi("Chưa lấy được chi tiết", r.loi || ""); else hsTrangThai(); }
});
$("hsMo").onclick = async () => { HS.daBaoLoi = false; await goi("/api/hstk/mo-chrome", {}); setTimeout(hsTrangThai, 800); };
$("hsNghe").onclick = async () => { const r = await goi("/api/hstk/nghe", {bat: true}); if(!r.ok) baoLoi("Chưa nhận được kết quả", r.loi || ""); hsTrangThai(); };
$("hsDungNghe").onclick = async () => { await goi("/api/hstk/nghe", {bat: false}); hsTrangThai(); };
$("hsChiTiet").onclick = async () => {
  const r = await goi("/api/hstk/lay-chi-tiet", {lam_lai: $("hsLamLai").checked});
  if(!r.ok) baoLoi("Chưa lấy được chi tiết", r.loi || ""); else hsTrangThai();
};
$("hsDung").onclick = async () => { await goi("/api/hstk/dung", {}); };
$("hsLamMoi").onclick = hsNap;
$("hsChanDoan").onclick = async () => {
  const r = await goi("/api/hstk/chan-doan", {ly_do: "nguoi-dung"});
  if(r.ok) $("hsBao").textContent = "Đã lưu cấu trúc trang: " + r.duong + " (đã mở thư mục).";
  else baoLoi("Chưa lưu được cấu trúc trang", r.loi || "");
};
$("hsXuat").onclick = async () => {
  $("hsXuat").disabled = true;
  const r = await goi("/api/hstk/xuat", {});
  $("hsXuat").disabled = false;
  if(r.ok){ $("hsGhiChu").textContent = "Đã gửi " + r.so + " hồ sơ sang UNESCO (tab Cổng DVC) và mở báo cáo CSV."; }
  else baoLoi("Chưa xuất được", r.loi || "");
};

/* ---- GD359: captcha hoá đơn máy tính tiền (cổng thuế bắt nhập mã cho mỗi lần tra cứu / lật trang) ---- */
(function(){
  let dangHien = false, lanCu = -1, dangGui = false, choAnhToi = 0;
  /* 26/11/2026 đợt 2: ảnh mã hiện TRỌN. Trước đây khung cố định 150 x 52 + overflow:hidden, còn ảnh (SVG của cổng thuế) rộng hơn khung
     nên bị cắt mất ký tự cuối -> người dùng gõ thiếu, cổng báo sai mãi. Nay: khung theo ảnh, ảnh phóng theo tỉ lệ (không cắt, không méo).
     Chương trình chỉ HIỂN THỊ ảnh; không đọc, không giải mã. */
  function veAnh(html){
    const box = document.getElementById("capMTTAnh");
    box.innerHTML = html || "";
    const s = box.querySelector("svg"), im = box.querySelector("img");
    if(s){
      let w = parseFloat(s.getAttribute("width")) || 0, c = parseFloat(s.getAttribute("height")) || 0;
      const vb = (s.getAttribute("viewBox") || "").trim().split(/[\s,]+/).map(Number);
      if(vb.length === 4 && vb[2] > 0 && vb[3] > 0){ w = vb[2]; c = vb[3]; }
      else {
        if(!(w > 0 && c > 0)){ try{ const b = s.getBBox(); w = b.x + b.width; c = b.y + b.height; }catch(e){} }
        if(w > 0 && c > 0) s.setAttribute("viewBox", "0 0 " + w + " " + c);
      }
      s.setAttribute("preserveAspectRatio", "xMidYMid meet");
      s.removeAttribute("width"); s.removeAttribute("height");
      const rong = Math.max(220, Math.min(340, Math.round((w || 200) * 1.5)));
      s.style.cssText = "display:block;width:" + rong + "px;max-width:100%;height:auto;overflow:visible";
    } else if(im){
      im.style.cssText = "display:block;min-width:220px;max-width:100%;height:auto";
    }
  }
  function hop(){
    let h = document.getElementById("capMTT");
    if(h) return h;
    h = document.createElement("div");
    h.id = "capMTT";
    h.style.cssText = "position:fixed;inset:0;background:rgba(5,15,30,.55);display:none;align-items:center;justify-content:center;z-index:9999;padding:16px";
    h.innerHTML = '<div style="background:var(--surface);color:var(--ink);border:1px solid var(--line-strong);border-radius:12px;max-width:520px;width:100%;padding:18px 20px;box-shadow:0 10px 40px rgba(0,0,0,.35)">' +
      '<div style="font-weight:700;font-size:16px;margin-bottom:4px">Nhập mã xác nhận – hoá đơn máy tính tiền</div>' +
      '<div id="capMTTMoTa" style="font-size:13px;color:var(--ink-soft);margin-bottom:10px"></div>' +
      '<div style="font-size:12.5px;margin-bottom:10px">Cổng thuế yêu cầu gõ mã cho mỗi lần tra cứu hoá đơn máy tính tiền (mỗi trang 50 hoá đơn). Hoá đơn điện tử thường không cần.</div>' +
      '<div id="capMTTLoi" style="color:#E5484D;font-size:13px;margin-bottom:6px"></div>' +
      '<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:10px">' +
        '<div id="capMTTAnh" style="flex:none;max-width:100%;min-height:52px;padding:6px 10px;background:#fff;border:1px solid var(--line-strong);border-radius:8px;display:flex;align-items:center;justify-content:center;overflow:visible"></div>' +
        '<button id="capMTTDoi" type="button" title="Ảnh khó đọc: lấy ảnh mã khác" style="padding:8px 12px;border-radius:8px;border:1px solid var(--line-strong);background:transparent;color:var(--ink);cursor:pointer">Lấy mã khác</button>' +
      '</div>' +
      '<input id="capMTTO" type="text" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="Gõ đủ các ký tự trong ảnh" style="display:block;width:100%;box-sizing:border-box;margin-bottom:6px;padding:9px 10px;border-radius:8px;border:1px solid var(--line-strong);background:var(--in-bg);color:var(--ink);font-size:16px;letter-spacing:.08em">' +
      '<div id="capMTTCon" style="font-size:12px;color:var(--ink-soft);margin-bottom:12px"></div>' +
      '<div style="display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end">' +
        '<button id="capMTTBoQua" type="button" style="padding:8px 12px;border-radius:8px;border:1px solid var(--line-strong);background:transparent;color:var(--ink);cursor:pointer">Bỏ qua HĐ máy tính tiền</button>' +
        '<button id="capMTTGui" type="button" style="padding:8px 16px;border-radius:8px;border:0;background:var(--blue);color:#fff;font-weight:700;cursor:pointer">Tiếp tục</button>' +
      '</div></div>';
    document.body.appendChild(h);
    const gui = async (body) => {
      // đợt 2: ẩn hộp ngay và KHÔNG vẽ lại cho tới khi máy chủ cục bộ nhận xong (trước đây lượt hỏi kế tiếp có thể vẽ lại ảnh cũ)
      // đợt 5: gõ mã / lấy mã khác thì hộp Ở NGUYÊN, ảnh kế tiếp hiện ngay trong chính hộp này (hỏi nhanh 0,25 giây một lần);
      //   chỉ «Bỏ qua» mới đóng hộp. Hết trang cần mã thì hộp tự đóng.
      const giu = !body.huy;
      if(giu){
        choAnhToi = Date.now() + 5000;
        document.getElementById("capMTTO").disabled = true; document.getElementById("capMTTGui").disabled = true;
        document.getElementById("capMTTLoi").textContent = "";
        document.getElementById("capMTTCon").textContent = body.doi ? "Đang lấy ảnh mã khác…" : "Đang gửi mã và lấy trang kế tiếp…";
      } else { h.style.display = "none"; dangHien = false; choAnhToi = 0; }
      dangGui = true;
      try{ await fetch("/api/captcha-mtt-gui", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(body)}); }catch(e){}
      dangGui = false;
      if(giu){ let n = 0; const nhanh = setInterval(() => { n++; hoi(); if(n > 40 || !choAnhToi) clearInterval(nhanh); }, 250); }
    };
    document.getElementById("capMTTGui").onclick = () => {
      const v = document.getElementById("capMTTO").value.trim();
      if(!v){ document.getElementById("capMTTO").focus(); return; }
      gui({cvalue: v});
    };
    document.getElementById("capMTTO").addEventListener("keydown", e => { if(e.key === "Enter") document.getElementById("capMTTGui").click(); });
    document.getElementById("capMTTBoQua").onclick = () => gui({huy: true, bo_qua_phien: true});
    document.getElementById("capMTTDoi").onclick = () => gui({doi: true});
    return h;
  }
  async function hoi(){
    let r = null;
    try{ r = await (await fetch("/api/captcha-mtt")).json(); }catch(e){ return; }
    const h = hop();
    if(dangGui) return;
    if(r && r.cho){
      if(!dangHien || r.lan !== lanCu){          // đợt 2: mỗi ảnh mã một số thứ tự - ảnh mới là vẽ lại ngay
        document.getElementById("capMTTMoTa").textContent = (r.mo_ta || "") +
          ((typeof TD_PHA !== "undefined" && TD_PHA === "mtt" && HUONG_QUEUE.length > 1) ? " — sau chiều này còn " + (HUONG_QUEUE.length - 1) + " chiều nữa cần gõ mã (bấm «Bỏ qua HĐ máy tính tiền» để thôi cả phần còn lại)" : "");
        document.getElementById("capMTTLoi").textContent = r.loi || "";
        veAnh(r.anh);
        document.getElementById("capMTTO").value = "";
        document.getElementById("capMTTO").disabled = false; document.getElementById("capMTTGui").disabled = false; choAnhToi = 0;
        h.style.display = "flex"; dangHien = true; lanCu = r.lan;
        setTimeout(() => document.getElementById("capMTTO").focus(), 50);
        try{ window.focus(); }catch(e){}
      }
      document.getElementById("capMTTCon").textContent = r.con ? ("Còn " + r.con + " giây để gõ mã; quá hạn thì bỏ qua hoá đơn máy tính tiền của lượt này (hoá đơn điện tử thường vẫn tải).") : "";
    }else if(dangHien){
      if(choAnhToi && Date.now() < choAnhToi) return;          // đợt 5: vừa gửi mã - chờ ảnh của trang kế trong cùng hộp
      choAnhToi = 0;
      document.getElementById("capMTTO").disabled = false; document.getElementById("capMTTGui").disabled = false;
      h.style.display = "none"; dangHien = false;
    }
  }
  setInterval(hoi, 1500);
})();
</script>
</body>
</html>
"""


# ==========================================================================
#  KHOI DONG
# ==========================================================================
# GD145: TAT TOOL CUNG TRANG TAI HOA DON. Trang giao dien goi /api/nhip moi 5 giay; dong trang (pagehide) -> gui
#   /api/thoat. Khong co trang nao goi lai trong 6 giay -> dong Chrome trang thue + tat Python. Nut 'Thoat' -> tat ngay.
#   Phong: trang an lau (Chrome giam nhip hen gio) -> chi tat khi 4 phut khong co nhip va KHONG dang tai.
THOAT = {"yeu_cau": 0.0, "nhip": {}, "co_nhip": False, "dang": False, "khoa": threading.Lock()}
THOAT_CHO_GIAY = 6
THOAT_MAT_NHIP_GIAY = 240


def thoat_ghi_nhip(pid):
    with THOAT["khoa"]:
        THOAT["nhip"][str(pid or "?")[:40]] = time.time()
        THOAT["co_nhip"] = True


def thoat_yeu_cau(pid, ngay=False):
    with THOAT["khoa"]:
        THOAT["nhip"].pop(str(pid or "?")[:40], None)
        THOAT["yeu_cau"] = time.time()
    if ngay:
        threading.Thread(target=thoat_tool, args=("Nguoi dung bam Thoat tren trang tai hoa don",), daemon=True).start()


def _thoat_canh_gac():
    """Luong nen: tat tool khi trang tai hoa don da dong."""
    while True:
        time.sleep(1)
        with THOAT["khoa"]:
            yc = THOAT["yeu_cau"]
            moi = max(THOAT["nhip"].values()) if THOAT["nhip"] else 0.0
            co = THOAT["co_nhip"]
        if yc and moi < yc and time.time() - yc > THOAT_CHO_GIAY:
            thoat_tool("Trang tai hoa don da dong")
            return
        if yc and moi >= yc:
            with THOAT["khoa"]:
                THOAT["yeu_cau"] = 0.0         # tai lai trang (F5) / con tab khac: khong tat
        if co and moi and time.time() - moi > THOAT_MAT_NHIP_GIAY and not STATE["tai"]["dang_chay"]:
            thoat_tool("Khong con trang tai hoa don nao mo (%d phut)" % (THOAT_MAT_NHIP_GIAY // 60))
            return


def thoat_tool(ly_do):
    """Dong Chrome trang thue (+ Chrome Cong DVC cua tool) roi tat Python."""
    with THOAT["khoa"]:
        if THOAT["dang"]:
            return
        THOAT["dang"] = True
    LOG.ghi("[KET THUC] %s - dong trang thue va tat tool." % ly_do)
    try:
        if STATE["tai"]["dang_chay"]:
            STATE["tai"]["dung"] = True
            t0 = time.time()
            while STATE["tai"]["dang_chay"] and time.time() - t0 < 20:
                time.sleep(0.5)
    except Exception:
        pass
    _chrome_dong_han()
    try:
        m = sys.modules.get("hstk_dvc")
        if m is not None and getattr(m, "TT", {}).get("cong"):
            c = m.TT["cong"]
            with urllib.request.urlopen("http://127.0.0.1:%d/json/version" % c, timeout=3) as r:
                ws = json.loads(r.read().decode("utf-8")).get("webSocketDebuggerUrl")
            k = KenhCDP(ws, timeout=10)
            try:
                k.goi("Browser.close")
            finally:
                k.dong()
            LOG.ghi("[KET THUC] Da dong cua so Cong dich vu cong cua tool.")
    except Exception:
        pass
    if UNESCO.get("nhung"):                                   # 26/11/2026: bo tep bao dia chi cua cua so nhung
        try:
            os.remove(nhung_tep_dia_chi())
        except Exception:
            pass
    LOG.ghi("[KET THUC] Tat tool.")
    if os.environ.get("UNESCO_THOAT_THU"):                     # GD145: bai kiem - khong tat tien trinh kiem
        THOAT["da_tat"] = True
        return
    os._exit(0)


def _an_cua_so_lenh():
    """GD145: chay tu phan mem UNESCO -> thu nho cua so den (van o thanh tac vu); tool tu tat khi dong trang tai hoa don."""
    if os.name != "nt":
        return
    try:
        import ctypes
        h = ctypes.windll.kernel32.GetConsoleWindow()
        if h:
            ctypes.windll.user32.ShowWindow(h, 7)            # SW_SHOWMINNOACTIVE
    except Exception:
        pass


_CTRL_HANDLER = []


def _bat_dong_cua_so_lenh():
    """GD145: nguoi dung bam X cua so den -> dong luon Chrome trang thue (Windows cho ~5 giay)."""
    if os.name != "nt":
        return
    try:
        import ctypes

        @ctypes.WINFUNCTYPE(ctypes.c_int, ctypes.c_uint)
        def _xu_ly(loai):
            if loai in (2, 5, 6):                            # CLOSE / LOGOFF / SHUTDOWN
                try:
                    LOG.ghi("[KET THUC] Cua so den bi dong - dong trang thue.")
                    _chrome_dong_han(cho=2.0)
                except Exception:
                    pass
            return 0
        _CTRL_HANDLER.append(_xu_ly)
        ctypes.windll.kernel32.SetConsoleCtrlHandler(_xu_ly, True)
    except Exception:
        pass


def nhung_tep_dia_chi():
    """26/11/2026: tep bao dia chi giao dien cho UNESCO XII (cua so nhung): <out>\\ket-qua\\NHUNG_GIAO_DIEN_<cong>.txt"""
    return os.path.join(unesco_thu_muc("ket-qua"), "NHUNG_GIAO_DIEN_%d.txt" % int(UNESCO.get("nhung") or 0))


def nhung_bao_dia_chi(dia_chi):
    """Ghi dia chi giao dien (http://127.0.0.1:<cong>) ra tep, ghi nguyen tu. Tep chi co dia chi - khong co phien, khong co mat khau."""
    try:
        dich = nhung_tep_dia_chi()
        tam = dich + ".tmp"
        with io.open(tam, "w", encoding="ascii") as f:
            f.write(dia_chi)
        os.replace(tam, dich)
        LOG.ghi("[NHUNG] Giao dien hien trong cua so nhung cua UNESCO XII (cong go loi %d)." % int(UNESCO.get("nhung") or 0))
    except Exception as e:
        LOG.loi("Khong ghi duoc tep bao dia chi cho cua so nhung", e)


def _nhung_canh_gac():
    """Cua so nhung da dong (UNESCO XII tat / bi tat ngang) -> cong go loi im 20 giay lien -> dung tai sach roi tat tool."""
    cong = int(UNESCO.get("nhung") or 0)
    im_tu = 0.0
    while cong:
        time.sleep(4)
        if _chrome_ds_tab(cong) is not None:
            im_tu = 0.0
            continue
        if not im_tu:
            im_tu = time.time()
        elif time.time() - im_tu >= 20:
            try:
                os.remove(nhung_tep_dia_chi())
            except Exception:
                pass
            thoat_tool("Cua so nhung cua UNESCO XII da dong")
            return


def tim_cong_trong(bat_dau=8765):
    for cong in range(bat_dau, bat_dau + 40):
        try:
            s = socket.socket()
            s.bind(("127.0.0.1", cong))
            s.close()
            return cong
        except Exception:
            continue
    return 0


def mo_chrome(url):
    duong_chrome = [
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    ]
    for d in duong_chrome:
        if os.path.exists(d):
            try:
                webbrowser.register("chrome", None, webbrowser.BackgroundBrowser(d))
                webbrowser.get("chrome").open(url)
                LOG.ghi("[KHOI DONG] Da mo Chrome tai: " + d)
                return True
            except Exception as e:
                LOG.loi("Khong mo duoc Chrome tai " + d, e)
    try:
        webbrowser.open(url)
        LOG.ghi("[KHOI DONG] Khong tim thay Chrome, da mo trinh duyet mac dinh.")
        return True
    except Exception as e:
        LOG.loi("Khong mo duoc trinh duyet nao", e)
        return False


def main():
    LOG.phan_cach("Mo tool")
    _tsdp = sys.modules.get("tham_so_du_phong")             # GD111
    if _tsdp is not None and _tsdp.TRANG_THAI.get("bu"):
        LOG.ghi("[UNESCO] GD111: tool chay KHONG kem tham so (lien ket .py cua Python install manager / Store) - lay tu %s"
                % os.path.basename(_tsdp.TRANG_THAI["bu"]))
    if THAM_SO_LOI:
        LOG.ghi("[UNESCO] KHONG doc duoc file tham so (%s) - thoat, khong mo giao dien." % "; ".join(THAM_SO_LOI))
        return
    if UNESCO.get("huvisoft"):
        LOG.ghi("[UNESCO] GD344: che do nhan tep Huvisoft, khong mo giao dien.")
        unesco_huvisoft(UNESCO["huvisoft"])
        return
    if UNESCO["nhap"]:
        LOG.ghi("[UNESCO] Che do nhap XML/ZIP, khong mo giao dien.")
        unesco_nhap_thu_muc(UNESCO["nhap"])
        return
    if UNESCO["goi_ai"]:
        LOG.ghi("[UNESCO] Che do goi Claude API, khong mo giao dien.")
        unesco_goi_claude(UNESCO["goi_ai"])
        return
    LOG.ghi("Phien ban tool      : %s" % APP_VERSION)
    LOG.ghi("Phien ban Python    : %s" % sys.version.replace("\n", " "))
    LOG.ghi("He dieu hanh        : %s %s (%s)" % (platform.system(), platform.release(), platform.machine()))
    LOG.ghi("Thu muc chua tool   : %s" % BASE_DIR)
    LOG.ghi("File nhat ky        : %s" % LOG_PATH)
    LOG.ghi("Thu muc luu hoa don : %s" % (SETTINGS.get("thu_muc_luu") or "(chua chon)"))
    LOG.ghi("Ma so thue da nho   : %s" % (SETTINGS.get("mst") or "(chua co)"))
    LOG.ghi("May chu dung lan truoc: %s" % (SETTINGS.get("may_chu_da_chay") or "(chua co, se tu do tim)"))
    LOG.ghi("Duong tai dung lan truoc: %s" % json.dumps(SETTINGS.get("duong_tai_da_chay", {}), ensure_ascii=False))
    LOG.ghi("Hop thoai chon thu muc: %s" % ("dung duoc" if TK_OK else "KHONG dung duoc (thieu tkinter)"))
    _dang_tai_don()             # GD94: tep DANG_TAI cua cua so da tat ngang

    cong = tim_cong_trong()
    if not cong:
        print("Khong tim duoc cong trong de chay tool. Xem file nhat ky:", LOG_PATH)
        LOG.ghi("[KHOI DONG] LOI: khong tim duoc cong trong.")
        input("Nhan Enter de dong...")
        return

    dia_chi = "http://127.0.0.1:%d" % cong
    LOG.ghi("[KHOI DONG] Giao dien chay tai: " + dia_chi)

    server = http.server.ThreadingHTTPServer(("127.0.0.1", cong), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    threading.Thread(target=_thoat_canh_gac, daemon=True).start()       # GD145: dong trang tai hoa don -> tat tool
    if UNESCO.get("bat"):
        _bat_dong_cua_so_lenh()

    print("=" * 58)
    print("  TOOL TAI HOA DON DIEN TU HANG LOAT - phien ban", APP_VERSION)
    print("=" * 58)
    print("  Giao dien dang mo trong Chrome:", dia_chi)
    print("  File nhat ky:", LOG_PATH)
    print()
    print("  GIU NGUYEN cua so nay trong luc dung tool.")
    print("  Dong cua so nay = tat tool.")
    print("  Dong trang tai hoa don (hoac bam Thoat) = tat tool + dong trang thue.")
    print("=" * 58)

    time.sleep(0.6)
    if UNESCO.get("nhung"):
        # 26/11/2026: UNESCO XII tu hien giao dien nay trong cua so nhung -> chi bao dia chi, KHONG mo Chrome
        nhung_bao_dia_chi(dia_chi)
        threading.Thread(target=_nhung_canh_gac, daemon=True).start()
    else:
        mo_chrome(dia_chi)
    if UNESCO.get("bat"):
        _an_cua_so_lenh()                   # GD145: cua so den thu nho (van o thanh tac vu)

    # Luong chinh: cho de mo hop thoai chon thu muc (tkinter chi chay o luong chinh)
    if TK_OK:
        root = tk.Tk()
        _gd167_ico(root)
        root.withdraw()

        def kiem_tra():
            try:
                while True:
                    tra_loi = HOP_THU_CHON_THU_MUC.get_nowait()
                    try:
                        root.deiconify(); root.withdraw()
                        root.attributes("-topmost", True)
                        thu_muc = filedialog.askdirectory(
                            title="Chọn thư mục lưu file XML hóa đơn",
                            initialdir=SETTINGS.get("thu_muc_luu") or os.path.expanduser("~"))
                        root.attributes("-topmost", False)
                        tra_loi.put(thu_muc or "")
                    except Exception as e:
                        LOG.loi("Loi khi mo hop thoai chon thu muc", e)
                        tra_loi.put("")
            except queue.Empty:
                pass
            except Exception as e:
                LOG.loi("Loi trong vong lap chon thu muc", e)
            try:          # GD359b: chon tep Excel "Xuat chi tiet" tai cong thue
                while True:
                    tra_loi = HOP_THU_CHON_TEP.get_nowait()
                    try:
                        root.deiconify(); root.withdraw()
                        root.attributes("-topmost", True)
                        tep = filedialog.askopenfilename(
                            title="Chọn file Excel 'Xuất chi tiết' tải từ hoadondientu.gdt.gov.vn",
                            filetypes=[("Excel", "*.xlsx"), ("Tất cả", "*.*")],
                            initialdir=os.path.join(os.path.expanduser("~"), "Downloads"))
                        root.attributes("-topmost", False)
                        tra_loi.put(tep or "")
                    except Exception as e:
                        LOG.loi("Loi khi mo hop thoai chon tep", e)
                        tra_loi.put("")
            except queue.Empty:
                pass
            root.after(200, kiem_tra)

        root.after(200, kiem_tra)
        try:
            root.mainloop()
        except KeyboardInterrupt:
            pass
    else:
        LOG.ghi("[KHOI DONG] Khong co tkinter - nut chon thu muc se khong mo duoc hop thoai.")
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            pass

    LOG.ghi("[KET THUC] Nguoi dung dong tool.")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        LOG.loi("Loi nghiem trong lam tool phai dung", e)
        try:
            print()
            print("Tool gap loi va phai dung lai.")
            print("Chi tiet da duoc ghi vao file:", LOG_PATH)
            print("Neu loi lap lai, gui file nhat-ky.txt cho nguoi ho tro.")
            input("Nhan Enter de dong...")
        except Exception:
            pass
