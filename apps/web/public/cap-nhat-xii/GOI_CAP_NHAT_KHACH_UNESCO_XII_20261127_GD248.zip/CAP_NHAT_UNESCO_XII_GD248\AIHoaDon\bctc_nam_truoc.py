# -*- coding: utf-8 -*-
"""GD131 - SO LIEU NAM TRUOC CHO BAO CAO TAI CHINH (CA HAI THONG TU: TT133/2016 VA TT99/2025) - CHI DOC, KHONG GHI SO.

VB6 (ModNamTruoc.NT131_Nhap / menu He thong -> So lieu nam truoc BCTC) goi:
    tool_htkk_unesco.py /namtruoc:<N-1> /chedo:<133|99> /thangdau:<m> /mst:"<MST>" /thumuc:"<thu muc khach>"
                        [/tep:"<tep Excel / XML / ZIP>"] /ra:"<...\\so-lieu-nam-truoc\\NAM_TRUOC_<N-1>.txt>"
    -> moc ket-qua\\DA_XONG_KHOASO "OK <txt>" / "LOI <mo ta>".

NGUON (khong co /tep: tu tim; co /tep: dung dung tep do):
  1) Tep XML to khai BCTC nam N-1 trong thu muc khach (XML HTKK / tai tu Cong): maTKhai 1281 (TT99), 402 (TT200),
     683 / 684 / 685 (TT133 B01a / B01b / B01-KLT).
  2) Du lieu HTKK tren may: <HTKK>\\DataFiles\\<MST>\\  99_0x_*, 200_0x_* (CDKT, SXKD, LCTTTT, LCTTGT), 133_B01A_0x_* ...
     (to khai nam N-1, uu tien ca nam, ban bo sung moi nhat).
  GD162) Tep BCTC nam N-1 anh chi da LUU (nguon-ky-truoc.json - He thong -> Nguon HTKK, to khai va BCTC ky truoc): dung TRUOC
     khi tu tim (doc loi thi tu tim nhu cu, kem canh bao).
  3) Tep nguoi dung chon: .xml (XML HTKK hoac tep du lieu HTKK - tu lay ca bo cung ky trong thu muc), .zip (tai tu Cong),
     .xlsx / .xls / .csv (Excel BCTC bat ky: tim cot "Ma so" va cot "Nam nay" / "So cuoi nam", nhan dang mau B01 / B02 /
     B03 truc tiep / gian tiep theo tieu de va bo ma so).
CHUYEN MA (so bo so dang dung):
  * Cung Thong tu -> giu ma.  * So TT99, nam truoc TT200 (TT99 thay TT200 tu 01/01/2026): B02 21 -> 22, 22 -> 23, 23 -> 24;
    B03 truc tiep / gian tiep giu ma; B01 theo bang doi chieu ma (B01_200_99, dong tong dieu chinh phan cho vay).
  * So TT99, nam truoc TT133: B02 (24 CP quan ly kinh doanh -> 26), B03 truc tiep (25 -> 27, 35 -> 36); B01 / B03 gian
    tiep khong chuyen (canh bao).  * So TT133, nguon TT200 / TT99: khong chuyen (bao loi).
KET QUA (.txt UTF-8, VB6 doc): dong KHOA=GIA TRI (NAM, TT_DICH, TT_NGUON, NGUON, XLSX, CB=canh bao) roi
    <bao cao>|<ma so>|<so tien>  - bao cao: B01 (TT99) | B01A / B01B / B01KLT (TT133) | B02 | B03 | B03GT.
  + .xlsx xem truoc cung ten (tom tat + tung bao cao + doi chieu ma). VB6 hien tom tat, nguoi dung DONG Y moi ghi vao
    bang BCTC_NamTruoc cua bo so (sao luu ban cu sang BCTC_NamTruoc_Cu). Khong dung den chung tu / so du.
"""
import datetime as _dt
import io
import os
import re
import sys
import zipfile
import xml.etree.ElementTree as ET

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

BAO_CAO = ("B01", "B02", "B03", "B03GT")
TEN_BC = {"B01": "B01 - Báo cáo tình hình tài chính", "B02": "B02 - Báo cáo kết quả hoạt động kinh doanh",
          "B03": "B03 - Lưu chuyển tiền tệ (trực tiếp)", "B03GT": "B03 - Lưu chuyển tiền tệ (gián tiếp)"}
TEN_TT = {"99": "TT99/2025", "200": "TT200/2014", "133": "TT133/2016"}
TEN_MAU = {"B01A": "B01a-DNN", "B01B": "B01b-DNN", "B01KLT": "B01-DNNKLT", "": ""}

# maTKhai HTKK -> (Thong tu, mau B01)
MA_TKHAI = {"683": ("133", "B01A"), "684": ("133", "B01B"), "685": ("133", "B01KLT"), "402": ("200", ""), "1281": ("99", "")}

# tien to tep du lieu HTKK (DataFiles\<MST>) theo (Thong tu, mau)
TIEN_TO = {
    ("99", ""): {"B01": "99_01_THTC", "B02": "99_02_KQHDKD", "B03": "99_03_LCTTTT", "B03GT": "99_04_LCTTGT"},
    ("200", ""): {"B01": "200_01_CDKT", "B02": "200_02_SXKD", "B03": "200_03_LCTTTT", "B03GT": "200_04_LCTTGT"},
    ("133", "B01A"): {"B01": "133_B01A_01_THTC", "B02": "133_B01A_02_SXKD", "B03": "133_B01A_03_LCTTTT", "B03GT": "133_B01A_04_LCTTGT"},
    ("133", "B01B"): {"B01": "133_B01B_01_THTC", "B02": "133_B01B_02_SXKD", "B03": "133_B01B_03_LCTTTT", "B03GT": "133_B01B_04_LCTTGT"},
    ("133", "B01KLT"): {"B01": "133_B01_01_THTC_KLT", "B02": "133_B01_02_SXKD_KLT", "B03": "133_B01_03_LCTTTT_KLT",
                        "B03GT": "133_B01_04_LCTTGT_KLT"},
}
THU_TU_TIM = {"99": (("99", ""), ("200", ""), ("133", "B01A"), ("133", "B01B"), ("133", "B01KLT")),
              "133": (("133", "B01A"), ("133", "B01B"), ("133", "B01KLT"))}

# khoi so lieu trong XML HTKK (duong da bo namespace) / tep du lieu HTKK (Cell Path)
KHOI = {
    "B01": re.compile(r"(?:^|/)(?:(?:CDKT|BCTHTC)_HoatDong(Khong)?LienTuc/)?SoCuoiNam/ct(\w+)$"),
    "B02": re.compile(r"(?:^|/)PL_KQHDSXKD/NamNay/ct(\w+)$"),
    "B03": re.compile(r"(?:^|/)PL_LCTTTT/NamNay/ct(\w+)$"),
    "B03GT": re.compile(r"(?:^|/)PL_LCTTGT/NamNay/ct(\w+)$"),
}

# ------------------------------------------------------------------ bang doi chieu ma
# B01: TT200 (B01-DN, 115 chi tieu) -> TT99 (B01-DN Bao cao tinh hinh tai chinh, 126 chi tieu). Nhieu ma -> mot ma: cong.
B01_200_99 = {
    "100": "100", "110": "110", "111": "111", "112": "112", "120": "120", "121": "121", "122": "122", "123": "123",
    "130": "130", "131": "131", "132": "132", "133": "133", "134": "134", "135": "123", "136": "135", "137": "136", "139": "137",
    "140": "140", "141": "141", "149": "142",
    "150": "160", "151": "161", "152": "162", "153": "163", "154": "164", "155": "165",
    "200": "200", "210": "210", "211": "211", "212": "212", "213": "213", "214": "214", "215": "265", "216": "215", "219": "216",
    "220": "220", "221": "221", "222": "222", "223": "223", "224": "224", "225": "225", "226": "226", "227": "227", "228": "228",
    "229": "229", "230": "240", "231": "241", "232": "242", "240": "250", "241": "251", "242": "252",
    "250": "260", "251": "261", "252": "262", "253": "263", "254": "264", "255": "265",
    "260": "270", "261": "271", "262": "272", "263": "273", "268": "274", "270": "280",
    "300": "300", "310": "310", "311": "311", "312": "312", "313": "314", "314": "315", "315": "316", "316": "317", "317": "318",
    "318": "319", "319": "320", "320": "321", "321": "322", "322": "323", "323": "324", "324": "325",
    "330": "330", "331": "331", "332": "332", "333": "334", "334": "335", "335": "336", "336": "337", "337": "338", "338": "339",
    "339": "340", "340": "341", "341": "342", "342": "343", "343": "344",
    "400": "400", "411": "411", "411a": "411a", "411b": "411b", "412": "412", "413": "413", "414": "414", "415": "415",
    "416": "416", "417": "417", "418": "418", "419": "419", "420": "419", "421": "420", "421a": "420a", "421b": "420b",
    "422": "414", "440": "440",
}
B01_200_99_BO = ("410", "430", "431", "432")     # TT99 khong co dong rieng (410 = dong nhom; 430 nguon kinh phi)
# dong tong TT99 phai tinh lai khi chi tiet doi nhom: (ma TT200 chi tiet, nhom cu TT99, nhom moi TT99)
B01_200_99_DOI_NHOM = (("135", "130", "120"), ("215", "210", "260"))
B02_200_99 = {"21": "22", "22": "23", "23": "24"}
B02_133_99 = {"21": "22", "22": "23", "23": "24", "24": "26"}
B03_133_99 = {"25": "27", "35": "36"}


def _ma_dich(tt):
    return {bc: set(d) for bc, d in NHAN.get(tt, {}).items()}


# ------------------------------------------------------------------ tien ich
def so(v):
    """So tu o Excel / XML: 1234567 | "1.234.567" | "1,234,567.5" | "(1.234)" | "-" -> float (0 neu khong phai so)."""
    if v is None or isinstance(v, bool):
        return 0.0
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip().replace(" ", "").replace(" ", "")
    if not s or s in ("-", "--", "—"):
        return 0.0
    am = False
    if s.startswith("(") and s.endswith(")"):
        am, s = True, s[1:-1]
    if s.startswith("-"):
        am, s = (not am), s[1:]
    if not re.match(r"^[0-9.,]+$", s):
        return 0.0
    if "," in s and "." in s:
        if s.rfind(",") > s.rfind("."):
            s = s.replace(".", "").replace(",", ".")
        else:
            s = s.replace(",", "")
    elif s.count(".") > 1 or (s.count(".") == 1 and len(s.split(".")[1]) == 3 and 1 <= len(s.split(".")[0]) <= 3):
        s = s.replace(".", "")
    elif s.count(",") > 1 or (s.count(",") == 1 and len(s.split(",")[1]) == 3 and 1 <= len(s.split(",")[0]) <= 3):
        s = s.replace(",", "")
    else:
        s = s.replace(",", ".")
    try:
        x = float(s)
    except ValueError:
        return 0.0
    return -x if am else x


def _dd(v):
    try:
        return "{:,.0f}".format(round(v)).replace(",", ".")
    except Exception:
        return str(v)


def chuan_ma(bc, ma):
    """Ma so chi tieu chuan: B01 '110' / '411a'; B02 / B03 hai chu so '01'."""
    m = str(ma or "").strip().lower().replace(" ", "")
    if re.match(r"^\d+\.0$", m):
        m = m[:-2]
    if re.match(r"^0+\d", m):
        m = m.lstrip("0")
    if not re.match(r"^\d{1,3}[a-z]?$", m):
        return ""
    if bc == "B01":
        return m
    return m.zfill(2) if m.isdigit() else m


def khong_dau(s):
    import unicodedata
    s = unicodedata.normalize("NFD", str(s or ""))
    s = "".join(c for c in s if unicodedata.category(c) != "Mn").replace("đ", "d").replace("Đ", "D")
    return re.sub(r"[^0-9a-z]+", "", s.lower())


def _giai_ma(b):
    if b[:2] in (b"\xff\xfe", b"\xfe\xff"):
        return b.decode("utf-16", "replace")
    if b[:3] == b"\xef\xbb\xbf":
        return b[3:].decode("utf-8", "replace")
    if len(b) > 1 and b[1:2] == b"\x00":
        return b.decode("utf-16-le", "replace")
    return b.decode("utf-8", "replace")


# ------------------------------------------------------------------ doc XML / du lieu HTKK
def phang_xml(b):
    """bytes XML -> (kieu, {duong: gia tri}) | kieu 'cell' (tep du lieu HTKK) / 'tk' (XML to khai) / '' khong doc duoc."""
    s = _giai_ma(b)
    if "<Cell" in s[:200000] and "Path=" in s[:200000]:
        d = {}
        for m in re.finditer(r"<Cell\s([^>]*?)/?>", s):
            a = dict(re.findall(r'(\w+)="([^"]*)"', m.group(1)))
            if a.get("Path"):
                d.setdefault(a["Path"], a.get("Value", ""))
        return "cell", d
    s2 = re.sub(r"^\s*<\?xml[^>]*\?>", "", s.lstrip("﻿"))
    try:
        goc = ET.fromstring(s2)
    except ET.ParseError:
        return "", {}
    out = {}

    def di(n, p):
        ten = n.tag.split("}", 1)[-1]
        p2 = p + "/" + ten if p else ten
        con = list(n)
        if not con:
            out.setdefault(p2, (n.text or "").strip())
        for c in con:
            di(c, p2)
    di(goc, "")
    return "tk", out


def tach_khoi(d):
    """{duong: gia tri} -> ({bao cao: {ma: so}}, co_khong_lien_tuc)."""
    kq = {bc: {} for bc in BAO_CAO}
    klt = {}
    for p, v in d.items():
        for bc, rx in KHOI.items():
            m = rx.search(p)
            if not m:
                continue
            if bc == "B01":
                ma = chuan_ma(bc, m.group(2))
                if not ma:
                    continue
                if m.group(1):
                    klt[ma] = so(v)
                else:
                    kq[bc][ma] = so(v)
            else:
                ma = chuan_ma(bc, m.group(1))
                if ma:
                    kq[bc][ma] = so(v)
    dung_klt = False
    if klt and not any(kq["B01"].values()) and any(klt.values()):
        kq["B01"] = klt
        dung_klt = True
    return {bc: v for bc, v in kq.items() if v}, dung_klt


def thong_tin_tk(d):
    """XML to khai: -> (maTKhai, ky)"""
    ma = ky = ""
    for p, v in d.items():
        if p.endswith("TKhaiThue/maTKhai"):
            ma = v.strip()
        elif p.endswith("KyKKhaiThue/kyKKhai"):
            ky = v.strip()
    return ma, ky


def che_do_tu_duong(d, ten_tep=""):
    """Thong tu + mau cua mot bo so lieu HTKK (theo khoi XML / ten tep)."""
    for p in d:
        if "BCTHTC_HoatDong" in p:
            return "99", ""
        if "CDKT_HoatDong" in p:
            return "200", ""
    t = os.path.basename(ten_tep or "").upper()
    t = re.sub(r"^BS\d+_", "", t)
    for (tt, mau), ds in TIEN_TO.items():
        for tien in ds.values():
            if t.startswith(tien.upper() + "_"):
                return tt, mau
    return "", ""


RX_TEP = r"^(?:bs(\d+)_)?%s_(\d{4})_(\d{8})_(\d{8})(?:[_ ].*)?\.xml$"


def _ngay8(s):
    try:
        return _dt.date(int(s[4:8]), int(s[2:4]), int(s[0:2]))
    except ValueError:
        return None


def chon_tep_htkk(thu_muc, tien_to, nam):
    """Tep du lieu HTKK tot nhat cua mot bao cao nam `nam`: ca nam (>= 300 ngay) > ngay cuoi muon > ban bo sung cao > moi nhat."""
    if not thu_muc or not os.path.isdir(thu_muc):
        return ""
    rx = re.compile(RX_TEP % re.escape(tien_to), re.I)
    tot, diem = "", None
    for t in os.listdir(thu_muc):
        m = rx.match(t)
        if not m or int(m.group(2)) != int(nam):
            continue
        d1, d2 = _ngay8(m.group(3)), _ngay8(m.group(4))
        if not d1 or not d2:
            continue
        p = os.path.join(thu_muc, t)
        try:
            mt = os.path.getmtime(p)
        except OSError:
            continue
        k = ((d2 - d1).days >= 300, d2, int(m.group(1) or 0), mt)
        if diem is None or k > diem:
            tot, diem = p, k
    return tot


def thu_muc_mst(goc_htkk, mst):
    so_ = re.sub(r"[^0-9-]", "", str(mst or ""))
    for ten in (so_, so_.split("-")[0]):
        p = os.path.join(goc_htkk, "DataFiles", ten)
        if ten and os.path.isdir(p):
            return p
    return ""


def doc_bo_htkk(thu_muc, tt, mau, nam, chi_bc=None):
    """Bo tep du lieu HTKK cung Thong tu / mau trong thu muc -> (so lieu, [ten tep], dung_klt)"""
    sl, tep, klt = {}, [], False
    for bc, tien in TIEN_TO[(tt, mau)].items():
        if chi_bc and bc not in chi_bc:
            continue
        p = chon_tep_htkk(thu_muc, tien, nam)
        if not p:
            continue
        try:
            with open(p, "rb") as f:
                _, d = phang_xml(f.read())
        except OSError:
            continue
        k, x = tach_khoi(d)
        if k.get(bc):
            sl[bc] = k[bc]
            tep.append(os.path.basename(p))
            klt = klt or (x and bc == "B01")
    return sl, tep, klt


# ------------------------------------------------------------------ doc Excel bat ky
TU_NAY = ("namnay", "socuoinam", "socuoiky", "cuoinam", "kynay", "socuoiquy", "cuoiky", "luyketudaunam")
TU_TRUOC = ("namtruoc", "sodaunam", "kytruoc", "daunam")


def _dong_so_cot(row):
    """Dong danh so cot duoi tieu de bang ("1 2 3 4 5" / "A B 1 2")."""
    x = [str(v).strip() for v in row if v not in (None, "") and str(v).strip()]
    if len(x) < 3:
        return False
    so_ = [int(float(v)) for v in x if re.match(r"^\d+(\.0)?$", v)]
    return len(so_) >= len(x) - 2 and so_ == sorted(so_) and len(set(so_)) == len(so_) and (not so_ or so_[-1] <= 12)


def _bang_excel(rows):
    """Mot sheet -> (ma -> so nam nay, {ma: ten}, tieu de khong dau) hoac None."""
    if not rows:
        return None
    vung = rows[:40]
    hd = cma = None
    for r, row in enumerate(vung):
        for c, v in enumerate(row or []):
            g = khong_dau(v)
            if g in ("maso", "masochitieu", "machitieu", "mact", "masoct"):
                hd, cma = r, c
                break
        if hd is not None:
            break
    if hd is None:
        return None
    cnay = None
    ctm = set()
    for r in range(hd, min(hd + 3, len(rows))):
        for c, v in enumerate(rows[r] or []):
            g = khong_dau(v)
            if c <= cma or not g:
                continue
            if "thuyetminh" in g:
                ctm.add(c)
            elif cnay is None and any(t in g for t in TU_NAY):
                cnay = c
    du_lieu = []
    for r in range(hd + 1, len(rows)):
        row = rows[r] or []
        if r <= hd + 2 and _dong_so_cot(row):
            continue
        ma = chuan_ma("B01", row[cma] if cma < len(row) else "")
        if ma:
            du_lieu.append((r, ma))
    if len(du_lieu) < 3:
        return None
    if cnay is None:
        dem = {}
        for r, _ in du_lieu:
            row = rows[r]
            for c in range(cma + 1, len(row)):
                if c in ctm:
                    continue
                v = row[c]
                if isinstance(v, (int, float)) and not isinstance(v, bool) or (isinstance(v, str) and so(v)):
                    dem[c] = dem.get(c, 0) + 1
        if not dem:
            return None
        cnay = min(c for c, n in dem.items() if n >= max(1, max(dem.values()) // 2))
    sl, ten = {}, {}
    for r, ma in du_lieu:
        row = rows[r]
        v = row[cnay] if cnay < len(row) else None
        if ma not in sl:
            sl[ma] = so(v)
            t = " ".join(str(x).strip() for x in row[:cma] if x not in (None, "") and str(x).strip())
            ten[ma] = re.sub(r"\s+", " ", t)[:100]
    tieu = khong_dau(" ".join(str(x) for row in rows[:hd + 1] for x in (row or []) if x not in (None, "")))
    return sl, ten, tieu


def nhan_dang_bang(sl, ten, tieu, ten_sheet=""):
    """-> (bao cao, Thong tu nguon, mau) cua mot bang Excel."""
    ma = set(sl)
    t = tieu + khong_dau(ten_sheet)
    nhan = {k: khong_dau(v) for k, v in ten.items()}
    if "luuchuyentiente" in t or "61" in ma or "061" in ma:
        b3 = {chuan_ma("B03", x) for x in ma}
        gt = "giantiep" in t or ("17" in b3 and "09" in b3) or "loinhuantruocthue" in nhan.get("1", "") + nhan.get("01", "")
        bc = "B03GT" if gt else "B03"
        if gt:
            tt = "133" if "18" in b3 else "200"
        else:
            tt = "200" if (b3 & {"26", "27", "36"}) else "133"
        return bc, tt, ""
    if "ketquahoatdong" in t or ("11" in ma and "20" in ma and "60" in ma) or ("011" in ma) or ({"1", "2", "10", "11", "20"} <= ma):
        b2 = {chuan_ma("B02", x) for x in ma}
        if "24" in b2 and "25" in b2:
            tt = "99"
        elif "25" in b2:
            tt = "200"
        else:
            tt = "133"
        if "batdongsan" in nhan.get("21", ""):
            tt = "99"
        return "B02", tt, ""
    if "candoiketoan" in t or "tinhhinhtaichinh" in t or "440" in ma or ("200" in ma and "500" in ma):
        if "280" in ma:
            tt = "99"
        elif "440" in ma or "139" in ma or "149" in ma:
            tt = "200"
        else:
            tt = "133"
        mau = ""
        if tt == "133":
            if "600" in ma or "511" in ma or "b01b" in t:
                mau = "B01B"
            elif ("171" in ma and "180" not in ma) or "klt" in t or "khongdapung" in t:
                mau = "B01KLT"
            else:
                mau = "B01A"
        return "B01", tt, mau
    return "", "", ""


def doc_excel(tep):
    """-> (so lieu {bc: {ma: so}}, thong tu nguon, mau, canh bao, {bc: {ma: ten}})"""
    import hd_excel_ai as HX
    sheets, _, an = HX.doc_tep(tep)
    tot = {}
    cb = []
    for ten_sh, rows in sheets.items():
        if ten_sh in an:
            continue
        x = _bang_excel(rows)
        if not x:
            continue
        sl, ten, tieu = x
        bc, tt, mau = nhan_dang_bang(sl, ten, tieu, ten_sh)
        if not bc:
            continue
        sl = {chuan_ma(bc, k): v for k, v in sl.items() if chuan_ma(bc, k)}
        ten = {chuan_ma(bc, k): v for k, v in ten.items() if chuan_ma(bc, k)}
        diem = sum(1 for v in sl.values() if v)
        if bc not in tot or diem > tot[bc][3]:
            tot[bc] = (sl, tt, mau, diem, ten, ten_sh)
    if not tot:
        return {}, "", "", ["Không tìm thấy bảng báo cáo tài chính trong tệp Excel (cần cột \"Mã số\" và cột \"Năm nay\" / "
                            "\"Số cuối năm\")."], {}
    tts = {v[1] for k, v in tot.items() if k in ("B01", "B02")}
    tt = "99" if "99" in tts else ("200" if "200" in tts else ("133" if "133" in tts else
                                                               sorted({v[1] for v in tot.values()})[0]))
    mau = tot["B01"][2] if "B01" in tot else ("B01A" if tt == "133" else "")
    for bc, v in sorted(tot.items()):
        cb.append("Excel: %s lấy ở sheet \"%s\" (%d chỉ tiêu có số)." % (TEN_BC[bc], v[5], v[3]))
    if len(tts) > 1:
        cb.append("Excel: các sheet có mẫu của nhiều Thông tư (%s) - dùng %s." % (", ".join(TEN_TT.get(x, x) for x in sorted(tts)),
                                                                               TEN_TT.get(tt, tt)))
    return ({bc: v[0] for bc, v in tot.items()}, tt, mau, cb, {bc: v[4] for bc, v in tot.items()})


# ------------------------------------------------------------------ doc nguon
class Nguon(object):
    def __init__(self):
        self.sl = {}
        self.tt = ""
        self.mau = ""
        self.mo_ta = ""
        self.cb = []
        self.ten = {}
        self.ky = ""


def doc_xml_bytes(b, ten, nam, ng):
    kieu, d = phang_xml(b)
    if not kieu:
        return False
    sl, klt = tach_khoi(d)
    if not sl:
        return False
    if kieu == "tk":
        ma, ky = thong_tin_tk(d)
        if ma and ma not in MA_TKHAI:
            ng.cb.append("Tệp %s là tờ khai mã %s - không phải bộ báo cáo tài chính năm." % (ten, ma))
            return False
        tt, mau = MA_TKHAI.get(ma) or che_do_tu_duong(d, ten)
        ng.ky = ky
    else:
        tt, mau = che_do_tu_duong(d, ten)
        m = re.search(r"_(\d{4})_\d{8}_\d{8}", os.path.basename(ten))
        ng.ky = m.group(1) if m else ""
    if not tt:
        return False
    ng.sl.update(sl)
    ng.tt, ng.mau = tt, mau
    if klt:
        ng.cb.append("B01: tờ khai năm trước lập theo mẫu \"hoạt động KHÔNG liên tục\" - đã lấy cột Số cuối năm của mẫu đó.")
    return True


def doc_tep(tep, nam, ng):
    duoi = os.path.splitext(tep)[1].lower()
    ten = os.path.basename(tep)
    if duoi == ".zip":
        with zipfile.ZipFile(tep) as z:
            for i in z.infolist():
                if i.filename.lower().endswith(".xml") and i.file_size < 20000000:
                    tmp = Nguon()
                    if doc_xml_bytes(z.read(i), os.path.basename(i.filename), nam, tmp):
                        ng.sl, ng.tt, ng.mau, ng.ky, ng.cb = tmp.sl, tmp.tt, tmp.mau, tmp.ky, ng.cb + tmp.cb
                        ng.mo_ta = "tệp ZIP %s (%s)" % (ten, os.path.basename(i.filename))
                        return True
        raise ValueError("Tệp ZIP %s không có XML bộ báo cáo tài chính năm (B01 / B02 / B03)." % ten)
    if duoi == ".xml":
        with open(tep, "rb") as f:
            b = f.read()
        if not doc_xml_bytes(b, ten, nam, ng):
            raise ValueError("Tệp %s không phải XML bộ báo cáo tài chính năm (HTKK TT133 / TT200 / TT99) hoặc không có số liệu." % ten)
        ng.mo_ta = "tệp XML %s" % ten
        # tep du lieu HTKK (mot bao cao): lay ca bo cung ky trong cung thu muc
        m = re.match(r"^(bs\d+_)?(.+?)_(\d{4}_\d{8}_\d{8})(.*)\.xml$", ten, re.I)
        if m and (ng.tt, ng.mau) in TIEN_TO:
            them = []
            for bc, tien in TIEN_TO[(ng.tt, ng.mau)].items():
                if bc in ng.sl:
                    continue
                p = os.path.join(os.path.dirname(tep), "%s%s_%s%s.xml" % (m.group(1) or "", tien, m.group(3), m.group(4)))
                if os.path.isfile(p):
                    with open(p, "rb") as f:
                        _, d = phang_xml(f.read())
                    k, _ = tach_khoi(d)
                    if k.get(bc):
                        ng.sl[bc] = k[bc]
                        them.append(os.path.basename(p))
            if them:
                ng.mo_ta += " + cùng kỳ: " + ", ".join(them)
        return True
    if duoi in (".xlsx", ".xlsm", ".xls", ".csv"):
        sl, tt, mau, cb, ten_ct = doc_excel(tep)
        if not sl:
            raise ValueError(cb[0] if cb else "Không đọc được tệp Excel %s." % ten)
        ng.sl, ng.tt, ng.mau, ng.ten = sl, tt, mau, ten_ct
        ng.cb.extend(cb)
        ng.mo_ta = "tệp Excel %s" % ten
        return True
    raise ValueError("Chỉ nhận tệp Excel (.xlsx / .xls / .csv), XML HTKK (.xml) hoặc tệp tải từ Cổng (.zip): %s" % ten)


BO_THU_MUC = ("so-lieu-nam-truoc", "ket-qua", "xml", "pdf", "anh", "hddttaive", "chrome-ho-so", "htkk-sao-luu")


def quet_xml_khach(thu_muc, nam, toi_da=20000, giay=60):
    """XML to khai BCTC nam `nam` trong thu muc khach -> duong tep tot nhat (so lan cao, moi nhat). Bo thu muc hoa don (xml / pdf),
    ket qua, sao luu; toi da `toi_da` tep / `giay` giay (VB6 cho tool 180 giay)."""
    import time
    t0 = time.time()
    tot, diem = "", None
    if not thu_muc or not os.path.isdir(thu_muc):
        return ""
    dem = 0
    for goc, ds_tm, ds_tep in os.walk(thu_muc):
        ds_tm[:] = [x for x in ds_tm if not x.startswith((".", "__")) and not x.lower().startswith(BO_THU_MUC)]
        for t in ds_tep:
            dem += 1
            if dem > toi_da or time.time() - t0 > giay:
                return tot
            if not t.lower().endswith(".xml"):
                continue
            p = os.path.join(goc, t)
            try:
                if os.path.getsize(p) > 5000000:
                    continue
                with open(p, "rb") as f:
                    dau = f.read(8000)
            except OSError:
                continue
            if b"HSoThueDTu" not in dau and b"H\x00S\x00o\x00T\x00h" not in dau:
                continue
            try:
                s = _giai_ma(dau)
                m1 = re.search(r"<maTKhai>\s*(\d+)\s*</maTKhai>", s)
                m2 = re.search(r"<kyKKhai>\s*(\d{4})\s*</kyKKhai>", s)
                if not m1 or m1.group(1) not in MA_TKHAI or not m2 or int(m2.group(1)) != int(nam):
                    continue
                m3 = re.search(r"<soLan>\s*(\d+)\s*</soLan>", s)
                k = (int(m3.group(1)) if m3 else 0, os.path.getmtime(p))
            except Exception:
                continue
            if diem is None or k > diem:
                tot, diem = p, k
    return tot


def tim_tu_dong(nam, che_do, mst, thu_muc, goc_htkk, ng, log=print):
    """Khong chon tep: XML trong thu muc khach, roi du lieu HTKK tren may."""
    p = quet_xml_khach(thu_muc, nam)
    if p:
        with open(p, "rb") as f:
            b = f.read()
        if doc_xml_bytes(b, os.path.basename(p), nam, ng) and (ng.tt == che_do or (che_do == "99" and ng.tt in ("200", "133"))):
            ng.mo_ta = "tờ khai XML năm %d trong thư mục khách (%s)" % (nam, os.path.basename(p))
            return True
        ng.sl = {}
    tm = thu_muc_mst(goc_htkk, mst) if goc_htkk else ""
    if not tm:
        if not goc_htkk:
            raise ValueError("Không tìm thấy HTKK trên máy và không có tệp XML BCTC năm %d trong thư mục khách - "
                             "anh chọn tệp Excel / XML / ZIP báo cáo tài chính năm %d." % (nam, nam))
        raise ValueError("HTKK trên máy chưa có dữ liệu của MST %s (thư mục DataFiles\\%s) - anh chọn tệp Excel / XML / ZIP "
                         "báo cáo tài chính năm %d." % (mst, re.sub(r"[^0-9-]", "", str(mst or "")), nam))
    for tt, mau in THU_TU_TIM.get(che_do, ()):
        sl, tep, klt = doc_bo_htkk(tm, tt, mau, nam)
        if sl:
            ng.sl, ng.tt, ng.mau = sl, tt, mau
            ng.ky = str(nam)
            ng.mo_ta = "dữ liệu HTKK trên máy (%s)" % ", ".join(tep)
            if klt:
                ng.cb.append("B01: tờ khai năm trước lập theo mẫu \"hoạt động KHÔNG liên tục\" - đã lấy cột Số cuối năm của mẫu đó.")
            log("[NAM TRUOC] HTKK %s %s: %s" % (tt, mau, ", ".join(tep)))
            return True
    raise ValueError("Không thấy báo cáo tài chính năm %d trong dữ liệu HTKK trên máy (thư mục DataFiles\\%s: tờ khai %s) - "
                     "anh chọn tệp Excel / XML / ZIP báo cáo tài chính năm %d."
                     % (nam, os.path.basename(tm), " / ".join(TEN_TT[t] for t in sorted({x[0] for x in THU_TU_TIM.get(che_do, ())},
                                                                                    reverse=True)), nam))


# ------------------------------------------------------------------ chuyen ma
def chuyen(ng, che_do):
    """-> ({khoa bao cao dich: {ma: so}}, [(khoa, ma nguon, ma dich, so)], [canh bao])"""
    out, doi, cb = {}, [], []
    nguon = ng.tt
    if che_do == "133" and nguon != "133":
        raise ValueError("Bộ sổ đang theo TT133/2016 nhưng số năm trước là báo cáo theo %s - không chuyển đổi tự động. "
                         "Anh chọn báo cáo tài chính năm trước theo TT133 (B01a / B01b / B01-DNNKLT)." % TEN_TT.get(nguon, nguon))
    hop_le = _ma_dich(che_do)
    for bc in BAO_CAO:
        src = ng.sl.get(bc)
        if not src:
            continue
        khoa = bc
        if che_do == "133" and bc == "B01":
            khoa = ng.mau or "B01A"
        d = {}
        bo = []
        if nguon == che_do or (nguon == "200" and bc in ("B03", "B03GT")):
            bang = None
        elif nguon == "200" and bc == "B02":
            bang = B02_200_99
        elif nguon == "200" and bc == "B01":
            bang = B01_200_99
        elif nguon == "133" and bc == "B02":
            bang = B02_133_99
        elif nguon == "133" and bc == "B03":
            bang = B03_133_99
        else:
            cb.append("%s theo %s không chuyển tự động sang %s (mẫu khác nhau nhiều) - bỏ qua, anh nhập cột năm trước trên HTKK nếu cần."
                      % (TEN_BC[bc], TEN_TT[nguon], TEN_TT[che_do]))
            continue
        ds_ma = hop_le.get(khoa)
        for ma, v in src.items():
            if bang is None:
                dich = ma
            elif bc == "B01":
                dich = bang.get(ma, "")
            else:
                dich = bang.get(ma, ma)
            if bc == "B01" and nguon == "200" and ma in B01_200_99_BO:
                if v and ma != "410":
                    bo.append(ma)
                continue
            if not dich or (ds_ma and dich not in ds_ma):
                if v:
                    bo.append(ma)
                continue
            d[dich] = d.get(dich, 0.0) + v
            doi.append((khoa, ma, dich, v))
        if bc == "B01" and nguon == "200" and che_do == "99":
            for ma_ct, nhom_cu, nhom_moi in B01_200_99_DOI_NHOM:
                v = src.get(ma_ct, 0.0)
                if v:
                    d[nhom_cu] = d.get(nhom_cu, 0.0) - v
                    d[nhom_moi] = d.get(nhom_moi, 0.0) + v
                    cb.append("B01: TT200 [%s] %s (%s) chuyển sang TT99 [%s] - dòng tổng [%s] / [%s] đã điều chỉnh tương ứng."
                              % (ma_ct, _dd(v), "phải thu về cho vay" if ma_ct == "135" else "phải thu về cho vay dài hạn",
                                 B01_200_99[ma_ct], nhom_cu, nhom_moi))
        if bo:
            cb.append("%s: các mã %s của %s có số nhưng không có chỉ tiêu tương ứng trên mẫu %s - không đưa vào: %s."
                      % (TEN_BC[bc], ", ".join(bo[:12]), TEN_TT[nguon], TEN_TT[che_do],
                         "; ".join("[%s] %s" % (m, _dd(src[m])) for m in bo[:6])))
        if d:
            out[khoa] = d
    if nguon != che_do:
        cb.insert(0, "Số năm trước lập theo %s, bộ sổ theo %s: đã chuyển mã theo bảng đối chiếu (sheet \"Doi chieu ma\" của tệp "
                     "xem trước). Chỉ tiêu mới của %s không có ở mẫu cũ để 0." % (TEN_TT[nguon], TEN_TT[che_do], TEN_TT[che_do]))
        if nguon == "133" and "B02" in out:
            cb.append("B02: TT133 [24] Chi phí quản lý kinh doanh (gồm cả chi phí bán hàng) đưa vào TT99 [26]; [25] Chi phí bán hàng để 0.")
        if nguon == "133" and "B03" in out:
            cb.append("B03: TT133 [23] / [24] gộp cho vay và đầu tư góp vốn - đưa vào TT99 [23] / [24]; [34] gộp nợ gốc vay và "
                      "thuê tài chính - đưa vào TT99 [34].")
    return out, doi, cb


def kiem_tra(out, che_do):
    cb = []

    def g(k, m):
        return out.get(k, {}).get(m, 0.0)
    if "B01" in out and che_do == "99" and abs(g("B01", "280") - g("B01", "440")) >= 1:
        cb.append("B01: TỔNG CỘNG TÀI SẢN [280] %s khác TỔNG CỘNG NGUỒN VỐN [440] %s." % (_dd(g("B01", "280")), _dd(g("B01", "440"))))
    if "B01A" in out and abs(g("B01A", "200") - g("B01A", "500")) >= 1:
        cb.append("B01a: TỔNG CỘNG TÀI SẢN [200] %s khác TỔNG CỘNG NGUỒN VỐN [500] %s." % (_dd(g("B01A", "200")), _dd(g("B01A", "500"))))
    if "B02" in out:
        lnst = g("B02", "50") - g("B02", "51") - g("B02", "52")
        if abs(lnst - g("B02", "60")) >= 1:
            cb.append("B02: [60] %s khác [50] - [51] - [52] = %s." % (_dd(g("B02", "60")), _dd(lnst)))
    for k in ("B03", "B03GT"):
        if k in out:
            t = g(k, "50") + g(k, "60") + g(k, "61")
            if abs(t - g(k, "70")) >= 1:
                cb.append("%s: [70] %s khác [50] + [60] + [61] = %s." % (TEN_BC[k], _dd(g(k, "70")), _dd(t)))
    for k, v in out.items():
        if not any(v.values()):
            cb.append("%s: tất cả chỉ tiêu bằng 0." % TEN_BC.get(k, k))
    return cb


# ------------------------------------------------------------------ ghi ket qua
def _chu_so(v):
    s = ("%.4f" % v).rstrip("0").rstrip(".")
    return "0" if s in ("-0", "") else s


def ghi_xem_truoc(p, nam, che_do, ng, out, doi, cb):
    from xlsx_viet import SoExcel
    wb = SoExcel(font="Times New Roman", co=11)
    kd = wb.kieu(dam=True, co=13, can="trai")
    kh = wb.kieu(dam=True, can="giua", khung=True, xuong=True, nen="F2F2F2")
    kt = wb.kieu(can="trai", khung=True, xuong=True)
    kc = wb.kieu(can="giua", khung=True)
    ks = wb.kieu(so='#,##0;(#,##0);"-"', khung=True)
    ws = wb.sheet("Tom tat", cot=[4, 120])
    ws.o(1, 1, "SỐ LIỆU NĂM TRƯỚC (NĂM %d) CHO BÁO CÁO TÀI CHÍNH NĂM %d" % (nam, nam + 1), kd)
    dong = ["Bộ sổ theo: %s" % TEN_TT.get(che_do, che_do),
            "Nguồn: %s - lập theo %s%s" % (ng.mo_ta, TEN_TT.get(ng.tt, ng.tt), (" (" + TEN_MAU.get(ng.mau, ng.mau) + ")") if ng.mau else ""),
            "Báo cáo có số: " + ", ".join("%s (%d chỉ tiêu)" % (TEN_BC.get(k[:3] if k.startswith("B01") else k, k), len(v))
                                         for k, v in out.items()),
            "Chỉ khi anh bấm ĐỒNG Ý ở phần mềm, số này mới ghi vào bộ sổ (bảng BCTC_NamTruoc; số cũ sao lưu sang BCTC_NamTruoc_Cu).",
            "Dùng cho: cột Năm trước của B02 / B03 (trực tiếp, gián tiếp) khi kỳ báo cáo bắt đầu từ tháng đầu năm tài chính; "
            "cột Số đầu năm của B01 khi sổ chưa có số dư đầu năm."]
    r = 3
    for x in dong:
        ws.o(r, 2, x, wb.kieu(can="trai", xuong=True))
        r += 1
    if cb:
        r += 1
        ws.o(r, 2, "CẦN XEM LẠI (%d)" % len(cb), wb.kieu(dam=True))
        r += 1
        for x in cb:
            ws.o(r, 1, "!", wb.kieu(dam=True, mau="C00000"))
            ws.o(r, 2, x, wb.kieu(can="trai", xuong=True))
            r += 1
    for k, v in out.items():
        bc = "B01" if k.startswith("B01") else k
        nhan = NHAN.get(che_do, {}).get(k, {})
        ws2 = wb.sheet(k, cot=[10, 70, 20, 12])
        ws2.o(1, 1, "%s - %s (cột năm trước, năm %d)" % (TEN_BC[bc], TEN_TT.get(che_do, che_do), nam), kd)
        ws2.dong(3, 1, ["Mã số", "Chỉ tiêu", "Số năm trước", "Mã nguồn"], kh)
        nguoc = {}
        for kk, mn, md, _ in doi:
            if kk == k:
                nguoc.setdefault(md, []).append(mn)
        rr = 4
        ma_all = sorted(set(v) | set(nhan), key=lambda m: (int(re.sub(r"\D", "", m) or 0), m))
        for m in ma_all:
            ws2.o(rr, 1, m, kc)
            ws2.o(rr, 2, nhan.get(m) or ng.ten.get(bc, {}).get(m, ""), kt)
            ws2.o(rr, 3, round(v.get(m, 0.0)), ks)
            ws2.o(rr, 4, ", ".join(nguoc.get(m, [])), kc)
            rr += 1
        ws2.dong_bang(4)
    if ng.tt != che_do and doi:
        ws3 = wb.sheet("Doi chieu ma", cot=[10, 14, 14, 20])
        ws3.o(1, 1, "ĐỐI CHIẾU MÃ %s -> %s" % (TEN_TT.get(ng.tt, ng.tt), TEN_TT.get(che_do, che_do)), kd)
        ws3.dong(3, 1, ["Báo cáo", "Mã nguồn", "Mã đích", "Số tiền"], kh)
        rr = 4
        for kk, mn, md, v in doi:
            ws3.dong(rr, 1, [kk, mn, md], kc)
            ws3.o(rr, 4, round(v), ks)
            rr += 1
    tam = p + ".tmp.xlsx"
    wb.luu(tam)
    try:
        os.replace(tam, p)
    except OSError:                              # tep xem truoc cu dang mo trong Excel -> ghi ten khac
        p = os.path.splitext(p)[0] + _dt.datetime.now().strftime("_%H%M%S") + ".xlsx"
        os.replace(tam, p)
    return p


def _tep_da_luu(thu_muc, nam):
    """GD162: tep BCTC nam `nam` da luu trong nguon-ky-truoc.json cua cong ty (con ton tai) hoac ''."""
    if not thu_muc:
        return ""
    try:
        import nguon_ky_truoc as NKT
        return NKT.tep_bctc(thu_muc, nam)
    except Exception:
        return ""


def chay(nam, che_do, mst="", thu_muc="", tep="", ra="", goc_htkk="", log=print):
    """-> (duong txt ket qua, loi)"""
    che_do = "99" if str(che_do).strip() == "99" else "133"
    nam = int(nam)
    ng = Nguon()
    try:
        if tep:
            if not os.path.isfile(tep):
                return None, "Không tìm thấy tệp: %s" % tep
            doc_tep(tep, nam, ng)
        else:
            da = _tep_da_luu(thu_muc, nam)          # GD162: tep BCTC nam truoc da luu dung TRUOC; khong dung duoc -> tu tim
            out = None
            if da:
                try:
                    doc_tep(da, nam, ng)
                    ng.mo_ta = "tệp BCTC năm %d đã lưu (Nguồn kỳ trước) - %s" % (nam, ng.mo_ta)
                    out, doi, cb = chuyen(ng, che_do)
                    if not out:
                        raise ValueError("không có số liệu báo cáo dùng được cho bộ sổ %s" % TEN_TT[che_do])
                    log("[NAM TRUOC] dung tep da luu: %s" % os.path.basename(da))
                except Exception as e:
                    log("[NAM TRUOC] tep da luu khong dung duoc: %s - tu tim" % e)
                    ng = Nguon()
                    ng.cb.append("Tệp BCTC đã lưu (%s) không dùng được: %s - đã tự tìm nguồn khác." % (os.path.basename(da), e))
                    out = None
            if out is None:
                tim_tu_dong(nam, che_do, mst, thu_muc, goc_htkk, ng, log)
                out, doi, cb = chuyen(ng, che_do)
        if tep:
            out, doi, cb = chuyen(ng, che_do)
    except ValueError as e:
        return None, str(e)
    if not out:
        return None, "Nguồn %s không có số liệu báo cáo nào dùng được cho bộ sổ %s." % (ng.mo_ta or tep, TEN_TT[che_do])
    cb = ng.cb + cb + kiem_tra(out, che_do)
    if ng.ky and ng.ky.isdigit() and int(ng.ky) != nam:
        cb.insert(0, "CHÚ Ý: nguồn là báo cáo kỳ năm %s, không phải năm %d - kiểm tra lại trước khi đồng ý." % (ng.ky, nam))
    if not ra:
        ra = os.path.join(thu_muc or BASE_DIR, "so-lieu-nam-truoc", "NAM_TRUOC_%d.txt" % nam)
    os.makedirs(os.path.dirname(os.path.abspath(ra)), exist_ok=True)
    xlsx = os.path.splitext(ra)[0] + ".xlsx"
    try:
        xlsx = ghi_xem_truoc(xlsx, nam, che_do, ng, out, doi, cb)
    except Exception as e:                       # xem truoc loi khong chan viec lay so
        log("[NAM TRUOC] khong ghi duoc xlsx xem truoc: %s" % e)
        try:
            os.remove(xlsx + ".tmp.xlsx")
        except OSError:
            pass
        xlsx = ""
    dong = ["NAM=%d" % nam, "TT_DICH=%s" % che_do, "TT_NGUON=%s" % ng.tt, "MAU=%s" % ng.mau,
            "NGUON=%s" % (ng.mo_ta + " - " + TEN_TT.get(ng.tt, ng.tt)).replace("|", "/"), "XLSX=%s" % xlsx]
    dong += ["CB=%s" % x.replace("\r", " ").replace("\n", " ").replace("|", "/") for x in cb]
    for k, v in out.items():
        for m in sorted(v, key=lambda m: (int(re.sub(r"\D", "", m) or 0), m)):
            dong.append("%s|%s|%s" % (k, m, _chu_so(v[m])))
    tam = ra + ".tmp"
    with io.open(tam, "w", encoding="utf-8-sig", newline="\r\n") as f:
        f.write("\n".join(dong) + "\n")
    os.replace(tam, ra)
    log("[NAM TRUOC] %d -> %s: %s, %s" % (nam, TEN_TT[che_do], ng.mo_ta, ", ".join("%s %d" % (k, len(v)) for k, v in out.items())))
    return ra, ""


# ------------------------------------------------------------------ ten chi tieu (khuon HTKK 5.7.7: 99_BCTC_305, 133_B01A_DNN_BCTC_232)
NHAN = {
    "99": {
        "B01": {
            "100": "A - TÀI SẢN NGẮN HẠN", "110": "I. Tiền và các khoản tương đương tiền", "111": "1. Tiền",
            "112": "2. Các khoản tương đương tiền", "120": "II. Đầu tư tài chính ngắn hạn",
            "121": "1. Chứng khoán kinh doanh", "122": "2. Dự phòng giảm giá chứng khoán kinh doanh (*)",
            "123": "3. Đầu tư nắm giữ đến ngày đáo hạn ngắn hạn",
            "124": "4. Dự phòng đầu tư nắm giữ đến ngày đáo hạn ngắn hạn (*)", "125": "5. Đầu tư ngắn hạn khác",
            "126": "6. Dự phòng tổn thất các khoản đầu tư ngắn hạn khác (*)", "130": "III. Các khoản phải thu ngắn hạn",
            "131": "1. Phải thu ngắn hạn của khách hàng", "132": "2. Trả trước cho người bán ngắn hạn",
            "133": "3. Phải thu nội bộ ngắn hạn", "134": "4. Phải thu theo tiến độ hợp đồng xây dựng",
            "135": "5. Phải thu ngắn hạn khác", "136": "6. Dự phòng phải thu ngắn hạn khó đòi (*)",
            "137": "7. Tài sản thiếu chờ xử lý", "140": "IV. Hàng tồn kho", "141": "1. Hàng tồn kho",
            "142": "2. Dự phòng giảm giá hàng tồn kho (*)", "150": "V. Tài sản sinh học ngắn hạn",
            "151": "1. Súc vật nuôi lấy sản phẩm một lần ngắn hạn",
            "152": "2. Cây trồng theo mùa vụ hoặc lấy sản phẩm một lần ngắn hạn",
            "153": "3. Dự phòng tổn thất tài sản sinh học ngắn hạn (*)", "160": "VI. Tài sản ngắn hạn khác",
            "161": "1. Chi phí chờ phân bổ ngắn hạn", "162": "2. Thuế GTGT được khấu trừ",
            "163": "3. Thuế và các khoản khác phải thu Nhà nước", "164": "4. Giao dịch mua bán lại trái phiếu Chính phủ",
            "165": "5. Tài sản ngắn hạn khác", "200": "B - TÀI SẢN DÀI HẠN", "210": "I. Các khoản phải thu dài hạn",
            "211": "1. Phải thu dài hạn của khách hàng", "212": "2. Trả trước cho người bán dài hạn",
            "213": "3. Vốn kinh doanh ở đơn vị trực thuộc", "214": "4. Phải thu nội bộ dài hạn",
            "215": "5. Phải thu dài hạn khác", "216": "6. Dự phòng phải thu dài hạn khó đòi (*)",
            "220": "II. Tài sản cố định", "221": "1. Tài sản cố định hữu hình", "222": "- Nguyên giá",
            "223": "- Giá trị hao mòn lũy kế (*)", "224": "2. Tài sản cố định thuê tài chính", "225": "- Nguyên giá",
            "226": "- Giá trị hao mòn lũy kế (*)", "227": "3. Tài sản cố định vô hình", "228": "- Nguyên giá",
            "229": "- Giá trị hao mòn lũy kế (*)", "230": "III. Tài sản sinh học dài hạn",
            "231": "1. Súc vật nuôi cho sản phẩm định kỳ",
            "232": "a) Súc vật nuôi cho sản phẩm định kỳ chưa đến giai đoạn trưởng thành",
            "233": "b) Súc vật nuôi cho sản phẩm định kỳ đến giai đoạn trưởng thành", "234": "- Nguyên giá",
            "235": "- Giá trị khấu hao lũy kế (*)", "236": "2. Súc vật nuôi lấy sản phẩm một lần dài hạn",
            "237": "3. Cây trồng theo mùa vụ hoặc lấy sản phẩm một lần dài hạn",
            "238": "4. Dự phòng tổn thất tài sản sinh học dài hạn (*)", "240": "IV. Bất động sản đầu tư",
            "241": "- Nguyên giá", "242": "- Giá trị hao mòn lũy kế (*)", "250": "V. Tài sản dở dang dài hạn",
            "251": "1. Chi phí sản xuất, kinh doanh dở dang dài hạn", "252": "2. Chi phí xây dựng cơ bản dở dang",
            "260": "VI. Đầu tư tài chính dài hạn", "261": "1. Đầu tư vào công ty con",
            "262": "2. Đầu tư vào công ty liên doanh, liên kết", "263": "3. Đầu tư góp vốn vào đơn vị khác",
            "264": "4. Dự phòng tổn thất đầu tư vào đơn vị khác dài hạn (*)",
            "265": "5. Đầu tư nắm giữ đến ngày đáo hạn dài hạn",
            "266": "6. Dự phòng đầu tư nắm giữ đến ngày đáo hạn dài hạn (*)", "270": "VII. Tài sản dài hạn khác",
            "271": "1. Chi phí chờ phân bổ dài hạn", "272": "2. Tài sản thuế thu nhập hoãn lại",
            "273": "3. Thiết bị, vật tư, phụ tùng thay thế dài hạn", "274": "4. Tài sản dài hạn khác",
            "280": "TỔNG CỘNG TÀI SẢN (280 = 100 + 200)", "300": "C - NỢ PHẢI TRẢ", "310": "I. Nợ ngắn hạn",
            "311": "1. Phải trả người bán ngắn hạn", "312": "2. Người mua trả tiền trước ngắn hạn",
            "313": "3. Phải trả cổ tức, lợi nhuận", "314": "4. Thuế và các khoản phải nộp Nhà nước ngắn hạn",
            "315": "5. Phải trả người lao động", "316": "6. Chi phí phải trả ngắn hạn", "317": "7. Phải trả nội bộ ngắn hạn",
            "318": "8. Phải trả theo tiến độ hợp đồng xây dựng ngắn hạn", "319": "9. Doanh thu chờ phân bổ ngắn hạn",
            "320": "10. Phải trả ngắn hạn khác", "321": "11. Vay và nợ thuê tài chính ngắn hạn",
            "322": "12. Dự phòng phải trả ngắn hạn", "323": "13. Quỹ khen thưởng, phúc lợi", "324": "14. Quỹ bình ổn giá",
            "325": "15. Giao dịch mua bán lại trái phiếu Chính phủ", "330": "II. Nợ dài hạn",
            "331": "1. Phải trả người bán dài hạn", "332": "2. Người mua trả tiền trước dài hạn",
            "333": "3. Thuế và các khoản phải nộp Nhà nước dài hạn", "334": "4. Chi phí phải trả dài hạn",
            "335": "5. Phải trả nội bộ về vốn kinh doanh", "336": "6. Phải trả nội bộ dài hạn",
            "337": "7. Doanh thu chờ phân bổ dài hạn", "338": "8. Phải trả dài hạn khác",
            "339": "9. Vay và nợ thuê tài chính dài hạn", "340": "10. Trái phiếu chuyển đổi", "341": "11. Cổ phiếu ưu đãi",
            "342": "12. Thuế thu nhập hoãn lại phải trả", "343": "13. Dự phòng phải trả dài hạn",
            "344": "14. Quỹ phát triển khoa học và công nghệ", "400": "D - VỐN CHỦ SỞ HỮU",
            "411": "1. Vốn góp của chủ sở hữu", "411a": "- Cổ phiếu phổ thông có quyền biểu quyết",
            "411b": "- Cổ phiếu ưu đãi", "412": "2. Thặng dư vốn", "413": "3. Quyền chọn chuyển đổi trái phiếu",
            "414": "4. Vốn khác của chủ sở hữu", "415": "5. Cổ phiếu mua lại của chính mình (*)",
            "416": "6. Chênh lệch đánh giá lại tài sản", "417": "7. Chênh lệch tỷ giá hối đoái",
            "418": "8. Quỹ đầu tư phát triển", "419": "9. Quỹ khác thuộc vốn chủ sở hữu",
            "420": "10. Lợi nhuận sau thuế chưa phân phối", "420a": "- LNST chưa phân phối lũy kế đến cuối kỳ trước",
            "420b": "- LNST chưa phân phối kỳ này", "440": "TỔNG CỘNG NGUỒN VỐN (440 = 300 + 400)",
        },
        "B02": {
            "01": "1. Doanh thu bán hàng và cung cấp dịch vụ", "02": "2. Các khoản giảm trừ doanh thu",
            "10": "3. Doanh thu thuần về bán hàng và cung cấp dịch vụ (10 = 01 - 02)", "11": "4. Giá vốn hàng bán",
            "20": "5. Lợi nhuận gộp về bán hàng và cung cấp dịch vụ (20 = 10-11)",
            "21": "6. Lãi/lỗ của hoạt động bán, thanh lý bất động sản đầu tư", "22": "7. Doanh thu hoạt động tài chính",
            "23": "8. Chi phí tài chính", "24": "- Trong đó: Chi phí đi vay", "25": "9. Chi phí bán hàng",
            "26": "10. Chi phí quản lý doanh nghiệp",
            "30": "11. Lợi nhuận thuần từ hoạt động kinh doanh {30 = 20 +21 + 22 - (23 + 25 + 26)}",
            "31": "12. Thu nhập khác", "32": "13. Chi phí khác", "40": "14. Lợi nhuận khác (40 = 31 - 32)",
            "50": "15. Tổng lợi nhuận kế toán trước thuế (50 = 30 + 40)", "51": "16. Chi phí thuế TNDN hiện hành",
            "52": "17. Chi phí thuế TNDN hoãn lại", "60": "18. Lợi nhuận sau thuế thu nhập doanh nghiệp (60 = 50 - 51 - 52)",
            "70": "19. Lãi cơ bản trên cổ phiếu (*)", "71": "20. Lãi suy giảm trên cổ phiếu (*)",
        },
        "B03": {
            "01": "1. Tiền thu từ bán hàng, cung cấp dịch vụ và doanh thu khác",
            "02": "2. Tiền chi trả cho người cung cấp hàng hóa và dịch vụ", "03": "3. Tiền chi trả cho người lao động",
            "04": "4. Chi phí đi vay đã trả", "05": "5. Thuế thu nhập doanh nghiệp đã nộp",
            "06": "6. Tiền thu khác từ hoạt động kinh doanh", "07": "7. Tiền chi khác cho hoạt động kinh doanh",
            "20": "Lưu chuyển tiền thuần từ hoạt động kinh doanh",
            "21": "1. Tiền chi để mua sắm, xây dựng TSCĐ và các tài sản dài hạn khác",
            "22": "2. Tiền thu từ thanh lý, nhượng bán TSCĐ và các tài sản dài hạn khác",
            "23": "3. Tiền chi cho vay, mua các công cụ nợ của đơn vị khác",
            "24": "4. Tiền thu hồi cho vay, bán lại các công cụ nợ của đơn vị khác",
            "25": "5. Tiền chi đầu tư góp vốn vào đơn vị khác", "26": "6. Tiền thu hồi đầu tư góp vốn vào đơn vị khác",
            "27": "7. Tiền thu lãi cho vay, cổ tức và lợi nhuận được chia",
            "30": "Lưu chuyển tiền thuần từ hoạt động đầu tư",
            "31": "1. Tiền thu từ phát hành cổ phiếu, nhận vốn góp của chủ sở hữu",
            "32": "2. Tiền trả lại vốn góp cho các chủ sở hữu, mua lại cổ phiếu đã phát hành", "33": "3. Tiền thu từ đi vay",
            "34": "4. Tiền trả nợ gốc vay", "35": "5. Tiền trả nợ gốc thuê tài chính",
            "36": "6. Cổ tức, lợi nhuận đã trả cho chủ sở hữu", "40": "Lưu chuyển tiền thuần từ hoạt động tài chính",
            "50": "Lưu chuyển tiền thuần trong kỳ (50 = 20+30+40)", "60": "Tiền và tương đương tiền đầu kỳ",
            "61": "Ảnh hưởng của thay đổi tỷ giá hối đoái quy đổi ngoại tệ",
            "70": "Tiền và tương đương tiền cuối kỳ (70 = 50+60+61)",
        },
        "B03GT": {
            "01": "1. Lợi nhuận trước thuế", "02": "- Khấu hao TSCĐ và BĐSĐT", "03": "- Các khoản dự phòng",
            "04": "- Lãi, lỗ chênh lệch tỷ giá hối đoái do đánh giá lại các khoản mục tiền tệ có gốc ngoại tệ",
            "05": "- Lãi, lỗ từ hoạt động đầu tư, tài chính", "06": "- Chi phí đi vay", "07": "- Các khoản điều chỉnh khác",
            "08": "3. Lợi nhuận từ hoạt động kinh doanh trước thay đổi vốn lưu động",
            "09": "- Tăng, giảm các khoản phải thu", "10": "- Tăng, giảm hàng tồn kho",
            "11": "- Tăng, giảm các khoản phải trả (Không kể lãi vay phải trả, thuế thu nhập doanh nghiệp phải nộp)",
            "12": "- Tăng, giảm chi phí chờ phân bổ", "13": "- Tăng, giảm chứng khoán kinh doanh",
            "14": "- Chi phí đi vay đã trả", "15": "- Thuế thu nhập doanh nghiệp đã nộp",
            "16": "- Tiền thu khác từ hoạt động kinh doanh", "17": "- Tiền chi khác cho hoạt động kinh doanh",
            "20": "Lưu chuyển tiền thuần từ hoạt động kinh doanh",
            "21": "1. Tiền chi để mua sắm, xây dựng TSCĐ và các tài sản dài hạn khác",
            "22": "2. Tiền thu từ thanh lý, nhượng bán TSCĐ và các tài sản dài hạn khác",
            "23": "3. Tiền chi cho vay, mua các công cụ nợ của đơn vị khác",
            "24": "4. Tiền thu hồi cho vay, bán lại các công cụ nợ của đơn vị khác",
            "25": "5. Tiền chi đầu tư góp vốn vào đơn vị khác", "26": "6. Tiền thu hồi đầu tư góp vốn vào đơn vị khác",
            "27": "7. Tiền thu lãi cho vay, cổ tức và lợi nhuận được chia",
            "30": "Lưu chuyển tiền thuần từ hoạt động đầu tư",
            "31": "1. Tiền thu từ phát hành cổ phiếu, nhận vốn góp của chủ sở hữu",
            "32": "2. Tiền trả lại vốn góp cho các chủ sở hữu, mua lại cổ phiếu đã phát hành", "33": "3. Tiền thu từ đi vay",
            "34": "4. Tiền trả nợ gốc vay", "35": "5. Tiền trả nợ gốc thuê tài chính",
            "36": "6. Cổ tức, lợi nhuận đã trả cho chủ sở hữu", "40": "Lưu chuyển tiền thuần từ hoạt động tài chính",
            "50": "Lưu chuyển tiền thuần trong kỳ (50 = 20+30+40)", "60": "Tiền và tương đương tiền đầu kỳ",
            "61": "Ảnh hưởng của thay đổi tỷ giá hối đoái quy đổi ngoại tệ",
            "70": "Tiền và tương đương tiền cuối kỳ (70 = 50+60+61)",
        },
    },
    "133": {
        "B01A": {
            "110": "I. Tiền và các khoản tương đương tiền", "120": "II. Đầu tư tài chính",
            "121": "1. Chứng khoán kinh doanh", "122": "2. Đầu tư nắm giữ đến ngày đáo hạn",
            "123": "3. Đầu tư góp vốn vào đơn vị khác", "124": "4. Dự phòng tổn thất đầu tư tài chính (*)",
            "130": "III. Các khoản phải thu", "131": "1. Phải thu của khách hàng", "132": "2. Trả trước cho người bán",
            "133": "3. Vốn kinh doanh ở đơn vị trực thuộc", "134": "4. Phải thu khác", "135": "5. Tài sản thiếu chờ xử lý",
            "136": "6. Dự phòng phải thu khó đòi (*)", "140": "IV. Hàng tồn kho", "141": "1. Hàng tồn kho",
            "142": "2. Dự phòng giảm giả hàng tồn kho (*)", "150": "V. Tài sản cố định", "151": "- Nguyên giá",
            "152": "- Giá trị hao mòn lũy kế (*)", "160": "VI. Bất động sản đầu tư", "161": "- Nguyên giá",
            "162": "- Giá trị hao mòn lũy kế (*)", "170": "VII. XDCB dở dang", "180": "VIII. Tài sản khác",
            "181": "1. Thuế GTGT được khấu trừ", "182": "2. Tài sản khác",
            "200": "TỔNG CỘNG TÀI SẢN (200=110+120+130+140+150+160+170+180)", "300": "I. Nợ phải trả",
            "311": "1. Phải trả người bán", "312": "2. Người mua trả tiền trước",
            "313": "3. Thuế và các khoản phải nộp Nhà nước", "314": "4. Phải trả người lao động", "315": "5. Phải trả khác",
            "316": "6. Vay và nợ thuê tài chính", "317": "7. Phải trả nội bộ về vốn kinh doanh",
            "318": "8. Dự phòng phải trả", "319": "9. Quỹ khen thưởng, phúc lợi",
            "320": "10. Quỹ phát triển khoa học và công nghệ", "400": "II. Vốn chủ sở hữu",
            "411": "1. Vốn góp của chủ sở hữu", "412": "2. Thặng dư vốn cổ phần", "413": "3. Vốn khác của chủ sở hữu",
            "414": "4. Cổ phiếu quỹ (*)", "415": "5. Chênh lệch tỷ giá hối đoái", "416": "6. Các quỹ thuộc vốn chủ sở hữu",
            "417": "7. Lợi nhuận sau thuế chưa phân phối", "500": "TỔNG CỘNG NGUỒN VỐN (500=300+400)",
        },
        "B02": {
            "01": "1. Doanh thu bán hàng và cung cấp dịch vụ", "02": "2. Các khoản giảm trừ doanh thu",
            "10": "3. Doanh thu thuần về bán hàng và cung cấp dịch vụ (10 = 01 - 02)", "11": "4. Giá vốn hàng bán",
            "20": "5. Lợi nhuận gộp về bán hàng và cung cấp dịch vụ (20 = 10 - 11)",
            "21": "6. Doanh thu hoạt động tài chính", "22": "7. Chi phí tài chính", "23": "- Trong đó: Chi phí lãi vay",
            "24": "8. Chi phí quản lý kinh doanh",
            "30": "9. Lợi nhuận thuần từ hoạt động kinh doanh (30 = 20 + 21 - 22 - 24)", "31": "10. Thu nhập khác",
            "32": "11. Chi phí khác", "40": "12. Lợi nhuận khác (40 = 31 - 32)",
            "50": "13. Tổng lợi nhuận kế toán trước thuế (50 = 30 + 40)", "51": "14. Chi phí thuế TNDN",
            "60": "15. Lợi nhuận sau thuế thu nhập doanh nghiệp (60 = 50 - 51)",
        },
        "B03": {
            "01": "1. Tiền thu từ bán hàng, cung cấp dịch vụ và doanh thu khác",
            "02": "2. Tiền chi trả cho người cung cấp hàng hóa, dịch vụ", "03": "3. Tiền chi trả cho người lao động",
            "04": "4. Tiền lãi vay đã trả", "05": "5. Thuế thu nhập doanh nghiệp đã nộp",
            "06": "6. Tiền thu khác từ hoạt động kinh doanh", "07": "7. Tiền chi khác cho hoạt động kinh doanh",
            "20": "Lưu chuyển tiền thuần từ hoạt động kinh doanh",
            "21": "1. Tiền chi để mua sắm, xây dựng TSCĐ, BĐSĐT và các tài sản dài hạn khác",
            "22": "2. Tiền thu từ thanh lý, nhượng bán TSCĐ, BĐSĐT và các tài sản dài hạn khác",
            "23": "3. Tiền chi cho vay, đầu tư góp vốn vào đơn vị khác",
            "24": "4. Tiền thu hồi cho vay, đầu tư góp vốn vào đơn vị khác",
            "25": "5. Tiền thu lãi cho vay, cổ tức và lợi nhuận được chia",
            "30": "Lưu chuyển tiền thuần từ hoạt động đầu tư",
            "31": "1. Tiền thu từ phát hành cổ phiếu, nhận vốn góp của chủ sở hữu",
            "32": "2. Tiền trả lại vốn góp cho các chủ sở hữu, mua lại cổ phiếu của doanh nghiệp đã phát hành",
            "33": "3. Tiền thu từ đi vay", "34": "4. Tiền trả nợ gốc vay và nợ thuê tài chính",
            "35": "5. Cổ tức, lợi nhuận đã trả cho chủ sở hữu", "40": "Lưu chuyển tiền thuần từ hoạt động tài chính",
            "50": "Lưu chuyển tiền thuần trong kỳ (50 = 20+30+40)", "60": "Tiền và tương đương tiền đầu kỳ",
            "61": "Ảnh hưởng của thay đổi tỷ giá hối đoái quy đổi ngoại tệ",
            "70": "Tiền và tương đương tiền cuối kỳ (70 = 50 + 60 + 61)",
        },
        "B03GT": {
            "01": "1. Lợi nhuận trước thuế", "02": "2. Điều chỉnh cho các khoản", "03": "- Khấu hao TSCĐ và BĐSĐT",
            "04": "- Các khoản dự phòng",
            "05": "- Lãi, lỗ chênh lệch tỷ giá hối đoái do đánh giá lại các khoản mục tiền tệ có gốc ngoại tệ",
            "06": "- Lãi, lỗ từ hoạt động đầu tư", "07": "- Chi phí lãi vay", "08": "- Các khoản điều chỉnh khác",
            "09": "3. Lợi nhuận từ hoạt động kinh doanh trước thay đổi vốn lưu động",
            "10": "- Tăng, giảm các khoản phải thu", "11": "- Tăng, giảm hàng tồn kho",
            "12": "- Tăng, giảm các khoản phải trả (Không kể lãi vay phải trả, thuế thu nhập doanh nghiệp phải nộp)",
            "13": "- Tăng, giảm chi phí trả trước", "14": "- Tăng, giảm chứng khoán kinh doanh",
            "15": "- Tiền lãi vay đã trả", "16": "- Thuế thu nhập doanh nghiệp đã nộp",
            "17": "- Tiền thu khác từ hoạt động kinh doanh", "18": "- Tiền chi khác cho hoạt động kinh doanh",
            "20": "Lưu chuyển tiền thuần từ hoạt động kinh doanh",
            "21": "1. Tiền chi để mua sắm, xây dựng TSCĐ, BĐSĐT và các tài sản dài hạn khác",
            "22": "2. Tiền thu từ thanh lý, nhượng bán TSCĐ, BĐSĐT và các tài sản dài hạn khác",
            "23": "3. Tiền chi cho vay, đầu tư góp vốn vào đơn vị khác",
            "24": "4. Tiền thu hồi cho vay, đầu tư góp vốn vào đơn vị khác",
            "25": "5.Tiền thu lãi cho vay, cổ tức và lợi nhuận được chia", "30": "Lưu chuyển tiền thuần từ hoạt động đầu tư",
            "31": "1. Tiền thu từ phát hành cổ phiếu, nhận vốn góp của chủ sở hữu",
            "32": "2. Tiền trả lại vốn góp cho các chủ sở hữu, mua lại cổ phiếu của doanh nghiệp đã phát hành",
            "33": "3. Tiền thu từ đi vay", "34": "4. Tiền trả nợ gốc vay và nợ gốc thuê tài chính",
            "35": "5. Cổ tức, lợi nhuận đã trả cho chủ sở hữu", "40": "Lưu chuyển tiền thuần từ hoạt động tài chính",
            "50": "Lưu chuyển tiền thuần trong kỳ (50 = 20+30+40)", "60": "Tiền và tương đương tiền đầu kỳ",
            "61": "Ảnh hưởng của thay đổi tỷ giá hối đoái quy đổi ngoại tệ",
            "70": "Tiền và tương đương tiền cuối kỳ (70 = 50+60+61)",
        },
    },
}
