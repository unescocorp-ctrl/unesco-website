# -*- coding: utf-8 -*-
"""GD347 - KHUON TRAO DOI ERP_ANHMAI <-> UNESCO AI (phien ban 1, them truong tuy chon v1.1). Thuan Python, khong doc so.

Nguon khuon: ERP_R7\\BUILD\\docs\\DAC_TA_BOOKOPS.md (muc "Khuon trao doi phien ban 1"), BOOKOPS_CHUNG_TU_SAI.md (chung_tu_sai /
sua / da_sua) va LIEN_THONG_ERP_UNESCO_AI.md (quy_tac[], ho_so, de_xuat - v1.1). ERP bo qua truong chua biet, nen tram co the
gui dan tung truong; nhung truong ERP DA kiem (phien_ban_khuon, lenh, tram, trang_thai, buoc[], hien_trang, chung_tu_sai) sai la
ERP tu choi ca tep -> kiem o day truoc khi ghi.

Ham chinh:
  kiem_lenh(d)      -> [loi]  tep lenh ERP ghi vao LENH\\cho
  kiem_ket_qua(d)   -> [loi]  tep ket qua tram ghi vao LENH\\ket_qua (cung dieu kien voi usp_BridgeIngestResult / ...VoucherIssues)
  hien_trang_tu(dh, dc, bt)   bang dieu hanh (bang_dieu_hanh.tinh) + doi chieu (doi_chieu_100) + bat thuong -> hien_trang
  quy_tac_tu(cl, bt, loi)     DC1-DC16 + KS8-KS12 -> quy_tac[] (DAT / LECH / THIEU_DL / KHONG_AP_DUNG / LOI)
  chung_tu_sai_tu(bt_dong, ct, tk)   dong bat thuong co MaCT -> chung_tu_sai[] (ma on dinh, muc NANG/VUA/NHE)
  viec_can_nguoi_tu(cl, bt, buoc_bo_qua)
"""
import datetime as _dt
import hashlib
import re

PHIEN_BAN_KHUON = 1
BUOC_V1 = ("tai_hd", "phan_tich", "kiem_tra", "doi_chieu", "ghi_trong_nguong", "ket_chuyen", "bao_cao", "sua_chung_tu")
TRANG_THAI_LENH = ("XONG", "XONG_CO_VIEC", "DUNG", "LOI", "HET_HAN")
TRANG_THAI_BUOC = ("XONG", "BO_QUA", "CAN_NGUOI", "LOI")
MUC_ISSUE = ("NANG", "VUA", "NHE")
KET_QUA_QUY_TAC = ("DAT", "LECH", "THIEU_DL", "KHONG_AP_DUNG", "LOI")
TRANG_THAI_DA_SUA = ("DA_SUA", "KHONG_SUA")
BO_QUY_TAC_MAC_DINH = "MAC_DINH"          # chua co bo quy tac nao duoc ke toan truong duyet trong ERP (RuleVersion)

_RE_LENH = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,39}$")
_RE_KY = re.compile(r"^\d{4}-(0[1-9]|1[0-2])$")

# ma doi chieu (doi_chieu_100.py) -> ten, va ma nao la "thieu nguon" (khong phai lech)
TEN_DC = {
    "DC1": "Hoá đơn CQT chưa có chứng từ", "DC2": "Liên kết hoá đơn -> chứng từ bị mất", "DC3": "Hoá đơn huỷ / bị thay thế đã hạch toán",
    "DC4": "Số dư 112 cuối tháng khác sao kê", "DC5": "Thiếu sao kê tháng có phát sinh 112", "DC6": "Doanh thu 511 khác hoá đơn bán ra",
    "DC7": "Thuế 3331 khác thuế hoá đơn bán ra", "DC8": "Thuế 133 khác thuế hoá đơn mua vào", "DC9": "Phát sinh 334 khác bảng lương",
    "DC10": "Tồn kho âm", "DC11": "Trùng mã đối tác", "DC12": "Tháng không có chứng từ / thiếu bảng lương",
    "DC13": "Chưa tải hoá đơn CQT tháng có phát sinh", "DC14": "Chứng từ ghi ngày sau hôm nay",
    "DC15": "Tờ khai 01/GTGT đã xuất HTKK khác sổ", "DC16": "Kỳ đã kết thúc chưa có tờ khai xuất HTKK",
}
DC_THIEU_DL = ("DC5", "DC12", "DC13")
TEN_KS = {"KS8": "Chi phí tăng đột biến", "KS9": "Giá mua / giá bán bất thường", "KS10": "Số chứng từ / hoá đơn trùng, nhảy",
          "KS11": "Ghi lùi vào tháng đã khoá", "KS12": "Lương / khấu hao bất thường"}
MUC_BT = {"Cao": "NANG", "Vừa": "VUA", "Thấp": "NHE", "Vua": "VUA", "Thap": "NHE"}


# ------------------------------------------------------------------ tien ich
def gio_iso(t=None):
    """Gio dia phuong kem mui gio, vd 2026-12-03T22:14:05+07:00 (ERP doc DateTimeOffset)."""
    t = t or _dt.datetime.now()
    if t.tzinfo is None:
        t = t.astimezone()
    return t.replace(microsecond=0).isoformat()


def doc_gio(s):
    """ISO 8601 (co hoac khong mui gio) -> datetime co mui gio; sai -> None."""
    if not s:
        return None
    try:
        t = _dt.datetime.fromisoformat(str(s).strip().replace("Z", "+00:00"))
    except ValueError:
        return None
    return t if t.tzinfo else t.astimezone()


def ngay_iso(s):
    """'30/09/2026' | date | datetime | '2026-09-30' -> '2026-09-30'; khong biet -> None (khong bao gio tra 0 / chuoi rong)."""
    if not s:
        return None
    if isinstance(s, (_dt.date, _dt.datetime)):
        return s.strftime("%Y-%m-%d")
    s = str(s).strip()
    m = re.match(r"^(\d{1,2})/(\d{1,2})/(\d{4})$", s)
    if m:
        try:
            return _dt.date(int(m.group(3)), int(m.group(2)), int(m.group(1))).strftime("%Y-%m-%d")
        except ValueError:
            return None
    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})", s)
    return m.group(0) if m else None


def thang_iso(s):
    d = ngay_iso(s)
    return d[:7] if d else None


def sha256_tep(duong, khoi=1 << 20):
    h = hashlib.sha256()
    with open(duong, "rb") as f:
        while True:
            b = f.read(khoi)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def _chu(x, n):
    s = str(x if x is not None else "").replace("\r", " ").replace("\n", " ").strip()
    return s[:n]


def ma_sach(s, n=100):
    """Ma on dinh: bo ky tu dieu khien / khoang trang thua; giu chu Viet."""
    s = re.sub(r"\s+", " ", str(s or "")).strip()
    return s[:n]


# ------------------------------------------------------------------ kiem tep lenh
def kiem_lenh(d):
    loi = []
    if not isinstance(d, dict):
        return ["tệp lệnh không phải JSON object"]
    if d.get("phien_ban_khuon") != PHIEN_BAN_KHUON:
        loi.append("phien_ban_khuon phải là %d" % PHIEN_BAN_KHUON)
    if not isinstance(d.get("lenh"), str) or not _RE_LENH.match(d.get("lenh") or ""):
        loi.append("lenh thiếu hoặc sai dạng")
    if not isinstance(d.get("so"), str) or not d.get("so", "").strip():
        loi.append("so (tên tệp sổ) thiếu")
    if not isinstance(d.get("ky"), str) or not _RE_KY.match(d.get("ky") or ""):
        loi.append("ky phải dạng YYYY-MM")
    b = d.get("buoc")
    if not isinstance(b, list) or not b or any(x not in BUOC_V1 for x in b):
        loi.append("buoc thiếu hoặc có bước ngoài khuôn")
    elif len(set(b)) != len(b):
        loi.append("buoc lặp")
    if d.get("het_han") is not None and doc_gio(d.get("het_han")) is None:
        loi.append("het_han không đọc được")
    if "sua" in d:
        s = d.get("sua")
        if not isinstance(s, list) or any(not isinstance(x, dict) or not x.get("ma") for x in s):
            loi.append("sua phải là danh sách có ma")
        elif "sua_chung_tu" not in (b or []):
            loi.append("có sua nhưng không có bước sua_chung_tu")
    if "bo_qua" in d:
        q = d.get("bo_qua")
        if not isinstance(q, list) or any(not isinstance(x, dict) or not x.get("ma") for x in q):
            loi.append("bo_qua phải là danh sách có ma")
    return loi


def khoa_bo_qua(lenh):
    """bo_qua[] cua tep lenh (ERP V0089: dong ke toan danh dau 'khong phai loi') -> (tap ma chung_tu_sai, tap khoa_tram)."""
    ma, khoa = set(), set()
    for x in (lenh or {}).get("bo_qua") or []:
        if isinstance(x, dict):
            if x.get("ma"):
                ma.add(str(x["ma"]))
            if x.get("khoa_tram"):
                khoa.add(str(x["khoa_tram"]))
    return ma, khoa


# ------------------------------------------------------------------ kiem tep ket qua (truoc khi ghi)
def kiem_ket_qua(d):
    loi = []
    if not isinstance(d, dict):
        return ["kết quả không phải JSON object"]
    if d.get("phien_ban_khuon") != PHIEN_BAN_KHUON:
        loi.append("phien_ban_khuon")
    for k in ("lenh", "tram"):
        if not isinstance(d.get(k), str) or not d.get(k):
            loi.append("thiếu " + k)
    if d.get("trang_thai") not in TRANG_THAI_LENH:
        loi.append("trang_thai lạ: %r" % (d.get("trang_thai"),))
    for k in ("bat_dau", "ket_thuc"):
        if d.get(k) is not None and doc_gio(d.get(k)) is None:
            loi.append(k + " không đọc được")
    b = d.get("buoc")
    if not isinstance(b, list):
        loi.append("buoc phải là danh sách")
    else:
        for i, x in enumerate(b):
            if not isinstance(x, dict) or x.get("ten") not in BUOC_V1:
                loi.append("buoc[%d].ten lạ" % i)
            elif x.get("trang_thai") not in TRANG_THAI_BUOC:
                loi.append("buoc[%d].trang_thai lạ" % i)
            elif x.get("trang_thai") in ("BO_QUA", "LOI", "CAN_NGUOI") and not (x.get("ly_do") or x.get("loi")):
                loi.append("buoc[%d] %s phải có ly_do" % (i, x["trang_thai"]))
            elif x.get("chi_so") is not None and not isinstance(x.get("chi_so"), dict):
                loi.append("buoc[%d].chi_so phải là object" % i)
    ht = d.get("hien_trang")
    if ht is not None:
        if not isinstance(ht, dict):
            loi.append("hien_trang phải là object")
        else:
            for k in ("chung_tu_den", "hd_den"):
                if ht.get(k) is not None and ngay_iso(ht.get(k)) != ht.get(k):
                    loi.append("hien_trang.%s phải YYYY-MM-DD" % k)
            if ht.get("so_phu_den") is not None and not re.match(r"^\d{4}-\d{2}$", str(ht["so_phu_den"])):
                loi.append("hien_trang.so_phu_den phải YYYY-MM")
            for k in ("thang_khoa", "diem_san_sang", "loi_nang"):
                v = ht.get(k)
                if v is not None and (not isinstance(v, int) or isinstance(v, bool) or v < 0 or v > (12 if k == "thang_khoa" else 100 if k == "diem_san_sang" else 10 ** 9)):
                    loi.append("hien_trang.%s ngoài khoảng" % k)
    vc = d.get("viec_can_nguoi")
    if vc is not None and (not isinstance(vc, list) or any(not isinstance(x, dict) or not x.get("loai") or not x.get("mo_ta") for x in vc)):
        loi.append("viec_can_nguoi: mỗi dòng cần loai, mo_ta")
    cts = d.get("chung_tu_sai")
    if cts is not None:
        if not isinstance(cts, list):
            loi.append("chung_tu_sai phải là danh sách")
        else:
            ma_da = set()
            for i, x in enumerate(cts):
                if not isinstance(x, dict):
                    loi.append("chung_tu_sai[%d] không phải object" % i)
                    continue
                ma = x.get("ma")
                if not isinstance(ma, str) or not ma.strip() or len(ma) > 100:
                    loi.append("chung_tu_sai[%d].ma thiếu / dài quá 100" % i)
                elif ma in ma_da:
                    loi.append("chung_tu_sai[%d].ma trùng: %s" % (i, ma))
                ma_da.add(ma)
                ml = x.get("ma_loi")
                if not isinstance(ml, str) or not ml.strip() or len(ml) > 20:
                    loi.append("chung_tu_sai[%d].ma_loi thiếu / dài quá 20" % i)
                if x.get("muc") not in MUC_ISSUE:
                    loi.append("chung_tu_sai[%d].muc phải NANG/VUA/NHE" % i)
                if not isinstance(x.get("mo_ta"), str) or not x.get("mo_ta", "").strip():
                    loi.append("chung_tu_sai[%d].mo_ta thiếu" % i)
                st = x.get("so_tien")
                if st is not None and (isinstance(st, bool) or not isinstance(st, int)):
                    loi.append("chung_tu_sai[%d].so_tien phải là số nguyên đồng hoặc bỏ trống" % i)
                if x.get("ngay_ct") is not None and ngay_iso(x.get("ngay_ct")) != x.get("ngay_ct"):
                    loi.append("chung_tu_sai[%d].ngay_ct phải YYYY-MM-DD" % i)
    ds = d.get("da_sua")
    if ds is not None and (not isinstance(ds, list) or any(
            not isinstance(x, dict) or not x.get("ma") or x.get("trang_thai") not in TRANG_THAI_DA_SUA
            or (x.get("trang_thai") == "KHONG_SUA" and not x.get("ly_do")) for x in ds)):
        loi.append("da_sua: mỗi dòng cần ma, trang_thai DA_SUA/KHONG_SUA (KHONG_SUA kèm ly_do)")
    qt = d.get("quy_tac")
    if qt is not None and (not isinstance(qt, list) or any(
            not isinstance(x, dict) or not x.get("ma") or x.get("ket_qua") not in KET_QUA_QUY_TAC
            or (x.get("ket_qua") in ("THIEU_DL", "LOI") and not x.get("ly_do")) for x in qt)):
        loi.append("quy_tac: mỗi dòng cần ma, ket_qua hợp lệ (THIEU_DL/LOI kèm ly_do)")
    return loi


# ------------------------------------------------------------------ dung cac phan cua ket qua tu so lieu da doc
def _so_nguyen(x):
    try:
        v = int(round(float(x)))
    except (TypeError, ValueError):
        return None
    return v


def hien_trang_tu(dh, dc, bt):
    """dh = bang_dieu_hanh.tinh(...) (co the None), dc = doi_chieu_100.doi_chieu(...) (co the None), bt = {n, cao, vua, thap, dong}.
    Thieu nguon -> None (khong ghi 0). loi_nang = so dong LOI cua doi chieu + bat thuong muc Cao."""
    dh = dh or {}
    dc = dc or {}
    ht_dc = dc.get("hien_trang") or {}
    bt = bt or {}
    khoa = [int(m) for m in (dh.get("khoa") or ht_dc.get("khoa") or []) if str(m).isdigit()]
    ss = dh.get("ss") or {}
    diem = _so_nguyen(ss.get("diem")) if ss else None
    if diem is not None:
        diem = max(0, min(100, diem))
    cl = dc.get("cl") or []
    loi_nang = sum(1 for x in cl if len(x) > 1 and x[1] == "LOI") + int(bt.get("cao") or 0)
    nguon_thieu = []
    for x in cl:
        if len(x) > 2 and x[0] in DC_THIEU_DL:
            nguon_thieu.append("%s:%s" % (x[0], x[2]))
    cs = dc.get("chi_so") or {}
    ht = {
        "chung_tu_den": ngay_iso(dh.get("ct_ngay")),
        "hd_den": ngay_iso(dh.get("hddt_den") or ht_dc.get("hd_den")),
        "so_phu_den": thang_iso(dh.get("sp_den") or ht_dc.get("sp_den")) if (dh.get("sp_co") or ht_dc.get("sp_co")) else None,
        "thang_khoa": max(khoa) if khoa else 0,
        "diem_san_sang": diem,
        "loi_nang": loi_nang,
        # v1.1 (ERP hien bo qua, V0088 se doc)
        "nhom": dc.get("nhom"),
        "ly_do_nhom": list(dc.get("ly_do_nhom") or [])[:10],
        "nguon_thieu": nguon_thieu[:50],
        "hd_chua_hach_toan": ht_dc.get("hd_chua"),
        "ton_am": ht_dc.get("ton_am"),
        "kpi": {"hd_hach_toan": cs.get("hd_ht"), "hd_may_lap": cs.get("hd_may"), "chenh_lech_chua_giai_trinh": cs.get("cl_chua_gt"),
                "to_khai_tre": cs.get("to_khai_tre"),
                # GD347b (F06): hd_may_lap = HDDT_QuanHe AI_LAP; khong cham tay = may ghi TU_DONG, khong ai sua / xem lai / huy sau do
                "hd_gan_tay": cs.get("hd_gan_tay"), "hd_khong_cham": cs.get("hd_khong_cham"), "tl_khong_cham": cs.get("tl_khong_cham"),
                # GD348c: ten theo LIEN_THONG_ERP_UNESCO_AI.md muc 4.5 (ERP doc tu ResultJson); None = so chua ghi che do (truoc GD347b)
                "tu_ghi": cs.get("hd_tu_ghi"), "nguoi_ghi": cs.get("hd_nguoi_ghi"), "gan_ct_cu": cs.get("hd_gan_tay"),
                "phai_sua_sau_tu_ghi": (cs["hd_tu_ghi"] - cs["hd_khong_cham"]) if isinstance(cs.get("hd_tu_ghi"), int) and isinstance(cs.get("hd_khong_cham"), int) else None},
        "bo_quy_tac": BO_QUY_TAC_MAC_DINH,
    }
    return ht


def quy_tac_tu(cl, bt, loi_doi_chieu=None, loi_bat_thuong=None):
    """-> quy_tac[]: moi ma DC1..DC16 va KS8..KS12 dung mot dong. Khong chay duoc -> LOI (khong bao gio thanh DAT)."""
    out = []
    cl = cl or []
    for ma in sorted(TEN_DC, key=lambda m: int(m[2:])):
        if loi_doi_chieu:
            out.append({"ma": ma, "ten": TEN_DC[ma], "ket_qua": "LOI", "ly_do": _chu(loi_doi_chieu, 300)})
            continue
        dong = [x for x in cl if x and x[0] == ma]
        if not dong:
            out.append({"ma": ma, "ten": TEN_DC[ma], "ket_qua": "DAT"})
        elif ma in DC_THIEU_DL:
            out.append({"ma": ma, "ten": TEN_DC[ma], "ket_qua": "THIEU_DL", "so_dong": len(dong),
                        "ly_do": _chu(dong[0][3] if len(dong[0]) > 3 else "thiếu nguồn", 300)})
        else:
            muc = "NANG" if any(len(x) > 1 and x[1] == "LOI" for x in dong) else ("VUA" if any(len(x) > 1 and x[1] == "CANH_BAO" for x in dong) else "NHE")
            out.append({"ma": ma, "ten": TEN_DC[ma], "ket_qua": "LECH", "muc": muc, "so_dong": len(dong),
                        "chi_tiet": [{"khoa": _chu(x[2], 60), "mo_ta": _chu(x[3], 300), "so_lieu": _chu(x[4] if len(x) > 4 else "", 300)} for x in dong[:30]]})
    bt = bt or {}
    dong_bt = bt.get("dong") or []
    for ks in ("KS8", "KS9", "KS10", "KS11", "KS12"):
        if loi_bat_thuong:
            out.append({"ma": ks, "ten": TEN_KS[ks], "ket_qua": "LOI", "ly_do": _chu(loi_bat_thuong, 300)})
            continue
        n = sum(1 for x in dong_bt if x.get("ks") == ks)
        if n == 0:
            out.append({"ma": ks, "ten": TEN_KS[ks], "ket_qua": "DAT"})
        else:
            cao = sum(1 for x in dong_bt if x.get("ks") == ks and x.get("muc") == "Cao")
            out.append({"ma": ks, "ten": TEN_KS[ks], "ket_qua": "LECH", "muc": "NANG" if cao else "VUA", "so_dong": n})
    return out


def chung_tu_sai_tu(dong_bt, ct=None, tk=None):
    """dong_bt = BatThuong.dong (co 'mact'); ct = {MaCT: (so_hieu, ngay dd/mm/yyyy, maTKNo, maTKCo, tien)}; tk = {maso: so_hieu}.
    Mot dong bat thuong co n chung tu -> n dong chung_tu_sai (ma = KS:MaCT:loai). Khong co MaCT -> mot dong theo khoa."""
    ct = ct or {}
    tk = tk or {}
    out, da = [], set()

    def them(ma, x, so_ct=None, ngay=None, no=None, co=None, tien=None):
        ma = ma_sach(ma, 100)
        if not ma or ma in da:
            return
        da.add(ma)
        d = {"ma": ma, "ma_loi": _chu(x.get("ks") or "KS", 20), "ten_loi": TEN_KS.get(x.get("ks"), x.get("loai") or ""),
             "muc": MUC_BT.get(x.get("muc"), "VUA"), "mo_ta": _chu(x.get("mo_ta") or x.get("loai"), 1000), "tu_sua": False}
        if x.get("khoa"):
            d["khoa_tram"] = _chu(x["khoa"], 200)        # khoa noi bo (HDDT_KS_BoQua) de "khong phai loi" tro ve dung dong
        if x.get("so_lieu"):
            d["mo_ta"] = _chu(d["mo_ta"] + " | " + x["so_lieu"], 1000)
        if x.get("goi_y"):
            d["de_xuat"] = _chu(x["goi_y"], 1000)
        if so_ct:
            d["so_ct"] = _chu(so_ct, 50)
        if ngay_iso(ngay):
            d["ngay_ct"] = ngay_iso(ngay)
        if no:
            d["tk_no"] = _chu(no, 20)
        if co:
            d["tk_co"] = _chu(co, 20)
        if tien is not None:
            v = _so_nguyen(tien)
            if v is not None and v != 0:
                d["so_tien"] = v
        out.append(d)

    for x in dong_bt or []:
        if not isinstance(x, dict):
            continue
        mact = [m for m in (x.get("mact") or []) if m]
        if not mact:
            them("%s:%s:%s" % (x.get("ks"), x.get("loai"), x.get("khoa") or x.get("ma")), x)
            continue
        for m in mact:
            c = ct.get(int(m)) if str(m).isdigit() or isinstance(m, int) else None
            if c:
                them("%s:%s:%s" % (x.get("ks"), m, x.get("loai")), x, c[0], c[1], tk.get(c[2]), tk.get(c[3]), c[4])
            else:
                them("%s:%s:%s" % (x.get("ks"), m, x.get("loai")), x)
    return out


def ct_tu_dl(dl):
    """hang_loat.dl_tu_mdb(...)[0] -> ({MaCT: (so_hieu, ngay, maTKNo, maTKCo, tien)}, {maso TK: so_hieu}). Nhieu dong cung MaCT: lay dong tien lon nhat."""
    tk = {}
    for r in (dl or {}).get("tk") or []:
        if len(r) > 1:
            tk[r[0]] = r[1]
    ct = {}
    for r in ((dl or {}).get("ss") or {}).get("ct") or []:
        if len(r) < 11:
            continue
        mact, sohieu, ngay, no, co, ps = r[1], r[4], r[5], r[8], r[9], r[10]
        cu = ct.get(mact)
        if cu is None or abs(float(ps or 0)) > abs(float(cu[4] or 0)):
            ct[mact] = (sohieu, ngay, no, co, ps)
    return ct, tk


def viec_can_nguoi_tu(cl, bt, buoc_bo_qua=()):
    """-> viec_can_nguoi[] (khuon v1 + 'ma' on dinh v1.1). THONG_TIN khong vao."""
    out = []
    for x in cl or []:
        if len(x) < 4 or x[1] == "THONG_TIN":
            continue
        out.append({"ma": ma_sach("%s:%s" % (x[0], x[2]), 100), "loai": "CHENH_LECH", "buoc": "doi_chieu", "quy_tac": x[0],
                    "muc": "NANG" if x[1] == "LOI" else "VUA", "mo_ta": _chu(x[3], 500), "so_lieu": _chu(x[4] if len(x) > 4 else "", 300)})
    bt = bt or {}
    if bt.get("cao"):
        out.append({"ma": "BT:CAO", "loai": "BAT_THUONG", "buoc": "kiem_tra", "muc": "NANG", "so_dong": int(bt["cao"]),
                    "mo_ta": "%d bất thường số liệu mức Cao (xem chung_tu_sai)" % int(bt["cao"])})
    for b, ly_do in buoc_bo_qua:
        out.append({"ma": "BUOC:" + b, "loai": "BUOC_CHUA_HO_TRO", "buoc": b, "muc": "VUA", "mo_ta": ly_do})
    return out
