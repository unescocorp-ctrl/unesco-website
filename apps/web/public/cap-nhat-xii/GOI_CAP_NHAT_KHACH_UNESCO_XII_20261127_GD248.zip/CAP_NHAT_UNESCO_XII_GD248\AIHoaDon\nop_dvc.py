# -*- coding: utf-8 -*-
"""GD185 - HO SO KY SO VA NOP CONG DICH VU CONG (01/GTGT, 03/TNDN, TNCN, BCTC).
Anh Thang 10/10/2026: "Code bo sung mau Bao cao Thue GTGT, TNDN, TNCN, BCTC khi xuat ra hien thi de ky so nop truc tiep Cong Dich vu cong".
Chon: Hien thi + XML dung chuan cong; anh TU dang nhap, TU cam USB ky va nop.

Phan mem CHI chuan bi: quet cac tep XML to khai da xuat (dang HTKK = dang cong nhan), kiem tra, hien thi dung mau, dong goi.
KHONG dang nhap, KHONG nhap mat khau / ma xac thuc, KHONG ky so, KHONG nop thay, KHONG sua to khai (tep XML duoc chep nguyen byte).

Luong:  tool_htkk_unesco /nopdvc:<tep|thu muc|a|b> /chedo:quet  -> ket-qua\\NOP_DVC.txt  (VB do vao luoi)
        tool_htkk_unesco /nopdvc:<a|b> /chedo:goi /ra:<thu muc> -> <ra>\\NOP_DVC_<ngay_gio>\\ (XML chep nguyen + 0_PHIEU_NOP.html + ...)

Moi to khai kiem:
  1 doc duoc XML, la to khai HTKK (HSoThueDTu, vung ten TKhaiThue)         -> loi [!] neu khong
  2 MST trong to khai = MST cong ty dang lam                               -> loi [!] neu khac
  3 luoc do XSD cua chinh HTKK tren may (neu co HTKK + lxml)               -> loi [!] neu sai
  4 bo rang buoc noi bo cua phan mem (01/GTGT, B01a... qua kiem_tra_tep)    -> loi [!] / canh bao [?]
  5 mau XML khop ban HTKK dang co, ky da ket thuc, co nguoi ky, trung ky    -> canh bao [?]
  6 han nop (Luat Quan ly thue 38/2019, dich ngay nghi), so sanh ky truoc (so_sanh_htkk.xem_truoc, tuy chon) -> canh bao [?]
Trang thai: SAN_SANG (khong co [!] / [?]), CAN_XEM (co [?]), CHAN (co [!]).
Khong ghi MST / ten nguoi nop thue vao nhat ky (chi co trong tep ket qua nam canh to khai)."""
import hashlib
import html as _html
import os
import re
import shutil
import xml.etree.ElementTree as ET
from datetime import date, datetime, timedelta

import so_sanh_htkk as SS

PHIEN_BAN = 1
TOI_DA_TEP = 200
CONG_DVC = "https://dichvucong.gdt.gov.vn"
NS_TKHAI = "http://kekhaithue.gdt.gov.vn/TKhaiThue"
TEN_HO = dict(SS.HO_TEN)
THU_TU_HO = {"GTGT": 1, "TNDN": 2, "KK": 3, "QTT": 4, "CNKD": 5, "BCTC": 6}
TEN_TRANG_THAI = {"SAN_SANG": "Sẵn sàng", "CAN_XEM": "Cần xem", "CHAN": "Có lỗi [!]"}
MOT_NGAY = timedelta(days=1)
_XSD_NHO = {}


# ------------------------------------------------------------------ tien ich
def _sach(s):
    """1 dong, khong tab (de VB tach cot)."""
    return re.sub(r"[\t\r\n]+", " ", str(s if s is not None else "")).strip()


def _vn(x):
    try:
        x = float(x)
    except (TypeError, ValueError):
        return ""
    s = "{:,.2f}".format(abs(x)).replace(",", "_").replace(".", ",").replace("_", ".")
    if s.endswith(",00"):
        s = s[:-3]
    return ("-" if x < 0 else "") + s


def _h(s):
    return _html.escape(str(s if s is not None else ""), quote=True)


def _mst_so(s):
    return re.sub(r"[^0-9]", "", str(s or ""))


def _ngay_vn(d):
    return d.strftime("%d/%m/%Y") if d else ""


def sha256_tep(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for kh in iter(lambda: f.read(1 << 20), b""):
            h.update(kh)
    return h.hexdigest()


# ------------------------------------------------------------------ liet ke tep
THU_MUC_XUAT = ("BaoCaoNam", "ToKhaiTNCN", "BaoCaoThue")      # thu muc lan xuat cua phan mem: <thu muc khach>\\<ten>\\<ngay_gio>
NGAY_GAN = 60                                               # @moinhat: tep trong thu muc htkk sua trong vong 60 ngay


def _tep_gan(thu_muc, hom_nay, ngay=NGAY_GAN):
    """Cac tep .xml trong thu muc (khong de quy) sua trong `ngay` ngay gan nhat."""
    ra = []
    try:
        for f in sorted(os.listdir(thu_muc)):
            p = os.path.join(thu_muc, f)
            if f.lower().endswith(".xml") and os.path.isfile(p):
                muon = datetime.fromtimestamp(os.path.getmtime(p)).date()
                if 0 <= (hom_nay - muon).days <= ngay:
                    ra.append(p)
    except Exception:
        pass
    return ra


def nguon_moi_nhat(thu_muc_khach, hom_nay=None):
    """'@moinhat' -> cac nguon: tep XML moi trong <khach>\\htkk + thu muc moi nhat cua moi thu muc lan xuat (BaoCaoNam...)."""
    hom_nay = hom_nay or date.today()
    ra = []
    if not thu_muc_khach:
        return ra
    ra += _tep_gan(os.path.join(thu_muc_khach, "htkk"), hom_nay)
    for ten in THU_MUC_XUAT:
        goc = os.path.join(thu_muc_khach, ten)
        try:
            con = sorted(d for d in os.listdir(goc) if os.path.isdir(os.path.join(goc, d)))
        except Exception:
            con = []
        if con:
            ra.append(os.path.join(goc, con[-1]))
    return ra


def liet_ke(nguon, thu_muc_khach="", hom_nay=None):
    """tep / thu muc / danh sach cach nhau '|' -> cac tep .xml (khong lap; thu muc: toi da 2 cap, bo thu muc NOP_DVC_* da dong goi
       va ban sao 'X (1).xml' khi da co 'X.xml'). Ky hieu: '@moinhat' (cac lan xuat gan nhat cua thu muc khach), '@gan60:<thu muc>'
       (tep trong thu muc do sua trong 60 ngay)."""
    ra, thay = [], set()

    def them(p):
        k = os.path.normcase(os.path.abspath(p))
        if k not in thay and p.lower().endswith(".xml") and os.path.isfile(p):
            thay.add(k)
            ra.append(os.path.abspath(p))

    ds = []
    for n in [x.strip().strip('"') for x in str(nguon or "").split("|") if x.strip()]:
        if n.lower() == "@moinhat":
            ds += nguon_moi_nhat(thu_muc_khach, hom_nay)
        elif n.lower().startswith("@gan60:"):
            ds += _tep_gan(n[7:].strip().strip('"'), hom_nay or date.today())
        else:
            ds.append(n)
    for n in ds:
        if os.path.isdir(n):
            goc_n = os.path.abspath(n)
            for goc, con, tep in os.walk(goc_n):
                rel = os.path.relpath(goc, goc_n)
                sau = 0 if rel == "." else rel.count(os.sep) + 1
                con[:] = [] if sau >= 2 else sorted(t for t in con if not t.upper().startswith("NOP_DVC_"))
                co = set(f.lower() for f in tep)
                for f in sorted(tep):
                    if f.lower().endswith(".xml") and not SS._la_ban_sao(f, co):
                        them(os.path.join(goc, f))
        else:
            them(n)
        if len(ra) >= TOI_DA_TEP:
            break
    return ra[:TOI_DA_TEP]


# ------------------------------------------------------------------ doc tep
def _goc_xml(b):
    if b[:2] in (b"\xff\xfe", b"\xfe\xff"):
        b = b.decode("utf-16").encode("utf-8")
    b = re.sub(rb"^\s*(\xef\xbb\xbf)?\s*<\?xml[^>]*\?>", b"", b)
    return ET.fromstring(b)


def _ten(tag):
    return tag.split("}", 1)[-1] if isinstance(tag, str) else ""


def _lay(goc, ten):
    for e in goc.iter():
        if _ten(e.tag) == ten:
            return (e.text or "").strip()
    return ""


def _co_the(goc, *ten):
    return any(_ten(e.tag) in ten for e in goc.iter())


def doc_menu_xsd(goc_htkk):
    """Menu.xml cua HTKK -> [(MaToKhai, VersionXML, XsdSchema|MaFile, MaFile)]. Loi -> []."""
    if not goc_htkk:
        return []
    try:
        cay = ET.parse(os.path.join(goc_htkk, "Project", "Menu.xml")).getroot()
    except Exception:
        return []
    ds = []
    for m in cay.iter():
        if _ten(m.tag) == "Menu" and m.get("MaFile") and m.get("MaToKhai"):
            ds.append((m.get("MaToKhai").strip(), (m.get("VersionXML") or "").strip(), (m.get("XsdSchema") or m.get("MaFile")).strip(),
                       m.get("MaFile")))
    return ds


def _so_pb(v):
    return tuple(int(x) for x in re.findall(r"\d+", v or "0"))


def tim_xsd(menu, goc_htkk, ma, pban):
    """-> (duong xsd | '', phien ban moi nhat cua HTKK cho ma to khai | '')."""
    cung = [m for m in menu if m[0] == str(ma or "").strip()]
    if not cung:
        return "", ""
    moi = max(cung, key=lambda m: _so_pb(m[1]))[1]
    khop = [m for m in cung if m[1] == str(pban or "").strip()]
    if not khop:
        return "", moi
    so = re.sub(r"\D", "", khop[0][1])
    xsd = os.path.join(goc_htkk, "InterfaceTemplates", "Validate", "%s_%s.xsd" % (khop[0][2], so))
    return (xsd if os.path.isfile(xsd) else ""), moi


def kiem_xsd(duong_xml, xsd):
    """-> ('OK'|'LOI'|'KHONG', [dong loi]). KHONG = khong co lxml / khong doc duoc XSD (khong ket luan)."""
    try:
        from lxml import etree as lx
    except Exception:
        return "KHONG", ["máy chưa có thư viện lxml nên chưa kiểm XSD"]
    try:
        sch = _XSD_NHO.get(xsd)
        if sch is None:
            sch = lx.XMLSchema(lx.parse(xsd))
            _XSD_NHO[xsd] = sch
    except Exception as e:
        return "KHONG", ["không đọc được lược đồ XSD của HTKK (%s)" % _sach(e)[:120]]
    try:
        if sch.validate(lx.parse(duong_xml)):
            return "OK", []
        return "LOI", ["dòng %d: %s" % (e.line, _sach(e.message)[:200]) for e in list(sch.error_log)[:12]]
    except Exception as e:
        return "LOI", ["không kiểm được: %s" % _sach(e)[:200]]


# ------------------------------------------------------------------ han nop
def _nghi(d):
    try:
        import hstk_dvc as H
        return H.la_ngay_nghi(d)
    except Exception:
        return d.weekday() >= 5


def _doi_ngay_nghi(d):
    n = 0
    while _nghi(d) and n < 40:
        d += MOT_NGAY
        n += 1
    return d


def han_nop_tk(tk):
    """Han nop (Luat Quan ly thue 38/2019): thang -> ngay 20 thang sau; quy -> ngay cuoi thang dau quy sau; nam -> ngay cuoi
       thang thu 3 ke tu ngay ket thuc nam. Trung ngay nghi -> ngay lam viec tiep theo. To khai bo sung -> None."""
    if tk.get("bs"):
        return None
    k = tk.get("ky")
    if not k:
        return None
    kieu, d1, d2 = k
    if kieu == "M":
        y, m = d2.year + (d2.month == 12), d2.month % 12 + 1
        return _doi_ngay_nghi(date(y, m, 20))
    if kieu == "Q":
        m, y = d2.month + 1, d2.year
        if m > 12:
            m, y = 1, y + 1
        return _doi_ngay_nghi(date(y + (m == 12), m % 12 + 1, 1) - MOT_NGAY)
    m, y = d2.month + 3, d2.year
    if m > 12:
        m, y = m - 12, y + 1
    return _doi_ngay_nghi(date(y + (m == 12), m % 12 + 1, 1) - MOT_NGAY)


# ------------------------------------------------------------------ bang hien thi dung mau
def _gia_tri(ct, *khoa):
    for t in khoa:
        k = SS._khoa_la(ct, t)
        if k:
            return ct[k]
    return None


def _b_gtgt(tk):
    import tool_htkk_unesco as T
    ct = tk["ct"]
    tt89 = any(k.split("/")[-1] in ("ct32b", "ct34a") for k in ct)
    dong = []
    for stt, ten, ma, mg, mt in T._dong_01gtgt(tt89):
        if mg == "*":
            dong.append(("muc", stt, ten, ma, None, None))
        elif mg == "21x":
            v = _gia_tri(ct, "ct21")
            dong.append(("dong", stt, ten, ma, "X" if v else "", None))
        else:
            dong.append(("dong", stt, ten, ma, _gia_tri(ct, "ct" + mg) if mg else None, _gia_tri(ct, "ct" + mt) if mt else None))
    return [{"tieu_de": "Tờ khai thuế GTGT (01/GTGT)", "cot": ["Giá trị HHDV (chưa có thuế GTGT)", "Số thuế GTGT"], "dong": dong}]


def _b_tndn(tk):
    import bao_cao_nam as B
    ct = tk["ct"]
    c7, c9 = _gia_tri(ct, "ctC7"), _gia_tri(ct, "ctC9")
    ts = "20"
    if c7 and c9:
        ts = str(int(round(c9 / c7 * 100))) if abs(c9 / c7 * 100 - round(c9 / c7 * 100)) < 0.05 else ("%.1f" % (c9 / c7 * 100)).replace(".", ",")
    dong = []
    for stt, ten, ma in B.TNDN_DONG:
        ten = ten.replace("{ts}", ts)
        if ma in B.TNDN_MUC:
            dong.append(("muc", stt, ten, "", None, None))
            continue
        if ma.startswith("tamnop"):
            dong.append(("dong", stt, ten, "", None, None))
            continue
        v = _gia_tri(ct, "ct" + ma)
        dong.append(("dong", stt, ten, ma, ("%s%%" % _vn(v)) if (ma == "C8a" and v is not None) else v, None))
    return [{"tieu_de": "Tờ khai quyết toán thuế TNDN (03/TNDN)", "cot": ["Số tiền"], "dong": dong}]


def _b_kk(tk):
    import kk_tncn as KK
    ct = tk["ct"]
    dong = [("dong", stt, ten, "[%s]" % ma, _gia_tri(ct, "ct" + ma), None) for stt, ten, ma, _dv, _d in KK.DONG]
    return [{"tieu_de": "Tờ khai khấu trừ thuế TNCN (05/KK-TNCN)", "cot": ["Số người / số tiền"], "dong": dong}]


def _b_qtt(tk):
    ct = tk["ct"]
    dong = [("dong", "", ten, "", ct.get(k), None) for k, ten, _kieu in SS.CT_QTT if k in ct]
    ds = _b_chung(tk, bo=set(k for k, _t, _x in SS.CT_QTT))
    return [{"tieu_de": "Quyết toán thuế TNCN (05/QTT-TNCN) - chỉ tiêu chính", "cot": ["Số liệu"], "dong": dong}] + ds


def _b_bctc(tk):
    import bao_cao_nam as B
    ct = tk["ct"]
    kq = []
    d1 = [("muc" if k == "td" else "dong", "", ten, ("[%d]" % ma) if ma else "", _gia_tri(ct, "SoCuoiNam/ct%d" % ma) if ma else None,
           _gia_tri(ct, "SoDauNam/ct%d" % ma) if ma else None) for ten, ma, k in B.B01A_DONG]
    if any(x[4] is not None or x[5] is not None for x in d1):
        kq.append({"tieu_de": "B01a-DNN - Báo cáo tình hình tài chính", "cot": ["Số cuối năm", "Số đầu năm"], "dong": d1})

    def b0x(ten, ds, khoi):
        dong = []
        for t, ma, k in ds:
            if ma is None:
                dong.append(("muc", "", t, "", None, None))
                continue
            a = _gia_tri(ct, "%s/NamNay/ct%02d" % (khoi, ma), "%s/NamNay/ct%d" % (khoi, ma))
            b = _gia_tri(ct, "%s/NamTruoc/ct%02d" % (khoi, ma), "%s/NamTruoc/ct%d" % (khoi, ma))
            dong.append(("dong", "", t, "[%02d]" % ma, a, b))
        if any(x[4] is not None or x[5] is not None for x in dong):
            kq.append({"tieu_de": ten, "cot": ["Năm nay", "Năm trước"], "dong": dong})
    b0x("B02-DNN - Báo cáo kết quả hoạt động kinh doanh", [(t, m, k) for t, m, k in B.B02_DONG], "PL_KQHDSXKD")
    b0x("B03-DNN - Báo cáo lưu chuyển tiền tệ", B.B03_DONG, "PL_LCTTTT")
    return kq or _b_chung(tk)


def _b_chung(tk, bo=()):
    """Mau chua co bang nhan rieng: moi chi tieu khac 0 theo nhom (ten the XML)."""
    nhom, so = {}, 0
    for k, v in tk["ct"].items():
        if k in bo or not v:
            continue
        g, _s, ma = k.rpartition("/")
        nhom.setdefault(g or "Tờ khai", []).append(("dong", "", "", "[%s]" % ma, v, None))
        so += 1
    kq = []
    for g in sorted(nhom):
        kq.append({"tieu_de": "Nhóm %s (chỉ tiêu khác 0)" % g, "cot": ["Số liệu"], "dong": nhom[g][:300]})
        if len(kq) >= 12:
            break
    return kq


def bang_hien_thi(tk):
    """-> [{'tieu_de','cot':[...],'dong':[(kieu,stt,ten,ma,v1,v2)]}] theo mau cua to khai. Loi doc nhan -> bang chung."""
    try:
        ho = tk["ho"]
        if ho == "GTGT":
            return _b_gtgt(tk)
        if ho == "TNDN":
            return _b_tndn(tk)
        if ho == "KK":
            return _b_kk(tk)
        if ho == "QTT":
            return _b_qtt(tk)
        if ho == "BCTC":
            return _b_bctc(tk)
    except Exception:
        pass
    return _b_chung(tk)


def tom_tat(tk):
    """Mot dong chi tieu chinh (toi da 4)."""
    try:
        ds = SS.danh_sach_chinh(tk)
    except Exception:
        ds = []
    ra = []
    for k, ten, kieu in ds:
        v = tk["ct"].get(k)
        if v is None:
            continue
        ra.append("%s: %s" % (ten, _vn(v)))
        if len(ra) >= 4:
            break
    return "; ".join(ra)


# ------------------------------------------------------------------ phan tich mot tep
def phan_tich(p, mst_cty="", menu=(), htkk_goc="", hom_nay=None):
    hom_nay = hom_nay or date.today()
    r = {"tep": p, "ten_tep": os.path.basename(p), "kiem": [], "trang_thai": "SAN_SANG", "tk": None, "bang": [], "tom_tat": "",
         "xsd": "KHONG", "han": None, "sha": "", "co": 0}

    def ghi(m, s):
        r["kiem"].append((m, s))

    try:
        r["co"] = os.path.getsize(p)
        with open(p, "rb") as f:
            b = f.read()
        r["sha"] = sha256_tep(p)
    except Exception as e:
        ghi("!", "Không đọc được tệp: %s" % _sach(e)[:120])
        r["trang_thai"] = "CHAN"
        return r
    try:
        goc = _goc_xml(b)
    except Exception as e:
        ghi("!", "Tệp không phải XML hợp lệ (%s). Cổng sẽ không nhận." % _sach(e)[:120])
        r["trang_thai"] = "CHAN"
        return r
    if _ten(goc.tag) != "HSoThueDTu" or not _co_the(goc, "HSoKhaiThue"):
        ghi("!", "Không phải tệp tờ khai thuế XML của HTKK (không có HSoThueDTu / HSoKhaiThue); đây có thể là hoá đơn hoặc tệp khác.")
        r["trang_thai"] = "CHAN"
        r["khong_phai_tk"] = True
        return r
    tk = SS.doc_xml_tk(p)
    if not tk:
        ghi("!", "Không đọc được kỳ kê khai hoặc mã tờ khai trong tệp.")
        r["trang_thai"] = "CHAN"
        return r
    r["tk"] = tk
    ns = goc.tag.split("}", 1)[0][1:] if "}" in goc.tag else ""
    if ns != NS_TKHAI:
        ghi("!", "Tệp không có vùng tên %s: cổng sẽ không nhận." % NS_TKHAI)
    if b[:2] in (b"\xff\xfe", b"\xfe\xff"):
        ghi("?", "Tệp mã hoá UTF-16; HTKK thường xuất UTF-8. Nên xuất lại từ phần mềm.")
    r["ten_nnt"] = _lay(goc, "tenNNT")
    r["mst"] = _mst_so(_lay(goc, "mst"))
    r["cqt"] = _lay(goc, "tenCQTNoiNop")
    r["nguoi_ky"] = _lay(goc, "nguoiKy")
    r["ngay_lap"] = _lay(goc, "ngayLapTKhai")
    r["da_ky"] = _co_the(goc, "Signature", "CKyDTu")
    r["ho"] = tk["ho"]
    ten_ho = TEN_HO.get(tk["ho"], "") or (tk.get("ten") or "Tờ khai")
    r["ten"] = "%s %s" % (ten_ho, SS._ten_ky(tk["ky"]))
    r["ky_ten"] = SS._ten_ky(tk["ky"])
    r["loai"] = ("Bổ sung lần %d" % max(tk.get("lan") or 0, 1)) if tk.get("bs") else "Chính thức"
    # 2. MST
    ms = _mst_so(mst_cty)
    if ms and r["mst"] and r["mst"][:10] != ms[:10]:
        ghi("!", "Tờ khai này của một mã số thuế KHÁC với công ty đang làm - không nộp nhầm công ty.")
    elif ms and not r["mst"]:
        ghi("?", "Tờ khai không ghi mã số thuế người nộp thuế.")
    if not r["ten_nnt"]:
        ghi("?", "Tờ khai chưa có tên người nộp thuế.")
    # 3. XSD cua HTKK
    xsd, moi = tim_xsd(menu, htkk_goc, tk["ma"], tk["pban"]) if menu else ("", "")
    if xsd:
        kq, loi = kiem_xsd(p, xsd)
        r["xsd"] = kq
        if kq == "LOI":
            ghi("!", "Không đạt lược đồ XSD của HTKK (cổng dùng cùng bộ lược đồ):")
            for x in loi:
                ghi("!", "  " + x)
        elif kq == "OK":
            ghi("v", "Đạt lược đồ XSD của chính HTKK trên máy (%s)." % os.path.basename(xsd))
        else:
            ghi("i", "Chưa kiểm XSD: " + "; ".join(loi))
    elif menu and moi:
        r["xsd"] = "MAU"
        ghi("?", "Tờ khai lập theo mẫu XML %s; HTKK trên máy đang có mẫu %s. Cổng thường chỉ nhận mẫu đang hiệu lực - nếu cổng báo sai mẫu, "
                 "xuất lại tờ khai từ phần mềm." % (tk["pban"] or "?", moi))
    elif menu:
        ghi("?", "HTKK trên máy không có mẫu tờ khai mã %s (bản HTKK có thể cũ hơn): chưa kiểm được theo XSD." % tk["ma"])
    else:
        ghi("i", "Máy chưa tìm thấy HTKK nên chưa kiểm theo lược đồ XSD (vẫn kiểm nội bộ bên dưới).")
    # 4. rang buoc noi bo
    try:
        import tool_htkk_unesco as T
        bao_cao, so_chan = T.kiem_tra_tep(p)
        chan_l, canh_l = [], []
        for dong in bao_cao.split("\n"):
            if dong.startswith("  - "):
                chan_l.append(dong[4:].strip())
            elif dong.startswith("  ? "):
                canh_l.append(dong[4:].strip())
        if so_chan or chan_l:
            ghi("!", "Kiểm nội bộ: %d lỗi phải sửa trước khi nộp:" % max(so_chan, len(chan_l)))
            for x in chan_l[:10]:
                ghi("!", "  " + x)
        if canh_l:
            ghi("?", "Kiểm nội bộ: %d cảnh báo nên xem lại:" % len(canh_l))
            for x in canh_l[:8]:
                ghi("?", "  " + x)
        if not so_chan and not chan_l and not canh_l and "Chua co bo rang buoc" not in bao_cao:
            ghi("v", "Đạt bộ ràng buộc nội bộ của phần mềm.")
        elif "Chua co bo rang buoc" in bao_cao:
            ghi("i", "Mẫu này chưa có bộ ràng buộc nội bộ (chỉ kiểm cấu trúc và XSD).")
    except Exception as e:
        ghi("i", "Chưa chạy được kiểm nội bộ (%s)." % _sach(e)[:80])
    # 5. mau / ky / nguoi ky / chu ky
    k = tk["ky"]
    if k and k[2] >= hom_nay:
        ghi("?", "Kỳ kê khai (%s) chưa kết thúc tính đến hôm nay." % r["ky_ten"])
    if not r["nguoi_ky"]:
        ghi("?", "Tờ khai chưa ghi tên người ký (người đại diện theo pháp luật).")
    if r["da_ky"]:
        ghi("i", "Tệp ĐÃ có chữ ký số. Không mở / sửa / lưu lại tệp này trước khi nộp (sửa bất kỳ ký tự nào là hỏng chữ ký).")
    else:
        ghi("i", "Tệp chưa ký - đúng như HTKK xuất. Anh ký ở bước \"Ký điện tử\" trên cổng bằng USB token.")
    # 6. han nop
    han = han_nop_tk(tk)
    r["han"] = han
    if tk.get("bs"):
        ghi("i", "Tờ khai bổ sung: không xét hạn nộp ở đây (nộp bổ sung khi phát hiện sai sót).")
    elif han:
        d = (han - hom_nay).days
        if d < 0:
            ghi("?", "Đã quá hạn nộp %s (%d ngày). Nộp muộn có thể bị xử phạt - anh xem lại với kế toán thuế." % (_ngay_vn(han), -d))
        elif d <= 5:
            ghi("?", "Sắp đến hạn nộp: %s (còn %d ngày)." % (_ngay_vn(han), d))
        else:
            ghi("i", "Hạn nộp: %s (còn %d ngày)." % (_ngay_vn(han), d))
    # chi tieu chinh
    r["tom_tat"] = tom_tat(tk)
    r["bang"] = bang_hien_thi(tk)
    return r


def _tinh_trang_thai(r):
    if any(m == "!" for m, _ in r["kiem"]):
        return "CHAN"
    if any(m == "?" for m, _ in r["kiem"]):
        return "CAN_XEM"
    return "SAN_SANG"


def _khoa_trung(r):
    tk = r["tk"]
    return (tk["ho"], tk["ma"], tk["ky"][0], tk["ky"][1], tk["ky"][2], tk.get("lan") or 0, r.get("mst", ""))


# ------------------------------------------------------------------ quet ca lo
def quet(nguon, mst="", ten_cty="", htkk_goc="", thu_muc_khach="", so_sanh=True, log=None, hom_nay=None):
    log = log or (lambda s: None)
    hom_nay = hom_nay or date.today()
    ds = liet_ke(nguon, thu_muc_khach, hom_nay)
    menu = doc_menu_xsd(htkk_goc)
    kq = {"nguon": str(nguon or ""), "mst": _mst_so(mst), "ten_cty": ten_cty or "", "htkk": bool(menu), "hom_nay": hom_nay,
          "ds": [], "khac": [], "so_sanh": False}
    ra = []
    for p in ds:
        r = phan_tich(p, mst, menu, htkk_goc, hom_nay)
        if r.get("khong_phai_tk"):
            kq["khac"].append(r)
        else:
            ra.append(r)
    # trung ky cung loai
    dem = {}
    for r in ra:
        if r["tk"]:
            dem.setdefault(_khoa_trung(r), []).append(r)
    for nhom in dem.values():
        if len(nhom) > 1:
            for r in nhom:
                r["kiem"].append(("?", "Có %d tệp cùng loại, cùng kỳ, cùng lần (%s): chỉ nộp MỘT tệp, nộp hai lần sẽ bị trùng hồ sơ." % (
                    len(nhom), ", ".join(x["ten_tep"] for x in nhom if x is not r)[:120])))
    # so sanh ky truoc / kiem cheo trong ky (GD164) - chi dong y kien, khong chan
    if so_sanh:
        try:
            tk_ds = [r["tep"] for r in ra if r["tk"]]
            if tk_ds:
                xt = SS.xem_truoc(tk_ds, mst, thu_muc_khach, htkk_goc, "", log)
                theo_tep = {os.path.normcase(os.path.abspath(m["tk"]["tep"])): m for m in xt.get("muc") or []}
                for r in ra:
                    m = theo_tep.get(os.path.normcase(os.path.abspath(r["tep"])))
                    if not m:
                        continue
                    truoc = m.get("truoc")
                    if truoc is None:
                        r["kiem"].append(("i", "Chưa thấy tờ khai kỳ trước để so sánh (chỉ kiểm trong kỳ)."))
                    else:
                        r["kiem"].append(("i", "So sánh với kỳ trước: %s - %s." % (SS._ten_ky(truoc["ky"]), truoc.get("nguon", ""))))
                    for x in m.get("cb") or []:
                        mark = "?" if x[0] in ("!", "?") else "i"
                        r["kiem"].append((mark, "So sánh/kiểm chéo: " + _sach(x[1])[:300]))
                kq["so_sanh"] = True
        except Exception as e:
            log("[NOP DVC] khong so sanh duoc ky truoc: %s" % _sach(e)[:100])
    for r in ra:
        r["trang_thai"] = _tinh_trang_thai(r)
    ra.sort(key=lambda r: (THU_TU_HO.get(r["ho"], 9), r["tk"]["ky"][1], r["tk"]["ky"][2], r["tk"].get("lan") or 0, r["ten_tep"].lower()))
    kq["ds"] = ra
    if not kq["ten_cty"] and ra:
        kq["ten_cty"] = next((r.get("ten_nnt") for r in ra if r.get("ten_nnt")), "")
    if not kq["mst"] and ra:
        kq["mst"] = next((r.get("mst") for r in ra if r.get("mst")), "")
    log("[NOP DVC] quet %d tep: %d to khai, %d tep khac; %d san sang, %d can xem, %d loi" % (
        len(ds), len(ra), len(kq["khac"]), sum(r["trang_thai"] == "SAN_SANG" for r in ra),
        sum(r["trang_thai"] == "CAN_XEM" for r in ra), sum(r["trang_thai"] == "CHAN" for r in ra)))
    return kq


def dem_trang_thai(kq):
    d = {"SAN_SANG": 0, "CAN_XEM": 0, "CHAN": 0}
    for r in kq["ds"]:
        d[r["trang_thai"]] += 1
    return d


# ------------------------------------------------------------------ tep ket qua cho VB6
def dong_ket_qua(kq):
    """Cac dong NOP_DVC.txt (tab):  NOPDVC | TK | CT.  VB tach theo Tab; noi dung da bo tab / xuong dong."""
    d = dem_trang_thai(kq)
    ra = ["\t".join(["NOPDVC", str(PHIEN_BAN), _sach(kq["nguon"]), str(len(kq["ds"])), str(d["SAN_SANG"]), str(d["CAN_XEM"]), str(d["CHAN"]),
                     "1" if kq["htkk"] else "0", "1" if kq["so_sanh"] else "0", str(len(kq["khac"])), _sach(kq["ten_cty"]), kq["mst"]])]
    for i, r in enumerate(kq["ds"], 1):
        ra.append("\t".join(["TK", str(i), _sach(r["tep"]), _sach(r["ten"]), _sach(r["ky_ten"]), _sach(r["loai"]), _ngay_vn(r["han"]),
                             r["trang_thai"], _sach(r["tom_tat"]), r["xsd"], r["sha"][:12]]))
        ra.append("\t".join(["CT", str(i), "Tệp: %s (%s byte) - mẫu XML %s, mã tờ khai %s" % (
            r["ten_tep"], _vn(r["co"]), r["tk"]["pban"] or "?", r["tk"]["ma"] or "?")]))
        if r.get("cqt"):
            ra.append("\t".join(["CT", str(i), "Nơi nộp: %s" % _sach(r["cqt"])]))
        for m, s in r["kiem"]:
            ra.append("\t".join(["CT", str(i), "[%s] %s" % ({"!": "!", "?": "?", "i": "i", "v": "OK"}.get(m, m), _sach(s))]))
    for r in kq["khac"]:
        ra.append("\t".join(["KHAC", _sach(r["tep"]), _sach(r["kiem"][0][1] if r["kiem"] else "")]))
    return ra


def ghi_ket_quet(kq, duong):
    os.makedirs(os.path.dirname(os.path.abspath(duong)), exist_ok=True)
    with open(duong, "w", encoding="utf-8-sig", newline="\r\n") as f:
        f.write("\n".join(dong_ket_qua(kq)) + "\n")
    return duong


# ------------------------------------------------------------------ cac buoc ky so va nop
def cac_buoc(tk_ds=()):
    """Huong dan dang nhap, ky so, nop tren Cong DVC (nguon: huong dan cua cong dichvucong.gdt.gov.vn; ten muc co the doi theo giao dien)."""
    co_bctc = any(r["ho"] == "BCTC" for r in tk_ds)
    b = [
        ("Chuẩn bị", "Cắm USB token (chữ ký số) vào máy, mở Chrome hoặc Edge, vào %s rồi bấm \"Đăng nhập\" bằng tài khoản Thuế điện tử "
                     "hoặc tài khoản định danh điện tử, chọn đối tượng \"Doanh nghiệp\". Anh tự đăng nhập và tự nhập mã xác thực; phần mềm "
                     "không nhập thay, không lưu mật khẩu." % CONG_DVC),
        ("Tìm thủ tục", "Vào \"Thủ tục hành chính\", gõ tên tờ khai (đúng như cột Tờ khai của phiếu này) vào ô \"Tên/Mã thủ tục hành chính\", "
                        "bấm \"Tìm kiếm\" rồi \"Nộp hồ sơ\"."),
        ("Chọn tờ khai", "Chọn đúng mẫu tờ khai và kỳ khai ghi trong phiếu, bấm \"Tiếp tục\", chọn hình thức \"Nộp XML\"."),
        ("Chọn tệp", "Bấm \"Chọn tệp\", chọn tệp XML trong thư mục hồ sơ này (đúng tên tệp ghi trong phiếu), bấm \"Tiếp tục\". "
                     "Tệp có phụ lục / bảng kê nằm trong cùng tệp XML nên chỉ cần chọn một tệp cho mỗi tờ khai."),
        ("Ký điện tử", "Bấm \"Ký điện tử\", nhập mã PIN của USB token rồi bấm \"Chấp nhận\". Nếu cổng báo chưa có plugin chữ ký số: "
                       "bấm \"Đóng\", vào \"Trợ giúp\" cài TCT SigningHub (hoặc eSigner), đăng xuất, đăng nhập lại và làm lại từ bước chọn "
                       "tờ khai. Cách khác: ký trước tệp XML bằng phần mềm TCT SigningHub, tải tệp đã ký lên và bỏ qua bước ký trên cổng."),
        ("Nộp", "Bấm \"Nộp tờ khai\". Cổng gửi \"Thông báo tiếp nhận hồ sơ khai thuế điện tử\" về email đã đăng ký; cơ quan thuế phản hồi "
                "chấp nhận hoặc không chấp nhận (thường trong 1 ngày làm việc) cũng qua email. Anh lưu thông báo chấp nhận vào hồ sơ."),
        ("Sau khi nộp", "Vào thẻ \"Hồ sơ thuế - Cổng DVC\" của phần mềm tải tờ khai đã nộp để làm số kỳ trước cho kỳ sau. Nếu cổng không "
                        "chấp nhận, đọc lý do trong thông báo, sửa ở phần mềm rồi xuất lại - không sửa tay trong tệp XML."),
    ]
    if co_bctc:
        b.append(("Báo cáo tài chính", "Bộ báo cáo tài chính (B01, B02, B03, B09) nộp cùng hồ sơ quyết toán thuế TNDN: tìm thủ tục theo tên "
                                       "\"báo cáo tài chính\" hoặc đính kèm ở bước \"Đính kèm tài liệu\" tuỳ giao diện cổng lúc nộp."))
    return b


GHI_CHU = [
    "Cổng chỉ nhận tờ khai dạng XML (không nhận Excel). Tên mục trên cổng có thể khác chút tuỳ thời điểm cập nhật giao diện.",
    "Phần mềm chỉ chuẩn bị hồ sơ: không đăng nhập, không nhập mật khẩu hay mã xác thực, không ký số, không nộp thay.",
    "Các tệp XML trong thư mục này được chép nguyên từng byte từ tệp đã xuất; mã SHA-256 trong phiếu để đối chiếu khi cần.",
    "Xem nội dung XML bằng iTaxViewer (phần mềm của Tổng cục Thuế) nếu muốn xem đúng dạng tờ khai trước khi ký.",
]


# ------------------------------------------------------------------ phieu HTML
CSS = """
:root{--nen:#f4f7f5;--the:#fff;--chu:#1d2b24;--phu:#5a6b62;--vien:#d5dfd9;--xanh:#1e5a3a;--xanh2:#e6f2ea;--do:#b3261e;--do2:#fdecea;--vang:#8a5a00;--vang2:#fff4d6}
@media (prefers-color-scheme:dark){:root{--nen:#14201a;--the:#1b2b23;--chu:#e8f1ec;--phu:#a5b8ad;--vien:#2d4337;--xanh:#7fd1a2;--xanh2:#1f3a2b;--do:#ff9d94;--do2:#3d1f1c;--vang:#f3c969;--vang2:#3a2f12}}
*{box-sizing:border-box}body{margin:0;background:var(--nen);color:var(--chu);font:15px/1.5 "Segoe UI",Roboto,Arial,sans-serif}
.trang{max-width:1100px;margin:0 auto;padding:20px 16px 60px}h1{font-size:22px;margin:0 0 4px;color:var(--xanh)}h2{font-size:18px;margin:26px 0 8px;color:var(--xanh)}
h3{font-size:15px;margin:16px 0 6px}.phu{color:var(--phu);font-size:13px}.the{background:var(--the);border:1px solid var(--vien);border-radius:10px;padding:14px 16px;margin:12px 0}
table{border-collapse:collapse;width:100%;font-size:14px}th,td{border:1px solid var(--vien);padding:5px 8px;text-align:left;vertical-align:top}
th{background:var(--xanh2);color:var(--xanh)}td.so,th.so{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}
tr.muc td{background:var(--xanh2);font-weight:600}.nhan{display:inline-block;padding:1px 9px;border-radius:99px;font-size:12.5px;font-weight:600}
.SAN_SANG{background:var(--xanh2);color:var(--xanh)}.CAN_XEM{background:var(--vang2);color:var(--vang)}.CHAN{background:var(--do2);color:var(--do)}
.k-ct{color:var(--do);font-weight:600}.k-cx{color:var(--vang);font-weight:600}.k-ok{color:var(--xanh);font-weight:600}.k-i{color:var(--phu)}
code{font-family:Consolas,monospace;font-size:12.5px;white-space:nowrap}.cuon table{min-width:620px}ol li{margin:6px 0}.cuon{overflow-x:auto}
@media print{body{background:#fff;color:#000}.the{break-inside:avoid;border-color:#999}h2{break-after:avoid}.trang{padding:0}}
@media (max-width:640px){th,td{padding:4px 5px;font-size:13px}}
"""


def _bang_html(b):
    o = ['<div class="cuon"><table><thead><tr><th>STT</th><th>Chỉ tiêu</th><th>Mã</th>']
    for c in b["cot"]:
        o.append('<th class="so">%s</th>' % _h(c))
    o.append("</tr></thead><tbody>")
    for kieu, stt, ten, ma, v1, v2 in b["dong"]:
        vals = [v1, v2][:len(b["cot"])]
        o.append('<tr class="%s"><td>%s</td><td>%s</td><td>%s</td>' % ("muc" if kieu == "muc" else "", _h(stt), _h(ten), _h(ma)))
        for v in vals:
            o.append('<td class="so">%s</td>' % (_h(v) if isinstance(v, str) else _h(_vn(v)) if v is not None else ""))
        o.append("</tr>")
    o.append("</tbody></table></div>")
    return "".join(o)


def phieu_html(kq, ds, ten_goi=""):
    """Phieu nop: bang tong hop + moi to khai hien thi dung mau + cac buoc nop. ds = cac ket qua phan tich da chon dong goi."""
    now = datetime.now().strftime("%d/%m/%Y %H:%M")
    o = ['<!DOCTYPE html><html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">',
         "<title>Phiếu nộp tờ khai qua Cổng DVC</title><style>%s</style></head><body><div class=\"trang\">" % CSS,
         "<h1>Hồ sơ ký số và nộp Cổng Dịch vụ công</h1>",
         '<div class="phu">%s%s - lập lúc %s bằng UNESCO AI. %s</div>' % (
             _h(kq.get("ten_cty") or ""), (" - MST %s" % _h(kq["mst"])) if kq.get("mst") else "", now, _h(ten_goi))]
    o.append('<div class="the"><b>Tóm tắt</b>: %d tờ khai. Anh tự đăng nhập, cắm USB token, ký và nộp trên %s theo các bước ở cuối phiếu.'
             "</div>" % (len(ds), _h(CONG_DVC)))
    o.append('<h2>1. Danh sách tờ khai</h2><div class="cuon"><table><thead><tr><th>STT</th><th>Tờ khai</th><th>Loại</th><th>Tệp XML</th><th>Hạn nộp</th>'
             "<th>Trạng thái</th><th>SHA-256</th></tr></thead><tbody>")
    for i, r in enumerate(ds, 1):
        o.append('<tr><td>%d</td><td>%s</td><td>%s</td><td><code>%s</code></td><td>%s</td><td><span class="nhan %s">%s</span></td><td><code>%s</code></td></tr>' % (
            i, _h(r["ten"]), _h(r["loai"]), _h(r.get("ten_goi") or r["ten_tep"]), _h(_ngay_vn(r["han"])), r["trang_thai"],
            _h(TEN_TRANG_THAI[r["trang_thai"]]), _h(r["sha"][:16])))
    o.append("</tbody></table></div>")
    for i, r in enumerate(ds, 1):
        tk = r["tk"]
        o.append('<h2>%d. %s</h2><div class="the">' % (i + 1, _h(r["ten"])))
        o.append('<div class="phu">Mẫu XML %s (mã tờ khai %s) - %s - nơi nộp: %s - người ký: %s - ngày lập: %s</div>' % (
            _h(tk["pban"] or "?"), _h(tk["ma"] or "?"), _h(r["loai"]), _h(r.get("cqt") or "(chưa ghi)"), _h(r.get("nguoi_ky") or "(chưa ghi)"),
            _h(r.get("ngay_lap") or "")))
        o.append('<h3>Kết quả kiểm tra: <span class="nhan %s">%s</span></h3><ul>' % (r["trang_thai"], _h(TEN_TRANG_THAI[r["trang_thai"]])))
        for m, s in r["kiem"]:
            cl, nh = {"!": ("k-ct", "[!]"), "?": ("k-cx", "[?]"), "v": ("k-ok", "[OK]")}.get(m, ("k-i", "[i]"))
            o.append('<li><span class="%s">%s</span> %s</li>' % (cl, nh, _h(s)))
        o.append("</ul>")
        for b in r["bang"]:
            o.append("<h3>%s</h3>%s" % (_h(b["tieu_de"]), _bang_html(b)))
        dem = tk.get("dem") or {}
        if dem:
            o.append('<h3>Phụ lục / bảng kê trong tệp</h3><ul>%s</ul>' % "".join(
                "<li>%s: %d dòng</li>" % (_h(k.split("/")[-1] or k), v) for k, v in sorted(dem.items())[:40]))
        o.append("</div>")
    o.append("<h2>%d. Các bước ký số và nộp trên Cổng DVC</h2><ol>" % (len(ds) + 2))
    for ten, nd in cac_buoc(ds):
        o.append("<li><b>%s</b>: %s</li>" % (_h(ten), _h(nd)))
    o.append("</ol><div class=\"the\"><b>Lưu ý</b><ul>%s</ul></div>" % "".join("<li>%s</li>" % _h(x) for x in GHI_CHU))
    o.append("</div></body></html>")
    return "".join(o)


def phieu_txt(kq, ds):
    d = ["HỒ SƠ KÝ SỐ VÀ NỘP CỔNG DỊCH VỤ CÔNG - %s" % datetime.now().strftime("%d/%m/%Y %H:%M"),
         "%s%s" % (kq.get("ten_cty") or "", (" - MST " + kq["mst"]) if kq.get("mst") else ""), ""]
    for i, r in enumerate(ds, 1):
        d.append("%d. %s - %s - tệp %s - hạn nộp %s - %s - SHA-256 %s" % (
            i, r["ten"], r["loai"], r.get("ten_goi") or r["ten_tep"], _ngay_vn(r["han"]) or "(không xét)", TEN_TRANG_THAI[r["trang_thai"]], r["sha"]))
        if r["tom_tat"]:
            d.append("   " + r["tom_tat"])
        for m, s in r["kiem"]:
            if m in ("!", "?"):
                d.append("   [%s] %s" % (m, s))
    d += ["", "CÁC BƯỚC KÝ SỐ VÀ NỘP (anh tự đăng nhập, tự ký, tự nộp):"]
    for n, (ten, nd) in enumerate(cac_buoc(ds), 1):
        d.append("%d. %s: %s" % (n, ten, nd))
    d += [""] + ["- " + x for x in GHI_CHU]
    return "\n".join(d) + "\n"


# ------------------------------------------------------------------ dong goi
def _thu_muc_moi(ra):
    goc = os.path.join(ra, "NOP_DVC_" + datetime.now().strftime("%Y%m%d_%H%M"))
    p, n = goc, 1
    while os.path.exists(p):
        n += 1
        p = "%s_%d" % (goc, n)
    os.makedirs(p)
    return p


def dong_goi(nguon, ra, mst="", ten_cty="", htkk_goc="", thu_muc_khach="", ep=False, so_sanh=True, log=None):
    """Chep NGUYEN BYTE cac tep XML da chon vao thu muc moi <ra>\\NOP_DVC_<ngay_gio>, kem 0_PHIEU_NOP.html, 0_PHIEU_NOP.txt.
       Tep co loi [!] bi bo (tru khi ep). -> dict(thu_muc, phieu, goi=[...], bo=[(tep, ly do)], kq)."""
    log = log or (lambda s: None)
    if not ra:
        raise ValueError("chưa có thư mục để lưu hồ sơ")
    kq = quet(nguon, mst, ten_cty, htkk_goc, thu_muc_khach, so_sanh, log)
    chon, bo = [], []
    for r in kq["ds"]:
        if r["trang_thai"] == "CHAN" and not ep:
            bo.append((r["ten_tep"], "có lỗi [!]: " + _sach(next((s for m, s in r["kiem"] if m == "!"), ""))[:200]))
        else:
            chon.append(r)
    for r in kq["khac"]:
        bo.append((r["ten_tep"], "không phải tờ khai XML của HTKK"))
    if not chon:
        raise ValueError("không có tờ khai nào đủ điều kiện đóng gói (%s)" % ("; ".join("%s: %s" % x for x in bo[:3]) or "không thấy tệp XML"))
    os.makedirs(ra, exist_ok=True)
    thu_muc = _thu_muc_moi(ra)
    goi = []
    for i, r in enumerate(chon, 1):
        ten = "%02d_%s" % (i, re.sub(r"[^A-Za-z0-9._()-]+", "_", r["ten_tep"]))
        dich = os.path.join(thu_muc, ten)
        shutil.copyfile(r["tep"], dich)
        if sha256_tep(dich) != r["sha"]:
            raise ValueError("chép tệp %s không khớp mã SHA-256" % r["ten_tep"])
        r["ten_goi"] = ten
        goi.append(dich)
    phieu = os.path.join(thu_muc, "0_PHIEU_NOP.html")
    with open(phieu, "w", encoding="utf-8-sig", newline="\r\n") as f:
        f.write(phieu_html(kq, chon, "Thư mục: %s" % os.path.basename(thu_muc)))
    with open(os.path.join(thu_muc, "0_PHIEU_NOP.txt"), "w", encoding="utf-8-sig", newline="\r\n") as f:
        f.write(phieu_txt(kq, chon))
    log("[NOP DVC] dong goi %d to khai, bo %d tep" % (len(goi), len(bo)))
    return {"thu_muc": thu_muc, "phieu": phieu, "goi": goi, "bo": bo, "kq": kq}


def xem_truoc_html(nguon, duong, mst="", ten_cty="", htkk_goc="", thu_muc_khach="", so_sanh=False, log=None):
    """Phieu xem truoc (chua dong goi): tat ca to khai tim thay -> mot tep HTML de VB mo bang trinh duyet. -> duong."""
    kq = quet(nguon, mst, ten_cty, htkk_goc, thu_muc_khach, so_sanh, log)
    if not kq["ds"]:
        raise ValueError("không thấy tờ khai XML nào để hiển thị")
    os.makedirs(os.path.dirname(os.path.abspath(duong)), exist_ok=True)
    with open(duong, "w", encoding="utf-8-sig", newline="\r\n") as f:
        f.write(phieu_html(kq, kq["ds"], "Bản xem trước - chưa đóng gói."))
    return duong


# ------------------------------------------------------------------ vao tool
def chay(nguon, che_do="quet", mst="", ten_cty="", htkk_goc="", thu_muc_khach="", ra="", ep=False, so_sanh=True, log=None, ket_qua_dir=""):
    """-> duong tep ket qua (cho moc DA_XONG_KHOASO). che_do: quet | goi | xem."""
    log = log or (lambda s: None)
    kd = ket_qua_dir or os.path.join(os.path.dirname(os.path.abspath(__file__)), "ket-qua")
    che_do = (che_do or "quet").strip().lower()
    if che_do == "goi":
        g = dong_goi(nguon, ra, mst, ten_cty, htkk_goc, thu_muc_khach, ep, so_sanh, log)
        tep = os.path.join(kd, "NOP_DVC_GOI.txt")
        os.makedirs(kd, exist_ok=True)
        dong = ["THUMUC\t" + _sach(g["thu_muc"]), "PHIEU\t" + _sach(g["phieu"])]
        dong += ["TEP\t" + _sach(x) for x in g["goi"]]
        dong += ["BO\t%s\t%s" % (_sach(a), _sach(b)) for a, b in g["bo"]]
        with open(tep, "w", encoding="utf-8-sig", newline="\r\n") as f:
            f.write("\n".join(dong) + "\n")
        return g["phieu"]
    if che_do == "xem":
        return xem_truoc_html(nguon, ra or os.path.join(kd, "NOP_DVC_XEM.html"), mst, ten_cty, htkk_goc, thu_muc_khach, False, log)
    kq = quet(nguon, mst, ten_cty, htkk_goc, thu_muc_khach, so_sanh, log)
    return ghi_ket_quet(kq, os.path.join(kd, "NOP_DVC.txt"))
