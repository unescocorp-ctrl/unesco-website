# -*- coding: utf-8 -*-
"""GD170 - THEO DOI MAU TO KHAI MOI TREN HTKK (chi DOC Project\\Menu.xml cua HTKK - khong sua HTKK, khong doi mau dang xuat).

Moi lan tool chay viec lien quan HTKK (xuat XML, xem truoc, nhap theo MST, dua vao HTKK) hoac VB goi /maumoi:1, ham quet():
  1. doc danh muc to khai HTKK (MaFile, MaToKhai, VersionXML, ten) qua htkk_dua_vao.doc_menu;
  2. so voi ban da biet lan truoc (ket-qua\\htkk_mau_da_biet.json): MaFile moi, phien ban XML doi;
  3. so voi cac ho to khai UNESCO dang xuat (UNESCO_XUAT): HTKK da co mau cung ho theo Thong tu moi hon (vi du *_TT89) ma
     phan mem chua ho tro -> bao "can cap nhat goi" (01/GTGT TT89 phan mem da tu chon khuon tu GD65);
  4. ghi ket-qua\\htkk_mau_moi.txt (VB6 doc - dong TONG; va dong M;) + htkk_mau_moi.json.
Lan quet dau tien (chua co ban da biet): ghi ban da biet, khong bao "moi" (tranh 239 dong moi); van bao muc 3.
Chi doc; khong co HTKK / khong doc duoc Menu.xml -> ghi TONG;0;0 kem ghi chu, khong loi."""
import io
import json
import os
import re
import datetime as _dt

TEP_TXT = "htkk_mau_moi.txt"
TEP_JSON = "htkk_mau_moi.json"
TEP_DA_BIET = "htkk_mau_da_biet.json"

# ho to khai UNESCO dang xuat sang HTKK: (ma ho, ten mau, MaFile dang dung, regex MaFile cung ho, ghi chu khi HTKK co mau moi hon)
UNESCO_XUAT = [
    ("GTGT", "01/GTGT", "01_GTGT_TT89", r"^01_GTGT_TT(\d+)$",
     "Phần mềm đã hỗ trợ tới khuôn 01_GTGT_TT89 (tự chọn khi HTKK có, GĐ65); HTKK có mẫu mới hơn nữa thì cần cập nhật gói."),
    ("KK", "05/KK-TNCN", "05_KK_TNCN_TT80", r"^05_KK_TNCN_TT(\d+)$",
     "Phần mềm đang xuất theo mẫu TT80 - cần cập nhật gói để xuất mẫu mới; tạm thời nhập XML mẫu cũ rồi đối chiếu trên HTKK."),
    ("TNDN", "03/TNDN", "03_TNDN_TT80", r"^03_TNDN_TT(\d+)$",
     "Phần mềm đang xuất theo mẫu TT80 - cần cập nhật gói để xuất mẫu mới; tạm thời nhập XML mẫu cũ rồi đối chiếu trên HTKK."),
    ("QTT", "05/QTT-TNCN", "05_QTT_TNCN_TT80", r"^05_QTT_TNCN_TT(\d+)$",
     "Phần mềm đang xuất theo mẫu TT80 - cần cập nhật gói để xuất mẫu mới; tạm thời nhập XML mẫu cũ rồi đối chiếu trên HTKK."),
    ("LPMB", "01/LPMB", "01_LPMB_TT80", r"^01_LPMB_TT(\d+)$",
     "Lệ phí môn bài bỏ từ 01/01/2026 (NQ 198/2025) - chỉ ghi nhận, không cần làm gì."),
    ("CNKD", "01/CNKD", "01_CNKD_HKD_TT50", r"^01_CNKD_HKD_TT(\d+)$",
     "Phần mềm lập 01/CNKD theo mẫu TT 50/2026 (GĐ172) - HTKK có mẫu hộ kinh doanh mới hơn thì cần cập nhật gói."),
]
# ho to khai lien quan ma UNESCO chua xuat (chi theo doi de bao)
THEO_DOI_THEM = [("BCTC58", "BCTC TT 58/2026 (DN siêu nhỏ)", r"^58_BCTC"), ("TKN", "01/TKN-CNKD thông báo doanh thu hộ", r"^01_TKN_CNKD"),
                 ("BCTC133", "BCTC TT 133", r"^133_B01"), ("BCTC99", "BCTC TT 99", r"^99_BCTC")]
# MaFile bo qua khi so sanh "moi" (bang ke, phu luc, mau dang ky): chi bao to khai chinh
_BO_QUA = re.compile(r"^(KHBS|PL_|BK_|BANGKE|TT_)", re.I)


def _so_tt(ma_file, rx):
    m = re.match(rx, ma_file or "", re.I)
    if not m or not m.groups():
        return 0
    try:
        return int(m.group(1))
    except ValueError:
        return 0


def _doc_json(p):
    try:
        with io.open(p, "r", encoding="utf-8-sig") as f:
            return json.load(f)
    except Exception:
        return None


def _ghi_json(p, d):
    tam = p + ".tam"
    with io.open(tam, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1)
    os.replace(tam, p)


def doc_menu(goc_htkk):
    """-> {MaFile: {MaToKhai, VersionXML, ten}} (rong neu khong doc duoc)."""
    try:
        import htkk_dua_vao as DV
        ds = DV.doc_menu(goc_htkk)
    except Exception:
        return {}
    ra = {}
    for m in ds:
        mf = (m.get("MaFile") or "").strip()
        if not mf:
            continue
        ra[mf] = {"ma": m.get("MaToKhai") or "", "pban": m.get("VersionXML") or "", "ten": (m.get("ten") or "").strip()}
    return ra


def so_sanh(menu, da_biet):
    """-> (moi: [(MaFile, ten, pban)], doi: [(MaFile, ten, pban cu, pban moi)]) - chi to khai chinh."""
    moi, doi = [], []
    cu = (da_biet or {}).get("mau") or {}
    for mf in sorted(menu):
        if _BO_QUA.match(mf):
            continue
        x = menu[mf]
        if mf not in cu:
            moi.append((mf, x["ten"], x["pban"]))
        elif (cu[mf].get("pban") or "") != (x["pban"] or ""):
            doi.append((mf, x["ten"], cu[mf].get("pban") or "", x["pban"] or ""))
    return moi, doi


def mau_hon_unesco(menu):
    """HTKK co mau cung ho theo Thong tu moi hon mau UNESCO dang xuat -> [(ma ho, ten mau, MaFile dang dung, MaFile moi, pban, ghi chu)]."""
    ra = []
    for ho, ten, dang_dung, rx, ghi_chu in UNESCO_XUAT:
        so_cu = _so_tt(dang_dung, rx)
        for mf in sorted(menu):
            so = _so_tt(mf, rx)
            if so and so > so_cu and mf != dang_dung:
                ra.append((ho, ten, dang_dung, mf, menu[mf]["pban"], ghi_chu))
    return ra


def co_them(menu):
    """ho to khai lien quan UNESCO chua xuat: [(ma, ten, [MaFile...])]."""
    ra = []
    for ma, ten, rx in THEO_DOI_THEM:
        ds = [mf for mf in sorted(menu) if re.match(rx, mf, re.I)]
        if ds:
            ra.append((ma, ten, ds))
    return ra


def quet(goc_htkk, thu_kq, phien_ban="", log=None):
    """-> dict ket qua (da ghi txt + json). Khong nem loi."""
    os.makedirs(thu_kq, exist_ok=True)
    gio = _dt.datetime.now().strftime("%d/%m/%Y %H:%M")
    kq = {"ngay": gio, "htkk": goc_htkk or "", "phien_ban": phien_ban or "", "doc_duoc": False, "lan_dau": False,
          "moi": [], "doi": [], "hon_unesco": [], "them": [], "so_mau": 0, "ghi_chu": ""}
    menu = doc_menu(goc_htkk) if goc_htkk else {}
    if not menu:
        kq["ghi_chu"] = ("Không tìm thấy HTKK trên máy" if not goc_htkk else "Không đọc được Project\\Menu.xml của HTKK") + " - chưa quét được mẫu mới."
        _ghi(thu_kq, kq)
        if log:
            log("[MAU MOI HTKK] " + kq["ghi_chu"])
        return kq
    kq["doc_duoc"] = True
    kq["so_mau"] = len(menu)
    p_db = os.path.join(thu_kq, TEP_DA_BIET)
    da_biet = _doc_json(p_db)
    if not isinstance(da_biet, dict) or not isinstance(da_biet.get("mau"), dict):
        kq["lan_dau"] = True
        da_biet = None
    else:
        moi, doi = so_sanh(menu, da_biet)
        kq["moi"] = [list(x) for x in moi]
        kq["doi"] = [list(x) for x in doi]
    cu = ((da_biet or {}).get("mau") or {})
    hon = [x for x in mau_hon_unesco(menu) if x[3] not in cu]          # da "Da xem" (co trong moc) thi khong bao lai
    kq["hon_unesco"] = [list(x) for x in hon]
    kq["them"] = [list(x) for x in co_them(menu)]
    # ban da biet: lan dau ghi toan bo (tru cac mau "hon UNESCO" de con bao den khi Da xem); cac lan sau GIU ban cu (VB "Da xem" moi doi)
    if da_biet is None:
        bo = set(x[3] for x in hon)
        _ghi_json(p_db, {"ngay": gio, "phien_ban": phien_ban or "", "mau": {k: {"pban": v["pban"], "ten": v["ten"]} for k, v in menu.items() if k not in bo}})
    kq["ghi_chu"] = "Lần quét đầu: ghi nhận %d mẫu hiện có làm mốc, từ lần sau báo mẫu mới / đổi phiên bản." % len(menu) if kq["lan_dau"] else ""
    _ghi(thu_kq, kq)
    if log:
        log("[MAU MOI HTKK] %d mau, %d moi, %d doi phien ban, %d mau moi hon UNESCO%s" % (
            len(menu), len(kq["moi"]), len(kq["doi"]), len(kq["hon_unesco"]), " (lan dau)" if kq["lan_dau"] else ""))
    return kq


def da_xem(thu_kq, goc_htkk):
    """Nguoi dung da xem (VB: nut Da xem) -> ban da biet = danh muc hien tai; lan sau khong bao lai. -> so mau."""
    menu = doc_menu(goc_htkk) if goc_htkk else {}
    if not menu:
        return 0
    os.makedirs(thu_kq, exist_ok=True)
    _ghi_json(os.path.join(thu_kq, TEP_DA_BIET), {"ngay": _dt.datetime.now().strftime("%d/%m/%Y %H:%M"), "phien_ban": "",
                                                   "mau": {k: {"pban": v["pban"], "ten": v["ten"]} for k, v in menu.items()}})
    kq = quet(goc_htkk, thu_kq)
    return kq.get("so_mau", 0)


def _sach(s, n=200):
    return re.sub(r"[;\r\n\t]+", " ", str(s or "")).strip()[:n]


def _ghi(thu_kq, kq):
    """txt cho VB6: TONG;so moi;so doi;so mau hon UNESCO;ngay quet;phien ban HTKK;so mau;ghi chu
                    M;MOI;MaFile;ten;pban  |  M;DOI;MaFile;ten;pban cu -> pban moi  |  M;HON;ho;ten mau;MaFile dang dung;MaFile moi;ghi chu
                    M;THEM;ma;ten;MaFile,MaFile..."""
    d = ["TONG;%d;%d;%d;%s;%s;%d;%s" % (len(kq["moi"]), len(kq["doi"]), len(kq["hon_unesco"]), kq["ngay"], _sach(kq["phien_ban"], 40),
                                        kq["so_mau"], _sach(kq["ghi_chu"]))]
    for mf, ten, pb in kq["moi"]:
        d.append("M;MOI;%s;%s;%s" % (_sach(mf, 60), _sach(ten, 120), _sach(pb, 20)))
    for mf, ten, pb1, pb2 in kq["doi"]:
        d.append("M;DOI;%s;%s;%s -> %s" % (_sach(mf, 60), _sach(ten, 120), _sach(pb1, 20), _sach(pb2, 20)))
    for ho, ten, dd, mf, pb, gc in kq["hon_unesco"]:
        d.append("M;HON;%s;%s;%s;%s;%s" % (ho, _sach(ten, 40), _sach(dd, 60), _sach(mf, 60), _sach(gc, 300)))
    for ma, ten, ds in kq["them"]:
        d.append("M;THEM;%s;%s;%s" % (ma, _sach(ten, 60), ",".join(ds)[:300]))
    p = os.path.join(thu_kq, TEP_TXT)
    tam = p + ".tmp"
    with io.open(tam, "w", encoding="utf-8") as f:
        f.write("\n".join(d) + "\n")
    os.replace(tam, p)
    try:
        _ghi_json(os.path.join(thu_kq, TEP_JSON), kq)
    except Exception:
        pass
    return p


# cac che do tool co lien quan HTKK -> quet sau khi xong (tool_htkk_unesco goi o __main__)
CHE_DO_QUET = ("/xuat:", "/sosanhhtkk:", "/nhaphtkk:", "/duavaohtkk:", "/xemtruoc:", "/tokhai:")


def quet_sau_tool(tham_so, tim_htkk, base_dir, log=None, mo_rong=None):
    """Goi sau main() cua tool_htkk_unesco: neu che do lien quan HTKK thi quet (im lang, khong nem loi).
    mo_rong: ham mo rong /thamso:<tep> (VB luon goi tool qua tep tham so) - tool_htkk_unesco.mo_rong_tham_so."""
    try:
        ds = [str(a) for a in tham_so]
        if mo_rong and any(a.lower().startswith("/thamso:") for a in ds):
            ds = [str(a) for a in mo_rong(ds)]
        if not any(a.lower().startswith(CHE_DO_QUET) for a in ds):
            return None
        goi_y = ""
        for a in ds:
            if a.lower().startswith("/htkk:"):
                goi_y = a[6:].strip('"')
        h = tim_htkk(goi_y) if tim_htkk else None
        goc = (h or {}).get("goc", "") if isinstance(h, dict) else ""
        pb = (h or {}).get("phien_ban", "") if isinstance(h, dict) else ""
        return quet(goc, os.path.join(base_dir, "ket-qua"), pb, log)
    except Exception as e:
        if log:
            log("[MAU MOI HTKK] loi quet: %s" % e)
        return None


if __name__ == "__main__":
    import sys
    print(json.dumps(quet(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else "."), ensure_ascii=False, indent=1))
