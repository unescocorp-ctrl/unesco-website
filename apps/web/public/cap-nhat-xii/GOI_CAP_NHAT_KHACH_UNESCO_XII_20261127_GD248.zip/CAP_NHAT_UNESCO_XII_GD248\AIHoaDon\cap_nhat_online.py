# -*- coding: utf-8 -*-
"""GD143 - CAP NHAT PHAN MEM TU DONG qua KENH CAP NHAT co CHU KY SO (Ed25519).

KENH CAP NHAT = mot thu muc (o mang, NAS, thu muc dong bo OneDrive / Google Drive) hoac dia chi web (https://...) chua:
    unesco_cap_nhat.json        mo ta goi moi nhat (goi, tep .zip, sha256, kich thuoc, ghi chu, danh muc van ban)
    unesco_cap_nhat.json.sig    chu ky Ed25519 (hex) cua dung tep tren - KY bang khoa RIENG o may phat hanh
    GOI_CAP_NHAT_KHACH_UNESCO_XI_<ngay>_<GD>.zip, cap_nhat_van_ban.txt
  (nha phat hanh tao bang _BAN_CAI_KHACH\\_CONG_CU_DONG_GOI\\TAO_KENH_CAP_NHAT.bat sau TAO_GOI_CAP_NHAT_KHACH.bat).
May khach: AIHoaDon\\cap_nhat_kenh.txt (dia chi kenh, moi dong mot dia chi) + AIHoaDon\\cap_nhat_khoa_cong_khai.txt (khoa kiem chu
ky). Chu ky sai / thieu khoa -> KHONG tai, KHONG cai. Tep tai ve kiem sha256 + kich thuoc truoc khi dung.

Dung (VB6 ModCapNhatTuDong goi; /thamso:"<tep UTF-8>" mo rong thanh tham so):
  python cap_nhat_online.py --kiem [--nen] [--kenh <dia chi>]   kiem goi moi (+ cap nhat danh muc van ban phap luat neu moi hon)
  python cap_nhat_online.py --tai [--kenh <dia chi>]            tai goi moi ve %LOCALAPPDATA%\\UNESCO_AI\\cap_nhat, kiem, giai nen
  python cap_nhat_online.py --cai --exe "<tep .exe dang chay>" [--pid <so>]
        -> mo cua so cai rieng: CHO phan mem thoat, cai bang cap_nhat_tu_dong.py (sao luu + KHOI_PHUC.bat, giu du lieu / cau hinh /
           khoa cua may), roi MO LAI phan mem.
Ket qua: AIHoaDon\\ket-qua\\cap_nhat_<kiem|tai|cai>.json + moc ket-qua\\DA_XONG_CAPNHAT ("OK <tep>" / "LOI <ly do>");
  --nen (VB6 kiem ngam moi ngay) khong ghi moc. Ket qua cai: ket-qua\\cap_nhat_ket_qua_cai.json.
KHONG ghi so ke toan, KHONG dung toi data\\*.mdb. May phat trien (thu muc du an VB6) -> khong tu cai."""
import datetime as _dt
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import time
import zipfile

PHIEN_BAN = "GD143"
HERE = os.path.dirname(os.path.abspath(__file__))
GOC = os.path.dirname(HERE)
KQ = os.path.join(HERE, "ket-qua")
TEP_KENH = os.path.join(HERE, "cap_nhat_kenh.txt")
TEP_KHOA = os.path.join(HERE, "cap_nhat_khoa_cong_khai.txt")
TEP_GOI = os.path.join(HERE, "phien_ban_goi.txt")
TEP_VB = os.path.join(HERE, "van_ban", "cap_nhat_van_ban.txt")
TEN_MF = "unesco_cap_nhat.json"
MOC = "DA_XONG_CAPNHAT"
TOOL_MOC = os.path.join("AIHoaDon", "tool_so_phu_unesco.py")
LA_WIN = os.name == "nt"
LOG = []
if HERE not in sys.path:
    sys.path.insert(0, HERE)


def ghi_log(s):
    s = "%s  %s" % (time.strftime("%Y-%m-%d %H:%M:%S"), s)
    LOG.append(s)
    try:
        os.makedirs(KQ, exist_ok=True)
        with io.open(os.path.join(KQ, "nhat-ky-cap-nhat.txt"), "a", encoding="utf-8") as f:
            f.write(s + "\n")
    except OSError:
        pass


def _in(s):
    try:
        print(s)
        sys.stdout.flush()
    except Exception:
        pass


def kho():
    """Thu muc tai ve cua may (khong nam trong thu muc phan mem - khong bi bo cap nhat chep / sao luu)."""
    b = os.environ.get("LOCALAPPDATA") or ""
    d = os.path.join(b, "UNESCO_AI", "cap_nhat") if b else os.path.join(KQ, "cap_nhat")
    os.makedirs(d, exist_ok=True)
    return d


def ghi_json(p, d):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    tam = "%s.%d.tam" % (p, os.getpid())
    with io.open(tam, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1)
    os.replace(tam, p)


def ghi_moc(noi_dung):
    """Moc DA_XONG_CAPNHAT ghi nguyen tu (VB6 khong doc phai tep dang ghi do)."""
    p = os.path.join(KQ, MOC)
    tam = "%s.%d.tam" % (p, os.getpid())
    with io.open(tam, "w", encoding="utf-8") as f:
        f.write(noi_dung)
    os.replace(tam, p)


def nhip(viec):
    """Nhip song cho VB6 (ket-qua\\cap_nhat_nhip.txt: yyyymmddhhmmss + viec) - VB6 thoi cho khi tien trinh chet."""
    try:
        os.makedirs(KQ, exist_ok=True)
        with io.open(os.path.join(KQ, "cap_nhat_nhip.txt"), "w", encoding="utf-8") as f:
            f.write("%s %s" % (time.strftime("%Y%m%d%H%M%S"), viec))
    except OSError:
        pass


def doc_json(p):
    try:
        with io.open(p, encoding="utf-8-sig") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def so_goi(s):
    """'GD143', 'GD143b', '143' -> (143, 'b'); khong doc duoc -> (0, '')."""
    m = re.search(r"(?:G[DĐ]\s*)?(\d{1,5})([a-z]?)", str(s or ""), re.I)
    return (int(m.group(1)), m.group(2).lower()) if m else (0, "")


def ten_goi(t):
    return "GĐ%d%s" % t if t[0] else "?"


def goi_dang_cai():
    try:
        with io.open(TEP_GOI, encoding="utf-8-sig") as f:
            for d in f:
                d = d.strip()
                if d and not d.startswith("#"):
                    return so_goi(d)
    except OSError:
        pass
    return (0, "")


def doc_kenh(them=None):
    ds = []
    for x in ([them] if them else []):
        if x and x.strip():
            ds.append(x.strip().strip('"'))
    try:
        with io.open(TEP_KENH, encoding="utf-8-sig") as f:
            for d in f:
                d = d.strip()
                if d and not d.startswith("#") and d not in ds:
                    ds.append(d)
    except OSError:
        pass
    return ds


def doc_khoa():
    try:
        with io.open(TEP_KHOA, encoding="utf-8-sig") as f:
            for d in f:
                d = d.strip()
                if re.match(r"^[0-9a-fA-F]{64}$", d):
                    return bytes.fromhex(d)
    except OSError:
        pass
    return None


def la_web(kenh):
    return re.match(r"^https?://", kenh, re.I) is not None


def dia_chi(kenh, ten):
    """Duong / URL cua tep 'ten' trong kenh (kenh co the la URL toi thang tep .json)."""
    if la_web(kenh):
        goc = kenh if not kenh.lower().endswith(".json") else kenh[:kenh.rfind("/") + 1]
        if not goc.endswith("/"):
            goc += "/"
        if ten == TEN_MF and kenh.lower().endswith(".json"):
            return kenh
        if ten == TEN_MF + ".sig" and kenh.lower().endswith(".json"):
            return kenh + ".sig"
        return goc + ten
    goc = os.path.dirname(kenh) if kenh.lower().endswith(".json") else kenh
    if ten == TEN_MF and kenh.lower().endswith(".json"):
        return kenh
    if ten == TEN_MF + ".sig" and kenh.lower().endswith(".json"):
        return kenh + ".sig"
    return os.path.join(goc, ten)


def _mo_web(url, han=30):
    import urllib.request
    rq = urllib.request.Request(url, headers={"User-Agent": "UNESCO-AI-CapNhat/%s" % PHIEN_BAN, "Cache-Control": "no-cache"})
    return urllib.request.urlopen(rq, timeout=han)


def doc_tu_kenh(kenh, ten, toi_da):
    p = dia_chi(kenh, ten)
    if la_web(kenh):
        with _mo_web(p) as r:
            b = r.read(toi_da + 1)
    else:
        with open(p, "rb") as f:
            b = f.read(toi_da + 1)
    if len(b) > toi_da:
        raise ValueError("tep %s qua lon" % ten)
    return b


def tai_tep(kenh, ten, dich, sha, kich):
    """Tai / chep tep ve 'dich', kiem kich thuoc + sha256; sai -> xoa, nem loi."""
    if os.path.isfile(dich) and os.path.getsize(dich) == kich and bam(dich) == sha:
        ghi_log("Da co san (dung sha256): %s" % dich)
        return dich
    tam = dich + ".tai"
    h = hashlib.sha256()
    n = 0
    p = dia_chi(kenh, ten)
    t0 = time.time()
    try:
        nguon = _mo_web(p, 60) if la_web(kenh) else open(p, "rb")
        with nguon as r, open(tam, "wb") as f:
            moc = 0
            while True:
                k = r.read(1 << 20)
                if not k:
                    break
                n += len(k)
                if n > kich:
                    raise ValueError("tep tai ve lon hon mo ta (%d > %d byte)" % (n, kich))
                h.update(k)
                f.write(k)
                if n - moc >= (1 << 20):
                    nhip("tai %d" % n)
                if n - moc >= (2 << 20):
                    moc = n
                    ghi_log("  da tai %.1f / %.1f MB" % (n / 1048576.0, kich / 1048576.0))
                    _in(" Dang tai goi cap nhat: %.1f / %.1f MB" % (n / 1048576.0, kich / 1048576.0))
        if n != kich:
            raise ValueError("tai thieu (%d / %d byte)" % (n, kich))
        if h.hexdigest() != sha:
            raise ValueError("sai sha256 - tep hong hoac bi thay doi")
        os.replace(tam, dich)
        ghi_log("Tai xong %s: %.1f MB, %.0f giay" % (ten, n / 1048576.0, time.time() - t0))
        return dich
    except BaseException:
        try:
            os.remove(tam)
        except OSError:
            pass
        raise


def bam(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for k in iter(lambda: f.read(1 << 20), b""):
            h.update(k)
    return h.hexdigest()


def kiem_mo_ta(m):
    """Mo ta goi hop le? -> '' hoac ly do."""
    if not isinstance(m, dict) or m.get("loai") != "unesco_cap_nhat":
        return "khong phai mo ta goi cap nhat UNESCO"
    t = m.get("tep") or ""
    if not re.match(r"^[A-Za-z0-9_.-]+\.zip$", t):
        return "ten tep goi khong hop le"
    if not re.match(r"^[0-9a-f]{64}$", m.get("sha256") or ""):
        return "thieu sha256"
    if not isinstance(m.get("kich_thuoc"), int) or not 0 < m["kich_thuoc"] < (2 << 30):
        return "kich thuoc khong hop le"
    if so_goi(m.get("ten") or m.get("goi"))[0] <= 0:
        return "thieu so goi"
    vb = m.get("van_ban")
    if vb is not None:
        if not isinstance(vb, dict) or not re.match(r"^[A-Za-z0-9_.-]+\.txt$", vb.get("tep") or "") \
                or not re.match(r"^[0-9a-f]{64}$", vb.get("sha256") or ""):
            return "muc van_ban khong hop le"
    return ""


def doc_mo_ta(kenh_them=None):
    """-> (mo ta da kiem chu ky, kenh, trang thai, thong bao). trang thai: OK / CHUA_CAU_HINH / CHUA_KHOA / CHU_KY_SAI / LOI."""
    import ky_so_ed25519 as K
    ds = doc_kenh(kenh_them)
    if not ds:
        return None, "", "CHUA_CAU_HINH", "Chưa có địa chỉ kênh cập nhật (AIHoaDon\\cap_nhat_kenh.txt) - liên hệ nhà cung cấp phần mềm."
    khoa = doc_khoa()
    if khoa is None:
        return None, "", "CHUA_KHOA", ("Phần mềm chưa có khoá kiểm chữ ký cập nhật (AIHoaDon\\cap_nhat_khoa_cong_khai.txt) - cài gói "
                                       "cập nhật thủ công một lần, từ lần sau tự cập nhật.")
    loi, sai, tot = [], [], []
    for kenh in ds:                      # thu MOI kenh: lay mo ta hop le co so goi lon nhat (mot kenh hong / cu khong chan kenh khac)
        try:
            b = doc_tu_kenh(kenh, TEN_MF, 1 << 20)
            ck = doc_tu_kenh(kenh, TEN_MF + ".sig", 4096).decode("ascii", "replace").strip()
        except Exception as e:
            loi.append("%s: %s" % (kenh, e))
            ghi_log("Kenh %s: khong doc duoc (%s)" % (kenh, e))
            continue
        try:
            sig = bytes.fromhex(ck)
        except ValueError:
            sig = b""
        if not K.kiem(khoa, b, sig):
            ghi_log("Kenh %s: CHU KY SAI - bo qua" % kenh)
            sai.append(kenh)
            continue
        try:
            m = json.loads(b.decode("utf-8-sig"))
        except ValueError as e:
            loi.append("%s: mo ta hong (%s)" % (kenh, e))
            continue
        ly_do = kiem_mo_ta(m)
        if ly_do:
            loi.append("%s: %s" % (kenh, ly_do))
            continue
        tot.append((so_goi(m.get("ten") or m.get("goi")), m, kenh))
    if tot:
        tot.sort(key=lambda x: x[0], reverse=True)
        return tot[0][1], tot[0][2], "OK", ""
    if sai:
        return None, sai[0], "CHU_KY_SAI", ("Mô tả gói trên kênh %s KHÔNG đúng chữ ký của nhà phát hành (hoặc kênh đang chép dở) - không "
                                           "tải, không cài. Thử lại sau; vẫn vậy thì báo nhà cung cấp phần mềm." % sai[0])
    return None, "", "LOI", "Không đọc được kênh cập nhật: " + "; ".join(loi)[:400]


def _ngay(s):
    try:
        return _dt.datetime.strptime((s or "").strip(), "%d/%m/%Y").date()
    except ValueError:
        return None


def _ngay_danh_muc(b):
    m = re.search(r"NGAY_DANH_MUC=(\d\d/\d\d/\d{4})", b.decode("utf-8", "replace"))
    return _ngay(m.group(1)) if m else None


def cap_nhat_van_ban(kenh, vb):
    """Danh muc van ban phap luat tren kenh (da ky qua sha256 trong mo ta) moi hon ban tren may -> thay (giu ban cu)."""
    try:
        b = doc_tu_kenh(kenh, vb["tep"], 4 << 20)
        if hashlib.sha256(b).hexdigest() != vb["sha256"]:
            return "LOI sai sha256"
        cu = b""
        if os.path.isfile(TEP_VB):
            with open(TEP_VB, "rb") as f:
                cu = f.read()
        if cu == b:
            return "GIU"
        nc, nm = _ngay_danh_muc(cu), _ngay_danh_muc(b)
        if nc and nm and nm < nc:
            return "GIU (ban tren may moi hon)"
        os.makedirs(os.path.dirname(TEP_VB), exist_ok=True)
        if cu:
            d = os.path.join(os.path.dirname(TEP_VB), "_cu")
            os.makedirs(d, exist_ok=True)
            with open(os.path.join(d, "cap_nhat_van_ban_%s.txt" % time.strftime("%Y%m%d_%H%M%S")), "wb") as f:
                f.write(cu)
        tam = TEP_VB + ".tam"
        with open(tam, "wb") as f:
            f.write(b)
        os.replace(tam, TEP_VB)
        ghi_log("Da cap nhat danh muc van ban phap luat (ngay %s)" % (nm.strftime("%d/%m/%Y") if nm else "?"))
        return "MOI"
    except Exception as e:
        return "LOI %s" % e


def kiem(kenh_them=None, nen=False):
    dc = goi_dang_cai()
    kq = {"lenh": "kiem", "phien_ban": PHIEN_BAN, "luc": time.strftime("%d/%m/%Y %H:%M"), "goi_dang_cai": ten_goi(dc),
          "goi_dang_cai_so": dc[0], "nen": nen}
    m, kenh, tt, tb = doc_mo_ta(kenh_them)
    kq.update(trang_thai=tt, kenh=kenh, thong_bao=tb)
    if m:
        moi = so_goi(m.get("ten") or m.get("goi"))
        gc = m.get("ghi_chu") or []
        if isinstance(gc, str):
            gc = [gc]
        kq.update(goi_moi=ten_goi(moi), goi_moi_so=moi[0], ngay=m.get("ngay") or "", kich_thuoc=m["kich_thuoc"],
                  co_exe=bool(m.get("co_exe")), bat_buoc=bool(m.get("bat_buoc")), ghi_chu=[str(x)[:300] for x in gc[:20]],
                  ghi_chu_chu="\n".join("- " + str(x)[:300] for x in gc[:12]))
        if m.get("van_ban"):
            kq["van_ban"] = cap_nhat_van_ban(kenh, m["van_ban"])
        if moi > dc:
            kq["trang_thai"] = "MOI"
            kq["thong_bao"] = "Có bản cập nhật %s (%s, %.1f MB) - phần mềm đang ở %s." % (
                ten_goi(moi), m.get("ngay") or "?", m["kich_thuoc"] / 1048576.0, ten_goi(dc))
        else:
            kq["trang_thai"] = "DA_MOI_NHAT"
            kq["thong_bao"] = "Đang dùng bản mới nhất (%s)." % ten_goi(dc)
        if kq.get("van_ban") == "MOI":
            kq["thong_bao"] += " Đã cập nhật danh mục văn bản pháp luật."
    ghi_log("Kiem cap nhat: %s - %s" % (kq["trang_thai"], kq.get("thong_bao", "")))
    return kq


def _giai_nen(zp, dich):
    """Giai nen an toan (khong cho duong dan ra ngoai thu muc dich) -> thu muc goc goi (co AIHoaDon\\tool_so_phu_unesco.py)."""
    if os.path.isdir(dich):
        shutil.rmtree(dich, ignore_errors=True)
    os.makedirs(dich, exist_ok=True)
    goc_dich = os.path.realpath(dich)
    with zipfile.ZipFile(zp) as z:
        for ten in z.namelist():
            p = os.path.realpath(os.path.join(dich, ten))
            if not (p == goc_dich or p.startswith(goc_dich + os.sep)):
                raise ValueError("goi co duong dan khong hop le: %s" % ten)
        z.extractall(dich)
    goc = dich
    for _ in range(3):
        if os.path.isfile(os.path.join(goc, TOOL_MOC)):
            return goc
        con = [os.path.join(goc, x) for x in os.listdir(goc) if os.path.isdir(os.path.join(goc, x))]
        if len(con) != 1:
            break
        goc = con[0]
    if os.path.isfile(os.path.join(goc, TOOL_MOC)):
        return goc
    raise ValueError("goi khong co AIHoaDon\\tool_so_phu_unesco.py")


def tai(kenh_them=None):
    kq = {"lenh": "tai", "phien_ban": PHIEN_BAN, "luc": time.strftime("%d/%m/%Y %H:%M")}
    m, kenh, tt, tb = doc_mo_ta(kenh_them)
    if not m:
        kq.update(trang_thai=tt, thong_bao=tb)
        return kq
    moi, dc = so_goi(m.get("ten") or m.get("goi")), goi_dang_cai()
    if moi <= dc:
        kq.update(trang_thai="DA_MOI_NHAT", thong_bao="Đang dùng bản mới nhất (%s) - không cần tải." % ten_goi(dc))
        return kq
    K = kho()
    _in(" UNESCO XI - TAI GOI CAP NHAT %s (%.1f MB) - cua so nay tu dong khi xong." % (ten_goi(moi), m["kich_thuoc"] / 1048576.0))
    nhip("bat dau tai")
    try:
        zp = tai_tep(kenh, m["tep"], os.path.join(K, m["tep"]), m["sha256"], m["kich_thuoc"])
        nhip("giai nen")
        goc = _giai_nen(zp, os.path.join(K, "%s_%s" % (os.path.splitext(m["tep"])[0], time.strftime("%Y%m%d%H%M%S"))))
        if not os.path.isfile(os.path.join(goc, "AIHoaDon", "cap_nhat_tu_dong.py")):
            raise ValueError("goi thieu bo cap nhat (AIHoaDon\\cap_nhat_tu_dong.py)")
        trong = goi_trong(goc)
        if trong[0] and trong != moi:
            raise ValueError("so goi trong tep (%s) khac mo ta (%s)" % (ten_goi(trong), ten_goi(moi)))
        for t in os.listdir(K):                     # chi giu goi vua tai
            p = os.path.join(K, t)
            if t.startswith("GOI_") and p != zp and not os.path.normcase(goc).startswith(os.path.normcase(p + os.sep)) \
                    and os.path.normcase(p) != os.path.normcase(goc):
                if os.path.isdir(p):
                    shutil.rmtree(p, ignore_errors=True)
                else:
                    try:
                        os.remove(p)
                    except OSError:
                        pass
        da = {"goi": ten_goi(moi), "goi_so": moi[0], "zip": zp, "sha256": m["sha256"], "thu_muc": goc, "luc": kq["luc"],
              "co_exe": bool(m.get("co_exe"))}
        ghi_json(os.path.join(K, "da_tai.json"), da)
        kq.update(trang_thai="DA_TAI", goi_moi=ten_goi(moi), thong_bao="Đã tải và kiểm tra gói %s (%.1f MB)." % (
            ten_goi(moi), m["kich_thuoc"] / 1048576.0))
    except Exception as e:
        ghi_log("Tai goi loi: %s" % e)
        kq.update(trang_thai="LOI", thong_bao="Không tải được gói cập nhật: %s" % e)
    return kq


def goi_trong(goc):
    try:
        with io.open(os.path.join(goc, "AIHoaDon", "phien_ban_goi.txt"), encoding="utf-8-sig") as f:
            for d in f:
                if d.strip() and not d.startswith("#"):
                    return so_goi(d)
    except OSError:
        pass
    return (0, "")


def _python_cua_so():
    """python.exe (co cua so) cung thu muc voi trinh dang chay (pythonw.exe -> python.exe)."""
    e = sys.executable or "python"
    d, t = os.path.split(e)
    if t.lower() == "pythonw.exe" and os.path.isfile(os.path.join(d, "python.exe")):
        return os.path.join(d, "python.exe")
    return e


def cai(exe, pid=0):
    kq = {"lenh": "cai", "phien_ban": PHIEN_BAN, "luc": time.strftime("%d/%m/%Y %H:%M")}
    K = kho()
    da = doc_json(os.path.join(K, "da_tai.json"))
    try:
        if not da or not os.path.isfile(da.get("zip", "")) or not os.path.isdir(da.get("thu_muc", "")):
            raise ValueError("chưa tải gói cập nhật (bấm Kiểm tra cập nhật để tải lại)")
        if bam(da["zip"]) != da.get("sha256"):
            raise ValueError("tệp gói đã tải bị thay đổi - tải lại")
        if so_goi(da.get("goi")) <= goi_dang_cai():
            raise ValueError("gói đã tải (%s) không mới hơn bản đang dùng (%s)" % (da.get("goi"), ten_goi(goi_dang_cai())))
        sys.path.insert(0, os.path.join(da["thu_muc"], "AIHoaDon"))
        import cap_nhat_tu_dong as C
        if C.la_du_an(GOC):
            raise ValueError("đây là thư mục DỰ ÁN VB6 (máy phát triển) - không tự cập nhật; dùng gói cập nhật thủ công")
        if C.loai_dich(GOC) != "NOI_CHAY":
            raise ValueError("không nhận ra thư mục cài phần mềm (%s)" % GOC)
        exe = _exe_cua_pid(pid) or os.path.abspath(exe or "")          # VB6 App.Path la ANSI - uu tien duong that theo pid
        if not os.path.isfile(exe) or os.path.normcase(os.path.dirname(exe)) != os.path.normcase(GOC):
            raise ValueError("tệp chương trình đang chạy không nằm trong thư mục cài (%s)" % exe)
        if (C.exe_cua(GOC) or "").lower() != os.path.basename(exe).lower():
            raise ValueError("thư mục cài có nhiều tệp chương trình (%s, %s) - bộ cập nhật sẽ thay %s, không phải tệp đang chạy; "
                             "cập nhật thủ công bằng gói cập nhật" % (os.path.basename(exe), C.exe_cua(GOC), C.exe_cua(GOC)))
        kh = {"goc": GOC, "exe": exe, "pid": int(pid or 0), "thu_muc_goi": da["thu_muc"], "zip": da["zip"], "goi": da["goi"],
              "ket_qua": os.path.join(KQ, "cap_nhat_ket_qua_cai.json"), "luc": kq["luc"]}
        p_kh = os.path.join(K, "ke_hoach_cai.json")
        ghi_json(p_kh, kh)
        cho = os.path.join(K, "cap_nhat_cho_cai.py")
        shutil.copy2(os.path.abspath(__file__), cho)
        lenh = [_python_cua_so(), cho, "--cho-cai", p_kh]
        if LA_WIN:
            subprocess.Popen(lenh, cwd=K, creationflags=0x00000010 | 0x00000200, close_fds=True)   # cua so moi, nhom tien trinh rieng
        else:
            subprocess.Popen(lenh, cwd=K, close_fds=True, start_new_session=True)
        ghi_log("Da mo cua so cai %s - cho phan mem thoat" % da["goi"])
        kq.update(trang_thai="SAN_SANG", goi_moi=da["goi"],
                  thong_bao="Đã sẵn sàng cài %s: phần mềm sẽ đóng, cửa sổ cài đặt chạy rồi tự mở lại phần mềm." % da["goi"])
    except Exception as e:
        ghi_log("Cai loi: %s" % e)
        kq.update(trang_thai="LOI", thong_bao="Không cài được: %s" % e)
    return kq


def _exe_cua_pid(pid):
    """Windows: duong day du (Unicode) cua tep .exe tien trinh pid; '' neu khong lay duoc."""
    if not LA_WIN or not pid:
        return ""
    try:
        import ctypes
        from ctypes import wintypes
        k = ctypes.windll.kernel32
        h = k.OpenProcess(0x1000, False, int(pid))                   # PROCESS_QUERY_LIMITED_INFORMATION
        if not h:
            return ""
        try:
            buf = ctypes.create_unicode_buffer(32768)
            n = wintypes.DWORD(32768)
            if k.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(n)):
                return buf.value
        finally:
            k.CloseHandle(h)
    except Exception:
        pass
    return ""


def _cho_thoat(pid, exe, han=240):
    """Cho tien trinh pid (hoac ten exe) thoat. True = da thoat."""
    if LA_WIN and pid:
        try:
            import ctypes
            k = ctypes.windll.kernel32
            h = k.OpenProcess(0x00100000, False, int(pid))          # SYNCHRONIZE
            if h:
                r = k.WaitForSingleObject(h, int(han * 1000))
                k.CloseHandle(h)
                return r == 0
            return True                                             # khong mo duoc = da thoat
        except Exception:
            pass
    t0 = time.time()
    ten = os.path.basename(exe)
    while time.time() - t0 < han:
        try:
            out = subprocess.run(["tasklist", "/NH", "/FI", "IMAGENAME eq %s" % ten], capture_output=True, text=True, timeout=20).stdout
        except Exception:
            return True
        if ten.lower() not in out.lower():
            return True
        time.sleep(1.5)
    return False


def cho_cai(p_kh):
    """Tien trinh rieng (cua so CMD): cho phan mem thoat -> cai -> mo lai (luon mo lai, ke ca khi loi)."""
    kh = doc_json(p_kh) or {}
    p_kq = kh.get("ket_qua") or os.path.join(KQ, "cap_nhat_ket_qua_cai.json")
    kq = {"goi": kh.get("goi"), "luc": time.strftime("%d/%m/%Y %H:%M"), "da_bao": False, "ket_qua": "LOI",
          "thong_bao": "Cập nhật chưa chạy xong."}
    ok, cho_xong = False, False
    try:
        print("=" * 70)
        print(" CAP NHAT PHAN MEM UNESCO XI + AI - goi %s" % kh.get("goi", "?"))
        print("=" * 70)
        print(" Dang cho phan mem thoat (toi da 4 phut)...")
        if not _cho_thoat(kh.get("pid"), kh.get("exe", ""), 240):
            kq.update(thong_bao="Phần mềm chưa thoát sau 4 phút - huỷ cập nhật, mở lại phần mềm rồi thử lại.")
            print(" [LOI] Phan mem chua thoat sau 4 phut - huy cap nhat.")
            return 2
        cho_xong = True
        time.sleep(2)
        goi_dir = kh["thu_muc_goi"]
        pb = os.path.join(goi_dir, "AIHoaDon", "phien_ban_goi.txt")
        pb_giu = pb + ".cho_cai"
        if os.path.isfile(pb):                    # so goi chi ghi SAU KHI cai xong (cai do dang -> lan sau van thay ban moi)
            os.replace(pb, pb_giu)
        sys.path.insert(0, os.path.join(goi_dir, "AIHoaDon"))
        rc = 1
        try:
            import cap_nhat_tu_dong as C
            rc = C.main(["--goi", goi_dir, "--dich", kh["goc"], "--khong-hoi", "--khong-quet"])
            for d in getattr(C, "LOG", [])[-200:]:
                ghi_log("  [cap_nhat_tu_dong] " + str(d))
        except Exception as e:
            print(" [LOI] %s" % e)
            ghi_log("cho_cai: loi bo cap nhat: %s" % e)
        if rc == 0 and os.path.isfile(pb_giu):
            shutil.copy2(pb_giu, os.path.join(kh["goc"], "AIHoaDon", "phien_ban_goi.txt"))
        if os.path.isfile(pb_giu):
            os.replace(pb_giu, pb)
        moi = goi_trong(kh["goc"])
        ok = rc == 0 and so_goi(kh.get("goi")) == moi
        kq.update(ket_qua="OK" if ok else "LOI", rc=rc, goi_sau=ten_goi(moi),
                  thong_bao=("Đã cập nhật phần mềm lên %s." % kh.get("goi")) if ok else
                  ("Cập nhật %s chưa xong (mã %s) - phần mềm vẫn ở %s; bấm Cập nhật phần mềm để thử lại. Nhật ký: AIHoaDon\\ket-qua\\"
                   "nhat-ky-cap-nhat.txt; bản cũ đã sao lưu (_sao_luu_*, KHOI_PHUC.bat)." % (kh.get("goi"), rc, ten_goi(moi))))
        return 0 if ok else 1
    except Exception as e:
        kq.update(thong_bao="Cập nhật lỗi: %s" % e)
        ghi_log("cho_cai: %s" % e)
        return 1
    finally:
        try:
            ghi_json(p_kq, kq)
        except Exception:
            pass
        print("")
        print(" %s" % ("XONG - dang mo lai phan mem..." if ok else "CHUA XONG - xem nhat ky AIHoaDon\\ket-qua\\nhat-ky-cap-nhat.txt"))
        if cho_xong or ok:
            try:
                if LA_WIN:
                    os.startfile(kh["exe"])        # nhu nhap dup (ke ca .exe can quyen quan tri)
            except Exception as e:
                print(" Khong mo lai duoc phan mem: %s - mo lai bang tay." % e)
        if ok:
            time.sleep(4)
        else:
            _dung()


def _dung():
    try:
        input(" Bam Enter de dong cua so...")
    except Exception:
        time.sleep(10)


def _tach(s):
    ra, cur, trong = [], "", False
    for c in s:
        if c == '"':
            trong = not trong
        elif c.isspace() and not trong:
            if cur:
                ra.append(cur)
                cur = ""
        else:
            cur += c
    if cur:
        ra.append(cur)
    return ra


def tham_so(argv):
    ra = []
    for a in argv:
        if a.startswith("/thamso:"):
            p = a[len("/thamso:"):].strip('"')
            try:
                with io.open(p, encoding="utf-8-sig") as f:
                    ra.extend(_tach(f.read()))
            except OSError:
                pass
            try:
                os.remove(p)
            except OSError:
                pass
        else:
            ra.append(a)
    return ra


def main(argv=None):
    a = tham_so(list(sys.argv[1:] if argv is None else argv))

    def lay(k):
        return a[a.index(k) + 1] if k in a and a.index(k) + 1 < len(a) else ""
    if "--cho-cai" in a:
        return cho_cai(lay("--cho-cai"))
    nen = "--nen" in a
    if "--kiem" in a:
        kq, ten = kiem(lay("--kenh"), nen), "cap_nhat_kiem.json"
    elif "--tai" in a:
        kq, ten = tai(lay("--kenh")), "cap_nhat_tai.json"
    elif "--cai" in a:
        kq, ten = cai(lay("--exe"), lay("--pid") or 0), "cap_nhat_cai.json"
    else:
        print(__doc__)
        return 2
    p = os.path.join(KQ, ten)
    ghi_json(p, kq)
    if not nen:
        loi = kq.get("trang_thai") in ("LOI", "CHU_KY_SAI")
        ghi_moc(("LOI " + kq.get("thong_bao", "")) if loi else ("OK " + p))
    return 0


if __name__ == "__main__":
    sys.exit(main())
