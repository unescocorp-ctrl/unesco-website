# -*- coding: utf-8 -*-
"""
tool_dvc_unesco.py - Tai du lieu Cong dich vu cong Thue (GD97-A: doc bang tren man hinh, ca eTax trong khung) (dichvucong.gdt.gov.vn)
                     cho phan mem ke toan UNESCO XI.

BA DIEU TOOL NAY KHONG LAM (quy tac 17):
  - Khong tu dien / khong vuot captcha. Nguoi dung tu dang nhap trong Chrome cua ho.
  - Khong luu mat khau, khong luu chu ky so, khong ky thay, khong nop ho so thay.
  - Khong ghi so ke toan. Tool chi TAI VE va ghi ra file .jsonl de VB6 doc.

KHONG CAN FILE .har:
  Truoc day thiet ke doi nguoi dung xuat file .har tu DevTools de biet duong API.
  Nay tool tu nghe mang qua Chrome DevTools Protocol - dung thu ma DevTools dung
  khi xuat .har - nen nguoi dung chi can BAM DUNG CHUC NANG MOT LAN, tool ghi lai
  duong goi that roi lan sau tu chay.

  Tool KHONG BAO GIO doan duong API. Chua hoc duoc thi bao ro "chua hoc duoc",
  khong am tham tra ve 0 dong.
"""

import base64
import collections
import hashlib
import io
import json
import html.parser
import os
import re
import socket
import struct
import subprocess
import sys
import threading
import time
import urllib.parse
import urllib.request
from datetime import datetime, date, timedelta

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

if __name__ == "__main__":          # GD111: lien ket .py cua Python install manager / Store bo mat tham so VB6
    try:
        import tham_so_du_phong as _TSDP
        sys.argv = _TSDP.bu_tham_so(sys.argv, BASE_DIR, khong_co=("/hoi:",))
    except Exception:
        pass

SETTINGS_PATH = os.path.join(BASE_DIR, "cai-dat.json")
LOG_PATH = os.path.join(BASE_DIR, "nhat-ky-dvc.txt")
CHROME_HO_SO = os.path.join(BASE_DIR, "chrome-ho-so-dvc")
TRANG_DVC = "https://dichvucong.gdt.gov.vn"
TRANG_VAO = TRANG_DVC + "/tthc/dich-vu-khac"

# Ngay MOC nguoi dung go khi day tool cach goi. Chon nam cu de chac chan khong trung
# voi ngay that nao trong body, va de tool tim ra vi tri hai o ngay.
MOC_TU = date(2020, 1, 1)
MOC_DEN = date(2020, 12, 31)

TRANG_DVK = "https://dichvucong.gdt.gov.vn/tthc/dich-vu-khac"
TRANG_TCHS = "https://dichvucong.gdt.gov.vn/tthc/tchs"

# Cac man hinh tra cuu CO THAT tren cong (doi chieu thang 9/2026).
#   captcha=True  -> KHONG BAO GIO phat lai lenh goi. Moi lan tra la mot lan nguoi dung
#                    tu go ma xac nhan; tool chi hung ket qua tra ve.
#   moc_cuoi      -> cong chi tra duoc du lieu TRUOC ngay nay.
#   tep=True      -> moi dong co nut "Tai ve" ra file XML.
NHOM = collections.OrderedDict([
    ("TB", {
        "ten": "Tra cuu thong bao (Nop thue)",
        "nhan": "Tra c\u1ee9u th\u00f4ng b\u00e1o",
        "trang": TRANG_DVK,
        "duong": "Dich vu khac > To chuc > Nop thue > Tra cuu thong bao",
        "tim": ["tra c\u1ee9u th\u00f4ng b\u00e1o", "tra cuu thong bao"],
        "captcha": False, "moc_cuoi": None, "tep": True,
    }),
    ("GNT", {
        "ten": "Tra cuu GNT (giay nop tien)",
        "nhan": "Tra c\u1ee9u GNT",
        "trang": TRANG_DVK,
        "duong": "Dich vu khac > To chuc > Nop thue > Tra cuu GNT",
        "tim": ["tra c\u1ee9u gnt", "tra cuu gnt"],
        "captcha": False, "moc_cuoi": None, "tep": True,
    }),
    ("HSDVC", {
        "ten": "Tra cuu ho so da nop tren DVC",
        "nhan": "Tra c\u1ee9u h\u1ed3 s\u01a1 \u0111\u00e3 n\u1ed9p tr\u00ean DVC",
        "trang": TRANG_TCHS,
        "duong": "Tra cuu ho so > tab 'Tra cuu ho so da nop tren DVC'",
        "tim": ["\u0111\u00e3 n\u1ed9p tr\u00ean dvc", "da nop tren dvc"],
        "captcha": True, "moc_cuoi": None, "tep": False,
    }),
    ("HSTDT", {
        "ten": "Tra cuu ho so da nop tren thue dien tu",
        "nhan": "Tra c\u1ee9u h\u1ed3 s\u01a1 \u0111\u00e3 n\u1ed9p tr\u00ean thu\u1ebf \u0111i\u1ec7n t\u1eed",
        "trang": TRANG_TCHS,
        "duong": "Tra cuu ho so > tab 'Tra cuu ho so da nop tren thue dien tu'",
        "tim": ["tr\u00ean thu\u1ebf \u0111i\u1ec7n t\u1eed", "tren thue dien tu"],
        # Cong ghi ro bang chu do: "chi ho tro doi voi tra cuu to khai nop truoc ngay 01/07/2025"
        "captcha": True, "moc_cuoi": date(2025, 7, 1), "tep": False,
    }),
])

# GD97-A: hai nhom moi - doc bang tren man hinh (eTax trong khung) hoac tu lay
NHOM["HSK"] = {
    "ten": "Ho so khai thue da nop",
    "nhan": "Tra cứu hồ sơ khai thuế",
    "trang": TRANG_DVK,
    "duong": "Dich vu khac > To chuc > Khai thue > Tra cuu to khai (man hinh eTax trong khung)",
    "tim": ["tra cứu tờ khai", "tra cuu to khai", "tra cứu hồ sơ khai thuế"],
    "captcha": False, "moc_cuoi": None, "tep": True,
}
NHOM["NV"] = {
    "ten": "Nghia vu thue (so con phai nop)",
    "nhan": "Tra cứu nghĩa vụ thuế",
    "trang": TRANG_DVK,
    "duong": "Dich vu khac > To chuc > Nop thue > Tra cuu nghia vu thue / thong tin nghia vu thue",
    "tim": ["tra cứu nghĩa vụ thuế", "tra cuu nghia vu thue", "tra cứu thông tin nghĩa vụ thuế",
            "nghĩa vụ thuế"],
    "captcha": False, "moc_cuoi": None, "tep": False,
}
NHOM["KHAC"] = {"ten": "Bang khac (doc tren man hinh)", "nhan": "", "trang": TRANG_DVK, "duong": "", "tim": [],
                "captcha": True, "moc_cuoi": None, "tep": True}


# ---------------------------------------------------------------------------
#  NHAT KY - che bot du lieu nhay cam truoc khi ghi
# ---------------------------------------------------------------------------
_RE_CHE = [
    (re.compile(r"(eyJ[\w-]{6,})[\w-]*\.[\w-]+\.[\w-]+"), r"\1...<phien>"),
    (re.compile(r"(?i)(authorization\"?\s*[:=]\s*\"?)([^\"',\s]{8,})"), r"\1<da che>"),
    (re.compile(r"(?i)(password|matkhau|pwd)(\"?\s*[:=]\s*\"?)([^\"',\s]+)"), r"\1\2<da che>"),
    (re.compile(r"\b(\d{9}|\d{12})\b"), "<so giay to>"),
]


def _gd167_ico(cs):
    """GD167: bieu tuong cua so = logo UNESCO (AIHoaDon/giao-dien/unesco.ico); thieu tep / loi -> bo qua"""
    try:
        p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "giao-dien", "unesco.ico")
        if os.path.exists(p):
            cs.iconbitmap(default=p)
    except Exception:
        pass


def che(s):
    s = str(s)
    for rx, thay in _RE_CHE:
        s = rx.sub(thay, s)
    return s


class NhatKy(object):
    def __init__(self, duong):
        self.duong = duong
        self.khoa = threading.Lock()

    def ghi(self, msg):
        dong = "%s  %s" % (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), che(msg))
        with self.khoa:
            try:
                with open(self.duong, "a", encoding="utf-8") as f:
                    f.write(dong + "\n")
            except Exception:
                pass
        try:
            print(dong)
        except Exception:
            pass

    def loi(self, msg, e=None):
        self.ghi("LOI: %s%s" % (msg, (" | " + str(e)[:300]) if e else ""))


LOG = NhatKy(LOG_PATH)
BAO_GD = None          # GD120: cua so moi (giao_dien_dvc.py) dat ham nay de ly do ket thuc (ghi_khong_co) hien trong nhat ky


# ---------------------------------------------------------------------------
#  CAI DAT
# ---------------------------------------------------------------------------
def _cd_doc_tho(duong):
    """GD63: doc cai-dat.json (utf-8-sig: Notepad hay luu kem BOM). -> (dict, ok). Tep hong -> giu ban sao .hong-<ngay>."""
    if not os.path.exists(duong):
        return {}, True
    try:
        with open(duong, "r", encoding="utf-8-sig") as f:
            d = json.load(f)
        return (d if isinstance(d, dict) else {}), isinstance(d, dict)
    except Exception:
        try:
            import shutil
            shutil.copy2(duong, duong + ".hong-" + datetime.now().strftime("%Y%m%d%H%M%S"))
        except Exception:
            pass
        return {}, False


def _cd_ghi_gop(duong, thay_doi, xoa=()):
    """GD63: doc lai tep HIEN TAI, chi doi / xoa cac khoa cua tool nay roi ghi tam + os.replace (khong xoa khoa tool khac)."""
    hien, _ok = _cd_doc_tho(duong)
    hien.update(thay_doi)
    for k in xoa:
        hien.pop(k, None)
    tam = duong + ".%d.tmp" % os.getpid()
    with open(tam, "w", encoding="utf-8") as f:
        json.dump(hien, f, ensure_ascii=False, indent=1)
    os.replace(tam, duong)
    return hien


def doc_cai_dat():
    return _cd_doc_tho(SETTINGS_PATH)[0]


def luu_cai_dat(s):
    """GD63: chi ghi cac khoa cua tool DVC (gop vao tep hien tai) - truoc day ghi DE ca tep."""
    try:
        _cd_ghi_gop(SETTINGS_PATH, {k: v for k, v in s.items() if k.startswith("dvc")})
        return True
    except Exception as e:
        LOG.loi("Khong luu duoc cai-dat.json", e)
        return False


def doc_duong_da_hoc(nhom):
    d = doc_cai_dat().get("dvc_endpoint") or {}
    m = d.get(nhom)
    # GD97-A: nhom khac hoc nham TRUNG duong cua TB (log 01/10/2026: GNT hoc 'tra-cuu-thongbao-cqt') -> chua hoc
    if m and nhom != "TB" and (d.get("TB") or {}).get("url") == m.get("url"):
        LOG.ghi("[%s] Duong da hoc trung duong cua Tra cuu thong bao - bo, dung doc bang tren man hinh" % nhom)
        return None
    return m


def luu_duong_da_hoc(nhom, mau):
    s = doc_cai_dat()
    d = s.get("dvc_endpoint") or {}
    d[nhom] = mau
    s["dvc_endpoint"] = d
    luu_cai_dat(s)


# ---------------------------------------------------------------------------
#  THAM SO DONG LENH (dung chung quy uoc voi cac tool khac cua UNESCO)
# ---------------------------------------------------------------------------
def _tach_dong_lenh(s):
    ra, cur, trong = [], "", False
    for c in s:
        if c == '"':
            trong = not trong
        elif c.isspace() and not trong:
            if cur:
                ra.append(cur); cur = ""
        else:
            cur += c
    if cur:
        ra.append(cur)
    return ra


def mo_rong_tham_so(argv):
    """/thamso:"<file UTF-8>" -> doc file do ra thanh cac tham so that (duong dan tieng Viet)."""
    ra = []
    for a in argv:
        if a.startswith("/thamso:"):
            tep = a[len("/thamso:"):].strip('"')
            try:
                with open(tep, "r", encoding="utf-8") as f:
                    ra.extend(_tach_dong_lenh(f.read()))
                LOG.ghi("Doc tham so tu file: " + tep)
            except Exception as e:
                LOG.loi("Khong doc duoc file tham so " + tep, e)
        else:
            ra.append(a)
    return ra


def doc_tham_so(argv):
    ts = {"nhom": "", "tu": None, "den": None, "out": "", "mst": "", "hoc": "", "tudong": False, "docbang": False, "cty": ""}
    for a in mo_rong_tham_so(argv):
        for k in ("nhom", "tu", "den", "out", "mst", "hoc", "cty"):          # GD120: cty = ten cong ty dang mo (chi de hien)
            if a.startswith("/" + k + ":"):
                ts[k] = a[len(k) + 2:].strip('"')
        if a == "/tudong":
            ts["tudong"] = True
        if a == "/docbang":          # GD97-A
            ts["docbang"] = True
    for k in ("tu", "den"):
        if ts[k]:
            ts[k] = doc_ngay(ts[k])
    return ts


def doc_ngay(s):
    s = (s or "").strip()
    for m in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%Y%m%d"):
        try:
            return datetime.strptime(s, m).date()
        except Exception:
            pass
    return None


def thu_muc_kq(out):
    d = os.path.join(out or BASE_DIR, "ket-qua")
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        pass
    return d

# ---------------------------------------------------------------------------
#  KENH CDP - noi websocket toi 1 tab Chrome (lay nguyen tu tool_tai_hoa_don_unesco.py
#  de hai tool cung mot cach lam, da chay on dinh tu goi S8)
# ---------------------------------------------------------------------------
class KenhCDP:
    """Ket noi websocket toi 1 tab Chrome, goi lenh DevTools. Rat gon, du dung."""

    def __init__(self, ws_url, timeout=120):
        u = urllib.parse.urlparse(ws_url)
        self.sock = socket.create_connection((u.hostname, u.port), timeout=timeout)
        self.sock.settimeout(timeout)
        key = base64.b64encode(os.urandom(16)).decode("ascii")
        req = ("GET %s HTTP/1.1\r\nHost: %s:%d\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
               "Sec-WebSocket-Key: %s\r\nSec-WebSocket-Version: 13\r\n\r\n" % (u.path, u.hostname, u.port, key))
        self.sock.sendall(req.encode("ascii"))
        dau = b""
        while b"\r\n\r\n" not in dau:
            phan = self.sock.recv(4096)
            if not phan:
                raise IOError("Chrome dong ket noi khi bat tay websocket")
            dau += phan
        if b" 101 " not in dau.split(b"\r\n")[0]:
            raise IOError("Chrome tu choi websocket: " + dau.split(b"\r\n")[0].decode("ascii", "replace"))
        self.id = 0
        self.khoa_gui = threading.Lock()
        self.su_kien = collections.deque(maxlen=2000)
        self.timeout = timeout
        self.dang_cho = {}
        self.loi_ket_noi = None
        self.sock.settimeout(None)
        threading.Thread(target=self._vong_doc, daemon=True).start()

    def _doc_du(self, n):
        buf = b""
        while len(buf) < n:
            phan = self.sock.recv(min(1 << 20, n - len(buf)))
            if not phan:
                raise IOError("Chrome dong ket noi")
            buf += phan
        return buf

    def _gui_khung(self, opcode, du_lieu):
        mask = os.urandom(4)
        n = len(du_lieu)
        dau = bytes([0x80 | opcode])
        if n < 126:
            dau += bytes([0x80 | n])
        elif n < 65536:
            dau += bytes([0x80 | 126]) + struct.pack(">H", n)
        else:
            dau += bytes([0x80 | 127]) + struct.pack(">Q", n)
        than = bytes(b ^ mask[i % 4] for i, b in enumerate(du_lieu))
        with self.khoa_gui:
            self.sock.sendall(dau + mask + than)

    def _nhan_khung(self):
        """Tra ve (opcode, payload) cua 1 thong diep hoan chinh (gop cac manh)."""
        du_lieu = b""
        opcode_dau = None
        while True:
            b1, b2 = self._doc_du(2)
            fin = b1 & 0x80
            opcode = b1 & 0x0F
            n = b2 & 0x7F
            if n == 126:
                n = struct.unpack(">H", self._doc_du(2))[0]
            elif n == 127:
                n = struct.unpack(">Q", self._doc_du(8))[0]
            mask = self._doc_du(4) if (b2 & 0x80) else None
            than = self._doc_du(n) if n else b""
            if mask:
                than = bytes(b ^ mask[i % 4] for i, b in enumerate(than))
            if opcode == 0x9:              # ping -> pong
                self._gui_khung(0xA, than)
                continue
            if opcode == 0x8:
                raise IOError("Chrome dong websocket")
            if opcode in (0x1, 0x2):
                opcode_dau = opcode
            du_lieu += than
            if fin:
                return opcode_dau, du_lieu

    def _vong_doc(self):
        """Luong doc rieng: tra loi lenh -> danh thuc nguoi cho; su kien -> xep hang."""
        try:
            while True:
                _, than = self._nhan_khung()
                try:
                    msg = json.loads(than.decode("utf-8"))
                except Exception:
                    continue
                if "id" in msg:
                    o = self.dang_cho.get(msg["id"])
                    if o is not None:
                        o[1] = msg
                        o[0].set()
                elif "method" in msg:
                    self.su_kien.append(msg)
        except Exception as e:
            self.loi_ket_noi = str(e)[:200]
            for o in list(self.dang_cho.values()):
                o[0].set()

    def goi(self, phuong_thuc, tham_so=None, timeout=None):
        if self.loi_ket_noi:
            raise IOError("Mat ket noi Chrome: " + self.loi_ket_noi)
        with self.khoa_gui:
            self.id += 1
            mid = self.id
        cho = [threading.Event(), None]
        self.dang_cho[mid] = cho
        try:
            self._gui_khung(0x1, json.dumps({"id": mid, "method": phuong_thuc, "params": tham_so or {}}).encode("utf-8"))
            if not cho[0].wait(timeout or self.timeout):
                raise IOError("CDP %s: qua thoi gian cho" % phuong_thuc)
        finally:
            self.dang_cho.pop(mid, None)
        if cho[1] is None:
            raise IOError("Mat ket noi Chrome: " + (self.loi_ket_noi or ""))
        msg = cho[1]
        if "error" in msg:
            raise IOError("CDP %s: %s" % (phuong_thuc, msg["error"].get("message", "")))
        return msg.get("result", {})

    def hut_su_kien(self, cho=0.3):
        """(giu de tuong thich) Su kien da duoc luong doc xep san; chi kiem tra ket noi."""
        if self.loi_ket_noi:
            raise IOError("Mat ket noi Chrome: " + self.loi_ket_noi)

    def chay_js(self, bieu_thuc, cho_promise=False, timeout=None):
        kq = self.goi("Runtime.evaluate", {"expression": bieu_thuc, "awaitPromise": cho_promise,
                                           "returnByValue": True})
        if kq.get("exceptionDetails"):
            raise IOError("JS loi: " + json.dumps(kq["exceptionDetails"].get("exception", {}).get("description", ""))[:300])
        return kq.get("result", {}).get("value")

    def dong(self):
        try:
            self.sock.close()
        except Exception:
            pass

# ---------------------------------------------------------------------------
#  MO CHROME + CHO NGUOI DUNG TU DANG NHAP
# ---------------------------------------------------------------------------
CHROME = {"tien_trinh": None, "cong": 0, "kenh": None, "trang_thai": "chua_mo", "loi": "", "tab": None}

# header trinh duyet tu dat / khong duoc phep dat lai
_HEADER_BO = {"host", "content-length", "cookie", "connection", "accept-encoding", "origin",
              "referer", "sec-fetch-site", "sec-fetch-mode", "sec-fetch-dest", "user-agent",
              "sec-ch-ua", "sec-ch-ua-mobile", "sec-ch-ua-platform"}


def tim_chrome():
    ds = []
    for b in (os.environ.get("PROGRAMFILES", r"C:\Program Files"),
              os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)"),
              os.environ.get("LOCALAPPDATA", "")):
        if b:
            ds.append(os.path.join(b, r"Google\Chrome\Application\chrome.exe"))
    ds += ["/usr/bin/google-chrome", "/usr/bin/chromium", "/usr/bin/chromium-browser",
           "/opt/pw-browsers/chromium"]
    for t in ds:
        if t and os.path.exists(t):
            return t
    return ""


def _cong_ranh():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    c = s.getsockname()[1]
    s.close()
    return c


def mo_chrome(url=TRANG_VAO):
    """Mo Chrome ho so rieng (khong dung chung voi Chrome thuong cua nguoi dung) toi cong DVC."""
    if CHROME["kenh"] is not None:
        return True, ""
    # GD97-A: Chrome ho so rieng con mo tu lan truoc -> noi lai (mo lan hai cung ho so: Chrome bo qua cong go loi moi)
    c = _cong_dang_chay()
    if c:
        CHROME["cong"] = c
        kenh = noi_tab()
        if kenh is None and _mo_tab_moi(url):
            time.sleep(2.0)
            kenh = noi_tab()
        if kenh is not None:
            LOG.ghi("[CHROME] Noi lai Chrome ho so rieng dang mo (cong %d)" % c)
            CHROME["kenh"] = kenh
            CHROME["trang_thai"] = "da_mo"
            try:
                kenh.goi("Runtime.enable")
                kenh.goi("Page.enable")
            except Exception:
                pass
            return True, ""
    chrome = tim_chrome()
    if not chrome:
        return False, "Khong tim thay Chrome tren may. Hay cai Google Chrome roi thu lai."
    try:
        os.makedirs(CHROME_HO_SO, exist_ok=True)
    except Exception:
        pass
    cong = _cong_ranh()
    lenh = [chrome, "--remote-debugging-port=%d" % cong, "--user-data-dir=" + CHROME_HO_SO,
            "--no-first-run", "--no-default-browser-check", "--disable-sync",
            "--window-size=1280,920", "--new-window", url]
    LOG.ghi("[CHROME] Mo Chrome ho so rieng cho cong DVC, cong go loi %d" % cong)
    try:
        CHROME["tien_trinh"] = subprocess.Popen(lenh, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception as e:
        LOG.loi("Khong mo duoc Chrome", e)
        return False, "Khong mo duoc Chrome: " + str(e)[:200]
    CHROME["cong"] = cong
    _luu_cong(cong)          # GD97-A
    kenh = None
    t0 = time.time()
    while kenh is None and time.time() - t0 < 60:
        time.sleep(1.5)
        kenh = noi_tab()
    if kenh is None:
        return False, "Chrome khong mo duoc trang Cong dich vu cong (qua 60 giay)."
    CHROME["kenh"] = kenh
    CHROME["trang_thai"] = "da_mo"
    try:
        kenh.goi("Runtime.enable")
        kenh.goi("Page.enable")
    except Exception:
        pass
    return True, ""


def _cac_tab_cong():
    """GD98-A: [(id, url, ws)] moi tab (page) cua cong thue dang mo, tab dichvucong truoc. None = khong noi duoc Chrome."""
    try:
        with urllib.request.urlopen("http://127.0.0.1:%d/json/list" % CHROME["cong"], timeout=5) as r:
            ds = json.loads(r.read().decode("utf-8"))
    except Exception:
        return None
    ra = [(t.get("id"), t.get("url") or "", t.get("webSocketDebuggerUrl")) for t in ds
          if t.get("type") == "page" and _la_cong(t.get("url") or "") and t.get("webSocketDebuggerUrl")]
    ra.sort(key=lambda x: 0 if "dichvucong." in x[1] else 1)
    return ra


def noi_tab():
    """Noi kenh toi tab cong: uu tien tab da chon (da dang nhap), roi tab dichvucong (GD98-A)."""
    ds = _cac_tab_cong()
    if not ds:
        return None
    ds.sort(key=lambda x: 0 if x[0] == CHROME.get("tab") else 1)
    for tid, url, ws in ds:
        try:
            k = KenhCDP(ws)
            CHROME["tab"] = tid
            return k
        except Exception as e:
            LOG.ghi("[CHROME] Chua noi duoc tab: " + str(e)[:200])
    return None


def noi_lai():
    """Tab bi chuyen trang / tai lai lam mat websocket -> noi lai."""
    try:
        if CHROME["kenh"]:
            CHROME["kenh"].dong()
    except Exception:
        pass
    CHROME["kenh"] = None
    t0 = time.time()
    while time.time() - t0 < 30:
        k = noi_tab()
        if k is not None:
            CHROME["kenh"] = k
            try:
                k.goi("Runtime.enable")
            except Exception:
                pass
            return k
        time.sleep(1.0)
    return None


# GD98-A: cong DVC moi (10/2026) - dau trang khong con nut 'Dang xuat'; cong chi cho dung MOT tab (tab thu hai bi thay
#   noi dung bang 'Tai khoan hien dang duoc su dung tren mot tab khac'). Truoc day tool chi xem tab dau danh sach ->
#   co the xem nham tab bi khoa / tab cu, khong bao gio thay da dang nhap. Nay xem MOI tab cong.
_JS_DA_DANG_NHAP = r"""
(() => {
  let t = (document.body ? document.body.innerText : '') || '';
  for (const id of ['unesco_dn', 'unesco_bang']) { const e = document.getElementById(id); if (e) t = t.replace(e.innerText || '', ''); }
  const k = t.toLowerCase();
  if (k.indexOf('đang được sử dụng trên một tab khác') >= 0) return 'tab_khac';
  if (window.__unesco_dn === 'xong') return 'co_bam';
  if (k.indexOf('đăng xuất') >= 0 || k.indexOf('dang xuat') >= 0) return 'co';
  if (document.querySelector('a[href*="logout" i],a[href*="dang-xuat" i],[hx-on\\:click*="dangXuat"],[onclick*="dangXuat"],[onclick*="logout" i]')) return 'co';
  if (Array.from(document.querySelectorAll('[onclick*="openDetailTinTuc"]')).some(e => /,\s*'Y'\s*\)/.test(e.getAttribute('onclick') || ''))) return 'co';
  const vis = e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
  const nutDN = Array.from(document.querySelectorAll('button,a,[hx-on\\:click]')).some(e => vis(e) &&
      (/^\s*đăng nhập\s*$/i.test(e.innerText || '') || /dangNhap\(/.test(e.getAttribute('hx-on:click') || '')));
  if (nutDN || document.querySelector('input[type=password]')) return 'chua';
  if (document.readyState === 'complete' && t.length > 300 && /(^|\.)dichvucong\.gdt\.gov\.vn$/.test(location.hostname)) return 'co_le';
  return 'khong_ro';
})()
"""

# GD98-A: dai xanh DUOI trang khi dang cho dang nhap - nut 'Toi da dang nhap xong' (cong doi giao dien, tool chua tu nhan ra)
_JS_NUT_DA_DN = r"""
(() => {
  if (!document.body) return 'chua_san';
  if (document.getElementById('unesco_dn')) return 'ok';
  const d = document.createElement('div');
  d.id = 'unesco_dn';
  d.setAttribute('style', 'position:fixed;z-index:2147483647;left:0;right:0;bottom:0;padding:6px 14px;background:#0b5ed7;color:#fff;'
    + 'font:14px/1.5 Tahoma,Arial,sans-serif;box-shadow:0 -2px 8px rgba(0,0,0,.3)');
  d.innerHTML = '<b>UNESCO</b> đang chờ anh/chị đăng nhập (tool không đọc mật khẩu). '
    + 'Đăng nhập xong mà tool chưa tự nhận ra thì bấm: '
    + '<button id="unesco_dn_xong" style="font:bold 14px Tahoma;padding:3px 12px;margin-left:8px;cursor:pointer">'
    + 'Tôi đã đăng nhập xong</button>';
  document.body.appendChild(d);
  document.getElementById('unesco_dn_xong').onclick = () => { window.__unesco_dn = 'xong'; d.remove(); };
  return 'ok';
})()
"""
_JS_XOA_NUT_DN = "(()=>{const d=document.getElementById('unesco_dn'); if(d) d.remove(); return 'ok';})()"

# GD98-A: moi lan chay nhan 'luot'; bam lai nut (Mo cong / Tai du lieu / cua so tool) -> lan cu tu dung, khong ghi ket qua
TEP_LUOT = os.path.join(CHROME_HO_SO, "unesco-luot.txt")
NHUONG = "NHUONG_LUOT"


def _nhan_luot():
    """Ghi luot moi; ghi khong duoc (thu muc chi doc, chong virus khoa tep...) -> None = khong theo doi luot."""
    ma = "%d-%d" % (os.getpid(), int(time.time() * 1000))
    try:
        os.makedirs(os.path.dirname(TEP_LUOT), exist_ok=True)
        with open(TEP_LUOT, "w", encoding="utf-8") as f:
            f.write(ma)
        with open(TEP_LUOT, "r", encoding="utf-8") as f:
            if f.read().strip() != ma:
                return None
    except Exception:
        return None
    return ma


def _con_luot(ma):
    if not ma:
        return True
    try:
        with open(TEP_LUOT, "r", encoding="utf-8") as f:
            return f.read().strip() in ("", ma)
    except Exception:
        return True


def _dong_tab(tid):
    try:
        with urllib.request.urlopen("http://127.0.0.1:%d/json/close/%s" % (CHROME["cong"], tid), timeout=5) as r:
            r.read()
        return True
    except Exception:
        return False


def _so_trang():
    """So trang (page) dang mo trong Chrome rieng, moi trang web (khong chi cong thue). -1 = khong doc duoc."""
    try:
        with urllib.request.urlopen("http://127.0.0.1:%d/json/list" % CHROME["cong"], timeout=5) as r:
            return sum(1 for t in json.loads(r.read().decode("utf-8")) if t.get("type") == "page")
    except Exception:
        return -1


def _co_mst(k):
    try:
        return bool(_chay_trong(k, _JS_MST_DANG_NHAP, timeout=15))
    except Exception:
        return False


def _dung_tab(tid):
    """Chuyen kenh chinh cua tool sang tab tid (tab nguoi dung da dang nhap)."""
    for t_id, url, ws in (_cac_tab_cong() or []):
        if t_id != tid:
            continue
        if CHROME.get("tab") == tid and CHROME.get("kenh") is not None and not CHROME["kenh"].loi_ket_noi:
            return True
        try:
            k = KenhCDP(ws)
        except Exception as e:
            LOG.ghi("[CHROME] Chua noi duoc tab da dang nhap: " + str(e)[:200])
            return False
        try:
            if CHROME.get("kenh") is not None:
                CHROME["kenh"].dong()
        except Exception:
            pass
        CHROME["kenh"], CHROME["tab"] = k, tid
        try:
            k.goi("Runtime.enable")
            k.goi("Page.enable")
        except Exception:
            pass
        return True
    return False


_TEN_TT = {"co": "trang bao da dang nhap", "co_bam": "anh/chi bam 'Toi da dang nhap xong'",
           "co_le": "het nut Dang nhap / o mat khau tren cong"}


def cho_dang_nhap(gioi_han=900, bao=None, luot=None):
    """Doi den khi MOT tab cong co dau hieu da dang nhap (xem moi tab, khong chi tab dau). Khong dong vao o mat khau,
       khong doc captcha. -> (True, "") | (False, ly do) | (False, NHUONG) khi da co lan chay moi."""
    t0 = time.time()
    lan_bao, lan_ghi, lan_mo, loi_lien = 0, 0.0, 0.0, 0
    co_le, da_dong, da_chua = {}, set(), set()
    while time.time() - t0 < gioi_han:
        if not _con_luot(luot):
            return False, NHUONG
        tabs = _cac_tab_cong()
        if tabs is None:
            loi_lien += 1          # mot lan /json/list loi (may ban) chua phai mat Chrome
            if loi_lien >= 5:
                return False, "Mat ket noi voi Chrome (cua so Chrome rieng da dong?)."
            time.sleep(2)
            continue
        loi_lien = 0
        if not tabs:
            # chi mo tab moi khi Chrome KHONG con trang nao: dang nhap VNeID / SSO dua tab sang trang khac -> KHONG mo
            #   them (tab moi chiem khoa 'mot tab' cua cong, tab cu quay ve bi khoa)
            if _so_trang() == 0 and time.time() - lan_mo > 20 and _mo_tab_moi(TRANG_VAO):
                lan_mo = time.time()
                LOG.ghi("[CHROME] Khong con trang nao - mo lai mot tab Cong DVC")
            time.sleep(2)
            continue
        tt_ds = []
        for tid, url, ws in tabs:
            k = kenh_khung(tid, ws)
            tt = "khong_noi"
            if k is not None:
                try:
                    tt = _chay_trong(k, _JS_DA_DANG_NHAP, timeout=20) or "khong_ro"
                except Exception:
                    tt = "khong_ro"
            tt_ds.append((tid, url, tt, k))
        con = [x for x in tt_ds if x[2] != "tab_khac"]
        for tid, url, tt, k in tt_ds:
            if tt == "tab_khac" and con and tid not in da_dong and _dong_tab(tid):
                da_dong.add(tid)
                LOG.ghi("[CHROME] Dong tab bi cong khoa ('dang duoc su dung tren mot tab khac'): " + url[:120])
        if not con and time.time() - lan_mo > 30:
            # moi tab deu bi khoa (tab chinh da dong) -> nap lai tab dau sau khi cong nha khoa (5 giay)
            lan_mo = time.time()
            try:
                tt_ds[0][3].goi("Page.navigate", {"url": TRANG_VAO}, timeout=20)
                LOG.ghi("[CHROME] Moi tab deu bi cong khoa - nap lai trang Cong DVC")
            except Exception:
                pass
        chon = None
        for x in tt_ds:
            if x[2] in ("co", "co_bam"):
                chon = x
                break
            if x[2] == "chua":
                da_chua.add(x[0])
            if x[2] == "co_le":
                # 'het nut Dang nhap' chi tin khi chinh tab do vua o trang dang nhap, hoac trang hien MST dang nhap
                co_le[x[0]] = co_le.get(x[0], 0) + 1
                if co_le[x[0]] >= 3 and x[3] is not None and (x[0] in da_chua or _co_mst(x[3])):
                    chon = x
                    break
            else:
                co_le.pop(x[0], None)
        if chon is not None:
            for x in tt_ds:
                if x[3] is not None:
                    try:
                        _chay_trong(x[3], _JS_XOA_NUT_DN, timeout=10)
                    except Exception:
                        pass
            if not _dung_tab(chon[0]):
                time.sleep(2)
                continue
            LOG.ghi("[CHROME] Da thay dau hieu DANG NHAP THANH CONG tren cong DVC (%s; %s)." % (_TEN_TT.get(chon[2], chon[2]), chon[1][:100]))
            return True, ""
        for x in tt_ds:
            if x[3] is not None and x[2] in ("chua", "khong_ro", "co_le"):
                try:
                    _chay_trong(x[3], _JS_NUT_DA_DN, timeout=10)
                except Exception:
                    pass
        if time.time() - lan_ghi > 60:
            lan_ghi = time.time()
            LOG.ghi("[CHROME] Tab cong (%d): %s" % (len(tt_ds), " | ".join(
                "%s = %s" % (re.sub(r"^https?://", "", x[1])[:70], x[2]) for x in tt_ds)))
        if bao and time.time() - t0 > lan_bao * 15:
            lan_bao += 1
            bao("Dang cho ban dang nhap trong cua so Chrome vua mo...")
        time.sleep(2)
    return False, "Het thoi gian cho dang nhap."

# ---------------------------------------------------------------------------
#  NGHE MANG TRONG TAB (thay cho file .har)
#  Chrome DevTools Protocol cho phep doc lai dung nhung yeu cau ma trang tu goi -
#  day chinh la thu DevTools dung de xuat file .har. Nen nguoi dung KHONG phai
#  biet .har la gi: chi bam dung chuc nang mot lan, tool ghi lai.
# ---------------------------------------------------------------------------
_DUOI_TINH = (".js", ".css", ".png", ".jpg", ".jpeg", ".gif", ".svg", ".ico", ".woff", ".woff2",
              ".ttf", ".eot", ".map", ".html", ".htm")


class BoNghe(object):
    def __init__(self, kenh):
        self.kenh = kenh
        self.yeu_cau = {}
        self.xong = []
        self.dang_chay = False
        self._luong = None

    def bat(self):
        self.kenh.goi("Network.enable", {"maxTotalBufferSize": 40000000,
                                         "maxResourceBufferSize": 20000000})
        self.dang_chay = True
        self._luong = threading.Thread(target=self._vong, daemon=True)
        self._luong.start()

    def tat(self):
        self.dang_chay = False
        try:
            self.kenh.goi("Network.disable")
        except Exception:
            pass

    def _vong(self):
        while self.dang_chay:
            try:
                self._xu_ly()
            except Exception:
                pass
            time.sleep(0.2)

    def _xu_ly(self):
        while self.kenh.su_kien:
            ev = self.kenh.su_kien.popleft()
            pt = ev.get("method")
            p = ev.get("params", {})
            rid = p.get("requestId")
            if pt == "Network.requestWillBeSent":
                rq = p.get("request", {}) or {}
                url = rq.get("url", "")
                if not _la_cong(url):          # GD97-A: ca eTax (thuedientu.gdt.gov.vn) trong khung
                    continue
                duong = url.split("?")[0].lower()
                if duong.endswith(_DUOI_TINH):
                    continue
                self.yeu_cau[rid] = {
                    "url": url, "method": rq.get("method", "GET"),
                    "body": rq.get("postData", "") or "",
                    "headers": {k: v for k, v in (rq.get("headers") or {}).items()
                                if k.lower() not in _HEADER_BO and not k.startswith(":")},
                    "loai": p.get("type", ""), "luc": time.time(),
                }
            elif pt == "Network.responseReceived":
                if rid in self.yeu_cau:
                    r = p.get("response", {}) or {}
                    self.yeu_cau[rid]["status"] = int(r.get("status") or 0)
                    self.yeu_cau[rid]["mime"] = r.get("mimeType", "")
                    self.yeu_cau[rid]["loai"] = p.get("type", self.yeu_cau[rid].get("loai", ""))
            elif pt == "Network.loadingFinished":
                v = self.yeu_cau.pop(rid, None)
                if v is None:
                    continue
                try:
                    kq = self.kenh.goi("Network.getResponseBody", {"requestId": rid}, timeout=20)
                    than = kq.get("body") or ""
                    if kq.get("base64Encoded"):
                        than = base64.b64decode(than).decode("utf-8", "replace")
                    v["tra_ve"] = than[:4000000]
                except Exception:
                    v["tra_ve"] = ""
                self.xong.append(v)
            elif pt == "Network.loadingFailed":
                self.yeu_cau.pop(rid, None)


# ---------- ngay MOC: cac cach viet co the gap trong URL / body ----------
def cac_dang_ngay(d):
    return [
        ("dd/MM/yyyy", d.strftime("%d/%m/%Y")),
        ("yyyy-MM-dd", d.strftime("%Y-%m-%d")),
        ("dd-MM-yyyy", d.strftime("%d-%m-%Y")),
        ("yyyyMMdd", d.strftime("%Y%m%d")),
        ("MM/dd/yyyy", d.strftime("%m/%d/%Y")),
        ("dd.MM.yyyy", d.strftime("%d.%m.%Y")),
    ]


def _bien_the(s):
    """Chuoi goc + ban ma hoa URL (dd%2FMM%2Fyyyy) - hai kieu deu hay gap."""
    return [s, urllib.parse.quote(s, safe=""), urllib.parse.quote(s, safe="")[:].replace("%2F", "%2f")]


def tim_dang_ngay(chuoi, d):
    """Tra ve list ten dang ngay xuat hien trong chuoi."""
    ra = []
    for ten, s in cac_dang_ngay(d):
        for bt in _bien_the(s):
            if bt and bt in chuoi:
                ra.append(ten)
                break
    return ra


def thay_ngay(chuoi, dang, moc, that):
    """Thay moi cach viet cua ngay MOC bang ngay THAT, giu nguyen dinh dang."""
    for ten, s in cac_dang_ngay(moc):
        if dang and ten not in dang:
            continue
        moi = dict(cac_dang_ngay(that))[ten]
        for bt_cu, bt_moi in zip(_bien_the(s), _bien_the(moi)):
            if bt_cu and bt_cu in chuoi:
                chuoi = chuoi.replace(bt_cu, bt_moi)
    return chuoi


# ---------- doc danh sach ban ghi trong JSON tra ve ----------
def lay_danh_sach(obj, sau=0):
    """Tim list ban ghi 'that' trong JSON tra ve: list dai nhat toan dict."""
    tot = []
    if isinstance(obj, list):
        if obj and all(isinstance(x, dict) for x in obj):
            tot = obj
        for x in obj[:50]:
            c = lay_danh_sach(x, sau + 1)
            if len(c) > len(tot):
                tot = c
    elif isinstance(obj, dict) and sau < 6:
        for k in ("data", "content", "items", "rows", "list", "result", "records", "dsHoSo",
                  "danhSach", "lstData", "body"):
            if k in obj:
                c = lay_danh_sach(obj[k], sau + 1)
                if len(c) > len(tot):
                    tot = c
        for v in obj.values():
            c = lay_danh_sach(v, sau + 1)
            if len(c) > len(tot):
                tot = c
    return tot


def doc_json(s):
    try:
        return json.loads(s)
    except Exception:
        return None


# ---------------------------------------------------------------------------
#  DOC KET QUA DANG BANG HTML
#  Trang "Dich vu khac" tra ve HTML thuan (bang + dong "Trang 1/1. Co N ban ghi"),
#  khong phai JSON. Phan nay doc bang do; duong JSON van giu nguyen cho trang nao
#  tra JSON.
# ---------------------------------------------------------------------------
class _DocBang(html.parser.HTMLParser):
    """Gom moi <table> thanh danh sach dong, moi o giu ca chu lan lien ket."""

    def __init__(self):
        html.parser.HTMLParser.__init__(self, convert_charrefs=True)
        self.bang = []          # [[ [o, o, ...], ... ], ...]
        self._ngan = []         # ngan xep bang (bang long nhau)
        self._dong = None
        self._o = None
        self._a = None
        self._tieude = []       # co <th> khong, theo tung bang

    # --- tien ich
    def _hien(self):
        return self._ngan[-1] if self._ngan else None

    def handle_starttag(self, tag, attrs):
        d = dict(attrs)
        if tag == "table":
            self._ngan.append([])
            self._tieude.append(False)
        elif tag == "tr" and self._hien() is not None:
            self._dong = []
        elif tag in ("td", "th") and self._dong is not None:
            self._o = {"chu": "", "lien_ket": [], "th": tag == "th"}
            if tag == "th" and self._tieude:
                self._tieude[-1] = True
            n = d.get("colspan")
            try:
                self._o["colspan"] = max(1, int(n))
            except Exception:
                self._o["colspan"] = 1
        elif tag == "a" and self._o is not None:
            self._a = {"chu": "", "href": d.get("href", ""), "onclick": d.get("onclick", "")}
        elif tag == "br" and self._o is not None:
            self._o["chu"] += " "

    def handle_endtag(self, tag):
        if tag == "a" and self._a is not None and self._o is not None:
            self._a["chu"] = " ".join(self._a["chu"].split())
            self._o["lien_ket"].append(self._a)
            self._a = None
        elif tag in ("td", "th") and self._o is not None and self._dong is not None:
            self._o["chu"] = " ".join(self._o["chu"].split())
            self._dong.append(self._o)
            self._o = None
        elif tag == "tr" and self._dong is not None and self._hien() is not None:
            if self._dong:
                self._hien().append(self._dong)
            self._dong = None
        elif tag == "table" and self._ngan:
            b = self._ngan.pop()
            co_th = self._tieude.pop() if self._tieude else False
            if b:
                self.bang.append({"dong": b, "co_th": co_th})

    def handle_data(self, data):
        if self._a is not None:
            self._a["chu"] += data
        elif self._o is not None:
            self._o["chu"] += data

    def close(self):
        html.parser.HTMLParser.close(self)
        while self._ngan:
            b = self._ngan.pop()
            co_th = self._tieude.pop() if self._tieude else False
            if b:
                self.bang.append({"dong": b, "co_th": co_th})


_RE_TRANG = re.compile(r"(?i)trang\s*(\d+)\s*/\s*(\d+)")
_RE_BANGHI = re.compile(r"(?i)c\u00f3\s*([\d.,]+)\s*b\u1ea3n\s*ghi")


def _so_nguyen(s):
    s = re.sub(r"[^\d]", "", str(s or ""))
    return int(s) if s else 0


def doc_phan_trang_html(noi_dung):
    """Doc 'Trang 1/3. Co 57 ban ghi' o duoi bang. Tra ve dict hoac {}."""
    ra = {}
    m = _RE_TRANG.search(noi_dung or "")
    if m:
        ra["trang"] = int(m.group(1))
        ra["tong_trang"] = int(m.group(2))
    m = _RE_BANGHI.search(noi_dung or "")
    if m:
        ra["tong_ban_ghi"] = _so_nguyen(m.group(1))
    return ra


def _chon_bang(cac_bang):
    """Chon bang ket qua: nhieu dong du lieu nhat, uu tien bang co <th>."""
    tot, diem_tot = None, -1
    for b in cac_bang:
        dong = b["dong"]
        nhieu_o = [d for d in dong if len(d) >= 3]
        if len(nhieu_o) < 2:
            continue
        diem = len(nhieu_o) * 10 + (5 if b["co_th"] else 0) + min(len(nhieu_o[0]), 20)
        if diem > diem_tot:
            tot, diem_tot = b, diem
    return tot


def doc_bang_html(noi_dung):
    """Doc bang ket qua trong mot trang HTML.
       Tra ve (danh_sach_dong_dict, thong_tin_phan_trang).
       Moi dong co them khoa '_lien_ket' = [{chu, href, onclick}] lay tu cac o."""
    if not noi_dung or "<" not in noi_dung:
        return [], {}
    p = _DocBang()
    try:
        p.feed(noi_dung)
        p.close()
    except Exception:
        pass
    b = _chon_bang(p.bang)
    if not b:
        return [], doc_phan_trang_html(noi_dung)
    dong = b["dong"]
    # hang tieu de: hang dau co <th>, neu khong thi hang dau tien
    i_td = 0
    for i, d in enumerate(dong):
        if any(o["th"] for o in d):
            i_td = i
            break
    tieu = []
    for o in dong[i_td]:
        ten = o["chu"] or ("cot%d" % (len(tieu) + 1))
        for _ in range(max(1, o.get("colspan", 1))):
            tieu.append(ten)
            ten = ""
    # bo cot khong co ten o dau/cuoi van giu cho de khop chi so
    ra = []
    for d in dong[i_td + 1:]:
        if len(d) < 2:
            continue
        if all(o["th"] for o in d):          # them mot hang tieu de nua -> bo qua
            continue
        r, lk = {}, []
        for j, o in enumerate(d):
            ten = tieu[j] if j < len(tieu) and tieu[j] else ("cot%d" % (j + 1))
            if ten in r and r[ten]:
                ten = "%s_%d" % (ten, j)
            r[ten] = o["chu"]
            lk.extend(o["lien_ket"])
        r["_lien_ket"] = lk
        ra.append(r)
    return ra, doc_phan_trang_html(noi_dung)


def lay_ban_ghi(noi_dung):
    """Lay danh sach ban ghi tu mot phan hoi, du la JSON hay HTML.
       Tra ve (danh_sach, kieu, phan_trang)."""
    js = doc_json(noi_dung or "")
    if js is not None:
        ds = lay_danh_sach(js)
        if ds:
            return ds, "json", {}
        return [], "json", {}
    ds, pt = doc_bang_html(noi_dung or "")
    return ds, ("html" if ds else ""), pt


# ---------- cham diem de chon dung yeu cau ----------
_TU_TRA_CUU = ("tra-cuu", "tracuu", "search", "query", "danh-sach", "danhsach", "list",
               "tim-kiem", "timkiem", "lookup", "getlist", "get-list")


def cham_diem(v, moc_tu, moc_den):
    """Cham diem mot yeu cau da nghe duoc. Chap nhan CA HAI dang tra ve:
       JSON (trang /tthc/tchs) va HTML co bang (trang /tthc/dich-vu-khac)."""
    diem, ly = 0, []
    url = v.get("url", "")
    than = (v.get("body") or "") + " " + url
    if v.get("status", 0) != 200:
        return -100, ["ma tra ve %s" % v.get("status")]
    ds, kieu, _pt = lay_ban_ghi(v.get("tra_ve") or "")
    if not kieu:
        return -100, ["tra ve khong phai JSON ma cung khong co bang HTML"]
    if kieu == "json":
        # trang SPA: yeu cau tra cuu phai la XHR/Fetch
        if v.get("loai") not in ("XHR", "Fetch"):
            diem -= 20
            ly.append("khong phai XHR/Fetch")
    else:
        # trang co dien: bam Tra cuu la mot lan nap trang, khong phai XHR
        ly.append("tra ve bang HTML")
    d1 = tim_dang_ngay(than, moc_tu)
    d2 = tim_dang_ngay(than, moc_den)
    if d1 and d2:
        diem += 50
        ly.append("co ca hai ngay moc (%s)" % d1[0])
    elif d1 or d2:
        diem += 20
        ly.append("co mot ngay moc")
    if ds:
        diem += 30
        ly.append("tra ve %d ban ghi" % len(ds))
    else:
        diem -= 10
        ly.append("khong thay danh sach ban ghi")
    low = url.lower()
    if any(t in low for t in _TU_TRA_CUU):
        diem += 10
        ly.append("duong dan kieu tra cuu")
    return diem, ly


# ---------- phan trang ----------
_KHOA_TRANG = ("page", "pageindex", "pagenumber", "pageno", "pagenum", "trang", "start",
               "offset", "skip", "from", "currentpage", "current")
_KHOA_CO = ("pagesize", "size", "limit", "rows", "pagelen", "sotrang", "soban", "take", "length")


def _tim_khoa_so(d, ten_hop_le):
    ra = {}
    if isinstance(d, dict):
        for k, v in d.items():
            if isinstance(v, (int, float)) and not isinstance(v, bool) and k.lower() in ten_hop_le:
                ra[k] = v
            elif isinstance(v, str) and v.isdigit() and k.lower() in ten_hop_le:
                ra[k] = int(v)
    return ra


def do_phan_trang(url, body):
    """Tim tham so phan trang trong URL hoac body. Tra ve mo ta hoac None."""
    q = urllib.parse.urlparse(url).query
    if q:
        ts = dict(urllib.parse.parse_qsl(q, keep_blank_values=True))
        t = {k: v for k, v in ts.items() if k.lower() in _KHOA_TRANG and v.isdigit()}
        c = {k: v for k, v in ts.items() if k.lower() in _KHOA_CO and v.isdigit()}
        if t:
            return {"o": "url", "trang": list(t.keys())[0], "co": (list(c.keys())[0] if c else ""),
                    "trang_dau": int(list(t.values())[0]), "so_moi_trang": int(list(c.values())[0]) if c else 0}
    js = doc_json(body or "")
    if isinstance(js, dict):
        t = _tim_khoa_so(js, _KHOA_TRANG)
        c = _tim_khoa_so(js, _KHOA_CO)
        if t:
            return {"o": "body", "trang": list(t.keys())[0], "co": (list(c.keys())[0] if c else ""),
                    "trang_dau": int(list(t.values())[0]), "so_moi_trang": int(list(c.values())[0]) if c else 0}
    return None

# ---------------------------------------------------------------------------
#  GOI LAI YEU CAU NGAY TRONG TAB (de dung nguyen phien dang nhap + cookie)
# ---------------------------------------------------------------------------
_JS_FETCH = r"""
(async () => {
  try {
    const r = await fetch(%s, %s);
    const u = new Uint8Array(await r.arrayBuffer());
    let s = ''; const CH = 0x8000;
    for (let i = 0; i < u.length; i += CH) s += String.fromCharCode.apply(null, u.subarray(i, i + CH));
    return JSON.stringify({s: r.status, t: r.headers.get('content-type') || '', d: btoa(s)});
  } catch (e) { return JSON.stringify({s: 0, e: String(e)}); }
})()
"""


def goi_trong_tab(kenh, url, method="GET", body=None, headers=None, timeout=90):
    """Tra ve (ma_tra_ve, kieu_noi_dung, bytes). Yeu cau do CHINH TRANG gui nen
       cookie / phien dang nhap giu nguyen - tool khong cham vao mat khau."""
    h = {"Accept": "application/json, text/plain, */*", "Accept-Language": "vi"}
    h.update(headers or {})
    h["X-Unesco-Tool"] = "dvc"                      # de bo nghe biet day la yeu cau cua tool
    tuy = {"method": method, "headers": h, "credentials": "include"}
    if body is not None and method.upper() != "GET":
        tuy["body"] = body
        if "Content-Type" not in h and "content-type" not in h:
            h["Content-Type"] = "application/json;charset=UTF-8"
    js = _JS_FETCH % (json.dumps(url), json.dumps(tuy))
    kq = kenh.chay_js(js, cho_promise=True, timeout=timeout)
    try:
        o = json.loads(kq)
    except Exception:
        return 0, "", b""
    if not o.get("s"):
        return 0, "", (o.get("e") or "").encode("utf-8", "replace")
    return int(o["s"]), o.get("t", ""), base64.b64decode(o.get("d") or "")


# ---------------------------------------------------------------------------
#  DAY TOOL CACH GOI (thay cho .har)
# ---------------------------------------------------------------------------
_JS_BANG = r"""
(() => {
  let d = document.getElementById('unesco_bang');
  if (!d) { d = document.createElement('div'); d.id = 'unesco_bang'; document.body.appendChild(d); }
  d.setAttribute('style', 'position:fixed;z-index:2147483647;left:0;right:0;top:0;padding:10px 14px;'
    + 'background:#0b5ed7;color:#fff;font:14px/1.5 Tahoma,Arial,sans-serif;box-shadow:0 2px 8px rgba(0,0,0,.3)');
  d.innerHTML = %s;
  return 'ok';
})()
"""

_JS_XOA_BANG = "(()=>{const d=document.getElementById('unesco_bang'); if(d) d.remove(); return 'ok';})()"

_JS_BAM_CHU = r"""
(() => {
  const can = %s;
  const bo = (s) => (s||'').toLowerCase()
     .normalize('NFD').replace(/[̀-ͯ]/g,'').replace(/đ/g,'d').replace(/\s+/g,' ').trim();
  const ds = Array.from(document.querySelectorAll('a,button,[role=menuitem],[role=tab],li,span,div'));
  for (const t of can) {
    const tt = bo(t);
    for (const e of ds) {
      if (e.id === 'unesco_bang' || e.closest('#unesco_bang')) continue;
      const txt = bo(e.innerText || e.textContent || '');
      if (!txt || txt.length > 120) continue;
      if (txt === tt || (txt.indexOf(tt) >= 0 && txt.length <= tt.length + 25)) {
        const r = e.getBoundingClientRect();
        if (r.width > 0 && r.height > 0) { e.click(); return 'da_bam:' + (e.innerText||'').slice(0,60); }
      }
    }
  }
  return 'khong_thay';
})()
"""


def _bang(kenh, html):
    try:
        kenh.chay_js(_JS_BANG % json.dumps(html))
    except Exception:
        pass


def _xoa_bang(kenh):
    try:
        kenh.chay_js(_JS_XOA_BANG)
    except Exception:
        pass


def hoc_nhom(kenh, ma_nhom, bao=None, cho_giay=180):
    """Nghe mang trong luc nguoi dung bam dung chuc nang MOT LAN, roi ghi lai cach goi."""
    n = NHOM[ma_nhom]
    tu_s = MOC_TU.strftime("%d/%m/%Y")
    den_s = MOC_DEN.strftime("%d/%m/%Y")
    html = ("<b>UNESCO - \u0111ang h\u1ecdc c\u00e1ch l\u1ea5y: %s</b><br>"
            "1) M\u1edf \u0111\u00fang ch\u1ee9c n\u0103ng n\u00e0y tr\u00ean c\u1ed5ng.&nbsp;&nbsp; "
            "2) Nh\u1eadp kho\u1ea3ng ng\u00e0y <b>%s</b> \u0111\u1ebfn <b>%s</b>.&nbsp;&nbsp; "
            "3) B\u1ea5m <b>Tra c\u1ee9u</b> m\u1ed9t l\u1ea7n r\u1ed3i ch\u1edd v\u00e0i gi\u00e2y.<br>"
            "<span style='opacity:.85'>Tool ch\u1ec9 ghi l\u1ea1i \u0111\u01b0\u1eddng g\u1ecdi, "
            "kh\u00f4ng \u0111\u1ed9ng v\u00e0o t\u00e0i kho\u1ea3n c\u1ee7a b\u1ea1n.</span>"
            % (n["nhan"], tu_s, den_s))
    _bang(kenh, html)
    if bao:
        bao("Hay bam '%s' tren cong, nhap ngay %s - %s roi bam Tra cuu." % (n["nhan"], tu_s, den_s))

    nghe = BoNghe(kenh)
    nghe.bat()
    # thu tu bam giup nguoi dung (khong bat buoc thanh cong)
    try:
        kq = kenh.chay_js(_JS_BAM_CHU % json.dumps(n["tim"]))
        LOG.ghi("[HOC %s] Tu bam menu: %s" % (ma_nhom, kq))
    except Exception as e:
        LOG.ghi("[HOC %s] Chua bam ho duoc menu: %s" % (ma_nhom, str(e)[:120]))

    t0 = time.time()
    tot_nhat, diem_tot, ly_tot = None, -999, []
    while time.time() - t0 < cho_giay:
        time.sleep(1.0)
        for v in list(nghe.xong):
            nghe.xong.remove(v)
            if "x-unesco-tool" in {k.lower() for k in (v.get("headers") or {})}:
                continue
            d, ly = cham_diem(v, MOC_TU, MOC_DEN)
            if d > diem_tot:
                tot_nhat, diem_tot, ly_tot = v, d, ly
            LOG.ghi("[HOC %s] %s %s -> %d diem (%s)" % (ma_nhom, v.get("method"), v.get("url")[:120], d, "; ".join(ly)))
        if diem_tot >= 80:
            break
    nghe.tat()
    _xoa_bang(kenh)

    if tot_nhat is None or diem_tot < 40:
        return None, ("Chua ghi duoc yeu cau nao cua chuc nang '%s'. "
                      "Hay mo dung chuc nang do, nhap ngay %s - %s roi bam Tra cuu trong luc tool dang hoc."
                      % (n["nhan"], tu_s, den_s))

    url, body = tot_nhat["url"], tot_nhat.get("body") or ""
    than = body + " " + url
    _ds_mau, _kieu_mau, _ = lay_ban_ghi(tot_nhat.get("tra_ve") or "")
    mau = {
        "url": url,
        "method": tot_nhat.get("method", "GET"),
        "body": body,
        "headers": tot_nhat.get("headers", {}),
        "dang_ngay_tu": tim_dang_ngay(than, MOC_TU),
        "dang_ngay_den": tim_dang_ngay(than, MOC_DEN),
        "phan_trang": do_phan_trang(url, body),
        "diem": diem_tot,
        "ly_do": ly_tot,
        "kieu": _kieu_mau,
        "captcha": bool(n.get("captcha")),
        "so_ban_ghi_mau": len(_ds_mau),
        "hoc_luc": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    luu_duong_da_hoc(ma_nhom, mau)
    LOG.ghi("[HOC %s] DA HOC: %s %s (%d diem, %d ban ghi mau)" %
            (ma_nhom, mau["method"], url[:150], diem_tot, mau["so_ban_ghi_mau"]))
    if not (mau["dang_ngay_tu"] and mau["dang_ngay_den"]):
        LOG.ghi("[HOC %s] Luu y: khong thay ngay moc trong yeu cau - khi tai se lay dung khoang ngay "
                "ma trang dang de san." % ma_nhom)
    return mau, ""

# ---------------------------------------------------------------------------
#  TAI DU LIEU MOT NHOM (dung cach goi da hoc)
# ---------------------------------------------------------------------------
def _dat_so(chuoi_url, chuoi_body, mo_ta, gia_tri):
    """Dat lai so trang trong URL hoac body theo mo ta phan trang."""
    if not mo_ta:
        return chuoi_url, chuoi_body
    k = mo_ta["trang"]
    if mo_ta["o"] == "url":
        u = urllib.parse.urlparse(chuoi_url)
        ts = urllib.parse.parse_qsl(u.query, keep_blank_values=True)
        ts = [(a, (str(gia_tri) if a == k else b)) for a, b in ts]
        return urllib.parse.urlunparse(u._replace(query=urllib.parse.urlencode(ts))), chuoi_body
    js = doc_json(chuoi_body or "")
    if isinstance(js, dict):
        js[k] = gia_tri
        return chuoi_url, json.dumps(js, ensure_ascii=False)
    return chuoi_url, chuoi_body


# GD20: cong co the gioi han khoang tra cuu -> chia nho theo so ngay roi gop lai.
DVC_CHIA_NGAY = 31


def chia_khoang_ngay(tu, den, so_ngay=None):
    """Chia [tu, den] thanh cac doan <= so_ngay ngay. Tra ve list (date, date)."""
    if so_ngay is None:
        try:
            so_ngay = int(doc_cai_dat().get("dvc_so_ngay_moi_lan") or DVC_CHIA_NGAY)
        except Exception:
            so_ngay = DVC_CHIA_NGAY
    if so_ngay < 1:
        so_ngay = DVC_CHIA_NGAY
    if not tu or not den or den < tu:
        return [(tu, den)]
    if (den - tu).days + 1 <= so_ngay:
        return [(tu, den)]
    ra, cur = [], tu
    # >= 28 ngay thi cat theo BIEN THANG cho de doi chieu ("thang 3", "thang 4"),
    # thay vi tung doan 31 ngay troi noi qua hai thang.
    theo_thang = so_ngay >= 28
    while cur <= den:
        if theo_thang:
            if cur.month == 12:
                cuoi_thang = date(cur.year, 12, 31)
            else:
                cuoi_thang = date(cur.year, cur.month + 1, 1) - timedelta(days=1)
            het = min(cuoi_thang, den)
        else:
            het = min(cur + timedelta(days=so_ngay - 1), den)
        ra.append((cur, het))
        cur = het + timedelta(days=1)
    return ra


def _tai_mot_doan(kenh, ma_nhom, mau, tu, den, bao=None, toi_da_trang=200):
    """Tai MOT doan ngay. Tra ve (danh_sach, loi)."""
    n = NHOM[ma_nhom]
    url = mau["url"]
    body = mau.get("body") or ""
    if tu and mau.get("dang_ngay_tu"):
        url = thay_ngay(url, mau["dang_ngay_tu"], MOC_TU, tu)
        body = thay_ngay(body, mau["dang_ngay_tu"], MOC_TU, tu)
    if den and mau.get("dang_ngay_den"):
        url = thay_ngay(url, mau["dang_ngay_den"], MOC_DEN, den)
        body = thay_ngay(body, mau["dang_ngay_den"], MOC_DEN, den)

    pt = mau.get("phan_trang")
    trang = pt["trang_dau"] if pt else 0
    buoc = 1
    if pt and pt["o"] == "url" and pt["trang"].lower() in ("start", "offset", "skip", "from"):
        buoc = pt["so_moi_trang"] or 20
    tat_ca, da_thay, so_trang = [], set(), 0
    while so_trang < toi_da_trang:
        u2, b2 = _dat_so(url, body, pt, trang)
        ma, kieu, du = goi_trong_tab(kenh, u2, mau.get("method", "GET"),
                                     b2 if b2 else None, mau.get("headers"))
        if ma != 200:
            if so_trang == 0:
                return [], ("Cong tra ve ma %s cho '%s'. Co the phien dang nhap da het han hoac cong "
                            "doi duong dan - hay bam \"Day tool cach lay\" de hoc lai." % (ma, n["nhan"]))
            LOG.ghi("[TAI %s] Trang %s tra ve ma %s - dung." % (ma_nhom, trang, ma))
            break
        ds, kieu_tv, pt_html = lay_ban_ghi(du.decode("utf-8", "replace"))
        if not kieu_tv:
            if so_trang == 0:
                return [], ("Cong tra ve du lieu khong doc duoc (khong phai JSON, cung khong co bang) "
                            "cho '%s' - hay hoc lai cach lay." % n["nhan"])
            break
        if pt_html.get("tong_trang") and so_trang + 1 >= pt_html["tong_trang"]:
            _het_trang_html = True
        else:
            _het_trang_html = False
        moi = 0
        for r in ds:
            k = json.dumps(r, ensure_ascii=False, sort_keys=True)
            if k in da_thay:
                continue
            da_thay.add(k)
            tat_ca.append(r)
            moi += 1
        so_trang += 1
        if bao:
            bao("%s: da lay %d ban ghi (trang %d)" % (n["ten"], len(tat_ca), so_trang))
        LOG.ghi("[TAI %s] %s..%s trang %s: %d ban ghi (%d moi)"
                % (ma_nhom, tu, den, trang, len(ds), moi))
        if _het_trang_html:
            LOG.ghi("[TAI %s] Bang HTML bao het trang (%s)." % (ma_nhom, pt_html))
            break
        if not pt or moi == 0 or not ds:
            break
        if pt.get("so_moi_trang") and len(ds) < pt["so_moi_trang"]:
            break
        trang += buoc
    if so_trang >= toi_da_trang:
        LOG.ghi("[TAI %s] CANH BAO: cham tran %d trang - hay thu khoang ngay ngan hon."
                % (ma_nhom, toi_da_trang))
    return tat_ca, ""


def gioi_han_ngay(ma_nhom, tu, den):
    """Mot so chuc nang chi tra duoc du lieu TRUOC mot moc ngay (cong ghi ro bang chu do).
       Tra ve (tu, den, ghi_chu). tu=None nghia la ca khoang deu ngoai pham vi."""
    n = NHOM.get(ma_nhom) or {}
    mc = n.get("moc_cuoi")
    if not mc or not tu or not den:
        return tu, den, ""
    ms = mc.strftime("%d/%m/%Y")
    if tu >= mc:
        return None, None, ("Chuc nang '%s' chi tra duoc ho so nop TRUOC ngay %s. "
                            "Khoang ngay ban chon nam hoan toan sau moc do nen khong co gi de lay."
                            % (n.get("ten", ma_nhom), ms))
    if den >= mc:
        den2 = mc - timedelta(days=1)
        return tu, den2, ("Chuc nang '%s' chi tra duoc ho so nop TRUOC ngay %s - da tu cat khoang "
                          "ngay lai den %s." % (n.get("ten", ma_nhom), ms, den2.strftime("%d/%m/%Y")))
    return tu, den, ""


def hung_nhom(kenh, ma_nhom, tu, den, bao=None, cho_giay=300):
    """Man hinh CO MA XAC NHAN (captcha).

    Tool KHONG doc, KHONG giai, KHONG dien captcha, va KHONG phat lai lenh goi -
    vi moi lan tra cuu can mot ma xac nhan moi. Thay vao do tool mo trang, nhac
    nguoi dung tu nhap khoang ngay va ma xac nhan roi bam Tim kiem, va chi HUNG
    ket qua ma chinh trang do nhan ve.

    Tra ve (danh_sach, loi).
    """
    n = NHOM[ma_nhom]
    tu_s = tu.strftime("%d/%m/%Y") if tu else ""
    den_s = den.strftime("%d/%m/%Y") if den else ""
    html_nhac = (
        "<b>UNESCO - \u0111ang ch\u1edd k\u1ebft qu\u1ea3: %s</b><br>"
        "M\u00e0n h\u00ecnh n\u00e0y c\u00f3 <b>m\u00e3 x\u00e1c nh\u1eadn</b> n\u00ean "
        "b\u1ea1n ph\u1ea3i t\u1ef1 nh\u1eadp - tool kh\u00f4ng \u0111i\u1ec1n thay.<br>"
        "1) M\u1edf: <i>%s</i>&nbsp;&nbsp; 2) Nh\u1eadp <b>%s</b> \u0111\u1ebfn <b>%s</b>"
        "&nbsp;&nbsp; 3) Nh\u1eadp m\u00e3 x\u00e1c nh\u1eadn r\u1ed3i b\u1ea5m "
        "<b>T\u00ecm ki\u1ebfm</b>.<br>"
        "<span style='opacity:.85'>N\u1ebfu c\u00f3 nhi\u1ec1u trang, b\u1ea5m sang t\u1eebng "
        "trang - tool nh\u1eadn h\u1ebft. Xong th\u00ec \u0111\u1ee3i v\u00e0i gi\u00e2y.</span>"
        % (n["nhan"], n.get("duong", ""), tu_s, den_s))
    _bang(kenh, html_nhac)
    if bao:
        bao("%s: man hinh co ma xac nhan - hay tu nhap %s - %s va ma xac nhan roi bam Tim kiem."
            % (n["ten"], tu_s, den_s))
    LOG.ghi("[HUNG %s] Cho nguoi dung tu tra cuu (%s - %s). Tool khong dien captcha." %
            (ma_nhom, tu_s, den_s))

    nghe = BoNghe(kenh)
    nghe.bat()
    try:
        kq = kenh.chay_js(_JS_BAM_CHU % json.dumps(n["tim"]))
        LOG.ghi("[HUNG %s] Tu bam menu: %s" % (ma_nhom, kq))
    except Exception as e:
        LOG.ghi("[HUNG %s] Chua bam ho duoc menu: %s" % (ma_nhom, str(e)[:120]))

    t0 = time.time()
    tat_ca, da_thay, lan = [], set(), 0
    im_lang_tu = None
    while time.time() - t0 < cho_giay:
        time.sleep(1.0)
        co_moi = False
        for v in list(nghe.xong):
            nghe.xong.remove(v)
            if "x-unesco-tool" in {k.lower() for k in (v.get("headers") or {})}:
                continue
            if v.get("status", 0) != 200:
                continue
            ds, kieu_tv, pt = lay_ban_ghi(v.get("tra_ve") or "")
            if not ds:
                continue
            moi = 0
            for r in ds:
                k = json.dumps(r, ensure_ascii=False, sort_keys=True, default=str)
                if k in da_thay:
                    continue
                da_thay.add(k)
                tat_ca.append(r)
                moi += 1
            if moi:
                lan += 1
                co_moi = True
                LOG.ghi("[HUNG %s] Hung duoc %d ban ghi moi (%s, tong %d)" %
                        (ma_nhom, moi, kieu_tv, len(tat_ca)))
                if bao:
                    bao("%s: da nhan %d ban ghi." % (n["ten"], len(tat_ca)))
        if co_moi:
            im_lang_tu = time.time()
        elif im_lang_tu and time.time() - im_lang_tu > 25:
            break                      # 25 giay khong co gi moi -> coi nhu nguoi dung xong
    nghe.tat()
    _xoa_bang(kenh)
    if not tat_ca:
        return [], ("Chua nhan duoc ban ghi nao cua '%s'. Man hinh nay co ma xac nhan nen tool "
                    "khong tu tra cuu duoc - hay mo dung chuc nang, nhap khoang ngay va ma xac nhan "
                    "roi bam Tim kiem trong luc tool dang cho." % n["nhan"])
    LOG.ghi("[HUNG %s] Xong: %d ban ghi qua %d lan tra cuu." % (ma_nhom, len(tat_ca), lan))
    return tat_ca, ""


def tai_nhom(kenh, ma_nhom, tu, den, bao=None, toi_da_trang=200):
    """Tra ve (cac_ban_ghi, thong_bao_loi). KHONG doan duong API: chua hoc thi bao ro.
       Khoang ngay dai -> tu chia doan (cong thuong gioi han khoang tra cuu)."""
    n = NHOM[ma_nhom]
    # Man hinh co ma xac nhan: KHONG phat lai lenh goi. Moi lan tra cuu can mot ma
    # xac nhan moi ma tool thi khong doc, khong giai, khong dien captcha.
    if n.get("captcha"):
        return [], ("Man hinh '%s' co ma xac nhan (captcha). Tool khong dien ma xac nhan va khong "
                    "chay lai duoc theo lich - hay dung nut \"Hung ket qua\" roi tu nhap ma tren cong."
                    % n["nhan"])
    tu, den, ghi_chu = gioi_han_ngay(ma_nhom, tu, den)
    if ghi_chu:
        LOG.ghi("[TAI %s] %s" % (ma_nhom, ghi_chu))
        if bao:
            bao(ghi_chu)
    if tu is None:
        return [], ghi_chu
    mau = doc_duong_da_hoc(ma_nhom)
    if not mau:
        return [], ("Chua hoc cach lay '%s'. Bam nut \"Day tool cach lay\" mot lan roi thu lai."
                    % n["nhan"])
    # khong nhan ra o ngay thi chia doan vo nghia (moi doan tra ve cung mot thu)
    if not (mau.get("dang_ngay_tu") and mau.get("dang_ngay_den")):
        return _tai_mot_doan(kenh, ma_nhom, mau, tu, den, bao, toi_da_trang)
    doan = chia_khoang_ngay(tu, den)
    if len(doan) <= 1:
        return _tai_mot_doan(kenh, ma_nhom, mau, tu, den, bao, toi_da_trang)
    LOG.ghi("[TAI %s] Khoang ngay dai - chia thanh %d doan." % (ma_nhom, len(doan)))
    tat_ca, da_co, loi_cuoi = [], set(), ""
    for i, (d1, d2) in enumerate(doan):
        ds, loi = _tai_mot_doan(kenh, ma_nhom, mau, d1, d2, bao, toi_da_trang)
        if loi:
            loi_cuoi = loi
            LOG.ghi("[TAI %s] Doan %d/%d (%s - %s) loi: %s" % (ma_nhom, i + 1, len(doan), d1, d2, loi))
            continue
        for r in ds:
            k = json.dumps(r, ensure_ascii=False, sort_keys=True)
            if k in da_co:
                continue
            da_co.add(k)
            tat_ca.append(r)
        if bao:
            bao("%s: %d/%d doan, tong %d ban ghi" % (n["ten"], i + 1, len(doan), len(tat_ca)))
    if not tat_ca and loi_cuoi:
        return [], loi_cuoi
    if loi_cuoi:
        LOG.ghi("[TAI %s] CANH BAO: co doan loi - so lieu co the chua du: %s" % (ma_nhom, loi_cuoi))
    return tat_ca, ""


# ---------------------------------------------------------------------------
#  CHUAN HOA MOT BAN GHI -> dong cho VB6
# ---------------------------------------------------------------------------
_KHOA_MA = ("mahoso", "masogiaodich", "magiaodich", "matb", "mathongbao", "sothongbao", "sohoso",
            "matokhai", "matkhai", "id", "maso", "magd", "soquyetdinh", "sotb")
_KHOA_NGAY = ("ngaynop", "ngaylap", "ngaytb", "ngaygui", "ngaytao", "ngayhieuluc", "ngayky",
              "ngaynhan", "ngayphathanh", "createddate", "ngay", "ngaychungtu", "ngayhanhthu")
_KHOA_TIEU_DE = ("tenthongbao", "tieude", "tentokhai", "tentkhai", "tenhoso", "noidung", "tenloaithue",
                 "tenmauto", "mauto", "tenthutuc", "tenkhoanmuc", "dienGiai", "diengiai", "mota")
_KHOA_TRANG_THAI = ("trangthai", "tentrangthai", "status", "tinhtrang", "ketqua")
_KHOA_KY = ("kykekhai", "kythue", "ky", "kytinhthue", "thangnam", "kykhaithue")
_KHOA_TIEN = ("sotien", "tienthue", "sophainop", "sotienphainop", "amount", "sotienconnO",
              "sotienconno", "tongtien", "sotiennop")
_KHOA_TEP = ("tentep", "filename", "tenfile", "duongdan", "url", "link", "path", "fileurl", "filepath")
# --- cac cot rieng cua man hinh Nop thue tren cong (doc tu bang HTML) ---
_KHOA_SO_GNT = ("sognt", "soGNT", "sogiaynoptien", "sogiaynop")
_KHOA_MA_HIEU_CT = ("mahieuchungtu", "mahieuct", "kyhieuchungtu")
_KHOA_SO_CT = ("sochungtu", "soct", "sochungtunganhang")
_KHOA_NGAY_NOP = ("ngaynopthue", "ngaynop", "ngaynoptien")
_KHOA_CQ = ("cqthongbao", "coquanthongbao", "cqthue", "coquanthue")
_KHOA_SO_TB = ("sothongbao", "sotb")
_KHOA_MA_GD = ("magiaodich", "magd", "masogiaodich")
_KHOA_LOAI_TB = ("loaithongbao", "tenloaithongbao")
# GD97-A: ho so khai thue (eTax) / nghia vu thue
_KHOA_TO_KHAI = ("tentokhai", "tokhai", "mautokhai", "loaitokhai", "tenhoso", "tenthutuc")
_KHOA_NV_TM = ("tieumuc", "matieumuc", "mandkt", "manoidungkinhte")
_KHOA_NV_CHUONG = ("chuong", "machuong")
_KHOA_NV_ND = ("noidungkinhte", "tentieumuc", "noidung", "loaithue", "sacthue", "khoannop", "tenkhoannop", "diengiai")
_KHOA_NV_CON = ("soconphainop", "sotienconphainop", "conphainop", "soconno", "sono", "sotienno", "sophainopconlai",
                "sodu", "tongsophainop", "sophainop", "sotienphainop", "sotien")
_KHOA_HAN = ("hannop", "hannopthue", "ngayhethannop", "hanchot")
_KHOA_NGAY = _KHOA_NGAY + ("ngaythongbao", "ngaybanhanh", "ngayhachtoan", "ngaygiaodich")


def _link_tai_ve(r):
    """Lay link 'Tai ve' cua mot dong bang HTML (nut ben canh 'Chi tiet')."""
    for a in (r.get("_lien_ket") or []):
        chu = _bo_dau(a.get("chu", "")).lower()
        href = (a.get("href") or "") + " " + (a.get("onclick") or "")
        h = (a.get("href") or "").strip()
        if h in ("#", "") or h.lower().startswith("javascript"):      # GD197: nut chi co onclick (downloadFile('id'))
            h = ""
        if "tai ve" in chu or "taive" in chu or "tai file" in chu or "tai thong bao" in chu:
            return h or a.get("onclick") or ""
        if re.search(r"(?i)tai[-_]?ve|download|export|getfile|taifile|layfile", href):
            return h or a.get("onclick") or ""
    return ""


_BANG_DAU = {}
for _g, _t in ((u"aáàảãạăắằẳẵặâấầẩẫậ", "a"), (u"eéèẻẽẹêếềểễệ", "e"), (u"iíìỉĩị", "i"),
               (u"oóòỏõọôốồổỗộơớờởỡợ", "o"), (u"uúùủũụưứừửữự", "u"),
               (u"yýỳỷỹỵ", "y"), (u"dđ", "d")):
    for _c in _g:
        _BANG_DAU[_c] = _t
        _BANG_DAU[_c.upper()] = _t


def _bo_dau(s):
    return "".join(_BANG_DAU.get(c, c) for c in str(s or ""))


def _chuan_khoa(k):
    """Bo dau roi bo moi ky tu khong phai chu/so: 'S\u1ed1 ch\u1ee9ng t\u1eeb' -> 'sochungtu'."""
    return re.sub(r"[^a-z0-9]", "", _bo_dau(k).lower())


def _lay_theo(d, ds_khoa):
    thap = {_chuan_khoa(k): (k, v) for k, v in d.items()}
    for t in ds_khoa:
        if t in thap:
            k, v = thap[t]
            if v is None:
                continue
            s = str(v).strip()
            if s and s.lower() not in ("none", "null"):
                return s
    return ""


def _chuan_ngay(s):
    if not s:
        return ""
    s = str(s).strip()
    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})", s)
    if m:
        return "%s-%s-%s" % m.groups()
    m = re.match(r"^(\d{2})[/-](\d{2})[/-](\d{4})", s)
    if m:
        return "%s-%s-%s" % (m.group(3), m.group(2), m.group(1))
    if re.fullmatch(r"\d{13}", s):
        try:
            return datetime.fromtimestamp(int(s) / 1000.0).strftime("%Y-%m-%d")
        except Exception:
            return ""
    if re.fullmatch(r"\d{8}", s):
        return "%s-%s-%s" % (s[0:4], s[4:6], s[6:8])
    return ""


def _chuan_tien(s):
    """Doc so tien moi kieu: 12.345.678 / 1.234,56 / 1,234.56 / (1.000) / -1000."""
    if s is None:
        return 0.0
    s = str(s).strip().replace(" ", "").replace("\u00a0", "")
    if not s:
        return 0.0
    am = s.startswith("-") or (s.startswith("(") and s.endswith(")"))
    s = re.sub(r"[^\d.,]", "", s)
    if not s:
        return 0.0
    co_cham, co_phay = "." in s, "," in s
    if co_cham and co_phay:
        # dau nao dung SAU CUNG la dau thap phan
        if s.rfind(",") > s.rfind("."):
            s = s.replace(".", "").replace(",", ".")
        else:
            s = s.replace(",", "")
    elif co_phay:
        duoi = s.split(",")[-1]
        s = s.replace(",", "") if len(duoi) == 3 else s.replace(",", ".")
    elif co_cham:
        duoi = s.split(".")[-1]
        if s.count(".") >= 2 or (len(duoi) == 3 and len(s.replace(".", "")) > 3):
            s = s.replace(".", "")
    try:
        v = float(s)
    except Exception:
        return 0.0
    return -v if am else v

def chuan_hoa_dong(ma_nhom, r, mst):
    ma = _lay_theo(r, _KHOA_MA)
    ngay = _chuan_ngay(_lay_theo(r, _KHOA_NGAY))
    d = {
        "nhom": ma_nhom,
        "ten_nhom": NHOM[ma_nhom]["ten"],
        "mst": mst or _lay_theo(r, ("mst", "masothue", "mstnnt")),
        "ma": ma,
        "ngay": ngay,
        "tieu_de": _lay_theo(r, _KHOA_TIEU_DE),
        "trang_thai": _lay_theo(r, _KHOA_TRANG_THAI),
        "ky": _lay_theo(r, _KHOA_KY),
        "so_tien": _chuan_tien(_lay_theo(r, _KHOA_TIEN)),
        "tep": _lay_theo(r, _KHOA_TEP) or _link_tai_ve(r),
        # --- rieng cho man hinh Nop thue: du lieu de doi chieu voi so phu ngan hang ---
        "so_gnt": _lay_theo(r, _KHOA_SO_GNT),
        "ma_hieu_ct": _lay_theo(r, _KHOA_MA_HIEU_CT),
        "so_ct": _lay_theo(r, _KHOA_SO_CT),
        "ngay_nop": _chuan_ngay(_lay_theo(r, _KHOA_NGAY_NOP)),
        "cq": _lay_theo(r, _KHOA_CQ),
        "so_tb": _lay_theo(r, _KHOA_SO_TB),
        "ma_gd": _lay_theo(r, _KHOA_MA_GD),
        "loai_tb": _lay_theo(r, _KHOA_LOAI_TB),
        "goc": {k: v for k, v in r.items() if k != "_lien_ket"},
    }
    # Khoa chong trung: nhom|ma|ngay (theo bo quy tac chong trung CT).
    # Rieng man hinh Nop thue: MA GIAO DICH KHONG duy nhat - mot giao dich nop thue
    # sinh nhieu thong bao (mot cua ngan hang, mot cua co quan thue) dung chung ma
    # giao dich. Cai duy nhat la SO THONG BAO. Lay nham thi hai thong bao khac nhau
    # co cung khoa va mot cai bi nuot mat.
    if ma_nhom in ("TB", "GNT"):
        rieng = d["so_tb"] or d["so_gnt"] or d["so_ct"]
        if rieng:
            ma = rieng
            d["ma"] = ma
    if not ma:
        ma = d["so_tb"] or d["so_gnt"] or d["so_ct"]
        d["ma"] = ma
    if not ngay:
        ngay = d["ngay_nop"]
        d["ngay"] = ngay
    # GD97-A: ho so khai thue - ten to khai; nghia vu thue - tieu muc / so con phai nop / han nop, khoa theo ngay lay
    if not d["tieu_de"]:
        d["tieu_de"] = d["loai_tb"] or _lay_theo(r, _KHOA_TO_KHAI)
    if ma_nhom == "HSK":
        d["tieu_de"] = d["tieu_de"] or _lay_theo(r, _KHOA_TO_KHAI)
    if ma_nhom == "NV":
        tm = _lay_theo(r, _KHOA_NV_TM)
        ch = _lay_theo(r, _KHOA_NV_CHUONG)
        d["tieu_de"] = _lay_theo(r, _KHOA_NV_ND) or d["tieu_de"]
        d["so_tien"] = _chuan_tien(_lay_theo(r, _KHOA_NV_CON))
        han = _chuan_ngay(_lay_theo(r, _KHOA_HAN))
        if han:
            ngay = han
            d["ngay"] = han
        ma = (tm + ("/" + ch if ch else "")) or ma
        d["ma"] = ma
        rut = hashlib.md5(json.dumps(d["goc"], ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()[:8]
        d["khoa"] = "NV|%s|%s|%s|%s" % (ma, d.get("ky", ""), rut, date.today().isoformat())
        return d
    khoa = "%s|%s|%s" % (ma_nhom, ma, ngay)
    if not ma:
        # bam ON DINH giua cac lan chay (hash() cua Python doi moi lan chay -> chong trung sai)
        rut = json.dumps(r, ensure_ascii=False, sort_keys=True)[:2000]
        khoa = "%s|H%s|%s" % (ma_nhom, hashlib.md5(rut.encode("utf-8")).hexdigest()[:12], ngay)
    d["khoa"] = khoa
    return d

# ---------------------------------------------------------------------------
#  TEP DINH KEM
# ---------------------------------------------------------------------------
_DUOI_TEP = (".pdf", ".xml", ".xls", ".xlsx", ".doc", ".docx", ".zip", ".rar", ".png", ".jpg")


def _duong_tep(gt):
    """Gia tri co phai duong dan tep tren chinh cong khong."""
    s = (gt or "").strip()
    if not s or len(s) > 500:
        return ""
    if s.startswith("http"):
        return s if _la_cong(s) else ""          # GD97-A: tep dinh kem tren eTax
    if s.startswith("/") and s.lower().endswith(_DUOI_TEP + ("=", "")):
        return TRANG_DVC + s
    if s.startswith("/") and ("down" in s.lower() or "file" in s.lower() or "tai" in s.lower()):
        return TRANG_DVC + s
    return ""


def _thu_muc_ky(goc, d):
    """Xep tep theo ky: <goc>\\<nam>\\<thang>. Khong biet ngay thi vao 'khong-ro-ky'."""
    ngay = d.get("ngay_nop") or d.get("ngay") or ""
    m = re.match(r"^(\d{4})-(\d{2})", str(ngay))
    if m:
        return os.path.join(goc, m.group(1), m.group(2))
    return os.path.join(goc, "khong-ro-ky")


def _ten_khong_trung(thu_muc, ten):
    """Them _2, _3... neu da co tep cung ten - khong bao gio ghi de tep cu."""
    goc, duoi = os.path.splitext(ten)
    dich = os.path.join(thu_muc, ten)
    i = 2
    while os.path.exists(dich) and i < 500:
        dich = os.path.join(thu_muc, "%s_%d%s" % (goc, i, duoi))
        i += 1
    return dich


def _doan_duoi(kieu_nd, du, mac_dinh=".xml"):
    k = (kieu_nd or "").lower()
    if "xml" in k:
        return ".xml"
    if "pdf" in k:
        return ".pdf"
    if "zip" in k:
        return ".zip"
    if "excel" in k or "spreadsheet" in k:
        return ".xlsx"
    if "html" in k:
        return ".html"
    dau = (du or b"")[:200].lstrip()
    if dau.startswith(b"%PDF"):
        return ".pdf"
    if dau.startswith(b"PK"):
        return ".zip"
    if dau.startswith(b"<?xml") or dau.startswith(b"<"):
        return ".xml"
    return mac_dinh


_JS_BAM_TAI = r"""
(() => {
  const can = %s, thu = %s;
  const ds = Array.from(document.querySelectorAll('a,button,input[type=button],span'))
      .filter(e => (e.getAttribute('onclick') || '').replace(/\s+/g, '') === can.replace(/\s+/g, ''));
  if (!ds.length) return 'khong_thay';
  const e = ds[Math.min(thu, ds.length - 1)];
  e.click();
  return 'da_bam';
})()
"""


def _khoa_tep(d):
    """Khoa nho 'da tai': nhom|ma (so thong bao / ma giao dich ...) - khong co ma thi theo noi dung dong."""
    ma = (d.get("ma") or "").strip()
    if ma:
        return "%s|%s" % (d.get("nhom", ""), ma)
    return "%s|%s" % (d.get("nhom", ""), hashlib.md5(json.dumps(d.get("goc") or {}, ensure_ascii=False, sort_keys=True)
                                                      .encode("utf-8")).hexdigest())


def _doc_da_tai(thu_muc):
    try:
        with io.open(os.path.join(thu_muc, "da_tai.json"), "r", encoding="utf-8") as f:
            return json.load(f) or {}
    except Exception:
        return {}


def _ghi_da_tai(thu_muc, ds):
    try:
        os.makedirs(thu_muc, exist_ok=True)
        tam = os.path.join(thu_muc, "da_tai.json.tmp")
        with io.open(tam, "w", encoding="utf-8") as f:
            json.dump(ds, f, ensure_ascii=False, indent=1)
        os.replace(tam, os.path.join(thu_muc, "da_tai.json"))
    except Exception as e:
        LOG.ghi("[TEP] Khong ghi duoc da_tai.json: %s" % str(e)[:120])


def _fetch_khung(kenh, ctx, url, timeout=90):
    """GD197: tai TRONG khung dang hien bang (thuedientu.gdt.gov.vn trong iframe) - cung nguon, cung phien dang nhap.
    Truoc day tai bang trang chinh dichvucong + ghep nham ten mien -> may chu tra 503."""
    tuy = {"method": "GET", "credentials": "include", "headers": {"X-Unesco-Tool": "dvc"}}
    p = {"expression": _JS_FETCH % (json.dumps(url), json.dumps(tuy)), "awaitPromise": True, "returnByValue": True}
    if ctx:
        p["contextId"] = ctx
    kq = kenh.goi("Runtime.evaluate", p, timeout=timeout)
    try:
        o = json.loads(kq.get("result", {}).get("value") or "{}")
    except Exception:
        return 0, "", b""
    if not o.get("s"):
        return 0, "", (o.get("e") or "").encode("utf-8", "replace")
    return int(o["s"]), o.get("t", ""), base64.b64decode(o.get("d") or "")


def _cho_tep_moi(thu_muc, truoc, cho=25):
    """Cho Chrome tai xong (khong con .crdownload) mot tep moi trong thu muc -> duong dan hoac ''."""
    t0 = time.time()
    while time.time() - t0 < cho:
        try:
            moi = [f for f in os.listdir(thu_muc) if f not in truoc and not f.endswith((".crdownload", ".tmp"))]
            dang = [f for f in os.listdir(thu_muc) if f.endswith(".crdownload")]
        except Exception:
            return ""
        if moi and not dang:
            moi.sort(key=lambda f: os.path.getmtime(os.path.join(thu_muc, f)))
            return os.path.join(thu_muc, moi[-1])
        time.sleep(0.5)
    return ""


def _dat_thu_muc_tai(thu_muc):
    """Browser.setDownloadBehavior: tep Chrome tai (nut chi co onclick) vao thu muc nay. True neu dat duoc."""
    try:
        with urllib.request.urlopen("http://127.0.0.1:%d/json/version" % CHROME["cong"], timeout=5) as r:
            ws = json.loads(r.read().decode("utf-8")).get("webSocketDebuggerUrl")
        if not ws:
            return False
        k = CHROME.get("kenh_trinh_duyet")
        if k is None or k.loi_ket_noi:
            k = KenhCDP(ws, timeout=30)
            CHROME["kenh_trinh_duyet"] = k
        k.goi("Browser.setDownloadBehavior", {"behavior": "allow", "downloadPath": os.path.abspath(thu_muc)}, timeout=15)
        return True
    except Exception as e:
        LOG.ghi("[TEP] Khong dat duoc thu muc tai cua Chrome: %s" % str(e)[:150])
        return False


def _tra_thu_muc_tai():
    try:
        k = CHROME.get("kenh_trinh_duyet")
        if k is not None:
            k.goi("Browser.setDownloadBehavior", {"behavior": "default"}, timeout=10)
    except Exception:
        pass


def tai_tep_dinh_kem(kenh, dong, thu_muc, bao=None, khung=None):
    """Tai tep dinh kem cua tung dong (nut 'Tai ve'), xep theo ky.

    GD197 (anh Thang 11/10/2026): dang nhap xong tai HET tep cua cac dong tim duoc, CO ROI THI KHONG TAI:
      - nho cac tep da tai trong <thu_muc>/da_tai.json (khoa nhom|so thong bao / ma); tep con tren dia -> bo qua;
      - link tuong doi ghep theo DIA CHI KHUNG dang hien bang (thuedientu...), tai TRONG khung do (khung=(kenh, ctx, url));
      - nut chi co onclick (downloadFile('id') / layFileTBao(...)): bam nut trong khung, Chrome tai vao thu muc ky.
    Khong doan duong tai: dong khong co nut tai thi bo qua.
    """
    n = bo_qua = loi = 0
    da = _doc_da_tai(thu_muc)
    k_kh, ctx_kh, url_kh = (khung or (None, None, ""))
    dat_tai = False
    dem_onclick = {}
    try:
        for d in dong:
            khoa = _khoa_tep(d)
            cu = da.get(khoa)
            if cu and os.path.exists(cu):
                d["tep_da_tai"] = cu
                bo_qua += 1
                continue
            if d.get("tep_da_tai") and os.path.exists(d["tep_da_tai"]):
                continue
            tep = (d.get("tep") or "").strip()
            url, onclick = "", ""
            if re.search(r"^[A-Za-z_$][\w$.]*\s*\(", tep):
                onclick = tep
            elif tep:
                if k_kh is not None and url_kh and (tep.startswith("/") or tep.startswith("Request")):
                    url = urllib.parse.urljoin(url_kh, tep)
                    url = url if _la_cong(url) else ""
                else:
                    url = _duong_tep(tep)
            if not url and not onclick:
                for v in (d.get("goc") or {}).values():
                    url = _duong_tep(v if isinstance(v, str) else "")
                    if url:
                        break
            if not url and not onclick:
                continue
            tm = _thu_muc_ky(thu_muc, d)
            try:
                os.makedirs(tm, exist_ok=True)
            except Exception:
                continue
            dinh = re.sub(r'[\\/:*?"<>|]', "_", (d.get("ma") or "x"))[:60]
            if onclick:
                if k_kh is None:
                    continue
                if not dat_tai:
                    dat_tai = _dat_thu_muc_tai(tm)
                    if not dat_tai:
                        k_kh = None
                        continue
                else:
                    _dat_thu_muc_tai(tm)
                truoc = set(os.listdir(tm))
                thu = dem_onclick.get(onclick, 0)
                dem_onclick[onclick] = thu + 1
                try:
                    kq = _chay_trong(k_kh, _JS_BAM_TAI % (json.dumps(onclick), thu), ctx_kh)
                except Exception as e:
                    kq = "loi " + str(e)[:80]
                if kq != "da_bam":
                    LOG.ghi("[TEP] Khong bam duoc nut tai %s: %s" % (onclick[:80], kq))
                    loi += 1
                    continue
                f = _cho_tep_moi(tm, truoc)
                if not f:
                    LOG.ghi("[TEP] Bam %s nhung khong thay tep tai ve" % onclick[:80])
                    loi += 1
                    continue
                dich = _ten_khong_trung(tm, "%s_%s%s" % (d.get("nhom", "DVC"), dinh, os.path.splitext(f)[1] or ".xml"))
                try:
                    os.replace(f, dich)
                except Exception:
                    dich = f
            else:
                goc_ten = os.path.basename(urllib.parse.urlparse(url).path) or ""
                goc_ten = re.sub(r'[\\/:*?"<>|]', "_", goc_ten)[:80]
                try:
                    if k_kh is not None and urllib.parse.urlparse(url).netloc == urllib.parse.urlparse(url_kh).netloc:
                        ma, kieu, du = _fetch_khung(k_kh, ctx_kh, url)
                    else:
                        ma, kieu, du = goi_trong_tab(kenh, url, "GET")
                except Exception as e:
                    LOG.ghi("[TEP] Khong tai duoc %s: %s" % (url[:120], str(e)[:120]))
                    loi += 1
                    continue
                if ma != 200 or not du:
                    LOG.ghi("[TEP] %s tra ve ma %s" % (url[:120], ma))
                    loi += 1
                    continue
                duoi = os.path.splitext(goc_ten)[1]
                if duoi.lower() in ("", ".do", ".jsp", ".action") or "request" in goc_ten.lower():
                    duoi = _doan_duoi(kieu, du)
                dich = _ten_khong_trung(tm, "%s_%s%s" % (d.get("nhom", "DVC"), dinh, duoi))
                try:
                    with open(dich, "wb") as f:
                        f.write(du)
                except Exception as e:
                    LOG.ghi("[TEP] Khong ghi duoc %s: %s" % (dich, str(e)[:120]))
                    continue
            d["tep_da_tai"] = dich
            da[khoa] = dich
            n += 1
            if bao and n % 5 == 0:
                bao("Da tai %d tep dinh kem..." % n)
    finally:
        if dat_tai:
            _tra_thu_muc_tai()
        if n:
            _ghi_da_tai(thu_muc, da)
    LOG.ghi("[TEP] Tai moi %d tep, %d tep da co (khong tai lai), %d loi - %s" % (n, bo_qua, loi, thu_muc))
    if bao and (n or bo_qua):
        bao("Tep dinh kem: tai moi %d, da co %d (khong tai lai)%s" % (n, bo_qua, (", %d loi" % loi) if loi else ""))
    return n


# ---------------------------------------------------------------------------
#  GHI KET QUA CHO VB6
# ---------------------------------------------------------------------------
def ghi_ket_qua(cac_dong, tong, out, co_ket="DA_XONG_DVC"):
    kq = thu_muc_kq(out)
    ts = datetime.now().strftime("%Y%m%d%H%M%S")
    ten = "dvc_%s_%s" % (tong.get("mst") or "CHUNG", ts)
    duong = os.path.join(kq, ten + ".jsonl.tmp")
    with open(duong, "w", encoding="utf-8") as f:
        for d in cac_dong:
            f.write(json.dumps(d, ensure_ascii=False) + "\n")
    cuoi = duong[:-4]
    os.replace(duong, cuoi)
    with open(os.path.join(kq, ten + "_tong.json"), "w", encoding="utf-8") as f:
        json.dump(tong, f, ensure_ascii=False, indent=2)
    try:
        with open(os.path.join(kq, co_ket), "w", encoding="utf-8") as f:
            f.write(cuoi)
    except Exception:
        pass
    LOG.ghi("Da ghi %s: %d dong" % (os.path.basename(cuoi), len(cac_dong)))
    return cuoi


def ghi_khong_co(out, ly_do, co_ket="DA_XONG_DVC"):
    try:
        with open(os.path.join(thu_muc_kq(out), co_ket), "w", encoding="utf-8") as f:
            f.write("KHONG_CO_DU_LIEU " + (ly_do or "")[:500])
    except Exception:
        pass
    LOG.ghi("KHONG CO DU LIEU: " + (ly_do or ""))
    if BAO_GD is not None:          # GD120: hien ly do trong cua so tool
        try:
            BAO_GD("KET_THUC " + (ly_do or ""))
        except Exception:
            pass


def luu_json_tho(out, ma_nhom, ds):
    """Giu nguyen ban ghi tho de sau nay con doi chieu duoc."""
    try:
        d = os.path.join(out or BASE_DIR, "dvc", "tho")
        os.makedirs(d, exist_ok=True)
        t = os.path.join(d, "dvc_tho_%s_%s.json" % (ma_nhom, datetime.now().strftime("%Y%m%d%H%M%S")))
        with open(t, "w", encoding="utf-8") as f:
            json.dump(ds, f, ensure_ascii=False, indent=1)
        return t
    except Exception as e:
        LOG.loi("Khong luu duoc JSON tho", e)
        return ""


# ===========================================================================
#  GD97-A - DOC THANG BANG KET QUA TREN MAN HINH (MOI KHUNG, KE CA eTax)
#  Bam "Tra cuu thong bao / GNT ..." tren cong DVC, cong chuyen sang he thong thuedientu.gdt.gov.vn (eTax)
#  NAM TRONG KHUNG (iframe) - ban truoc chi nghe dichvucong.gdt.gov.vn nen hoc nham trang khac va khong lay duoc.
#  Nay tool doc thang BANG KET QUA dang hien (trang chinh + moi khung cua *.gdt.gov.vn), tu nhan nhom theo tieu
#  de cot, tu lat trang, doc MST dang nhap de doi chieu cong ty. Khong dien / khong vuot ma xac nhan, khong nop gi.
# ===========================================================================
def _la_cong(url):
    """Dia chi thuoc cong Thue (*.gdt.gov.vn): dichvucong, thuedientu (eTax), ..."""
    try:
        h = (urllib.parse.urlparse(url or "").hostname or "").lower()
    except Exception:
        return False
    return h == "gdt.gov.vn" or h.endswith(".gdt.gov.vn")


TEP_CONG = os.path.join(CHROME_HO_SO, "unesco-cong.txt")


def _cong_dang_chay():
    """Chrome ho so rieng DA MO tu lan truoc (cong go loi luu o TEP_CONG) -> so cong; khong -> 0.
       Mo Chrome lan hai cung ho so: Chrome chuyen sang cua so cu va bo qua cong moi -> truoc day tool 'mat ket noi'."""
    try:
        with open(TEP_CONG, "r", encoding="utf-8") as f:
            c = int((f.read() or "0").strip())
    except Exception:
        return 0
    if c <= 0:
        return 0
    try:
        with urllib.request.urlopen("http://127.0.0.1:%d/json/version" % c, timeout=2) as r:
            r.read()
        return c
    except Exception:
        return 0


def _luu_cong(c):
    try:
        os.makedirs(CHROME_HO_SO, exist_ok=True)
        with open(TEP_CONG, "w", encoding="utf-8") as f:
            f.write(str(c))
    except Exception:
        pass


def _mo_tab_moi(url):
    for m in ("PUT", "GET"):
        try:
            req = urllib.request.Request("http://127.0.0.1:%d/json/new?%s" % (CHROME["cong"], url), method=m)
            with urllib.request.urlopen(req, timeout=10) as r:
                r.read()
            return True
        except Exception:
            continue
    return False


def cac_khung():
    """[(id, loai, url, ws)] trang + khung (iframe tach tien trinh) cua cong thue dang mo trong Chrome."""
    try:
        with urllib.request.urlopen("http://127.0.0.1:%d/json/list" % CHROME["cong"], timeout=5) as r:
            ds = json.loads(r.read().decode("utf-8"))
    except Exception:
        return []
    ra = []
    for t in ds:
        if t.get("type") in ("page", "iframe") and _la_cong(t.get("url", "")) and t.get("webSocketDebuggerUrl"):
            ra.append((t.get("id"), t.get("type"), t.get("url", ""), t["webSocketDebuggerUrl"]))
    return ra


KHUNG = {}


def kenh_khung(tid, ws):
    k = KHUNG.get(tid)
    if k is not None and not k.loi_ket_noi:
        return k
    try:
        k = KenhCDP(ws, timeout=60)
        KHUNG[tid] = k
        return k
    except Exception:
        return None


def _chay_trong(kenh, js, ctx=None, timeout=60):
    """Runtime.evaluate trong trang (ctx=None) hoac trong mot khung cung tien trinh (contextId)."""
    p = {"expression": js, "awaitPromise": False, "returnByValue": True}
    if ctx:
        p["contextId"] = ctx
    kq = kenh.goi("Runtime.evaluate", p, timeout=timeout)
    if kq.get("exceptionDetails"):
        raise IOError("JS loi: " + json.dumps(kq["exceptionDetails"].get("exception", {}).get("description", ""))[:300])
    return kq.get("result", {}).get("value")


def _ngu_canh_khung(kenh):
    """contextId cho tung khung con CUNG tien trinh (frame cross-origin cung tien trinh: JS trang chinh khong doc duoc)."""
    ra = []
    try:
        cay = kenh.goi("Page.getFrameTree", {}, timeout=20).get("frameTree") or {}
    except Exception:
        return ra
    ds = []

    def _duyet(n, sau):
        for c in (n.get("childFrames") or []):
            f = c.get("frame") or {}
            if _la_cong(f.get("url", "")):
                ds.append(f.get("id"))
            if sau < 6:
                _duyet(c, sau + 1)
    _duyet(cay, 0)
    for fid in ds[:12]:
        try:
            r = kenh.goi("Page.createIsolatedWorld", {"frameId": fid, "worldName": "unesco_doc", "grantUniveralAccess": False}, timeout=20)
            if r.get("executionContextId"):
                ra.append(r["executionContextId"])
        except Exception:
            continue
    return ra


_JS_LAY_BANG = r"""
(() => {
  const vis = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
  const out = {u: location.href, t: document.title, b: [], x: '', ky: ''};
  const ts = Array.from(document.querySelectorAll('table'));
  let la = ts.filter(t => vis(t) && t.rows && t.rows.length >= 2 && !t.querySelector('table'));
  if (!la.length) la = ts.filter(t => vis(t) && t.rows && t.rows.length >= 2);
  for (const t of la.slice(0, 40)) out.b.push(t.outerHTML.slice(0, 3000000));
  out.x = (document.body ? document.body.innerText : '').slice(0, 30000);
  let lon = null;
  for (const t of la) if (!lon || t.rows.length > lon.rows.length) lon = t;
  if (lon) out.ky = lon.rows.length + '|' + Array.from(lon.rows).slice(1, 4).map(r => r.innerText).join('#').slice(0, 600);
  return JSON.stringify(out);
})()
"""

_JS_KY_BANG = r"""
(() => {
  const vis = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
  let lon = null;
  for (const t of document.querySelectorAll('table')) {
    if (!vis(t) || !t.rows || t.rows.length < 2 || t.querySelector('table')) continue;
    if (!lon || t.rows.length > lon.rows.length) lon = t;
  }
  return lon ? (lon.rows.length + '|' + Array.from(lon.rows).slice(1, 4).map(r => r.innerText).join('#').slice(0, 600)) : '';
})()
"""

_JS_TRANG_SAU = r"""
(() => {
  const bo = s => (s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/đ/g, 'd').replace(/\s+/g, ' ').trim();
  const vis = e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
  const tat = e => { const c = ((e.className || '') + ' ' + ((e.parentElement && e.parentElement.className) || '')).toString();
                     return e.disabled || /disabled|inactive/i.test(c) || e.getAttribute('aria-disabled') === 'true'; };
  const ds = Array.from(document.querySelectorAll('a,button,input[type=button],input[type=submit],li,span'));
  for (const w of ['trang sau', 'trang tiep', 'tiep theo', 'sau', 'tiep', 'next', '>', '›']) {
    for (const e of ds) {
      if (!vis(e)) continue;
      const tx = bo(e.innerText || e.value || e.title || e.getAttribute('aria-label') || '');
      if (tx !== w || tat(e)) continue;
      e.click(); return 'bam:' + w;
    }
  }
  let cur = 0;
  for (const e of ds) {
    const tx = (e.innerText || '').trim();
    if (!/^\d{1,3}$/.test(tx) || !vis(e)) continue;
    const c = ((e.className || '') + ' ' + ((e.parentElement && e.parentElement.className) || '')).toString();
    if (/active|current|selected/i.test(c)) { cur = parseInt(tx, 10); break; }
  }
  if (cur > 0) {
    for (const e of ds) {
      if ((e.innerText || '').trim() === String(cur + 1) && vis(e) && !tat(e)) { e.click(); return 'bam:so ' + (cur + 1); }
    }
  }
  return 'het';
})()
"""

_JS_MST_DANG_NHAP = r"""
(() => {
  const t = (document.body ? document.body.innerText : '') || '';
  const m = t.match(/(?:Mã số thuế|MST|Người nộp thuế)\s*[:\-]?\s*(\d{10}(?:-\d{3})?)(?!\d)/i)
         || t.match(/(?:^|\s)(\d{10}(?:-\d{3})?)(?!\d)\s*[-–]\s*[A-ZÀ-ỹ]/);
  if (!m) return '';
  let ten = '';
  const i = t.indexOf(m[1]);
  if (i >= 0) { const sau = t.slice(i + m[1].length, i + m[1].length + 140).split('\n')[0]; ten = sau.replace(/^[\s\-–:]+/, '').trim(); }
  return m[1] + '|' + ten.slice(0, 120);
})()
"""

# dau hieu tieu de cot cua tung nhom (chu da bo dau, viet thuong)
DAU_HIEU = collections.OrderedDict([
    ("TB", [r"so thong bao|ma thong bao", r"loai thong bao|ten thong bao|noi dung thong bao|trich yeu", r"ngay thong bao|ngay ban hanh|ngay gui|ngay ky"]),
    ("GNT", [r"so gnt|giay nop tien|so giay nop", r"ma hieu chung tu|so chung tu|so tham chieu", r"ngay nop|ngay chung tu|ngay hach toan", r"so tien"]),
    ("HSK", [r"ma giao dich|ma ho so", r"to khai|mau to khai|loai to khai|ten ho so", r"ky tinh thue|ky ke khai|ky thue|ky bao cao", r"lan nop|ngay nop|lan bo sung"]),
    ("NV", [r"phai nop|con no|con phai nop|no thue|nop thua|so du", r"tieu muc|chuong|noi dung kinh te|loai thue|sac thue|khoan nop", r"han nop|ky thue|ky tinh thue"]),
])


def _bo_dau_thuong(s):
    return re.sub(r"\s+", " ", _bo_dau(s).lower()).strip()


def nhan_nhom_bang(cot):
    """Ten cac cot -> (ma nhom, diem). Diem < 2 -> khong chac."""
    k = " | ".join(_bo_dau_thuong(c) for c in cot if c and not str(c).startswith("_"))
    tot, diem_tot = "", 0
    for ma, ds in DAU_HIEU.items():
        d = sum(1 for rx in ds if re.search(rx, k))
        if ma == "TB" and re.search(r"so thong bao", k):
            d += 1
        if ma == "GNT" and re.search(r"so gnt|giay nop tien", k):
            d += 1
        if d > diem_tot:
            tot, diem_tot = ma, d
    return tot, diem_tot


def _chon_bang_nhom(cac_html, nhom_goi_y="", cot_mau=None):
    """Trong cac bang dang hien: chon bang ket qua (nhan nhom theo tieu de cot).
       cot_mau: cot cua bang o trang truoc (dang lat trang) -> uu tien dung bang do.
       Nhan nhom chi khi du dau hieu (diem >= 2) - goi y khong du de gan nhom cho bang la.
       -> (nhom, dong, phan_trang, diem, cot)."""
    tot = ("", [], {}, -1, [])
    for h in cac_html:
        ds, pt = doc_bang_html(h)
        if not ds:
            continue
        cot = [k for k in ds[0].keys() if k != "_lien_ket"]
        nhom, d0 = nhan_nhom_bang(cot)
        d = d0
        if nhom_goi_y and nhom == nhom_goi_y and d0 >= 2:
            d += 2
        if cot_mau is not None and cot == list(cot_mau):
            d += 10
        diem = d * 100 + min(len(ds), 99)
        if diem > tot[3]:
            tot = (nhom if d0 >= 2 else "", ds, pt, diem, cot)
    return tot


def doc_khung_dang_mo(nhom_goi_y="", chi_tid=None, cot_mau=None):
    """Doc bang ket qua dang hien o MOI trang / khung cua cong thue (chi_tid: chi trong trang / khung do).
       -> dict {nhom, dong, pt, kenh, ctx, ky, url, text, tid, cot} hoac None."""
    tot, diem_tot = None, -1
    for tid, loai, url, ws in cac_khung():
        if chi_tid and tid != chi_tid:
            continue
        k = kenh_khung(tid, ws)
        if k is None:
            continue
        for ctx in [None] + _ngu_canh_khung(k):
            try:
                o = json.loads(_chay_trong(k, _JS_LAY_BANG, ctx) or "{}")
            except Exception:
                continue
            nhom, ds, pt, diem, cot = _chon_bang_nhom(o.get("b") or [], nhom_goi_y, cot_mau)
            if not ds:
                continue
            if not pt:
                pt = doc_phan_trang_html(o.get("x") or "")
            if diem > diem_tot:
                tot, diem_tot = {"nhom": nhom, "dong": ds, "pt": pt, "kenh": k, "ctx": ctx, "ky": o.get("ky", ""),
                                 "url": o.get("u", url), "text": o.get("x", ""), "tid": tid, "cot": cot}, diem
    return tot


def lat_trang(kenh, ctx, ky_cu, cho=15):
    """Bam 'trang sau' trong khung chua bang; doi den khi bang doi (ky bang khac). True = da sang trang moi."""
    try:
        kq = _chay_trong(kenh, _JS_TRANG_SAU, ctx)
    except Exception:
        return False
    if not str(kq or "").startswith("bam:"):
        return False
    t0 = time.time()
    while time.time() - t0 < cho:
        time.sleep(0.8)
        try:
            ky = _chay_trong(kenh, _JS_KY_BANG, ctx)
        except Exception:
            # khung tai lai (form submit) -> ngu canh cu mat: doc lai o vong ngoai
            return True
        if ky and ky != ky_cu:
            return True
    return False


def doc_het_trang(nhom_goi_y="", toi_da=100, bao=None):
    """Doc bang dang mo + tu lat trang den het. -> (nhom, ds_dong, thong_tin) ; ds rong neu khong thay bang."""
    dau = doc_khung_dang_mo(nhom_goi_y)
    if not dau:
        return nhom_goi_y, [], {}
    nhom = dau["nhom"] or nhom_goi_y
    tat_ca, da_thay, so_trang = [], set(), 0
    hien = dau
    while hien and so_trang < toi_da:
        moi = 0
        for r in hien["dong"]:
            k = json.dumps({a: b for a, b in r.items() if a != "_lien_ket"}, ensure_ascii=False, sort_keys=True)
            if k in da_thay:
                continue
            da_thay.add(k)
            tat_ca.append(r)
            moi += 1
        so_trang += 1
        if bao:
            bao("Da doc %d dong (trang %d)" % (len(tat_ca), so_trang))
        LOG.ghi("[DOC BANG %s] trang %d: %d dong (%d moi) - %s" % (nhom or "?", so_trang, len(hien["dong"]), moi, (hien.get("url") or "")[:100]))
        pt = hien.get("pt") or {}
        if pt.get("tong_trang") and so_trang >= pt["tong_trang"]:
            break
        if moi == 0 and so_trang > 1:
            break
        ky_cu, dau_cu = hien.get("ky", ""), (hien["dong"][0] if hien["dong"] else None)
        if not lat_trang(hien["kenh"], hien["ctx"], ky_cu):
            break
        # doc lai DUNG bang do (cung trang / khung, cung cot); khung co the dang tai lai -> cho toi 12 giay
        hien, t1 = None, time.time()
        while time.time() - t1 < 12:
            h = doc_khung_dang_mo(nhom, chi_tid=dau.get("tid"), cot_mau=dau.get("cot"))
            if not h or h.get("cot") != dau.get("cot"):
                h = doc_khung_dang_mo(nhom, cot_mau=dau.get("cot"))
            if h and h.get("cot") == dau.get("cot") and h["dong"] and \
                    (h.get("ky") != ky_cu or h["dong"][0] != dau_cu):
                hien = h
                break
            time.sleep(1)
        if hien is None:
            LOG.ghi("[DOC BANG %s] sau khi lat trang khong thay lai bang cung cot - dung o trang %d" % (nhom or "?", so_trang))
    return nhom, tat_ca, {"so_trang": so_trang, "url": dau.get("url", ""), "kenh": dau.get("kenh"), "ctx": dau.get("ctx")}


def mst_dang_nhap():
    """MST tai khoan dang nhap (doc tren trang / khung cua cong). -> (mst, ten) - rong neu khong doc duoc."""
    for tid, loai, url, ws in cac_khung():
        k = kenh_khung(tid, ws)
        if k is None:
            continue
        try:
            s = _chay_trong(k, _JS_MST_DANG_NHAP) or ""
        except Exception:
            continue
        if s:
            a = s.split("|", 1)
            return re.sub(r"[^0-9-]", "", a[0]), (a[1] if len(a) > 1 else "").strip()
    return "", ""


def _cung_mst(a, b):
    a, b = re.sub(r"\D", "", a or "")[:10], re.sub(r"\D", "", b or "")[:10]
    return bool(a) and a == b


_JS_BANG_NUT = r"""
(() => {
  let d = document.getElementById('unesco_bang');
  if (!d) { d = document.createElement('div'); d.id = 'unesco_bang'; document.body.appendChild(d); }
  d.setAttribute('style', 'position:fixed;z-index:2147483647;left:0;right:0;top:0;padding:8px 14px;'
    + 'background:#0b5ed7;color:#fff;font:14px/1.5 Tahoma,Arial,sans-serif;box-shadow:0 2px 8px rgba(0,0,0,.3)');
  d.innerHTML = %s
    + '<div style="margin-top:6px">'
    + '<button id="unesco_lay" style="font:bold 14px Tahoma;padding:4px 14px;margin-right:10px;cursor:pointer">Lấy bảng này</button>'
    + '<button id="unesco_xong" style="font:14px Tahoma;padding:4px 14px;cursor:pointer">Xong</button></div>';
  window.__unesco_lenh = window.__unesco_lenh || '';
  document.getElementById('unesco_lay').onclick = () => { window.__unesco_lenh = 'lay'; };
  document.getElementById('unesco_xong').onclick = () => { window.__unesco_lenh = 'xong'; };
  return 'ok';
})()
"""

_JS_DOC_LENH = "(() => { const l = window.__unesco_lenh || ''; window.__unesco_lenh = ''; return l; })()"


def che_do_doc_bang(ts, bao=None, cho_giay=1800):
    """Nguoi dung tu mo man hinh tra cuu tren cong (ke ca man hinh eTax trong khung, man hinh co ma xac nhan),
       tra cuu xong bam 'Lay bang nay' tren dai xanh -> tool doc bang (moi trang) + nhan nhom + ghi ket qua.
       Lam lai bao nhieu man hinh cung duoc; bam 'Xong' de ket thuc."""
    kenh = CHROME["kenh"]
    mst_cty = ts.get("mst", "")
    huong = ("<b>UNESCO - lấy dữ liệu trên màn hình</b><br>"
             "Mở màn hình tra cứu (thông báo, GNT, hồ sơ khai thuế, nghĩa vụ thuế...), "
             "nhập điều kiện và tự bấm Tra cứu (mã xác nhận nếu có do bạn tự nhập). "
             "Khi bảng kết quả hiện ra: bấm <b>Lấy bảng này</b> (tool tự lật hết các trang). "
             "Làm tiếp màn hình khác hoặc bấm <b>Xong</b>.")
    tong = {"mst": mst_cty, "nhom": {}, "loi": [], "so_tep": 0, "che_do": "doc_bang"}
    so_lan, t0, da_ghi, nhuong = 0, time.time(), 0, False
    while time.time() - t0 < cho_giay:
        if not _con_luot(ts.get("_luot")):          # GD98-A
            LOG.ghi("[DOC BANG] Da co lan chay moi (bam lai nut) - lan nay dung.")
            nhuong = True
            break
        try:
            kenh.chay_js(_JS_BANG_NUT % json.dumps(huong))
        except Exception:
            kenh = noi_lai()
            if kenh is None:
                break
            continue
        lenh = ""
        for _ in range(8):
            time.sleep(0.5)
            try:
                lenh = kenh.chay_js(_JS_DOC_LENH) or ""
            except Exception:
                lenh = ""
                break
            if lenh:
                break
        if lenh == "xong":
            break
        if lenh != "lay":
            continue
        if not _con_luot(ts.get("_luot")):          # GD98-A
            nhuong = True
            break
        mst_dn, ten_dn = mst_dang_nhap()
        if mst_dn and mst_cty and not _cung_mst(mst_dn, mst_cty):
            tb = "KHAC_MST: dang nhap cong bang MST %s - khong phai cong ty dang mo (MST %s). Khong lay du lieu." % (mst_dn, mst_cty)
            LOG.ghi(tb)
            if bao:
                bao(tb)
            tong["loi"].append(tb)
            huong = "<b>UNESCO: KHÔNG lấy</b> - đang đăng nhập MST " + mst_dn + \
                    ", không phải công ty đang mở (MST " + mst_cty + ")."
            continue
        nhom, ds, tt = doc_het_trang("", bao=bao)
        if not ds:
            huong = ("<b>UNESCO:</b> chưa thấy bảng kết quả trên màn hình - tra cứu xong "
                     "(bảng hiện dữ liệu) rồi bấm lại Lấy bảng này.")
            continue
        nhom = nhom or "KHAC"
        so_lan += 1
        luu_json_tho(ts.get("out"), nhom, ds)
        dong = [chuan_hoa_dong(nhom, r, mst_cty) for r in ds]
        for d in dong:
            d["mst_dang_nhap"], d["ten_dang_nhap"] = mst_dn, ten_dn
            d["nguon_doc"] = "doc_bang"
        tong["nhom"][nhom] = {"ten": (NHOM.get(nhom) or {}).get("ten", nhom), "so_dong": len(dong)}
        tong["so_tep"] += tai_tep_dinh_kem(kenh, dong, os.path.join(ts.get("out") or BASE_DIR, "dvc", "tep"), bao,
                                           khung=(tt.get("kenh"), tt.get("ctx"), tt.get("url", "")))
        ghi_ket_qua(dong, dict(tong, mst_dang_nhap=mst_dn), ts.get("out"))
        da_ghi += len(dong)
        huong = ("<b>UNESCO: đã lấy %d dòng</b> (%s, %d trang). Mở màn hình khác rồi Lấy bảng này, "
                 "hoặc bấm Xong." % (len(dong), (NHOM.get(nhom) or {}).get("ten", nhom), tt.get("so_trang", 1)))
    _xoa_bang(kenh)
    if not da_ghi:
        if not nhuong:
            ghi_khong_co(ts.get("out"), "; ".join(tong["loi"]) or "Chua lay bang nao (khong bam 'Lay bang nay')")
        return False
    return True


# ---------------------------------------------------------------------------
#  CHAY MOT LUOT
# ---------------------------------------------------------------------------
def chay(ts, bao=None):
    def _bao(s):
        LOG.ghi(s)
        if bao:
            try:
                bao(s)
            except Exception:
                pass

    nhom = [x.strip().upper() for x in (ts.get("nhom") or "").split(",") if x.strip()]
    if not nhom:
        nhom = ["TB", "GNT"]      # hai man hinh khong co captcha - chay tu dong duoc
    nhom = [x for x in nhom if x in NHOM]
    tu_dong = bool(ts.get("tu_dong_chay"))          # GD189: dang nhap xong tu tim + tai moi thu; chi man hinh co captcha moi cho nguoi dung
    if tu_dong:
        nhom = [m for m in nhom if not NHOM[m].get("captcha")] + [m for m in nhom if NHOM[m].get("captcha")]   # khong captcha truoc
    if not nhom and not ts.get("docbang"):
        ghi_khong_co(ts.get("out"), "Nhom khong hop le")
        return False

    luot = _nhan_luot()          # GD98-A: bam lai nut -> lan chay cu tu dung
    ts["_luot"] = luot
    ok, loi = mo_chrome()
    if not ok:
        ghi_khong_co(ts.get("out"), loi)
        return False
    if tu_dong:
        _bao("Da mo Chrome. Hay dang nhap bang tai khoan doanh nghiep - dang nhap xong tool TU DONG tim va tai moi noi dung moi.")
    else:
        _bao("Da mo Chrome. Hay dang nhap bang tai khoan doanh nghiep cua ban.")
    ok, loi = cho_dang_nhap(bao=_bao, luot=luot)
    if loi == NHUONG:
        LOG.ghi("[CHROME] Da co lan chay moi (bam lai nut) - lan nay dung, khong ghi ket qua.")
        return False
    if not ok:
        ghi_khong_co(ts.get("out"), loi)
        return False
    kenh = CHROME["kenh"]

    # GD97-A: doi chieu MST tai khoan dang nhap voi cong ty dang mo (nhieu cong ty / nhieu bo so)
    mst_dn, ten_dn = mst_dang_nhap()
    if mst_dn:
        LOG.ghi("[DVC] Dang nhap MST %s" % mst_dn)
    if mst_dn and ts.get("mst") and not _cung_mst(mst_dn, ts.get("mst")):
        ghi_khong_co(ts.get("out"), "KHAC_MST dang nhap cong bang MST %s - khong phai cong ty dang mo (MST %s). Dang xuat, "
                     "dang nhap dung tai khoan cong ty roi lam lai." % (mst_dn, ts.get("mst")))
        return False
    # GD97-A: che do doc bang tren man hinh (nut 'Lay bang dang mo' / 'Day tool cach lay')
    if ts.get("docbang"):
        return che_do_doc_bang(ts, _bao)

    # che do day tool cach lay
    if ts.get("hoc"):
        # GD39: chi bao DA_HOC_XONG khi hoc duoc it nhat mot nhom (truoc day bao "da hoc xong" ca khi
        # nhom co ma xac nhan bi bo qua hoac hoc_nhom loi).
        da_hoc, chua_hoc = [], []
        for m in [x.strip().upper() for x in ts["hoc"].split(",") if x.strip().upper() in NHOM]:
            if NHOM[m].get("captcha"):
                _bao("[%s] Man hinh nay co ma xac nhan nen khong hoc duong goi de phat lai. "
                     "Dung nut \"Hung ket qua\" - ban tu nhap ma, tool nhan ket qua ve." % m)
                chua_hoc.append("%s: man hinh co ma xac nhan - dung Hung ket qua" % m)
                continue
            mau, loi = hoc_nhom(kenh, m, _bao)
            if loi:
                _bao("[%s] %s" % (m, loi))
                chua_hoc.append("%s: %s" % (m, loi))
            else:
                _bao("[%s] Da hoc xong cach lay (%d ban ghi mau)." % (m, mau["so_ban_ghi_mau"]))
                da_hoc.append(m)
        if da_hoc:
            ghi_khong_co(ts.get("out"), "DA_HOC_XONG " + ",".join(da_hoc) +
                         ((" | chua hoc: " + "; ".join(chua_hoc)) if chua_hoc else ""))
            return True
        ghi_khong_co(ts.get("out"), "Chua hoc duoc nhom nao: " + "; ".join(chua_hoc or ["khong co nhom hop le"]))
        return False

    tu = ts.get("tu") or date(date.today().year, 1, 1)
    den = ts.get("den") or date.today()
    can_doc = []          # GD97-A
    cho_captcha, het_gio = [], []          # GD189: nhom dang cho nguoi dung nhap ma xac nhan / het gio cho
    if tu_dong:
        _bao("Dang nhap xong - dang tu tim va tai noi dung moi tu %s den %s..." % (tu.strftime("%d/%m/%Y"), den.strftime("%d/%m/%Y")))
    tat_ca, tong = [], {"mst": ts.get("mst", ""), "tu": str(tu), "den": str(den),
                        "nhom": {}, "loi": [], "so_tep": 0}
    for m in nhom:
        if NHOM[m].get("captcha"):
            # Man hinh co ma xac nhan: khong hoc duong goi de phat lai, ma cho nguoi
            # dung tu tra cuu roi hung ket qua ve. Tool khong dien ma xac nhan.
            t1, t2, ghi_chu = gioi_han_ngay(m, tu, den)
            if ghi_chu:
                _bao("[%s] %s" % (m, ghi_chu))
            if t1 is None:
                tong["loi"].append("%s: %s" % (NHOM[m]["ten"], ghi_chu))
                continue
            if tu_dong:
                _bao("CAN_NHAP_CAPTCHA %s: can ban tu nhap ma xac nhan tren cua so Chrome (tool khong dien ma thay)." % NHOM[m]["ten"])
                cho_captcha.append(NHOM[m]["ten"])
                ds, loi = hung_nhom(kenh, m, t1, t2, _bao, cho_giay=240)
                if loi:
                    het_gio.append(NHOM[m]["ten"])
            else:
                ds, loi = hung_nhom(kenh, m, t1, t2, _bao)
        else:
            if not doc_duong_da_hoc(m):
                # GD97-A: chua co duong goi -> doc bang tren man hinh (nguoi dung tu tra cuu, bam Lay bang nay)
                can_doc.append(m)
                continue
            ds, loi = tai_nhom(kenh, m, tu, den, _bao)
        if loi:
            tong["loi"].append("%s: %s" % (NHOM[m]["ten"], loi))
            _bao("[%s] %s" % (m, loi))
            continue
        luu_json_tho(ts.get("out"), m, ds)
        dong = [chuan_hoa_dong(m, r, ts.get("mst", "")) for r in ds]
        tong["nhom"][m] = {"ten": NHOM[m]["ten"], "so_dong": len(dong)}
        tat_ca.extend(dong)

    if not _con_luot(luot):          # GD98-A: da co lan chay moi trong luc tai -> khong ghi de ket qua cua lan moi
        LOG.ghi("[DVC] Da co lan chay moi (bam lai nut) - lan nay dung, khong ghi ket qua.")
        return False
    for d in tat_ca:          # GD97-A: cong xac nhan cong ty cua VB doi chieu MST dang nhap
        d["mst_dang_nhap"], d["ten_dang_nhap"] = mst_dn, ten_dn
    if tat_ca:
        tong["so_tep"] = tai_tep_dinh_kem(kenh, tat_ca,
                                          os.path.join(ts.get("out") or BASE_DIR, "dvc", "tep"), _bao)
    if can_doc and tu_dong:
        # GD189: khong dung cho doc bang 30 phut - ghi phan da lay, noi ro nhom nao can day tool
        if tat_ca:
            duong = ghi_ket_qua(tat_ca, tong, ts.get("out"))
            _bao("Da ghi %d dong: %s" % (len(tat_ca), os.path.basename(duong)))
        _bao("CAN_DAY_TOOL %s" % ", ".join(NHOM[m]["ten"] for m in can_doc))
        if not tat_ca:
            ghi_khong_co(ts.get("out"), "CHUA_HOC " + ", ".join(NHOM[m]["ten"] for m in can_doc))
        return bool(tat_ca)
    if can_doc:
        if tat_ca:
            duong = ghi_ket_qua(tat_ca, tong, ts.get("out"))
            _bao("Da ghi %d dong: %s" % (len(tat_ca), os.path.basename(duong)))
        _bao("Chua co cach tu lay: %s - hay mo tung man hinh tren cong, tra cuu roi bam 'Lay bang nay'." %
             ", ".join(NHOM[m]["ten"] for m in can_doc))
        return che_do_doc_bang(ts, _bao) or bool(tat_ca)
    if not tat_ca:
        ghi_khong_co(ts.get("out"), "; ".join(tong["loi"]) or "Khong co ban ghi nao trong khoang ngay da chon")
        return False
    duong = ghi_ket_qua(tat_ca, tong, ts.get("out"))
    _bao("Xong: %d dong, %d tep dinh kem. File: %s" % (len(tat_ca), tong["so_tep"], os.path.basename(duong)))
    if tu_dong:
        _bao("TOM_TAT " + "; ".join("%s %d" % (v["ten"], v["so_dong"]) for v in tong["nhom"].values()))
        if het_gio:
            _bao("CAPTCHA_CHUA_NHAP %s" % ", ".join(het_gio))
    return True

# ---------------------------------------------------------------------------
#  GIAO DIEN NHO (khi mo bang cach bam dup) + dong lenh (khi VB6 goi)
# ---------------------------------------------------------------------------
def giao_dien(ts):
    try:
        import tkinter as tk
        from tkinter import ttk
    except Exception:
        LOG.ghi("May khong co tkinter - chay thang che do dong lenh.")
        return chay(ts)

    # GD120: cua so moi theo anh thiet ke (giao_dien_dvc.py, chu co dau, bieu tuong giao-dien\dvc). Loi -> cua so cu ben duoi.
    try:
        if BASE_DIR not in sys.path:
            sys.path.insert(0, BASE_DIR)
        import giao_dien_dvc
        return giao_dien_dvc.mo(ts, sys.modules[__name__])
    except Exception as e:
        LOG.loi("Giao dien moi (giao_dien_dvc) loi - dung giao dien cu", e)

    root = tk.Tk()
    _gd167_ico(root)
    root.title("UNESCO - Cong dich vu cong Thue")
    root.geometry("760x520")
    khung = ttk.Frame(root, padding=12)
    khung.pack(fill="both", expand=True)

    ttk.Label(khung, text="Tai du lieu tu Cong dich vu cong Thue (dichvucong.gdt.gov.vn)",
              font=("Tahoma", 11, "bold")).pack(anchor="w")
    ttk.Label(khung, wraplength=720, foreground="#444",
              text=("Ban tu dang nhap bang tai khoan doanh nghiep trong cua so Chrome ma tool mo ra. "
                    "Tool khong luu mat khau, khong dien captcha, khong ky hay nop ho so thay ban. "
                    "Lan dau moi chuc nang, tool xin ban bam dung chuc nang do MOT LAN de hoc cach lay.")
              ).pack(anchor="w", pady=(4, 10))

    hang = ttk.Frame(khung); hang.pack(fill="x")
    ttk.Label(hang, text="Tu ngay (dd/mm/yyyy):").grid(row=0, column=0, sticky="w")
    e_tu = ttk.Entry(hang, width=14); e_tu.grid(row=0, column=1, padx=6)
    ttk.Label(hang, text="Den ngay:").grid(row=0, column=2, sticky="w")
    e_den = ttk.Entry(hang, width=14); e_den.grid(row=0, column=3, padx=6)
    e_tu.insert(0, (ts.get("tu") or date(date.today().year, 1, 1)).strftime("%d/%m/%Y"))
    e_den.insert(0, (ts.get("den") or date.today()).strftime("%d/%m/%Y"))

    chon = {}
    khung_n = ttk.LabelFrame(khung, text="Nhom du lieu", padding=8)
    khung_n.pack(fill="x", pady=10)
    for i, (m, n) in enumerate(NHOM.items()):
        v = tk.IntVar(value=1 if m != "HDHL" else 0)
        chon[m] = v
        da = " (da hoc)" if doc_duong_da_hoc(m) else " (chua hoc)"
        ttk.Checkbutton(khung_n, text=n["ten"] + da, variable=v).grid(row=i // 2, column=i % 2,
                                                                     sticky="w", padx=6, pady=2)

    nk = tk.Text(khung, height=13, wrap="word")
    nk.pack(fill="both", expand=True, pady=(6, 8))

    def bao(s):
        try:
            nk.insert("end", s + "\n"); nk.see("end"); root.update_idletasks()
        except Exception:
            pass

    def _ds_chon():
        return ",".join([m for m, v in chon.items() if v.get()])

    def chay_tai():
        t = dict(ts)
        t["nhom"] = _ds_chon(); t["hoc"] = ""
        t["tu"] = doc_ngay(e_tu.get()); t["den"] = doc_ngay(e_den.get())
        if not t["nhom"]:
            bao("Chua chon nhom nao."); return
        threading.Thread(target=lambda: chay(t, bao), daemon=True).start()

    def chay_hoc():
        t = dict(ts)
        t["hoc"] = _ds_chon()
        if not t["hoc"]:
            bao("Chon nhom can day roi bam lai."); return
        threading.Thread(target=lambda: chay(t, bao), daemon=True).start()

    def chay_doc_bang():          # GD97-A
        t = dict(ts)
        t["docbang"] = True; t["hoc"] = ""
        threading.Thread(target=lambda: chay(t, bao), daemon=True).start()

    nut = ttk.Frame(khung); nut.pack(fill="x")
    ttk.Button(nut, text="Lay bang dang mo tren cong", command=chay_doc_bang).pack(side="left")
    ttk.Button(nut, text="Day tool cach lay (1 lan/chuc nang)", command=chay_hoc).pack(side="left", padx=8)
    ttk.Button(nut, text="Tai du lieu", command=chay_tai).pack(side="left", padx=8)
    ttk.Button(nut, text="Dong", command=root.destroy).pack(side="right")

    bao("San sang. Bam 'Tai du lieu' - lan dau tool se xin ban bam dung chuc nang mot lan de hoc.")
    root.mainloop()
    return True


def main():
    ts = doc_tham_so(sys.argv[1:])
    LOG.ghi("=" * 70)
    LOG.ghi("Khoi dong tool Cong dich vu cong. Tham so: nhom=%s tu=%s den=%s hoc=%s"
            % (ts.get("nhom"), ts.get("tu"), ts.get("den"), ts.get("hoc")))
    if ts.get("nhom") or ts.get("hoc") or ts.get("docbang"):
        return chay(ts)
    return giao_dien(ts)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        LOG.loi("Loi nghiem trong lam tool phai dung", e)
        try:
            print("\nTool gap loi va phai dung lai. Chi tiet trong:", LOG_PATH)
            input("Nhan Enter de dong...")
        except Exception:
            pass
