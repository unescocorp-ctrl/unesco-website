# -*- coding: utf-8 -*-
"""GD233 - TRANG THAI 9 TRAM x 12 THANG cua quy trinh ke toan lien thong (chi doc / tinh; VB6 ModTramKy ghi bang HDDT_TramKy).

Tram: 1 Thu thap, 2 Chuan hoa & ghep ma, 3 Doi chieu ba chieu, 4 Hach toan, 5 Cuoi ky nghiep vu, 6 Gia thanh,
      7 Ket chuyen & khoa so, 8 Bao cao & to khai, 9 Nop & ban giao.
Trang thai: CHUA (chua chay) | DA_CHAY (da chay, chua kiem) | XANH | VANG (chi canh bao) | DO (co loi) | THIEU_DL | CAN_CHAY_LAI.

Hai tep ';' trong AIHoaDon\\ket-qua:
  tram_ky.txt       VB6 ghi:  T;<thang>;<tram>;<trang thai>;<luc yyyy-mm-dd hh:nn:ss>;<ghi chu>
  tram_ky_kiem.txt  Python ghi sau kiem_khoa_so: cung dang, VB6 nap lai (TK233_NapKiem) cho tram co Luc VB <= luc tep.
Quy tac "ban" (CAN_CHAY_LAI) - VB6 la nguon su that, ham ban() o day chi de kiem thu cung quy tac:
  - thang T, tu tram t0: moi tram >= t0 cua T dang khac CHUA -> CAN_CHAY_LAI;
  - cac thang SAU T (theo thu tu nam tai chinh): moi tram >= 5 dang khac CHUA -> CAN_CHAY_LAI (so du dau ky doi).
"""
import io
import os

TEN_TRAM = {1: "Thu thập", 2: "Chuẩn hoá & ghép mã", 3: "Đối chiếu ba chiều", 4: "Hạch toán", 5: "Cuối kỳ nghiệp vụ",
            6: "Giá thành", 7: "Kết chuyển & khoá sổ", 8: "Báo cáo & tờ khai", 9: "Nộp & bàn giao"}
SO_TRAM = 9
TRAM_TU_SAU = 5          # thang sau bi anh huong tu tram nay
TT = ("CHUA", "DA_CHAY", "XANH", "VANG", "DO", "THIEU_DL", "CAN_CHAY_LAI")

# ma kiem tra (kiem_khoa_so) -> tram
MA_TRAM = {"K36": 1, "K39": 1, "K40": 3, "K41": 3, "K42": 3, "K44": 7, "K45": 7, "K46": 8, "K47": 6, "K48": 6, "K49": 6, "K50": 2, "K51": 2, "K52": 5, "K53": 5, "K54": 8, "K55": 7, "K56": 7, "K57": 5, "K58": 8, "K59": 6, "K30": 2, "K31": 2, "K33": 2, "K34": 2, "K35": 2,
           "K05": 3, "K08": 3, "K09": 3, "K10": 3, "K18": 3, "K19": 3, "K20": 3, "K32": 3,
           "K01": 4, "K02": 4, "K03": 4, "K04": 4, "K06": 4,
           "K11": 5, "K12": 5, "K13": 5, "K14": 5,
           "K15": 6, "K21": 6, "K22": 6, "K23": 6, "K24": 6, "K25": 6, "K26": 6, "K27": 6, "K28": 6,
           "K07": 7, "K37": 7, "K16": 8, "K17": 8, "K60": 6, "K61": 5}     # GD352: K60 phuong an gia thanh -> tram 6; GD353: K61 no kho doi -> tram 5


def tram_cua(ma):
    return MA_TRAM.get(str(ma or "")[:3], 0)


def thangs_cua(S):
    """Cac thang duong lich trong ky kiem (S.t1..S.t2 la thu tu nam TC, S.dau_ky = thang dau ky)."""
    try:
        return [(t + S.dau_ky - 2) % 12 + 1 for t in range(S.t1, S.t2 + 1)]
    except Exception:
        return []


def trang_thai_tu_kiem(kq, LOI="LOI", CANH_BAO="CANH_BAO"):
    """kq: danh sach dict {ma, muc, ...} cua kiem_khoa_so -> {tram: (trang_thai, so_loi, so_cb)}; tram khong co phep kiem -> THIEU_DL."""
    dem = {t: [0, 0, 0] for t in range(1, SO_TRAM + 1)}
    for k in kq or []:
        t = tram_cua(k.get("ma"))
        if not t:
            continue
        dem[t][2] += 1
        if k.get("muc") == LOI:
            dem[t][0] += 1
        elif k.get("muc") == CANH_BAO:
            dem[t][1] += 1
    kq2 = {}
    for t, (loi, cb, n) in dem.items():
        if n == 0:
            kq2[t] = ("THIEU_DL", 0, 0)
        elif loi:
            kq2[t] = ("DO", loi, cb)
        elif cb:
            kq2[t] = ("VANG", 0, cb)
        else:
            kq2[t] = ("XANH", 0, 0)
    return kq2


def _sach(s):
    return str(s or "").replace(";", ",").replace("\r", " ").replace("\n", " ")


def doc_tep(duong):
    """-> {(thang, tram): (trang_thai, luc, ghi_chu)}; tep khong co -> {}."""
    ds = {}
    if not duong or not os.path.exists(duong):
        return ds
    with io.open(duong, "r", encoding="utf-8-sig") as f:
        for dong in f:
            p = dong.rstrip("\r\n").split(";")
            if len(p) >= 5 and p[0] == "T":
                try:
                    ds[(int(p[1]), int(p[2]))] = (p[3], p[4], p[5] if len(p) > 5 else "")
                except ValueError:
                    pass
    return ds


def ghi_tep(duong, ds, luc):
    """ds: {(thang, tram): (trang_thai, ghi_chu)}"""
    os.makedirs(os.path.dirname(os.path.abspath(duong)), exist_ok=True)
    dong = ["LUC;%s" % luc]
    for (thang, tram) in sorted(ds):
        tt, gc = ds[(thang, tram)]
        dong.append("T;%d;%d;%s;%s;%s" % (thang, tram, tt, luc, _sach(gc)[:200]))
    with io.open(duong, "w", encoding="utf-8") as f:
        f.write("\n".join(dong) + "\n")
    return duong


def ban(ds, thang, tram_tu, thu_tu, dang_chay=0):
    """Danh dau CAN_CHAY_LAI. ds: {(thang, tram): trang_thai} (sua tai cho). thu_tu: ham thang -> thu tu trong nam TC."""
    t0 = max(int(tram_tu), int(dang_chay) + 1)
    doi = 0
    for (th, tr), tt in list(ds.items()):
        if tt == "CHUA":
            continue
        if th == thang and tr >= t0:
            ds[(th, tr)] = "CAN_CHAY_LAI"; doi += 1
        elif thu_tu(th) > thu_tu(thang) and tr >= TRAM_TU_SAU:
            ds[(th, tr)] = "CAN_CHAY_LAI"; doi += 1
    return doi


# ---------------------------------------------------------------- noi vao kiem_khoa_so
def _thu_muc_ket_qua():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "ket-qua")


def k_tram_ky(S, _kq, DAT, CANH_BAO, LOI, THONG_TIN, duong=None):
    """K38: tram can chay lai trong ky (doc tep VB6 ghi). Dung _kq cua kiem_khoa_so de tao dong ket qua."""
    ten = "Trạm quy trình cần chạy lại (sau khi sửa số liệu)"
    if duong is None:
        duong = os.path.join(_thu_muc_ket_qua(), "tram_ky.txt")
    ds = doc_tep(duong)
    if not ds:
        return [_kq("K38", ten, THONG_TIN, "Chưa có trạng thái trạm (bản chưa biên dịch GĐ233 hoặc chưa ghi chứng từ nào từ khi cập nhật).")]
    thang_ky = set(thangs_cua(S)) or None
    dong = []
    for (thang, tram), (tt, luc, gc) in sorted(ds.items()):
        if tt == "CAN_CHAY_LAI" and (thang_ky is None or thang in thang_ky):
            dong.append([thang, tram, TEN_TRAM.get(tram, ""), luc, gc])
    if dong:
        return [_kq("K38", ten, LOI, "%d trạm của %d tháng cần chạy lại vì số liệu trạm trước đã sửa: chạy lại theo thứ tự trạm rồi kiểm lại. "
                    "Khoá sổ khi còn trạm đỏ = số đã kiểm không còn đúng." % (len(dong), len(set(d[0] for d in dong))),
                    ["Tháng", "Trạm", "Tên trạm", "Đánh dấu lúc", "Lý do"], dong)]
    return [_kq("K38", ten, DAT, "Không có trạm nào cần chạy lại.")]


def ghi_kiem(kq, S, luc, LOI="LOI", CANH_BAO="CANH_BAO", duong=None):
    """Sau kiem_khoa_so: ghi tram_ky_kiem.txt cho moi thang trong ky (ket qua kiem la cua ca ky -> ghi cung trang thai cho tung thang)."""
    if duong is None:
        duong = os.path.join(_thu_muc_ket_qua(), "tram_ky_kiem.txt")
    tt = trang_thai_tu_kiem(kq, LOI, CANH_BAO)
    thangs = thangs_cua(S)
    ds = {}
    for th in thangs:
        for tram, (trang_thai, loi, cb) in tt.items():
            ds[(th, tram)] = (trang_thai, "loi %d, canh bao %d" % (loi, cb) if trang_thai != "THIEU_DL" else "khong co phep kiem")
    return ghi_tep(duong, ds, luc)
