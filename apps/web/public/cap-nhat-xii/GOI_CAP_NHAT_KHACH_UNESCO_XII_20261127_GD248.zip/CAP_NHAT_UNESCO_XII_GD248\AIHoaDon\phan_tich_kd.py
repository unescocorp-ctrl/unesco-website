# -*- coding: utf-8 -*-
"""GD159 (lo trinh C2 + C3) - PHAN TICH KINH DOANH CHO CHU DOANH NGHIEP. CHI DOC, UOC TINH tu so ke toan.

  LAI (C2): doanh thu (Co 511 tru giam tru / tra lai) - gia von (No 632 Co kho) theo MAT HANG, KHACH HANG, THANG; chi phi ban hang + quan ly
            (641 / 642 / 6421 / 6422) phan bo theo ty trong doanh thu -> lai sau phan bo (uoc tinh). Canh bao: mat hang ban lo, bien mong,
            ban khong co gia von; khach lai mong ma tra cham / con no qua han (thoi quen tra hoc tu lich su nhu du bao dong tien GD156).
  TON (C3): theo bang TonKho phan mem: ton cuoi, xuat binh quan 3 thang, so ngay ton, lan xuat gan nhat; cham luan chuyen (khong xuat N ngay /
            ton > 180 ngay), can dat hang (ton <= toc do x (ngay cho hang + du phong)) kem luong de xuat, phan loai ABC theo gia tri.
Dau vao: JSON VB6 (ModPhanTichKD.PT159_Json) = so lieu cong no GD70 + "ss" GD78 (ct, vt, kho, tonkho, ck4) + "pt159" {loai, hom_nay, tham so}.
Ra: Excel + HTML + ket-qua\\phan_tich_kd.txt (TONG + dong canh bao cho VB6). Khong ghi so.
GD176: HTML thanh trang phan tich bang bieu do (bo ve SVG dung chung bd_* trong dong_tien.py): LAI - the chi so, lai gop 15 mat hang, lai gop
theo khach hang, doanh thu / gia von / lai gop + bien lai gop theo thang; TON - the chi so, 15 ma gia tri lon nhat, ABC, so ngay ton, cham luan
chuyen, can dat hang. Excel va tep tom tat khong doi."""
import datetime as _dt
import html
import io
import json
import os
import re
from collections import defaultdict

import kiem_khoa_so as K
import so_sach_mau as SM

GOC = os.path.dirname(os.path.abspath(__file__))
TK_KHO3 = ("151", "152", "153", "154", "155", "156", "157", "158")
TK_CP_BH_QL = ("641", "642", "6421", "6422")


def _so(x):
    try:
        return float(x or 0)
    except (TypeError, ValueError):
        try:
            return float(str(x).replace(",", "."))
        except (TypeError, ValueError):
            return 0.0


def tien(x):
    return "{:,.0f}".format(round(x or 0)).replace(",", ".")


def pt(x):
    return ("%.1f%%" % (x * 100)).replace(".", ",")


def _sach(s, n=300):
    return re.sub(r"[\t\r\n;]+", " ", str(s or "")).strip()[:n]


class ThamSo(object):
    def __init__(self, b):
        b = b or {}
        self.loai = str(b.get("loai") or "LAI").upper()
        self.cho = int(_so(b.get("ngay_cho_hang")) or 15)          # ngay tu dat den nhan hang
        dp = b.get("ngay_du_phong")
        self.du_phong = int(_so(dp)) if dp not in (None, "") else 7      # 0 ngay du phong la hop le
        self.cham = int(_so(b.get("ngay_cham")) or 90)             # khong xuat N ngay -> cham luan chuyen
        self.bien_mong = (_so(b.get("bien_mong")) or 10) / 100.0     # bien lai gop duoi muc nay -> mong
        self.no_lau = int(_so(b.get("ngay_no_lau")) or 60)


class PhanTich(object):
    def __init__(self, dl, hom_nay=None):
        self.dl = dl
        self.b = dl.get("pt159") or {}
        self.ts = ThamSo(self.b)
        self.S = S = SM.SoLieuSS(dl)
        self.hom_nay = hom_nay or SM._ngay(self.b.get("hom_nay")) or _dt.date.today()
        self.KH = SM._kho(S)                     # kem kiem bang TonKho khop chung tu (canh bao vao S.cb)
        self.canh_bao = []

    def sh(self, m):
        return self.S.sh(m)

    def ten_vt(self, vt):
        if not vt:
            return ["", "Không rõ mặt hàng (dịch vụ / doanh thu không gắn mã)", "", ""]
        return self.KH.ten_vt(vt)

    def ten_kh(self, kh):
        if not kh:
            return ["", "Khách lẻ / không rõ khách"]
        d = self.S.dt.get(kh)
        return [d[0] if d else str(kh), self.S.ten_dt(kh) or ("đối tượng mã số %d" % kh)]

    def thang_chu(self, t):
        m, y = self.S.thang_lich(t)
        return "%02d/%d" % (m, y)

    def _cb_du_lieu(self):
        """canh bao du lieu (VB ss.canh_bao, bang TonKho chua khop chung tu...) -> dong 'Thông tin'."""
        ds = []
        for x in self.S.cb or []:
            x = str(x)
            if x.startswith("Kỳ chọn") or (self.ts.loai != "TON" and ("TonKho" in x or "tồn kho" in x.lower())):
                continue                                 # thong bao cua bieu mau so sach / ton kho khong lien quan bao cao lai
            ds.append(("Thông tin", "Dữ liệu", "", x[:300], "Chạy Tính lại giá xuất / Kiểm tra số liệu rồi lập lại." if "TonKho" in x else ""))
        return ds[:10]

    # ================================================================== C2 LAI
    def lai(self):
        S, sh = self.S, self.sh
        theo_ct = defaultdict(list)
        for d in S.ct:
            theo_ct[d.mact].append(d)
        vt = defaultdict(lambda: {"dt": 0.0, "gv": 0.0, "sl": 0.0, "ct": set(), "kh": set()})
        kh = defaultdict(lambda: {"dt": 0.0, "gv": 0.0, "ct": set(), "vt": set()})
        th = defaultdict(lambda: {"dt": 0.0, "gv": 0.0, "cp": 0.0})
        for mact, ds in theo_ct.items():
            if any(sh(d.no).startswith("911") or sh(d.co).startswith("911") for d in ds):
                continue                                 # chung tu ket chuyen cuoi ky (ke ca dong mot ben) - khong phai ban hang / chi phi
            dt_vt, gv_vt, sl_vt = defaultdict(float), defaultdict(float), defaultdict(float)
            dt_khong = 0.0
            khach = 0
            t = ds[0].t
            for d in ds:
                a, b = sh(d.no), sh(d.co)
                if b.startswith("511") and not a.startswith(("911", "511", "521")):
                    if d.vt:
                        dt_vt[d.vt] += d.tien
                    else:
                        dt_khong += d.tien
                    khach = khach or d.kh
                elif a.startswith(("511", "521")) and not b.startswith(("911", "511", "521")):
                    if d.vt:
                        dt_vt[d.vt] -= d.tien
                    else:
                        dt_khong -= d.tien
                    khach = khach or d.khc
                elif a.startswith("632") and b[:3] in TK_KHO3:
                    gv_vt[d.vt] += d.tien
                    sl_vt[d.vt] += d.sl_co
                elif a[:3] in TK_KHO3 and b.startswith("632"):
                    gv_vt[d.vt] -= d.tien
                    sl_vt[d.vt] -= d.sl_no
                if a.startswith("131") and d.kh and not khach:
                    khach = d.kh
                if a.startswith(TK_CP_BH_QL) and not b.startswith(("911",) + TK_CP_BH_QL):
                    th[t]["cp"] += d.tien
                elif b.startswith(TK_CP_BH_QL) and not a.startswith(("911",) + TK_CP_BH_QL):
                    th[t]["cp"] -= d.tien
            if not dt_vt and not dt_khong and not gv_vt:
                continue
            if dt_khong:
                co_gv = {v: abs(g) for v, g in gv_vt.items() if v and g and (g > 0) == (dt_khong > 0)}   # tra lai: chia theo gia von ghi giam
                tong_gv = sum(co_gv.values())
                if co_gv and tong_gv > 0:
                    for v, g in co_gv.items():               # doanh thu khong gan ma: chia theo gia von cac mat hang cung chung tu
                        dt_vt[v] += dt_khong * g / tong_gv
                else:
                    dt_vt[0] += dt_khong
            for v in set(dt_vt) | set(gv_vt):
                x = vt[v]
                x["dt"] += dt_vt.get(v, 0.0)
                x["gv"] += gv_vt.get(v, 0.0)
                x["sl"] += sl_vt.get(v, 0.0)
                x["ct"].add(mact)
                x["kh"].add(khach)
                y = kh[khach]
                y["dt"] += dt_vt.get(v, 0.0)
                y["gv"] += gv_vt.get(v, 0.0)
                y["ct"].add(mact)
                y["vt"].add(v)
                th[t]["dt"] += dt_vt.get(v, 0.0)
                th[t]["gv"] += gv_vt.get(v, 0.0)
        tong_dt = sum(x["dt"] for x in vt.values())
        tong_gv = sum(x["gv"] for x in vt.values())
        tong_cp = sum(x["cp"] for x in th.values())
        he_cp = tong_cp / tong_dt if tong_dt > 0 else 0.0
        # cong no khach: thoi quen tra + qua han (nhu du bao dong tien)
        tra = {}
        try:
            import dong_tien as DTN
            mo, hoc, _ = DTN.fifo(S, True, self.hom_nay)
            ok, qua, tq, chung = DTN.du_kien(mo, hoc, self.hom_nay, True)
            con = defaultdict(float)
            qh = defaultdict(float)
            for h in ok + qua:
                con[h["kh"]] += h["con"]
            for h in qua:
                if h.get("qua_ngay"):
                    qh[h["kh"]] += h["con"]
            for k in set(con) | set(tq):
                tra[k] = {"con": con.get(k, 0.0), "qua_han": qh.get(k, 0.0), "ngay_tb": (tq.get(k) or (None, 0))[0]}
        except Exception:
            tra = {}
        dv = []
        for v, x in vt.items():
            lg = x["dt"] - x["gv"]
            cp = x["dt"] * he_cp if x["dt"] > 0 else 0.0
            t_ = self.ten_vt(v)
            dv.append({"vt": v, "ma": t_[0], "ten": t_[1], "dvt": t_[2], "sl": x["sl"], "dt": x["dt"], "gv": x["gv"], "lg": lg,
                       "bien": lg / x["dt"] if x["dt"] > 0 else None, "cp": cp, "lr": lg - cp, "so_ct": len(x["ct"]), "so_kh": len(x["kh"] - {0})})
        dk = []
        for k, x in kh.items():
            lg = x["dt"] - x["gv"]
            cp = x["dt"] * he_cp if x["dt"] > 0 else 0.0
            t_ = self.ten_kh(k)
            r = tra.get(k) or {}
            dk.append({"kh": k, "ma": t_[0], "ten": t_[1], "dt": x["dt"], "gv": x["gv"], "lg": lg, "bien": lg / x["dt"] if x["dt"] > 0 else None,
                       "cp": cp, "lr": lg - cp, "so_ct": len(x["ct"]), "so_vt": len(x["vt"] - {0}), "con_no": r.get("con", 0.0),
                       "qua_han": r.get("qua_han", 0.0), "ngay_tb": r.get("ngay_tb")})
        dv.sort(key=lambda r: -r["lg"])
        dk.sort(key=lambda r: -r["dt"])
        dth = []
        for t in sorted(th):
            x = th[t]
            dth.append({"t": t, "thang": self.thang_chu(t), "dt": x["dt"], "gv": x["gv"], "lg": x["dt"] - x["gv"], "cp": x["cp"],
                        "lr": x["dt"] - x["gv"] - x["cp"], "bien": (x["dt"] - x["gv"]) / x["dt"] if x["dt"] > 0 else None})
        cb = []
        bien_tb = (tong_dt - tong_gv) / tong_dt if tong_dt > 0 else 0.0
        BM = min(self.ts.bien_mong, max(0.0, bien_tb * 0.5))      # lai mong: duoi nguong va duoi nua bien binh quan cua chinh so
        dang_ke = max(tong_dt * 0.005, 0.0)                         # chi xet mat hang co doanh thu >= 0,5% tong
        n_mong = 0
        for r in dv:
            if r["vt"] and r["dt"] > 0 and r["lg"] < -0.5:
                cb.append(("Cao", "Mặt hàng bán lỗ", r["ma"], "%s: doanh thu %s, giá vốn %s, lỗ gộp %s" % (r["ten"][:60], tien(r["dt"]), tien(r["gv"]), tien(-r["lg"])),
                           "Kiểm tra giá bán, chiết khấu, giá xuất kho (Tính lại giá xuất), hàng khuyến mại / biếu tặng."))
            elif r["vt"] and r["dt"] > 0 and r["gv"] <= 0 and self.KH.tk_vt.get(r["vt"]):
                cb.append(("Vừa", "Bán không có giá vốn", r["ma"], "%s: doanh thu %s nhưng chưa có giá vốn" % (r["ten"][:60], tien(r["dt"])),
                           "Chưa kết chuyển giá vốn / chưa tính giá xuất kho cho mặt hàng này."))
            elif r["vt"] and r["bien"] is not None and 0 <= r["bien"] < BM and r["dt"] >= dang_ke and r["dt"] > 0 and n_mong < 30:
                n_mong += 1
                cb.append(("Thấp", "Mặt hàng lãi mỏng", r["ma"], "%s: biên lãi gộp %s (dưới %s)" % (r["ten"][:60], pt(r["bien"]), pt(BM)),
                           "Xem lại giá bán / giá mua; sau phân bổ chi phí có thể lỗ: lãi sau phân bổ %s." % tien(r["lr"])))
        for r in dk:
            if not r["kh"] or r["dt"] <= 0 or r["bien"] is None:
                continue
            cham = (r["ngay_tb"] or 0) > self.ts.no_lau
            if r["bien"] < BM and (cham or r["qua_han"] > 0.5):
                cb.append(("Vừa", "Khách lãi mỏng mà trả chậm", r["ma"],
                           "%s: biên %s; %s%s" % (r["ten"][:60], pt(r["bien"]), ("trả bình quân %d ngày; " % r["ngay_tb"]) if r["ngay_tb"] else "",
                                                ("nợ quá hạn %s" % tien(r["qua_han"])) if r["qua_han"] > 0.5 else "còn nợ %s" % tien(r["con_no"])),
                           "Cân nhắc giá bán / điều kiện thanh toán, thu nợ quá hạn trước khi bán tiếp."))
        self.canh_bao = cb + self._cb_du_lieu()
        self.kq_lai = {"vt": dv, "kh": dk, "th": dth, "dt": tong_dt, "gv": tong_gv, "cp": tong_cp, "he_cp": he_cp}
        return self.kq_lai

    # ================================================================== C3 TON KHO
    def ton(self):
        S, KH, ts = self.S, self.KH, self.ts
        nt = KH.nt
        # moc = ngay nhap / xuat kho cuoi cung cua so (so thuong nhap tre; chung tu ngan hang co the nhap truoc hang hoa), khong qua hom nay
        ng_ct = [d.ngay for d in S.ct if d.ngay and d.ngay <= self.hom_nay and (KH.la_xuat(d) or KH.la_nhap(d))]
        dem = defaultdict(int)
        for g in ng_ct:
            dem[(g.year, g.month)] += 1
        ref = self.hom_nay
        if dem:
            tv = sorted(dem.values())[len(dem) // 2]
            ym = max(k for k, v in dem.items() if v >= max(2, 0.3 * tv))  # thang cuoi co nhap / xuat dang ke (bo vai chung tu le thang sau)
            ref = min(self.hom_nay, max(g for g in ng_ct if (g.year, g.month) == ym))
        self.ngay_so_lieu = ref
        t_nay = K.thang_tc(ref.month, S.dau_ky) if ref.year in (S.nam, S.nam + 1) else S.t2
        t_nay = min(max(t_nay, S.t1), S.t2)
        # 3 thang da tron: bo thang cua moc neu chua het thang
        cuoi = t_nay - 1 if ref.day < 25 and t_nay > S.t1 else t_nay
        ds_t = [t for t in range(max(S.t1, cuoi - 2), cuoi + 1)]
        xuat_cuoi, nhap_dau = {}, {}
        lx3, th_x = defaultdict(float), defaultdict(set)
        for d in S.ct:
            if not d.ngay or d.ngay > ref:
                continue
            if KH.la_xuat(d):                            # la_xuat da bo chuyen kho noi bo cung TK
                k = d.vt
                if k not in xuat_cuoi or d.ngay > xuat_cuoi[k]:
                    xuat_cuoi[k] = d.ngay
                if d.t in ds_t:
                    lx3[k] += d.sl_co
                    th_x[k].add(d.t)
            elif KH.la_nhap(d):
                if d.vt not in nhap_dau or d.ngay < nhap_dau[d.vt]:
                    nhap_dau[d.vt] = d.ngay
        theo_vt = defaultdict(lambda: {"l": 0.0, "t": 0.0, "ldk": 0.0, "tk": set()})
        for (tk, vt), x in KH.ton.items():
            r = KH.nxt(tk, vt)
            if r is None:
                continue
            y = theo_vt[vt]
            y["l"] += r[6]
            y["t"] += r[7]
            y["ldk"] += r[0]
            y["tk"].add(self.sh(tk))
        dong = []
        for vt, y in theo_vt.items():
            if abs(y["l"]) < 1e-9 and abs(y["t"]) < 0.5 and lx3.get(vt, 0) <= 0:
                continue
            v = KH.ten_vt(vt)
            toc = lx3.get(vt, 0.0) / float(len(ds_t) or 1)    # xuat binh quan / thang
            ngay_ton = (y["l"] / (toc / 30.0)) if toc > 0 and y["l"] > 0 else None
            xc = xuat_cuoi.get(vt)
            if xc:
                khong_xuat = (ref - xc).days
            elif y["ldk"] > 0:
                khong_xuat = (ref - S.tu_ky).days        # ton dau nam chua xuat lan nao: tinh tu dau nam
            elif nhap_dau.get(vt):
                khong_xuat = (ref - nhap_dau[vt]).days   # moi nhap chua xuat: tinh tu lan nhap dau
            else:
                khong_xuat = None
            nvl = any(t.startswith(("152", "153")) for t in y["tk"])
            tp = any(t.startswith(("154", "155")) for t in y["tk"])
            r = {"vt": vt, "ma": v[0], "ten": v[1], "dvt": v[2], "tk": ", ".join(sorted(y["tk"])), "l": y["l"], "t": y["t"], "toc": toc,
                 "ngay_ton": ngay_ton, "xuat_cuoi": xc, "khong_xuat": khong_xuat, "nvl": nvl, "tp": tp, "nhom": "", "cham": False, "dat": 0.0,
                 "deu": len(ds_t) >= 2 and len(th_x.get(vt, ())) >= 2}
            if y["l"] > 0 and ((khong_xuat is not None and khong_xuat >= ts.cham) or (ngay_ton or 0) > 180):
                r["cham"] = True
            muc_dat = toc / 30.0 * (ts.cho + ts.du_phong)
            if toc > 0 and r["deu"] and y["l"] <= muc_dat:            # chi mat hang xuat deu (>= 2 / 3 thang)
                r["dat"] = max(0.0, toc / 30.0 * (ts.cho + ts.du_phong + 30) - max(y["l"], 0.0))
            dong.append(r)
        # ABC theo gia tri ton
        tong = sum(r["t"] for r in dong if r["t"] > 0)
        for r in dong:
            if r["cham"] and r["t"] < max(100000.0, tong * 0.001):
                r["cham"] = False                        # ton le gia tri nho - khong bao cham luan chuyen
        luy = 0.0
        for r in sorted(dong, key=lambda r: -r["t"]):
            if r["t"] <= 0:
                r["nhom"] = "C"
                continue
            luy += r["t"]
            r["nhom"] = "A" if luy <= tong * 0.8 or luy - r["t"] == 0 else ("B" if luy <= tong * 0.95 else "C")
        dong.sort(key=lambda r: -r["t"])
        cb = []
        for r in dong:
            if r["l"] < -1e-9:
                cb.append(("Cao", "Âm kho", r["ma"], "%s: tồn %s %s" % (r["ten"][:60], _sl(r["l"]), r["dvt"]), "Xem thẻ Kiểm soát / tính lại giá xuất kho."))
            elif r["cham"]:
                cb.append(("Vừa", "Chậm luân chuyển", r["ma"], "%s: tồn %s %s, giá trị %s, %s" % (
                    r["ten"][:60], _sl(r["l"]), r["dvt"], tien(r["t"]),
                    ("không xuất %d ngày" % r["khong_xuat"]) if r["khong_xuat"] is not None else ("đủ dùng %d ngày" % r["ngay_ton"] if r["ngay_ton"] else "chưa xuất")),
                    "Cân nhắc giảm giá, bán thanh lý, ngừng nhập; lập dự phòng giảm giá hàng tồn kho nếu giá trị thuần thấp hơn giá gốc."))
            elif r["dat"] > 0:
                cb.append(("Vừa" if r["nvl"] else "Thấp", "Nguyên vật liệu sắp thiếu" if r["nvl"] else ("Thành phẩm sắp hết (cần sản xuất)" if r["tp"] else "Cần đặt hàng"), r["ma"],
                           "%s: tồn %s %s, xuất bình quân %s / tháng" % (r["ten"][:60], _sl(r["l"]), r["dvt"], _sl(r["toc"])),
                           "Đặt thêm khoảng %s %s (đủ %d ngày chờ hàng + %d ngày dự phòng + 1 tháng)." % (_sl(r["dat"]), r["dvt"], ts.cho, ts.du_phong)))
        self.canh_bao = cb + self._cb_du_lieu()
        self.kq_ton = {"dong": dong, "tong": tong, "thang": [self.thang_chu(t) for t in ds_t], "den": ref}
        return self.kq_ton


def _sl(x):
    if abs(x - round(x)) < 1e-6:
        return tien(x)
    return ("{:,.2f}".format(x)).replace(",", "X").replace(".", ",").replace("X", ".")


# ====================================================================== ghi
def ghi_txt(P, ra_txt, tep_xlsx):
    os.makedirs(os.path.dirname(ra_txt), exist_ok=True)
    if P.ts.loai == "TON":
        k = P.kq_ton
        d = k["dong"]
        tong = "TONG;TON;%d;%d;%d;%d;%s;%d;%s;%s" % (len(d), round(k["tong"]), sum(1 for r in d if r["cham"]), round(sum(r["t"] for r in d if r["cham"])),
                                                     sum(1 for r in d if r["dat"] > 0), len(P.canh_bao), _sach(tep_xlsx, 400), k["den"].strftime("%d/%m/%Y"))
    else:
        k = P.kq_lai
        tong = "TONG;LAI;%d;%d;%d;%d;%s;%d;%s;%d" % (round(k["dt"]), round(k["gv"]), round(k["dt"] - k["gv"]), round(k["cp"]),
                                                    ("%.4f" % ((k["dt"] - k["gv"]) / k["dt"])) if k["dt"] > 0 else "", len(P.canh_bao), _sach(tep_xlsx, 400),
                                                    len([r for r in k["vt"] if r["vt"]]))
    dong = [tong] + ["C;%s;%s;%s;%s" % (_sach(m), _sach(l), _sach(ma, 40), _sach(nd, 200)) for m, l, ma, nd, _ in P.canh_bao[:40]]
    with io.open(ra_txt, "w", encoding="utf-8", newline="") as f:
        f.write("\r\n".join(dong) + "\r\n")
    return ra_txt


def lap_excel(P, ra):
    from xlsx_viet import SoExcel
    wb = SoExcel(font="Times New Roman", co=11)
    k_td = wb.kieu(dam=True, co=14, can="giua", mau="0B3D91")
    k_ghi = wb.kieu(nghieng=True, mau="555555", xuong=True, doc="tren")
    k_dau = wb.kieu(dam=True, nen="D9E1F2", khung=True, can="giua", xuong=True)
    k_o = wb.kieu(khung=True, xuong=True, doc="tren")
    k_so = wb.kieu(khung=True, so="#,##0")
    k_sl = wb.kieu(khung=True, so="#,##0.##")
    k_pt = wb.kieu(khung=True, so="0.0%")
    k_do = wb.kieu(khung=True, so="#,##0", mau="C00000", dam=True)
    cty = ((P.dl.get("cty") or {}).get("ten") or "")
    ky = "Từ %s đến %s" % (P.S.tu.strftime("%d/%m/%Y"), P.S.den.strftime("%d/%m/%Y"))
    ghi = "Ước tính từ sổ kế toán, chỉ đọc. Chi phí bán hàng + quản lý (641 / 642) phân bổ theo tỷ trọng doanh thu."
    if P.ts.loai == "TON":
        k = P.kq_ton
        ws = wb.sheet("TongQuan", cot=[52, 20])
        ws.gop(1, 1, 1, 2, cty, wb.kieu(dam=True))
        ws.gop(2, 1, 2, 2, "TỒN KHO THÔNG MINH", k_td)
        ws.gop(3, 1, 3, 2, "Số liệu sổ đến ngày %s (theo bảng tồn kho phần mềm đã tính - Tính lại giá xuất để cập nhật). Tốc độ xuất = bình quân %s. "
                           "Chậm luân chuyển: không xuất từ %d ngày hoặc đủ dùng trên 180 ngày. Cần đặt hàng: tồn ≤ tốc độ × (%d ngày chờ hàng + %d ngày dự phòng)."
                           % (k["den"].strftime("%d/%m/%Y"), ", ".join(k["thang"]), P.ts.cham, P.ts.cho, P.ts.du_phong), k_ghi)
        ws.cao(3, 46)
        d = k["dong"]
        r = 5
        for t, v, kk in (("Giá trị tồn kho", k["tong"], k_so), ("Số mã có tồn / phát sinh", len(d), k_so),
                         ("Nhóm A (80% giá trị) - số mã", sum(1 for x in d if x["nhom"] == "A"), k_so),
                         ("Chậm luân chuyển - số mã", sum(1 for x in d if x["cham"]), k_so), ("Chậm luân chuyển - giá trị", sum(x["t"] for x in d if x["cham"]), k_so),
                         ("Cần đặt hàng / nguyên vật liệu sắp thiếu - số mã", sum(1 for x in d if x["dat"] > 0), k_so), ("Âm kho - số mã", sum(1 for x in d if x["l"] < -1e-9), k_so)):
            ws.o(r, 1, t, k_o)
            ws.o(r, 2, v, kk)
            r += 1
        ws.gop(r + 1, 1, r + 1, 2, "Phần mềm chưa có cột hạn dùng - chưa cảnh báo hàng gần hết hạn.", k_ghi)
        w2 = wb.sheet("TonKho", cot=[12, 40, 8, 10, 14, 16, 14, 10, 12, 10, 6, 12, 14])
        w2.gop(1, 1, 1, 13, "TỒN KHO THEO MẶT HÀNG", k_td)
        w2.dong(3, 1, ["Mã", "Tên", "ĐVT", "TK", "Tồn SL", "Tồn giá trị", "Xuất BQ / tháng", "Số ngày tồn", "Xuất gần nhất", "Không xuất (ngày)", "ABC",
                       "Chậm LC", "Đề xuất đặt"], k_dau)
        r = 3
        for x in d:
            r += 1
            w2.dong(r, 1, [x["ma"], x["ten"], x["dvt"], x["tk"]], k_o)
            w2.o(r, 5, x["l"], k_sl)
            w2.o(r, 6, x["t"], k_so)
            w2.o(r, 7, x["toc"], k_sl)
            w2.o(r, 8, round(x["ngay_ton"]) if x["ngay_ton"] is not None else "", k_so)
            w2.o(r, 9, x["xuat_cuoi"].strftime("%d/%m/%Y") if x["xuat_cuoi"] else "", k_o)
            w2.o(r, 10, x["khong_xuat"] if x["khong_xuat"] is not None else "", k_so)
            w2.dong(r, 11, [x["nhom"], "Chậm" if x["cham"] else ""], k_o)
            w2.o(r, 13, x["dat"] if x["dat"] > 0 else "", k_sl)
        w2.dong_bang(4, 3)
        _sheet_cb(wb, P, k_td, k_dau, k_o, k_ghi)
    else:
        k = P.kq_lai
        ws = wb.sheet("TongQuan", cot=[44, 20, 14])
        ws.gop(1, 1, 1, 3, cty, wb.kieu(dam=True))
        ws.gop(2, 1, 2, 3, "LÃI THEO MẶT HÀNG, KHÁCH HÀNG", k_td)
        ws.gop(3, 1, 3, 3, ky + ". " + ghi, k_ghi)
        ws.cao(3, 32)
        lg = k["dt"] - k["gv"]
        r = 5
        for t, v in (("Doanh thu thuần", k["dt"]), ("Giá vốn", k["gv"]), ("Lãi gộp", lg), ("Chi phí bán hàng + quản lý", k["cp"]), ("Lãi sau phân bổ (ước tính)", lg - k["cp"])):
            ws.o(r, 1, t, k_o)
            ws.o(r, 2, v, k_so if v >= 0 else k_do)
            r += 1
        ws.o(r, 1, "Biên lãi gộp", k_o)
        ws.o(r, 2, lg / k["dt"] if k["dt"] > 0 else "", k_pt)
        r += 2
        ws.dong(r, 1, ["Lãi gộp cao nhất (mặt hàng)", "Lãi gộp", "Biên"], k_dau)
        for x in [y for y in k["vt"] if y["vt"]][:10]:
            r += 1
            ws.o(r, 1, "%s - %s" % (x["ma"], x["ten"][:50]), k_o)
            ws.o(r, 2, x["lg"], k_so)
            ws.o(r, 3, x["bien"] if x["bien"] is not None else "", k_pt)
        w2 = wb.sheet("MatHang", cot=[12, 40, 8, 12, 16, 16, 16, 9, 14, 16, 8, 8])
        w2.gop(1, 1, 1, 12, "LÃI THEO MẶT HÀNG", k_td)
        w2.dong(3, 1, ["Mã", "Tên", "ĐVT", "SL bán", "Doanh thu", "Giá vốn", "Lãi gộp", "Biên", "CP phân bổ", "Lãi sau PB", "Số CT", "Số khách"], k_dau)
        r = 3
        for x in k["vt"]:
            r += 1
            w2.dong(r, 1, [x["ma"], x["ten"], x["dvt"]], k_o)
            w2.o(r, 4, x["sl"], k_sl)
            for c, key in ((5, "dt"), (6, "gv"), (7, "lg")):
                w2.o(r, c, x[key], k_so if x[key] >= 0 else k_do)
            w2.o(r, 8, x["bien"] if x["bien"] is not None else "", k_pt)
            w2.o(r, 9, x["cp"], k_so)
            w2.o(r, 10, x["lr"], k_so if x["lr"] >= 0 else k_do)
            w2.o(r, 11, x["so_ct"], k_so)
            w2.o(r, 12, x["so_kh"], k_so)
        w2.dong_bang(4, 3)
        w3 = wb.sheet("KhachHang", cot=[12, 40, 16, 16, 16, 9, 16, 16, 16, 10, 8])
        w3.gop(1, 1, 1, 11, "LÃI THEO KHÁCH HÀNG VÀ CÔNG NỢ", k_td)
        w3.dong(3, 1, ["Mã", "Tên", "Doanh thu", "Giá vốn", "Lãi gộp", "Biên", "Lãi sau PB", "Còn nợ", "Quá hạn", "Trả BQ (ngày)", "Số mặt hàng"], k_dau)
        r = 3
        for x in k["kh"]:
            r += 1
            w3.dong(r, 1, [x["ma"], x["ten"]], k_o)
            for c, key in ((3, "dt"), (4, "gv"), (5, "lg")):
                w3.o(r, c, x[key], k_so if x[key] >= 0 else k_do)
            w3.o(r, 6, x["bien"] if x["bien"] is not None else "", k_pt)
            w3.o(r, 7, x["lr"], k_so if x["lr"] >= 0 else k_do)
            w3.o(r, 8, x["con_no"], k_so)
            w3.o(r, 9, x["qua_han"], k_do if x["qua_han"] > 0.5 else k_so)
            w3.o(r, 10, x["ngay_tb"] if x["ngay_tb"] is not None else "", k_so)
            w3.o(r, 11, x["so_vt"], k_so)
        w3.dong_bang(4, 3)
        w4 = wb.sheet("TheoThang", cot=[10, 16, 16, 16, 9, 16, 16])
        w4.gop(1, 1, 1, 7, "LÃI THEO THÁNG", k_td)
        w4.dong(3, 1, ["Tháng", "Doanh thu", "Giá vốn", "Lãi gộp", "Biên", "CP BH + QL", "Lãi sau PB"], k_dau)
        r = 3
        for x in k["th"]:
            r += 1
            w4.o(r, 1, x["thang"], k_o)
            for c, key in ((2, "dt"), (3, "gv"), (4, "lg"), (6, "cp"), (7, "lr")):
                w4.o(r, c, x[key], k_so if x[key] >= 0 else k_do)
            w4.o(r, 5, x["bien"] if x["bien"] is not None else "", k_pt)
        w4.dong_bang(4, 2)
        _sheet_cb(wb, P, k_td, k_dau, k_o, k_ghi)
    os.makedirs(os.path.dirname(os.path.abspath(ra)), exist_ok=True)
    wb.luu(ra)
    return ra


def _sheet_cb(wb, P, k_td, k_dau, k_o, k_ghi):
    w = wb.sheet("CanhBao", cot=[8, 28, 14, 70, 60])
    w.gop(1, 1, 1, 5, "CẢNH BÁO", k_td)
    w.dong(3, 1, ["Mức", "Loại", "Mã", "Nội dung", "Gợi ý"], k_dau)
    r = 3
    for m, l, ma, nd, gy in P.canh_bao:
        r += 1
        w.dong(r, 1, [m, l, ma, nd, gy], k_o)
    if r == 3:
        w.gop(4, 1, 4, 5, "Không có cảnh báo.", k_ghi)
    w.dong_bang(4, 3)


def _ten_ma(ma, ten):
    return ("%s %s" % (ma, ten)).strip() if ma else (ten or "")


def _html_lai(P, BD):
    """GD176: chi so + lai gop theo khach hang + doanh thu / gia von / lai gop theo thang + bien lai gop theo thang + bang thang."""
    k = P.kq_lai
    lg = k["dt"] - k["gv"]
    lo = [r for r in k["vt"] if r["vt"] and r["dt"] > 0 and r["lg"] < -0.5]
    so_vt = len([r for r in k["vt"] if r["vt"]])
    h = [BD.bd_kpi([("Tổng doanh thu thuần", tien(k["dt"]), "%d mặt hàng có mã, %d khách" % (so_vt, len([r for r in k["kh"] if r["kh"]])), k["dt"] < 0),
                    ("Tổng lãi gộp", tien(lg), "Doanh thu - giá vốn %s" % tien(k["gv"]), lg < 0),
                    ("Biên lãi gộp", pt(lg / k["dt"]) if k["dt"] > 0 else "-", "Lãi gộp / doanh thu thuần", lg < 0),
                    ("Lãi sau phân bổ chi phí", tien(lg - k["cp"]), "Trừ chi phí bán hàng + quản lý %s" % tien(k["cp"]), lg - k["cp"] < 0),
                    ("Số mặt hàng bán lỗ", "%d" % len(lo), ("Lỗ gộp %s" % tien(-sum(r["lg"] for r in lo))) if lo else "Không có mặt hàng bán lỗ", bool(lo))])]
    # (a) lai gop theo khach hang: 15 khach |lai gop| lon nhat, xep tu lai nhieu den lo nhieu
    kh = [r for r in k["kh"] if abs(r["dt"]) > 0.5 or abs(r["gv"]) > 0.5]
    chon = sorted(sorted(kh, key=lambda r: -abs(r["lg"]))[:15], key=lambda r: -r["lg"])
    ds = [{"nhan": _ten_ma(r["ma"], r["ten"]), "v": r["lg"],
           "tip": "doanh thu %s, giá vốn %s, biên %s%s" % (tien(r["dt"]), tien(r["gv"]), pt(r["bien"]) if r["bien"] is not None else "-",
                                                         (", nợ quá hạn %s" % tien(r["qua_han"])) if r["qua_han"] > 0.5 else "")} for r in chon]
    ghi = ("%d / %d khách có lãi gộp (dương hoặc âm) lớn nhất. " % (len(chon), len(kh)) if len(kh) > len(chon) else "") + \
        "Thanh đỏ: khách bán lỗ (giá vốn cao hơn doanh thu). Lãi gộp chưa trừ chi phí bán hàng, quản lý."
    h.append(BD.bd_an_toan("Lãi gộp theo khách hàng", BD.bd_ngang, "Lãi gộp theo khách hàng", ds, tien, ghi=ghi))
    # (b) (c) theo thang
    th = k["th"]
    nhan = [x["thang"] for x in th]
    h.append(BD.bd_an_toan("Doanh thu, giá vốn, lãi gộp theo tháng", BD.bd_cot, "Doanh thu, giá vốn, lãi gộp theo tháng", nhan,
                           [{"ten": "Doanh thu thuần", "v": [x["dt"] for x in th], "mau": BD.BD_XAM},
                            {"ten": "Giá vốn", "v": [x["gv"] for x in th], "mau": BD.BD_VANG},
                            {"ten": "Lãi gộp", "v": [x["lg"] for x in th], "mau": BD.BD_XANH, "mau_am": BD.BD_DO}], tien,
                           ghi="Cùng một trục số tiền; lãi gộp âm (lỗ) tô đỏ. Rê chuột lên cột để xem số tiền."))
    bien_tb = lg / k["dt"] if k["dt"] > 0 else None
    h.append(BD.bd_an_toan("Biên lãi gộp theo tháng", BD.bd_duong, "Biên lãi gộp theo tháng", nhan, [x["bien"] for x in th], pt, fmt_truc=BD.bd_pt,
                           moc=(bien_tb, "Bình quân %s" % pt(bien_tb)) if bien_tb is not None else None, kep=(-1.0, 1.0),
                           ghi="Biên lãi gộp = lãi gộp / doanh thu thuần từng tháng; tháng không có doanh thu để trống. Điểm đỏ: tháng lỗ gộp."))
    if th:
        h.append("<div class='bd'><h2 class='bd-t'>Bảng lãi theo tháng</h2><table class='bg'><tr><th>Tháng</th><th>Doanh thu</th><th>Giá vốn</th>"
                 "<th>Lãi gộp</th><th>Biên</th><th>CP BH + QL</th><th>Lãi sau PB</th></tr>")
        for x in th:
            h.append("<tr><td>%s</td>%s<td>%s</td>%s</tr>" % (
                html.escape(x["thang"]), "".join("<td%s>%s</td>" % (" class='am'" if x[c] < 0 else "", tien(x[c])) for c in ("dt", "gv", "lg")),
                pt(x["bien"]) if x["bien"] is not None else "-", "".join("<td%s>%s</td>" % (" class='am'" if x[c] < 0 else "", tien(x[c])) for c in ("cp", "lr"))))
        h.append("</table></div>")
    return h


def _html_ton(P, BD):
    """GD176: chi so + ABC + so ngay ton (theo gia tri) + cham luan chuyen top 10 + can dat hang top 10."""
    k = P.kq_ton
    d = k["dong"]
    cham = [r for r in d if r["cham"]]
    dat = [r for r in d if r["dat"] > 0]
    am = [r for r in d if r["l"] < -1e-9]
    duong = [r for r in d if r["t"] > 0]
    tong = sum(r["t"] for r in duong)
    nhom_a = [r for r in duong if r["nhom"] == "A"]
    n_nvl = sum(1 for r in dat if r["nvl"])
    h = [BD.bd_kpi([("Tổng giá trị tồn kho", tien(k["tong"]), "%d mã có tồn / phát sinh" % len(d), False),
                    ("Nhóm A (80% giá trị)", "%d mã" % len(nhom_a), "Giá trị %s" % tien(sum(r["t"] for r in nhom_a)), False),
                    ("Chậm luân chuyển", "%d mã" % len(cham), "Giá trị %s" % tien(sum(r["t"] for r in cham)), False),
                    ("Cần đặt hàng / sắp hết", "%d mã" % len(dat), ("Trong đó %d nguyên vật liệu" % n_nvl) if n_nvl else "Theo tốc độ xuất 3 tháng", False),
                    ("Âm kho", "%d mã" % len(am), "Tính lại giá xuất / xem phiếu nhập xuất" if am else "Không có mã âm kho", bool(am))])]
    # (a) ABC
    ds = []
    if tong > 0:
        for nh, mau, mo in (("A", BD.BD_XANH, "80% giá trị đầu tiên"), ("B", "#60a5fa", "15% tiếp theo"), ("C", "#93c5fd", "phần còn lại")):
            g = [r for r in duong if r["nhom"] == nh]
            v = sum(r["t"] for r in g)
            ds.append({"nhan": "Nhóm %s (%d mã)" % (nh, len(g)), "v": v, "mau": mau, "nhan_v": "%s (%s)" % (tien(v), pt(v / tong)), "tip": mo})
    h.append(BD.bd_an_toan("Phân loại ABC theo giá trị tồn", BD.bd_ngang, "Phân loại ABC theo giá trị tồn", ds, tien, nhan_w=150,
                           ghi="Nhóm A: các mã lớn nhất cộng dồn tới 80% giá trị tồn; B: 15% tiếp theo; C: phần còn lại. Ưu tiên kiểm kê, theo dõi nhóm A."))
    # (b) so ngay ton theo gia tri
    ten_n = ("Đủ dùng đến 30 ngày", "31 - 90 ngày", "91 - 180 ngày", "Trên 180 ngày", "Không xuất trong %d tháng gần nhất" % len(k["thang"]))
    mau_n = (BD.BD_XANH, BD.BD_XANH, BD.BD_VANG, BD.BD_DO, BD.BD_DO)
    gt, so = [0.0] * 5, [0] * 5
    for r in duong:
        if r["l"] <= 0:
            continue
        n = r["ngay_ton"]
        i = 4 if n is None else (0 if n <= 30 else 1 if n <= 90 else 2 if n <= 180 else 3)
        gt[i] += r["t"]
        so[i] += 1
    tg = sum(gt)
    ds = [{"nhan": "%s (%d mã)" % (ten_n[i], so[i]), "v": gt[i], "mau": mau_n[i], "nhan_v": "%s (%s)" % (tien(gt[i]), pt(gt[i] / tg))} for i in range(5)] if tg > 0 else []
    h.append(BD.bd_an_toan("Số ngày tồn kho (theo giá trị)", BD.bd_ngang, "Số ngày tồn kho (theo giá trị)", ds, tien, nhan_w=280, so_chu=46,
                           ghi="Số ngày tồn = tồn cuối / xuất bình quân ngày (%s). Đỏ: tồn quá 180 ngày hoặc không xuất - xem xét giảm giá, thanh lý."
                           % ", ".join(k["thang"])))
    # (c) cham luan chuyen / can dat hang
    ds = [{"nhan": _ten_ma(r["ma"], r["ten"]), "v": r["t"], "mau": BD.BD_VANG,
           "tip": "tồn %s %s, %s" % (_sl(r["l"]), r["dvt"], ("không xuất %d ngày" % r["khong_xuat"]) if r["khong_xuat"] is not None else "chưa xuất")}
          for r in sorted(cham, key=lambda r: -r["t"])[:10]]
    h.append(BD.bd_an_toan("Chậm luân chuyển - 10 mã giá trị lớn nhất", BD.bd_ngang, "Chậm luân chuyển - 10 mã giá trị lớn nhất", ds, tien,
                           ghi="Không xuất từ %d ngày hoặc đủ dùng trên 180 ngày. Cân nhắc giảm giá, thanh lý, ngừng nhập; lập dự phòng nếu giá trị thuần thấp hơn giá gốc."
                           % P.ts.cham, rong="Không có mã chậm luân chuyển."))

    def con_ngay(r):
        return max(r["l"], 0.0) / (r["toc"] / 30.0) if r["toc"] > 0 else 0.0
    ds = [{"nhan": _ten_ma(r["ma"], r["ten"]) + (" (NVL)" if r["nvl"] else ""), "v": con_ngay(r), "mau": BD.BD_DO if r["l"] <= 0 else BD.BD_VANG,
           "nhan_v": "còn %d ngày - đặt %s %s" % (round(con_ngay(r)), _sl(r["dat"]), r["dvt"]),
           "tip": "tồn %s %s, xuất bình quân %s / tháng" % (_sl(r["l"]), r["dvt"], _sl(r["toc"]))} for r in sorted(dat, key=con_ngay)[:10]]
    cho = P.ts.cho + P.ts.du_phong
    h.append(BD.bd_an_toan("Cần đặt hàng - 10 mã gấp nhất", BD.bd_ngang, "Cần đặt hàng - 10 mã gấp nhất", ds, tien, moc=(cho, "Chờ hàng + dự phòng %d ngày" % cho),
                           ghi="Thanh = số ngày tồn còn đủ dùng theo tốc độ xuất; vạch dọc = %d ngày chờ hàng + %d ngày dự phòng. Đỏ: đã hết hàng."
                           % (P.ts.cho, P.ts.du_phong), rong="Không có mã cần đặt hàng."))
    return h


def viet_html(P, ra):
    import dong_tien as BD
    cty = (P.dl.get("cty") or {}).get("ten") or ""
    if P.ts.loai == "TON":
        ds = [(x["ma"] + " " + x["ten"][:30], x["t"]) for x in P.kq_ton["dong"][:15]]
        tieu = "Tồn kho - 15 mã giá trị lớn nhất"
        trang = "Tồn kho thông minh"
        phu = "Số liệu sổ đến ngày %s; tốc độ xuất bình quân %s. Ước tính từ sổ kế toán, chỉ đọc." % (
            P.kq_ton["den"].strftime("%d/%m/%Y"), ", ".join(P.kq_ton["thang"]))
    else:
        ds = [(x["ma"] + " " + x["ten"][:30], x["lg"]) for x in P.kq_lai["vt"] if x["vt"]][:15]
        tieu = "Lãi gộp - 15 mặt hàng cao nhất"
        trang = "Lãi theo mặt hàng, khách hàng, tháng"
        try:
            ky = "Từ %s đến %s. " % (P.S.tu.strftime("%d/%m/%Y"), P.S.den.strftime("%d/%m/%Y"))
        except Exception:
            ky = ""
        phu = ky + "Ước tính từ sổ kế toán, chỉ đọc. Chi phí bán hàng + quản lý (641 / 642) phân bổ theo tỷ trọng doanh thu."
    mx = max([abs(v) for _, v in ds] or [1]) or 1
    h = ["<!doctype html><html lang='vi'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>%s</title>"
         "<style>body{font-family:Segoe UI,Arial,sans-serif;margin:16px;color:#1f2937;max-width:900px}"
         "h1{font-size:19px;color:#0b3d91;margin:0 0 2px}.g{color:#555;font-style:italic}td{padding:2px 6px;font-size:13px}table{border-collapse:collapse}"
         ".cb td{border-bottom:1px solid #e5e7eb;vertical-align:top}.cb td:nth-child(-n+3){white-space:nowrap}.bg th{background:#eef2ff;font-weight:600;font-size:12.5px;padding:3px 8px;text-align:right}"
         ".bg td{text-align:right;border-bottom:1px solid #e5e7eb;padding:2px 8px;font-variant-numeric:tabular-nums}.bg th:first-child,.bg td:first-child{text-align:left}"
         ".am{color:#b91c1c}%s%s</style></head><body><h1>%s</h1><p class='g'>%s%s</p>"
         % (html.escape(trang), BD.BD_CSS, BD.BD_IN, html.escape(trang), (html.escape(cty) + ". ") if cty else "", html.escape(phu))]
    phan = _html_ton(P, BD) if P.ts.loai == "TON" else _html_lai(P, BD)
    h.append(phan[0])                                    # hang chi so dat dau trang
    if ds:
        H = 24 * len(ds) + 10
        sv = ["<svg viewBox='0 0 760 %d' width='760' height='%d' style='max-width:760px' role='img' aria-label='%s'>" % (H, H, html.escape(tieu))]
        for i, (t, v) in enumerate(ds):
            w = int(400 * abs(v) / mx)
            sv.append("<text x='0' y='%d' font-size='12'>%s</text><rect x='250' y='%d' width='%d' height='16' fill='%s'><title>%s: %s</title></rect>"
                      "<text x='%d' y='%d' font-size='12'>%s</text>"
                      % (24 * i + 16, html.escape(t), 24 * i + 4, max(w, 1), "#2563eb" if v >= 0 else "#dc2626", html.escape(t), tien(v), 256 + w, 24 * i + 16, tien(v)))
        sv.append("</svg>")
        h.append(BD.bd_khung(tieu, "".join(sv), "Thanh đỏ: giá trị âm." if any(v < 0 for _, v in ds) else None))
    else:
        h.append(BD.bd_rong(tieu))
    h.extend(phan[1:])
    h.append("<h2 class='bd-t'>Cảnh báo</h2><table class='cb'>")
    for m, l, ma, nd, gy in P.canh_bao[:60]:
        h.append("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>" % (html.escape(m), html.escape(l), html.escape(ma), html.escape(nd)))
    if not P.canh_bao:
        h.append("<tr><td class='g'>Không có cảnh báo.</td></tr>")
    h.append("</table></body></html>")
    with io.open(ra, "w", encoding="utf-8") as f:
        f.write("\n".join(h))
    return ra


def chay(duong_json, ra):
    with io.open(duong_json, "r", encoding="utf-8-sig") as f:
        dl = json.loads(f.read(), strict=False)
    P = PhanTich(dl)
    if P.ts.loai == "TON":
        P.ton()
    else:
        P.lai()
    if not ra:
        ra = os.path.join(GOC, "ket-qua", "PhanTich_%s.xlsx" % P.ts.loai)
    lap_excel(P, ra)
    viet_html(P, os.path.splitext(ra)[0] + ".html")
    ghi_txt(P, os.path.join(GOC, "ket-qua", "phan_tich_kd.txt"), ra)
    return ra, ""


if __name__ == "__main__":
    import sys
    if len(sys.argv) >= 2:
        print(chay(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else ""))
