# -*- coding: utf-8 -*-
"""GD78 - BAO CAO TAI CHINH NAM (TT133/2016) + TO KHAI QUYET TOAN 03/TNDN (TT80/2021) cho "Xuat 1 lan" (CHI DOC SO).

  lap(dl, ma, kieu, thumuc)  ma: B01A B02 B03 F01 TNDN ; kieu chua "E" (Excel dung ban in HTKK) va / hoac "X" (XML HTKK)
     Excel: MOI MUC MOT TEP  B01a_DNN_<nam>.xlsx  B02_DNN_<nam>.xlsx  B03_DNN_<nam>.xlsx  F01_DNN_<nam>.xlsx  03_TNDN_<nam>.xlsx
     XML  : 133_B01A_DNN_BCTC_<nam>.xml (maTKhai 683, 2.3.2: B01a + PL_KQHDSXKD + PL_LCTTTT + PL_CDTK) - lap MOT lan du chon
            nhieu muc B01A / B02 / B03 / F01 ; 03_TNDN_TT80_<nam>.xml (maTKhai 892, 2.9.4: to khai + PL 03-1A + PL 03-2).
  gia_tri_bctc(dl) -> {"B01A": {ma: (cuoi, dau)}, "B02": {ma: (nay, truoc)}, "B03": {ma: (nay, truoc)}, "F01": [dong...], ...}
     (dung lai cho thuyet minh B09 / nhom khac).

NGUON SO LIEU (khong doan):
  * B01a / B02 / B03 = SO CUA CHINH DONG CO BAO CAO PHAN MEM (VB6 InCdtsB01aExcel / InKqkdExcelTT133 / InLCTTExcelTT133 chay
    che do chiTinh -> doc bang tam CdTs / KQKD / LCTT) - dl["bctc"] do ModHDDTBaoCaoNam.HDDT_BCN_JsonThem ghi. Dong tong tinh lai
    tu dong chi tiet DA LAM TRON (nhu cong thuc HTKK), lech voi dong tong cua dong co -> canh bao.
  * F01 = tu dl["tk"] (so du dau nam), dl["ps"] (phat sinh theo thang), dl["kh_dau" / "kh_no" / "kh_co"] (131 / 331 tach
    du No / du Co THEO DOI TUONG nhu PL_CDTK cua HTKK); TK cha = cong TK con (nhu cong thuc HTKK); tongCong = cong TK cap 1.
  * Cot nam truoc B03 (dong co de 0 khi ky bat dau thang dau nam) va so lo cac nam truoc (PL 03-2): tu to khai nam truoc -
    (a) XML HTKK chuan (HSoThueDTu) nam N-1 trong thu muc khach (de quy, ca ket qua Xuat 1 lan truoc), (b) du lieu HTKK tren may
    <HTKK>\\DataFiles\\<MST>\\03_2_TNDN_TT80_<N-1>_*.xml, 133_B01A_03_LCTTTT_<N-1>_*.xml. Khong co -> 0 + CANH BAO.
  * 03/TNDN: A1 = B02 ma 50; B / C / D / E / G / H / I theo cong thuc HTKK 2.9.4 (nhu ClsThueTNDN.TT80_TinhLai); thue suat [C7]
    do nguoi dung chon (dl["tndn"]["thue_suat"], hop chon HDDT_TNDN_HoiThueSuat); [G2] = No 3334 / Co 11x trong ky."""
import io
import os
import re
import xml.etree.ElementTree as ET
from collections import defaultdict
from datetime import datetime

NS = "http://kekhaithue.gdt.gov.vn/TKhaiThue"
NS_XSI = "http://www.w3.org/2001/XMLSchema-instance"
MUC_BCTC = ("B01A", "B02", "B03", "F01")
SO_FMT = '#,##0;(#,##0);0'     # nhu ban in HTKK: am trong ngoac, 0 ghi "0"

# ------------------------------------------------------------------ bieu mau (ten dung ban in HTKK)
B01A_DONG = [
    ("TÀI SẢN", None, "td"),
    ("I. Tiền và các khoản tương đương tiền", 110, "d"), ("II. Đầu tư tài chính", 120, "d"),
    ("1. Chứng khoán kinh doanh", 121, ""), ("2. Đầu tư nắm giữ đến ngày đáo hạn", 122, ""),
    ("3. Đầu tư góp vốn vào đơn vị khác", 123, ""), ("4. Dự phòng tổn thất đầu tư tài chính (*)", 124, ""),
    ("III. Các khoản phải thu", 130, "d"), ("1. Phải thu của khách hàng", 131, ""), ("2. Trả trước cho người bán", 132, ""),
    ("3. Vốn kinh doanh ở đơn vị trực thuộc", 133, ""), ("4. Phải thu khác", 134, ""), ("5. Tài sản thiếu chờ xử lý", 135, ""),
    ("6. Dự phòng phải thu khó đòi (*)", 136, ""),
    ("IV. Hàng tồn kho", 140, "d"), ("1. Hàng tồn kho", 141, ""), ("2. Dự phòng giảm giá hàng tồn kho (*)", 142, ""),
    ("V. Tài sản cố định", 150, "d"), ("- Nguyên giá", 151, ""), ("- Giá trị hao mòn lũy kế (*)", 152, ""),
    ("VI. Bất động sản đầu tư", 160, "d"), ("- Nguyên giá", 161, ""), ("- Giá trị hao mòn lũy kế (*)", 162, ""),
    ("VII. XDCB dở dang", 170, "d"), ("VIII. Tài sản khác", 180, "d"), ("1. Thuế GTGT được khấu trừ", 181, ""),
    ("2. Tài sản khác", 182, ""),
    ("TỔNG CỘNG TÀI SẢN (200=110+120+130+140+150+160+170+180)", 200, "t"),
    ("NGUỒN VỐN", None, "td"),
    ("I. Nợ phải trả", 300, "d"), ("1. Phải trả người bán", 311, ""), ("2. Người mua trả tiền trước", 312, ""),
    ("3. Thuế và các khoản phải nộp Nhà nước", 313, ""), ("4. Phải trả người lao động", 314, ""), ("5. Phải trả khác", 315, ""),
    ("6. Vay và nợ thuê tài chính", 316, ""), ("7. Phải trả nội bộ về vốn kinh doanh", 317, ""), ("8. Dự phòng phải trả", 318, ""),
    ("9. Quỹ khen thưởng, phúc lợi", 319, ""), ("10. Quỹ phát triển khoa học và công nghệ", 320, ""),
    ("II. Vốn chủ sở hữu", 400, "d"), ("1. Vốn góp của chủ sở hữu", 411, ""), ("2. Thặng dư vốn cổ phần", 412, ""),
    ("3. Vốn khác của chủ sở hữu", 413, ""), ("4. Cổ phiếu quỹ (*)", 414, ""), ("5. Chênh lệch tỷ giá hối đoái", 415, ""),
    ("6. Các quỹ thuộc vốn chủ sở hữu", 416, ""), ("7. Lợi nhuận sau thuế chưa phân phối", 417, ""),
    ("TỔNG CỘNG NGUỒN VỐN (500=300+400)", 500, "t"),
]
B01A_MA = [x[1] for x in B01A_DONG if x[1]]
B01A_TONG = {120: (121, 122, 123, 124), 130: (131, 132, 133, 134, 135, 136), 140: (141, 142), 150: (151, 152), 160: (161, 162),
             180: (181, 182), 200: (110, 120, 130, 140, 150, 160, 170, 180), 300: tuple(range(311, 321)),
             400: tuple(range(411, 418)), 500: (300, 400)}

B02_DONG = [
    ("1. Doanh thu bán hàng và cung cấp dịch vụ", 1, ""), ("2. Các khoản giảm trừ doanh thu", 2, ""),
    ("3. Doanh thu thuần về bán hàng và cung cấp dịch vụ (10= 01-02)", 10, "d"), ("4. Giá vốn hàng bán", 11, ""),
    ("5. Lợi nhuận gộp về bán hàng và cung cấp dịch vụ (20=10-11)", 20, "d"), ("6. Doanh thu hoạt động tài chính", 21, ""),
    ("7. Chi phí tài chính", 22, ""), ("- Trong đó: Chi phí lãi vay", 23, "n"), ("8. Chi phí quản lý kinh doanh", 24, ""),
    ("9. Lợi nhuận thuần từ hoạt động kinh doanh (30 = 20 + 21 - 22 - 24)", 30, "d"), ("10. Thu nhập khác", 31, ""),
    ("11. Chi phí khác", 32, ""), ("12. Lợi nhuận khác (40 = 31 - 32)", 40, "d"),
    ("13. Tổng lợi nhuận kế toán trước thuế (50 = 30 + 40)", 50, "d"), ("14. Chi phí thuế TNDN", 51, ""),
    ("15. Lợi nhuận sau thuế thu nhập doanh nghiệp (60=50 - 51)", 60, "d"),
]
B02_MA = [x[1] for x in B02_DONG]

B03_DONG = [
    ("I. Lưu chuyển tiền từ hoạt động kinh doanh", None, "tl"),
    ("1. Tiền thu từ bán hàng, cung cấp dịch vụ và doanh thu khác", 1, ""),
    ("2. Tiền chi trả cho người cung cấp hàng hóa, dịch vụ", 2, ""), ("3. Tiền chi trả cho người lao động", 3, ""),
    ("4. Tiền lãi vay đã trả", 4, ""), ("5. Thuế thu nhập doanh nghiệp đã nộp", 5, ""),
    ("6. Tiền thu khác từ hoạt động kinh doanh", 6, ""), ("7. Tiền chi khác cho hoạt động kinh doanh", 7, ""),
    ("Lưu chuyển tiền thuần từ hoạt động kinh doanh", 20, "d"),
    ("II. Lưu chuyển tiền từ hoạt động đầu tư", None, "tl"),
    ("1. Tiền chi để mua sắm, xây dựng TSCĐ, BĐSĐT và các tài sản dài hạn khác", 21, ""),
    ("2. Tiền thu từ thanh lý, nhượng bán TSCĐ, BĐSĐT và các tài sản dài hạn khác", 22, ""),
    ("3. Tiền chi cho vay, đầu tư góp vốn vào đơn vị khác", 23, ""),
    ("4. Tiền thu hồi cho vay, đầu tư góp vốn vào đơn vị khác", 24, ""),
    ("5. Tiền thu lãi cho vay, cổ tức và lợi nhuận được chia", 25, ""),
    ("Lưu chuyển tiền thuần từ hoạt động đầu tư", 30, "d"),
    ("III. Lưu chuyển tiền từ hoạt động tài chính", None, "tl"),
    ("1. Tiền thu từ phát hành cổ phiếu, nhận vốn góp của chủ sở hữu", 31, ""),
    ("2. Tiền trả lại vốn góp cho các chủ sở hữu, mua lại cổ phiếu của doanh nghiệp đã phát hành", 32, ""),
    ("3. Tiền thu từ đi vay", 33, ""), ("4. Tiền trả nợ gốc vay và nợ thuê tài chính", 34, ""),
    ("5. Cổ tức, lợi nhuận đã trả cho chủ sở hữu", 35, ""),
    ("Lưu chuyển tiền thuần từ hoạt động tài chính", 40, "d"),
    ("Lưu chuyển tiền thuần trong kỳ (50 = 20+30+40)", 50, "d"), ("Tiền và tương đương tiền đầu kỳ", 60, ""),
    ("Ảnh hưởng của thay đổi tỷ giá hối đoái quy đổi ngoại tệ", 61, ""),
    ("Tiền và tương đương tiền cuối kỳ (70 = 50+60+61)", 70, "d"),
]
B03_MA = [x[1] for x in B03_DONG if x[1]]

# Bang can doi tai khoan: danh muc TK cua PL_CDTK HTKK 2.3.2 (dung thu tu the XML) ; "#" = dong nhom (chi Excel)
CDTK_DS = (
    "111|Tiền mặt;1111|Tiền Việt Nam;1112|Ngoại tệ;112|Tiền gửi Ngân hàng;1121|Tiền Việt Nam;1122|Ngoại tệ;"
    "121|Chứng khoán kinh doanh;128|Đầu tư nắm giữ đến ngày đáo hạn;1281|Tiền gửi có kỳ hạn;"
    "1288|Các khoản đầu tư khác nắm giữ đến ngày đáo hạn;131|Phải thu của khách hàng;133|Thuế GTGT được khấu trừ;"
    "1331|Thuế GTGT được khấu trừ của hàng hóa, dịch vụ;1332|Thuế GTGT được khấu trừ của TSCĐ;136|Phải thu nội bộ;"
    "1361|Vốn kinh doanh ở đơn vị trực thuộc;1368|Phải thu nội bộ khác;138|Phải thu khác;1381|Tài sản thiếu chờ xử lý;"
    "1386|Cầm cố, thế chấp, ký quỹ, ký cược;1388|Phải thu khác;141|Tạm ứng;151|Hàng mua đang đi đường;"
    "152|Nguyên liệu, vật liệu;153|Công cụ, dụng cụ;154|Chi phí sản xuất, kinh doanh dở dang;155|Thành phẩm;156|Hàng hóa;"
    "157|Hàng gửi đi bán;211|Tài sản cố định;2111|TSCĐ hữu hình;2112|TSCĐ thuê tài chính;2113|TSCĐ vô hình;"
    "214|Hao mòn tài sản cố định;2141|Hao mòn TSCĐ hữu hình;2142|Hao mòn TSCĐ thuê tài chính;2143|Hao mòn TSCĐ vô hình;"
    "2147|Hao mòn bất động sản đầu tư;217|Bất động sản đầu tư;228|Đầu tư góp vốn vào đơn vị khác;"
    "2281|Đầu tư vào công ty liên doanh, liên kết;2288|Đầu tư khác;229|Dự phòng tổn thất tài sản;"
    "2291|Dự phòng giảm giá chứng khoán kinh doanh;2292|Dự phòng tổn thất đầu tư vào đơn vị khác;"
    "2293|Dự phòng phải thu khó đòi;2294|Dự phòng giảm giá hàng tồn kho;241|Xây dựng cơ bản dở dang;2411|Mua sắm TSCĐ;"
    "2412|Xây dựng cơ bản;2413|Sửa chữa lớn TSCĐ;242|Chi phí trả trước;#|LOẠI TÀI KHOẢN NỢ PHẢI TRẢ;"
    "331|Phải trả cho người bán;333|Thuế và các khoản phải nộp Nhà nước;3331|Thuế giá trị gia tăng phải nộp;"
    "33311|Thuế GTGT đầu ra;33312|Thuế GTGT hàng nhập khẩu;3332|Thuế tiêu thụ đặc biệt;3333|Thuế xuất, nhập khẩu;"
    "3334|Thuế thu nhập doanh nghiệp;3335|Thuế thu nhập cá nhân;3336|Thuế tài nguyên;3337|Thuế nhà đất, tiền thuê đất;"
    "3338|Thuế bảo vệ môi trường và các loại thuế khác;33381|Thuế bảo vệ môi trường;33382|Các loại thuế khác;"
    "3339|Phí, lệ phí và các khoản phải nộp khác;334|Phải trả người lao động;335|Chi phí phải trả;336|Phải trả nội bộ;"
    "3361|Phải trả nội bộ về vốn kinh doanh;3368|Phải trả nội bộ khác;338|Phải trả, phải nộp khác;"
    "3381|Tài sản thừa chờ giải quyết;3382|Kinh phí công đoàn;3383|Bảo hiểm xã hội;3384|Bảo hiểm y tế;"
    "3385|Bảo hiểm thất nghiệp;3386|Nhận ký quỹ, ký cược;3387|Doanh thu chưa thực hiện;3388|Phải trả, phải nộp khác;"
    "341|Vay và nợ thuê tài chính;3411|Các khoản đi vay;3412|Nợ thuê tài chính;352|Dự phòng phải trả;"
    "3521|Dự phòng bảo hành sản phẩm hàng hóa;3522|Dự phòng bảo hành công trình xây dựng;3524|Dự phòng phải trả khác;"
    "353|Quỹ khen thưởng phúc lợi;3531|Quỹ khen thưởng;3532|Quỹ phúc lợi;3533|Quỹ phúc lợi đã hình thành TSCĐ;"
    "3534|Quỹ thưởng ban quản lý điều hành công ty;356|Quỹ phát triển khoa học và công nghệ;"
    "3561|Quỹ phát triển khoa học và công nghệ;3562|Quỹ phát triển khoa học và công nghệ đã hình thành TSCĐ;"
    "#|LOẠI TÀI KHOẢN VỐN CHỦ SỞ HỮU;411|Vốn đầu tư của chủ sở hữu;4111|Vốn góp của chủ sở hữu;4112|Thặng dư vốn cổ phần;"
    "4118|Vốn khác;413|Chênh lệch tỷ giá hối đoái;418|Các quỹ thuộc vốn chủ sở hữu;419|Cổ phiếu quỹ;"
    "421|Lợi nhuận sau thuế chưa phân phối;4211|Lợi nhuận sau thuế chưa phân phối năm trước;"
    "4212|Lợi nhuận sau thuế chưa phân phối năm nay;#|LOẠI TÀI KHOẢN DOANH THU;"
    "511|Doanh thu bán hàng và cung cấp dịch vụ;5111|Doanh thu bán hàng hóa;5112|Doanh thu bán thành phẩm;"
    "5113|Doanh thu cung cấp dịch vụ;5118|Doanh thu khác;515|Doanh thu hoạt động tài chính;"
    "#|LOẠI TÀI KHOẢN CHI PHÍ SẢN XUẤT, KINH DOANH;611|Mua hàng;631|Giá thành sản xuất;632|Giá vốn hàng bán;"
    "635|Chi phí tài chính;642|Chi phí quản lý kinh doanh;6421|Chi phí bán hàng;6422|Chi phí quản lý doanh nghiệp;"
    "#|LOẠI TÀI KHOẢN THU NHẬP KHÁC;711|Thu nhập khác;#|LOẠI TÀI KHOẢN CHI PHÍ KHÁC;811|Chi phí khác;"
    "821|Chi phí thuế thu nhập doanh nghiệp;#|TÀI KHOẢN XÁC ĐỊNH KẾT QUẢ KINH DOANH;911|Xác định kết quả kinh doanh"
)
CDTK = [tuple(x.split("|", 1)) for x in CDTK_DS.split(";")]
CDTK_TK = [a for a, _ in CDTK if a != "#"]
CDTK_TEN = {a: b for a, b in CDTK if a != "#"}


def _cha_cdtk(a):
    """TK cha gan nhat trong danh muc PL_CDTK ("" = cap 1)."""
    p = [b for b in CDTK_TK if b != a and a.startswith(b)]
    return max(p, key=len) if p else ""


CDTK_CHA = {a: _cha_cdtk(a) for a in CDTK_TK}
CDTK_CON = defaultdict(list)
for _a in CDTK_TK:
    if CDTK_CHA[_a]:
        CDTK_CON[CDTK_CHA[_a]].append(_a)
CDTK_CAP1 = [a for a in CDTK_TK if not CDTK_CHA[a]]
COT_F01 = ("dau_no", "dau_co", "ps_no", "ps_co", "cuoi_no", "cuoi_co")

# To khai 03/TNDN (TT80) - (stt, chi tieu, ma) ; ma None = dong muc
TNDN_DONG = [
    ("A", "Kết quả kinh doanh ghi nhận theo báo cáo tài chính", "A"),
    ("1", "Tổng lợi nhuận kế toán trước thuế thu nhập doanh nghiệp", "A1"),
    ("B", "Xác định thu nhập chịu thuế theo Luật thuế thu nhập doanh nghiệp", "B"),
    ("1", "Điều chỉnh tăng tổng lợi nhuận trước thuế thu nhập doanh nghiệp (B1= B2+B3+B4+B5+B6+B7)", "B1"),
    ("1.1", "Các khoản điều chỉnh tăng doanh thu", "B2"), ("1.2", "Chi phí của phần doanh thu điều chỉnh giảm", "B3"),
    ("1.3", "Các khoản chi không được trừ khi xác định thu nhập chịu thuế", "B4"),
    ("1.4", "Thuế thu nhập đã nộp cho phần thu nhập nhận được ở nước ngoài", "B5"),
    ("1.5", "Điều chỉnh tăng lợi nhuận do xác định giá thị trường đối với giao dịch liên kết", "B6"),
    ("1.6", "Các khoản điều chỉnh làm tăng lợi nhuận trước thuế khác", "B7"),
    ("2", "Điều chỉnh giảm tổng lợi nhuận trước thuế thu nhập doanh nghiệp (B8=B9+B10+B11+B12)", "B8"),
    ("2.1", "Giảm trừ các khoản doanh thu đã tính thuế năm trước", "B9"),
    ("2.2", "Chi phí của phần doanh thu điều chỉnh tăng", "B10"),
    ("2.3", "Chi phí lãi vay không được trừ kỳ trước được chuyển sang kỳ này của doanh nghiệp có giao dịch liên kết", "B11"),
    ("2.4", "Các khoản điều chỉnh làm giảm lợi nhuận trước thuế khác", "B12"),
    ("3", "Tổng thu nhập chịu thuế (B13=A1+B1-B8)", "B13"),
    ("3.1", "Thu nhập chịu thuế từ hoạt động sản xuất kinh doanh", "B14"),
    ("3.2", "Thu nhập chịu thuế từ hoạt động chuyển nhượng BĐS", "B15"),
    ("C", "Thuế thu nhập doanh nghiệp (TNDN) phải nộp từ hoạt động sản xuất kinh doanh", "C"),
    ("1", "Thu nhập chịu thuế (C1 = B14)", "C1"), ("2", "Thu nhập miễn thuế", "C2"),
    ("3", "Chuyển lỗ và bù trừ lãi, lỗ (C3=C3a+C3b)", "C3"),
    ("3.1", "+ Lỗ từ hoạt động SXKD được chuyển trong kỳ", "C3a"),
    ("3.2", "+ Lỗ từ chuyển nhượng BĐS được bù trừ với lãi của hoạt động SXKD", "C3b"),
    ("4", "Thu nhập tính thuế (TNTT) (C4=C1-C2-C3)", "C4"), ("5", "Trích lập quỹ khoa học công nghệ (nếu có)", "C5"),
    ("6", "TNTT sau khi đã trích lập quỹ khoa học công nghệ (C6=C4-C5=C7+C8)", "C6"),
    ("6.1", "+ Thu nhập tính thuế áp dụng thuế suất {ts}%", "C7"),
    ("6.2", "+ Thu nhập tính thuế tính theo thuế suất không ưu đãi khác", "C8"),
    ("6.3", "+ Thuế suất không ưu đãi khác (%)", "C8a"),
    ("7", "Thuế TNDN từ hoạt động SXKD tính theo thuế suất không ưu đãi (C9 = (C7 x {ts}%) + (C8 x C8a))", "C9"),
    ("8", "Thuế TNDN được ưu đãi theo Luật thuế TNDN (C10 = C11 + C12 + C13)", "C10"),
    ("8.1", "+ Thuế TNDN chênh lệch do áp dụng mức thuế suất ưu đãi", "C11"),
    ("8.2", "+ Thuế TNDN được miễn trong kỳ", "C12"), ("8.3", "+ Thuế TNDN được giảm trong kỳ", "C13"),
    ("9", "Thuế TNDN được miễn, giảm theo Hiệp định thuế", "C14"),
    ("10", "Thuế TNDN được miễn, giảm theo từng thời kỳ", "C15"),
    ("11", "Thuế thu nhập đã nộp ở nước ngoài được trừ trong kỳ tính thuế", "C16"),
    ("12", "Thuế TNDN phải nộp của hoạt động sản xuất kinh doanh (C17=C9-C10-C14-C15-C16)", "C17"),
    ("D", "Thuế TNDN phải nộp từ hoạt động chuyển nhượng BĐS", "D"),
    ("1", "Thu nhập chịu thuế (D1 = B15)", "D1"), ("2", "Lỗ từ hoạt động chuyển nhượng BĐS được chuyển trong kỳ", "D2"),
    ("3", "Thu nhập tính thuế (D3=D1-D2)", "D3"), ("4", "Trích lập quỹ khoa học công nghệ (nếu có)", "D4"),
    ("5", "TNTT sau khi đã trích lập quỹ khoa học công nghệ (D5=D3-D4)", "D5"),
    ("6", "Thuế TNDN phải nộp của hoạt động chuyển nhượng BĐS trong kỳ", "D6"),
    ("7", "Thuế TNDN chênh lệch do áp dụng mức thuế suất ưu đãi đối với thu nhập từ thực hiện dự án đầu tư - kinh doanh "
          "nhà ở xã hội để bán, cho thuê, cho thuê mua", "D7"),
    ("8", "Thuế TNDN của hoạt động chuyển nhượng BĐS còn phải nộp kỳ này (D8=D6-D7)", "D8"),
    ("E", "Số thuế TNDN phải nộp quyết toán trong kỳ (E=E1+E2+E5)", "E"),
    ("1", "Thuế TNDN của hoạt động sản xuất kinh doanh", "E1"),
    ("2", "Thuế TNDN từ hoạt động chuyển nhượng bất động sản (E2=E3+E4)", "E2"),
    ("2.1", "Thuế TNDN từ hoạt động chuyển nhượng bất động sản", "E3"),
    ("2.2", "Thuế TNDN từ hoạt động chuyển nhượng cơ sở hạ tầng, nhà có thu tiền theo tiến độ", "E4"),
    ("3", "Thuế TNDN phải nộp khác (nếu có)", "E5"),
    ("3.1", "Trong đó thuế TNDN từ xử lý Quỹ phát triển khoa học công nghệ", "E6"),
    ("G", "Số thuế TNDN đã tạm nộp (G=G1+G2+G3+G4+G5)", "G"),
    ("1", "Thuế TNDN đã tạm nộp của hoạt động sản xuất kinh doanh", "tamnop_sxkd"),
    ("1.1", "Thuế TNDN nộp thừa kỳ trước chuyển sang kỳ này", "G1"), ("1.2", "Thuế TNDN đã tạm nộp trong năm", "G2"),
    ("2", "Thuế TNDN đã tạm nộp của hoạt động chuyển nhượng BĐS", "tamnop_cnbds"),
    ("2.1", "Thuế TNDN nộp thừa kỳ trước chuyển sang kỳ này của hoạt động chuyển nhượng BĐS", "G3"),
    ("2.2", "Thuế TNDN đã tạm nộp trong năm của hoạt động chuyển nhượng BĐS", "G4"),
    ("2.3", "Thuế TNDN đã tạm nộp các kỳ trước và trong năm quyết toán của hoạt động chuyển nhượng cơ sở hạ tầng, nhà có "
            "thu tiền theo tiến độ", "G5"),
    ("H", "Chênh lệch giữa số thuế phải nộp và số thuế đã tạm nộp", "H"),
    ("1", "Chênh lệch giữa số thuế phải nộp và số thuế đã tạm nộp trong năm của hoạt động sản xuất kinh doanh (H1=E1+E5-G2)", "H1"),
    ("2", "Chênh lệch giữa số thuế phải nộp và số thuế đã tạm nộp trong năm của hoạt động chuyển nhượng BĐS (H2=E3-G4)", "H2"),
    ("3", "Chênh lệch giữa số thuế phải nộp và số thuế đã tạm nộp của hoạt động chuyển nhượng cơ sở hạ tầng, nhà có thu "
          "tiền theo tiến độ (H3=E4-G5)", "H3"),
    ("I", "Số thuế TNDN còn phải nộp đến thời hạn nộp hồ sơ khai quyết toán thuế (I=E-G=I1+I2)", "I"),
    ("1", "Thuế TNDN còn phải nộp của hoạt động sản xuất kinh doanh (I1=E1+E5-G1-G2)", "I1"),
    ("2", "Thuế TNDN còn phải nộp của hoạt động chuyển nhượng BĐS (I2=E2-G3-G4-G5)", "I2"),
]
TNDN_MUC = ("A", "B", "C", "D", "H")          # dong muc khong co so
# Thu tu the so trong CTieuTKhaiChinh cua XML 2.9.4 (sau Header)
TNDN_THE = ["A1"] + ["B%d" % i for i in range(1, 16)] + ["C1", "C2", "@dsThMienThue", "C3", "C3a", "C3b", "C4", "C5", "C6",
            "@C7", "C8", "C8a", "C9", "C10", "C11", "C12", "C13", "C14", "C15", "C16", "C17"] + ["D%d" % i for i in range(1, 9)] + \
    ["E", "E1", "E2", "E3", "E4", "E5", "E6", "G", "@tamnop_sxkd", "G1", "G2", "@tamnop_cnbds", "G3", "G4", "G5", "H1", "H2",
     "H3", "I", "I1", "I2"]

PL031A_DONG = [
    ("", "Kết quả kinh doanh ghi nhận theo báo cáo tài chính:", None),
    ("1", "Doanh thu bán hàng và cung cấp dịch vụ", "04"),
    ("", "Trong đó: - Doanh thu bán hàng hoá, dịch vụ xuất khẩu", "05"),
    ("2", "Các khoản giảm trừ doanh thu ([06]=[07]+[08]+[09])", "06"),
    ("a", "Chiết khấu thương mại", "07"), ("b", "Giảm giá hàng bán", "08"), ("c", "Giá trị hàng bán bị trả lại", "09"),
    ("3", "Doanh thu hoạt động tài chính", "10"), ("", "Trong đó: Doanh thu từ lãi tiền gửi", "11"),
    ("4", "Chi phí sản xuất, kinh doanh hàng hoá, dịch vụ ([12]=[13]+[14]+[15])", "12"),
    ("a", "Giá vốn hàng bán", "13"), ("b", "Chi phí bán hàng", "14"), ("c", "Chi phí quản lý doanh nghiệp", "15"),
    ("5", "Chi phí tài chính", "16"), ("", "Trong đó: Chi phí lãi tiền vay", "17"),
    ("6", "Lợi nhuận thuần từ hoạt động kinh doanh ([18]=[04]-[06]+[10]-[12]-[16])", "18"),
    ("7", "Thu nhập khác", "19"), ("8", "Chi phí khác", "20"), ("9", "Lợi nhuận khác ([21]=[19]-[20])", "21"),
    ("10", "Tổng lợi nhuận kế toán trước thuế thu nhập doanh nghiệp ([22]=[18]+[21])", "22"),
]
# Anh xa PL 03-1A <- B02 (ma so KQKD cua phan mem)
PL031A_TU_B02 = {"04": "B02[01] doanh thu (tổng, trước giảm trừ)", "07": "B02[02] giảm trừ doanh thu (phần mềm không tách CK / GG / "
                 "trả lại -> ghi cả vào [07])", "10": "B02[21]", "13": "B02[11]", "14": "kết chuyển Nợ 911 / Có 6421 trong kỳ",
                 "15": "B02[24] - [14]", "16": "B02[22]", "17": "B02[23]", "19": "B02[31]", "20": "B02[32]",
                 "11": "PS Có 515 đối ứng Nợ 112 trong kỳ", "05": "0 (phần mềm không tách doanh thu xuất khẩu - khai tay nếu có)"}


# ------------------------------------------------------------------ tien ich
def _so(x):
    if x in (None, ""):
        return 0.0
    if isinstance(x, (int, float)):
        return float(x)
    t = re.sub(r"[^\d,.\-]", "", str(x))
    if re.fullmatch(r"-?[\d.]+,\d+", t):
        t = t.replace(".", "").replace(",", ".")
    else:
        t = t.replace(",", "")
    try:
        return float(t)
    except ValueError:
        return 0.0


def lam_tron(x):
    """Lam tron dong nhu HTKK / Excel ROUND(x, 0): nua don vi ra xa so 0."""
    x = _so(x)
    return int(abs(x) + 0.5) * (1 if x >= 0 else -1)


def _dd(v):
    v = lam_tron(v)
    return ("-" if v < 0 else "") + "{:,}".format(abs(v)).replace(",", ".")


def _ngay(s):
    s = str(s or "").strip()
    for fm in ("%d/%m/%Y", "%Y-%m-%d"):
        try:
            return datetime.strptime(s[:10], fm)
        except ValueError:
            pass
    return None


def thang_tc(thang_ct, dau_ky):
    t = int(_so(thang_ct))
    if t <= 0:
        return 0
    if t > 12:
        return 13
    return t - dau_ky + 1 if t >= dau_ky else 13 - dau_ky + t


def _st(dl):
    """Trang thai / bo nho dem trong dl (lap MOT lan XML BCTC du chon nhieu muc)."""
    return dl.setdefault("_bcn", {})


def _ky(dl):
    x = dl.get("x1l") or {}
    ky = dl.get("ky") or {}
    tu = _ngay(x.get("tu") or ky.get("tu"))
    den = _ngay(x.get("den") or ky.get("den"))
    dau_ky = int(_so(x.get("thang_dau_ky") or dl.get("thang_dau_ky")) or 1)
    nam = int(_so(x.get("nam_tc") or dl.get("nam_tc")) or 0) or (den.year if den else datetime.now().year)
    if not tu:
        tu = datetime(nam, dau_ky, 1)
    if not den:
        den = datetime(nam + (1 if dau_ky > 1 else 0), (dau_ky - 2) % 12 + 1, 28)
    lap = _ngay(x.get("ngay_lap")) or datetime.now()
    return {"tu": tu, "den": den, "dau_ky": dau_ky, "nam": nam, "lap": lap,
            "t1": thang_tc(tu.month, dau_ky), "t2": thang_tc(den.month, dau_ky)}


def _dn(dl):
    dn = dict(dl.get("cty") or {})
    dn.update({k: v for k, v in (dl.get("dn") or {}).items() if v not in (None, "")})
    return dn


def _nguoi_ky(dl):
    nk = dict(dl.get("nguoi_ky") or {})
    dn = _dn(dl)
    if not nk.get("giam_doc"):
        nk["giam_doc"] = dn.get("nguoi_dd_pl") or dn.get("nguoi_ky") or ""
    if not nk.get("nguoi_ky"):
        nk["nguoi_ky"] = dn.get("nguoi_ky") or nk.get("giam_doc") or ""
    return nk


# ------------------------------------------------------------------ so lieu dong co (dl["bctc"])
def _bang_dong_co(dl, khoa):
    b = dl.get("bctc") or {}
    rows = b.get(khoa)
    if not rows:
        return None
    d = {}
    for r in rows:
        try:
            ma = int(_so(r[0]))
        except (TypeError, IndexError):
            continue
        a, c = lam_tron(r[1] if len(r) > 1 else 0), lam_tron(r[2] if len(r) > 2 else 0)
        x = d.get(ma, (0, 0))
        d[ma] = (x[0] + a, x[1] + c)
    return d


def _tinh_tong(chi, tong, thu_tu):
    """Dong tong = cong dong chi tiet DA lam tron (theo thu tu cac ma tong)."""
    d = dict(chi)
    for ma in thu_tu:
        ds = tong[ma]
        d[ma] = tuple(sum(d.get(x, (0, 0))[i] for x in ds) for i in (0, 1))
    return d


def _b01a(dl, cb):
    e = _bang_dong_co(dl, "b01a")
    if e is None:
        return None
    chi = {m: e.get(m, (0, 0)) for m in B01A_MA if m not in B01A_TONG}
    d = _tinh_tong(chi, B01A_TONG, (120, 130, 140, 150, 160, 180, 200, 300, 400, 500))
    for m in B01A_TONG:
        if m in e and e[m] != d[m]:
            cb.append("B01a [%d]: động cơ phần mềm ra %s / %s, cộng các dòng chi tiết (đã làm tròn) ra %s / %s - báo cáo ghi số "
                      "cộng lại (như HTKK)." % (m, _dd(e[m][0]), _dd(e[m][1]), _dd(d[m][0]), _dd(d[m][1])))
    la = [m for m in e if m not in B01A_MA and m not in (0, 600) and any(e[m])]
    if la:
        cb.append("B01a: bảng CDTS133a có mã không thuộc mẫu TT133 (%s) - không đưa vào báo cáo." % ", ".join(str(x) for x in la))
    return d


def _b02(dl, cb, nt):
    e = _bang_dong_co(dl, "b02")
    if e is None:
        return None
    d = {m: e.get(m, (0, 0)) for m in (1, 2, 11, 21, 22, 23, 24, 31, 32, 51)}

    def cot(i):
        g = {m: d[m][i] for m in d}
        g[10] = g[1] - g[2]
        g[20] = g[10] - g[11]
        g[30] = g[20] + g[21] - g[22] - g[24]
        g[40] = g[31] - g[32]
        g[50] = g[30] + g[40]
        g[60] = g[50] - g[51]
        return g
    a, b = cot(0), cot(1)
    k = _ky(dl)
    truoc_0 = not any(b[m] for m in b)
    if truoc_0 and nt.get("b02_nay"):
        b = {m: lam_tron(nt["b02_nay"].get(m, 0)) for m in B02_MA}
        cb.append("B02 cột Năm trước: động cơ không có số năm trước (kỳ không bắt đầu tháng 1) - lấy PL_KQHDSXKD cột Năm nay của %s."
                  % nt.get("nguon_bctc", "tờ khai năm trước"))
    out = {m: (a[m], b[m]) for m in B02_MA}
    for m in (10, 20, 30, 40, 50, 60):
        if m in e and e[m] != out[m] and not (truoc_0 and nt.get("b02_nay") and e[m][0] == out[m][0]):
            cb.append("B02 [%02d]: động cơ phần mềm ra %s / %s, cộng theo công thức mẫu ra %s / %s - báo cáo ghi số cộng lại."
                      % (m, _dd(e[m][0]), _dd(e[m][1]), _dd(out[m][0]), _dd(out[m][1])))
    if k["tu"].month != k["dau_ky"] and not truoc_0:
        cb.append("B02 cột Năm trước: kỳ không bắt đầu từ tháng đầu năm tài chính nên động cơ ghi số các tháng trước kỳ của CÙNG năm.")
    return out


def _b03(dl, cb, nt):
    e = _bang_dong_co(dl, "b03")
    if e is None:
        return None
    e = dict(e)
    if any(m in e for m in (26, 27, 36)):          # bang LCTT cong ty tu lap theo ma TT200 -> gop nhu FrmXmlHTKK.XmlHTKK_GopLCTT1
        g = lambda m, i: e.get(m, (0, 0))[i]      # noqa: E731
        e[23] = (g(23, 0) + g(25, 0), g(23, 1) + g(25, 1))
        e[24] = (g(24, 0) + g(26, 0), g(24, 1) + g(26, 1))
        e[25] = (g(27, 0), g(27, 1))
        e[34] = (g(34, 0) + g(35, 0), g(34, 1) + g(35, 1))
        e[35] = (g(36, 0), g(36, 1))
        cb.append("B03: bảng LCTT của sổ theo mã TT200 (có mã 26 / 27 / 36) - đã gộp về mã TT133 (23+25, 24+26, 27 -> 25, 34+35, 36 -> 35).")
    d = {m: e.get(m, (0, 0)) for m in (1, 2, 3, 4, 5, 6, 7, 21, 22, 23, 24, 25, 31, 32, 33, 34, 35, 60, 61)}

    def cot(i):
        g = {m: d[m][i] for m in d}
        g[20] = sum(g[m] for m in range(1, 8))
        g[30] = sum(g[m] for m in range(21, 26))
        g[40] = sum(g[m] for m in range(31, 36))
        g[50] = g[20] + g[30] + g[40]
        g[70] = g[50] + g[60] + g[61]
        return g
    a, b = cot(0), cot(1)
    k = _ky(dl)
    if not any(b.values()):
        if nt.get("b03_nay"):
            b = {m: lam_tron(nt["b03_nay"].get(m, 0)) for m in B03_MA}
            cb.append("B03 cột Năm trước: lấy PL_LCTTTT cột Năm nay của %s (động cơ phần mềm không có số năm trước khi kỳ bắt đầu "
                      "tháng đầu năm)." % nt.get("nguon_lctt", "tờ khai năm trước"))
        else:
            b = {m: 0 for m in B03_MA}
            cb.append("B03 cột Năm trước để 0: không tìm thấy BCTC (B03) năm %d dạng XML HTKK trong thư mục khách / dữ liệu HTKK trên "
                      "máy - anh nhập cột này trên HTKK (hoặc chép tệp XML BCTC năm %d vào thư mục khách rồi xuất lại)."
                      % (k["nam"] - 1, k["nam"] - 1))
    out = {m: (a[m], b[m]) for m in B03_MA}
    for m in (20, 30, 40, 50, 70):
        if m in e and e[m][0] != out[m][0]:
            cb.append("B03 [%02d]: động cơ phần mềm ra %s, cộng theo công thức mẫu ra %s - báo cáo ghi số cộng lại."
                      % (m, _dd(e[m][0]), _dd(out[m][0])))
    return out


# ------------------------------------------------------------------ F01 bang can doi tai khoan
def _f01(dl, cb):
    k = _ky(dl)
    dk, t1, t2 = k["dau_ky"], k["t1"], k["t2"]
    tk = {}
    for r in dl.get("tk") or []:
        try:
            ma = int(_so(r[0]))
        except (TypeError, IndexError):
            continue
        tk[ma] = {"sh": str(r[1] or "").strip(), "con": int(_so(r[2])), "dn0": _so(r[5]), "dc0": _so(r[6]),
                  "id": int(_so(r[7])) if len(r) > 7 else 0}
    if not tk:
        return None
    ps = defaultdict(lambda: [0.0, 0.0, 0.0, 0.0])        # truoc ky No / Co, trong ky No / Co
    for r in dl.get("ps") or []:
        ma, t = int(_so(r[0])), thang_tc(r[1], dk)
        no, co = _so(r[2]) + _so(r[4] if len(r) > 4 else 0), _so(r[3]) + _so(r[5] if len(r) > 5 else 0)
        if t < t1:
            ps[ma][0] += no
            ps[ma][1] += co
        elif t <= t2:
            ps[ma][2] += no
            ps[ma][3] += co
    # cong no theo doi tuong
    kh = defaultdict(lambda: [0.0, 0.0])                   # (tk, kh) -> [du dau ky (No - Co), du cuoi]
    co_dt = set()
    for r in dl.get("kh_dau") or []:
        key = (int(_so(r[0])), int(_so(r[1])))
        v = _so(r[2]) - _so(r[3])
        kh[key][0] += v
        kh[key][1] += v
        co_dt.add(key[0])
    for ten, dau in (("kh_no", 1), ("kh_co", -1)):
        for r in dl.get(ten) or []:
            key, t = (int(_so(r[0])), int(_so(r[1]))), thang_tc(r[2], dk)
            v = dau * _so(r[3])
            co_dt.add(key[0])
            if t < t1:
                kh[key][0] += v
                kh[key][1] += v
            elif t <= t2:
                kh[key][1] += v
    kh_tk = defaultdict(lambda: [0.0, 0.0, 0.0, 0.0])      # tk -> dau No, dau Co, cuoi No, cuoi Co (tach theo doi tuong)
    for (ma, _), (d0, d1) in kh.items():
        x = kh_tk[ma]
        d0, d1 = lam_tron(d0), lam_tron(d1)
        if d0 > 0:
            x[0] += d0
        else:
            x[1] -= d0
        if d1 > 0:
            x[2] += d1
        else:
            x[3] -= d1
    la = {}                                                # so hieu la -> 6 cot
    ngoai, cha_gan, lech_dt = [], [], []
    for ma, t in tk.items():
        if t["con"] != 0 or not t["sh"] or not t["sh"][0].isdigit() or t["sh"].startswith("0"):
            if t["con"] != 0 and ps.get(ma) and any(ps[ma]):
                cb.append("F01: TK %s là TK tổng hợp (có TK con) nhưng có chứng từ ghi thẳng vào - số này KHÔNG vào bảng cân đối, "
                          "anh chuyển về TK chi tiết." % t["sh"])
            continue
        p = ps.get(ma, [0.0, 0.0, 0.0, 0.0])
        dau = t["dn0"] - t["dc0"] + p[0] - p[1]
        cuoi = dau + p[2] - p[3]
        v = [0, 0, lam_tron(p[2]), lam_tron(p[3]), 0, 0]
        if ma in co_dt:
            x = kh_tk.get(ma, [0.0, 0.0, 0.0, 0.0])
            v[0], v[1], v[4], v[5] = lam_tron(x[0]), lam_tron(x[1]), lam_tron(x[2]), lam_tron(x[3])
            if abs((v[0] - v[1]) - lam_tron(dau)) >= 1 or abs((v[4] - v[5]) - lam_tron(cuoi)) >= 1:
                lech_dt.append("TK %s: chi tiết đối tượng đầu kỳ %s / cuối kỳ %s, sổ cái %s / %s" % (
                    t["sh"], _dd(v[0] - v[1]), _dd(v[4] - v[5]), _dd(dau), _dd(cuoi)))
        else:
            dau, cuoi = lam_tron(dau), lam_tron(cuoi)
            v[0], v[1] = (dau, 0) if dau > 0 else (0, -dau)
            v[4], v[5] = (cuoi, 0) if cuoi > 0 else (0, -cuoi)
        hang = [a for a in CDTK_TK if t["sh"].startswith(a)]
        dich = max(hang, key=len) if hang else ""
        if not dich:
            if any(v):
                ngoai.append((t["sh"], v))
            continue
        if dich in CDTK_CON and any(v):
            cha_gan.append(t["sh"] + "->" + dich)
        x = la.setdefault(dich, [0] * 6)
        for i in range(6):
            x[i] += v[i]
    # cong TK cha = TK con (duoi len) + phan gan thang
    gt = {a: list(la.get(a, [0] * 6)) for a in CDTK_TK}
    for a in sorted(CDTK_TK, key=len, reverse=True):
        for c in CDTK_CON.get(a, []):
            for i in range(6):
                gt[a][i] += gt[c][i]
    tong = [sum(gt[a][i] for a in CDTK_CAP1) for i in range(6)]
    for nt_, v in ngoai:
        for i in range(6):
            tong[i] += v[i]
    if ngoai:
        cb.append("F01: TK ngoài danh mục bảng cân đối của HTKK có số (%s) - Excel ghi thêm dòng cuối; XML HTKK không có chỗ ghi."
                  % ", ".join(x[0] for x in ngoai[:10]))
    if cha_gan:
        cb.append("F01: TK chi tiết của sổ không có dòng riêng trên PL_CDTK HTKK, số được cộng vào dòng TK cấp trên (%s) - trên HTKK dòng "
                  "này là dòng tổng, anh xem lại." % ", ".join(cha_gan[:10]))
    if lech_dt:
        cb.append("F01: số dư chi tiết theo đối tượng lệch số dư sổ cái - " + "; ".join(lech_dt[:5]))
    dong = []
    for a, ten in CDTK:
        if a == "#":
            dong.append({"tk": "", "ten": ten, "nhom": True})
        else:
            dong.append(dict(zip(COT_F01, gt[a]), tk=a, ten=ten, cap1=(a in CDTK_CAP1), nhom=False))
    for sh, v in ngoai:
        dong.append(dict(zip(COT_F01, v), tk=sh, ten="(TK ngoài danh mục HTKK)", cap1=True, nhom=False, ngoai=True))
    dong.append(dict(zip(COT_F01, tong), tk="", ten="Tổng cộng", cap1=False, nhom=False, tong=True))
    # TK ket qua (loai 5-9) con so du cuoi ky (chua ket chuyen) - nhu KiemTraKetChuyen
    ton = [a for a in CDTK_CAP1 if a[0] in "56789" and (gt[a][4] or gt[a][5])]
    if ton:
        cb.append("F01: TK loại 5-9 còn số dư cuối kỳ (chưa kết chuyển hết): %s." % ", ".join(
            "%s %s" % (a, _dd(gt[a][4] - gt[a][5])) for a in ton[:10]))
    return dong


def f01_dict(dong):
    """[dong] -> {tk: (dau_no, dau_co, ps_no, ps_co, cuoi_no, cuoi_co)} (chi TK danh muc HTKK) + "tong"."""
    d = {}
    for r in dong or []:
        if r.get("nhom"):
            continue
        k = "tong" if r.get("tong") else r["tk"]
        if r.get("ngoai"):
            continue
        d[k] = tuple(r[c] for c in COT_F01)
    return d


# ------------------------------------------------------------------ to khai nam truoc (XML HTKK chuan / du lieu HTKK tren may)
def _goc_htkk():
    """-> (thu muc goc HTKK tren may, phien ban) hoac ("", "")."""
    try:
        import tool_htkk_unesco as X
        h = X.tim_htkk()
        return (h.get("goc") or "", h.get("phien_ban") or "") if h else ("", "")
    except Exception:
        return "", ""


def _ten(nut):
    return nut.tag.split("}", 1)[-1]


def _khoi(goc, *duong):
    n = goc
    for d in duong:
        m = None
        for c in list(n):
            if _ten(c) == d:
                m = c
                break
        if m is None:
            return None
        n = m
    return n


def _khoi_so(goc, *duong):
    n = _khoi(goc, *duong)
    if n is None:
        return {}
    return {_ten(c): (c.text or "").strip() for c in n if not list(c)}


def _ma_ct(d):
    """{"ct110": "123"} -> {110: 123.0}"""
    out = {}
    for k, v in d.items():
        m = re.match(r"ct(\d+)$", k)
        if m:
            out[int(m.group(1))] = _so(v)
    return out


def _doc_xml_tk(p):
    try:
        with open(p, "rb") as f:
            dau = f.read(6000)
        if b"HSoThueDTu" not in dau and b"H\x00S\x00o\x00T" not in dau:
            return None
        g = ET.parse(p).getroot()
    except Exception:
        return None
    tk = _khoi(g, "HSoKhaiThue", "TTinChung", "TTinTKhaiThue", "TKhaiThue")
    if tk is None:
        return None
    ma = (_khoi_so(tk).get("maTKhai") or "").strip()
    ky = _khoi_so(_khoi(tk, "KyKKhaiThue") if _khoi(tk, "KyKKhaiThue") is not None else tk).get("kyKKhai", "")
    t = _khoi_so(tk)
    return {"ma": ma, "ky": ky.strip(), "goc": g, "duong": p, "so_lan": int(_so(t.get("soLan"))),
            "ngay": t.get("ngayLapTKhai", ""), "mtime": os.path.getmtime(p)}


def _quet_xml(thu_muc, nam, bo_qua="", toi_da=30000):
    """-> {maTKhai: to khai tot nhat (so lan cao nhat, ngay lap moi nhat)} cho ky nam `nam`."""
    kq = {}
    if not thu_muc or not os.path.isdir(thu_muc):
        return kq
    dem = 0
    bo = os.path.normcase(os.path.abspath(bo_qua)) if bo_qua else ""
    for goc, ds_thu_muc, ds_tep in os.walk(thu_muc):
        if bo and os.path.normcase(os.path.abspath(goc)).startswith(bo):
            ds_thu_muc[:] = []
            continue
        ds_thu_muc[:] = [x for x in ds_thu_muc if not x.startswith((".", "__"))]
        for t in ds_tep:
            dem += 1
            if dem > toi_da:
                return kq
            if not t.lower().endswith(".xml"):
                continue
            p = os.path.join(goc, t)
            try:
                if os.path.getsize(p) > 5000000:
                    continue
            except OSError:
                continue
            x = _doc_xml_tk(p)
            if not x or x["ky"] != str(nam) or x["ma"] not in ("683", "892"):
                continue
            cu = kq.get(x["ma"])
            if cu is None or (x["so_lan"], x["ngay"], x["mtime"]) > (cu["so_lan"], cu["ngay"], cu["mtime"]):
                kq[x["ma"]] = x
    return kq


def _doc_cell(p):
    """Tep du lieu HTKK (<Cell Path=... Value=...>) -> {Path: Value}."""
    try:
        with open(p, "rb") as f:
            b = f.read()
        if b[:2] in (b"\xff\xfe", b"\xfe\xff"):
            s = b.decode("utf-16")
        else:
            s = b.decode("utf-8-sig", "replace")
    except Exception:
        return {}
    d = {}
    for m in re.finditer(r"<Cell\s([^>]*?)/?>", s):
        a = dict(re.findall(r'(\w+)="([^"]*)"', m.group(1)))
        if a.get("Path"):
            d.setdefault(a["Path"], a.get("Value", ""))
    return d


def _tep_htkk(goc, mst, tien_to, nam):
    so = re.sub(r"[^0-9-]", "", str(mst or ""))
    for ten in (so, so.split("-")[0]):
        d = os.path.join(goc, "DataFiles", ten)
        if not ten or not os.path.isdir(d):
            continue
        ds = [os.path.join(d, x) for x in os.listdir(d) if x.upper().startswith((tien_to + "_" + str(nam) + "_").upper())
              and x.lower().endswith(".xml")]
        if ds:
            return max(ds, key=os.path.getmtime)
    return ""


def _lo_tu_bang(dong):
    """[{ct2, ct3, ct4, ct5, ct6}] -> [(nam, ct3, ct4, ct5, ct6)]"""
    out = []
    for r in dong:
        nam = int(_so(r.get("ct2")))
        if nam:
            out.append((nam, _so(r.get("ct3")), _so(r.get("ct4")), _so(r.get("ct5")), _so(r.get("ct6"))))
    return out


def nam_truoc(dl, thumuc=""):
    """So lieu to khai nam truoc (nam N-1) - cache trong dl."""
    st = _st(dl)
    if "nam_truoc" in st:
        return st["nam_truoc"]
    k = _ky(dl)
    n1 = k["nam"] - 1
    dn = _dn(dl)
    nt = {"nam": n1, "nguon": []}
    bo_qua = thumuc or (dl.get("x1l") or {}).get("thumuc", "")
    xml = _quet_xml(dn.get("thu_muc_khach", ""), n1, bo_qua=bo_qua)
    try:                                   # GD320: thu muc to khai da chon + TEP BCTC nam truoc nguoi dung chon (ban dieu chinh) - uu tien
        import nguon_ky_truoc as NKT
        tmk = dn.get("thu_muc_khach", "")
        tm2 = NKT.thu_muc_to_khai(tmk) if tmk else ""
        if tm2 and os.path.isdir(tm2):
            for ma2, x2 in _quet_xml(tm2, n1, bo_qua=bo_qua).items():
                cu = xml.get(ma2)
                if cu is None or (x2["so_lan"], x2["ngay"], x2["mtime"]) > (cu["so_lan"], cu["ngay"], cu["mtime"]):
                    xml[ma2] = x2
        p2 = NKT.tep_bctc(tmk, n1) if tmk else ""
        if p2 and p2.lower().endswith(".xml") and os.path.isfile(p2):
            x2 = _doc_xml_tk(p2)
            if x2 and x2["ma"] == "683" and x2["ky"] == str(n1):
                xml["683"] = x2
    except Exception:
        pass
    x = xml.get("683")
    if x:
        g = x["goc"]
        ten = "tệp XML BCTC năm %d (%s)" % (n1, os.path.basename(x["duong"]))
        nt["nguon_bctc"] = nt["nguon_lctt"] = ten
        nt["nguon"].append(ten)
        nt["b01a_cuoi"] = _ma_ct(_khoi_so(g, "HSoKhaiThue", "CTieuTKhaiChinh", "SoCuoiNam"))
        nt["b02_nay"] = _ma_ct(_khoi_so(g, "HSoKhaiThue", "PLuc", "PL_KQHDSXKD", "NamNay"))
        nt["b03_nay"] = _ma_ct(_khoi_so(g, "HSoKhaiThue", "PLuc", "PL_LCTTTT", "NamNay"))
        nt["cdtk_cuoi"] = {b: {kk[2:]: _so(v) for kk, v in _khoi_so(g, "HSoKhaiThue", "PLuc", "PL_CDTK", "SoDuCuoiKy", b).items()}
                           for b in ("No", "Co")}
        t = _khoi_so(g, "HSoKhaiThue", "TTinChung", "TTinTKhaiThue", "TKhaiThue")
        nt["cqt"] = (t.get("maCQTNoiNop", ""), t.get("tenCQTNoiNop", ""))
        nt["nnt"] = _khoi_so(g, "HSoKhaiThue", "TTinChung", "TTinTKhaiThue", "NNT")
    x = xml.get("892")
    if x:
        g = x["goc"]
        ten = "tờ khai 03/TNDN năm %d (%s)" % (n1, os.path.basename(x["duong"]))
        nt["nguon_tndn"] = ten
        nt["nguon"].append(ten)
        c = _khoi_so(g, "HSoKhaiThue", "CTieuTKhaiChinh")
        h = _khoi_so(g, "HSoKhaiThue", "CTieuTKhaiChinh", "Header")
        lo = {}
        p2 = _khoi(g, "HSoKhaiThue", "PLuc", "PLuc_03_2_TNDN")
        for nhom in ("Lo_HDSXKD", "Lo_CNBDS"):
            b = _khoi(p2, nhom, "BangChiTietSoLo") if p2 is not None else None
            lo[nhom] = _lo_tu_bang([_khoi_so(b, "noiDungNamThu%d" % i) for i in range(1, 6)]) if b is not None else []
        nt["tndn"] = {"C1": _so(c.get("ctC1")), "C2": _so(c.get("ctC2")), "B15": _so(c.get("ctB15")), "D2": _so(c.get("ctD2")),
                      "lo": lo, "ct04_ma": h.get("ct04_ma", ""), "ct04_ten": h.get("ct04_ten", ""), "ct05": h.get("ct05", "")}
        t = _khoi_so(g, "HSoKhaiThue", "TTinChung", "TTinTKhaiThue", "TKhaiThue")
        nt.setdefault("cqt", (t.get("maCQTNoiNop", ""), t.get("tenCQTNoiNop", "")))
        nt.setdefault("nnt", _khoi_so(g, "HSoKhaiThue", "TTinChung", "TTinTKhaiThue", "NNT"))
    # (b) du lieu HTKK tren may
    need = ("b03_nay" not in nt) or ("tndn" not in nt) or ("b02_nay" not in nt) or ("b01a_cuoi" not in nt) or ("cdtk_cuoi" not in nt)
    goc = _goc_htkk()[0] if need else ""
    if goc:
        mst = dn.get("mst", "")

        def doc(tien_to):
            p = _tep_htkk(goc, mst, tien_to, n1)
            return (_doc_cell(p), p) if p else ({}, "")
        if "b03_nay" not in nt:
            d, p = doc("133_B01A_03_LCTTTT")
            if d:
                nt["b03_nay"] = {int(m.group(1)): _so(v) for kk, v in d.items() for m in [re.match(r"PL_LCTTTT/NamNay/ct(\d+)$", kk)] if m}
                nt["nguon_lctt"] = "dữ liệu HTKK trên máy (%s)" % os.path.basename(p)
                nt["nguon"].append(nt["nguon_lctt"])
        if "b02_nay" not in nt:
            d, p = doc("133_B01A_02_SXKD")
            if d:
                nt["b02_nay"] = {int(m.group(1)): _so(v) for kk, v in d.items() for m in [re.match(r"PL_KQHDSXKD/NamNay/ct(\d+)$", kk)] if m}
                nt.setdefault("nguon_bctc", "dữ liệu HTKK trên máy (%s)" % os.path.basename(p))
        if "b01a_cuoi" not in nt:
            d, p = doc("133_B01A_01_THTC")
            if d:
                nt["b01a_cuoi"] = {int(m.group(1)): _so(v) for kk, v in d.items() for m in [re.search(r"SoCuoiNam/ct(\d+)$", kk)] if m}
        if "cdtk_cuoi" not in nt:
            d, p = doc("133_B01A_05_CDTK")
            if d:
                nt["cdtk_cuoi"] = {b: {m.group(1): _so(v) for kk, v in d.items() for m in [re.match(r"PL_CDTK/SoDuCuoiKy/%s/ct(\w+)$" % b, kk)] if m}
                                   for b in ("No", "Co")}
        if "tndn" not in nt:
            d2, p2 = doc("03_2_TNDN_TT80")
            d1, p1 = doc("03_TNDN_TT80")
            if d2 or d1:
                lo = {}
                for nhom in ("Lo_HDSXKD", "Lo_CNBDS"):
                    lo[nhom] = _lo_tu_bang([{c: d2.get("PLuc_03_2_TNDN/%s/BangChiTietSoLo/noiDungNamThu%d/%s" % (nhom, i, c), "")
                                              for c in ("ct2", "ct3", "ct4", "ct5", "ct6")} for i in range(1, 6)])
                c0 = "HSoThueDTu/HSoKhaiThue/CTieuTKhaiChinh/"
                nt["tndn"] = {"C1": _so(d1.get(c0 + "ctC1")), "C2": _so(d1.get(c0 + "ctC2")), "B15": _so(d1.get(c0 + "ctB15")),
                              "D2": _so(d1.get(c0 + "ctD2")), "lo": lo, "ct04_ma": d1.get(c0 + "Header/ct04_ma", ""),
                              "ct04_ten": d1.get(c0 + "Header/ct04_ten", ""), "ct05": d1.get(c0 + "Header/ct05", ""),
                              "co_to_khai": bool(d1)}
                nt["nguon_tndn"] = "dữ liệu HTKK trên máy (%s)" % ", ".join(os.path.basename(x) for x in (p2, p1) if x)
                nt["nguon"].append(nt["nguon_tndn"])
    st["nam_truoc"] = nt
    return nt


# ------------------------------------------------------------------ gia tri BCTC (dung chung)
def gia_tri_bctc(dl):
    st = _st(dl)
    if "gt" in st:
        return st["gt"]
    cb = []
    if str((dl.get("bctc") or {}).get("che_do") or "").upper() == "TT99":
        # GD131: so TT99 - VB6 (ModHDDTBaoCaoNam.BCN_B02TT99) da doi B02 TT99 ve chi tieu B02 TT133 ma 03/TNDN dung
        cb.append("Sổ theo TT99/2025: 03/TNDN lấy B02 tính theo TT99, đổi về chỉ tiêu phụ lục 03-1A: [22] doanh thu tài chính, "
                  "[23] / [24] chi phí tài chính / lãi vay, [25] + [26] chi phí bán hàng + quản lý doanh nghiệp, lãi / lỗ bán "
                  "BĐSĐT [21] vào doanh thu / chi phí tài chính, [51] + [52] chi phí thuế TNDN. B01 / B03 TT99 lập ở nút riêng.")
    nt = nam_truoc(dl)
    out = {"B01A": _b01a(dl, cb), "B02": _b02(dl, cb, nt), "B03": _b03(dl, cb, nt), "F01": _f01(dl, cb), "canh_bao": cb,
           "nam_truoc": nt, "loi_dong_co": list((dl.get("bctc") or {}).get("loi") or [])}
    out["kiem_cheo"] = _kiem_cheo(dl, out)
    st["gt"] = out
    return out


def _kiem_cheo(dl, g):
    """Kiem cheo BCTC -> [canh bao]."""
    cb = []
    a, b, c, f = g["B01A"], g["B02"], g["B03"], f01_dict(g["F01"])
    nt = g["nam_truoc"]
    if a:
        for i, ten in ((0, "cuối năm"), (1, "đầu năm")):
            if a[200][i] != a[500][i]:
                cb.append("B01a %s: TỔNG TÀI SẢN [200] %s khác TỔNG NGUỒN VỐN [500] %s (lệch %s)."
                          % (ten, _dd(a[200][i]), _dd(a[500][i]), _dd(a[200][i] - a[500][i])))
        if c:
            if c[70][0] != a[110][0]:
                cb.append("B03 [70] tiền cuối kỳ %s khác B01a [110] cuối năm %s (lệch %s) - thường do chứng từ tiền thiếu TK đối ứng "
                          "hoặc TK 111 / 112 dư Có." % (_dd(c[70][0]), _dd(a[110][0]), _dd(c[70][0] - a[110][0])))
            if c[60][0] != a[110][1]:
                cb.append("B03 [60] tiền đầu kỳ %s khác B01a [110] đầu năm %s." % (_dd(c[60][0]), _dd(a[110][1])))
            try:                                   # GD257: so B03 dong co voi B03 tinh tu chung tu (K58, Kiem tra truoc khoa so ca nam)
                import b03_chung_tu
                import chinh_sach_so
                ds257 = (dl.get("bctc") or {}).get("duong_so") or dl.get("duong_so") or ""
                if ds257:
                    tm257, _ = chinh_sach_so._thu_muc_ra(ds257, tao=False)
                    bc257 = b03_chung_tu.doc_da_luu(tm257, _ky(dl)["nam"])
                    if bc257:
                        lech = ["[%02d] %s / %s" % (m, _dd(c[m][0]), _dd(bc257.get(m, 0))) for m in (1, 2, 3, 4, 5, 6, 7, 21, 22, 23, 24, 25, 31, 32, 33, 34, 35)
                                if lam_tron(c[m][0]) != lam_tron(bc257.get(m, 0))]
                        if lech:
                            cb.append("B03 (động cơ phần mềm) khác B03 tính từ từng chứng từ tiền theo TK đối ứng (K58): %s - xem sheet K58 của Kiểm tra "
                                      "trước khoá sổ để biết cặp TK nào xếp khác." % "; ".join(lech[:10]))
                    else:
                        cb.append("Chưa có B03 tính từ chứng từ của năm %d để so: chạy Kiểm tra trước khoá sổ cho cả năm (K58)." % _ky(dl)["nam"])
            except Exception:
                pass
        if nt.get("b01a_cuoi"):
            lech = ["[%d] %s / %s" % (m, _dd(a[m][1]), _dd(nt["b01a_cuoi"].get(m, 0))) for m in B01A_MA
                    if a[m][1] != lam_tron(nt["b01a_cuoi"].get(m, 0))]
            if lech:
                cb.append("B01a Số đầu năm khác Số cuối năm của %s: %s." % (nt.get("nguon_bctc", "BCTC năm trước"), "; ".join(lech[:8])))
    if b and nt.get("b02_nay"):
        lech = ["[%02d] %s / %s" % (m, _dd(b[m][1]), _dd(nt["b02_nay"].get(m, 0))) for m in B02_MA if b[m][1] != lam_tron(nt["b02_nay"].get(m, 0))]
        if lech:
            cb.append("B02 cột Năm trước khác cột Năm nay của %s: %s." % (nt.get("nguon_bctc", "BCTC năm trước"), "; ".join(lech[:8])))
    if f:
        t = f["tong"]
        for i, ten in ((0, "số dư đầu kỳ"), (2, "số phát sinh"), (4, "số dư cuối kỳ")):
            if t[i] != t[i + 1]:
                cb.append("F01 %s: tổng Nợ %s khác tổng Có %s (lệch %s)." % (ten, _dd(t[i]), _dd(t[i + 1]), _dd(t[i] - t[i + 1])))
        # khop dl["tk"]: so du dau (rong) TK cap 1 cua so = dong HTKK cung so hieu
        k = _ky(dl)
        if k["t1"] <= 1:
            lech = []
            for r in dl.get("tk") or []:
                sh = str(r[1] or "").strip()
                if sh in f and sh in CDTK_CAP1:
                    so = lam_tron(_so(r[5]) - _so(r[6]))
                    ht = f[sh][0] - f[sh][1]
                    if so != ht:
                        lech.append("TK %s sổ %s / bảng %s" % (sh, _dd(so), _dd(ht)))
            if lech:
                cb.append("F01 số dư đầu kỳ (ròng) khác số dư đầu năm khai trong hệ thống tài khoản: %s." % "; ".join(lech[:8]))
        if nt.get("cdtk_cuoi"):
            lech = []
            for tkh in CDTK_TK:
                for i, bn in ((0, "No"), (1, "Co")):
                    v = lam_tron(nt["cdtk_cuoi"][bn].get(tkh, 0))
                    if f[tkh][i] != v:
                        lech.append("%s %s: %s / %s" % (tkh, "Nợ" if i == 0 else "Có", _dd(f[tkh][i]), _dd(v)))
            if lech:
                cb.append("F01 số dư đầu kỳ khác số dư cuối kỳ PL_CDTK của %s: %s." % (nt.get("nguon_bctc", "BCTC năm trước"), "; ".join(lech[:8])))
        # B01a (dong co) so voi cong thuc mau chuan tinh tren bang can doi tai khoan
        if a:
            try:
                import tool_htkk_unesco as X
                for i, (ten, cot) in enumerate((("cuối năm", (4, 5)), ("đầu năm", (0, 1)))):
                    no = {tkh: f[tkh][cot[0]] for tkh in CDTK_TK}
                    co = {tkh: f[tkh][cot[1]] for tkh in CDTK_TK}
                    lech = []
                    for ma, _, ct_ in X.CT_B01A:
                        v = lam_tron(X._tinh_ct(ct_, no, co))
                        if v != a[int(ma)][i]:
                            lech.append("[%s] %s / %s" % (ma, _dd(a[int(ma)][i]), _dd(v)))
                    if lech:
                        cb.append("B01a %s (động cơ phần mềm) khác công thức mẫu chuẩn tính trên bảng cân đối tài khoản: %s." % (ten, "; ".join(lech[:8])))
            except Exception:
                pass
        # B02 ma 60 so voi bien dong 421
        if b and "421" in f:
            bd = (f["421"][5] - f["421"][4]) - (f["421"][1] - f["421"][0])
            if bd != b[60][0]:
                cb.append("B02 [60] lợi nhuận sau thuế %s khác biến động TK 421 trong kỳ %s (lệch %s) - kiểm tra kết chuyển 911 -> 421, "
                          "chia lợi nhuận / điều chỉnh 421 trong năm." % (_dd(b[60][0]), _dd(bd), _dd(b[60][0] - bd)))
    return cb


# ------------------------------------------------------------------ 03/TNDN
def _lo_moi(lo_cu, nam, lo_nam_truoc):
    """Bang 03-2 nam `nam` (5 nam N-5..N-1) tu bang nam truoc (N-6..N-2) + lo nam N-1. -> [[nam, ct3, ct4, con]]"""
    cu = {r[0]: r for r in lo_cu}
    out = []
    for y in range(nam - 5, nam):
        if y == nam - 1:
            out.append([y, lam_tron(lo_nam_truoc), 0, lam_tron(lo_nam_truoc)])
        elif y in cu:
            _, c3, c4, c5, c6 = cu[y]
            out.append([y, lam_tron(c3), lam_tron(c4 + c5), max(0, lam_tron(c6))])
        else:
            out.append([y, 0, 0, 0])
    return out


def _phan_bo(bang, duoc):
    """FIFO nam cu truoc: -> bang [(nam, ct3, ct4, ct5, ct6)], tong ct5."""
    con = max(0, lam_tron(duoc))
    out, tong = [], 0
    for y, c3, c4, avail in bang:
        c5 = min(avail, con)
        con -= c5
        tong += c5
        out.append((y, c3, c4, c5, c3 - c4 - c5))
    return out, tong


def _tam_nop_nam_nay(dl, k, tong, du_co_dau):
    """GD319: tach PS No 3334 / Co 11x trong ky: khoan nop cho NAM TRUOC (dien giai ghi nam < nam quyet toan, vd "Q4.2025",
    "QT TNDN 2025"; khong ghi nam -> tru dan so du Co 3334 dau nam theo ngay) khong phai tam nop nam nay ([G2]).
    -> (g2, so_nam_truoc, [mo ta]). Khong doc duoc so -> tru so du Co dau nam (uoc tinh)."""
    import re
    nam = k["nam"]
    ds = None
    try:
        duong = (dl.get("bctc") or {}).get("duong_so") or dl.get("duong_so") or ""
        if duong and os.path.isfile(duong):
            import jet_doc
            m = jet_doc.Mdb(duong)
            try:
                tk = {r.get("MaSo"): str(r.get("SoHieu") or "").strip() for r in m.doc("HethongTK")}
                ds = []
                for r in m.doc("ChungTu"):
                    if not tk.get(r.get("MaTKNo"), "").startswith("3334") or not tk.get(r.get("MaTKCo"), "").startswith("11"):
                        continue
                    t = thang_tc(int(r.get("ThangCT") or 0) or 1, k["dau_ky"])
                    if not (k["t1"] <= t <= k["t2"]):
                        continue
                    ds.append((r.get("NgayCT") or datetime(nam, 1, 1), float(r.get("SoPS") or 0), str(r.get("DienGiai") or ""), str(r.get("SoHieu") or "")))
            finally:
                try:
                    m.dong()
                except Exception:
                    pass
    except Exception:
        ds = None
    con_no = max(0.0, float(du_co_dau or 0))
    if not ds or abs(sum(x[1] for x in ds) - tong) > 1:
        truoc = min(tong, con_no)
        return max(0, lam_tron(tong - truoc)), lam_tron(truoc), ["ước tính: trừ số dư Có 3334 đầu năm %s" % _dd(con_no)] if truoc else []
    truoc, mo, chua = 0.0, [], []
    for ngay, ps, dg, sh in sorted(ds, key=lambda x: x[0]):
        nams = [int(y) for y in re.findall(r"(?<!\d)(20\d\d)(?!\d)", dg)]
        if nams and max(nams) < nam:
            truoc += ps
            mo.append("%s %s (%s)" % (sh, _dd(ps), "năm %d" % max(nams)))
        elif not nams:
            chua.append((ngay, ps, sh))
    con_no = max(0.0, con_no - truoc)
    for ngay, ps, sh in chua:
        if con_no <= 0:
            break
        x = min(ps, con_no)
        truoc += x
        con_no -= x
        mo.append("%s %s (trừ số dư Có 3334 đầu năm)" % (sh, _dd(x)))
    return max(0, lam_tron(tong - truoc)), lam_tron(truoc), mo


def tinh_tndn(dl):
    """-> dict chi tieu 03/TNDN + PL 03-1A + PL 03-2 + canh bao. None neu nguoi dung bam Huy thue suat / khong co B02."""
    st = _st(dl)
    if "tndn" in st:
        return st["tndn"]
    cb = []
    g = gia_tri_bctc(dl)
    b = g["B02"]
    k = _ky(dl)
    dn = _dn(dl)
    t = dl.get("tndn") or {}
    if b is None:
        raise ValueError(_thieu(dl, "B02 (kết quả kinh doanh)") + " - không lập được 03/TNDN.")
    if t.get("loi"):
        raise ValueError("Phần mềm không lấy được số liệu 03/TNDN: %s" % t["loi"])
    if str(t.get("huy", "0")) in ("1", "True", "true") or (t and str(t.get("thue_suat", "")) == ""):
        st["tndn"] = None
        return None
    ts = int(_so(t.get("thue_suat")) or 20)
    if ts not in (15, 17, 20):
        cb.append("Thuế suất [C7] %s%% không thuộc 15 / 17 / 20%% - dùng 20%%." % ts)
        ts = 20
    if not t:
        cb.append("Phần mềm chưa gửi phần 03/TNDN (thuế suất, tạm nộp) - tạm tính thuế suất 20%, tạm nộp 0.")
    nay = {m: b[m][0] for m in B02_MA}
    # PL 03-1A
    p = {}
    p["04"] = nay[1]
    p["05"] = 0
    p["07"], p["08"], p["09"] = nay[2], 0, 0
    p["06"] = p["07"] + p["08"] + p["09"]
    p["10"] = nay[21]
    p["11"] = min(lam_tron(t.get("lai_tien_gui")), p["10"]) if p["10"] > 0 else 0
    p["13"] = nay[11]
    p["14"] = lam_tron(t.get("cp_ban_hang"))
    p["15"] = nay[24] - p["14"]
    p["12"] = p["13"] + p["14"] + p["15"]
    p["16"], p["17"] = nay[22], nay[23]
    p["18"] = p["04"] - p["06"] + p["10"] - p["12"] - p["16"]
    p["19"], p["20"] = nay[31], nay[32]
    p["21"] = p["19"] - p["20"]
    p["22"] = p["18"] + p["21"]
    if t.get("cp_qldn") is not None and lam_tron(t.get("cp_qldn")) != p["15"]:
        cb.append("PL 03-1A [15] chi phí QLDN = B02[24] - [14] = %s, kết chuyển Nợ 911 / Có 6422 trong kỳ = %s - kiểm tra kết chuyển 642."
                  % (_dd(p["15"]), _dd(t.get("cp_qldn"))))
    if p["07"]:
        cb.append("PL 03-1A [07]: giảm trừ doanh thu %s ghi cả vào Chiết khấu thương mại (phần mềm không tách chiết khấu / giảm giá / "
                  "hàng bán trả lại) - sửa trên HTKK nếu cần." % _dd(p["07"]))
    if p["10"]:
        cb.append("PL 03-1A [11] lãi tiền gửi = PS Có 515 đối ứng Nợ 112 = %s (lãi chênh lệch tỷ giá, cổ tức... không tính) - xem lại."
                  % _dd(p["11"]))
    v = defaultdict(int)
    v["A1"] = nay[50]
    if p["22"] != v["A1"]:
        cb.append("PL 03-1A [22] %s khác B02 [50] %s." % (_dd(p["22"]), _dd(v["A1"])))
    # o nhap tay man hinh QT cu (License) - chi dung khi khac 0, ghi ro nguon.
    # GD121: man hinh FrmQTTNDN danh so theo mau 03/TNDN cu (TT156): B2 tang DT, B3 CP cua DT giam, B4 chi khong duoc tru,
    #   B5 thue nop o nuoc ngoai, B6 tang KHAC; B7 = TONG giam (B8..B11): B8 LN khong thuoc dien chiu thue, B9 giam tru DT da
    #   tinh thue nam truoc, B10 CP cua DT dieu chinh tang, B11 giam KHAC; License.B16 = C2 thu nhap mien thue.
    #   -> TT80: B7 (tang khac) <- B6 cu; B12 (giam khac) <- B8 + B11 cu; B6 (GDLK), B11 (lai vay GDLK) khong co tren man hinh cu.
    nh = dn.get("tndn_nhap") or {}
    dung = []
    for moi, cus in (("B2", ("B2",)), ("B3", ("B3",)), ("B4", ("B4",)), ("B5", ("B5",)), ("B7", ("B6",)), ("B9", ("B9",)),
                     ("B10", ("B10",)), ("B12", ("B8", "B11")), ("C2", ("B16",))):
        x = sum(lam_tron(nh.get(cu)) for cu in cus)
        if x:
            v[moi] = max(0, x)
            nguon = " + ".join(("License." + cu) for cu in cus)
            dung.append("[%s] = %s (ô %s)" % (moi, _dd(x), nguon))
    if lam_tron(nh.get("B8")):
        cb.append("Ô B8 màn hình Quyết toán TNDN cũ (\"lợi nhuận từ hoạt động không thuộc diện chịu thuế\" = %s) đã đưa vào [B12] "
                  "giảm khác - nếu là thu nhập miễn thuế (cổ tức được chia...) thì chuyển sang [C2] trên HTKK." % _dd(lam_tron(nh.get("B8"))))
    if dung:
        cb.append("03/TNDN lấy từ ô nhập tay màn hình Quyết toán TNDN cũ (bảng License): %s - kiểm tra đúng năm %d chưa."
                  % ("; ".join(dung), k["nam"]))
    v["B1"] = sum(v["B%d" % i] for i in range(2, 8))
    v["B8"] = sum(v["B%d" % i] for i in range(9, 13))
    v["B13"] = v["A1"] + v["B1"] - v["B8"]
    v["B14"], v["B15"] = v["B13"], 0
    v["C1"] = v["B14"]
    # chuyen lo (PL 03-2)
    nt = g["nam_truoc"]
    tn = nt.get("tndn")
    lo_nam_truoc = 0
    if tn:
        if tn.get("co_to_khai", True):
            lo_nam_truoc = max(0, lam_tron(tn["C2"] - tn["C1"]))
        bang_sx = _lo_moi(tn["lo"].get("Lo_HDSXKD", []), k["nam"], lo_nam_truoc)
        bang_bds = _lo_moi(tn["lo"].get("Lo_CNBDS", []), k["nam"], 0)
    else:
        bang_sx = _lo_moi([], k["nam"], 0)
        bang_bds = _lo_moi([], k["nam"], 0)
        cb.append("PL 03-2A (chuyển lỗ) để 0: không tìm thấy tờ khai 03/TNDN năm %d (XML HTKK trong thư mục khách hoặc dữ liệu HTKK "
                  "trên máy) - nếu còn lỗ các năm trước chưa chuyển hết, anh khai tay trên HTKK." % (k["nam"] - 1))
    thu = v["C1"] - v["C2"]
    lo_sx, v["C3a"] = _phan_bo(bang_sx, thu if thu > 0 else 0)
    lo_bds, _ = _phan_bo(bang_bds, 0)
    v["C3b"] = 0
    if sum(r[3] for r in bang_bds):
        cb.append("PL 03-2A: còn lỗ chuyển nhượng BĐS được chuyển %s - phần mềm không tự bù trừ vào [C3b], anh xem lại."
                  % _dd(sum(r[3] for r in bang_bds)))
    v["C3"] = 0 if thu <= 0 else v["C3a"] + v["C3b"]
    v["C4"] = 0 if thu <= 0 else v["C1"] - v["C2"] - v["C3"]
    v["C5"] = 0
    v["C6"] = 0 if thu <= 0 else v["C4"] - v["C5"]
    v["C7"] = max(0, v["C6"])
    v["C8"], v["C8a"] = 0, 0
    v["C9"] = lam_tron(v["C7"] * ts / 100.0) + lam_tron(v["C8"] * v["C8a"] / 100.0)
    for x in ("C10", "C11", "C12", "C13", "C14", "C15", "C16"):
        v[x] = 0
    v["C17"] = max(0, v["C9"] - v["C10"] - v["C14"] - v["C15"] - v["C16"])
    v["D1"] = v["B15"]
    for x in ("D2", "D4", "D6", "D7"):
        v[x] = 0
    v["D3"] = 0 if v["D1"] <= 0 else v["D1"] - v["D2"]
    v["D5"] = 0 if v["D1"] <= 0 else v["D3"] - v["D4"]
    v["D8"] = v["D6"] - v["D7"]
    v["E1"] = v["C17"]
    v["E3"] = v["E4"] = v["E5"] = v["E6"] = 0
    v["E2"] = v["E3"] + v["E4"]
    v["E"] = v["E1"] + v["E2"] + v["E5"]
    v["G1"] = 0
    du3334_0 = t.get("du_3334_dau") or [0, 0]
    v["G2"], g2_truoc, g2_mo = _tam_nop_nam_nay(dl, k, lam_tron(t.get("tam_nop")), du3334_0[1] if len(du3334_0) > 1 else 0)     # GD319
    v["G3"] = v["G4"] = v["G5"] = 0
    v["G"] = v["G1"] + v["G2"] + v["G3"] + v["G4"] + v["G5"]
    v["tamnop_sxkd"] = v["G1"] + v["G2"]
    v["tamnop_cnbds"] = v["G3"] + v["G4"] + v["G5"]
    v["H1"] = v["E1"] + v["E5"] - v["G2"]
    v["H2"] = v["E3"] - v["G4"]
    v["H3"] = v["E4"] - v["G5"]
    v["I1"] = v["E1"] + v["E5"] - v["G1"] - v["G2"]
    v["I2"] = v["E2"] - v["G3"] - v["G4"] - v["G5"]
    v["I"] = v["I1"] + v["I2"]
    du3334 = t.get("du_3334_dau") or [0, 0]
    if lam_tron(du3334[0] if len(du3334) > 0 else 0) > 0:
        cb.append("TK 3334 đầu năm dư Nợ %s (thuế TNDN nộp thừa kỳ trước) - [G1] để 0; nếu anh bù trừ vào quyết toán năm nay thì khai "
                  "[G1] trên HTKK." % _dd(du3334[0]))
    if lam_tron(t.get("tam_nop_khac")):
        cb.append("TK 3334 có PS Nợ đối ứng TK khác 11x %s - không tính vào [G2] (chỉ tính Nợ 3334 / Có 111, 112)." % _dd(t.get("tam_nop_khac")))
    if g2_truoc:
        cb.append("[G2] tạm nộp năm %d = %s: PS Nợ 3334 / Có 11x trong kỳ %s trừ %s nộp cho năm trước - %s." % (
            k["nam"], _dd(v["G2"]), _dd(t.get("tam_nop")), _dd(g2_truoc), "; ".join(g2_mo[:6])))
    cb.append("[G2] tạm nộp = PS Nợ 3334 / Có 11x trong kỳ của năm %d (%s). Số nộp cho năm %d sau ngày 31/12 (đến hạn nộp quyết toán) anh cộng "
              "thêm trên HTKK." % (k["nam"], _dd(v["G2"]), k["nam"]))
    if thu < 0:
        cb.append("Năm %d lỗ %s - chuyển sang PL 03-2A các năm sau." % (k["nam"], _dd(-thu)))
    # nganh nghe [04] / ty le [05]
    ma_ng = (dn.get("ma_nganh") or "").strip()
    ten_ng = (dn.get("ten_nganh") or "").strip()
    ct05 = ""
    if not ma_ng and tn and tn.get("ct04_ma"):
        ma_ng, ten_ng, ct05 = tn["ct04_ma"], tn.get("ct04_ten", ""), tn.get("ct05", "")
        cb.append("[04] ngành nghề lấy theo tờ khai năm trước: %s." % (ten_ng or ma_ng))
    elif ma_ng and ten_ng and not ten_ng.startswith(ma_ng):
        ten_ng = "%s - %s" % (ma_ng, ten_ng)
    if not ma_ng:
        cb.append("[04] ngành nghề có tỷ lệ doanh thu cao nhất: chưa có trong phần mềm - anh chọn trên HTKK.")
    tl = str(dn.get("ty_le_nganh") or "").strip().replace(",", ".")     # GD150: [05] anh chi nhap o Xuat XML HTKK
    try:
        if tl and 0 < float(tl) <= 100:
            ct05 = tl
    except ValueError:
        pass
    ct05 = ct05 or "100.00"
    n1052 = 0 if ma_ng.upper() in ("B06", "S92001", "R9201") else 1
    nv = {"CtE1/soKK": v["E1"], "CtE1/tieuMuc1052": v["E1"] * n1052, "CtE1/tieuMuc1056": v["E1"] * (1 if ma_ng.upper() == "B06" else 0),
          "CtE1/tieuMuc1057": v["E1"] * (1 if ma_ng.upper() == "S92001" else 0), "CtE1/tieuMuc1099": 0,
          "CtE2/soKK": v["E2"], "CtE2/tieuMuc1053": v["E2"], "CtE5/soKK": v["E5"], "CtE5/tieuMuc1052": v["E5"],
          "CtE5/tieuMuc1056": 0, "CtE5/tieuMuc1057": 0, "CtE5/tieuMuc1099": 0}
    nv["tong1052"] = nv["CtE1/tieuMuc1052"] + nv["CtE5/tieuMuc1052"]
    nv["tong1056"] = nv["CtE1/tieuMuc1056"] + nv["CtE5/tieuMuc1056"]
    nv["tong1057"] = nv["CtE1/tieuMuc1057"] + nv["CtE5/tieuMuc1057"]
    nv["tong1053"] = nv["CtE2/tieuMuc1053"]
    # kiem cheo
    if v["A1"] != b[50][0]:
        cb.append("03/TNDN [A1] %s khác B02 [50] %s." % (_dd(v["A1"]), _dd(b[50][0])))
    if p["22"] != v["A1"]:
        cb.append("PL 03-1A [22] %s khác [A1] %s." % (_dd(p["22"]), _dd(v["A1"])))
    kq = {"ct": dict(v), "pl": p, "lo_sx": lo_sx, "lo_bds": lo_bds, "ts": ts, "nv": nv, "ma_nganh": ma_ng, "ten_nganh": ten_ng,
          "ct05": ct05, "canh_bao": cb, "nguon_lo": (nt.get("nguon_tndn") if tn else "")}
    st["tndn"] = kq
    return kq


# ------------------------------------------------------------------ XML HTKK
def _e(cha, ten, gt=None):
    n = ET.SubElement(cha, "{%s}%s" % (NS, ten))
    if gt is not None:
        n.text = str(gt)
    return n


def _iso(d):
    return d.strftime("%Y-%m-%d")


def _dau_htkk(dl):
    st = _st(dl)
    if "dau_htkk" in st:
        return st["dau_htkk"]
    hd, pb = {}, ""
    goc, pb = _goc_htkk()
    if goc:
        try:
            import tool_htkk_unesco as X
            hd = X.dau_may(goc, _dn(dl).get("mst", ""))
        except Exception:
            hd = {}
    st["dau_htkk"] = (hd, pb)
    return st["dau_htkk"]


def _ttin_chung(dl, goc_hs, ma_tk, ten_tk, mo_ta, pban, cb, nhan, dly=True):
    k = _ky(dl)
    dn = _dn(dl)
    nk = _nguoi_ky(dl)
    hd, pb = _dau_htkk(dl)
    nt = nam_truoc(dl)
    try:
        import tool_htkk_unesco as X
        ttin = X.TTIN_NHA_CCAP
    except Exception:
        ttin = ""
    tc = _e(goc_hs, "TTinChung")
    dv = _e(tc, "TTinDVu")
    _e(dv, "maDVu", "HTKK")
    _e(dv, "tenDVu", "HỖ TRỢ KÊ KHAI THUẾ")
    _e(dv, "pbanDVu", pb or "5.7.6")
    _e(dv, "ttinNhaCCapDVu", ttin)
    tt = _e(tc, "TTinTKhaiThue")
    tk = _e(tt, "TKhaiThue")
    _e(tk, "maTKhai", ma_tk)
    _e(tk, "tenTKhai", ten_tk)
    _e(tk, "moTaBMau", mo_ta)
    _e(tk, "pbanTKhaiXML", pban)
    _e(tk, "loaiTKhai", "C")
    _e(tk, "soLan", "0")
    ky = _e(tk, "KyKKhaiThue")
    _e(ky, "kieuKy", "Y")
    _e(ky, "kyKKhai", str(k["nam"]))
    _e(ky, "kyKKhaiTuNgay", k["tu"].strftime("%d/%m/%Y"))
    _e(ky, "kyKKhaiDenNgay", k["den"].strftime("%d/%m/%Y"))
    _e(ky, "kyKKhaiTuThang", "")
    _e(ky, "kyKKhaiDenThang", "")
    ma_cqt, ten_cqt, ng = hd.get("maCQTNoiNop", ""), hd.get("tenCQTNoiNop", ""), "HEADER.xml của HTKK"
    if not ma_cqt:
        ma_cqt, ten_cqt, ng = dn.get("ma_cqt", ""), dn.get("ten_cqt", ""), "khai báo trong phần mềm"
    if not ma_cqt and nt.get("cqt") and nt["cqt"][0]:
        ma_cqt, ten_cqt, ng = nt["cqt"][0], nt["cqt"][1], "tờ khai năm trước"
    if not ma_cqt:
        cb.append("XML %s: THIẾU mã cơ quan thuế nơi nộp (maCQTNoiNop) - anh chọn lại trên HTKK trước khi nộp." % nhan)
    elif ng != "HEADER.xml của HTKK":
        cb.append("XML %s: mã CQT %s %s lấy theo %s - kiểm tra lại." % (nhan, ma_cqt, ten_cqt, ng))
    _e(tk, "maCQTNoiNop", ma_cqt)
    _e(tk, "tenCQTNoiNop", ten_cqt)
    _e(tk, "ngayLapTKhai", _iso(k["lap"]))
    gh = _e(tk, "GiaHan")
    _e(gh, "maLyDoGiaHan", "")
    _e(gh, "lyDoGiaHan", "")
    _e(tk, "nguoiKy", nk.get("nguoi_ky") or nk.get("giam_doc") or hd.get("nguoiKy", ""))
    _e(tk, "ngayKy", _iso(k["lap"]))
    _e(tk, "nganhNgheKD", hd.get("nganhNgheKD", ""))
    nnt = _e(tt, "NNT")
    _e(nnt, "mst", re.sub(r"[^0-9-]", "", str(dn.get("mst") or hd.get("mst") or "")))
    _e(nnt, "tenNNT", dn.get("ten") or hd.get("tenNNT", ""))
    _e(nnt, "dchiNNT", dn.get("dia_chi") or hd.get("dchiNNT", ""))
    _e(nnt, "phuongXa", hd.get("tenXaPhuongNNT", ""))
    _e(nnt, "maHuyenNNT", "")
    _e(nnt, "tenHuyenNNT", "")
    nn = nt.get("nnt") or {}
    _e(nnt, "maTinhNNT", hd.get("maTinhNNT") or nn.get("maTinhNNT", ""))
    _e(nnt, "tenTinhNNT", hd.get("tenTinhNNT") or dn.get("tinh") or nn.get("tenTinhNNT", ""))
    _e(nnt, "dthoaiNNT", dn.get("dien_thoai") or hd.get("dthoaiNNT", ""))
    _e(nnt, "faxNNT", dn.get("fax") or hd.get("faxNNT", ""))
    _e(nnt, "emailNNT", dn.get("email") or hd.get("emailNNT", ""))
    mdl = re.sub(r"[^0-9-]", "", str(hd.get("mstDLyThue") or ""))
    if dly and str(hd.get("ThongTinDaiLy")).lower() == "true" and re.fullmatch(r"\d{10}(-\d{3})?|\d{12}", mdl or ""):
        d = _e(tt, "DLyThue")
        for the in ("mstDLyThue", "tenDLyThue", "dchiDLyThue", "maHuyenDLyThue", "tenHuyenDLyThue", "maTinhDLyThue", "tenTinhDLyThue",
                    "dthoaiDLyThue", "faxDLyThue", "emailDLyThue", "soHDongDLyThue", "ngayKyHDDLyThue"):
            _e(d, the, mdl if the == "mstDLyThue" else ("" if the == "ngayKyHDDLyThue" else hd.get(the, "")))
        nv = _e(d, "NVienDLy")
        _e(nv, "tenNVienDLyThue", hd.get("tenNVienDLyThue", ""))
        _e(nv, "cchiHNghe", hd.get("cchiHNghe", ""))
    return tc


def _ghi_xml(goc, duong):
    try:
        ET.register_namespace("", NS)
        ET.register_namespace("xsi", NS_XSI)
    except Exception:
        pass
    goc.set("xmlns:xsi", NS_XSI)
    try:
        ET.indent(goc, space="  ")
    except Exception:
        pass
    txt = ET.tostring(goc, encoding="unicode")
    tam = duong + ".tmp"
    with io.open(tam, "w", encoding="utf-8-sig", newline="\r\n") as f:
        f.write('<?xml version="1.0" encoding="UTF-8"?>\n' + txt + "\n")
    os.replace(tam, duong)
    return duong


def _khoi_ct(cha, ten, ds, gia):
    n = _e(cha, ten)
    for m in ds:
        _e(n, "ct%s" % m, "" if gia is None else str(lam_tron(gia.get(m, 0))))
    return n


def lap_xml_bctc(dl, thumuc, cb):
    """133_B01A_DNN_BCTC (683, 2.3.2): B01a + PL_KQHDSXKD + PL_LCTTTT + PL_CDTK. Lap MOT lan (nho trong dl)."""
    st = _st(dl)
    if st.get("xml_bctc"):
        return st["xml_bctc"]
    g = gia_tri_bctc(dl)
    k = _ky(dl)
    nk = _nguoi_ky(dl)
    if g["B01A"] is None:
        raise ValueError(_thieu(dl, "B01a") + " - không lập được XML BCTC.")
    goc = ET.Element("{%s}HSoThueDTu" % NS)
    hs = _e(goc, "HSoKhaiThue")
    _ttin_chung(dl, hs, "683", "Bộ báo cáo tài chính (B01a - DNN)(TT133/2016/TT-BTC)",
                "(Ban hành theo Thông tư số 133/2016/TT-BTC ngày 26/8/2016 của Bộ Tài chính)", "2.3.2", cb, "BCTC")
    ct = _e(hs, "CTieuTKhaiChinh")
    _e(ct, "bctcDaKiemToan", "0")
    _e(ct, "maYKienKToan", "0")
    _e(ct, "tenYKienKToan", "")
    a = g["B01A"]
    _khoi_ct(ct, "ThuyetMinh", B01A_MA, None)
    _khoi_ct(ct, "SoCuoiNam", B01A_MA, {m: a[m][0] for m in B01A_MA})
    _khoi_ct(ct, "SoDauNam", B01A_MA, {m: a[m][1] for m in B01A_MA})
    _e(ct, "nguoiLapBieu", nk.get("nguoi_lap", ""))
    _e(ct, "keToanTruong", nk.get("ke_toan_truong", ""))
    _e(ct, "ngayLap", _iso(k["lap"]))
    _e(ct, "nguoiDaiDienTheoPhapLuat", nk.get("giam_doc", ""))
    pl = _e(hs, "PLuc")
    b = g["B02"]
    if b is not None:
        n = _e(pl, "PL_KQHDSXKD")
        ms = ["%02d" % m for m in B02_MA]
        _khoi_ct(n, "ThuyetMinh", ms, None)
        _khoi_ct(n, "NamNay", ms, {"%02d" % m: b[m][0] for m in B02_MA})
        _khoi_ct(n, "NamTruoc", ms, {"%02d" % m: b[m][1] for m in B02_MA})
    else:
        cb.append("XML BCTC: không có số B02 từ phần mềm - bỏ phụ lục PL_KQHDSXKD.")
    c = g["B03"]
    if c is not None:
        n = _e(pl, "PL_LCTTTT")
        ms = ["%02d" % m for m in B03_MA]
        _khoi_ct(n, "ThuyetMinh", ms, None)
        _khoi_ct(n, "NamNay", ms, {"%02d" % m: c[m][0] for m in B03_MA})
        _khoi_ct(n, "NamTruoc", ms, {"%02d" % m: c[m][1] for m in B03_MA})
    else:
        cb.append("XML BCTC: không có số B03 từ phần mềm - bỏ phụ lục PL_LCTTTT.")
    f = f01_dict(g["F01"])
    if f:
        n = _e(pl, "PL_CDTK")
        for khoi, (i_no, i_co) in (("SoDuDauKy", (0, 1)), ("SoPhatSinhTrongKy", (2, 3)), ("SoDuCuoiKy", (4, 5))):
            kk = _e(n, khoi)
            for ben, i in (("No", i_no), ("Co", i_co)):
                bb = _e(kk, ben)
                for tkh in CDTK_TK:
                    _e(bb, "ct" + tkh, str(lam_tron(f[tkh][i])))
                _e(bb, "tongCong", str(lam_tron(sum(f[tkh][i] for tkh in CDTK_CAP1))))
    p = os.path.join(thumuc, "133_B01A_DNN_BCTC_%d.xml" % k["nam"])
    _ghi_xml(goc, p)
    # tu kiem bang bo rang buoc B01a cua tool (46 rang buoc) - loi so hoc bao ngay
    try:
        import tool_htkk_unesco as X
        chan, canh, _chu = X.kiem_tra_b01a(ET.parse(p).getroot())
        da_bao = ("phai bang TONG NGUON VON", "phai bang [110]", "tien dau ky phai bang", "tong ben No phai bang tong ben Co")
        for x in [x for x in chan if not any(d in x for d in da_bao)][:8]:
            cb.append("Tự kiểm XML BCTC: " + x.replace("\n", " "))
    except Exception:
        pass
    _kiem_xsd(p, "133_B01A_DNN_BCTC", cb)             # GD328: XSD cua HTKK tren may
    st["xml_bctc"] = p
    return p


def lap_xml_tndn(dl, thumuc, cb):
    q = tinh_tndn(dl)
    if q is None:
        return ""
    k = _ky(dl)
    v, p, nv = q["ct"], q["pl"], q["nv"]
    goc = ET.Element("{%s}HSoThueDTu" % NS)
    hs = _e(goc, "HSoKhaiThue")
    hs.set("id", "ID_1")
    _ttin_chung(dl, hs, "892", "TỜ KHAI QUYẾT TOÁN THUẾ THU NHẬP DOANH NGHIỆP (Mẫu số 03/TNDN)",
                "(Ban hành kèm theo Thông tư số 80/2021/TT-BTC ngày 29 tháng 9 năm 2021 của Bộ trưởng Bộ Tài chính)", "2.9.4", cb, "03/TNDN")
    ct = _e(hs, "CTieuTKhaiChinh")
    h = _e(ct, "Header")
    _e(h, "kyTaiChinh_Tu", k["tu"].strftime("%d/%m"))
    _e(h, "kyTaiChinh_Den", k["den"].strftime("%d/%m"))
    _e(h, "ma_THQuyetToan", "01")
    _e(h, "ten_THQuyetToan", "QT định kỳ")
    _e(h, "ct04_ma", q["ma_nganh"])
    _e(h, "ct04_ten", q["ten_nganh"])
    _e(h, "ct05", "%.2f" % _so(q["ct05"]))
    for the in TNDN_THE:
        if the == "@dsThMienThue":
            ds = _e(ct, "dsThMienThue")
            m = _e(ds, "thMienThue")
            m.set("id", "ID_1")
            _e(m, "ma_loaiMien", "")
            _e(m, "ten_loaiMien", "")
            _e(m, "ctC2_soThuNhap", str(v["C2"]))
        elif the == "@C7":
            _e(ct, "ctC7_thuNhap", str(v["C7"]))
            _e(ct, "ctC7_tenThueSuat", "+ Thu nhập tính thuế áp dụng thuế suất %d%%" % q["ts"])
            _e(ct, "ctC7_thueSuat", str(q["ts"]))
        elif the == "@tamnop_sxkd":
            _e(ct, "thueTNDN_tamnop_sxkd", str(v["tamnop_sxkd"]))
        elif the == "@tamnop_cnbds":
            _e(ct, "thueTNDN_tamnop_cnbds", str(v["tamnop_cnbds"]))
        elif the == "C8a":
            _e(ct, "ctC8a", str(v["C8a"]))
        else:
            _e(ct, "ct" + the, str(v[the]))
    n = _e(ct, "NghiaVuThue")
    for nhom, ds in (("CtE1", ("soKK", "tieuMuc1052", "tieuMuc1056", "tieuMuc1057", "tieuMuc1099")), ("CtE2", ("soKK", "tieuMuc1053")),
                     ("CtE5", ("soKK", "tieuMuc1052", "tieuMuc1056", "tieuMuc1057", "tieuMuc1099"))):
        x = _e(n, nhom)
        for c in ds:
            _e(x, c, str(nv["%s/%s" % (nhom, c)]))
    for c in ("tong1052", "tong1056", "tong1057", "tong1053"):
        _e(n, c, str(nv[c]))
    pl = _e(hs, "PLuc")
    a = _e(pl, "PLuc_03_1A_TNDN")
    for m in ["%02d" % i for i in range(4, 23)]:
        _e(a, "ct" + m, str(p[m]))
    p2 = _e(pl, "PLuc_03_2_TNDN")
    for nhom, bang in (("Lo_HDSXKD", q["lo_sx"]), ("Lo_CNBDS", q["lo_bds"])):
        x = _e(p2, nhom)
        bt = _e(x, "BangChiTietSoLo")
        for i, (y, c3, c4, c5, c6) in enumerate(bang, start=1):
            r = _e(bt, "noiDungNamThu%d" % i)
            for c, gt in (("ct2", y), ("ct3", c3), ("ct4", c4), ("ct5", c5), ("ct6", c6)):
                _e(r, c, str(gt))
        _e(x, "tongCong", str(sum(r[3] for r in bang)))
    pth = os.path.join(thumuc, "03_TNDN_TT80_%d.xml" % k["nam"])
    _ghi_xml(goc, pth)
    try:
        import kiem_03tndn as K3
        _ma, _R, lech, _cb = K3.kiem(pth)
        for m, ten, x, y in lech[:8]:
            cb.append("Tự kiểm 03/TNDN: %s (%s / %s)." % (ten, _dd(x), _dd(y)))
    except Exception:
        pass
    _kiem_xsd(pth, "03_TNDN_TT80", cb)                # GD328: XSD cua HTKK tren may
    return pth


def _kiem_xsd(p, ma_file, cb):
    """GD328: kiem XML theo XSD cua chinh HTKK cai tren may; sai -> canh bao (tep van giu de nguoi dung xem)."""
    try:
        import tool_htkk_unesco as X
        cach, loi = X.kiem_xsd_htkk(p, ma_file)
        if cach == "xsd" and loi:
            cb.append("XML %s CHƯA HỢP LỆ theo lược đồ XSD của HTKK (HTKK sẽ từ chối khi nhập): %s"
                      % (os.path.basename(p), "; ".join(loi[:4])))
    except Exception:
        pass


# ------------------------------------------------------------------ Excel (bo cuc ban in HTKK)
def _thieu(dl, ten):
    loi = (dl.get("bctc") or {}).get("loi") or []
    return "Phần mềm chưa gửi số liệu %s (động cơ báo cáo)%s" % (ten, (": " + "; ".join(str(x) for x in loi)) if loi else "")


def _tieu_de_dn(ws, wb, r, dl, so_cot, day_du=True, ma=("[01]", "[02]")):
    dn = _dn(dl)
    k_t = wb.kieu(can="trai", xuong=False)
    ws.gop(r, 1, r, so_cot, "%s Tên người nộp thuế: %s" % (ma[0], dn.get("ten", "")), wb.kieu(dam=True, can="trai"))
    ws.gop(r + 1, 1, r + 1, so_cot, "%s Mã số thuế: %s" % (ma[1], dn.get("mst", "")), wb.kieu(dam=True, can="trai"))
    if not day_du:
        return r + 2
    ws.o(r + 2, 1, "[03] Địa chỉ: %s" % dn.get("dia_chi", ""), wb.kieu(can="trai", xuong=True))
    ws.gop(r + 2, 2, r + 2, 3, "[04] Quận/Huyện: %s" % dn.get("quan", ""), wb.kieu(can="trai", xuong=True))
    ws.gop(r + 2, 4, r + 2, so_cot, "[05] Tỉnh/Thành phố: %s" % dn.get("tinh", ""), wb.kieu(can="trai", xuong=True))
    ws.cao(r + 2, 30)
    ws.o(r + 3, 1, "[06] Điện thoại: %s" % dn.get("dien_thoai", ""), k_t)
    ws.gop(r + 3, 2, r + 3, 3, "[07] Fax: %s" % dn.get("fax", ""), k_t)
    ws.gop(r + 3, 4, r + 3, so_cot, "[08] E-mail: %s" % dn.get("email", ""), k_t)
    return r + 4


def _dau_mau(ws, wb, so_cot, mau, ban_hanh, phu_luc=False, tieu=(), cot_trai=None):
    """Khoi dau trang: quoc hieu (trai) + mau so (phai) + ten bao cao."""
    c_mau = so_cot - 1 if cot_trai is None else cot_trai + 1
    k_qh = wb.kieu(dam=True, can="giua")
    k_mau = wb.kieu(dam=True, can="giua")
    k_bh = wb.kieu(nghieng=True, can="giua", xuong=True, co=9)
    trai = c_mau - 1
    if phu_luc:
        ws.gop(1, 1, 1, trai, "PHỤ LỤC", k_qh)
    else:
        ws.gop(1, 1, 1, trai, "CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM", k_qh)
        ws.gop(2, 1, 2, trai, "Độc lập - Tự do - Hạnh phúc", wb.kieu(dam=True, can="giua"))
        ws.gop(3, 1, 3, trai, "-------------------------", wb.kieu(can="giua"))
    ws.gop(1, c_mau, 1, so_cot, "Mẫu số: %s" % mau, k_mau)
    ws.gop(2, c_mau, 3, so_cot, ban_hanh, k_bh)
    ws.cao(2, 16)
    ws.cao(3, 30)
    r = 5
    for i, (txt, co, dam) in enumerate(tieu):
        ws.gop(r, 1, r, so_cot, txt, wb.kieu(dam=dam, co=co, can="giua", nghieng=(co == 10 and not dam)))
        r += 1
    return r + 1


def _ky_ten(ws, wb, r, dl, so_cot, ghi_chu=()):
    k = _ky(dl)
    nk = _nguoi_ky(dl)
    lap = k["lap"]
    a = max(1, so_cot // 3)
    b = a + max(1, (so_cot - a) // 2)
    khoi = ((1, a), (a + 1, b), (b + 1, so_cot))          # 5 cot: A | B-C | D-E ; 8 cot: A-B | C-E | F-H
    ws.gop(r, khoi[2][0], r, khoi[2][1], "Lập ngày %02d tháng %02d năm %d" % (lap.day, lap.month, lap.year), wb.kieu(nghieng=True, can="giua"))
    r += 1
    kd = wb.kieu(dam=True, can="giua", xuong=True, co=10)
    kn = wb.kieu(nghieng=True, can="giua", co=9, xuong=True)
    kt = wb.kieu(dam=True, can="giua")
    for (c1, c2), td, gc, ten in zip(khoi, ("NGƯỜI LẬP BIỂU", "KẾ TOÁN TRƯỞNG", "NGƯỜI ĐẠI DIỆN THEO PHÁP LUẬT"),
                                     ("(Ký, ghi rõ họ tên)", "(Ký, ghi rõ họ tên)", "(Ký, ghi rõ họ tên, đóng dấu)"),
                                     (nk.get("nguoi_lap", ""), nk.get("ke_toan_truong", ""), nk.get("giam_doc", ""))):
        ws.gop(r, c1, r, c2, td, kd)
        ws.gop(r + 1, c1, r + 1, c2, gc, kn)
        ws.gop(r + 5, c1, r + 5, c2, ten, kt)
    r += 7
    ds = list(ghi_chu)
    if nk.get("chung_chi") or nk.get("don_vi_dv"):
        ds.append("Số chứng chỉ hành nghề: %s   Đơn vị cung cấp dịch vụ kế toán: %s" % (nk.get("chung_chi", ""), nk.get("don_vi_dv", "")))
    for x in ds:
        ws.gop(r, 1, r, so_cot, x, wb.kieu(nghieng=True, can="trai", xuong=True, co=9))
        ws.cao(r, 26)
        r += 1
    return r


def _bang_so(ws, wb, r, dau_cot, dong, gia, cot_so=2, co_tm=True):
    """Bang chi tieu | ma | thuyet minh | so ... ; dong: (ten, ma, kieu) ; gia: {ma: (a, b)}."""
    kh = wb.kieu(dam=True, can="giua", khung=True, xuong=True, nen="F2F2F2")
    kh2 = wb.kieu(nghieng=True, can="giua", khung=True)
    for i, t in enumerate(dau_cot, start=1):
        ws.o(r, i, t, kh)
        ws.o(r + 1, i, str(i), kh2)
    ws.cao(r, 30)
    r += 2
    k_ten = {"": wb.kieu(khung=True, xuong=True, can="trai"), "d": wb.kieu(dam=True, khung=True, xuong=True, can="trai"),
             "t": wb.kieu(dam=True, khung=True, xuong=True, can="giua"), "td": wb.kieu(dam=True, khung=True, can="giua"),
             "tl": wb.kieu(dam=True, khung=True, can="trai"),
             "n": wb.kieu(nghieng=True, khung=True, xuong=True, can="trai")}
    k_ma = wb.kieu(khung=True, can="giua")
    k_ma_d = wb.kieu(khung=True, can="giua", dam=True)
    k_so = wb.kieu(khung=True, so=SO_FMT, can="phai")
    k_so_d = wb.kieu(khung=True, so=SO_FMT, can="phai", dam=True)
    for ten, ma, kieu in dong:
        dam = kieu in ("d", "t")
        ws.o(r, 1, ten, k_ten.get(kieu, k_ten[""]))
        ws.o(r, 2, ("%02d" % ma if ma < 100 else str(ma)) if ma else "", k_ma_d if dam else k_ma)
        c = 3
        if co_tm:
            ws.o(r, 3, "", k_ma)
            c = 4
        for j in range(cot_so):
            ws.o(r, c + j, (gia.get(ma, (0,) * cot_so)[j]) if ma else None, k_so_d if dam else k_so)
        r += 1
    return r


def _wb():
    from xlsx_viet import SoExcel
    return SoExcel(font="Times New Roman", co=11)


def excel_b01a(dl, thumuc):
    g = gia_tri_bctc(dl)
    a = g["B01A"]
    if a is None:
        raise ValueError(_thieu(dl, "B01a"))
    k = _ky(dl)
    wb = _wb()
    ws = wb.sheet("B01a-DNN", cot=[56, 8, 10, 19, 19])
    r = _dau_mau(ws, wb, 5, "B01a - DNN", "(Ban hành theo Thông tư số 133/2016/TT-BTC ngày 26/8/2016 của Bộ Tài chính)",
                 tieu=(("BÁO CÁO TÌNH HÌNH TÀI CHÍNH", 14, True),
                       ("Tại ngày %d tháng %d năm %d" % (k["den"].day, k["den"].month, k["den"].year), 11, False),
                       ("(Áp dụng cho doanh nghiệp đáp ứng giả định hoạt động liên tục)", 10, False)), cot_trai=3)
    r = _tieu_de_dn(ws, wb, r, dl, 5)
    ws.gop(r, 1, r, 5, "BCTC đã được kiểm toán: [ ]        Ý kiến kiểm toán:", wb.kieu(can="trai"))
    ws.gop(r + 1, 4, r + 1, 5, "Đơn vị tiền: đồng Việt Nam", wb.kieu(nghieng=True, can="phai"))
    r += 2
    dau = k["tu"].month == k["dau_ky"]
    r = _bang_so(ws, wb, r, ("CHỈ TIÊU", "Mã số", "Thuyết minh", "Số cuối năm", "Số đầu năm" if dau else "Số đầu kỳ"), B01A_DONG, a)
    ws.in_trang(ngang=False, lap_dong=None)
    _ky_ten(ws, wb, r + 1, dl, 5)
    p = os.path.join(thumuc, "B01a_DNN_%d.xlsx" % k["nam"])
    wb.luu(p)
    return p


def excel_b02(dl, thumuc):
    g = gia_tri_bctc(dl)
    b = g["B02"]
    if b is None:
        raise ValueError(_thieu(dl, "B02"))
    k = _ky(dl)
    wb = _wb()
    ws = wb.sheet("B02-DNN", cot=[58, 8, 10, 19, 19])
    r = _dau_mau(ws, wb, 5, "B02 - DNN", "(Ban hành theo Thông tư số 133/2016/TT-BTC ngày 26/8/2016 của Bộ Tài chính)", phu_luc=True,
                 tieu=(("BÁO CÁO KẾT QUẢ HOẠT ĐỘNG KINH DOANH", 14, True), ("Năm %d" % k["nam"], 11, True)), cot_trai=3)
    r = _tieu_de_dn(ws, wb, r, dl, 5, day_du=False, ma=("[02]", "[03]"))
    ws.gop(r, 4, r, 5, "Đơn vị tiền: đồng Việt Nam", wb.kieu(nghieng=True, can="phai"))
    r += 1
    r = _bang_so(ws, wb, r, ("CHỈ TIÊU", "Mã số", "Thuyết minh", "Năm nay", "Năm trước"), B02_DONG, b)
    ws.in_trang(ngang=False)
    _ky_ten(ws, wb, r + 1, dl, 5)
    p = os.path.join(thumuc, "B02_DNN_%d.xlsx" % k["nam"])
    wb.luu(p)
    return p


def excel_b03(dl, thumuc):
    g = gia_tri_bctc(dl)
    c = g["B03"]
    if c is None:
        raise ValueError(_thieu(dl, "B03"))
    k = _ky(dl)
    wb = _wb()
    ws = wb.sheet("B03-DNN", cot=[58, 8, 10, 19, 19])
    r = _dau_mau(ws, wb, 5, "B03 - DNN", "(Ban hành theo Thông tư số 133/2016/TT-BTC ngày 26/8/2016 của Bộ Tài chính)", phu_luc=True,
                 tieu=(("BÁO CÁO LƯU CHUYỂN TIỀN TỆ", 14, True), ("(Theo phương pháp trực tiếp)", 11, False),
                       ("Năm %d" % k["nam"], 11, True)), cot_trai=3)
    r = _tieu_de_dn(ws, wb, r, dl, 5, day_du=False, ma=("[02]", "[03]"))
    ws.gop(r, 4, r, 5, "Đơn vị tiền: đồng Việt Nam", wb.kieu(nghieng=True, can="phai"))
    r += 1
    r = _bang_so(ws, wb, r, ("Chỉ tiêu", "Mã số", "Thuyết minh", "Năm nay", "Năm trước"), B03_DONG, c)
    ws.in_trang(ngang=False)
    _ky_ten(ws, wb, r + 1, dl, 5, ghi_chu=(
        "Ghi chú: (1) Các chỉ tiêu không có số liệu thì doanh nghiệp không phải trình bày nhưng không được đánh lại “Mã số” chỉ tiêu.",
        "(2) Đối với trường hợp thuê dịch vụ làm kế toán, làm kế toán trưởng thì phải ghi rõ số Giấy chứng nhận đăng ký hành nghề dịch vụ "
        "kế toán, tên đơn vị cung cấp dịch vụ kế toán."))
    p = os.path.join(thumuc, "B03_DNN_%d.xlsx" % k["nam"])
    wb.luu(p)
    return p


def excel_f01(dl, thumuc):
    g = gia_tri_bctc(dl)
    dong = g["F01"]
    if not dong:
        raise ValueError("Không có hệ thống tài khoản (tk) trong số liệu - không lập được F01.")
    k = _ky(dl)
    wb = _wb()
    ws = wb.sheet("F01-DNN", cot=[9, 30, 16, 16, 17, 17, 16, 16])
    r = _dau_mau(ws, wb, 8, "F01 - DNN", "(Ban hành theo Thông tư số 133/2016/TT-BTC ngày 26/8/2016 của Bộ Tài chính)", phu_luc=True,
                 tieu=(("BẢNG CÂN ĐỐI TÀI KHOẢN", 14, True), ("Năm %d" % k["nam"], 11, True)), cot_trai=5)
    r = _tieu_de_dn(ws, wb, r, dl, 8, day_du=False, ma=("[02]", "[03]"))
    ws.gop(r, 7, r, 8, "Đơn vị tiền: đồng Việt Nam", wb.kieu(nghieng=True, can="phai"))
    r += 1
    kh = wb.kieu(dam=True, can="giua", khung=True, xuong=True, nen="F2F2F2")
    ws.gop(r, 1, r + 1, 1, "Số hiệu tài khoản", kh)
    ws.gop(r, 2, r + 1, 2, "Tên tài khoản", kh)
    for i, t in enumerate(("Số dư đầu kỳ", "Số phát sinh trong kỳ", "Số dư cuối kỳ")):
        ws.gop(r, 3 + 2 * i, r, 4 + 2 * i, t, kh)
        ws.o(r + 1, 3 + 2 * i, "Nợ", kh)
        ws.o(r + 1, 4 + 2 * i, "Có", kh)
    kh2 = wb.kieu(nghieng=True, can="giua", khung=True)
    for i, t in enumerate(("A", "B", "1", "2", "3", "4", "5", "6"), start=1):
        ws.o(r + 2, i, t, kh2)
    ws.in_trang(ngang=True, lap_dong=(r, r + 2))
    r += 3
    k_tk = wb.kieu(khung=True, can="giua")
    k_tk_d = wb.kieu(khung=True, can="giua", dam=True)
    k_ten = wb.kieu(khung=True, xuong=True, can="trai")
    k_ten_d = wb.kieu(khung=True, xuong=True, can="trai", dam=True)
    k_nhom = wb.kieu(khung=True, dam=True, can="trai")
    k_so = wb.kieu(khung=True, so=SO_FMT, can="phai")
    k_so_d = wb.kieu(khung=True, so=SO_FMT, can="phai", dam=True)
    for d in dong:
        if d.get("nhom"):
            ws.gop(r, 1, r, 8, d["ten"], k_nhom)
            r += 1
            continue
        dam = d.get("cap1") or d.get("tong")
        ws.o(r, 1, d["tk"], k_tk_d if dam else k_tk)
        ws.o(r, 2, d["ten"], wb.kieu(khung=True, dam=True, can="giua") if d.get("tong") else (k_ten_d if dam else k_ten))
        for i, c in enumerate(COT_F01):
            ws.o(r, 3 + i, d[c], k_so_d if dam else k_so)
        r += 1
    _ky_ten(ws, wb, r + 1, dl, 8, ghi_chu=(
        "Ghi chú: Đối với trường hợp thuê dịch vụ làm kế toán, làm kế toán trưởng thì phải ghi rõ số Giấy chứng nhận đăng ký hành nghề "
        "dịch vụ kế toán, tên đơn vị cung cấp dịch vụ kế toán.",))
    ws.dong_bang(r=1)
    p = os.path.join(thumuc, "F01_DNN_%d.xlsx" % k["nam"])
    wb.luu(p)
    return p


def excel_tndn(dl, thumuc):
    q = tinh_tndn(dl)
    if q is None:
        return ""
    k = _ky(dl)
    dn = _dn(dl)
    nk = _nguoi_ky(dl)
    v, pl = q["ct"], q["pl"]
    wb = _wb()
    kd = wb.kieu(dam=True, can="giua")
    kt = wb.kieu(can="trai")
    kh = wb.kieu(dam=True, can="giua", khung=True, xuong=True, nen="F2F2F2")
    kh2 = wb.kieu(nghieng=True, can="giua", khung=True)
    k_stt = wb.kieu(khung=True, can="giua")
    k_stt_d = wb.kieu(khung=True, can="giua", dam=True)
    k_ten = wb.kieu(khung=True, xuong=True, can="trai")
    k_ten_d = wb.kieu(khung=True, xuong=True, can="trai", dam=True)
    k_so = wb.kieu(khung=True, so=SO_FMT, can="phai")
    k_so_d = wb.kieu(khung=True, so=SO_FMT, can="phai", dam=True)
    k_pt = wb.kieu(khung=True, so="0.00", can="phai")
    ky_txt = "Năm %d Từ %s đến %s" % (k["nam"], k["tu"].strftime("%d/%m/%Y"), k["den"].strftime("%d/%m/%Y"))

    def cam_doan(ws, r, so_cot):
        lap = k["lap"]
        x = so_cot // 2
        ws.gop(r, 1, r, so_cot, "Tôi cam đoan số liệu khai trên là đúng và chịu trách nhiệm trước pháp luật về những số liệu đã khai./.",
               wb.kieu(nghieng=True, can="trai", xuong=True))
        ws.cao(r, 28)
        r += 1
        ws.gop(r, 1, r, x, "NHÂN VIÊN ĐẠI LÝ THUẾ", kd)
        ws.gop(r, x + 1, r, so_cot, "Ngày %02d tháng %02d năm %d" % (lap.day, lap.month, lap.year), wb.kieu(nghieng=True, can="giua"))
        ws.gop(r + 1, 1, r + 1, x, "Họ và tên:", kt)
        ws.gop(r + 1, x + 1, r + 1, so_cot, "NGƯỜI NỘP THUẾ hoặc ĐẠI DIỆN HỢP PHÁP CỦA NGƯỜI NỘP THUẾ", wb.kieu(dam=True, can="giua", xuong=True))
        ws.cao(r + 1, 30)
        ws.gop(r + 2, 1, r + 2, x, "Chứng chỉ hành nghề số:", kt)
        ws.gop(r + 2, x + 1, r + 2, so_cot, "(Chữ ký, ghi rõ họ tên; chức vụ và đóng dấu (nếu có)/Ký điện tử)",
               wb.kieu(nghieng=True, can="giua", co=9, xuong=True))
        ws.gop(r + 6, x + 1, r + 6, so_cot, nk.get("nguoi_ky") or nk.get("giam_doc", ""), kd)
        return r + 8

    # ---- to khai 03/TNDN
    ws = wb.sheet("03-TNDN", cot=[6, 70, 11, 19])
    ws.gop(1, 1, 1, 2, "CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM", kd)
    ws.gop(2, 1, 2, 2, "Độc lập - Tự do - Hạnh phúc", kd)
    ws.gop(3, 1, 3, 2, "-------------------------", wb.kieu(can="giua"))
    ws.gop(1, 3, 1, 4, "Mẫu số: 03/TNDN", kd)
    ws.gop(2, 3, 3, 4, "(Ban hành kèm theo Thông tư số 80/2021/TT-BTC ngày 29 tháng 9 năm 2021 của Bộ trưởng Bộ Tài chính)",
           wb.kieu(nghieng=True, can="giua", xuong=True, co=9))
    ws.cao(3, 40)
    ws.gop(5, 1, 5, 4, "TỜ KHAI QUYẾT TOÁN THUẾ THU NHẬP DOANH NGHIỆP (MẪU SỐ 03/TNDN)", wb.kieu(dam=True, co=13, can="giua"))
    ws.gop(6, 1, 6, 4, "(Áp dụng đối với phương pháp doanh thu - chi phí)", wb.kieu(nghieng=True, can="giua"))
    ws.gop(7, 1, 7, 4, "[01] Kỳ tính thuế: %s" % ky_txt, wb.kieu(dam=True, can="giua"))
    ws.gop(8, 1, 8, 4, "[02] Lần đầu: [X]    [03] Bổ sung lần thứ: [ ]", wb.kieu(can="giua"))
    ws.gop(10, 1, 10, 4, "[04] Ngành nghề có tỷ lệ doanh thu cao nhất: %s" % (q["ten_nganh"] or q["ma_nganh"]), kt)
    ws.gop(11, 1, 11, 4, "[05] Tỷ lệ (%%): %s" % ("%.2f" % _so(q["ct05"])).replace(".", ","), kt)
    ws.gop(12, 1, 12, 4, "[06] Tên người nộp thuế: %s" % dn.get("ten", ""), wb.kieu(dam=True, can="trai"))
    ws.gop(13, 1, 13, 4, "[07] Mã số thuế: %s" % dn.get("mst", ""), wb.kieu(dam=True, can="trai"))
    ws.gop(14, 1, 14, 4, "[08] Tên đại lý thuế (nếu có):", kt)
    ws.gop(15, 1, 15, 4, "[09] Mã số thuế:", kt)
    ws.gop(16, 1, 16, 4, "[10] Hợp đồng đại lý thuế: Số ..........  Ngày ..........", kt)
    ws.gop(17, 3, 17, 4, "Đơn vị tiền: Đồng Việt Nam", wb.kieu(nghieng=True, can="phai"))
    r = 18
    for i, t in enumerate(("STT", "Chỉ tiêu", "Mã chỉ tiêu", "Số tiền"), start=1):
        ws.o(r, i, t, kh)
        ws.o(r + 1, i, "(%d)" % i, kh2)
    r += 2
    for stt, ten, ma in TNDN_DONG:
        muc = ma in TNDN_MUC or ma in ("E", "G", "I") or stt in ("A", "B", "C", "D", "E", "G", "H", "I")
        ten = ten.replace("{ts}", str(q["ts"]))
        ws.o(r, 1, stt, k_stt_d if muc else k_stt)
        ws.o(r, 2, ten, k_ten_d if muc else k_ten)
        ws.o(r, 3, "" if ma.startswith("tamnop") else ma, k_stt_d if muc else k_stt)
        if ma in TNDN_MUC:
            ws.o(r, 4, None, k_so)
        elif ma == "C8a":
            ws.o(r, 4, v["C8a"], k_pt)
        else:
            ws.o(r, 4, v[ma], k_so_d if muc else k_so)
        if ma == "C2":
            r += 1
            ws.o(r, 1, "", k_stt)
            ws.o(r, 2, "Loại thu nhập miễn thuế", wb.kieu(khung=True, nghieng=True, can="trai"))
            ws.o(r, 3, "", k_stt)
            ws.o(r, 4, v["C2"], k_so)
        r += 1
    r = cam_doan(ws, r + 1, 4)
    ghi = ["Ghi chú: 1. TNDN: Thu nhập doanh nghiệp; BĐS: Bất động sản.",
           "2. Chỉ tiêu G1, G3: NNT kê khai số thuế TNDN nộp thừa kỳ trước chuyển sang bù trừ với số thuế TNDN phải nộp kỳ này.",
           "3. Chỉ tiêu G2, G4, G5: NNT kê khai số thuế TNDN đã tạm nộp vào NSNN tính đến thời hạn nộp hồ sơ khai quyết toán.",
           "Hạch toán số tiền %s vào tiểu mục 1052: Thuế thu nhập doanh nghiệp từ hoạt động sản xuất kinh doanh." % _dd(q["nv"]["tong1052"])]
    for x in ghi:
        ws.gop(r, 1, r, 4, x, wb.kieu(nghieng=True, can="trai", xuong=True, co=9))
        ws.cao(r, 26)
        r += 1
    ws.in_trang(ngang=False, lap_dong=(18, 19))
    # ---- PL 03-1A
    ws = wb.sheet("PL 03-1A", cot=[6, 70, 11, 19])
    ws.gop(1, 1, 1, 2, "PHỤ LỤC", kd)
    ws.gop(1, 3, 1, 4, "Mẫu số: 03-1A/TNDN", kd)
    ws.gop(2, 3, 3, 4, "(Ban hành kèm theo Thông tư số 80/2021/TT-BTC ngày 29 tháng 9 năm 2021 của Bộ trưởng Bộ Tài chính)",
           wb.kieu(nghieng=True, can="giua", xuong=True, co=9))
    ws.cao(3, 40)
    ws.gop(2, 1, 2, 2, "KẾT QUẢ HOẠT ĐỘNG SẢN XUẤT KINH DOANH", kd)
    ws.gop(3, 1, 3, 2, "Áp dụng đối với ngành sản xuất, thương mại, dịch vụ (trừ công ty an ninh, quốc phòng)\n"
           "(Kèm theo tờ khai quyết toán thuế thu nhập doanh nghiệp số 03/TNDN)", wb.kieu(nghieng=True, can="giua", xuong=True))
    ws.gop(5, 1, 5, 4, "[01] Kỳ tính thuế: Năm %d" % k["nam"], wb.kieu(dam=True, can="giua"))
    ws.gop(6, 1, 6, 4, "[02] Tên người nộp thuế: %s" % dn.get("ten", ""), wb.kieu(dam=True, can="trai"))
    ws.gop(7, 1, 7, 4, "[03] Mã số thuế: %s" % dn.get("mst", ""), wb.kieu(dam=True, can="trai"))
    ws.gop(8, 3, 8, 4, "Đơn vị tiền: Đồng Việt Nam", wb.kieu(nghieng=True, can="phai"))
    r = 9
    for i, t in enumerate(("STT", "Chỉ tiêu", "Mã chỉ tiêu", "Số tiền"), start=1):
        ws.o(r, i, t, kh)
        ws.o(r + 1, i, "(%d)" % i, kh2)
    r += 2
    for stt, ten, ma in PL031A_DONG:
        dam = ma in ("18", "22") or ma is None
        ws.o(r, 1, stt, k_stt)
        ws.o(r, 2, ten, k_ten_d if dam else k_ten)
        ws.o(r, 3, "[%s]" % ma if ma else "", k_stt)
        ws.o(r, 4, pl[ma] if ma else None, k_so_d if dam else k_so)
        r += 1
    r = cam_doan(ws, r + 1, 4)
    ws.gop(r, 1, r, 4, "Ghi chú: Số liệu chỉ tiêu [22] được tổng hợp vào chỉ tiêu A1 của Tờ khai 03/TNDN.", wb.kieu(nghieng=True, can="trai", co=9))
    r += 1
    ws.gop(r, 1, r, 4, "Ánh xạ số liệu từ phần mềm: " + "; ".join("[%s] = %s" % (m, PL031A_TU_B02[m]) for m in sorted(PL031A_TU_B02)),
           wb.kieu(nghieng=True, can="trai", xuong=True, co=9))
    ws.cao(r, 54)
    ws.in_trang(ngang=False)
    # ---- PL 03-2A
    ws = wb.sheet("PL 03-2A", cot=[6, 12, 19, 21, 21, 21])
    ws.gop(1, 1, 1, 4, "PHỤ LỤC", kd)
    ws.gop(1, 5, 1, 6, "Mẫu số: 03-2/TNDN", kd)
    ws.gop(2, 5, 3, 6, "(Ban hành kèm theo Thông tư số 80/2021/TT-BTC ngày 29 tháng 9 năm 2021 của Bộ trưởng Bộ Tài chính)",
           wb.kieu(nghieng=True, can="giua", xuong=True, co=9))
    ws.cao(3, 40)
    ws.gop(2, 1, 2, 4, "CHUYỂN LỖ", kd)
    ws.gop(3, 1, 3, 4, "(Kèm theo tờ khai quyết toán thuế thu nhập doanh nghiệp số 03/TNDN)", wb.kieu(nghieng=True, can="giua"))
    ws.gop(5, 1, 5, 6, "[01] Kỳ tính thuế: Năm %d" % k["nam"], wb.kieu(dam=True, can="giua"))
    ws.gop(6, 1, 6, 6, "[02] Tên người nộp thuế: %s" % dn.get("ten", ""), wb.kieu(dam=True, can="trai"))
    ws.gop(7, 1, 7, 6, "[03] Mã số thuế: %s" % dn.get("mst", ""), wb.kieu(dam=True, can="trai"))
    ws.gop(8, 5, 8, 6, "Đơn vị tiền: Đồng Việt Nam", wb.kieu(nghieng=True, can="phai"))
    r = 9
    for i, t in enumerate(("STT", "Năm phát sinh lỗ", "Số lỗ phát sinh", "Số lỗ đã chuyển trong các kỳ tính thuế trước",
                           "Số lỗ được chuyển trong kỳ tính thuế này", "Số lỗ còn được chuyển sang các kỳ tính thuế sau"), start=1):
        ws.o(r, i, t, kh)
        ws.o(r + 1, i, "(%d)" % i, kh2)
    ws.cao(r, 45)
    r += 2
    for la_ma, ten, bang in (("I", "Lỗ của hoạt động sản xuất kinh doanh được chuyển trong kỳ", q["lo_sx"]),
                             ("II", "Lỗ của hoạt động chuyển nhượng bất động sản được chuyển trong kỳ", q["lo_bds"])):
        ws.o(r, 1, la_ma, k_stt_d)
        ws.gop(r, 2, r, 6, ten, k_ten_d)
        r += 1
        for i, (y, c3, c4, c5, c6) in enumerate(bang, start=1):
            ws.o(r, 1, i, k_stt)
            ws.o(r, 2, y, k_stt)
            for j, x in enumerate((c3, c4, c5, c6)):
                ws.o(r, 3 + j, x, k_so)
            r += 1
        ws.o(r, 1, "", k_stt)
        ws.gop(r, 2, r, 4, "Tổng cộng", k_stt_d)
        ws.o(r, 5, sum(x[3] for x in bang), k_so_d)
        ws.o(r, 6, None, k_so)
        r += 1
    r = cam_doan(ws, r + 1, 6)
    for x in ("Ghi chú: - Số liệu chỉ tiêu [04] được tổng hợp vào chỉ tiêu C3a của Tờ khai 03/TNDN;",
              "- Số liệu chỉ tiêu [05] được tổng hợp vào chỉ tiêu D2 của Tờ khai 03/TNDN.",
              "Nguồn số lỗ các năm trước: %s." % (q["nguon_lo"] or "không có (để 0)")):
        ws.gop(r, 1, r, 6, x, wb.kieu(nghieng=True, can="trai", xuong=True, co=9))
        r += 1
    ws.in_trang(ngang=False)
    p = os.path.join(thumuc, "03_TNDN_%d.xlsx" % k["nam"])
    wb.luu(p)
    return p


# ------------------------------------------------------------------ hop dong xuat_1_lan
def lap(dl, ma, kieu, thumuc):
    ma = str(ma or "").upper()
    kieu = str(kieu or "E").upper()
    st = _st(dl)
    tep, cb = [], []
    g = gia_tri_bctc(dl)
    if not st.get("da_bao_chung"):
        st["da_bao_chung"] = True
        for x in g.get("loi_dong_co") or []:
            cb.append("Động cơ báo cáo phần mềm: %s" % x)
        cb.extend(g["canh_bao"])
        cb.extend(g["kiem_cheo"])
        nt = g["nam_truoc"]
        if nt.get("nguon"):
            cb.append("Số năm trước dùng để đối chiếu / điền cột năm trước: " + "; ".join(nt["nguon"]) + ".")
    if ma in MUC_BCTC:
        if "E" in kieu:
            tep.append({"B01A": excel_b01a, "B02": excel_b02, "B03": excel_b03, "F01": excel_f01}[ma](dl, thumuc))
        if "X" in kieu:
            da_co = bool(st.get("xml_bctc"))
            try:
                p = lap_xml_bctc(dl, thumuc, cb)
            except Exception as e:                     # GD78 soat: Excel da lap van giu, XML loi ghi canh bao
                if "E" not in kieu:
                    raise
                p = None
                cb.append("XML HTKK bộ BCTC chưa lập được: %s - tệp Excel vẫn lập." % e)
            if p and not da_co:
                tep.append(p)
            elif p:
                cb.append("XML HTKK: %s đã nằm trong tệp %s (bộ BCTC lập một lần)." % (ma, os.path.basename(p)))
                if "E" not in kieu:
                    tep.append(p)
    elif ma == "TNDN":
        q = tinh_tndn(dl)
        if q is None:
            cb.append("03/TNDN: anh đã bấm Huỷ ở hộp chọn thuế suất [C7] - KHÔNG lập tờ khai quyết toán TNDN.")
            return {"tep": [], "canh_bao": cb}
        if "E" in kieu:
            tep.append(excel_tndn(dl, thumuc))
        if "X" in kieu:
            tep.append(lap_xml_tndn(dl, thumuc, cb))
        cb.extend(q["canh_bao"])
    else:
        raise ValueError("Mục %s không thuộc báo cáo năm (B01A, B02, B03, F01, TNDN)." % ma)
    da = st.setdefault("da_bao", set())
    cb2 = []
    for x in cb:
        if x not in da:
            da.add(x)
            cb2.append(x)
    return {"tep": [t for t in tep if t], "canh_bao": cb2}
