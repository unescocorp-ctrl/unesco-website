# -*- coding: utf-8 -*-
"""GD358 - THUC HIEN NGHIEP VU DINH KY (theo mau: dau nam / dinh ky / cuoi ky) - chi DOC .MDB, khong ghi so.

Moi nghiep vu x moi thang (thu tu nam tai chinh): DA (da lam, so tien, ngay chung tu gan nhat) / CAN (phai lam truoc khi khoa)
/ XEM (nen kiem lai) / KHONG (khong phat sinh). Dung chung so lieu voi khoa_so_thang.py (GD356): but toan sai tung dong,
viec can lam, da lam - VB6 FrmNghiepVu358 doc ca 2 tep.
Ra ket-qua\\nghiep_vu_dinh_ky.txt + .html (+ khoa_so_thang.txt / .html):
  TONG;<so>;<nam>;<tu>;<den>;<luc>;<ten cty>;<thang can khoa tiep>
  NV;<nhom>;<ma>;<ten>;<lan gan nhat>;<tt thang can khoa>;<so thang CAN>;<so thang DA>;<cach lam>;<noi lam>
  O;<ma>;<t>;<tt>;<ghi chu>"""
import datetime as _dt
import html
import io
import os
import re
from collections import defaultdict

import khoa_so_thang as K

HERE = os.path.dirname(os.path.abspath(__file__))
TEP = "nghiep_vu_dinh_ky"
NHOM = (("DAU_NAM", "Nghiệp vụ đầu năm"), ("DINH_KY", "Nghiệp vụ định kỳ"), ("CUOI_KY", "Nghiệp vụ cuối kỳ"), ("DAU_VAO", "Kiểm tra chứng từ đầu vào"))
# nhom, ma, ten, cach lam (but toan), noi lam
NV = [
    ("DAU_NAM", "KC_LNST", "Kết chuyển lợi nhuận sau thuế năm trước", "Đầu năm: số dư 4212 (năm nay của năm trước) chuyển sang 4211 - lãi: Nợ 4212 / Có 4211; lỗ: Nợ 4211 / Có 4212.", "Chứng từ kết chuyển"),
    ("DAU_NAM", "MON_BAI", "Hạch toán lệ phí môn bài đầu năm", "Từ 01/01/2026 lệ phí môn bài đã bãi bỏ (Nghị quyết 198/2025/QH15) - không hạch toán. Năm trước 2026: Nợ 6425 (642) / Có 3338, nộp: Nợ 3338 / Có 111, 112.", "Không cần làm từ 2026"),
    ("DINH_KY", "GIA_XUAT", "Tính giá xuất kho", "Cuối tháng tính lại giá xuất kho (bình quân / FIFO) để phiếu xuất có giá vốn: Nợ 632, 154, 621... / Có 152, 153, 155, 156.", "Tổng hợp > Tính lại giá xuất kho"),
    ("DINH_KY", "DC_BANG_KE", "Đối chiếu bảng kê hoá đơn đầu vào với TCT", "Tải hoá đơn mua vào từ cổng TCT, đối chiếu từng hoá đơn với sổ (Nợ 133); hoá đơn chưa có trong sổ thì hạch toán, hoá đơn rủi ro thì loại khỏi khấu trừ.", "Soát rủi ro hoá đơn / AI hoá đơn"),
    ("DINH_KY", "KHAU_HAO", "Khấu hao TSCĐ", "Tính khấu hao tháng: Nợ 627 / 641 / 642 (theo bộ phận dùng) / Có 214.", "Tài sản cố định"),
    ("DINH_KY", "GIA_THANH", "Tính giá thành", "Tập hợp 621, 622, 627 vào 154 rồi nhập kho thành phẩm: Nợ 155 / Có 154 (dịch vụ: Nợ 632 / Có 154).", "Giá thành"),
    ("DINH_KY", "PB_242", "Phân bổ chi phí trả trước", "Phân bổ chi phí trả trước tháng: Nợ 627 / 641 / 642 / Có 242.", "Công cụ dụng cụ / Chi phí trả trước"),
    ("DINH_KY", "KT_GTGT", "Khấu trừ thuế GTGT", "Cuối tháng / quý kê khai: Nợ 3331 / Có 133 số nhỏ hơn giữa hai bên (khớp tờ khai 01/GTGT).", "Chứng từ kết chuyển"),
    ("DINH_KY", "PB_CCDC", "Phân bổ công cụ dụng cụ", "Xuất dùng: Nợ 242 / Có 153; phân bổ tháng: Nợ 627 / 641 / 642 / Có 242.", "Công cụ dụng cụ"),
    ("DINH_KY", "TNDN_TAM", "Ước tính thuế TNDN tạm nộp", "Tháng cuối quý: lãi luỹ kế x thuế suất (20%; doanh thu năm đến 3 tỷ 15%, trên 3 đến 50 tỷ 17% - Luật TNDN 2025): Nợ 8211 / Có 3334; nộp chậm nhất ngày 30 tháng đầu quý sau.", "Thuế TNDN dự kiến"),
    ("DINH_KY", "LUONG", "Hạch toán lương", "Trích lương: Nợ 622 / 627 / 641 / 642 / Có 334; bảo hiểm doanh nghiệp đóng: Nợ 622... / Có 3383, 3384, 3386, 3382; phần người lao động: Nợ 334 / Có 338.", "Nhân viên - lương"),
    ("DINH_KY", "KC_LAI_LO", "Kết chuyển lãi lỗ", "Nợ 511, 515, 711 / Có 911; Nợ 911 / Có 632, 635, 641, 642, 811, 821; lãi: Nợ 911 / Có 4212 (lỗ ngược lại).", "Tổng hợp > Kết chuyển số liệu"),
    ("DINH_KY", "DC_HD", "Đối chiếu hoá đơn bán ra với TCT", "Tải hoá đơn bán ra từ cổng TCT, đối chiếu với doanh thu (Có 511, 3331); hoá đơn chưa ghi sổ thì hạch toán.", "AI hoá đơn"),
    ("CUOI_KY", "KIEM_SO", "Kiểm tra sổ sách", "Sửa từng bút toán LỖI trên lưới (mở chứng từ), xem lại dòng CẦN XEM; chạy lại kiểm tra đến khi hết lỗi.", "Kiểm tra tổng hợp khoá sổ"),
    ("CUOI_KY", "KHOA_SO", "Khoá sổ", "Khoá tháng theo thứ tự: tháng trước khoá rồi mới khoá tháng sau (máy chấm điểm sẵn sàng và sao lưu trước khi khoá).", "Kiểm tra tổng hợp khoá sổ > Khoá tháng"),
    ("CUOI_KY", "DANH_SO", "Đánh lại số chứng từ", "Số chứng từ trùng giữa các phiếu cùng loại trong tháng: sửa số phiếu sau cho liền mạch (mở chứng từ, sửa Số) - máy không tự đổi số.", "Mở chứng từ"),
    ("CUOI_KY", "BO_KHOA", "Bỏ khoá sổ", "Chỉ bỏ khoá khi phải sửa tháng đã khoá (cần mật khẩu quản trị); sửa xong khoá lại ngay.", "Kiểm tra tổng hợp khoá sổ"),
    ("CUOI_KY", "XUAT_KHAU", "Xuất khẩu hàng loạt", "Tháng đã khoá: in / xuất toàn bộ sổ sách, báo cáo ra Excel / PDF để lưu trữ.", "Báo cáo > In toàn bộ sổ"),
    # GD358f: kiem tra chung tu dau vao
    ("DAU_VAO", "CT_HOADON", "Hoá đơn mua vào / bán ra", "Đối chiếu hoá đơn tải từ cổng TCT với sổ: hoá đơn chưa hạch toán thì ghi (Nợ 152/156/642, 133 / Có 331, 111, 112; Có 511, 3331 / Nợ 131, 111, 112); thuế đầu vào trên sổ phải có hoá đơn.", "AI hoá đơn"),
    ("DAU_VAO", "CT_LUONG", "Bảng lương, bảo hiểm", "Bảng lương tháng (chấm công, lương, BHXH, thuế TNCN) phải khớp sổ: Có 334 = tổng thu nhập; Có 338 = BH doanh nghiệp đóng; Nợ 334 / Có 338, 3335 phần trừ lương.", "Nhân viên - lương"),
    ("DAU_VAO", "CT_SOPHU", "Sổ phụ ngân hàng", "Nhập đủ sổ phụ từng tài khoản ngân hàng trong tháng (thu: Nợ 112; chi: Có 112), số dư 112 cuối tháng khớp số dư sổ phụ; không để 112 âm.", "AI hoá đơn > Sổ phụ ngân hàng"),
    ("DAU_VAO", "CT_THUCHI", "Phiếu thu, phiếu chi tiền mặt", "Quỹ tiền mặt không âm theo ngày; khoản chi từ 5 triệu có hoá đơn GTGT phải chuyển khoản mới được khấu trừ; phiếu chi có chứng từ gốc.", "Kiểm tra tổng hợp khoá sổ"),
    ("DAU_VAO", "CT_VAY", "Vay, mượn (341, 1388, 3388)", "Khoản vay / mượn có hợp đồng, theo dõi theo đối tượng; trích lãi vay hằng tháng Nợ 635 / Có 335 (hoặc 111, 112 khi trả); vay không âm.", "Kiểm tra tổng hợp khoá sổ"),
    ("DAU_VAO", "CT_CONGNO", "Công nợ khách hàng, nhà cung cấp (131, 331)", "Mọi dòng 131 / 331 có đối tượng; đối chiếu công nợ cuối kỳ; số dư ngược bên (131 dư Có, 331 dư Nợ) là trả trước - kiểm tra lại; nợ quá hạn xem Nợ khó đòi.", "Công nợ"),
]
TT_TEN = {"DA": ("Đã làm", "#1d6b34"), "CAN": ("Cần làm", "#a3262a"), "XEM": ("Cần xem", "#9a5b00"), "KHONG": ("Không phát sinh", "#8a96a3")}


def _tk(d, r, ben):
    return d["tk"].get(r.get("MaTKNo" if ben == "N" else "MaTKCo"), "")


def _cap(d, rows, no, co):
    return [r for r in rows if _tk(d, r, "N").startswith(no) and _tk(d, r, "C").startswith(co)]


def _ngmax(rows):
    ng = [K._ngay(r.get("NgayCT")) for r in rows]
    ng = [x for x in ng if x]
    return max(ng) if ng else None


def _hddt(d, th, nam, ban_ra):
    tong = chua = 0
    gom = {}
    for h in d["hddt"]:
        ng = K._ngay(h.get("NgayLap"))
        if not ng or (ng.month, ng.year) != (th, nam) or bool(h.get("HDBanRa")) != ban_ra:
            continue
        tt = str(h.get("TrangThaiHoaDon") or "").lower()
        if "thay thế" in tt or "huỷ" in tt or "hủy" in tt:
            continue
        doi = h.get("MSTNguoiMuaNguoiNhanHang") if ban_ra else h.get("MSTNguoiBanNguoiXuatHang")
        so = str(h.get("SoHoaDon") or "").strip().lstrip("0")
        k = (str(h.get("KyHieuHoaDon") or ""), so, re.sub(r"\D", "", str(doi or ""))[:10])
        da = (str(h.get("MaCTKeToan") or "").strip() not in ("", "0") or str(h.get("MaCT") or "").strip() in d["hddt_da"]
              or K.hd_ghi_tay(d, h))          # GD370: dinh danh day du (so + chieu + MST / tien)
        gom[k] = gom.get(k, False) or da
    tong = len(gom)
    chua = sum(1 for v in gom.values() if not v)
    return tong, chua


def _ket_qua_quy(d, rows):
    thu = sum(K._f(r.get("SoPS")) for r in rows if _tk(d, r, "C").startswith(("511", "515", "711")) and not _tk(d, r, "N").startswith("911"))
    thu -= sum(K._f(r.get("SoPS")) for r in rows if _tk(d, r, "N").startswith(("511", "521")) and not _tk(d, r, "C").startswith("911"))
    chi = sum(K._f(r.get("SoPS")) for r in rows if _tk(d, r, "N").startswith(("632", "635", "641", "642", "811")) and not _tk(d, r, "C").startswith("911"))
    return thu - chi


def danh_gia(d, kq):
    """Tra ve {ma: {t: (tt, ghi, ngay)}}."""
    theo = defaultdict(list)
    for r in d["ct"]:
        t = K._i(r.get("ThangCT"))
        if 1 <= t <= 12:
            theo[t].append(r)
    o = defaultdict(dict)
    ca_nam = [r for t in theo for r in theo[t]]
    kc_lnst = _cap(d, ca_nam, "4212", "4211") + _cap(d, ca_nam, "4211", "4212")
    du4212 = sum(v for m, v in d["tk_dau"].items() if d["tk"].get(m, "").startswith("4212"))
    mb = [r for r in ca_nam if _tk(d, r, "C").startswith("3338") and ("môn bài" in K._u(d, r.get("DienGiai")).lower() or _tk(d, r, "N").startswith(("6425", "642")))]
    for m in kq["thang"]:
        t = m["t"]
        rows = [r for r in theo.get(t, []) if K._f(r.get("SoPS"))]
        tat = theo.get(t, [])
        th, nam = K.thang_lich(d, t)
        viec = {v[1]: v for v in m["viec"]}
        da_ma = lambda ds: ds and ("DA", "%s" % K._dd(sum(K._f(r.get("SoPS")) for r in ds)), _ngmax(ds))
        # dau nam
        if t == 1:
            if kc_lnst:
                o["KC_LNST"][t] = ("DA", "Đã kết chuyển %s" % K._dd(sum(K._f(r.get("SoPS")) for r in kc_lnst)), _ngmax(kc_lnst))
            elif abs(du4212) > 1000:
                o["KC_LNST"][t] = ("CAN", "Số dư đầu năm 4212 %s chưa chuyển sang 4211" % K._dd(abs(du4212)), None)
            else:
                o["KC_LNST"][t] = ("KHONG", "4212 đầu năm không có số dư", None)
            if nam >= 2026:
                o["MON_BAI"][t] = ("XEM", "Sổ có %d dòng hạch toán môn bài năm %d - đã bãi bỏ từ 2026, kiểm tra lại" % (len(mb), nam), _ngmax(mb)) if mb \
                    else ("KHONG", "Bãi bỏ từ 01/01/2026 - không phải hạch toán", None)
            else:
                o["MON_BAI"][t] = ("DA", "Đã hạch toán %s" % K._dd(sum(K._f(r.get("SoPS")) for r in mb)), _ngmax(mb)) if mb else ("CAN", "Chưa hạch toán lệ phí môn bài năm %d" % nam, None)
        # gia xuat kho
        xuat = [r for r in tat if K._i(r.get("MaVattu")) > 0 and _tk(d, r, "N") and _tk(d, r, "C").startswith(("152", "153", "155", "156"))]          # bo dong xuat giu ho / gui gia cong khong co TK No
        x0 = [r for r in xuat if not K._f(r.get("SoPS"))]
        if x0:
            o["GIA_XUAT"][t] = ("CAN", "%d dòng xuất kho chưa có giá" % len(x0), None)
        elif xuat:
            o["GIA_XUAT"][t] = ("DA", "%d dòng xuất, giá vốn %s" % (len(xuat), K._dd(sum(K._f(r.get("SoPS")) for r in xuat))), _ngmax(xuat))
        else:
            o["GIA_XUAT"][t] = ("KHONG", "Không có phiếu xuất kho", None)
        # hoa don
        for ma, ban, tk_ss in (("DC_BANG_KE", False, "N133"), ("DC_HD", True, "C3331")):
            tong, chua = _hddt(d, th, nam, ban)
            co_so = any(_tk(d, r, tk_ss[0]).startswith(tk_ss[1:]) for r in rows)
            if chua:
                o[ma][t] = ("CAN", "%d / %d hoá đơn TCT chưa có trong sổ" % (chua, tong), None)
            elif tong:
                o[ma][t] = ("DA", "%d hoá đơn TCT đã khớp sổ" % tong, None)
            elif co_so:
                o[ma][t] = ("XEM", "Sổ có %s nhưng chưa tải hoá đơn tháng này từ TCT để đối chiếu" % ("thuế đầu vào" if not ban else "thuế đầu ra"), None)
            else:
                o[ma][t] = ("KHONG", "Không có hoá đơn", None)
        # khau hao, 242, luong, kc, thue
        for ma, vm, ds, khong in (("KHAU_HAO", ("KHAU_HAO",), [r for r in rows if _tk(d, r, "C").startswith("214")], "Không có TSCĐ cần khấu hao"),
                                  ("PB_242", ("PHAN_BO_242",), [r for r in rows if _tk(d, r, "C").startswith("242")], "Không còn chi phí trả trước"),
                                  ("LUONG", ("LUONG", "BAO_HIEM"), [r for r in rows if _tk(d, r, "C").startswith("334")], "Không có bảng lương"),
                                  ("KC_LAI_LO", ("KC_911",), [r for r in rows if _tk(d, r, "C").startswith("911") or _tk(d, r, "N").startswith("911")], "Không có doanh thu / chi phí"),
                                  ("KT_GTGT", ("THUE_GTGT",), _cap(d, rows, "3331", "133"), "Không có thuế cần khấu trừ")):
            v = [viec[k] for k in vm if k in viec]
            if v:
                o[ma][t] = ("CAN", " ; ".join(x[2] for x in v), _ngmax(ds))
            elif ds:
                o[ma][t] = da_ma(ds)
            else:
                o[ma][t] = ("KHONG", khong, None)
        # CCDC
        cc = [r for r in rows if _tk(d, r, "C").startswith("153") or (_tk(d, r, "C").startswith("242") and re.search("công cụ|ccdc|dụng cụ", K._u(d, r.get("DienGiai")).lower()))]
        if cc:
            o["PB_CCDC"][t] = da_ma(cc)
        elif "PHAN_BO_242" in viec:
            o["PB_CCDC"][t] = ("XEM", "Chi phí trả trước / CCDC 242 chưa phân bổ tháng này", None)
        else:
            o["PB_CCDC"][t] = ("KHONG", "Không có CCDC phân bổ", None)
        # gia thanh
        gt = [v for k, v in viec.items() if k.startswith("GT_")]
        nk = _cap(d, rows, "155", "154") + _cap(d, rows, "632", "154")
        if gt:
            o["GIA_THANH"][t] = ("CAN" if any(v[0] == "NANG" for v in gt) else "XEM", " ; ".join(v[2] for v in gt)[:250], _ngmax(nk))
        elif nk:
            o["GIA_THANH"][t] = da_ma(nk)
        elif any(_tk(d, r, "N").startswith("154") for r in rows):
            o["GIA_THANH"][t] = ("CAN", "Có tập hợp chi phí 154 nhưng chưa kết chuyển giá thành", None)
        else:
            o["GIA_THANH"][t] = ("KHONG", "Không có chi phí sản xuất", None)
        # TNDN tam nop (thang cuoi quy duong lich)
        if th % 3 == 0:
            q = [r for k in range(1, t + 1) if K.thang_lich(d, k)[0] in (th - 2, th - 1, th) for r in theo.get(k, []) if K._f(r.get("SoPS"))]
            t3334 = _cap(d, q, "821", "3334")
            lai = _ket_qua_quy(d, q)
            if t3334:
                o["TNDN_TAM"][t] = da_ma(t3334)
            elif lai > 0:
                o["TNDN_TAM"][t] = ("XEM", "Quý %d lãi theo sổ khoảng %s - tạm tính %s (20%%), chưa hạch toán 8211 / 3334" % ((th - 1) // 3 + 1, K._dd(lai), K._dd(lai * 0.2)), None)
            else:
                o["TNDN_TAM"][t] = ("KHONG", "Quý không có lãi", None)
        else:
            o["TNDN_TAM"][t] = ("KHONG", "Chỉ làm tháng cuối quý", None)
        # cuoi ky
        if m["n_loi"]:
            o["KIEM_SO"][t] = ("CAN", "%d bút toán lỗi, %d cần xem" % (m["n_loi"], m["n_cb"]), None)
        elif m["n_cb"]:
            o["KIEM_SO"][t] = ("XEM", "%d bút toán cần xem" % m["n_cb"], None)
        else:
            o["KIEM_SO"][t] = ("DA", "Không có bút toán sai", None)
        o["KHOA_SO"][t] = {"DA_KHOA": ("DA", "Đã khoá", None), "DUOC_KHOA": ("XEM", "Đủ điều kiện - bấm Khoá tháng", None)}.get(
            m["tt"], ("CAN", "Chưa khoá được: %d lỗi, %d việc nặng" % (m["n_loi"], m["n_nang"]), None))
        so = defaultdict(set)
        for r in tat:
            if str(r.get("SoHieu") or "").strip():
                so[(K._i(r.get("MaLoai")), str(r.get("SoHieu")).strip())].add(r.get("MaCT"))
        trung = sorted(k[1] for k, v in so.items() if len(v) > 1)
        o["DANH_SO"][t] = ("XEM", "%d số chứng từ trùng: %s" % (len(trung), ", ".join(trung[:8])), None) if trung else ("DA", "Số chứng từ không trùng", None)
        o["BO_KHOA"][t] = ("XEM", "Tháng đã khoá còn %d bút toán lỗi - bỏ khoá để sửa" % m["n_loi"], None) if (m["da_khoa"] and m["n_loi"]) else ("KHONG", "", None)
        _dau_vao(d, o, t, th, nam, m, rows, theo)
        o["XUAT_KHAU"][t] = ("XEM", "Tháng đã khoá - in / xuất sổ lưu trữ", None) if m["da_khoa"] else ("KHONG", "Chưa khoá", None)
    return o


def _du_tk(d, theo, t, tien_to):
    """so du (No - Co) cuoi thang t cua cac TK bat dau bang tien_to."""
    la = {k for k, s in d["tk"].items() if s.startswith(tien_to)}
    du = sum(v for k, v in d["tk_dau"].items() if k in la)
    for k in range(1, t + 1):
        for r in theo.get(k, []):
            p = K._f(r.get("SoPS"))
            if r.get("MaTKNo") in la:
                du += p
            if r.get("MaTKCo") in la:
                du -= p
    return du


def _dau_vao(d, o, t, th, nam, m, rows, theo):
    """GD358f: kiem tra chung tu dau vao cua thang t."""
    bt = m["bt"]
    # hoa don
    tm, cm = _hddt(d, th, nam, False)
    tb, cb = _hddt(d, th, nam, True)
    co133 = any(_tk(d, r, "N").startswith("133") for r in rows)
    if cm or cb:
        o["CT_HOADON"][t] = ("CAN", "Chưa hạch toán: %d hoá đơn mua vào, %d bán ra (tải từ TCT)" % (cm, cb), None)
    elif tm or tb:
        o["CT_HOADON"][t] = ("DA", "%d mua vào, %d bán ra đã khớp sổ" % (tm, tb), None)
    elif co133 or any(_tk(d, r, "C").startswith("3331") for r in rows):
        o["CT_HOADON"][t] = ("XEM", "Sổ có thuế GTGT nhưng chưa tải hoá đơn tháng này từ TCT để đối chiếu", None)
    else:
        o["CT_HOADON"][t] = ("KHONG", "Không có hoá đơn", None)
    # luong
    bl = [r for r in d["bl"] if K._i(r.get("thang")) in (th, t)]
    tong = sum(K._f(r.get("tongthunhap")) for r in bl)
    c334 = sum(K._f(r.get("SoPS")) for r in rows if _tk(d, r, "C").startswith("334"))
    if tong and abs(c334 - tong) > max(1000, tong * 0.01):
        o["CT_LUONG"][t] = ("CAN", "Bảng lương %s, sổ Có 334 %s - lệch %s" % (K._dd(tong), K._dd(c334), K._dd(tong - c334)), None)
    elif tong:
        o["CT_LUONG"][t] = ("DA", "Bảng lương %s người, %s khớp sổ" % (len(bl), K._dd(tong)), None)
    elif c334:
        o["CT_LUONG"][t] = ("XEM", "Sổ có trích lương %s nhưng chưa lập bảng lương tháng trong phần mềm" % K._dd(c334), None)
    else:
        o["CT_LUONG"][t] = ("KHONG", "Không có lương", None)
    # so phu ngan hang
    am112 = [x for x in bt if x["ma"] == "QUY_AM" and str(x.get("co", "")).startswith("112")]
    ps112 = [r for r in rows if _tk(d, r, "N").startswith("112") or _tk(d, r, "C").startswith("112")]
    du112 = _du_tk(d, theo, t, "112")
    if am112:
        o["CT_SOPHU"][t] = ("CAN", am112[0]["mo_ta"] + " - thiếu dòng thu trên sổ phụ?", None)
    elif ps112:
        o["CT_SOPHU"][t] = ("DA", "%d dòng ngân hàng, dư cuối tháng %s - đối chiếu số dư sổ phụ" % (len(ps112), K._dd(du112)), None)
    elif abs(du112) > 1000:
        o["CT_SOPHU"][t] = ("XEM", "Tài khoản ngân hàng dư %s nhưng tháng này không có phát sinh - chưa nhập sổ phụ?" % K._dd(du112), None)
    else:
        o["CT_SOPHU"][t] = ("KHONG", "Không dùng ngân hàng", None)
    # thu chi tien mat
    am111 = [x for x in bt if x["ma"] == "QUY_AM" and str(x.get("co", "")).startswith("111")]
    tm5 = [x for x in bt if x["ma"] == "TM_5TR"]
    if am111:
        o["CT_THUCHI"][t] = ("CAN", am111[0]["mo_ta"], None)
    elif tm5:
        o["CT_THUCHI"][t] = ("XEM", "%d phiếu chi tiền mặt từ 5 triệu có thuế đầu vào (không được khấu trừ)" % len(tm5), None)
    elif any(_tk(d, r, "N").startswith("111") or _tk(d, r, "C").startswith("111") for r in rows):
        o["CT_THUCHI"][t] = ("DA", "Quỹ tiền mặt không âm, dư cuối tháng %s" % K._dd(_du_tk(d, theo, t, "111")), None)
    else:
        o["CT_THUCHI"][t] = ("KHONG", "Không có thu chi tiền mặt", None)
    # vay muon
    du341 = -_du_tk(d, theo, t, "341")
    ps_vay = [r for r in rows if any(_tk(d, r, b).startswith(("341", "1388", "3388")) for b in "NC")]
    thieu = [x for x in bt if x["ma"] == "THIEU_DT" and (str(x.get("no", "")) + str(x.get("co", ""))).find("88") >= 0]
    lai = any(_tk(d, r, "N").startswith("635") for r in rows)
    if du341 < -1000:
        o["CT_VAY"][t] = ("CAN", "Vay 341 dư Nợ %s (trả nhiều hơn vay) - kiểm tra hợp đồng vay / ghi nhầm TK" % K._dd(-du341), None)
    elif thieu:
        o["CT_VAY"][t] = ("CAN", "%d dòng 1388 / 3388 thiếu đối tượng (người cho mượn / mượn)" % len(thieu), None)
    elif du341 > 1000 and not lai:
        o["CT_VAY"][t] = ("XEM", "Đang vay %s nhưng tháng này chưa có chi phí lãi vay (Nợ 635)" % K._dd(du341), None)
    elif du341 > 1000 or ps_vay:
        o["CT_VAY"][t] = ("DA", "Dư vay 341 %s; %d dòng vay / mượn trong tháng" % (K._dd(max(du341, 0)), len(ps_vay)), None)
    else:
        o["CT_VAY"][t] = ("KHONG", "Không có vay, mượn", None)
    # cong no
    thieu_cn = [x for x in bt if x["ma"] == "THIEU_DT" and (str(x.get("no", "")) + " " + str(x.get("co", ""))).split()[0:2] and
                (str(x.get("no", "")).startswith(("131", "331")) or str(x.get("co", "")).startswith(("131", "331")))]
    d131, d331 = _du_tk(d, theo, t, "131"), -_du_tk(d, theo, t, "331")
    nguoc = []
    if d131 < -1000:
        nguoc.append("131 dư Có %s" % K._dd(-d131))
    if d331 < -1000:
        nguoc.append("331 dư Nợ %s" % K._dd(-d331))
    if thieu_cn:
        o["CT_CONGNO"][t] = ("CAN", "%d dòng 131 / 331 thiếu đối tượng" % len(thieu_cn), None)
    elif nguoc:
        o["CT_CONGNO"][t] = ("XEM", "Tổng dư ngược bên: " + ", ".join(nguoc) + " - kiểm tra trả trước / ghi nhầm", None)
    elif any(_tk(d, r, b).startswith(("131", "331")) for r in rows for b in "NC"):
        o["CT_CONGNO"][t] = ("DA", "Phải thu %s, phải trả %s cuối tháng" % (K._dd(d131), K._dd(d331)), None)
    else:
        o["CT_CONGNO"][t] = ("KHONG", "Không có công nợ", None)


def phan_tich(d, tu=1, den=None):
    kq = K.phan_tich(d, tu, den)
    o = danh_gia(d, kq)
    tiep = next((m for m in kq["thang"] if not m["da_khoa"]), None)
    kq["tiep"] = tiep["t"] if tiep else 0
    kq["tiep_th"] = tiep["th"] if tiep else ""
    nv = []
    for nhom, ma, ten, cach, noi in NV:
        cot = o.get(ma, {})
        da = [(t, x) for t, x in sorted(cot.items()) if x[0] == "DA"]
        gan = ""
        if da:
            t, x = da[-1]
            gan = (K._nd(x[2]) if x[2] else "") + (" (tháng %s)" % next(m["th"] for m in kq["thang"] if m["t"] == t))
        hien = cot.get(kq["tiep"], ("KHONG", "", None)) if kq["tiep"] else ("DA", "Đã khoá hết", None)
        nv.append({"nhom": nhom, "ma": ma, "ten": ten, "cach": cach, "noi": noi, "gan": gan.strip(), "hien": hien,
                   "n_can": sum(1 for x in cot.values() if x[0] == "CAN"), "n_da": len(da), "o": cot})
    kq["nv"] = nv
    return kq


def ghi(kq, thu_muc):
    p1, p2 = K.ghi(kq, thu_muc)
    s = K._s
    L = ["TONG;%s;%d;%d;%d;%s;%s;%s" % (s(kq["so"]), kq["nam"], kq["tu"], kq["den"], _dt.datetime.now().strftime("%d/%m/%Y %H:%M"), s(kq["ten"])[:80], kq["tiep_th"])]
    for n in kq["nv"]:
        L.append("NV;%s;%s;%s;%s;%s;%d;%d;%s;%s" % (n["nhom"], n["ma"], s(n["ten"]), s(n["gan"]), n["hien"][0] + "|" + s(n["hien"][1])[:200], n["n_can"], n["n_da"], s(n["cach"])[:400], s(n["noi"])))
        for t, x in sorted(n["o"].items()):
            L.append("O;%s;%d;%s;%s" % (n["ma"], t, x[0], s(x[1])[:200]))
    pt = os.path.join(thu_muc, TEP + ".txt")
    with io.open(pt, "w", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")
    ph = os.path.join(thu_muc, TEP + ".html")
    with io.open(ph, "w", encoding="utf-8") as f:
        f.write(_html(kq))
    return pt, ph


def _html(kq):
    e = html.escape
    th = [m for m in kq["thang"]]
    p = ["<!doctype html><html lang='vi'><head><meta charset='utf-8'><title>Nghiệp vụ định kỳ</title><style>"
         "body{font-family:Segoe UI,Arial,sans-serif;background:#f4f6f8;color:#17212b;margin:0;padding:16px;font-size:14px}h1{font-size:21px;margin:0 0 4px}"
         "h2{font-size:17px;margin:20px 0 8px}.mu{color:#5a6672}.card{background:#fff;border:1px solid #d6dce2;border-radius:8px;padding:6px 14px;margin:10px 0}"
         ".nv{display:flex;gap:12px;align-items:flex-start;border-bottom:1px solid #eef1f4;padding:10px 0}.nv:last-child{border:0}.ten{font-weight:600;min-width:260px;flex:1}"
         ".tag{color:#fff;border-radius:4px;padding:2px 8px;font-weight:600;font-size:12px;white-space:nowrap}.cach{color:#3a4652;font-size:13px;margin-top:3px}"
         ".gan{font-size:12px;color:#5a6672}table{border-collapse:collapse;width:100%}th,td{border:1px solid #e1e6ea;padding:4px 5px;font-size:12px;text-align:center}"
         "td.l{text-align:left}.sc{overflow-x:auto}.o{display:inline-block;width:14px;height:14px;border-radius:3px}</style></head><body>"]
    p.append("<h1>Thực hiện nghiệp vụ định kỳ – %s</h1><p class='mu'>%s · năm %d · tháng %d → %d · tháng cần khoá tiếp: <b>%s</b> · máy chỉ đọc sổ, mọi bút toán do người dùng bấm ghi.</p>" % (
        e(kq["ten"]), e(kq["so"]), kq["nam"], kq["tu"], kq["den"], e(kq["tiep_th"] or "đã khoá hết")))
    for nh, ten_nh in NHOM:
        p.append("<h2>%s</h2><div class='card'>" % ten_nh)
        for n in [x for x in kq["nv"] if x["nhom"] == nh]:
            tt = TT_TEN[n["hien"][0]]
            p.append("<div class='nv'><div class='ten'>%s<div class='cach'>%s</div><div class='gan'>Lần thực hiện gần nhất: %s · Làm ở: %s</div></div>"
                     "<div><span class='tag' style='background:%s'>%s</span><div class='gan' style='max-width:300px'>%s</div></div></div>" % (
                         e(n["ten"]), e(n["cach"]), e(n["gan"] or "chưa có"), e(n["noi"]), tt[1], tt[0], e(n["hien"][1])))
        p.append("</div>")
    p.append("<h2>Bảng theo dõi từng tháng</h2><div class='sc'><table><tr><th>Nghiệp vụ</th>%s</tr>" % "".join("<th>%s</th>" % m["th"][:5] for m in th))
    for n in kq["nv"]:
        p.append("<tr><td class='l'>%s</td>%s</tr>" % (e(n["ten"]), "".join(
            "<td title='%s'><span class='o' style='background:%s'></span></td>" % (e(TT_TEN[n["o"][m["t"]][0]][0] + ": " + n["o"][m["t"]][1]) if m["t"] in n["o"] else "", TT_TEN[n["o"][m["t"]][0]][1] if m["t"] in n["o"] else "#fff")
            for m in th)))
    p.append("</table></div><p class='gan'>Xanh: đã làm · Đỏ: cần làm · Cam: cần xem · Xám: không phát sinh.</p>")
    k = K._html(kq)
    a, b = k.find("<body>"), k.rfind("</body>")
    p.append("<h2 style='margin-top:30px'>Chi tiết khoá sổ từng tháng (bút toán sai, việc cần làm, đã làm)</h2>" + k[a + 6:b])
    p.append("</body></html>")
    return "".join(p)


def chay(duong, tu=1, den=None, thu_muc=None):
    d = K.doc(duong)
    kq = phan_tich(d, tu, den)
    return (kq,) + ghi(kq, thu_muc or os.path.join(HERE, "ket-qua"))


def main(argv):
    t = {}
    for a in argv[1:]:
        if a.startswith("/") and ":" in a:
            k, v = a[1:].split(":", 1)
            t[k.lower()] = v.strip('"')
    if not t.get("so"):
        print('python nghiep_vu_dinh_ky.py /so:"<so.MDB>" [/tu:1] [/den:12] [/ra:<thu muc>]')
        return 1
    kq, p1, p2 = chay(t["so"], int(t.get("tu") or 1), int(t.get("den") or 0) or None, t.get("ra"))
    for n in kq["nv"]:
        print("%-11s %-5s can %2d da %2d | %s | %s" % (n["ma"], n["hien"][0], n["n_can"], n["n_da"], n["gan"], n["hien"][1][:70]))
    print(p2)
    return 0


if __name__ == "__main__":
    import sys
    sys.exit(main(sys.argv))
