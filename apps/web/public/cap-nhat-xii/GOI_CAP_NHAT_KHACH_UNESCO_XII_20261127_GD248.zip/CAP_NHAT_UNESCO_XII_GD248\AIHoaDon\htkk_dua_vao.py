# -*- coding: utf-8 -*-
"""GD122 / GD125 - DUA TO KHAI THANG VAO HTKK + MO HTKK THEO MST CONG TY.
GD125: chon MST trong danh sach dang nhap HTKK (khong go chu), dua cua so len truoc roi bam, lam lai khi HTKK mo lai man
hinh dang nhap (tu cap nhat); MST chua co trong HTKK -> cho nguoi dung khai Thong tin chung roi tu dua to khai vao.

Truoc GD122: UNESCO lap tep XML (dang tep HTKK ket xuat) -> nguoi dung tu mo HTKK, tu go MST, tu chon ky, tu "Nhap XML";
HTKK chi doc cac o co trong tep nhap. GD122 lam nhu cac phan mem ke toan khac (ghi thang vao HTKK):
  1. Doc tep XML to khai (HSoThueDTu/HSoKhaiThue/...) - maTKhai, pbanTKhaiXML, ky, loai (chinh thuc / bo sung), MST.
  2. Tim to khai trong Project\\Menu.xml cua HTKK tren may (MaToKhai + VersionXML) -> cac Sheet (to khai + phu luc).
  3. Moi Sheet co so lieu: lay khuon man hinh cua chinh HTKK InterfaceTemplates\\xml\\<DataFile>_<so>.xml
     (Sections / Cell Path=...), dien Value TUNG O theo Path tu tep XML; o dong (bang ke) -> RowData "a###b###c";
     dung kieu o HTKK: Controltype 2 -> True/False, 14 -> dd/mm/yyyy, so giu nguyen, o so trong -> mac dinh HTKK ("0").
     Thong tin chung (ten, dia chi, CQT...) trong tep XML ma trong -> lay tu DataFiles\\<MST>\\HEADER.xml cua HTKK.
  4. Ghi DataFiles\\<MST>\\<DataFile>_<ky>_<so>.xml dung kieu HTKK tu luu (UTF-8 BOM, CRLF, Sections Version = ban HTKK).
     Ten tep: hoc tu tep HTKK da luu tren may; khong co thi theo mau da doi chieu voi tep HTKK that:
       KieuKy 19 + nop theo CQT (01/GTGT): CQTQL<ma CQT quan ly>_<nganh nghe>_<MMYYYY | QnnYYYY>
       KieuKy 11 / 26 (03/TNDN, BCTC):     <nam>_<ddmmyyyy tu>_<ddmmyyyy den>
       KieuKy 12 (05/QTT-TNCN):             <nam>_<mmyyyy tu>_<mmyyyy den>
       KieuKy 19 khong nop theo CQT (05/KK-TNCN): <MMYYYY | QnnYYYY>
     Kieu ky khac chua co tep that de doi chieu -> khong ghi, bao dung Nhap XML (tru khi hoc duoc ten tu tep HTKK tren may).
  Quy tac 18: KHONG ghi de to khai HTKK dang co tru khi nguoi dung chon ghi de - khi ghi de, sao luu tep cu ra ngoai
  HTKK truoc (AIHoaDon\\htkk-sao-luu\\<MST>\\<thoi diem>\\). MST chua co trong HTKK (chua co HEADER.xml) -> khong tao gi,
  bao nguoi dung dang nhap MST do trong HTKK mot lan. MST tep XML khac MST cong ty -> tu choi.
  Mo HTKK theo MST: mo HTKK roi dien MST cong ty vao o "Ma so thue" cua man hinh dang nhap va bam Dong y
  (man hinh nay chi co MST - khong mat khau, khong chu ky; khong ky / nop thay nguoi dung). MST luon duoc chep vao
  Clipboard de dan tay neu HTKK doi giao dien.
"""
import io
import os
import re
import shutil
import time
import xml.etree.ElementTree as ET
from collections import Counter
from datetime import datetime, timedelta

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SAO_LUU_MAC_DINH = os.path.join(BASE_DIR, "htkk-sao-luu")

# o man hinh (khong co trong XML) cua 01/GTGT: tieu muc hach toan -> ten (danh muc HTKK)
TIEU_MUC_TEN = {
    "1701": "Thuế giá trị gia tăng hàng sản xuất, kinh doanh trong nước (gồm cả dịch vụ trong lĩnh vực dầu khí)",
}
# thong tin chung de trong trong XML -> lay tu HEADER.xml (ten the XML -> PropertyInfo HEADER)
HEADER_THEO_THE = {"phuongXa": "tenXaPhuongNNT"}
# cac nut chi la thong tin phan mem / to khai (khong co o tren man hinh HTKK) - khong tinh "so lieu chua vao".
# TTinChung (ten, dia chi, CQT, ngay lap...): HTKK lay tu HEADER.xml cua MST khi mo to khai, khong luu trong tep to khai.
NUT_KHONG_CO_O = ("TTinChung", "TTinDVu", "mst_cu", "maTKhai", "tenTKhai", "moTaBMau", "pbanTKhaiXML", "KyKKhaiThue", "loaiTKhai", "soLan",
                  "GiaHan", "CKyDTu", "maHuyenNNT", "tenHuyenNNT")


# ---------------------------------------------------------------------------
#  DOC TEP
# ---------------------------------------------------------------------------
def doc_chu(p):
    with open(p, "rb") as f:
        b = f.read()
    if b[:2] in (b"\xff\xfe", b"\xfe\xff"):
        return b.decode("utf-16")
    if b[:3] == b"\xef\xbb\xbf":
        return b[3:].decode("utf-8")
    try:
        return b.decode("utf-8")
    except UnicodeDecodeError:
        return b.decode("utf-16") if b[1:2] == b"\x00" else b.decode("latin-1")


_RE_KB = re.compile(r"<\?xml[^>]*\?>")
_RE_DT = re.compile(r"<!DOCTYPE[^>]*>")


def phan_tich(s):
    """chuoi XML (co the co khai bao / DOCTYPE) -> (Element, doctype)."""
    dt = _RE_DT.search(s)
    s2 = _RE_DT.sub("", _RE_KB.sub("", s, count=1), count=1).strip()
    return ET.fromstring(s2), (dt.group(0) if dt else "")


def _bo_ns(goc):
    for n in goc.iter():
        if isinstance(n.tag, str) and "}" in n.tag:
            n.tag = n.tag.split("}", 1)[1]
        for k in list(n.attrib):
            if "}" in k:
                del n.attrib[k]
    return goc


def _con(cha, ten):
    if cha is None:
        return None
    for c in cha:
        if c.tag == ten:
            return c
    tl = ten.lower()
    for c in cha:
        if isinstance(c.tag, str) and c.tag.lower() == tl:
            return c
    return None


def _tim(cha, seg):
    n = cha
    for s in seg:
        n = _con(n, s)
        if n is None:
            return None
    return n


def _seg(p):
    return [s for s in str(p or "").replace("\\", "/").split("/") if s]


class ToKhai(object):
    """Tep XML to khai (dang HTKK ket xuat) da bo vung ten."""

    def __init__(self, duong):
        self.duong = duong
        goc, _dt = phan_tich(doc_chu(duong))
        self.goc = _bo_ns(goc)
        if self.goc.tag != "HSoThueDTu":
            raise ValueError("không phải tờ khai XML HTKK (thiếu HSoThueDTu)")
        self.hs = _con(self.goc, "HSoKhaiThue")
        self.pluc = _con(self.hs, "PLuc")
        self.ct = _con(self.hs, "CTieuTKhaiChinh")
        t = "HSoKhaiThue/TTinChung/TTinTKhaiThue/TKhaiThue/"
        g = self.lay
        self.ma = g(t + "maTKhai")
        self.pban = g(t + "pbanTKhaiXML")
        self.ten = g(t + "tenTKhai")
        self.kieu_ky = g(t + "KyKKhaiThue/kieuKy").upper()
        self.ky = g(t + "KyKKhaiThue/kyKKhai")
        self.loai = (g(t + "loaiTKhai") or "C").upper()
        self.so_lan = re.sub(r"\D", "", g(t + "soLan")) or "0"
        self.ma_cqt = g(t + "maCQTNoiNop")
        self.mst = re.sub(r"[^0-9-]", "", g("HSoKhaiThue/TTinChung/TTinTKhaiThue/NNT/mst"))
        self.nganh = g("HSoKhaiThue/CTieuTKhaiChinh/ma_NganhNghe")
        self.tieu_muc = g("HSoKhaiThue/CTieuTKhaiChinh/tieuMucHachToan")
        self.d1, self.d2 = self._ky(t)
        self.dung = set()

    def lay(self, p):
        n = _tim(self.goc, _seg(p))
        return (n.text or "").strip() if n is not None and not len(n) else ""

    def _ky(self, t):
        g = self.lay
        tu, den = g(t + "KyKKhaiThue/kyKKhaiTuNgay"), g(t + "KyKKhaiThue/kyKKhaiDenNgay")
        d1 = _ngay(tu)
        d2 = _ngay(den)
        if d1 and d2:
            return d1, d2
        tt, dt = g(t + "KyKKhaiThue/kyKKhaiTuThang"), g(t + "KyKKhaiThue/kyKKhaiDenThang")
        m1, m2 = re.fullmatch(r"(\d{1,2})/(\d{4})", tt), re.fullmatch(r"(\d{1,2})/(\d{4})", dt)
        if m1 and m2:
            a = datetime(int(m1.group(2)), int(m1.group(1)), 1)
            b = _cuoi_thang(int(m2.group(2)), int(m2.group(1)))
            return a, b
        ky = self.ky
        m = re.fullmatch(r"(\d)/(\d{4})", ky)
        if self.kieu_ky == "Q" and m:
            q, y = int(m.group(1)), int(m.group(2))
            return datetime(y, 3 * q - 2, 1), _cuoi_thang(y, 3 * q)
        m = re.fullmatch(r"(\d{1,2})/(\d{4})", ky)
        if m:
            y, th = int(m.group(2)), int(m.group(1))
            return datetime(y, th, 1), _cuoi_thang(y, th)
        m = re.fullmatch(r"(\d{4})", ky)
        if m:
            y = int(ky)
            return datetime(y, 1, 1), datetime(y, 12, 31)
        return None, None


def _ngay(s):
    s = str(s or "").strip()
    for f in ("%d/%m/%Y", "%Y-%m-%d"):
        try:
            return datetime.strptime(s[:10], f)
        except Exception:
            pass
    return None


def _cuoi_thang(y, m):
    return (datetime(y + (m == 12), m % 12 + 1, 1) - timedelta(days=1))


def tim_nut_xml(tk, p):
    """Path cua o HTKK -> nut trong XML. Tuyet doi 'HSoThueDTu/...' hoac tuong doi tu PLuc ('PLuc_03_1A_TNDN/ct04')."""
    s = _seg(p)
    if not s:
        return None
    if s[0] == "HSoThueDTu":
        return _tim(tk.goc, s[1:])
    for base in (tk.pluc, tk.hs, tk.ct):
        if base is not None:
            n = _tim(base, s)
            if n is not None:
                return n
    return None


# ---------------------------------------------------------------------------
#  HTKK TREN MAY: MENU, KHUON, HEADER, PHIEN BAN
# ---------------------------------------------------------------------------
def _so_pb(v):
    return tuple(int(x) for x in re.findall(r"\d+", v or "0"))


def doc_menu(goc_htkk):
    cay = ET.parse(os.path.join(goc_htkk, "Project", "Menu.xml")).getroot()
    ds = []
    theo_id = {}                                  # GD197: duong menu (Ke khai -> nhom -> to khai) de tu mo to khai
    for m in cay.iter():
        if isinstance(m.tag, str) and m.tag.split("}")[-1] == "Menu" and m.get("ID"):
            theo_id.setdefault(m.get("ID"), (m.get("ParentID") or "", m.get("Caption") or ""))

    def _duong(m):
        d, cha, lan = [m.get("Caption") or ""], m.get("ParentID") or "", 0
        while cha and cha in theo_id and lan < 8:
            d.insert(0, theo_id[cha][1])
            cha, lan = theo_id[cha][0], lan + 1
        return [x for x in d if x]
    for m in cay.iter():
        if not isinstance(m.tag, str) or m.tag.split("}")[-1] != "Menu" or not m.get("MaFile"):
            continue
        sh = [dict(x.attrib) for x in m.iter() if isinstance(x.tag, str) and x.tag.split("}")[-1] == "Sheet"]
        ds.append({"MaFile": m.get("MaFile"), "MaToKhai": (m.get("MaToKhai") or "").strip(),
                   "VersionXML": (m.get("VersionXML") or "").strip(), "KieuKy": (m.get("KieuKy") or "").strip(),
                   "NopTheoTinhCQT": (m.get("NopTheoTinhCQT") or "").strip(),
                   "ten": m.get("TenToKhai") or m.get("Caption") or m.get("MaFile"), "sheets": sh,
                   "duong": _duong(m)})
    return ds


def tim_menu(ds, ma, pban):
    cung = [m for m in ds if m["MaToKhai"] == str(ma or "").strip()]
    if not cung:
        return None
    for m in cung:
        if m["VersionXML"] == pban:
            return m
    return max(cung, key=lambda m: _so_pb(m["VersionXML"]))


def tep_khuon(thu_xml, data_file, so):
    """'<DataFile>_<so>.xml' (khuon man hinh, KHONG phai khuon nhap '_xml_'); khong co thi ban gan nhat <= so."""
    p = os.path.join(thu_xml, "%s_%s.xml" % (data_file, so))
    if os.path.isfile(p):
        return p
    ds = []
    try:
        for f in os.listdir(thu_xml):
            m = re.match(re.escape(data_file) + r"_(\d+)\.xml$", f, re.I)
            if m:
                ds.append((int(m.group(1)), os.path.join(thu_xml, f)))
    except Exception:
        return ""
    if not ds:
        return ""
    ds.sort()
    duoi = [x for x in ds if so.isdigit() and x[0] <= int(so)]
    return (duoi or ds)[-1][1]


def phien_ban_htkk(goc_htkk):
    try:
        with io.open(os.path.join(goc_htkk, "version", "version.inf"), "r", encoding="utf-8-sig", errors="replace") as f:
            return f.read().strip()
    except Exception:
        return ""


def thu_muc_mst(goc_htkk, mst):
    so = re.sub(r"[^0-9-]", "", str(mst or ""))
    for ten in dict.fromkeys([so, so.replace("-", "")]):
        if ten and os.path.isdir(os.path.join(goc_htkk, "DataFiles", ten)):
            return os.path.join(goc_htkk, "DataFiles", ten)
    return ""


def doc_header(thu_mst):
    """HEADER.xml -> {'p31': ..., 'tenNNT': ...} (theo Path va theo PropertyInfo)."""
    d = {}
    p = os.path.join(thu_mst, "HEADER.xml")
    if not os.path.isfile(p):
        return d
    try:
        g, _ = phan_tich(doc_chu(p))
    except Exception:
        return d
    for c in g.iter("Cell"):
        v = (c.get("Value") or "").strip()
        for k in (c.get("Path"), c.get("PropertyInfo")):
            k = (k or "").strip()
            if k and k not in d:
                d[k] = v
    return d


# ---------------------------------------------------------------------------
#  TEN TEP HTKK
# ---------------------------------------------------------------------------
_RE_TEP = re.compile(r"^(bs\d+_)?(.+)_(\d{3,4})\.xml$", re.I)


def hinh_ten(giua):
    """'CQTQL80115_00_Q042024' -> '{CQT}_{NGANH}_{KY}'; '2024_01012024_31122024' -> '{NAM}_{TU8}_{DEN8}'. Khong ro -> None."""
    tok = giua.split("_")
    n6 = sum(1 for t in tok if re.fullmatch(r"\d{6}", t))
    ra = []
    for t in tok:
        if re.fullmatch(r"CQTQL\d+", t, re.I):
            ra.append("{CQT}")
        elif re.fullmatch(r"Q\d{6}", t, re.I):
            ra.append("{KY}")
        elif re.fullmatch(r"\d{8}", t):
            ra.append("{TU8}" if "{TU8}" not in ra else "{DEN8}")
        elif re.fullmatch(r"\d{6}", t):
            ra.append("{KY}" if n6 == 1 else ("{TU6}" if "{TU6}" not in ra else "{DEN6}"))
        elif re.fullmatch(r"\d{4}", t):
            ra.append("{NAM}")
        elif re.fullmatch(r"\d{2}", t) and ra and ra[-1] == "{CQT}":
            ra.append("{NGANH}")
        else:
            return None
    return "_".join(ra)


_HINH_CACHE = {}


def hoc_hinh_ten(goc_htkk, data_files):
    """Hinh ten tep HTKK da luu tren may (moi thu muc MST) cho cac DataFile cua mot to khai -> hinh pho bien nhat."""
    khoa = (goc_htkk, tuple(sorted(set(data_files))))
    if khoa not in _HINH_CACHE:
        _HINH_CACHE[khoa] = _hoc_hinh_ten(goc_htkk, data_files)
    return _HINH_CACHE[khoa]


def _hoc_hinh_ten(goc_htkk, data_files):
    dem = Counter()
    dfs = sorted(set(data_files), key=len, reverse=True)
    thu = os.path.join(goc_htkk, "DataFiles")
    try:
        ds_mst = [e.path for e in os.scandir(thu) if e.is_dir()]
    except Exception:
        return None
    for d in ds_mst[:3000]:
        try:
            for e in os.scandir(d):
                m = _RE_TEP.match(e.name)
                if not m:
                    continue
                than = m.group(2)
                for df in dfs:
                    if than.lower().startswith(df.lower() + "_"):
                        h = hinh_ten(than[len(df) + 1:])
                        if h:
                            dem[h] += 1
                        break
        except Exception:
            continue
    return dem.most_common(1)[0][0] if dem else None


def hinh_mac_dinh(menu):
    """-> (hinh, da_doi_chieu). Da doi chieu voi tep HTKK 5.x that: 01/GTGT, 03/TNDN, BCTC B01a, 05/QTT-TNCN, 05/KK-TNCN."""
    kk = menu.get("KieuKy", "")
    if kk in ("11", "26"):
        return "{NAM}_{TU8}_{DEN8}", True
    if kk == "12":
        return "{NAM}_{TU6}_{DEN6}", True
    if kk == "19":
        if menu.get("NopTheoTinhCQT"):
            return "{CQT}_{NGANH}_{KY}", True
        return "{KY}", True                  # 05/KK-TNCN: 05_KK_TNCN_TT80_Q012023_251.xml, ..._MMYYYY_251.xml (tep HTKK that)
    if kk in ("35", "21") and menu.get("NopTheoTinhCQT"):
        # GD172: 01/CNKD ho kinh doanh - TT40 (kieu 35) tep HTKK that: 01_CNKD_TT40_CQTQL<cqt>_Q032024_072024_092024_274.xml;
        # TT50 (kieu 21, thang / quy / lan phat sinh) chua co tep that -> du doan cung hinh (hoc tu tep da luu khi co)
        return "{CQT}_{KY}_{TU6}_{DEN6}", kk == "35"
    return None, False


def _ky_tu_ten(ten):
    """Ky trong ten tep HTKK -> (nam, thang cuoi ky) de xep moi / cu: _092026_ -> (2026, 9); _Q032024_ -> (2024, 9);
    _2023_ (nam) -> (2023, 12). Khong co -> None."""
    m = re.search(r"_Q(0[1-4])(\d{4})(?:_|\.)", ten)
    if m:
        return int(m.group(2)), int(m.group(1)) * 3
    m = re.search(r"_(0[1-9]|1[0-2])(\d{4})(?:_|\.)", ten)
    if m:
        return int(m.group(2)), int(m.group(1))
    m = re.search(r"_CQTQL\d+_(\d{4})_", ten)
    if m:
        return int(m.group(1)), 12
    return None


def ma_cqt_quan_ly(thu_mst, header, tk, ky_bo=""):
    """Ma CQT quan ly trong ten tep (CQTQL<ma>). GD196 (anh Thang 11/10/2026): HEADER p31 co the la ma CQT CU (Truong Thanh:
    p31 = 70134, nhung tu 01/2026 HTKK luu tep CQTQL70101 = maCQTNoiNop sau sap nhap co quan thue) -> UNESCO ghi tep 70134,
    HTKK mo tep 70101 trong -> to khai chi co [22]. Thu tu: (1) ma CQT cua tep HTKK luu gan nhat THEO KY (khong theo gio sua,
    bo ky dang ghi - tep UNESCO vua ghi khong tu nuoi sai), (2) HEADER p31 (HTKK cu dat ten theo p31, vd 80115 khi
    maCQTNoiNop = 80100 cap cuc), (3) maCQTNoiNop."""
    moi = []
    try:
        for e in os.scandir(thu_mst):
            m = re.search(r"_CQTQL(\d+)_", e.name)
            if not m or (ky_bo and ("_%s_" % ky_bo) in e.name):
                continue
            k = _ky_tu_ten(e.name)
            if k:
                moi.append((k, e.stat().st_mtime, m.group(1)))
    except Exception:
        pass
    if moi:
        return max(moi)[2]
    for v in (header.get("p31", ""), header.get("maCQTNoiNop", ""), tk.ma_cqt or ""):
        v = re.sub(r"\D", "", v or "")
        if v:
            return v
    return ""


def ky_ten_tep(tk):
    """Phan ky trong ten tep (MMYYYY / QnnYYYY) - giong dien_ten."""
    d1, d2 = tk.d1, tk.d2
    if not d1 or not d2:
        return ""
    if tk.kieu_ky in ("Q", "M"):
        q = tk.kieu_ky == "Q"
    else:
        q = d1.day == 1 and (d1.month - 1) % 3 == 0 and d2 == _cuoi_thang(d1.year, d1.month + 2)
    return ("Q%02d%04d" % ((d1.month - 1) // 3 + 1, d1.year)) if q else ("%02d%04d" % (d1.month, d1.year))


def dien_ten(hinh, tk, cqt):
    d1, d2 = tk.d1, tk.d2
    if not d1 or not d2:
        raise ValueError("tờ khai không có kỳ kê khai")
    if tk.kieu_ky in ("Q", "M"):
        q = tk.kieu_ky == "Q"
    else:
        q = d1.day == 1 and (d1.month - 1) % 3 == 0 and d2 == _cuoi_thang(d1.year, d1.month + 2)
    ky = ("Q%02d%04d" % ((d1.month - 1) // 3 + 1, d1.year)) if q else ("%02d%04d" % (d1.month, d1.year))
    nam = tk.ky if re.fullmatch(r"\d{4}", tk.ky or "") else str(d1.year)
    if "{CQT}" in hinh and not cqt:
        raise ValueError("chưa có mã CQT quản lý trong HTKK (Thông tin chung của MST)")
    rep = {"{CQT}": "CQTQL" + (cqt or ""), "{NGANH}": tk.nganh or "00", "{KY}": ky, "{NAM}": nam,
           "{TU8}": d1.strftime("%d%m%Y"), "{DEN8}": d2.strftime("%d%m%Y"),
           "{TU6}": d1.strftime("%m%Y"), "{DEN6}": d2.strftime("%m%Y")}
    s = hinh
    for k, v in rep.items():
        s = s.replace(k, v)
    return s


def _ky_regex(hinh, than_ky):
    """Phan ky cua ten tep -> regex khop DUNG ky / nganh / ma CQT (to khai cung ky nop cho CQT khac la to khai khac:
    khong chan, khong xoa)."""
    return re.escape(than_ky)


# ---------------------------------------------------------------------------
#  DIEN KHUON MAN HINH (Sections)
# ---------------------------------------------------------------------------
def gia_o(txt, ct, mac):
    v = str(txt or "").strip()
    ct = str(ct or "")
    if v in ("...", "\u2026", ".."):            # GD125: chu mac dinh phan mem (vd nguoi ky chua khai) -> de trong (HTKK lay HEADER)
        v = ""
    if ct == "2":
        return "True" if v.lower() in ("1", "true", "x", "có", "co") else "False"
    if ct == "14":
        m = re.fullmatch(r"(\d{4})-(\d{2})-(\d{2})(T.*)?", v)
        return "%s/%s/%s" % (m.group(3), m.group(2), m.group(1)) if m else v
    if ct == "16" and v == "":
        return mac if mac not in (None, "") else "0"
    return v


def _o_rieng(df, p, o, tk, mst):
    """O chi co tren man hinh HTKK (Path khong co '/'): da doi chieu voi tep HTKK luu that."""
    dfu = df.upper()
    ct = o.get("Controltype") or ""
    if p == "nullAB36":                       # 03/TNDN: MST tren dau to khai
        return mst
    if dfu.startswith("01_GTGT"):
        if p == "path_1":
            return tk.tieu_muc or None
        if p == "path_2":
            return TIEU_MUC_TEN.get(tk.tieu_muc or "")
        if p == "K47":
            return "0" if tk.loai == "B" else "1"
    if re.match(r"133_B01[AB]_", dfu) and tk.d1 and tk.d2:
        if p.startswith("path_null_") and ct == "2":
            return "True"
        if re.fullmatch(r"D\d+", p) and ct == "2":
            return "False"
        if p == "F97":
            return tk.d1.strftime("%d/%m/%Y")
        if p == "H97":
            return tk.d2.strftime("%d/%m/%Y")
    return None


def _goc_pl(sections):
    """Ten nut phu luc (doan dau Path tuong doi) ma khuon dung."""
    ds = set()
    for o in sections.iter("Cell"):
        s = _seg(o.get("Path"))
        if len(s) > 1 and s[0] != "HSoThueDTu":
            ds.add(s[0])
    for sec in sections.iter("Section"):
        s = _seg(sec.get("TablePath"))
        if len(s) > 1 and s[0] != "HSoThueDTu":
            ds.add(s[0])
    return ds


def co_so_lieu_pl(sections, tk):
    return any(_con(tk.pluc, x) is not None for x in _goc_pl(sections)) if tk.pluc is not None else False


def _dich_o(o, dich):
    """HTKK chen dong bang ke thi cac o NAM DUOI bang doi so dong: CellID (dong tren khuon) va CellID2 (dong tren
    bao cao) cong them (so dong - 1) cua moi bang o phia tren (Location giu toa do khuon) - da doi chieu tep that."""
    for thuoc, k in (("CellID", 0), ("CellID2", 1)):
        m = re.fullmatch(r"([A-Z]+)_(\d+)", o.get(thuoc) or "")
        if not m:
            continue
        r = int(m.group(2))
        cong = sum(n for moc, n in ((x[k], x[2]) for x in dich) if moc and r > moc)
        if cong:
            o.set(thuoc, "%s_%d" % (m.group(1), r + cong))


def _doi_loc(sec, cong):
    """GD324: doi Location cua bang ke xuong 'cong' dong (TableTemplate/Report, DataLocationTemplate/Report)."""
    loc = sec.find("Location")
    if loc is None:
        return
    for ten in ("TableTemplateRowStart", "TableReportRowStart", "DataLocationTemplateRowStart", "DataLocationReportRowStart"):
        x = loc.find(ten)
        if x is not None and (x.text or "").strip().isdigit():
            x.text = str(int(x.text.strip()) + cong)


def _so_loc(sec, ten):
    loc = sec.find("Location")
    n = loc.find(ten) if loc is not None else None
    try:
        return int((n.text or "").strip()) if n is not None else 0
    except ValueError:
        return 0


def dien_sections(sections, tk, df, mst, header, kq):
    """Dien Value moi o + RowData bang ke + doi dong cac o duoi bang. kq: {'o','dien','thieu':[],'dong':0}."""
    dich = []
    cong = 0
    for sec in sections.iter("Section"):
        if sec.get("Dynamic") == "1":
            moc = (_so_loc(sec, "DataLocationTemplateRowStart"), _so_loc(sec, "DataLocationReportRowStart"))
            n = _dien_bang(sec, tk, kq)
            # GD324: bang ke NAM DUOI mot bang ke da chen them dong -> HTKK luu Location da DOI xuong (cong so dong them cua cac
            # bang phia tren; DataLocationTaiBangKeRowStart giu nguyen) - da doi chieu 200+ tep HTKK luu that. Truoc day giu toa do
            # khuon -> PL 142/174/204 muc II hien dong so lieu len dai tieu de, tong cong 0, [09] sai.
            if cong:
                _doi_loc(sec, cong)
            if n > 1:
                dich.append((moc[0], moc[1], n - 1))
                cong += n - 1
    for sec in sections.iter("Section"):
        if sec.get("Dynamic") == "1":
            continue
        if dich:
            for o in sec.iter("Cell"):
                _dich_o(o, dich)
        for o in sec.iter("Cell"):
            p = (o.get("Path") or "").strip()
            if not p:
                continue
            ct = o.get("Controltype")
            if "/" not in p:
                v = _o_rieng(df, p, o, tk, mst)
                if v is not None:
                    o.set("Value", v)
                continue
            kq["o"] += 1
            n = tim_nut_xml(tk, p)
            if n is None or len(n):
                kq["thieu"].append(p)
                continue
            tk.dung.add(id(n))
            v = gia_o(n.text, ct, o.get("Value"))
            if v == "" and "/TTinChung/" in p and "/DLyThue/" not in p:
                ten = _seg(p)[-1]
                v = header.get(HEADER_THEO_THE.get(ten, ten), "") or v
            o.set("Value", v)
            kq["dien"] += 1


def _dien_bang(sec, tk, kq):
    s = _seg(sec.get("TablePath"))
    if not s:
        return 0
    cha = tim_nut_xml(tk, "/".join(s[:-1])) if len(s) > 1 else tk.pluc
    if cha is None:
        return 0
    ten = s[-1].lower()
    dong = [c for c in cha if isinstance(c.tag, str) and c.tag.lower() == ten]
    if not dong:
        return 0
    ri = sec.find("RowInfo")
    cot = ri.findall("Cell") if ri is not None else []
    row_path = (ri.get("RowPath") or "").strip() if ri is not None else ""
    if row_path:
        # GD172: bang LONG (01/CNKD: moi phan tu TablePath la mot KHOI dia diem kinh doanh - o Header theo Path tuong doi;
        # dong bang ke = con RowPath cua khoi). Chi dien duoc khoi dau (HTKK nhan ban khoi theo TableLength); khoi sau bao thieu.
        khoi, dong = dong, []
        hd = sec.find("Header")
        for i_k, kb in enumerate(khoi):
            if i_k > 0:
                kq["thieu"].append("%s[%d] (khối địa điểm thứ %d - nhập tay trên HTKK)" % (s[-1], i_k + 1, i_k + 1))
                continue
            for o in (hd.findall("Cell") if hd is not None else []):
                p = (o.get("Path") or "").strip()
                if not p or p.lower().startswith("path"):
                    continue
                kq["o"] += 1
                n = _tim(kb, _seg(p))
                if n is not None and not len(n):
                    tk.dung.add(id(n))
                    o.set("Value", gia_o(n.text, o.get("Controltype"), o.get("Value") or ""))
                    kq["dien"] += 1
            dong.extend(c for c in kb if isinstance(c.tag, str) and c.tag.lower() == row_path.lower())
        if not dong:
            return 0
    try:
        cot_stt = _chu_cot(int(sec.get("iColumnSTT") or 0))
    except ValueError:
        cot_stt = ""
    for r in sec.findall("RowData"):
        sec.remove(r)
    for i, d in enumerate(dong, 1):
        tk.dung.add(id(d))
        gt = []
        for c in cot:
            p = (c.get("Path") or "").strip()
            ct, mac = c.get("Controltype"), c.get("Value") or ""
            o_man_hinh = p.lower().startswith("path")          # path_1, pathStt, pathMucL, pathE: o rieng man hinh HTKK
            if o_man_hinh and (p in ("path_1", "pathStt") or (cot_stt and c.get("CellID") == cot_stt)):
                v = str(i)                                     # cot STT
            elif p and not o_man_hinh:
                n = _tim(d, _seg(p))
                if n is not None and not len(n):
                    tk.dung.add(id(n))
                    v = gia_o(n.text, ct, mac)
                    kq["dien"] += 1
                else:
                    v = "False" if ct == "2" else mac
                kq["o"] += 1
            else:
                v = mac                                        # vd "Mục I" / "Mục II" cua bang ke PL 142
            gt.append(v.replace("###", "# # #"))
        e = ET.SubElement(sec, "RowData")
        e.set("RowDisplay", "1")
        e.text = "###".join(gt)
    sec.set("MaxRows", str(len(dong)))
    kq["dong"] += len(dong)
    return len(dong)


def _chu_cot(i):
    """2 -> 'B', 27 -> 'AA' (cot Excel cua cot STT trong bang HTKK)."""
    r = ""
    while i > 0:
        i, m = divmod(i - 1, 26)
        r = chr(65 + m) + r
    return r


def so_lieu_chua_vao(tk):
    """La XML co so (khac rong / 0) ma khong o nao cua HTKK nhan -> danh sach Path (de bao, khong im lang mat so)."""
    ra = []

    def di(n, duong):
        for c in n:
            if not isinstance(c.tag, str) or c.tag in NUT_KHONG_CO_O:
                continue
            p = duong + "/" + c.tag
            if len(c):
                if id(c) in tk.dung:
                    continue          # dong bang ke da vao (cot thua da tinh khi duyet dong)
                di(c, p)
            else:
                v = (c.text or "").strip()
                if v and v not in ("0", "0.0", "false", "False") and id(c) not in tk.dung and not p.endswith("/NNT/mst"):
                    ra.append(p.lstrip("/"))
    if tk.hs is not None:
        di(tk.hs, "HSoKhaiThue")
    return ra


def ghi_sections(sections, doctype, duong, pban):
    if pban:
        sections.set("Version", pban)
    try:
        ET.indent(sections, space="  ")
    except Exception:
        pass
    txt = ET.tostring(sections, encoding="unicode")
    dau = '<?xml version="1.0" encoding="utf-8"?>\n'
    if doctype:
        dau += (doctype if doctype.endswith("[]>") else doctype[:-1] + "[]>") + "\n"
    tam = duong + ".unesco_tmp"
    with io.open(tam, "w", encoding="utf-8-sig", newline="\r\n") as f:
        f.write(dau + txt)
    os.replace(tam, duong)


# ---------------------------------------------------------------------------
#  DUA VAO HTKK
# ---------------------------------------------------------------------------
def _goc_htkk(goc_htkk):
    if goc_htkk:
        return goc_htkk
    try:
        import tool_htkk_unesco as X
        h = X.tim_htkk()
        return (h or {}).get("goc", "")
    except Exception:
        return ""


def thu_muc_sao_luu(goc):
    """Thu muc sao luu MOI cho moi lan ghi de (ngay gio + micro giay; tao bang exist_ok=False -> hai lan ghi de cung
    mot giay khong bao gio dung chung thu muc / ghi de ban sao luu truoc)."""
    for i in range(1000):
        p = os.path.join(goc, datetime.now().strftime("%Y%m%d_%H%M%S_%f") + ("_%d" % i if i else ""))
        try:
            os.makedirs(p, exist_ok=False)
            return p
        except FileExistsError:
            continue
    raise RuntimeError("không tạo được thư mục sao lưu mới trong %s" % goc)


def dua_vao(duong_xml, mst="", goc_htkk="", ghi_de=False, sao_luu="", log=None):
    """Mot tep XML to khai -> cac tep man hinh HTKK trong DataFiles\\<MST>.
    -> {'ok', 'loi', 'ten_tk', 'thu_muc', 'tep': [{'ten','o','dien','dong','thieu'}], 'bo_qua': [], 'canh_bao': [], 'chua_vao': []}"""
    log = log or (lambda s: None)
    kq = {"ok": False, "loi": "", "xml": duong_xml, "ten_tk": os.path.basename(duong_xml), "thu_muc": "", "tep": [], "bo_qua": [],
          "canh_bao": [], "chua_vao": [], "sao_luu": ""}
    try:
        tk = ToKhai(duong_xml)
    except Exception as e:
        kq["loi"] = "Không đọc được tờ khai %s: %s" % (os.path.basename(duong_xml), e)
        return kq
    goc_htkk = _goc_htkk(goc_htkk)
    if not goc_htkk or not os.path.isfile(os.path.join(goc_htkk, "Project", "Menu.xml")):
        kq["loi"] = "Không tìm thấy HTKK trên máy (Hệ thống > Nguồn HTKK, tờ khai và BCTC kỳ trước... > Chỉ đường HTKK, chọn HTKK.exe)."
        return kq
    mst_tk = re.sub(r"[^0-9-]", "", tk.mst)
    mst = re.sub(r"[^0-9-]", "", str(mst or "")) or mst_tk
    if mst_tk and mst and mst_tk.replace("-", "") != mst.replace("-", ""):
        kq["loi"] = "MST trong tờ khai (%s) khác MST công ty đang làm (%s) - không đưa vào HTKK." % (mst_tk, mst)
        return kq
    thu = thu_muc_mst(goc_htkk, mst)
    if not thu or not os.path.isfile(os.path.join(thu, "HEADER.xml")):
        kq["loi"] = ("HTKK trên máy chưa có MST %s. Bấm Mở HTKK: phần mềm điền sẵn MST, anh khai \"Thông tin chung\" "
                     "(tên, địa chỉ, cơ quan thuế) một lần rồi Ghi - phần mềm tự đưa tờ khai này vào HTKK ngay sau đó." % mst)
        kq["thieu_mst"] = mst            # GD125: ghi vao ket-qua\HTKK_CHO_MST.txt (ghi_cho_ghi_de) - tu dua vao khi HTKK co MST
        return kq
    kq["thu_muc"] = thu
    try:
        menu = tim_menu(doc_menu(goc_htkk), tk.ma, tk.pban)
    except Exception as e:
        kq["loi"] = "Không đọc được Menu.xml của HTKK: %s" % e
        return kq
    if not menu:
        kq["loi"] = "HTKK trên máy không có tờ khai mã %s (%s) - cập nhật HTKK mới." % (tk.ma, tk.ten or kq["ten_tk"])
        return kq
    kq["ten_tk"] = menu["ten"]
    if menu["VersionXML"] != tk.pban and tk.pban:
        kq["canh_bao"].append("Tờ khai lập theo mẫu %s, HTKK trên máy là %s - đã điền theo mẫu của HTKK."
                              % (tk.pban, menu["VersionXML"]))
    header = doc_header(thu)
    pban_htkk = phien_ban_htkk(goc_htkk)
    so = re.sub(r"\D", "", menu["VersionXML"])
    thu_xml = os.path.join(goc_htkk, "InterfaceTemplates", "xml")
    dfs = [s.get("DataFile", "") for s in menu["sheets"] if s.get("DataFile")]
    hinh, da_doi_chieu = hinh_mac_dinh(menu)     # mau da doi chieu tep HTKK that (khong phai quet 1.000+ thu muc MST)
    if not (hinh and da_doi_chieu):
        hoc = hoc_hinh_ten(goc_htkk, dfs)
        if hoc:
            hinh, da_doi_chieu = hoc, True
    if not hinh:
        kq["loi"] = "Chưa biết cách HTKK đặt tên tệp cho %s (kiểu kỳ %s) - dùng \"Nhập XML\" trong HTKK." % (
            menu["ten"], menu["KieuKy"])
        return kq
    if not da_doi_chieu:
        kq["canh_bao"].append("Tên tệp %s theo dự đoán (máy chưa có tờ khai này do HTKK lưu để đối chiếu): nếu mở HTKK "
                              "không thấy số liệu thì dùng \"Nhập XML\" với tệp %s." % (menu["MaFile"], os.path.basename(duong_xml)))
    cqt = ma_cqt_quan_ly(thu, header, tk, ky_ten_tep(tk)) if "{CQT}" in hinh else ""
    try:
        than_ky = dien_ten(hinh, tk, cqt)
    except Exception as e:
        kq["loi"] = "%s: %s" % (menu["ten"], e)
        return kq
    tien_to = ("bs%s_" % (int(tk.so_lan) or 1)) if tk.loai == "B" else ""
    if tien_to:
        kq["canh_bao"].append("Tờ khai bổ sung lần %s: mở trong HTKK, kiểm sheet KHBS (HTKK tự lập) trước khi ghi." % (int(tk.so_lan) or 1))
    viec = []
    for i, sh in enumerate(menu["sheets"]):
        df = sh.get("DataFile", "")
        if not df or df.upper().startswith("KHBS") or sh.get("Active") == "0":
            continue
        kh = tep_khuon(thu_xml, df, so)
        if not kh:
            if i == 0:
                kq["loi"] = "Không thấy khuôn màn hình %s_%s.xml trong %s" % (df, so, thu_xml)
                return kq
            nut = _con(tk.pluc, _seg(sh.get("XMLnode"))[-1]) if tk.pluc is not None and sh.get("XMLnode") else None
            if nut is not None and any((x.text or "").strip() not in ("", "0") for x in nut.iter() if not len(x)):
                kq["canh_bao"].append("Phụ lục %s có số liệu nhưng HTKK trên máy thiếu khuôn %s_%s.xml - nhập tay phụ lục này "
                                      "hoặc cập nhật HTKK." % (sh.get("SheetName", df), df, so))
            continue
        try:
            sections, doctype = phan_tich(doc_chu(kh))
        except Exception as e:
            kq["canh_bao"].append("Khuôn %s lỗi: %s" % (os.path.basename(kh), e))
            continue
        if i > 0 and not co_so_lieu_pl(sections, tk):
            continue
        so_kh = re.match(r".*_(\d+)\.xml$", kh).group(1)
        ten = "%s%s_%s_%s.xml" % (tien_to, df, than_ky, so_kh)
        viec.append((df, sections, doctype, ten, sh.get("SheetName", df)))
    if not viec:
        kq["loi"] = "Tờ khai không có sheet nào để đưa vào HTKK."
        return kq
    # quy tac 18: to khai cung ky da co trong HTKK (moi sheet, moi phien ban khuon, moi ma CQT) -> khong ghi de neu chua chon
    ds_df = [x.get("DataFile", "") for x in menu["sheets"]
             if x.get("DataFile") and not x.get("DataFile", "").upper().startswith("KHBS")]
    mau_ky = re.compile(r"^(?:%s)_%s_\d+\.xml$" % (re.escape(tien_to) + "(?:" + "|".join(re.escape(x) for x in ds_df) + ")",
                                                   _ky_regex(hinh, than_ky)), re.I)
    ton = sorted(f for f in os.listdir(thu) if mau_ky.match(f))
    if ton and not ghi_de:
        kq["bo_qua"] = ton
        ghi_mo_to_khai(kq, tk, menu, mst, pl=[v[4] for v in viec[1:]])      # GD198: van mo dung to khai nay (sau khi hoi ghi de)
        kq["loi"] = ("HTKK đã có %s kỳ này (%s) - không ghi đè. Muốn thay bằng số liệu mới: chọn \"Ghi đè\" "
                     "(tệp cũ được sao lưu trước)." % (menu["ten"], ", ".join(ton[:3]) + (" ..." if len(ton) > 3 else "")))
        return kq
    if ton:
        bk = thu_muc_sao_luu(os.path.join(sao_luu or SAO_LUU_MAC_DINH, os.path.basename(thu)))
        for f in ton:
            dich = os.path.join(bk, f)
            if os.path.exists(dich):                 # khong bao gio ghi de ban sao luu
                raise RuntimeError("thư mục sao lưu đã có %s - dừng, không ghi đè HTKK" % f)
            shutil.copy2(os.path.join(thu, f), dich)
            if os.path.getsize(dich) != os.path.getsize(os.path.join(thu, f)):
                raise RuntimeError("sao lưu %s không trọn vẹn - dừng, không ghi đè HTKK" % f)
        kq["sao_luu"] = bk
        moi = set(v[3].lower() for v in viec)
        for f in ton:
            if f.lower() not in moi:
                os.remove(os.path.join(thu, f))       # da sao luu: sheet / ban khuon cu cung ky - HTKK chi thay bo moi
        log("[HTKK GD122] sao luu %d tep cu -> %s" % (len(ton), bk))
    # GD196: tep CUNG KY nhung MA CQT KHAC do chinh UNESCO ghi truoc day (ma CQT cu trong HEADER p31) -> HTKK khong mo, de lai
    #   gay hai to khai cung ky. Chi don tep co trong nhat ky UNESCO ("[HTKK GD122] <ten>:"), sao luu truoc roi moi bo.
    if cqt:
        lac = tep_lac_cqt(thu, ds_df, tien_to, than_ky, cqt)
        if lac:
            bk2 = kq["sao_luu"] or thu_muc_sao_luu(os.path.join(sao_luu or SAO_LUU_MAC_DINH, os.path.basename(thu)))
            for f in lac:
                dich = os.path.join(bk2, f)
                if os.path.exists(dich):
                    continue
                shutil.copy2(os.path.join(thu, f), dich)
                if os.path.getsize(dich) == os.path.getsize(os.path.join(thu, f)):
                    os.remove(os.path.join(thu, f))
            kq["sao_luu"] = bk2
            kq["canh_bao"].append("Đã dọn %d tệp cùng kỳ UNESCO ghi nhầm mã CQT cũ (%s) - HTKK dùng mã CQT %s; bản cũ ở %s"
                                  % (len(lac), ", ".join(lac[:2]), cqt, bk2))
            log("[HTKK GD196] don %d tep ma CQT cu cung ky -> %s" % (len(lac), bk2))
    for df, sections, doctype, ten, ten_sheet in viec:
        d = {"ten": ten, "sheet": ten_sheet, "o": 0, "dien": 0, "dong": 0, "thieu": []}
        dien_sections(sections, tk, df, mst, header, d)
        ghi_sections(sections, doctype, os.path.join(thu, ten), pban_htkk)
        kq["tep"].append(d)
        log("[HTKK GD122] %s: %d/%d o, %d dong bang ke" % (ten, d["dien"], d["o"], d["dong"]))
    kq["chua_vao"] = so_lieu_chua_vao(tk)
    kq["ok"] = True
    ghi_mo_to_khai(kq, tk, menu, mst)
    return kq


def tep_lac_cqt(thu, ds_df, tien_to, than_ky, cqt, nhat_ky=None):
    """GD196: tep cung sheet + cung ky nhung CQTQL<ma khac cqt>, CHI tep UNESCO tung ghi (co trong nhat-ky-htkk.txt)."""
    m = re.match(r"CQTQL\d+(_.*)$", than_ky)
    if not m:
        return []
    duoi = m.group(1)
    mau = re.compile(r"^%s(?:%s)_CQTQL(\d+)%s_\d+\.xml$" % (re.escape(tien_to), "|".join(re.escape(x) for x in ds_df), re.escape(duoi)), re.I)
    nk = ""
    try:
        with io.open(nhat_ky or os.path.join(BASE_DIR, "nhat-ky-htkk.txt"), "r", encoding="utf-8", errors="replace") as f:
            nk = f.read()
    except Exception:
        return []
    ra = []
    try:
        for f in sorted(os.listdir(thu)):
            x = mau.match(f)
            if x and x.group(1) != cqt and ("[HTKK GD122] %s:" % f) in nk:
                ra.append(f)
    except Exception:
        pass
    return ra


def mo_ta(kq):
    """Ket qua dua_vao -> cac dong tieng Viet cho 0_KET_QUA.txt / man hinh."""
    d = []
    if not kq.get("ok"):
        d.append("[--] %s: %s" % (kq.get("ten_tk", ""), kq.get("loi", "")))
        return d
    d.append("[OK] %s -> HTKK (%s)" % (kq["ten_tk"], kq["thu_muc"]))
    for t in kq["tep"]:
        d.append("      %s: %d/%d ô có số liệu%s" % (t["ten"], t["dien"], t["o"],
                                                    (", %d dòng bảng kê" % t["dong"]) if t["dong"] else ""))
        if t["thieu"]:
            d.append("        (tệp XML không có %d ô - HTKK để mặc định: %s%s)" % (
                len(t["thieu"]), ", ".join(x.split("/")[-1] for x in t["thieu"][:6]), " ..." if len(t["thieu"]) > 6 else ""))
    if kq.get("chua_vao"):
        d.append("      ! %d chỉ tiêu có số nhưng HTKK không có ô tương ứng: %s" % (
            len(kq["chua_vao"]), ", ".join(kq["chua_vao"][:5])))
    if kq.get("sao_luu"):
        d.append("      Tờ khai cũ trong HTKK đã sao lưu tại: %s" % kq["sao_luu"])
    d.append("      (HTKK đang mở đúng tờ khai này thì đóng tờ khai rồi mở lại để thấy số mới; soát lại trước khi ký / nộp)")
    for c in kq.get("canh_bao") or []:
        d.append("      ! %s" % c)
    return d


TEP_CHO = "HTKK_CHO_GHI_DE.txt"


def duong_cho():
    return os.path.join(BASE_DIR, "ket-qua", TEP_CHO)


def bat():
    """cai-dat.json "htkk_dua_vao": false -> tat tu dua vao HTKK khi xuat XML (mac dinh BAT)."""
    try:
        import json
        with io.open(os.path.join(BASE_DIR, "cai-dat.json"), "r", encoding="utf-8-sig") as f:
            return json.loads(f.read() or "{}").get("htkk_dua_vao", True) is not False
    except Exception:
        return True


def _khoa(p):
    return os.path.normcase(os.path.abspath(p))


def ghi_cho_ghi_de(kqs, duong=None):
    """To khai bi bo qua vi HTKK DA CO cung ky -> ket-qua\\HTKK_CHO_GHI_DE.txt ('<xml>|<mo ta>' moi dong) de nut Mo HTKK
    hoi nguoi dung ghi de. GOP voi danh sach dang co (lan xuat khac van giu): to khai trong kqs con cho -> ghi / cap nhat,
    to khai trong kqs da xong (hoac loi khac) -> bo khoi danh sach. Khong con gi -> xoa tep. -> so to khai dang cho."""
    duong = duong or duong_cho()
    ds = {}
    try:
        if os.path.isfile(duong):
            with io.open(duong, "r", encoding="utf-8-sig", errors="replace") as f:
                for d in f:
                    d = d.rstrip("\r\n")
                    p = d.split("|", 1)[0].strip()
                    if p.lower().endswith(".xml") and os.path.isfile(p):
                        ds[_khoa(p)] = d
    except Exception:
        pass
    for k in kqs:
        if not k.get("xml"):
            continue
        kh = _khoa(k["xml"])
        if not k.get("ok") and k.get("bo_qua"):
            ds[kh] = "%s|%s (%s)" % (k["xml"], k.get("ten_tk", ""), ", ".join(k["bo_qua"][:2]))
        else:
            ds.pop(kh, None)
    ghi_cho_mst(kqs, os.path.join(os.path.dirname(duong), TEP_CHO_MST))     # GD125: to khai cho MST chua co trong HTKK
    try:
        if not ds:
            if os.path.isfile(duong):
                os.remove(duong)
            return 0
        os.makedirs(os.path.dirname(duong), exist_ok=True)
        with io.open(duong, "w", encoding="utf-8", newline="\r\n") as f:
            for d in ds.values():
                f.write(d + "\n")
    except Exception:
        pass
    return len(ds)


# ---------------------------------------------------------------------------
#  GD125 - TO KHAI CHO MST CHUA CO TRONG HTKK
# ---------------------------------------------------------------------------
TEP_CHO_MST = "HTKK_CHO_MST.txt"
TEP_THEO_DOI = "HTKK_THEO_DOI.txt"


def _so(mst):
    return re.sub(r"\D", "", str(mst or ""))


def _doc_cho_mst(duong):
    ds = {}
    try:
        if os.path.isfile(duong):
            with io.open(duong, "r", encoding="utf-8-sig", errors="replace") as f:
                for d in f:
                    p = d.rstrip("\r\n").split("|")
                    if len(p) >= 2 and p[1].lower().endswith(".xml") and os.path.isfile(p[1]):
                        ds[_khoa(p[1])] = "|".join(p)
    except Exception:
        pass
    return ds


def ghi_cho_mst(kqs, duong=None):
    """GD125: to khai CHUA dua vao duoc vi HTKK chua co MST -> ket-qua\\HTKK_CHO_MST.txt ('<mst>|<xml>|<ten>' moi dong).
    Mo HTKK, khai Thong tin chung MST do mot lan -> tool tu dua vao. To khai da vao / da co trong HTKK / loi khac -> bo khoi
    danh sach. Gop voi danh sach dang co. -> so to khai dang cho."""
    duong = duong or os.path.join(BASE_DIR, "ket-qua", TEP_CHO_MST)
    ds = _doc_cho_mst(duong)
    for k in kqs:
        if not k.get("xml"):
            continue
        kh = _khoa(k["xml"])
        m = k.get("thieu_mst") or k.get("giu_cho")
        if m:
            ds[kh] = "%s|%s|%s" % (_so(m) or m, k["xml"], (k.get("ten_tk") or "").replace("|", " "))
        else:
            ds.pop(kh, None)
    try:
        if not ds:
            if os.path.isfile(duong):
                os.remove(duong)
            return 0
        os.makedirs(os.path.dirname(duong), exist_ok=True)
        tam = duong + ".%d.tam" % os.getpid()          # ghi tep tam roi thay (nhieu tien trinh tool cung ghi)
        with io.open(tam, "w", encoding="utf-8", newline="\r\n") as f:
            for d in ds.values():
                f.write(d + "\n")
        os.replace(tam, duong)
    except Exception:
        pass
    return len(ds)


def cho_cua_mst(mst, duong=None):
    """To khai dang cho cua MST -> [duong xml]."""
    duong = duong or os.path.join(BASE_DIR, "ket-qua", TEP_CHO_MST)
    so = _so(mst)
    return [d.split("|")[1] for d in _doc_cho_mst(duong).values() if so and _so(d.split("|")[0]) == so]


def co_mst_htkk(goc_htkk, mst):
    thu = thu_muc_mst(goc_htkk, mst) if goc_htkk else ""
    return bool(thu) and os.path.isfile(os.path.join(thu, "HEADER.xml"))


def dua_vao_dang_cho(goc_htkk, mst, log=None, duong=None):
    """MST da co trong HTKK -> dua cac to khai dang cho vao (KHONG ghi de - quy tac 18). -> (kqs, dong mo ta)."""
    ds = cho_cua_mst(mst, duong)
    if not ds or not co_mst_htkk(goc_htkk, mst):
        return [], []
    kqs, dong = [], []
    for p in ds:
        try:
            k = dua_vao(p, mst, goc_htkk, False, log=log)
        except Exception as e:                  # loi bat ngo: giu trong danh sach cho, lan sau thu lai
            k = {"ok": False, "xml": p, "loi": "lỗi đưa vào HTKK: %s" % e, "ten_tk": os.path.basename(p), "thu_muc": "",
                 "tep": [], "bo_qua": [], "canh_bao": [], "chua_vao": [], "sao_luu": "", "giu_cho": mst}
        kqs.append(k)
        try:
            dong.extend(mo_ta(k))
        except Exception:
            dong.append("[--] %s: %s" % (k.get("ten_tk", ""), k.get("loi", "")))
    ghi_cho_ghi_de(kqs, os.path.join(os.path.dirname(duong), TEP_CHO) if duong else None)
    return kqs, dong


def _danh_sach(nguon):
    """tep .xml | thu muc | tep .txt ('<xml>|...' moi dong) -> cac tep .xml."""
    if os.path.isdir(nguon):
        ds = [os.path.join(nguon, f) for f in sorted(os.listdir(nguon)) if f.lower().endswith(".xml")]
    elif nguon.lower().endswith(".txt") and os.path.isfile(nguon):
        ds = []
        with io.open(nguon, "r", encoding="utf-8-sig", errors="replace") as f:
            for d in f:
                p = d.split("|", 1)[0].strip()
                if p.lower().endswith(".xml") and os.path.isfile(p):
                    ds.append(p)
    else:
        ds = [nguon]
    return bo_trung(ds)


def bo_trung(ds):
    """Bo tep trung (cung duong dan) - giu thu tu."""
    da, ra = set(), []
    for p in ds:
        k = _khoa(p)
        if k not in da:
            da.add(k)
            ra.append(p)
    return ra


def dua_vao_nhieu(nguon, mst="", goc_htkk="", ghi_de=False, sao_luu="", log=None):
    """nguon = tep .xml, thu muc (moi tep .xml trong do) hoac danh sach cho ghi de (.txt). -> (danh sach kq, dong mo ta)."""
    ds = _danh_sach(nguon)
    goc_htkk = _goc_htkk(goc_htkk)
    kqs, dong = [], []
    for p in ds:
        try:
            ToKhai(p)
        except Exception:
            continue                      # tep XML khong phai to khai (vd khuon, bao cao) - bo qua im lang
        k = dua_vao(p, mst, goc_htkk, ghi_de, sao_luu, log)
        kqs.append(k)
        dong.extend(mo_ta(k))
    return kqs, dong


# ---------------------------------------------------------------------------
#  MO HTKK THEO MST (man hinh dang nhap HTKK chi co o Ma so thue)
# ---------------------------------------------------------------------------
def chep_clipboard(s):
    if os.name != "nt":
        return False
    try:
        import subprocess
        r = subprocess.run(["clip"], input=str(s).encode("ascii", "ignore"), timeout=10, creationflags=0x08000000)
        if r.returncode == 0:
            return True
    except Exception:
        pass
    try:
        import ctypes
        from ctypes import wintypes
        u32, k32 = ctypes.windll.user32, ctypes.windll.kernel32
        k32.GlobalAlloc.restype = wintypes.HGLOBAL
        k32.GlobalAlloc.argtypes = [wintypes.UINT, ctypes.c_size_t]
        k32.GlobalLock.restype = wintypes.LPVOID
        k32.GlobalLock.argtypes = [wintypes.HGLOBAL]
        k32.GlobalUnlock.argtypes = [wintypes.HGLOBAL]
        u32.SetClipboardData.argtypes = [wintypes.UINT, wintypes.HANDLE]
        u32.OpenClipboard.argtypes = [wintypes.HWND]
        b = (str(s) + "\0").encode("utf-16-le")
        for _ in range(10):
            if u32.OpenClipboard(None):
                break
            time.sleep(0.1)
        else:
            return False
        try:
            u32.EmptyClipboard()
            h = k32.GlobalAlloc(0x0002, len(b))
            p = k32.GlobalLock(h)
            ctypes.memmove(p, b, len(b))
            k32.GlobalUnlock(h)
            ok = bool(u32.SetClipboardData(13, h))
        finally:
            u32.CloseClipboard()
        return ok
    except Exception:
        return False


NUT_DONG_Y = ("đồng ý", "dong y", "đăng nhập", "dang nhap", "ok", "chấp nhận", "chap nhan")
NHAN_MST = ("mã số thuế", "ma so thue", "mst")
# dau hieu RIENG cua man hinh dang nhap HTKK 5.x (frmFormStart): nut "Ma so moi" / tieu de "Dang nhap vao he thong"
DAU_DANG_NHAP = ("mã số mới", "ma so moi", "đăng nhập vào hệ thống", "dang nhap vao he thong")


_API = []                                       # GD125: dat argtypes mot lan (tool goi hang nghin thong diep)


def _api():
    """user32 / kernel32 co argtypes day du (HWND 64-bit khong bi cat)."""
    if _API:
        return _API[0]
    import ctypes
    from ctypes import wintypes
    u32, k32 = ctypes.windll.user32, ctypes.windll.kernel32
    proc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    u32.EnumWindows.argtypes = [proc, wintypes.LPARAM]
    u32.EnumChildWindows.argtypes = [wintypes.HWND, proc, wintypes.LPARAM]
    u32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    u32.IsWindowVisible.argtypes = [wintypes.HWND]
    u32.IsWindowEnabled.argtypes = [wintypes.HWND]
    u32.IsWindow.argtypes = [wintypes.HWND]
    u32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
    u32.SendMessageTimeoutW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, ctypes.c_void_p, wintypes.UINT,
                                        wintypes.UINT, ctypes.POINTER(ctypes.c_size_t)]
    u32.SendMessageTimeoutW.restype = ctypes.c_ssize_t
    u32.PostMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
    u32.SetForegroundWindow.argtypes = [wintypes.HWND]
    u32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
    u32.IsIconic.argtypes = [wintypes.HWND]
    u32.GetParent.argtypes = [wintypes.HWND]                 # GD125
    u32.GetParent.restype = wintypes.HWND
    u32.GetDlgCtrlID.argtypes = [wintypes.HWND]
    u32.GetForegroundWindow.restype = wintypes.HWND
    u32.GetWindowThreadProcessId.restype = wintypes.DWORD
    k32.GetCurrentThreadId.restype = wintypes.DWORD
    u32.AttachThreadInput.argtypes = [wintypes.DWORD, wintypes.DWORD, wintypes.BOOL]
    u32.BringWindowToTop.argtypes = [wintypes.HWND]
    u32.GetLastActivePopup.argtypes = [wintypes.HWND]
    u32.GetLastActivePopup.restype = wintypes.HWND
    u32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
    k32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    k32.OpenProcess.restype = wintypes.HANDLE
    k32.QueryFullProcessImageNameW.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
    k32.CloseHandle.argtypes = [wintypes.HANDLE]
    _API.append((ctypes, wintypes, u32, k32, proc))
    return _API[0]


def _chu_cs(hwnd):
    """WM_GETTEXT qua SendMessageTimeout: doc duoc chu control cua tien trinh khac, khong treo neu HTKK ban."""
    ctypes, _w, u32, _k, _p = _api()
    buf = ctypes.create_unicode_buffer(512)
    kq = ctypes.c_size_t()
    u32.SendMessageTimeoutW(hwnd, 0x000D, 512, ctypes.cast(buf, ctypes.c_void_p), 0x0002, 1500, ctypes.byref(kq))
    return buf.value


def _cua_so_htkk(exe):
    """Cac cua so cap cao dang hien cua tien trinh HTKK.exe -> [hwnd]."""
    ctypes, wintypes, u32, k32, proc = _api()
    ra = []
    ten_exe = os.path.basename(exe or "HTKK.exe").lower()

    def anh(pid):
        h = k32.OpenProcess(0x1000, False, pid)
        if not h:
            return ""
        try:
            buf = ctypes.create_unicode_buffer(1024)
            n = wintypes.DWORD(1024)
            if k32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(n)):
                return buf.value
        finally:
            k32.CloseHandle(h)
        return ""

    def cb(hwnd, _l):
        if hwnd and u32.IsWindowVisible(hwnd):
            pid = wintypes.DWORD()
            u32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            if os.path.basename(anh(pid.value)).lower() == ten_exe:
                ra.append(hwnd)
        return True
    f = proc(cb)
    u32.EnumWindows(f, 0)
    return ra


def _con_cs(hwnd):
    ctypes, _w, u32, _k, proc = _api()
    ra = []

    def cb(h, _l):
        lop = ctypes.create_unicode_buffer(256)
        u32.GetClassNameW(h, lop, 256)
        ra.append((h, lop.value.upper(), bool(u32.IsWindowVisible(h) and u32.IsWindowEnabled(h))))
        return True
    f = proc(cb)
    u32.EnumChildWindows(hwnd, f, 0)
    return ra


def la_man_dang_nhap(chu_con):
    """chu_con = [(lop, chu, hien)] cac control cua mot cua so -> (chi so o MST, chi so nut Dong y) hoac (None, None).
    Chi nhan khi cua so co nhan 'Ma so thue' + dau hieu rieng man hinh dang nhap HTKK (nut 'Ma so moi' / 'Dang nhap vao he thong')
    + dung MOT o nhap so + nut Dong y (tranh go nham vao o nam / thang hay hop thoai khac cua HTKK)."""
    nhan = any(any(k in (c or "").lower() for k in NHAN_MST) for lop, c, _h in chu_con if "EDIT" not in lop)
    rieng = any(any(k in (c or "").lower().replace("&", "") for k in DAU_DANG_NHAP) for lop, c, _h in chu_con if "EDIT" not in lop)
    if not rieng:
        return None, None
    nut = [i for i, (lop, c, hien) in enumerate(chu_con)
           if hien and "BUTTON" in lop and (c or "").strip().lower().replace("&", "") in NUT_DONG_Y]
    o = [i for i, (lop, c, hien) in enumerate(chu_con) if hien and "EDIT" in lop]
    if not nhan or not nut or len(o) != 1 or not re.match(r"[\d\-]{0,20}(\s|$)", (chu_con[o[0]][1] or "").strip()):
        return None, None
    return o[0], nut[0]


# GD125: thong diep ComboBox (khong con tro / he thong tu chuyen chuoi qua tien trinh voi CB_GETLBTEXT)
CB_GETCOUNT, CB_GETCURSEL, CB_GETLBTEXT, CB_GETLBTEXTLEN, CB_SETCURSEL = 0x0146, 0x0147, 0x0148, 0x0149, 0x014E
WM_COMMAND, CBN_SELCHANGE, CBN_SELENDOK = 0x0111, 1, 9


def _gui(hwnd, msg, wp, lp, cho=2000):
    """SendMessageTimeoutW -> ket qua (so co dau) hoac None khi het gio / loi (HTKK ban khong lam treo tool)."""
    ctypes, _w, u32, _k, _p = _api()
    kq = ctypes.c_size_t()
    try:
        r = u32.SendMessageTimeoutW(hwnd, msg, wp, lp, 0x0002, cho, ctypes.byref(kq))
    except Exception:
        return None
    if not r:
        return None
    return ctypes.c_ssize_t(kq.value).value


def _cac_muc(combo):
    """Chu cac muc cua ComboBox MST cua HTKK. [] khi khong doc duoc (het gio / muc rong) -> go chu nhu cu."""
    ctypes = _api()[0]
    n = _gui(combo, CB_GETCOUNT, 0, None)
    if not n or n < 0 or n > 50000:
        return []
    ra = []
    for i in range(n):
        dai = _gui(combo, CB_GETLBTEXTLEN, i, None)
        if dai is None or dai < 0 or dai > 2000:
            return []
        buf = ctypes.create_unicode_buffer(dai + 2)
        if _gui(combo, CB_GETLBTEXT, i, ctypes.cast(buf, ctypes.c_void_p)) is None:
            return []
        ra.append(buf.value)
    return ra if any(t.strip() for t in ra) else []


def tim_muc(cac_muc, mst):
    """Vi tri muc MST trong danh sach dang nhap HTKK: dung chu MST (co / khong '-'), roi so dau dong (vd '0101234567 - Ten').
    KHONG coi '000000' + MST la cung MST (HTKK co thu muc rieng nhu vay). -> chi so hoac -1."""
    m = str(mst or "").strip()
    so = re.sub(r"\D", "", m)
    if not so:
        return -1
    for i, t in enumerate(cac_muc):
        if t.strip() == m:
            return i
    for i, t in enumerate(cac_muc):
        dau = (t.strip().split() or [""])[0]
        if re.sub(r"\D", "", dau) == so and re.sub(r"[\d\-]", "", dau) == "":
            return i
    return -1


def _bao_chon(combo):
    """Bao HTKK nhu nguoi dung vua chon: WM_COMMAND CBN_SELCHANGE / CBN_SELENDOK len cua so cha (WinForms chuyen ve combo)."""
    _c, _w, u32, _k, _p = _api()
    try:
        cha = u32.GetParent(combo)
        cid = u32.GetDlgCtrlID(combo) & 0xFFFF
        if cha:
            _gui(cha, WM_COMMAND, (CBN_SELCHANGE << 16) | cid, combo)
            _gui(cha, WM_COMMAND, (CBN_SELENDOK << 16) | cid, combo)
    except Exception:
        pass


def _chon_muc(combo, idx):
    """CB_SETCURSEL + bao HTKK. -> True khi CB_GETCURSEL = idx."""
    _gui(combo, CB_SETCURSEL, idx, None)
    _bao_chon(combo)
    return _gui(combo, CB_GETCURSEL, 0, None) == idx


def _bo_chon(combo):
    """Bo muc dang chon (CB_SETCURSEL -1) truoc khi go chu: WinForms co DisplayMember lay Text tu muc dang chon (muc dau)."""
    ctypes = _api()[0]
    _gui(combo, CB_SETCURSEL, ctypes.c_size_t(-1).value, None)
    _bao_chon(combo)


def _len_truoc(hwnd):
    """Dua cua so HTKK len truoc (AttachThreadInput voi cua so dang truoc) - nguoi dung thay ngay man hinh HTKK."""
    _c, _w, u32, k32, _p = _api()
    try:
        if u32.IsIconic(hwnd):
            u32.ShowWindow(hwnd, 9)
        fg = u32.GetForegroundWindow()
        t1 = u32.GetWindowThreadProcessId(fg, None) if fg else 0
        t2 = k32.GetCurrentThreadId()
        noi = bool(t1 and t1 != t2 and u32.AttachThreadInput(t2, t1, True))
        u32.BringWindowToTop(hwnd)
        u32.SetForegroundWindow(hwnd)
        if noi:
            u32.AttachThreadInput(t2, t1, False)
    except Exception:
        pass


def _tim_dang_nhap(exe):
    """Man hinh dang nhap HTKK dang hien -> (hwnd, o Edit MST, nut Dong y) hoac (None, None, None)."""
    for hwnd in _cua_so_htkk(exe):
        con = _con_cs(hwnd)
        chu = [(lop, _chu_cs(h), hien) for h, lop, hien in con]
        io_, in_ = la_man_dang_nhap(chu)
        if io_ is not None:
            return hwnd, con[io_][0], con[in_][0]
    return None, None, None


def _co_cua_so_chinh(exe, bo=()):
    """Co cua so HTKK lon (khong phai man hinh dang nhap, khong phai hop thoai #32770) dang hien = HTKK da vao / dang lam viec."""
    ctypes, wintypes, u32, _k, _p = _api()
    for hwnd in _cua_so_htkk(exe):
        if hwnd in bo:
            continue
        lop = ctypes.create_unicode_buffer(256)
        u32.GetClassNameW(hwnd, lop, 256)
        if lop.value == "#32770":
            continue
        r = wintypes.RECT()
        if not u32.GetWindowRect(hwnd, ctypes.byref(r)) or (r.right - r.left) < 600 or (r.bottom - r.top) < 400:
            continue
        if _tim_dang_nhap_cua(hwnd):
            continue
        return True
    return False


def _tim_dang_nhap_cua(hwnd):
    con = _con_cs(hwnd)
    return la_man_dang_nhap([(lop, _chu_cs(h), hien) for h, lop, hien in con])[0] is not None


def _go_chu(o, mst, combo=None):
    """Go MST vao o Edit (cach cu GD122): bo muc dang chon, xoa, go tung ky tu (WM_CHAR), khong khop thi dat thang (WM_SETTEXT)."""
    ctypes, _w, u32, _k, _p = _api()
    if combo:
        _bo_chon(combo)
    rong = ctypes.create_unicode_buffer("")
    u32.SendMessageTimeoutW(o, 0x000C, 0, ctypes.cast(rong, ctypes.c_void_p), 0x0002, 2000, None)  # WM_SETTEXT ""
    for ch in mst:
        u32.PostMessageW(o, 0x0102, ord(ch), 1)                                                     # WM_CHAR
    time.sleep(0.8)
    if _chu_cs(o).replace("-", "").strip() != mst.replace("-", ""):
        buf = ctypes.create_unicode_buffer(mst)
        u32.SendMessageTimeoutW(o, 0x000C, 0, ctypes.cast(buf, ctypes.c_void_p), 0x0002, 2000, None)
    return _chu_cs(o).replace("-", "").strip() == mst.replace("-", "")


def _dien_mot(hwnd, o, nut, mst, log, exe, goc=""):
    """Mot man hinh dang nhap: chon (hoac go) MST roi bam Dong y, doi man hinh dong.
    -> 'vao' | 'chua_co' (HTKK chua co MST - da go san, KHONG bam) | 'loi:<ly do>'."""
    _c, _w, u32, _k, _p = _api()
    combo = u32.GetParent(o)
    lop = _c.create_unicode_buffer(256)
    u32.GetClassNameW(combo, lop, 256)
    if "COMBOBOX" not in lop.value.upper():
        combo = None
    _len_truoc(hwnd)                              # truoc khi chon: HTKK nap lai danh sach luc Activated thi da xong
    muc = []
    if combo:
        for _ in range(12):                       # HTKK nap danh sach MST sau khi hien man hinh -> doi danh sach on dinh
            muc = _cac_muc(combo)
            time.sleep(0.5)
            if muc and len(_cac_muc(combo)) == len(muc):
                break
    idx = tim_muc(muc, mst) if muc else -1
    co_mst = co_mst_htkk(goc, mst) if goc else False
    log("[HTKK GD125] man hinh dang nhap: %d MST trong danh sach, MST cong ty o vi tri %d%s"
        % (len(muc), idx, "" if not goc else (" (HTKK co thu muc MST)" if co_mst else " (HTKK chua co MST)")))
    if muc and idx < 0 and not co_mst:
        _go_chu(o, mst, combo)                    # HTKK chua co MST nay: go san, KHONG bam (nguoi dung khai Thong tin chung)
        return "chua_co"
    if idx >= 0:
        ok = _chon_muc(combo, idx)
        hien = _chu_cs(o).strip()
        log("[HTKK GD125] chon muc %d: %s, o MST %s" % (idx, "dung" if ok else "CHUA dung", "dung" if hien == muc[idx].strip() else "khac"))
        if not ok:
            idx = -1
            if not _go_chu(o, mst, combo):
                return "loi:HTKK không nhận MST tự điền"
    elif not _go_chu(o, mst, combo):
        return "loi:HTKK không nhận MST tự điền"
    truoc = set(_cua_so_htkk(exe))
    for lan in range(2):
        if lan == 1:                              # bam lai CHI khi man hinh dang nhap van la cua so dang dung (khong co hop thoai)
            if (not u32.IsWindowEnabled(hwnd) or u32.GetLastActivePopup(hwnd) != hwnd
                    or set(_cua_so_htkk(exe)) - truoc):
                return "loi:HTKK đang hiện hộp thoại - xem trên HTKK"
            if idx >= 0:
                _chon_muc(combo, idx)
        if idx >= 0 and _gui(combo, CB_GETCURSEL, 0, None) != idx:
            _chon_muc(combo, idx)
        time.sleep(0.3)
        u32.PostMessageW(nut, 0x00F5, 0, 0)                                                        # BM_CLICK
        log("[HTKK GD122] da dien MST dang nhap HTKK (bam Dong y lan %d)" % (lan + 1))
        for _ in range(30):                       # man hinh dang nhap dong = HTKK da vao MST
            time.sleep(0.5)
            if not u32.IsWindow(hwnd) or not u32.IsWindowVisible(hwnd):
                return "vao"
    return "loi:đã điền MST nhưng HTKK chưa vào - bấm Đồng ý trên HTKK"


def _the_doi(the):
    """Lan Mo HTKK nay da bi lan moi hon thay (HTKK_THEO_DOI.txt doi) -> True: dung moi viec tren HTKK."""
    if not the:
        return False
    return _the(os.path.join(BASE_DIR, "ket-qua", TEP_THEO_DOI)) not in ("", the)


def dien_mst_dang_nhap(mst, exe, cho=90, log=None, goc="", the=None):
    """Cho man hinh dang nhap HTKK -> chon / dien MST + bam Dong y. HTKK tu cap nhat roi mo lai man hinh dang nhap MOI
    -> lam lai (toi da 3 man hinh, canh them 2 phut sau lan dien cuoi). Dung ngay khi: HTKK da vao (thay cua so lam viec),
    nguoi dung tu lam viec tren HTKK, hoac co lan Mo HTKK moi hon (the).
    -> (ok, thong_diep, trang_thai: 'vao' | 'chua_co' | 'loi')."""
    log = log or (lambda s: None)
    if os.name != "nt":
        return False, "chỉ chạy trên Windows", "loi"
    han = time.time() + cho
    da_thay, da_lam, kq = False, [], None
    while time.time() < han:
        if _the_doi(the):
            return False, "có lần Mở HTKK mới - dừng", "loi"
        try:
            ds = _cua_so_htkk(exe)
            da_thay = da_thay or bool(ds)
            hwnd, o, nut = _tim_dang_nhap(exe)
        except Exception as e:
            return False, "không dò được cửa sổ HTKK: %s" % e, "loi"
        if hwnd and hwnd not in da_lam and len(da_lam) < 3:
            da_lam.append(hwnd)
            kq = _dien_mot(hwnd, o, nut, mst, log, exe, goc)
            log("[HTKK GD125] man hinh dang nhap %d: %s" % (len(da_lam), kq))
            if kq == "chua_co":
                return False, ("HTKK chưa có MST %s - đã điền sẵn MST: bấm \"Mã số mới\" để khai Thông tin chung "
                               "(tên, địa chỉ, cơ quan thuế) một lần rồi Ghi" % mst), "chua_co"
            han = max(han, time.time() + 120)     # canh HTKK mo lai man hinh dang nhap (tu cap nhat)
            continue
        if da_lam and not hwnd:
            try:
                xong = _co_cua_so_chinh(exe)
            except Exception:
                xong = False
            if xong:                              # HTKK da vao (hoac nguoi dung dang lam viec) -> khong canh nua
                if kq != "vao":
                    kq = "vao" if not _tim_dang_nhap(exe)[0] else kq
                break
        time.sleep(0.5)
    if kq == "vao" and not _tim_dang_nhap(exe)[0]:
        return True, "đã chọn MST %s và vào HTKK" % mst, "vao"
    if kq and kq != "vao":
        return False, kq.split(":", 1)[-1], "loi"
    if kq == "vao":
        return False, "HTKK lại hiện màn hình đăng nhập - bấm Đồng ý trên HTKK", "loi"
    if da_thay:
        return False, "HTKK đã mở nhưng không thấy màn hình nhập mã số thuế", "loi"
    return False, "chưa thấy cửa sổ HTKK sau %d giây" % cho, "loi"


def _hop_bao(noi_dung, tieu_de="UNESCO AI - HTKK", cho=True):
    """Hop thong bao Windows noi len tren (tool chay nen sau khi VB da nhan ket qua). cho=False: hien o luong rieng,
    tool lam tiep (vd van canh HTKK luu Thong tin chung trong khi hop dang mo)."""
    if os.name != "nt":
        return

    def hien():
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, noi_dung, tieu_de, 0x00000040 | 0x00010000 | 0x00040000)
        except Exception:
            pass
    if cho:
        hien()
    else:
        import threading
        threading.Thread(target=hien).start()


def _the(duong):
    try:
        with io.open(duong, "r", encoding="utf-8") as f:
            return f.read().strip()
    except Exception:
        return ""


def _header_xong(goc_htkk, mst, log):
    """HEADER.xml cua MST da ghi xong: kich thuoc dung yen 2 lan do + doc duoc (tranh doc tep dang ghi do)."""
    thu = thu_muc_mst(goc_htkk, mst)
    p = os.path.join(thu, "HEADER.xml") if thu else ""
    cu = -1
    for _ in range(10):
        time.sleep(2)
        try:
            n = os.path.getsize(p)
        except OSError:
            n = -1
        if n > 0 and n == cu and doc_header(thu):
            return True
        cu = n
    log("[HTKK GD125] HEADER.xml cua MST %s chua on dinh / chua doc duoc" % mst)
    return False


def cho_mst_roi_dua_vao(goc_htkk, mst, log=None, cho=1200, the=None, duong_cho=None):
    """GD125: HTKK chua co MST, co to khai dang cho -> doi HTKK luu HEADER.xml cua MST (nguoi dung khai Thong tin chung)
    roi tu dua to khai vao (khong ghi de) + hop thong bao. Dung khi co lan Mo HTKK moi (the trong HTKK_THEO_DOI.txt doi).
    -> (ok, thong_diep)."""
    log = log or (lambda s: None)
    try:
        het = time.time() + cho
        log("[HTKK GD125] cho HTKK co MST %s (toi da %d phut) de dua %d to khai vao" % (mst, cho // 60, len(cho_cua_mst(mst, duong_cho))))
        while time.time() < het:
            if _the_doi(the):
                return False, "có lần Mở HTKK mới - dừng chờ"
            if co_mst_htkk(goc_htkk, mst):
                if not _header_xong(goc_htkk, mst, log) or _the_doi(the):
                    time.sleep(3)
                    continue
                kqs, dong = dua_vao_dang_cho(goc_htkk, mst, log, duong_cho)
                for d in dong:
                    log(d)
                ok = any(k.get("ok") for k in kqs)
                tb = "\n".join(x.strip() for x in dong if x.strip())[:1500] or "Không có tờ khai nào đang chờ."
                _hop_bao(("Đã đưa tờ khai vào HTKK MST %s:\n\n%s\n\nTrên HTKK mở tờ khai đúng kỳ là thấy số liệu "
                          "(soát lại trước khi ký / nộp)." % (mst, tb)) if ok else ("Chưa đưa được tờ khai vào HTKK MST %s:\n\n%s" % (mst, tb)))
                return ok, tb
            time.sleep(3)
        return False, "hết thời gian chờ HTKK có MST %s" % mst
    except Exception as e:
        log("[HTKK GD125] cho MST loi: %s" % e)
        _hop_bao("Chưa đưa được tờ khai vào HTKK MST %s: %s\nAnh bấm Mở HTKK lại (tờ khai vẫn đang chờ)." % (mst, e))
        return False, "lỗi: %s" % e


TEP_MO_TK = "HTKK_MO_TO_KHAI.json"


def ghi_mo_to_khai(kq, tk, menu, mst, duong=None, pl=None):
    """GD197: to khai vua dua vao HTKK -> ket-qua\\HTKK_MO_TO_KHAI.json (duong menu, ky, phu luc co so lieu) de nut
    Mo HTKK tu mo dung to khai do sau khi dang nhap."""
    try:
        d1 = tk.d1
        kieu = (tk.kieu_ky or "").upper()
        if kieu not in ("M", "Q"):
            kieu = "Y" if d1 and tk.d2 and (tk.d2 - d1).days > 200 else kieu
        ky = ""
        if d1 and kieu == "M":
            ky = str(d1.month)
        elif d1 and kieu == "Q":
            ky = str((d1.month - 1) // 3 + 1)
        o = {"mst": re.sub(r"[^0-9-]", "", str(mst or tk.mst or "")), "duong": menu.get("duong") or [], "ten": kq.get("ten_tk", ""),
             "kieu": kieu, "ky": ky, "nam": str(d1.year) if d1 else "", "lan_dau": (tk.loai != "B"),
             "so_lan": tk.so_lan, "pl": pl if pl is not None else [t["sheet"] for t in kq.get("tep", [])[1:] if t.get("sheet")],
             "luc": time.time()}
        p = duong or os.path.join(BASE_DIR, "ket-qua", TEP_MO_TK)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        import json
        with io.open(p, "w", encoding="utf-8") as f:
            json.dump(o, f, ensure_ascii=False)
    except Exception:
        pass


def mo_to_khai_htkk(h, mst, log=None, duong=None, cho=90):
    """GD197 (anh Thang 11/10/2026): HTKK da vao MST cong ty -> tu bam menu mo DUNG to khai vua dua vao + chon ky, tick
    phu luc, bam Dong y (htkk_mo_to_khai.ps1 - UI Automation cua Windows). Khong chac ky thi de hop chon ky mo cho nguoi
    dung. -> chuoi bao (rong neu khong co to khai vua dua vao / khong phai Windows)."""
    import json
    log = log or (lambda s: None)
    p = duong or os.path.join(BASE_DIR, "ket-qua", TEP_MO_TK)
    try:
        with io.open(p, "r", encoding="utf-8") as f:
            o = json.load(f)
    except Exception:
        return ""
    mst = re.sub(r"[^0-9-]", "", str(mst or ""))
    if not o.get("duong") or (mst and o.get("mst") and o["mst"] != mst) or time.time() - float(o.get("luc") or 0) > 12 * 3600:
        return ""
    ky = ("tháng %s/%s" % (o["ky"], o["nam"])) if o.get("kieu") == "M" else (("quý %s/%s" % (o["ky"], o["nam"])) if o.get("kieu") == "Q" else ("năm %s" % o.get("nam", "")))
    huong = "Trên HTKK chọn %s > %s, kỳ %s rồi bấm Đồng ý." % (" > ".join(o["duong"][:-1]), o["duong"][-1], ky)
    if os.name != "nt":
        return huong
    ps = os.path.join(BASE_DIR, "htkk_mo_to_khai.ps1")
    if not os.path.isfile(ps):
        return huong
    o2 = dict(o, exe=(h or {}).get("exe", ""), cay=os.path.join(BASE_DIR, "ket-qua", "htkk_hop_chon_ky.txt"))
    ts = os.path.join(BASE_DIR, "ket-qua", "htkk_mo_to_khai_ts.json")
    ra = os.path.join(BASE_DIR, "ket-qua", "htkk_mo_to_khai_kq.txt")
    try:
        with io.open(ts, "w", encoding="utf-8") as f:
            json.dump(o2, f, ensure_ascii=False)
        if os.path.exists(ra):
            os.remove(ra)
        import subprocess
        subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-STA", "-File", ps, "-Thamso", ts, "-Ra", ra],
                       timeout=cho, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        dong = io.open(ra, "r", encoding="utf-8-sig").read().splitlines() if os.path.exists(ra) else []
    except Exception as e:
        log("[HTKK GD197] mo to khai loi: %s" % e)
        return huong
    for d in dong:
        log("[HTKK GD197] " + d)
    tt = ([d[8:].strip() for d in dong if d.startswith("KET_QUA ")] or [""])[-1]
    if tt == "DA_MO":
        return "Đã mở %s kỳ %s trên HTKK (kèm %d phụ lục có số liệu) - soát lại rồi Kết xuất XML để ký nộp." % (
            o["duong"][-1], ky, len(o.get("pl") or []))
    if tt == "CHO_NGUOI_DUNG":
        return "Đã mở hộp chọn kỳ của %s - kiểm kỳ %s rồi bấm Đồng ý." % (o["duong"][-1], ky)
    if tt == "DA_BAM_MENU":
        return "Đã bấm mở %s trên HTKK." % o["duong"][-1]
    return huong


def mo_htkk_theo_mst(h, mst, cho=90, log=None, da_mo=None):
    """Mo HTKK va dang nhap san MST cong ty. da_mo(ok, thong_diep): goi NGAY khi da mo HTKK (VB khong phai cho).
    GD125: MST da co trong HTKK + to khai dang cho -> dua vao TRUOC; chon MST trong danh sach (khong go chu); HTKK dang mo
    o man hinh dang nhap -> chon MST + Dong y; dang o man hinh lam viec -> chi dua len truoc. MST chua co trong HTKK -> go
    san MST, cho nguoi dung khai Thong tin chung roi tu dua to khai vao. MST luon chep vao Clipboard de dan tay."""
    log = log or (lambda s: None)
    da_mo = da_mo or (lambda ok, x: None)
    mst = re.sub(r"[^0-9-]", "", str(mst or ""))
    if not h:
        da_mo(False, "Không tìm thấy HTKK trên máy này.")
        return False, "Không tìm thấy HTKK trên máy này."
    goc = h.get("goc", "")
    the = "%d_%d" % (os.getpid(), int(time.time() * 1000))
    try:                                          # lan Mo HTKK nay -> lan truoc dang cho / dang dien (neu co) tu dung
        os.makedirs(os.path.join(BASE_DIR, "ket-qua"), exist_ok=True)
        with io.open(os.path.join(BASE_DIR, "ket-qua", TEP_THEO_DOI), "w", encoding="utf-8") as f:
            f.write(the)
    except Exception:
        pass
    them = ""
    try:
        if mst and goc and cho_cua_mst(mst) and co_mst_htkk(goc, mst):
            kqs, dong = dua_vao_dang_cho(goc, mst, log)
            for d in dong:
                log(d)
            if any(k.get("ok") for k in kqs):
                them = " Đã đưa %d tờ khai đang chờ vào HTKK." % sum(1 for k in kqs if k.get("ok"))
    except Exception as e:
        log("[HTKK GD125] dua to khai dang cho loi: %s" % e)
    clip = chep_clipboard(mst) if mst else False
    goi_y = (" MST %s đã chép sẵn - bấm Ctrl+V vào ô Mã số thuế." % mst) if clip else ""
    dang_mo = []
    if os.name == "nt":
        try:
            dang_mo = _cua_so_htkk(h.get("exe"))
        except Exception:
            dang_mo = []
    if dang_mo:
        dn = (None, None, None)
        try:
            dn = _tim_dang_nhap(h.get("exe"))
        except Exception:
            pass
        if not dn[0]:
            try:
                _c, _w, u32, _k, _p = _api()
                if u32.IsIconic(dang_mo[0]):
                    u32.ShowWindow(dang_mo[0], 9)
                u32.SetForegroundWindow(dang_mo[0])
            except Exception:
                pass
            tb = ("HTKK đang mở sẵn - đã đưa lên trước (không gõ vào cửa sổ đang làm việc). Nếu HTKK đang ở MST khác: "
                  "đóng HTKK rồi bấm Mở HTKK lại, phần mềm tự đăng nhập MST %s." % mst) + them + goi_y
            mo = mo_to_khai_htkk(h, mst, log)            # GD197
            if mo:
                tb = mo + " " + tb
            da_mo(True, tb)
            return True, tb
        da_mo(True, "HTKK đang ở màn hình đăng nhập - phần mềm chọn MST %s." % mst + them)
    else:
        try:
            import tool_htkk_unesco as X
            ok, x = X.mo_htkk(h)
        except Exception as e:
            ok, x = False, str(e)
        if not ok:
            da_mo(False, x)
            return False, x
        da_mo(True, x + them)
    if not mst:
        return True, "Đã mở HTKK (phần mềm chưa có MST công ty để điền sẵn)."
    try:                                          # HTKK da mo: loi tu day khong duoc lam noi goi mo HTKK them lan nua
        ok, tb, tt = dien_mst_dang_nhap(mst, h.get("exe"), cho, log, goc, the)
        if tt == "chua_co" or (not co_mst_htkk(goc, mst) and cho_cua_mst(mst)):
            if cho_cua_mst(mst):
                dau = ("Phần mềm đã điền sẵn MST ở màn hình đăng nhập HTKK: bấm \"Mã số mới\"" if tt == "chua_co"
                       else "Trên HTKK nhập MST %s ở màn hình đăng nhập, bấm \"Mã số mới\"" % mst)
                _hop_bao("HTKK trên máy chưa có MST %s.\n\n%s, khai Thông tin chung (tên, địa chỉ, cơ quan thuế quản lý) rồi "
                         "Ghi.\n\nNgay khi HTKK lưu xong, phần mềm tự đưa %d tờ khai đang chờ vào HTKK (chờ tối đa 20 phút)."
                         % (mst, dau, len(cho_cua_mst(mst))), cho=False)
                ok2, tb2 = cho_mst_roi_dua_vao(goc, mst, log, 1200, the)
                return ok2, "HTKK chưa có MST %s: %s" % (mst, tb2)
            return False, tb + "." + goi_y
        if ok:
            mo = mo_to_khai_htkk(h, mst, log)            # GD197: tu mo dung to khai vua dua vao
            return True, "Đã mở HTKK và " + tb + "." + them + ((" " + mo) if mo else "")
        return True, "Đã mở HTKK; chưa tự điền được MST (%s).%s" % (tb, goi_y)
    except Exception as e:
        log("[HTKK GD125] dien MST loi: %s" % e)
        return True, "Đã mở HTKK; chưa tự điền được MST (%s).%s" % (e, goi_y)
