# -*- coding: utf-8 -*-
"""GD348b - VIEC TU ERP vao hang doi viec cua UNESCO AI (FrmHangDoi). Chi doc hop thu LENH\\ cua tram (erp_tram.json: "lenh") va so.

  lap(duong_so)  -> ds cung dang hang_doi_viec.lap: (muc_so, tram, ma, ten, noi, ket_luan, bo_qua_thi, muc)
      ma = "E|<lenh>|<ma chung tu sai>|<MaCT ke toan hoac rong>|<khoa_tram hoac rong>"   (khong co ';')
      lay tu lenh (cho\\, dang_lam\\, xong\\) co sua[] va so = ten tep so; chi tiet tu ket_qua\\<lenh>.ket_qua.json (hoac da_gui\\);
      ma da co dong ERP_THUCHIEN (erp_thuc_hien) DA_GHI / KHONG_GHI -> khong dua vao hang doi (da tra loi).
  ghi_bo_qua(duong_so, thu_muc) -> ket-qua\\erp_bo_qua.txt  (lenh;ma;khoa_tram;ly_do) - VB (ERP348_ApBoQua) ghi HDDT_KS_BoQua.
Khong ghi gi vao .MDB.
"""
import io
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))


def _s(x):
    return str(x if x is not None else "").replace(";", ",").replace("|", "/").replace("\r", " ").replace("\n", " ").strip()


def hop_thu():
    """Thu muc LENH tu erp_tram.json (ben canh erp_tram.py). Khong co -> ''."""
    p = os.path.join(HERE, "erp_tram.json")
    try:
        with io.open(p, "r", encoding="utf-8-sig") as f:
            return os.path.normpath(str(json.load(f).get("lenh") or ""))
    except (OSError, ValueError, AttributeError):
        return ""


def _doc(p):
    try:
        with io.open(p, "r", encoding="utf-8-sig") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else None
    except (OSError, ValueError):
        return None


def lenh_cua_so(hop, ten_so):
    """-> [(lenh dict, ket_qua dict | None)] cac lenh cua so nay co sua[] hoac bo_qua[] (cho, dang_lam, xong)."""
    out = []
    if not hop or not os.path.isdir(hop):
        return out
    ten = os.path.basename(str(ten_so or "")).lower()
    for tm in ("cho", "dang_lam", "xong"):
        d = os.path.join(hop, tm)
        try:
            teps = sorted(os.listdir(d))
        except OSError:
            continue
        for t in teps:
            if not t.lower().endswith(".json"):
                continue
            L = _doc(os.path.join(d, t))
            if not L or L.get("phien_ban_khuon") != 1 or not isinstance(L.get("lenh"), str):
                continue
            if os.path.basename(str(L.get("so") or "")).lower() != ten:
                continue
            if not (L.get("sua") or L.get("bo_qua")):
                continue
            kq = _doc(os.path.join(hop, "ket_qua", L["lenh"] + ".ket_qua.json")) or _doc(os.path.join(hop, "ket_qua", "da_gui", L["lenh"] + ".ket_qua.json"))
            out.append((L, kq))
    return out


def _chi_tiet(kq):
    """ket_qua.chung_tu_sai[] -> {ma: dong}"""
    d = {}
    for x in (kq or {}).get("chung_tu_sai") or []:
        if isinstance(x, dict) and x.get("ma"):
            d[str(x["ma"])] = x
    return d


def _mact(ma, ct):
    if ct and ct.get("ma_ct") is not None:
        return str(ct["ma_ct"])
    p = str(ma).split(":")
    return p[1] if len(p) >= 3 and p[1].isdigit() and int(p[1]) > 0 else ""


def lap(duong_so, hop=None):
    hop = hop if hop is not None else hop_thu()
    if not duong_so or not hop:
        return []
    try:
        import erp_thuc_hien
        th, _ = erp_thuc_hien.doc(duong_so)
    except Exception:
        th = []
    da = {x.get("khoa_nguon"): x for x in th if x.get("khoa_nguon") and x.get("trang_thai") in ("DA_GHI", "KHONG_GHI")}
    ds, co = [], set()
    for L, kq in lenh_cua_so(hop, duong_so):
        ct = _chi_tiet(kq)
        for s in L.get("sua") or []:
            if not isinstance(s, dict) or not s.get("ma"):
                continue
            ma = str(s["ma"])
            if ma in da or (L["lenh"], ma) in co:
                continue
            co.add((L["lenh"], ma))
            c = ct.get(ma) or {k: v for k, v in s.items() if k in ("ma_loi", "so_ct", "ngay_ct", "tk_no", "tk_co", "so_tien", "mo_ta", "de_xuat", "muc")}     # GD348c: ERP Contracts sua[]
            muc = str(c.get("muc") or "VUA").upper()
            khoa = "E|%s|%s|%s|%s" % (_s(L["lenh"]), _s(ma), _s(_mact(ma, c)), _s(c.get("khoa_tram")))
            ten = "[ERP %s] %s" % (L["lenh"], c.get("ten_loi") or c.get("ma_loi") or "Sửa chứng từ")
            mo_ta = c.get("mo_ta") or s.get("huong_dan") or s.get("mo_ta") or ma
            so_ct = c.get("so_ct") or ""
            noi = "Chứng từ %s%s - bấm Mở nơi làm để mở phiếu, sửa xong bấm Đã làm" % (so_ct or "", (" ngày " + c["ngay_ct"]) if c.get("ngay_ct") else "")
            if not _mact(ma, c):
                noi = "Không có số chứng từ kế toán - làm theo mô tả, xong bấm Đã làm"
            kl = ("%s%s" % (mo_ta, (" | Hướng dẫn ERP: " + str(s["huong_dan"])) if s.get("huong_dan") else ""))
            if c.get("de_xuat"):
                kl += " | Đề xuất: " + str(c["de_xuat"])
            ds.append((0 if muc == "NANG" else 1, 9, khoa, _s(ten), _s(noi), _s(kl)[:600], "ERP nhận KHONG_SUA kèm lý do anh/chị ghi", "LOI" if muc == "NANG" else "CANH_BAO"))
    return ds


def ghi_bo_qua(duong_so, thu_muc, hop=None):
    """ket-qua\\erp_bo_qua.txt: moi dong lenh;ma;khoa_tram (chi dong co khoa_tram). -> so dong."""
    hop = hop if hop is not None else hop_thu()
    dong = []
    if duong_so and hop:
        for L, _kq in lenh_cua_so(hop, duong_so):
            for b in L.get("bo_qua") or []:
                if isinstance(b, dict) and b.get("ma") and b.get("khoa_tram"):
                    dong.append("%s;%s;%s;%s" % (_s(L["lenh"]), _s(b["ma"]), str(b["khoa_tram"]).replace(";", ",").replace("\r", " ").replace("\n", " ")[:250],
                                                 _s(b.get("ly_do"))[:200]))     # GD348c: ly do ke toan ghi tren ERP
    try:
        os.makedirs(thu_muc, exist_ok=True)
        with io.open(os.path.join(thu_muc, "erp_bo_qua.txt"), "w", encoding="utf-8") as f:
            for x in dong:
                f.write(x + "\n")
    except OSError:
        pass
    return len(dong)
