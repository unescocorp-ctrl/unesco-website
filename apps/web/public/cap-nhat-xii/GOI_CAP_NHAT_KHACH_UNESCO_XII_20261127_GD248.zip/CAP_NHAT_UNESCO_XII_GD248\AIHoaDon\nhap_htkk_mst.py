# -*- coding: utf-8 -*-
"""GD168 - NHAP TOAN BO DU LIEU HTKK THEO MST (mot lan) thay vi lay tung mau.

HTKK tren may luu moi to khai trong <HTKK>\\DataFiles\\<MST>\\ : moi sheet (to khai chinh, tung phu luc) la mot tep
"Sections / Section / Cells / Cell Path=... Value=..." (utf-8 hoac utf-16), ten  [bs<n>_]<DataFile>_<ky>[_<phien ban>][ (n)].xml
  - <DataFile> -> MaFile / ten to khai / kieu ky theo <HTKK>\\Project\\Menu.xml (sheet dau = to khai chinh)
  - <ky>: 072026 (thang) / Q032026 (quy) / 2025_01012025_31122025 (nam) ; bs<n>_ = to khai bo sung lan n
  - ban HTKK cu (truoc khi them phien ban vao ten): 01_GTGT_032015.xml, 01_1_GTGT_..., 01A_TNDN_..., 48_01_CDKT_2014.xml ...
  - HEADER.xml / Header_nn.xml: thong tin chung (nguoi ky, co quan thue ...); Session.dat: phien lam viec
Mot lan chay:
 1. Danh muc MOI to khai cua MST (ca dinh dang cu) + thu muc chi nhanh <MST>-xxx (chi dem).
 2. So chuyen ky cho nam tai chinh N cua bo so:
    - BCTC nam N-1 -> bctc_nam_truoc.chay (NAM_TRUOC_<N-1>.txt; VB hoi Dong y moi ghi BCTC_NamTruoc - quy tac 18)
    - so du cuoi nam N-1 tung TK cap 1 (PL_CDTK cua BCTC TT133) <-> so du dau nam N cua so (HethongTK DuNo_0 / DuCo_0)
    - 03/TNDN nam N-1: chi tieu chinh + lo con duoc chuyen sang nam N (PL 03-2A)
    - 01/GTGT gan nhat: [43] -> [22] ky sau; ky trong nam N chua thay to khai
    - 05/KK-TNCN nam N, 05/QTT-TNCN nam N-1
 3. Bao cao (dong [!] / [?] / [i]) + NhapHTKK_<N>.xlsx + <ra>.khoa.txt (KHOA=GIA TRI cho VB: NAMTRUOC, XLSX, LOI, XEM, TO_KHAI).
CHI DOC HTKK va so lieu so; khong ghi HTKK, khong ghi so (ghi BCTC nam truoc do VB hoi rieng)."""
import io
import json
import os
import re
import time
from datetime import date, datetime

import so_sanh_htkk as S

TEN_EXCEL = "NhapHTKK_%d.xlsx"
GIAY = 60
RX_TEP = re.compile(r"^(bs(\d+)_)?(.+?)(?: \((\d+)\))?\.xml$", re.I)
RX_PB = re.compile(r"^(.*)_(\d{3,4})$")
TEN_HO = {"GTGT": "Thuế GTGT", "TNDN": "Quyết toán TNDN", "BCTC": "Báo cáo tài chính", "KK": "Khấu trừ TNCN (05/KK)",
          "QTT": "Quyết toán TNCN (05/QTT)", "TNDN_TT": "Tạm tính TNDN (mẫu cũ)", "HD": "Hoá đơn / ấn chỉ", "DK": "Đăng ký thuế",
          "khac": "Tờ khai khác"}
THU_TU_HO = ["GTGT", "TNDN", "BCTC", "KK", "QTT", "TNDN_TT", "HD", "DK", "khac"]
# ten tep HTKK ban cu (khong co trong Menu.xml hien hanh): (mau, ho, ten)
CU = [(r"^0?1_[12]_GTGT_", "GTGT", "Phụ lục 01-1 / 01-2 GTGT (mẫu cũ)"),
      (r"^0?1[AB]_TNDN_", "TNDN_TT", "Tờ khai tạm tính TNDN 01A / 01B (mẫu cũ)"),
      (r"^48_\d+_(CDKT|SXKD|LCTTTT|LCTTGT|CDTK|BCTC)\d*_", "BCTC", "Báo cáo tài chính QĐ48 (mẫu cũ)"),
      (r"^0?5([ABC]|MT)?_TNCN_", "QTT", "Quyết toán TNCN (mẫu cũ)"),
      (r"^0?[1-4]_(TBAC|MBAI)_", "HD", "Thông báo / mua hoá đơn (mẫu cũ)")]


def _ho(ma_file, ten):
    h = S._ho_tu(ma_file, ten, [])
    if h:
        return h
    m = (ma_file or "").upper()
    if re.match(r"^(BC26|0?[1-4]_TBAC|0?1_MBAI|0?3_DL_HDDT|0?1_AC|0?1_LPMB|BC21|BC01)", m):
        return "HD"
    if re.match(r"^0?5_DK|^16_TH_DKNPT|^20_DK|^0?1_DK", m):
        return "DK"
    if re.match(r"^0?1A?_TNDN|^0?1B_TNDN", m):
        return "TNDN_TT"
    return "khac"


def _menu_df(goc):
    """[(datafile_thuong, MaFile, ten, ho, la_to_khai_chinh)] dai truoc."""
    ra = {}
    menu = S._menu(goc)
    if not menu:                                   # khong doc duoc Menu.xml: DataFile chinh theo ten tep HTKK that
        for ho, ds in S.DF_MAC_DINH.items():
            for d in ds:
                ra.setdefault(d.lower(), (d, TEN_HO.get(ho, ho), ho, True))
    for m in menu:
        mf = m.get("MaFile") or ""
        ten = m.get("ten") or m.get("TenToKhai") or ""
        ho = _ho(mf, ten)
        for i, s in enumerate(m.get("sheets") or []):
            d = (s.get("DataFile") or "").strip()
            if d and d.lower() not in ra:
                ra[d.lower()] = (mf, ten, ho, i == 0)
    return sorted(((k,) + v for k, v in ra.items()), key=lambda x: len(x[0]), reverse=True)


def thu_muc_mst(goc, mst):
    """(thu muc chinh, [(ten chi nhanh, so tep)]) ; '' khi HTKK chua co MST."""
    so = re.sub(r"[^0-9]", "", str(mst or ""))
    if not goc or len(so) not in (10, 13):
        return "", []
    df = os.path.join(goc, "DataFiles")
    chinh, nhanh = "", []
    try:
        ten = sorted(os.listdir(df))
    except OSError:
        return "", []
    for t in ten:
        p = os.path.join(df, t)
        if not os.path.isdir(p):
            continue
        tso = re.sub(r"[^0-9]", "", t)
        if not re.fullmatch(r"[0-9-]+", t):
            continue
        if t == so:
            chinh = p
        elif tso == so:
            chinh = chinh or p
        elif len(so) == 10 and len(tso) == 13 and tso.startswith(so):
            try:
                nhanh.append((t, len(os.listdir(p))))
            except OSError:
                nhanh.append((t, 0))
    return chinh, nhanh


def _phan_tich(f, dfs):
    """ten tep -> dict (ma_file, ten, ho, ky, lan, pb, chinh, cu) hoac None (khong phai to khai)."""
    m = RX_TEP.match(f)
    if not m:
        return None
    lan = int(m.group(2) or 0)
    goc_ten = m.group(3)
    thu = []
    mp = RX_PB.match(goc_ten)
    if mp:
        thu.append((mp.group(1), int(mp.group(2))))
    thu.append((goc_ten, 0))
    for than, pb in thu:
        tl = than.lower()
        for df, mf, ten, ho, chinh in dfs:
            if tl.startswith(df + "_"):
                ky = S._ky_ten_tep(than[len(df) + 1:])
                if ky:
                    return {"ma_file": mf, "ten": ten, "ho": ho, "ky": ky, "lan": lan, "pb": pb, "chinh": chinh, "cu": pb == 0,
                            "than_ky": than[len(df) + 1:], "df": df}
    for mau, ho, ten in CU:
        mm = re.match(mau, goc_ten, re.I)
        if mm:
            ky = S._ky_ten_tep(goc_ten[mm.end():])
            if not ky and re.fullmatch(r"\d{4}", goc_ten[mm.end():]):
                y = int(goc_ten[mm.end():])
                ky = ("Y", date(y, 1, 1), date(y, 12, 31))
            return {"ma_file": mm.group(0).strip("_").upper(), "ten": ten, "ho": ho, "ky": ky, "lan": lan, "pb": 0, "chinh": True,
                    "cu": True, "than_ky": goc_ten[mm.end():], "df": mm.group(0).lower()}
    return None


def danh_muc(goc, mst):
    """Danh muc to khai trong DataFiles\\<MST>: {"thu_muc", "to_khai": [...], "tep", "khong_ro", "header", "chi_nhanh"}"""
    thu, nhanh = thu_muc_mst(goc, mst)
    kq = {"thu_muc": thu, "to_khai": [], "tep": 0, "khong_ro": 0, "header": False, "chi_nhanh": nhanh, "ban_sao": 0, "loi_doc": ""}
    if not thu:
        return kq
    dfs = _menu_df(goc)
    nhom = {}
    try:
        ten_tep = sorted(os.listdir(thu))
    except OSError as e:
        kq["loi_doc"] = str(e)
        return kq
    co = set(x.lower() for x in ten_tep)
    for f in ten_tep:
        p = os.path.join(thu, f)
        if not os.path.isfile(p):
            continue
        kq["tep"] += 1
        if re.match(r"^header(_\d+)?\.xml$", f, re.I):
            kq["header"] = True
            continue
        if not f.lower().endswith(".xml"):
            continue
        if S._la_ban_sao(f, co):
            kq["ban_sao"] += 1                     # "X (1).xml" khi con "X.xml": ban sao (Windows / dong bo) - HTKK chi mo ban goc
            continue
        try:
            x = _phan_tich(f, dfs)
        except Exception:                          # ten tep la (vd nam 0000)
            x = None
        if not x:
            kq["khong_ro"] += 1
            continue
        khoa = (x["ma_file"], x["lan"], x["than_ky"].lower(), x["pb"])
        g = nhom.get(khoa)
        if g is None:
            g = dict(x)
            g.update({"tep": [], "tep_chinh": "", "mtime": 0.0})
            nhom[khoa] = g
        g["tep"].append(p)
        if x["chinh"] and not g["tep_chinh"]:
            g["tep_chinh"] = p
        try:
            g["mtime"] = max(g["mtime"], os.path.getmtime(p))
        except OSError:
            pass
    for g in nhom.values():
        if not g["tep_chinh"]:
            g["tep_chinh"] = g["tep"][0]
            g["thieu_chinh"] = True
    kq["to_khai"] = sorted(nhom.values(), key=lambda g: (THU_TU_HO.index(g["ho"]) if g["ho"] in THU_TU_HO else 99, g["ma_file"],
                                                         g["ky"][2] if g["ky"] else date(1900, 1, 1), g["lan"]))
    return kq


def tom_tat_ho(dm):
    """{ho: {"n", "bs", "dau", "cuoi", "cu", "mau": set}}"""
    t = {}
    for g in dm["to_khai"]:
        x = t.setdefault(g["ho"], {"n": 0, "bs": 0, "dau": None, "cuoi": None, "cu": 0, "mau": set()})
        x["n"] += 1
        x["bs"] += 1 if g["lan"] else 0
        x["cu"] += 1 if g["cu"] else 0
        x["mau"].add(g["ma_file"])
        if g["ky"]:
            if x["dau"] is None or g["ky"][2] < x["dau"][2]:
                x["dau"] = g["ky"]
            if x["cuoi"] is None or g["ky"][2] > x["cuoi"][2]:
                x["cuoi"] = g["ky"]
    return t


# ------------------------------------------------------------------ so du TK: so <-> PL_CDTK HTKK
def doc_so_du_so(p):
    """JSON VB: {"tk": [[so hieu, so TK con, du No dau nam, du Co dau nam], ...]} -> {TK cap 1 PL_CDTK: [No, Co]} (cong TK la)."""
    if not p or not os.path.isfile(p):
        return None
    try:
        with io.open(p, encoding="utf-8-sig") as f:
            d = json.load(f)
    except Exception:
        return None
    import bao_cao_nam as B
    cap1 = sorted(B.CDTK_CAP1, key=len, reverse=True)
    ra = {}
    for r in d.get("tk") or []:
        try:
            sh, con, no, co = str(r[0] or "").strip(), int(float(r[1] or 0)), float(r[2] or 0), float(r[3] or 0)
        except (TypeError, ValueError, IndexError):
            continue
        if con or not sh or not sh[0].isdigit():
            continue
        c = next((a for a in cap1 if sh.startswith(a)), "")
        if not c:
            continue
        x = ra.setdefault(c, [0.0, 0.0])
        x[0] += no
        x[1] += co
    return ra


def so_du_htkk(goc, mst, nam):
    """PL_CDTK (bang can doi tai khoan, BCTC TT133) nam `nam` tren HTKK -> ({TK: [No, Co]} so du cuoi ky, ten tep) ; ({}, '')"""
    try:
        import bao_cao_nam as B
        p = B._tep_htkk(goc, mst, "133_B01A_05_CDTK", nam) if goc else ""
        if not p:
            return {}, ""
        d = B._doc_cell(p)
    except Exception:
        return {}, ""
    ra = {}
    for k, v in d.items():
        m = re.search(r"PL_CDTK/SoDuCuoiKy/(No|Co)/ct(\w+)$", k)
        if m:
            x = ra.setdefault(m.group(2), [0.0, 0.0])
            x[0 if m.group(1) == "No" else 1] += S._so(v) or 0.0
    return ra, os.path.basename(p)


def so_sanh_so_du(so, ht):
    """-> (dong bang [(TK, ten, so No, so Co, HTKK No, HTKK Co, chenh rong)], [canh bao])"""
    import bao_cao_nam as B
    bang, cb = [], []
    if not ht:
        return bang, cb
    tong_so = sum(abs(a) + abs(b) for a, b in (so or {}).values())
    lech = []
    for tk in B.CDTK_CAP1:
        a = (so or {}).get(tk, [0.0, 0.0])
        h = ht.get(tk, [0.0, 0.0])
        if not any(a) and not any(h):
            continue
        ch = round((a[0] - a[1]) - (h[0] - h[1]))
        bang.append((tk, B.CDTK_TEN.get(tk, ""), a[0], a[1], h[0], h[1], ch))
        if abs(ch) >= 1:
            lech.append("TK %s sổ %s / HTKK %s" % (tk, S._vn(a[0] - a[1]), S._vn(h[0] - h[1])))
    if so is None:
        cb.append(("i", "Chưa đọc được số dư đầu năm của sổ - chỉ liệt kê số dư cuối năm trước trên HTKK (%d TK)." % len(bang)))
    elif tong_so < 1:
        cb.append(("?", "Sổ CHƯA có số dư đầu năm (mọi TK bằng 0) trong khi HTKK có số dư cuối năm trước ở %d TK - nhập số dư đầu kỳ "
                        "(theo TK chi tiết / đối tượng) hoặc bấm Ghi số liệu BCTC năm trước để B01 có cột Số đầu năm. "
                        "Nếu số dư nhập bằng chứng từ đầu năm thì bỏ qua." % len(bang)))
    elif lech:
        cb.append(("!", "Số dư đầu năm của sổ (ròng Nợ - Có, cộng TK chi tiết) khác số dư cuối năm trước trên HTKK ở %d TK: %s%s." % (
            len(lech), "; ".join(lech[:8]), " ..." if len(lech) > 8 else "")))
    else:
        cb.append(("i", "Số dư đầu năm của sổ khớp số dư cuối năm trước trên HTKK (%d TK cấp 1)." % len(bang)))
    return bang, cb


# ------------------------------------------------------------------ so chuyen ky
def _nam_tc(nam, thang_dau):
    d1 = date(nam, thang_dau, 1)
    d2 = S._cuoi_thang(nam + (1 if thang_dau > 1 else 0), 12 if thang_dau == 1 else thang_dau - 1)
    return ("Y", d1, d2)


def _gia(tk, ma):
    return S._co(tk["ct"], ma) if tk else None


def tndn_nam_truoc(ng, nam, thang_dau):
    """03/TNDN nam tai chinh `nam` -> (to khai, {chi tieu}, lo con chuyen) ; (None, {}, 0)"""
    k = _nam_tc(nam, thang_dau)
    tk = ng.tim({"ho": "TNDN", "ma": "", "pban": ""}, k)
    if tk is None:
        return None, {}, 0.0
    ct = {m: _gia(tk, "ct" + m) for m in ("A1", "B13", "C1", "C2", "C3", "C4", "C9", "C16", "C17", "D", "E", "G", "I")}
    hang = {}
    for kk, v in tk["ct"].items():
        m = re.search(r"Lo_HDSXKD/BangChiTietSoLo/noiDungNamThu(\d+)/ct([26])$", kk)
        if m:
            hang.setdefault(m.group(1), {})[m.group(2)] = S._so(v) or 0.0
    # PL 03-2A nam N-1: [6] lo con duoc chuyen cac nam sau; nam N chi con chuyen lo phat sinh tu N-5 (5 nam lien tuc)
    lo = sum(max(0.0, r.get("6", 0.0)) for r in hang.values() if int(r.get("2", 0) or 0) >= nam + 1 - 5)
    lo_nam = max(0.0, (ct.get("C2") or 0.0) - (ct.get("C1") or 0.0))          # lo cua chinh nam N-1 (nhu bao_cao_nam)
    return tk, ct, lo + lo_nam


def _ky_gtgt_xml(ng):
    """Ky 01/GTGT cua to khai XML (Ho so thue, to khai luu tru, thu muc to khai da chon, lan xuat truoc)."""
    try:
        return {x["ky"] for x in ng.xml() if x.get("ho") == "GTGT" and x.get("ky") and x["ky"][0] in ("M", "Q")}
    except Exception:
        return set()


def gtgt_moi_nhat(dm, ng, den):
    """01/GTGT co ky ket thuc truoc `den` moi nhat (HTKK tren may + to khai XML) -> to khai (ban hieu luc theo Nguon) ; None"""
    ky = {g["ky"] for g in dm["to_khai"] if g["ho"] == "GTGT" and g["ky"] and g["ky"][0] in ("M", "Q") and not g["cu"]}
    ky = sorted({k for k in ky | _ky_gtgt_xml(ng) if k[2] <= den}, key=lambda k: k[2], reverse=True)
    for k in ky[:3]:
        tk = ng.tim({"ho": "GTGT", "ma": "", "pban": ""}, k)
        if tk is not None:
            return tk
    return None


def ky_thieu_gtgt(dm, kieu, nam, thang_dau, den, them=()):
    """Ky 01/GTGT trong nam tai chinh (toi ky `den`) chua thay to khai tren HTKK (va trong `them` - ky cua to khai XML)."""
    co = {(g["ky"][0], g["ky"][1]) for g in dm["to_khai"] if g["ho"] == "GTGT" and g["ky"]} | {(k[0], k[1]) for k in them}
    _, d1, d2 = _nam_tc(nam, thang_dau)
    if kieu == "M":
        k = ("M", d1, S._cuoi_thang(d1.year, d1.month))
    else:
        q0 = 3 * ((d1.month - 1) // 3) + 1
        k = ("Q", date(d1.year, q0, 1), S._cuoi_thang(d1.year, q0 + 2))
    ra = []
    for _ in range(14):
        if k[2] > min(d2, den):
            break
        if (k[0], k[1]) not in co:
            ra.append(S._ten_ky(k))
        k = _ky_sau(k)
    return ra


def kk_nam(ng, nam, thang_dau, den):
    """05/KK-TNCN da khai trong nam tai chinh: [(ten ky, [21], [29], nguon)]"""
    _, d1, d2 = _nam_tc(nam, thang_dau)
    ra, m = [], d1
    while m <= min(d2, den):
        q0 = date(m.year, 3 * ((m.month - 1) // 3) + 1, 1)
        kq = ("Q", q0, S._cuoi_thang(q0.year, q0.month + 2))
        if m == q0:
            g = ng.tim({"ho": "KK", "ma": "", "pban": ""}, kq)
            if g is not None:
                ra.append((S._ten_ky(kq), _gia(g, "ct21") or 0.0, _gia(g, "ct29") or 0.0, g.get("nguon", "")))
                m = date(q0.year + (q0.month >= 10), (q0.month + 2) % 12 + 1, 1)
                continue
        km = ("M", m, S._cuoi_thang(m.year, m.month))
        g = ng.tim({"ho": "KK", "ma": "", "pban": ""}, km)
        if g is not None:
            ra.append((S._ten_ky(km), _gia(g, "ct21") or 0.0, _gia(g, "ct29") or 0.0, g.get("nguon", "")))
        m = date(m.year + (m.month == 12), m.month % 12 + 1, 1)
    return ra


# ------------------------------------------------------------------ chay
def chay(nam, che_do="133", thang_dau=1, mst="", thu_muc_khach="", goc_htkk="", so_du="", ra="", ra_nam_truoc="", log=None,
         hom_nay=None):
    """-> {"dong", "loi", "xem", "excel", "nam_truoc", "danh_muc"}"""
    log = log or (lambda s: None)
    nam, thang_dau = int(nam), int(thang_dau or 1)
    if not 1 <= thang_dau <= 12:
        thang_dau = 1
    che_do = "99" if str(che_do).strip() == "99" else "133"
    hom_nay = hom_nay or date.today()
    t0 = time.time()
    dong = ["NHẬP TOÀN BỘ DỮ LIỆU HTKK THEO MÃ SỐ THUẾ - NĂM TÀI CHÍNH %d (%s)" % (nam, datetime.now().strftime("%d/%m/%Y %H:%M")),
            "Chỉ đọc HTKK và sổ: chưa ghi gì vào sổ, không sửa HTKK. Dòng [!] sai lệch phải xem, [?] nên kiểm tra, [i] thông tin.", ""]
    cb_all, bang_sd, chuyen = [], [], []
    kq = {"dong": dong, "loi": 0, "xem": 0, "excel": "", "nam_truoc": "", "danh_muc": None}

    def them(m, c):
        cb_all.append((m, c))
        dong.append("[%s] %s" % (m, c))

    if not goc_htkk:
        them("?", "Không tìm thấy HTKK trên máy - chỉ lấy được số liệu năm trước từ tờ khai XML trong thư mục khách. "
                  "Chỉ đường HTKK ở Hệ thống > Nguồn HTKK, tờ khai và BCTC kỳ trước.")
    dm = danh_muc(goc_htkk, mst) if goc_htkk else {"thu_muc": "", "to_khai": [], "tep": 0, "khong_ro": 0, "header": False,
                                                    "chi_nhanh": []}
    kq["danh_muc"] = dm
    # 1. danh muc
    dong.append("1. DANH MỤC TỜ KHAI TRÊN HTKK CỦA MÃ SỐ THUẾ")
    if dm.get("loi_doc"):
        them("?", "Không đọc được thư mục dữ liệu của mã số thuế trên HTKK: %s" % dm["loi_doc"])
    elif goc_htkk and not dm["thu_muc"]:
        them("?", "HTKK trên máy chưa có thư mục dữ liệu của mã số thuế công ty (DataFiles) - chưa khai tờ khai nào bằng HTKK trên "
                  "máy này, hoặc mã số thuế công ty trong bộ sổ khác mã số thuế trên HTKK.")
    elif dm["thu_muc"]:
        th = tom_tat_ho(dm)
        dong.append("   %d tệp, %d tờ khai (gộp các sheet phụ lục), %d bản bổ sung, %d tờ khai định dạng cũ, %d tệp không nhận ra%s." % (
            dm["tep"], len(dm["to_khai"]), sum(x["bs"] for x in th.values()), sum(x["cu"] for x in th.values()), dm["khong_ro"],
            "; có thông tin chung (HEADER)" if dm["header"] else ""))
        if dm.get("ban_sao"):
            dong.append("   %d tệp bản sao dạng \"tên (1).xml\" bỏ qua - đọc tệp gốc cùng tên như HTKK mở." % dm["ban_sao"])
        for h in THU_TU_HO:
            x = th.get(h)
            if not x:
                continue
            dong.append("   - %s: %d tờ khai (%s), từ %s đến %s%s." % (
                TEN_HO.get(h, h), x["n"], ", ".join(sorted(x["mau"]))[:120], S._ten_ky(x["dau"]) or "?", S._ten_ky(x["cuoi"]) or "?",
                (", %d bổ sung" % x["bs"]) if x["bs"] else ""))
        if dm["chi_nhanh"]:
            dong.append("   Thư mục chi nhánh (mã 13 số, khai riêng - không gộp số): %d thư mục, %d tệp." % (
                len(dm["chi_nhanh"]), sum(n for _t, n in dm["chi_nhanh"])))
    dong.append("")
    ng = S.Nguon(mst, thu_muc_khach, goc_htkk, log=log)
    # 2. BCTC nam truoc
    dong.append("2. BÁO CÁO TÀI CHÍNH NĂM %d (cột Năm trước B02 / B03, Số đầu năm B01)" % (nam - 1))
    try:
        import bctc_nam_truoc as NT
        p, loi = NT.chay(nam - 1, che_do, mst=mst, thu_muc=thu_muc_khach, tep="", ra=ra_nam_truoc, goc_htkk=goc_htkk, log=log)
    except Exception as e:
        p, loi = None, "lỗi đọc BCTC năm trước: %s" % e
    if p:
        kq["nam_truoc"] = p
        nguon, dem = "", {}
        try:
            with io.open(p, encoding="utf-8-sig") as f:
                for d in f.read().splitlines():
                    if d.startswith("NGUON="):
                        nguon = d[6:]
                    elif "|" in d:
                        bc = d.split("|", 1)[0]
                        dem[bc] = dem.get(bc, 0) + 1
        except Exception:
            pass
        them("i", "BCTC năm %d: %s (%s). Bấm Ghi ở hộp kế tiếp để cập nhật vào bộ sổ (số cũ được sao lưu)." % (
            nam - 1, nguon or "đã lấy", ", ".join("%s %d chỉ tiêu" % kv for kv in sorted(dem.items()))))
    else:
        them("?", "Chưa lấy được BCTC năm %d: %s" % (nam - 1, (loi or "không có nguồn").rstrip(".")) + ".")
    # 3. so du TK
    dong.append("")
    dong.append("3. SỐ DƯ TÀI KHOẢN: CUỐI NĂM %d TRÊN HTKK (bảng cân đối tài khoản PL_CDTK) - ĐẦU NĂM %d CỦA SỔ" % (nam - 1, nam))
    ht, tep_ht = so_du_htkk(goc_htkk, mst, nam - 1)
    if not ht:
        them("i", "HTKK không có bảng cân đối tài khoản năm %d (chỉ BCTC TT133 nộp kèm PL_CDTK; TT200 / TT99 không có) - "
                  "đối chiếu số đầu năm theo B01 khi lập BCTC." % (nam - 1))
    else:
        dong.append("   Nguồn: %s." % tep_ht)
        bang_sd, cb = so_sanh_so_du(doc_so_du_so(so_du), ht)
        for m, c in cb:
            them(m, c)
    # 4. 03/TNDN nam truoc
    dong.append("")
    dong.append("4. QUYẾT TOÁN TNDN NĂM %d (03/TNDN)" % (nam - 1))
    tk, ct, lo = tndn_nam_truoc(ng, nam - 1, thang_dau)
    if tk is None:
        them("?", "Chưa thấy tờ khai 03/TNDN năm %d (HTKK trên máy, thẻ Hồ sơ thuế, tờ khai lưu trữ) - 03/TNDN năm %d sẽ để PL 03-2A "
                  "(chuyển lỗ) bằng 0." % (nam - 1, nam))
    else:
        ds = ["[%s] %s" % (m, S._vn(v)) for m, v in ct.items() if v is not None and m in ("A1", "C4", "C9", "C16", "C17", "I")]
        them("i", "03/TNDN năm %d (%s%s): %s; lỗ còn được chuyển sang năm %d: %s - 03/TNDN năm %d tự lấy." % (
            nam - 1, tk.get("nguon", ""), (", bổ sung lần %d" % tk["lan"]) if tk.get("bs") and tk.get("lan") else "",
            "; ".join(ds) or "không có chỉ tiêu số", nam, S._vn(lo), nam))
        chuyen.append(("03/TNDN năm %d" % (nam - 1), "Lỗ còn được chuyển sang năm %d" % nam, lo, tk.get("nguon", "")))
        for m in ("A1", "C4", "C9", "C17"):
            if ct.get(m) is not None:
                chuyen.append(("03/TNDN năm %d" % (nam - 1), "[%s]" % m, ct[m], tk.get("nguon", "")))
    # 5. 01/GTGT
    dong.append("")
    dong.append("5. THUẾ GTGT (01/GTGT): SỐ CHUYỂN KỲ")
    _, dn1, dn2 = _nam_tc(nam, thang_dau)
    g = gtgt_moi_nhat(dm, ng, min(dn2, hom_nay))
    if g is None:
        them("?", "Chưa thấy tờ khai 01/GTGT nào trước %s trên HTKK trên máy, Hồ sơ thuế, tờ khai lưu trữ - Xuất 01/GTGT sẽ hỏi [22]." % (
            hom_nay.strftime("%d/%m/%Y")))
    else:
        v43 = _gia(g, "ct43")
        them("i", "01/GTGT gần nhất: %s (%s%s): [40] %s, [43] %s -> [22] kỳ %s (Xuất 01/GTGT tự lấy, không hỏi)." % (
            S._ten_ky(g["ky"]), g.get("nguon", ""), (", bổ sung lần %d" % g["lan"]) if g.get("bs") and g.get("lan") else "",
            S._vn(_gia(g, "ct40") or 0), S._vn(v43 or 0), S._ten_ky(_ky_sau(g["ky"]))))
        chuyen.append(("01/GTGT %s" % S._ten_ky(g["ky"]), "[43] -> [22] kỳ %s" % S._ten_ky(_ky_sau(g["ky"])), v43 or 0.0, g.get("nguon", "")))
        thieu = ky_thieu_gtgt(dm, g["ky"][0], nam, thang_dau, g["ky"][2], _ky_gtgt_xml(ng))
        if thieu:
            them("?", "Năm %d chưa thấy tờ khai 01/GTGT trên HTKK trên máy / Hồ sơ thuế: %s (khai ở máy khác thì bỏ qua)." % (
                nam, ", ".join(thieu)))
    # 6. TNCN
    dong.append("")
    dong.append("6. THUẾ TNCN: 05/KK-TNCN NĂM %d, 05/QTT-TNCN NĂM %d" % (nam, nam - 1))
    ds = kk_nam(ng, nam, thang_dau, hom_nay)
    if ds:
        them("i", "05/KK-TNCN năm %d đã khai: %s; tổng [29] %s." % (
            nam, "; ".join("%s [21] %s [29] %s" % (a, S._vn(b), S._vn(c)) for a, b, c, _n in ds), S._vn(sum(x[2] for x in ds))))
        for a, b, c, n in ds:
            chuyen.append(("05/KK-TNCN %s" % a, "[29] thuế đã khấu trừ", c, n))
    else:
        them("i", "Chưa thấy 05/KK-TNCN nào của năm %d (không phát sinh khấu trừ thì không phải khai)." % nam)
    q = ng.tim({"ho": "QTT", "ma": "", "pban": ""}, _nam_tc(nam - 1, thang_dau))
    if q is not None:
        them("i", "05/QTT-TNCN năm %d (%s): [16] %s người, [23] %s, [31] %s." % (
            nam - 1, q.get("nguon", ""), S._vn(_gia(q, "NVuKhauTruThue/ct16") or 0), S._vn(_gia(q, "NVuKhauTruThue/ct23") or 0),
            S._vn(_gia(q, "NVuKhauTruThue/ct31") or 0)))
    dong.append("")
    kq["loi"] = sum(1 for m, _c in cb_all if m == "!")
    kq["xem"] = sum(1 for m, _c in cb_all if m == "?")
    dong.append("Tổng: %d dòng [!], %d dòng [?]; đã đọc %d nguồn trong %.0f giây." % (kq["loi"], kq["xem"], len(ng.da_quet), time.time() - t0))
    if ra:
        os.makedirs(os.path.dirname(os.path.abspath(ra)), exist_ok=True)
        try:
            kq["excel"] = lap_excel(os.path.join(os.path.dirname(os.path.abspath(ra)), TEN_EXCEL % nam), nam, dm, bang_sd, chuyen, dong)
            dong.append("Bảng chi tiết: %s" % os.path.basename(kq["excel"]))
        except Exception as e:
            log("[NHAP HTKK] khong lap duoc Excel: %s" % e)
            try:
                os.remove(os.path.join(os.path.dirname(os.path.abspath(ra)), TEN_EXCEL % nam) + ".tmp.xlsx")
            except OSError:
                pass
            dong.append("[i] Không lập được Excel chi tiết (tệp đang mở?): %s" % e)
        tam = ra + ".tmp"
        with io.open(tam, "w", encoding="utf-8-sig", newline="\r\n") as f:
            f.write("\n".join(dong) + "\n")
        os.replace(tam, ra)
        # khoa cho VB (GD168): tep BCTC nam truoc (hop Ghi cua GD131), Excel, so dong [!] / [?], so to khai
        with io.open(ra + ".khoa.txt", "w", encoding="utf-8-sig", newline="\r\n") as f:
            f.write("NAMTRUOC=%s\nXLSX=%s\nLOI=%d\nXEM=%d\nTO_KHAI=%d\n" % (
                kq["nam_truoc"] or "", kq["excel"] or "", kq["loi"], kq["xem"], len(dm["to_khai"])))
    return kq


def _ky_sau(k):
    if k[0] == "M":
        n = k[2].replace(day=1)
        n = date(n.year + (n.month == 12), n.month % 12 + 1, 1)
        return ("M", n, S._cuoi_thang(n.year, n.month))
    q = (k[1].month - 1) // 3 + 1
    y, q = (k[1].year + 1, 1) if q == 4 else (k[1].year, q + 1)
    return ("Q", date(y, 3 * q - 2, 1), S._cuoi_thang(y, 3 * q))


def lap_excel(p, nam, dm, bang_sd, chuyen, dong):
    from xlsx_viet import SoExcel
    wb = SoExcel(font="Times New Roman", co=11)
    h = wb.kieu(dam=True, co=10, can="giua", doc="giua", xuong=True, khung=True, nen="E2EFDA")
    c = wb.kieu(co=10, khung=True, xuong=True, doc="giua")
    n = wb.kieu(co=10, khung=True, so="#,##0;(#,##0);0", doc="giua")
    nd = wb.kieu(co=10, khung=True, so="#,##0;(#,##0);0", doc="giua", mau="C00000")
    td = wb.kieu(dam=True, co=12)
    ws = wb.sheet("Tong hop", cot=[150])
    ws.o(1, 1, "NHẬP TOÀN BỘ DỮ LIỆU HTKK THEO MÃ SỐ THUẾ - NĂM TÀI CHÍNH %d" % nam, td)
    for i, d in enumerate(dong[1:], 3):
        ws.o(i, 1, d, wb.kieu(co=10, mau="C00000" if d.lstrip().startswith("[!]") else "000000", dam=d[:2].strip(". ").isdigit()))
    w2 = wb.sheet("Danh muc to khai", cot=[18, 22, 50, 22, 10, 8, 18, 50])
    w2.dong(1, 1, ["Nhóm", "Mã tờ khai (MaFile)", "Tên tờ khai", "Kỳ", "Lần bổ sung", "Số sheet", "Sửa lần cuối", "Tệp tờ khai chính"], h)
    r = 2
    for g in dm["to_khai"]:
        w2.dong(r, 1, [(TEN_HO.get(g["ho"], g["ho"]), c), (g["ma_file"], c), (g["ten"], c), (S._ten_ky(g["ky"]) or g["than_ky"], c),
                       (g["lan"], n), (len(g["tep"]), n),
                       (datetime.fromtimestamp(g["mtime"]).strftime("%d/%m/%Y %H:%M") if g["mtime"] else "", c),
                       (os.path.basename(g["tep_chinh"]) + (" (định dạng cũ)" if g["cu"] else ""), c)])
        r += 1
    w3 = wb.sheet("So du TK", cot=[9, 40, 17, 17, 17, 17, 17])
    w3.dong(1, 1, ["TK", "Tên", "Sổ đầu năm Nợ", "Sổ đầu năm Có", "HTKK cuối năm trước Nợ", "HTKK cuối năm trước Có", "Chênh (ròng)"], h)
    for i, (tk, ten, a, b, x, y, ch) in enumerate(bang_sd, 2):
        w3.dong(i, 1, [(tk, c), (ten, c), (a, n), (b, n), (x, n), (y, n), (ch, nd if abs(ch) >= 1 else n)])
    w4 = wb.sheet("So chuyen ky", cot=[30, 40, 18, 60])
    w4.dong(1, 1, ["Tờ khai", "Chỉ tiêu", "Số", "Nguồn"], h)
    for i, (a, b, v, s) in enumerate(chuyen, 2):
        w4.dong(i, 1, [(a, c), (b, c), (v, n), (s, c)])
    tam = p + ".tmp.xlsx"
    wb.luu(tam)
    try:
        os.replace(tam, p)
    except OSError:                                # tep cu dang mo trong Excel -> ten moi theo gio
        p = os.path.splitext(p)[0] + "_" + datetime.now().strftime("%H%M%S") + ".xlsx"
        os.replace(tam, p)
    return p
