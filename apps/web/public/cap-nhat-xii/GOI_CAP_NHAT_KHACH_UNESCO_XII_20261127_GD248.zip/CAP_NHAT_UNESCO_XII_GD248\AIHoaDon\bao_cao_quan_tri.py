# -*- coding: utf-8 -*-
"""GD140 - BAO CAO QUAN TRI: TRANG TONG QUAN (HTML mo bang trinh duyet).

Anh Thang (06/10/2026): Bao cao quan tri can trang tong quan chi tieu + bieu do.
VB6 (ModBCQuanTri.BQT_TongQuan) doc so (CHI DOC) -> JSON UTF-8:
  {"loai": "quantri", "phien_ban": 140, "thong_tu": 133|99, "cty": {"ten", "mst", "dia_chi"}, "nam_tc", "thang_dau_ky",
   "tu_thang", "den_thang" (thang duong lich), "hom_nay", "lap_luc",
   "tk": [[ma, so_hieu, ten, cap, tk_con, du_no_0, du_co_0]],          he thong tai khoan (so du dau nam)
   "ps": [[ma_tk_no, ma_tk_co, thang_ct, so_tien, so_tien_ket_chuyen]], phat sinh theo cap TK / thang; cot 5 = phan cua chung
         tu ket chuyen (chung tu co dong TK 911, ca khi nhap mot ben) - khong tinh vao doanh thu / chi phi
   "kh_dau": [[ma_tk, ma_kh, du_no_0, du_co_0]], "kh_no": [[ma_tk, ma_kh, thang, p]], "kh_co": [...]   (TK 131 / 331)
   "kh": [[ma, so_hieu, ten]], "vt": [[ma_vt, thang, p]], "vt_ten": [[ma_vt, so_hieu, ten]]}       (doanh thu Co 511 theo hang)
Python tinh chi tieu, ve bieu do SVG (khong can thu vien / mang), ghi MOT tep .html tu chua (in A4 ngang duoc).
Khong ghi gi vao so. So chinh thuc: Bao cao tinh hinh tai chinh / Ket qua kinh doanh."""
import html
import io
import json
import math
import os
import time

PHIEN_BAN = 140

# mau (bo nhan dien "AI sang" - GD113)
NAVY, XANH, TEAL, LUC, CAM, DO, XAM = "#103070", "#1e5bd8", "#028798", "#17a35b", "#f08a24", "#d64545", "#8a99b3"
TIM, VANG = "#7b4fd1", "#c99a06"


# ------------------------------------------------------------------------------------------------ doc / so
def doc_json(duong):
    with io.open(duong, "r", encoding="utf-8-sig") as f:
        return json.loads(f.read(), strict=False)          # ten trong so co the chua ky tu dieu khien


def _so(x):
    try:
        return float(x or 0)
    except (TypeError, ValueError):
        return 0.0


def dinh_dang(x, le=0):
    """1234567.8 -> '1.234.568' (dau cham hang nghin kieu Viet)."""
    x = _so(x)
    am = x < 0
    s = ("{:,.%df}" % le).format(abs(x)).replace(",", "#").replace(".", ",").replace("#", ".")
    return ("-" if am and s.strip("0,.") else "") + s


def rut_gon(x):
    """so ngan cho bieu do: 1,25 tỷ / 345,6 tr / 12 nghìn."""
    x = _so(x)
    a = abs(x)
    if a >= 1e9:
        s = dinh_dang(x / 1e9, 2 if a < 1e10 else 1) + " tỷ"
    elif a >= 1e6:
        s = dinh_dang(x / 1e6, 1 if a < 1e8 else 0) + " tr"
    elif a >= 1e3:
        s = dinh_dang(x / 1e3, 0) + " nghìn"
    else:
        s = dinh_dang(x, 0)
    return s.replace(",0 ", " ").replace(",00 ", " ")


def phan_tram(a, b, le=1):
    if not b:
        return None
    return a * 100.0 / b


def chu_pt(v, le=1):
    return "—" if v is None else dinh_dang(v, le) + "%"


def e(s):
    return html.escape("" if s is None else str(s), quote=True)


# ------------------------------------------------------------------------------------------------ so lieu
class SoLieu(object):
    """Chi tieu tu he thong tai khoan + phat sinh (thang tai chinh k = 1..12; k = 0: dau nam)."""

    def __init__(self, dl):
        self.dl = dl
        self.tt = 99 if int(_so(dl.get("thong_tu")) or 133) == 99 else 133
        self.dk = int(_so(dl.get("thang_dau_ky")) or 1)
        if not 1 <= self.dk <= 12:
            self.dk = 1
        self.nam = int(_so(dl.get("nam_tc")) or 0)
        k1 = self.k_cua(int(_so(dl.get("tu_thang")) or self.dk))
        k2 = self.k_cua(int(_so(dl.get("den_thang")) or self.dk))
        if k2 < k1:
            k1, k2 = k2, k1
        self.k1, self.k2 = k1, k2
        # he thong tai khoan
        self.sh, self.ten, self.la = {}, {}, {}
        self.dau = {}                                   # so hieu (TK la) -> no - co dau nam
        for r in dl.get("tk") or []:
            try:
                ma, sh, ten, cap, con, dn, dc = r[0], str(r[1] or "").strip(), str(r[2] or "").strip(), r[3], r[4], r[5], r[6]
            except (IndexError, TypeError):
                continue
            self.sh[ma] = sh
            self.ten.setdefault(sh, ten)
            la = not _so(con)
            self.la[sh] = la
            if la and sh:
                self.dau[sh] = self.dau.get(sh, 0.0) + _so(dn) - _so(dc)
        # phat sinh: (so hieu no, so hieu co, k, ket chuyen 0/1) -> tien
        cap = {}
        for r in dl.get("ps") or []:
            try:
                n, c, th = r[0], r[1], int(_so(r[2]))
            except (IndexError, TypeError):
                continue
            k = self.k_cua(th)
            if not k:
                continue
            for kc, p in ((0, _so(r[3]) if len(r) > 3 else 0.0), (1, _so(r[4]) if len(r) > 4 else 0.0)):
                if p:
                    key = (self.sh.get(n, ""), self.sh.get(c, ""), k, kc)
                    cap[key] = cap.get(key, 0.0) + p
        self.cap_kc = [(a, b, k, kc, p) for (a, b, k, kc), p in cap.items()]
        tong = {}
        for a, b, k, kc, p in self.cap_kc:
            tong[(a, b, k)] = tong.get((a, b, k), 0.0) + p
        self.cap = [(a, b, k, p) for (a, b, k), p in tong.items()]          # tat ca (so du)
        self.cap_kd = [(a, b, k, p) for a, b, k, kc, p in self.cap_kc if not kc]   # bo chung tu ket chuyen (doanh thu / chi phi)
        self._no, self._co = {}, {}                      # so hieu -> [13]
        for a, b, k, p in self.cap:
            if a:
                self._no.setdefault(a, [0.0] * 13)[k] += p
            if b:
                self._co.setdefault(b, [0.0] * 13)[k] += p
        self._kh = None

    # thang duong lich <-> thang tai chinh
    def k_cua(self, thang):
        if thang == 13:
            return 12
        if not 1 <= thang <= 12:
            return 0
        return (thang - self.dk) % 12 + 1

    def thang_cua(self, k):
        return (self.dk - 1 + k - 1) % 12 + 1

    def nam_cua(self, k):
        t = self.thang_cua(k)
        return self.nam + (1 if t < self.dk else 0)

    def nhan_thang(self, k):
        return "T%d" % self.thang_cua(k)

    def so_ngay(self, k1, k2):
        n = 0
        for k in range(k1, k2 + 1):
            t, y = self.thang_cua(k), self.nam_cua(k)
            n += [31, 29 if (y % 4 == 0 and (y % 100 != 0 or y % 400 == 0)) else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][t - 1]
        return n

    # ---- phat sinh
    @staticmethod
    def _co_dau(sh, ds):
        return any(sh.startswith(x) for x in ds)

    def ps_thang(self, tien_to, ben, tru=(), bo_tk=(), bo_kc=False):
        """[13] phat sinh ben 'N' / 'C' cua TK bat dau bang tien_to (tru TK bat dau bang bo_tk), bo doi ung bat dau bang tru;
        bo_kc: bo chung tu ket chuyen."""
        if isinstance(tien_to, str):
            tien_to = (tien_to,)
        if isinstance(tru, str):
            tru = (tru,)
        out = [0.0] * 13
        for a, b, k, p in (self.cap_kd if bo_kc else self.cap):
            x, y = (a, b) if ben == "N" else (b, a)
            if x and self._co_dau(x, tien_to) and not (tru and self._co_dau(y, tru)) and not (bo_tk and self._co_dau(x, bo_tk)):
                out[k] += p
        return out

    def rong_thang(self, tien_to, tru=("911",), dau=1):
        """[13] (No - Co) * dau, bo doi ung 911 va chung tu ket chuyen."""
        n = self.ps_thang(tien_to, "N", tru, bo_kc=True)
        c = self.ps_thang(tien_to, "C", tru, bo_kc=True)
        return [(n[k] - c[k]) * dau for k in range(13)]

    # ---- so du
    def no_tk(self, k):
        """so hieu TK la -> (No - Co) cuoi thang tai chinh k."""
        d = dict(self.dau)
        for sh, v in self._no.items():
            d[sh] = d.get(sh, 0.0) + sum(v[1:k + 1])
        for sh, v in self._co.items():
            d[sh] = d.get(sh, 0.0) - sum(v[1:k + 1])
        return d

    @staticmethod
    def tong(d, tien_to, chi=None):
        if isinstance(tien_to, str):
            tien_to = (tien_to,)
        s = 0.0
        for sh, v in d.items():
            if any(sh.startswith(x) for x in tien_to):
                if chi == "no":
                    s += max(v, 0.0)
                elif chi == "co":
                    s += max(-v, 0.0)
                else:
                    s += v
        return s

    # ---- cong no theo doi tuong (131 / 331)
    def kh_du(self, k):
        """{'131': {ma_kh: no-co}, '331': {...}} cuoi thang k."""
        out = {"131": {}, "331": {}}
        for r in self.dl.get("kh_dau") or []:
            try:
                sh, kh, v = self.sh.get(r[0], ""), r[1], _so(r[2]) - _so(r[3])
            except (IndexError, TypeError):
                continue
            for g in out:
                if sh.startswith(g):
                    out[g][kh] = out[g].get(kh, 0.0) + v
        for ten, dau in (("kh_no", 1), ("kh_co", -1)):
            for r in self.dl.get(ten) or []:
                try:
                    sh, kh, kk, p = self.sh.get(r[0], ""), r[1], self.k_cua(int(_so(r[2]))), _so(r[3])
                except (IndexError, TypeError):
                    continue
                if not kk or kk > k:
                    continue
                for g in out:
                    if sh.startswith(g):
                        out[g][kh] = out[g].get(kh, 0.0) + dau * p
        return out

    def kh_ps(self, nhom, ben, k1, k2):
        """phat sinh theo doi tuong trong ky (ben 'N' = kh_no, 'C' = kh_co)."""
        out = {}
        for r in self.dl.get("kh_no" if ben == "N" else "kh_co") or []:
            try:
                sh, kh, kk, p = self.sh.get(r[0], ""), r[1], self.k_cua(int(_so(r[2]))), _so(r[3])
            except (IndexError, TypeError):
                continue
            if sh.startswith(nhom) and k1 <= kk <= k2:
                out[kh] = out.get(kh, 0.0) + p
        return out

    def ten_kh(self):
        if self._kh is None:
            self._kh = {}
            for r in self.dl.get("kh") or []:
                try:
                    self._kh[r[0]] = (str(r[1] or "").strip(), str(r[2] or "").strip())
                except (IndexError, TypeError):
                    continue
        return self._kh


# ------------------------------------------------------------------------------------------------ chi tieu
def tinh(dl):
    S = SoLieu(dl)
    k1, k2 = S.k1, S.k2
    KQ = {"S": S, "k1": k1, "k2": k2}
    cp_bh = ("641",) if S.tt == 99 else ("6421",)
    cp_ql = ("642",) if S.tt == 99 else ("6422",)
    kc = ("911",)
    dt = [a - b for a, b in zip(S.rong_thang("511", kc, -1), S.rong_thang("521", kc, 1))]
    gv = S.rong_thang("632", kc)
    bh = S.rong_thang(cp_bh, kc)
    ql = S.rong_thang(cp_ql, kc)
    if S.tt == 133:                                           # TK 642 khong chi tiet (TT133) -> tinh vao QLDN
        tong642 = S.rong_thang("642", kc)
        ql = [tong642[k] - bh[k] for k in range(13)]
    dttc = S.rong_thang("515", kc, -1)
    cptc = S.rong_thang("635", kc)
    tnk = S.rong_thang("711", kc, -1)
    cpk = S.rong_thang("811", kc)
    tndn = S.rong_thang("821", kc)
    gop = [dt[k] - gv[k] for k in range(13)]
    lntt = [gop[k] + dttc[k] - cptc[k] - bh[k] - ql[k] + tnk[k] - cpk[k] for k in range(13)]
    lnst = [lntt[k] - tndn[k] for k in range(13)]
    KQ["thang"] = dict(dt=dt, gv=gv, bh=bh, ql=ql, dttc=dttc, cptc=cptc, tnk=tnk, cpk=cpk, tndn=tndn, gop=gop, lntt=lntt, lnst=lnst)

    def ky(v, a=k1, b=k2):
        return sum(v[a:b + 1])
    KQ["ky"] = {x: ky(v) for x, v in KQ["thang"].items()}
    KQ["luy_ke"] = {x: ky(v, 1, k2) for x, v in KQ["thang"].items()}

    # so du theo thang (0..k2)
    tien_tt = ("111", "112", "113")
    htk_tt = ("151", "152", "153", "154", "155", "156", "157", "158")
    du = {x: [0.0] * 13 for x in ("tien", "tm", "tg", "htk", "pthu", "ptra", "thue", "vay", "luong", "ts", "npt", "vcsh",
                                    "tsnh", "lech", "tru_ncc", "mua_tra_truoc", "gtgt_kt", "tscd")}
    for k in range(0, k2 + 1):
        d = S.no_tk(k)
        kh = S.kh_du(k)
        du["tien"][k] = S.tong(d, tien_tt)
        du["tm"][k] = S.tong(d, "111")
        du["tg"][k] = S.tong(d, "112")
        du["htk"][k] = S.tong(d, htk_tt)
        d131 = sum(kh["131"].values())
        d331 = sum(kh["331"].values())
        t131, t331 = S.tong(d, "131"), S.tong(d, "331")
        # chi tiet doi tuong khong khop tong hop -> phan chenh coi nhu 1 doi tuong (giu dung tong)
        pthu = sum(max(v, 0.0) for v in kh["131"].values()) + max(t131 - d131, 0.0)
        mua_truoc = sum(max(-v, 0.0) for v in kh["131"].values()) + max(d131 - t131, 0.0)
        tra_ncc_truoc = sum(max(v, 0.0) for v in kh["331"].values()) + max(t331 - d331, 0.0)
        ptra = sum(max(-v, 0.0) for v in kh["331"].values()) + max(d331 - t331, 0.0)
        du["pthu"][k], du["mua_tra_truoc"][k], du["tru_ncc"][k], du["ptra"][k] = pthu, mua_truoc, tra_ncc_truoc, ptra
        du["thue"][k] = S.tong(d, "333", "co")
        du["gtgt_kt"][k] = S.tong(d, "133")
        du["vay"][k] = -S.tong(d, ("341", "311", "315"))
        du["luong"][k] = -S.tong(d, "334")
        du["tscd"][k] = S.tong(d, ("211", "212", "213", "214"))
        lop = {c: 0.0 for c in "0123456789"}
        for sh, v in d.items():
            if sh[:1] in lop:
                lop[sh[:1]] += v
        cr131 = mua_truoc
        dr331 = tra_ncc_truoc
        du["tsnh"][k] = lop["1"] + cr131 + dr331
        du["ts"][k] = lop["1"] + lop["2"] + cr131 + dr331
        du["npt"][k] = -lop["3"] + cr131 + dr331
        du["vcsh"][k] = -lop["4"] - sum(lop[c] for c in "56789")
        du["lech"][k] = du["ts"][k] - du["npt"][k] - du["vcsh"][k]       # = tong so du TK loai 1 - 9 (0 khi so can)
    KQ["du"] = du

    # dong tien: thu (No 11x doi ung khong phai 11x), chi (Co 11x ...)
    KQ["thu"] = S.ps_thang(tien_tt, "N", tien_tt)
    KQ["chi"] = S.ps_thang(tien_tt, "C", tien_tt)
    # thue GTGT
    KQ["gtgt_ra"] = S.ps_thang("3331", "C", ("3331",), bo_tk=("33312",))     # dau ra trong nuoc (33312 = GTGT hang nhap khau)
    KQ["gtgt_vao"] = S.ps_thang("133", "N", ("133",))                        # gom GTGT hang nhap khau (No 133 / Co 33312)
    # luong
    KQ["luong_ps"] = S.ps_thang("334", "C", ("334",))
    KQ["luong_tra"] = S.ps_thang("334", "N", ("334",))
    # co cau chi phi trong ky theo TK chi tiet
    cc = []
    for tien_to, nhom in (("632", "Giá vốn"), ("641", "Bán hàng"), ("642", "Quản lý"), ("635", "Tài chính"), ("811", "Khác")):
        theo = {}
        for a, b, k, p in S.cap_kd:
            if k1 <= k <= k2:
                if a.startswith(tien_to) and not b.startswith("911"):
                    theo[a] = theo.get(a, 0.0) + p
                if b.startswith(tien_to) and not a.startswith("911"):
                    theo[b] = theo.get(b, 0.0) - p
        for sh, v in theo.items():
            if abs(v) >= 1:
                ten = S.ten.get(sh, "")
                if S.tt == 133 and sh.startswith("6421"):
                    nh = "Bán hàng"
                elif S.tt == 133 and sh.startswith("642"):
                    nh = "Quản lý"
                else:
                    nh = nhom
                cc.append((sh, ten, nh, v))
    cc.sort(key=lambda x: -x[3])
    KQ["co_cau"] = cc
    # doi tuong: so du cuoi ky + phat sinh trong ky
    ten_kh = S.ten_kh()
    khd = S.kh_du(k2)

    def ten(ma):
        t = ten_kh.get(ma)
        if not t:
            return "(không mã đối tượng)" if not ma else "Mã %s" % ma
        return ("%s - %s" % (t[0], t[1])).strip(" -") if t[1] else t[0]
    KQ["top_thu"] = sorted([(ten(m), v) for m, v in khd["131"].items() if v >= 1], key=lambda x: -x[1])
    KQ["top_tra"] = sorted([(ten(m), -v) for m, v in khd["331"].items() if v <= -1], key=lambda x: -x[1])
    KQ["ban_chiu"] = sorted([(ten(m), v) for m, v in S.kh_ps("131", "N", k1, k2).items() if v >= 1], key=lambda x: -x[1])
    KQ["mua_chiu"] = sorted([(ten(m), v) for m, v in S.kh_ps("331", "C", k1, k2).items() if v >= 1], key=lambda x: -x[1])
    # doanh thu theo hang
    vt_ten = {}
    for r in dl.get("vt_ten") or []:
        try:
            vt_ten[r[0]] = (str(r[1] or "").strip(), str(r[2] or "").strip())
        except (IndexError, TypeError):
            continue
    vt = {}
    for r in dl.get("vt") or []:
        try:
            ma, kk, p = r[0], S.k_cua(int(_so(r[1]))), _so(r[2])
        except (IndexError, TypeError):
            continue
        if k1 <= kk <= k2:
            vt[ma] = vt.get(ma, 0.0) + p
    KQ["top_hang"] = sorted([(("%s - %s" % vt_ten[m]) if m in vt_ten else "Mã %s" % m, v) for m, v in vt.items() if v >= 1],
                            key=lambda x: -x[1])
    KQ["chi_so"] = chi_so(KQ)
    KQ["canh_bao"] = canh_bao(KQ)
    return KQ


def chi_so(KQ):
    S, k1, k2, du, ky = KQ["S"], KQ["k1"], KQ["k2"], KQ["du"], KQ["ky"]
    ngay = S.so_ngay(k1, k2)
    a = k1 - 1

    def bq(x):
        return (du[x][a] + du[x][k2]) / 2.0
    mua = sum(KQ["S"].ps_thang("331", "C", ("331",))[k1:k2 + 1])
    out = []

    def them(ten, gt, kieu, giai, tot=None):
        out.append(dict(ten=ten, gt=gt, kieu=kieu, giai=giai, tot=tot))
    them("Biên lợi nhuận gộp", phan_tram(ky["gop"], ky["dt"]), "%", "Lợi nhuận gộp / Doanh thu thuần.",
         None if ky["dt"] <= 0 else (phan_tram(ky["gop"], ky["dt"]) or 0) > 0)
    them("Biên lợi nhuận trước thuế", phan_tram(ky["lntt"], ky["dt"]), "%", "Lợi nhuận trước thuế / Doanh thu thuần.",
         None if ky["dt"] <= 0 else ky["lntt"] >= 0)
    tl = (du["tsnh"][k2] / du["npt"][k2]) if du["npt"][k2] > 1 else None
    them("Khả năng thanh toán", tl, "x", "Tài sản ngắn hạn (TK loại 1) / Nợ phải trả (TK loại 3). Trên 1 là an toàn.",
         None if tl is None else tl >= 1)
    tn = ((du["tsnh"][k2] - du["htk"][k2]) / du["npt"][k2]) if du["npt"][k2] > 1 else None
    them("Thanh toán nhanh", tn, "x", "(Tài sản ngắn hạn - Hàng tồn kho) / Nợ phải trả.", None if tn is None else tn >= 0.5)
    tt = (du["tien"][k2] / du["npt"][k2]) if du["npt"][k2] > 1 else None
    them("Thanh toán bằng tiền", tt, "x", "Tiền và tương đương tiền / Nợ phải trả.", None)
    nthu = (bq("pthu") / (ky["dt"] * 1.0) * ngay) if ky["dt"] > 1 else None
    them("Số ngày thu tiền bình quân", nthu, "ngày", "Phải thu khách hàng bình quân / Doanh thu thuần x %d ngày (ước tính, doanh thu chưa gồm thuế)." % ngay,
         None if nthu is None else nthu <= 60)
    nkho = (bq("htk") / ky["gv"] * ngay) if ky["gv"] > 1 else None
    them("Số ngày tồn kho bình quân", nkho, "ngày", "Hàng tồn kho bình quân / Giá vốn x %d ngày." % ngay, None)
    ntra = (bq("ptra") / mua * ngay) if mua > 1 else None
    them("Số ngày trả tiền người bán", ntra, "ngày", "Phải trả người bán bình quân / Phát sinh Có TK 331 x %d ngày." % ngay, None)
    nv = (du["npt"][k2] / du["vcsh"][k2]) if du["vcsh"][k2] > 1 else None
    them("Nợ phải trả / Vốn chủ sở hữu", nv, "x", "Đòn bẩy tài chính. Vốn chủ sở hữu gồm cả lợi nhuận chưa kết chuyển.",
         None if nv is None else nv <= 3)
    roe = phan_tram(ky["lnst"], bq("vcsh")) if bq("vcsh") > 1 else None
    them("Lợi nhuận / Vốn chủ sở hữu (trong kỳ)", roe, "%", "Lợi nhuận sau thuế trong kỳ / Vốn chủ sở hữu bình quân (không quy năm).",
         None if roe is None else roe >= 0)
    return out


def canh_bao(KQ):
    S, k1, k2, du, T = KQ["S"], KQ["k1"], KQ["k2"], KQ["du"], KQ["thang"]
    out = []
    am_tm = [k for k in range(1, k2 + 1) if du["tm"][k] < -1]
    if am_tm:
        out.append(("!", "Tồn quỹ tiền mặt âm cuối %s (thấp nhất %s đ). Kiểm tra phiếu chi ghi trước phiếu thu / thiếu phiếu thu." %
                    (", ".join(S.nhan_thang(k) for k in am_tm[:6]), dinh_dang(min(du["tm"][k] for k in am_tm)))))
    am_tg = [k for k in range(1, k2 + 1) if du["tg"][k] < -1]
    if am_tg:
        out.append(("!", "Số dư tiền gửi ngân hàng âm cuối %s - đối chiếu sổ phụ ngân hàng." % ", ".join(S.nhan_thang(k) for k in am_tg[:6])))
    if du["htk"][k2] < -1:
        out.append(("!", "Hàng tồn kho cuối kỳ âm (%s đ) - xuất kho vượt nhập hoặc thiếu chứng từ nhập." % dinh_dang(du["htk"][k2])))
    if abs(du["lech"][0]) > 1000:
        out.append(("!", "Số dư đầu năm chưa cân (tổng dư Nợ - tổng dư Có các tài khoản = %s đ) - kiểm tra màn hình Số dư đầu kỳ. "
                         "Các chỉ tiêu tổng tài sản / nguồn vốn bị lệch theo." % dinh_dang(du["lech"][0])))
    if abs(du["lech"][k2] - du["lech"][0]) > 1000:
        out.append(("!", "Phát sinh trong năm chưa cân (Nợ khác Có): chênh %s đ - chạy Kiểm tra dữ liệu." % dinh_dang(du["lech"][k2] - du["lech"][0])))
    ky = KQ["ky"]
    if ky["dt"] > 0 and ky["gv"] > ky["dt"]:
        out.append(("!", "Giá vốn lớn hơn doanh thu trong kỳ (biên gộp %s) - xem lại giá xuất kho / kết chuyển giá thành." %
                    chu_pt(phan_tram(ky["gop"], ky["dt"]))))
    if ky["lntt"] < 0:
        out.append(("?", "Kỳ báo cáo lỗ %s đ trước thuế." % dinh_dang(-ky["lntt"])))
    if ky["dt"] <= 0 and k2 >= 1:
        out.append(("?", "Chưa có doanh thu trong kỳ - kiểm tra hoá đơn bán ra đã lập chứng từ chưa."))
    # chi phi tang dot bien
    cp = [T["bh"][k] + T["ql"][k] for k in range(13)]
    for k in range(max(k1, 4), k2 + 1):
        truoc = [cp[j] for j in range(1, k) if cp[j] > 0]
        if len(truoc) >= 3:
            tb = sum(truoc) / len(truoc)
            if tb > 0 and cp[k] > 1.5 * tb and cp[k] - tb > 5e6:
                out.append(("?", "Chi phí bán hàng + quản lý %s tăng %s so với bình quân các tháng trước (%s đ so với %s đ)." %
                            (S.nhan_thang(k), chu_pt(phan_tram(cp[k] - tb, tb), 0), dinh_dang(cp[k]), dinh_dang(tb))))
    tong_thu = du["pthu"][k2]
    if KQ["top_thu"] and tong_thu > 0 and KQ["top_thu"][0][1] > 0.5 * tong_thu and len(KQ["top_thu"]) > 1:
        out.append(("?", "Phải thu tập trung: %s chiếm %s tổng phải thu." % (KQ["top_thu"][0][0], chu_pt(phan_tram(KQ["top_thu"][0][1], tong_thu), 0))))
    if du["mua_tra_truoc"][k2] > 1:
        out.append(("i", "Khách hàng trả trước / TK 131 dư Có: %s đ (đã tách khỏi phải thu)." % dinh_dang(du["mua_tra_truoc"][k2])))
    if du["tru_ncc"][k2] > 1:
        out.append(("i", "Trả trước cho người bán / TK 331 dư Nợ: %s đ (đã tách khỏi phải trả)." % dinh_dang(du["tru_ncc"][k2])))
    ra, vao = KQ["gtgt_ra"], KQ["gtgt_vao"]
    lien = 0
    for k in range(1, k2 + 1):
        lien = lien + 1 if (vao[k] > ra[k] and vao[k] > 0) else 0
    if lien >= 3:
        out.append(("i", "Thuế GTGT đầu vào lớn hơn đầu ra %d tháng liền - xem xét đề nghị hoàn thuế hoặc kiểm tra hoá đơn bán ra." % lien))
    # lech chi tiet doi tuong dau nam
    kh0 = S.kh_du(0)
    d0 = S.no_tk(0)
    for g, ten in (("131", "phải thu khách hàng"), ("331", "phải trả người bán")):
        lech = sum(kh0[g].values()) - S.tong(d0, g)
        if abs(lech) > 1000 and kh0[g]:
            out.append(("?", "Số dư đầu năm chi tiết theo đối tượng TK %s (%s) lệch tổng hợp %s đ." % (g, ten, dinh_dang(lech))))
    if not out:
        out.append(("i", "Không phát hiện điểm bất thường trong các phép kiểm tự động."))
    return out


# ------------------------------------------------------------------------------------------------ bieu do SVG
def _buoc_dep(tho):
    if tho <= 0:
        return 1.0
    mu = 10 ** math.floor(math.log10(tho))
    for m in (1, 2, 2.5, 5, 10):
        if tho <= m * mu:
            return m * mu
    return 10 * mu


def _truc(lo, hi, so=5):
    if hi <= lo:
        hi = lo + 1
    b = _buoc_dep((hi - lo) / so)
    a = math.floor(lo / b) * b
    z = math.ceil(hi / b) * b
    ds, v = [], a
    while v <= z + b * 0.001:
        ds.append(v)
        v += b
    return a, z, ds


def bieu_do_cot(nhan, cot, duong=(), cao=380, rong=1300, nen_ky=None, tieu_de=""):
    """cot: [(ten, mau, [gia tri])] (cot canh nhau); duong: [(ten, mau, [gia tri])]; nen_ky: (i_dau, i_cuoi) to nen."""
    n = len(nhan)
    tat = [v for _, _, vs in list(cot) + list(duong) for v in vs] + [0.0]
    if not n or max(abs(v) for v in tat) < 1:
        return '<div class="trong">Chưa có số liệu trong năm.</div>'
    lo, hi, ticks = _truc(min(tat), max(tat))
    L, R, T, B = 74, 16, 34, 34
    w, h = rong - L - R, cao - T - B

    def y(v):
        return T + h - (v - lo) / (hi - lo) * h
    o = ['<svg class="bd" viewBox="0 0 %d %d" role="img" aria-label="%s">' % (rong, cao, e(tieu_de))]
    nhom = w / float(n)
    if nen_ky:
        a, b = nen_ky
        o.append('<rect x="%.1f" y="%d" width="%.1f" height="%d" fill="#e8f1fd"/>' % (L + a * nhom, T, (b - a + 1) * nhom, h))
    for t in ticks:
        o.append('<line x1="%d" x2="%d" y1="%.1f" y2="%.1f" stroke="%s" stroke-width="1"/>' %
                 (L, L + w, y(t), y(t), "#9fb0c8" if t == 0 else "#e3e9f2"))
        o.append('<text x="%d" y="%.1f" class="tr">%s</text>' % (L - 6, y(t) + 4, e(rut_gon(t))))
    nc = max(len(cot), 1)
    bc = min(nhom * 0.78 / nc, 34)
    for i in range(n):
        x0 = L + i * nhom + (nhom - bc * nc) / 2.0
        for j, (ten, mau, vs) in enumerate(cot):
            v = vs[i]
            ya, yb = y(max(v, 0)), y(min(v, 0))
            o.append('<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" fill="%s" rx="2"><title>%s %s: %s đ</title></rect>' %
                     (x0 + j * bc, ya, max(bc - 2, 1), max(yb - ya, 0.5), mau, e(ten), e(nhan[i]), e(dinh_dang(v))))
        o.append('<text x="%.1f" y="%d" class="tx">%s</text>' % (L + (i + 0.5) * nhom, T + h + 18, e(nhan[i])))
    for ten, mau, vs in duong:
        pts = " ".join("%.1f,%.1f" % (L + (i + 0.5) * nhom, y(vs[i])) for i in range(n))
        o.append('<polyline points="%s" fill="none" stroke="%s" stroke-width="2.5" stroke-linejoin="round"/>' % (pts, mau))
        for i in range(n):
            o.append('<circle cx="%.1f" cy="%.1f" r="3.5" fill="#fff" stroke="%s" stroke-width="2"><title>%s %s: %s đ</title></circle>' %
                     (L + (i + 0.5) * nhom, y(vs[i]), mau, e(ten), e(nhan[i]), e(dinh_dang(vs[i]))))
    # chu giai
    x = L
    for ten, mau, _ in cot:
        o.append('<rect x="%.0f" y="10" width="12" height="12" rx="2" fill="%s"/><text x="%.0f" y="20" class="cg">%s</text>' % (x, mau, x + 17, e(ten)))
        x += 26 + 7.4 * len(ten)
    for ten, mau, _ in duong:
        o.append('<line x1="%.0f" x2="%.0f" y1="16" y2="16" stroke="%s" stroke-width="3"/><text x="%.0f" y="20" class="cg">%s</text>' %
                 (x, x + 16, mau, x + 21, e(ten)))
        x += 30 + 7.4 * len(ten)
    o.append("</svg>")
    return "".join(o)


def bieu_do_ngang(muc, mau=XANH, toi_da=10, rong=560, tieu_de="", con_lai=True):
    """muc: [(nhan, gia tri)] da sap giam dan."""
    if not muc:
        return '<div class="trong">Không có số liệu.</div>'
    ds = list(muc[:toi_da])
    khac = sum(v for _, v in muc[toi_da:])
    if con_lai and khac > 0:
        ds.append(("Còn lại (%d)" % (len(muc) - toi_da), khac))
    hang, L = 30, 210
    cao = hang * len(ds) + 10
    mx = max([v for _, v in ds] + [1.0])
    w = rong - L - 110
    o = ['<svg class="bd" viewBox="0 0 %d %d" role="img" aria-label="%s">' % (rong, cao, e(tieu_de))]
    for i, (nh, v) in enumerate(ds):
        yy = 5 + i * hang
        ngan = nh if len(nh) <= 30 else nh[:29] + "…"
        bw = max(v, 0) / mx * w
        m = XAM if nh.startswith("Còn lại") else mau
        o.append('<text x="%d" y="%d" class="hn"><title>%s</title>%s</text>' % (L - 8, yy + 19, e(nh), e(ngan)))
        o.append('<rect x="%d" y="%d" width="%.1f" height="20" rx="3" fill="%s"><title>%s: %s đ</title></rect>' %
                 (L, yy + 5, max(bw, 1), m, e(nh), e(dinh_dang(v))))
        o.append('<text x="%.1f" y="%d" class="hv">%s</text>' % (L + bw + 6, yy + 19, e(rut_gon(v))))
    o.append("</svg>")
    return "".join(o)


def duong_nho(vs, mau=XANH, rong=150, cao=36):
    if not vs or len(vs) < 2:
        return ""
    lo, hi = min(vs), max(vs)
    if hi - lo < 1e-9:
        hi = lo + 1
    pts = " ".join("%.1f,%.1f" % (2 + i * (rong - 4) / float(len(vs) - 1), cao - 3 - (v - lo) / (hi - lo) * (cao - 6)) for i, v in enumerate(vs))
    return ('<svg class="sp" viewBox="0 0 %d %d" aria-hidden="true"><polyline points="%s" fill="none" stroke="%s" stroke-width="2"/></svg>' %
            (rong, cao, pts, mau))


# ------------------------------------------------------------------------------------------------ HTML
CSS = """
:root{--navy:#103070;--xanh:#1e5bd8;--teal:#028798;--nen:#eef5fd;--the:#fff;--vien:#d6e5f5;--chu:#1b2a4a;--phu:#5b6b86}
*{box-sizing:border-box}body{margin:0;background:var(--nen);color:var(--chu);font:14px/1.45 "Segoe UI",Tahoma,Arial,sans-serif}
header{background:linear-gradient(180deg,#01447b,#006c9e);color:#fff;padding:18px 28px 16px}
header h1{margin:0;font-size:22px;letter-spacing:.3px}header .p{margin-top:4px;color:#cde4f6;font-size:13.5px}
header .dong{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;flex-wrap:wrap}
.nut{background:#fff;color:var(--navy);border:0;border-radius:6px;padding:8px 16px;font-weight:600;cursor:pointer;font-size:13.5px}
main{padding:18px 28px 28px;max-width:1500px;margin:0 auto}
.luoi{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}@media(max-width:1100px){.luoi{grid-template-columns:repeat(2,1fr)}}
.kpi{background:var(--the);border:1px solid var(--vien);border-radius:10px;padding:12px 14px;min-height:112px}
.kpi .h{display:flex;align-items:center;justify-content:space-between;gap:8px}
.kpi .t{color:var(--phu);font-size:12.5px;font-weight:600;text-transform:uppercase;letter-spacing:.3px}
.kpi .v{font-size:23px;font-weight:700;color:var(--navy);margin:4px 0 2px;white-space:nowrap}
.kpi .s{font-size:12.5px;color:var(--phu)}.kpi .sp{width:110px;height:34px;flex:none}
.kpi.do .v{color:#c62828}.len{color:#17a35b;font-weight:600}.xuong{color:#d64545;font-weight:600}
section{background:var(--the);border:1px solid var(--vien);border-radius:10px;margin-top:16px;padding:14px 16px}
section h2{margin:0 0 10px;font-size:16px;color:var(--navy);display:flex;align-items:center;gap:8px}
section h2:before{content:"";width:5px;height:18px;background:var(--teal);border-radius:3px;display:inline-block}
.hai{display:grid;grid-template-columns:1fr 1fr;gap:16px}@media(max-width:1000px){.hai{grid-template-columns:1fr}}
.hai>div h3{margin:2px 0 6px;font-size:14px;color:#24407a}
svg.bd{width:100%;height:auto;display:block}svg .tr{font-size:12.5px;fill:#6b7a93;text-anchor:end}
svg .tx{font-size:13px;fill:#44536e;text-anchor:middle}svg .cg{font-size:13px;fill:#2c3b58}
svg .hn{font-size:12px;fill:#2c3b58;text-anchor:end}svg .hv{font-size:12px;fill:#2c3b58;font-weight:600}
table{border-collapse:collapse;width:100%;font-size:13px}th,td{border-bottom:1px solid #e6edf6;padding:6px 8px;text-align:right;white-space:nowrap}
th{background:#f2f7fd;color:#24407a;font-weight:600}td:first-child,th:first-child{text-align:left;white-space:normal}
tr.dam td{font-weight:700;color:var(--navy)}.kc td{background:#f7fbff}
.cs td:nth-child(2){font-weight:700}.cs td:last-child,.cs th:last-child{white-space:normal;color:var(--phu);text-align:left}
.tot{color:#17a35b}.xau{color:#d64545}
ul.cb{list-style:none;margin:0;padding:0}ul.cb li{padding:7px 10px 7px 40px;position:relative;border-bottom:1px solid #eef2f8}
ul.cb li b{position:absolute;left:8px;top:6px;width:24px;height:22px;border-radius:5px;text-align:center;color:#fff;font-size:12.5px;line-height:22px}
ul.cb .k1 b{background:#d64545}ul.cb .k2 b{background:#f08a24}ul.cb .k3 b{background:#1e5bd8}
.trong{color:var(--phu);padding:18px;text-align:center;font-style:italic}
details summary{cursor:pointer;color:var(--xanh);font-weight:600;margin:6px 0}
footer{color:var(--phu);font-size:12px;margin-top:14px;line-height:1.6}
.ghi{color:var(--phu);font-size:12.5px;margin:4px 0 0}
@media print{body{background:#fff}header{-webkit-print-color-adjust:exact;print-color-adjust:exact}.nut{display:none}
section,.kpi{break-inside:avoid;-webkit-print-color-adjust:exact;print-color-adjust:exact}main{padding:10px}@page{size:A4 landscape;margin:10mm}}
"""


def _the(t, v, s="", sp="", do=False):
    return ('<div class="kpi%s"><div class="t">%s</div><div class="h"><div class="v">%s</div>%s</div><div class="s">%s</div></div>' %
            (" do" if do else "", e(t), v, sp, s))


def _bien(v_moi, v_cu):
    if not v_cu:
        return ""
    p = (v_moi - v_cu) * 100.0 / abs(v_cu)
    lop = "len" if p >= 0 else "xuong"
    return '<span class="%s">%s%s%%</span> so với tháng trước' % (lop, "+" if p >= 0 else "", dinh_dang(p, 1))


def lap_html(dl, KQ):
    S, k1, k2, T, du, ky = KQ["S"], KQ["k1"], KQ["k2"], KQ["thang"], KQ["du"], KQ["ky"]
    cty = dl.get("cty") or {}
    ks = list(range(1, k2 + 1))
    nhan = [S.nhan_thang(k) for k in ks]
    if k1 == k2:
        ten_ky = "Tháng %d/%d" % (S.thang_cua(k1), S.nam_cua(k1))
    else:
        ten_ky = "Từ tháng %d/%d đến tháng %d/%d" % (S.thang_cua(k1), S.nam_cua(k1), S.thang_cua(k2), S.nam_cua(k2))
    tt = "Thông tư 99/2025/TT-BTC" if S.tt == 99 else "Thông tư 133/2016/TT-BTC"
    o = ["<!DOCTYPE html><html lang=\"vi\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">",
         "<title>Báo cáo quản trị - %s</title><style>%s</style></head><body>" % (e(cty.get("ten", "")), CSS)]
    o.append('<header><div class="dong"><div><h1>BÁO CÁO QUẢN TRỊ — TRANG TỔNG QUAN</h1>'
             '<div class="p">%s%s</div><div class="p">%s · %s · Năm tài chính %s · Lập lúc %s</div></div>'
             '<button class="nut" onclick="window.print()">In trang này</button></div></header><main>' %
             (e(cty.get("ten", "")), (" · MST " + e(cty.get("mst"))) if cty.get("mst") else "", e(ten_ky), e(tt), e(S.nam),
              e(dl.get("lap_luc") or time.strftime("%d/%m/%Y %H:%M"))))
    # ---- the chi tieu
    bien_gop = phan_tram(ky["gop"], ky["dt"])
    the = [
        _the("Doanh thu thuần", rut_gon(ky["dt"]) + " đ", "Lũy kế năm: %s đ<br>%s" % (rut_gon(KQ["luy_ke"]["dt"]), (_bien(T["dt"][k2], T["dt"][k2 - 1]) if k2 > 1 else "")
                                                                                      if k1 == k2 else "Bình quân tháng: %s đ" % rut_gon(ky["dt"] / (k2 - k1 + 1))),
             duong_nho([T["dt"][k] for k in ks], XANH)),
        _the("Lợi nhuận gộp", rut_gon(ky["gop"]) + " đ", "Biên gộp: <b>%s</b>" % chu_pt(bien_gop), duong_nho([T["gop"][k] for k in ks], TEAL), ky["gop"] < 0),
        _the("Lợi nhuận trước thuế", rut_gon(ky["lntt"]) + " đ", "Sau thuế: %s đ<br>Lũy kế năm: %s đ" % (rut_gon(ky["lnst"]), rut_gon(KQ["luy_ke"]["lntt"])),
             duong_nho([T["lntt"][k] for k in ks], LUC), ky["lntt"] < 0),
        _the("Tiền và tương đương tiền", rut_gon(du["tien"][k2]) + " đ", "Tiền mặt %s · Ngân hàng %s" % (rut_gon(du["tm"][k2]), rut_gon(du["tg"][k2])),
             duong_nho([du["tien"][k] for k in ks], NAVY), du["tien"][k2] < 0),
        _the("Phải thu khách hàng", rut_gon(du["pthu"][k2]) + " đ", "%d khách hàng còn nợ" % len(KQ["top_thu"]), duong_nho([du["pthu"][k] for k in ks], CAM)),
        _the("Phải trả người bán", rut_gon(du["ptra"][k2]) + " đ", "%d nhà cung cấp" % len(KQ["top_tra"]), duong_nho([du["ptra"][k] for k in ks], TIM)),
        _the("Hàng tồn kho", rut_gon(du["htk"][k2]) + " đ", "TK 151 - 158 cuối kỳ", duong_nho([du["htk"][k] for k in ks], VANG), du["htk"][k2] < 0),
        _the("Thuế phải nộp Nhà nước", rut_gon(du["thue"][k2]) + " đ", "Thuế GTGT còn được khấu trừ: %s đ" % rut_gon(du["gtgt_kt"][k2]),
             duong_nho([du["thue"][k] for k in ks], DO)),
    ]
    o.append('<div class="luoi">%s</div>' % "".join(the))
    nen = (k1 - 1, k2 - 1)
    # ---- ket qua kinh doanh
    o.append("<section><h2>Kết quả kinh doanh theo tháng</h2>")
    o.append(bieu_do_cot(nhan, [("Doanh thu thuần", XANH, [T["dt"][k] for k in ks]), ("Giá vốn", "#9cc3f5", [T["gv"][k] for k in ks]),
                                ("Chi phí bán hàng + quản lý", CAM, [T["bh"][k] + T["ql"][k] for k in ks])],
                         [("Lợi nhuận trước thuế", LUC, [T["lntt"][k] for k in ks])], nen_ky=nen, tieu_de="Kết quả kinh doanh"))
    o.append('<p class="ghi">Nền xanh nhạt = kỳ báo cáo. Doanh thu thuần = Có TK 511 - Nợ TK 511%s (không tính bút toán kết chuyển 911).</p>' %
             (" - giảm trừ TK 521" if S.tt == 99 else ""))
    hang = [("Doanh thu thuần", "dt", False), ("Giá vốn hàng bán", "gv", False), ("Lợi nhuận gộp", "gop", True),
            ("Doanh thu hoạt động tài chính", "dttc", False), ("Chi phí tài chính", "cptc", False), ("Chi phí bán hàng", "bh", False),
            ("Chi phí quản lý doanh nghiệp", "ql", False), ("Thu nhập khác", "tnk", False), ("Chi phí khác", "cpk", False),
            ("Lợi nhuận trước thuế", "lntt", True), ("Chi phí thuế TNDN", "tndn", False), ("Lợi nhuận sau thuế", "lnst", True)]
    o.append("<details><summary>Bảng số liệu theo tháng (đồng)</summary><div style=\"overflow-x:auto\"><table><tr><th>Chỉ tiêu</th>%s<th>Kỳ báo cáo</th><th>Lũy kế năm</th></tr>" %
             "".join("<th>%s</th>" % e(x) for x in nhan))
    for ten, ma, dam in hang:
        o.append('<tr class="%s"><td>%s</td>%s<td>%s</td><td>%s</td></tr>' %
                 ("dam" if dam else "", e(ten), "".join("<td>%s</td>" % dinh_dang(T[ma][k]) for k in ks), dinh_dang(ky[ma]), dinh_dang(KQ["luy_ke"][ma])))
    o.append("</table></div></details></section>")
    # ---- dong tien
    o.append("<section><h2>Dòng tiền và số dư tiền</h2>")
    o.append('<div class="hai"><div><h3>Tiền thu vào / chi ra theo tháng</h3>%s</div><div><h3>Số dư tiền cuối tháng</h3>%s</div></div>' % (
        bieu_do_cot(nhan, [("Thu vào", LUC, [KQ["thu"][k] for k in ks]), ("Chi ra", DO, [KQ["chi"][k] for k in ks])],
                    cao=300, rong=640, nen_ky=nen, tieu_de="Dòng tiền"),
        bieu_do_cot(nhan, [], [("Tiền và tương đương", NAVY, [du["tien"][k] for k in ks]), ("Tiền mặt", CAM, [du["tm"][k] for k in ks]),
                               ("Tiền gửi ngân hàng", TEAL, [du["tg"][k] for k in ks])], cao=300, rong=640, nen_ky=nen, tieu_de="Số dư tiền")))
    o.append('<p class="ghi">Thu / chi = phát sinh Nợ / Có TK 111, 112, 113 với tài khoản đối ứng ngoài nhóm tiền (không tính rút tiền gửi về quỹ, nộp tiền vào ngân hàng).</p></section>')
    # ---- cong no
    o.append('<section><h2>Công nợ cuối kỳ</h2><div class="hai"><div><h3>Phải thu khách hàng — %s đ</h3>%s</div><div><h3>Phải trả người bán — %s đ</h3>%s</div></div>' %
             (e(dinh_dang(du["pthu"][k2])), bieu_do_ngang(KQ["top_thu"], CAM, tieu_de="Phải thu"),
              e(dinh_dang(du["ptra"][k2])), bieu_do_ngang(KQ["top_tra"], TIM, tieu_de="Phải trả")))
    o.append(bieu_do_cot(nhan, [], [("Phải thu khách hàng", CAM, [du["pthu"][k] for k in ks]), ("Phải trả người bán", TIM, [du["ptra"][k] for k in ks]),
                                    ("Hàng tồn kho", VANG, [du["htk"][k] for k in ks])], cao=320, nen_ky=nen, tieu_de="Xu hướng công nợ"))
    o.append("</section>")
    # ---- mua ban theo doi tuong / hang
    o.append('<section><h2>Bán hàng và mua hàng trong kỳ</h2><div class="hai"><div><h3>Doanh thu theo mặt hàng (Có TK 511)</h3>%s</div>'
             '<div><h3>Bán chịu theo khách hàng (phát sinh Nợ TK 131)</h3>%s</div></div>' %
             (bieu_do_ngang(KQ["top_hang"], XANH, tieu_de="Doanh thu theo mặt hàng"), bieu_do_ngang(KQ["ban_chiu"], TEAL, tieu_de="Bán chịu")))
    o.append('<div class="hai" style="margin-top:10px"><div><h3>Mua chịu theo nhà cung cấp (phát sinh Có TK 331)</h3>%s</div>'
             '<div><h3>Cơ cấu chi phí trong kỳ (theo tài khoản)</h3>%s</div></div></section>' %
             (bieu_do_ngang(KQ["mua_chiu"], TIM, tieu_de="Mua chịu"),
              bieu_do_ngang([("%s %s" % (sh, ten), v) for sh, ten, _, v in KQ["co_cau"] if v > 0], NAVY, tieu_de="Cơ cấu chi phí")))
    # ---- thue + luong
    o.append('<section><h2>Thuế GTGT và tiền lương</h2><div class="hai"><div><h3>Thuế GTGT đầu ra / đầu vào</h3>%s</div><div><h3>Lương phải trả / đã trả (TK 334)</h3>%s</div></div></section>' %
             (bieu_do_cot(nhan, [("Đầu ra (Có 3331)", DO, [KQ["gtgt_ra"][k] for k in ks]), ("Đầu vào (Nợ 133)", XANH, [KQ["gtgt_vao"][k] for k in ks])],
                          cao=300, rong=640, nen_ky=nen, tieu_de="Thuế GTGT"),
              bieu_do_cot(nhan, [("Phải trả (Có 334)", TEAL, [KQ["luong_ps"][k] for k in ks]), ("Đã trả (Nợ 334)", XAM, [KQ["luong_tra"][k] for k in ks])],
                          cao=300, rong=640, nen_ky=nen, tieu_de="Tiền lương")))
    # ---- chi so + canh bao
    o.append('<section><h2>Chỉ số tài chính và điểm cần chú ý</h2><div class="hai"><div><table class="cs"><tr><th>Chỉ số</th><th>Giá trị</th><th>Cách tính</th></tr>')
    for c in KQ["chi_so"]:
        if c["gt"] is None:
            gt = "—"
        elif c["kieu"] == "%":
            gt = chu_pt(c["gt"])
        elif c["kieu"] == "x":
            gt = dinh_dang(c["gt"], 2) + " lần"
        else:
            gt = dinh_dang(c["gt"], 0) + " " + c["kieu"]
        lop = "" if c["tot"] is None else (' class="tot"' if c["tot"] else ' class="xau"')
        o.append("<tr><td>%s</td><td%s>%s</td><td>%s</td></tr>" % (e(c["ten"]), lop, e(gt), e(c["giai"])))
    o.append('</table></div><div><ul class="cb">')
    for muc, chu in KQ["canh_bao"]:
        o.append('<li class="%s"><b>%s</b>%s</li>' % ({"!": "k1", "?": "k2"}.get(muc, "k3"), e("[" + muc + "]"), e(chu)))
    o.append("</ul></div></div>")
    o.append('<details><summary>Tóm tắt tình hình tài chính cuối kỳ (ước tính từ số dư tài khoản, đồng)</summary><table>'
             "<tr><th>Khoản mục</th><th>Đầu năm</th><th>Đầu kỳ</th><th>Cuối kỳ</th></tr>")
    for ten, ma in (("Tài sản ngắn hạn (loại 1)", "tsnh"), ("Tổng tài sản", "ts"), ("Nợ phải trả", "npt"), ("Vốn chủ sở hữu (gồm lợi nhuận chưa kết chuyển)", "vcsh"),
                    ("Tiền và tương đương tiền", "tien"), ("Phải thu khách hàng", "pthu"), ("Hàng tồn kho", "htk"), ("Tài sản cố định (giá trị còn lại)", "tscd"),
                    ("Phải trả người bán", "ptra"), ("Vay và nợ thuê tài chính", "vay"), ("Thuế phải nộp Nhà nước", "thue"), ("Phải trả người lao động", "luong")):
        o.append("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>" % (e(ten), dinh_dang(du[ma][0]), dinh_dang(du[ma][k1 - 1]), dinh_dang(du[ma][k2])))
    o.append("</table></details></section>")
    o.append('<footer>Số liệu đọc trực tiếp từ sổ kế toán (chứng từ, hệ thống tài khoản, số dư đầu năm theo đối tượng) tại thời điểm lập — phần mềm chỉ đọc, '
             'không ghi gì vào sổ. Chỉ số là ước tính nhanh để quản trị; số chính thức xem Báo cáo tình hình tài chính và Báo cáo kết quả kinh doanh. '
             'Rê chuột lên cột / điểm để xem số đầy đủ. UNESCO XI + AI — GĐ%d.</footer></main></body></html>' % PHIEN_BAN)
    return "".join(o)


# ------------------------------------------------------------------------------------------------ chay
def chay(duong_json, ra="", ghi_log=None):
    """-> (duong .html, loi)."""
    def log(s):
        if ghi_log:
            try:
                ghi_log("[QUAN TRI] " + s)
            except Exception:
                pass
    try:
        dl = doc_json(duong_json)
    except Exception as ex:
        return None, "Khong doc duoc so lieu: %s" % ex
    if dl.get("loai") != "quantri":
        return None, "Tep so lieu khong phai bao cao quan tri"
    KQ = tinh(dl)
    noi = lap_html(dl, KQ)
    if not ra:
        ra = os.path.join(os.path.dirname(os.path.abspath(duong_json)), "BaoCaoQuanTri_%s.html" % time.strftime("%Y%m%d_%H%M%S"))
    thu = os.path.dirname(os.path.abspath(ra))
    if thu and not os.path.isdir(thu):
        os.makedirs(thu, exist_ok=True)
    tam = ra + ".tam"
    with io.open(tam, "w", encoding="utf-8", newline="\n") as f:
        f.write(noi)
    os.replace(tam, ra)
    log("da lap %s (%d tai khoan, %d cap phat sinh, ky %d-%d)" % (os.path.basename(ra), len(KQ["S"].sh), len(KQ["S"].cap), KQ["k1"], KQ["k2"]))
    return ra, ""


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("dung: bao_cao_quan_tri.py <so_lieu.json> [ra.html]")
        sys.exit(2)
    d, loi = chay(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else "", print)
    print(d or loi)
    sys.exit(0 if d else 1)
