# -*- coding: utf-8 -*-
"""So sanh 2 file doi chieu (CSV ';') do UNESCO xuat bang nut 'Xuat doi chieu lo' tren 2 ban sao MDB:
   - ban 1: Quy tac -> DuongGhi = 0 (qua Excel tam)   - ban 2: DuongGhi = 1 (truc tiep)
Cach chay:  python so_sanh_doi_chieu.py doi-chieu-...-duong0.csv doi-chieu-...-duong1.csv [bao_cao.csv]
Ket qua: in tom tat + ghi bao cao khac biet (CSV). 0 khac biet tren >= 3 bo so moi bat DuongGhi=1 that.
Chi dung thu vien chuan."""
import sys, os, csv, io

BO_QUA_COT = {"KhoaHD"}          # cot dung lam khoa
SO_LE = 0.5                       # sai so tien cho phep


def doc(duong):
    """Tra ve {(BANG, KhoaHD): [dict dong...]} ; hai khoi CT va HD, moi khoi co dong tieu de 'BANG;...' rieng."""
    kq = {}
    tieu_de = None
    with io.open(duong, "r", encoding="cp1252", errors="replace") as f:
        for raw in f:
            raw = raw.rstrip("\r\n")
            if not raw:
                continue
            phan = raw.split(";")
            if phan[0] == "BANG":
                tieu_de = phan[1:]
                continue
            if tieu_de is None:
                continue
            bang = phan[0]
            gt = phan[1:]
            d = dict(zip(tieu_de, gt))
            khoa = (bang, d.get("KhoaHD", ""))
            kq.setdefault(khoa, []).append(d)
    return kq


def chuan(v):
    v = (v or "").strip()
    try:
        return round(float(v.replace(",", ".")), 2)
    except ValueError:
        return v


def khop_dong(a, b):
    """So 2 dong: tra ve danh sach (cot, gia_tri_a, gia_tri_b) khac nhau."""
    kh = []
    for cot in set(a) | set(b):
        if cot in BO_QUA_COT:
            continue
        x, y = chuan(a.get(cot, "")), chuan(b.get(cot, ""))
        if isinstance(x, float) and isinstance(y, float):
            if abs(x - y) > SO_LE:
                kh.append((cot, a.get(cot, ""), b.get(cot, "")))
        elif str(x) != str(y):
            kh.append((cot, a.get(cot, ""), b.get(cot, "")))
    return kh


def dau_dong(d):
    """Khoa phu de ghep dong giua 2 ban (khong dung MaSo): TK No/Co + so tien + ma VT, hoac so HD + ty le."""
    if "TKNo" in d:
        return (d.get("TKNo", ""), d.get("TKCo", ""), chuan(d.get("SoPS", "")), d.get("MaVT", ""))
    return (d.get("SoHD", ""), chuan(d.get("TyLe", "")), chuan(d.get("ThanhTien", "")))


def so_sanh(f1, f2):
    a, b = doc(f1), doc(f2)
    bao_cao = []
    for khoa in sorted(set(a) | set(b)):
        da, db = a.get(khoa, []), b.get(khoa, [])
        if not da or not db:
            bao_cao.append((khoa[0], khoa[1], "THIEU", "co %d dong / %d dong" % (len(da), len(db)), "", ""))
            continue
        if len(da) != len(db):
            bao_cao.append((khoa[0], khoa[1], "SO_DONG", "%d" % len(da), "%d" % len(db), ""))
        con_b = list(db)
        for d in da:
            k = dau_dong(d)
            cung = [x for x in con_b if dau_dong(x) == k]
            if not cung:
                bao_cao.append((khoa[0], khoa[1], "KHONG_KHOP_DONG", str(k), "", ""))
                continue
            x = cung[0]
            con_b.remove(x)
            for cot, va, vb in khop_dong(d, x):
                bao_cao.append((khoa[0], khoa[1], "KHAC_COT", cot, va, vb))
        for x in con_b:
            bao_cao.append((khoa[0], khoa[1], "THUA_BEN_2", str(dau_dong(x)), "", ""))
    return bao_cao, len(a), len(b)


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        return 2
    f1, f2 = sys.argv[1], sys.argv[2]
    ra = sys.argv[3] if len(sys.argv) > 3 else os.path.join(os.path.dirname(f1) or ".", "bao-cao-doi-chieu.csv")
    bc, n1, n2 = so_sanh(f1, f2)
    with io.open(ra, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f, delimiter=";")
        w.writerow(["Bang", "KhoaHD", "LoaiKhac", "ChiTiet/Cot", "Ban1", "Ban2"])
        for r in bc:
            w.writerow(r)
    print("Ban 1: %d nhom (CT/HD theo hoa don) - Ban 2: %d nhom" % (n1, n2))
    print("Khac biet: %d dong  ->  %s" % (len(bc), ra))
    if not bc:
        print("KET LUAN: 0 khac biet. (Can 0 khac biet tren >= 3 bo so moi bat 'Ghi truc tiep'.)")
    else:
        for r in bc[:20]:
            print("  ", r)
    return 0 if not bc else 1


if __name__ == "__main__":
    sys.exit(main())
