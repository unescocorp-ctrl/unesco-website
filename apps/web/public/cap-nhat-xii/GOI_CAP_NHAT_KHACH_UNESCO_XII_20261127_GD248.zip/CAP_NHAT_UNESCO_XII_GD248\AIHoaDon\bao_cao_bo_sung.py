# -*- coding: utf-8 -*-
"""GD70 - BAO CAO BO SUNG THEO TT133 (chi DOC so, khong ghi so) - lap Excel tu JSON cua VB6 (ModHDDTHTKK.HDDT_BC_Excel):
  B03GT : B03-DNN Bao cao luu chuyen tien te - phuong phap GIAN TIEP (tu so du + doi ung tai khoan), kiem tien cuoi ky khop 111/112.
          GD76: ma so TT133 (01..70 nhu HTKK PL_LCTTGT; 02 = tong dieu chinh, 09 = 10..18 theo bo thiet lap chuan), cong thuc
          chuan rut gon: lai vay trich truoc, trich / chi quy, danh gia lai tien ngoai te [61], co phieu quy 419 ... khop [70].
  B09   : So lieu cho Ban thuyet minh B09-DNN: tien, hang ton kho, phai thu / phai tra theo doi tuong, TSCD tang giam, 242, thue 333,
          vay 341, von chu so huu, doanh thu / chi phi tai chinh / khac, chi phi SXKD theo yeu to, thue TNDN.
          GD76: TSCD tach 2111 / 2113 / 2112 / 217, VCSH gom 413 + loi nhuan nam nay, tong du No / du Co theo doi tuong,
          thue phai nop / da nop theo mau V.10, them V.2, VI.3 gia von, VI.6 CPQLKD, dong ghi giam 515 / 635 / 711 / 811.
  CONGNO: tuoi no phai thu / phai tra theo doi tuong (FIFO), 131 du Co / 331 du No (ung truoc), thu doi chieu cong no.
  S01   : S01-DNN Nhat ky - So cai (TK cap 1) cho ky.
  NVNN  : GD77 Tinh hinh thuc hien nghia vu doi voi Nha nuoc theo bo thiet lap chuan TT133 (10..20, 30..33, 40): ky truoc chuyen sang,
          phai nop = PS Co - PS No + da nop, da nop = No 333x / Co 11, 141, 131, 138, 331, 338, 136, 336; + cuoi ky, kiem tra so du.
  MAU   : bieu mau chung tu TT133 con thieu, dien san tu so: 08a-TT kiem ke quy, 03-TT / 04-TT tam ung (+ bang 141), 10-LDTL thuong,
          11-LDTL trich nop theo luong, 05-TSCD kiem ke TSCD, 02-TSCD thanh ly (GD71); 09-TT bang ke chi tien, 07-VT phan bo
          NVL / CCDC / 242 theo TK ghi No, 05-TT giay de nghi thanh toan (GD74). CONGNO co them S14-DNN (GD71).
  ALL   : tat ca trong mot file.
JSON = KS_Json (tk, ps, kh_dau, kh_no, kh_co, dt...) + doi_ung [[tkNo, tkCo, thangCT, tien]] + cn_ct [[tk, kh, ngay, no, co, sh, dg, han]]
     + dt_dc [[kh, dia chi]] + nk [[MaCT, sh, ngay, dg, shNo, shCo, tien]] + nguoi_ky {...}.
Moi so lieu la GOI Y de doi chieu; cac dong uoc tinh (doi ung khong tach duoc) ghi ro trong cot Ghi chu."""
import datetime
import json
import os
import re
from collections import defaultdict

import kiem_khoa_so as K
from so_sach_mau import so_thanh_chu

_so, _dd, thang_tc = K._so, K._dd, K.thang_tc
TIEN = ("111", "112")


def _ngay(s):
    m = re.match(r"\s*(\d{1,2})/(\d{1,2})/(\d{4})", str(s or ""))
    if not m:
        return None
    try:
        return datetime.date(int(m.group(3)), int(m.group(2)), int(m.group(1)))
    except ValueError:
        return None


class SoLieuBS(K.SoLieu):
    def __init__(self, dl):
        K.SoLieu.__init__(self, dl)
        # doi ung: (tkNo, tkCo) -> thang tai chinh -> tien
        self.du = defaultdict(lambda: defaultdict(float))
        for r in dl.get("doi_ung") or []:
            self.du[(int(_so(r[0])), int(_so(r[1])))][thang_tc(r[2], self.dau_ky)] += _so(r[3])
        self.dt = {int(_so(r[0])): [str(r[1] or ""), str(r[2] or ""), str(r[3] or "")] for r in dl.get("dt") or []}
        self.dt_dc = {int(_so(r[0])): str(r[1] or "") for r in dl.get("dt_dc") or []}
        self.dt_tel = {int(_so(r[0])): str(r[1] or "") for r in dl.get("dt_tel") or []}          # GD220: so dien thoai nguoi ban (KhachHang.Tel)
        self.nguoi_ky = dl.get("nguoi_ky") or {}
        # GD71: tai san (thang cuoi ky), tam ung 141, bang luong, nhan vien
        self.ts = [list(r) + [None] * (10 - len(r)) for r in dl.get("ts") or []]
        self.tu = [list(r) + [None] * (7 - len(r)) for r in dl.get("tu") or []]
        self.luong = [list(r) + [None] * (11 - len(r)) for r in dl.get("luong") or []]
        self.nv = {int(_so(r[0])): [str(r[1] or ""), str(r[2] or ""), str(r[3] or "")] for r in dl.get("nv") or []}

    # ---- so du dau nam / cuoi ky
    def du_nam(self, ma):
        t = self.tk.get(ma) or {}
        return t.get("dn0", 0.0) - t.get("dc0", 0.0)

    def sh(self, ma):
        return (self.tk.get(ma) or {}).get("sh", "")

    def la_bat_dau(self, *tt):
        return [m for m in self.la if any(self.sh(m).startswith(x) for x in tt)]

    def tong_du(self, tt, ham):
        return sum(ham(m) for m in self.la_bat_dau(*tt))

    def ps_tk(self, ma, kc=False):
        """(No, Co) trong ky [t1, t2] (mac dinh bo phan ket chuyen 911)."""
        return self.ps_ky(ma, kc)

    def ps_nhom(self, tt, kc=False):
        n = c = 0.0
        for m in self.la_bat_dau(*tt):
            a, b = self.ps_tk(m, kc)
            n += a
            c += b
        return n, c

    def doi_ung(self, tt_no, tt_co, t1=None, t2=None):
        """tong tien No (TK bat dau bang tt_no) / Co (tt_co) trong ky."""
        t1 = self.t1 if t1 is None else t1
        t2 = self.t2 if t2 is None else t2
        s = 0.0
        for (a, b), th in self.du.items():
            if any(self.sh(a).startswith(x) for x in tt_no) and any(self.sh(b).startswith(x) for x in tt_co):
                s += sum(v for t, v in th.items() if t1 <= t <= t2)
        return s

    def doi_ung_tk(self, ma, ben, t1=None, t2=None):
        """cac doi ung cua TK ma (ben 'N': ma o No -> {tkCo: tien}; 'C': ma o Co -> {tkNo: tien})."""
        t1 = self.t1 if t1 is None else t1
        t2 = self.t2 if t2 is None else t2
        ra = defaultdict(float)
        for (a, b), th in self.du.items():
            if (ben == "N" and a == ma) or (ben == "C" and b == ma):
                ra[b if ben == "N" else a] += sum(v for t, v in th.items() if t1 <= t <= t2)
        return ra

    def ten_dt(self, kh):
        d = self.dt.get(kh)
        return ("%s %s" % (d[0], d[1])).strip() if d else ("KH %d" % kh)


# ============================================================ khoi ky ten
def khoi_ky(S, X, so_cot, ngay=None):
    """Cac dong cuoi bang: 'Lap, ngay ...' + Nguoi lap bieu / Ke toan truong / Nguoi dai dien theo phap luat (ten tu khai bao)."""
    nk = S.nguoi_ky if hasattr(S, "nguoi_ky") else (S.dl.get("nguoi_ky") or {})
    ngay = ngay or datetime.date.today()
    dong = [[], [(None, 0)] * (so_cot - 2) + [("Lập, ngày %d tháng %d năm %d" % (ngay.day, ngay.month, ngay.year), X.X_THUONG)]]
    vt = [("Người lập biểu", nk.get("nguoi_lap", "")), ("Kế toán trưởng", nk.get("ke_toan_truong", "")),
          ("Người đại diện theo pháp luật", nk.get("giam_doc", ""))]
    if so_cot >= 6:
        cot = [0, so_cot // 2, so_cot - 2]
    else:
        cot = [0, min(1, so_cot - 1), so_cot - 1]
    for k in range(3):
        d = [(None, 0)] * so_cot
        for i, (ten, gia) in enumerate(vt):
            d[cot[i]] = ((ten, "(Ký, họ tên)", gia or "")[k], X.X_DAM if k == 0 else (X.X_GHICHU if k == 1 else X.X_THUONG))
        dong.append(d)
    if nk.get("chung_chi") or nk.get("don_vi_dv"):
        dong.append([("Đơn vị dịch vụ kế toán: %s - số chứng chỉ hành nghề: %s" % (nk.get("don_vi_dv", ""), nk.get("chung_chi", "")), X.X_GHICHU)])
    return dong


def _dau(S, X, tieu_de, ghi_chu=""):
    cty = S.dl.get("cty") or {}
    ky = S.dl.get("ky") or {}
    d = [[(tieu_de, X.X_TITLE)],
         [("Đơn vị: %s    MST: %s    Kỳ: %s - %s" % (cty.get("ten") or "", cty.get("mst") or "", ky.get("tu") or "", ky.get("den") or ""),
           X.X_THUONG)]]
    d.append([])                                   # GD208: bo dong ghi chu ky thuat - bieu mau chi giu tieu de, don vi, ky
    return d


# ============================================================ B03-DNN gian tiep
# GD76: MA SO theo TT133 (bo thiet lap chuan + HTKK PL_LCTTGT ct01..ct70). Mang (ten, ma); ma None = dong tieu de muc;
# ma "06.x" = dong chi tiet cua 06 (mau chuan danh dau "khong in" - sheet in nghieng de doi chieu).
B03_TEN = [("I. LƯU CHUYỂN TIỀN TỪ HOẠT ĐỘNG KINH DOANH", None), ("1. Lợi nhuận trước thuế", "01"),
           ("2. Điều chỉnh cho các khoản", "02"), ("- Khấu hao TSCĐ và BĐSĐT", "03"), ("- Các khoản dự phòng", "04"),
           ("- Lãi, lỗ chênh lệch tỷ giá hối đoái do đánh giá lại các khoản mục tiền tệ có gốc ngoại tệ", "05"),
           ("- Lãi, lỗ từ hoạt động đầu tư", "06"),
           ("   + Lãi, lỗ từ thanh lý, nhượng bán TSCĐ, BĐSĐT", "06.1"),
           ("   + Lãi, lỗ từ việc đánh giá lại tài sản phi tiền tệ mang đi góp vốn, đầu tư vào đơn vị khác", "06.2"),
           ("   + Lãi, lỗ từ bán, thu hồi các khoản đầu tư tài chính (không bao gồm lãi, lỗ mua bán chứng khoán kinh doanh)", "06.3"),
           ("   + Khoản tổn thất hoặc hoàn nhập tổn thất của các khoản đầu tư nắm giữ đến ngày đáo hạn", "06.4"),
           ("   + Lãi cho vay, lãi tiền gửi, cổ tức và lợi nhuận được chia, lãi đầu tư định kỳ", "06.5"),
           ("- Chi phí lãi vay", "07"), ("- Các khoản điều chỉnh khác", "08"),
           ("3. Lợi nhuận từ hoạt động kinh doanh trước thay đổi vốn lưu động", "09"),
           ("- Tăng, giảm các khoản phải thu", "10"), ("- Tăng, giảm hàng tồn kho", "11"),
           ("- Tăng, giảm các khoản phải trả (không kể lãi vay phải trả, thuế thu nhập doanh nghiệp phải nộp)", "12"),
           ("- Tăng, giảm chi phí trả trước", "13"), ("- Tăng, giảm chứng khoán kinh doanh", "14"),
           ("- Tiền lãi vay đã trả", "15"), ("- Thuế thu nhập doanh nghiệp đã nộp", "16"),
           ("- Tiền thu khác từ hoạt động kinh doanh", "17"), ("- Tiền chi khác cho hoạt động kinh doanh", "18"),
           ("Lưu chuyển tiền thuần từ hoạt động kinh doanh", "20"),
           ("II. LƯU CHUYỂN TIỀN TỪ HOẠT ĐỘNG ĐẦU TƯ", None),
           ("1. Tiền chi để mua sắm, xây dựng TSCĐ, BĐSĐT và các tài sản dài hạn khác", "21"),
           ("2. Tiền thu từ thanh lý, nhượng bán TSCĐ, BĐSĐT và các tài sản dài hạn khác", "22"),
           ("3. Tiền chi cho vay, đầu tư góp vốn vào đơn vị khác", "23"),
           ("4. Tiền thu hồi cho vay, đầu tư góp vốn vào đơn vị khác", "24"),
           ("5. Tiền thu lãi cho vay, cổ tức và lợi nhuận được chia", "25"),
           ("Lưu chuyển tiền thuần từ hoạt động đầu tư", "30"),
           ("III. LƯU CHUYỂN TIỀN TỪ HOẠT ĐỘNG TÀI CHÍNH", None),
           ("1. Tiền thu từ phát hành cổ phiếu, nhận vốn góp của chủ sở hữu", "31"),
           ("2. Tiền trả lại vốn góp cho các chủ sở hữu, mua lại cổ phiếu của doanh nghiệp đã phát hành", "32"),
           ("3. Tiền thu từ đi vay", "33"), ("4. Tiền trả nợ gốc vay và nợ thuê tài chính", "34"),
           ("5. Cổ tức, lợi nhuận đã trả cho chủ sở hữu", "35"),
           ("Lưu chuyển tiền thuần từ hoạt động tài chính", "40"),
           ("Lưu chuyển tiền thuần trong kỳ (50 = 20+30+40)", "50"), ("Tiền và tương đương tiền đầu kỳ", "60"),
           ("Ảnh hưởng của thay đổi tỷ giá hối đoái quy đổi ngoại tệ", "61"),
           ("Tiền và tương đương tiền cuối kỳ (70 = 50+60+61)", "70")]
B03_MUC = ("02", "09", "20", "30", "40", "50", "70")          # dong tong hop (in dam)
# TK theo che do cu (TT200 / QD48) van gap trong so chuyen doi: dua vao cung dong de [70] khong lech (vo hai khi so khong co)
TS_DH = ("211", "212", "213", "217")                          # TSCD, thue TC (212 cu), vo hinh (213 cu), BDSDT
DT_TC = ("128", "221", "222", "228")                          # cho vay / dau tu (221, 222 cu)
HTK = ("151", "152", "153", "154", "155", "156", "157", "158")        # 158: TK cu (hang kho bao thue)
# TK von luu dong tinh theo tong du No / du Co: 133 gom ca 1332 (chuan de o 21.1 / 17 - giu o day de [70] khop); 244 / 344: ky quy TK cu
VLD = ("131", "331", "138", "338", "141", "133", "333", "334", "136", "336", "335", "244", "344")


def b03_gian_tiep(S):
    """B03-DNN gian tiep theo MA SO TT133 va cong thuc bo thiet lap chuan (rut gon theo du lieu S: doi ung theo cap TK, so du TK la,
    cong no 131 / 331 theo doi tuong). -> [(ma, ten, tien, ghi_chu)] (ca dong 06.1..06.5), {ma: tien}, tien cuoi ky theo so (111+112+113).
    Cac cho UOC TINH (du lieu khong co danh dau hoat dong nhu ham ...ChiTietTheoHD_ cua chuan) ghi ro o ghi chu."""
    DU, kc, g = S.doi_ung, False, {}

    def thuan(tt, ben):
        n, c = S.ps_nhom(tt, kc)
        return (c - n) if ben == "C" else (n - c)

    def delta(tt):                                                 # du cuoi - du DAU KY (No - Co)
        return S.tong_du(tt, S.du_cuoi) - S.tong_du(tt, S.du_dau)
    # ---- I. 01 + 02 (03..08)
    g["01"] = thuan(("511",), "C") + thuan(("515",), "C") + thuan(("711",), "C") - thuan(("632",), "N") \
        - thuan(("642", "641"), "N") - thuan(("635",), "N") - thuan(("811",), "N") - thuan(("521",), "N")      # GD227: 521 (so TT99)
    CP = ("632", "154", "62", "64", "811")                           # 62x: so con dung 621 / 622 / 627
    g["03"] = DU(CP, ("214",)) - DU(("214",), CP)                   # khong tinh 241/214 (khau hao dua vao XDCB)
    g["04"] = -delta(("229", "352", "159"))                         # tang du Co du phong (159: TK cu)
    lo_tg, lai_tg = DU(("635",), ("413",)), DU(("413",), ("515",))
    g["05"] = lo_tg - lai_tg
    co_tl = DU(("811",), TS_DH) > 0 or DU(("214",), TS_DH) > 0     # ky co thanh ly / ghi giam TSCD
    tl_thu = DU(TIEN, ("711", "5118")) if co_tl else 0.0            # UOC TINH: moi 711 / 5118 thu tien khi ky co thanh ly
    tl_chi = DU(("811",), TIEN) if co_tl else 0.0                   # UOC TINH: moi 811 chi tien khi ky co thanh ly
    g["06.1"] = -tl_thu + DU(("811",), TS_DH) + tl_chi
    g["06.2"] = -DU(("228",), ("711",))
    g["06.3"] = DU(("635",), ("228",))
    g["06.4"] = DU(("635",), ("128",)) - DU(("128",), ("635",))
    _, co515 = S.ps_nhom(("515",), kc)
    # bo 515 doi ung TK von luu dong (chiet khau TT duoc huong 331/515, lai ban tra cham 131/515, lai / co tuc du thu 1388/515):
    # khong phai tien, da nam trong [10] / [12] (GD76 mo rong so voi A.3: lai du thu khong con lam lech [70])
    g["06.5"] = -(co515 - lai_tg - DU(VLD, ("515",)))
    g["06"] = sum(g[k] for k in ("06.1", "06.2", "06.3", "06.4", "06.5"))
    n635, _ = S.ps_nhom(("635",), kc)
    lai_trich, hoan_lai = DU(("635",), ("335",)), DU(("335",), ("635",))
    # UOC TINH lai vay = No 635 tru lo ty gia, 635 doi ung dau tu (121, 128, 228, 229) va doi ung von luu dong tru 335
    # (131: chiet khau TT cho nguoi mua, 331: lai mua tra cham, 3388 ...: da nam trong [10] / [12]); 635/335 bu o [12]
    bo635 = ("121", "128", "228", "229") + tuple(x for x in VLD if x != "335")
    g["07"] = max(0.0, n635 - lo_tg - DU(("635",), bo635)) - hoan_lai
    g["08"] = DU(("632", "642"), ("356",)) - DU(("356",), ("632", "642")) + DU(("632",), ("241",))
    g["02"] = sum(g[k] for k in ("03", "04", "05", "06", "07", "08"))
    # ---- thay doi von luu dong: tong du No / du Co (131, 331 theo doi tuong; TK khac theo dau so du TK la)
    la_cn, cn = K._cong_no(S)

    def no_co(tt, cuoi, bo=("3334",)):
        dn = dc = 0.0
        for m in S.la_bat_dau(*tt):
            if any(S.sh(m).startswith(x) for x in bo):
                continue
            con = S.du_cuoi(m) if cuoi else S.du_dau(m)
            if m in la_cn:
                for x in cn[m].values():
                    b = x[0] + ((x[1] - x[2]) if cuoi else 0.0)
                    dn, dc, con = dn + max(b, 0.0), dc + max(-b, 0.0), con - b
            dn, dc = dn + max(con, 0.0), dc + max(-con, 0.0)       # phan khong ghi doi tuong
        return dn, dc
    dn1, dc1 = no_co(VLD, True)
    dn0, dc0 = no_co(VLD, False)
    mua_ts_no = DU(TS_DH + ("241",), ("331",))                      # mua TSCD / XDCB chua tra: khong phai dong tien
    lai_tra_335 = min(DU(("335",), TIEN), lai_trich + max(0.0, -S.tong_du(("335",), S.du_dau)))   # UOC TINH phan lai
    g["10"] = -(dn1 - dn0)
    # GD76 mo rong: vat tu / hang hoa chuyen sang TSCD, XDCB (241/152, 211/156...) khong phai tien -> tru khoi [11]
    chuyen_dh = DU(TS_DH + ("241",), HTK) - DU(HTK, TS_DH + ("241",))
    g["11"] = -delta(HTK) - chuyen_dh
    g["12"] = (dc1 - dc0) + lai_tra_335 + hoan_lai - lai_trich - mua_ts_no
    g["13"] = -delta(("242",))
    g["14"] = -delta(("121",))
    g["15"] = -DU(("635",), TIEN) - lai_tra_335
    g["16"] = -DU(("3334",), TIEN)
    g["17"] = DU(TIEN, ("353", "356"))
    g["18"] = -DU(("353", "356", "418"), TIEN) - DU(("353", "356"), ("334", "338", "331"))   # mo rong: chi quy qua phai tra
    g["09"] = sum(g[k] for k in ("10", "11", "12", "13", "14", "15", "16", "17", "18"))       # theo bo thiet lap chuan
    g["20"] = g["01"] + g["02"] + g["09"]
    # ---- II. dau tu
    g["21"] = -DU(TS_DH, TIEN) - DU(("241",), TIEN) + DU(TIEN, ("241",))
    g["22"] = tl_thu - tl_chi
    g["23"] = -DU(DT_TC, TIEN)
    g["24"] = DU(TIEN, DT_TC)
    g["25"] = DU(TIEN, ("515",))
    g["30"] = sum(g[k] for k in ("21", "22", "23", "24", "25"))
    # ---- III. tai chinh
    g["31"] = DU(TIEN, ("411", "419"))
    g["32"] = -DU(("411", "419"), TIEN)
    g["33"] = DU(TIEN, ("341",)) + DU(("331",), ("341",))
    g["34"] = -DU(("341",), TIEN)
    g["35"] = -DU(("421",), TIEN)
    g["40"] = sum(g[k] for k in ("31", "32", "33", "34", "35"))
    g["50"] = g["20"] + g["30"] + g["40"]
    g["60"] = S.tong_du(("111", "112", "113"), S.du_dau)
    g["61"] = DU(TIEN, ("413",)) - DU(("413",), TIEN)
    g["70"] = g["50"] + g["60"] + g["61"]
    thuc = S.tong_du(("111", "112", "113"), S.du_cuoi)
    ghi = {
        "01": "Có 511 + 515 + 711 - Nợ 521 + 632 + 641 + 642 + 635 + 811 (bỏ bút toán kết chuyển 911; trước thuế TNDN 821)",
        "02": "= [03] + [04] + [05] + [06] + [07] + [08]",
        "03": "Nợ 632, 154, 62x, 64x, 811 / Có 214 - bút toán đảo Nợ 214 / Có các TK đó (không tính khấu hao đưa vào XDCB Nợ 241 / Có 214)",
        "04": "Δ dư Có 229 + 352 (trích lập - hoàn nhập, sử dụng dự phòng; 159 nếu sổ còn TK cũ)",
        "05": "Lỗ (Nợ 635 / Có 413) - lãi (Nợ 413 / Có 515) đánh giá lại tỷ giá",
        "06": "= [06.1] + [06.2] + [06.3] + [06.4] + [06.5]",
        "06.1": "ƯỚC TÍNH: kỳ có ghi giảm TSCĐ (Nợ 811 hoặc 214 / Có 211, 217) thì mọi tiền thu Có 711, 5118 coi là thu thanh lý, "
                "mọi tiền chi Nợ 811 là chi thanh lý; + GTCL (Nợ 811 / Có 211, 217)",
        "06.2": "-(Nợ 228 / Có 711): lãi đánh giá lại tài sản mang đi góp vốn",
        "06.3": "Nợ 635 / Có 228: lỗ khi bán, thu hồi vốn góp",
        "06.4": "Nợ 635 / Có 128 - Nợ 128 / Có 635",
        "06.5": "-(Có 515 trừ lãi tỷ giá 413/515 và 515 đối ứng TK vốn lưu động: chiết khấu thanh toán được hưởng 331/515, "
                "lãi bán trả chậm 131/515, lãi / cổ tức dự thu 1388/515 - phần này nằm ở [10], thu tiền sau cũng ở [10])",
        "07": "ƯỚC TÍNH: Nợ 635 trừ lỗ tỷ giá (635/413), 635 đối ứng 121, 128, 228, 229 và 635 đối ứng TK vốn lưu động trừ 335 "
              "(131, 331, 138, 338...: đã ở [10] / [12]); phần còn lại coi là lãi vay, gồm cả phí ngân hàng (phần trả tiền bù lại ở [15]) "
              "- hoàn nhập lãi trích thừa (Nợ 335 / Có 635)",
        "08": "Nợ 632, 642 / Có 356 - Nợ 356 / Có 632, 642 + Nợ 632 / Có 241",
        "09": "Theo bộ thiết lập chuẩn TT133 (HTKK): [09] = [10] + ... + [18]; [20] = [01] + [02] + [09]. "
              "Nếu cần 'lợi nhuận trước thay đổi vốn lưu động' theo nghĩa [01] + [02] = %s" % _dd(round(g["01"] + g["02"])),
        "10": "-Δ tổng dư Nợ 131, 331 (theo đối tượng), 133, 136, 138, 141, 333 (trừ 3334), 334, 335, 336, 338. "
              "1332 (VAT TSCĐ) để ở đây, chuẩn đưa vào [21]/[17]",
        "11": "-Δ dư Nợ 151 - 157 - vật tư, hàng hoá chuyển sang TSCĐ / XDCB (Nợ 21x, 241 / Có 15x; không qua tiền)",
        "12": "Δ tổng dư Có cùng nhóm TK dòng 10 + phần lãi trong tiền trả 335 + hoàn nhập 335/635 - lãi trích trước 635/335 "
              "- mua TSCĐ / XDCB chưa trả (Nợ 211, 217, 241 / Có 331). Trả nợ người bán TSCĐ vẫn nằm ở đây (chuẩn đưa vào 21.2) - tách tay nếu lớn",
        "13": "-Δ dư Nợ 242", "14": "-Δ dư Nợ 121",
        "15": "-(Nợ 635 / Có 111, 112) - ƯỚC TÍNH phần lãi trong tiền trả 335 = min(tiền trả Nợ 335, lãi trích 635/335 + dư Có 335 đầu kỳ)",
        "16": "-(Nợ 3334 / Có 111, 112)",
        "17": "Nợ 111, 112 / Có 353, 356",
        "18": "-(Nợ 353, 356, 418 / Có 111, 112) - chi quỹ qua phải trả (Nợ 353, 356 / Có 334, 338, 331)",
        "20": "= [01] + [02] + [09]",
        "21": "-(Nợ 211, 217 / Có 111, 112) - (Nợ 241 / Có 111, 112) + (Nợ 111, 112 / Có 241); VAT TSCĐ 1332 ở [10], trả nợ mua TSCĐ ở [12]",
        "22": "ƯỚC TÍNH: tiền thu Có 711, 5118 - tiền chi Nợ 811 khi kỳ có thanh lý (bán chịu không tính)",
        "23": "-(Nợ 128, 228 / Có 111, 112)", "24": "Nợ 111, 112 / Có 128, 228", "25": "Nợ 111, 112 / Có 515",
        "30": "= [21] + [22] + [23] + [24] + [25]",
        "31": "Nợ 111, 112 / Có 411, 419", "32": "-(Nợ 411, 419 / Có 111, 112)",
        "33": "Nợ 111, 112 / Có 341 + ngân hàng giải ngân trả thẳng người bán (Nợ 331 / Có 341)",
        "34": "-(Nợ 341 / Có 111, 112), gồm nợ thuê tài chính", "35": "-(Nợ 421 / Có 111, 112)",
        "40": "= [31] + [32] + [33] + [34] + [35]", "50": "= [20] + [30] + [40]",
        "60": "Số dư đầu kỳ 111 + 112 (+ 113 nếu sổ còn dùng)",
        "61": "Nợ 111, 112 / Có 413 - Nợ 413 / Có 111, 112 (đánh giá lại tiền ngoại tệ)",
        "70": "= [50] + [60] + [61]; phải bằng số dư 111 + 112 cuối kỳ (xem KIỂM TRA)",
    }
    ra = [(ma, ten, g.get(ma) if ma else None, ghi.get(ma, "") if ma else "") for ten, ma in B03_TEN]
    return ra, g, thuc


def sheet_b03(S, X):
    ra, gt, thuc = b03_gian_tiep(S)
    lech = gt["70"] - thuc
    T = _dau(S, X, "BÁO CÁO LƯU CHUYỂN TIỀN TỆ (PHƯƠNG PHÁP GIÁN TIẾP) - Mẫu B03-DNN",
             "Mã số theo TT133 (như phụ lục LCTT gián tiếp của tờ khai HTKK). Tính từ số dư và đối ứng tài khoản trong sổ; các dòng ghi 'ƯỚC TÍNH' "
             "ở cột Cách tính cần kế toán đối chiếu. Dòng 06.1 - 06.5 (chữ nghiêng) là chi tiết của 06, mẫu chuẩn không in. "
             "Cột Năm trước: số liệu năm trước đã lưu trong bộ sổ (menu Hệ thống -> Số liệu năm trước BCTC, kỳ từ đầu năm tài "
             "chính); chưa lưu thì để trống - chép từ B03 năm trước. "
             "Chỉ tiêu 70 phải bằng số dư 111 + 112 cuối kỳ - lệch thì xem cột ghi chú và bảng đối ứng tiền bên dưới.")
    T.append([(c, X.X_TIEUDE) for c in ("Chỉ tiêu", "Mã số", "Kỳ này", "Năm trước")])
    # GD131: cot Nam truoc = so lieu nam truoc da luu (VB6 NT131_JsonB03GT: [[ma, so], ...])
    nt = {}
    for r in S.dl.get("nam_truoc_b03gt") or []:
        try:
            nt[str(r[0]).strip().zfill(2)] = float(r[1])
        except (TypeError, ValueError, IndexError):
            continue
    for ma, ten, tien, ghi in ra:
        if ma is None:
            T.append([(ten, X.X_MUC)] + [("", X.X_MUC)] * 3)
        elif "." in ma:
            continue                                   # GD208: dong chi tiet 06.x mau chuan khong in
        else:
            muc = ma in B03_MUC
            T.append([(ten, X.X_MUC if muc else X.X_CHU), (ma, X.X_MUC if muc else X.X_CHU), (round(tien), X.X_SOMUC if muc else X.X_SO),
                      (round(nt[ma]) if ma in nt else "", X.X_SOMUC if muc else X.X_SO)])
    T += khoi_ky(S, X, 4)
    return ("B03 gian tiep", [70, 8, 20, 18], T, 4)


# ============================================================ B09-DNN so lieu thuyet minh
def _bang(T, X, tieu, cot, dong, tong=None, them=()):
    """them: cac dong tong phu sau dong Cong (GD76: tong du No / du Co tach ben)."""
    T.append([(tieu, X.X_MUC)] + [("", X.X_MUC)] * (len(cot) - 1))
    T.append([(c, X.X_TIEUDE) for c in cot])
    for d in dong:
        T.append([(v, X.X_SO if isinstance(v, (int, float)) and not isinstance(v, bool) else X.X_CHU) for v in d])
    for d in ([tong] if tong is not None else []) + list(them):
        T.append([(v, X.X_SOMUC if isinstance(v, (int, float)) and not isinstance(v, bool) else X.X_MUC) for v in d])
    T.append([])


def _tang_giam(S, tt, kc=True):
    """[(sh, ten, dau, tang(No), giam(Co), cuoi)] cho cac TK la bat dau bang tt + dong cong.
    GD76: dau = so du DAU KY (= dau nam tai chinh khi lap tu dau nam); kc=True: phat sinh gom ca chung tu ket chuyen (TK bang can doi)
    nen dau + No - Co = cuoi; khong bo TK chi co so du cuoi (vd 4212 dau nam = 0)."""
    ds, tong = [], [0.0] * 4
    for m in sorted(S.la_bat_dau(*tt), key=S.sh):
        d, (n, c) = S.du_dau(m), S.ps_tk(m, kc)
        cu = S.du_cuoi(m)
        if abs(d) < 1 and n < 1 and c < 1 and abs(cu) < 1:
            continue
        ds.append([S.sh(m), S.tk[m]["ten"], round(d), round(n), round(c), round(cu)])
        for i, v in enumerate((d, n, c, cu)):
            tong[i] += v
    return ds, [round(v) for v in tong]


def _phan_du(S, tt, ben_no):
    """GD76: phan du No (ben_no) / du Co cua tung TK la (DUNO / DUCO_ChitietTheoTK cua mau) - TK luong tinh trinh bay tach ben."""
    k, ds = (1 if ben_no else -1), []
    for m in sorted(S.la_bat_dau(*tt), key=S.sh):
        d, cu = max(k * S.du_dau(m), 0.0), max(k * S.du_cuoi(m), 0.0)
        if d >= 1 or cu >= 1:
            ds.append([S.sh(m), "%s (phần dư %s)" % (S.tk[m]["ten"], "Nợ" if ben_no else "Có"), round(d), "", "", round(cu)])
    return ds


def _so0(v):
    return v if isinstance(v, (int, float)) and not isinstance(v, bool) else 0


def _tong_ben(ds, ten, duong=True):
    """dong tong phan duong (duong=True) / phan am cua cot dau (2) va cuoi (5)."""
    k = 1 if duong else -1
    return ["", ten, sum(max(k * _so0(r[2]), 0) for r in ds), "", "", sum(max(k * _so0(r[5]), 0) for r in ds)]


def _dong_doi_ung(S, tt, ben):
    """Phat sinh TK tt theo TK doi ung (bo 911) + GD76 dong ghi giam (phia nguoc, doi ung khac 911, so am)."""
    ten = lambda k: (S.tk.get(k) or {}).get("ten", "")
    rows, giam = [], []
    for m in sorted(S.la_bat_dau(tt), key=S.sh):
        for k, v in sorted(S.doi_ung_tk(m, ben).items(), key=lambda kv: -kv[1]):
            if S.sh(k).startswith("911") or v < 1:
                continue
            rows.append([S.sh(m), "%s %s" % (S.sh(k), ten(k)), round(v)])
        for k, v in sorted(S.doi_ung_tk(m, "N" if ben == "C" else "C").items(), key=lambda kv: -kv[1]):
            if S.sh(k).startswith("911") or v < 1:
                continue
            giam.append([S.sh(m), ("Ghi giảm: Nợ %s / Có %s %s" % (S.sh(m), S.sh(k), ten(k))) if ben == "C"
                         else ("Ghi giảm: Nợ %s %s / Có %s" % (S.sh(k), ten(k), S.sh(m))), -round(v)])
    return rows + giam


def sheet_b09(S, X):
    DN = "Đầu năm" if S.t1 <= 1 else "Đầu kỳ"
    T = _dau(S, X, "BẢN THUYẾT MINH BÁO CÁO TÀI CHÍNH - Mẫu B09-DNN (số liệu các bảng)",
             "Cột '%s' = số dư đầu kỳ lập báo cáo (lập từ đầu năm tài chính thì là số đầu năm); số cuối kỳ = tính từ chứng từ đến cuối kỳ. "
             "Tăng / giảm tài khoản bảng cân đối "
             "tính cả bút toán kết chuyển nên đầu + tăng - giảm = cuối. Mã (V.x / VI.x) trong tên bảng là dòng tương ứng của mẫu B09-DNN; "
             "dòng 'Tổng dư Nợ / Tổng dư Có' tách theo đối tượng (131, 331) hoặc theo tài khoản chi tiết để điền đúng dòng mẫu. "
             "Phần chữ (chính sách kế toán, thông tin khác) kế toán tự viết. Chi phí theo yếu tố tách theo tài khoản đối ứng (ước tính)." % DN)
    # 1 tien
    ds, tong = _tang_giam(S, ("111", "112", "113"))
    _bang(T, X, "1. Tiền và tương đương tiền (V.1)", ("TK", "Tên", DN, "Tăng (Nợ)", "Giảm (Có)", "Cuối kỳ"), ds, ["", "Cộng"] + tong)
    # 1b dau tu tai chinh (GD76)
    ds, tong = _tang_giam(S, ("121", "128", "228", "2291", "2292"))
    if ds:
        _bang(T, X, "1b. Các khoản đầu tư tài chính (V.2): chứng khoán kinh doanh 121, nắm giữ đến ngày đáo hạn 128, góp vốn / đầu tư khác 228, "
              "dự phòng 2291 / 2292 (dư Có: số âm)", ("TK", "Tên", DN + " (Nợ - Có)", "Tăng (Nợ)", "Giảm (Có)", "Cuối kỳ (Nợ - Có)"), ds, ["", "Cộng"] + tong)
    # 2 hang ton kho
    ds, tong = _tang_giam(S, ("151", "152", "153", "154", "155", "156", "157", "158"))
    _bang(T, X, "2. Hàng tồn kho (V.4)", ("TK", "Tên", DN, "Nhập / tăng (Nợ)", "Xuất / giảm (Có)", "Cuối kỳ"), ds, ["", "Cộng"] + tong)
    dp = _tang_giam(S, ("2294", "1593"))[0]
    if dp:
        _bang(T, X, "   Dự phòng giảm giá hàng tồn kho", ("TK", "Tên", DN, "Nợ", "Có", "Cuối kỳ"), dp)
    # 3 phai thu / phai tra theo doi tuong (top) + tong du No / du Co theo doi tuong (GD76)
    la_cn, d = K._cong_no(S)
    for tt, tieu, nhan in (("131", "3. Phải thu của khách hàng (V.3.a; dư Có: V.9.b) - chi tiết theo đối tượng, dư cuối lớn nhất",
                            ("V.3.a Phải thu của khách hàng", "V.9.b Người mua trả tiền trước")),
                           ("331", "7. Phải trả người bán (V.9.a; dư Nợ: V.3.b) - chi tiết theo đối tượng",
                            ("V.3.b Trả trước cho người bán", "V.9.a Phải trả người bán"))):
        ds = []
        for m in la_cn:
            if not S.sh(m).startswith(tt):
                continue
            for kh, v in d[m].items():
                cu = v[0] + v[1] - v[2]
                if abs(cu) > 1 or abs(v[0]) > 1:
                    ds.append([S.ten_dt(kh), S.dt.get(kh, ["", "", ""])[2], round(v[0]), round(v[1]), round(v[2]), round(cu)])
        ds.sort(key=lambda r: -abs(r[5]))
        tong = ["Cộng (Nợ - Có, bù trừ các đối tượng)", "", sum(r[2] for r in ds), sum(r[3] for r in ds), sum(r[4] for r in ds), sum(r[5] for r in ds)]
        them = [["Tổng dư Nợ theo đối tượng - " + nhan[0]] + _tong_ben(ds, "")[1:],
                ["Tổng dư Có theo đối tượng - " + nhan[1]] + _tong_ben(ds, "", False)[1:]]
        _bang(T, X, tieu, ("Đối tượng", "MST", DN + " (Nợ - Có)", "PS Nợ", "PS Có", "Cuối kỳ (Nợ - Có)"), ds[:60], tong, them)
        if len(ds) > 60:
            T.insert(len(T) - 1, [("... còn %d đối tượng khác (xem sổ chi tiết công nợ); các dòng tổng tính trên toàn bộ đối tượng" % (len(ds) - 60), X.X_GHICHU)])
    # 4 phai thu khac: 136 / 138 / 141 (+ 244 TK cu) theo TK la + phan du No 334 / 338 (GD76)
    ds, tong = _tang_giam(S, ("136", "138", "141", "244"))
    ds += _phan_du(S, ("334", "338"), True)
    if ds:
        _bang(T, X, "4. Phải thu khác, tạm ứng, ký quỹ (V.3.c, V.3.d) - gồm phần dư Nợ 334 / 338", ("TK", "Tên", DN + " (Nợ - Có)", "Nợ", "Có", "Cuối kỳ (Nợ - Có)"),
              ds, ["", "Cộng", sum(_so0(r[2]) for r in ds), tong[1], tong[2], sum(_so0(r[5]) for r in ds)],
              [_tong_ben(ds, "Tổng dư Nợ - điền V.3.c / V.3.d (dư Có 138 ở bảng 9)")])
    # 5 TSCD (GD76): tach 2111 / 2113 / 2112 / 217 voi hao mon 2141 / 2143 / 2142 / 2147
    NHOM = [("2111", "2141", "5. Tăng, giảm TSCĐ hữu hình (V.5.A)"), ("2113", "2143", "5b. Tăng, giảm TSCĐ vô hình (V.5.B)"),
            ("2112", "2142", "5c. Tăng, giảm TSCĐ thuê tài chính (V.5.C)"), ("217", "2147", "5d. Tăng, giảm bất động sản đầu tư cho thuê (V.6.a)")]
    if not S.la_bat_dau("2111", "2112", "2113"):          # so chua chi tiet cap 2 / theo che do cu: 211 / 213 / 212 cap 1
        NHOM = [("211", "2141", NHOM[0][2]), ("213", "2143", NHOM[1][2]), ("212", "2142", NHOM[2][2]), NHOM[3]]
    for i, (tt, hm, tieu) in enumerate(NHOM):
        ds_ng, tong_ng = _tang_giam(S, (tt,))
        if not ds_ng:
            continue
        ds_hm, tong_hm = _tang_giam(S, (hm,))
        if not ds_hm and i == 0 and not S.la_bat_dau("2141", "2142", "2143", "2147"):   # 214 khong chi tiet: tinh het cho huu hinh
            hm = "214"
            ds_hm, tong_hm = _tang_giam(S, (hm,))
        if not ds_hm:
            tong_hm = [0, 0, 0, 0]
        rows = [["Nguyên giá", "TK " + tt] + tong_ng]
        # tang theo nguon: mua sam (doi ung 111/112/331/141), XDCB hoan thanh (241), khac
        mua = sum(S.doi_ung((tt,), (x,)) for x in ("111", "112", "331", "141", "341"))
        xdcb = S.doi_ung((tt,), ("241",))
        rows.append(["  - Mua sắm (đối ứng 111, 112, 331, 141, 341)", "", "", round(mua), "", ""])
        rows.append(["  - Xây dựng cơ bản hoàn thành (241)", "", "", round(xdcb), "", ""])
        rows.append(["  - Tăng khác", "", "", round(tong_ng[1] - mua - xdcb), "", ""])
        tl = S.doi_ung(("214", "811"), (tt,))
        rows.append(["  - Thanh lý, nhượng bán (đối ứng 214, 811)", "", "", "", round(tl), ""])
        rows.append(["  - Giảm khác", "", "", "", round(tong_ng[2] - tl), ""])
        rows.append(["Giá trị hao mòn luỹ kế", "TK " + hm, -tong_hm[0], tong_hm[2], tong_hm[1], -tong_hm[3]])
        rows.append(["  - Khấu hao trong kỳ (Có %s)" % hm, "", "", tong_hm[2], "", ""])
        rows.append(["Giá trị còn lại", "", tong_ng[0] + tong_hm[0], "", "", tong_ng[3] + tong_hm[3]])
        _bang(T, X, tieu, ("Chỉ tiêu", "", DN, "Tăng", "Giảm", "Cuối kỳ"), rows)
    ds, tong = _tang_giam(S, ("241",))
    if ds:
        _bang(T, X, "   Xây dựng cơ bản dở dang (241) (V.7)", ("TK", "Tên", DN, "Nợ", "Có", "Cuối kỳ"), ds, ["", "Cộng"] + tong)
    ds, tong = _tang_giam(S, ("242",))
    if ds:
        _bang(T, X, "6. Chi phí trả trước (242) (V.8.1): đầu năm, tăng, phân bổ, cuối kỳ", ("TK", "Tên", DN, "Tăng (Nợ)", "Phân bổ (Có)", "Cuối kỳ"),
              ds, ["", "Cộng"] + tong)
    # 8 thue (GD76): phai nop = PS Co - PS No + da nop; da nop = No 333x doi ung Co 11x, 141, 131, 138, 331, 338, 136, 336 (mau V.10)
    # GD77: tinh CHUNG ham voi sheet 'Nghia vu NN' (nvnn_so_tk: dau + phai nop - da nop = cuoi, ca but toan trong phieu ket chuyen)
    #       + cot dong mau chuan NVNN (11..20, 32; 'ngoai mau' = TK 333 khong thuoc dong nao)
    ds, tong = [], [0.0] * 4
    dong_mau = nvnn_dong_cua_tk(S)
    for m in sorted(S.la_bat_dau("333"), key=S.sh):
        dau, phai, nop, cu, n, c, _ = nvnn_so_tk(S, m)
        if abs(dau) < 1 and n < 1 and c < 1 and abs(cu) < 1:
            continue
        ds.append([S.sh(m), S.tk[m]["ten"], round(dau), round(phai), round(nop), round(cu), dong_mau.get(m, "ngoài mẫu")])
        for i, v in enumerate((dau, phai, nop, cu)):
            tong[i] += v
    _bang(T, X, "8. Thuế và các khoản phải nộp Nhà nước (V.10): phải nộp = PS Có - PS Nợ + đã nộp (VAT: đã trừ khấu trừ 3331/133); "
          "đã nộp = Nợ 333x đối ứng Có 11x, 141, 131, 138, 331, 338, 136, 336 (dư Có = còn phải nộp; số âm = nộp thừa). Cùng công thức với "
          "sheet 'Nghia vu NN' (mẫu Tình hình thực hiện nghĩa vụ đối với Nhà nước); cột cuối = dòng của mẫu đó",
          ("TK", "Tên", DN + " phải nộp", "Số phải nộp trong kỳ", "Số đã thực nộp trong kỳ", "Cuối kỳ phải nộp", "Dòng mẫu NVNN"), ds,
          ["", "Cộng"] + [round(v) for v in tong] + [""],
          [_tong_ben(ds, "Tổng dư Có - còn phải nộp (V.10)"), _tong_ben(ds, "Tổng dư Nợ - nộp thừa, phải thu Nhà nước (V.8.2)", False)])
    # 9 phai tra khac (GD76): so duong = Co - No; them 336 (3368) va phan du Co 138 (1388)
    ds, tong = _tang_giam(S, ("334", "335", "336", "338", "352", "353", "356"))
    ds = [[r[0], r[1], -r[2], r[4], r[3], -r[5]] for r in ds] + _phan_du(S, ("138",), False)
    if ds:
        _bang(T, X, "9. Phải trả người lao động, chi phí phải trả, phải trả nội bộ, phải trả khác, dự phòng, quỹ (V.9.c, V.12) - gồm phần dư Có 138",
              ("TK", "Tên", DN + " (Có - Nợ)", "Tăng (Có)", "Giảm (Nợ)", "Cuối kỳ (Có - Nợ)"),
              ds, ["", "Cộng", sum(_so0(r[2]) for r in ds), tong[2], tong[1], sum(_so0(r[5]) for r in ds)],
              [_tong_ben(ds, "Tổng dư Có - điền V.9.c / V.12 (dư Nợ 334 / 338 ở bảng 4)")])
    ds, tong = _tang_giam(S, ("341",))
    if ds:
        _bang(T, X, "10. Vay và nợ thuê tài chính (341) (V.11): đầu năm, tăng (Có), trả (Nợ), cuối kỳ", ("TK", "Tên", DN + " (Nợ - Có)", "Trả (Nợ)", "Vay thêm (Có)", "Cuối kỳ (Nợ - Có)"),
              ds, ["", "Cộng"] + tong)
    # von chu so huu (GD76): gom 413, phat sinh ca ket chuyen -> 4212 co loi nhuan nam nay
    ds, tong = _tang_giam(S, ("411", "413", "418", "419", "421"))
    rows = [[r[0], r[1], -r[2], r[4], r[3], -r[5]] for r in ds]
    _bang(T, X, "11. Vốn chủ sở hữu (V.13): dư Có - Nợ; đầu năm, tăng (Có), giảm (Nợ), cuối kỳ - gồm lợi nhuận năm nay kết chuyển 911, "
          "cổ phiếu quỹ 419 và lỗ luỹ kế là số âm", ("TK", "Tên", DN, "Tăng (Có)", "Giảm (Nợ)", "Cuối kỳ"), rows,
          ["", "Cộng", -tong[0], tong[2], tong[1], -tong[3]])
    # doanh thu / chi phi
    ds = []
    for m in sorted(S.la_bat_dau("511"), key=S.sh):
        n, c = S.ps_tk(m, False)
        if n or c:
            ds.append([S.sh(m), S.tk[m]["ten"], round(c), round(n), round(c - n)])
    if S.cp99:                                   # GD227: so TT99 - cac khoan giam tru doanh thu ghi No 521
        for m in sorted(S.la_bat_dau("521"), key=S.sh):
            n, c = S.ps_tk(m, False)
            if n or c:
                ds.append([S.sh(m), S.tk[m]["ten"], 0, round(n - c), round(c - n)])
    _bang(T, X, "12. Doanh thu bán hàng và cung cấp dịch vụ (Có 511), các khoản giảm trừ (Nợ 521)" if S.cp99 else
          "12. Doanh thu bán hàng và cung cấp dịch vụ (Có 511), các khoản giảm trừ (Nợ 511) (VI.1, VI.2)", ("TK", "Tên", "Doanh thu", "Giảm trừ", "Thuần"), ds,
          ["", "Cộng", sum(r[2] for r in ds), sum(r[3] for r in ds), sum(r[4] for r in ds)])
    # 12b gia von (GD76)
    rows = _dong_doi_ung(S, "632", "N")
    if rows:
        kc632 = S.doi_ung(("911",), ("632",)) - S.doi_ung(("632",), ("911",))
        _bang(T, X, "12b. Giá vốn hàng bán (Nợ 632) theo đối ứng, các khoản ghi giảm giá vốn (VI.3)", ("TK", "Đối ứng", "Số tiền"), rows,
              ["", "Cộng (giá vốn - ghi giảm)", sum(r[2] for r in rows)], [["", "Giá vốn thuần đã kết chuyển 911 (khớp B02 mã 11)", round(kc632)]])
    for tt, tieu, ben in (("515", "13. Doanh thu hoạt động tài chính (Có 515) theo đối ứng, ghi giảm (VI.4)", "C"),
                          ("635", "14. Chi phí tài chính (Nợ 635) theo đối ứng, ghi giảm (VI.5)", "N"),
                          ("642", "", ""),                    # 14b chi phi quan ly kinh doanh (VI.6) - bang rieng
                          ("711", "15. Thu nhập khác (Có 711) theo đối ứng, ghi giảm (VI.7)", "C"),
                          ("811", "16. Chi phí khác (Nợ 811) theo đối ứng, ghi giảm (VI.8)", "N")):
        rows = _dong_doi_ung(S, tt, ben) if ben else []
        if tt == "642":
            _bang_cpqlkd(S, T, X)
        elif rows:
            _bang(T, X, tieu, ("TK", "Đối ứng", "Số tiền"), rows, ["", "Cộng", sum(r[2] for r in rows)])
    # chi phi SXKD theo yeu to
    yt = [("Chi phí nguyên liệu, vật liệu", ("152", "151", "611")), ("Chi phí công cụ, dụng cụ (xuất dùng)", ("153",)),
          ("Chi phí nhân công (334, 338 - BHXH, KPCĐ)", ("334", "338")), ("Chi phí khấu hao TSCĐ", ("214",)),
          ("Chi phí dịch vụ mua ngoài (đối ứng 331, 335, 242)", ("331", "335", "242")), ("Chi phí khác bằng tiền (đối ứng 111, 112, 141)", ("111", "112", "141"))]
    cp_tk = ("154", "621", "622", "623", "627", "641", "642", "6421", "6422")
    rows, tong_yt = [], 0.0
    khac = 0.0
    tong_no = sum(S.ps_nhom((x,), False)[0] for x in ("154", "621", "622", "627", "641", "642"))
    for ten, tt in yt:
        v = S.doi_ung(cp_tk, tt)
        rows.append([ten, round(v)])
        tong_yt += v
    khac = tong_no - tong_yt - S.doi_ung(cp_tk, ("154", "155", "156", "632", "911", "621", "622", "627", "642"))
    rows.append(["Chi phí khác (đối ứng còn lại)", round(max(khac, 0.0))])
    _bang(T, X, "17. Chi phí sản xuất, kinh doanh theo yếu tố (Nợ 154 / 642 / 62x - tách theo TK đối ứng, ước tính)", ("Yếu tố chi phí", "Số tiền"), rows,
          ["Cộng", round(tong_yt + max(khac, 0.0))])
    ds = []
    for m in sorted(S.la_bat_dau("821"), key=S.sh):
        n, c = S.ps_tk(m, False)
        if n or c:
            ds.append([S.sh(m), S.tk[m]["ten"], round(n), round(c), round(n - c)])
    if ds:
        _bang(T, X, "18. Chi phí thuế TNDN (821) (VI.9)", ("TK", "Tên", "Nợ", "Có", "Thuần"), ds)
    T += khoi_ky(S, X, 6)
    return ("B09 so lieu", [46, 40, 18, 18, 18, 18, 14], T, 4)          # GD77: cot 7 = dong mau NVNN (muc 8)


def _bang_cpqlkd(S, T, X):
    """GD76: 14b Chi phi quan ly kinh doanh (VI.6): a) No 6422, b) No 6421 (bo doi ung 911); c) ghi giam: c.1 hoan nhap du phong
    No 352 / Co 642, c.2 Co 642 khac (bo 911, 352)."""
    if S.cp99:                                   # GD227: so TT99 - a) chi phi ban hang (641), b) chi phi quan ly doanh nghiep (642)
        la41, la42 = S.la_bat_dau("641"), S.la_bat_dau("642")
        if not (la41 or la42):
            return

        def no_co99(ds_tk, ben, bo=("911",)):
            return sum(v for m in ds_tk for k, v in S.doi_ung_tk(m, ben).items() if not S.sh(k).startswith(bo))
        a, b = no_co99(la41, "N"), no_co99(la42, "N")
        c1 = S.doi_ung(("352",), ("642",))
        c2 = no_co99(la41 + la42, "C", ("911", "352"))
        rows = [["a) Chi phí bán hàng phát sinh trong kỳ (Nợ 641)", round(a)], ["b) Chi phí quản lý doanh nghiệp phát sinh trong kỳ (Nợ 642)", round(b)],
                ["c) Các khoản ghi giảm chi phí bán hàng, chi phí quản lý doanh nghiệp", -round(c1 + c2)],
                ["   - Hoàn nhập các khoản dự phòng (Nợ 352 / Có 642)", -round(c1)],
                ["   - Các khoản ghi giảm khác (Có 641, 642 đối ứng khác 911, 352)", -round(c2)]]
        kc = (S.doi_ung(("911",), ("641", "642")) - S.doi_ung(("641", "642"), ("911",)))
        _bang(T, X, "14b. Chi phí bán hàng, chi phí quản lý doanh nghiệp (VI.6)", ("Chỉ tiêu", "Số tiền"), rows,
              ["Cộng (a + b - khoản ghi giảm c)", round(a + b - c1 - c2)],
              [["Chi phí thuần đã kết chuyển 911 (khớp B02 mã 25 + 26)", round(kc)]])
        return
    la = S.la_bat_dau("642")
    if not la:
        return

    def no_co(ds_tk, ben, bo=("911",)):
        return sum(v for m in ds_tk for k, v in S.doi_ung_tk(m, ben).items() if not S.sh(k).startswith(bo))
    a = no_co([m for m in la if S.sh(m).startswith("6422")], "N")
    b = no_co([m for m in la if S.sh(m).startswith("6421")], "N")
    khac = no_co([m for m in la if not S.sh(m).startswith(("6421", "6422"))], "N")
    c1 = S.doi_ung(("352",), ("642",))
    c2 = no_co(la, "C", ("911", "352"))
    rows = [["a) Chi phí quản lý doanh nghiệp phát sinh trong kỳ (Nợ 6422)", round(a)], ["b) Chi phí bán hàng phát sinh trong kỳ (Nợ 6421)", round(b)]]
    if abs(khac) >= 1:
        rows.append(["   Chi phí 642 chưa tách 6421 / 6422", round(khac)])
    rows += [["c) Các khoản ghi giảm chi phí quản lý kinh doanh", -round(c1 + c2)], ["   - Hoàn nhập các khoản dự phòng (Nợ 352 / Có 642)", -round(c1)],
             ["   - Các khoản ghi giảm khác (Có 642 đối ứng khác 911, 352)", -round(c2)]]
    kc642 = S.doi_ung(("911",), ("642",)) - S.doi_ung(("642",), ("911",))
    _bang(T, X, "14b. Chi phí quản lý kinh doanh (VI.6)", ("Chỉ tiêu", "Số tiền"), rows, ["Cộng (a + b - khoản ghi giảm c)", round(a + b + khac - c1 - c2)],
          [["Chi phí QLKD thuần đã kết chuyển 911 (khớp B02 mã 24)", round(kc642)]])


# ============================================================ GD77: Tinh hinh thuc hien nghia vu doi voi Nha nuoc (mau chuan TT133)
# Bo thiet lap chuan (16 chi tieu 10..20, 30..33, 40; 3 cot cong thuc):
#   (1) So con phai nop ky truoc chuyen sang = DUCO(x) - DUNO(x) dau ky
#   (2) So phai nop trong ky = PS Co - PS No + DUN       (DUN = PS No x doi ung Co 11, 141, 131, 138, 331, 338, 136, 336)
#   (3) So da nop trong ky   = DUN
#   Dong 11 (33311) cua chuan: (2) = PS Co - DU(33311/133) - giam VAT, (3) = DUN - giam VAT, "giam VAT" = chung tu phan mem mau DANH DAU
#   giam thue. UNESCO khong co co danh dau -> GD77 chot: giam VAT = PS No 33311 doi ung TK NGOAI 133 va ngoai nhom nop (thuong Co 711:
#   thue GTGT duoc giam tru vao so phai nop; Co 511 / 521...) => (2) = PS Co - PS No + DUN nhu cac dong khac, (3) = DUN; No 33311 / Co 131
#   (hang ban tra lai, giam gia) van tinh "da nop" nhu chuan khi chung tu khong danh dau - ghi chu so tien de ke toan soat.
#   Them (4) So con phai nop cuoi ky = (1) + (2) - (3), (5) so du cuoi ky theo so (Co - No), (6) chenh lech (4) - (5) = 0 moi dong.
#   So khong mo TK cap 3: dong 11 lay 3331 (tru 33312 neu co), dong 20 lay 3338 (tru 33381 neu co) - ghi chu tren dong.
NVNN_NOP = ("11", "141", "131", "138", "331", "338", "136", "336")
NVNN_DONG = [("10", "I – Thuế", None), ("11", "1. Thuế GTGT hàng bán nội địa", "33311"), ("12", "2. Thuế GTGT hàng nhập khẩu", "33312"),
             ("13", "3. Thuế tiêu thụ đặc biệt", "3332"), ("14", "4. Thuế xuất, nhập khẩu", "3333"), ("15", "5. Thuế thu nhập doanh nghiệp", "3334"),
             ("16", "6. Thuế thu nhập cá nhân", "3335"), ("17", "7. Thuế tài nguyên", "3336"), ("18", "8. Thuế nhà đất, tiền thuê đất", "3337"),
             ("19", "9. Thuế bảo vệ môi trường", "33381"), ("20", "10. Các loại thuế khác", "33382"),
             ("30", "II – Các khoản phải nộp khác", None), ("31", "1. Các khoản phụ thu", None), ("32", "2. Các khoản phí, lệ phí", "3339"),
             ("33", "3. Các khoản khác", None), ("40", "Tổng cộng", None)]
NVNN_TONG = {"10": ("11", "12", "13", "14", "15", "16", "17", "18", "19", "20"), "30": ("31", "32", "33"), "40": ("10", "30")}
NVNN_COT = ("Chỉ tiêu", "Mã số", "Số còn phải nộp kỳ trước chuyển sang", "Số phải nộp trong kỳ", "Số đã nộp trong kỳ",
            "Số còn phải nộp cuối kỳ")


def nvnn_so_tk(S, m):
    """Mot TK la 333x theo cong thuc mau chuan -> (C1, C2, C3, du cuoi theo so (Co - No), PS No, PS Co, {TK doi ung Co: tien No}).
    Phat sinh GOM ca chung tu ket chuyen (vd No 821 / Co 3334 trong phieu ket chuyen) de C1 + C2 - C3 = du cuoi."""
    n, c = S.ps_tk(m, True)
    du = S.doi_ung_tk(m, "N")
    nop = sum(v for k, v in du.items() if S.sh(k).startswith(NVNN_NOP))
    return -S.du_dau(m), c - n + nop, nop, -S.du_cuoi(m), n, c, du


def nvnn_tk(S):
    """{ma dong: ([TK la], ghi chu TK)}; so khong mo TK cap 3: 11 lay 3331 (tru 33312), 20 lay 3338 (tru 33381)."""
    def co(tt):
        return any(t["sh"].startswith(tt) for t in S.tk.values())

    def la(tt, bo=()):
        return sorted((m for m in S.la_bat_dau(tt) if not (bo and S.sh(m).startswith(bo))), key=S.sh)
    ra = {ma: (la(tt), "TK " + tt) for ma, _, tt in NVNN_DONG if tt}
    if not co("33311"):
        ra["11"] = (la("3331", ("33312",)), "Sổ không mở TK 33311: lấy TK 3331" + (" (trừ 33312)" if co("33312") else ""))
    if not co("33382"):
        if co("33381"):
            ra["20"] = (la("3338", ("33381",)), "Sổ không mở TK 33382: lấy TK 3338 trừ 33381")
        else:
            ra["20"] = (la("3338"), "Sổ không mở TK 33381 / 33382: lấy cả TK 3338 (thuế BVMT, nếu có, nằm ở dòng này; dòng 19 để trống)")
    return ra


def nvnn_dong_cua_tk(S):
    """{TK la: ma dong mau chuan} (TK 333x khong thuoc dong nao -> khong co trong dict)."""
    return {m: ma for ma, (ds, _) in nvnn_tk(S).items() for m in ds}


def nvnn(S):
    """Bang mau chuan -> (dong [(ma, ten, C1, C2, C3, C4 = C1 + C2 - C3, du so, ghi chu)] (so da lam tron), chi tiet TK
    [(m, ma dong hoac None, so lieu nvnn_so_tk)], tong du cuoi moi TK 333 theo so, [TK 333 ngoai mau co so lieu])."""
    tk = nvnn_tk(S)
    v, ghi, ct, thuoc = {}, {}, [], {}
    for ma, (ds, g) in tk.items():
        s = [0.0] * 4
        for m in ds:
            x = nvnn_so_tk(S, m)
            for i in range(4):
                s[i] += x[i]
            thuoc[m] = ma
            ct.append((m, ma, x))
        v[ma] = [round(y) for y in s]
        ghi[ma] = g + (" (" + ", ".join(S.sh(m) for m in ds) + ")" if ds and [S.sh(m) for m in ds] != [g[3:]] else "")
    for ma in ("31", "33"):
        v[ma] = [0, 0, 0, 0]
        ghi[ma] = "Mẫu chuẩn để trống - nhập tay nếu có"
    # dong 11: tach so phai nop de ke toan doi chieu (khau tru 133, giam thue / dieu chinh khac, No 33311 / Co 131 trong 'da nop')
    x11 = [x for m, ma, x in ct if ma == "11"]
    if x11:
        ps_no, ps_co, nop = sum(x[4] for x in x11), sum(x[5] for x in x11), sum(x[2] for x in x11)
        kt = sum(t for x in x11 for k, t in x[6].items() if S.sh(k).startswith("133"))
        tra131 = sum(t for x in x11 for k, t in x[6].items() if S.sh(k).startswith("131"))
        khac = defaultdict(float)
        for x in x11:
            for k, t in x[6].items():
                if not S.sh(k).startswith(NVNN_NOP + ("133",)):
                    khac[S.sh(k)] += t
        giam = ps_no - nop - kt
        ghi["11"] += ("; phải nộp = PS Có %s - khấu trừ (Nợ 33311 / Có 133) %s - giảm thuế / điều chỉnh khác %s" % (_dd(ps_co), _dd(kt), _dd(giam))
                      + (" (đối ứng %s)" % ", ".join("%s: %s" % (k, _dd(t)) for k, t in sorted(khac.items(), key=lambda kv: -kv[1])[:4]) if khac else "")
                      + ". Giảm VAT: sổ không đánh dấu theo chứng từ như phần mềm mẫu - coi mọi Nợ 33311 đối ứng TK ngoài 133 và ngoài nhóm nộp là giảm")
        if tra131 >= 1:
            ghi["11"] += ("; 'đã nộp' gồm %s Nợ 33311 / Có 131 (hàng bán trả lại, giảm giá...): mẫu chuẩn chỉ loại ra khi chứng từ được đánh dấu "
                          "giảm thuế - soát tay nếu không phải khoản nộp / bù trừ" % _dd(tra131))
    for ma in ("10", "30", "40"):
        v[ma] = [sum(v[k][i] for k in NVNN_TONG[ma]) for i in range(4)]
    ghi["10"], ghi["30"], ghi["40"] = "= [11] + ... + [20]", "= [31] + [32] + [33]", "= [10] + [30]"
    dong = []
    for ma, ten, _ in NVNN_DONG:
        c1, c2, c3, sd = v[ma]
        dong.append((ma, ten, c1, c2, c3, c1 + c2 - c3, sd, ghi.get(ma, "")))
    la333 = sorted(S.la_bat_dau("333"), key=S.sh)
    tong333 = sum(-S.du_cuoi(m) for m in la333)
    ngoai = []
    for m in la333:
        if m in thuoc:
            continue
        x = nvnn_so_tk(S, m)
        if abs(x[0]) >= 1 or x[4] >= 1 or x[5] >= 1 or abs(x[3]) >= 1:
            ngoai.append(m)
            ct.append((m, None, x))
    ct.sort(key=lambda r: S.sh(r[0]))
    return dong, ct, tong333, ngoai


def sheet_nvnn(S, X):
    dong, ct, tong333, ngoai = nvnn(S)
    T = _dau(S, X, "TÌNH HÌNH THỰC HIỆN NGHĨA VỤ ĐỐI VỚI NHÀ NƯỚC",
             "Công thức theo bộ thiết lập chuẩn: (1) Số còn phải nộp kỳ trước chuyển sang = dư Có - dư Nợ đầu kỳ; (2) Số phải nộp trong kỳ = PS Có "
             "- PS Nợ + số đã nộp (dòng 11: PS Có - khấu trừ 133 - giảm thuế); (3) Số đã nộp trong kỳ = PS Nợ đối ứng Có 11x, 141, 131, 138, 331, "
             "338, 136, 336. Cột (4) = (1) + (2) - (3) phải bằng số dư cuối kỳ theo sổ (5): cột Chênh lệch khác 0 là còn số chưa giải thích. "
             "Số âm = nộp thừa / còn được hoàn. Phát sinh gồm cả bút toán trong phiếu kết chuyển (vd Nợ 821 / Có 3334).")
    T.append([(c, X.X_TIEUDE) for c in NVNN_COT])
    T.append([(c, X.X_GHICHU) for c in ("A", "B", "1", "2", "3", "4")])
    for ma, ten, c1, c2, c3, c4, sd, ghi in dong:
        muc = ma in NVNN_TONG
        kc, ks = (X.X_MUC, X.X_SOMUC) if muc else (X.X_CHU, X.X_SO)
        T.append([(ten, kc), (ma, kc), (c1, ks), (c2, ks), (c3, ks), (c4, ks)])
    T += khoi_ky(S, X, 6)
    return ("Nghia vu NN", [52, 10, 20, 20, 20, 20], T, 6)


# ============================================================ cong no: tuoi no, du sai ben, thu doi chieu
def tuoi_no(S, ben_no=True):
    """FIFO theo doi tuong: tang no (No 131 / Co 331) la 'hoa don', giam (Co 131 / No 331) tru dan cac hoa don cu nhat.
       -> {kh: {"du": x, "moc": [<=30, 31-90, 91-180, 181-365, >365, dau nam], "ct": [(ngay, con)]}}"""
    tt = "131" if ben_no else "331"
    la = [m for m in S.la if S.sh(m).startswith(tt)]
    dau = defaultdict(float)
    for r in S.dl.get("kh_dau") or []:
        m = int(_so(r[0]))
        if m in la:
            v = _so(r[2]) - _so(r[3])
            dau[int(_so(r[1]))] += v if ben_no else -v
    ct = defaultdict(list)
    ky_den = _ngay((S.dl.get("ky") or {}).get("den")) or datetime.date.today()
    for r in S.dl.get("cn_ct") or []:
        m = int(_so(r[0]))
        if m not in la:
            continue
        ng = _ngay(r[2])
        if not ng or ng > ky_den:
            continue
        no, co = _so(r[3]), _so(r[4])
        tang, giam = (no, co) if ben_no else (co, no)
        ct[int(_so(r[1]))].append((ng, tang, giam, str(r[5] or ""), str(r[6] or "")))
    ra = {}
    for kh in set(dau) | set(ct):
        hd = []          # [ngay, con lai, sh]
        d0 = dau.get(kh, 0.0)
        if d0 > 0:
            hd.append([None, d0, "Dư đầu năm"])
        tra_thua = max(-d0, 0.0)
        for ng, tang, giam, sh, dg in sorted(ct.get(kh, []), key=lambda x: x[0]):
            if tang > 0:
                if tra_thua > 0:
                    x = min(tra_thua, tang)
                    tra_thua -= x
                    tang -= x
                if tang > 0:
                    hd.append([ng, tang, sh])
            if giam > 0:
                for h in hd:
                    if giam <= 0:
                        break
                    x = min(h[1], giam)
                    h[1] -= x
                    giam -= x
                if giam > 0:
                    tra_thua += giam
        moc = [0.0] * 6
        for ng, con, sh in hd:
            if con <= 0.5:
                continue
            if ng is None:
                moc[5] += con
                continue
            tuoi = (ky_den - ng).days
            i = 0 if tuoi <= 30 else 1 if tuoi <= 90 else 2 if tuoi <= 180 else 3 if tuoi <= 365 else 4
            moc[i] += con
        du = sum(moc) - tra_thua
        ra[kh] = {"du": du, "moc": moc, "thua": tra_thua, "ct": [(ng, con, sh) for ng, con, sh in hd if con > 0.5]}
    return ra


def sheet_cong_no(S, X):
    sheets = []
    ky = S.dl.get("ky") or {}
    for ben_no, tieu, ten_sheet in ((True, "TUỔI NỢ PHẢI THU KHÁCH HÀNG (131) TẠI NGÀY %s" % ky.get("den", ""), "Tuoi no 131"),
                                    (False, "TUỔI NỢ PHẢI TRẢ NGƯỜI BÁN (331) TẠI NGÀY %s" % ky.get("den", ""), "Tuoi no 331")):
        tn = tuoi_no(S, ben_no)
        T = _dau(S, X, tieu, "Phân bổ theo FIFO: tiền thu (trả) trừ dần các phát sinh nợ cũ nhất; số dư đầu năm chưa rõ ngày ghi ở cột riêng. "
                 "Tuổi nợ tính theo ngày chứng từ (không phải ngày đến hạn).")
        cot = ("Đối tượng", "MST", "Dư cuối", "≤ 30 ngày", "31 - 90", "91 - 180", "181 - 365", "> 365 ngày", "Dư đầu năm chưa rõ tuổi", "Trả thừa / ứng trước")
        T.append([(c, X.X_TIEUDE) for c in cot])
        tong = [0.0] * 8
        ds = sorted(tn.items(), key=lambda kv: -abs(kv[1]["du"]))
        for kh, v in ds:
            if abs(v["du"]) < 1:
                continue
            m = v["moc"]
            T.append([(S.ten_dt(kh), X.X_CHU), (S.dt.get(kh, ["", "", ""])[2], X.X_CHU), (round(v["du"]), X.X_SO), (round(m[0]), X.X_SO), (round(m[1]), X.X_SO),
                      (round(m[2]), X.X_SO), (round(m[3]), X.X_SO), (round(m[4]), X.X_VANG if m[4] > 0.5 else X.X_SO), (round(m[5]), X.X_SO),
                      (round(v["thua"]), X.X_SO)])
            for i, x in enumerate([v["du"]] + m + [v["thua"]]):
                tong[i] += x
        T.append([("Cộng", X.X_MUC), ("", X.X_MUC)] + [(round(x), X.X_SOMUC) for x in tong])
        T += khoi_ky(S, X, 10)
        sheets.append((ten_sheet, [40, 14, 18, 16, 16, 16, 16, 16, 20, 18], T, 5))
    # du sai ben
    la_cn, d = K._cong_no(S)
    T = _dau(S, X, "CÔNG NỢ DƯ SAI BÊN: 131 dư Có (khách trả trước) và 331 dư Nợ (trả trước người bán) - để trình bày đúng trên B01a-DNN",
             "TT133: 131 dư Có trình bày ở 'Người mua trả tiền trước' (phải trả); 331 dư Nợ ở 'Trả trước cho người bán' (phải thu). "
             "Kiểm lại nếu là ghi nhầm đối tượng / nhầm tài khoản.")
    T.append([(c, X.X_TIEUDE) for c in ("TK", "Đối tượng", "MST", "Dư cuối (Nợ +, Có -)", "Trình bày")])
    n_du = 0
    for m in sorted(la_cn, key=S.sh):
        for kh, v in sorted(d[m].items(), key=lambda kv: kv[1][0] + kv[1][1] - kv[1][2]):
            cu = v[0] + v[1] - v[2]
            if (S.sh(m).startswith("131") and cu < -1) or (S.sh(m).startswith("331") and cu > 1):
                n_du += 1
                T.append([(S.sh(m), X.X_CHU), (S.ten_dt(kh), X.X_CHU), (S.dt.get(kh, ["", "", ""])[2], X.X_CHU), (round(cu), X.X_SO),
                          ("Người mua trả tiền trước ngắn hạn" if cu < 0 else "Trả trước cho người bán ngắn hạn", X.X_CHU)])
    if not n_du:
        T.append([("(không có đối tượng dư sai bên)", X.X_CHU)])
    sheets.append(("Du sai ben", [8, 44, 14, 20, 34], T, 5))
    # thu doi chieu: danh sach + mau thu (INDEX theo STT)
    cty = S.dl.get("cty") or {}
    D = _dau(S, X, "DANH SÁCH ĐỐI CHIẾU CÔNG NỢ TẠI NGÀY %s (đổi số STT ở sheet 'Mau thu' để in từng thư)" % ky.get("den", ""))
    D.append([(c, X.X_TIEUDE) for c in ("STT", "Đối tượng", "MST", "Địa chỉ", "Phải thu (131) dư Nợ", "131 dư Có", "Phải trả (331) dư Có", "331 dư Nợ")])
    gom = defaultdict(lambda: [0.0, 0.0, 0.0, 0.0])
    for m in la_cn:
        for kh, v in d[m].items():
            cu = v[0] + v[1] - v[2]
            if abs(cu) < 1:
                continue
            g = gom[kh]
            if S.sh(m).startswith("131"):
                g[0 if cu > 0 else 1] += abs(cu)
            else:
                g[2 if cu < 0 else 3] += abs(cu)
    stt = 0
    for kh, g in sorted(gom.items(), key=lambda kv: -(kv[1][0] + kv[1][2])):
        stt += 1
        D.append([(stt, X.X_SO), (S.ten_dt(kh), X.X_CHU), (S.dt.get(kh, ["", "", ""])[2], X.X_CHU), (S.dt_dc.get(kh, ""), X.X_CHU),
                  (round(g[0]), X.X_SO), (round(g[1]), X.X_SO), (round(g[2]), X.X_SO), (round(g[3]), X.X_SO)])
    sheets.append(("Doi chieu cong no", [6, 44, 14, 50, 20, 16, 20, 16], D, 4))
    n0 = 5          # dong du lieu dau tien cua danh sach (tieu de, don vi, trong, tieu de cot = 4 dong)
    idx = lambda c: "=!IFERROR(INDEX('Doi chieu cong no'!%s%d:%s%d,$B$3),\"\")" % (c, n0, c, n0 + max(stt, 1) - 1)
    M = [[("THƯ XÁC NHẬN CÔNG NỢ", X.X_TITLE)], [("Đơn vị: %s    MST: %s" % (cty.get("ten") or "", cty.get("mst") or ""), X.X_THUONG)],
         [("STT trong danh sách (đổi số này để in từng thư):", X.X_DAM), (1 if stt else "", X.X_SO)], [],
         [("Kính gửi:", X.X_DAM), (idx("B"), X.X_THUONG)], [("MST:", X.X_DAM), (idx("C"), X.X_THUONG)], [("Địa chỉ:", X.X_DAM), (idx("D"), X.X_THUONG)], [],
         [("Theo sổ kế toán của chúng tôi, đến ngày %s số dư công nợ giữa hai bên như sau (đơn vị: đồng Việt Nam):" % ky.get("den", ""), X.X_THUONG)],
         [("Quý đơn vị còn phải trả chúng tôi (phải thu 131):", X.X_CHU), (idx("E"), X.X_SO)],
         [("Quý đơn vị đã trả trước cho chúng tôi (131 dư Có):", X.X_CHU), (idx("F"), X.X_SO)],
         [("Chúng tôi còn phải trả quý đơn vị (phải trả 331):", X.X_CHU), (idx("G"), X.X_SO)],
         [("Chúng tôi đã trả trước cho quý đơn vị (331 dư Nợ):", X.X_CHU), (idx("H"), X.X_SO)], [],
         [("Đề nghị quý đơn vị kiểm tra, xác nhận và gửi lại cho chúng tôi trước ngày ....../....../.......... Nếu có chênh lệch xin ghi rõ số liệu của quý đơn vị "
           "và lý do. Sau thời hạn trên không nhận được phản hồi, chúng tôi xem như quý đơn vị đã đồng ý với số dư nêu trên.", X.X_THUONG)], [],
         [("XÁC NHẬN CỦA ĐƠN VỊ NHẬN THƯ", X.X_DAM), ("ĐƠN VỊ GỬI THƯ", X.X_DAM)],
         [("Số dư khớp / không khớp: .............................", X.X_THUONG), ("Người lập: %s" % (S.nguoi_ky.get("nguoi_lap") or ""), X.X_THUONG)],
         [("Số liệu của chúng tôi: ...............................", X.X_THUONG), ("Kế toán trưởng: %s" % (S.nguoi_ky.get("ke_toan_truong") or ""), X.X_THUONG)],
         [("Ký, đóng dấu", X.X_GHICHU), ("Người đại diện theo pháp luật: %s" % (S.nguoi_ky.get("giam_doc") or ""), X.X_THUONG)]]
    sheets.append(("Mau thu", [60, 50], M, 0))
    return sheets


# ============================================================ S01-DNN nhat ky - so cai
def sheet_s01(S, X):
    nk = S.dl.get("nk") or []
    ky = S.dl.get("ky") or {}
    # TK cap 1 dung trong ky (theo thu tu so hieu)
    cap1 = sorted({str(r[4] or "")[:3] for r in nk} | {str(r[5] or "")[:3] for r in nk})
    cap1 = [c for c in cap1 if c]
    ten_c1 = {}
    for m, t in S.tk.items():
        if len(t["sh"]) == 3:
            ten_c1[t["sh"]] = t["ten"]
    T = _dau(S, X, "S01-DNN - NHẬT KÝ - SỔ CÁI (kỳ %s - %s)" % (ky.get("tu", ""), ky.get("den", "")),
             "Mỗi dòng chứng từ = một định khoản; cột tài khoản theo TK cấp 1. Số dư đầu kỳ / cuối kỳ tính theo TK cấp 1 (cộng các TK chi tiết).")
    dau1 = [("STT dòng", X.X_TIEUDE), ("Ngày ghi sổ", X.X_TIEUDE), ("Số CT", X.X_TIEUDE), ("Ngày CT", X.X_TIEUDE), ("Diễn giải", X.X_TIEUDE),
            ("Số tiền phát sinh", X.X_TIEUDE), ("TK Nợ", X.X_TIEUDE), ("TK Có", X.X_TIEUDE)]
    for c in cap1:
        dau1 += [("%s Nợ" % c, X.X_TIEUDE), ("%s Có" % c, X.X_TIEUDE)]
    T.append(dau1)
    n_cot = len(dau1)
    # so du dau ky theo cap 1
    du_dau = defaultdict(float)
    for m in S.la:
        du_dau[S.sh(m)[:3]] += S.du_dau(m)
    d = [("", X.X_MUC), ("", X.X_MUC), ("", X.X_MUC), ("", X.X_MUC), ("Số dư đầu kỳ", X.X_MUC), ("", X.X_MUC), ("", X.X_MUC), ("", X.X_MUC)]
    for c in cap1:
        v = du_dau.get(c, 0.0)
        d += [(round(v) if v > 0.5 else "", X.X_SOMUC), (round(-v) if v < -0.5 else "", X.X_SOMUC)]
    T.append(d)
    tong = defaultdict(float)
    tong_ps = 0.0
    for i, r in enumerate(nk, start=1):
        tien = _so(r[6])
        shn, shc = str(r[4] or ""), str(r[5] or "")
        d = [(i, X.X_SO), (str(r[2] or ""), X.X_CHU), (str(r[1] or ""), X.X_CHU), (str(r[2] or ""), X.X_CHU), (str(r[3] or ""), X.X_CHU), (round(tien), X.X_SO),
             (shn, X.X_CHU), (shc, X.X_CHU)]
        for c in cap1:
            d += [(round(tien) if shn[:3] == c else "", X.X_SO), (round(tien) if shc[:3] == c else "", X.X_SO)]
            if shn[:3] == c:
                tong[(c, 0)] += tien
            if shc[:3] == c:
                tong[(c, 1)] += tien
        tong_ps += tien
        T.append(d)
    d = [("", X.X_MUC), ("", X.X_MUC), ("", X.X_MUC), ("", X.X_MUC), ("Cộng phát sinh trong kỳ", X.X_MUC), (round(tong_ps), X.X_SOMUC), ("", X.X_MUC), ("", X.X_MUC)]
    for c in cap1:
        d += [(round(tong[(c, 0)]), X.X_SOMUC), (round(tong[(c, 1)]), X.X_SOMUC)]
    T.append(d)
    d = [("", X.X_MUC), ("", X.X_MUC), ("", X.X_MUC), ("", X.X_MUC), ("Số dư cuối kỳ", X.X_MUC), ("", X.X_MUC), ("", X.X_MUC), ("", X.X_MUC)]
    for c in cap1:
        v = du_dau.get(c, 0.0) + tong[(c, 0)] - tong[(c, 1)]
        d += [(round(v) if v > 0.5 else "", X.X_SOMUC), (round(-v) if v < -0.5 else "", X.X_SOMUC)]
    T.append(d)
    T += khoi_ky(S, X, min(n_cot, 8))
    return ("S01 Nhat ky - So cai", [8, 12, 14, 12, 50, 18, 8, 8] + [16] * (2 * len(cap1)), T, 5)


# ============================================================ GD71: S14-DNN so chi tiet thanh toan voi nguoi mua / nguoi ban
def sheet_s14(S, X):
    ky = S.dl.get("ky") or {}
    d1, d2 = _ngay(ky.get("tu")), _ngay(ky.get("den"))
    la_cn, d = K._cong_no(S)
    T = _dau(S, X, "S14-DNN - SỔ CHI TIẾT THANH TOÁN VỚI NGƯỜI MUA (NGƯỜI BÁN) - kỳ %s - %s" % (ky.get("tu", ""), ky.get("den", "")),
             "Mỗi đối tượng một khối: số dư đầu kỳ, các chứng từ trong kỳ (TK đối ứng, thời hạn được chiết khấu / hạn thanh toán), số dư cuối kỳ. "
             "Dư Nợ = còn phải thu (131) / đã trả trước (331); Dư Có = khách trả trước (131) / còn phải trả (331).")
    cot = ("Ngày ghi sổ", "Số CT", "Ngày CT", "Diễn giải", "TK đối ứng", "Hạn TT", "PS Nợ", "PS Có", "Dư Nợ", "Dư Có")
    theo_dt = defaultdict(list)
    for r in S.dl.get("cn_ct") or []:
        m = int(_so(r[0]))
        if m not in la_cn:
            continue
        ng = _ngay(r[2])
        if ng and d1 and d2 and d1 <= ng <= d2:
            theo_dt[(m, int(_so(r[1])))].append((ng, str(r[5] or ""), str(r[6] or ""), str(r[8] or "") if len(r) > 8 else "", str(r[7] or ""), _so(r[3]), _so(r[4])))
    n_khoi = 0
    for m in sorted(la_cn, key=S.sh):
        for kh, v in sorted(d[m].items(), key=lambda kv: S.ten_dt(kv[0])):
            ds = sorted(theo_dt.get((m, kh), []), key=lambda x: x[0])
            dau = v[0]
            if not ds and abs(dau) < 1:
                continue
            n_khoi += 1
            T.append([("TK %s - %s" % (S.sh(m), S.ten_dt(kh)), X.X_MUC)] + [("", X.X_MUC)] * 9)
            T.append([(c, X.X_TIEUDE) for c in cot])
            T.append([("", X.X_CHU), ("", X.X_CHU), ("", X.X_CHU), ("Số dư đầu kỳ", X.X_DAM), ("", X.X_CHU), ("", X.X_CHU), ("", X.X_SO), ("", X.X_SO),
                      (round(dau) if dau > 0.5 else "", X.X_SO), (round(-dau) if dau < -0.5 else "", X.X_SO)])
            du = dau
            tn = tc = 0.0
            for ng, sh, dg, du_tk, han, no, co in ds:
                du += no - co
                tn += no
                tc += co
                T.append([(ng.strftime("%d/%m/%Y"), X.X_CHU), (sh, X.X_CHU), (ng.strftime("%d/%m/%Y"), X.X_CHU), (dg, X.X_CHU), (du_tk, X.X_CHU), (han, X.X_CHU),
                          (round(no) if no else "", X.X_SO), (round(co) if co else "", X.X_SO), (round(du) if du > 0.5 else "", X.X_SO), (round(-du) if du < -0.5 else "", X.X_SO)])
            T.append([("", X.X_MUC), ("", X.X_MUC), ("", X.X_MUC), ("Cộng phát sinh / số dư cuối kỳ", X.X_MUC), ("", X.X_MUC), ("", X.X_MUC), (round(tn), X.X_SOMUC),
                      (round(tc), X.X_SOMUC), (round(du) if du > 0.5 else "", X.X_SOMUC), (round(-du) if du < -0.5 else "", X.X_SOMUC)])
            T.append([])
    if not n_khoi:
        T.append([("(không có đối tượng nào có số dư / phát sinh trong kỳ)", X.X_CHU)])
    T += khoi_ky(S, X, 10)
    return ("S14 chi tiet thanh toan", [12, 14, 12, 44, 10, 12, 16, 16, 16, 16], T, 4)


# ============================================================ GD71: bieu mau chung tu TT133 con thieu (Excel dien san)
MENH_GIA = (500000, 200000, 100000, 50000, 20000, 10000, 5000, 2000, 1000, 500)


def _mau_dau(S, X, mau, ten, so_cot):
    cty = S.dl.get("cty") or {}
    return [[("Đơn vị: %s" % (cty.get("ten") or ""), X.X_THUONG)] + [(None, 0)] * (so_cot - 3) + [("Mẫu số %s" % mau, X.X_DAM)],
            [("Địa chỉ: ....................................", X.X_THUONG)] + [(None, 0)] * (so_cot - 3) + [("(Ban hành theo Thông tư 133/2016/TT-BTC)", X.X_GHICHU)],
            [], [(ten, X.X_TITLE)], []]


def _ky_3(X, so_cot, *chuc):
    d = [[]]
    n = len(chuc)
    vt = [int(i * (so_cot - 1) / max(1, n - 1)) for i in range(n)] if n > 1 else [0]
    for k in range(2):
        r = [(None, 0)] * so_cot
        for i, c in enumerate(chuc):
            r[vt[i]] = ((c, "(Ký, họ tên)")[k], X.X_DAM if k == 0 else X.X_GHICHU)
        d.append(r)
    return d


def sheet_mau(S, X):
    sheets = []
    ky = S.dl.get("ky") or {}
    d2 = _ngay(ky.get("den")) or datetime.date.today()
    nk = S.nguoi_ky
    # ---- 08a-TT bang kiem ke quy (VND)
    quy = S.tong_du(("1111",), S.du_cuoi) if S.la_bat_dau("1111") else S.tong_du(("111",), S.du_cuoi)   # GD72: khong lan 1112 ngoai te
    T = _mau_dau(S, X, "08a-TT", "BẢNG KIỂM KÊ QUỸ (dùng cho VND)", 5)
    T += [[("Hôm nay, vào ..... giờ ..... ngày %02d tháng %02d năm %d" % (d2.day, d2.month, d2.year), X.X_THUONG)],
          [("Chúng tôi gồm:", X.X_THUONG)],
          [("- Ông/Bà: %s - Đại diện kế toán" % (nk.get("ke_toan_truong") or "..............................."), X.X_THUONG)],
          [("- Ông/Bà: %s - Thủ quỹ" % (nk.get("thu_quy") or "..............................."), X.X_THUONG)],
          [("- Ông/Bà: ............................... - Người chịu trách nhiệm kiểm kê", X.X_THUONG)],
          [("Cùng tiến hành kiểm kê quỹ tiền mặt, kết quả như sau:", X.X_THUONG)], [],
          [(c, X.X_TIEUDE) for c in ("STT", "Diễn giải", "Số lượng (tờ)", "Mệnh giá", "Số tiền")],
          [("I", X.X_CHU), ("Số dư theo sổ quỹ (tính từ chứng từ đến ngày kiểm kê)", X.X_DAM), ("", X.X_CHU), ("", X.X_CHU), (round(quy), X.X_SOMUC)],
          [("II", X.X_CHU), ("Số kiểm kê thực tế", X.X_DAM), ("", X.X_CHU), ("", X.X_CHU), ("", X.X_SOMUC)]]
    r0 = len(T) + 1
    T[-1][4] = ("=!SUM(E%d:E%d)" % (r0, r0 + len(MENH_GIA) - 1), X.X_SOMUC)
    for i, mg in enumerate(MENH_GIA):
        T.append([(i + 1, X.X_SO), ("Loại %s đồng" % _dd(mg), X.X_CHU), ("", X.X_SO), (mg, X.X_SO), ("=!C%d*D%d" % (r0 + i, r0 + i), X.X_SO)])
    T.append([("III", X.X_CHU), ("Chênh lệch (II - I)", X.X_DAM), ("", X.X_CHU), ("", X.X_CHU), ("=!E%d-E%d" % (r0 - 1, r0 - 2), X.X_SOMUC)])
    if quy < -0.5:      # GD72: so quy am - kiem ke se lech gia, phai soat so truoc
        T.append([("!", X.X_DO), ("SỔ QUỸ ĐANG ÂM %s đồng (TK 111 dư Có) tại ngày %s: chi vượt số tồn hoặc ghi thiếu phiếu thu / ghi nhầm tài khoản. "
                                  "Soát sổ quỹ trước khi kiểm kê." % (_dd(round(-quy)), d2.strftime("%d/%m/%Y")), X.X_DO)])
    T += [[], [("- Lý do: + Thừa: ......................................................................", X.X_THUONG)],
          [("            + Thiếu: ......................................................................", X.X_THUONG)],
          [("- Kết luận sau khi kiểm kê quỹ: ......................................................................", X.X_THUONG)]]
    T += _ky_3(X, 5, "Kế toán trưởng", "Thủ quỹ", "Người chịu trách nhiệm kiểm kê quỹ")
    sheets.append(("08a-TT Kiem ke quy", [6, 56, 14, 14, 18], T, 0))
    # ---- tam ung 141 theo doi tuong (dung cho 03-TT / 04-TT)
    tu = defaultdict(lambda: {"ten": "", "dau": 0.0, "no": 0.0, "co": 0.0, "ct": []})
    d1 = _ngay(ky.get("tu"))
    for r in S.tu:
        ng = _ngay(r[0])
        dt = str(r[5] or "")
        x = tu[dt]
        x["ten"] = str(r[6] or "") or x["ten"]
        no, co = _so(r[3]), _so(r[4])
        if ng and d2 and ng > d2:
            continue
        if ng and d1 and ng < d1:
            x["dau"] += no - co
        else:
            x["no"] += no
            x["co"] += co
            x["ct"].append((ng, str(r[1] or ""), str(r[2] or ""), no, co))
    dau_141 = S.tong_du(("141",), S.du_nam)
    L = _dau(S, X, "TẠM ỨNG (TK 141) THEO ĐỐI TƯỢNG - dùng cho Giấy đề nghị tạm ứng (03-TT) và Giấy thanh toán tiền tạm ứng (04-TT)",
             "Số dư đầu năm 141 theo sổ: %s (chưa tách theo người nếu chứng từ không ghi đối tượng). Đổi ô STT ở sheet 04-TT để lập giấy thanh toán cho từng người." % _dd(dau_141))
    L.append([(c, X.X_TIEUDE) for c in ("STT", "Đối tượng", "Dư đầu kỳ (chưa thanh toán)", "Tạm ứng trong kỳ (Nợ 141)", "Đã thanh toán / hoàn (Có 141)", "Còn phải thanh toán")])
    stt = 0
    for dt, x in sorted(tu.items(), key=lambda kv: -(kv[1]["dau"] + kv[1]["no"] - kv[1]["co"])):
        stt += 1
        L.append([(stt, X.X_SO), ((dt + " " + x["ten"]).strip() or "(không ghi đối tượng)", X.X_CHU), (round(x["dau"]), X.X_SO), (round(x["no"]), X.X_SO),
                  (round(x["co"]), X.X_SO), (round(x["dau"] + x["no"] - x["co"]), X.X_SO)])
    if not stt:
        L.append([("(kỳ này không có phát sinh TK 141)", X.X_CHU)])
    sheets.append(("Tam ung 141", [6, 44, 22, 22, 22, 22], L, 4))
    n0 = 5
    idx = lambda c: "=!IFERROR(INDEX('Tam ung 141'!%s%d:%s%d,$E$3),\"\")" % (c, n0, c, n0 + max(stt, 1) - 1)
    T = _mau_dau(S, X, "03-TT", "GIẤY ĐỀ NGHỊ TẠM ỨNG", 5)
    T += [[("Ngày ..... tháng ..... năm %d" % d2.year, X.X_THUONG)], [("Số: ............", X.X_THUONG)], [],
          [("Kính gửi: %s" % (nk.get("giam_doc") or "..............................."), X.X_THUONG)],
          [("Tên tôi là: ......................................................................", X.X_THUONG)],
          [("Bộ phận (hoặc địa chỉ): ......................................................................", X.X_THUONG)],
          [("Đề nghị cho tạm ứng số tiền: .......................... (Viết bằng chữ): ..........................................", X.X_THUONG)],
          [("Lý do tạm ứng: ......................................................................", X.X_THUONG)],
          [("Thời hạn thanh toán: ......................................................................", X.X_THUONG)]]
    T += _ky_3(X, 5, "Giám đốc", "Kế toán trưởng", "Phụ trách bộ phận", "Người đề nghị tạm ứng")
    sheets.append(("03-TT De nghi tam ung", [30, 30, 20, 20, 20], T, 0))
    T = _mau_dau(S, X, "04-TT", "GIẤY THANH TOÁN TIỀN TẠM ỨNG", 5)
    T[0] = [("Đơn vị: %s" % ((S.dl.get("cty") or {}).get("ten") or ""), X.X_THUONG), (None, 0), (None, 0), ("STT người (sheet Tam ung 141):", X.X_DAM), (1 if stt else "", X.X_SO)]
    T += [[("Ngày %02d tháng %02d năm %d" % (d2.day, d2.month, d2.year), X.X_THUONG)],
          [("Họ và tên người thanh toán:", X.X_THUONG), (idx("B"), X.X_THUONG)],
          [("Bộ phận (hoặc địa chỉ): ......................................................................", X.X_THUONG)],
          [("Số tiền tạm ứng được thanh toán theo bảng dưới đây:", X.X_THUONG)], [],
          [(c, X.X_TIEUDE) for c in ("Diễn giải", "", "", "", "Số tiền")],
          [("I. Số tiền tạm ứng", X.X_DAM), ("", X.X_CHU), ("", X.X_CHU), ("", X.X_CHU), ("=!E%d+E%d" % (len(T) + 8, len(T) + 9), X.X_SOMUC)],
          [("   1. Số tạm ứng các kỳ trước chưa chi hết", X.X_CHU), ("", X.X_CHU), ("", X.X_CHU), ("", X.X_CHU), (idx("C"), X.X_SO)],
          [("   2. Số tạm ứng kỳ này", X.X_CHU), ("", X.X_CHU), ("", X.X_CHU), ("", X.X_CHU), (idx("D"), X.X_SO)],
          [("II. Số tiền đã chi (theo chứng từ kèm theo)", X.X_DAM), ("", X.X_CHU), ("", X.X_CHU), ("", X.X_CHU), (idx("E"), X.X_SOMUC)],
          [("III. Chênh lệch", X.X_DAM), ("", X.X_CHU), ("", X.X_CHU), ("", X.X_CHU), ("=!E%d-E%d" % (len(T) + 7, len(T) + 10), X.X_SOMUC)],
          [("   1. Số tạm ứng chi không hết (I - II)", X.X_CHU), ("", X.X_CHU), ("", X.X_CHU), ("", X.X_CHU), ("=!MAX(E%d,0)" % (len(T) + 11), X.X_SO)],
          [("   2. Chi quá số tạm ứng (II - I)", X.X_CHU), ("", X.X_CHU), ("", X.X_CHU), ("", X.X_CHU), ("=!MAX(-E%d,0)" % (len(T) + 11), X.X_SO)]]
    T += _ky_3(X, 5, "Giám đốc", "Kế toán trưởng", "Kế toán thanh toán", "Người đề nghị thanh toán")
    sheets.append(("04-TT Thanh toan tam ung", [40, 12, 12, 30, 20], T, 0))
    # ---- 10-LDTL bang thanh toan tien thuong
    nvs = {}
    for r in S.luong:
        nvs.setdefault(int(_so(r[0])), None)
    T = _mau_dau(S, X, "10-LĐTL", "BẢNG THANH TOÁN TIỀN THƯỞNG - tháng ..... năm %d" % d2.year, 8)
    T.append([(c, X.X_TIEUDE) for c in ("STT", "Họ và tên", "Chức vụ", "Bậc lương", "Mức thưởng - Xếp loại", "Mức thưởng - Số tiền", "Ghi chú", "Ký nhận")])
    for i, ma in enumerate(sorted(nvs), start=1):
        nv = S.nv.get(ma, ["", "", ""])
        T.append([(i, X.X_SO), ((nv[0] + " " + nv[1]).strip() or "NV %d" % ma, X.X_CHU), (nv[2], X.X_CHU), ("", X.X_CHU), ("", X.X_CHU), ("", X.X_SO), ("", X.X_CHU), ("", X.X_CHU)])
    for i in range(max(0, 15 - len(nvs))):
        T.append([(len(nvs) + i + 1, X.X_SO)] + [("", X.X_CHU)] * 4 + [("", X.X_SO), ("", X.X_CHU), ("", X.X_CHU)])
    T.append([("", X.X_MUC), ("Cộng", X.X_MUC), ("", X.X_MUC), ("", X.X_MUC), ("", X.X_MUC), ("=!SUM(F%d:F%d)" % (6, len(T)), X.X_SOMUC), ("", X.X_MUC), ("", X.X_MUC)])
    T += _ky_3(X, 8, "Người lập biểu", "Kế toán trưởng", "Giám đốc")
    sheets.append(("10-LDTL Tien thuong", [6, 32, 16, 12, 16, 18, 20, 14], T, 5))
    # ---- 11-LDTL bang ke trich nop cac khoan theo luong
    T = _mau_dau(S, X, "11-LĐTL", "BẢNG KÊ TRÍCH NỘP CÁC KHOẢN THEO LƯƠNG - kỳ %s - %s" % (ky.get("tu", ""), ky.get("den", "")), 12)
    T.append([(c, X.X_TIEUDE) for c in ("Tháng", "Số người", "Tổng quỹ lương", "BHXH - Tổng", "BHXH - DN trích", "BHXH - NLĐ", "BHYT - Tổng", "BHYT - DN", "BHYT - NLĐ",
                                        "BHTN - Tổng", "BHTN - DN", "BHTN - NLĐ")])
    thang = defaultdict(lambda: [0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
    thang_ky = {(t + S.dau_ky - 2) % 12 + 1 for t in range(S.t1, S.t2 + 1)}
    for r in S.luong:
        t = int(_so(r[1]))
        if t not in thang_ky:
            continue
        x = thang[t]
        x[0] += 1
        x[1] += _so(r[2])
        x[2] += _so(r[7]); x[3] += _so(r[4]); x[4] += _so(r[8]); x[5] += _so(r[5]); x[6] += _so(r[9]); x[7] += _so(r[6])
    nguon = "Số liệu từ Bảng lương trong sổ (BHXH / BHYT / BHTN phần doanh nghiệp và người lao động)."
    if not thang:
        nguon = "Sổ chưa có Bảng lương: lấy phát sinh Có 3383 / 3384 / 3385 theo tháng (chưa tách phần DN / NLĐ) - điền tay phần còn thiếu."
        for t in range(S.t1, S.t2 + 1):
            thang_dl = (t + S.dau_ky - 2) % 12 + 1
            x = thang[thang_dl]
            for tt, i in (("3383", 2), ("3384", 4), ("3385", 6)):
                x[i] += sum(S.ps[m]["thang"].get(t, [0, 0, 0, 0])[1] for m in S.la_bat_dau(tt) if m in S.ps)
            x[1] += sum(S.ps[m]["thang"].get(t, [0, 0, 0, 0])[1] for m in S.la_bat_dau("334") if m in S.ps)
    tong = [0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    for t in sorted(thang):
        x = thang[t]
        T.append([("Tháng %d" % t, X.X_CHU), (x[0], X.X_SO), (round(x[1]), X.X_SO), (round(x[2] + x[3]), X.X_SO), (round(x[2]), X.X_SO), (round(x[3]), X.X_SO),
                  (round(x[4] + x[5]), X.X_SO), (round(x[4]), X.X_SO), (round(x[5]), X.X_SO), (round(x[6] + x[7]), X.X_SO), (round(x[6]), X.X_SO), (round(x[7]), X.X_SO)])
        for i in range(8):
            tong[i] += x[i]
    T.append([("Cộng", X.X_MUC), (tong[0], X.X_SOMUC), (round(tong[1]), X.X_SOMUC), (round(tong[2] + tong[3]), X.X_SOMUC), (round(tong[2]), X.X_SOMUC), (round(tong[3]), X.X_SOMUC),
              (round(tong[4] + tong[5]), X.X_SOMUC), (round(tong[4]), X.X_SOMUC), (round(tong[5]), X.X_SOMUC), (round(tong[6] + tong[7]), X.X_SOMUC), (round(tong[6]), X.X_SOMUC), (round(tong[7]), X.X_SOMUC)])
    T.append([(nguon + " Kinh phí công đoàn (2% quỹ lương, nếu có) ghi thêm cột riêng khi nộp.", X.X_GHICHU)])
    T += _ky_3(X, 12, "Người lập biểu", "Kế toán trưởng", "Giám đốc")
    sheets.append(("11-LDTL Trich nop", [10, 9, 18, 16, 16, 16, 16, 16, 16, 16, 16, 16], T, 6))
    # ---- 05-TSCD bien ban kiem ke TSCD
    T = _mau_dau(S, X, "05-TSCĐ", "BIÊN BẢN KIỂM KÊ TÀI SẢN CỐ ĐỊNH - thời điểm kiểm kê: ..... giờ ..... ngày %02d/%02d/%d" % (d2.day, d2.month, d2.year), 13)
    T += [[("Ban kiểm kê gồm: - Ông/Bà: ............................... Trưởng ban;  - Ông/Bà: ............................... Uỷ viên;  - Ông/Bà: ............................... Uỷ viên", X.X_THUONG)],
          [("Đã kiểm kê TSCĐ, kết quả như sau (số liệu theo sổ tại tháng cuối kỳ; cột kiểm kê điền tay, chênh lệch tự tính):", X.X_THUONG)], []]
    T.append([(c, X.X_TIEUDE) for c in ("STT", "Tên TSCĐ", "Mã số", "Nơi sử dụng", "Theo sổ - SL", "Theo sổ - Nguyên giá", "Theo sổ - GTCL", "Kiểm kê - SL",
                                        "Kiểm kê - Nguyên giá", "Kiểm kê - GTCL", "Chênh lệch - SL", "Chênh lệch - NG", "Ghi chú")])
    r0 = len(T) + 1
    for i, r in enumerate(S.ts, start=1):
        rr = r0 + i - 1
        T.append([(i, X.X_SO), (str(r[2] or ""), X.X_CHU), (str(r[1] or ""), X.X_CHU), (str(r[7] or ""), X.X_CHU), (1, X.X_SO), (round(_so(r[4])), X.X_SO), (round(_so(r[6])), X.X_SO),
                  ("", X.X_SO), ("", X.X_SO), ("", X.X_SO), ("=!IF(H%d=\"\",\"\",H%d-E%d)" % (rr, rr, rr), X.X_SO), ("=!IF(I%d=\"\",\"\",I%d-F%d)" % (rr, rr, rr), X.X_SO), ("", X.X_CHU)])
    if not S.ts:
        T.append([("(sổ chưa có tài sản cố định)", X.X_CHU)])
    T.append([("", X.X_MUC), ("Cộng", X.X_MUC), ("", X.X_MUC), ("", X.X_MUC), (len(S.ts), X.X_SOMUC), (round(sum(_so(r[4]) for r in S.ts)), X.X_SOMUC),
              (round(sum(_so(r[6]) for r in S.ts)), X.X_SOMUC), ("", X.X_MUC), ("", X.X_MUC), ("", X.X_MUC), ("", X.X_MUC), ("", X.X_MUC), ("", X.X_MUC)])
    T += _ky_3(X, 13, "Giám đốc", "Kế toán trưởng", "Trưởng ban kiểm kê")
    sheets.append(("05-TSCD Kiem ke", [5, 34, 14, 14, 8, 16, 16, 8, 16, 16, 10, 14, 16], T, 9))
    # ---- 02-TSCD bien ban thanh ly (INDEX theo STT tai san o sheet kiem ke)
    idx2 = lambda c: "=!IFERROR(INDEX('05-TSCD Kiem ke'!%s%d:%s%d,$E$3),\"\")" % (c, r0, c, r0 + max(len(S.ts), 1) - 1)
    T = _mau_dau(S, X, "02-TSCĐ", "BIÊN BẢN THANH LÝ TÀI SẢN CỐ ĐỊNH", 5)
    T[0] = [("Đơn vị: %s" % ((S.dl.get("cty") or {}).get("ten") or ""), X.X_THUONG), (None, 0), (None, 0), ("STT tài sản (sheet 05-TSCD):", X.X_DAM), (1 if S.ts else "", X.X_SO)]
    T += [[("Ngày ..... tháng ..... năm %d     Số: ............     Nợ: ...........     Có: ..........." % d2.year, X.X_THUONG)],
          [("Căn cứ Quyết định số: .......... ngày ..... tháng ..... năm ..... của .......................... về việc thanh lý tài sản cố định.", X.X_THUONG)],
          [("I. Ban thanh lý TSCĐ gồm: Ông/Bà ............................... Trưởng ban; Ông/Bà ............................... Uỷ viên; Ông/Bà ............................... Uỷ viên", X.X_THUONG)],
          [("II. Tiến hành thanh lý TSCĐ:", X.X_DAM)],
          [("- Tên, ký mã hiệu, quy cách (cấp hạng) TSCĐ:", X.X_CHU), (idx2("B"), X.X_THUONG)], [("- Số hiệu TSCĐ:", X.X_CHU), (idx2("C"), X.X_THUONG)],
          [("- Nước sản xuất (xây dựng): ..........................", X.X_CHU)], [("- Năm sản xuất: ..........     Năm đưa vào sử dụng: ..........", X.X_CHU)],
          [("- Nguyên giá TSCĐ:", X.X_CHU), (idx2("F"), X.X_SO)], [("- Giá trị hao mòn đã trích đến thời điểm thanh lý:", X.X_CHU), ("=!IFERROR(B%d-B%d,\"\")" % (len(T) + 9, len(T) + 11), X.X_SO)],
          [("- Giá trị còn lại của TSCĐ:", X.X_CHU), (idx2("G"), X.X_SO)],
          [("III. Kết luận của Ban thanh lý TSCĐ: ......................................................................", X.X_DAM)],
          [("IV. Kết quả thanh lý TSCĐ:", X.X_DAM)], [("- Chi phí thanh lý TSCĐ: .......................... (viết bằng chữ) ..........................", X.X_CHU)],
          [("- Giá trị thu hồi: .......................... (viết bằng chữ) ..........................", X.X_CHU)],
          [("- Đã ghi giảm sổ TSCĐ ngày ..... tháng ..... năm .....", X.X_CHU)]]
    T += _ky_3(X, 5, "Giám đốc", "Kế toán trưởng", "Trưởng ban thanh lý")
    sheets.append(("02-TSCD Thanh ly", [44, 30, 12, 26, 12], T, 0))
    # ---- GD74: 09-TT bang ke chi tien (phieu chi tien mat trong ky, theo nhat ky cua ky)
    nkct = S.dl.get("nk") or []
    gop = {}      # mot phieu chi (so CT + ngay) mot dong: cong tien, TK No ghep
    for r in nkct:
        if not str(r[5] or "").startswith("111"):
            continue
        k = (str(r[1] or ""), str(r[2] or ""))
        x = gop.setdefault(k, [r[1], r[2], str(r[3] or ""), [], 0.0])
        if str(r[4] or "") not in x[3]:
            x[3].append(str(r[4] or ""))
        x[4] += _so(r[6])
    chi = [[None, a, b, c, ", ".join(d), e] for (a, b, c, d, e) in gop.values()]
    chi.sort(key=lambda r: (_ngay(r[2]) or datetime.date.min, str(r[1])))
    T = _mau_dau(S, X, "09-TT", "BẢNG KÊ CHI TIỀN", 6)
    T += [[("Họ và tên người chi: ...............................     Bộ phận (hoặc địa chỉ): ...............................", X.X_THUONG)],
          [("Chi cho công việc: ...............................", X.X_THUONG)],
          [("Kỳ: %s - %s. Điền sẵn các phiếu chi tiền mặt (Có TK 111) đã ghi sổ trong kỳ; xoá dòng không thuộc bảng kê này." % (ky.get("tu", ""), ky.get("den", "")), X.X_GHICHU)], [],
          [(c, X.X_TIEUDE) for c in ("STT", "Số CT", "Ngày CT", "Nội dung chi", "TK ghi Nợ", "Số tiền")]]
    r0 = len(T) + 1
    for i, r in enumerate(chi, 1):
        T.append([(i, X.X_SO), (str(r[1] or ""), X.X_CHU), (str(r[2] or ""), X.X_CHU), (str(r[3] or ""), X.X_CHU), (str(r[4] or ""), X.X_CHU), (round(_so(r[5])), X.X_SO)])
    if not chi:
        T.append([("", X.X_SO), ("(kỳ này sổ không có phiếu chi tiền mặt)", X.X_CHU), ("", X.X_CHU), ("", X.X_CHU), ("", X.X_CHU), ("", X.X_SO)])
    T.append([("", X.X_MUC), ("Cộng", X.X_MUC), ("", X.X_MUC), ("", X.X_MUC), ("", X.X_MUC), ("=!SUM(F%d:F%d)" % (r0, r0 + max(len(chi), 1) - 1), X.X_SOMUC)])
    T += [[("Số tiền bằng chữ: ......................................................................", X.X_THUONG)],
          [("(Kèm theo ..... chứng từ gốc)", X.X_GHICHU)]]
    T += _ky_3(X, 6, "Người lập bảng kê", "Kế toán trưởng", "Người duyệt")
    sheets.append(("09-TT Bang ke chi tien", [5, 12, 12, 52, 10, 18], T, 0))
    # ---- GD74: 07-VT bang phan bo nguyen lieu, vat lieu, cong cu, dung cu (doi tuong su dung = TK ghi No; Co 152 / 153 / 242)
    pb = defaultdict(lambda: [0.0, 0.0, 0.0])
    for (a, b), th in S.du.items():
        shb = S.sh(b)
        cot = 0 if shb.startswith("152") else 1 if shb.startswith("153") else 2 if shb.startswith("242") else -1
        if cot < 0:
            continue
        v = sum(x for t, x in th.items() if S.t1 <= t <= S.t2)
        if abs(v) > 0.5:
            pb[a][cot] += v
    T = _mau_dau(S, X, "07-VT", "BẢNG PHÂN BỔ NGUYÊN LIỆU, VẬT LIỆU, CÔNG CỤ, DỤNG CỤ", 7)
    T += [[("Kỳ: %s - %s. Số theo sổ: giá trị NVL (Có 152), CCDC (Có 153) xuất dùng và chi phí trả trước phân bổ (Có 242) theo tài khoản ghi Nợ." % (ky.get("tu", ""), ky.get("den", "")), X.X_GHICHU)], [],
          [(c, X.X_TIEUDE) for c in ("STT", "TK ghi Nợ (đối tượng sử dụng)", "Tên tài khoản", "Có TK 152", "Có TK 153", "Có TK 242", "Cộng")]]
    r0 = len(T) + 1
    dong = sorted(pb.items(), key=lambda x: S.sh(x[0]))
    for i, (a, v) in enumerate(dong, 1):
        T.append([(i, X.X_SO), (S.sh(a), X.X_CHU), ((S.tk.get(a) or {}).get("ten", ""), X.X_CHU), (round(v[0]), X.X_SO), (round(v[1]), X.X_SO), (round(v[2]), X.X_SO),
                  ("=!SUM(D%d:F%d)" % (r0 + i - 1, r0 + i - 1), X.X_SO)])
    if not dong:
        T.append([("", X.X_SO), ("(kỳ này sổ không có xuất NVL / CCDC, phân bổ 242)", X.X_CHU), ("", X.X_CHU), ("", X.X_SO), ("", X.X_SO), ("", X.X_SO), ("", X.X_SO)])
    r1 = r0 + max(len(dong), 1) - 1
    T.append([("", X.X_MUC), ("Cộng", X.X_MUC), ("", X.X_MUC)] + [("=!SUM(%s%d:%s%d)" % (c, r0, c, r1), X.X_SOMUC) for c in "DEFG"])
    T += _ky_3(X, 7, "Người lập biểu", "Kế toán trưởng")
    sheets.append(("07-VT Phan bo NVL CCDC", [5, 26, 36, 16, 16, 16, 16], T, 0))
    # ---- GD74: 05-TT giay de nghi thanh toan (mau trong, ten nguoi ky theo khai bao)
    T = _mau_dau(S, X, "05-TT", "GIẤY ĐỀ NGHỊ THANH TOÁN", 5)
    T += [[("Ngày ..... tháng ..... năm %d" % d2.year, X.X_THUONG)],
          [("Kính gửi: %s" % (nk.get("giam_doc") or "..............................."), X.X_THUONG)],
          [("Họ và tên người đề nghị thanh toán: ...............................", X.X_THUONG)],
          [("Bộ phận (hoặc địa chỉ): ...............................", X.X_THUONG)],
          [("Nội dung thanh toán: ......................................................................", X.X_THUONG)],
          [("Số tiền: ..........................     (Viết bằng chữ): ......................................................................", X.X_THUONG)],
          [("(Kèm theo ..... chứng từ gốc)", X.X_GHICHU)]]
    T += _ky_3(X, 5, "Người đề nghị thanh toán", "Kế toán trưởng", "Người duyệt")
    sheets.append(("05-TT De nghi thanh toan", [30, 22, 22, 22, 22], T, 0))
    return sheets


# ============================================================ lap Excel
# ============================================================ GD211: Bang ke thu mua hang hoa, dich vu mua vao khong co hoa don (mau 02/TNDN)
# Can cu: Luat Thue TNDN 2025; Nghi dinh 320/2025/ND-CP Dieu 9 khoan 1 diem b (5 truong hop duoc lap bang ke); Thong tu 20/2026/TT-BTC
# (ban hanh mau 02/TNDN thay mau 01/TNDN cua TT78/2014). Tu 15/12/2025: tong mua trong ngay tu 5 trieu dong tro len cua mot nguoi ban
# phai thanh toan khong dung tien mat. Bang ke do nguoi mua lap, nguoi dai dien theo phap luat (hoac nguoi duoc uy quyen) ky.
NGUONG_TIEN_MAT = 5000000
THU_MUA_COT = ("STT", "Ngày mua", "Họ và tên người bán", "Địa chỉ", "Số CCCD / mã định danh cá nhân", "Tên hàng hoá, dịch vụ",
               "Số lượng", "Đơn giá", "Tổng số tiền thanh toán", "Ghi chú")


def _chu_so_dinh_danh(v):
    return re.sub(r"\D", "", str(v or ""))


def _tel(v):
    """so dien thoai that (bo gia tri trang / '...' / '-')."""
    v = str(v or "").strip()
    return v if re.search(r"\d", v) else ""


def thu_mua_dong(S):
    """Cac dong mua vao khong co hoa don tu VB6 (nhap hang, khong co so hoa don) -> danh sach dict da gan ten / dia chi / dinh danh."""
    ky = S.dl.get("ky") or {}
    d1, d2 = _ngay(ky.get("tu")), _ngay(ky.get("den"))
    kq = []
    for r in S.dl.get("thu_mua") or []:
        r = list(r) + [None] * (11 - len(r))
        ng = _ngay(r[0])
        if ng is None or (d1 and ng < d1) or (d2 and ng > d2):
            continue
        kh = int(_so(r[2]))
        dt = S.dt.get(kh) or ["", "", ""]
        kq.append(dict(ngay=ng, so_ct=str(r[1] or ""), kh=kh, ten=dt[1], dinh_danh=str(dt[2] or "").strip(), dia_chi=S.dt_dc.get(kh, ""), tel=_tel(getattr(S, "dt_tel", {}).get(kh, "")),
                       ma_vt=str(r[3] or ""), ten_vt=str(r[4] or ""), dvt=str(r[5] or ""), sl=_so(r[6]), tien=_so(r[7]),
                       tk_no=str(r[8] or ""), tk_co=str(r[9] or ""), dien_giai=str(r[10] or "")))
    kq.sort(key=lambda x: (x["ngay"], x["ten"], x["so_ct"]))
    return kq


def thu_mua_tra_tien_mat(S):
    """{ma nguoi ban: tong tien mat da tra trong ky} tu cac phieu Co 111 / No 331 (VB: tra_nb = [ngay, ma doi tuong, TK Co, tien])."""
    kq = defaultdict(float)
    for r in S.dl.get("tra_nb") or []:
        r = list(r) + [None] * (4 - len(r))
        if str(r[2] or "").startswith("111"):
            kq[int(_so(r[1]))] += _so(r[3])
    return kq


def thu_mua_kiem_tra(ds, tien_mat_da_tra=None):
    """[(muc_do, ngay/nguoi ban, noi dung)] - muc_do: 'DO' (khong du dieu kien) / 'VANG' (can xem lai)."""
    kq = []
    mat_tra = tien_mat_da_tra or {}
    theo = defaultdict(lambda: [0.0, 0.0, 0.0])          # (ngay, kh) -> tong, tra thang bang tien mat (Co 111), ghi cong no
    for x in ds:
        t = theo[(x["ngay"], x["kh"])]
        t[0] += x["tien"]
        if x["tk_co"].startswith("111"):
            t[1] += x["tien"]
        elif x["tk_co"].startswith("331"):
            t[2] += x["tien"]
    ten = {x["kh"]: x["ten"] for x in ds}
    for (ng, kh), (tong, mat, no) in sorted(theo.items(), key=lambda kv: (kv[0][0], str(ten.get(kv[0][1], "")))):
        nb = ten.get(kh) or "(chưa chọn người bán)"
        if tong >= NGUONG_TIEN_MAT and mat > 0:
            kq.append(("DO", "%s - %s" % (ng.strftime("%d/%m/%Y"), nb),
                       "Tổng mua trong ngày %s đồng, trong đó trả tiền mặt %s đồng: từ 5 triệu đồng/ngày/người bán phải thanh toán không dùng tiền mặt "
                       "(chuyển khoản), nếu không khoản chi không được tính vào chi phí được trừ." % (_dd(round(tong)), _dd(round(mat)))))
        elif tong >= NGUONG_TIEN_MAT and no > 0:
            tra = mat_tra.get(kh, 0.0)
            them = (" Trong kỳ đã có phiếu chi tiền mặt %s đồng cho người bán này: kiểm tra khoản trả có thuộc ngày mua này không." % _dd(round(tra))) if tra > 0 else ""
            kq.append(("VANG", "%s - %s" % (ng.strftime("%d/%m/%Y"), nb),
                       "Tổng mua trong ngày %s đồng ghi công nợ (TK 331): khi trả tiền phải chuyển khoản, không trả tiền mặt.%s" % (_dd(round(tong)), them)))
    vistr = set()
    for x in ds:
        k = x["kh"]
        if k in vistr:
            continue
        vistr.add(k)
        nb = x["ten"] or "(chưa chọn người bán)"
        if not k:
            kq.append(("DO", nb, "Có dòng mua vào chưa gắn người bán: bảng kê phải ghi họ tên người bán."))
            continue
        dd = _chu_so_dinh_danh(x["dinh_danh"])
        if not dd:
            kq.append(("DO", nb, "Thiếu số CCCD / mã định danh cá nhân của người bán (ghi vào ô Mã số thuế của đối tượng)."))
        elif len(dd) == 12:
            pass
        elif len(dd) in (10, 13):
            kq.append(("VANG", nb, "Đối tượng có mã số thuế (%s): nếu là doanh nghiệp / hộ kinh doanh đã đăng ký kê khai thì phải lấy hoá đơn, "
                                   "chỉ lập bảng kê khi thuộc 5 trường hợp được lập bảng kê." % dd))
        else:
            kq.append(("VANG", nb, "Số định danh (%s) không đủ 12 chữ số của CCCD: kiểm tra lại." % dd))
        if not x["dia_chi"].strip():
            kq.append(("DO", nb, "Thiếu địa chỉ cư trú của người bán."))
    return kq


class _Dong(list):
    """danh sach dong + 'gop' = cac o can gop them (viet_xlsx_o doc thuoc tinh nay)."""
    gop = ()


def _bo_cccd(ten):
    """Ten khach co kem so CCCD/CMND o cuoi (vd 'Hoang Thong 096071010161') -> chi lay ho ten cho bang ke."""
    t = str(ten or "").strip()
    m = re.match(r"^(.*?)[\s,\-]*\d{9}(?:\d{3})?$", t)
    return (m.group(1).strip() if m and m.group(1).strip() else t)


THU_MUA_RONG = [12, 26, 34, 20, 16, 32, 10, 12, 14, 18, 16]


def sheet_thu_mua(S, X):
    """GD220: dung MAU HIEN HANH 02/TNDN (TT 20/2026/TT-BTC): Ngay thang | Nguoi ban (ten, dia chi, so can cuoc, so dien thoai) |
    Hang hoa, dich vu mua (ten, DVT, so luong, don gia, tong gia thanh toan) | Ghi chu."""
    cty = S.dl.get("cty") or {}
    ky = S.dl.get("ky") or {}
    ds = thu_mua_dong(S)
    ncot = len(THU_MUA_RONG)
    dc = cty.get("dia_chi") or S.dl.get("cty_dc") or ""
    dt = cty.get("dien_thoai") or S.dl.get("cty_dt") or ""
    d1, d2 = _ngay(ky.get("tu")), _ngay(ky.get("den"))
    if d1 and d2 and d1 != d2:
        ngay_ky_hieu = "(Từ ngày %02d tháng %02d năm %d đến ngày %02d tháng %02d năm %d)" % (d1.day, d1.month, d1.year, d2.day, d2.month, d2.year)
    else:
        d = d1 or d2 or datetime.date.today()
        ngay_ky_hieu = "(Ngày %02d tháng %02d năm %d)" % (d.day, d.month, d.year)
    T = [[(None, 0)] * (ncot - 2) + [("Mẫu số: 02/TNDN", X.X_DAM), (None, 0)],
         [(None, 0)] * (ncot - 2) + [("(Ban hành kèm theo Thông tư số 20/2026/TT-BTC của Bộ trưởng Bộ Tài chính)", X.X_GHICHU), (None, 0)],
         [("BẢNG KÊ THU MUA HÀNG HÓA, DỊCH VỤ", X.X_TITLE)],
         [(ngay_ky_hieu, X.X_THUONG)],
         [("- Tên doanh nghiệp: %s" % (cty.get("ten") or ""), X.X_THUONG)],
         [("-  Mã số thuế: %s" % (cty.get("mst") or ""), X.X_THUONG)],
         [("- Địa chỉ: %s" % dc, X.X_THUONG)],
         [("- Số điện thoại: %s" % dt, X.X_THUONG)],
         [("- Địa chỉ nơi tổ chức thu mua: %s" % (cty.get("noi_thu_mua") or dc), X.X_THUONG)]]
    Hd = X.X_TIEUDE
    T.append([("Ngày tháng", Hd), ("Người bán", Hd), ("", Hd), ("", Hd), ("", Hd), ("Hàng hóa, dịch vụ mua", Hd), ("", Hd), ("", Hd), ("", Hd), ("", Hd), ("Ghi chú", Hd)])
    T.append([("", Hd), ("Tên người bán", Hd), ("Địa chỉ", Hd), ("Số căn cước", Hd), ("Số điện thoại (nếu có)", Hd), ("Tên hàng hóa, dịch vụ", Hd), ("Đơn vị tính", Hd),
              ("Số lượng, trọng lượng", Hd), ("Đơn giá", Hd), ("Tổng giá thanh toán", Hd), ("", Hd)])
    T.append([(str(i), X.X_GHICHU) for i in (1, 2, 3, 4, 5, 6)] + [("", X.X_GHICHU)] + [(str(i), X.X_GHICHU) for i in (7, 8, 9, 10)])
    dong_bang = len(T)
    tong = 0.0
    for x in ds:
        gia = (x["tien"] / x["sl"]) if abs(x["sl"]) > 1e-9 else 0.0
        T.append([(x["ngay"].strftime("%d/%m/%Y"), X.X_CHU), (_bo_cccd(x["ten"]), X.X_CHU), (x["dia_chi"], X.X_CHU), (x["dinh_danh"], X.X_CHU), (x.get("tel", ""), X.X_CHU),
                  (x["ten_vt"], X.X_CHU), (x["dvt"], X.X_CHU), (x["sl"], X.X_SO), (round(gia), X.X_SO), (round(x["tien"]), X.X_SO), ("", X.X_CHU)])
        tong += x["tien"]
    if not ds:
        T.append([("", X.X_CHU), ("Trong kỳ không có dòng mua vào nào chưa có hoá đơn (nhập hàng không có số hoá đơn).", X.X_CHU)] + [("", X.X_CHU)] * (ncot - 2))
    T.append([("", X.X_MUC), ("Tổng cộng", X.X_MUC)] + [("", X.X_MUC)] * 7 + [(round(tong), X.X_SOMUC), ("", X.X_MUC)])
    T.append([])
    T.append([("Tổng giá trị hàng hoá, dịch vụ mua vào: %s đồng (bằng chữ: %s)" % (_dd(round(tong)), so_thanh_chu(tong)), X.X_THUONG)])
    T.append([("Tôi cam đoan bảng kê trên là đúng sự thật, nếu sai tôi xin chịu trách nhiệm trước pháp luật.", X.X_THUONG)])
    T.append([("Lưu ý: từ 5 triệu đồng/ngày/người bán trở lên phải thanh toán không dùng tiền mặt; kèm chứng từ chi tiền và (khi cần) bản chụp CCCD người bán.", X.X_GHICHU)])
    T.append([])
    d = (_ngay(ky.get("den")) or datetime.date.today())
    T.append([(None, 0)] * (ncot - 3) + [("Ngày %02d tháng %02d năm %d" % (d.day, d.month, d.year), X.X_THUONG), (None, 0), (None, 0)])
    T += _ky_3(X, ncot, "Người lập bảng kê", "Người đại diện theo pháp luật")
    T = _Dong(T)
    T.gop = ["A10:A11", "B10:E10", "F10:J10", "K10:K11", "G12:G12"][:4]
    return ("02-TNDN Bang ke thu mua", THU_MUA_RONG, T, dong_bang)


def sheet_thu_mua_kt(S, X):
    ds = thu_mua_dong(S)
    kt = thu_mua_kiem_tra(ds, thu_mua_tra_tien_mat(S))
    T = _dau(S, X, "KIỂM TRA ĐIỀU KIỆN LẬP BẢNG KÊ THU MUA (mẫu 02/TNDN)")
    T.append([("Mức", X.X_TIEUDE), ("Người bán / ngày", X.X_TIEUDE), ("Nội dung cần xử lý", X.X_TIEUDE)])
    dong_bang = len(T)
    ten_muc = {"DO": "Chưa đủ điều kiện", "VANG": "Cần xem lại"}
    for m, nb, nd in kt:
        k = X.X_DO if m == "DO" else X.X_VANG
        T.append([(ten_muc[m], k), (nb, k), (nd, k)])
    if not kt:
        T.append([("Đạt", X.X_XANH), ("", X.X_XANH), ("Các dòng mua vào đủ tên, địa chỉ, số định danh và không có khoản tiền mặt từ 5 triệu đồng/ngày/người bán.", X.X_XANH)])
    T.append([])
    T.append([("Điều kiện chung để khoản mua không hoá đơn được tính vào chi phí được trừ (Nghị định 320/2025/NĐ-CP, Điều 9): thuộc 1 trong 5 trường hợp được lập bảng kê; "
               "có bảng kê do người đại diện theo pháp luật (hoặc người được uỷ quyền) ký; có chứng từ chi tiền; thanh toán không dùng tiền mặt nếu từ 5 triệu đồng/ngày/người bán.", X.X_GHICHU)])
    return ("Kiem tra bang ke", [18, 40, 110], T, dong_bang)


def sheet_thu_mua_ban_ra(S, X):
    """Doi chieu hang mua khong hoa don voi hang xuat ban trong ky (cung ma vat tu)."""
    ds = thu_mua_dong(S)
    mua = defaultdict(lambda: [0.0, 0.0, "", ""])
    for x in ds:
        m = mua[x["ma_vt"]]
        m[0] += x["sl"]
        m[1] += x["tien"]
        m[2] = x["ten_vt"]
        m[3] = x["dvt"]
    ban = {str(r[0] or ""): (_so(r[2]), str(r[1] or "")) for r in (S.dl.get("ban_ra") or [])}
    T = _dau(S, X, "ĐỐI CHIẾU HÀNG MUA KHÔNG HOÁ ĐƠN VỚI HÀNG XUẤT BÁN TRONG KỲ")
    T.append([(c, X.X_TIEUDE) for c in ("Mã hàng", "Tên hàng", "ĐVT", "SL mua không hoá đơn", "Tiền mua", "SL xuất kho trong kỳ", "Nhận xét")])
    dong_bang = len(T)
    for ma in sorted(mua):
        m = mua[ma]
        sl_ban = ban.get(ma, (0.0, ""))[0]
        if sl_ban <= 0:
            nx, k = "Chưa xuất bán trong kỳ (còn trong kho).", X.X_CHU
        elif sl_ban > m[0] + 1e-6:
            nx, k = "Xuất nhiều hơn số mua không hoá đơn: phần còn lại lấy từ tồn kho / hàng có hoá đơn.", X.X_CHU
        else:
            nx, k = "Hàng bán ra có nguồn từ bảng kê thu mua: lưu bảng kê cùng hồ sơ hoá đơn bán ra.", X.X_XANH
        T.append([(ma, X.X_CHU), (m[2], X.X_CHU), (m[3], X.X_CHU), (m[0], X.X_SO), (round(m[1]), X.X_SO), (sl_ban, X.X_SO), (nx, k)])
    if not mua:
        T.append([("", X.X_CHU), ("Không có hàng mua không hoá đơn trong kỳ.", X.X_CHU)] + [("", X.X_CHU)] * 5)
    return ("Doi chieu ban ra", [14, 40, 8, 20, 18, 20, 80], T, dong_bang)



def lap_excel(dl, loai, ra):
    import tool_htkk_unesco as X
    S = SoLieuBS(dl)
    loai = (loai or "ALL").upper()
    sheets = []
    if S.cp99 and loai == "B03GT":                # GD227: ma so B03-DN TT99 lap o nut Bao cao tai chinh TT99 (BCN_B03TT99), khong dung ma so TT133
        raise ValueError("Sổ theo TT99/2025: Báo cáo lưu chuyển tiền tệ B03-DN lập ở nút Báo cáo tài chính (mã số TT99); "
                         "mẫu B03GT ở đây dùng mã số TT133 nên không lập cho sổ TT99.")
    if loai in ("B03GT", "ALL") and not S.cp99:
        sheets.append(sheet_b03(S, X))
    if loai in ("B09", "ALL"):
        sheets.append(sheet_b09(S, X))
    if loai in ("NVNN", "ALL"):                   # GD77: Tinh hinh thuc hien nghia vu doi voi Nha nuoc
        sheets.append(sheet_nvnn(S, X))
    if loai in ("CONGNO", "ALL"):
        sheets += sheet_cong_no(S, X)
        sheets.append(sheet_s14(S, X))
    if loai in ("S01", "ALL"):
        sheets.append(sheet_s01(S, X))
    if loai in ("MAU", "ALL"):
        sheets += sheet_mau(S, X)
    if loai == "TM":                      # GD211: bang ke thu mua mau 02/TNDN
        sheets += [sheet_thu_mua(S, X), sheet_thu_mua_kt(S, X), sheet_thu_mua_ban_ra(S, X)]
    if not sheets:
        raise ValueError("loai bao cao khong hop le: %s" % loai)
    os.makedirs(os.path.dirname(os.path.abspath(ra)), exist_ok=True)
    X.viet_xlsx_o(ra, sheets)
    return ra, {"sheets": [s[0] for s in sheets]}


def chay(loai, duong_json, ra):
    with open(duong_json, "r", encoding="utf-8-sig") as f:
        dl = json.loads(f.read(), strict=False)
    try:
        import tieu_de_tt
        tieu_de_tt.nhan(dl)                     # GD139: tieu de mau theo Thong tu cua bo so
    except Exception:
        pass
    d, _ = lap_excel(dl, loai, ra)
    return d, ""


if __name__ == "__main__":
    import sys
    if len(sys.argv) >= 3:
        print(chay(sys.argv[1], sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else re.sub(r"\.json$", ".xlsx", sys.argv[2])))
