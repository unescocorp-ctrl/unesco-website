# -*- coding: utf-8 -*-
"""GD258 - XAY DUNG / LAP DAT: danh muc cong trinh co du toan va % hoan thanh -> may canh chi phi, tinh gia von phai ket chuyen
   theo nghiem thu, doanh thu theo tien do. Nguoi khai mot lan (tham so, viec cua nguoi: % hoan thanh, nghiem thu); may tinh moi ky.
   Tep: <thu muc chinh sach cua so>\\cong_trinh.txt, moi dong:
     <TK 154 chi tiet cua cong trinh, vd 15401>;<ten cong trinh>;<du toan chi phi>;<gia tri hop dong>;<% hoan thanh den cuoi ky>;<TK doanh thu, vd 5112>
   Quy uoc: moi cong trinh mot TK 154 chi tiet (cach so dang dung o K53); doanh thu cong trinh ghi Co TK doanh thu voi MaKH / MaDT - khong doc duoc
   tu dl nen doanh thu da ghi KHONG tu kiem (chi nhac), gia von da ket chuyen = luy ke Co 154x (ca ky truoc trong nam).
   K59: - chi phi luy ke (No 154x luy ke tu dau nam + du dau nam) > du toan -> CANH_BAO (vuot du toan)
        - gia von phai ket chuyen den cuoi ky = du toan x % hoan thanh (toi da chi phi luy ke) - da ket chuyen (Co 154x) -> > 0: CANH_BAO + but toan
          No 632 / Co 154x ; < 0 (ket chuyen qua): LOI
        - doanh thu theo tien do = hop dong x % hoan thanh (chi nhac, khong kiem duoc doanh thu da ghi)
"""
import io
import os

MAU = ("# Danh muc cong trinh. Bo dau # va dien, moi dong mot cong trinh:\n"
       "#<TK 154 chi tiet>;<ten>;<du toan chi phi>;<gia tri hop dong>;<% hoan thanh den cuoi ky>;<TK doanh thu>\n"
       "#15401;Nha xuong A;5000000000;6000000000;60;5112\n")


def _f(x):
    try:
        return float(str(x).replace(",", ""))
    except Exception:
        return 0.0


def tep_tham_so(S):
    duong = S.dl.get("duong_so") or ""
    if not duong:
        return None
    try:
        import chinh_sach_so
        tm, _ = chinh_sach_so._thu_muc_ra(duong)
        return os.path.join(tm, "cong_trinh.txt")
    except Exception:
        return None


def doc(tep):
    out = []
    if not tep or not os.path.isfile(tep):
        return out
    with io.open(tep, encoding="utf-8-sig") as f:
        for d in f:
            d = d.strip()
            if not d or d.startswith("#"):
                continue
            x = [v.strip() for v in d.split(";")]
            if len(x) < 5:
                continue
            out.append({"tk": x[0], "ten": x[1], "du_toan": _f(x[2]), "hop_dong": _f(x[3]), "pt": _f(x[4]), "tk_dt": x[5] if len(x) > 5 else "5112"})
    return out


def _luy_ke(S, m):
    """(No luy ke, Co luy ke) TK la m tu dau nam TC den het S.t2 (ca ket chuyen)."""
    n = c = 0.0
    p = S.ps.get(m) if hasattr(S.ps, "get") else None
    if p:
        for t, x in p["thang"].items():
            if t <= S.t2:
                n += x[0] + x[2]
                c += x[1] + x[3]
    return n, c


def k_cong_trinh(S, _kq, DAT, CANH_BAO, LOI, THONG_TIN, tep=None):
    ten = "Công trình: chi phí so dự toán, giá vốn theo % hoàn thành (xây dựng, lắp đặt)"
    tep = tep or tep_tham_so(S)
    if not tep:
        return None
    ds = doc(tep)
    if not ds:
        co_154 = len(S.la_theo("154")) >= 2
        try:
            if co_154 and not os.path.isfile(tep):
                os.makedirs(os.path.dirname(tep), exist_ok=True)
                with io.open(tep, "w", encoding="utf-8") as f:
                    f.write(MAU)
        except Exception:
            pass
        if not co_154:
            return None
        return [_kq("K59", ten, THONG_TIN, "Sổ có %d TK 154 chi tiết nhưng chưa khai danh mục công trình (dự toán, %% hoàn thành). Điền %s để máy canh dự toán và tính giá vốn theo nghiệm thu."
                    % (len(S.la_theo("154")), tep))]
    dong = []
    muc = DAT
    for c in ds:
        ms = [m for m in S.la if (S.tk[m].get("sh") or "").strip() == c["tk"]]
        if not ms:
            dong.append([c["tk"], c["ten"], "", "", "", "", "", "Không có TK %s trong hệ thống tài khoản - sửa cong_trinh.txt" % c["tk"]])
            muc = CANH_BAO if muc == DAT else muc
            continue
        m = ms[0]
        tk = S.tk[m]
        du_dau_nam = float(tk.get("dn0") or 0) - float(tk.get("dc0") or 0)
        n, co = _luy_ke(S, m)
        chi_phi = du_dau_nam + n
        pt = min(max(c["pt"], 0.0), 100.0) / 100.0
        gv_can = min(c["du_toan"] * pt, chi_phi) if c["du_toan"] > 0 else chi_phi * pt
        gv_them = gv_can - co
        dt_td = c["hop_dong"] * pt
        xl = []
        if c["du_toan"] > 0 and chi_phi > c["du_toan"] * 1.001:
            xl.append("Vượt dự toán %s" % _d(chi_phi - c["du_toan"]))
            muc = CANH_BAO if muc == DAT else muc
        if gv_them > 1000:
            xl.append("Kết chuyển giá vốn: Nợ 632 / Có %s %s" % (c["tk"], _d(gv_them)))
            muc = CANH_BAO if muc == DAT else muc
        elif gv_them < -1000:
            xl.append("Đã kết chuyển quá %s so %% hoàn thành - xem lại %% hoặc phiếu kết chuyển" % _d(-gv_them))
            muc = LOI
        if dt_td > 0:
            xl.append("Doanh thu theo tiến độ đến cuối kỳ %s (Có %s, đối chiếu biên bản nghiệm thu)" % (_d(dt_td), c["tk_dt"]))
        dong.append([c["tk"], c["ten"], round(c["du_toan"]), round(chi_phi), "%g%%" % c["pt"], round(co), round(gv_them), "; ".join(xl) or "Đúng tiến độ"])
    kl = "%d công trình đã khai (%s). Máy chỉ tính và nhắc; %% hoàn thành, nghiệm thu là quyết định của người." % (len(ds), tep)
    return [_kq("K59", ten, muc, kl, ["TK 154", "Công trình", "Dự toán", "Chi phí luỹ kế", "% HT", "Giá vốn đã kết chuyển", "Giá vốn cần thêm", "Xử lý"], dong)]


def _d(x):
    return "{:,.0f}".format(x).replace(",", ".")
