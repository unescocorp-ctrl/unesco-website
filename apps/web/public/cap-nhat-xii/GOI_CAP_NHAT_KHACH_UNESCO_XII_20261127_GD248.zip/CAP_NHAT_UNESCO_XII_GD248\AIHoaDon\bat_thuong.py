# -*- coding: utf-8 -*-
"""GD157 (lo trinh B3; GD158 tinh chinh theo so that) - PHAT HIEN BAT THUONG SO LIEU (KS8 - KS12) cho the "Bat thuong so lieu" cua man hinh Kiem soat. CHI DOC.

Dau vao: JSON do VB6 lap (ModBatThuong.BT157_Json) = so lieu cong no GD70 (tk, ps, doi ung, dt, cn_ct) + phan "ss" cua GD78
(ct: dong chung tu day du trong nam tai chinh, vt, tonkho, tsan, nv, bl) + "hd" (hoa don gan chung tu) + "khoa" (thang da khoa)
+ "bt157" (nguong theo bo so, ten CSDL, hom nay).

  KS8  chi phi tang dot bien: theo TK chi phi (6xx, 8xx tru 632) va theo NCC (mua chiu 331): thang > (1 + X%) x binh quan
       toi da 6 thang truoc (can >= 3 thang lich su trong nam) va phan tang >= so tien toi thieu.
  KS9  gia: gia mua mot vat tu lech > Y% so lan mua truoc; chung tu ban co doanh thu (Co 511) thap hon gia von (No 632).
  KS10 so chung tu trung / nhay so (theo loai, theo day so; tu nhan biet danh so lai hang thang); hoa don cung so, ky hieu,
       doi tuong o nhieu chung tu.
  KS11 chung tu cua thang DA KHOA nhung nhap sau phan lon chung tu thang ke tiep (MaCT tang theo thu tu nhap) - nghi ghi lui ngay.
  KS12 luong co ban thap hon luong toi thieu vung (bo tham so nam, vung chon theo bo so); khau hao thang khac thang truoc ma
       khong co tang / giam TSCD, hoac thang bo trong.

Ra: tep TAB (UTF-8) ket-qua\\bat_thuong.txt:
  TONG <n> <lap luc> <KS8> <KS9> <KS10> <KS11> <KS12> | DB <ten CSDL> | NGUONG <X> <Y> <tien min> <vung>
  B <loai> <muc> <ma> <mo ta> <so lieu> <goi y> <khoa danh dau> <MaCT,MaCT...>
"""
import datetime as _dt
import io
import json
import os
import re
from collections import defaultdict

import kiem_khoa_so as K
import so_sach_mau as SM

try:
    import tham_so_nam as TS
except Exception:          # pragma: no cover
    TS = None

GOC = os.path.dirname(os.path.abspath(__file__))
TOI_DA_LOAI = 60                # toi da dong moi loai (giu dong quan trong nhat; luoi VB6 nhe)
MUC_CAO, MUC_VUA, MUC_THAP = "Cao", "Vừa", "Thấp"
THU_TU_MUC = {MUC_CAO: 0, MUC_VUA: 1, MUC_THAP: 2}
LOAI = (  # loai -> (ma KS, ten ngan)
    ("BT_CP_TK", "KS8", "Chi phí TK tăng đột biến"),
    ("BT_CP_NCC", "KS8", "Mua của NCC tăng đột biến"),
    ("BT_GIA_MUA", "KS9", "Giá mua lệch lần trước"),
    ("BT_GIA_BAN", "KS9", "Bán dưới giá vốn"),
    ("BT_SO_TRUNG", "KS10", "Số chứng từ trùng"),
    ("BT_SO_NHAY", "KS10", "Số chứng từ nhảy"),
    ("BT_HD_TRUNG", "KS10", "Hoá đơn trùng số"),
    ("BT_LUI_NGAY", "KS11", "Ghi lùi vào tháng đã khoá"),
    ("BT_LUONG", "KS12", "Lương dưới tối thiểu vùng"),
    ("BT_KHAU_HAO", "KS12", "Khấu hao bất thường"),
)
MA_KS = {a: b for a, b, _ in LOAI}
TK_KHO3 = ("151", "152", "153", "154", "155", "156", "157", "158")
TK_SX3 = ("621", "622", "627", "632", "911", "641", "642")
TK_TS3 = ("211", "212", "213", "217")
LA_MA = {1: "I", 2: "II", 3: "III", 4: "IV"}


def _so(x):
    try:
        return float(x or 0)
    except (TypeError, ValueError):
        try:
            return float(str(x).replace(",", "."))
        except (TypeError, ValueError):
            return 0.0


def tien(x):
    """1234567.4 -> '1.234.567'"""
    return "{:,.0f}".format(round(x or 0)).replace(",", ".")


def don_gia(x):
    if abs(x) >= 1000 or x == int(x):
        return tien(x)
    return ("%.2f" % x).replace(".", ",")


def pt(x):
    return ("%+.0f%%" % (x * 100)).replace("+", "+")


def _sach(s, n=400):
    s = re.sub(r"[\t\r\n]+", " ", str(s or "")).strip()
    return s[:n]


def _ngay(s):
    return SM._ngay(s)


def trung_vi(ds):
    a = sorted(ds)
    if not a:
        return 0
    m = len(a) // 2
    return a[m] if len(a) % 2 else (a[m - 1] + a[m]) / 2.0


class Nguong(object):
    def __init__(self, b):
        b = b or {}
        self.x = _so(b.get("x")) or 50.0              # % tang chi phi
        self.y = _so(b.get("y")) or 30.0              # % lech gia mua
        self.tien_min = _so(b.get("tien_min")) or 5000000.0
        self.vung = int(_so(b.get("vung")))
        if self.vung not in (1, 2, 3, 4):
            self.vung = 0


class BatThuong(object):
    def __init__(self, dl, hom_nay=None):
        self.dl = dl
        self.b = dl.get("bt157") or {}
        self.ng = Nguong(self.b)
        self.S = S = SM.SoLieuSS(dl)
        self.hom_nay = hom_nay or _ngay(self.b.get("hom_nay")) or _dt.date.today()
        self.t_nay = K.thang_tc(self.hom_nay.month, S.dau_ky) if self.hom_nay.year in (S.nam, S.nam + 1) else S.t2
        self.ct = S.ct
        self.dong = []
        self.ten_loai_ct = {}
        # chung tu: MaCT -> dong
        self.theo_ct = defaultdict(list)
        for d in self.ct:
            self.theo_ct[d.mact].append(d)

    # ------------------------------------------------------------------ tien ich
    def sh(self, m):
        return self.S.sh(m)

    def thang_chu(self, t):
        m, y = self.S.thang_lich(t)
        return "%02d/%d" % (m, y)

    def ten_dt(self, kh):
        d = self.S.dt.get(kh)
        return ((d[0] + " - ") if d and d[0] else "") + (self.S.ten_dt(kh) or ("đối tượng mã số %d" % kh))

    def ma_dt(self, kh):
        d = self.S.dt.get(kh)
        return d[0] if d and d[0] else str(kh)

    def them(self, loai, muc, ma, mo_ta, so_lieu, goi_y, khoa, mact=(), diem=0.0):
        ds = []
        for x in mact:
            x = int(_so(x))
            if x > 0 and x not in ds:
                ds.append(x)
        self.dong.append({"loai": loai, "muc": muc, "ma": _sach(ma, 60), "mo_ta": _sach(mo_ta), "so_lieu": _sach(so_lieu), "goi_y": _sach(goi_y),
                          "khoa": _sach(khoa, 200), "mact": ds[:40], "diem": float(diem)})

    def ct_lon(self, ds_dong, n=20):
        """MaCT cua cac dong tien lon nhat"""
        tong = defaultdict(float)
        for d in ds_dong:
            tong[d.mact] += abs(d.tien)
        return [m for m, _ in sorted(tong.items(), key=lambda x: -x[1])[:n]]

    def _tang(self, gia_tri, t):
        """-> (binh quan, so thang) cua toi da 6 thang truoc t trong nam (can >= 3 thang)."""
        tr = [u for u in range(max(1, t - 6), t)]
        if len(tr) < 3:
            return None, 0
        if sum(1 for u in tr if gia_tri.get(u, 0.0) > 0) < 2:
            return None, 0                       # GD158: can >= 2 thang co phat sinh (mua theo dot / mot lan khong so)
        return sum(gia_tri.get(u, 0.0) for u in tr) / float(len(tr)), len(tr)

    # ------------------------------------------------------------------ KS8
    def ks8(self):
        X, MIN = self.ng.x / 100.0, self.ng.tien_min
        cp = defaultdict(lambda: defaultdict(float))
        cp_dong = defaultdict(list)
        mua = defaultdict(lambda: defaultdict(float))
        mua_dong = defaultdict(list)
        for d in self.ct:
            a, b = self.sh(d.no), self.sh(d.co)
            if d.no and a[:1] in ("6", "8") and not a.startswith(("632", "911")) and not (b[:1] in ("6", "8") or b.startswith("911")):
                cp[d.no][d.t] += d.tien
                cp_dong[(d.no, d.t)].append(d)
            elif d.co and b[:1] in ("6", "8") and not b.startswith(("632", "911")) and not (a[:1] in ("6", "8") or a.startswith("911")):
                cp[d.co][d.t] -= d.tien                   # giam chi phi
            if d.co and b.startswith("331") and d.khc > 0 and not a.startswith(("111", "112", "113", "131", "331", "911")):
                mua[d.khc][d.t] += d.tien
                mua_dong[(d.khc, d.t)].append(d)
        tmax = min(self.S.t2, self.t_nay)
        for tk, g in cp.items():
            for t in range(4, tmax + 1):
                bq, n = self._tang(g, t)
                cur = g.get(t, 0.0)
                if bq is None or bq <= 0 or cur <= bq * (1 + X) or cur - bq < MIN:
                    continue
                tang = cur / bq - 1
                self.them("BT_CP_TK", MUC_CAO if tang >= 3 * X and cur - bq >= 5 * MIN else MUC_VUA, self.sh(tk),
                          "Chi phí TK %s (%s) tháng %s tăng %s so với bình quân %d tháng trước" % (
                              self.sh(tk), self.S.ten_tk(tk)[:50], self.thang_chu(t), pt(tang), n),
                          "Tháng %s: %s | Bình quân: %s | Tăng thêm: %s" % (self.thang_chu(t), tien(cur), tien(bq), tien(cur - bq)),
                          "Xem các chứng từ lớn trong tháng: hạch toán nhầm TK, ghi trùng, chi phí trả trước chưa phân bổ qua 242, chi phí năm "
                          "dồn một tháng. Nếu đúng thực tế, đánh dấu Không phải lỗi.",
                          "BT_CP_TK|%s|%s" % (self.sh(tk), self.thang_chu(t)), self.ct_lon(cp_dong[(tk, t)]), cur - bq)
        XN = max(2 * X, 1.0)                         # GD158: mua cua NCC theo dot - nguong it nhat gap doi, phan tang >= 2 lan muc toi thieu
        for kh, g in mua.items():
            for t in range(4, tmax + 1):
                bq, n = self._tang(g, t)
                cur = g.get(t, 0.0)
                if bq is None or bq <= 0 or cur <= bq * (1 + XN) or cur - bq < 2 * MIN:
                    continue
                tang = cur / bq - 1
                self.them("BT_CP_NCC", MUC_VUA, self.ma_dt(kh),
                          "Mua chịu của %s tháng %s tăng %s so với bình quân %d tháng trước" % (self.ten_dt(kh)[:80], self.thang_chu(t), pt(tang), n),
                          "Tháng %s: %s | Bình quân: %s | Tăng thêm: %s" % (self.thang_chu(t), tien(cur), tien(bq), tien(cur - bq)),
                          "Kiểm tra hoá đơn ghi trùng, nhập nhầm nhà cung cấp, hoặc đơn hàng lớn bất thường (đối chiếu hợp đồng, phiếu nhập).",
                          "BT_CP_NCC|%s|%s" % (self.ma_dt(kh), self.thang_chu(t)), self.ct_lon(mua_dong[(kh, t)]), cur - bq)

    # ------------------------------------------------------------------ KS9
    def ks9(self):
        Y = self.ng.y / 100.0
        KH = SM.Kho(self.S)
        mua = defaultdict(list)
        for d in self.ct:
            if d.loai == 4 or d.sl_no <= 0 or d.tien <= 0 or not KH.la_nhap(d):
                continue
            if self.sh(d.co)[:3] in TK_KHO3 + TK_SX3:
                continue
            mua[d.vt].append(d)
        MIN = self.ng.tien_min * 0.2
        for vt, ds in mua.items():
            ds.sort(key=lambda d: (d.ngay or _dt.date(1900, 1, 1), d.mact, d.ms))
            for i in range(1, len(ds)):
                b = ds[i]
                truoc = ds[max(0, i - 3):i]                 # trung vi toi da 3 lan mua truoc (lan tro lai gia cu khong bi bao)
                a = truoc[-1]
                ua, ub = trung_vi([x.tien / x.sl_no for x in truoc]), b.tien / b.sl_no
                if ua <= 0 or b.tien < MIN:
                    continue
                lech = ub / ua - 1
                if abs(lech) <= Y:
                    continue
                v = KH.ten_vt(vt)
                ncc_b = self._ncc(b)
                self.them("BT_GIA_MUA", MUC_VUA if abs(lech) < 1 else MUC_CAO, v[0],
                          "Giá mua %s %s/%s lệch %s so với giá %d lần mua trước %s (gần nhất ngày %s)" % (
                              v[1][:60], don_gia(ub), v[2] or "đvt", pt(lech), len(truoc), don_gia(ua), a.ngay.strftime("%d/%m/%Y") if a.ngay else ""),
                          "Lần này: %s ngày %s, SL %s, tiền %s%s | Lần trước: %s, SL %s, tiền %s" % (
                              b.sh, b.ngay.strftime("%d/%m/%Y") if b.ngay else "", don_gia(b.sl_no), tien(b.tien), (", " + ncc_b) if ncc_b else "",
                              a.sh, don_gia(a.sl_no), tien(a.tien)),
                          "Kiểm tra đơn giá, số lượng, đơn vị tính trên phiếu nhập (nhầm ĐVT, thiếu số lượng, chưa tính chiết khấu); "
                          "nếu đúng giá mới, đánh dấu Không phải lỗi.",
                          "BT_GIA_MUA|%s|%d" % (v[0], b.mact), [a.mact, b.mact], abs(lech) * b.tien)
        # ban duoi gia von: theo chung tu
        for mact, ds in self.theo_ct.items():
            dt_ = gv = 0.0
            dt_vt, gv_vt = defaultdict(float), defaultdict(float)
            kh = 0
            for d in ds:
                a, b = self.sh(d.no), self.sh(d.co)
                if b.startswith("511") and not a.startswith(("911", "511", "521")):
                    dt_ += d.tien
                    if d.vt:
                        dt_vt[d.vt] += d.tien
                    if d.kh and not kh:
                        kh = d.kh
                elif a.startswith("632") and b[:3] in TK_KHO3:
                    gv += d.tien
                    if d.vt:
                        gv_vt[d.vt] += d.tien
                if a.startswith("131") and d.kh and not kh:
                    kh = d.kh
            if dt_ <= 0 or gv <= 0 or dt_ >= gv - max(1000.0, gv * 0.001):
                continue
            d0 = ds[0]
            vt_lo = [vt for vt in gv_vt if dt_vt.get(vt, 0) > 0 and dt_vt[vt] < gv_vt[vt] - 1]
            ct_vt = ""
            if vt_lo:
                ct_vt = " | Mặt hàng: " + "; ".join("%s bán %s < vốn %s" % (KH.ten_vt(v)[0], tien(dt_vt[v]), tien(gv_vt[v])) for v in vt_lo[:5])
            self.them("BT_GIA_BAN", MUC_VUA, d0.sh,
                      "Chứng từ %s ngày %s%s: doanh thu %s thấp hơn giá vốn %s" % (
                          d0.sh, d0.ngay.strftime("%d/%m/%Y") if d0.ngay else "", (" - " + self.ten_dt(kh)[:60]) if kh else "", tien(dt_), tien(gv)),
                      "Lỗ %s (%s giá vốn)%s" % (tien(gv - dt_), pt(dt_ / gv - 1), ct_vt),
                      "Kiểm tra giá bán, chiết khấu, giá xuất kho (Tính lại giá xuất); hàng khuyến mại, biếu tặng cần hạch toán riêng.",
                      "BT_GIA_BAN|%d" % mact, [mact], gv - dt_)

    def _ncc(self, d):
        for x in self.theo_ct.get(d.mact, ()):
            if x.khc and self.sh(x.co).startswith("331"):
                return self.ten_dt(x.khc)[:60]
        return ""

    # ------------------------------------------------------------------ KS10
    @staticmethod
    def day_so(sh):
        """'PT001/09' -> ('PT#/09', 1): day so dai nhat (bang nhau lay day cuoi)."""
        runs = list(re.finditer(r"\d+", sh))
        if not runs:
            return None, None
        best = None
        for m in runs:
            if best is None or len(m.group(0)) >= len(best.group(0)):
                best = m
        return sh[:best.start()] + "#" + sh[best.end():], int(best.group(0))

    def ks10(self):
        ct = {}
        for mact, ds in self.theo_ct.items():
            d0 = ds[0]
            ct[mact] = (d0.loai, d0.sh.strip(), d0.ngay, d0.thang, sum(abs(d.tien) for d in ds if d.no and d.co) or sum(abs(d.tien) for d in ds))
        # trung so trong cung thang (so cai danh so lai hang thang van dung)
        nhom = defaultdict(list)
        for mact, (loai, sh, ngay, thang, tong) in ct.items():
            if sh:
                nhom[(loai, sh.upper(), thang)].append(mact)
        for (loai, sh, thang), ds in nhom.items():
            if len(ds) < 2:
                continue
            ds.sort()
            tong = [ct[m][4] for m in ds]
            cung_tien = len(set(round(x) for x in tong)) < len(tong)
            self.them("BT_SO_TRUNG", MUC_CAO if cung_tien else MUC_VUA, ct[ds[0]][1],
                      "Số chứng từ %s (loại %d) dùng cho %d chứng từ khác nhau trong tháng %02d" % (ct[ds[0]][1], loai, len(ds), thang),
                      "; ".join("%s: %s" % (ct[m][2].strftime("%d/%m/%Y") if ct[m][2] else "", tien(ct[m][4])) for m in ds[:6])
                      + (" (có chứng từ cùng số tiền - nghi nhập trùng)" if cung_tien else ""),
                      "Đối chiếu từng chứng từ: nếu nhập trùng thì xoá bản thừa; nếu khác nhau thì đánh lại số.",
                      "BT_SO_TRUNG|%d|%s|%d" % (loai, sh, thang), ds, max(tong) if cung_tien else 0)
        # nhay so: theo day so (loai + mau); danh so lai hang thang -> xet tung thang
        day = defaultdict(lambda: defaultdict(set))
        mau_sh = {}
        tien_mat = defaultdict(lambda: [0, 0])      # GD158: [so chung tu co TK 111, tong] - chi xet day phieu thu / chi tien mat
        for mact, (loai, sh, ngay, thang, tong) in ct.items():
            k, so = self.day_so(sh)
            if k is None:
                continue
            day[(loai, k.upper())][thang].add(so)
            mau_sh[(loai, k.upper())] = sh
            x = tien_mat[(loai, k.upper())]
            x[1] += 1
            if any(self.sh(d.no).startswith("111") or self.sh(d.co).startswith("111") for d in self.theo_ct[mact]):
                x[0] += 1
        for (loai, k), theo_thang in day.items():
            tm = tien_mat[(loai, k)]
            if k.startswith("KC") or tm[0] < 0.8 * tm[1]:
                continue                             # GD158: day ket chuyen / so tu sinh (gia von, so phu, hoa don) - khong xet nhay so
            tat_ca = [s for st in theo_thang.values() for s in st]
            lap_lai = len(tat_ca) != len(set(tat_ca))
            nhom_xet = list(theo_thang.items()) if lap_lai else [(0, set(tat_ca))]
            for thang, so in nhom_xet:
                so = sorted(so)
                if len(so) < 5:
                    continue
                thieu = []
                for a, b in zip(so, so[1:]):
                    if 1 < b - a <= 11:
                        thieu.append((a + 1, b - 1))
                n = sum(b - a + 1 for a, b in thieu)
                if not thieu or n > 30:
                    continue
                chu = ", ".join(str(a) if a == b else "%d-%d" % (a, b) for a, b in thieu[:12])
                self.them("BT_SO_NHAY", MUC_THAP, mau_sh[(loai, k)],
                          "Dãy số %s (loại %d)%s thiếu %d số" % (k, loai, (" tháng %02d" % thang) if thang else "", n),
                          "Từ %d đến %d, thiếu: %s" % (so[0], so[-1], chu),
                          "Có thể chứng từ đã bị xoá hoặc nhảy số khi nhập: kiểm tra, ghi chú lý do (chứng từ huỷ) hoặc đánh lại số.",
                          "BT_SO_NHAY|%d|%s|%d" % (loai, k, thang), [], n)
        # hoa don cung so, ky hieu, doi tuong o nhieu chung tu
        hd = defaultdict(set)
        tt = {}
        for r in self.dl.get("hd") or []:
            r = list(r) + [0] * (9 - len(r))
            mact, kh, kyh, so_hd = int(_so(r[0])), int(_so(r[2])), str(r[3] or "").strip().upper(), str(r[4] or "").strip()
            ds = re.sub(r"\D", "", so_hd)
            if not mact or not ds or int(ds) == 0:
                continue
            a, b = self.sh(int(_so(r[7]))), self.sh(int(_so(r[8])))
            chieu = "mua vào" if a.startswith("133") else ("bán ra" if b.startswith("333") else "")
            khoa = (kh, re.sub(r"\s+", "", kyh), int(ds), "" if kyh else str(r[5] or ""))
            hd[khoa].add(mact)
            x = tt.setdefault(khoa, [chieu, 0.0, so_hd, kyh])
            x[1] += _so(r[6])
            if chieu and not x[0]:
                x[0] = chieu
        for khoa, ds in hd.items():
            if len(ds) < 2:
                continue
            kh, kyh, so, _ = khoa
            chieu, tong, so_hd, kyh0 = tt[khoa]
            ds = sorted(ds)
            self.them("BT_HD_TRUNG", MUC_CAO, ("%s %s" % (kyh0, so_hd)).strip(),
                      "Hoá đơn %s số %s%s của %s ghi ở %d chứng từ" % (chieu or "", so_hd, (" ký hiệu " + kyh0) if kyh0 else "", self.ten_dt(kh)[:70], len(ds)),
                      "Chứng từ: " + ", ".join("%s (%s)" % (self.theo_ct[m][0].sh if self.theo_ct.get(m) else str(m),
                                                          self.theo_ct[m][0].ngay.strftime("%d/%m/%Y") if self.theo_ct.get(m) and self.theo_ct[m][0].ngay else "")
                                               for m in ds[:6]) + " | Tổng tiền dòng hoá đơn: " + tien(tong),
                      "Nghi ghi trùng hoá đơn (khấu trừ hoặc doanh thu hai lần): mở từng chứng từ đối chiếu, xoá bản trùng. "
                      "Hoá đơn điều chỉnh / thay thế cùng số thì đánh dấu Không phải lỗi.",
                      "BT_HD_TRUNG|%d|%s|%d" % (kh, kyh, so), ds, tong)

    # ------------------------------------------------------------------ KS11
    def ks11(self):
        khoa = set(int(_so(x)) for x in (self.dl.get("khoa") or []) if 1 <= int(_so(x)) <= 12)
        if not khoa:
            return
        theo_thang = defaultdict(list)
        for mact, ds in self.theo_ct.items():
            theo_thang[ds[0].thang].append(mact)
        for m in sorted(khoa):
            n = m % 12 + 1
            if K.thang_tc(n, self.S.dau_ky) < K.thang_tc(m, self.S.dau_ky):
                continue                         # thang cuoi nam tai chinh: khong co thang ke tiep trong so
            sau, nay = theo_thang.get(n) or [], theo_thang.get(m) or []
            if len(sau) < 5 or not nay:
                continue
            tv = trung_vi(sau)
            lui = sorted(x for x in nay if x > tv)
            if not lui or len(lui) > max(3, len(nay) // 2):
                continue                         # qua nhieu: MaCT khong theo thu tu nhap - khong ket luan
            for mact in lui[:50]:
                ds = self.theo_ct[mact]
                d0 = ds[0]
                tong = sum(abs(d.tien) for d in ds if d.no and d.co) or sum(abs(d.tien) for d in ds)
                self.them("BT_LUI_NGAY", MUC_CAO, d0.sh,
                          "Chứng từ %s ngày %s thuộc tháng %02d đã khoá nhưng nhập sau phần lớn chứng từ tháng %02d" % (
                              d0.sh, d0.ngay.strftime("%d/%m/%Y") if d0.ngay else "", m, n),
                          "Tổng tiền %s | Thứ tự nhập (MaCT) %d > trung vị tháng %02d (%d)" % (tien(tong), mact, n, tv),
                          "Ghi lùi ngày vào tháng đã khoá làm đổi số đã báo cáo / tờ khai: kiểm tra lý do; nếu đúng phải khai bổ sung. "
                          "Chứng từ nhập muộn có chủ đích thì đánh dấu Không phải lỗi.",
                          "BT_LUI_NGAY|%d" % mact, [mact], tong)

    # ------------------------------------------------------------------ KS12
    def ks12(self):
        S = self.S
        ss = S.ss
        vung = self.ng.vung or 4
        nv = {int(_so(r[0])): (str(r[1] or ""), str(r[2] or "")) for r in ss.get("nv") or []}
        theo_nv = defaultdict(list)
        for r in ss.get("bl") or []:
            r = list(r) + [0] * (22 - len(r))
            manv, thang, lcb = int(_so(r[0])), int(_so(r[1])), _so(r[4])
            if lcb <= 0 or not 1 <= thang <= 12:
                continue
            y = S.nam if thang >= S.dau_ky else S.nam + 1
            ltt = None
            if TS is not None:
                ltt = TS.lay("LTT_VUNG_%d" % vung, _dt.date(y, thang, 1))
            if not ltt or lcb >= ltt - 0.5:
                continue
            theo_nv[manv].append((y, thang, lcb, ltt, _so(r[8])))
        for manv, ds in theo_nv.items():
            ds.sort()
            sh_, ten = nv.get(manv, (str(manv), ""))
            th = ", ".join("%02d/%d" % (t, y) for y, t, _, _, _ in ds[:12])
            lmin = min(x[2] for x in ds)
            ltt = ds[-1][3]
            self.them("BT_LUONG", MUC_VUA, sh_,
                      "Lương cơ bản %s thấp hơn lương tối thiểu vùng %s (%d tháng)" % ((ten or sh_)[:60], LA_MA[vung], len(ds)),
                      "Thấp nhất %s < %s | Tháng: %s%s" % (tien(lmin), tien(ltt), th, " | có đóng BHXH" if any(x[4] > 0 for x in ds) else ""),
                      "Lương theo hợp đồng / lương đóng BHXH không được thấp hơn mức tối thiểu vùng (bộ tham số năm). "
                      + ("Chưa chọn vùng cho bộ sổ - đang so với vùng IV, chọn ở nút Ngưỡng... " if not self.ng.vung else "")
                      + "Làm không trọn thời gian thì đánh dấu Không phải lỗi.",
                      "BT_LUONG|%d|%d" % (manv, ds[0][0]), [], (ltt - lmin) * len(ds))
        # khau hao: Co 214 (tru giam TSCD), so voi thang truoc
        kh = defaultdict(float)
        kh_dong = defaultdict(list)
        bien = set()
        for d in self.ct:
            a, b = self.sh(d.no), self.sh(d.co)
            if b.startswith("214") and a[:3] not in TK_TS3 + ("214",):
                kh[d.t] += d.tien
                kh_dong[d.t].append(d.mact)
            if a[:3] in TK_TS3 or b[:3] in TK_TS3:
                bien.add(d.t)
        ds_t = [t for t, v in kh.items() if v > 0]
        if not ds_t:
            return
        t_cuoi = max(ds_t)
        for t in range(2, t_cuoi + 1):
            truoc, nay = kh.get(t - 1, 0.0), kh.get(t, 0.0)
            ganh = [kh[u] for u in range(t - 1, 0, -1) if kh.get(u, 0) > 0][:2]     # 2 thang co trich gan nhat
            if not ganh:
                continue
            if truoc <= 0:
                truoc = ganh[0]
                if nay <= 0:
                    continue                     # da bao thang bo trong
            if nay <= 0:
                self.them("BT_KHAU_HAO", MUC_VUA, "214", "Tháng %s không trích khấu hao (tháng trước %s)" % (self.thang_chu(t), tien(truoc)),
                          "Tháng %s: 0 | Tháng %s: %s%s" % (self.thang_chu(t), self.thang_chu(t - 1), tien(truoc), " | có tăng / giảm TSCĐ" if t in bien else ""),
                          "Kiểm tra bút toán trích khấu hao tháng (Tài sản > Trích khấu hao). Nếu đã thanh lý hết TSCĐ thì đánh dấu Không phải lỗi.",
                          "BT_KHAU_HAO|%s" % self.thang_chu(t), [], truoc)
            elif all(abs(nay - g) > max(g * 0.01, 100000.0) for g in ganh) and t not in bien and (t - 1) not in bien:
                self.them("BT_KHAU_HAO", MUC_THAP, "214",
                          "Khấu hao tháng %s khác tháng trước %s mà không có tăng / giảm TSCĐ" % (self.thang_chu(t), pt(nay / truoc - 1)),
                          "Tháng %s: %s | Tháng %s: %s" % (self.thang_chu(t), tien(nay), self.thang_chu(t - 1), tien(truoc)),
                          "Kiểm tra bút toán khấu hao sửa tay, thời gian khấu hao / nguyên giá bị đổi, tài sản hết khấu hao.",
                          "BT_KHAU_HAO|%s" % self.thang_chu(t), kh_dong[t][:20], abs(nay - truoc))

    # ------------------------------------------------------------------
    def chay(self):
        for f in (self.ks8, self.ks9, self.ks10, self.ks11, self.ks12):
            f()
        thu = {a: i for i, (a, _, _) in enumerate(LOAI)}
        kq = []
        for loai, _, _ in LOAI:
            ds = [x for x in self.dong if x["loai"] == loai]
            ds.sort(key=lambda x: (THU_TU_MUC[x["muc"]], -x["diem"]))
            kq += ds[:TOI_DA_LOAI]
        kq.sort(key=lambda x: (THU_TU_MUC[x["muc"]], thu[x["loai"]], -x["diem"]))
        self.dong = kq
        return kq

    def dem_ks(self):
        n = defaultdict(int)
        for x in self.dong:
            n[MA_KS[x["loai"]]] += 1
        return [n["KS8"], n["KS9"], n["KS10"], n["KS11"], n["KS12"]]


def ghi(B, ra):
    os.makedirs(os.path.dirname(ra), exist_ok=True)
    ng = B.ng
    dong = ["TONG\t%d\t%s\t%s" % (len(B.dong), _dt.datetime.now().strftime("%Y-%m-%d %H:%M"), "\t".join(str(x) for x in B.dem_ks())),
            "DB\t%s" % _sach(B.b.get("db"), 400),
            "NGUONG\t%g\t%g\t%d\t%d" % (ng.x, ng.y, int(ng.tien_min), ng.vung)]
    for x in B.dong:
        dong.append("\t".join(["B", x["loai"], x["muc"], x["ma"], x["mo_ta"], x["so_lieu"], x["goi_y"], x["khoa"], ",".join(str(m) for m in x["mact"])]))
    with io.open(ra, "w", encoding="utf-8", newline="") as f:
        f.write("\r\n".join(dong) + "\r\n")
    return ra


def chay(duong_json, ra=""):
    with io.open(duong_json, "r", encoding="utf-8-sig") as f:
        dl = json.loads(f.read(), strict=False)
    if not ra:
        ra = os.path.join(GOC, "ket-qua", "bat_thuong.txt")
    B = BatThuong(dl)
    B.chay()
    return ghi(B, ra), ""


if __name__ == "__main__":
    import sys
    if len(sys.argv) >= 2:
        print(chay(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else ""))
