# -*- coding: utf-8 -*-
"""GD139 - TIEU DE MAU (Mau so ... / Ban hanh theo ...) THEO DUNG THONG TU CUA BO SO: TT133/2016 hay TT99/2025.

Anh Thang (06/10/2026): "Khi chuyen su dung Thong tu 99 nhung tieu de bieu mau van de thong tu 133, QD 48 - fix dieu chinh
lai tat ca mau bieu dung theo quy dinh tung Thong tu".

Quy dinh (da tra cuu 10/2026):
  * TT133/2016/TT-BTC ngay 26/8/2016 (DN nho va vua): "Mau so S03a-DNN" - "(Ban hanh theo Thong tu so 133/2016/TT-BTC
    ngay 26/8/2016 cua Bo Tai chinh)". Danh muc so: S01-DNN ... S27-DNN (S04a quy, S05 tien gui, S06 chi tiet VL, S07 tong
    hop VL, S08 the kho, S09 TSCD, S10 TSCD-CCDC noi su dung, S11 the TSCD, S12 thanh toan, S13 ngoai te, S14, S15 tien vay,
    S16 ban hang, S17 chi phi SXKD, S18 the gia thanh, S19 chi tiet cac TK, S24 XDCB, S25 thue GTGT, S26, S27).
  * TT99/2025/TT-BTC ngay 27/10/2025 (Che do ke toan doanh nghiep, hieu luc 01/01/2026): "Mau so S03a-DN" - "(Kem theo
    Thong tu so 99/2025/TT-BTC ngay 27 thang 10 nam 2025 cua Bo truong Bo Tai chinh)". Danh muc so (Phu luc III): S01-DN ...
    S07 quy, S07a, S08 tien gui, S10 chi tiet VL, S11 tong hop, S12 the kho, S21 TSCD, S22, S23 the TSCD, S31 thanh toan,
    S32 ngoai te, S33, S34 tien vay, S35 ban hang, S36 chi phi SXKD, S37 the gia thanh, S38 chi tiet cac TK, S52 XDCB,
    S61 thue GTGT, S62, S63. Chung tu: 01-TT, 02-TT, 01-VT, 02-VT... giu ky hieu.
Dung chung: Python (xlsx_viet / viet_xlsx_o - ghi Excel), cong cu sua tep Crystal .RPT (tool/gd139). VB6 co ban sao cung
quy tac (ModTieuDeMau.bas). CHI doi chu tieu de (o dau trang), khong doi so lieu."""
import re
import unicodedata

CHE_DO = 0          # 0 = chua biet (khong doi); 133 / 99 - dat bang nhan(dl) khi doc JSON cua VB

# ------------------------------------------------------------------ chu "Ban hanh theo" / "Kem theo" (Excel: ban day du)
BH = {
    133: {"full": ["(Ban hành theo Thông tư số 133/2016/TT-BTC ngày 26/8/2016 của Bộ Tài chính)"],
          2: [["(Ban hành theo Thông tư số 133/2016/TT-BTC"], ["ngày 26/8/2016 của Bộ Tài chính)"]],
          3: [["(Ban hành theo Thông tư số"], ["133/2016/TT-BTC ngày"], ["26/8/2016 của Bộ Tài chính)"]]},
    99: {"full": ["(Kèm theo Thông tư số 99/2025/TT-BTC ngày 27/10/2025 của Bộ trưởng Bộ Tài chính)"],
         2: [["(Kèm theo Thông tư số 99/2025/TT-BTC"], ["ngày 27/10/2025 của Bộ trưởng Bộ Tài chính)"]],
         3: [["(Kèm theo Thông tư số"], ["99/2025/TT-BTC ngày"], ["27/10/2025 của Bộ trưởng Bộ Tài chính)"]]},
}
SO_TT = ("48/2006", "133/2016", "15/2006", "200/2014", "99/2025", "167/2000")

# ------------------------------------------------------------------ ten so / chung tu -> ky hieu (TT133, TT99)
# khoa: chu HOA khong dau; so khop "bat dau bang" (dai truoc) - ten chi tiet dat truoc ten chung
TIEU_DE = [
    ("SO KE TOAN CHI TIET QUY TIEN MAT", "S04b-DNN", "S07a-DN"),
    ("SO NHAT KY THU TIEN", "S03a1-DNN", "S03a1-DN"),
    ("SO NHAT KY CHI TIEN", "S03a2-DNN", "S03a2-DN"),
    ("SO NHAT KY MUA HANG", "S03a3-DNN", "S03a3-DN"),
    ("SO NHAT KY BAN HANG", "S03a4-DNN", "S03a4-DN"),
    ("SO NHAT KY CHUNG", "S03a-DNN", "S03a-DN"),
    ("NHAT KY - SO CAI", "S01-DNN", "S01-DN"),
    ("NHAT KY SO CAI", "S01-DNN", "S01-DN"),
    ("SO DANG KY CHUNG TU GHI SO", "S02b-DNN", "S02b-DN"),
    ("CHUNG TU GHI SO", "S02a-DNN", "S02a-DN"),
    ("SO CHI TIET CAC TAI KHOAN", "S19-DNN", "S38-DN"),
    ("SO CHI TIET TAI KHOAN", "S19-DNN", "S38-DN"),
    ("SO CAI", "S03b-DNN", "S03b-DN"),
    ("SO QUY TIEN MAT", "S04a-DNN", "S07-DN"),
    ("SO TIEN GUI NGAN HANG", "S05-DNN", "S08-DN"),
    ("SO TIEN GUI", "S05-DNN", "S08-DN"),
    ("SO CHI TIET VAT LIEU", "S06-DNN", "S10-DN"),
    ("SO CHI TIET VAT TU", "S06-DNN", "S10-DN"),
    ("SO CHI TIET HANG HOA", "S06-DNN", "S10-DN"),
    ("SO CHI TIET SAN PHAM", "S06-DNN", "S10-DN"),
    ("BANG TONG HOP CHI TIET VAT LIEU", "S07-DNN", "S11-DN"),
    ("BANG KE TONG HOP CHI TIET VAT LIEU", "S07-DNN", "S11-DN"),
    ("BANG TONG HOP NHAP XUAT TON", "S07-DNN", "S11-DN"),
    ("BANG TONG HOP NHAP - XUAT - TON", "S07-DNN", "S11-DN"),
    ("THE KHO", "S08-DNN", "S12-DN"),
    ("SO THEO DOI TSCD VA CONG CU", "S10-DNN", "S22-DN"),
    ("SO THEO DOI TAI SAN CO DINH VA CONG CU", "S10-DNN", "S22-DN"),
    ("SO THEO DOI CONG CU", "S10-DNN", "S22-DN"),
    ("SO CONG CU DUNG CU", "S10-DNN", "S22-DN"),
    ("SO TAI SAN CO DINH", "S09-DNN", "S21-DN"),
    ("SO THEO DOI TAI SAN CO DINH", "S09-DNN", "S21-DN"),
    ("THE TAI SAN CO DINH", "S11-DNN", "S23-DN"),
    ("SO THEO DOI THANH TOAN BANG NGOAI TE", "S14-DNN", "S33-DN"),
    ("SO CHI TIET THANH TOAN VOI NGUOI MUA (NGUOI BAN) BANG NGOAI TE", "S13-DNN", "S32-DN"),
    ("SO CHI TIET THANH TOAN VOI NGUOI MUA", "S12-DNN", "S31-DN"),
    ("SO CHI TIET THANH TOAN VOI NGUOI BAN", "S12-DNN", "S31-DN"),
    ("SO CHI TIET THANH TOAN", "S12-DNN", "S31-DN"),
    ("SO CHI TIET TIEN VAY", "S15-DNN", "S34-DN"),
    ("SO CHI TIET BAN HANG", "S16-DNN", "S35-DN"),
    ("SO CHI PHI SAN XUAT", "S17-DNN", "S36-DN"),
    ("THE TINH GIA THANH", "S18-DNN", "S37-DN"),
    ("SO CHI PHI DAU TU XAY DUNG", "S24-DNN", "S52-DN"),
    ("SO THEO DOI THUE GIA TRI GIA TANG", "S25-DNN", "S61-DN"),
    ("SO THEO DOI THUE GTGT", "S25-DNN", "S61-DN"),
    ("SO CHI TIET THUE GTGT DUOC HOAN LAI", "S26-DNN", "S62-DN"),
    ("SO CHI TIET THUE GIA TRI GIA TANG DUOC HOAN LAI", "S26-DNN", "S62-DN"),
    ("SO CHI TIET THUE GTGT DUOC MIEN GIAM", "S27-DNN", "S63-DN"),
    ("SO CHI TIET THUE GIA TRI GIA TANG DUOC MIEN GIAM", "S27-DNN", "S63-DN"),
    ("PHIEU THU", "01-TT", "01-TT"),
    ("PHIEU CHI", "02-TT", "02-TT"),
    ("GIAY DE NGHI TAM UNG", "03-TT", "03-TT"),
    ("GIAY THANH TOAN TIEN TAM UNG", "04-TT", "04-TT"),
    ("GIAY DE NGHI THANH TOAN", "05-TT", "05-TT"),
    ("PHIEU NHAP KHO", "01-VT", "01-VT"),
    ("PHIEU XUAT KHO", "02-VT", "02-VT"),
    ("PHIEU NHAP", "01-VT", "01-VT"),
    ("PHIEU XUAT", "02-VT", "02-VT"),
]
# so TT133 (DNN) <-> TT99 (DN) cho o ky hieu khong tim duoc ten so
S133_99 = {"S01": "S01", "S02a": "S02a", "S02b": "S02b", "S02c1": "S02c1", "S02c2": "S02c2", "S03a": "S03a", "S03a1": "S03a1",
           "S03a2": "S03a2", "S03a3": "S03a3", "S03a4": "S03a4", "S03b": "S03b", "S04a": "S07", "S04b": "S07a", "S05": "S08",
           "S06": "S10", "S07": "S11", "S08": "S12", "S09": "S21", "S10": "S22", "S11": "S23", "S12": "S31", "S13": "S32",
           "S14": "S33", "S15": "S34", "S16": "S35", "S17": "S36", "S18": "S37", "S19": "S38", "S24": "S52", "S25": "S61",
           "S26": "S62", "S27": "S63"}
S99_133 = {v: k for k, v in S133_99.items()}
# ten so CHUNG (mot man hinh in nhieu loai so): giu ho ky hieu dang co neu hop ly (vd So cai mau chung tu ghi so S02c1)
TEN_CHUNG = {"SO CAI": ("S03b", "S02c1", "S02c2", "S01", "S19"),
             "SO CHI TIET TAI KHOAN": ("S19", "S03b", "S02c1", "S02c2"),
             "SO CHI TIET CAC TAI KHOAN": ("S19", "S03b", "S02c1", "S02c2"),
             "SO TAI SAN CO DINH": ("S09", "S10"),
             "SO THEO DOI TAI SAN CO DINH": ("S09", "S10")}
_BO_DAU = str.maketrans("àáạảãâầấậẩẫăằắặẳẵèéẹẻẽêềếệểễìíịỉĩòóọỏõôồốộổỗơờớợởỡùúụủũưừứựửữỳýỵỷỹđ"
                        "ÀÁẠẢÃÂẦẤẬẨẪĂẰẮẶẲẴÈÉẸẺẼÊỀẾỆỂỄÌÍỊỈĨÒÓỌỎÕÔỒỐỘỔỖƠỜỚỢỞỠÙÚỤỦŨƯỪỨỰỬỮỲÝỴỶỸĐ",
                        "aaaaaaaaaaaaaaaaaeeeeeeeeeeeiiiiiooooooooooooooooouuuuuuuuuuuyyyyyd"
                        "AAAAAAAAAAAAAAAAAEEEEEEEEEEEIIIIIOOOOOOOOOOOOOOOOOUUUUUUUUUUUYYYYYD")


def bo_dau(s):
    """bo dau tieng Viet tung ky tu (do dai khong doi - nhu VB HDDT_BoDau)."""
    return str(s or "").translate(_BO_DAU)


def khoa(s):
    """chu HOA khong dau, mot dau cach (VB TDM_Khoa)."""
    k = bo_dau(str(s or "").replace("\r", " ").replace("\n", " ").replace("\t", " ").replace("\xa0", " ")).upper()
    return " ".join(x for x in k.split(" ") if x)


def nhan(dl):
    """Doc Thong tu cua bo so tu JSON VB (thong_tu / cty.thong_tu / bctc.che_do) -> CHE_DO (133 / 99)."""
    global CHE_DO
    try:
        v = dl.get("thong_tu")
        if v in (None, ""):
            v = (dl.get("cty") or {}).get("thong_tu") if isinstance(dl.get("cty"), dict) else None
        if v in (None, ""):
            v = (dl.get("bctc") or {}).get("che_do") if isinstance(dl.get("bctc"), dict) else None
        v = str(v or "").upper().replace("TT", "").strip()
        CHE_DO = 99 if v.startswith("99") else (133 if v.startswith("133") else 0)
    except Exception:
        CHE_DO = 0
    return CHE_DO


def _dau(k, d):
    return k[:len(d)] == d


def ma_theo_tieu_de(chu):
    """ten so tren trang -> (khoa ten, ky hieu TT133, TT99) | None (VB TDM_MaTheoTen)."""
    k = khoa(chu)
    while k[:1] in ("(", '"', "'"):
        k = k[1:]
    for t, a, b in TIEU_DE:
        if _dau(k, t):
            if t == "SO CHI TIET THANH TOAN" and "NGOAI TE" in k:
                return t, "S13-DNN", "S32-DN"
            return t, a, b
    return None


def tach_ma(dong):
    """o 'Mau so: S03a - DNN' (dong dau) -> dict (vi_tri, ma, loai, hau, du) | None. Ban sao tung ky tu cua VB TDM_TachMa."""
    k = bo_dau(str(dong).replace("\xa0", " ")).upper()
    L = len(k)
    p = 0

    def bo_cach(p):
        while p < L and k[p] == " ":
            p += 1
        return p
    p = bo_cach(p)
    if k[p:p + 3] == "MAU":
        p += 3
    else:
        return None                      # chi "Mau so" (khong nhan "Ma so thue", "Ma so KH")
    p = bo_cach(p)
    if k[p:p + 2] != "SO":
        return None
    p = bo_cach(p + 2)
    if k[p:p + 1] == "(":
        q = k.find(")", p)
        if q < 0:
            return None
        p = q + 1
    while p < L and k[p] in (" ", ":"):
        p += 1
    vi_tri = p
    chu_cai = ""
    while p < L and "A" <= k[p] <= "Z" and len(chu_cai) < 2:
        chu_cai += k[p]
        p += 1
    while p < L and k[p] in (" ", "-"):
        p += 1
    so = ""
    while p < L and k[p].isdigit() and len(so) < 2:
        so += k[p]
        p += 1
    if not so:
        return None
    phu = ""
    if p < L and "a" <= dong[p] <= "z":
        phu = dong[p]
        p += 1
        if p < L and k[p].isdigit():
            phu += k[p]
            p += 1
    p = bo_cach(p)
    if p >= L or dong[p] not in ("-", "/", "–"):
        return None
    p = bo_cach(p + 1)
    hau = ""
    for h in ("DNNKLT", "DNN", "DN", "TT", "VT", "BH", "LDTL", "TSCD"):
        if k[p:p + len(h)] == h:
            hau = h
            break
    if not hau:
        return None
    sau = (k + " ")[p + len(hau)]
    if "A" <= sau <= "Z" or sau.isdigit():
        return None
    if any(x in k for x in ("HKD", "GTGT", "TNDN", "TNCN", "TBH")):
        return None
    if chu_cai == "S" and len(so) == 1:
        so = "0" + so
    return {"vi_tri": vi_tri, "ma": chu_cai + so + phu, "loai": chu_cai or "#", "hau": hau, "du": dong[p + len(hau):]}


def ma_moi(info, td, che_do):
    """ky hieu dung theo Thong tu; "" = giu nguyen; "X" = mau khong cung Thong tu (bo qua ca trang). (VB TDM_MaMoi)"""
    loai, ma, hau = info["loai"], info["ma"], info["hau"]
    if loai in ("B", "F"):
        if che_do == 99 and hau == "DN":
            x = ma[1:]
            if len(x) < 2:
                x = ("00" + x)[-2:]
            return "%s %s - DN" % (ma[0], x)
        if che_do == 133 and hau in ("DNN", "DNNKLT"):
            return ""
        return "X"
    if td:
        ten, a, b = td
        if ten in TEN_CHUNG and loai == "S":
            ma133 = ma if hau == "DNN" else S99_133.get(ma, "")
            if ma133 in TEN_CHUNG[ten]:
                td = None                 # ten chung + ky hieu dang co hop ly -> giu ho ky hieu
        if td:
            return a if che_do == 133 else b
    if loai == "S":
        if che_do == 99 and hau == "DNN" and ma in S133_99:
            return S133_99[ma] + "-DN"
        if che_do == 133 and hau == "DN" and ma in S99_133:
            return S99_133[ma] + "-DNN"
        if che_do == 99 and hau == "DN" or che_do == 133 and hau == "DNN":
            return ma + "-" + hau
    return ""


def la_bh(dong):
    """dong dau chu Ban hanh: '(Ban hanh theo ...', '(Kem theo Thong tu ...', 'Ban hanh kem theo ...' (VB TDM_LaBH)."""
    k = khoa(dong)
    mo = k[:1] == "("
    while k[:1] in ("(", " "):
        k = k[1:]
    k += " "
    if _dau(k, "BAN HANH ") or _dau(k, "BANH HANH ") or _dau(k, "BAN HANG THEO ") or _dau(k, "KEM THEO THONG TU ") or \
            _dau(k, "KEM THEO TT") or _dau(k, "KEM THEO QD ") or _dau(k, "KEM THEO QUYET DINH "):
        return True
    return mo and (_dau(k, "THEO QD ") or _dau(k, "THEO QUYET DINH ") or _dau(k, "THEO THONG TU ") or _dau(k, "THEO TT "))


def _so_ngay(k):
    """'#/####/', '##/####/', '###/####/' hoac ngay '#(#)/#(#)/####' o dau chuoi (VB Like)."""
    m = re.match(r"^(\d{1,3})/(\d{4})/", k) or re.match(r"^\d{1,2}/\d{1,2}/\d{4}", k)
    return bool(m)


def la_tiep(dong):
    """o noi tiep chu Ban hanh (ngay / so Thong tu / cua Bo ...) - phai co dau hieu tieu de (Bo, BTC, Tai chinh, so TT). (VB TDM_LaTiep)"""
    k = khoa(dong)
    while k[:1] in ("(", " "):
        k = k[1:]
    if not ("BO " in k + " " or "BTC" in k or "TAI CHINH" in k or any(x in dong for x in SO_TT)):
        return False
    if _dau(k + " ", "NGAY ") or _dau(k, "CUA BO") or _dau(k, "BO TAI") or _dau(k, "THONG TU SO"):
        return True
    if _dau(k, "SO "):
        k = k[3:]
    return _so_ngay(k)


def chu_bh(che_do, so_phan, i):
    """phan thu i (1..) cua chu Ban hanh so_phan dong (VB TDM_ChuBH)."""
    n = min(so_phan, 3)
    if i > n:
        return ""
    if n == 1:
        return BH[che_do]["full"][0]
    return BH[che_do][n][i - 1][0]


def dung_tt(gop, che_do):
    """chu Ban hanh da dung Thong tu cua bo so (VB TDM_DungTT)."""
    so = "133/2016" if che_do == 133 else "99/2025"
    if any(x != so and x in gop for x in SO_TT):
        return False
    if so not in gop:
        return False
    if che_do == 99:
        if "2006" in gop:
            return False
        if "2025" not in gop.replace("99/2025", ""):
            return False
    return True


def doi_bang(o, che_do=None):
    """o: {(dong, cot): chu} vung dau trang (dong 1..14, cot 1..40). Tra {(dong, cot): chu moi}. Ban sao VB TDM_Trang."""
    che_do = che_do or CHE_DO
    if che_do not in (133, 99):
        return {}
    o = {k: v for k, v in o.items() if isinstance(v, str) and v.strip() and 1 <= k[0] <= 14 and 1 <= k[1] <= 40}
    moi = dict(o)
    td = None
    for k in sorted(o):
        d0 = o[k].split("\n")[0]
        if td is None and not tach_ma(d0) and not la_bh(d0):
            td = ma_theo_tieu_de(o[k])
    co_ma = False
    dong_ma = 0
    for k in sorted(o):
        dong = o[k].split("\n")
        info = tach_ma(dong[0])
        if not info:
            continue
        mm = ma_moi(info, td, che_do)
        if mm == "X":
            return {}
        if info["loai"] not in ("B", "F"):
            co_ma = True
        if not dong_ma:
            dong_ma = k[0]
        if mm:
            s = dong[0][:info["vi_tri"]].rstrip()
            while s[-1:] in (":", " "):
                s = s[:-1]
            dong[0] = s + " " + mm + info["du"]
            moi[k] = "\n".join(dong)
    for k in sorted(o):
        r, c = k
        if dong_ma and not (dong_ma - 1 <= r <= dong_ma + 3):
            continue                     # chu Ban hanh chi o canh o ky hieu
        if not dong_ma and r > 6:
            continue
        dong = moi[k].split("\n")
        vt = next((i for i, d in enumerate(dong) if la_bh(d)), -1)
        if vt < 0:
            continue
        tiep = []
        for rr in (r + 1, r + 2):
            v2 = o.get((rr, c))
            if v2 and la_tiep(v2) and not la_bh(v2):
                tiep.append((rr, c))
            else:
                break
        gop = " ".join(dong[vt:] + [o[x] for x in tiep])
        kg = khoa(gop)
        if not any(x in gop for x in SO_TT) or "HKD" in kg or "BLDTBXH" in kg or "88/2021" in gop or "152/2025" in gop:
            continue
        if che_do == 133 and "99/2025" in gop or dung_tt(gop, che_do):
            continue
        if not (che_do == 133 or co_ma or td or "99/2025" in gop):
            continue
        n = len(dong) - vt + len(tiep)
        dem = 0
        for i in range(vt, len(dong)):
            dem += 1
            dong[i] = chu_bh(che_do, n, dem)
        moi[k] = "\n".join(dong)
        for x in tiep:
            dem += 1
            moi[x] = chu_bh(che_do, n, dem)
    return {k: v for k, v in moi.items() if o.get(k) != v}

# ------------------------------------------------------------------ dung cho cac bo ghi Excel (xlsx_viet / viet_xlsx_o)
def sua_o(o_dict, che_do=None):
    """o_dict: {(dong, cot): (gia tri, kieu)} cua mot trang (xlsx_viet._Sheet._o) - sua tai cho, tra so o da doi."""
    che_do = che_do or CHE_DO
    if che_do not in (133, 99):
        return 0
    try:
        vung = {k: v[0] for k, v in o_dict.items() if k[0] <= 14 and k[1] <= 40 and isinstance(v[0], str) and not v[0].startswith("=")}
        d = doi_bang(vung, che_do)
        for k, moi in d.items():
            gt, kieu = o_dict[k]
            o_dict[k] = (type(gt)(moi) if type(gt) is not str else moi, kieu)
        return len(d)
    except Exception:
        return 0


def sua_dong(cac_dong, che_do=None):
    """cac_dong: [[(gia tri, kieu) | None, ...], ...] (viet_xlsx_o) - tra ban da sua (khong doi ban goc)."""
    che_do = che_do or CHE_DO
    if che_do not in (133, 99):
        return cac_dong
    try:
        vung = {}
        for r, dong in enumerate(cac_dong[:14], start=1):
            for c, x in enumerate(dong or [], start=1):
                if x and isinstance(x[0], str) and not x[0].startswith("=") and c <= 40:
                    vung[(r, c)] = x[0]
        d = doi_bang(vung, che_do)
        if not d:
            return cac_dong
        ra = [list(dong) if dong else dong for dong in cac_dong]
        for (r, c), moi in d.items():
            gt, kieu = ra[r - 1][c - 1]
            ra[r - 1][c - 1] = (type(gt)(moi) if type(gt) is not str else moi, kieu)
        return ra
    except Exception:
        return cac_dong
