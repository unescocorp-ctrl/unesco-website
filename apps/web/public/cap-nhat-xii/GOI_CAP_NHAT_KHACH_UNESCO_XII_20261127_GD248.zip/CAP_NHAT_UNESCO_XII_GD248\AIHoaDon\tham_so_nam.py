# -*- coding: utf-8 -*-
"""GD156 - BO THAM SO NAM (lo trinh D3): doc AIHoaDon\\tham_so_nam.txt (goi cap nhat ghi de) + tham_so_nam_rieng.txt (gia tri rieng cua may,
khong bao gio ghi de) -> gia tri theo NGAY HIEU LUC. Dong: khoa TAB dd/mm/yyyy TAB gia tri TAB don vi TAB ten TAB can cu; '#' = ghi chu.
  lay(khoa, ngay=None, mac_dinh=None)  -> gia tri hieu luc tai ngay (dong co ngay hieu luc gan nhat khong sau ngay)
  bang(ngay=None)                       -> [(khoa, ten, gia tri, don vi, hieu luc tu, can cu, nguon, thay doi sap toi)]
VB6 doc cung tep (ModThamSoNam). Khong ghi so."""
import datetime as _dt
import io
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
TEP = os.path.join(HERE, "tham_so_nam.txt")
TEP_RIENG = os.path.join(HERE, "tham_so_nam_rieng.txt")
_CACHE = {}


def _ngay(s):
    if isinstance(s, _dt.datetime):
        return s.date()
    if isinstance(s, _dt.date):
        return s
    m = re.match(r"^\s*(\d{1,2})/(\d{1,2})/(\d{4})", str(s or ""))
    if m:
        try:
            return _dt.date(int(m.group(3)), int(m.group(2)), int(m.group(1)))
        except ValueError:
            return None
    m = re.match(r"^\s*(\d{4})-(\d{2})-(\d{2})", str(s or ""))
    if m:
        try:
            return _dt.date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except ValueError:
            return None
    return None


def _so(s):
    try:
        return float(str(s).strip().replace(",", "."))
    except (TypeError, ValueError):
        return None


def _doc_tep(tep, nguon):
    kq = []
    try:
        with io.open(tep, "r", encoding="utf-8-sig") as f:
            dong = f.read().splitlines()
    except (IOError, OSError):
        return kq
    for d in dong:
        if not d.strip() or d.lstrip().startswith("#"):
            continue
        a = d.split("\t")
        if len(a) < 3:
            continue
        k, n, v = a[0].strip().upper(), _ngay(a[1]), _so(a[2])
        if not k or n is None or v is None:
            continue
        kq.append({"khoa": k, "tu": n, "gia_tri": v, "don_vi": (a[3] if len(a) > 3 else "").strip(), "ten": (a[4] if len(a) > 4 else "").strip(),
                   "can_cu": (a[5] if len(a) > 5 else "").strip(), "nguon": nguon})
    return kq


def doc(tep=None, tep_rieng=None):
    """-> {khoa: [dong sap theo ngay hieu luc]}; dong rieng thang dong chung cung khoa + ngay."""
    tep = tep or TEP
    tep_rieng = tep_rieng or TEP_RIENG
    try:
        moc = (tep, os.path.getmtime(tep) if os.path.exists(tep) else 0, tep_rieng, os.path.getmtime(tep_rieng) if os.path.exists(tep_rieng) else 0)
    except OSError:
        moc = None
    if moc and _CACHE.get("moc") == moc:
        return _CACHE["ds"]
    gop = {}
    for r in _doc_tep(tep, "chung") + _doc_tep(tep_rieng, "rieng"):
        gop[(r["khoa"], r["tu"])] = r
    ds = {}
    for (k, _), r in sorted(gop.items(), key=lambda kv: (kv[0][0], kv[0][1])):
        ds.setdefault(k, []).append(r)
    # ten / don vi: dong rieng thieu thi lay tu dong chung
    for k, rr in ds.items():
        ten = next((r["ten"] for r in rr if r["ten"]), "")
        dv = next((r["don_vi"] for r in rr if r["don_vi"]), "")
        for r in rr:
            r["ten"] = r["ten"] or ten
            r["don_vi"] = r["don_vi"] or dv
    if moc:
        _CACHE["moc"], _CACHE["ds"] = moc, ds
    return ds


def dong_hieu_luc(khoa, ngay=None, ds=None):
    ds = ds if ds is not None else doc()
    ngay = _ngay(ngay) or _dt.date.today()
    chon = None
    for r in ds.get(str(khoa).upper(), []):
        if r["tu"] <= ngay:
            chon = r
    return chon


def lay(khoa, ngay=None, mac_dinh=None, ds=None):
    r = dong_hieu_luc(khoa, ngay, ds)
    return r["gia_tri"] if r else mac_dinh


def bang(ngay=None, ds=None, sap_toi_ngay=366):
    """moi khoa mot dong: gia tri hien hanh + thay doi trong 'sap_toi_ngay' ngay toi (neu co)."""
    ds = ds if ds is not None else doc()
    ngay = _ngay(ngay) or _dt.date.today()
    kq = []
    for k in sorted(ds):
        r = dong_hieu_luc(k, ngay, ds)
        toi = [x for x in ds[k] if ngay < x["tu"] <= ngay + _dt.timedelta(days=sap_toi_ngay)]
        if r is None and not toi:
            continue
        kq.append((k, (r or toi[0])["ten"], r["gia_tri"] if r else None, (r or toi[0])["don_vi"], r["tu"] if r else None, r["can_cu"] if r else "",
                   r["nguon"] if r else "", [(x["tu"], x["gia_tri"], x["can_cu"]) for x in toi]))
    return kq


def chu_gia_tri(v, don_vi=""):
    if v is None:
        return ""
    if "tỷ lệ" in don_vi or (0 < abs(v) < 1 and v != int(v)):
        return ("%g" % (v * 100)).replace(".", ",") + "%"
    if v == int(v):
        return "{:,.0f}".format(v).replace(",", ".")
    return ("%g" % v).replace(".", ",")


def tran_bhxh(ngay=None, ds=None):
    """tran tien luong dong BHXH, BHYT = he so x luong co so (muc tham chieu) tai ngay."""
    he_so = lay("BHXH_TRAN_HE_SO", ngay, 20, ds)
    lcs = lay("LUONG_CO_SO", ngay, None, ds)
    return he_so * lcs if lcs else None


if __name__ == "__main__":
    for x in bang():
        print("%-28s %-16s %s" % (x[0], chu_gia_tri(x[2], x[3]), x[1]))
