# xii_chup_so.ps1 - chup mot so UNESCO XII (CSDL SQL Server) thanh tep JSON "xii-so-sql-1", CHI DOC, khong can mo chuong trinh XII.
# Tra ve cho tram ERP cua XII (xii_erp_tram.py) cung khuon voi Modules\AiSqlBookSnapshot.vb (SbsWrite): cung bang, cung cot, cung thu tu dong, cung cach viet so / ngay / chu.
# ASCII-only on purpose (PowerShell 5.1 reads BOM-less files as ANSI).
#   powershell -NoProfile -ExecutionPolicy Bypass -File xii_chup_so.ps1 -Server ".\SQLEXPRESS" -Database UNESCO_ABC_2026 -Out "D:\TRAM\ABC.so_sql.json"
# Ket thuc: 0 = da ghi; 2 = khong doc duoc so (dong cuoi cua man hinh la ly do); tep ghi qua <Out>.tmp roi doi ten.
# Ket noi: tai khoan Windows dang chay, ApplicationIntent=ReadOnly; chi SELECT; khong ghi chuoi ket noi ra man hinh.
param(
    [Parameter(Mandatory = $true)][string]$Database,
    [Parameter(Mandatory = $true)][string]$Out,
    [string]$Server = '.\SQLEXPRESS'
)
$ErrorActionPreference = 'Stop'
if ($Database -notmatch '^[A-Za-z0-9_]{1,100}$') { Write-Output 'LOI: ten CSDL chi gom chu khong dau, so va gach duoi'; exit 2 }
Add-Type -ReferencedAssemblies 'System.Data' -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Text;

public static class XiiChup {
    // the 20 tables of AiSqlBookSnapshot.SbsTables (same order), then what the ERP station reads on top (doi_chieu_100, bang_dieu_hanh, hang_loat.dl_tu_mdb, erp_thuc_hien)
    static readonly string[] Tables = { "License", "HeThongTK", "ChungTu", "KhachHang", "CNDauNam", "DoituongCT", "Vattu", "TonKho", "ThanhPham", "ThanhPhamDD", "DinhMuc",
        "BangLuong", "PhanLoai154", "ThamSoGiaThanh", "TP154", "TaiSan", "HoaDon", "HDDT_QuanHe", "HDDT_ThamSo", "HDDTTaiVe",
        "HDDT_DVC_Dong", "HDDT_NhatKy", "HDDT_SP_Dong", "HDDT_SP_TaiKhoanNH", "HDDT_KS_BoQua", "QuanLyNhanVien", "ERP_THUCHIEN" };
    static readonly HashSet<string> SkipTypes = new HashSet<string>(new string[] { "xml", "image", "varbinary", "binary", "timestamp", "rowversion", "geography", "geometry", "hierarchyid", "sql_variant" });

    static object Scalar(SqlConnection cn, string sql, params SqlParameter[] ps) {
        using (var c = new SqlCommand(sql, cn)) { c.CommandTimeout = 300; foreach (var p in ps) c.Parameters.Add(p); return c.ExecuteScalar(); }
    }
    static bool TableAvailable(SqlConnection cn, string name) {
        object v = Scalar(cn, "SELECT COUNT(*) FROM sys.tables WHERE [name]=@n AND [schema_id]=SCHEMA_ID(N'dbo')", new SqlParameter("@n", SqlDbType.NVarChar, 128) { Value = name });
        return Convert.ToInt32(v, CultureInfo.InvariantCulture) == 1;
    }
    static bool ColumnAvailable(SqlConnection cn, string table, string column) {
        object v = Scalar(cn, "SELECT COUNT(*) FROM sys.columns WHERE [object_id]=OBJECT_ID(@t) AND [name]=@c",
            new SqlParameter("@t", SqlDbType.NVarChar, 260) { Value = "dbo." + table }, new SqlParameter("@c", SqlDbType.NVarChar, 128) { Value = column });
        return Convert.ToInt32(v, CultureInfo.InvariantCulture) == 1;
    }
    static List<string> Columns(SqlConnection cn, string name) {
        var r = new List<string>();
        using (var c = new SqlCommand("SELECT [COLUMN_NAME],[DATA_TYPE] FROM INFORMATION_SCHEMA.COLUMNS WHERE [TABLE_SCHEMA]=N'dbo' AND [TABLE_NAME]=@t ORDER BY [ORDINAL_POSITION]", cn)) {
            c.Parameters.Add(new SqlParameter("@t", SqlDbType.NVarChar, 128) { Value = name });
            using (var rd = c.ExecuteReader()) while (rd.Read()) { if (!SkipTypes.Contains(Convert.ToString(rd[1]).ToLowerInvariant())) r.Add(Convert.ToString(rd[0])); }
        }
        return r;
    }
    static string Quote(string id) {
        for (int i = 0; i < id.Length; i++) { char ch = id[i]; if (!(ch == '_' || (ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z') || (i > 0 && ch >= '0' && ch <= '9'))) throw new ArgumentException("ten bang/cot khong hop le: " + id); }
        if (id.Length == 0) throw new ArgumentException("ten bang/cot rong");
        return "[" + id + "]";
    }
    // SELECT of one table in XI column names (null = leave the table out), like SbsRead / SbsReadInvoices
    static string SelectFor(SqlConnection cn, string name) {
        if (name == "HDDTTaiVe") {
            foreach (string c in new string[] { "KhoaHD", "SoHoaDon", "KyHieuHoaDon", "MSTNguoiBan", "MSTNguoiMua", "NgayLap", "MaCTKeToan", "TongTien", "TinhTrangHoaDon" })
                if (!ColumnAvailable(cn, "HDDTTaiVe", c)) return null;
            string sale = ColumnAvailable(cn, "HDDTTaiVe", "HDBanRa") ? "CASE WHEN H.[HDBanRa]=1 OR H.[MaSoLoaiCT]=8 THEN 1 ELSE 0 END" : "CASE WHEN H.[MaSoLoaiCT]=8 THEN 1 ELSE 0 END";
            string onlyInvoice = ColumnAvailable(cn, "HDDTTaiVe", "AIRecordType") ? " AND (H.[AIRecordType] IS NULL OR H.[AIRecordType]=N'INVOICE')" : "";
            string skip = ColumnAvailable(cn, "HDDTTaiVe", "AIValidationStatus") ? " AND ISNULL(H.[AIValidationStatus],N'')<>N'BO_QUA'" : "";
            // the first 11 columns are exactly those of AiSqlBookSnapshot.SbsReadInvoices (khoa_so_thang); the extra ones (appended) are the XI names doi_chieu_100 reads:
            // amounts without tax and tax (DC1, DC6, DC7, DC8), party names, AI status and batch (DC1, DC3, DC13).
            var extra = new StringBuilder();
            foreach (string[] m in new string[][] { new string[] { "ThanhTien", "ThanhTienChuaThue" }, new string[] { "TienThue", "TienThue" }, new string[] { "TenNguoiBan", "TenNguoiBanNguoiXuatHang" },
                                                    new string[] { "TenNguoiMua", "TenNguoiMuaNguoiNhanHang" }, new string[] { "AIValidationStatus", "AIValidationStatus" }, new string[] { "AIBatchID", "AIBatchID" } })
                if (ColumnAvailable(cn, "HDDTTaiVe", m[0])) extra.Append(", H.[").Append(m[0]).Append("] AS [").Append(m[1]).Append("]");
            return "SELECT H.[MaSo], H.[KhoaHD] AS [MaCT], H.[SoHoaDon], H.[KyHieuHoaDon], H.[MSTNguoiBan] AS [MSTNguoiBanNguoiXuatHang], H.[MSTNguoiMua] AS [MSTNguoiMuaNguoiNhanHang], " +
                   "H.[NgayLap], H.[MaCTKeToan], " + sale + " AS [HDBanRa], H.[TongTien] AS [TongTienThanhToan], H.[TinhTrangHoaDon] AS [TrangThaiHoaDon]" + extra.ToString() + " " +
                   "FROM [dbo].[HDDTTaiVe] H WHERE H.[KhoaHD] IS NOT NULL" + onlyInvoice + skip + " ORDER BY H.[MaSo]";
        }
        List<string> cols = Columns(cn, name);
        if (cols.Count == 0) return null;
        var sb = new StringBuilder();
        foreach (string c in cols) {
            if (name == "ChungTu" && string.Equals(c, "MaCTHDDTTaiVe", StringComparison.OrdinalIgnoreCase) && ColumnAvailable(cn, "ChungTu", "KhoaHDDT"))
                sb.Append("CASE WHEN ISNULL([KhoaHDDT],N'') NOT IN (N'',N'...') THEN [KhoaHDDT] ELSE ISNULL(CAST([MaCTHDDTTaiVe] AS nvarchar(50)),N'') END AS [MaCTHDDTTaiVe],");
            else sb.Append(Quote(c)).Append(",");
        }
        sb.Length -= 1;
        // SQL Server gives no order without ORDER BY and the analysers allocate payments first-in-first-out: MaSo when the table has it
        bool hasMaSo = cols.Exists(delegate (string c) { return string.Equals(c, "MaSo", StringComparison.OrdinalIgnoreCase); });
        return "SELECT " + sb.ToString() + " FROM [dbo]." + Quote(name) + (hasMaSo ? " ORDER BY [MaSo]" : "");
    }
    static char Kind(Type t) {
        if (t == typeof(bool)) return 'b';
        if (t == typeof(byte) || t == typeof(short) || t == typeof(int) || t == typeof(long)) return 'i';
        if (t == typeof(decimal) || t == typeof(double) || t == typeof(float)) return 'f';
        if (t == typeof(DateTime)) return 'd';
        return 's';
    }
    static void Text(TextWriter w, string v) {
        w.Write('"');
        if (v != null) foreach (char ch in v) {
            switch (ch) {
                case '"': w.Write("\\\""); break;
                case '\\': w.Write("\\\\"); break;
                case (char)8: w.Write("\\b"); break;
                case (char)9: w.Write("\\t"); break;
                case (char)10: w.Write("\\n"); break;
                case (char)12: w.Write("\\f"); break;
                case (char)13: w.Write("\\r"); break;
                default: if (ch < 32) w.Write("\\u" + ((int)ch).ToString("x4", CultureInfo.InvariantCulture)); else w.Write(ch); break;
            }
        }
        w.Write('"');
    }
    static void Value(TextWriter w, object v, char kind) {
        if (v == null || v is DBNull) { w.Write("null"); return; }
        switch (kind) {
            case 'b': w.Write(Convert.ToBoolean(v, CultureInfo.InvariantCulture) ? "true" : "false"); break;
            case 'i': w.Write(Convert.ToInt64(v, CultureInfo.InvariantCulture).ToString(CultureInfo.InvariantCulture)); break;
            case 'f': { double d = Convert.ToDouble(v, CultureInfo.InvariantCulture); if (double.IsNaN(d) || double.IsInfinity(d)) w.Write("null"); else w.Write(d.ToString("R", CultureInfo.InvariantCulture)); break; }
            case 'd': w.Write("\"" + Convert.ToDateTime(v, CultureInfo.InvariantCulture).ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture) + "\""); break;
            default: Text(w, Convert.ToString(v, CultureInfo.InvariantCulture)); break;
        }
    }
    public static int Run(string server, string db, string path, out string message) {
        message = "";
        string temp = path + ".tmp";
        try {
            var cs = new SqlConnectionStringBuilder();
            cs.DataSource = server; cs.InitialCatalog = db; cs.IntegratedSecurity = true; cs.ApplicationIntent = ApplicationIntent.ReadOnly; cs.ConnectTimeout = 15; cs.ApplicationName = "UNESCO XII tram ERP (chup so)";
            using (var cn = new SqlConnection(cs.ConnectionString)) {
                cn.Open();
                using (var w = new StreamWriter(temp, false, new UTF8Encoding(false))) {
                    w.Write("{\"format\":\"xii-so-sql-1\",\"db\":"); Text(w, db); w.Write(",\"tables\":{");
                    bool first = true;
                    foreach (string name in Tables) {
                        if (!TableAvailable(cn, name)) continue;
                        string sql = SelectFor(cn, name);
                        if (sql == null) continue;
                        using (var c = new SqlCommand(sql, cn)) {
                            c.CommandTimeout = 600;
                            using (var rd = c.ExecuteReader()) {
                                int n = rd.FieldCount; var kinds = new char[n];
                                if (!first) w.Write(","); first = false;
                                Text(w, name); w.Write(":{\"cols\":[");
                                for (int i = 0; i < n; i++) { if (i > 0) w.Write(","); Text(w, rd.GetName(i)); kinds[i] = Kind(rd.GetFieldType(i)); }
                                w.Write("],\"kinds\":[");
                                for (int i = 0; i < n; i++) { if (i > 0) w.Write(","); w.Write("\"" + kinds[i] + "\""); }
                                w.Write("],\"rows\":[");
                                bool firstRow = true;
                                while (rd.Read()) {
                                    if (!firstRow) w.Write(","); firstRow = false;
                                    w.Write("[");
                                    for (int i = 0; i < n; i++) { if (i > 0) w.Write(","); Value(w, rd.GetValue(i), kinds[i]); }
                                    w.Write("]");
                                }
                                w.Write("]}");
                            }
                        }
                    }
                    w.Write("}}");
                }
            }
            if (File.Exists(path)) File.Delete(path);
            File.Move(temp, path);
            return 0;
        } catch (Exception e) {
            message = e.GetType().Name + ": " + e.Message.Replace("\r", " ").Replace("\n", " ");
            try { if (File.Exists(temp)) File.Delete(temp); } catch (Exception) { }
            return 2;
        }
    }
}
'@
$msg = ''
$rc = [XiiChup]::Run($Server, $Database, $Out, [ref]$msg)
if ($rc -ne 0) { Write-Output ('LOI: khong chup duoc so ' + $Database + ' (' + $msg + ')'); exit 2 }
Write-Output ('OK ' + $Out)
exit 0
