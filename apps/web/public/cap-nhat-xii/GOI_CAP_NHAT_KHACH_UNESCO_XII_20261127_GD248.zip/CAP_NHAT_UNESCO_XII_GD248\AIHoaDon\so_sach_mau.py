# -*- coding: utf-8 -*-
"""GD78 - BIEU MAU SO SACH, CHUNG TU THEO TT133 (bang so do mau Excel TT133, bo cac mau to xanh: DM tai khoan, DM chung tu,
bang ke chi phi khong duoc tru, phieu ke toan) - MOI MAU MOT TEP Excel, so lieu lay tu so cua ky dang chon. CHI DOC SO.

Hop dong (xuat_1_lan.py): lap(dl, ma, kieu, thumuc) -> {"tep": [...], "canh_bao": [...]}; TEN_MAU = {ma: ten hien thi}.
  dl  = JSON VB: phan chung (BC_Json + KS_Json: tk, ps, kh_dau / kh_no / kh_co, dt, dt_dc, nk, nguoi_ky...) + "x1l" + "dn"
        + "ss" (ModHDDTSoSach.HDDT_SS_JsonThem): ct (dong chung tu day du trong ky), vt / kho / tonkho / ck4, ccdc / ccdc_ts,
        tsan / tsan_ts, nv / cc / bl / tsl / gt_khac, tk_nh, dt_nam_truoc.
  Bo cuc (tieu de, mau so, dong don vi / dia chi, dau cot, gop o, do rong, co chu, khung, ky ten) doc tu
  tham_khao/mau_so_sach_tt133.json (trich tu tep mau Excel TT133 bang tool/gd78/sosach/trich_mau.py - bo du lieu mau).
  Cong thuc tham chieu sheet khac cua mau -> GIA TRI tinh dung tu so. Excel viet bang xlsx_viet (khong can openpyxl).
  So tren bieu mau = so tren so cua phan mem: phat sinh / so du theo HethongTK + ChungTu (nhu so cai), gia xuat kho = so
  tien phan mem da tinh tren dong xuat, ton kho = TonKho (Luong_k / Tien_k), khau hao = ThongSo, phan bo CCDC / 242 =
  ThongSo1, luong = BangLuong, cham cong = ChamCong. Moi mau tu doi chieu voi so (canh_bao khi lech): NKC = tong phat sinh
  = F01, so cai / chi tiet: dau + No - Co = cuoi, quy = du 111, tien gui = du 112, TH 131 / 331 = F01 hai ben, N-X-T = du TK
  kho = TonKho, khau hao = 211 / 214, phan bo = 242, luong = Co 334, TonKho khop chung tu tung thang.
  Nhap / xuat kho theo dung dieu kien SAS.bas tinh TonKho: TK_ID 1000, co ma vat tu + ma kho, loai 1 / 13 / 4 (nhap), 2 / 4 (xuat).
  Ky in = tron cac thang ghi so (ThangCT) t1..t2 (so phan mem ghi theo thang).
  B01a / B02 / B03 / F01 / B09 cua bang so do GIAO cho bao_cao_nam.py / thuyet_minh_b09.py (khong lap lai o day)."""
import datetime
import importlib
import io
import json
import math
import os
import re
from collections import OrderedDict, defaultdict

import kiem_khoa_so as K
from xlsx_viet import SoExcel
from xlsx_viet import CT as _CT          # GD222

GOC = os.path.dirname(os.path.abspath(__file__))

TEN_MAU = OrderedDict([
    ("SS_NKC", "Nhật ký chung (S03a-DNN)"),
    ("SS_SOCAI", "Sổ cái các tài khoản (S03b-DNN)"),
    ("SS_SCTTK", "Sổ chi tiết tài khoản"),
    ("SS_QUYTM", "Sổ quỹ tiền mặt (S04a-DNN)"),
    ("SS_TGNH", "Sổ tiền gửi ngân hàng (S05-DNN)"),
    ("SS_TH131", "Bảng tổng hợp công nợ phải thu khách hàng - TK 131"),
    ("SS_TH331", "Bảng tổng hợp công nợ phải trả nhà cung cấp - TK 331"),
    ("SS_CDTK", "Bảng cân đối số phát sinh tài khoản (F01-DNN)"),
    ("SS_B01A", "Báo cáo tình hình tài chính (B01a-DNN)"),
    ("SS_B02", "Báo cáo kết quả kinh doanh (B02-DNN)"),
    ("SS_B03", "Báo cáo lưu chuyển tiền tệ (B03-DNN)"),
    ("SS_TM", "Thuyết minh báo cáo tài chính (B09-DNN)"),
    ("SS_TTTNDN", "Tạm tính thuế TNDN theo quý"),
    ("SS_PTHU", "Phiếu thu (01-TT)"),
    ("SS_PCHI", "Phiếu chi (02-TT)"),
    ("SS_PNK", "Phiếu nhập kho (01-VT)"),
    ("SS_PXK", "Phiếu xuất kho (02-VT)"),
    ("SS_BKNX", "Bảng kê phiếu nhập - xuất kho hàng hóa"),
    ("SS_SCTVT", "Sổ chi tiết vật tư, hàng hóa (S07-DNN)"),
    ("SS_THNXT", "Bảng tổng hợp nhập - xuất - tồn kho (S08-DNN)"),
    ("SS_DMHH", "Danh mục hàng hóa"),
    ("SS_PBCPMH", "Bảng phân bổ chi phí mua hàng"),
    ("SS_PB242", "Bảng phân bổ chi phí trả trước - TK 242"),
    ("SS_KH214", "Bảng tính khấu hao TSCĐ - TK 214"),
    ("SS_CHAMCONG", "Bảng chấm công (01a-LĐTL)"),
    ("SS_LUONG", "Bảng tính lương"),
    ("SS_TNCNTHANG", "Bảng tính thuế TNCN cho người lao động"),
])
# mau bao cao tai chinh tren bang so do: giao module cua nhom khac (goi qua importlib)
GIAO = {"SS_B01A": ("bao_cao_nam", "B01A"), "SS_B02": ("bao_cao_nam", "B02"), "SS_B03": ("bao_cao_nam", "B03"),
        "SS_CDTK": ("bao_cao_nam", "F01"), "SS_TM": ("thuyet_minh_b09", "SS_TM")}
TKVT_ID = 1000            # TK_ID tai khoan vat tu (SAS.bas) - TonKho chi tinh cac TK nay
TEP = {"SS_NKC": "NhatKyChung", "SS_SOCAI": "SoCai", "SS_SCTTK": "SoChiTietTaiKhoan", "SS_QUYTM": "SoQuyTienMat",
       "SS_TGNH": "SoTienGuiNganHang", "SS_TH131": "TongHopPhaiThu_131", "SS_TH331": "TongHopPhaiTra_331",
       "SS_TTTNDN": "TamTinhThueTNDN", "SS_PTHU": "PhieuThu", "SS_PCHI": "PhieuChi", "SS_PNK": "PhieuNhapKho",
       "SS_PXK": "PhieuXuatKho", "SS_BKNX": "BangKeNhapXuat", "SS_SCTVT": "SoChiTietVatTu", "SS_THNXT": "TongHopNhapXuatTon",
       "SS_DMHH": "DanhMucHangHoa", "SS_PBCPMH": "PhanBoChiPhiMuaHang", "SS_PB242": "PhanBoChiPhiTraTruoc_242",
       "SS_KH214": "KhauHaoTSCD_214", "SS_CHAMCONG": "BangChamCong", "SS_LUONG": "BangTinhLuong", "SS_TNCNTHANG": "BangTinhThueTNCN"}

TK_KHO = ("151", "152", "153", "154", "155", "156", "157", "158")
F_TIEN = '#,##0;(#,##0);"-"'
F_SL = '#,##0.00;(#,##0.00);"-"'
F_SL0 = '#,##0;(#,##0);"-"'
F_NGAY = "dd/mm/yyyy"
TOI_DA_PHIEU_SHEET = 1500
KIEM = {}                 # ma -> [(ten, so bieu mau, so so sach, khop)] cua lan lap gan nhat (de test / tro ly doc)
_MAU = [None]
_CACHE = [None, None]


def _so(x):
    return K._so(x)


def lam_tron(x):
    """lam tron dong: half away from zero (nhu HTKK)."""
    x = _so(x)
    return int(math.floor(abs(x) + 0.5)) * (1 if x >= 0 else -1)


def dd(x):
    return "{:,.0f}".format(lam_tron(x)).replace(",", ".")


def sl_txt(x):
    """so luong -> chu kieu Viet (1.234,5)"""
    x = round(_so(x), 2)
    s = "{:,.2f}".format(x).rstrip("0").rstrip(".")
    return s.replace(",", "#").replace(".", ",").replace("#", ".")


def _ngay(s):
    if isinstance(s, datetime.date):
        return s
    m = re.match(r"\s*(\d{1,2})/(\d{1,2})/(\d{4})", str(s or ""))
    if not m:
        return None
    try:
        return datetime.date(int(m.group(3)), int(m.group(2)), int(m.group(1)))
    except ValueError:
        return None


# ============================================================ so -> chu
_CS = ["không", "một", "hai", "ba", "bốn", "năm", "sáu", "bảy", "tám", "chín"]


def _doc3(n, day_du):
    tr, ch, dv = n // 100, (n // 10) % 10, n % 10
    ds = []
    if tr > 0 or day_du:
        ds += [_CS[tr], "trăm"]
    if ch == 0:
        if dv > 0 and (tr > 0 or day_du):
            ds.append("lẻ")
    elif ch == 1:
        ds.append("mười")
    else:
        ds += [_CS[ch], "mươi"]
    if dv > 0:
        if dv == 1 and ch >= 2:
            ds.append("mốt")
        elif dv == 5 and ch >= 1:
            ds.append("lăm")
        else:
            ds.append(_CS[dv])
    return ds


def so_thanh_chu(so, don_vi="đồng"):
    """So tien -> chu tieng Viet chuan (vd 1.005.000 -> 'Một triệu không trăm lẻ năm nghìn đồng'). Lam tron dong truoc."""
    n = lam_tron(so)
    am = n < 0
    n = abs(n)
    if n == 0:
        kq = "không " + don_vi if don_vi else "không"
    else:
        nhom = []
        while n > 0:
            nhom.append(n % 1000)
            n //= 1000
        ds = []
        for i in range(len(nhom) - 1, -1, -1):
            g = nhom[i]
            if g == 0:
                continue
            ds += _doc3(g, i < len(nhom) - 1)
            dv = ["", "nghìn", "triệu"][i % 3]
            if dv:
                ds.append(dv)
            ds += ["tỷ"] * (i // 3)
        kq = " ".join(ds) + ((" " + don_vi) if don_vi else "")
    if am:
        kq = "âm " + kq
    return kq[:1].upper() + kq[1:]


# ============================================================ thue TNCN (bieu luy tien tung phan - thang)
def thue_tncn_thang(tn, nam):
    """Thue TNCN thang tren thu nhap tinh thue tn. Tu 2026: 5 bac 5/10/20/30/35% nguong 10/30/60/100 trieu
    (Luat 109/2025/QH15); den 2025: 7 bac 5-35% (nguong 5/10/18/32/52/80 trieu)."""
    tn = _so(tn)
    if tn <= 0:
        return 0
    if nam >= 2026:
        bac = [(10e6, 0.05), (30e6, 0.10), (60e6, 0.20), (100e6, 0.30), (None, 0.35)]
    else:
        bac = [(5e6, 0.05), (10e6, 0.10), (18e6, 0.15), (32e6, 0.20), (52e6, 0.25), (80e6, 0.30), (None, 0.35)]
    thue, duoi = 0.0, 0.0
    for tren, ts in bac:
        if tren is None or tn <= tren:
            thue += (tn - duoi) * ts
            break
        thue += (tren - duoi) * ts
        duoi = tren
    return lam_tron(thue)


def giam_tru_luat(nam):
    """(ban than, nguoi phu thuoc) / thang theo nam tinh thue: tu 2026 15,5 tr / 6,2 tr (NQ 110/2025/UBTVQH15); truoc 11 / 4,4 tr."""
    return (15500000, 6200000) if nam >= 2026 else (11000000, 4400000)


# ============================================================ so lieu
class Dong(object):
    __slots__ = ("ms", "mact", "loai", "thang", "t", "sh", "ngay", "ngay_gs", "dg", "no", "co", "tien", "kh", "khc", "vt",
                 "kho", "sl_no", "sl_co", "nguon", "thuchi")


class SoLieuSS(K.SoLieu):
    def __init__(self, dl):
        K.SoLieu.__init__(self, dl)
        self.dl = dl
        self.x1l = dl.get("x1l") or {}
        self.dn = dl.get("dn") or {}
        self.ss = dl.get("ss") or {}
        self.cb = [str(x) for x in (self.ss.get("canh_bao") or [])]
        ky = dl.get("ky") or {}
        self.tu = _ngay(self.x1l.get("tu") or ky.get("tu"))
        self.den = _ngay(self.x1l.get("den") or ky.get("den"))
        self.nam = int(_so(self.x1l.get("nam_tc") or dl.get("nam_tc")) or (self.den.year if self.den else datetime.date.today().year))
        self.ngay_lap = _ngay(self.x1l.get("ngay_lap")) or datetime.date.today()
        if self.tu is None:
            self.tu = datetime.date(self.nam, self.dau_ky, 1)
        if self.den is None:
            self.den = self.ngay_lap
        self.ca_nam = (self.t1 == 1 and self.t2 == 12)
        # so sach phan mem ghi theo THANG (ThangCT): ky in tren bieu mau = tron cac thang t1..t2
        m1, y1 = self.thang_lich(self.t1)
        m2, y2 = self.thang_lich(self.t2)
        self.tu_ky = datetime.date(y1, m1, 1)
        self.den_ky = datetime.date(y2 + (m2 == 12), m2 % 12 + 1, 1) - datetime.timedelta(days=1)
        if (self.tu, self.den) != (self.tu_ky, self.den_ky):
            self.cb.append("Kỳ chọn %s - %s không trọn tháng: sổ sách phần mềm ghi theo tháng (tháng ghi sổ trên chứng từ) nên "
                           "biểu mẫu lập trọn các tháng, từ ngày %s đến ngày %s" % (
                               self.tu.strftime("%d/%m/%Y"), self.den.strftime("%d/%m/%Y"), self.tu_ky.strftime("%d/%m/%Y"),
                               self.den_ky.strftime("%d/%m/%Y")))
        nk = dict(dl.get("nguoi_ky") or {})
        if not nk.get("giam_doc"):
            nk["giam_doc"] = self.dn.get("nguoi_dd_pl") or ""
        self.nguoi_ky = nk
        self.dt = {int(_so(r[0])): [str(r[1] or ""), str(r[2] or ""), str(r[3] or "") if len(r) > 3 else ""] for r in dl.get("dt") or []}
        self.dt_dc = {int(_so(r[0])): str(r[1] or "") for r in dl.get("dt_dc") or []}
        self._top = {}
        self._doc_ct()

    # ---- tai khoan
    def sh(self, ma):
        return (self.tk.get(ma) or {}).get("sh", "")

    def ten_tk(self, ma):
        return (self.tk.get(ma) or {}).get("ten", "")

    def top(self, ma):
        if ma in self._top:
            return self._top[ma]
        x, buoc = ma, 0
        while buoc < 10:
            c = (self.tk.get(x) or {}).get("cha", 0)
            # dung o TK cap 1: cha la nhom 'Loai 1..9' (so hieu khong bat dau bang chu so) hoac khong co
            if not c or c == x or c not in self.tk or not self.tk[c]["sh"][:1].isdigit():
                break
            x, buoc = c, buoc + 1
        self._top[ma] = x
        return x

    def la_duoi(self, top):
        return [m for m in self.la if self.top(m) == top]

    def thang_lich(self, t):
        """thu tu thang tai chinh -> (thang, nam) duong lich"""
        m = (self.dau_ky - 1 + t - 1) % 12 + 1
        return m, (self.nam if m >= self.dau_ky else self.nam + 1)

    def ten_dt(self, kh):
        d = self.dt.get(kh)
        t = (d[1] if d else "").strip()
        return "" if t in ("...", "..", ".", "#", "0") else t

    def dc_dt(self, kh):
        t = (self.dt_dc.get(kh) or "").strip() if kh else ""
        return "" if t in ("...", "..", ".", "#", "0") else t

    # ---- dong chung tu
    def _doc_ct(self):
        ds = []
        rows = self.ss.get("ct")
        self.co_ct_day_du = rows is not None
        if rows is None:
            # du phong: JSON khong co "ss" -> dung nhat ky tom tat (dong du 2 ben, dien giai 80 ky tu)
            ma_sh = {}
            for m, t in sorted(self.tk.items()):
                if t["con"] == 0:
                    ma_sh.setdefault(t["sh"], m)
            rows = []
            for i, r in enumerate(self.dl.get("nk") or []):
                ng = str(r[2] or "")
                rows.append([i + 1, r[0], 0, (_ngay(ng) or self.den).month, r[1], ng, ng, r[3], ma_sh.get(str(r[4] or ""), 0),
                             ma_sh.get(str(r[5] or ""), 0), r[6], 0, 0, 0, 0, 0, 0, 0, ""])
            if rows:
                self.cb.append("Thiếu dòng chứng từ đầy đủ (JSON không có phần \"ss\") - dùng nhật ký tóm tắt; "
                               "dòng một bên (Nợ hoặc Có) không có trong biểu mẫu")
        for r in rows:
            r = list(r) + [0] * (19 - len(r))
            d = Dong()
            d.ms, d.mact, d.loai, d.thang = int(_so(r[0])), int(_so(r[1])), int(_so(r[2])), int(_so(r[3]))
            d.t = K.thang_tc(d.thang, self.dau_ky)
            d.sh, d.ngay, d.ngay_gs, d.dg = str(r[4] or ""), _ngay(r[5]), _ngay(r[6]) or _ngay(r[5]), str(r[7] or "")
            d.no, d.co, d.tien = int(_so(r[8])), int(_so(r[9])), lam_tron(r[10])
            d.kh, d.khc, d.vt, d.kho = int(_so(r[11])), int(_so(r[12])), int(_so(r[13])), int(_so(r[14]))
            d.sl_no, d.sl_co, d.nguon = _so(r[15]), _so(r[16]), int(_so(r[17]))
            d.thuchi = str(r[18] or "").strip()
            if d.thuchi in ("...", ".", "0"):
                d.thuchi = ""
            ds.append(d)
        ds.sort(key=lambda d: (d.t, d.ngay_gs or datetime.date(1900, 1, 1), d.mact, d.ms))
        self.ct = [d for d in ds if self.t1 <= d.t <= self.t2]
        # doi ung cua dong mot ben: TK ben kia trong cung chung tu
        mot_no, mot_co = defaultdict(list), defaultdict(list)
        for d in self.ct:
            if d.no and not d.co:
                mot_no[d.mact].append(d.no)
            elif d.co and not d.no:
                mot_co[d.mact].append(d.co)
        self._mot_no, self._mot_co = mot_no, mot_co

    def _ds_tk(self, ds):
        kq = []
        for m in ds:
            s = self.sh(m)
            if s and s not in kq:
                kq.append(s)
        if len(kq) > 3:
            return ", ".join(kq[:3]) + "..."
        return ", ".join(kq)

    def doi_ung_no(self, d):
        """TK doi ung khi dong d nam ben No"""
        return self.sh(d.co) if d.co else self._ds_tk(self._mot_co.get(d.mact, []))

    def doi_ung_co(self, d):
        return self.sh(d.no) if d.no else self._ds_tk(self._mot_no.get(d.mact, []))

    # ---- chu tieu de
    def thay(self, **them):
        dn = self.dn
        ten = dn.get("ten") or (self.dl.get("cty") or {}).get("ten") or ""
        dc = str(dn.get("dia_chi") or "").strip()
        for x in (dn.get("quan"), dn.get("tinh")):
            x = str(x or "").strip()
            if x and x.lower() not in dc.lower():
                dc = (dc + ", " + x) if dc else x
        tu, den = self.tu_ky.strftime("%d/%m/%Y"), self.den_ky.strftime("%d/%m/%Y")
        d = {"TEN_DV": "Đơn vị: " + ten, "DIA_CHI": "Địa chỉ: " + dc, "NAM": str(self.nam),
             "KY_HOA": ("NĂM %d" % self.nam) if self.ca_nam else ("TỪ NGÀY %s ĐẾN NGÀY %s" % (tu, den)),
             "KY_NAM": str(self.nam),
             "KY_TT": ("năm %d" % self.nam) if self.ca_nam else ("từ ngày %s đến ngày %s" % (tu, den)),
             "KY_HOA_TT": ("Năm: %d" % self.nam) if self.ca_nam else ("Từ ngày %s đến ngày %s" % (tu, den)),
             "KY_THUONG": ("Năm %d" % self.nam) if self.ca_nam else ("Từ ngày %s đến ngày %s" % (tu, den)),
             "NOI_NGAY": self.noi_ngay(self.ngay_lap)}
        d.update(them)
        return d

    def noi_ngay(self, ng):
        tinh = re.sub(r"^(Tỉnh|Thành phố|TP\.?)\s+", "", str(self.dn.get("tinh") or "").strip(), flags=re.I)
        s = "ngày %02d tháng %02d năm %d" % (ng.day, ng.month, ng.year)
        return (tinh + ", " + s) if tinh else (s[:1].upper() + s[1:])


class Kiem(object):
    """doi chieu so tren bieu mau voi so sach"""

    def __init__(self, ma):
        self.ma = ma
        self.ds = []

    def them(self, ten, a, b, sai=0.5):
        self.ds.append((ten, lam_tron(a), lam_tron(b), abs(_so(a) - _so(b)) <= sai))

    def canh_bao(self):
        KIEM[self.ma] = list(self.ds)
        cb = ["LỆCH khi đối chiếu - %s: biểu mẫu %s, sổ %s (chênh %s)" % (t, dd(a), dd(b), dd(a - b)) for t, a, b, ok in self.ds if not ok]
        if self.ds:
            n = sum(1 for x in self.ds if x[3])
            cb.append("Đối chiếu với sổ: khớp %d/%d mục" % (n, len(self.ds)))
        return cb


# ============================================================ ve theo mau
def mau():
    if _MAU[0] is None:
        with io.open(os.path.join(GOC, "tham_khao", "mau_so_sach_tt133.json"), "r", encoding="utf-8") as f:
            _MAU[0] = json.load(f)
    return _MAU[0]


_RE_THAY = re.compile(r"\{([A-Z0-9_]+)\}")


_TEN_KY = [("người lập phiếu", "nguoi_lap"), ("người lập", "nguoi_lap"), ("kế toán trưởng", "ke_toan_truong"),
           ("giám đốc", "giam_doc"), ("đại diện", "giam_doc"), ("người phê duyệt", "giam_doc"), ("thủ quỹ", "thu_quy"),
           ("thủ kho", "thu_kho"), ("người nộp", "NGUOI"), ("người nhận", "NGUOI"), ("người giao", "NGUOI")]


class Ve(object):
    def __init__(self, S, ma):
        M = mau()
        self.S, self.ma = S, ma
        self.sp = M["mau"][ma]
        self.K = M["kieu"]
        self.wb = SoExcel("Times New Roman", 12)
        self._c = {}
        self._dk = {}
        self.cot = sorted(int(c) for c in self.sp["rong"])

    def kieu(self, kid, **them):
        key = (kid, tuple(sorted((k, tuple(sorted(v.items())) if isinstance(v, dict) else v) for k, v in them.items())))
        if key in self._c:
            return self._c[key]
        d = dict(self.K[int(kid[1:])]) if kid else {"font": "Times New Roman", "co": 12}
        d.update(them)
        kh = d.get("khung") or {}
        k = self.wb.kieu(dam=d.get("dam", False), nghieng=d.get("nghieng", False), gach=d.get("gach", False), co=d.get("co"),
                         font=d.get("font"), nen=d.get("nen"), khung=False, khung_trai=kh.get("trai") or False,
                         khung_phai=kh.get("phai") or False, khung_tren=kh.get("tren") or False, khung_duoi=kh.get("duoi") or False,
                         so=d.get("so"), can=d.get("can"), doc=d.get("doc", "giua"), xuong=d.get("xuong", False))
        self._c[key] = k
        return k

    def sheet(self, ten):
        ws = self.wb.sheet(ten)
        for c, w in self.sp["rong"].items():
            ws.rong(int(c), w)
        ws.in_trang(ngang=self.sp.get("ngang", False))
        return ws

    def _sub(self, v, thay):
        if isinstance(v, str):
            v = _RE_THAY.sub(lambda m: str(thay.get(m.group(1), "")), v)
        return v

    def _khoi(self, ws, r0, o_ds, gop, cao, thay):
        for (a, b, c, d) in gop:
            ws.gop(r0 + a - 1, b, r0 + c - 1, d)
        for r, h in (cao or {}).items():
            ws.cao(r0 + int(r) - 1, h)
        for (r, c, v, k) in o_ds:
            v = self._sub(v, thay)
            ws.o(r0 + r - 1, c, v if v != "" else None, self.kieu(k))

    def dau(self, ws, r0, thay):
        self._khoi(ws, r0, self.sp["dau"], self.sp["gop_dau"], self.sp.get("cao_dau"), thay)
        return r0 + self.sp["so_dong_dau"]

    def cuoi(self, ws, r0, thay, nguoi=""):
        """phan ngay lap + ky ten; ghi ho ten nguoi ky (khai bao mot lan) duoi '(Ky, ho ten)'. -> dong cuoi da ghi"""
        o_ds = self.sp.get("cuoi") or []
        self._khoi(ws, r0, o_ds, self.sp.get("gop_cuoi") or [], self.sp.get("cao_cuoi"), thay)
        cuoi = r0 + max([x[0] for x in o_ds] or [1]) - 1
        cuoi = max(cuoi, self._ten_ky(ws, r0, o_ds, self.sp.get("gop_cuoi") or [], nguoi, 4))
        return cuoi

    def _ten_ky(self, ws, r0, o_ds, gop, nguoi, cach):
        nk = self.S.nguoi_ky
        cao = r0
        o = {(x[0], x[1]): x for x in o_ds}
        for (r, c, v, k) in o_ds:
            if not (isinstance(v, str) and v.strip().startswith("(")):
                continue
            tieu = o.get((r - 1, c))
            if not tieu or not isinstance(tieu[2], str):
                continue
            t = tieu[2].lower()
            if "người lập phiếu" in t and "người giao" in t:
                continue
            khoa = next((kk for tt, kk in _TEN_KY if tt in t), None)
            if not khoa:
                continue
            ten = nguoi if khoa == "NGUOI" else nk.get(khoa, "")
            if not ten:
                continue
            rr = r0 + r - 1 + cach
            span = next(((b, d) for (a, b, cc, d) in gop if a == r - 1 and b <= c <= d), None)
            kd = self.kieu(tieu[3], nghieng=False, dam=True)
            if span and span[1] > span[0]:
                ws.gop(rr, span[0], rr, span[1])
            ws.o(rr, c, ten, kd)
            cao = max(cao, rr)
        return cao

    def ky_chung(self, ws, r, cot, ngay=None):
        """khoi ky ten chung (mau goc khong co): ngay lap + Nguoi lap bieu / Ke toan truong / Giam doc; cot = 3 cot."""
        nk = self.S.nguoi_ky
        kn = self.kieu(None, nghieng=True, co=11, can="giua")
        kd = self.kieu(None, dam=True, co=11, can="giua")
        ws.o(r, cot[2], self.S.noi_ngay(ngay or self.S.ngay_lap), kn)
        for c, (ten, khoa) in zip(cot, (("Người lập biểu", "nguoi_lap"), ("Kế toán trưởng", "ke_toan_truong"),
                                        ("Giám đốc", "giam_doc"))):
            ws.o(r + 1, c, ten, kd)
            ws.o(r + 2, c, "(Ký, họ tên)" if khoa != "giam_doc" else "(Ký, họ tên, đóng dấu)", kn)
            if nk.get(khoa):
                ws.o(r + 6, c, nk[khoa], kd)
        return r + 6

    def dong(self, ws, r, ten, gt, vai=None, them=None, gop=True):
        """ghi mot dong du lieu theo kieu dong mau 'ten' (khung, co chu, dam...) - vai: {cot: 'so'|'sl'|'dg'|'ngay'|'giua'|'trai'|'traix'}"""
        dm = self.sp["dong"][ten]
        vai = vai or {}
        them = them or {}
        if gop:
            for (b, d) in dm.get("gop") or []:
                ws.gop(r, b, r, d)
        for c in self.cot:
            v = gt.get(c)
            vv = vai.get(c)
            if vv == "so" and v is not None:
                v = lam_tron(v)
            elif vv in ("sl", "dg") and v is not None:
                v = round(_so(v), 2 if vv == "dg" else 4)
                if v == int(v):
                    v = int(v)
            tc = them.get(c)
            key = (ten, c, vv, tuple(sorted(tc.items())) if tc else None, isinstance(v, float))
            k = self._dk.get(key)
            if k is None:
                x = dict(tc or {})
                if vv == "so":
                    x.update(so=F_TIEN, can="phai")
                elif vv in ("sl", "dg"):
                    x.update(so=F_SL if isinstance(v, float) else F_SL0, can="phai")
                elif vv == "ngay":
                    x.update(so=F_NGAY, can="giua")
                elif vv == "giua":
                    x.update(can="giua")
                elif vv == "trai":
                    x.update(can="trai", xuong=False)
                elif vv == "traix":
                    x.update(can="trai", xuong=True)
                elif vv == "phai":
                    x.update(can="phai")
                k = self.kieu(dm["kieu"].get(str(c)), **x)
                self._dk[key] = k
            ws.o(r, c, v, k)

    def ghi_chu(self, ws, r, c1, c2, chu, co=11):
        """dong ghi chu dai: gop o c1..c2 (trong be rong bang), xuong dong, chieu cao theo do dai - khong tran ra ngoai vung in"""
        c2 = max(c1, min(c2, max(self.cot)))
        rong = sum(float(self.sp["rong"].get(str(c), 9.0)) for c in range(c1, c2 + 1))
        k = self.kieu("k0", nghieng=True, co=co, can="trai", doc="tren", xuong=True)
        ws.gop(r, c1, r, c2, chu, k)
        dong = max(1, int(math.ceil(len(chu) * (co / 11.0) / max(rong * 1.15, 10))))
        ws.cao(r, 15.0 * dong * (co / 11.0) + 2)
        return r

    def luu(self, S, ma):
        ten = TEP[ma] + "_%d" % S.nam + ("" if S.ca_nam else "_T%02d-%02d" % (S.thang_lich(S.t1)[0], S.thang_lich(S.t2)[0]))
        return ten


# ============================================================ 1. NHAT KY CHUNG
def lap_nkc(S):
    V, KT = Ve(S, "SS_NKC"), Kiem("SS_NKC")
    ws = V.sheet("Nhật ký chung")
    r = V.dau(ws, 1, S.thay())
    ws.in_trang(ngang=False, lap_dong=(7, 9))
    vai = {1: "ngay", 2: "giua", 3: "ngay", 4: "traix", 5: "giua", 6: "giua", 7: "so", 8: "so"}
    tn = tc = 0
    thang = OrderedDict()
    for d in S.ct:
        thang.setdefault(d.t, []).append(d)
    for t, ds in thang.items():
        m, y = S.thang_lich(t)
        V.dong(ws, r, "thang", {4: "Tháng %02d năm %d" % (m, y)}, {4: "trai"})
        r += 1
        sn = sc = 0
        for d in ds:
            chung = {1: d.ngay_gs, 2: d.sh, 3: d.ngay, 4: d.dg}
            if d.no:
                x = dict(chung)
                x.update({5: S.sh(d.no), 6: S.doi_ung_no(d), 7: d.tien})
                V.dong(ws, r, "dl", x, vai)
                r += 1
                sn += d.tien
            if d.co:
                x = dict(chung)
                x.update({5: S.sh(d.co), 6: S.doi_ung_co(d), 8: d.tien})
                V.dong(ws, r, "dl", x, vai)
                r += 1
                sc += d.tien
        V.dong(ws, r, "tong_thang", {4: "Cộng tháng %02d/%d" % (m, y), 7: sn, 8: sc}, {4: "trai", 7: "so", 8: "so"})
        r += 1
        tn += sn
        tc += sc
    ky = ("NĂM %d" % S.nam) if S.ca_nam else ("TỪ %s ĐẾN %s" % (S.tu_ky.strftime("%d/%m/%Y"), S.den_ky.strftime("%d/%m/%Y")))
    V.dong(ws, r, "tong", {4: "CỘNG PHÁT SINH " + ky, 7: tn, 8: tc}, {4: "trai", 7: "so", 8: "so"})
    V.cuoi(ws, r + 2, S.thay())
    pn = sum(S.ps_ky(m)[0] for m in S.la)
    pc = sum(S.ps_ky(m)[1] for m in S.la)
    KT.them("Tổng phát sinh Nợ trong kỳ (nhật ký chung / phát sinh các TK)", tn, pn)
    KT.them("Tổng phát sinh Có trong kỳ (nhật ký chung / phát sinh các TK)", tc, pc)
    f = _f01_bcn(S, "tong")
    if f is not None:
        KT.them("Tổng phát sinh Nợ = dòng Tổng cộng bảng cân đối tài khoản (F01)", tn, f[2])
        KT.them("Tổng phát sinh Có = dòng Tổng cộng bảng cân đối tài khoản (F01)", tc, f[3])
    if not S.ct:
        S_cb = ["Kỳ này sổ không có chứng từ - nhật ký chung chỉ có phần đầu / cuối"]
    else:
        S_cb = []
    return V, S_cb + KT.canh_bao()


# ============================================================ 2. SO CAI / 3. SO CHI TIET TK
def _du(x):
    return (x, None) if x > 0 else ((None, -x) if x < 0 else (None, None))


def _muc_luc(V, ws, S, ds, tieu_de, r=1):
    """sheet muc luc: STT, so hieu, ten TK, du dau / phat sinh / du cuoi"""
    kd = V.kieu(None, dam=True, co=14, can="giua")
    kh = V.kieu(None, dam=True, co=11, can="giua", xuong=True, khung={"trai": "mong", "phai": "mong", "tren": "mong", "duoi": "mong"})
    kt = V.kieu(None, co=11, khung={"trai": "mong", "phai": "mong", "tren": "mong", "duoi": "mong"})
    kc = V.kieu(None, co=11, can="giua", khung={"trai": "mong", "phai": "mong", "tren": "mong", "duoi": "mong"})
    ks = V.kieu(None, co=11, so=F_TIEN, can="phai", khung={"trai": "mong", "phai": "mong", "tren": "mong", "duoi": "mong"})
    ksd = V.kieu(None, co=11, dam=True, so=F_TIEN, can="phai", khung={"trai": "mong", "phai": "mong", "tren": "mong", "duoi": "mong"})
    for c, w in enumerate([6, 12, 42, 16, 16, 17, 17, 16, 16, 12], start=1):
        ws.rong(c, w)
    th = S.thay()
    ws.o(r, 1, th["TEN_DV"], V.kieu(None, co=11))
    ws.o(r + 1, 1, th["DIA_CHI"], V.kieu(None, co=11))
    ws.gop(r + 3, 1, r + 3, 10, tieu_de, kd)
    ws.gop(r + 4, 1, r + 4, 10, th["KY_THUONG"], V.kieu(None, nghieng=True, can="giua"))
    r += 6
    hd = ["STT", "Số hiệu TK", "Tên tài khoản", "Dư Nợ đầu kỳ", "Dư Có đầu kỳ", "Phát sinh Nợ", "Phát sinh Có", "Dư Nợ cuối kỳ",
          "Dư Có cuối kỳ", "Sheet"]
    for i, h in enumerate(hd, start=1):
        ws.o(r, i, h, kh)
    ws.cao(r, 30)
    r += 1
    tong = [0.0] * 6
    for i, (sh, ten, d0, pn, pc, sheet) in enumerate(ds, start=1):
        d1 = d0 + pn - pc
        v = [max(d0, 0), max(-d0, 0), pn, pc, max(d1, 0), max(-d1, 0)]
        ws.o(r, 1, i, kc)
        ws.o(r, 2, sh, kc)
        ws.o(r, 3, ten, kt)
        for j, x in enumerate(v):
            ws.o(r, 4 + j, lam_tron(x) if x else None, ks)
            tong[j] += x
        ws.o(r, 10, sheet, kc)
        r += 1
    ws.o(r, 3, "Tổng cộng", V.kieu(None, co=11, dam=True, can="giua", khung={"trai": "mong", "phai": "mong", "tren": "mong", "duoi": "mong"}))
    for c in (1, 2, 10):
        ws.o(r, c, None, kc)
    for j, x in enumerate(tong):
        ws.o(r, 4 + j, lam_tron(x), ksd)
    ws.in_trang(ngang=True, lap_dong=(7, 7))
    return r


def lap_socai(S):
    V, KT = Ve(S, "SS_SOCAI"), Kiem("SS_SOCAI")
    tops = OrderedDict()
    for m in S.la:
        tops.setdefault(S.top(m), []).append(m)
    dong = defaultdict(list)
    for d in S.ct:
        if d.no:
            dong[S.top(d.no)].append((d, "N"))
        if d.co:
            dong[S.top(d.co)].append((d, "C"))
    ds = []
    for tp in sorted(tops, key=lambda x: S.sh(x)):
        las = tops[tp]
        d0 = sum(S.du_dau(m) for m in las)
        pn = sum(S.ps_ky(m)[0] for m in las)
        pc = sum(S.ps_ky(m)[1] for m in las)
        if abs(d0) < 0.5 and not dong.get(tp) and abs(pn) < 0.5 and abs(pc) < 0.5:
            continue
        ds.append((tp, las, d0, pn, pc))
    ml = V.wb.sheet("Mục lục")
    _muc_luc(V, ml, S, [(S.sh(tp), S.ten_tk(tp), d0, pn, pc, S.sh(tp)) for tp, las, d0, pn, pc in ds],
             "SỔ CÁI CÁC TÀI KHOẢN - MỤC LỤC")
    vai = {1: "ngay", 2: "giua", 3: "ngay", 4: "traix", 5: "giua", 6: "giua", 7: "giua", 8: "so", 9: "so"}
    for tp, las, d0, pn, pc in ds:
        ws = V.sheet(S.sh(tp))
        r = V.dau(ws, 1, S.thay(TEN_TK=S.ten_tk(tp), SO_HIEU_TK=S.sh(tp)))
        ws.in_trang(ngang=False, lap_dong=(11, 13))
        n0, c0 = _du(d0)
        V.dong(ws, r, "dau_ky", {4: "Số dư đầu kỳ", 8: n0, 9: c0}, {8: "so", 9: "so"})
        r += 1
        V.dong(ws, r, "ps", {4: "Phát sinh trong kỳ"})
        r += 1
        sn = sc = 0
        for d, ben in dong.get(tp, []):
            x = {1: d.ngay_gs, 2: d.sh, 3: d.ngay, 4: d.dg}
            if ben == "N":
                x.update({7: S.doi_ung_no(d), 8: d.tien})
                sn += d.tien
            else:
                x.update({7: S.doi_ung_co(d), 9: d.tien})
                sc += d.tien
            V.dong(ws, r, "dl", x, vai)
            r += 1
        V.dong(ws, r, "cong", {4: "Cộng phát sinh", 8: sn, 9: sc}, {8: "so", 9: "so"})
        r += 1
        n1, c1 = _du(d0 + sn - sc)
        V.dong(ws, r, "cuoi_ky", {4: "Số dư cuối kỳ", 8: n1, 9: c1}, {8: "so", 9: "so"})
        V.cuoi(ws, r + 2, S.thay())
        KT.them("TK %s: phát sinh Nợ" % S.sh(tp), sn, pn)
        KT.them("TK %s: phát sinh Có" % S.sh(tp), sc, pc)
        KT.them("TK %s: đầu + Nợ - Có = số dư cuối các TK chi tiết" % S.sh(tp), d0 + sn - sc, sum(S.du_cuoi(m) for m in las))
    return V, _kiem_gon(KT, "SS_SOCAI")


def _kiem_gon(KT, ma):
    """gom canh bao doi chieu nhieu dong (moi TK) -> chi liet ke dong lech + tong ket"""
    return KT.canh_bao()


def lap_scttk(S):
    V, KT = Ve(S, "SS_SCTTK"), Kiem("SS_SCTTK")
    dong = defaultdict(list)
    for d in S.ct:
        if d.no:
            dong[d.no].append((d, "N"))
        if d.co:
            dong[d.co].append((d, "C"))
    ds = []
    for m in sorted(S.la, key=lambda x: (S.sh(x), x)):
        d0 = S.du_dau(m)
        pn, pc = S.ps_ky(m)
        if abs(d0) < 0.5 and not dong.get(m) and abs(pn) < 0.5 and abs(pc) < 0.5:
            continue
        ds.append((m, d0, pn, pc))
    ml = V.wb.sheet("Mục lục")
    ten_sheet = {}
    for m, d0, pn, pc in ds:
        ten = re.sub(r"[\[\]\*\?/\\:]", "-", S.sh(m))[:31] or str(m)
        goc, i = ten, 1
        while ten.lower() in (x.lower() for x in ten_sheet.values()):
            i += 1
            ten = goc[:28] + "_%d" % i
        ten_sheet[m] = ten
    _muc_luc(V, ml, S, [(S.sh(m), S.ten_tk(m), d0, pn, pc, ten_sheet[m]) for m, d0, pn, pc in ds], "SỔ CHI TIẾT CÁC TÀI KHOẢN - MỤC LỤC")
    vai = {1: "ngay", 2: "giua", 3: "ngay", 4: "traix", 5: "giua", 6: "so", 7: "so", 8: "so", 9: "so"}
    for m, d0, pn, pc in ds:
        ws = V.sheet(ten_sheet[m])
        r = V.dau(ws, 1, S.thay(TEN_TK=S.ten_tk(m), SO_HIEU_TK=S.sh(m)))
        ws.in_trang(ngang=False, lap_dong=(10, 12))
        n0, c0 = _du(d0)
        V.dong(ws, r, "dau_ky", {4: "Số dư đầu kỳ", 8: n0, 9: c0}, {8: "so", 9: "so"})
        r += 1
        V.dong(ws, r, "ps", {4: "Phát sinh trong kỳ"})
        r += 1
        sn = sc = 0
        du = d0
        for d, ben in dong.get(m, []):
            x = {1: d.ngay_gs, 2: d.sh, 3: d.ngay, 4: d.dg}
            if ben == "N":
                x.update({5: S.doi_ung_no(d), 6: d.tien})
                sn += d.tien
                du += d.tien
            else:
                x.update({5: S.doi_ung_co(d), 7: d.tien})
                sc += d.tien
                du -= d.tien
            a, b = _du(du)
            x.update({8: a, 9: b})
            V.dong(ws, r, "dl", x, vai)
            r += 1
        V.dong(ws, r, "cong", {4: "Cộng phát sinh", 6: sn, 7: sc}, {6: "so", 7: "so"}, them={6: {"dam": True}, 7: {"dam": True}})
        r += 1
        n1, c1 = _du(d0 + sn - sc)
        V.dong(ws, r, "cuoi_ky", {4: "Số dư cuối kỳ", 8: n1, 9: c1}, {8: "so", 9: "so"})
        V.cuoi(ws, r + 2, S.thay())
        KT.them("TK %s: phát sinh Nợ" % S.sh(m), sn, pn)
        KT.them("TK %s: phát sinh Có" % S.sh(m), sc, pc)
        KT.them("TK %s: số dư cuối" % S.sh(m), d0 + sn - sc, S.du_cuoi(m))
    return V, KT.canh_bao()


# ============================================================ 4. SO QUY TIEN MAT / 5. TIEN GUI NGAN HANG
def _so_phieu(d):
    return d.thuchi or d.sh


def lap_quytm(S):
    V, KT = Ve(S, "SS_QUYTM"), Kiem("SS_QUYTM")
    las = [m for m in S.la if S.sh(S.top(m)) == "111" or (S.sh(m).startswith("111") and S.top(m) == m)]
    vai = {1: "ngay", 2: "ngay", 3: "giua", 4: "giua", 5: "traix", 6: "so", 7: "so", 8: "so", 9: "trai"}
    cb = []
    tong_cuoi = 0.0
    co_sheet = False
    for m in sorted(las, key=lambda x: (S.sh(x), x)):
        d0 = S.du_dau(m)
        pn, pc = S.ps_ky(m)
        phieu = OrderedDict()
        for d in S.ct:
            if d.no == m:
                phieu.setdefault((d.mact, "T"), []).append(d)
            if d.co == m:
                phieu.setdefault((d.mact, "C"), []).append(d)
        if abs(d0) < 0.5 and not phieu:
            continue
        co_sheet = True
        ws = V.sheet(S.sh(m))
        r = V.dau(ws, 1, S.thay(TEN_TK=S.ten_tk(m), SO_HIEU_TK=S.sh(m)))
        ws.in_trang(ngang=False, lap_dong=(11, 13))
        V.dong(ws, r, "dau_ky", {5: "Tồn đầu kỳ", 8: d0}, {5: "giua", 8: "so"})
        r += 1
        ton, st, sc = d0, 0, 0
        for (mact, ben), ds in phieu.items():
            d = ds[0]
            tien = sum(x.tien for x in ds)
            x = {1: d.ngay_gs, 2: d.ngay, 5: d.dg}
            if ben == "T":
                ton += tien
                st += tien
                x.update({3: _so_phieu(d), 6: tien})
            else:
                ton -= tien
                sc += tien
                x.update({4: _so_phieu(d), 7: tien})
            x[8] = ton
            V.dong(ws, r, "dl", x, vai)
            r += 1
        V.dong(ws, r, "cong", {5: "Cộng phát sinh", 6: st, 7: sc}, {5: "giua", 6: "so", 7: "so"})
        r += 1
        V.dong(ws, r, "cuoi_ky", {5: "Số dư cuối kỳ", 8: d0 + st - sc}, {5: "giua", 8: "so"})
        V.cuoi(ws, r + 2, S.thay())
        if d0 + st - sc < -0.5:
            cb.append("TK %s: tồn quỹ cuối kỳ âm %s" % (S.sh(m), dd(d0 + st - sc)))
        KT.them("TK %s: tổng thu = phát sinh Nợ" % S.sh(m), st, pn)
        KT.them("TK %s: tổng chi = phát sinh Có" % S.sh(m), sc, pc)
        tong_cuoi += d0 + st - sc
    if not co_sheet:
        ws = V.sheet("111")
        r = V.dau(ws, 1, S.thay(TEN_TK="Tiền mặt", SO_HIEU_TK="111"))
        V.dong(ws, r, "dau_ky", {5: "Tồn đầu kỳ"})
        V.cuoi(ws, r + 2, S.thay())
        cb.append("Sổ không có tài khoản tiền mặt (111) có số dư / phát sinh trong kỳ")
    KT.them("Tồn quỹ cuối kỳ = số dư TK 111", tong_cuoi, sum(S.du_cuoi(m) for m in las))
    return V, cb + KT.canh_bao()


def lap_tgnh(S):
    V, KT = Ve(S, "SS_TGNH"), Kiem("SS_TGNH")
    las = [m for m in S.la if S.sh(S.top(m)) == "112" or (S.sh(m).startswith("112") and S.top(m) == m)]
    nh = {}
    for r in S.ss.get("tk_nh") or []:
        nh.setdefault(str(r[0] or "").strip(), r)
    vai = {1: "ngay", 2: "giua", 3: "ngay", 4: "traix", 5: "giua", 6: "so", 7: "so", 8: "so", 9: "trai"}
    cb = []
    tong_cuoi = 0.0
    co_sheet = False
    ten_sheet = set()
    for m in sorted(las, key=lambda x: (S.sh(x), x)):
        d0 = S.du_dau(m)
        pn, pc = S.ps_ky(m)
        ds = [d for d in S.ct if d.no == m or d.co == m]
        if abs(d0) < 0.5 and not ds:
            continue
        co_sheet = True
        ten = S.sh(m)
        if ten in ten_sheet:
            ten = "%s_%d" % (ten, m)
        ten_sheet.add(ten)
        x = nh.get(S.sh(m))
        ngan_hang = (x[2] if x and x[2] else "") or S.ten_tk(m)
        ws = V.sheet(ten)
        r = V.dau(ws, 1, S.thay(TEN_TK=S.ten_tk(m), SO_HIEU_TK=S.sh(m), NGAN_HANG=ngan_hang, SO_TK_NH=(x[1] if x else "")))
        ws.in_trang(ngang=False, lap_dong=(9, 11))
        V.dong(ws, r, "dau_ky", {4: "Số tồn đầu kỳ", 8: d0}, {8: "so"})
        r += 1
        V.dong(ws, r, "ps", {4: "Phát sinh trong kỳ"})
        r += 1
        con, st, sc = d0, 0, 0
        for d in ds:
            for ben in ("N", "C"):
                if (ben == "N" and d.no != m) or (ben == "C" and d.co != m):
                    continue
                y = {1: d.ngay_gs, 2: d.sh, 3: d.ngay, 4: d.dg}
                if ben == "N":
                    con += d.tien
                    st += d.tien
                    y.update({5: S.doi_ung_no(d), 6: d.tien})
                else:
                    con -= d.tien
                    sc += d.tien
                    y.update({5: S.doi_ung_co(d), 7: d.tien})
                y[8] = con
                V.dong(ws, r, "dl", y, vai)
                r += 1
        V.dong(ws, r, "cong", {4: "Cộng phát sinh", 6: st, 7: sc}, {6: "so", 7: "so"})
        r += 1
        V.dong(ws, r, "cuoi_ky", {4: "Số dư cuối kỳ", 8: d0 + st - sc}, {8: "so"})
        V.cuoi(ws, r + 2, S.thay())
        KT.them("TK %s: tổng thu = phát sinh Nợ" % S.sh(m), st, pn)
        KT.them("TK %s: tổng chi = phát sinh Có" % S.sh(m), sc, pc)
        tong_cuoi += d0 + st - sc
    if not co_sheet:
        ws = V.sheet("112")
        r = V.dau(ws, 1, S.thay(TEN_TK="Tiền gửi ngân hàng", SO_HIEU_TK="112"))
        V.dong(ws, r, "dau_ky", {4: "Số tồn đầu kỳ"})
        V.cuoi(ws, r + 2, S.thay())
        cb.append("Sổ không có tài khoản tiền gửi (112) có số dư / phát sinh trong kỳ")
    KT.them("Tiền gửi cuối kỳ = số dư TK 112", tong_cuoi, sum(S.du_cuoi(m) for m in las))
    return V, cb + KT.canh_bao()


# ============================================================ 6-7. TONG HOP CONG NO 131 / 331
def _cong_no(S, tk_id):
    """-> {(TK chi tiet, kh): [du dau (No-Co), ps No, ps Co]} tu kh_dau / kh_no / kh_co (TK_ID 3500 / 3310) - tach theo
    TUNG TK chi tiet va doi tuong nhu F01 (bao_cao_nam._f01) de hai ben No / Co khop bang can doi tai khoan."""
    tien_to = "131" if tk_id == K.TKCN_KH else "331"
    las = {m for m in S.la if S.tk[m].get("id") == tk_id and S.sh(m).startswith(tien_to)}
    if not las:                  # so khong dat so hieu chuan: moi TK cong no cung TK_ID
        las = {m for m in S.la if S.tk[m].get("id") == tk_id}
    g = defaultdict(lambda: [0.0, 0.0, 0.0])
    for r in S.dl.get("kh_dau") or []:
        m, kh = int(_so(r[0])), int(_so(r[1]))
        if m in las:
            g[(m, kh)][0] += _so(r[2]) - _so(r[3])
    for ten, ben in (("kh_no", 1), ("kh_co", 2)):
        for r in S.dl.get(ten) or []:
            m, kh, t, v = int(_so(r[0])), int(_so(r[1])), K.thang_tc(r[2], S.dau_ky), _so(r[3])
            if m not in las or t > S.t2:
                continue
            x = g[(m, kh)]
            if t < S.t1:
                x[0] += v if ben == 1 else -v
            else:
                x[ben] += v
    return las, g


def _f01_bcn(S, sh):
    """dong F01 cua bao_cao_nam (nhom B1) cho TK sh -> (dau_no, dau_co, ps_no, ps_co, cuoi_no, cuoi_co) | None"""
    try:
        bcn = importlib.import_module("bao_cao_nam")
        f = bcn.f01_dict(bcn.gia_tri_bctc(S.dl)["F01"])
        return f.get(sh)
    except Exception:
        return None


def _lap_th(S, ma, tk_id, ten_so):
    V, KT = Ve(S, ma), Kiem(ma)
    las, g = _cong_no(S, tk_id)
    ws = V.sheet(ten_so)
    r = V.dau(ws, 1, S.thay())
    sp = V.sp
    ws.in_trang(ngang=False, lap_dong=(sp["so_dong_dau"] - 1, sp["so_dong_dau"]))
    vai = {1: "trai", 2: "traix", 3: "so", 4: "so", 5: "so", 6: "so", 7: "so", 8: "so", 9: "giua"}
    tong = [0] * 6
    ds = []
    for (m, kh), (d0, pn, pc) in g.items():
        # lam tron dong tung doi tuong truoc khi tach No / Co (nhu F01) - tong = cong cac dong da lam tron
        d1 = lam_tron(d0 + pn - pc)
        d0, pn, pc = lam_tron(d0), lam_tron(pn), lam_tron(pc)
        if not (d0 or pn or pc or d1):
            continue
        dt = S.dt.get(kh)
        ds.append(((dt[0] if dt else "") or "", kh, m, d0, pn, pc, d1, dt))
    ds.sort(key=lambda x: (S.sh(x[2]), x[0], x[1]))
    for sh_dt, kh, m, d0, pn, pc, d1, dt in ds:
        v = [max(d0, 0), max(-d0, 0), pn, pc, max(d1, 0), max(-d1, 0)]
        ten = S.ten_dt(kh) or ("(chưa gán đối tượng)" if kh == 0 else (
            "Đối tượng mã số %d (không có trong danh mục)" % kh if not dt else "(đối tượng %s chưa có tên)" % sh_dt))
        V.dong(ws, r, "dl", {1: sh_dt, 2: ten, 3: v[0] or None, 4: v[1] or None, 5: v[2] or None, 6: v[3] or None,
                             7: v[4] or None, 8: v[5] or None, 9: S.sh(m)}, vai)
        for i in range(6):
            tong[i] += v[i]
        r += 1
    V.dong(ws, r, "tong", {2: "Tổng cộng", 3: tong[0], 4: tong[1], 5: tong[2], 6: tong[3], 7: tong[4], 8: tong[5]},
           {3: "so", 4: "so", 5: "so", 6: "so", 7: "so", 8: "so"})
    V.cuoi(ws, r + 2, S.thay())
    cb = []
    if not las:
        cb.append("Hệ thống tài khoản không có TK công nợ theo đối tượng (TK_ID %d)" % tk_id)
    d_tk0 = sum(S.du_dau(m) for m in las)
    pn_tk = sum(S.ps_ky(m)[0] for m in las)
    pc_tk = sum(S.ps_ky(m)[1] for m in las)
    KT.them("Dư đầu kỳ (Nợ - Có) theo đối tượng = số dư TK", tong[0] - tong[1], d_tk0)
    KT.them("Phát sinh Nợ theo đối tượng = phát sinh TK", tong[2], pn_tk)
    KT.them("Phát sinh Có theo đối tượng = phát sinh TK", tong[3], pc_tk)
    KT.them("Dư cuối kỳ (Nợ - Có) theo đối tượng = số dư TK", tong[4] - tong[5], sum(S.du_cuoi(m) for m in las))
    top = sorted({S.sh(S.top(m)) for m in las})
    if len(top) == 1:
        f = _f01_bcn(S, top[0])
        if f is not None:
            for i, ten in ((0, "Dư Nợ đầu kỳ"), (1, "Dư Có đầu kỳ"), (4, "Dư Nợ cuối kỳ"), (5, "Dư Có cuối kỳ")):
                KT.them("%s = F01 dòng TK %s (bảng cân đối tài khoản)" % (ten, top[0]), tong[i], f[i])
    return V, cb + KT.canh_bao()


def lap_th131(S):
    return _lap_th(S, "SS_TH131", K.TKCN_KH, "TK 131")


def lap_th331(S):
    return _lap_th(S, "SS_TH331", K.TKCN_PT, "TK 331")


# ============================================================ 8. TAM TINH THUE TNDN THEO QUY (GD221 cot ky truoc / luy ke; GD222 o nhap + cong thuc; GD223 IX = da nop thuc te + de xuat; GD225 ky truoc = nop trong quy, cot I luy ke; GD226 o nhap II.B IV V)
_TNDN_511 = [("5111", "Doanh thu bán hàng hóa"), ("5112", "Doanh thu bán thành phẩm"), ("5113", "Doanh thu cung cấp dịch vụ"),
             ("5118", "Doanh thu khác")]


def lap_tttndn(S):
    V, KT = Ve(S, "SS_TTTNDN"), Kiem("SS_TTTNDN")
    cb = []
    tn = S.dl.get("tndn") or {}                 # phan 03/TNDN cua ModHDDTBaoCaoNam: thue suat ke toan da chon khi xuat
    ts_chon = int(_so(tn.get("thue_suat"))) if str(tn.get("thue_suat", "")).strip() not in ("", "0") else 0
    dtt = S.ss.get("dt_nam_truoc")
    if dtt is None:
        dtt = tn.get("dt_nam_truoc") or (S.dl.get("dt_nam_truoc") or {}).get("so")
    if ts_chon in (15, 17, 20) and str(tn.get("huy", "0")) not in ("1", "True", "true"):
        ts, ly_do = ts_chon, "thuế suất kế toán đã chọn khi xuất (hộp chọn thuế suất 03/TNDN)"
    elif S.nam < 2026:
        ts, ly_do = 20, "thuế suất phổ thông năm %d" % S.nam
    else:
        ts, ly_do = K.thue_suat_goi_y(_so(dtt) if dtt not in (None, "") else None)
        if ts is None:
            ts, ly_do = 20, "Chưa có tổng doanh thu năm trước - tạm dùng thuế suất phổ thông 20%"
            cb.append(ly_do)
        else:
            ly_do = "gợi ý theo Luật Thuế TNDN 2025 - " + ly_do[:1].lower() + ly_do[1:]

    def ps_q(tt, th):
        """(No, Co) cac TK la bat dau tt trong cac thang th - BO chung tu ket chuyen (911)"""
        n = c = 0.0
        for m in S.la_theo(tt):
            p = S.ps.get(m)
            if not p:
                continue
            for t in th:
                x = p["thang"].get(t)
                if x:
                    n += x[0]
                    c += x[1]
        return lam_tron(n), lam_tron(c)
    quy = []
    for q in range(4):
        th = [t for t in range(q * 3 + 1, q * 3 + 4) if S.t1 <= t <= S.t2]
        if th:
            quy.append((q + 1, th))
    so_la_ma = {1: "I", 2: "II", 3: "III", 4: "IV"}
    sp = V.sp
    body = {(x[0], x[1]): x for x in sp["dau"]}
    # GD221: ty le tam nop moi quy (mac dinh 80%) - tong 4 quy khong thap hon 80% so quyet toan; lam tron den nghin dong
    tl = _so(S.ss.get("ty_le_tam_nop") or tn.get("ty_le_tam_nop") or 80)
    tl = tl / 100.0 if tl > 1 else tl
    if not (0 < tl <= 1):
        tl = 0.8

    # GD222: so chu so 0 lam tron so tam nop (6 = tron trieu dong) - nguoi dung sua o C41 tren Excel, cong thuc tu tinh lai
    so_le = int(_so(S.ss.get("lam_tron_tam_nop") or tn.get("lam_tron_tam_nop") or 6))
    so_le = max(0, min(9, so_le))

    def nghin(x):
        return int(lam_tron(x / 10.0 ** so_le)) * 10 ** so_le

    def nhom_dt(th):
        """dong doanh thu 511 co so trong cac thang th: [(tt, ten, no, co)] (511 khong chia 5111..5118 -> dong '511')"""
        n511 = c511 = 0
        ds = []
        for tt, ten in _TNDN_511:
            n, c = ps_q(tt, th)
            if n or c:
                ds.append((tt, ten, n, c))
            n511 += n
            c511 += c
        n_k, c_k = ps_q("511", th)
        if abs(n_k - n511) > 0.5 or abs(c_k - c511) > 0.5:
            ds.append(("511", "Doanh thu (TK 511 không chi tiết)", n_k - n511, c_k - c511))
            n511, c511 = n_k, c_k
        return ds, n511, c511

    def co_nhom(tts, th):
        """tong phat sinh Co cua nhom dong doanh thu tts (ma '511' = phan TK 511 khong chia chi tiet)"""
        ds, _, _ = nhom_dt(th)
        return sum(x[3] for x in ds if x[0] in tts)

    def tinh(th):
        """so lieu mot khoang thang th -> {dong: gia tri} theo mau (dong 12..38)"""
        g = {}
        if not th:
            return g
        ds, n511, c511 = nhom_dt(th)
        n515, c515 = ps_q("515", th)
        n711, c711 = ps_q("711", th)
        g[13], g[16] = c511, n511
        if S.cp99:                                     # GD227: so TT99 - giam tru doanh thu ghi No 521 (them vao phan No 511 neu co)
            n521, c521 = ps_q("521", th)
            g[16] = n511 + n521 - c521
        g[21], g[22] = c515 - n515, c711 - n711
        g[20] = g[21] + g[22]
        g[12] = g[13] - g[16] + g[20]
        cp = 0
        # GD227: so TT99 - chi phi ban hang 641, chi phi quan ly 642 (6421.. la yeu to cua 642, khong phai ban hang)
        for rr, tt in ((25, "632"), (26, "635"), (27, "641" if S.cp99 else "6421"), (28, "642" if S.cp99 else "6422"), (29, "811")):
            n, c = ps_q(tt, th)
            if tt in ("6421", "6422") and not S.la_theo("6421") and not S.la_theo("6422"):
                if tt == "6422":
                    n, c = ps_q("642", th)
                else:
                    n = c = 0
            g[rr] = n - c
            cp += n - c
        g[24], g[30] = cp, 0
        g[23] = cp
        g[33] = g[12] - g[23]
        g[34] = g[35] = 0
        g[36] = g[33]
        g[38] = lam_tron(max(g[36], 0) * ts / 100.0)
        return g

    quy_co = {q: th for q, th in quy}
    tong_quy = []          # GD121: (quy, doanh thu + thu nhap khac, chi phi, loi nhuan, thue quy) -> sheet "Luy ke nam"
    lk_nop_truoc = 0       # luy ke so tam nop cac quy truoc (theo ty le, lam tron nghin)
    lk_ln_truoc = 0
    nop_ds = {}
    for q in range(1, 5):
        th_q = [t for t in range(q * 3 - 2, q * 3 + 1)]
        th_lk = list(range(1, q * 3 + 1))
        g_q = tinh(th_q)
        g_lk = tinh(th_lk)
        lk_ln = lk_ln_truoc + g_q[33]
        lk_thue = lam_tron(max(lk_ln, 0) * ts / 100.0)
        g_lk[38] = lk_thue                                   # thue luy ke tinh tren loi nhuan luy ke (lo quy truoc bu lai)
        lk_nop = max(lk_nop_truoc, nghin(lk_thue * tl))
        nop_q = lk_nop - lk_nop_truoc
        nop_ds[q] = nop_q
        if q > max(quy_co or [0]):
            break
        if q not in quy_co:
            lk_nop_truoc, lk_ln_truoc = lk_nop, lk_ln
            continue
        th = quy_co[q]
        g_t = tinh(th) if len(th) != 3 else g_q
        g_tr = tinh(list(range(q * 3 - 5, q * 3 - 2))) if q > 1 else {}
        nop_tr = nop_ds.get(q - 1, 0)
        ws = V.sheet("Quý %s" % so_la_ma[q])
        m1, y1 = S.thang_lich(th[0])
        m2, y2 = S.thang_lich(th[-1])
        ghi = "" if len(th) == 3 else " (tháng %02d - %02d)" % (m1, m2)
        V.dau(ws, 1, S.thay(QUY_NAM="QUÝ %s NĂM %d%s" % (so_la_ma[q], S.nam, ghi.upper())))
        ws.in_trang(ngang=False)
        khung = {"trai": "mong", "phai": "mong", "tren": "mong", "duoi": "mong"}
        kso = V.kieu("k0", so=F_TIEN, can="phai", co=12, khung=khung)
        ksod = V.kieu("k0", so=F_TIEN, can="phai", co=12, dam=True, khung=khung)
        ktd = V.kieu("k0", dam=True, co=11, can="giua", xuong=True, khung=khung)
        kgiua = V.kieu("k0", can="giua", co=11, khung=khung)
        # tieu de cot: D = ky truoc, E = luy ke tu dau nam, F = ky nay (so dung cho cac dong IX, X va phe duyet)
        ws.o(10, 4, "Số liệu đối chiếu", ktd)
        ws.o(11, 4, "Kỳ trước" + (" (Quý %s)" % so_la_ma[q - 1] if q > 1 else ""), ktd)
        ws.o(11, 5, "Lũy kế từ đầu năm", ktd)
        ws.o(10, 6, "Kỳ này (Quý %s)" % so_la_ma[q], ktd)
        ws.cao(11, 33)
        # ten dong doanh thu (dong 14, 15) theo nhom TK 511 co so trong ky nay
        ds, _, _ = nhom_dt(th)
        if not ds:
            ds = [("5111", "Doanh thu bán hàng hóa", 0, 0), ("5113", "Doanh thu cung cấp dịch vụ", 0, 0)]
        nhom = {14: [ds[0]]}
        if len(ds) >= 2:
            nhom[15] = ds[1:]
        for rr, xs in nhom.items():
            tts = [x[0] for x in xs]
            ws.o(rr, 2, " + ".join(x[1] for x in xs) + " ", V.kieu(body[(rr, 2)][3]) if (rr, 2) in body else None)
            ws.o(rr, 3, " ".join(tts), kgiua)
            ws.o(rr, 4, co_nhom(tts, list(range(q * 3 - 5, q * 3 - 2))) if q > 1 else None, kso)
            ws.o(rr, 5, co_nhom(tts, th_lk), kso)
            ws.o(rr, 6, co_nhom(tts, th), kso)
        if 15 not in nhom:
            for c in (4, 5, 6):
                ws.o(15, c, None, kso)
        if S.cp99:                                           # GD227: so TT99
            ws.o(27, 3, 641, kgiua)
            ws.o(28, 3, 642, kgiua)
        elif not S.la_theo("6421") and not S.la_theo("6422"):
            ws.o(28, 3, 642, kgiua)
        dam = {12, 13, 16, 20, 23, 24, 30, 33, 36, 38}
        for rr in (12, 13, 16, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 33, 34, 35, 36, 38):
            k = ksod if rr in dam else kso
            ws.o(rr, 4, g_tr.get(rr) if q > 1 else None, k)
            ws.o(rr, 5, g_lk.get(rr), k)
            ws.o(rr, 6, g_t.get(rr), k)
        for rr in (17, 18, 19):
            for c in (4, 5, 6):
                ws.o(rr, c, None, kso)
        kts = V.kieu("k0", so="0%", can="phai", dam=True, co=12, khung=khung)
        for c in (4, 5, 6):
            ws.o(37, c, ts / 100.0 if (c != 4 or q > 1) else None, kts)
        # GD226: II.B / IV / V nhap o cot Ky nay (nen vang); II, III, VI, VIII = cong thuc ca 3 cot
        kvang = V.kieu("k0", so=F_TIEN, can="phai", co=12, nen="FFF2CC", khung=khung)
        truoc226 = ("'Quý %s'!" % so_la_ma[q - 1]) if (q - 1) in quy_co else ""
        for rr in (30, 34, 35):
            ws.o(rr, 6, 0, kvang)
            ws.o(rr, 5, _CT((truoc226 + "E%d+F%d" % (rr, rr)) if truoc226 else "F%d" % rr, g_lk.get(rr, 0)), ksod if rr == 30 else kso)
            if q > 1 and truoc226:
                ws.o(rr, 4, _CT(truoc226 + "F%d" % rr, 0), ksod if rr == 30 else kso)
        cot226 = [("E", 5, g_lk), ("F", 6, g_t)] + ([("D", 4, g_tr)] if (q > 1 and truoc226) else [])
        for L, c, g in cot226:
            ws.o(23, c, _CT("%s24-%s30" % (L, L), g.get(23)), ksod)
            ws.o(33, c, _CT("%s12-%s23" % (L, L), g.get(33)), ksod)
            ws.o(36, c, _CT("%s33-%s34-%s35" % (L, L, L), g.get(36)), ksod)
            ws.o(38, c, _CT("ROUND(MAX(%s36,0)*%s37,0)" % (L, L), g.get(38)), ksod)
        # IX. tam nop trong ky ; X. con phai nop khi quyet toan
        kten = V.kieu(body[(38, 2)][3]) if (38, 2) in body else ktd
        kla = V.kieu(body[(38, 1)][3]) if (38, 1) in body else kgiua
        ws.o(39, 1, "IX", kla)
        # GD223: Ky truoc / Luy ke = so DA NOP thuc te (No TK 3334 trong ky, tru du Co dau nam = thue nam truoc con no);
        #        Ky nay = so DE XUAT tam nop = thue luy ke x ty le (C39), lam tron (C41), tru so da nop luy ke
        def thuc_lk(den):
            if den < 1:
                return 0
            n_3334 = ps_q("3334", list(range(1, den + 1)))[0]
            du_co = sum(S.tk[m]["dc0"] - S.tk[m]["dn0"] for m in S.la_theo("3334"))
            return max(0, lam_tron(n_3334 - du_co))
        da_nop = thuc_lk(q * 3)
        # GD225: Ky truoc = so da nop TRONG quy nay (tam nop cua quy truoc nop o thang dau quy nay; quy I = phan vuot thue nam truoc)
        nop_quy_truoc = thuc_lk(q * 3) - thuc_lk((q - 1) * 3)
        if not hasattr(V, "_nop_quy"):
            V._nop_quy = {}
        V._nop_quy[q] = nop_quy_truoc
        de_xuat = max(0, nghin(lk_thue * tl) - da_nop)
        kten2 = V.kieu(body[(38, 2)][3], xuong=True) if (38, 2) in body else ktd
        ws.o(39, 2, "THUẾ TNDN TẠM NỘP (kỳ trước: số đã nộp trong quý này cho quý trước; lũy kế: đã nộp từ đầu năm - Nợ TK 3334; kỳ này: số đề xuất)", kten2)
        knhap = V.kieu("k0", so="0%", can="giua", dam=True, co=11, nen="FFF2CC", khung=khung)
        ws.o(39, 3, tl, knhap)
        ws.o(39, 4, nop_quy_truoc, ksod)
        ws.o(39, 5, da_nop, ksod)
        ws.o(39, 6, _CT("MAX(0,ROUND(MAX(E38,0)*C39,-C41)-E39)", de_xuat), ksod)
        ws.o(40, 1, "X", kla)
        ws.o(40, 2, "THUẾ TNDN CÒN PHẢI NỘP KHI QUYẾT TOÁN (X = VIII lũy kế - đã nộp - đề xuất kỳ này)", kten2)
        ws.o(40, 3, None, kgiua)
        ws.o(40, 4, None, ksod)
        ws.o(40, 5, _CT("MAX(0,E38-E39-F39)", max(0, lk_thue - da_nop - de_xuat)), ksod)
        ws.o(40, 6, None, ksod)
        ws.o(41, 2, "Làm tròn số đề xuất: số chữ số 0 cuối (6 = tròn triệu, 3 = tròn nghìn, 0 = không làm tròn)",
             V.kieu("k0", nghieng=True, co=10, can="trai", xuong=True))
        ws.o(41, 3, so_le, V.kieu("k0", so="0", can="giua", dam=True, co=11, nen="FFF2CC", khung=khung))
        ws.cao(41, 30)
        ws.to_mau(39, 3, 39, 3, "C39<0.8", dam=True)
        ws.to_mau(39, 6, 39, 6, "E39+F39<MAX(E38,0)*0.8", dam=True)
        ws.cao(39, 66)
        ws.cao(40, 50)
        tong_quy.append((q, g_t[12], g_t[23], g_t[33], g_t[38]))
        r = 43
        V.cuoi(ws, r, S.thay(QUY_TEXT="Quý %s" % so_la_ma[q], SO_TIEN=dd(de_xuat), CHU=so_thanh_chu(de_xuat)))
        # GD222: so tien + bang chu tren phe duyet = cong thuc theo o F39 (doi ty le / lam tron tren Excel la doi theo)
        kc = {(x[0], x[1]): x[3] for x in (V.sp.get("cuoi") or [])}
        ws.o(r + 1, 2, _CT('"Tạm nộp thuế TNDN Quý %s năm %d, số tiền là: "&FIXED(F39,0)&" đồng"' % (so_la_ma[q], S.nam),
                           "Tạm nộp thuế TNDN Quý %s năm %d, số tiền là: %s đồng" % (so_la_ma[q], S.nam, dd(de_xuat))), V.kieu(kc[(2, 2)]) if (2, 2) in kc else None)
        ws.o(r + 2, 1, _CT('"(Bằng chữ: "&' + _tttndn_chu("F39") + '&")"', "(Bằng chữ: %s)" % so_thanh_chu(de_xuat)),
             V.kieu(kc[(3, 1)]) if (3, 1) in kc else None)
        ghi_chu = ["Ghi chú: số TẠM TÍNH theo sổ (phát sinh trong quý, không gồm bút toán kết chuyển 911); thuế suất %d%%: %s. "
                   "Cột Lũy kế: từ tháng đầu năm tài chính đến hết quý này; thuế lũy kế tính trên lợi nhuận lũy kế (lỗ quý trước được bù vào lãi quý sau)." % (ts, ly_do),
                   "Dòng IX: Kỳ trước = số đã nộp trong quý này (tạm nộp của quý trước, hạn cuối tháng đầu quý này), Lũy kế = số đã nộp từ đầu năm đến hết quý này (phát sinh Nợ TK 3334, đã trừ thuế năm trước còn nợ đầu năm); "
                   "Kỳ này = số ĐỀ XUẤT tạm nộp = thuế lũy kế x tỷ lệ C39, làm tròn theo C41, trừ số đã nộp lũy kế. "
                   "Ô nhập (nền vàng): C39 tỷ lệ tạm nộp - luật cho phép tối thiểu 80%% số thuế quyết toán năm (tổng 4 quý); C41 số chữ số 0 làm tròn. "
                   "Dòng IX, X, số tiền và bằng chữ phần phê duyệt tự tính lại. Ô tô đỏ: tỷ lệ dưới 80%% hoặc làm tròn xuống làm lũy kế tạm nộp dưới 80%% "
                   "thuế lũy kế - nộp thiếu phần chênh lệch bị tính tiền chậm nộp từ sau hạn tạm nộp quý 4. Hạn nộp: ngày cuối tháng đầu quý sau.",
                   "Dòng II.B (chi phí không được trừ), IV (thu nhập miễn thuế), V (lỗ năm trước chuyển sang): nhập ở cột Kỳ này (nền vàng), "
                   "lũy kế cộng dồn từ sheet quý trước; các dòng II, III, VI, VIII, IX, X tự tính lại. Mặc định 0 - kế toán tự điều chỉnh "
                   "(dòng II.B, IV, V) trước khi nộp; số quyết toán năm lập trên tờ khai 03/TNDN."]
        for i, gc in enumerate(ghi_chu):
            V.ghi_chu(ws, r + 8 + i, 1, 6, gc)
        KT.them("Quý %s: doanh thu bán hàng (Có 511 trừ kết chuyển)" % so_la_ma[q], g_t[13], ps_q("511", th)[1])
        KT.them("Quý %s: lũy kế doanh thu = các quý cộng lại" % so_la_ma[q], g_lk[12], sum(tinh(list(range(k * 3 - 2, k * 3 + 1)))[12] for k in range(1, q + 1)))
        lk_nop_truoc, lk_ln_truoc = lk_nop, lk_ln
    if not quy:
        cb.append("Kỳ chọn không có tháng nào để tạm tính thuế TNDN")
    else:
        _tttndn_luy_ke(V, S, tong_quy, ts, ly_do, so_la_ma, tl, so_le)
        _tttndn_doc_so(V)
    return V, cb + KT.canh_bao()


def _tttndn_luy_ke(V, S, tong_quy, ts, ly_do, so_la_ma, tl=1.0, so_le=3):
    """GD121: sheet "Luy ke nam" - loi nhuan / thue tam tinh luy ke tu dau nam (lo quy truoc bu lai quy sau trong nam),
    so thue tam nop them tung quy, ghi chu quy dinh tam nop (khong con to khai tam tinh 01A/01B tu quy 4/2014)."""
    ws = V.wb.sheet("Lũy kế năm")
    for c, w in ((1, 9), (2, 18), (3, 18), (4, 18), (5, 18), (6, 16), (7, 18), (8, 18), (9, 18)):
        ws.rong(c, w)
    ws.in_trang(ngang=True)
    kt = V.kieu(None, dam=True, co=14, can="giua")
    kd = V.kieu(None, dam=True, co=11, can="giua", xuong=True, khung={"trai": "mong", "phai": "mong", "tren": "mong", "duoi": "mong"})
    kso = V.kieu(None, so=F_TIEN, can="phai", co=11, khung={"trai": "mong", "phai": "mong", "tren": "mong", "duoi": "mong"})
    ksod = V.kieu(None, so=F_TIEN, can="phai", co=11, dam=True, khung={"trai": "mong", "phai": "mong", "tren": "mong", "duoi": "mong"})
    kg = V.kieu(None, can="giua", co=11, khung={"trai": "mong", "phai": "mong", "tren": "mong", "duoi": "mong"})
    kn = V.kieu(None, nghieng=True, co=10, can="trai", doc="tren", xuong=True)
    ws.gop(1, 1, 1, 9, "TẠM TÍNH THUẾ THU NHẬP DOANH NGHIỆP LŨY KẾ NĂM %d" % S.nam, kt)
    ws.gop(2, 1, 2, 9, "Thuế suất %d%% - %s" % (ts, ly_do), V.kieu(None, nghieng=True, co=11, can="giua", xuong=True))
    ws.cao(2, 30)
    tieu = ["Quý", "Doanh thu và thu nhập khác (I)", "Chi phí (II)", "Lợi nhuận quý (III)", "Lợi nhuận lũy kế từ đầu năm",
            "Thuế tạm tính riêng quý", "Thuế tạm tính lũy kế từ đầu năm", "Số đề xuất tạm nộp của quý (dòng IX kỳ này)", "Đã nộp trong quý (Nợ TK 3334)"]
    for i, t in enumerate(tieu):
        ws.o(4, i + 1, t, kd)
    ws.cao(4, 45)
    r = 5
    lk_ln = 0
    lk_thue_truoc = 0
    tong = [0, 0, 0, 0, 0]
    nop_quy = getattr(V, "_nop_quy", {})          # GD225
    tong_nop = 0
    for q, I, II, III, thue in tong_quy:
        lk_ln += III
        lk_thue = lam_tron(max(lk_ln, 0) * ts / 100.0)
        lk_nop = max(lk_thue_truoc, int(lam_tron(lk_thue * tl / 10.0 ** so_le)) * 10 ** so_le)
        nop_them = lk_nop - lk_thue_truoc
        ws.o(r, 1, so_la_ma[q], kg)
        for c, v in ((2, I), (3, II), (4, III), (5, lk_ln), (6, thue), (7, lk_thue), (8, _CT("'Quý %s'!F39" % so_la_ma[q], nop_them))):
            ws.o(r, c, v, kso)
        ws.o(r, 9, _CT("'Quý %s'!D39" % so_la_ma[q], nop_quy.get(q, 0)), kso)
        tong_nop += nop_quy.get(q, 0)
        lk_thue_truoc = lk_nop
        tong = [tong[0] + I, tong[1] + II, tong[2] + III, tong[3] + thue, tong[4] + nop_them]
        r += 1
    ws.o(r, 1, "Cộng", kd)
    for c, v in ((2, tong[0]), (3, tong[1]), (4, tong[2]), (5, lk_ln), (6, tong[3]), (7, lam_tron(max(lk_ln, 0) * ts / 100.0)), (8, _CT("SUM(H5:H%d)" % (r - 1), tong[4])), (9, _CT("SUM(I5:I%d)" % (r - 1), tong_nop))):
        ws.o(r, c, v, ksod)
    r += 2
    ghi = ["Căn cứ: Luật Quản lý thuế 108/2025/QH15 và Nghị định 252/2026/NĐ-CP (Điều 24): doanh nghiệp KHÔNG nộp tờ khai thuế TNDN "
           "tạm tính quý (mẫu 01A/TNDN, 01B/TNDN đã bãi bỏ từ quý 4/2014 theo Thông tư 151/2014/TT-BTC), chỉ tạm nộp tiền thuế "
           "chậm nhất ngày cuối cùng của tháng đầu quý sau.",
           "Tổng số thuế đã tạm nộp của 4 quý không được thấp hơn 80% số thuế phải nộp theo quyết toán năm; nộp thiếu phần chênh lệch "
           "thì tính tiền chậm nộp từ ngày tiếp sau hạn tạm nộp quý 4.",
           "Số liệu lấy theo sổ (phát sinh trong quý, bỏ bút toán kết chuyển 911), chưa điều chỉnh chi phí không được trừ, thu nhập "
           "miễn thuế, lỗ các năm trước chuyển sang. Cột \"Số tạm nộp của quý\" = dòng IX sheet từng quý (thuế lũy kế x tỷ lệ ô C39, làm tròn theo ô C41, trừ số đã tạm nộp các quý trước) "
           "(lỗ quý trước được bù vào lãi quý sau trong cùng năm). Cột \"Đã nộp trong quý\" = phát sinh Nợ TK 3334 trong quý (quý I đã trừ thuế năm trước còn nợ) - đối chiếu giấy nộp tiền.",
           "Thuế suất theo Luật Thuế TNDN 67/2025/QH15: 20%; 15% nếu tổng doanh thu năm trước không quá 3 tỷ đồng; 17% nếu từ trên "
           "3 tỷ đến 50 tỷ đồng (không áp dụng cho doanh nghiệp có quan hệ liên kết mà bên liên kết không đủ điều kiện)." ]
    for g in ghi:
        ws.gop(r, 1, r, 9, g, kn)
        ws.cao(r, 32)
        r += 1
    V.ky_chung(ws, r + 1, (2, 5, 7))

def _tttndn_chu(o):
    """GD222: cong thuc Excel doc so tien o 'o' thanh chu (toi da nghin ty) - tra bang sheet an DocSo (0..999)."""
    rg = "DocSo!$A$1:$C$1000"
    dv = ["", " nghìn", " triệu", " tỷ", " nghìn tỷ"]
    ps = []
    for k in range(4, -1, -1):
        g = "MOD(INT(%s/1E%d),1000)" % (o, 3 * k)
        ps.append('IF(%s=0,"",VLOOKUP(%s,%s,IF(INT(%s/1E%d)=0,2,3),FALSE)&"%s ")' % (g, g, rg, o, 3 * k + 3, dv[k]))
    t = "TRIM(" + "&".join(ps) + ")"
    return 'IF(ROUND(%s,0)=0,"Không đồng",UPPER(LEFT(%s,1))&MID(%s,2,500)&" đồng")' % (o, t, t)


def _tttndn_doc_so(V):
    """GD222: sheet an DocSo: cot A so 0..999, B chu khi la nhom dau, C chu khi co nhom truoc ('không trăm linh ...')."""
    ws = V.wb.sheet("DocSo")
    ws._an_sheet = True
    for n in range(1000):
        ws.o(n + 1, 1, n)
        if n:
            ws.o(n + 1, 2, " ".join(_doc3(n, False)))
            ws.o(n + 1, 3, " ".join(_doc3(n, True)))




# ============================================================ 9-10. PHIEU THU / PHIEU CHI
def _phieu_tien(S):
    """-> (thu, chi): danh sach (mact, dong 111 ben No / ben Co, dong khac cung chung tu)"""
    t111 = {m for m in S.la if S.sh(S.top(m)) == "111" or S.sh(m).startswith("111")}
    thu, chi = OrderedDict(), OrderedDict()
    theo_ct = defaultdict(list)
    for d in S.ct:
        theo_ct[d.mact].append(d)
    for d in S.ct:
        if d.no in t111 and d.co not in t111:
            thu.setdefault(d.mact, []).append(d)
        if d.co in t111 and d.no not in t111:
            chi.setdefault(d.mact, []).append(d)
        if d.no in t111 and d.co in t111 and d.no != d.co:
            thu.setdefault(d.mact, []).append(d)
            chi.setdefault(d.mact, []).append(d)
    return t111, thu, chi, theo_ct


def _tk_tien(S, pairs):
    """[(ma, tien)] -> 'TK1, TK2' (so hieu TK khong trung)"""
    g = OrderedDict()
    for m, v in pairs:
        s = S.sh(m) if isinstance(m, int) else str(m)
        if s:
            g[s] = g.get(s, 0) + v
    return ", ".join(g)


def _lap_phieu_tien(S, ma, thu):
    V, KT = Ve(S, ma), Kiem(ma)
    t111, ds_thu, ds_chi, theo_ct = _phieu_tien(S)
    ds = ds_thu if thu else ds_chi
    sp = V.sp
    so_dong = sp["so_dong_dau"]
    cb = []
    tong = 0
    theo_thang = OrderedDict()
    for mact, lines in ds.items():
        theo_thang.setdefault(lines[0].t, []).append((mact, lines))
    tach = len(ds) > TOI_DA_PHIEU_SHEET
    ws = None
    r = 1
    for t, phs in theo_thang.items():
        if ws is None or tach:
            m, y = S.thang_lich(t)
            ws = V.sheet(("T%02d-%d" % (m, y)) if tach else ("Phiếu thu" if thu else "Phiếu chi"))
            ws.in_trang(ngang=sp.get("ngang", True))
            r = 1
        for mact, lines in phs:
            d = lines[0]
            tien = sum(x.tien for x in lines)
            tong += tien
            if thu:
                tk_no = _tk_tien(S, [(x.no, x.tien) for x in lines])
                doi = [(x.co if x.co else S.doi_ung_no(x), x.tien) for x in lines]
                tk_co = _tk_tien(S, doi)
                kh = next((x.khc for x in lines if x.khc), 0) or next((x.kh for x in lines if x.kh), 0)
            else:
                tk_co = _tk_tien(S, [(x.co, x.tien) for x in lines])
                doi = [(x.no if x.no else S.doi_ung_co(x), x.tien) for x in lines]
                tk_no = _tk_tien(S, doi)
                kh = next((x.kh for x in lines if x.kh), 0) or next((x.khc for x in lines if x.khc), 0)
            if not kh:
                kh = next((x.kh or x.khc for x in theo_ct.get(mact, []) if x.kh or x.khc), 0)
            nguoi = S.ten_dt(kh)
            ly_do = "; ".join(OrderedDict((x.dg, 1) for x in lines if x.dg).keys())
            ng = d.ngay or d.ngay_gs
            ngay_ct = ("Ngày %02d tháng %02d năm %d" % (ng.day, ng.month, ng.year)) if ng else ""
            th = S.thay(NGAY_CT=ngay_ct, SO=_so_phieu(d), TK_NO=tk_no, TK_CO=tk_co, NGUOI=nguoi, DC=S.dc_dt(kh),
                        LY_DO=ly_do, SO_TIEN="%s đồng" % dd(tien), CHU=so_thanh_chu(tien), CHU2="", KEM_THEO="............",
                        QUYEN="............")
            V._khoi(ws, r, sp["dau"], sp["gop_dau"], sp.get("cao_dau"), th)
            V._ten_ky(ws, r, sp["dau"], sp["gop_dau"], nguoi, sp.get("ky_ten", 20) - 17)
            r += so_dong
            ws.ngat_trang(r - 1)
            r += 1
    if not ds:
        ws = V.sheet("Phiếu thu" if thu else "Phiếu chi")
        ws.in_trang(ngang=sp.get("ngang", True))
        V._khoi(ws, 1, sp["dau"], sp["gop_dau"], sp.get("cao_dau"), S.thay(QUYEN="............", KEM_THEO="............"))
        cb.append("Kỳ này sổ không có chứng từ %s tiền mặt (TK 111) - tệp chỉ có mẫu trống" % ("thu" if thu else "chi"))
    else:
        cb.append("%d phiếu %s, mỗi phiếu một trang in" % (len(ds), "thu" if thu else "chi"))
    pn = sum(S.ps_ky(m)[0] for m in t111)
    pc = sum(S.ps_ky(m)[1] for m in t111)
    if thu:
        KT.them("Tổng tiền các phiếu thu = phát sinh Nợ TK 111", tong, pn)
    else:
        KT.them("Tổng tiền các phiếu chi = phát sinh Có TK 111", tong, pc)
    return V, cb + KT.canh_bao()


def lap_pthu(S):
    return _lap_phieu_tien(S, "SS_PTHU", True)


def lap_pchi(S):
    return _lap_phieu_tien(S, "SS_PCHI", False)


# ============================================================ kho
class Kho(object):
    """vat tu, ton kho (TonKho), dong nhap / xuat kho (dieu kien nhu InLuyKeN / TonKho cua phan mem)."""

    def __init__(self, S):
        ss = S.ss
        self.S = S
        self.vt = {int(_so(r[0])): [str(r[1] or ""), str(r[2] or ""), str(r[3] or ""), str(r[4] or "") if len(r) > 4 else ""]
                   for r in ss.get("vt") or []}
        self.ten_kho = {int(_so(r[0])): str(r[1] or "") for r in ss.get("kho") or []}
        nt = S.t2 - S.t1 + 1
        self.ton = defaultdict(lambda: [0.0] * (2 + 6 * nt))      # (tk, vt) -> [Ldk, Tdk, (Ln, Tn, Lx, Tx, L, T)*]
        self.tk_vt = defaultdict(set)
        self.tk_kho = set()
        for r in ss.get("tonkho") or []:
            tk, vt = int(_so(r[1])), int(_so(r[2]))
            x = self.ton[(tk, vt)]
            for i in range(min(len(x), len(r) - 3)):
                x[i] += _so(r[3 + i])
            self.tk_kho.add(tk)
            self.tk_vt[vt].add(tk)
        self.ck4 = defaultdict(lambda: [0.0, 0.0, 0.0])        # chuyen kho noi bo cung TK: [SL nhap, tien, SL xuat]
        for r in ss.get("ck4") or []:
            x = self.ck4[(int(_so(r[1])), int(_so(r[2])))]
            x[0] += _so(r[3])
            x[1] += _so(r[4])
            x[2] += _so(r[5]) if len(r) > 5 else _so(r[3])
        # TK vat tu = TK co TK_ID 1000 (nhu SAS.bas tinh TonKho); so cu khong danh dau TK_ID -> TK trong TonKho / 15x
        self.tk_vattu = {m for m, t in S.tk.items() if t.get("id") == TKVT_ID}
        if not self.tk_vattu:
            self.tk_vattu = set(self.tk_kho) | {m for m in S.la if S.sh(m)[:3] in TK_KHO and S.sh(m)[:3] != "154"}
        if not self.tk_kho:            # khong co TonKho: TK kho theo he thong TK
            self.tk_kho = {m for m in self.tk_vattu if m in S.la}
        self.nt = nt

    # dieu kien nhu SAS.bas (tinh TonKho): nhap = loai 1 / 13 / 4 ghi No TK vat tu; xuat = loai 2 / 4 ghi Co TK vat tu;
    #   co ma vat tu, co ma kho (loai 4: kho nhan = MaNguon, kho xuat = MaKho)
    def la_nhap(self, d):
        return d.vt > 0 and d.kho > 0 and d.no in self.tk_vattu and (d.loai in (1, 13) or (d.loai == 4 and d.no != d.co))

    def la_xuat(self, d):
        return d.vt > 0 and d.kho > 0 and d.co in self.tk_vattu and (d.loai == 2 or (d.loai == 4 and d.no != d.co))

    @staticmethod
    def kho_nhap(d):
        return d.nguon if d.loai == 4 and d.nguon else d.kho

    def ten_vt(self, vt):
        return self.vt.get(vt) or ["VT%d" % vt, "(vật tư mã số %d không có trong danh mục)" % vt, "", ""]

    def nxt(self, tk, vt):
        """-> (Ldk, Tdk, Ln, Tn, Lx, Tx, Lck, Tck) theo TonKho (tru chuyen kho noi bo nhu InLuyKe)"""
        x = self.ton.get((tk, vt))
        if not x:
            return None
        ln = tn = lx = tx = 0.0
        for i in range(self.nt):
            b = 2 + 6 * i
            ln += x[b]
            tn += x[b + 1]
            lx += x[b + 2]
            tx += x[b + 3]
        c = self.ck4.get((tk, vt))
        if c:                            # chuyen kho noi bo cung TK: TonKho ghi ca nhap lan xuat -> bo ca hai
            ln -= c[0]
            tn -= c[1]
            lx -= c[2]
            tx -= c[1]
        b = 2 + 6 * (self.nt - 1)
        return x[0], x[1], ln, tn, lx, tx, x[b + 4], x[b + 5]


def _kho(S):
    if getattr(S, "_kho", None) is None:
        S._kho = KH = Kho(S)
        if not S.ss.get("tonkho"):
            S.cb.append("JSON không có tồn kho (TonKho) - số tồn đầu / cuối kho không lập được")
        elif S.co_ct_day_du:
            # bang TonKho (phan mem tinh khi Kiem tra so lieu / tinh gia xuat) phai khop chung tu nhap / xuat tung thang
            ct_n, ct_x = defaultdict(float), defaultdict(float)
            for d in S.ct:
                if KH.la_nhap(d):
                    ct_n[d.t] += d.tien
                if KH.la_xuat(d):
                    ct_x[d.t] += d.tien
            lech = []
            for i, t in enumerate(range(S.t1, S.t2 + 1)):
                tn = sum(x[2 + 6 * i + 1] for x in KH.ton.values())
                tx = sum(x[2 + 6 * i + 3] for x in KH.ton.values())
                if not KH.ck4 and (abs(tn - ct_n[t]) > 0.5 or abs(tx - ct_x[t]) > 0.5):
                    m, y = S.thang_lich(t)
                    lech.append("tháng %02d/%d (nhập TonKho %s / chứng từ %s, xuất TonKho %s / chứng từ %s)"
                                % (m, y, dd(tn), dd(ct_n[t]), dd(tx), dd(ct_x[t])))
            if lech:
                S.cb.append("Bảng tồn kho của phần mềm (TonKho) CHƯA cập nhật theo chứng từ: %s - vào phần mềm chạy Kiểm tra số liệu / "
                            "Tính giá xuất kho rồi xuất lại; bảng N-X-T lấy số TonKho, sổ chi tiết / phiếu lấy số chứng từ nên sẽ lệch"
                            % "; ".join(lech[:6]))
    return S._kho


def _lap_phieu_kho(S, ma, nhap):
    V, KT = Ve(S, ma), Kiem(ma)
    KH = _kho(S)
    sp = V.sp
    ds = OrderedDict()
    for d in S.ct:
        if (nhap and KH.la_nhap(d)) or (not nhap and KH.la_xuat(d)):
            ds.setdefault(d.mact, []).append(d)
    theo_ct = defaultdict(list)
    for d in S.ct:
        theo_ct[d.mact].append(d)
    cb = []
    tach = len(ds) > TOI_DA_PHIEU_SHEET
    ws = None
    r = 1
    tong = 0
    theo_thang = OrderedDict()
    for mact, lines in ds.items():
        theo_thang.setdefault(lines[0].t, []).append((mact, lines))
    ten = "Phiếu nhập kho" if nhap else "Phiếu xuất kho"
    vai = {1: "giua", 2: "traix", 3: "giua", 4: "giua", 5: "sl", 6: "sl", 7: "dg", 8: "so"} if nhap else \
        {1: "giua", 2: "traix", 5: "giua", 6: "giua", 7: "sl", 8: "sl", 9: "dg", 10: "so"}
    for t, phs in theo_thang.items():
        if ws is None or tach:
            m, y = S.thang_lich(t)
            ws = V.sheet(("T%02d-%d" % (m, y)) if tach else ten)
            ws.in_trang(ngang=sp.get("ngang", True))
            r = 1
        for mact, lines in phs:
            d = lines[0]
            tien = sum(x.tien for x in lines)
            tong += tien
            if nhap:
                tk_no = _tk_tien(S, [(x.no, x.tien) for x in lines])
                tk_co = _tk_tien(S, [(x.co if x.co else S.doi_ung_no(x), x.tien) for x in lines])
                kh = next((x.khc for x in lines if x.khc), 0) or next((x.khc or x.kh for x in theo_ct.get(mact, []) if x.khc or x.kh), 0)
                kho = next((KH.kho_nhap(x) for x in lines if KH.kho_nhap(x)), 0)
            else:
                tk_co = _tk_tien(S, [(x.co, x.tien) for x in lines])
                tk_no = _tk_tien(S, [(x.no if x.no else S.doi_ung_co(x), x.tien) for x in lines])
                kh = next((x.kh for x in lines if x.kh), 0) or next((x.kh or x.khc for x in theo_ct.get(mact, []) if x.kh or x.khc), 0)
                kho = next((x.kho for x in lines if x.kho), 0)
            ng = d.ngay or d.ngay_gs
            ngay_ct = ("Ngày %02d tháng %02d năm %d" % (ng.day, ng.month, ng.year)) if ng else ""
            nguoi = S.ten_dt(kh)
            ly_do = "; ".join(OrderedDict((x.dg, 1) for x in lines if x.dg).keys())
            theo = "chứng từ số %s ngày %s%s" % (d.sh, ng.strftime("%d/%m/%Y") if ng else "", (" của " + nguoi) if nguoi else "")
            th = S.thay(NGAY_CT=ngay_ct, SO=d.sh, TK_NO=tk_no, TK_CO=tk_co, NGUOI=nguoi, DC=S.dc_dt(kh),
                        LY_DO=ly_do, THEO=theo, KHO=KH.ten_kho.get(kho, ""), DIA_DIEM="", CHU=so_thanh_chu(tien), KEM_THEO="............")
            r = V.dau(ws, r, th)
            for i, x in enumerate(lines, start=1):
                vt = KH.ten_vt(x.vt)
                sl = x.sl_no if nhap else x.sl_co
                dg = (x.tien / sl) if sl else None
                if nhap:
                    V.dong(ws, r, "dl", {1: i, 2: vt[1], 3: vt[0], 4: vt[2], 5: sl or None, 6: sl or None, 7: dg, 8: x.tien}, vai)
                else:
                    V.dong(ws, r, "dl", {1: i, 2: vt[1], 5: vt[0], 6: vt[2], 7: sl or None, 8: sl or None, 9: dg, 10: x.tien}, vai)
                r += 1
            if nhap:
                V.dong(ws, r, "tong", {3: "Cộng", 8: tien}, {8: "so"})
            else:
                V.dong(ws, r, "tong", {2: "Cộng", 10: tien}, {10: "so"})
            r += 1
            r = V.cuoi(ws, r, th, nguoi) + 1
            ws.ngat_trang(r - 1)
            r += 1
    if not ds:
        ws = V.sheet(ten)
        ws.in_trang(ngang=sp.get("ngang", True))
        r = V.dau(ws, 1, S.thay(KEM_THEO="............"))
        V.cuoi(ws, r + 1, S.thay(KEM_THEO="............"))
        cb.append("Kỳ này sổ không có chứng từ %s kho có vật tư - tệp chỉ có mẫu trống" % ("nhập" if nhap else "xuất"))
    else:
        cb.append("%d phiếu %s kho, mỗi phiếu một trang in" % (len(ds), "nhập" if nhap else "xuất"))
    # doi chieu voi TonKho (tong tien nhap / xuat trong ky)
    if KH.ton:
        tt = 0.0
        for (tk, vt) in KH.ton:
            x = KH.nxt(tk, vt)
            tt += x[3] if nhap else x[5]
        KT.them("Tổng tiền các phiếu %s = tiền %s trong bảng tồn kho (TonKho)" % ("nhập" if nhap else "xuất", "nhập" if nhap else "xuất"), tong, tt)
    return V, cb + KT.canh_bao()


def lap_pnk(S):
    return _lap_phieu_kho(S, "SS_PNK", True)


def lap_pxk(S):
    return _lap_phieu_kho(S, "SS_PXK", False)


# ============================================================ 13. BANG KE PHIEU NHAP - XUAT
def lap_bknx(S):
    V, KT = Ve(S, "SS_BKNX"), Kiem("SS_BKNX")
    KH = _kho(S)
    ws = V.sheet("Bảng kê N-X")
    r = V.dau(ws, 1, S.thay())
    ws.in_trang(ngang=True, lap_dong=(9, 11))
    vai = {1: "giua", 2: "ngay", 3: "traix", 4: "trai", 5: "traix", 6: "giua", 7: "sl", 8: "dg", 9: "so", 10: "sl", 11: "dg", 12: "so"}
    theo = OrderedDict()
    for d in S.ct:
        n, x = KH.la_nhap(d), KH.la_xuat(d)
        if n or x:
            theo.setdefault(d.t, []).append((d, n, x))
    tn = tx = 0
    for t, ds in theo.items():
        m, y = S.thang_lich(t)
        V.dong(ws, r, "thang", {3: "Tháng %02d năm %d" % (m, y)})
        r += 1
        sn = sx = 0
        for d, n, x in ds:
            vt = KH.ten_vt(d.vt)
            for ben in (("N",) if n else ()) + (("X",) if x else ()):
                g = {1: d.sh, 2: d.ngay, 3: d.dg, 4: vt[0], 5: vt[1], 6: vt[2]}
                if ben == "N":
                    g.update({7: d.sl_no or None, 8: (d.tien / d.sl_no) if d.sl_no else None, 9: d.tien})
                    sn += d.tien
                else:
                    g.update({10: d.sl_co or None, 11: (d.tien / d.sl_co) if d.sl_co else None, 12: d.tien})
                    sx += d.tien
                V.dong(ws, r, "dl", g, vai)
                r += 1
        V.dong(ws, r, "tong_thang", {3: "TỔNG CỘNG THÁNG %02d/%d" % (m, y), 9: sn, 12: sx}, {9: "so", 12: "so"},
               them={3: {"dam": True}, 9: {"dam": True}, 12: {"dam": True}})
        r += 1
        tn += sn
        tx += sx
    V.dong(ws, r, "tong_thang", {3: "TỔNG CỘNG", 9: tn, 12: tx}, {9: "so", 12: "so"}, them={3: {"dam": True}, 9: {"dam": True}, 12: {"dam": True}})
    V.cuoi(ws, r + 2, S.thay())
    cb = []
    if not theo:
        cb.append("Kỳ này sổ không có phiếu nhập / xuất kho có vật tư")
    if KH.ton:
        n0 = sum(KH.nxt(tk, vt)[3] for (tk, vt) in KH.ton)
        x0 = sum(KH.nxt(tk, vt)[5] for (tk, vt) in KH.ton)
        KT.them("Tổng tiền nhập = bảng tồn kho (TonKho)", tn, n0)
        KT.them("Tổng tiền xuất = bảng tồn kho (TonKho)", tx, x0)
    return V, cb + KT.canh_bao()


# ============================================================ 14. SO CHI TIET VAT TU / 15. TONG HOP N-X-T
def lap_sctvt(S):
    V, KT = Ve(S, "SS_SCTVT"), Kiem("SS_SCTVT")
    KH = _kho(S)
    dong = defaultdict(list)
    for d in S.ct:
        if KH.la_nhap(d):
            dong[(d.no, d.vt)].append((d, "N"))
        if KH.la_xuat(d):
            dong[(d.co, d.vt)].append((d, "X"))
    khoa = set(dong) | {k for k, x in KH.ton.items() if abs(x[0]) > 1e-9 or abs(x[1]) > 0.5}
    ds = sorted(khoa, key=lambda k: (S.sh(k[0]), KH.ten_vt(k[1])[0]))
    ws = V.sheet("Sổ chi tiết VT-HH")
    ws.in_trang(ngang=False)
    ml = V.wb.sheet("Danh sách")
    vai = {2: "giua", 3: "ngay", 4: "traix", 5: "sl", 6: "dg", 7: "so", 8: "sl", 9: "dg", 10: "so", 11: "sl", 12: "so"}
    r = 1
    muc = []
    lech = 0
    for (tk, vt) in ds:
        ten = KH.ten_vt(vt)
        x = KH.nxt(tk, vt)
        l0, t0 = (x[0], x[1]) if x else (0.0, 0.0)
        r_dau = r
        r = V.dau(ws, r, S.thay(MA_VT=ten[0], TEN_VT=ten[1], DVT=ten[2], SO_HIEU_TK=S.sh(tk), TEN_TK=S.ten_tk(tk)))
        # dong 'So ton dau ky' / 'Phat sinh trong ky' da nam trong phan dau cua mau -> ghi so vao
        ws.o(r - 2, 11, round(l0, 4) if l0 else None, V.kieu(V.sp["dong"]["dau_ky"]["kieu"]["11"], so=F_SL, can="phai"))
        ws.o(r - 2, 12, lam_tron(t0) if t0 else None, V.kieu(V.sp["dong"]["dau_ky"]["kieu"]["12"], so=F_TIEN, can="phai"))
        l, tt = l0, t0
        sn = sx = ln = lx = 0
        for d, ben in dong.get((tk, vt), []):
            g = {2: d.sh, 3: d.ngay, 4: d.dg}
            if ben == "N":
                l += d.sl_no
                tt += d.tien
                sn += d.tien
                ln += d.sl_no
                g.update({5: d.sl_no or None, 6: (d.tien / d.sl_no) if d.sl_no else None, 7: d.tien})
            else:
                l -= d.sl_co
                tt -= d.tien
                sx += d.tien
                lx += d.sl_co
                g.update({8: d.sl_co or None, 9: (d.tien / d.sl_co) if d.sl_co else None, 10: d.tien})
            g.update({11: round(l, 4), 12: tt})
            V.dong(ws, r, "dl", g, vai)
            r += 1
        V.dong(ws, r, "cong", {4: "Cộng phát sinh", 5: ln or None, 7: sn, 8: lx or None, 10: sx},
               {5: "sl", 7: "so", 8: "sl", 10: "so"}, them={5: {"dam": True}, 7: {"dam": True}, 8: {"dam": True}, 10: {"dam": True}})
        r += 1
        V.dong(ws, r, "cuoi_ky", {4: "Số dư cuối kỳ", 11: round(l, 4), 12: tt}, {11: "sl", 12: "so"},
               them={11: {"dam": True}, 12: {"dam": True}})
        r = V.cuoi(ws, r + 2, S.thay()) + 1
        ws.ngat_trang(r - 1)
        r += 1
        muc.append((S.sh(tk), ten[0], ten[1], ten[2], l0, t0, ln, sn, lx, sx, l, tt, r_dau))
        if x:
            if abs(tt - x[7]) > 0.5 or abs(l - x[6]) > 0.001:
                lech += 1
            KT.them("%s / %s: tồn cuối (tiền) = TonKho" % (S.sh(tk), ten[0]), tt, x[7])
    # danh sach (muc luc)
    th = S.thay()
    kd = V.kieu(None, dam=True, co=13, can="giua")
    kb = {"trai": "mong", "phai": "mong", "tren": "mong", "duoi": "mong"}
    kh_ = V.kieu(None, dam=True, co=11, can="giua", xuong=True, khung=kb)
    kt = V.kieu(None, co=11, khung=kb)
    ks = V.kieu(None, co=11, so=F_TIEN, can="phai", khung=kb)
    ksl = V.kieu(None, co=11, so=F_SL, can="phai", khung=kb)
    for c, w in enumerate([8, 14, 38, 8, 12, 15, 12, 15, 12, 15, 12, 15, 10], start=1):
        ml.rong(c, w)
    ml.o(1, 1, th["TEN_DV"], V.kieu(None, co=11))
    ml.gop(3, 1, 3, 13, "SỔ CHI TIẾT VẬT TƯ, HÀNG HÓA - DANH SÁCH MẶT HÀNG (%s)" % th["KY_THUONG"], kd)
    hd = ["TK", "Mã", "Tên vật tư, hàng hóa", "ĐVT", "SL đầu kỳ", "Tiền đầu kỳ", "SL nhập", "Tiền nhập", "SL xuất", "Tiền xuất",
          "SL cuối kỳ", "Tiền cuối kỳ", "Dòng (sheet sổ)"]
    for i, h in enumerate(hd, start=1):
        ml.o(5, i, h, kh_)
    rr = 6
    for x in muc:
        for i, v in enumerate(x, start=1):
            if i in (5, 7, 9, 11):
                ml.o(rr, i, round(v, 4) if v else None, ksl)
            elif i in (6, 8, 10, 12):
                ml.o(rr, i, lam_tron(v) if v else None, ks)
            else:
                ml.o(rr, i, v, kt)
        rr += 1
    ml.in_trang(ngang=True, lap_dong=(5, 5))
    V.wb.sheets.reverse()
    cb = []
    if not ds:
        cb.append("Kỳ này không có vật tư, hàng hóa có tồn / phát sinh")
    KT.them("Tổng tồn cuối các mặt hàng = tổng tồn kho (TonKho)", sum(x[11] for x in muc),
            sum(KH.nxt(tk, vt)[7] for (tk, vt) in KH.ton) if KH.ton else sum(x[11] for x in muc))
    return V, cb + KT.canh_bao()


def lap_thnxt(S):
    V, KT = Ve(S, "SS_THNXT"), Kiem("SS_THNXT")
    KH = _kho(S)
    ws = V.sheet("Tổng hợp N-X-T")
    r = V.dau(ws, 1, S.thay())
    ws.in_trang(ngang=True, lap_dong=(9, 11))
    vai = {2: "trai", 3: "traix", 4: "giua", 5: "sl", 6: "so", 7: "sl", 8: "so", 9: "dg", 10: "sl", 11: "so", 12: "sl", 13: "so"}
    theo_tk = defaultdict(list)
    for (tk, vt), x in KH.ton.items():
        v = KH.nxt(tk, vt)
        if all(abs(y) < 1e-9 for y in v):
            continue
        theo_tk[tk].append((KH.ten_vt(vt), v))
    tong = [0.0] * 8
    cb = []
    sai_dong = 0
    for tk in sorted(theo_tk, key=lambda m: S.sh(m)):
        V.dong(ws, r, "tong", {2: S.sh(tk), 3: S.ten_tk(tk)}, {2: "trai", 3: "trai"})
        r += 1
        st = [0.0] * 8
        for ten, v in sorted(theo_tk[tk], key=lambda x: x[0][0]):
            dgx = (v[5] / v[4]) if v[4] else None
            V.dong(ws, r, "dl", {2: ten[0], 3: ten[1], 4: ten[2], 5: v[0] or None, 6: v[1] or None, 7: v[2] or None, 8: v[3] or None,
                                 9: dgx, 10: v[4] or None, 11: v[5] or None, 12: v[6] or None, 13: v[7] or None}, vai)
            r += 1
            for i in range(8):
                st[i] += v[i]
            if abs(v[1] + v[3] - v[5] - v[7]) > 0.5:
                sai_dong += 1
        V.dong(ws, r, "tong", {3: "Cộng TK %s" % S.sh(tk), 6: st[1], 8: st[3], 11: st[5], 13: st[7]}, {6: "so", 8: "so", 11: "so", 13: "so"})
        r += 1
        for i in range(8):
            tong[i] += st[i]
        la = [m for m in S.la if m == tk]
        KT.them("TK %s: tồn cuối (tiền) = số dư TK" % S.sh(tk), st[7], sum(S.du_cuoi(m) for m in la))
        KT.them("TK %s: tồn đầu (tiền) = số dư đầu kỳ TK" % S.sh(tk), st[1], sum(S.du_dau(m) for m in la))
    V.dong(ws, r, "tong", {3: "Tổng cộng", 6: tong[1], 8: tong[3], 11: tong[5], 13: tong[7]}, {6: "so", 8: "so", 11: "so", 13: "so"})
    V.cuoi(ws, r + 2, S.thay())
    am = [(ten[0], v[6]) for tk in theo_tk for ten, v in theo_tk[tk] if v[6] < -1e-9 or v[7] < -0.5]
    if am:
        cb.append("Âm kho cuối kỳ %d mặt hàng (vd %s) - kiểm tra lại phiếu nhập / xuất trên phần mềm"
                  % (len(am), ", ".join("%s: %s" % (a, sl_txt(b)) for a, b in am[:5])))
    if sai_dong:
        cb.append("%d dòng tồn kho: đầu + nhập - xuất khác tồn cuối (bảng TonKho chưa tính lại giá) - chạy Tính giá xuất kho trên phần mềm" % sai_dong)
    if not theo_tk:
        cb.append("Kỳ này không có tồn / nhập / xuất kho (TonKho)")
    return V, cb + KT.canh_bao()


# ============================================================ 16. DANH MUC HANG HOA
def lap_dmhh(S):
    V = Ve(S, "SS_DMHH")
    KH = _kho(S)
    ws = V.sheet("DMHH")
    r = V.dau(ws, 1, S.thay())
    ws.in_trang(ngang=False, lap_dong=(6, 6))
    vai = {2: "giua", 3: "trai", 4: "traix", 5: "giua", 6: "giua"}
    for i, (ms, v) in enumerate(sorted(KH.vt.items(), key=lambda x: x[1][0]), start=1):
        tk = ", ".join(sorted(S.sh(t) for t in KH.tk_vt.get(ms, ()))) or v[3]
        V.dong(ws, r, "dl", {2: i, 3: v[0], 4: v[1], 5: v[2], 6: tk}, vai)
        r += 1
    cb = [] if KH.vt else ["Sổ chưa có danh mục vật tư, hàng hóa"]
    KIEM["SS_DMHH"] = [("Số mặt hàng trong danh mục", len(KH.vt), len(S.ss.get("vt") or []), True)]
    return V, cb


# ============================================================ 17. PHAN BO CHI PHI MUA HANG (TK 1562)
def lap_pbcpmh(S):
    V, KT = Ve(S, "SS_PBCPMH"), Kiem("SS_PBCPMH")
    KH = _kho(S)
    ws = V.sheet("PB CPMH")
    r = V.dau(ws, 1, S.thay())
    ws.in_trang(ngang=True, lap_dong=(10, 12))
    t1562 = {m for m in S.la if S.sh(m).startswith("1562")}
    vai = {1: "giua", 2: "ngay", 3: "traix", 4: "trai", 5: "traix", 6: "giua", 7: "sl", 8: "dg", 9: "dg", 10: "so", 11: "so", 12: "so",
           13: "dg", 14: "dg"}
    cb = []
    sk = sl_ = 0
    for d in S.ct:
        if d.no in t1562:                               # chi phi mua hang phat sinh (can phan bo)
            V.dong(ws, r, "dl", {1: d.sh, 2: d.ngay, 3: d.dg, 11: d.tien}, vai)
            sk += d.tien
            r += 1
    for d in S.ct:
        if d.co in t1562:                               # da phan bo: ghi Co 1562 -> hang ton kho / gia von
            vt = KH.ten_vt(d.vt) if d.vt else ["", S.doi_ung_co(d) and ("TK " + S.doi_ung_co(d)) or "", "", ""]
            sl = d.sl_no or None
            V.dong(ws, r, "dl", {1: d.sh, 2: d.ngay, 3: d.dg, 4: vt[0], 5: vt[1], 6: vt[2], 7: sl, 12: d.tien,
                                 13: (d.tien / sl) if sl else None}, vai)
            sl_ += d.tien
            r += 1
    V.dong(ws, r, "dl", {3: "Cộng", 11: sk, 12: sl_}, {11: "so", 12: "so"}, them={3: {"dam": True}, 11: {"dam": True}, 12: {"dam": True}})
    r += 1
    d0 = sum(S.du_dau(m) for m in t1562)
    V.ghi_chu(ws, r + 1, 3, 14, "Số dư TK 1562 đầu kỳ: %s - cuối kỳ: %s" % (dd(d0), dd(d0 + sk - sl_)))
    if not t1562:
        cb.append("Hệ thống tài khoản không có TK 1562 (chi phí thu mua hàng hóa) - bảng phân bổ để trống")
        V.ghi_chu(ws, r + 2, 3, 14, "Sổ không theo dõi chi phí mua hàng trên TK 1562 - không có số liệu để phân bổ.")
    elif not sk and not sl_:
        cb.append("Kỳ này không có phát sinh TK 1562 - bảng phân bổ chi phí mua hàng để trống")
        V.ghi_chu(ws, r + 2, 3, 14, "Kỳ này không có chi phí mua hàng (TK 1562) phát sinh / phân bổ.")
    V.cuoi(ws, r + 4, S.thay())
    pn = sum(S.ps_ky(m)[0] for m in t1562)
    pc = sum(S.ps_ky(m)[1] for m in t1562)
    KT.them("Chi phí cần phân bổ = phát sinh Nợ TK 1562", sk, pn)
    KT.them("Chi phí đã phân bổ = phát sinh Có TK 1562", sl_, pc)
    return V, cb + KT.canh_bao()


# ============================================================ 18-19. PHAN BO 242 / KHAU HAO TSCD
def _lap_pb(S, ma, loai):
    """loai 'CCDC' (ThongSo1, 242) | 'TS' (ThongSo, 214)"""
    V, KT = Ve(S, ma), Kiem(ma)
    ss = S.ss
    if loai == "CCDC":
        ds_ts = ss.get("ccdc") or []
        ds_so = ss.get("ccdc_ts") or []
    else:
        ds_ts = ss.get("tsan") or []
        ds_so = ss.get("tsan_ts") or []
    so = defaultdict(dict)                         # MaTS -> thang -> (NG, KH, CL, MaDTSD)
    for r in ds_so:
        so[int(_so(r[0]))][int(_so(r[1]))] = (_so(r[2]), _so(r[3]), _so(r[4]), int(_so(r[5])))
    ws = V.sheet("PB 242" if loai == "CCDC" else "KH TSCĐ")
    r = V.dau(ws, 1, S.thay())
    ws.in_trang(ngang=True, lap_dong=(9, 10))
    kth = None
    for x in V.sp["dau"]:
        if x[0] == 10 and x[1] == 9:
            kth = x[3]
    for i in range(12):
        m, y = S.thang_lich(i + 1)
        ws.o(10, 9 + i, "Tháng %d" % m, V.kieu(kth) if kth else None)
    vai = {1: "giua", 2: "trai", 3: "traix", 4: "ngay", 5: "so", 6: "giua", 7: "so", 8: "so", 21: "so", 22: "so", 23: "so", 24: "trai"}
    for i in range(12):
        vai[9 + i] = "so"
    t1, t2 = S.t1, S.t2
    nhom = defaultdict(list)
    cb = []
    for x in ds_ts:
        if loai == "CCDC":
            ms, sh, ten, _mtk, ten_loai, nkh, nct, tang, giam = x[:9]
        else:
            ms, sh, ten, _shl, ten_loai, nkh, nct, tang, giam = x[:9]
        ms = int(_so(ms))
        tt = so.get(ms) or {}
        tang_f = K.thang_tc(tang, S.dau_ky)
        giam_f = 13 if int(_so(giam)) == 0 else K.thang_tc(giam, S.dau_ky)
        if giam_f < t1:
            continue                                # da ghi giam truoc ky

        def con_dung(t):
            return tang_f <= t <= giam_f
        dk = tt.get(t1 - 1)
        if dk is None or tang_f > t1 - 1:
            lk_dau = 0.0
            ng_dau = 0.0
        else:
            lk_dau = dk[0] - dk[2]
            ng_dau = dk[0]
        kh_t = {}
        for t in range(t1, t2 + 1):
            v = tt.get(t)
            if v and con_dung(t) and abs(v[1]) > 0.5:
                kh_t[t] = v[1]
        cuoi = tt.get(t2)
        ng = cuoi[0] if cuoi else ng_dau
        cp = (cuoi[3] if cuoi else 0) or (dk[3] if dk else 0)
        tong_ky = sum(kh_t.values())
        lk_cuoi = lk_dau + tong_ky
        con_lai = ng - lk_cuoi
        if loai == "CCDC" and abs(lk_dau - ng) < 0.5 and not kh_t and ng > 0:
            continue                                # CCDC da phan bo het truoc ky (TSCD het khau hao van con tren so -> van liet ke)
        if not tt or (ng < 0.5 and not kh_t):
            continue
        if cuoi and abs((cuoi[0] - cuoi[2]) - lk_cuoi) > 1.5 and con_dung(t2):
            cb.append("%s %s: lũy kế theo tháng (%s) khác nguyên giá - còn lại phần mềm lưu (%s)" % (sh, ten[:30], dd(lk_cuoi), dd(cuoi[0] - cuoi[2])))
        nkh = int(_so(nkh))
        muc = (ng / nkh) if (nkh and loai == "CCDC") else ((ng / (nkh * 12)) if nkh else None)
        nhom[cp].append([sh, ten, _ngay(nct), ng, nkh or None, muc, lk_dau, kh_t, tong_ky, lk_cuoi, con_lai, ten_loai])
    tong = defaultdict(float)
    chu = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    for gi, cp in enumerate(sorted(nhom, key=lambda m: S.sh(m))):
        V.dong(ws, r, "nhom", {1: chu[gi % 26], 3: ("TK %s - %s" % (S.sh(cp), S.ten_tk(cp))) if cp else "Chưa gán tài khoản chi phí"},
               {3: "traix"})
        r += 1
        stt = 0
        for x in sorted(nhom[cp], key=lambda y: y[0]):
            stt += 1
            sh, ten, nct, ng, nkh, muc, lk_dau, kh_t, tong_ky, lk_cuoi, con_lai, ten_loai = x
            g = {1: stt, 2: sh, 3: ten, 4: nct, 5: ng, 6: nkh, 7: muc, 8: lk_dau or None, 21: tong_ky or None, 22: lk_cuoi or None,
                 23: con_lai, 24: ten_loai}
            for t, v in kh_t.items():
                g[8 + t] = v
            V.dong(ws, r, "dl", g, vai)
            r += 1
            for k in (5, 8, 21, 22, 23):
                tong[k] += _so(g.get(k))
            for t, v in kh_t.items():
                tong[8 + t] += v
    gt = {3: "TỔNG CỘNG"}
    for k, v in tong.items():
        gt[k] = v
    V.dong(ws, r, "tong", gt, dict((k, "so") for k in gt if k != 3))
    V.cuoi(ws, r + 2, S.thay())
    if not nhom:
        cb.append("Kỳ này không có %s còn giá trị phải %s" % (("công cụ dụng cụ / chi phí trả trước", "phân bổ") if loai == "CCDC"
                                                                 else ("tài sản cố định", "khấu hao")))
    tk = "242" if loai == "CCDC" else "214"
    las = [m for m in S.la if S.sh(m).startswith(tk)]
    if loai == "CCDC":
        KT.them("Số phân bổ trong kỳ = phát sinh Có TK 242", tong[21], sum(S.ps_ky(m)[1] for m in las))
        KT.them("Giá trị còn lại cuối kỳ = số dư Nợ TK 242", tong[23], sum(S.du_cuoi(m) for m in las))
    else:
        KT.them("Số khấu hao trong kỳ = phát sinh Có TK 214", tong[21], sum(S.ps_ky(m)[1] for m in las))
        KT.them("Khấu hao lũy kế cuối kỳ = số dư Có TK 214", tong[22], -sum(S.du_cuoi(m) for m in las))
        l211 = [m for m in S.la if S.sh(m).startswith("211")]
        KT.them("Nguyên giá = số dư Nợ TK 211", tong[5], sum(S.du_cuoi(m) for m in l211))
    return V, cb + KT.canh_bao()


def lap_pb242(S):
    return _lap_pb(S, "SS_PB242", "CCDC")


def lap_kh214(S):
    return _lap_pb(S, "SS_KH214", "TS")


# ============================================================ 20-22. CHAM CONG / LUONG / THUE TNCN
def _nhan_vien(S):
    nv = {}
    for r in S.ss.get("nv") or []:
        r = list(r) + [""] * (10 - len(r))
        nv[int(_so(r[0]))] = {"sh": str(r[1] or ""), "ten": str(r[2] or ""), "cv": str(r[3] or ""), "shcv": str(r[4] or ""),
                              "pl": int(_so(r[5])), "shpl": str(r[6] or ""), "tpl": str(r[7] or ""), "hd": int(_so(r[8])),
                              "nghi": int(_so(r[9]))}
    if not nv:
        for r in S.dl.get("nv") or []:
            nv[int(_so(r[0]))] = {"sh": str(r[1] or ""), "ten": str(r[2] or ""), "cv": str(r[3] or ""), "shcv": "", "pl": 0,
                                  "shpl": "", "tpl": "", "hd": 0, "nghi": 0}
    return nv


def _thang_ky(S):
    return [S.thang_lich(t) for t in range(S.t1, S.t2 + 1)]


def _nhom_nv(nv, ds_ma):
    """[(ten nhom, [ma nv])] theo bo phan (phan loai nhan vien)"""
    g = OrderedDict()
    for ma in sorted(ds_ma, key=lambda m: ((nv.get(m) or {}).get("shpl", ""), (nv.get(m) or {}).get("sh", ""))):
        x = nv.get(ma) or {}
        ten = x.get("tpl") or "Nhân viên"
        if x.get("shpl"):
            ten = "%s (%s)" % (ten, x["shpl"])
        g.setdefault(ten, []).append(ma)
    return list(g.items())


_CC_THUONG = ("C",)
_CC_NUA = ("P1", "V1")


def lap_chamcong(S):
    V, KT = Ve(S, "SS_CHAMCONG"), Kiem("SS_CHAMCONG")
    nv = _nhan_vien(S)
    theo_sh = {x["sh"]: ma for ma, x in nv.items()}
    cc = defaultdict(dict)
    for r in S.ss.get("cc") or []:
        cc[int(_so(r[1]))][str(r[0] or "")] = r
    cb = []
    chu = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    for (m, y) in _thang_ky(S):
        rows = cc.get(m) or {}
        ws = V.sheet("T%02d-%d" % (m, y))
        so_ngay = (datetime.date(y + (m == 12), m % 12 + 1, 1) - datetime.timedelta(days=1)).day
        r = V.dau(ws, 1, S.thay(THANG_NAM="Tháng %02d năm %d" % (m, y), NOI_NGAY=S.noi_ngay(datetime.date(y, m, so_ngay))))
        ws.in_trang(ngang=True, lap_dong=(8, 10))
        k9 = next((x[3] for x in V.sp["dau"] if x[0] == 9 and x[1] == 4), None)
        k10 = next((x[3] for x in V.sp["dau"] if x[0] == 10 and x[1] == 4), None)
        cn = set()
        for i in range(31):
            if i < so_ngay:
                ng = datetime.date(y, m, i + 1)
                nen = "D9D9D9" if ng.weekday() == 6 else None
                if nen:
                    cn.add(4 + i)
                ws.o(9, 4 + i, i + 1, V.kieu(k9, can="giua", nen=nen))
                ws.o(10, 4 + i, ["T2", "T3", "T4", "T5", "T6", "T7", "CN"][ng.weekday()], V.kieu(k10, can="giua", nen=nen))
            else:
                ws.o(9, 4 + i, None, V.kieu(k9, nen=None))
                ws.o(10, 4 + i, None, V.kieu(k10, nen=None))
        nen_ngay = {c: {"nen": ("D9D9D9" if c in cn else None)} for c in range(4, 35)}
        ma_co = {theo_sh.get(sh, -1) for sh in rows}
        vai = {1: "giua", 2: "traix", 3: "giua"}
        for c in range(4, 41):
            vai[c] = "giua"
        tong = [0.0] * 6
        stt = 0
        khong_dm = [sh for sh in rows if sh not in theo_sh]
        nhom = _nhom_nv(nv, [x for x in ma_co if x != -1])
        if khong_dm:
            nhom.append(("Mã nhân viên không có trong danh mục", [-1]))
        for gi, (ten_nhom, ds_ma) in enumerate(nhom):
            dsr = []
            for ma in ds_ma:
                if ma == -1:
                    dsr += [(sh, {"ten": sh, "cv": ""}, rows[sh]) for sh in khong_dm]
                else:
                    dsr.append((nv[ma]["sh"], nv[ma], rows[nv[ma]["sh"]]))
            st = [0.0] * 6
            ghi = []
            for sh, x, rr in dsr:
                ngay = [str(v or "").strip() for v in rr[6:37]]
                ca = sum(1 for v in ngay if v.upper() in _CC_THUONG)
                nua = sum(1 for v in ngay if v.upper() in _CC_NUA)
                cong, nghi, phep, tang = _so(rr[2]), _so(rr[3]), _so(rr[4]), _so(rr[5])
                v6 = [ca, nua, cong, phep, cong + phep + tang, nghi]
                ghi.append((x, ngay, v6))
                for i in range(6):
                    st[i] += v6[i]
            V.dong(ws, r, "nhom", {1: chu[gi % 26], 2: ten_nhom, 35: st[0], 36: st[1], 37: st[2], 38: st[3], 39: st[4], 40: st[5]},
                   {2: "trai", 35: "sl", 36: "sl", 37: "sl", 38: "sl", 39: "sl", 40: "sl"}, them=nen_ngay)
            r += 1
            for x, ngay, v6 in ghi:
                stt += 1
                g = {1: stt, 2: x.get("ten"), 3: x.get("cv")}
                for i in range(so_ngay):
                    g[4 + i] = ngay[i] or None
                for i in range(6):
                    g[35 + i] = v6[i] or None
                vd = dict(vai)
                vd.update({35: "sl", 36: "sl", 37: "sl", 38: "sl", 39: "sl", 40: "sl"})
                V.dong(ws, r, "dl", g, vd, them=nen_ngay)
                r += 1
            for i in range(6):
                tong[i] += st[i]
        V.dong(ws, r, "tong", {2: "Tổng số ngày công", 35: tong[0], 36: tong[1], 37: tong[2], 38: tong[3], 39: tong[4], 40: tong[5]},
               {2: "trai", 35: "sl", 36: "sl", 37: "sl", 38: "sl", 39: "sl", 40: "sl"}, them=nen_ngay)
        r = V.cuoi(ws, r + 1, S.thay(NOI_NGAY=S.noi_ngay(datetime.date(y, m, so_ngay))))
        V.ghi_chu(ws, r + 2, 2, 40, "Ký hiệu chấm công (theo phần mềm): C - có mặt; V - vắng mặt; P - nghỉ phép; P1 - đi làm nửa ngày, phép nửa "
                       "ngày; V1 - đi làm nửa ngày, vắng nửa ngày; T - tăng ca.")
        V.ghi_chu(ws, r + 3, 2, 40, "Tháng %02d năm %d có %d ngày. Ngày công tính lương = ngày công + nghỉ phép + tăng ca (như phần mềm tính lương)."
             % (m, y, so_ngay))
        if not rows:
            cb.append("Tháng %02d/%d: chưa có bảng chấm công trên phần mềm" % (m, y))
        khac = sum(1 for rr in rows.values()
                   if abs(sum(1 for v in rr[6:37] if str(v or "").strip().upper() in _CC_THUONG)
                          + 0.5 * sum(1 for v in rr[6:37] if str(v or "").strip().upper() in _CC_NUA) - _so(rr[2])) > 0.01)
        if khac:
            cb.append("Tháng %02d/%d: %d người có số ô ký hiệu công (C, P1, V1) khác 'ngày công' phần mềm đã lưu - "
                      "biểu mẫu in đúng cả hai (cột AI-AJ đếm ký hiệu, cột AK ngày công đã lưu)" % (m, y, khac))
        KT.them("Tháng %02d/%d: tổng ngày công = bảng chấm công phần mềm" % (m, y), tong[2], sum(_so(x[2]) for x in rows.values()))
    return V, cb + KT.canh_bao()


def _luong_thang(S):
    """-> {thang: [dong BangLuong]}, tsl {(sh, thang): dong ThongSoLuong}"""
    bl = defaultdict(list)
    for r in S.ss.get("bl") or []:
        bl[int(_so(r[1]))].append(list(r) + [0] * (22 - len(r)))
    tsl = {}
    for r in S.ss.get("tsl") or []:
        tsl[(str(r[0] or ""), int(_so(r[1])))] = list(r) + [0] * (23 - len(r))
    return bl, tsl


def _ps_thang(S, tt, ben, t):
    n = c = 0.0
    for m in S.la_theo(tt):
        p = S.ps.get(m)
        if p:
            x = p["thang"].get(t)
            if x:
                n += x[0] + x[2]
                c += x[1] + x[3]
    return n if ben == "N" else c


def _pt(v):
    v = _so(v)
    return ("(%s%%)" % ("%g" % v).replace(".", ",")) if v else ""


def lap_luong(S):
    V, KT = Ve(S, "SS_LUONG"), Kiem("SS_LUONG")
    nv = _nhan_vien(S)
    bl, tsl = _luong_thang(S)
    cb = []
    chu = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    for t in range(S.t1, S.t2 + 1):
        m, y = S.thang_lich(t)
        rows = bl.get(m) or []
        so_ngay = (datetime.date(y + (m == 12), m % 12 + 1, 1) - datetime.timedelta(days=1)).day
        mau_ts = next((tsl.get((nv.get(int(_so(x[0])), {}).get("sh", ""), m)) for x in rows
                       if tsl.get((nv.get(int(_so(x[0])), {}).get("sh", ""), m))), None)
        th = S.thay(THANG_NAM="Tháng %02d năm %d" % (m, y), NOI_NGAY=S.noi_ngay(datetime.date(y, m, so_ngay)),
                    DN_XH=_pt(mau_ts[19]) if mau_ts else "", DN_YT=_pt(mau_ts[20]) if mau_ts else "",
                    DN_TN=_pt(mau_ts[21]) if mau_ts else "", NV_XH=_pt(mau_ts[16]) if mau_ts else "",
                    NV_YT=_pt(mau_ts[17]) if mau_ts else "", NV_TN=_pt(mau_ts[18]) if mau_ts else "")
        ws = V.sheet("T%02d-%d" % (m, y))
        r = V.dau(ws, 1, th)
        ws.in_trang(ngang=True, lap_dong=(9, 11))
        vai = {1: "giua", 2: "traix", 3: "giua", 10: "sl", 25: "traix"}
        for c in list(range(4, 10)) + list(range(11, 25)):
            vai[c] = "so"
        theo_ma = {int(_so(x[0])): x for x in rows}
        tong = defaultdict(float)
        stt = 0
        for gi, (ten_nhom, ds_ma) in enumerate(_nhom_nv(nv, list(theo_ma))):
            ghi = []
            st = defaultdict(float)
            for ma in ds_ma:
                x = theo_ma[ma]
                n = nv.get(ma) or {"ten": "Nhân viên mã số %d" % ma, "cv": "", "sh": ""}
                p = tsl.get((n.get("sh", ""), m))
                tnk = _so(x[6])
                if p:
                    e = _so(p[5]) + _so(p[6])          # chuc vu + trach nhiem
                    f = _so(p[8])                        # com / an trua
                    g_ = _so(p[7])                       # luu dong
                else:
                    e = f = g_ = 0.0
                h = tnk - e - f - g_                     # thuong, tang ca, cong khac, phu cap khac (phan con lai)
                dn = [_so(x[17]), _so(x[18]), _so(x[19])]
                nvb = [_so(x[8]), _so(x[9]), _so(x[10])]
                v = {4: _so(x[4]), 5: e, 6: f, 7: g_, 8: h, 9: _so(x[7]), 10: _so(x[3]), 11: _so(x[5]), 12: _so(x[4]), 13: None,
                     14: dn[0], 15: dn[1], 16: dn[2], 17: sum(dn), 18: nvb[0], 19: nvb[1], 20: nvb[2], 21: sum(nvb), 22: _so(x[16]),
                     23: _so(x[11]) + _so(x[12]), 24: _so(x[13])}
                ghi_chu = []
                if _so(x[12]):
                    ghi_chu.append("trừ khác %s" % dd(x[12]))
                if abs(_so(x[7]) - _so(x[5]) - tnk) > 1:
                    ghi_chu.append("tổng TN khác lương + phụ cấp")
                ghi.append((n, v, "; ".join(ghi_chu)))
                for k, vv in v.items():
                    if k != 10:
                        st[k] += _so(vv)
            gt = {1: chu[gi % 26], 2: ten_nhom}
            gt.update({k: st[k] for k in st})
            V.dong(ws, r, "nhom", gt, vai)
            r += 1
            for n, v, gc in ghi:
                stt += 1
                g = {1: stt, 2: n.get("ten"), 3: n.get("cv"), 25: gc or None}
                g.update({k: (vv if vv else None) for k, vv in v.items()})
                V.dong(ws, r, "dl", g, vai)
                r += 1
            for k, vv in st.items():
                tong[k] += vv
        gt = {2: "Tổng cộng"}
        gt.update(dict(tong))
        V.dong(ws, r, "tong", gt, vai)
        r = V.cuoi(ws, r + 2, th)
        V.ghi_chu(ws, r + 2, 2, 25, "Số liệu lấy từ bảng lương phần mềm (BangLuong / ThongSoLuong) tháng %02d/%d; thực lĩnh = số phần mềm đã tính "
                       "(tổng thu nhập - BH người lao động - tạm ứng - trừ khác). Phần mềm không lưu KPCĐ trong bảng lương." % (m, y))
        if not rows:
            cb.append("Tháng %02d/%d: chưa có bảng lương trên phần mềm" % (m, y))
            continue
        c334 = _ps_thang(S, "334", "C", t)
        KT.them("Tháng %02d/%d: tổng thu nhập bảng lương = phát sinh Có TK 334" % (m, y), tong[9], c334, sai=0.5)
        thue = tong[22]
        if thue and all(abs(_so(x[13]) - (_so(x[7]) - _so(x[8]) - _so(x[9]) - _so(x[10]) - _so(x[11]) - _so(x[12]))) < 1 for x in rows):
            cb.append("Tháng %02d/%d: thực lĩnh phần mềm chưa trừ thuế TNCN %s (phần mềm trừ thuế qua 'trừ khác' / chứng từ riêng)" % (m, y, dd(thue)))
    return V, cb + KT.canh_bao()


_LOAI_HD = {1: "Không thời hạn", 2: "12 - 36 tháng", 3: "Dưới 12 tháng"}


def lap_tncnthang(S):
    V, KT = Ve(S, "SS_TNCNTHANG"), Kiem("SS_TNCNTHANG")
    nv = _nhan_vien(S)
    bl, tsl = _luong_thang(S)
    gk = defaultdict(float)
    for r in S.ss.get("gt_khac") or []:
        gk[(int(_so(r[0])), int(_so(r[1])))] += _so(r[2])
    cb = []
    chu = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    gt_luat = giam_tru_luat(S.nam)
    gt_pm = (_so(S.dn.get("gt_ban_than")), _so(S.dn.get("gt_phu_thuoc")))
    if S.t1 > S.t2:
        raise ValueError("Kỳ báo cáo vắt qua hai năm tài chính - chọn kỳ trong một năm tài chính.")
    for t in range(S.t1, S.t2 + 1):
        m, y = S.thang_lich(t)
        rows = bl.get(m) or []
        so_ngay = (datetime.date(y + (m == 12), m % 12 + 1, 1) - datetime.timedelta(days=1)).day
        ws = V.sheet("T%02d-%d" % (m, y))
        th = S.thay(THANG_NAM="Tháng %02d năm %d" % (m, y), NOI_NGAY=S.noi_ngay(datetime.date(y, m, so_ngay)))
        r = V.dau(ws, 1, th)
        ws.in_trang(ngang=True, lap_dong=(9, 10))
        # them 2 cot sau cot thue phan mem: kiem tinh lai + chenh lech
        k_h = next((x[3] for x in V.sp["dau"] if x[0] == 9 and x[1] == 19), "k0")
        ws.rong(20, 13)
        ws.rong(21, 11)
        ws.gop(9, 20, 10, 20, "Kiểm tính lại\n(biểu %s)" % ("5 bậc" if y >= 2026 else "7 bậc"), V.kieu(k_h))
        ws.gop(9, 21, 10, 21, "Chênh lệch", V.kieu(k_h))
        ws.o(10, 20, None, V.kieu(k_h))
        ws.o(10, 21, None, V.kieu(k_h))
        vai = {1: "giua", 2: "traix", 3: "giua", 4: "giua", 13: "giua"}
        for c in list(range(5, 13)) + list(range(14, 22)):
            vai[c] = "so"
        kso = V.kieu(V.sp["dong"]["dl"]["kieu"]["19"], so=F_TIEN, can="phai")
        ksod = V.kieu(V.sp["dong"]["tong"]["kieu"]["19"], so=F_TIEN, can="phai")
        theo_ma = {int(_so(x[0])): x for x in rows}
        tong = defaultdict(float)
        stt = 0
        lech = 0
        for gi, (ten_nhom, ds_ma) in enumerate(_nhom_nv(nv, list(theo_ma))):
            ghi = []
            st = defaultdict(float)
            for ma in ds_ma:
                x = theo_ma[ma]
                n = nv.get(ma) or {"ten": "Nhân viên mã số %d" % ma, "cv": "", "hd": 0}
                tn = _so(x[7])
                bt = _so(x[20]) if _so(x[20]) > 0 else gt_luat[0]      # uu tien so phan mem luu o BangLuong
                muc_pt = _so(x[21]) if _so(x[21]) > 0 else gt_luat[1]
                npt = int(_so(x[15]))
                bh = _so(x[8]) + _so(x[9]) + _so(x[10])
                khac = gk.get((ma, m), 0.0)
                q = bt + npt * muc_pt + bh + khac
                tntt = max(tn - q, 0)
                thue_pm = _so(x[16])
                kiem = thue_tncn_thang(tntt, y)
                v = {5: tn, 11: tn, 12: bt, 13: npt or None, 14: npt * muc_pt, 15: bt + npt * muc_pt, 16: bh, 17: q, 18: tntt, 19: thue_pm,
                     20: kiem, 21: thue_pm - kiem}
                ghi.append((n, v))
                if abs(thue_pm - kiem) > 1:
                    lech += 1
                for k, vv in v.items():
                    if k != 13:
                        st[k] += _so(vv)
            gt = {1: chu[gi % 26], 2: ten_nhom}
            gt.update(dict(st))
            V.dong(ws, r, "nhom", gt, vai)
            ws.o(r, 20, st[20], ksod)
            ws.o(r, 21, st[21], ksod)
            r += 1
            for n, v in ghi:
                stt += 1
                g = {1: stt, 2: n.get("ten"), 3: n.get("cv"), 4: _LOAI_HD.get(n.get("hd"), "")}
                g.update({k: (vv if vv else None) for k, vv in v.items() if k < 20})
                V.dong(ws, r, "dl", g, vai)
                ws.o(r, 20, v[20] or None, kso)
                ws.o(r, 21, v[21] or None, kso)
                r += 1
            for k, vv in st.items():
                tong[k] += vv
        gt = {2: "TỔNG CỘNG"}
        gt.update(dict(tong))
        V.dong(ws, r, "tong", gt, vai)
        ws.o(r, 20, tong[20], ksod)
        ws.o(r, 21, tong[21], ksod)
        r = V.ky_chung(ws, r + 2, (2, 9, 16), datetime.date(y, m, so_ngay))
        gc = ["Thu nhập chịu thuế = tổng thu nhập trên bảng lương phần mềm (phần mềm không tách thu nhập miễn thuế: ăn giữa ca, "
              "điện thoại, trang phục...; cột F - J để trống). Giảm trừ bản thân %s, người phụ thuộc %s / người / tháng "
              "(Luật 109/2025/QH15, NQ 110/2025/UBTVQH15 áp dụng từ kỳ tính thuế 2026; ưu tiên mức phần mềm lưu trong bảng lương nếu có)."
              % (dd(gt_luat[0]), dd(gt_luat[1])) if y >= 2026 else
              "Thu nhập chịu thuế = tổng thu nhập trên bảng lương phần mềm. Giảm trừ bản thân %s, người phụ thuộc %s / người / tháng."
              % (dd(gt_luat[0]), dd(gt_luat[1])),
              "Cột S = thuế phần mềm đã tính (bảng lương); cột T kiểm tính lại theo biểu thuế lũy tiến %s năm %d; cột U = S - T."
              % ("5 bậc (5/10/20/30/35%, ngưỡng 10/30/60/100 triệu)" if y >= 2026 else "7 bậc", y)]
        for i, g in enumerate(gc):
            V.ghi_chu(ws, r + 2 + i, 2, 21, g)
        if not rows:
            cb.append("Tháng %02d/%d: chưa có bảng lương / thuế TNCN trên phần mềm" % (m, y))
        if lech:
            cb.append("Tháng %02d/%d: %d người có thuế TNCN phần mềm khác kiểm tính lại (xem cột U)" % (m, y, lech))
        KT.them("Tháng %02d/%d: thu nhập chịu thuế = tổng thu nhập bảng lương" % (m, y), tong[5], sum(_so(x[7]) for x in rows))
    if y >= 2026 and gt_pm[0] and abs(gt_pm[0] - gt_luat[0]) > 0.5:
        cb.append("Khai báo giảm trừ gia cảnh trên phần mềm đang là %s / %s (mức cũ) - phần mềm tính thuế tháng theo mức này; "
                  "cột T kiểm tính lại theo mức %s / %s" % (dd(gt_pm[0]), dd(gt_pm[1]), dd(gt_luat[0]), dd(gt_luat[1])))
    return V, cb + KT.canh_bao()


# ============================================================ dieu phoi
HAM = {"SS_NKC": lap_nkc, "SS_SOCAI": lap_socai, "SS_SCTTK": lap_scttk, "SS_QUYTM": lap_quytm, "SS_TGNH": lap_tgnh,
       "SS_TH131": lap_th131, "SS_TH331": lap_th331, "SS_TTTNDN": lap_tttndn, "SS_PTHU": lap_pthu, "SS_PCHI": lap_pchi,
       "SS_PNK": lap_pnk, "SS_PXK": lap_pxk, "SS_BKNX": lap_bknx, "SS_SCTVT": lap_sctvt, "SS_THNXT": lap_thnxt,
       "SS_DMHH": lap_dmhh, "SS_PBCPMH": lap_pbcpmh, "SS_PB242": lap_pb242, "SS_KH214": lap_kh214,
       "SS_CHAMCONG": lap_chamcong, "SS_LUONG": lap_luong, "SS_TNCNTHANG": lap_tncnthang}


def so_lieu(dl):
    if _CACHE[0] is not dl:
        _CACHE[0], _CACHE[1] = dl, SoLieuSS(dl)
    return _CACHE[1]


def _giao(dl, ma, kieu, thumuc):
    mod, m2 = GIAO[ma]
    ten = TEN_MAU.get(ma, ma)
    try:
        M = importlib.import_module(mod)
    except Exception as e:
        return {"tep": [], "canh_bao": ["%s: chưa có mô-đun %s.py trong AIHoaDon (%s) - không lập được" % (ten, mod, e)]}
    try:
        r = M.lap(dl, m2, "E", thumuc)
    except Exception as e:
        return {"tep": [], "canh_bao": ["%s: lỗi khi lập qua %s.py: %s" % (ten, mod, e)]}
    if isinstance(r, dict):
        return {"tep": list(r.get("tep") or []), "canh_bao": list(r.get("canh_bao") or [])}
    if isinstance(r, (list, tuple)):
        return {"tep": [str(x) for x in r], "canh_bao": []}
    return {"tep": [str(r)] if r else [], "canh_bao": []}


def lap(dl, ma, kieu, thumuc):
    """Lap MOT tep Excel cho mau 'ma' (SS_...) vao thu muc 'thumuc' (kieu X / HTKK khong ap dung cho so sach)."""
    ma = str(ma or "").strip().upper()
    try:
        import tieu_de_tt
        tieu_de_tt.nhan(dl)                  # GD227: tieu de mau (Mau so ... / Ban hanh theo ...) theo Thong tu cua bo so (GD139)
    except Exception:
        pass
    if ma in GIAO:
        if so_lieu(dl).cp99:                 # GD227: so TT99 - B01 / B02 / B03 / B09 / bang can doi so phat sinh theo mau TT99 lap o nut Bao cao tai chinh
            return {"tep": [], "canh_bao": ["%s: sổ theo TT99/2025 - báo cáo tài chính (B01-DN, B02-DN, B03-DN, B09-DN, S06-DN) lập ở nút "
                                            "Báo cáo tài chính, không lập từ biểu mẫu sổ sách (mẫu này theo TT133)" % TEN_MAU.get(ma, ma)]}
        return _giao(dl, ma, kieu, thumuc)
    if ma not in HAM:
        raise ValueError("Mẫu %s không có trong bảng sơ đồ sổ sách TT133" % ma)
    S = so_lieu(dl)
    V, cb = HAM[ma](S)
    ten = V.luu(S, ma)
    duong = os.path.join(thumuc, ten + ".xlsx")
    V.wb.luu(duong)
    # canh bao chung cua so lieu (ky khong tron thang, JSON thieu phan...) chi bao MOT lan trong lan xuat
    da = getattr(S, "_da_bao", None)
    if da is None:
        da = S._da_bao = set()
    them = [x for x in S.cb if x not in cb and x not in da]
    da.update(them)
    if kieu and "E" not in str(kieu).upper():
        them.append("Biểu mẫu sổ sách chỉ lập Excel (không có XML HTKK)")
    return {"tep": [duong], "canh_bao": them + cb}
