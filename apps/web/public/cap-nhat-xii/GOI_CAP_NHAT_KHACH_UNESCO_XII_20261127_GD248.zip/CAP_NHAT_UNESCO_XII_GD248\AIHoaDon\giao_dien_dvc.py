# -*- coding: utf-8 -*-
"""
giao_dien_dvc.py - GD120: cua so "Tai du lieu tu Cong dich vu cong Thue" theo anh thiet ke anh Thang (04/10/2026).

Chi la GIAO DIEN cho tool_dvc_unesco.py: ba nut chay dung ba che do cu cua tool (khong them chuc nang gia):
  - Lay bang dang mo tren cong  -> che do doc bang (nguoi dung tu tra cuu, bam 'Lay bang nay' tren cong)
  - Day tool cach lay           -> che do hoc (moi chuc nang 1 lan)
  - Tai du lieu                 -> tai cac nhom da chon trong khoang ngay
Chu tieng Viet co dau day du (tkinter ve Unicode). Nhat ky cua tool (khong dau, ghi file) duoc chuyen sang co dau khi hien.
Hinh: AIHoaDon\\giao-dien\\dvc\\*.png (thieu hinh van chay, chi mat bieu tuong).
Tool KHONG luu mat khau, KHONG dien ma xac nhan, KHONG ky / nop ho so thay (quy tac 17) - giao dien nay khong doi dieu do.
"""
import os
import queue
import re
import threading
from datetime import date, datetime

THU_MUC = os.path.dirname(os.path.abspath(__file__))
HINH = os.path.join(THU_MUC, "giao-dien", "dvc")

MAU = {
    "trang": "#f6f9fe", "the": "#fdfeff", "vien": "#d9e5f3", "dau_the": "#ecf4fc", "o": "#ffffff", "vien_o": "#e0e8f2",
    "chu": "#22314f", "chu_nhat": "#5f6d84", "xanh_dam": "#0d2f7c", "xanh": "#1667d9", "la": "#13924b", "la_dam": "#0e7a3d",
    "cam": "#f08a00", "nen_cam": "#fff0d6", "nen_la": "#e2f6e9", "chu_la": "#15884a", "nen_xanh": "#e5efff",
    "nen_tl": "#f1f7fd", "vien_tl": "#d8e5f2", "nen_tl2": "#eef9f2", "vien_tl2": "#cdeada", "o_tl": "#d4f0de",
    "banner1": "#03214f", "banner2": "#0a3f91", "cam_nut": "#f7931e", "dong_le": "#f8fbfe",
}

# ten nhom co dau (theo thu tu tool: TB, GNT, HSDVC, HSTDT, HSK, NV, KHAC)
TEN_VN = {
    "TB": "Tra cứu thông báo (Nộp thuế)",
    "GNT": "Tra cứu GNT (giấy nộp tiền)",
    "HSDVC": "Tra cứu hồ sơ đã nộp trên DVC",
    "HSTDT": "Tra cứu hồ sơ đã nộp trên thuế điện tử",
    "HSK": "Hồ sơ khai thuế đã nộp",
    "NV": "Nghĩa vụ thuế (số còn phải nộp)",
    "KHAC": "Bảng khác (đọc trên màn hình)",
}

HUONG_DAN = (
    "Cách dùng\n\n"
    "Mở từ nút 'Mở Cổng dịch vụ công' của phần mềm: bạn chỉ cần ĐĂNG NHẬP - tool tự tìm và tải mọi nội dung mới "
    "(thông báo, giấy nộp tiền, hồ sơ, nghĩa vụ thuế) trong khoảng ngày đã chọn. Màn hình nào có mã xác nhận thì tool "
    "báo bạn tự nhập mã trên Chrome (tool không điền mã). Nhóm chưa dạy cách lấy sẽ được báo rõ để bạn dạy một lần.\n\n"
    "1. Chọn khoảng ngày và các nhóm dữ liệu cần tải.\n"
    "2. Bấm Tải dữ liệu: tool mở Chrome tới Cổng dịch vụ công. Bạn tự đăng nhập bằng tài khoản doanh nghiệp.\n"
    "3. Nhóm đã học: tool tự tải theo khoảng ngày. Nhóm chưa học: mở màn hình tra cứu trên cổng, tự tra cứu "
    "rồi bấm 'Lấy bảng này' trên dải xanh đầu trang (tool tự lật hết các trang).\n"
    "4. Lấy bảng đang mở trên cổng: dùng cho mọi màn hình, kể cả màn hình có mã xác nhận (bạn tự nhập mã).\n"
    "5. Dạy tool cách lấy: chọn nhóm, bấm và dùng chức năng đó trên cổng một lần - lần sau tool tự tải.\n"
    "6. Xong, quay lại phần mềm: thẻ Cổng thuế tự nạp kết quả.\n\n"
    "Tool chỉ ĐỌC dữ liệu: không lưu mật khẩu, không điền mã xác nhận, không ký, không nộp hồ sơ thay bạn. "
    "Đăng nhập bằng MST khác công ty đang mở thì tool không lấy.")

# ---------------------------------------------------------------- nhat ky: khong dau -> co dau
_VN = [
    (r"^San sang\. Bam 'Tai du lieu' - lan dau tool se xin ban bam dung chuc nang mot lan de hoc\.$",
     "Sẵn sàng. Bấm 'Tải dữ liệu' – lần đầu tool sẽ xin bạn bấm dùng chức năng một lần để học."),
    (r"^Da mo Chrome\. Hay dang nhap bang tai khoan doanh nghiep cua ban\.$",
     "Đã mở Chrome. Hãy đăng nhập bằng tài khoản doanh nghiệp của bạn."),
    (r"^Dang cho ban dang nhap trong cua so Chrome vua mo\.\.\.$", "Đang chờ bạn đăng nhập trong cửa sổ Chrome vừa mở..."),
    (r"^Hay bam '(.*)' tren cong, nhap ngay (.*) - (.*) roi bam Tra cuu\.$", r"Hãy bấm '\1' trên cổng, nhập ngày \2 - \3 rồi bấm Tra cứu."),
    (r"^(.*): da lay (\d+) ban ghi \(trang (\d+)\)$", r"\1: đã lấy \2 bản ghi (trang \3)"),
    (r"^(.*): man hinh co ma xac nhan - hay tu nhap (.*) - (.*) va ma xac nhan roi bam Tim kiem\.?$",
     r"\1: màn hình có mã xác nhận – hãy tự nhập \2 - \3 và mã xác nhận rồi bấm Tìm kiếm."),
    (r"^(.*): da nhan (\d+) ban ghi\.$", r"\1: đã nhận \2 bản ghi."),
    (r"^(.*): (\d+)/(\d+) doan, tong (\d+) ban ghi$", r"\1: \2/\3 đoạn, tổng \4 bản ghi"),
    (r"^Da tai (\d+) tep dinh kem\.\.\.$", r"Đã tải \1 tệp đính kèm..."),
    (r"^Da doc (\d+) dong \(trang (\d+)\)$", r"Đã đọc \1 dòng (trang \2)"),
    (r"^KHAC_MST:? dang nhap cong bang MST (\S+) - khong phai cong ty dang mo \(MST ([^)]*)\)\..*$",
     r"KHÔNG LẤY: đang đăng nhập cổng bằng MST \1 – không phải công ty đang mở (MST \2). "
     r"Đăng xuất, đăng nhập đúng tài khoản công ty rồi làm lại."),
    (r"^Man hinh nay co ma xac nhan nen khong hoc duong goi de phat lai\..*$",
     "Màn hình này có mã xác nhận nên không dạy tool tự lấy được – dùng 'Lấy bảng đang mở trên cổng': "
     "bạn tự nhập mã, tra cứu rồi bấm 'Lấy bảng này'."),
    (r"^Da hoc xong cach lay \((\d+) ban ghi mau\)\.$", r"Đã học xong cách lấy (\1 bản ghi mẫu)."),
    (r"^Man hinh '(.*)' co ma xac nhan \(captcha\)\..*$",
     r"Màn hình '\1' có mã xác nhận (captcha) – tool không điền mã; dùng 'Lấy bảng đang mở trên cổng' và tự nhập mã trên cổng."),
    (r"^Chua hoc cach lay '(.*)'\..*$", r"Chưa học cách lấy '\1'. Bấm 'Dạy tool cách lấy' một lần rồi thử lại."),
    (r"^Cong tra ve ma (\S+) cho '(.*?)'\..*$",
     r"Cổng trả về mã \1 cho '\2' – có thể phiên đăng nhập đã hết hạn (đăng nhập lại rồi thử lại) hoặc cổng đã đổi "
     r"đường dẫn (bấm 'Dạy tool cách lấy' để học lại)."),
    (r"^Chua hoc duoc nhom nao: (.*)$", r"Chưa học được nhóm nào: \1"),
    (r"^Da ghi (\d+) dong: (.*)$", r"Đã ghi \1 dòng: \2"),
    (r"^Chua co cach tu lay: (.*) - hay mo tung man hinh tren cong, tra cuu roi bam 'Lay bang nay'\.$",
     r"Chưa có cách tự lấy: \1 – hãy mở từng màn hình trên cổng, tra cứu rồi bấm 'Lấy bảng này'."),
    (r"^Xong: (\d+) dong, (\d+) tep dinh kem\. File: (.*)$", r"Xong: \1 dòng, \2 tệp đính kèm. Tệp: \3"),
    (r"^CAN_NHAP_CAPTCHA (.*?): can ban tu nhap ma xac nhan.*$",
     r"CẦN BẠN NHẬP MÃ XÁC NHẬN: màn hình '\1' – nhập khoảng ngày và mã xác nhận trên cửa sổ Chrome rồi bấm Tìm kiếm "
     r"(tool không điền mã thay). Các nhóm khác đã được tải xong."),
    (r"^CAN_DAY_TOOL (.*)$",
     r"Nhóm chưa dạy tool cách lấy: \1 – bấm 'Dạy tool cách lấy' một lần cho từng nhóm (lần sau sẽ tự tải)."),
    (r"^TOM_TAT (.*)$", r"Tóm tắt lượt tự động: \1."),
    (r"^CAPTCHA_CHUA_NHAP (.*)$", r"Chưa nhận được dữ liệu vì chưa nhập mã xác nhận: \1 – bấm 'Tải dữ liệu' để làm lại riêng nhóm này."),
    (r"^CHUA_HOC (.*)$", r"Chưa dạy tool cách lấy: \1."),
    (r"^Dang nhap xong - dang tu tim va tai noi dung moi tu (\S+) den (\S+)\.\.\.$",
     r"Đã đăng nhập – đang tự tìm và tải nội dung mới từ \1 đến \2..."),
    (r"^Da mo Chrome\. Hay dang nhap bang tai khoan doanh nghiep - dang nhap xong tool TU DONG tim va tai moi noi dung moi\.$",
     "Đã mở Chrome. Hãy đăng nhập bằng tài khoản doanh nghiệp – đăng nhập xong tool TỰ ĐỘNG tìm và tải mọi nội dung mới."),
    (r"^Chua chon nhom nao\.$", "Chưa chọn nhóm nào."),
    (r"^LOI: ngay khong hop le - nhap dang dd/mm/yyyy\.$", "Ngày không hợp lệ – nhập dạng dd/mm/yyyy."),
    (r"^LOI: khoang ngay khong hop le - Tu ngay phai truoc Den ngay, trong nam 2000 - (\d+)\.$",
     r"Khoảng ngày không hợp lệ – Từ ngày phải trước Đến ngày, trong năm 2000 - \1."),
    (r"^Chon nhom can day roi bam lai\.$", "Chọn nhóm cần dạy rồi bấm lại."),
    (r"^Het thoi gian cho dang nhap\.$", "Hết thời gian chờ đăng nhập."),
    (r"^Mat ket noi voi Chrome \(cua so Chrome rieng da dong\?\)\.$", "Mất kết nối với Chrome (cửa sổ Chrome riêng đã đóng?)."),
    (r"^Khong tim thay Chrome tren may\. Hay cai Google Chrome roi thu lai\.$",
     "Không tìm thấy Chrome trên máy. Hãy cài Google Chrome rồi thử lại."),
    (r"^Khong mo duoc Chrome: (.*)$", r"Không mở được Chrome: \1"),
    (r"^Chrome khong mo duoc trang Cong dich vu cong \(qua 60 giay\)\.$", "Chrome không mở được trang Cổng dịch vụ công (quá 60 giây)."),
    (r"^Chua lay bang nao \(khong bam 'Lay bang nay'\)$", "Chưa lấy bảng nào (chưa bấm 'Lấy bảng này')."),
    (r"^Khong co ban ghi nao trong khoang ngay da chon$", "Không có bản ghi nào trong khoảng ngày đã chọn."),
    (r"^Chua hoc duoc nhom nao: (.*)$", r"Chưa học được nhóm nào: \1"),
    (r"^Chuc nang '(.*)' chi tra duoc ho so nop TRUOC ngay (\S+)\. Khoang ngay ban chon nam hoan toan sau moc do nen khong co gi de lay\.$",
     r"Chức năng '\1' chỉ tra được hồ sơ nộp TRƯỚC ngày \2. Khoảng ngày bạn chọn nằm hoàn toàn sau mốc đó nên không có gì để lấy."),
    (r"^Chuc nang '(.*)' chi tra duoc ho so nop TRUOC ngay (\S+) - da tu cat khoang ngay lai den (\S+)\.$",
     r"Chức năng '\1' chỉ tra được hồ sơ nộp TRƯỚC ngày \2 – đã tự cắt khoảng ngày lại đến \3."),
]
_VN = [(re.compile(a), b) for a, b in _VN]


def _gd167_ico(cs):
    """GD167: bieu tuong cua so = logo UNESCO (AIHoaDon/giao-dien/unesco.ico); thieu tep / loi -> bo qua"""
    try:
        p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "giao-dien", "unesco.ico")
        if os.path.exists(p):
            cs.iconbitmap(default=p)
    except Exception:
        pass


def viet(s, nhom=None):
    """Thong bao khong dau cua tool -> co dau (chi de hien; file nhat ky giu nguyen). Khong nhan ra thi giu nguyen."""
    s = (s or "").strip()
    m = re.match(r"^\[(\w+)\] (.+)$", s, re.S)          # "[MA] ..." -> giu ma nhom, dich phan sau
    if m:
        return "[%s] %s" % (m.group(1), viet(m.group(2), nhom))
    m = re.match(r"^DA_HOC_XONG (\S+)(?: \| chua hoc: (.*))?$", s)
    if m:
        return "Đã học xong: %s%s" % (m.group(1), ("; chưa học: " + _chua_hoc(m.group(2))) if m.group(2) else "")
    m = re.match(r"^Chua hoc duoc nhom nao: (.*)$", s)
    if m:
        return "Chưa học được nhóm nào: " + _chua_hoc(m.group(1))
    if nhom:
        for ma, ten in sorted(((k, v.get("ten", "")) for k, v in nhom.items()), key=lambda x: -len(x[1])):
            if ten and ten in s and ma in TEN_VN:
                s = s.replace(ten, TEN_VN[ma])
    for r, thay in _VN:
        if r.match(s):
            return r.sub(thay, s)
    return s


def _chua_hoc(s):
    """'HSDVC: man hinh co ma xac nhan - dung Hung ket qua; NV: <loi>' -> co dau (nut 'Hung ket qua' nay la 'Lay bang dang mo')."""
    ra = []
    for p in (s or "").split("; "):
        p = re.sub(r"man hinh co ma xac nhan - dung Hung ket qua",
                   "màn hình có mã xác nhận – dùng 'Lấy bảng đang mở trên cổng'", p)
        p = p.replace("khong co nhom hop le", "không có nhóm hợp lệ")
        ra.append(p)
    return "; ".join(ra)


def loai_dong(s):
    """Bieu tuong dong nhat ky theo thong bao goc (khong dau): tt / cho / xong / canh / loi."""
    s = re.sub(r"^\[\w+\] ", "", (s or "").strip())
    if re.search(r"^(CAN_NHAP_CAPTCHA|CAPTCHA_CHUA_NHAP)", s):
        return "cho"
    if re.search(r"^(CAN_DAY_TOOL|CHUA_HOC)", s):
        return "canh"
    if re.search(r"^TOM_TAT", s):
        return "xong"
    if re.search(r"^(KHAC_MST|LOI|Het thoi gian|Mat ket noi|Khong tim thay Chrome|Khong mo duoc|Chrome khong mo|Cong tra ve)", s):
        return "loi"
    if re.search(r"^(Dang cho|Hay bam)|man hinh co ma xac nhan - hay tu nhap", s):
        return "cho"
    if re.search(r"^(Xong:|Da ghi|Da doc|Da tai|Da hoc xong|DA_HOC_XONG)|: da lay \d|: da nhan \d", s):
        return "xong"
    if re.search(r"^(Chua|Chuc nang '|Man hinh|Khong co ban ghi)", s):          # (Chua hoc duoc nhom nao -> canh)
        return "canh"
    return "tt"


def doc_ngay_vn(s):
    s = (s or "").strip()
    for m in ("%d/%m/%Y", "%d-%m-%Y", "%Y-%m-%d"):
        try:
            return datetime.strptime(s, m).date()
        except Exception:
            pass
    return None


# ---------------------------------------------------------------- giao dien
_GD_CUOI = None          # cua so dang mo (de kiem thu)


def mo(ts, T):
    """ts: tham so cua tool ; T: module tool_dvc_unesco (chay, NHOM, doc_duong_da_hoc, LOG ...)."""
    import tkinter as tk
    from tkinter import font as tkfont
    from tkinter import messagebox

    global _GD_CUOI
    root = tk.Tk()
    _gd167_ico(root)
    try:
        _GD_CUOI = GiaoDien(root, ts, T, tk, tkfont, messagebox)
    except Exception:
        try:
            root.destroy()
        except Exception:
            pass
        raise
    root.mainloop()
    return True


def _bo_tron(cv, x0, y0, x1, y1, r, **kw):
    r = max(0, min(r, (x1 - x0) / 2.0, (y1 - y0) / 2.0))
    p = [x0 + r, y0, x1 - r, y0, x1, y0, x1, y0 + r, x1, y1 - r, x1, y1, x1 - r, y1, x0 + r, y1, x0, y1, x0, y1 - r, x0, y0 + r, x0, y0]
    return cv.create_polygon(p, smooth=True, **kw)


class GiaoDien(object):
    def __init__(self, root, ts, T, tk, tkfont, messagebox):
        self.root, self.ts, self.T, self.tk, self.mb = root, ts, T, tk, messagebox
        self.q = queue.Queue()
        self.anh = {}
        self.dang_chay = 0
        self.hang_le = False
        self.da_hien = set()
        self.co_ghi = False
        self.lan_bam = 0.0
        self.mo_ta_tl = []                       # dong mo ta o Tro ly AI (an khi cua so qua thap)
        self.dong_cuoi = [None, None, 0]
        ho = dict((f.lower(), f) for f in tkfont.families())
        fam = next((ho[f.lower()] for f in ("Segoe UI", "Tahoma", "Arial", "DejaVu Sans") if f.lower() in ho), "TkDefaultFont")
        self.F = lambda co, dam=False: (fam, co, "bold" if dam else "normal")
        root.title("UNESCO XI + AI - Cổng dịch vụ công Thuế")
        sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
        self.gon = sh < 900                      # man hinh thap (1366x768, 1280x800...): thu gon khoang cach
        self.hep = sw < 1240                     # man hinh hep: nut duoi nho lai (khong mat nut Dong)
        w, h = min(1180, sw - 40), min(860, sh - 130)          # chua cho thanh tieu de + thanh tac vu Windows
        root.geometry("%dx%d+%d+%d" % (w, h, max(0, (sw - w) // 2), max(0, (sh - h - 70) // 2)))
        root.minsize(min(940 if self.hep else 1120, w), min(640, h))
        root.configure(bg=MAU["trang"])
        if sw < 1240 or sh <= 800:
            try:
                root.state("zoomed")             # Windows: phong to cho vua man hinh nho
            except Exception:
                pass
        g = 6 if self.gon else 10
        self._banner()
        ngoai = tk.Frame(root, bg=MAU["trang"])
        ngoai.pack(fill="both", expand=True, padx=16, pady=(g, g))
        self._nut_duoi(ngoai).pack(side="bottom", fill="x")          # nut luon thay (cua so thap thi nhat ky co lai)
        than = tk.Frame(ngoai, bg=MAU["trang"])
        than.pack(side="top", fill="both", expand=True)
        than.grid_columnconfigure(0, weight=1)
        than.grid_columnconfigure(1, weight=0, minsize=300)
        than.grid_rowconfigure(3, weight=1, minsize=110)          # nhat ky luon con it nhat vai dong
        self._tieu_de(than).grid(row=0, column=0, sticky="ew", pady=(0, g))
        self._the_ngay(than).grid(row=1, column=0, sticky="ew", pady=(0, g))
        self._the_nhom(than).grid(row=2, column=0, sticky="ew", pady=(0, g))
        self._the_tro_ly(than).grid(row=0, column=1, rowspan=3, sticky="nsew", padx=(14, 0), pady=(0, g))
        self._the_nhat_ky(than).grid(row=3, column=0, columnspan=2, sticky="nsew", pady=(0, g))
        root.protocol("WM_DELETE_WINDOW", self.dong)
        try:
            T.BAO_GD = self.bao          # ly do ket thuc (ghi_khong_co) cung hien trong nhat ky
        except Exception:
            pass
        if ts.get("tudong"):                       # GD189: mo tu nut 'Mo Cong dich vu cong' -> tu chay, khong can bam them
            self.bao("San sang. Tool dang mo Chrome - ban dang nhap, tool tu tim va tai noi dung moi.")
            root.after(900, self.chay_tu_dong)
        else:
            self.bao("San sang. Bam 'Tai du lieu' - lan dau tool se xin ban bam dung chuc nang mot lan de hoc.")
        root.after(100, self._xu_ly_hang_doi)

    # ------------------------------------------------------------ tien ich
    def hinh(self, ten):
        if ten in self.anh:
            return self.anh[ten]
        p = os.path.join(HINH, ten + ".png")
        im = None
        if os.path.exists(p):
            try:
                im = self.tk.PhotoImage(file=p)
            except Exception:
                im = None
        self.anh[ten] = im
        return im

    def the(self, cha, nen=None, vien=None, nen_cha=None, r=12, dem=None, gian=False, rong=10):
        """Khung bo goc: Canvas ve nen + Frame ben trong (.trong). gian=True: noi dung gian theo chieu cao the.
           rong: be rong xin (Canvas mac dinh xin ~380 diem anh -> cot phai qua rong)."""
        tk = self.tk
        nen = nen or MAU["the"]
        vien = vien or MAU["vien"]
        nen_cha = nen_cha or cha.cget("bg")
        if dem is None:
            dem = 9 if self.gon else 12
        cv = tk.Canvas(cha, bg=nen_cha, highlightthickness=0, bd=0, height=40, width=rong)
        cv.trong = tk.Frame(cv, bg=nen)
        cid = cv.create_window(dem, dem, window=cv.trong, anchor="nw")

        def ve(e=None):
            w, h = cv.winfo_width(), cv.winfo_height()
            cv.delete("nen")
            _bo_tron(cv, 1, 1, w - 2, h - 2, r, fill=nen, outline=vien, tags="nen")
            cv.tag_lower("nen")
            cv.itemconfigure(cid, width=max(10, w - 2 * dem))
            if gian:
                cv.itemconfigure(cid, height=max(10, h - 2 * dem))

        def co(e=None):
            if not gian:
                hh = cv.trong.winfo_reqheight() + 2 * dem
                if int(float(cv.cget("height"))) != hh:
                    cv.configure(height=hh)
        cv.bind("<Configure>", ve)
        cv.trong.bind("<Configure>", co)
        return cv

    def nhan(self, cha, chu, co=10, dam=False, mau=None, **kw):
        return self.tk.Label(cha, text=chu, font=self.F(co, dam), fg=mau or MAU["chu"], bg=cha.cget("bg"), **kw)

    def dau_the(self, cha, bt, chu, phu=""):
        f = self.tk.Frame(cha, bg=cha.cget("bg"))
        im = self.hinh(bt)
        if im is not None:
            self.tk.Label(f, image=im, bg=f.cget("bg")).pack(side="left", padx=(0, 10))
        self.nhan(f, chu, 12, True, MAU["xanh_dam"]).pack(side="left")
        if phu:
            self.nhan(f, phu, 10, False, MAU["chu_nhat"]).pack(side="left", padx=(6, 0), pady=(2, 0))
        return f

    def nut(self, cha, chu, bt, lenh, rong=220, cao=46, chinh=False):
        tk = self.tk
        nen_cha = cha.cget("bg")
        cv = tk.Canvas(cha, width=rong, height=cao, bg=nen_cha, highlightthickness=0, bd=0, cursor="hand2")
        mau = (MAU["la"], MAU["la_dam"], "#ffffff", MAU["la_dam"]) if chinh else ("#ffffff", "#c9d6e8", MAU["xanh_dam"], "#eaf2fd")
        im = self.hinh(bt)

        def ve(nen):
            cv.delete("all")
            _bo_tron(cv, 1, 1, rong - 2, cao - 2, 8, fill=nen, outline=mau[1], width=1)
            f = self.F(10, True)
            tw = tkfont_do(cv, chu, f)
            iw = (im.width() + 10) if im is not None else 0
            x = (rong - tw - iw) / 2.0
            if im is not None:
                cv.create_image(x + im.width() / 2.0, cao / 2.0, image=im)
            cv.create_text(x + iw, cao / 2.0, text=chu, anchor="w", font=f, fill=mau[2])
        ve(mau[0])
        cv.bind("<Enter>", lambda e: ve(mau[3]))
        cv.bind("<Leave>", lambda e: ve(mau[0]))
        cv.bind("<ButtonRelease-1>", lambda e: lenh() if 0 <= e.x < rong and 0 <= e.y < cao else None)          # keo ra ngoai roi tha = huy
        return cv

    def huy_hieu(self, cha, ma):
        cv = self.tk.Canvas(cha, width=98, height=24, bg=cha.cget("bg"), highlightthickness=0, bd=0)
        cv.ma = ma
        self.ve_huy_hieu(cv)
        return cv

    def ve_huy_hieu(self, cv):
        ma = cv.ma
        n = self.T.NHOM.get(ma) or {}
        if n.get("captcha"):
            chu, nen, mau = "(tự tra cứu)", MAU["nen_xanh"], MAU["xanh"]
        elif self.T.doc_duong_da_hoc(ma):
            chu, nen, mau = "(đã học)", MAU["nen_la"], MAU["chu_la"]
        else:
            chu, nen, mau = "(chưa học)", MAU["nen_cam"], MAU["cam"]
        cv.delete("all")
        _bo_tron(cv, 1, 1, 96, 22, 11, fill=nen, outline=nen)
        cv.create_text(49, 12, text=chu, font=self.F(9), fill=mau)

    # ------------------------------------------------------------ cac phan
    def _banner(self):
        tk = self.tk
        H = 64 if self.gon else 78
        y = lambda v: int(round(v * H / 78.0))
        cv = tk.Canvas(self.root, height=H, bg=MAU["banner1"], highlightthickness=0, bd=0)
        cv.pack(fill="x")
        cty = re.sub(r"\s+", " ", (self.ts.get("cty") or "")).strip()
        mst = (self.ts.get("mst") or "").strip()

        def ve(e=None):
            w = cv.winfo_width()
            cv.delete("all")
            a = (3, 33, 79)
            b = (10, 63, 145)
            buoc = 6
            for x in range(0, w, buoc):
                t = min(1.0, x / float(max(1, w * 0.75)))
                c = "#%02x%02x%02x" % tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))
                cv.create_rectangle(x, 0, x + buoc, H, fill=c, outline=c)
            im = self.hinh("logo")
            if im is not None:
                cv.create_image(46, H / 2.0, image=im)
            co = 19 if self.gon else 22
            cv.create_text(84, y(30), text="UNESCO XI", anchor="w", font=self.F(co, True), fill="#ffffff", tags="td")
            x1 = cv.bbox("td")[2] + 8
            cv.create_text(x1, y(30), text="+ AI", anchor="w", font=self.F(co, True), fill="#5fd0ff")
            cv.create_text(86, y(58), anchor="w", font=self.F(8), fill="#c7d9f5",
                           text="HÓA ĐƠN ĐIỆN TỬ · SỔ PHỤ · TỜ KHAI HẢI QUAN · BẢNG LƯƠNG · KẾT CHUYỂN CUỐI KỲ")
            # hop cong ty (ten that cua cong ty dang mo + MST) - an khi cua so hep
            xp = w - 16
            if (cty or mst) and w >= 1060:
                bw = 270
                _bo_tron(cv, xp - bw, y(10), xp, y(68), 8, fill="#0c3a80", outline="#2a5aa5")
                ten = (cty[:64] + ("..." if len(cty) > 64 else "")) if cty else "CÔNG TY ĐANG MỞ"
                cv.create_text(xp - bw + 12, y(30), text=ten, anchor="w", width=bw - 24, font=self.F(9 if len(ten) < 60 else 8, True),
                               fill="#ffffff")
                cv.create_text(xp - bw + 12, y(56), text="MST: " + (mst or "-"), anchor="w", font=self.F(9), fill="#cfe0fb")
                xp -= bw + 12
            # nut Huong dan (that: mo huong dan dung)
            bw = 132
            _bo_tron(cv, xp - bw, y(20), xp, y(58), 8, fill=MAU["cam_nut"], outline=MAU["cam_nut"], tags="hd")
            cv.create_text(xp - bw / 2.0, y(39), text="?  Hướng dẫn", font=self.F(10, True), fill="#ffffff", tags="hd")
        # gan mot lan (the "hd" con hieu luc sau delete("all")) - gan trong ve() thi moi lan doi kich thuoc them lenh Tcl moi
        cv.tag_bind("hd", "<ButtonRelease-1>", lambda e: self.mb.showinfo("Hướng dẫn - Cổng dịch vụ công", HUONG_DAN,
                                                                           parent=self.root))
        cv.tag_bind("hd", "<Enter>", lambda e: cv.configure(cursor="hand2"))
        cv.tag_bind("hd", "<Leave>", lambda e: cv.configure(cursor=""))
        cv.bind("<Configure>", ve)

    def _tieu_de(self, cha):
        tk = self.tk
        f = tk.Frame(cha, bg=cha.cget("bg"))
        im = self.hinh("ngan_hang")
        if im is not None:
            tk.Label(f, image=im, bg=f.cget("bg")).pack(side="left", anchor="n", padx=(0, 14))
        p = tk.Frame(f, bg=f.cget("bg"))
        p.pack(side="left", fill="x", expand=True)
        h = tk.Frame(p, bg=p.cget("bg"))
        h.pack(anchor="w", fill="x")
        td = self.nhan(h, "Tải dữ liệu từ Cổng dịch vụ công Thuế", 16 if self.gon else 18, True, MAU["xanh_dam"])
        td.pack(side="left")
        mien = self.nhan(h, "(dichvucong.gdt.gov.vn)", 11, False, MAU["chu_nhat"])
        mien.pack(side="left", padx=(8, 0), pady=(6, 0))

        def vua(e):                                # khong du cho thi an ten mien (khong de bi cat doi)
            du = td.winfo_reqwidth() + mien.winfo_reqwidth() + 12 <= e.width
            if du and not mien.winfo_manager():
                mien.pack(side="left", padx=(8, 0), pady=(6, 0))
            elif not du and mien.winfo_manager():
                mien.pack_forget()
        h.bind("<Configure>", vua)
        mo_ta = self.nhan(p, ("Bạn tự đăng nhập bằng tài khoản doanh nghiệp trong cửa sổ Chrome mà tool mở ra. Tool không lưu mật "
                              "khẩu, không điền mã xác nhận (captcha), không ký hay nộp hồ sơ thay bạn. Lần đầu mỗi chức năng, "
                              "tool xin bạn bấm dùng chức năng đó một lần để học cách lấy dữ liệu."),
                          9 if self.gon else 10, False, MAU["chu_nhat"], justify="left", wraplength=700)
        mo_ta.pack(anchor="w", fill="x", pady=(4, 0))
        p.bind("<Configure>", lambda e: mo_ta.configure(wraplength=max(300, e.width - 10)))

        def thap(e):                               # cua so qua thap (man hinh 720 dong): bo dong mo ta de nhat ky con cho
            if e.widget is not self.root:
                return
            can_an = e.height < 680
            if can_an and mo_ta.winfo_manager():
                mo_ta.pack_forget()
                for m in self.mo_ta_tl:
                    m.pack_forget()
            elif not can_an and not mo_ta.winfo_manager():
                mo_ta.pack(anchor="w", fill="x", pady=(4, 0))
                for m in self.mo_ta_tl:
                    m.pack(anchor="w", fill="x", pady=(2, 0))
        self.root.bind("<Configure>", thap, add="+")
        return f

    def _o_ngay(self, cha, gia_tri):
        tk = self.tk
        k = tk.Frame(cha, bg="#ffffff", highlightthickness=1, highlightbackground="#c9d6e8", highlightcolor=MAU["xanh"])
        e = tk.Entry(k, width=15, relief="flat", font=self.F(11), bg="#ffffff", fg=MAU["chu"], bd=0, highlightthickness=0,
                     insertbackground=MAU["chu"])
        e.pack(side="left", padx=(10, 4), pady=4 if self.gon else 6)
        e.insert(0, gia_tri)
        tk.Frame(k, bg="#dfe7f2", width=1).pack(side="left", fill="y")
        im = self.hinh("lich_nho")
        b = tk.Label(k, image=im, text="" if im else "...", bg="#f4f8fd", cursor="hand2", padx=8)
        b.pack(side="left", fill="y")
        b.bind("<Button-1>", lambda ev: self.lich(e))
        return k, e

    def _the_ngay(self, cha):
        cv = self.the(cha)
        t = cv.trong
        self.dau_the(t, "lich", "Khoảng thời gian lấy dữ liệu").pack(anchor="w", pady=(0, 10))
        h = self.tk.Frame(t, bg=t.cget("bg"))
        h.pack(anchor="w", fill="x")
        tu = self.ts.get("tu") or date(date.today().year, 1, 1)
        den = self.ts.get("den") or date.today()
        self.nhan(h, "Từ ngày (dd/mm/yyyy):", 10).pack(side="left", padx=(6, 10))
        k1, self.e_tu = self._o_ngay(h, tu.strftime("%d/%m/%Y"))
        k1.pack(side="left")
        self.nhan(h, "Đến ngày:", 10).pack(side="left", padx=(40, 10))
        k2, self.e_den = self._o_ngay(h, den.strftime("%d/%m/%Y"))
        k2.pack(side="left")
        return cv

    def _the_nhom(self, cha):
        tk = self.tk
        cv = self.the(cha)
        t = cv.trong
        self.dau_the(t, "lop", "Nhóm dữ liệu", "(Chọn các loại dữ liệu cần tải)").pack(anchor="w", pady=(0, 8))
        luoi = tk.Frame(t, bg=t.cget("bg"))
        luoi.pack(fill="x")
        luoi.grid_columnconfigure(0, weight=1, uniform="c")
        luoi.grid_columnconfigure(1, weight=1, uniform="c")
        self.chon, self.huy = {}, {}
        for i, ma in enumerate(self.T.NHOM.keys()):
            v = tk.IntVar(value=0 if ma == "HDHL" else 1)
            self.chon[ma] = v
            o = self.the(luoi, nen=MAU["o"], vien=MAU["vien_o"], r=8, dem=4 if self.gon else 6)
            o.grid(row=i // 2, column=i % 2, sticky="ew", padx=(0 if i % 2 == 0 else 6, 6 if i % 2 == 0 else 0),
                   pady=2 if self.gon else 3)
            q = o.trong
            on, off = self.hinh("o_bat"), self.hinh("o_tat")
            if on is not None and off is not None:
                cb = tk.Checkbutton(q, variable=v, image=off, selectimage=on, indicatoron=False, bd=0, relief="flat",
                                    bg=q.cget("bg"), activebackground=q.cget("bg"), selectcolor=q.cget("bg"),
                                    highlightthickness=0, cursor="hand2", offrelief="flat", overrelief="flat")
            else:
                cb = tk.Checkbutton(q, variable=v, bg=q.cget("bg"), activebackground=q.cget("bg"), highlightthickness=0)
            cb.pack(side="left", padx=(6, 10), pady=2 if self.gon else 4)
            hh = self.huy_hieu(q, ma)              # nhan (da hoc / chua hoc) xep truoc: chat cho thi ten bi cat, nhan van du
            hh.pack(side="right", padx=(6, 4))
            self.huy[ma] = hh
            lb = self.nhan(q, TEN_VN.get(ma, self.T.NHOM[ma].get("ten", ma)), 11, cursor="hand2", anchor="w")
            lb.pack(side="left", fill="x", expand=True)
            lb.bind("<Button-1>", lambda e, vv=v: vv.set(0 if vv.get() else 1))
        return cv

    def _the_tro_ly(self, cha):
        tk = self.tk
        cv = self.the(cha, nen=MAU["nen_tl"], vien=MAU["vien_tl"], dem=14, rong=300)
        t = cv.trong
        h = tk.Frame(t, bg=t.cget("bg"))
        h.pack(anchor="w", pady=(0, 12))
        im = self.hinh("robot")
        if im is not None:
            tk.Label(h, image=im, bg=h.cget("bg")).pack(side="left", padx=(0, 10))
        self.nhan(h, "Trợ lý AI", 15, True, MAU["xanh_dam"]).pack(side="left")
        o = self.the(t, nen=MAU["nen_tl2"], vien=MAU["vien_tl2"], r=10, dem=12)
        o.pack(fill="x")
        q = o.trong
        h2 = tk.Frame(q, bg=q.cget("bg"))
        h2.pack(anchor="w", pady=(0, 8))
        im = self.hinh("tich_xanh")
        if im is not None:
            tk.Label(h2, image=im, bg=h2.cget("bg")).pack(side="left", padx=(0, 8))
        self.nhan(h2, "AI sẽ hỗ trợ bạn:", 11, True, MAU["la_dam"]).pack(side="left")
        muc = [("kinh_lup", "Tự động nhận diện", "Nhận diện loại bảng đang mở trên Cổng dịch vụ công Thuế."),
               ("banh_rang", "Học cấu trúc bảng", "Tự học cách lấy dữ liệu theo từng chức năng (chỉ cần dạy 1 lần)."),
               ("csdl", "Đồng bộ vào UNESCO", "Trích xuất kết quả để phần mềm nạp vào thẻ Cổng thuế.")]
        for i, (bt, td, mt) in enumerate(muc):
            if i:
                tk.Frame(q, bg=MAU["vien_tl2"], height=1).pack(fill="x", pady=8)
            r = tk.Frame(q, bg=q.cget("bg"))
            r.pack(fill="x", anchor="w")
            o2 = tk.Canvas(r, width=44, height=44, bg=q.cget("bg"), highlightthickness=0, bd=0)
            _bo_tron(o2, 1, 1, 42, 42, 8, fill=MAU["o_tl"], outline="#b9e2c8")
            im = self.hinh(bt)
            if im is not None:
                o2.create_image(22, 22, image=im)
            o2.pack(side="left", anchor="n", padx=(0, 10))
            c = tk.Frame(r, bg=r.cget("bg"))
            c.pack(side="left", fill="x", expand=True)
            self.nhan(c, td, 11, True, MAU["xanh_dam"]).pack(anchor="w")
            m = self.nhan(c, mt, 9, False, MAU["chu_nhat"], justify="left", wraplength=190, anchor="w")
            m.pack(anchor="w", fill="x", pady=(2, 0))
            self.mo_ta_tl.append(m)
            m.bind("<Configure>", lambda e, mm=m: mm.configure(wraplength=max(120, e.width - 4)))
        return cv

    def _the_nhat_ky(self, cha):
        tk = self.tk
        cv = self.the(cha, gian=True, nen=MAU["nen_tl"], vien=MAU["vien_tl"])
        t = cv.trong
        self.dau_the(t, "giay", "Trạng thái & nhật ký").pack(anchor="w", pady=(0, 8))
        k = tk.Frame(t, bg="#ffffff", highlightthickness=1, highlightbackground=MAU["vien_o"])
        k.pack(fill="both", expand=True)
        thanh = tk.Scrollbar(k)
        thanh.pack(side="right", fill="y")
        self.nk = tk.Text(k, wrap="word", font=self.F(10), relief="flat", bd=0, bg="#ffffff", fg=MAU["chu"], height=6,
                          padx=10, pady=6, yscrollcommand=thanh.set, cursor="arrow", spacing1=4, spacing3=4,
                          tabs=("76", "104"))
        self.nk.pack(side="left", fill="both", expand=True)
        thanh.configure(command=self.nk.yview)
        self.nk.tag_configure("gio", foreground="#4a5873")
        self.nk.tag_configure("dong", lmargin2=104)          # dong dai xuong hang: thut vao thang cot noi dung
        self.nk.tag_configure("le", background=MAU["dong_le"])
        self.nk.tag_configure("loi", foreground="#c62828")
        self.nk.configure(state="disabled")
        return cv

    def _nut_duoi(self, cha):
        tk = self.tk
        f = tk.Frame(cha, bg=cha.cget("bg"))
        r = (250, 300, 190, 110) if self.hep else (300, 360, 250, 150)
        g = 10 if self.hep else 14
        self.nut(f, "Lấy bảng đang mở trên cổng", "nut_bang", self.chay_doc_bang, rong=r[0]).pack(side="left")
        self.nut(f, "Dạy tool cách lấy (1 lần/chức năng)", "nut_mu", self.chay_hoc, rong=r[1]).pack(side="left", padx=(g, 0))
        self.nut(f, "Tải dữ liệu", "nut_tai", self.chay_tai, rong=r[2], chinh=True).pack(side="left", padx=(g, 0))
        self.nut(f, "Đóng", "nut_dong", self.dong, rong=r[3]).pack(side="right")
        return f

    # ------------------------------------------------------------ lich chon ngay
    def lich(self, o):
        tk = self.tk
        d0 = doc_ngay_vn(o.get()) or date.today()
        top = tk.Toplevel(self.root)
        top.title("Chọn ngày")
        top.transient(self.root)
        top.resizable(False, False)
        top.configure(bg="#ffffff")
        tt = {"nam": d0.year, "thang": d0.month}
        dau = tk.Frame(top, bg="#ffffff")
        dau.pack(fill="x", padx=8, pady=6)
        nhan = tk.Label(dau, font=self.F(10, True), bg="#ffffff", fg=MAU["xanh_dam"])
        luoi = tk.Frame(top, bg="#ffffff")
        luoi.pack(padx=8, pady=(0, 8))

        def ve():
            for w in luoi.winfo_children():
                w.destroy()
            nhan.configure(text="Tháng %02d/%d" % (tt["thang"], tt["nam"]))
            for i, t in enumerate(("T2", "T3", "T4", "T5", "T6", "T7", "CN")):
                tk.Label(luoi, text=t, font=self.F(9, True), bg="#ffffff", fg=MAU["chu_nhat"], width=4).grid(row=0, column=i)
            d = date(tt["nam"], tt["thang"], 1)
            cot, hang = d.weekday(), 1
            while d.month == tt["thang"]:
                chon = (d == d0)
                b = tk.Label(luoi, text=str(d.day), font=self.F(10, chon), width=4, pady=3, cursor="hand2",
                             bg=MAU["xanh"] if chon else "#ffffff", fg="#ffffff" if chon else MAU["chu"])
                b.grid(row=hang, column=cot)
                b.bind("<Button-1>", lambda e, dd=d: (o.delete(0, "end"), o.insert(0, dd.strftime("%d/%m/%Y")), top.destroy()))
                cot += 1
                if cot == 7:
                    cot, hang = 0, hang + 1
                d = date.fromordinal(d.toordinal() + 1)

        def doi(n):
            m = tt["thang"] + n
            tt["nam"] += (m - 1) // 12
            tt["thang"] = (m - 1) % 12 + 1
            ve()
        tk.Button(dau, text="◀", relief="flat", bg="#ffffff", command=lambda: doi(-1)).pack(side="left")
        nhan.pack(side="left", expand=True)
        tk.Button(dau, text="▶", relief="flat", bg="#ffffff", command=lambda: doi(1)).pack(side="right")
        ve()
        top.update_idletasks()
        x = o.winfo_rootx()
        y = o.winfo_rooty() + o.winfo_height() + 6
        top.geometry("+%d+%d" % (x, y))
        top.bind("<Escape>", lambda e: top.destroy())
        try:
            top.grab_set()
        except Exception:
            pass

    # ------------------------------------------------------------ nhat ky (luong chinh)
    def bao(self, s):
        """Goi tu moi luong: chi dua vao hang doi; luong giao dien ghi ra (tkinter khong an toan khi goi tu luong khac)."""
        self.q.put(("nk", s))

    def _them_dong(self, s):
        if s.startswith("KET_THUC "):                # ghi_khong_co cua tool: ly do ket thuc luot chay
            ly = s[9:].strip()
            if ly.startswith("DA_HOC_XONG"):
                s = ly
            else:
                if not ly or ly in self.da_hien:     # vd. KHAC_MST da hien trong luot nay
                    return
                loai = loai_dong(ly)
                # luot nay da ghi du lieu (nhom da hoc) roi moi het phan doc bang -> khong noi 'khong co du lieu moi'
                dau = "Kết thúc: " if self.co_ghi else "Kết thúc – không có dữ liệu mới: "
                return self._ghi_dong(dau + viet(ly, self.T.NHOM), "loi" if loai == "loi" else "canh")
        if re.match(r"^(Da ghi \d|Xong: )", s):
            self.co_ghi = True
        self.da_hien.add(s)
        if len(self.da_hien) > 500:
            self.da_hien.clear()
        self._ghi_dong(viet(s, self.T.NHOM), loai_dong(s))

    def _ghi_dong(self, chu, loai):
        """Mot dong: gio + bieu tuong + noi dung. Trung dong ngay truoc (vd. 'Dang cho dang nhap' moi 15 giay) -> cap nhat gio + (xN)."""
        nk = self.nk
        nk.configure(state="normal")
        lap = [chu, loai] == self.dong_cuoi[:2]
        if lap:
            self.dong_cuoi[2] += 1
            nk.delete("dong_cuoi", "end-1c")
            le = not self.hang_le
        else:
            self.dong_cuoi = [chu, loai, 1]
            nk.mark_set("dong_cuoi", "end-1c")
            nk.mark_gravity("dong_cuoi", "left")
            le = self.hang_le
            self.hang_le = not self.hang_le
        dau = nk.index("end-1c")
        nk.insert("end", datetime.now().strftime("%H:%M:%S") + "\t", ("gio", "dong"))
        im = self.hinh("nk_" + loai)
        if im is not None:
            nk.image_create("end", image=im, padx=2)
        them = "  (×%d)" % self.dong_cuoi[2] if self.dong_cuoi[2] > 1 else ""
        nk.insert("end", "\t" + chu + them + "\n", (("dong", "loi") if loai == "loi" else ("dong",)))
        if le:
            nk.tag_add("le", dau, "end-1c")
        nk.configure(state="disabled")
        nk.see("end")

    def _xu_ly_hang_doi(self):
        try:
            while True:
                m = self.q.get_nowait()
                if m[0] == "nk":
                    self._them_dong(m[1])
                elif m[0] == "xong":
                    self.dang_chay = max(0, self.dang_chay - 1)
                    for hh in self.huy.values():
                        self.ve_huy_hieu(hh)
        except queue.Empty:
            pass
        except Exception:
            pass
        try:
            self.root.after(150, self._xu_ly_hang_doi)
        except Exception:
            pass

    # ------------------------------------------------------------ chay (giu nguyen ba che do cu cua tool)
    def _ds_chon(self):
        return ",".join([m for m, v in self.chon.items() if v.get()])

    def _chay_nen(self, t):
        import time
        bay_gio = time.time()
        if bay_gio - self.lan_bam < 3:           # bam dup / bam lien: khong mo hai lan chay cung luc (tranh mo Chrome hai lan)
            return
        if self.dang_chay and not self.mb.askyesno(
                "Đang chạy", "Tool đang chạy lượt trước (Chrome đang mở). Dừng lượt đó và chạy lại từ đầu?", parent=self.root):
            return
        self.lan_bam = time.time()
        self.da_hien = set()
        self.co_ghi = False
        self.dang_chay += 1

        def chay():
            try:
                self.T.chay(t, self.bao)
            except Exception as e:
                try:
                    self.T.LOG.loi("Giao dien DVC: loi khi chay", e)
                except Exception:
                    pass
                self.bao("LOI: %s" % str(e)[:200])
            self.q.put(("xong",))
        threading.Thread(target=chay, daemon=True).start()

    def chay_tai(self):
        t = dict(self.ts)
        t["nhom"] = self._ds_chon()
        t["hoc"] = ""
        t["tu"] = doc_ngay_vn(self.e_tu.get()) or self.T.doc_ngay(self.e_tu.get())
        t["den"] = doc_ngay_vn(self.e_den.get()) or self.T.doc_ngay(self.e_den.get())
        if not t["nhom"]:
            self.bao("Chua chon nhom nao.")
            return
        if not t["tu"] or not t["den"]:
            self.bao("LOI: ngay khong hop le - nhap dang dd/mm/yyyy.")
            return
        nam = date.today().year
        if t["tu"] > t["den"] or t["tu"].year < 2000 or t["den"].year > nam + 1:
            self.bao("LOI: khoang ngay khong hop le - Tu ngay phai truoc Den ngay, trong nam 2000 - %d." % (nam + 1))
            return
        self._chay_nen(t)

    def chay_tu_dong(self):
        """GD189: dang nhap xong tu tim + tai moi nhom (khong captcha truoc); nhom captcha thi bao nguoi dung nhap ma."""
        t = dict(self.ts)
        t["nhom"] = ",".join(m for m in self.T.NHOM if m != "KHAC")
        t["hoc"] = ""
        t["tu_dong_chay"] = True
        t["tu"] = doc_ngay_vn(self.e_tu.get()) or self.T.doc_ngay(self.e_tu.get()) or t.get("tu")
        t["den"] = doc_ngay_vn(self.e_den.get()) or self.T.doc_ngay(self.e_den.get()) or t.get("den")
        self._chay_nen(t)

    def chay_hoc(self):
        t = dict(self.ts)
        t["hoc"] = self._ds_chon()
        if not t["hoc"]:
            self.bao("Chon nhom can day roi bam lai.")
            return
        self._chay_nen(t)

    def chay_doc_bang(self):
        t = dict(self.ts)
        t["docbang"] = True
        t["hoc"] = ""
        self._chay_nen(t)

    def dong(self):
        if self.dang_chay:
            if not self.mb.askyesno("Đóng", "Tool đang chạy (Chrome đang mở). Đóng cửa sổ sẽ dừng việc đang làm. Vẫn đóng?",
                                    parent=self.root):
                return
        try:
            self.T.BAO_GD = None
        except Exception:
            pass
        self.root.destroy()


_DO = {}


def tkfont_do(cv, chu, f):
    """Be rong chu (diem anh) theo font f tren canvas cv (nho lai: ve lai nut khi re chuot khong tao font moi)."""
    k = (chu, tuple(f))
    if k not in _DO:
        try:
            from tkinter import font as tkfont
            _DO[k] = tkfont.Font(root=cv, font=f).measure(chu)
        except Exception:
            _DO[k] = len(chu) * 7
    return _DO[k]
