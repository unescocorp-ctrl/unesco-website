# -*- coding: utf-8 -*-
"""
tao_ban_phat_hanh.py - Dung thu muc PHAT HANH cho tinh nang tu dong cap nhat
                       cua phan mem ke toan UNESCO XI.

Chay tren MOT may (may cua nguoi quan tri), ket qua dat vao thu muc "CapNhat"
canh file .mdb tren may chu. Cac may tram khi mo chuong trinh se tu thay.

    python tao_ban_phat_hanh.py --nguon <thu muc goi cap nhat> ^
                                --dich  "\\\\MAYCHU\\KeToan\\DATA\\CapNhat" ^
                                --phien-ban 405 --mo-ta "Sua loi font, them HTKK"
                                [--bat-buoc] [--exe <thu muc chua file chuong trinh>]

Sinh ra:
    <dich>\\phien-ban.json                 thong tin ban phat hanh
    <dich>\\payload\\AIHoaDon\\*.py         cac tool Python
    <dich>\\payload\\ChuongTrinh\\*         file chuong trinh (neu co --exe)
    <dich>\\payload\\manifest\\KIEM_TRA.csv duong_dan,so_byte,crc32

May tram kiem tung tep theo kich thuoc + CRC32 truoc khi chep. Tep thieu hoac
chep do dang la DUNG, khong chep gi ca.

Luu y: CRC32 bat duoc tep hong / chep thieu. Day KHONG phai chu ky so - su tin cay
den tu cho thu muc phat hanh nam tren may chu cua chinh doanh nghiep.
"""

import argparse
import json
import os
import shutil
import sys
import zlib
from datetime import date


def crc32_tep(duong):
    c = 0
    with open(duong, "rb") as f:
        while True:
            b = f.read(1 << 16)
            if not b:
                break
            c = zlib.crc32(b, c)
    return c & 0xFFFFFFFF


def chep_cay(nguon, dich, duoi=None):
    """Chep tep tu nguon sang dich (mot cap). Tra ve list duong tuong doi da chep."""
    ra = []
    if not os.path.isdir(nguon):
        return ra
    os.makedirs(dich, exist_ok=True)
    for ten in sorted(os.listdir(nguon)):
        p = os.path.join(nguon, ten)
        if not os.path.isfile(p):
            continue
        if duoi and not ten.lower().endswith(duoi):
            continue
        shutil.copy2(p, os.path.join(dich, ten))
        ra.append(ten)
    return ra


def main(argv=None):
    ap = argparse.ArgumentParser(add_help=True)
    ap.add_argument("--nguon", required=True, help="thu muc goi cap nhat (co thu muc AIHoaDon)")
    ap.add_argument("--dich", required=True, help="thu muc phat hanh tren may chu")
    ap.add_argument("--phien-ban", type=int, required=True, help="so phien ban, phai LON HON ban truoc")
    ap.add_argument("--mo-ta", default="", help="mo ta ngan hien cho nguoi dung")
    ap.add_argument("--bat-buoc", action="store_true", help="ban bat buoc - may tram khong duoc hoan")
    ap.add_argument("--exe", default="", help="thu muc chua file chuong trinh (.exe, .dll, ...)")
    ts = ap.parse_args(argv)

    nguon = os.path.abspath(ts.nguon)
    dich = os.path.abspath(ts.dich)
    payload = os.path.join(dich, "payload")

    # khong ghi de nham len ban dang co neu so phien ban khong tang
    cu = os.path.join(dich, "phien-ban.json")
    if os.path.exists(cu):
        try:
            with open(cu, "r", encoding="utf-8") as f:
                pb_cu = int(json.load(f).get("phien_ban") or 0)
            if ts.phien_ban <= pb_cu:
                print("DUNG: ban dang phat hanh la %d, so moi (%d) phai LON HON." % (pb_cu, ts.phien_ban))
                return 2
        except Exception:
            pass

    if os.path.isdir(payload):
        shutil.rmtree(payload)
    os.makedirs(payload, exist_ok=True)

    tep_ke = []
    n_py = chep_cay(os.path.join(nguon, "AIHoaDon"), os.path.join(payload, "AIHoaDon"), ".py")
    tep_ke += [("AIHoaDon/" + t) for t in n_py]
    if ts.exe:
        n_exe = chep_cay(os.path.abspath(ts.exe), os.path.join(payload, "ChuongTrinh"))
        tep_ke += [("ChuongTrinh/" + t) for t in n_exe]

    if not tep_ke:
        print("DUNG: khong co tep nao de phat hanh (thieu thu muc AIHoaDon hoac --exe).")
        return 3

    os.makedirs(os.path.join(payload, "manifest"), exist_ok=True)
    dong = ["duong_dan,so_byte,crc32"]
    for rel in tep_ke:
        p = os.path.join(payload, rel.replace("/", os.sep))
        dong.append("%s,%d,%08X" % (rel, os.path.getsize(p), crc32_tep(p)))
    with open(os.path.join(payload, "manifest", "KIEM_TRA.csv"), "w", encoding="utf-8") as f:
        f.write("\n".join(dong) + "\n")

    thong_tin = {
        "phien_ban": ts.phien_ban,
        "ngay": date.today().isoformat(),
        "mo_ta": ts.mo_ta,
        "bat_buoc": bool(ts.bat_buoc),
        "so_tep": len(tep_ke),
        "co_chuong_trinh": any(t.startswith("ChuongTrinh/") for t in tep_ke),
    }
    with open(cu, "w", encoding="utf-8") as f:
        json.dump(thong_tin, f, ensure_ascii=False, indent=1)

    print("Da phat hanh ban %d: %d tep (%s)" %
          (ts.phien_ban, len(tep_ke), "co phan chuong trinh" if thong_tin["co_chuong_trinh"] else "chi AIHoaDon"))
    print("Thu muc: " + dich)
    return 0


if __name__ == "__main__":
    sys.exit(main())
