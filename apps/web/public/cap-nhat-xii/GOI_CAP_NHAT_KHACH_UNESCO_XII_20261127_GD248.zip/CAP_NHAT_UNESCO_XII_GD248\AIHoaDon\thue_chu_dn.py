# -*- coding: utf-8 -*-
"""GD160 (lo trinh C4 + C5) - THUE TNDN DU KIEN CA NAM + KICH BAN; BAO CAO 1 TRANG CHO CHU DOANH NGHIEP. CHI DOC, UOC TINH tu so ke toan.

  THUE (C4): ket qua kinh doanh theo THANG tai chinh (bo chung tu ket chuyen 911) -> du bao ca nam = thuc te cac thang da tron + binh quan
             thang (cac thang da co hoac 3 thang gan nhat) x so thang con lai -> loi nhuan truoc thue, thu nhap tinh thue (+ chi khong duoc
             tru, - lo duoc chuyen), thue suat theo tong doanh thu nam truoc (15 / 17 / 20% - bo tham so nam GD156), thue du kien ca nam.
             Kich ban: mua TSCD (khau hao phan con lai cua nam), thuong cuoi nam, chi bi loai, chi phi them, doanh thu them -> thue doi bao
             nhieu. Tam nop: tong 4 quy toi thieu 80% so quyet toan (bo tham so nam TNDN_TAM_NOP_4Q) - da nop (No 3334 / Co 111, 112, 113 sau
             khi tru so con no nam truoc) -> con phai nop them, han tung quy. Canh bao nguong doanh thu 3 ty / 50 ty quyet dinh thue suat nam sau.
  CHU  (C5): mot trang A4 (HTML, in / luu PDF tu trinh duyet): doanh thu, gia von, lai gop, chi phi, lai thang nay - thang truoc - luy ke;
             tien hien co + dong tien 4 tuan (du bao GD156), phai thu qua han, phai tra den han, ton kho cham luan chuyen / can dat hang
             (GD159), thue sap nop (so du 333 + tam nop TNDN), 5 canh bao quan trong nhat.
Dau vao: JSON VB6 (ModChuDN.TD160_Json) = so lieu cong no GD70 (+ "ss" GD78, "pt159", "dt156" voi bao cao chu DN) + "td160".
Ra: Excel + HTML (THUE), HTML 1 trang (CHU) + ket-qua\\thue_chu_dn.txt (TONG + dong canh bao cho VB6). Khong ghi so.
GD176: HTML THUE them bieu do thue goc / tung kich ban, tien do tam nop, tam nop theo quy; HTML CHU them 2 bieu do gon (doanh thu / lai
theo thang, so du tien 4 tuan) van 1 trang A4. Bo ve SVG dung chung bd_* trong dong_tien.py. Excel va tep tom tat khong doi."""
import datetime as _dt
import html
import io
import json
import os
import re

import kiem_khoa_so as K

GOC = os.path.dirname(os.path.abspath(__file__))
TEP_KQ = "thue_chu_dn.txt"
NHOM = (("dt", "Doanh thu bán hàng, dịch vụ (thuần)"), ("dttc", "Doanh thu hoạt động tài chính"), ("tnk", "Thu nhập khác"),
        ("gv", "Giá vốn hàng bán"), ("bh", "Chi phí bán hàng"), ("ql", "Chi phí quản lý doanh nghiệp"), ("cptc", "Chi phí tài chính"),
        ("cpk", "Chi phí khác"))
CONG = ("dt", "dttc", "tnk")
TRU = ("gv", "bh", "ql", "cptc", "cpk")
MUC = {"Cao": 3, "Vừa": 2, "Thấp": 1, "Thông tin": 0}


def _so(x):
    try:
        return float(x or 0)
    except (TypeError, ValueError):
        try:
            return float(str(x).replace(".", "").replace(",", "."))
        except (TypeError, ValueError):
            return 0.0


def tien(x):
    return "{:,.0f}".format(round(x or 0)).replace(",", ".")


def pt(x, le=1):
    return (("%." + str(le) + "f%%") % (x * 100)).replace(".", ",")


def _ngay(s):
    m = re.match(r"^\s*(\d{1,2})/(\d{1,2})/(\d{4})", str(s or ""))
    if not m:
        return None
    try:
        return _dt.date(int(m.group(3)), int(m.group(2)), int(m.group(1)))
    except ValueError:
        return None


def vn(d):
    return d.strftime("%d/%m/%Y") if d else ""


def _sach(s, n=300):
    return re.sub(r"[\t\r\n;]+", " ", str(s or "")).strip()[:n]


def cuoi_thang(y, m):
    while m > 12:
        y, m = y + 1, m - 12
    return (_dt.date(y, 12, 31) if m == 12 else _dt.date(y, m + 1, 1) - _dt.timedelta(days=1))


def trung_vi(ds):
    ds = sorted(ds)
    if not ds:
        return None
    n = len(ds)
    return ds[n // 2] if n % 2 else (ds[n // 2 - 1] + ds[n // 2]) / 2.0


def ts_nam(khoa, ngay, md=None):
    """bo tham so nam GD156 (tham_so_nam.txt); khong doc duoc -> mac dinh."""
    try:
        import tham_so_nam as TS
        v = TS.lay(khoa, ngay)
        return md if v is None else v
    except Exception:
        return md


def ts_can_cu(khoa, ngay):
    try:
        import tham_so_nam as TS
        r = TS.dong_hieu_luc(khoa, ngay)
        return (r.get("can_cu") or "") if r else ""
    except Exception:
        return ""


# ====================================================================== ky tai chinh
class Ky(object):
    def __init__(self, dl, b):
        self.dau_ky = int(_so(dl.get("thang_dau_ky")) or 1)
        if not 1 <= self.dau_ky <= 12:
            self.dau_ky = 1
        d0 = _ngay(b.get("dau_nam")) or _ngay((dl.get("ky") or {}).get("tu"))
        hn = _ngay(b.get("hom_nay")) or _dt.date.today()
        if d0 is None:
            d0 = _dt.date(hn.year if hn.month >= self.dau_ky else hn.year - 1, self.dau_ky, 1)
        self.d0 = _dt.date(d0.year, d0.month, 1)
        self.d_cuoi = cuoi_thang(self.d0.year, self.d0.month + 11)
        self.hom_nay = min(max(hn, self.d0), self.d_cuoi)
        self.t_hien = self.t_cua(self.hom_nay)
        self.that = _ngay(b.get("hom_nay_that")) or max(hn, self.hom_nay)   # ngay thuc (so nam truoc mo sau khi het nam: han tam nop da qua)

    def lich(self, t):
        """thang tai chinh t (1..15) -> (nam, thang) duong lich."""
        mm = self.d0.month - 1 + t - 1
        return self.d0.year + mm // 12, mm % 12 + 1

    def t_cua(self, d):
        return (d.year - self.d0.year) * 12 + d.month - self.d0.month + 1

    def chu(self, t):
        y, m = self.lich(t)
        return "%02d/%d" % (m, y)

    def cuoi(self, t):
        y, m = self.lich(t)
        return cuoi_thang(y, m)

    def han_quy(self, q):
        """han tam nop quy q (1..4) cua nam tai chinh: ngay 30 thang dau quy sau (thang 2 -> ngay cuoi thang)."""
        y, m = self.lich(3 * q + 1)
        c = cuoi_thang(y, m)
        return _dt.date(y, m, min(30, c.day))


# ====================================================================== so lieu ket qua kinh doanh theo thang
def chuoi_thang(S):
    """{nhom: [0..12]} theo thang tai chinh (chi phan KHONG ket chuyen 911); + 821."""
    T = {k: [0.0] * 13 for k, _ in NHOM}
    T["821"] = [0.0] * 13
    co_641 = getattr(S, "cp99", None)              # GD179: kiem_khoa_so.SoLieu.cp99 (he thong TK co 641 = so TT99)
    if co_641 is None:
        co_641 = any(S.tk[m]["sh"].startswith("641") for m in S.la)
    for m in S.la:
        sh = S.tk[m]["sh"]
        p = S.ps.get(m)
        if not p or not sh[:1] in ("5", "6", "7", "8"):
            continue
        for t, x in p["thang"].items():
            if not 1 <= t <= 12:
                continue
            no, co = x[0], x[1]
            if sh.startswith("511"):
                T["dt"][t] += co - no
            elif sh.startswith("521"):
                T["dt"][t] -= no - co
            elif sh.startswith("515"):
                T["dttc"][t] += co - no
            elif sh.startswith("711"):
                T["tnk"][t] += co - no
            elif sh.startswith("632"):
                T["gv"][t] += no - co
            elif sh.startswith("641"):
                T["bh"][t] += no - co
            elif sh.startswith("642"):
                if not co_641 and sh.startswith("6421"):
                    T["bh"][t] += no - co               # TT133: 6421 chi phi ban hang, 6422 quan ly
                else:
                    T["ql"][t] += no - co
            elif sh.startswith("635"):
                T["cptc"][t] += no - co
            elif sh.startswith("811"):
                T["cpk"][t] += no - co
            elif sh.startswith("821"):
                T["821"][t] += no - co
    return T


def lntt(x):
    return sum(x[k] for k in CONG) - sum(x[k] for k in TRU)


def thang_so_lieu(T, t_hien):
    """-> (thang dau co so lieu, thang cuoi co so lieu dang ke)."""
    act = [0.0] * 13
    for t in range(1, 13):
        act[t] = sum(abs(T[k][t]) for k, _ in NHOM)
    co = [t for t in range(1, t_hien + 1) if act[t] > 0.5]
    if not co:
        return 0, 0
    med = trung_vi([act[t] for t in co])
    cuoi = max([t for t in co if act[t] >= max(1.0, 0.3 * med)] or [co[-1]])
    return co[0], cuoi


# ====================================================================== C4 THUE TNDN DU KIEN
def thue_suat(dt_truoc, ngay, nhan="năm trước"):
    """-> (ty le, ly do). Ky tinh thue tu 2025: <= 3 ty 15%, <= 50 ty 17% (Luat 67/2025/QH15, ND 320/2025); con lai pho thong."""
    pho = ts_nam("TNDN_THUE_SUAT", ngay, 0.2)
    r1, r2 = ts_nam("TNDN_TS_DT_DUOI_3TY", ngay), ts_nam("TNDN_TS_DT_3_50TY", ngay)
    n1, n2 = ts_nam("TNDN_NGUONG_DT_1", ngay, 3e9), ts_nam("TNDN_NGUONG_DT_2", ngay, 5e10)
    if r1 is None or r2 is None:
        return pho, "Kỳ tính thuế trước 2025: thuế suất phổ thông %s" % pt(pho, 0)
    if dt_truoc is None:
        return pho, "Chưa có tổng doanh thu năm trước: tạm dùng thuế suất phổ thông %s (nhập doanh thu năm trước ở Tham số)" % pt(pho, 0)
    if dt_truoc <= n1:
        return r1, "Tổng doanh thu %s %s không quá %s: %s" % (nhan, tien(dt_truoc), tien(n1), pt(r1, 0))
    if dt_truoc <= n2:
        return r2, "Tổng doanh thu %s %s trên %s đến %s: %s" % (nhan, tien(dt_truoc), tien(n1), tien(n2), pt(r2, 0))
    return pho, "Tổng doanh thu %s %s trên %s: %s" % (nhan, tien(dt_truoc), tien(n2), pt(pho, 0))


def _kb(b):
    k = b.get("kb") or {}
    bien = k.get("bien_them")
    return {"tscd_ng": max(0.0, _so(k.get("tscd_ng"))), "tscd_thang": str(k.get("tscd_thang") or "").strip(),
            "tscd_nam": max(0.0, _so(k.get("tscd_nam"))), "thuong": max(0.0, _so(k.get("thuong"))), "chi_loai": max(0.0, _so(k.get("chi_loai"))),
            "chi_them": max(0.0, _so(k.get("chi_them"))), "dt_them": _so(k.get("dt_them")),
            "bien_them": None if bien in (None, "") or _so(bien) < 0 else _so(bien) / 100.0}


class ThueNam(object):
    def __init__(self, dl, S=None, bo_kb=False):
        self.dl = dl
        self.b = b = dl.get("td160") or {}
        self.S = S or K.SoLieu(dl)
        self.ky = Ky(dl, b)
        self.cach = "3T" if str(b.get("cach") or "").upper() == "3T" else "BQ"
        dtt = b.get("dt_nam_truoc")
        self.dt_truoc = _so(dtt) if dtt not in (None, "") and _so(dtt) >= 0 else None
        self.nguon_dt = str(b.get("nguon_dt") or "")
        self.lo_chuyen = max(0.0, _so(b.get("lo_chuyen")))
        self.ts_tay = int(_so(b.get("ts_tay"))) if int(_so(b.get("ts_tay"))) in (15, 17, 20) else 0
        self.kb = _kb({} if bo_kb else b)
        self.canh_bao = []

    # ------------------------------------------------------------------ du bao
    def tinh(self):
        ky, S = self.ky, self.S
        T = self.T = chuoi_thang(S)
        t_dau, t_cuoi = thang_so_lieu(T, ky.t_hien)
        do_dang = t_cuoi > 0 and t_cuoi == ky.t_hien and ky.hom_nay < ky.cuoi(t_cuoi)
        t_tron = t_cuoi - 1 if do_dang else t_cuoi
        self.t_dau, self.t_cuoi, self.t_tron, self.do_dang = t_dau, t_cuoi, t_tron, do_dang
        base = list(range(max(t_dau, 1), t_tron + 1)) if t_tron >= 1 and t_dau >= 1 else []
        if self.cach == "3T":
            base = base[-3:]
        self.base = base
        con = (12 - t_tron) if base else 0
        self.con = con
        self.thuc_te = {k: sum(T[k][t] for t in range(1, t_cuoi + 1)) for k, _ in NHOM}
        self.ytd = {k: sum(T[k][t] for t in range(1, t_tron + 1)) for k, _ in NHOM} if base else dict(self.thuc_te)
        self.bq = {k: (sum(T[k][t] for t in base) / len(base)) if base else 0.0 for k, _ in NHOM}
        self.ca_nam = {k: self.ytd[k] + self.bq[k] * con for k, _ in NHOM}
        self.du_bao = {t: {k: (T[k][t] if t <= (t_tron if base else t_cuoi) else self.bq[k]) for k, _ in NHOM} for t in range(1, 13)}
        self.lntt_ytd = lntt(self.thuc_te)
        self.lntt = lntt(self.ca_nam)
        self.tong_dt = sum(self.ca_nam[k] for k in CONG)
        self.t821 = sum(T["821"][t] for t in range(1, t_cuoi + 1))
        # thue suat nam nay
        if self.ts_tay:
            self.ts, self.ts_ly_do = self.ts_tay / 100.0, "Thuế suất %d%% do anh chọn ở Tham số" % self.ts_tay
        else:
            self.ts, self.ts_ly_do = thue_suat(self.dt_truoc, ky.d0)
        self.goc = self.thue_cua(self.lntt, 0.0)
        self.kich_ban()
        self.tam_nop()
        self.nam_sau()
        self.lap_canh_bao()
        return self

    def thue_cua(self, ln, chi_loai):
        tn = max(0.0, ln + chi_loai)
        lo = min(self.lo_chuyen, tn)
        tntt = tn - lo
        return {"lntt": ln, "chi_loai": chi_loai, "lo": lo, "tntt": tntt, "thue": round(tntt * self.ts)}

    # ------------------------------------------------------------------ kich ban
    def kich_ban(self):
        k, ky = self.kb, self.ky
        dong = []
        self.ngoai_nam = ""
        bien_ht = (self.ca_nam["dt"] - self.ca_nam["gv"]) / self.ca_nam["dt"] if self.ca_nam["dt"] > 0 else 0.0
        if k["tscd_ng"] > 0:
            ng = k["tscd_ng"]
            nam = k["tscd_nam"] or 5.0
            toi_thieu = ts_nam("TSCD_NGUYEN_GIA_TOI_THIEU", ky.d0, 30000000)
            ghi = []
            if ng < toi_thieu:
                nam = min(nam, 3.0)
                ghi.append("Nguyên giá dưới %s: là công cụ dụng cụ, phân bổ tối đa 3 năm" % tien(toi_thieu))
            d = _ngay("01/" + k["tscd_thang"]) if k["tscd_thang"] else None
            t_sd = ky.t_cua(d) if d else ky.t_hien
            so_thang = max(0, 12 - t_sd + 1)
            if t_sd <= self.t_tron:
                ghi.append("Tháng đã qua: khấu hao các tháng đó phải ghi bổ sung")
            kh = ng / (nam * 12.0) * so_thang
            ghi.append("Khấu hao đường thẳng %s năm, %d tháng trong năm nay (từ %s)" % (("%g" % nam).replace(".", ","), so_thang, ky.chu(t_sd)))
            ghi.append("Tiền mua tài sản không trừ một lần; chỉ khấu hao được trừ (tài sản phục vụ sản xuất kinh doanh, có hoá đơn, thanh toán không dùng tiền mặt từ 5 triệu)")
            if 1 <= t_sd <= 12:
                dong.append(("Mua tài sản cố định %s" % tien(ng), -kh, 0.0, 0.0, "; ".join(ghi)))
            else:
                self.ngoai_nam = "Tháng bắt đầu dùng tài sản %s nằm ngoài năm tài chính %s - %s: không tính vào thuế năm nay." % (
                    k["tscd_thang"], ky.chu(1), ky.chu(12))
        if k["thuong"] > 0:
            dong.append(("Thưởng cuối năm cho người lao động", -k["thuong"], 0.0, 0.0,
                         "Được trừ khi ghi trong hợp đồng lao động / thoả ước / quy chế thưởng và chi trả trước hạn nộp hồ sơ quyết toán"))
        if k["chi_them"] > 0:
            dong.append(("Chi phí khác phát sinh thêm (được trừ)", -k["chi_them"], 0.0, 0.0, "Có hoá đơn, chứng từ hợp lệ, phục vụ sản xuất kinh doanh"))
        if k["dt_them"]:
            b = k["bien_them"] if k["bien_them"] is not None else bien_ht
            dong.append(("Doanh thu thêm %s (biên lãi gộp %s)" % (tien(k["dt_them"]), pt(b)), k["dt_them"] * b, 0.0, k["dt_them"],
                         "Chưa tính chi phí bán hàng tăng thêm; doanh thu thêm cũng làm tăng tổng doanh thu xét thuế suất năm sau"))
        if k["chi_loai"] > 0:
            dong.append(("Chi không được trừ (bị loại khi quyết toán)", 0.0, k["chi_loai"], 0.0,
                         "Ví dụ: không có hoá đơn hợp lệ, thanh toán tiền mặt từ 5 triệu, phạt vi phạm hành chính, vượt mức khống chế"))
        kq = []
        tong_ln, tong_cl, tong_dt = 0.0, 0.0, 0.0
        for ten, d_ln, d_cl, d_dt, ghi in dong:
            x = self.thue_cua(self.lntt + d_ln, d_cl)
            kq.append({"ten": ten, "d_ln": d_ln, "d_cl": d_cl, "d_dt": d_dt, "thue": x["thue"], "d_thue": x["thue"] - self.goc["thue"], "ghi": ghi})
            tong_ln += d_ln
            tong_cl += d_cl
            tong_dt += d_dt
        self.kb_dong = kq
        self.kb_tong = self.thue_cua(self.lntt + tong_ln, tong_cl) if kq else dict(self.goc)
        self.kb_tong["d_dt"] = tong_dt
        self.kb_tong["d_thue"] = self.kb_tong["thue"] - self.goc["thue"]

    # ------------------------------------------------------------------ tam nop 4 quy
    def tam_nop(self):
        S, ky = self.S, self.ky
        tien_ma = set(S.la_theo("111", "112", "113"))
        tk3334 = set(S.la_theo("3334"))
        nop = 0.0
        for r in self.dl.get("doi_ung") or []:
            a, b = int(_so(r[0])), int(_so(r[1]))
            t = K.thang_tc(r[2], ky.dau_ky)
            if not 1 <= t <= 12:
                continue
            if a in tk3334 and b in tien_ma:
                nop += _so(r[3])
            elif a in tien_ma and b in tk3334:
                nop -= _so(r[3])                       # hoan / ghi giam so da nop
        du_dau = sum(S.tk[m]["dn0"] - S.tk[m]["dc0"] for m in tk3334)      # No - Co dau nam
        no_cu = max(0.0, -du_dau)
        da_nop = max(0.0, nop - no_cu) + max(0.0, du_dau)
        ty_le = ts_nam("TNDN_TAM_NOP_4Q", ky.d0, 0.8)
        thue = self.goc["thue"]                         # theo so thuc te du kien (kich ban chi de so sanh)
        toi_thieu = round(thue * ty_le)
        thieu = max(0.0, toi_thieu - da_nop)
        quy = []
        for q in range(1, 5):
            quy.append({"q": q, "tu": ky.chu(3 * q - 2), "den": ky.chu(3 * q), "han": ky.han_quy(q)})
        con = [x for x in quy if x["han"] >= ky.that]
        for x in quy:
            x["goi_y"] = round(thieu / len(con)) if (con and x in con) else 0
        self.tn = {"nop": nop, "du_dau": du_dau, "no_cu": no_cu, "da_nop": da_nop, "ty_le": ty_le, "thue": thue, "toi_thieu": toi_thieu,
                   "toi_thieu_kb": round(self.kb_tong["thue"] * ty_le) if self.kb_dong else None,
                   "thieu": thieu, "quy": quy, "han_gan": con[0] if con else None, "han_qt": ky.cuoi(15),
                   "can_cu": ts_can_cu("TNDN_TAM_NOP_4Q", ky.d0) or "NĐ 126/2020/NĐ-CP sửa đổi bởi NĐ 91/2022/NĐ-CP"}

    # ------------------------------------------------------------------ nguong doanh thu -> thue suat nam sau
    def nam_sau(self):
        ky = self.ky
        ngay = ky.d_cuoi + _dt.timedelta(days=1)
        n1, n2 = ts_nam("TNDN_NGUONG_DT_1", ngay, 3e9), ts_nam("TNDN_NGUONG_DT_2", ngay, 5e10)
        tong = self.tong_dt + (self.kb_tong.get("d_dt") or 0.0)
        ts2, ly2 = thue_suat(tong, ngay, "năm nay (dự kiến)")
        sat = None
        for n in (n1, n2):
            if n and abs(tong - n) <= 0.1 * n:
                sat = n
        self.ns = {"tong": tong, "ts": ts2, "ly_do": ly2, "n1": n1, "n2": n2, "sat": sat}

    # ------------------------------------------------------------------ canh bao
    def lap_canh_bao(self):
        cb, ky, tn, ns = [], self.ky, self.tn, self.ns
        if not self.base:
            cb.append(("Vừa", "Chưa đủ số liệu", "Chưa có tháng nào đủ số liệu để dự báo cả năm: số dưới đây là số thực tế đến nay.",
                       "Ghi sổ đủ ít nhất 1 tháng rồi lập lại."))
        elif self.t_cuoi < ky.t_hien - 1:
            cb.append(("Thấp", "Sổ chưa cập nhật", "Số liệu sổ mới đến tháng %s; các tháng sau tính theo bình quân." % ky.chu(self.t_cuoi),
                       "Ghi sổ đến tháng gần nhất để ước tính sát hơn."))
        if self.dt_truoc is None and not self.ts_tay:
            cb.append(("Vừa", "Chưa có doanh thu năm trước", "Tạm dùng thuế suất phổ thông %s; doanh nghiệp nhỏ có thể chỉ 15%% / 17%%." % pt(self.ts, 0),
                       "Nhập tổng doanh thu năm trước (KQKD [10] + [21] + [31]) ở Tham số."))
        if tn["thieu"] > 0.5 and tn["han_gan"] is not None:
            muc = "Cao" if tn["han_gan"]["q"] == 4 or (tn["han_gan"]["han"] - ky.that).days <= 45 else "Vừa"
            cb.append((muc, "Tạm nộp TNDN chưa đủ %s" % pt(tn["ty_le"], 0),
                       "Đã nộp %s, tối thiểu cả năm %s: còn thiếu %s; hạn gần nhất %s (quý %d)." % (
                           tien(tn["da_nop"]), tien(tn["toi_thieu"]), tien(tn["thieu"]), vn(tn["han_gan"]["han"]), tn["han_gan"]["q"]),
                       "Nộp thêm trước hạn; thiếu quá mức tối thiểu sau hạn quý 4 bị tính tiền chậm nộp trên phần thiếu."))
        elif tn["thieu"] > 0.5:
            cb.append(("Vừa", "Tạm nộp TNDN chưa đủ %s" % pt(tn["ty_le"], 0),
                       "Đã hết hạn tạm nộp 4 quý: đã nộp %s, tối thiểu %s, còn thiếu %s." % (tien(tn["da_nop"]), tien(tn["toi_thieu"]), tien(tn["thieu"])),
                       "Nộp khi quyết toán trước %s; phần thiếu so với mức tối thiểu bị tính tiền chậm nộp từ sau hạn tạm nộp quý 4." % vn(tn["han_qt"])))
        if self.ngoai_nam:
            cb.append(("Thông tin", "Kịch bản tài sản ngoài năm", self.ngoai_nam, "Nhập tháng trong năm tài chính đang mở."))
        if ns["sat"]:
            cb.append(("Vừa", "Sát ngưỡng doanh thu %s" % tien(ns["sat"]),
                       "Tổng doanh thu cả năm dự kiến %s (ngưỡng %s) quyết định thuế suất năm sau: %s." % (tien(ns["tong"]), tien(ns["sat"]), pt(ns["ts"], 0)),
                       "Theo dõi doanh thu các tháng cuối năm; thuế suất năm sau tính theo tổng doanh thu năm nay."))
        elif abs(ns["ts"] - self.ts) > 1e-9:
            cb.append(("Thông tin", "Năm sau đổi thuế suất", "Năm sau dự kiến %s (%s)." % (pt(ns["ts"], 0), ns["ly_do"]), ""))
        if self.lntt < 0:
            cb.append(("Vừa", "Dự kiến lỗ cả năm", "Lợi nhuận trước thuế cả năm dự kiến %s: không phát sinh thuế TNDN." % tien(self.lntt),
                       "Lỗ được chuyển trừ vào thu nhập các năm sau, tối đa 5 năm liên tục."))
        cb.sort(key=lambda x: -MUC.get(x[0], 0))
        self.canh_bao = cb


# ====================================================================== C4 ghi
def ghi_txt_thue(R, ra_txt, tep):
    tn, g, kb = R.tn, R.goc, R.kb_tong
    tong = "TONG;THUE;%d;%d;%d;%d;%d;%d;%d;%d;%d;%s;%s;%d" % (
        round(R.lntt_ytd), round(R.lntt), round(R.ts * 100), round(g["thue"]), round(kb["thue"]), round(tn["da_nop"]), round(tn["thieu"]),
        round(R.ns["tong"]), round(R.ns["ts"] * 100), R.ky.chu(R.t_cuoi) if R.t_cuoi else "", _sach(tep, 400), len(R.kb_dong))
    dong = [tong]
    if tn["han_gan"] is not None:
        dong.append("Q;%d;%s;%d" % (tn["han_gan"]["q"], vn(tn["han_gan"]["han"]), round(tn["han_gan"]["goi_y"])))
    for x in R.kb_dong:
        dong.append("K;%s;%d" % (_sach(x["ten"], 120), round(x["d_thue"])))
    for m, l, nd, _ in R.canh_bao[:20]:
        dong.append("C;%s;%s;%s" % (_sach(m), _sach(l), _sach(nd, 220)))
    _ghi(ra_txt, dong)


def _ghi(ra_txt, dong):
    os.makedirs(os.path.dirname(ra_txt), exist_ok=True)
    with io.open(ra_txt + ".tmp", "w", encoding="utf-8", newline="") as f:
        f.write("\r\n".join(dong) + "\r\n")
    os.replace(ra_txt + ".tmp", ra_txt)
    return ra_txt


def lap_excel_thue(R, ra):
    from xlsx_viet import SoExcel
    wb = SoExcel(font="Times New Roman", co=11)
    k_td = wb.kieu(dam=True, co=14, can="giua", mau="0B3D91")
    k_ghi = wb.kieu(nghieng=True, mau="555555", xuong=True, doc="tren")
    k_dau = wb.kieu(dam=True, nen="D9E1F2", khung=True, can="giua", xuong=True)
    k_o = wb.kieu(khung=True, xuong=True, doc="tren")
    k_od = wb.kieu(khung=True, xuong=True, doc="tren", dam=True)
    k_so = wb.kieu(khung=True, so="#,##0")
    k_sod = wb.kieu(khung=True, so="#,##0", dam=True)
    k_do = wb.kieu(khung=True, so="#,##0", mau="C00000", dam=True)
    k_pt = wb.kieu(khung=True, so="0%")
    k_uoc = wb.kieu(khung=True, so="#,##0", nen="FFF2CC")
    ky, g, tn, ns = R.ky, R.goc, R.tn, R.ns
    cty = ((R.dl.get("cty") or {}).get("ten") or "")
    ws = wb.sheet("TongQuan", cot=[52, 20, 60])
    ws.gop(1, 1, 1, 3, cty, wb.kieu(dam=True))
    ws.gop(2, 1, 2, 3, "THUẾ TNDN DỰ KIẾN CẢ NĂM TÀI CHÍNH %s - %s (ƯỚC TÍNH)" % (ky.chu(1), ky.chu(12)), k_td)
    if R.base:
        cach = ("bình quân %d tháng gần nhất" if R.cach == "3T" else "bình quân %d tháng đã có số liệu") % len(R.base)
        ghi = ("Thực tế đến hết tháng %s + %d tháng còn lại theo %s (%s). " % (ky.chu(R.t_tron), R.con, cach, ", ".join(ky.chu(t) for t in R.base))
               if R.con else "Năm tài chính đã hết: số thực tế cả năm. ")
    else:
        ghi = "Chưa đủ 1 tháng số liệu: chỉ có số thực tế đến nay. "
    if R.do_dang:
        ghi += "Tháng %s đang ghi dở không dùng để dự báo. " % ky.chu(R.t_cuoi)
    ws.gop(3, 1, 3, 3, ghi + "Bỏ bút toán kết chuyển 911. Chỉ đọc sổ, không ghi; mùa vụ / bút toán cuối năm (khấu hao, phân bổ, dự phòng) có thể làm số thực tế khác.", k_ghi)
    ws.cao(3, 46)
    r = 5
    ws.dong(r, 1, ["Chỉ tiêu", "Số tiền", "Ghi chú"], k_dau)
    for ten, v, gc, kk in (("Tổng doanh thu đến nay (thực tế)", sum(R.thuc_te[k] for k in CONG), "Doanh thu thuần + tài chính + thu nhập khác", k_so),
                           ("Lợi nhuận trước thuế đến nay (thực tế)", R.lntt_ytd, "", k_so),
                           ("Tổng doanh thu cả năm (dự kiến)", R.tong_dt, "Xét thuế suất năm sau", k_uoc),
                           ("Lợi nhuận trước thuế cả năm (dự kiến)", R.lntt, "", k_uoc),
                           ("Lỗ các năm trước được chuyển", -g["lo"], "Theo số anh nhập ở Tham số" if R.lo_chuyen else "", k_so),
                           ("Thu nhập tính thuế (dự kiến)", g["tntt"], "", k_sod),
                           ("Thuế suất", R.ts, R.ts_ly_do, k_pt),
                           ("THUẾ TNDN DỰ KIẾN CẢ NĂM", g["thue"], "Chưa gồm kịch bản", k_sod)):
        r += 1
        ws.o(r, 1, ten, k_od if ten.isupper() or ten.startswith("THUẾ") else k_o)
        ws.o(r, 2, v, k_do if (kk is not k_pt and v < 0) else kk)
        ws.o(r, 3, gc, k_o)
    if R.kb_dong:
        r += 2
        ws.dong(r, 1, ["Kịch bản (chi tiết sheet KichBan)", "Thuế đổi", "Ghi chú"], k_dau)
        for x in R.kb_dong:
            r += 1
            ws.dong(r, 1, [x["ten"]], k_o)
            ws.o(r, 2, x["d_thue"], k_so)
            ws.o(r, 3, x["ghi"], k_o)
        r += 1
        ws.o(r, 1, "Thuế dự kiến nếu làm tất cả kịch bản", k_od)
        ws.o(r, 2, R.kb_tong["thue"], k_sod)
        ws.o(r, 3, "Đổi %s so với không làm gì" % tien(R.kb_tong["d_thue"]), k_o)
    r += 2
    ws.dong(r, 1, ["Tạm nộp (chi tiết sheet TamNop)", "Số tiền", "Ghi chú"], k_dau)
    for ten, v, gc in (("Đã nộp trong năm cho năm nay (Nợ 3334 / Có tiền)", tn["da_nop"],
                        "Đã trừ %s là thuế năm trước còn nợ đầu năm" % tien(tn["no_cu"]) if tn["no_cu"] > 0.5 else ""),
                       ("Tối thiểu 4 quý (%s thuế cả năm)" % pt(tn["ty_le"], 0), tn["toi_thieu"],
                        tn["can_cu"] + ((" - nếu làm các kịch bản: %s" % tien(tn["toi_thieu_kb"])) if tn["toi_thieu_kb"] is not None else "")),
                       ("Còn phải nộp thêm để đủ mức tối thiểu", tn["thieu"],
                        ("Hạn gần nhất %s (quý %d)" % (vn(tn["han_gan"]["han"]), tn["han_gan"]["q"])) if tn["han_gan"] is not None else "Đã hết hạn tạm nộp các quý")):
        r += 1
        ws.o(r, 1, ten, k_o)
        ws.o(r, 2, v, k_so)
        ws.o(r, 3, gc, k_o)
    r += 2
    ws.dong(r, 1, ["Năm sau", "", ""], k_dau)
    r += 1
    ws.o(r, 1, "Thuế suất dự kiến năm sau", k_o)
    ws.o(r, 2, ns["ts"], k_pt)
    ws.o(r, 3, ns["ly_do"] + ((" - SÁT NGƯỠNG %s" % tien(ns["sat"])) if ns["sat"] else ""), k_o)
    if R.canh_bao:
        r += 2
        ws.dong(r, 1, ["Cảnh báo", "Mức", "Gợi ý"], k_dau)
        for m, l, nd, gy in R.canh_bao:
            r += 1
            ws.o(r, 1, l + ": " + nd, k_o)
            ws.o(r, 2, m, k_o)
            ws.o(r, 3, gy, k_o)
    r += 2
    ws.gop(r, 1, r, 3, "ƯỚC TÍNH để lập kế hoạch, không thay tờ khai quyết toán. Thuế suất 15% / 17% có điều kiện loại trừ (ví dụ doanh nghiệp có quan hệ liên kết) "
                       "- kiểm tra NĐ 320/2025/NĐ-CP. Chưa trừ thu nhập miễn thuế, ưu đãi, trích quỹ khoa học công nghệ.", k_ghi)
    ws.cao(r, 32)
    # theo thang
    w2 = wb.sheet("TheoThang", cot=[12, 12] + [16] * 9)
    w2.gop(1, 1, 1, 11, "KẾT QUẢ KINH DOANH THEO THÁNG (thực tế / dự kiến)", k_td)
    w2.dong(3, 1, ["Tháng", "Loại"] + [t for _, t in NHOM] + ["Lợi nhuận trước thuế"], k_dau)
    w2.cao(3, 46)
    r = 3
    gioi = R.t_tron if R.base else R.t_cuoi
    for t in range(1, 13):
        r += 1
        x = R.du_bao[t]
        uoc = t > gioi
        w2.dong(r, 1, [ky.chu(t), "Dự kiến" if uoc else ("Đang ghi" if (R.do_dang and t == R.t_cuoi) else "Thực tế")], k_o)
        c = 3
        for k, _ in NHOM:
            w2.o(r, c, x[k], k_uoc if uoc else k_so)
            c += 1
        w2.o(r, c, lntt(x), k_do if lntt(x) < 0 else (k_uoc if uoc else k_so))
    r += 1
    w2.o(r, 1, "Cả năm", k_od)
    w2.o(r, 2, "", k_o)
    c = 3
    for k, _ in NHOM:
        w2.o(r, c, R.ca_nam[k], k_sod)
        c += 1
    w2.o(r, c, R.lntt, k_sod)
    w2.dong_bang(4, 3)
    # kich ban
    w3 = wb.sheet("KichBan", cot=[44, 18, 18, 18, 18, 70])
    w3.gop(1, 1, 1, 6, "KỊCH BẢN - THUẾ ĐỔI BAO NHIÊU (ước tính)", k_td)
    w3.dong(3, 1, ["Kịch bản", "Lợi nhuận đổi", "Chi bị loại", "Thuế cả năm", "Thuế đổi", "Điều kiện / ghi chú"], k_dau)
    r = 3
    r += 1
    w3.dong(r, 1, ["Không làm gì (gốc)"], k_o)
    w3.o(r, 2, 0, k_so)
    w3.o(r, 3, 0, k_so)
    w3.o(r, 4, g["thue"], k_so)
    w3.o(r, 5, 0, k_so)
    w3.o(r, 6, "", k_o)
    for x in R.kb_dong:
        r += 1
        w3.o(r, 1, x["ten"], k_o)
        w3.o(r, 2, x["d_ln"], k_so)
        w3.o(r, 3, x["d_cl"], k_so)
        w3.o(r, 4, x["thue"], k_so)
        w3.o(r, 5, x["d_thue"], k_so)
        w3.o(r, 6, x["ghi"], k_o)
    if R.kb_dong:
        r += 1
        w3.o(r, 1, "Tất cả kịch bản cùng lúc", k_od)
        w3.o(r, 2, R.kb_tong["lntt"] - R.lntt, k_sod)
        w3.o(r, 3, R.kb_tong["chi_loai"], k_sod)
        w3.o(r, 4, R.kb_tong["thue"], k_sod)
        w3.o(r, 5, R.kb_tong["d_thue"], k_sod)
        w3.o(r, 6, "", k_o)
    else:
        r += 2
        w3.gop(r, 1, r, 6, "Chưa nhập kịch bản: trên màn hình chọn Kịch bản (mua tài sản cố định, thưởng cuối năm, chi bị loại, chi phí / doanh thu thêm).", k_ghi)
    # tam nop
    w4 = wb.sheet("TamNop", cot=[10, 14, 14, 14, 20, 50])
    w4.gop(1, 1, 1, 6, "TẠM NỘP THUẾ TNDN THEO QUÝ", k_td)
    w4.gop(2, 1, 2, 6, "Tổng số đã tạm nộp 4 quý không thấp hơn %s số thuế quyết toán năm (%s). Hạn tạm nộp: ngày 30 tháng đầu quý sau; "
                       "hạn quyết toán: ngày cuối tháng thứ 3 sau khi kết thúc năm (%s). Khoản nộp đầu năm là thuế năm trước mà sổ không ghi số còn nợ "
                       "đầu năm (dư Có 3334) thì phần đã nộp ở đây cao hơn thực tế." % (pt(tn["ty_le"], 0), tn["can_cu"], vn(tn["han_qt"])), k_ghi)
    w4.cao(2, 46)
    w4.dong(4, 1, ["Quý", "Từ tháng", "Đến tháng", "Hạn tạm nộp", "Gợi ý nộp thêm", "Ghi chú"], k_dau)
    r = 4
    for x in tn["quy"]:
        r += 1
        w4.dong(r, 1, ["Quý %d" % x["q"], x["tu"], x["den"], vn(x["han"])], k_o)
        w4.o(r, 5, x["goi_y"], k_so)
        w4.o(r, 6, "Đã qua hạn" if x["han"] < ky.that else "", k_o)
    r += 2
    for ten, v in (("Thuế dự kiến cả năm (chưa gồm kịch bản)", tn["thue"]), ("Mức tối thiểu 4 quý", tn["toi_thieu"]),
                   ("Nộp trong năm (Nợ 3334 / Có 111, 112, 113, trừ hoàn)", tn["nop"]), ("Trong đó trả thuế năm trước còn nợ đầu năm", min(tn["nop"], tn["no_cu"])),
                   ("Nộp thừa đầu năm chuyển sang", max(0.0, tn["du_dau"])), ("Đã nộp cho năm nay", tn["da_nop"]), ("Còn thiếu", tn["thieu"])):
        w4.gop(r, 1, r, 4, ten, k_o)
        w4.o(r, 5, v, k_so)
        r += 1
    # can cu
    w5 = wb.sheet("CanCu", cot=[34, 16, 70])
    w5.gop(1, 1, 1, 3, "CĂN CỨ (bộ tham số năm - cập nhật qua kênh cập nhật)", k_td)
    w5.dong(3, 1, ["Tham số", "Giá trị", "Căn cứ"], k_dau)
    r = 3
    for kh, ten in (("TNDN_THUE_SUAT", "Thuế suất phổ thông"), ("TNDN_TS_DT_DUOI_3TY", "Thuế suất doanh thu năm không quá ngưỡng 1"),
                    ("TNDN_TS_DT_3_50TY", "Thuế suất doanh thu năm trên ngưỡng 1 đến ngưỡng 2"), ("TNDN_NGUONG_DT_1", "Ngưỡng 1 (đồng)"),
                    ("TNDN_NGUONG_DT_2", "Ngưỡng 2 (đồng)"), ("TNDN_TAM_NOP_4Q", "Tạm nộp 4 quý tối thiểu"),
                    ("TSCD_NGUYEN_GIA_TOI_THIEU", "Nguyên giá tối thiểu TSCĐ (đồng)")):
        v = ts_nam(kh, ky.d0)
        r += 1
        w5.o(r, 1, ten, k_o)
        w5.o(r, 2, v if v is not None else "", k_so if (v or 0) >= 1 else k_o)
        w5.o(r, 3, ts_can_cu(kh, ky.d0), k_o)
    r += 2
    w5.gop(r, 1, r, 3, "Tổng doanh thu năm trước: %s%s" % (tien(R.dt_truoc) if R.dt_truoc is not None else "chưa có",
                                                         (" (" + R.nguon_dt + ")") if R.nguon_dt else ""), k_o)
    os.makedirs(os.path.dirname(os.path.abspath(ra)), exist_ok=True)
    wb.luu(ra)
    return ra


def _nop_quy(R):
    """GD176 (chi cho bieu do): so da nop TNDN theo quy tai chinh (theo thang nop tien: No 3334 / Co 111, 112, 113, tru hoan), tru dan thue nam
    truoc con no dau nam tu quy dau - cong 4 quy khop R.tn["da_nop"] (khong tinh nop thua dau nam chuyen sang)."""
    S, ky = R.S, R.ky
    tien_ma = set(S.la_theo("111", "112", "113"))
    tk = set(S.la_theo("3334"))
    q = [0.0] * 4
    for r in R.dl.get("doi_ung") or []:
        a, b = int(_so(r[0])), int(_so(r[1]))
        t = K.thang_tc(r[2], ky.dau_ky)
        if not 1 <= t <= 12:
            continue
        if a in tk and b in tien_ma:
            q[(t - 1) // 3] += _so(r[3])
        elif a in tien_ma and b in tk:
            q[(t - 1) // 3] -= _so(r[3])
    tru = R.tn["no_cu"]
    for i in range(4):
        x = min(max(q[i], 0.0), tru)
        q[i] -= x
        tru -= x
    return q


def _bd_thue(R, BD):
    """GD176: thue TNDN thuc te (goc) va tung kich ban; tien do tam nop; tam nop theo quy."""
    h = []
    tieu = "Thuế TNDN dự kiến theo kịch bản"
    if R.kb_dong:
        g = R.goc["thue"]
        ds = [{"nhan": "Không làm gì (theo số thực tế dự kiến)", "v": g, "mau": BD.BD_XAM, "tip": "thuế cả năm chưa gồm kịch bản"}]
        for x in R.kb_dong + [dict(ten="Tất cả kịch bản cùng lúc", thue=R.kb_tong["thue"], d_thue=R.kb_tong["d_thue"], ghi="")]:
            ds.append({"nhan": x["ten"], "v": x["thue"], "mau": BD.BD_VANG if x["d_thue"] > 0.5 else BD.BD_XANH,
                       "nhan_v": "%s (%s%s)" % (tien(x["thue"]), "+" if x["d_thue"] >= 0 else "", tien(x["d_thue"])), "tip": x["ghi"]})
        h.append(BD.bd_an_toan(tieu, BD.bd_ngang, tieu, ds, tien, nhan_w=330, so_chu=54, moc=(g, "Thuế gốc %s" % tien(g)),
                               ghi="Xám: thuế cả năm nếu không làm gì; xanh: kịch bản làm giảm thuế; vàng: làm tăng thuế. Số trong ngoặc là thuế đổi so với thuế gốc."))
    else:
        h.append(BD.bd_rong(tieu, "Chưa nhập kịch bản: trên màn hình chọn Kịch bản (mua tài sản cố định, thưởng cuối năm, chi bị loại, chi phí / doanh thu thêm)."))
    tn = R.tn
    h.append(BD.bd_an_toan("Tiến độ tạm nộp so với mức tối thiểu", BD.bd_tien_do, "Tiến độ tạm nộp so với mức tối thiểu", tn["da_nop"], tn["toi_thieu"], tien,
                           "Đã nộp cho năm nay", "Tối thiểu 4 quý (%s thuế cả năm)" % pt(tn["ty_le"], 0),
                           ghi="Vạch đen = mức tối thiểu; thanh vàng khi chưa đủ. Còn thiếu %s%s." % (
                               tien(tn["thieu"]), (", hạn gần nhất %s (quý %d)" % (vn(tn["han_gan"]["han"]), tn["han_gan"]["q"])) if tn["han_gan"] is not None and tn["thieu"] > 0.5 else "")))
    try:
        da = _nop_quy(R)
    except Exception:
        da = [0.0] * 4
    q = tn["quy"]
    ghi = "Đã nộp tính theo tháng nộp tiền (Nợ 3334 / Có 111, 112, 113)%s; gợi ý nộp thêm chia đều cho các quý chưa đến hạn để đủ mức tối thiểu." % (
        (", đã trừ %s thuế năm trước còn nợ đầu năm" % tien(tn["no_cu"])) if tn["no_cu"] > 0.5 else "")
    if tn["du_dau"] > 0.5:
        ghi += " Nộp thừa đầu năm chuyển sang %s không vẽ theo quý." % tien(tn["du_dau"])
    h.append(BD.bd_an_toan("Tạm nộp TNDN theo quý", BD.bd_cot, "Tạm nộp TNDN theo quý", ["Quý %d - hạn %s" % (x["q"], vn(x["han"])) for x in q],
                           [{"ten": "Đã nộp trong quý", "v": da, "mau": BD.BD_XANH}, {"ten": "Gợi ý nộp thêm (theo hạn)", "v": [x["goi_y"] for x in q], "mau": BD.BD_VANG}],
                           tien, H=190, nhan_tip=["Quý %d (%s - %s, hạn %s)" % (x["q"], x["tu"], x["den"], vn(x["han"])) for x in q], ghi=ghi,
                           rong="Chưa nộp tạm và không có số gợi ý nộp thêm."))
    return h


def viet_html_thue(R, ra):
    import dong_tien as BD
    ky = R.ky
    gioi = R.t_tron if R.base else R.t_cuoi
    ds = [(ky.chu(t), lntt(R.du_bao[t]), t > gioi) for t in range(1, 13)]
    mx = max([abs(v) for _, v, _ in ds] or [1]) or 1
    h = ["<!doctype html><html lang='vi'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>Thuế TNDN dự kiến</title>"
         "<style>body{font-family:Segoe UI,Arial,sans-serif;margin:16px;color:#1f2937;max-width:900px}h1{font-size:19px;color:#0b3d91;margin:0 0 2px}"
         ".g{color:#555;font-style:italic}td{padding:2px 8px;font-size:13px}"
         "table{border-collapse:collapse}.b td{border-bottom:1px solid #e5e7eb}.s{text-align:right}" + BD.BD_CSS + BD.BD_IN + "</style></head><body>",
         "<h1>Thuế TNDN dự kiến cả năm %s - %s</h1><p class='g'>Ước tính từ sổ kế toán, chỉ đọc. %s</p>" % (ky.chu(1), ky.chu(12), html.escape(R.ts_ly_do)),
         "<table class='b'>"]
    for t, v in (("Lợi nhuận trước thuế đến nay", R.lntt_ytd), ("Lợi nhuận trước thuế cả năm (dự kiến)", R.lntt), ("Thu nhập tính thuế", R.goc["tntt"]),
                 ("Thuế TNDN dự kiến cả năm", R.goc["thue"]), ("Thuế nếu làm các kịch bản", R.kb_tong["thue"]), ("Đã tạm nộp cho năm nay", R.tn["da_nop"]),
                 ("Còn thiếu so với mức tối thiểu %s" % pt(R.tn["ty_le"], 0), R.tn["thieu"])):
        h.append("<tr><td>%s</td><td class='s'>%s</td></tr>" % (html.escape(t), tien(v)))
    h.append("</table>")
    tieu = "Lợi nhuận trước thuế theo tháng (xanh: thực tế, vàng: dự kiến)"
    if any(abs(v) >= 0.5 for _, v, _ in ds):
        sv = ["<svg viewBox='0 0 760 %d' width='760' height='%d' style='max-width:760px' role='img' aria-label='Lợi nhuận trước thuế theo tháng'>" % (24 * 12 + 10, 24 * 12 + 10)]
        for i, (t, v, uoc) in enumerate(ds):
            w = int(480 * abs(v) / mx)
            mau = "#dc2626" if v < 0 else ("#f59e0b" if uoc else "#2563eb")
            sv.append("<text x='0' y='%d' font-size='12'>%s</text><rect x='70' y='%d' width='%d' height='16' fill='%s'><title>%s (%s): %s</title></rect>"
                      "<text x='%d' y='%d' font-size='12'>%s</text>"
                      % (24 * i + 16, t, 24 * i + 4, max(w, 1), mau, t, "dự kiến" if uoc else "thực tế", tien(v), 76 + w, 24 * i + 16, tien(v)))
        sv.append("</svg>")
        h.append(BD.bd_khung(tieu, "".join(sv), "Đỏ: tháng lỗ. Tháng dự kiến = bình quân các tháng đã có số liệu (hoặc 3 tháng gần nhất)."))
    else:
        h.append(BD.bd_rong(tieu))
    h.extend(_bd_thue(R, BD))
    h.append("<h2 class='bd-t'>Cảnh báo</h2><table class='b'>")
    for m, l, nd, gy in R.canh_bao:
        h.append("<tr><td>%s</td><td>%s</td><td>%s</td><td class='g'>%s</td></tr>" % (html.escape(m), html.escape(l), html.escape(nd), html.escape(gy)))
    if not R.canh_bao:
        h.append("<tr><td class='g'>Không có cảnh báo.</td></tr>")
    h.append("</table></body></html>")
    with io.open(ra, "w", encoding="utf-8") as f:
        f.write("\n".join(h))
    return ra


# ====================================================================== C5 BAO CAO CHU DOANH NGHIEP
def _kpi(x):
    lg = x["dt"] - x["gv"]
    return {"dt": x["dt"], "gv": x["gv"], "lg": lg, "bien": (lg / x["dt"]) if x["dt"] > 0 else None, "cp": x["bh"] + x["ql"], "lntt": lntt(x)}


class ChuDN(object):
    def __init__(self, dl):
        self.dl = dl
        self.R = ThueNam(dl, bo_kb=True).tinh()          # bao cao chu DN: so thuc te, khong kich ban
        self.ky = self.R.ky
        self.loi = []
        self.canh_bao = []

    def tinh(self):
        R, ky = self.R, self.ky
        t_ref = R.t_tron if R.t_tron >= 1 else R.t_cuoi
        self.t_ref = t_ref
        rong = {k: 0.0 for k, _ in NHOM}
        thang = {k: R.T[k][t_ref] for k, _ in NHOM} if t_ref else dict(rong)
        truoc = {k: R.T[k][t_ref - 1] for k, _ in NHOM} if t_ref >= 2 else None
        luy = {k: sum(R.T[k][t] for t in range(1, t_ref + 1)) for k, _ in NHOM} if t_ref else dict(rong)
        self.k_thang, self.k_truoc, self.k_luy = _kpi(thang), (_kpi(truoc) if truoc else None), _kpi(luy)
        # so cu (moi ghi den truoc thang truoc): tien, cong no, dong tien tinh tai cuoi thang bao cao cho khop so lieu
        self.cu = bool(t_ref) and t_ref < ky.t_hien - 1
        self.ngay_bc = ky.cuoi(t_ref) if self.cu else ky.hom_nay
        # dong tien 4 tuan (GD156)
        self.L = None
        try:
            import dong_tien as DT
            dl2 = dict(self.dl)
            dl2["dt156"] = dict(self.dl.get("dt156") or {}, hom_nay=vn(self.ngay_bc), so_tuan=4)
            if self.cu:
                dl2["thang"] = [(self.dl.get("thang") or [1, 12])[0], t_ref]      # so du tien / 333 / 334 / 338 tai cuoi thang bao cao
            self.L = DT.lap_lich(dl2, self.ngay_bc)
        except Exception as e:
            self.loi.append("Dự báo dòng tiền: %s" % type(e).__name__)
        # lai / ton kho (GD159)
        self.lai = self.ton = None
        self.cb_lai, self.cb_ton = [], []
        if self.dl.get("ss"):
            try:
                import phan_tich_kd as PK
                P = PK.PhanTich(self.dl, self.ngay_bc)
                P.ts.loai = "LAI"
                self.lai = P.lai()
                self.cb_lai = list(P.canh_bao)
                P.ts.loai = "TON"
                self.ton = P.ton()
                self.cb_ton = list(P.canh_bao)
            except Exception as e:
                self.loi.append("Lãi / tồn kho: %s" % type(e).__name__)
        self.lap_canh_bao()
        return self

    # ------------------------------------------------------------------ 5 canh bao
    def lap_canh_bao(self):
        ds = []                                 # (muc, so tien de xep, noi dung, viec)
        L, R = self.L, self.R
        if L:
            if L["am"]:
                w = L["am"][0]
                ds.append(("Cao", abs(L["du"][w]), "Tiền dự kiến âm từ tuần %d (%s): thấp nhất %s." % (w + 1, self._tuan(w), tien(L["du"][L["thap"]])),
                           "Đòi nợ quá hạn, lùi khoản chi chưa gấp, chuẩn bị vay ngắn hạn."))
            phai_thu = sum(h["con"] for h in L["thu_ok"]) + L["tong_thu_qua"]
            if L["tong_thu_qua"] > 0.5:
                top = self._top_qua()
                ds.append(("Cao" if L["tong_thu_qua"] > 0.2 * max(phai_thu, 1) else "Vừa", L["tong_thu_qua"],
                           "Khách nợ quá hạn %s (%s phải thu)%s." % (tien(L["tong_thu_qua"]), pt(L["tong_thu_qua"] / phai_thu, 0) if phai_thu > 0 else "",
                                                                      ("; lớn nhất: " + top[0][0] + " " + tien(top[0][1])) if top else ""),
                           "Gọi điện / gửi thư đối chiếu công nợ, tạm dừng bán chịu cho khách nợ lâu."))
        for m, l, nd, gy in R.canh_bao:
            if m in ("Cao", "Vừa") and l != "Chưa có doanh thu năm trước":
                so = R.tn["thieu"] if l.startswith("Tạm nộp") else abs(R.lntt) if l.startswith("Dự kiến lỗ") else 0.0
                ds.append((m, so, "%s: %s" % (l, nd), gy))
        lo = [x for x in self.cb_lai if x[1] == "Mặt hàng bán lỗ"]
        if lo:
            tong_lo = sum(-r["lg"] for r in (self.lai or {}).get("vt", []) if r["vt"] and r["dt"] > 0 and r["lg"] < -0.5)
            ds.append(("Cao", tong_lo, "%d mặt hàng bán lỗ (lỗ gộp %s), ví dụ %s." % (len(lo), tien(tong_lo), lo[0][3][:80]),
                       "Kiểm tra giá bán, chiết khấu, giá xuất kho."))
        kh = [x for x in self.cb_lai if x[1] == "Khách lãi mỏng mà trả chậm"]
        if kh:
            ds.append(("Vừa", 0.0, "%d khách lãi mỏng mà trả chậm, ví dụ %s." % (len(kh), kh[0][3][:80]), kh[0][4]))
        if self.ton:
            d = self.ton["dong"]
            am = [r for r in d if r["l"] < -1e-9]
            if am:
                ds.append(("Cao", 0.0, "%d mã hàng âm kho, ví dụ %s %s." % (len(am), am[0]["ma"], am[0]["ten"][:50]), "Tính lại giá xuất / kiểm tra phiếu nhập xuất."))
            cham = [r for r in d if r["cham"]]
            if cham:
                gt = sum(r["t"] for r in cham)
                ds.append(("Vừa", gt, "%d mã chậm luân chuyển, giá trị %s (%s tồn kho)." % (len(cham), tien(gt), pt(gt / self.ton["tong"], 0) if self.ton["tong"] > 0 else ""),
                           "Giảm giá, thanh lý, ngừng nhập; xem dự phòng giảm giá hàng tồn kho."))
            dat = [r for r in d if r["dat"] > 0]
            if dat:
                nvl = sum(1 for r in dat if r["nvl"])
                ds.append(("Vừa" if nvl else "Thấp", 0.0, "%d mã cần đặt hàng / sắp hết%s, ví dụ %s %s." % (
                    len(dat), (" (%d nguyên vật liệu)" % nvl) if nvl else "", dat[0]["ma"], dat[0]["ten"][:50]), "Đặt hàng / lên kế hoạch sản xuất."))
        a, b = self.k_thang, self.k_truoc
        if b and b["lntt"] > 0 and a["lntt"] < 0.7 * b["lntt"] and (b["lntt"] - a["lntt"]) > 0.05 * max(abs(self.k_luy["dt"]), 1):
            ds.append(("Vừa", b["lntt"] - a["lntt"], "Lãi tháng %s giảm %s so với tháng trước (%s xuống %s)." % (
                self.ky.chu(self.t_ref), pt((b["lntt"] - a["lntt"]) / b["lntt"], 0), tien(b["lntt"]), tien(a["lntt"])),
                "Xem doanh thu, giá vốn, chi phí phát sinh lớn trong tháng."))
        if a["bien"] is not None and self.k_luy["bien"] is not None and a["dt"] > 0.03 * max(self.k_luy["dt"], 1) and a["bien"] < self.k_luy["bien"] - 0.05:
            ds.append(("Vừa", 0.0, "Biên lãi gộp tháng %s là %s, thấp hơn bình quân năm %s." % (self.ky.chu(self.t_ref), pt(a["bien"]), pt(self.k_luy["bien"])),
                       "Kiểm tra giá vốn, giá bán, hàng khuyến mại trong tháng."))
        ds.sort(key=lambda x: (-MUC.get(x[0], 0), -x[1]))
        self.canh_bao = ds

    def _tuan(self, w):
        a = self.L["hom_nay"] + _dt.timedelta(days=7 * w)
        return "%s-%s" % (a.strftime("%d/%m"), (a + _dt.timedelta(days=6)).strftime("%d/%m"))

    def _top_qua(self, n=3):
        L = self.L
        S = L["S"]
        g = {}
        for h in L["thu_qua"]:
            g[h["kh"]] = g.get(h["kh"], 0.0) + h["con"]
        ds = sorted(g.items(), key=lambda x: -x[1])[:n]
        return [((S.ten_dt(kh) or ("mã %s" % kh))[:40], v) for kh, v in ds if v > 0.5]


def _td(x, cls=""):
    return "<td%s>%s</td>" % ((" class='%s'" % cls) if cls else "", x)


def _bd_chu(C):
    """GD176: hai bieu do gon cho trang A4 (doanh thu / lai truoc thue theo thang; so du tien hien co + 4 tuan toi), dat canh nhau."""
    import dong_tien as BD
    R, ky, L = C.R, C.ky, C.L
    o = []
    t1 = "Doanh thu và lãi trước thuế theo tháng"
    if C.t_ref:
        ts = list(range(1, C.t_ref + 1))
        x = [{k: R.T[k][t] for k, _ in NHOM} for t in ts]
        o.append(BD.bd_an_toan(t1, BD.bd_cot, t1, ["%02d" % ky.lich(t)[1] for t in ts],
                               [{"ten": "Doanh thu thuần", "v": [y["dt"] for y in x], "mau": BD.BD_XAM},
                                {"ten": "Lãi (lỗ) trước thuế", "v": [lntt(y) for y in x], "mau": BD.BD_XANH, "mau_am": BD.BD_DO}],
                               tien, W=340, H=92, fs=9, nhan_tip=["Tháng %s" % ky.chu(t) for t in ts]))
    else:
        o.append(BD.bd_rong(t1))
    t2 = "Số dư tiền hiện có và 4 tuần tới"
    if L:
        n = min(4, L["so_tuan"])
        o.append(BD.bd_an_toan(t2, BD.bd_cot, t2, ["Hiện có"] + ["T%d" % (w + 1) for w in range(n)],
                               [{"ten": "Số dư tiền", "v": [L["tien_dau"]] + list(L["du"][:n]), "mau": BD.BD_XANH, "mau_am": BD.BD_DO}],
                               tien, W=340, H=92, fs=9, nhan_tip=["Hiện có ngày %s" % vn(C.ngay_bc)] + ["Cuối tuần %s" % C._tuan(w) for w in range(n)],
                               ghi="Cột đỏ: dự kiến âm tiền."))
    else:
        o.append(BD.bd_rong(t2, "Chưa lập được dự báo dòng tiền."))
    return "<div class='luoi'><div>%s</div><div>%s</div></div>" % (o[0], o[1])


def viet_html_chu(C, ra):
    R, ky, L = C.R, C.ky, C.L
    cty = (C.dl.get("cty") or {}).get("ten") or ""
    thang = ky.chu(C.t_ref) if C.t_ref else "-"
    e = html.escape
    import dong_tien as BD
    h = ["<!doctype html><html lang='vi'><head><meta charset='utf-8'><title>Báo cáo chủ doanh nghiệp %s</title><style>" % thang,
         "@page{size:A4 portrait;margin:10mm}*{box-sizing:border-box}body{font-family:Segoe UI,Arial,sans-serif;font-size:11.5px;color:#111827;margin:0;"
         "background:#fff}.trang{max-width:190mm;margin:0 auto;padding:8px}h1{font-size:17px;margin:0;color:#0b3d91}h2{font-size:12.5px;margin:8px 0 3px;"
         "color:#0b3d91;border-bottom:1px solid #c7d2fe}.g{color:#555;font-size:10.5px}.luoi{display:grid;grid-template-columns:1fr 1fr;gap:0 14px}"
         "table{border-collapse:collapse;width:100%}td,th{padding:2px 4px;border-bottom:1px solid #e5e7eb;vertical-align:top}th{background:#eef2ff;"
         "text-align:left;font-weight:600}.s{text-align:right;white-space:nowrap}.am{color:#b91c1c;font-weight:600}.tot{color:#047857}"
         ".cb td{border-bottom:1px solid #f3f4f6}.muc{font-weight:700;white-space:nowrap}.Cao{color:#b91c1c}.Vua{color:#b45309}.Thap{color:#2563eb}"
         ".nut{margin:6px 0}@media print{.nut{display:none}}" + BD.BD_CSS +
         ".trang h2.bd-t{font-size:11px;margin:6px 0 1px;color:#374151;border:0}.trang .bd{margin:0 0 2px}.trang .bd-ghi,.trang .bd-cg{font-size:10px;margin:0}"
         ".trang .bd-cg i{width:8px;height:8px}.trang .bd-rong{font-size:10.5px}</style></head><body><div class='trang'>",
         "<div class='nut'><button onclick='window.print()'>In / lưu PDF</button></div>",
         "<h1>BÁO CÁO NHANH CHO CHỦ DOANH NGHIỆP - THÁNG %s</h1>" % thang,
         "<div class='g'>%s. Lập %s từ sổ kế toán: số liệu ước tính, chưa kiểm toán, chỉ đọc sổ.%s</div>" % (
             e(cty), _dt.datetime.now().strftime("%d/%m/%Y %H:%M"),
             ((" Tháng %s đang ghi dở không đưa vào." % ky.chu(R.t_cuoi)) if R.do_dang else "")
             + ((" <b>Sổ mới ghi đến tháng %s: tiền, công nợ, dòng tiền tính tại ngày %s.</b>" % (thang, vn(C.ngay_bc))) if C.cu else "")),
         "<h2>1. Kết quả kinh doanh</h2><table><tr><th>Chỉ tiêu</th><th class='s'>Tháng %s</th><th class='s'>Tháng trước</th><th class='s'>Tăng / giảm</th>"
         "<th class='s'>Luỹ kế năm</th></tr>" % thang]
    a, b, c = C.k_thang, C.k_truoc, C.k_luy
    for ten, k in (("Doanh thu thuần", "dt"), ("Giá vốn", "gv"), ("Lãi gộp", "lg"), ("Chi phí bán hàng + quản lý", "cp"), ("Lãi (lỗ) trước thuế", "lntt")):
        tg = ""
        if b and abs(b[k]) > 0.5:
            r = (a[k] - b[k]) / abs(b[k])
            tg = ("+" if r >= 0 else "") + pt(r, 0)
        h.append("<tr>" + _td(e(ten)) + _td(tien(a[k]), "s" + (" am" if a[k] < 0 else "")) + _td(tien(b[k]) if b else "-", "s") + _td(tg, "s")
                 + _td(tien(c[k]), "s" + (" am" if c[k] < 0 else "")) + "</tr>")
    h.append("<tr>" + _td("Biên lãi gộp") + _td(pt(a["bien"]) if a["bien"] is not None else "-", "s") + _td(pt(b["bien"]) if b and b["bien"] is not None else "-", "s")
             + _td("") + _td(pt(c["bien"]) if c["bien"] is not None else "-", "s") + "</tr></table>")
    h.append(_bd_chu(C))                            # GD176: 2 bieu do gon, van 1 trang A4
    h.append("<div class='luoi'><div>")
    # tien + dong tien
    h.append("<h2>2. Tiền và dòng tiền 4 tuần %s</h2>" % ("sau ngày %s" % vn(C.ngay_bc) if C.cu else "tới"))
    if L:
        h.append("<table><tr><th>Tuần</th><th class='s'>Tiền vào</th><th class='s'>Tiền ra</th><th class='s'>Số dư cuối tuần</th></tr>")
        h.append("<tr>" + _td("Hiện có") + _td("") + _td("") + _td(tien(L["tien_dau"]), "s") + "</tr>")
        for w in range(min(4, L["so_tuan"])):
            h.append("<tr>" + _td(C._tuan(w)) + _td(tien(L["vao"][w]), "s") + _td(tien(L["ra"][w]), "s") + _td(tien(L["du"][w]), "s" + (" am" if L["du"][w] < 0 else "")) + "</tr>")
        h.append("</table>")
    else:
        h.append("<div class='g'>Chưa lập được dự báo dòng tiền.</div>")
    # cong no
    h.append("<h2>3. Công nợ</h2>")
    if L:
        phai_thu = sum(x["con"] for x in L["thu_ok"]) + L["tong_thu_qua"]
        phai_tra = sum(x["con"] for x in L["tra_ok"]) + sum(x["con"] for x in L["tra_ngay"]) + sum(x["con"] for x in L["tra_cu"])
        import dong_tien as DT
        den_han = sum(L["bang"][DT.DONG[4]][w] for w in range(min(4, L["so_tuan"])))
        h.append("<table>")
        h.append("<tr>" + _td("Phải thu khách hàng") + _td(tien(phai_thu), "s") + "</tr>")
        h.append("<tr>" + _td("Trong đó quá hạn") + _td(tien(L["tong_thu_qua"]), "s" + (" am" if L["tong_thu_qua"] > 0.5 else "")) + "</tr>")
        for ten, v in C._top_qua():
            h.append("<tr>" + _td("&nbsp;&nbsp;- " + e(ten), "g") + _td(tien(v), "s g") + "</tr>")
        h.append("<tr>" + _td("Phải trả nhà cung cấp") + _td(tien(phai_tra), "s") + "</tr>")
        h.append("<tr>" + _td("Phải trả đến hạn trong 4 tuần") + _td(tien(den_han), "s") + "</tr></table>")
    else:
        h.append("<div class='g'>Chưa có số liệu công nợ.</div>")
    h.append("</div><div>")
    # ton kho
    h.append("<h2>4. Hàng tồn kho</h2>")
    if C.ton and (C.ton["dong"] or C.ton["tong"]):
        d = C.ton["dong"]
        cham = [r for r in d if r["cham"]]
        h.append("<table>")
        h.append("<tr>" + _td("Giá trị tồn kho") + _td(tien(C.ton["tong"]), "s") + "</tr>")
        h.append("<tr>" + _td("Chậm luân chuyển (%d mã)" % len(cham)) + _td(tien(sum(r["t"] for r in cham)), "s") + "</tr>")
        h.append("<tr>" + _td("Cần đặt hàng / sắp hết") + _td("%d mã" % sum(1 for r in d if r["dat"] > 0), "s") + "</tr>")
        n_am = sum(1 for r in d if r["l"] < -1e-9)
        if n_am:
            h.append("<tr>" + _td("Âm kho") + _td("%d mã" % n_am, "s am") + "</tr>")
        h.append("</table><div class='g'>Số liệu tồn kho đến %s.</div>" % vn(C.ton["den"]))
    else:
        h.append("<div class='g'>Không có hàng tồn kho theo dõi trong sổ.</div>")
    # thue
    h.append("<h2>5. Thuế sắp nộp</h2><table>")
    co_thue = False
    if L:
        for ten, d, v, nguon in L["nghia_vu"]:
            if nguon == "số dư hiện tại":
                h.append("<tr>" + _td(e(ten)) + _td(vn(d), "s") + _td(tien(v), "s") + "</tr>")
                co_thue = True
    tn = R.tn
    if tn["han_gan"] is not None and tn["thieu"] > 0.5:
        h.append("<tr>" + _td("Tạm nộp TNDN quý %d (để đủ %s)" % (tn["han_gan"]["q"], pt(tn["ty_le"], 0))) + _td(vn(tn["han_gan"]["han"]), "s")
                 + _td(tien(tn["han_gan"]["goi_y"]), "s") + "</tr>")
        co_thue = True
    h.append("<tr>" + _td("Thuế TNDN dự kiến cả năm (%s)" % pt(R.ts, 0)) + _td("") + _td(tien(R.goc["thue"]), "s") + "</tr>")
    h.append("</table>")
    if not co_thue:
        h.append("<div class='g'>Không có khoản thuế còn phải nộp trên sổ.</div>")
    h.append("</div></div>")
    # top mat hang / khach
    if C.lai and C.lai.get("dt"):
        h.append("<div class='luoi'><div><h2>Mặt hàng lãi gộp cao nhất (luỹ kế)</h2><table>")
        for x in [y for y in C.lai["vt"] if y["vt"]][:3]:
            h.append("<tr>" + _td(e((x["ten"] or x["ma"])[:42])) + _td(tien(x["lg"]), "s") + _td(pt(x["bien"]) if x["bien"] is not None else "", "s") + "</tr>")
        h.append("</table></div><div><h2>Khách hàng doanh thu lớn nhất (luỹ kế)</h2><table>")
        for x in [y for y in C.lai["kh"] if y["kh"]][:3]:
            h.append("<tr>" + _td(e((x["ten"] or x["ma"])[:42])) + _td(tien(x["dt"]), "s") + _td(("nợ quá hạn " + tien(x["qua_han"])) if x["qua_han"] > 0.5 else "", "s am") + "</tr>")
        h.append("</table></div></div>")
    # canh bao
    h.append("<h2>6. Năm việc cần chú ý</h2><table class='cb'>")
    for m, _, nd, viec in C.canh_bao[:5]:
        h.append("<tr><td class='muc %s'>%s</td><td>%s<br><span class='g'>%s</span></td></tr>" % (m.replace("ừ", "u").replace("ấ", "a"), e(m), e(nd), e(viec)))
    if not C.canh_bao:
        h.append("<tr><td class='tot'>Không có cảnh báo quan trọng.</td></tr>")
    h.append("</table>")
    if C.loi:
        h.append("<div class='g'>Chưa lập được: %s.</div>" % e("; ".join(C.loi)))
    h.append("<div class='g' style='margin-top:6px'>Lập bằng UNESCO AI (Dữ liệu > Báo cáo chủ doanh nghiệp). Số liệu theo sổ đến thời điểm lập; "
             "dòng tiền, thuế cả năm là dự kiến.</div></div></body></html>")
    os.makedirs(os.path.dirname(os.path.abspath(ra)), exist_ok=True)
    with io.open(ra + ".tmp", "w", encoding="utf-8") as f:
        f.write("\n".join(h))
    os.replace(ra + ".tmp", ra)
    return ra


def ghi_txt_chu(C, ra_txt, tep):
    a, c = C.k_thang, C.k_luy
    L = C.L
    tong = "TONG;CHU;%s;%d;%d;%d;%d;%d;%d;%d;%s" % (
        C.ky.chu(C.t_ref) if C.t_ref else "", round(a["dt"]), round(a["lntt"]), round(c["dt"]), round(c["lntt"]),
        round(L["tien_dau"]) if L else 0, round(L["tong_thu_qua"]) if L else 0, len(C.canh_bao), _sach(tep, 400))
    dong = [tong] + ["C;%s;%s" % (_sach(m), _sach(nd, 220)) for m, _, nd, _ in C.canh_bao[:5]]
    _ghi(ra_txt, dong)


# ====================================================================== chay
def chay(duong_json, ra):
    with io.open(duong_json, "r", encoding="utf-8-sig") as f:
        dl = json.loads(f.read(), strict=False)
    b = dl.get("td160") or {}
    txt = os.path.join(GOC, "ket-qua", TEP_KQ)
    if str(b.get("loai") or "").upper() == "CHU":
        C = ChuDN(dl).tinh()
        thu_muc = os.path.dirname(ra) if ra else os.path.join(GOC, "ket-qua")
        if C.t_ref:
            y, m = C.ky.lich(C.t_ref)
        else:
            y, m = C.ky.hom_nay.year, C.ky.hom_nay.month
        tep = os.path.join(thu_muc, "BaoCao_ChuDN_%04d_%02d.html" % (y, m))
        viet_html_chu(C, tep)
        ghi_txt_chu(C, txt, tep)
        return tep, ""
    R = ThueNam(dl).tinh()
    if not ra:
        ra = os.path.join(GOC, "ket-qua", "ThueTNDN_DuKien.xlsx")
    lap_excel_thue(R, ra)
    viet_html_thue(R, os.path.splitext(ra)[0] + ".html")
    ghi_txt_thue(R, txt, ra)
    return ra, ""


if __name__ == "__main__":
    import sys
    if len(sys.argv) >= 2:
        print(chay(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else ""))
