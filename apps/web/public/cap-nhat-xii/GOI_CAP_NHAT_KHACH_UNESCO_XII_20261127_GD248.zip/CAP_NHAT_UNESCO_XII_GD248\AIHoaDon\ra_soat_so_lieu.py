# -*- coding: utf-8 -*-
"""GD362 - RA SOAT SO LIEU: ghep ma khach hang, ghep ma vat tu, chuyen nhom vat tu, ghep so phu.
May CHI DOC so (jet_doc, 'rb'). Tinh ra KE HOACH ghep (ket-qua\\ghep_tu_dong.txt):
  H;TEN_SO (dong dau: VB so voi so dang mo)
  G;LOAI;KHOA;GIATRI;TIN_CAY;MAY(1/0);LY_DO     - dong MAY=1: VB (ModGhep362) tu ghi, co sao luu + nhat ky
  SL;NHOM;MUC;SO;MO_TA;DE_XUAT                  - tong hop phat hien (HTML + bao cao)
Chi tu ghep khi KHOP CHINH XAC va DUY NHAT (tin cay >= 90). Con lai chi de xuat, khong ghi.
Khong tao ma moi, khong sua chung tu ke toan, khong dung so tien."""
import io
import os
import re
from collections import defaultdict

import bang_luong_gd78 as BL
import jet_doc

TEP = "ghep_tu_dong"
NGUONG_TU_GHEP = 90


def _s(x):
    return str(x if x is not None else "").strip()


def _i(x):
    try:
        return int(float(x))
    except Exception:
        return 0


def _vang(x):
    """'...' la gia tri rong cua so cu."""
    t = _s(x)
    return "" if t in ("...", "0") else t


def _mst(x):
    return re.sub(r"[^0-9\-]", "", _s(x)).strip("-")


def _mst10(x):
    return _mst(x)[:10]


def _so_hd(x):
    return _s(x).lstrip("0") or "0"


def doc_bang(duong):
    m = jet_doc.Mdb(duong)
    try:
        b = {k.lower(): k for k in m.bang()}

        def tb(t):
            k = b.get(t.lower())
            return m.doc(k) if k else []
        return {t: tb(t) for t in ("HDDTTaiVe", "KhachHang", "Vattu", "PhanLoaiVattu", "HoaDon", "HDDT_GhepMa", "HDDT_SP_Dong",
                                   "HDDT_SP_HocMa", "HDDT_SP_TaiKhoanNH", "HDDT_SP_MaMoi", "HeThongTK", "ChungTu")}
    finally:
        try:
            m.dong()
        except Exception:
            pass


def ra_soat(B):
    """B = doc_bang(...). Tra {'ke_hoach': [...], 'phat_hien': [...]}"""
    kh_ds, vt_ds, pl_ds = B["KhachHang"], B["Vattu"], B["PhanLoaiVattu"]
    tk = {r["MaSo"]: _s(r.get("SoHieu")) for r in B["HeThongTK"]}
    ke_hoach, ph = [], []

    def kh_them(loai, khoa, giatri, tc, may, ly):
        ke_hoach.append({"loai": loai, "khoa": khoa, "giatri": giatri, "tin_cay": tc, "may": 1 if (may and tc >= NGUONG_TU_GHEP) else 0, "ly_do": ly})

    # ---------------- 1. ma khach hang <-> MST
    theo_mst = defaultdict(list)
    for r in kh_ds:
        m = _mst10(r.get("MST"))
        if m:
            theo_mst[m].append(r)
    trung = {m: v for m, v in theo_mst.items() if len(v) > 1 and len({_mst(x.get("MST")) for x in v}) == 1 and len({_s(x.get("SoHieu")) for x in v}) > 1}
    # MST co chi nhanh (-001) la khac nhau; chi bao cung MST day du
    if trung:
        ph.append(("KHACH_HANG", "CHU_Y", len(trung), "mã số thuế có nhiều mã khách hàng", "gộp mã trùng trước khi ghép: " + ", ".join(sorted(trung)[:5])))
    thieu_kh, khong_mst = {}, 0
    for h in B["HDDTTaiVe"]:
        if _vang(h.get("AIPartyCode")):
            continue
        doi_tac = _mst(h.get("MSTNguoiMuaNguoiNhanHang")) if h.get("HDBanRa") else _mst(h.get("MSTNguoiBanNguoiXuatHang"))
        ten = _s(h.get("TenNguoiMuaNguoiNhanHang") if h.get("HDBanRa") else h.get("TenNguoiBanNguoiXuatHang"))
        if not doi_tac:
            khong_mst += 1
            continue
        ds = theo_mst.get(doi_tac[:10], [])
        full = [x for x in ds if _mst(x.get("MST")) == doi_tac] or ds
        if len(full) == 1:
            kh_them("GHEP_KH_HD", h["MaSo"], _s(full[0].get("SoHieu")), 98 if _mst(full[0].get("MST")) == doi_tac else 92, True, "MST " + doi_tac)
        elif len(full) > 1:
            ph.append(("KHACH_HANG", "CAN_NGUOI", 1, "hoá đơn %s: MST %s có %d mã khách hàng" % (_s(h.get("SoHoaDon")), doi_tac, len(full)), "chọn mã đúng"))
        else:
            thieu_kh[doi_tac] = ten
    if thieu_kh:
        ph.append(("KHACH_HANG", "DE_XUAT", len(thieu_kh), "đối tác trên hoá đơn chưa có mã khách hàng (không tự tạo mã mới)", "; ".join("%s %s" % (m, t[:30]) for m, t in list(thieu_kh.items())[:5])))
    if khong_mst:
        ph.append(("KHACH_HANG", "CHU_Y", khong_mst, "dòng hoá đơn không có MST đối tác (bán lẻ / người mua không lấy hoá đơn)", "ghép tay hoặc dùng mã khách lẻ"))

    # ---------------- 2. ma vat tu <-> ten hang hoa don
    vt_ten = defaultdict(list)
    for r in vt_ds:
        vt_ten[BL.khoa_ten(r.get("TenVattu"))].append(r)
    hoc = {}
    for g in B["HDDT_GhepMa"]:
        k = (_mst(g.get("MST")), _s(g.get("KhoaTen")))
        if _vang(g.get("MaVT")):
            hoc[k] = _s(g.get("MaVT"))
    khong_vt = {}
    for h in B["HDDTTaiVe"]:
        if _vang(h.get("MaVT")) or not _s(h.get("TenHangHoaDichVu")):
            continue
        if not h.get("SoLuong") and not h.get("ThanhTienChuaThue"):
            continue          # dong ghi chu / chiet khau
        ten = BL.khoa_ten(h.get("TenHangHoaDichVu"))
        mst = _mst(h.get("MSTNguoiBanNguoiXuatHang") if not h.get("HDBanRa") else h.get("MSTNguoiMuaNguoiNhanHang"))
        ma = hoc.get((mst, ten))
        nguon, tc = "đã học (cùng đối tác và tên hàng)", 96
        if not ma:
            ds = vt_ten.get(ten, [])
            if len(ds) == 1:
                ma, nguon, tc = _s(ds[0].get("SoHieu")), "trùng tên vật tư", 94
            elif len(ds) > 1:
                ph.append(("VAT_TU", "CAN_NGUOI", 1, "hàng '%s' trùng tên %d vật tư" % (_s(h.get("TenHangHoaDichVu"))[:30], len(ds)), "chọn mã đúng"))
                continue
        if ma:
            kh_them("GHEP_VT_HD", h["MaSo"], ma, tc, True, nguon)
        else:
            khong_vt[ten] = _s(h.get("TenHangHoaDichVu"))
    if khong_vt:
        ph.append(("VAT_TU", "DE_XUAT", len(khong_vt), "tên hàng trên hoá đơn chưa khớp vật tư nào (không tự tạo vật tư)", "; ".join(list(khong_vt.values())[:5])))

    # ---------------- 3. chuyen nhom vat tu theo tai khoan thuc te su dung
    pl_id = {p["MaSo"]: p for p in pl_ds}
    tk_vt = defaultdict(set)
    for r in B["ChungTu"]:
        v = _i(r.get("MaVattu"))
        if v > 0:
            for k in ("MaTKNo", "MaTKCo"):
                s = tk.get(r.get(k), "")
                if s and s[:3] in ("152", "153", "154", "155", "156", "157", "632"):
                    tk_vt[v].add(s)
    pl_theo_tk = defaultdict(list)
    for p in pl_ds:
        s = tk.get(p.get("MaTK"), "")
        if s:
            pl_theo_tk[s[:3]].append(p)
    mo_coi, lech = 0, 0
    for r in vt_ds:
        cur = _i(r.get("MaPhanLoai"))
        dung = {s[:3] for s in tk_vt.get(r["MaSo"], set()) if s[:3] != "632" and s[:3] != "154"}
        if cur not in pl_id:
            mo_coi += 1
            cs = {p["MaSo"] for t in dung for p in pl_theo_tk.get(t, [])}
            if len(cs) == 1:
                kh_them("CHUYEN_NHOM_VT", r["MaSo"], str(next(iter(cs))), 92, True, "nhóm chưa có / không tồn tại; tài khoản đang dùng %s" % ",".join(sorted(dung)))
            else:
                ph.append(("NHOM_VAT_TU", "CAN_NGUOI", 1, "vật tư %s chưa có nhóm" % _s(r.get("SoHieu")), "chọn nhóm"))
            continue
        thuoc = tk.get(pl_id[cur].get("MaTK"), "")[:3]
        if dung and thuoc and thuoc not in dung:
            cs = {p["MaSo"] for t in dung for p in pl_theo_tk.get(t, [])}
            if len(cs) == 1:
                lech += 1
                kh_them("CHUYEN_NHOM_VT", r["MaSo"], str(next(iter(cs))), 75, False, "nhóm %s (TK %s) nhưng chứng từ dùng TK %s" % (_s(pl_id[cur].get("SoHieu")), thuoc, ",".join(sorted(dung))))
    if lech:
        ph.append(("NHOM_VAT_TU", "DE_XUAT", lech, "vật tư nằm nhóm lệch với tài khoản thực tế dùng trong chứng từ (không tự chuyển vì đổi nhóm đổi tài khoản kho)", "xem ghep_tu_dong.txt dòng G;CHUYEN_NHOM_VT có MAY=0"))
    if mo_coi:
        ph.append(("NHOM_VAT_TU", "CHU_Y", mo_coi, "vật tư chưa có nhóm hợp lệ", ""))

    # ---------------- 4. so phu ngan hang
    kh_mst = {m: v[0] for m, v in theo_mst.items() if len(v) == 1}
    hocma = {(_s(x.get("Chieu")), _s(x.get("DoiUngSTK"))): x for x in B["HDDT_SP_HocMa"] if _vang(x.get("MaKH"))}
    tknh = {_s(x.get("SoTKNH")) for x in B["HDDT_SP_TaiKhoanNH"] if _vang(x.get("TK112"))}
    thieu_tk, cho_nguoi, cho_tong = set(), 0, 0
    for r in B["HDDT_SP_Dong"]:
        if _s(r.get("TrangThai")).upper() in ("DA_HACH_TOAN", "BO_QUA"):
            continue
        cho_tong += 1
        if _s(r.get("SoTKNH")) and _s(r.get("SoTKNH")) not in tknh:
            thieu_tk.add(_s(r.get("SoTKNH")))
        if _vang(r.get("MaKH")) or _i(r.get("MaNV")) > 0:
            continue
        ma = None
        mst = _mst(r.get("MSTNoiDung"))
        if mst and mst[:10] in kh_mst:
            ma, nguon, tc = kh_mst[mst[:10]], "MST trong nội dung", 95
        else:
            chieu = "VAO" if _i(r.get("TienVao")) else "RA"
            hm = hocma.get((chieu, _s(r.get("DoiUngSTK")))) if _vang(r.get("DoiUngSTK")) else None
            if hm:
                ma, nguon, tc = hm.get("MaKH"), "đã học theo số tài khoản đối ứng", 93
        if ma:
            kh_them("SP_GHEP_KH", r["MaSo"], _s(ma.get("SoHieu") if isinstance(ma, dict) else ma), tc, True, nguon)
        else:
            cho_nguoi += 1
    if thieu_tk:
        ph.append(("SO_PHU", "CAN_NGUOI", len(thieu_tk), "tài khoản ngân hàng chưa khai báo TK 112", ", ".join(sorted(thieu_tk))))
    if cho_nguoi:
        ph.append(("SO_PHU", "CAN_NGUOI", cho_nguoi, "dòng sao kê chưa ghép được mã khách / nhân viên (máy không đoán)", "ghép trên màn hình Sổ phụ; máy sẽ học cho lần sau"))
    # ---------------- 4b. hoa don ban ra ghi trung (ghi tay '566' + tai ve '00000566' cung thang, cung tien)
    nhom = defaultdict(list)
    for r in B["ChungTu"]:
        if _i(r.get("MaLoai")) != 8:
            continue
        so = _s(r.get("SoHieu")).lstrip("0")
        if so:
            nhom[(_i(r.get("ThangCT")), so, round(float(r.get("SoPS") or 0)), tk.get(r.get("MaTKCo"), ""))].append(r)
    trung_hd = {}
    for k, rs in nhom.items():
        mact = {r.get("MaCT") for r in rs}
        if len(mact) > 1 and len({_s(r.get("SoHieu")) for r in rs}) > 1:
            trung_hd.setdefault(k[0], set()).update(mact)
    for t in sorted(trung_hd):
        ph.append(("HOA_DON", "CAN_NGUOI", len(trung_hd[t]), "tháng %d: %d chứng từ bán ra trùng số hoá đơn (ghi tay và tải về cùng tồn tại)" % (t, len(trung_hd[t])),
                   "doanh thu tháng bị nhân đôi - xoá bản ghi tay hoặc bản tải về trên màn hình Hoá đơn (máy không tự xoá)"))
    # ---------------- 5. so du le TK 154 cuoi ky
    sai = defaultdict(float)
    for r in B["ChungTu"]:
        n, c = tk.get(r.get("MaTKNo"), ""), tk.get(r.get("MaTKCo"), "")
        v = float(r.get("SoPS") or 0)
        if n.startswith("154"):
            sai[_i(r.get("ThangCT"))] += v
        if c.startswith("154"):
            sai[_i(r.get("ThangCT"))] -= v
    for t, v in sorted(sai.items()):
        if 0 < abs(v) <= 10:
            ph.append(("GIA_THANH", "DE_XUAT", 1, "tháng %d: TK 154 phát sinh lệch %d đồng (làm tròn giá thành)" % (t, round(v)), "đẩy chênh lệch vào dòng cuối phiếu KCTP của tháng"))
    # gop cac phat hien giong nhau (cung nhom, muc, mo ta) -> mot dong, cong so
    gop, thu_tu = {}, []
    for g, muc, so, mo, de in ph:
        k = (g, muc, mo)
        if k in gop:
            gop[k][2] += so
        else:
            gop[k] = [g, muc, so, mo, de]
            thu_tu.append(k)
    return {"ke_hoach": ke_hoach, "phat_hien": [tuple(gop[k]) for k in thu_tu]}


def ghi(kq, thu_muc, so=""):
    os.makedirs(thu_muc, exist_ok=True)
    p = os.path.join(thu_muc, TEP + ".txt")
    L = ["H;%s" % _s(so).replace(";", ",")]
    for k in kq["ke_hoach"]:
        L.append("G;%s;%s;%s;%d;%d;%s" % (k["loai"], k["khoa"], k["giatri"], k["tin_cay"], k["may"], _s(k["ly_do"]).replace(";", ",")))
    for g, muc, so, mo, de in kq["phat_hien"]:
        L.append("SL;%s;%s;%d;%s;%s" % (g, muc, so, mo.replace(";", ","), de.replace(";", ",")))
    with io.open(p, "w", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")
    return p


def chay(duong, thu_muc, so=""):
    kq = ra_soat(doc_bang(duong))
    return kq, ghi(kq, thu_muc, so or os.path.splitext(os.path.basename(duong))[0])


if __name__ == "__main__":
    import sys
    kq, p = chay(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else ".")
    from collections import Counter
    print(Counter((k["loai"], k["may"]) for k in kq["ke_hoach"]))
    for x in kq["phat_hien"]:
        print(x)
