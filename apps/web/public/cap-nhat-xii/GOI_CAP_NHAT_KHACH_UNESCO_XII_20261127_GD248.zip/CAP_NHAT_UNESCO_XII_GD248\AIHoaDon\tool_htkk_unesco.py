# -*- coding: utf-8 -*-
"""
tool_htkk_unesco.py - Ket xuat va KIEM TRA To khai thue GTGT / Bao cao tai chinh
                      sang HTKK cua Cuc Thue, cho phan mem ke toan UNESCO XI.

BAN GD24 - doi chieu voi ho so THAT da nop cua doanh nghiep:
    <MST>000-01_GTGT_TT80-Q12026-L00.xml         (01/GTGT, maTKhai 842, pban 2.8.3)
    <MST>000-133_B01A_DNN_BCTC-Y2025-L00.xml     (B01a-DNN TT133, maTKhai 683, pban 2.3.2)

CACH LAM (va vi sao lam the):
  HTKK nhan du lieu qua nut "Nhap tu XML" ngay trong man hinh tung to khai.
  Cau truc XML cua HTKK KHONG duoc cong bo, lai doi theo tung phien ban va tung
  mau to khai. Doan cau truc = chac chan bi HTKK bao "Cau truc to khai XML nhap
  vao khong hop le", hoac te hon la nhan file nhung dat sai chi tieu.

  Vi vay tool KHONG TU CHE cau truc. Nguoi dung lam MOT LAN cho moi mau to khai:
      HTKK -> mo to khai do (de trong cung duoc) -> "Ket xuat XML"
  roi chi cho tool file XML ay. Tool doc file that de biet khai bao XML, ten the
  goc, vung ten, ma to khai, phien ban va VI TRI DAY DU cua tung chi tieu trong
  cay XML. Sau do tool chi DIEN SO vao dung nhung the ay.

BA LOI CUA BAN GD21 DA SUA O BAN NAY (deu phat hien khi doi chieu file that):

  (1) RO RI SO LIEU KY TRUOC.  Ban cu chi ghi de nhung chi tieu tinh duoc; chi
      tieu nao khong tinh thi GIU NGUYEN so cua file mau. Hoc mau tu to khai
      Q1/2026 roi ket xuat Q2 thi ca phu luc 128 dong va ct9 = 287.063.630 cua
      Q1 se di theo sang Q2. Nay tool XOA TRANG moi o so truoc khi dien
      (xem xoa_so_trong_khuon) va XOA het dong lap trong bang ke.

  (2) TU KIEM CHAN NHAM HOA DON 8%.  Ban cu bat [33] = [32] x 10%. To khai that
      Q1/2026 cua chinh doanh nghiep nay la 8% ([33]/[32] = 8,0000%) nen ban cu
      se TU CHOI ket xuat mot to khai DUNG. Hoa don giam thue theo NQ142 van
      khai o dong [32]/[33]; phan giam 2% khai rieng o PL_NQ142_GTGT/ChenhLech/ct9.

  (3) DUNG DO SO HIEU CHI TIEU.  Ban cu lay khoa la so hieu chi tieu ("01"),
      dung cho 01/GTGT (31 chi tieu, khong dung) nhung SAI cho BCTC: 555 the ct
      gop nham con 114 khoa (ct01 nam o 6 cho: KQKD/NamNay, KQKD/NamTruoc,
      LCTT/NamNay...). Nay khoa la DUONG DAN day du.

KIEM TRA TRUOC KHI NOP (/kiemtra):
  46 rang buoc cua B01a-DNN va 9 rang buoc cua 01/GTGT deu da chay dung tren ho
  so THAT cua doanh nghiep (46/46 va 9/9 khop). Rieng tongCong cua PL_CDTK:
  KHONG phai cong tat ca cac the, ma chi cong TAI KHOAN CAP 1 - cong tat ca cho
  87 ty thay vi 66 ty (sai 31%). Da kiem tren ca 6 khoi cua ho so that.

GD56 - HTKK 5.7.x BAO "Cau truc to khai xml nhap vao khong hop le": ban cu dua ve 0 ca maTKhai,
  pbanTKhaiXML, tieuMucHachToan... va giu ky cua file mau. Nay 01/GTGT lay KHUON THANG TU HTKK
  CAI TREN MAY (Menu.xml + khung InterfaceTemplates/xml + XSD Validate), phu luc
  PL 142/174/204 lap theo dong hang (I mua vao 8% co thue, II ban ra 8%, III [09]=[08]-[06]),
  kiem theo luoc do cua HTKK TRUOC khi giao. Xem khoi "GD56" ben duoi.

GD59 - /xemtruoc:<json> /ra:<xlsx>: lap Excel XEM TRUOC to khai (01-GTGT theo mau TT80, phu luc 142/174/204,
  doi chieu so - Cong HDDT, hoa don 8%) - khong can HTKK, khong chan tu kiem (loi ghi vao sheet); co ket
  ket-qua/DA_XONG_XEMTRUOC ('OK <xlsx>' / 'LOI ...'). /xuat: sau khi giao XML cung lap Excel cung ten.

KHONG LAM: khong ky so thay, khong nop to khai thay, khong sua du lieu ke toan.
Tool chi DOC so ke toan va GHI file XML ket xuat.
"""

import json
import io
import os
import re
import sys
import xml.etree.ElementTree as ET
from datetime import datetime
# GD318: luon tim module Python ngay canh tool (may khach chay tu thu muc khac / Python bat che do safe-path)
try:
    _GD318_DIR = os.path.dirname(os.path.abspath(__file__))
    if _GD318_DIR not in sys.path:
        sys.path.insert(0, _GD318_DIR)
except Exception:
    pass

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

if __name__ == "__main__":          # GD111: lien ket .py cua Python install manager / Store bo mat tham so VB6
    try:
        import tham_so_du_phong as _TSDP
        sys.argv = _TSDP.bu_tham_so(sys.argv, BASE_DIR, khong_co=("/hoi:",))
    except Exception:
        pass

SETTINGS_PATH = os.path.join(BASE_DIR, "cai-dat.json")
LOG_PATH = os.path.join(BASE_DIR, "nhat-ky-htkk.txt")

NS_TKHAI = "http://kekhaithue.gdt.gov.vn/TKhaiThue"


def ghi_log(msg):
    dong = "%s  %s" % (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), msg)
    try:
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(dong + "\n")
    except Exception:
        pass
    try:
        print(dong)
    except Exception:
        pass


def _cd_doc_tho(duong):
    """GD63: doc cai-dat.json (utf-8-sig: Notepad hay luu kem BOM). -> (dict, ok). Tep hong -> giu ban sao .hong-<ngay>."""
    if not os.path.exists(duong):
        return {}, True
    try:
        with open(duong, "r", encoding="utf-8-sig") as f:
            d = json.load(f)
        return (d if isinstance(d, dict) else {}), isinstance(d, dict)
    except Exception:
        try:
            import shutil
            shutil.copy2(duong, duong + ".hong-" + datetime.now().strftime("%Y%m%d%H%M%S"))
        except Exception:
            pass
        return {}, False


def _cd_ghi_gop(duong, thay_doi, xoa=()):
    """GD63: doc lai tep HIEN TAI, chi doi / xoa cac khoa cua tool nay roi ghi tam + os.replace (khong xoa khoa tool khac)."""
    hien, _ok = _cd_doc_tho(duong)
    hien.update(thay_doi)
    for k in xoa:
        hien.pop(k, None)
    tam = duong + ".%d.tmp" % os.getpid()
    with open(tam, "w", encoding="utf-8") as f:
        json.dump(hien, f, ensure_ascii=False, indent=1)
    os.replace(tam, duong)
    return hien


def doc_cai_dat():
    return _cd_doc_tho(SETTINGS_PATH)[0]


def luu_cai_dat(s):
    """GD63: chi ghi cac khoa cua tool HTKK (htkk_*) gop vao tep hien tai - truoc day ghi DE ca tep."""
    try:
        _cd_ghi_gop(SETTINGS_PATH, {k: v for k, v in s.items() if k.startswith("htkk")})
        return True
    except Exception as e:
        ghi_log("Khong luu duoc cai-dat.json: %s" % e)
        return False


# ---------------------------------------------------------------------------
#  SO HOC
# ---------------------------------------------------------------------------
def _so(v):
    if v in (None, ""):
        return 0.0
    if isinstance(v, (int, float)):
        return float(v)
    t = re.sub(r"[^\d,.\-]", "", str(v))
    if re.fullmatch(r"-?[\d.]+,\d+", t):
        t = t.replace(".", "").replace(",", ".")
    else:
        t = t.replace(",", "")
    try:
        return float(t)
    except Exception:
        return 0.0


def _dinh_dang(v):
    try:
        return "{:,.0f}".format(float(v)).replace(",", ".")
    except Exception:
        return str(v)


def _so_xml(v):
    """HTKK doc so khong co dau phan cach; so nguyen thi khong co phan thap phan."""
    f = _so(v)
    if abs(f - round(f)) < 0.0005:
        return str(int(round(f)))
    return ("%.2f" % f).rstrip("0").rstrip(".")


def _la_so(s):
    """True neu chuoi nay la mot con so (de biet the nao can xoa ve 0)."""
    s = (s or "").strip()
    if s == "":
        return False
    return re.fullmatch(r"-?[\d.,]+", s) is not None


# ---------------------------------------------------------------------------
#  DUYET CAY XML
# ---------------------------------------------------------------------------
_RE_CT = re.compile(r"^ct(\d{1,5}[a-z]?)$", re.I)


def _ten(the):
    """Ten the, bo vung ten: '{http://...}ct22' -> 'ct22'."""
    t = the.tag
    return t.split("}", 1)[1] if "}" in t else t


def _duyet(nut, duong=""):
    for con in list(nut):
        d = duong + "/" + _ten(con)
        yield d, con
        for x in _duyet(con, d):
            yield x


def _tim_nut(goc, duong):
    """Tim nut theo duong dan da hoc. Duong dan do _duyet() sinh ra nen KHONG chua
       ten the goc: '/HSoKhaiThue/CTieuTKhaiChinh/ct22'."""
    nut = goc
    for ten in [x for x in duong.split("/") if x]:
        tiep = None
        for con in list(nut):
            if _ten(con) == ten:
                tiep = con
                break
        if tiep is None:
            return None
        nut = tiep
    return nut


def _lay_khoi(goc, duong):
    """Tra ve dict {ten_the: so} cua cac the con truc tiep cua mot khoi."""
    nut = _tim_nut(goc, duong)
    if nut is None:
        return {}
    return {_ten(c): _so((c.text or "").strip()) for c in list(nut) if not list(c)}


# ---------------------------------------------------------------------------
#  HOC KHUON TU FILE XML DO CHINH HTKK KET XUAT
# ---------------------------------------------------------------------------
def hoc_khuon(duong_xml):
    """Doc file XML do HTKK ket xuat -> mo ta khuon. Khong sua gi file goc."""
    try:
        cay = ET.parse(duong_xml)
    except Exception as e:
        return None, "Khong doc duoc file XML: %s" % e
    goc = cay.getroot()
    khuon = {
        "tep_mau": os.path.basename(duong_xml),
        "the_goc": _ten(goc),
        "vung_ten": goc.tag.split("}", 1)[0][1:] if "}" in goc.tag else "",
        "hoc_luc": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "chi_tieu": [],        # DANH SACH duong dan day du cua moi the ct
        "ngan": {},            # so hieu ngan -> duong dan (CHI khi duy nhat)
        "trung": {},           # so hieu xuat hien nhieu cho -> so luong
        "dau": {},             # cac the thong tin chung
        "so_the": 0,
    }
    dem = {}
    for duong, nut in _duyet(goc):
        khuon["so_the"] += 1
        ten = _ten(nut)
        m = _RE_CT.match(ten)
        if m:
            khuon["chi_tieu"].append(duong)
            k = m.group(1).lower()
            dem.setdefault(k, []).append(duong)
    for k, ds in dem.items():
        if len(ds) == 1:
            khuon["ngan"][k] = ds[0]
        else:
            khuon["trung"][k] = len(ds)

    ten_dau = ("mst", "maSoThue", "tenNNT", "tenNguoiNopThue", "kyKKhaiTuNgay", "kyKKhaiDenNgay",
               "kyKKhai", "kieuKy", "ngayLapTKhai", "maTKhai", "tenTKhai", "pbanTKhaiXML",
               "phienBanTKhaiXML", "phienBan", "soLan", "loaiTKhai", "maCQTNoiNop", "tenCQTNoiNop",
               "maHuyenNNT", "maTinhNNT", "dchiNNT", "nguoiKy", "ngayKy",
               "ngayLap", "nguoiLapBieu", "keToanTruong", "nguoiDaiDienTheoPhapLuat")
    for duong, nut in _duyet(goc):
        if _ten(nut) in ten_dau and _ten(nut) not in khuon["dau"]:
            khuon["dau"][_ten(nut)] = duong

    if not khuon["chi_tieu"]:
        return khuon, ("File XML nay khong co the nao dang 'ct<so>' nen tool chua biet chi tieu "
                       "nam o dau. Hay ket xuat dung mau to khai can dung tu HTKK.")
    ghi_log("[HOC] %s: %d the, %d chi tieu (%d so hieu duy nhat, %d so hieu trung)"
            % (khuon["tep_mau"], khuon["so_the"], len(khuon["chi_tieu"]),
               len(khuon["ngan"]), len(khuon["trung"])))
    if khuon["trung"]:
        ghi_log("[HOC] So hieu nam o nhieu cho (phai goi bang duong dan day du): %s"
                % ", ".join("ct%s(%d)" % (k, v) for k, v in sorted(khuon["trung"].items())[:12]))
    return khuon, ""


def luu_khuon(ma_tk, khuon, duong_xml):
    s = doc_cai_dat()
    d = s.get("htkk_khuon") or {}
    k = dict(khuon)
    k["duong_mau"] = os.path.abspath(duong_xml)
    d[ma_tk] = k
    s["htkk_khuon"] = d
    luu_cai_dat(s)


def doc_khuon(ma_tk):
    return (doc_cai_dat().get("htkk_khuon") or {}).get(ma_tk)


def giai_khoa(khuon, khoa):
    """Doi khoa nguoi dung dua vao -> duong dan day du trong cay XML.
       Chap nhan:  '22'  |  'ct22'  |  'SoCuoiNam/ct110'  |  duong dan day du."""
    khoa = str(khoa).strip()
    ds = khuon.get("chi_tieu") or []
    if khoa in ds:
        return khoa, ""
    k = khoa.lower().lstrip("/")
    if k.startswith("ct"):
        k2 = k[2:]
    else:
        k2 = k
    # so hieu don gian va duy nhat
    if "/" not in k and k2 in (khuon.get("ngan") or {}):
        return khuon["ngan"][k2], ""
    if "/" not in k and k2 in (khuon.get("trung") or {}):
        return None, ("so hieu [%s] nam o %d cho khac nhau - phai goi bang duong dan day du "
                      "(vi du 'PL_KQHDSXKD/NamNay/ct%s')" % (k2, khuon["trung"][k2], k2))
    # khop duoi duong dan
    hau = "/" + khoa.strip("/")
    hop = [d for d in ds if d.endswith(hau)]
    if len(hop) == 1:
        return hop[0], ""
    if len(hop) > 1:
        return None, "duong dan '%s' khop %d cho - ghi ro hon" % (khoa, len(hop))
    return None, "khong tim thay chi tieu '%s' trong khuon" % khoa


# ---------------------------------------------------------------------------
#  XOA TRANG KHUON TRUOC KHI DIEN  (sua loi 1: ro ri so lieu ky truoc)
# ---------------------------------------------------------------------------
def xoa_so_trong_khuon(goc):
    """Dat ve '0' moi the la mot CON SO. The rong van de rong (vi du muc ThuyetMinh,
       Header/ct09, ct10 la o danh dau - dien '0' vao co the lam HTKK bao sai).
       Tra ve so the da xoa."""
    n = 0
    for duong, nut in _duyet(goc):
        if list(nut):
            continue
        # GD56: CHI xoa so o phan chi tieu va phu luc. Phan thong tin chung (maTKhai 842,
        # pbanTKhaiXML 2.8.3, maCQTNoiNop, maTinhNNT, soLan...) va cac MA / o danh dau trong
        # to khai (ma_NganhNghe, tieuMucHachToan 1701, bctcDaKiemToan...) phai giu nguyen -
        # dua ve 0 la HTKK bao "Cau truc to khai xml nhap vao khong hop le".
        if not (duong.startswith("/HSoKhaiThue/CTieuTKhaiChinh") or duong.startswith("/HSoKhaiThue/PLuc")):
            continue
        ten = _ten(nut)
        if ten in _GIU_NGUYEN or re.match(r"^ma([A-Z_]|$)", ten) or duong.startswith("/HSoKhaiThue/CTieuTKhaiChinh/Header"):
            continue
        t = (nut.text or "")
        if _la_so(t) and t.strip() != "0":
            nut.text = "0"
            n += 1
    return n


def xoa_dong_lap(goc):
    """Xoa het cac dong bang ke (vi du BangKeTenHHDV cua PL_NQ142_GTGT), giu lai mot
       dong lam khuon mau de con dung lai. Tra ve dict {duong: (mau, so_da_xoa)}.

       CACH NHAN DIEN "dong bang ke": mot TEN THE duoc coi la dong bang ke neu o dau do
       trong file no xuat hien TU 2 LAN TRO LEN DUOI CUNG MOT THE CHA. Sau do xoa MOI
       the mang ten ay o MOI cho.
         - Vi sao phai quet ca file: trong to khai 01/GTGT that, khoi mua vao co 128
           dong <BangKeTenHHDV> nhung khoi ban ra chi co 1 dong. Neu chi xet tung cha
           mot thi dong ban ra cua ky truoc (ten hang "Ly, nap nhua pp, pet") se o lai
           trong to khai ky moi.
         - Vi sao phai theo TUNG CHA chu khong dem ca file: <No> va <Co> cua PL_CDTK
           xuat hien 3 lan moi ben (du dau / phat sinh / du cuoi) nhung moi cha chi co
           mot cai. Dem ca file se tuong day la dong bang ke va xoa sach phu luc."""
    ten_dong = set()
    for _, nut in _duyet(goc):
        dem = {}
        for c in list(nut):
            dem[_ten(c)] = dem.get(_ten(c), 0) + 1
        for ten, k in dem.items():
            if k >= 2:
                ten_dong.add(ten)
        # Dau hieu thu hai, khong phu thuoc so luong: mot the CO THE CON nam canh
        # mot the la ten bat dau bang "tongCong" thi chac chan la DONG cua bang ke
        # (vi cai kia la dong cong cua chinh bang ay). Nho dau hieu nay ma bang ke
        # chi con 1 dong - hoac file mau trang chi giu 1 dong lam khuon - van duoc
        # nhan ra. Da thu tren ca 3 ho so that: bat dung 01/GTGT (BangKeTenHHDV o
        # ca hai khoi mua vao/ban ra) va 03/TNDN (BangChiTietSoLo), khong he nham
        # <No>/<Co> cua PL_CDTK vi tongCong cua chung nam BEN TRONG chu khong ben canh.
        if any((not list(c)) and _ten(c).startswith("tongCong") for c in list(nut)):
            for c in list(nut):
                if list(c):
                    ten_dong.add(_ten(c))
    mau = {}
    for duong, nut in list(_duyet(goc)):
        for ten in ten_dong:
            ds = [c for c in list(nut) if _ten(c) == ten]
            if not ds:
                continue
            mau[duong + "/" + ten] = (ds[0], len(ds))
            for c in ds:
                nut.remove(c)
    return mau


def _dong_moi(mau_nut, gia_tri):
    """Nhan ban mot dong bang ke tu dong mau, dien gia tri theo ten the."""
    import copy
    m = copy.deepcopy(mau_nut)
    for c in list(m):
        t = _ten(c)
        if t in gia_tri:
            c.text = gia_tri[t] if isinstance(gia_tri[t], str) else _so_xml(gia_tri[t])
        elif _la_so(c.text or ""):
            c.text = "0"
        else:
            # khong duoc de chu cua ky truoc o lai (vi du ten hang hoa)
            c.text = ""
    return m


def cong_bang_ke(cha):
    """Dien cac o tongCong* cua mot bang ke bang tong cot tuong ung tren cac dong.

    Quy uoc ten the trong to khai that: o tong ten la "tongCong" + ten cot, chi khac
    chu hoa chu thuong o ky tu dau:
        tongCongGiaTriHHDVMuaVao   <- giaTriHHDVMuaVao
        tongCongThueGTGTHHDV       <- thueGTGTHHDV
        tongCongGiaTriHHDV         <- giaTriHHDV
        tongCongThueGTGTDuocGiam   <- thueGTGTDuocGiam
    Khong dien thi o tong bi bo trang - dung loi ma PL_CDTK dang mac (xem
    ModHDDTBCTC.bas). Tra ve so o da dien."""
    dong = [c for c in list(cha) if list(c)]
    n = 0
    for c in list(cha):
        ten = _ten(c)
        if list(c) or not ten.startswith("tongCong"):
            continue
        cot = ten[len("tongCong"):].lower()
        if not cot:
            continue
        t = 0.0
        thay = False
        for d in dong:
            for x in list(d):
                if _ten(x).lower() == cot:
                    t += _so((x.text or "").strip())
                    thay = True
        if thay:
            c.text = _so_xml(t)
            n += 1
    return n


# ---------------------------------------------------------------------------
#  RANG BUOC 01/GTGT  (Thong tu 80/2021)
#  Da chay dung tren to khai THAT Q1/2026: 9/9 khop.
# ---------------------------------------------------------------------------
def tu_kiem_01gtgt(ct):
    """ct: dict {'22': so, ...}. Tra ve (chan, canh_bao).
       chan = sai so hoc -> KHONG duoc ghi file. canh_bao = nen xem lai."""
    chan, canh = [], []
    g = lambda k: _so(ct.get(k))
    co = lambda *ks: all(k in ct for k in ks)

    if co("27", "29", "30", "32"):
        t = g("29") + g("30") + g("32") + g("32a") - g("32b")          # GD65: TT89 tru [32b] (TT80: [32b] khong co = 0)
        if abs(g("27") - t) > 1:
            chan.append("[27] tong doanh thu HHDV ban ra chiu thue = [29]+[30]+[32]+[32a]-[32b]: "
                        "dang la %s, phai la %s" % (_dinh_dang(g("27")), _dinh_dang(t)))
    if co("28", "31", "33"):
        t = g("31") + g("33")
        if abs(g("28") - t) > 1:
            chan.append("[28] tong thue GTGT ban ra = [31]+[33]: dang la %s, phai la %s"
                        % (_dinh_dang(g("28")), _dinh_dang(t)))
    if co("34", "26", "27"):
        t = g("26") + g("27") + g("34a")                               # GD65: TT89 cong [34a]
        if abs(g("34") - t) > 1:
            chan.append("[34] tong doanh thu HHDV ban ra = [26]+[27]+[34a]: dang la %s, phai la %s"
                        % (_dinh_dang(g("34")), _dinh_dang(t)))
    if co("35", "28") and abs(g("35") - g("28")) > 1:
        chan.append("[35] tong thue GTGT ban ra = [28]: dang la %s, phai la %s"
                    % (_dinh_dang(g("35")), _dinh_dang(g("28"))))
    if co("36", "35", "25"):
        t = g("35") - g("25")
        if abs(g("36") - t) > 1:
            chan.append("[36] thue GTGT phat sinh = [35]-[25]: dang la %s, phai la %s"
                        % (_dinh_dang(g("36")), _dinh_dang(t)))
    if co("40a", "41") and g("40a") > 0 and g("41") > 0:
        chan.append("[40a] va [41] khong the cung > 0 (vua phai nop vua chua khau tru het)")
    if co("40", "40a", "40b"):
        t = g("40a") - g("40b")
        if t < 0:
            t = 0
        if abs(g("40") - t) > 1:
            chan.append("[40] thue con phai nop = [40a]-[40b]: dang la %s, phai la %s"
                        % (_dinh_dang(g("40")), _dinh_dang(t)))
    if co("43", "41", "42"):
        t = g("41") - g("42")
        if abs(g("43") - t) > 1:
            chan.append("[43] thue chuyen ky sau = [41]-[42]: dang la %s, phai la %s"
                        % (_dinh_dang(g("43")), _dinh_dang(t)))
    if co("25", "24") and g("25") > g("24") + 1:
        chan.append("[25] thue duoc khau tru (%s) khong the lon hon [24] thue mua vao (%s)"
                    % (_dinh_dang(g("25")), _dinh_dang(g("24"))))

    # --- CANH BAO: thue suat thuc te tren tung dong ---
    # Dong [30]/[31] la 5%. Dong [32]/[33] la 10% THEO TEN, nhung hoa don duoc giam
    # thue theo NQ142 khai o day voi thue suat 8% -> KHONG duoc chan.
    for dt, thue, ten_dong, hop_le in (("30", "31", "5%", (5.0,)),
                                       ("32", "33", "10% (va 8% duoc giam)", (8.0, 10.0))):
        if co(dt, thue) and g(dt) > 0:
            ts = g(thue) / g(dt) * 100.0
            if not any(abs(ts - x) <= 0.15 for x in hop_le):
                canh.append("dong %s: thue thuc te %.3f%% tren doanh thu %s - khong phai %s. "
                            "Kiem tra lai bang ke (co the co hoa don sai thue suat)."
                            % (ten_dong, ts, _dinh_dang(g(dt)),
                               " hoac ".join("%g%%" % x for x in hop_le)))
    return chan, canh


# ---------------------------------------------------------------------------
#  RANG BUOC B01a-DNN (TT133/2016)
#  46 rang buoc, da chay dung tren BO BAO CAO THAT nam 2025 (46/46 khop).
#  Chu y: [182] = No 242 + No 333  (thue nop thua la mot khoan phai THU).
# ---------------------------------------------------------------------------
# Tai khoan cap 1 dung de cong tongCong cua PL_CDTK.
def _tk_cap1(cac_tk):
    """Tai khoan 'cap 1' = khong co tai khoan nao khac trong danh sach la tien to cua no."""
    return [a for a in cac_tk if not any(b != a and a.startswith(b) for b in cac_tk)]


def _cdtk(goc, khoi, ben):
    d = _lay_khoi(goc, "/HSoKhaiThue/PLuc/PL_CDTK/%s/%s" % (khoi, ben))
    d.pop("tongCong", None)
    return {k[2:]: v for k, v in d.items() if k.startswith("ct")}


def tong_cong_cdtk(d_tk):
    """tongCong = CHI cong tai khoan cap 1. Cong tat ca the se thua ~31%
       (da kiem: 87.243.899.383 thay vi 66.336.009.398 tren ho so that)."""
    return sum(d_tk[a] for a in _tk_cap1(list(d_tk.keys())))


# ---------------------------------------------------------------------------
#  BANG CONG THUC CHINH THUC CUA B01a-DNN (TT133/2016)
#
#  Chep tu man hinh "Thiet lap bao cao tai chinh - B01a-DNN" cua bo mau chuan
#  (video mau do nguoi dung cung cap 19/09/2026), cot "Cong thuc".
#  Mau goc viet DUNO(x)/DUCO(x), DUNO_ChitietTheoTK(x), DUNO_ChitietTheoTKvaDoituong(x):
#  deu la so du ben No / ben Co cua tai khoan x, cong theo chi tiet. Phu luc PL_CDTK
#  trong file XML da la bang can doi tai khoan CHI TIET (TK 131 co ca du No lan du Co)
#  nen doc thang tu do la dung.
#
#  Moi dong: (ma chi tieu, ten, [(dau, ben, tai khoan), ...])
#     dau "+" hoac "-" ; ben "N" (du No) hoac "C" (du Co)
#
#  Da doi chieu ca 37 cong thuc nay tren BO BAO CAO THAT nam 2025 cua doanh nghiep,
#  cho ca So cuoi nam va So dau nam: 74/74 khop, du dung bang 0.
#
#  VI SAO PHAI SUA: ban truoc tu suy cong thuc nen mot so dong chi DUNG NHO MAY tren
#  bo so nay - vi du [152] lay ca Co 214 (dung ra phai tru 2147 vi 2147 thuoc dong
#  [162]), [134] lay Co 138 (dung ra la 338 + 1388 + 334 + 1368 + 1386 + 141, va
#  KHONG duoc gom 1381 vi 1381 la dong [135]), [411] lay Co 411 (dung ra la 4111).
#  Nam nao phat sinh nhung tai khoan ay thi ban cu bao sai.
# ---------------------------------------------------------------------------
CT_B01A = [
    ("110", "Tien va cac khoan tuong duong tien", [("+", "N", "111"), ("+", "N", "112")]),
    ("121", "Chung khoan kinh doanh", [("+", "N", "121")]),
    ("122", "Dau tu nam giu den ngay dao han", [("+", "N", "1281"), ("+", "N", "1288")]),
    ("123", "Dau tu gop von vao don vi khac", [("+", "N", "228")]),
    ("124", "Du phong ton that dau tu tai chinh", [("-", "C", "2291"), ("-", "C", "2292")]),
    ("131", "Phai thu cua khach hang", [("+", "N", "131")]),
    ("132", "Tra truoc cho nguoi ban", [("+", "N", "331")]),
    ("133", "Von kinh doanh o don vi truc thuoc", [("+", "N", "1361")]),
    ("134", "Phai thu khac", [("+", "N", "338"), ("+", "N", "1388"), ("+", "N", "334"),
                              ("+", "N", "1368"), ("+", "N", "1386"), ("+", "N", "141")]),
    ("135", "Tai san thieu cho xu ly", [("+", "N", "1381")]),
    ("136", "Du phong phai thu kho doi", [("-", "C", "2293")]),
    ("141", "Hang ton kho", [("+", "N", "151"), ("+", "N", "152"), ("+", "N", "153"),
                             ("+", "N", "154"), ("+", "N", "155"), ("+", "N", "156"),
                             ("+", "N", "157")]),
    ("142", "Du phong giam gia hang ton kho", [("-", "C", "2294")]),
    ("151", "Nguyen gia TSCD", [("+", "N", "211")]),
    ("152", "Gia tri hao mon luy ke TSCD", [("-", "C", "2141"), ("-", "C", "2142"),
                                            ("-", "C", "2143")]),
    ("161", "Nguyen gia BDS dau tu", [("+", "N", "217")]),
    ("162", "Hao mon luy ke BDS dau tu", [("-", "C", "2147")]),
    ("170", "XDCB do dang", [("+", "N", "241")]),
    ("181", "Thue GTGT duoc khau tru", [("+", "N", "133")]),
    ("182", "Tai san khac", [("+", "N", "242"), ("+", "N", "333")]),
    ("311", "Phai tra nguoi ban", [("+", "C", "331")]),
    ("312", "Nguoi mua tra tien truoc", [("+", "C", "131")]),
    ("313", "Thue va cac khoan phai nop Nha nuoc", [("+", "C", "333")]),
    ("314", "Phai tra nguoi lao dong", [("+", "C", "334")]),
    ("315", "Phai tra khac", [("+", "C", "338"), ("+", "C", "1388"), ("+", "C", "335"),
                              ("+", "C", "3368")]),
    ("316", "Vay va no thue tai chinh", [("+", "C", "341")]),
    ("317", "Phai tra noi bo ve von kinh doanh", [("+", "C", "3361")]),
    ("318", "Du phong phai tra", [("+", "C", "352")]),
    ("319", "Quy khen thuong, phuc loi", [("+", "C", "353")]),
    ("320", "Quy phat trien khoa hoc va cong nghe", [("+", "C", "356")]),
    ("411", "Von gop cua chu so huu", [("+", "C", "4111")]),
    ("412", "Thang du von co phan", [("+", "C", "4112"), ("-", "N", "4112")]),
    ("413", "Von khac cua chu so huu", [("+", "C", "4118")]),
    ("414", "Co phieu quy", [("-", "N", "419")]),
    ("415", "Chenh lech ty gia hoi doai", [("+", "C", "413"), ("-", "N", "413")]),
    ("416", "Cac quy thuoc von chu so huu", [("+", "C", "418")]),
    ("417", "Loi nhuan sau thue chua phan phoi", [("+", "C", "421"), ("-", "N", "421")]),
]

# Ket qua kinh doanh: lay tu phat sinh trong ky. Mau goc viet PhatsinhDU(911/632) -
# PhatsinhDU(632/911) (so ket chuyen rong giua hai tai khoan); PL_CDTK chi co tong
# phat sinh No/Co tung tai khoan nen day la phep doi chieu GAN DUNG - dat o muc
# CANH BAO, khong chan. Lech chi xay ra khi trong ky co but toan ghi giam nguoc.
CT_KQKD = [
    ("01", "Doanh thu ban hang va cung cap dich vu", [("+", "C", "511")]),
    ("11", "Gia von hang ban", [("+", "N", "632")]),
    ("21", "Doanh thu hoat dong tai chinh", [("+", "C", "515")]),
    ("22", "Chi phi tai chinh", [("+", "N", "635")]),
    ("24", "Chi phi quan ly kinh doanh", [("+", "N", "642")]),
    ("31", "Thu nhap khac", [("+", "C", "711")]),
    ("32", "Chi phi khac", [("+", "N", "811")]),
    ("51", "Chi phi thue TNDN", [("+", "N", "821")]),
]


def _mo_ta_ct(cong_thuc):
    """(dau, ben, tk) -> 'No 111 + No 112' / '- Co 2141 - Co 2142'."""
    ra = ""
    for i, (dau, ben, tk) in enumerate(cong_thuc):
        b = "No" if ben == "N" else "Co"
        if i == 0:
            ra = ("- " if dau == "-" else "") + "%s %s" % (b, tk)
        else:
            ra += " %s %s %s" % (dau, b, tk)
    return ra


def _tinh_ct(cong_thuc, no, co):
    t = 0.0
    for dau, ben, tk in cong_thuc:
        v = (no if ben == "N" else co).get(tk, 0.0)
        t += -v if dau == "-" else v
    return t


def kiem_tra_b01a(goc):
    """Tra ve (chan, canh, ghi_chu). Doc tu cay XML da dien."""
    chan, canh, chu = [], [], []
    CN = _lay_khoi(goc, "/HSoKhaiThue/CTieuTKhaiChinh/SoCuoiNam")
    DN = _lay_khoi(goc, "/HSoKhaiThue/CTieuTKhaiChinh/SoDauNam")
    KQn = _lay_khoi(goc, "/HSoKhaiThue/PLuc/PL_KQHDSXKD/NamNay")
    KQt = _lay_khoi(goc, "/HSoKhaiThue/PLuc/PL_KQHDSXKD/NamTruoc")
    LCn = _lay_khoi(goc, "/HSoKhaiThue/PLuc/PL_LCTTTT/NamNay")
    if not CN:
        return ["Khong tim thay khoi CTieuTKhaiChinh/SoCuoiNam - file nay co phai B01a-DNN khong?"], [], []

    # Dung sai = 0. Bang can doi ke toan cong so nguyen voi so nguyen nen KHONG co
    # sai so lam tron: tren bo bao cao THAT nam 2025, ca 46 rang buoc deu du dung
    # bang 0. Lech 1 dong o day la lech that (thuong la go nham mot chu so).
    def ck(kho, nhan, tinh, thuc, dung=0.0):
        if abs(tinh - thuc) > dung:
            kho.append("%s: dang la %s, theo cong thuc phai la %s (lech %s)"
                       % (nhan, _dinh_dang(thuc), _dinh_dang(tinh), _dinh_dang(thuc - tinh)))

    # ---- Bang can doi ke toan: cong don trong noi bo bao cao ----
    for ten, B in (("Cuoi nam", CN), ("Dau nam", DN)):
        if not B:
            continue
        p = lambda k: _so(B.get("ct" + k))
        ck(chan, "%s [130] = [131]+[132]+[133]+[134]+[135]+[136]" % ten,
           sum(p(x) for x in ("131", "132", "133", "134", "135", "136")), p("130"))
        ck(chan, "%s [140] = [141]+[142]" % ten, p("141") + p("142"), p("140"))
        ck(chan, "%s [150] = [151]+[152]" % ten, p("151") + p("152"), p("150"))
        ck(chan, "%s [160] = [161]+[162]" % ten, p("161") + p("162"), p("160"))
        ck(chan, "%s [180] = [181]+[182]" % ten, p("181") + p("182"), p("180"))
        ck(chan, "%s [200] TONG TAI SAN = [110]+[120]+[130]+[140]+[150]+[160]+[170]+[180]" % ten,
           sum(p(x) for x in ("110", "120", "130", "140", "150", "160", "170", "180")), p("200"))
        ck(chan, "%s [300] = tong [311]..[320]" % ten,
           sum(p(str(x)) for x in range(311, 321)), p("300"))
        ck(chan, "%s [400] = tong [411]..[417]" % ten,
           sum(p(str(x)) for x in range(411, 418)), p("400"))
        ck(chan, "%s [500] TONG NGUON VON = [300]+[400]" % ten, p("300") + p("400"), p("500"))
        ck(chan, "%s: TONG TAI SAN [200] phai bang TONG NGUON VON [500]" % ten, p("200"), p("500"))
        if p("152") > 0:
            canh.append("%s [152] hao mon luy ke dang duong (%s) - chi tieu nay phai GHI AM."
                        % (ten, _dinh_dang(p("152"))))

    # ---- Ket qua kinh doanh: cong don ----
    for ten, K in (("Nam nay", KQn), ("Nam truoc", KQt)):
        if not K:
            continue
        p = lambda k: _so(K.get("ct" + k))
        ck(chan, "KQKD %s [10] = [01]-[02]" % ten, p("01") - p("02"), p("10"))
        ck(chan, "KQKD %s [20] = [10]-[11]" % ten, p("10") - p("11"), p("20"))
        ck(chan, "KQKD %s [30] = [20]+[21]-[22]-[24]" % ten,
           p("20") + p("21") - p("22") - p("24"), p("30"))
        ck(chan, "KQKD %s [40] = [31]-[32]" % ten, p("31") - p("32"), p("40"))
        ck(chan, "KQKD %s [50] = [30]+[40]" % ten, p("30") + p("40"), p("50"))
        ck(chan, "KQKD %s [60] = [50]-[51]" % ten, p("50") - p("51"), p("60"))

    # ---- Luu chuyen tien te ----
    if LCn:
        p = lambda k: _so(LCn.get("ct" + k))
        # Phu luc PL_LCTTTT cua B01a-DNN chi co ct01..ct07, ct20..ct25, ct30..ct35,
        # ct40, ct50, ct60, ct61, ct70 -> day la mau LUU CHUYEN TIEN TE TRUC TIEP.
        # Mau GIAN TIEP co cau truc khac han ([02] = [03]+..+[08], [20] = [01]+[02]+[09])
        # va can toi ct08, ct09, ct10..ct18 - nhung the KHONG CO trong to khai nay.
        if abs(sum(p("0%d" % i) for i in range(1, 8)) - p("20")) > 0:
            goi_y = ""
            if KQn and abs(p("01") - _so(KQn.get("ct50"))) <= 1 and p("01") != 0:
                goi_y = ("\n    Luu y: [01] dang bang dung [50] cua Ket qua kinh doanh "
                         "(loi nhuan truoc thue). Rat co the so lieu la cua mau LUU CHUYEN "
                         "TIEN TE GIAN TIEP, trong khi phu luc nay la mau TRUC TIEP "
                         "(tien thu tu ban hang, tien chi tra nguoi ban...). Hai mau khong "
                         "the dung lan nhau.")
            chan.append("LCTT [20] luu chuyen tu HDKD = [01]+[02]+[03]+[04]+[05]+[06]+[07]: "
                        "dang la %s, theo cong thuc phai la %s%s"
                        % (_dinh_dang(p("20")),
                           _dinh_dang(sum(p("0%d" % i) for i in range(1, 8))), goi_y))
        ck(chan, "LCTT [30] luu chuyen tu dau tu = tong [21]..[25]",
           sum(p(str(i)) for i in range(21, 26)), p("30"))
        ck(chan, "LCTT [40] luu chuyen tu tai chinh = tong [31]..[35]",
           sum(p(str(i)) for i in range(31, 36)), p("40"))
        ck(chan, "LCTT [50] luu chuyen thuan = [20]+[30]+[40]", p("20") + p("30") + p("40"), p("50"))
        ck(chan, "LCTT [70] tien cuoi ky = [50]+[60]+[61]", p("50") + p("60") + p("61"), p("70"))
        if CN:
            ck(chan, "LCTT [70] tien cuoi ky phai bang [110] tren bang can doi ke toan",
               _so(CN.get("ct110")), p("70"))
        if DN:
            ck(chan, "LCTT [60] tien dau ky phai bang [110] dau nam", _so(DN.get("ct110")), p("60"))

    # ---- Phu luc bang can doi tai khoan ----
    co_cdtk = _tim_nut(goc, "/HSoKhaiThue/PLuc/PL_CDTK") is not None
    if co_cdtk:
        for khoi, nhan in (("SoDuDauKy", "So du dau ky"),
                           ("SoPhatSinhTrongKy", "So phat sinh trong ky"),
                           ("SoDuCuoiKy", "So du cuoi ky")):
            No = _cdtk(goc, khoi, "No")
            Co = _cdtk(goc, khoi, "Co")
            if not No and not Co:
                continue
            tn, tc = tong_cong_cdtk(No), tong_cong_cdtk(Co)
            ck(chan, "CDTK %s: tong ben No phai bang tong ben Co" % nhan, tn, tc)
            for ben, tinh in (("No", tn), ("Co", tc)):
                ghi = _so(_lay_khoi(goc, "/HSoKhaiThue/PLuc/PL_CDTK/%s/%s" % (khoi, ben)).get("tongCong"))
                if abs(ghi - tinh) > 1:
                    if ghi == 0:
                        chu.append("CDTK %s/%s: tongCong dang de TRONG (0), phai la %s "
                                   "- dung /sua de tool dien gium."
                                   % (nhan, ben, _dinh_dang(tinh)))
                    else:
                        chan.append("CDTK %s/%s: tongCong ghi %s nhung cong tai khoan cap 1 duoc %s"
                                    % (nhan, ben, _dinh_dang(ghi), _dinh_dang(tinh)))
            # can doi: du cuoi = du dau + phat sinh
        DKn, DKc = _cdtk(goc, "SoDuDauKy", "No"), _cdtk(goc, "SoDuDauKy", "Co")
        PSn, PSc = _cdtk(goc, "SoPhatSinhTrongKy", "No"), _cdtk(goc, "SoPhatSinhTrongKy", "Co")
        CKn, CKc = _cdtk(goc, "SoDuCuoiKy", "No"), _cdtk(goc, "SoDuCuoiKy", "Co")
        lech = []
        for a in sorted(set(list(DKn) + list(PSn) + list(CKn))):
            d = (DKn.get(a, 0) - DKc.get(a, 0)) + (PSn.get(a, 0) - PSc.get(a, 0))
            c = CKn.get(a, 0) - CKc.get(a, 0)
            if abs(d - c) > 1:
                lech.append("TK %s: dau (%s) + phat sinh (%s) = %s, nhung du cuoi ghi %s"
                            % (a, _dinh_dang(DKn.get(a, 0) - DKc.get(a, 0)),
                               _dinh_dang(PSn.get(a, 0) - PSc.get(a, 0)),
                               _dinh_dang(d), _dinh_dang(c)))
        if lech:
            chan.append("CDTK: %d tai khoan co du cuoi khong bang du dau + phat sinh:\n    - %s"
                        % (len(lech), "\n    - ".join(lech[:10])))

        # ---- Doi chieu voi bang can doi tai khoan, THEO DUNG CONG THUC MAU ----
        for ten_khoi, B, No_, Co_ in (("Cuoi nam", CN, CKn, CKc), ("Dau nam", DN, DKn, DKc)):
            if not B:
                continue
            for ma, ten, ct_ in CT_B01A:
                if ("ct" + ma) not in B:
                    continue
                ck(canh, "%s [%s] %s = %s" % (ten_khoi, ma, ten, _mo_ta_ct(ct_)),
                   _tinh_ct(ct_, No_, Co_), _so(B.get("ct" + ma)))
        if KQn and PSn:
            for ma, ten, ct_ in CT_KQKD:
                if ("ct" + ma) not in KQn:
                    continue
                ck(canh, "KQKD [%s] %s = phat sinh %s" % (ma, ten, _mo_ta_ct(ct_)),
                   _tinh_ct(ct_, PSn, PSc), _so(KQn.get("ct" + ma)))
            ck(canh, "KQKD [60] Loi nhuan sau thue = ket chuyen Co 4211",
               PSc.get("4211", 0.0), _so(KQn.get("ct60")))
    else:
        chu.append("File khong co phu luc PL_CDTK nen khong doi chieu duoc voi bang can doi tai khoan.")
    return chan, canh, chu


# ---------------------------------------------------------------------------
#  GD72 - B01b-DNN va B01-DNNKLT (ra soat GD63 P2-10): rang buoc + khuon lay tu HTKK
#
#  FrmXmlHTKK (VB6) dien so vao KHUON XML: B01a dung RePorts\133_B01A_DNN_BCTC.xml co san;
#  B01b / KLT chua co khuon nen tool lay khung tu HTKK cai tren may (InterfaceTemplates\xml,
#  giong 01/GTGT o GD56), gan vung ten + ma to khai / phien ban tu Project\Menu.xml, dien 0
#  vao cac o so (theo XSD trong InterfaceTemplates\Validate neu co) roi ghi ve RePorts\ mot lan.
#  Sau khi VB6 dien so, /kiemtra soat B01b / KLT bang bo rang buoc duoi day (nhu B01a).
# ---------------------------------------------------------------------------
# MaFile cua to khai trong Project\Menu.xml cua HTKK 5.x (da doi chieu Menu.xml that: 683 / 684 / 685, VersionXML 2.3.2)
MAU_BCTC = {"B01A": "133_B01A_DNN_BCTC", "B01B": "133_B01B_DNN_BCTC", "KLT": "133_B01_DNN_BCTC_KLT"}
PL_BO_QUA = ("PL_LCTTGT",)

# Doi chieu voi bang can doi tai khoan (CANH BAO, khong chan) - B01b-DNN, TT133 Phu luc 2.
# Chi tieu phai tach ngan han / dai han (133, 214, 415, 416, 421..425) khong doi chieu duoc tu PL_CDTK nen bo qua.
CT_B01B = [
    ("110", "Tien va tuong duong tien", [("+", "N", "111"), ("+", "N", "112")]),
    ("121", "Chung khoan kinh doanh", [("+", "N", "121")]),
    ("122", "Du phong giam gia chung khoan kinh doanh", [("-", "C", "2291")]),
    ("123", "Dau tu nam giu den ngay dao han (ngan han)", [("+", "N", "128")]),
    ("131", "Phai thu ngan han cua khach hang", [("+", "N", "131")]),
    ("132", "Tra truoc cho nguoi ban ngan han", [("+", "N", "331")]),
    ("134", "Tai san thieu cho xu ly", [("+", "N", "1381")]),
    ("135", "Du phong phai thu ngan han kho doi", [("-", "C", "2293")]),
    ("141", "Hang ton kho", [("+", "N", "151"), ("+", "N", "152"), ("+", "N", "153"), ("+", "N", "154"),
                            ("+", "N", "155"), ("+", "N", "156"), ("+", "N", "157")]),
    ("142", "Du phong giam gia hang ton kho", [("-", "C", "2294")]),
    ("151", "Thue GTGT duoc khau tru", [("+", "N", "133")]),
    ("213", "Von kinh doanh o don vi truc thuoc", [("+", "N", "1361")]),
    ("221", "Nguyen gia TSCD", [("+", "N", "211")]),
    ("222", "Hao mon luy ke TSCD", [("-", "C", "2141"), ("-", "C", "2142"), ("-", "C", "2143")]),
    ("231", "Nguyen gia BDS dau tu", [("+", "N", "217")]),
    ("232", "Hao mon luy ke BDS dau tu", [("-", "C", "2147")]),
    ("240", "XDCB do dang", [("+", "N", "241")]),
    ("251", "Dau tu gop von vao don vi khac", [("+", "N", "228")]),
    ("252", "Du phong ton that dau tu vao don vi khac", [("-", "C", "2292")]),
    ("411", "Phai tra nguoi ban ngan han", [("+", "C", "331")]),
    ("412", "Nguoi mua tra tien truoc ngan han", [("+", "C", "131")]),
    ("413", "Thue va cac khoan phai nop Nha nuoc", [("+", "C", "333")]),
    ("414", "Phai tra nguoi lao dong", [("+", "C", "334")]),
    ("417", "Du phong phai tra ngan han", [("+", "C", "352")]),
    ("418", "Quy khen thuong, phuc loi", [("+", "C", "353")]),
    ("423", "Phai tra noi bo ve von kinh doanh", [("+", "C", "3361")]),
    ("427", "Quy phat trien khoa hoc va cong nghe", [("+", "C", "356")]),
    ("511", "Von gop cua chu so huu", [("+", "C", "4111")]),
    ("512", "Thang du von co phan", [("+", "C", "4112"), ("-", "N", "4112")]),
    ("513", "Von khac cua chu so huu", [("+", "C", "4118")]),
    ("514", "Co phieu quy", [("-", "N", "419")]),
    ("515", "Chenh lech ty gia hoi doai", [("+", "C", "413"), ("-", "N", "413")]),
    ("516", "Cac quy thuoc von chu so huu", [("+", "C", "418")]),
    ("517", "Loi nhuan sau thue chua phan phoi", [("+", "C", "421"), ("-", "N", "421")]),
]

# B01-DNNKLT (doanh nghiep khong dap ung gia dinh hoat dong lien tuc): khong tach ngan / dai han,
# khong co dong du phong (tai san ghi theo gia tri thuan). So o day la so theo SO; gia tri thu hoi /
# thanh ly (neu danh gia lai) khai tay tren HTKK.
CT_KLT = [
    ("110", "Tien va tuong duong tien", [("+", "N", "111"), ("+", "N", "112")]),
    ("121", "Chung khoan kinh doanh", [("+", "N", "121"), ("-", "C", "2291")]),
    ("122", "Dau tu nam giu den ngay dao han", [("+", "N", "128")]),
    ("123", "Dau tu gop von vao don vi khac", [("+", "N", "228"), ("-", "C", "2292")]),
    ("131", "Phai thu cua khach hang", [("+", "N", "131")]),
    ("132", "Tra truoc cho nguoi ban", [("+", "N", "331")]),
    ("133", "Von kinh doanh o don vi truc thuoc", [("+", "N", "1361")]),
    ("135", "Tai san thieu cho xu ly", [("+", "N", "1381")]),
    ("140", "Hang ton kho", [("+", "N", "151"), ("+", "N", "152"), ("+", "N", "153"), ("+", "N", "154"),
                            ("+", "N", "155"), ("+", "N", "156"), ("+", "N", "157"), ("-", "C", "2294")]),
    ("181", "Thue GTGT duoc khau tru", [("+", "N", "133")]),
    ("171", "Thue GTGT duoc khau tru", [("+", "N", "133")]),
    ("311", "Phai tra nguoi ban", [("+", "C", "331")]),
    ("312", "Nguoi mua tra tien truoc", [("+", "C", "131")]),
    ("313", "Thue va cac khoan phai nop Nha nuoc", [("+", "C", "333")]),
    ("314", "Phai tra nguoi lao dong", [("+", "C", "334")]),
    ("316", "Vay va no thue tai chinh", [("+", "C", "341")]),
    ("317", "Phai tra noi bo ve von kinh doanh", [("+", "C", "3361")]),
    ("318", "Du phong phai tra", [("+", "C", "352")]),
    ("319", "Quy khen thuong, phuc loi", [("+", "C", "353")]),
    ("320", "Quy phat trien khoa hoc va cong nghe", [("+", "C", "356")]),
    ("411", "Von gop cua chu so huu", [("+", "C", "4111")]),
    ("412", "Thang du von co phan", [("+", "C", "4112"), ("-", "N", "4112")]),
    ("413", "Von khac cua chu so huu", [("+", "C", "4118")]),
    ("414", "Co phieu quy", [("-", "N", "419")]),
    ("415", "Chenh lech ty gia hoi doai", [("+", "C", "413"), ("-", "N", "413")]),
    ("416", "Cac quy thuoc von chu so huu", [("+", "C", "418")]),
    ("417", "Loi nhuan sau thue chua phan phoi", [("+", "C", "421"), ("-", "N", "421")]),
]


def _mau_bctc_khac(ma, ten, duong, goc):
    """'B01B' / 'KLT' / '' - nhan dang theo ten to khai, ten tep, roi theo ma chi tieu co trong file."""
    t = (ten or "").upper().replace(" ", "").replace("-", "").replace("_", "")
    b = os.path.basename(duong or "").upper().replace("-", "_")
    if "B01B" in t or "B01B" in b:
        return "B01B"
    if "KLT" in t or "KLT" in b:
        return "KLT"
    CN = _lay_khoi(goc, "/HSoKhaiThue/CTieuTKhaiChinh/SoCuoiNam")
    if CN and "ct600" in CN and "ct410" in CN:
        return "B01B"
    return ""


def _tong_co(B, cac_ma):
    """Cong cac chi tieu CO trong khoi (ma nao khong co o thi bo qua) -> (tong, [ma co])."""
    co = [m for m in cac_ma if ("ct" + m) in B]
    return sum(_so(B.get("ct" + m)) for m in co), co


def _kiem_phu_luc_bctc(goc, CN, DN, chan, canh, chu, ct_cdkt):
    """Phan chung cua B01a / B01b / KLT: ket qua kinh doanh, luu chuyen tien te truc tiep, bang can doi tai khoan."""
    def ck(kho, nhan, tinh, thuc, dung=0.0):
        if abs(tinh - thuc) > dung:
            kho.append("%s: dang la %s, theo cong thuc phai la %s (lech %s)"
                       % (nhan, _dinh_dang(thuc), _dinh_dang(tinh), _dinh_dang(thuc - tinh)))
    # Menu.xml cua HTKK ghi XMLnode "PL_KQHDXSKD", file that ket xuat dung "PL_KQHDSXKD" -> nhan ca hai
    KQn = _lay_khoi(goc, "/HSoKhaiThue/PLuc/PL_KQHDSXKD/NamNay") or _lay_khoi(goc, "/HSoKhaiThue/PLuc/PL_KQHDXSKD/NamNay")
    KQt = _lay_khoi(goc, "/HSoKhaiThue/PLuc/PL_KQHDSXKD/NamTruoc") or _lay_khoi(goc, "/HSoKhaiThue/PLuc/PL_KQHDXSKD/NamTruoc")
    LCn = _lay_khoi(goc, "/HSoKhaiThue/PLuc/PL_LCTTTT/NamNay")
    for ten, K in (("Nam nay", KQn), ("Nam truoc", KQt)):
        if not K:
            continue
        p = lambda k: _so(K.get("ct" + k))
        ck(chan, "KQKD %s [10] = [01]-[02]" % ten, p("01") - p("02"), p("10"))
        ck(chan, "KQKD %s [20] = [10]-[11]" % ten, p("10") - p("11"), p("20"))
        ck(chan, "KQKD %s [30] = [20]+[21]-[22]-[24]" % ten, p("20") + p("21") - p("22") - p("24"), p("30"))
        ck(chan, "KQKD %s [40] = [31]-[32]" % ten, p("31") - p("32"), p("40"))
        ck(chan, "KQKD %s [50] = [30]+[40]" % ten, p("30") + p("40"), p("50"))
        ck(chan, "KQKD %s [60] = [50]-[51]" % ten, p("50") - p("51"), p("60"))
    if LCn:
        p = lambda k: _so(LCn.get("ct" + k))
        ck(chan, "LCTT [20] luu chuyen tu HDKD = [01]+[02]+[03]+[04]+[05]+[06]+[07]", sum(p("0%d" % i) for i in range(1, 8)), p("20"))
        ck(chan, "LCTT [30] luu chuyen tu dau tu = tong [21]..[25]", sum(p(str(i)) for i in range(21, 26)), p("30"))
        ck(chan, "LCTT [40] luu chuyen tu tai chinh = tong [31]..[35]", sum(p(str(i)) for i in range(31, 36)), p("40"))
        ck(chan, "LCTT [50] luu chuyen thuan = [20]+[30]+[40]", p("20") + p("30") + p("40"), p("50"))
        ck(chan, "LCTT [70] tien cuoi ky = [50]+[60]+[61]", p("50") + p("60") + p("61"), p("70"))
        if CN:
            ck(chan, "LCTT [70] tien cuoi ky phai bang [110] tren bao cao tinh hinh tai chinh", _so(CN.get("ct110")), p("70"))
        if DN:
            ck(chan, "LCTT [60] tien dau ky phai bang [110] dau nam", _so(DN.get("ct110")), p("60"))
    if _tim_nut(goc, "/HSoKhaiThue/PLuc/PL_CDTK") is None:
        chu.append("Mau B01-DNNKLT khong co phu luc bang can doi tai khoan (PL_CDTK) - khong doi chieu tung chi tieu voi so du tai khoan."
                   if ct_cdkt is CT_KLT else "File khong co phu luc PL_CDTK nen khong doi chieu duoc voi bang can doi tai khoan.")
        return
    for khoi, nhan in (("SoDuDauKy", "So du dau ky"), ("SoPhatSinhTrongKy", "So phat sinh trong ky"), ("SoDuCuoiKy", "So du cuoi ky")):
        No, Co = _cdtk(goc, khoi, "No"), _cdtk(goc, khoi, "Co")
        if not No and not Co:
            continue
        tn, tc = tong_cong_cdtk(No), tong_cong_cdtk(Co)
        ck(chan, "CDTK %s: tong ben No phai bang tong ben Co" % nhan, tn, tc)
        for ben, tinh in (("No", tn), ("Co", tc)):
            ghi = _so(_lay_khoi(goc, "/HSoKhaiThue/PLuc/PL_CDTK/%s/%s" % (khoi, ben)).get("tongCong"))
            if abs(ghi - tinh) > 1:
                if ghi == 0:
                    chu.append("CDTK %s/%s: tongCong dang de TRONG (0), phai la %s - dung /sua de tool dien gium." % (nhan, ben, _dinh_dang(tinh)))
                else:
                    chan.append("CDTK %s/%s: tongCong ghi %s nhung cong tai khoan cap 1 duoc %s" % (nhan, ben, _dinh_dang(ghi), _dinh_dang(tinh)))
    DKn, DKc = _cdtk(goc, "SoDuDauKy", "No"), _cdtk(goc, "SoDuDauKy", "Co")
    PSn, PSc = _cdtk(goc, "SoPhatSinhTrongKy", "No"), _cdtk(goc, "SoPhatSinhTrongKy", "Co")
    CKn, CKc = _cdtk(goc, "SoDuCuoiKy", "No"), _cdtk(goc, "SoDuCuoiKy", "Co")
    lech = []
    for a in sorted(set(list(DKn) + list(PSn) + list(CKn))):
        d = (DKn.get(a, 0) - DKc.get(a, 0)) + (PSn.get(a, 0) - PSc.get(a, 0))
        c = CKn.get(a, 0) - CKc.get(a, 0)
        if abs(d - c) > 1:
            lech.append("TK %s: dau (%s) + phat sinh (%s) = %s, nhung du cuoi ghi %s"
                        % (a, _dinh_dang(DKn.get(a, 0) - DKc.get(a, 0)), _dinh_dang(PSn.get(a, 0) - PSc.get(a, 0)), _dinh_dang(d), _dinh_dang(c)))
    if lech:
        chan.append("CDTK: %d tai khoan co du cuoi khong bang du dau + phat sinh:\n    - %s" % (len(lech), "\n    - ".join(lech[:10])))
    for ten_khoi, B, No_, Co_ in (("Cuoi nam", CN, CKn, CKc), ("Dau nam", DN, DKn, DKc)):
        if not B:
            continue
        for ma, ten, ct_ in ct_cdkt:
            if ("ct" + ma) not in B:
                continue
            ck(canh, "%s [%s] %s = %s" % (ten_khoi, ma, ten, _mo_ta_ct(ct_)), _tinh_ct(ct_, No_, Co_), _so(B.get("ct" + ma)))
    if KQn and PSn:
        for ma, ten, ct_ in CT_KQKD:
            if ("ct" + ma) not in KQn:
                continue
            ck(canh, "KQKD [%s] %s = phat sinh %s" % (ma, ten, _mo_ta_ct(ct_)), _tinh_ct(ct_, PSn, PSc), _so(KQn.get("ct" + ma)))


def kiem_tra_b01b(goc):
    """B01b-DNN (tach ngan han / dai han). -> (chan, canh, ghi_chu)."""
    chan, canh, chu = [], [], []
    CN = _lay_khoi(goc, "/HSoKhaiThue/CTieuTKhaiChinh/SoCuoiNam")
    DN = _lay_khoi(goc, "/HSoKhaiThue/CTieuTKhaiChinh/SoDauNam")
    if not CN:
        return ["Khong tim thay khoi CTieuTKhaiChinh/SoCuoiNam - file nay co phai B01b-DNN khong?"], [], []

    def ck(kho, nhan, tinh, thuc):
        if abs(tinh - thuc) > 0:
            kho.append("%s: dang la %s, theo cong thuc phai la %s (lech %s)" % (nhan, _dinh_dang(thuc), _dinh_dang(tinh), _dinh_dang(thuc - tinh)))
    for ten, B in (("Cuoi nam", CN), ("Dau nam", DN)):
        if not B:
            continue
        p = lambda k: _so(B.get("ct" + k))
        for cha, con in (("120", ("121", "122", "123")), ("130", ("131", "132", "133", "134", "135")), ("140", ("141", "142")),
                         ("150", ("151", "152")), ("100", ("110", "120", "130", "140", "150")),
                         ("210", ("211", "212", "213", "214", "215")), ("220", ("221", "222")), ("230", ("231", "232")),
                         ("250", ("251", "252", "253")), ("200", ("210", "220", "230", "240", "250", "260")),
                         ("410", tuple(str(x) for x in range(411, 420))), ("420", tuple(str(x) for x in range(421, 428))),
                         ("400", ("410", "420")), ("500", tuple(str(x) for x in range(511, 518)))):
            if ("ct" + cha) not in B:
                continue
            t, co = _tong_co(B, con)
            ck(chan, "%s [%s] = %s" % (ten, cha, "+".join("[%s]" % m for m in co)), t, p(cha))
        ck(chan, "%s [300] TONG TAI SAN = [100]+[200]" % ten, p("100") + p("200"), p("300"))
        ck(chan, "%s [600] TONG NGUON VON = [400]+[500]" % ten, p("400") + p("500"), p("600"))
        ck(chan, "%s: TONG TAI SAN [300] phai bang TONG NGUON VON [600]" % ten, p("300"), p("600"))
        for m in ("122", "135", "142", "215", "222", "232", "252", "514"):
            if p(m) > 0:
                canh.append("%s [%s] dang duong (%s) - chi tieu (*) nay phai GHI AM." % (ten, m, _dinh_dang(p(m))))
    _kiem_phu_luc_bctc(goc, CN, DN, chan, canh, chu, CT_B01B)
    return chan, canh, chu


def kiem_tra_klt(goc):
    """B01-DNNKLT. Nhan ca hai cach danh ma tai san: 150 TSCD / 160 BDSDT / 170 XDCB / 180 = 181 + 182,
       hoac 150 TSCD / 160 XDCB / 170 = 171 + 172. -> (chan, canh, ghi_chu)."""
    chan, canh, chu = [], [], []
    CN = _lay_khoi(goc, "/HSoKhaiThue/CTieuTKhaiChinh/SoCuoiNam")
    DN = _lay_khoi(goc, "/HSoKhaiThue/CTieuTKhaiChinh/SoDauNam")
    if not CN:
        return ["Khong tim thay khoi CTieuTKhaiChinh/SoCuoiNam - file nay co phai B01-DNNKLT khong?"], [], []

    def ck(kho, nhan, tinh, thuc):
        if abs(tinh - thuc) > 0:
            kho.append("%s: dang la %s, theo cong thuc phai la %s (lech %s)" % (nhan, _dinh_dang(thuc), _dinh_dang(tinh), _dinh_dang(thuc - tinh)))
    for ten, B in (("Cuoi nam", CN), ("Dau nam", DN)):
        if not B:
            continue
        p = lambda k: _so(B.get("ct" + k))
        nhom = [("120", ("121", "122", "123")), ("130", ("131", "132", "133", "134", "135"))]
        if "ct171" in B or "ct172" in B:
            nhom.append(("170", ("171", "172")))
        if "ct181" in B or "ct182" in B:
            nhom.append(("180", ("181", "182")))
        nhom += [("200", ("110", "120", "130", "140", "150", "160", "170", "180")),
                 ("300", tuple(str(x) for x in range(311, 321))), ("400", tuple(str(x) for x in range(411, 418)))]
        for cha, con in nhom:
            if ("ct" + cha) not in B:
                continue
            t, co = _tong_co(B, con)
            ck(chan, "%s [%s] = %s" % (ten, cha, "+".join("[%s]" % m for m in co)), t, p(cha))
        ck(chan, "%s [500] TONG NGUON VON = [300]+[400]" % ten, p("300") + p("400"), p("500"))
        ck(chan, "%s: TONG TAI SAN [200] phai bang TONG NGUON VON [500]" % ten, p("200"), p("500"))
    _kiem_phu_luc_bctc(goc, CN, DN, chan, canh, chu, CT_KLT)
    return chan, canh, chu


def _the_so_xsd(xsd):
    """Ten cac the kieu SO (va boolean - '0' hop le) trong XSD cua HTKK, ke ca kieu khai bao o tep XSD khac ma tep nay
       xs:redefine / xs:include / xs:import (HTKK: Validate/<to khai>.xsd redefine ../TKhaiThue.xsd). Khong doc duoc -> None."""
    XS = "{http://www.w3.org/2001/XMLSchema}"
    cac, hang, da = [], [os.path.abspath(xsd)], set()
    while hang:
        p = hang.pop(0)
        if p in da or len(da) > 12:
            continue
        da.add(p)
        try:
            g = ET.parse(p).getroot()
        except Exception:
            if p == os.path.abspath(xsd):
                return None
            continue
        cac.append(g)
        for the in ("redefine", "include", "import"):
            for r in g.iter(XS + the):
                loc = r.get("schemaLocation")
                if loc:
                    hang.append(os.path.abspath(os.path.join(os.path.dirname(p), loc.replace("\\", "/"))))
    kieu_so = {"decimal", "integer", "long", "int", "double", "float", "short", "byte", "nonNegativeInteger", "positiveInteger",
               "negativeInteger", "nonPositiveInteger", "unsignedLong", "unsignedInt", "unsignedShort", "boolean"}
    st = {}
    for g in cac:
        for s in g.iter(XS + "simpleType"):
            r = s.find(XS + "restriction")
            if s.get("name") and r is not None:
                st[s.get("name")] = (r.get("base") or "").split(":")[-1]

    def la_so(t):
        t = (t or "").split(":")[-1]
        for _ in range(8):
            if t in kieu_so:
                return True
            if t in st:
                t = st[t]
            else:
                return False
        return False
    ra = set()
    for g in cac:
        for e in g.iter(XS + "element"):
            ten = e.get("name")
            if not ten:
                continue
            t = e.get("type")
            if t is None:
                s = e.find(XS + "simpleType")
                r = s.find(XS + "restriction") if s is not None else None
                t = r.get("base") if r is not None else ""
            if la_so(t):
                ra.add(ten)
    return ra


def khuon_bctc(goc, mau):
    """To khai BCTC TT133 trong Project\\Menu.xml cua HTKK (MaFile dung ten, ban VersionXML lon nhat).
       HTKK chia to khai thanh SHEET: sheet chinh (XMLnode .../CTieuTKhaiChinh) co khung day du
       <DataFile>_xml_<ver>.xml (TTinChung + CTieuTKhaiChinh + PLuc rong); moi sheet phu luc (.../PLuc/PL_x) la mot
       manh <PL_x> rieng. Bo PL_LCTTGT (UNESCO lap LCTT truc tiep; file B01a that do HTKK ket xuat cung chi co
       KQHDSXKD, LCTTTT, CDTK) va KHBS. -> (dict: khung, phu_luc [(ten, tep)], thieu [...], ...; loi)."""
    duong_menu = os.path.join(goc, "Project", "Menu.xml")
    try:
        cay = ET.parse(duong_menu)
    except Exception as e:
        return None, "Không đọc được %s: %s" % (duong_menu, e)
    ma_file = MAU_BCTC[mau]
    muc, pb_lon = None, ()
    for m in cay.getroot().iter():
        if _ten(m) != "Menu":
            continue
        if ma_file.upper() not in ((m.get("MaFile") or "").strip().upper(), (m.get("XsdSchema") or "").strip().upper()):
            continue
        v = tuple(int(x) for x in re.findall(r"\d+", m.get("VersionXML") or "0"))
        if muc is None or v > pb_lon:
            muc, pb_lon = m, v
    if muc is None:
        return None, "HTKK ở %s không có tờ khai %s (%s) - bản HTKK quá cũ?" % (goc, mau, ma_file)
    mf = (muc.get("MaFile") or ma_file).strip()
    pb = (muc.get("VersionXML") or "").strip()
    so = re.sub(r"\D", "", pb)
    thu_xml = os.path.join(goc, "InterfaceTemplates", "xml")
    chinh, phu, thieu = "", [], []
    for sh in muc.iter():
        if _ten(sh) != "Sheet":
            continue
        df = (sh.get("DataFile") or "").strip()
        nut = (sh.get("XMLnode") or "").strip().strip("/")
        if not df or not nut or df.upper().startswith("KHBS") or (sh.get("Active") or "1").strip() == "0":
            continue
        cuoi = nut.split("/")[-1]
        if cuoi in PL_BO_QUA:
            continue
        tep = _tep_phien_ban(thu_xml, df + "_xml_", so)
        if cuoi == "CTieuTKhaiChinh":
            if tep:
                chinh = tep
            else:
                thieu.append(df + "_xml_" + so)
        elif "/PLuc/" in "/" + nut + "/":
            if tep:
                phu.append((cuoi, tep))
            else:
                thieu.append(df + "_xml_" + so)
    if not chinh:
        chinh = _tep_phien_ban(thu_xml, mf + "_xml_", so)      # HTKK cu: mot khung cho ca to khai
    if not chinh:
        return None, "Không thấy khung XML của %s trong %s (thiếu: %s)" % (mf, thu_xml, ", ".join(thieu) or mf + "_xml_" + so)
    kq = {"goc": goc, "ma_file": mf, "maTKhai": (muc.get("MaToKhai") or "").strip(), "pbanTKhaiXML": pb,
          "tenTKhai": muc.get("TenToKhai") or "", "moTaBMau": muc.get("MoTaBieuMau") or "", "khung": chinh,
          "phu_luc": phu, "thieu": thieu, "xsd": ""}
    xsd = os.path.join(goc, "InterfaceTemplates", "Validate", "%s_%s.xsd" % ((muc.get("XsdSchema") or mf).strip(), so))
    if os.path.isfile(xsd):
        kq["xsd"] = xsd
    return kq, ""


def _manh_pl(tep, ten):
    """Manh phu luc HTKK -> Element <PL_x> (goc manh la PL_x; phong khi manh boc ca to khai thi tim theo ten)."""
    r = _khung_ns(tep)
    if _ten(r).startswith("PL"):
        return r
    for n in r.iter():
        if _ten(n) == ten:
            return n
    for n in r.iter():
        if _ten(n) == "PLuc" and list(n):
            return list(n)[0]
    return None


def khung_bctc(mau, duong_ra, goi_y_htkk=""):
    """Lap tep KHUON cho FrmXmlHTKK: khung sheet chinh cua HTKK + cac manh phu luc (KQHDSXKD, LCTTTT, CDTK) + vung ten
       + ma / ten / phien ban to khai + 0 o cac o so (khong dung ThuyetMinh - HTKK de trong).
       Khong dien so lieu ke toan (VB6 dien tu file Excel QTTNDN). -> (duong_ra, '') / (None, loi)."""
    mau = (mau or "").upper().strip()
    if mau not in MAU_BCTC:
        return None, "Mẫu không hợp lệ: %s (chỉ B01A / B01B / KLT)" % mau
    h = tim_htkk(goi_y_htkk)
    if not h:
        return None, ("Không tìm thấy HTKK trên máy này. Mở màn hình AI - Hoá đơn điện tử, thẻ Tự động xử lý, vào Hệ thống > Nguồn HTKK, tờ khai và BCTC kỳ trước... > "
                      "Chỉ đường HTKK, chọn HTKK.exe trong thư mục cài HTKK, rồi xuất lại.")
    km, loi = khuon_bctc(h["goc"], mau)
    if not km:
        return None, loi
    try:
        goc = _khung_ns(km["khung"])
    except Exception as e:
        return None, "Không đọc được khung %s: %s" % (km["khung"], e)
    hk = _tim_nut(goc, "/HSoKhaiThue")
    if hk is None or _tim_nut(goc, "/HSoKhaiThue/CTieuTKhaiChinh") is None:
        return None, "Khung %s không có HSoKhaiThue/CTieuTKhaiChinh - không phải khung tờ khai chính." % km["khung"]
    plc = _tim_nut(goc, "/HSoKhaiThue/PLuc")
    if plc is None:
        plc = ET.SubElement(hk, "{%s}PLuc" % NS_TKHAI)
    da_co = {_ten(c) for c in list(plc)}
    gan = []
    for ten, tep in km.get("phu_luc") or []:
        try:
            m = _manh_pl(tep, ten)
        except Exception as e:
            ghi_log("[KHUON BCTC] Khong doc duoc manh %s: %s" % (tep, e))
            continue
        if m is None or _ten(m) in da_co:
            continue
        m.tail = None
        plc.append(m)
        da_co.add(_ten(m))
        gan.append(_ten(m))
    t = "/HSoKhaiThue/TTinChung/TTinTKhaiThue/TKhaiThue"
    # dai ly thue: FrmXmlHTKK khong khai -> bo khoi DLyThue (mstDLyThue kieu TIN bat buoc, de trong thi sai XSD);
    # khuon B01a trong RePorts cung khong co khoi nay
    ttk = _tim_nut(goc, "/HSoKhaiThue/TTinChung/TTinTKhaiThue")
    dl = _con(ttk, "DLyThue") if ttk is not None else None
    if dl is not None:
        ttk.remove(dl)
    _dat(goc, "/HSoKhaiThue/TTinChung/TTinDVu/maDVu", "HTKK")
    _dat(goc, "/HSoKhaiThue/TTinChung/TTinDVu/tenDVu", "HỖ TRỢ KÊ KHAI THUẾ")
    _dat(goc, "/HSoKhaiThue/TTinChung/TTinDVu/pbanDVu", re.sub(r"[^\d.]", "", h.get("phien_ban") or "") or "5.7.6")
    _dat(goc, "/HSoKhaiThue/TTinChung/TTinDVu/ttinNhaCCapDVu", TTIN_NHA_CCAP)
    _dat(goc, t + "/maTKhai", km["maTKhai"])
    _dat(goc, t + "/tenTKhai", km["tenTKhai"])
    _dat(goc, t + "/moTaBMau", km["moTaBMau"])
    _dat(goc, t + "/pbanTKhaiXML", km["pbanTKhaiXML"])
    _dat(goc, t + "/KyKKhaiThue/kieuKy", "Y")
    # to khai chinh thuc lan dau: loaiTKhai C, soLan 0 (khung HTKK de san soLan 1, kieuKy D) - nhu khuon B01a trong RePorts
    # va file B01a that do HTKK ket xuat
    _dat(goc, t + "/loaiTKhai", "C")
    _dat(goc, t + "/soLan", "0")
    for duong in ("/HSoKhaiThue/CTieuTKhaiChinh/bctcDaKiemToan", "/HSoKhaiThue/CTieuTKhaiChinh/maYKienKToan"):
        n = _tim_nut(goc, duong)
        if n is not None and not (n.text or "").strip():
            n.text = "0"
    so = _the_so_xsd(km["xsd"]) if km.get("xsd") else None
    n0 = 0
    for duong, nut in _duyet(goc):
        if list(nut) or "/ThuyetMinh/" in duong + "/" or not (duong.startswith("/HSoKhaiThue/CTieuTKhaiChinh") or duong.startswith("/HSoKhaiThue/PLuc")):
            continue
        ten = _ten(nut)
        la = (ten in so) if so is not None else bool(_RE_CT.match(ten) or ten == "tongCong")
        if la and not (nut.text or "").strip():
            nut.text = "0"
            n0 += 1
    try:
        os.makedirs(os.path.dirname(os.path.abspath(duong_ra)), exist_ok=True)
        _ghi_xml(ET.ElementTree(goc), goc, duong_ra)
    except Exception as e:
        return None, "Không ghi được khuôn %s: %s" % (duong_ra, e)
    ghi_log("[KHUON BCTC] %s: khung %s + phu luc %s%s (ma %s, pban %s, xsd %s) -> %s, dien 0 vao %d o"
            % (mau, os.path.basename(km["khung"]), ", ".join(gan) or "-", (" - THIEU " + ", ".join(km["thieu"])) if km.get("thieu") else "",
               km["maTKhai"], km["pbanTKhaiXML"], "co" if so is not None else "khong", duong_ra, n0))
    return duong_ra, ""


# ---------------------------------------------------------------------------
#  DIEN SO VAO KHUON -> FILE XML MOI
# ---------------------------------------------------------------------------
def xuat_xml(ma_tk, du_lieu, duong_ra, duong_mau=None, bo_qua_tu_kiem=False, ttc=None):
    """du_lieu: {'dau': {...}, 'chi_tieu': {khoa: so}, 'bang_ke': {duong: [ {the: gt} ]}}.
       Tra ve (duong_ra, "") hoac (None, loi)."""
    khuon = doc_khuon(ma_tk)
    mau = duong_mau or (khuon or {}).get("duong_mau")
    if not khuon or not mau or not os.path.exists(mau):
        return None, ("Chua co file mau XML cua to khai '%s'. Trong HTKK mo to khai do roi bam "
                      "\"Ket xuat XML\", sau do nhap to khai o He thong > Nguon HTKK, to khai va BCTC ky truoc. "
                      "Lam mot lan cho moi mau to khai." % ma_tk)
    ct = {str(k): v for k, v in (du_lieu.get("chi_tieu") or {}).items()}

    # tu kiem TRUOC khi ghi file - thu du lieu sai khong duoc di tiep sang co quan thue
    if not bo_qua_tu_kiem and ma_tk.upper().replace(" ", "").startswith("01/GTGT"):
        ngan = {k.lower().lstrip("/").replace("ct", "", 1) if k.lower().startswith("ct") else k.lower(): v
                for k, v in ct.items() if "/" not in k}
        chan, canh = tu_kiem_01gtgt(ngan)
        for c in canh:
            ghi_log("[CANH BAO] " + c)
        if chan:
            return None, ("So lieu chua can doi nen KHONG ket xuat (tranh nop to khai sai):\n- "
                          + "\n- ".join(chan))

    try:
        cay = ET.parse(mau)
    except Exception as e:
        return None, "Khong doc duoc file mau: %s" % e
    goc = cay.getroot()

    # (1) xoa trang: khong de so cua ky mau ro ri sang to khai moi
    n_xoa = xoa_so_trong_khuon(goc)
    mau_dong = xoa_dong_lap(goc)
    if n_xoa or mau_dong:
        ghi_log("[XUAT] Xoa trang khuon: %d o so, %d bang ke (%s)"
                % (n_xoa, len(mau_dong), ", ".join(k.split("/")[-1] for k in mau_dong) or "-"))

    # (2) dien bang ke (neu co)
    for duong, cac_dong in (du_lieu.get("bang_ke") or {}).items():
        hop = [k for k in mau_dong if k.endswith("/" + duong.strip("/")) or duong.strip("/") in k]
        if not hop:
            ghi_log("[XUAT] Khong thay bang ke '%s' trong khuon - bo qua" % duong)
            continue
        kmau, _ = mau_dong[hop[0]]
        cha = _tim_nut(goc, hop[0].rsplit("/", 1)[0])
        if cha is None:
            continue
        chen = 0
        for i, dong in enumerate(cac_dong):
            cha.insert(i, _dong_moi(kmau, dong))
            chen += 1
        n_tong = cong_bang_ke(cha)
        ghi_log("[XUAT] Bang ke %s: chen %d dong, cong %d o tongCong" % (hop[0], chen, n_tong))

    # (3) dien chi tieu
    da, thieu = [], []
    for khoa, gt in ct.items():
        duong, loi = giai_khoa(khuon, khoa)
        if not duong:
            thieu.append("%s (%s)" % (khoa, loi))
            continue
        nut = _tim_nut(goc, duong)
        if nut is None:
            thieu.append("%s (khong thay trong file mau)" % khoa)
            continue
        nut.text = _so_xml(gt)
        da.append(khoa)

    # (4) dien thong tin chung (GD162: truoc het theo to khai ky truoc - moi hon file mau; roi du lieu VB gui)
    if ttc:
        ghi_log("[XUAT] Thong tin chung theo to khai ky truoc: %d o" % _bu_ttc(goc, ttc))
    nk = _tim_nut(goc, "/HSoKhaiThue/TTinChung/TTinTKhaiThue/TKhaiThue/nguoiKy")
    if nk is not None and not (nk.text or "").strip() and (du_lieu.get("dau") or {}).get("nguoiKyDuPhong"):
        nk.text = str(du_lieu["dau"]["nguoiKyDuPhong"])          # GD162: nguoi ky khai bao cua bo so khi mau / ky truoc khong co
    for ten, gt in (du_lieu.get("dau") or {}).items():
        duong = (khuon.get("dau") or {}).get(ten)
        if not duong:
            continue
        nut = _tim_nut(goc, duong)
        if nut is not None and gt not in (None, ""):
            nut.text = str(gt)

    if thieu:
        ghi_log("[XUAT] Khong dien duoc: %s" % "; ".join(thieu))

    # GD56: ky / ngay theo dinh dang HTKK (kyKKhai cua file mau khong duoc o lai), moi dong bang ke
    # mot ID rieng. Chi to khai thang / quy (01/GTGT) - BCTC nam co cach ghi ky khac.
    if ma_tk.upper().replace(" ", "").startswith("01/GTGT"):
        _dien_ky(goc, du_lieu.get("dau") or {})
        tm = _tim_nut(goc, "/HSoKhaiThue/CTieuTKhaiChinh/tieuMucHachToan")
        if tm is not None and (tm.text or "").strip() not in TIEU_MUC_HOP_LE:
            tm.text = TIEU_MUC_MAC_DINH
    _danh_so_dong(goc)

    try:
        os.makedirs(os.path.dirname(os.path.abspath(duong_ra)), exist_ok=True)
    except Exception:
        pass
    try:
        ghi_xml_htkk(goc, duong_ra)
    except Exception as e:
        return None, "Khong ghi duoc file XML: %s" % e
    ghi_log("[XUAT] %s: dien %d chi tieu -> %s" % (ma_tk, len(da), duong_ra))
    if thieu:
        return duong_ra, ""
    return duong_ra, ""


def _ghi_xml(cay, goc, duong_ra):
    """Ghi UTF-8, giu vung ten goc khong bi doi thanh ns0:."""
    vt = goc.tag.split("}", 1)[0][1:] if "}" in goc.tag else ""
    if vt:
        try:
            ET.register_namespace("", vt)
        except Exception:
            pass
    cay.write(duong_ra, encoding="utf-8", xml_declaration=True)


# ---------------------------------------------------------------------------
#  GD56 - LAY KHUON THANG TU HTKK CAI TREN MAY + PHU LUC 142/174/204 THEO DONG HANG
#
#  VI SAO HTKK BAO "Cau truc to khai xml nhap vao khong hop le" (GD21 -> GD55):
#    xoa_so_trong_khuon() dua VE 0 moi the "trong giong con so" - ke ca MA trong phan thong tin
#    chung: maTKhai 842 -> 0, pbanTKhaiXML 2.8.3 -> 0, maCQTNoiNop, maTinhNNT, ma_NganhNghe,
#    tieuMucHachToan 1701 -> 0 (sai luoc do XSD cua chinh HTKK: chi nhan 1701|1704|...).
#    Them: kyKKhai giu nguyen ky cua file mau (1/2026 khi dang xuat quy 2), ngayLapTKhai ghi
#    dd/mm/yyyy, ngayKy giu ngay cua file mau, moi dong bang ke deu ID="ID_1".
#    Da tai hien: dem file xuat cu kiem bang Validate\01_GTGT_TT80_283.xsd cua HTKK -> bao loi.
#
#  CACH MOI: KHONG can file mau nua neu may co HTKK.
#    - Tim HTKK: duong nguoi dung dat (cai-dat.json "htkk_duong") -> loi tat Start Menu
#      C:\ProgramData\Microsoft\Windows\Start Menu\Programs\TCT\HTKK\HTKK.lnk (doc WORKING_DIR,
#      vi day la loi tat MSI tro vao C:\Windows\Installer) -> so dang ky go cai dat -> cac o dia.
#    - Project\Menu.xml cua HTKK: MaToKhai (842), VersionXML (2.8.3), ten, mo ta bieu mau,
#      phu luc nao nam o the PL_NQ142_GTGT ("PL 142/2024/QH15-174/2024/QH15-204/2025/QH15").
#    - InterfaceTemplates\xml\01_GTGT_TT80_xml_283.xml + 01_10_MGT_GTGT_TT80_xml_283.xml:
#      khung XML trang ma chinh HTKK dung -> dung thu tu the, khong doan.
#    - DataFiles\<MST>\HEADER.xml: thong tin chung cua NNT ma HTKK dang luu (CQT, tinh, nguoi ky).
#    - Validate\01_GTGT_TT80_283.xsd: kiem file TRUOC khi giao (co lxml thi kiem day du theo luoc
#      do cua HTKK; khong co thi kiem noi bo cac loi da gap). Sai -> KHONG giao file, bao ro loi.
#
#  PHU LUC 142/174/204 (the PL_NQ142_GTGT) dung mau HTKK 5.7.x:
#    I  mua vao 8%: ten hang, gia tri chua thue, THUE GTGT (cot 4 bat buoc > 0)
#    II ban ra 8% : ten hang, gia tri, 10, 8, giam = (3) x [(4)-(5)] lam tron tung dong
#    III [09] = [08] - [06]  (tong giam ban ra - tong thue mua vao 8%) - co the AM.
#    Dong hang lay tu hoa don dien tu da tai (HDDTTaiVe) khi khop tien voi hoa don so sach;
#    khong khop / khong co thi 1 dong theo hoa don so sach (MatHang, ThanhTien, thue).
#    Tong cot (3) luon bam hoa don SO SACH thue suat 8% -> khop [32] / [23] cua to khai.
# ---------------------------------------------------------------------------
import calendar as _cal
import copy as _copy
import math as _math
import struct as _struct
import unicodedata as _ud

NS_XSI = "http://www.w3.org/2001/XMLSchema-instance"
TTIN_NHA_CCAP = "686EA069E39ECDEAFF7B44D25713EA55"   # HTKK ghi hang so nay vao moi file ket xuat
MA_FILE_01GTGT = "01_GTGT_TT80"
NGANH_NGHE_MAC_DINH = ("00", "Hoạt động sản xuất kinh doanh thông thường")
TIEU_MUC_MAC_DINH = "1701"
TIEU_MUC_HOP_LE = ("1701", "1704", "1705", "0000", "1761", "1052", "1056", "1057")
LNK_MAC_DINH = (
    r"%ProgramData%\Microsoft\Windows\Start Menu\Programs\TCT\HTKK\HTKK.lnk",
    r"%APPDATA%\Microsoft\Windows\Start Menu\Programs\TCT\HTKK\HTKK.lnk",
    r"%PUBLIC%\Desktop\HTKK.lnk",
    r"%USERPROFILE%\Desktop\HTKK.lnk",
    r"%USERPROFILE%\OneDrive\Desktop\HTKK.lnk",
)
# The khong bao gio dua ve 0 khi xoa trang khuon (ma, co danh dau) - xem xoa_so_trong_khuon
_GIU_NGUYEN = ("tieuMucHachToan", "bctcDaKiemToan", "co", "khong", "loaiTKhai", "soLan")


def _bo_dau(s):
    s = str(s or "").replace("Đ", "D").replace("đ", "d")
    s = "".join(c for c in _ud.normalize("NFD", s) if _ud.category(c) != "Mn")
    return re.sub(r"\s+", " ", s).strip()


def _tron(x):
    """Lam tron nua len (khong phai kieu ngan hang cua round()): 43.703,5 -> 43.704; -1.012.500,5 -> -1.012.501."""
    try:
        x = float(x)
    except Exception:
        return 0
    return int(_math.floor(abs(x) + 0.5)) * (1 if x >= 0 else -1)


def _mst_so(v):
    return re.sub(r"[^0-9-]", "", str(v or "")).strip("-")


def _mst10(v):
    return re.sub(r"\D", "", str(v or ""))[:10]


def _so_hd(v):
    s = re.sub(r"\D", "", str(v or ""))
    return s.lstrip("0") or ("0" if s else "")


# ---------------------------------------------------------------------------
#  LOI TAT .LNK (MS-SHLLINK) - chi doc, khong can pywin32
# ---------------------------------------------------------------------------
def _chuoi_u16(b, p):
    e = p
    while e + 1 < len(b) and not (b[e] == 0 and b[e + 1] == 0):
        e += 2
    return b[p:e].decode("utf-16-le", "replace")


def _chuoi_a(b, p):
    e = b.find(b"\x00", p)
    if e < 0:
        e = len(b)
    try:
        return b[p:e].decode("mbcs" if os.name == "nt" else "latin-1", "replace")
    except Exception:
        return b[p:e].decode("latin-1", "replace")


def doc_lnk(duong):
    """File .lnk -> {'dich', 'ten', 'tuong_doi', 'thu_muc', 'doi_so', 'bieu_tuong'} (thieu thi khong co khoa).
       Loi tat HTKK la loi tat MSI 'quang cao' (Darwin): dich / bieu tuong tro vao C:\\Windows\\Installer,
       chi WORKING_DIR (vd F:\\HTKK\\Project\\) moi la thu muc cai that."""
    try:
        with open(duong, "rb") as f:
            b = f.read()
    except Exception:
        return {}
    if len(b) < 0x4C or _struct.unpack_from("<I", b, 0)[0] != 0x4C:
        return {}
    co = _struct.unpack_from("<I", b, 0x14)[0]
    p = 0x4C
    kq = {}
    try:
        if co & 0x1:                                    # HasLinkTargetIDList
            p += 2 + _struct.unpack_from("<H", b, p)[0]
        if co & 0x2:                                    # HasLinkInfo
            n = _struct.unpack_from("<I", b, p)[0]
            hs = _struct.unpack_from("<I", b, p + 4)[0]
            cf = _struct.unpack_from("<I", b, p + 8)[0]
            if cf & 1:
                if hs >= 0x24:
                    o = _struct.unpack_from("<I", b, p + 28)[0]
                    if o:
                        kq["dich"] = _chuoi_u16(b, p + o)
                if not kq.get("dich"):
                    o = _struct.unpack_from("<I", b, p + 16)[0]
                    if o:
                        kq["dich"] = _chuoi_a(b, p + o)
            p += n
        uni = bool(co & 0x80)
        for bit, ten in ((0x4, "ten"), (0x8, "tuong_doi"), (0x10, "thu_muc"), (0x20, "doi_so"), (0x40, "bieu_tuong")):
            if co & bit:
                n = _struct.unpack_from("<H", b, p)[0]
                p += 2
                if uni:
                    kq[ten] = b[p:p + 2 * n].decode("utf-16-le", "replace")
                    p += 2 * n
                else:
                    kq[ten] = b[p:p + n].decode("latin-1", "replace")
                    p += n
    except Exception:
        pass
    return kq


# ---------------------------------------------------------------------------
#  TIM HTKK TREN MAY
# ---------------------------------------------------------------------------
def la_goc_htkk(d):
    return bool(d) and os.path.isfile(os.path.join(d, "Project", "Menu.xml")) \
        and os.path.isdir(os.path.join(d, "InterfaceTemplates", "xml"))


def goc_tu_duong(p, _sau=0):
    """Mot duong bat ky (loi tat .lnk, HTKK.exe, thu muc cai, file ben trong) -> thu muc goc HTKK, hoac ''."""
    p = os.path.expandvars(str(p or "").strip().strip('"'))
    if not p or _sau > 2:
        return ""
    if p.lower().endswith(".lnk"):
        if not os.path.isfile(p):
            return ""
        t = doc_lnk(p)
        ung = [t.get("thu_muc"), t.get("dich")]
        if t.get("tuong_doi"):
            ung.append(os.path.normpath(os.path.join(os.path.dirname(p), t["tuong_doi"])))
        for x in ung:
            if x and "\\windows\\installer" not in x.lower().replace("/", "\\"):
                g = goc_tu_duong(x, _sau + 1)
                if g:
                    return g
        return ""
    if not os.path.exists(p):
        return ""
    d = p if os.path.isdir(p) else os.path.dirname(p)
    for _ in range(5):
        if la_goc_htkk(d):
            return os.path.normpath(d)
        cha = os.path.dirname(d)
        if not cha or cha == d:
            break
        d = cha
    return ""


def _htkk_so_dang_ky():
    ra = []
    try:
        import winreg
    except Exception:
        return ra
    for hk, duong in ((getattr(winreg, "HKEY_LOCAL_MACHINE"), r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"),
                      (getattr(winreg, "HKEY_LOCAL_MACHINE"), r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
                      (getattr(winreg, "HKEY_CURRENT_USER"), r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall")):
        try:
            k = winreg.OpenKey(hk, duong)
        except Exception:
            continue
        i = 0
        while i < 3000:
            try:
                ten = winreg.EnumKey(k, i)
            except OSError:
                break
            i += 1
            try:
                kk = winreg.OpenKey(k, ten)
                dn = str(winreg.QueryValueEx(kk, "DisplayName")[0])
            except Exception:
                continue
            u = _bo_dau(dn).upper()
            if "HTKK" not in u and "HO TRO KE KHAI" not in u:
                continue
            for v in ("InstallLocation", "DisplayIcon", "InstallSource"):
                try:
                    x = str(winreg.QueryValueEx(kk, v)[0]).strip().strip('"')
                    if x:
                        ra.append(x.split(",")[0])
                except Exception:
                    pass
    return ra


def tim_htkk(goi_y=""):
    """-> {'goc','nguon','lnk','exe','phien_ban'} hoac None. goi_y: duong nguoi dung / VB dua vao."""
    s = doc_cai_dat()
    ung = []
    if goi_y:
        ung.append(("chi_dinh", goi_y))
    if s.get("htkk_duong"):
        ung.append(("cai_dat", s["htkk_duong"]))
    for p in LNK_MAC_DINH:
        ung.append(("start_menu", p))
    if s.get("htkk_goc"):
        ung.append(("lan_truoc", s["htkk_goc"]))
    if os.name == "nt":
        for p in _htkk_so_dang_ky():
            ung.append(("so_dang_ky", p))
        for o in "CDEFGHIJK":
            for sub in ("HTKK", r"Program Files (x86)\HTKK", r"Program Files\HTKK", r"TCT\HTKK", r"Program Files (x86)\TCT\HTKK"):
                ung.append(("o_dia", o + ":\\" + sub))
    for nguon, p in ung:
        g = goc_tu_duong(p)
        if not g:
            continue
        lnk = ""
        if str(p).lower().endswith(".lnk"):
            lnk = os.path.expandvars(p)
        else:
            for q in LNK_MAC_DINH:
                q = os.path.expandvars(q)
                if os.path.isfile(q) and goc_tu_duong(q) == g:
                    lnk = q
                    break
        pb = ""
        try:
            with open(os.path.join(g, "version", "version.inf"), "r", encoding="utf-8-sig", errors="replace") as f:
                pb = f.read().strip()
        except Exception:
            pass
        if s.get("htkk_goc") != g:
            s["htkk_goc"] = g
            luu_cai_dat(s)
        return {"goc": g, "nguon": nguon, "lnk": lnk, "exe": os.path.join(g, "Project", "HTKK.exe"), "phien_ban": pb}
    return None


def dat_duong_htkk(p):
    """Nguoi dung chon duong HTKK (thu muc cai, HTKK.exe hoac loi tat). Hop le moi luu. -> (goc, loi)."""
    p = str(p or "").strip().strip('"')
    if "\\windows\\installer" in p.lower().replace("/", "\\"):
        return "", ("Đây là tệp biểu tượng của bộ cài (C:\\Windows\\Installer), không phải nơi cài HTKK. "
                    "Anh chọn HTKK.exe trong thư mục cài HTKK (ví dụ F:\\HTKK\\Project\\HTKK.exe) hoặc chính thư mục đó.")
    g = goc_tu_duong(p)
    if not g:
        return "", ("Không thấy HTKK ở: %s\nThư mục cài HTKK phải có Project\\Menu.xml và InterfaceTemplates\\xml "
                    "(ví dụ F:\\HTKK hoặc C:\\Program Files (x86)\\HTKK)." % p)
    s = doc_cai_dat()
    s["htkk_duong"] = p
    s["htkk_goc"] = g
    luu_cai_dat(s)
    ghi_log("[HTKK] Da dat duong HTKK: %s -> goc %s" % (p, g))
    return g, ""


def mo_htkk(h=None):
    """Mo ung dung HTKK (qua loi tat neu co - loi tat MSI can mo bang shell). -> (True, duong) / (False, loi)."""
    h = h or tim_htkk()
    if not h:
        return False, ("Không tìm thấy HTKK trên máy này. Vào Hệ thống > Nguồn HTKK, tờ khai và BCTC kỳ trước... > Chỉ đường HTKK, chọn HTKK.exe trong thư mục cài HTKK.")
    loi = ""
    for p in (h.get("lnk"), h.get("exe")):
        if not p or not os.path.isfile(p):
            continue
        try:
            if os.name == "nt":
                if p.lower().endswith(".exe"):
                    import subprocess
                    subprocess.Popen([p], cwd=os.path.dirname(p))
                else:
                    os.startfile(p)
            ghi_log("[HTKK] Mo HTKK: %s" % p)
            return True, p
        except Exception as e:
            loi = str(e)
    return False, "Không mở được HTKK (%s): %s" % (h.get("goc"), loi or "không có HTKK.exe / lối tắt")


# ---------------------------------------------------------------------------
#  KHUON CUA CHINH HTKK
# ---------------------------------------------------------------------------
def _tep_phien_ban(thu_muc, tien_to, so):
    """'<tien_to><so>.xml' neu co; khong thi ban lon nhat <= so; khong nua thi ban lon nhat."""
    p = os.path.join(thu_muc, tien_to + so + ".xml")
    if os.path.isfile(p):
        return p
    ds = []
    try:
        for f in os.listdir(thu_muc):
            m = re.match(re.escape(tien_to) + r"(\d+)\.xml$", f, re.I)
            if m:
                ds.append((int(m.group(1)), os.path.join(thu_muc, f)))
    except Exception:
        return ""
    if not ds:
        return ""
    ds.sort()
    duoi = [x for x in ds if so.isdigit() and x[0] <= int(so)]
    return (duoi or ds)[-1][1]


def khuon_may(goc, ma_file=MA_FILE_01GTGT):
    """Doc Project\\Menu.xml cua HTKK -> mo ta to khai + duong khung XML / XSD. -> (dict, loi)."""
    duong_menu = os.path.join(goc, "Project", "Menu.xml")
    try:
        cay = ET.parse(duong_menu)
    except Exception as e:
        return None, "Không đọc được %s: %s" % (duong_menu, e)
    muc, pb_lon = None, ()
    for m in cay.getroot().iter():
        if _ten(m) != "Menu" or m.get("MaFile") != ma_file:
            continue
        v = tuple(int(x) for x in re.findall(r"\d+", m.get("VersionXML") or "0"))
        if muc is None or v > pb_lon:
            muc, pb_lon = m, v
    if muc is None:
        return None, "HTKK ở %s không có tờ khai %s (bản HTKK quá cũ?)." % (goc, ma_file)
    pb = (muc.get("VersionXML") or "").strip()
    so = re.sub(r"\D", "", pb)
    thu_xml = os.path.join(goc, "InterfaceTemplates", "xml")
    khung = _tep_phien_ban(thu_xml, ma_file + "_xml_", so)
    if not khung:
        return None, "Không thấy khung XML %s_xml_%s.xml trong %s" % (ma_file, so, thu_xml)
    kq = {"goc": goc, "ma_file": ma_file, "maTKhai": (muc.get("MaToKhai") or "").strip(), "pbanTKhaiXML": pb,
          "tenTKhai": muc.get("TenToKhai") or "", "moTaBMau": muc.get("MoTaBieuMau") or "",
          "khung": khung, "xsd": "", "pl142": {}}
    xsd = os.path.join(goc, "InterfaceTemplates", "Validate", "%s_%s.xsd" % (muc.get("XsdSchema") or ma_file, so))
    if os.path.isfile(xsd):
        kq["xsd"] = xsd
    for sh in muc.iter():
        if _ten(sh) == "Sheet" and (sh.get("XMLnode") or "").rstrip("/").endswith("/PL_NQ142_GTGT"):
            kq["pl142"] = {"ten": sh.get("SheetName") or "", "data_file": sh.get("DataFile") or "",
                           "khung": _tep_phien_ban(thu_xml, (sh.get("DataFile") or "") + "_xml_", so)}
            break
    return kq, ""


def dau_may(goc, mst):
    """DataFiles\\<MST>\\HEADER.xml cua HTKK -> {PropertyInfo: Value} (thong tin chung NNT HTKK dang luu)."""
    so = _mst_so(mst)
    for ten in (so, so.replace("-", ""), so.split("-")[0]):
        if not ten:
            continue
        p = os.path.join(goc, "DataFiles", ten, "HEADER.xml")
        if not os.path.isfile(p):
            continue
        try:
            g = ET.parse(p).getroot()
        except Exception:
            continue
        d = {}
        for c in g.iter():
            k = (c.get("PropertyInfo") or "").strip()
            if k and k not in d:
                d[k] = (c.get("Value") or "").strip()
        return d
    return {}


def _khung_ns(duong):
    """Khung XML cua HTKK (khong co vung ten, the rong) -> Element da gan vung ten TKhaiThue, bo khoang trang."""
    with open(duong, "rb") as f:
        b = f.read()
    if b[:2] in (b"\xff\xfe", b"\xfe\xff"):
        txt = b.decode("utf-16")
    else:
        txt = b.decode("utf-8-sig")
    txt = re.sub(r"^\s*<\?xml[^>]*\?>", "", txt)
    goc = ET.fromstring(txt)
    for n in goc.iter():
        if not str(n.tag).startswith("{"):
            n.tag = "{%s}%s" % (NS_TKHAI, n.tag)
        n.tail = None
        if list(n):
            n.text = None
        elif n.text is not None and not n.text.strip():
            n.text = None
    return goc


def _con(nut, ten):
    for c in list(nut):
        if _ten(c) == ten:
            return c
    return None


def _dat(goc, duong, gt):
    n = _tim_nut(goc, duong)
    if n is not None:
        n.text = "" if gt is None else str(gt)
    return n


def _ngay_iso(s, mac_dinh=None):
    """'24/09/2026' | '2026-09-24' | datetime -> '2026-09-24'."""
    if isinstance(s, datetime):
        return s.strftime("%Y-%m-%d")
    s = str(s or "").strip()
    for f in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%Y/%m/%d"):
        try:
            return datetime.strptime(s[:10], f).strftime("%Y-%m-%d")
        except Exception:
            pass
    return mac_dinh if mac_dinh is not None else datetime.now().strftime("%Y-%m-%d")


def ky_ke_khai(tu, den):
    """('01/04/2026','30/06/2026') -> ('Q','2/2026'); ('01/08/2026','31/08/2026') -> ('M','08/2026')."""
    try:
        d1 = datetime.strptime(str(tu)[:10], "%d/%m/%Y")
        d2 = datetime.strptime(str(den)[:10], "%d/%m/%Y")
    except Exception:
        return "", ""
    if d1.day == 1 and (d1.month - 1) % 3 == 0:
        m3 = d1.month + 2
        if d2 == datetime(d1.year, m3, _cal.monthrange(d1.year, m3)[1]):
            return "Q", "%d/%d" % ((d1.month - 1) // 3 + 1, d1.year)
    return "M", "%02d/%d" % (d1.month, d1.year)


def _dien_ky(goc, dau):
    """Ky ke khai + ngay lap / ngay ky dung dinh dang HTKK ghi (kyKKhai 'Q/YYYY' hoac 'MM/YYYY', ngay ISO)."""
    t = "/HSoKhaiThue/TTinChung/TTinTKhaiThue/TKhaiThue"
    tu, den = dau.get("kyKKhaiTuNgay"), dau.get("kyKKhaiDenNgay")
    kieu, ky = ky_ke_khai(tu, den)
    if kieu:
        _dat(goc, t + "/KyKKhaiThue/kieuKy", dau.get("kieuKy") or kieu)
        _dat(goc, t + "/KyKKhaiThue/kyKKhai", dau.get("kyKKhai") or ky)
        _dat(goc, t + "/KyKKhaiThue/kyKKhaiTuNgay", tu)
        _dat(goc, t + "/KyKKhaiThue/kyKKhaiDenNgay", den)
        _dat(goc, t + "/KyKKhaiThue/kyKKhaiTuThang", "")
        _dat(goc, t + "/KyKKhaiThue/kyKKhaiDenThang", "")
    _dat(goc, t + "/ngayLapTKhai", _ngay_iso(dau.get("ngayLapTKhai")))
    _dat(goc, t + "/ngayKy", _ngay_iso(dau.get("ngayKy") or dau.get("ngayLapTKhai")))
    _dat(goc, t + "/loaiTKhai", dau.get("loaiTKhai") or "C")
    _dat(goc, t + "/soLan", str(dau.get("soLan") or 0))


def _danh_so_dong(goc):
    """Moi dong bang ke mot ID rieng ID_1..ID_n (nhan ban dong mau thi ca bang deu la ID_1)."""
    for nut in goc.iter():
        i = 0
        for c in list(nut):
            if list(c) and c.get("ID") is not None:
                i += 1
                c.set("ID", "ID_%d" % i)


def _so_nguyen(v):
    return str(_tron(_so(v)))


# ---------------------------------------------------------------------------
#  PHU LUC 142/174/204 TU HOA DON SO SACH + DONG HANG HOA DON DIEN TU
# ---------------------------------------------------------------------------
def lap_pl204(raw, ts_qd=10.0, ts_sau=8.0):
    """raw = {'hd': [hoa don so sach 8%], 'dong': [dong hang HDDTTaiVe 8%]} (ModHDDTHTKK.HTKK_JsonPL204).
         hd  : {'h': 1 ban | -1 mua, 'so', 'ngay', 'mst' doi tac, 'ten' MatHang, 'gt', 'thue', 'kt' ChungTu.MaCT}
         dong: {'h', 'so', 'mst', 'kt' MaCTKeToan, 'ten', 'gt', 'thue', 'tt' trang thai}
       -> {'ban_ra': [...], 'mua_vao': [...], 'tong': {...}, 'ct9', 'thong_ke': {...}}"""
    hd = [x for x in (raw.get("hd") or []) if int(_so(x.get("h"))) in (1, -1)]
    dong = raw.get("dong") or []
    theo_kt, theo_so, bo = {}, {}, 0
    for i, d in enumerate(dong):
        h = int(_so(d.get("h")))
        if h not in (1, -1):
            continue
        tt = _bo_dau(d.get("tt")).lower()
        if "bi thay the" in tt or "bi huy" in tt or "da huy" in tt:
            bo += 1
            continue
        d = dict(d)
        d["_i"] = i
        kt = str(d.get("kt") or "").strip()
        if kt:
            theo_kt.setdefault((h, kt), []).append(d)
        theo_so.setdefault((h, _so_hd(d.get("so")), _mst10(d.get("mst"))), []).append(d)
    da_dung = set()
    gom = {1: {}, -1: {}}
    tk = {"hd_ban": 0, "hd_ban_hddt": 0, "hd_mua": 0, "hd_mua_hddt": 0, "dong_bo_huy": bo, "uoc_thue_mua": 0,
          "gt_ban_so_sach": 0.0, "gt_mua_so_sach": 0.0, "thue_mua_so_sach": 0.0}

    def them(h, ten, gt, thue):
        ten = re.sub(r"[\x00-\x1f\x7f]", " ", str(ten or ""))       # XML khong chua duoc ky tu dieu khien
        ten = re.sub(r"\s+", " ", ten).strip() or "Hàng hóa, dịch vụ"
        k = ten.casefold()
        if k not in gom[h]:
            gom[h][k] = [ten[:150], 0.0, 0.0]
        gom[h][k][1] += gt
        gom[h][k][2] += thue

    for x in hd:
        h = int(_so(x.get("h")))
        gt, thue = _so(x.get("gt")), _so(x.get("thue"))
        ten_so = str(x.get("ten") or "").strip() or ("Hàng hóa, dịch vụ theo hóa đơn số %s" % (x.get("so") or "?"))
        kt = str(x.get("kt") or "").strip()
        ung = [d for d in theo_kt.get((h, kt), []) if d["_i"] not in da_dung] if kt else []
        if not ung:
            ung = [d for d in theo_so.get((h, _so_hd(x.get("so")), _mst10(x.get("mst"))), []) if d["_i"] not in da_dung]
        s = sum(_so(d.get("gt")) for d in ung)
        khop = bool(ung) and abs(s - gt) <= max(2.0, abs(gt) * 0.0005)
        if h == 1:
            tk["hd_ban"] += 1
            tk["gt_ban_so_sach"] += gt
        else:
            tk["hd_mua"] += 1
            tk["gt_mua_so_sach"] += gt
            tk["thue_mua_so_sach"] += thue
        if khop:
            tk["hd_ban_hddt" if h == 1 else "hd_mua_hddt"] += 1
            # chenh lam tron (<= 2 d) giua dong HDDT va hoa don so sach don vao dong lon nhat -> tong cot (3)
            # luon bang so sach (khop [32] / [23] cua to khai)
            du = gt - s
            lon = max(range(len(ung)), key=lambda j: abs(_so(ung[j].get("gt"))))
            for j, d in enumerate(ung):
                da_dung.add(d["_i"])
                g = _so(d.get("gt")) + (du if j == lon else 0)
                t = _so(d.get("thue"))
                if h == -1 and t == 0 and g != 0:
                    t = _tron(g * ts_sau / 100.0)
                    tk["uoc_thue_mua"] += 1
                them(h, d.get("ten") or ten_so, g, t)
        else:
            if h == -1 and thue == 0 and gt != 0:
                thue = _tron(gt * ts_sau / 100.0)
                tk["uoc_thue_mua"] += 1
            them(h, ten_so, gt, thue)

    def sap(ds):
        return sorted(ds, key=lambda r: (_bo_dau(r[0]).casefold(), r[0]))

    ban, mua = [], []
    for ten, gt, _t in sap(gom[1].values()):
        gt = _tron(gt)
        if gt == 0:
            continue
        ban.append({"tenHHDV": ten, "giaTriHHDV": gt, "thueSuatTheoQuyDinh": "%g" % ts_qd,
                    "thueSuatSauGiam": "%g" % ts_sau, "thueGTGTDuocGiam": _tron(gt * (ts_qd - ts_sau) / 100.0)})
    for ten, gt, t in sap(gom[-1].values()):
        gt, t = _tron(gt), _tron(t)
        if gt == 0 and t == 0:
            continue
        mua.append({"tenHHDVMuaVao": ten, "giaTriHHDVMuaVao": gt, "thueGTGTHHDV": t})
    tong = {"tongCongGiaTriHHDV": sum(r["giaTriHHDV"] for r in ban),
            "tongCongThueGTGTDuocGiam": sum(r["thueGTGTDuocGiam"] for r in ban),
            "tongCongGiaTriHHDVMuaVao": sum(r["giaTriHHDVMuaVao"] for r in mua),
            "tongCongThueGTGTHHDV": sum(r["thueGTGTHHDV"] for r in mua)}
    tk["dong_ban"], tk["dong_mua"] = len(ban), len(mua)
    return {"ban_ra": ban, "mua_vao": mua, "tong": tong,
            "ct9": tong["tongCongThueGTGTDuocGiam"] - tong["tongCongThueGTGTHHDV"], "thong_ke": tk}


def pl_tu_bang_ke_cu(bk):
    """Tuong thich goi du lieu cu ('bang_ke' da lap san trong VB) -> dang cua lap_pl204."""
    ban = [dict(r) for r in (bk.get("HH_DV_BanRaTrongKy") or [])]
    mua = [dict(r) for r in (bk.get("HH_DV_MuaVaoTrongKy") or [])]
    for r in ban:
        r["giaTriHHDV"] = _tron(_so(r.get("giaTriHHDV")))
        r["thueGTGTDuocGiam"] = _tron(_so(r.get("thueGTGTDuocGiam")))
    for r in mua:
        r["giaTriHHDVMuaVao"] = _tron(_so(r.get("giaTriHHDVMuaVao")))
        r["thueGTGTHHDV"] = _tron(_so(r.get("thueGTGTHHDV")))
    tong = {"tongCongGiaTriHHDV": sum(r["giaTriHHDV"] for r in ban),
            "tongCongThueGTGTDuocGiam": sum(r["thueGTGTDuocGiam"] for r in ban),
            "tongCongGiaTriHHDVMuaVao": sum(r["giaTriHHDVMuaVao"] for r in mua),
            "tongCongThueGTGTHHDV": sum(r["thueGTGTHHDV"] for r in mua)}
    return {"ban_ra": ban, "mua_vao": mua, "tong": tong,
            "ct9": tong["tongCongThueGTGTDuocGiam"] - tong["tongCongThueGTGTHHDV"], "thong_ke": {}}


def _lap_pl142(khung_pl, pl):
    """Khung 01_10_MGT_GTGT_TT80_xml_<ban>.xml cua HTKK + so lieu -> Element <PL_NQ142_GTGT>."""
    goc = _khung_ns(khung_pl)
    for khoi, ds in (("HH_DV_MuaVaoTrongKy", pl.get("mua_vao") or []), ("HH_DV_BanRaTrongKy", pl.get("ban_ra") or [])):
        k = _con(goc, khoi)
        if k is None:
            continue
        mau = _con(k, "BangKeTenHHDV")
        if not ds or mau is None:
            goc.remove(k)                      # khoi nay minOccurs=0 trong luoc do HTKK
            continue
        vt = list(k).index(mau)
        k.remove(mau)
        for i, r in enumerate(ds):
            m = _copy.deepcopy(mau)
            m.set("ID", "ID_%d" % (i + 1))
            for c in list(m):
                v = r.get(_ten(c))
                c.text = "" if v is None else str(v)
            k.insert(vt + i, m)
        for c in list(k):
            t = _ten(c)
            if not list(c) and t.startswith("tongCong"):
                c.text = str((pl.get("tong") or {}).get(t, 0))
    cl = _tim_nut(goc, "/ChenhLech/ct9")
    if cl is not None:
        cl.text = str(_tron(pl.get("ct9") or 0))
    return goc


# ---------------------------------------------------------------------------
#  LAP TO KHAI 01/GTGT TU KHUON CUA HTKK TREN MAY
# ---------------------------------------------------------------------------
def lap_xml_may(km, du_lieu, dau_htkk=None, pban_dvu="", pl=None, ttc=None):
    """km = khuon_may(); du_lieu nhu xuat_xml; dau_htkk = dau_may(); pl = lap_pl204(); ttc = thong tin chung to khai ky truoc
       (GD162: o HEADER HTKK de trong thi lay theo to khai ky truoc). -> Element goc."""
    goc = _khung_ns(km["khung"])
    dau = dict(du_lieu.get("dau") or {})
    hd = dau_htkk or {}
    tt = ttc or {}                    # GD162
    t = "/HSoKhaiThue/TTinChung/TTinTKhaiThue/TKhaiThue"
    n = "/HSoKhaiThue/TTinChung/TTinTKhaiThue/NNT"
    _dat(goc, "/HSoKhaiThue/TTinChung/TTinDVu/maDVu", "HTKK")
    _dat(goc, "/HSoKhaiThue/TTinChung/TTinDVu/tenDVu", "HỖ TRỢ KÊ KHAI THUẾ")
    _dat(goc, "/HSoKhaiThue/TTinChung/TTinDVu/pbanDVu", pban_dvu or "5.7.6")
    _dat(goc, "/HSoKhaiThue/TTinChung/TTinDVu/ttinNhaCCapDVu", TTIN_NHA_CCAP)
    _dat(goc, t + "/maTKhai", km["maTKhai"])
    _dat(goc, t + "/tenTKhai", km["tenTKhai"])
    _dat(goc, t + "/moTaBMau", km["moTaBMau"])
    _dat(goc, t + "/pbanTKhaiXML", km["pbanTKhaiXML"])
    _dat(goc, t + "/maCQTNoiNop", hd.get("maCQTNoiNop") or dau.get("maCQTNoiNop") or tt.get("maCQTNoiNop") or "")
    _dat(goc, t + "/tenCQTNoiNop", hd.get("tenCQTNoiNop") or dau.get("tenCQTNoiNop") or tt.get("tenCQTNoiNop") or "")
    gh = _tim_nut(goc, t + "/GiaHan")
    if gh is not None:
        for c in list(gh):
            c.text = ""
    _dat(goc, t + "/nguoiKy", dau.get("nguoiKy") or tt.get("nguoiKy") or hd.get("nguoiKy") or dau.get("nguoiKyDuPhong") or "")
    _dat(goc, t + "/nganhNgheKD", hd.get("nganhNgheKD") or tt.get("nganhNgheKD") or "")
    _dien_ky(goc, dau)
    mst = _mst_so(dau.get("mst") or hd.get("mst"))
    _dat(goc, n + "/mst", mst)
    _dat(goc, n + "/tenNNT", dau.get("tenNNT") or hd.get("tenNNT") or "")
    # quan / huyen de trong nhu file HTKK ket xuat that (bo cap huyen tu 07/2025; HEADER.xml con ma cu)
    for the, k in (("dchiNNT", "dchiNNT"), ("phuongXa", "tenXaPhuongNNT"), ("maTinhNNT", "maTinhNNT"),
                   ("tenTinhNNT", "tenTinhNNT"), ("dthoaiNNT", "dthoaiNNT"), ("faxNNT", "faxNNT"), ("emailNNT", "emailNNT")):
        _dat(goc, n + "/" + the, dau.get(the) or hd.get(k) or tt.get(the) or "")
    _dat(goc, n + "/maHuyenNNT", "")
    _dat(goc, n + "/tenHuyenNNT", "")
    # dai ly thue: chi giu khi HTKK co khai dai ly (mstDLyThue kieu TIN bat buoc) - khong thi bo khoi
    ttk = _tim_nut(goc, "/HSoKhaiThue/TTinChung/TTinTKhaiThue")
    dl = _con(ttk, "DLyThue") if ttk is not None else None
    if dl is not None:
        mdl = _mst_so(hd.get("mstDLyThue"))
        if str(hd.get("ThongTinDaiLy")).lower() == "true" and re.fullmatch(r"\d{10}(-\d{3})?|\d{12}", mdl or ""):
            for c in dl.iter():
                if not list(c):
                    c.text = hd.get(_ten(c)) or ""
            _dat(goc, "/HSoKhaiThue/TTinChung/TTinTKhaiThue/DLyThue/mstDLyThue", mdl)
            _dat(goc, "/HSoKhaiThue/TTinChung/TTinTKhaiThue/DLyThue/ngayKyHDDLyThue",
                 _ngay_iso(hd.get("ngayKyHDDLyThue"), ""))
        elif not hd and (tt.get("dly") or {}).get("mstDLyThue"):          # GD162: khong co HEADER HTKK -> dai ly theo to khai ky truoc
            d0 = tt["dly"]
            for c in dl.iter():
                if not list(c):
                    c.text = d0.get(_ten(c)) or ""
            _dat(goc, "/HSoKhaiThue/TTinChung/TTinTKhaiThue/DLyThue/mstDLyThue", _mst_so(d0.get("mstDLyThue")))
            _dat(goc, "/HSoKhaiThue/TTinChung/TTinTKhaiThue/DLyThue/ngayKyHDDLyThue", _ngay_iso(d0.get("ngayKyHDDLyThue"), ""))
        else:
            ttk.remove(dl)
    # chi tieu to khai
    c0 = "/HSoKhaiThue/CTieuTKhaiChinh"
    ma_ng = dau.get("ma_NganhNghe") or tt.get("ma_NganhNghe") or NGANH_NGHE_MAC_DINH[0]          # GD162: theo to khai ky truoc
    ten_ng = (dau.get("ten_NganhNghe") or (tt.get("ten_NganhNghe") if ma_ng == tt.get("ma_NganhNghe") else "")
              or (NGANH_NGHE_MAC_DINH[1] if ma_ng == NGANH_NGHE_MAC_DINH[0] else ""))
    tmuc = tt.get("tieuMucHachToan") if tt.get("tieuMucHachToan") in TIEU_MUC_HOP_LE else ""
    _dat(goc, c0 + "/ma_NganhNghe", ma_ng)
    _dat(goc, c0 + "/ten_NganhNghe", ten_ng)
    _dat(goc, c0 + "/tieuMucHachToan", dau.get("tieuMucHachToan") or tmuc or TIEU_MUC_MAC_DINH)
    ct = {}
    for k, v in (du_lieu.get("chi_tieu") or {}).items():
        k = str(k)
        if "/" in k:
            continue
        ct[k.lower()[2:] if k.lower().startswith("ct") else k.lower()] = v
    ctn = _tim_nut(goc, c0)
    for duong, nut in _duyet(ctn):
        if list(nut) or duong.startswith("/Header"):
            continue
        m = _RE_CT.match(_ten(nut))
        if not m:
            continue
        so = m.group(1).lower()
        v = ct.get(so, 0)
        if so == "21":
            nut.text = "1" if _so(v) else "0"
        elif so == "22":
            nut.text = str(max(0, _tron(_so(v))))
        else:
            nut.text = _so_nguyen(v)
    # phu luc
    plc = _tim_nut(goc, "/HSoKhaiThue/PLuc")
    if plc is not None:
        for c in list(plc):
            plc.remove(c)
        plc.text = None
        co_pl = pl and pl.get("ban_ra")          # GD324: chi lap PL khi CO ban ra 8% (chi mua vao 8% -> khong lap)
        if co_pl and (km.get("pl142") or {}).get("khung"):
            plc.append(_lap_pl142(km["pl142"]["khung"], pl))
    return goc


def ghi_xml_htkk(goc, duong_ra):
    """Ghi dung kieu HTKK: UTF-8 co BOM, khai bao nhay kep, co xmlns:xsi, thut dong."""
    try:
        ET.register_namespace("", NS_TKHAI)
    except Exception:
        pass
    co_xsi = any(str(k).startswith("{%s}" % NS_XSI) for n in goc.iter() for k in n.attrib)
    if co_xsi:
        ET.register_namespace("xsi", NS_XSI)
    elif goc.get("xmlns:xsi") is None:
        goc.set("xmlns:xsi", NS_XSI)
    try:
        ET.indent(goc, space="  ")
    except Exception:
        pass
    txt = ET.tostring(goc, encoding="unicode")
    tam = duong_ra + ".tmp"
    with open(tam, "w", encoding="utf-8-sig", newline="\r\n") as f:
        f.write('<?xml version="1.0" encoding="UTF-8"?>\n' + txt + "\n")
    os.replace(tam, duong_ra)


# ---------------------------------------------------------------------------
#  KIEM FILE TRUOC KHI GIAO
# ---------------------------------------------------------------------------
def kiem_noi_bo(duong_xml, khung=None):
    """Kiem cac loi da lam HTKK tu choi (khong can lxml). -> [loi]."""
    loi = []
    try:
        goc = ET.parse(duong_xml).getroot()
    except Exception as e:
        return ["Không đọc được XML: %s" % e]
    if goc.tag != "{%s}HSoThueDTu" % NS_TKHAI:
        loi.append("thẻ gốc / vùng tên sai: %s" % goc.tag)
    g = lambda p: ((_tim_nut(goc, p).text or "").strip() if _tim_nut(goc, p) is not None else None)
    t = "/HSoKhaiThue/TTinChung/TTinTKhaiThue/TKhaiThue"
    if not re.fullmatch(r"\d+", g(t + "/maTKhai") or "") or g(t + "/maTKhai") == "0":
        loi.append("maTKhai = '%s' (phải là mã tờ khai của HTKK, ví dụ 842)" % g(t + "/maTKhai"))
    if not re.fullmatch(r"\d+\.\d+\.\d+", g(t + "/pbanTKhaiXML") or ""):
        loi.append("pbanTKhaiXML = '%s' (phải là phiên bản HTKK, ví dụ 2.8.3)" % g(t + "/pbanTKhaiXML"))
    if g(t + "/KyKKhaiThue/kieuKy") not in ("Q", "M"):
        loi.append("kieuKy = '%s'" % g(t + "/KyKKhaiThue/kieuKy"))
    if not re.fullmatch(r"\d{1,2}/\d{4}", g(t + "/KyKKhaiThue/kyKKhai") or ""):
        loi.append("kyKKhai = '%s'" % g(t + "/KyKKhaiThue/kyKKhai"))
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", g(t + "/ngayKy") or ""):
        loi.append("ngayKy = '%s' (phải yyyy-mm-dd)" % g(t + "/ngayKy"))
    if not re.fullmatch(r"(\d{10}(-\d{3})?)|(\d{12})", g("/HSoKhaiThue/TTinChung/TTinTKhaiThue/NNT/mst") or ""):
        loi.append("mst = '%s' sai dạng" % g("/HSoKhaiThue/TTinChung/TTinTKhaiThue/NNT/mst"))
    tm = g("/HSoKhaiThue/CTieuTKhaiChinh/tieuMucHachToan")
    if tm is not None and tm not in TIEU_MUC_HOP_LE:
        loi.append("tieuMucHachToan = '%s' (HTKK chỉ nhận %s)" % (tm, "|".join(TIEU_MUC_HOP_LE)))
    ctn = _tim_nut(goc, "/HSoKhaiThue/CTieuTKhaiChinh")
    if ctn is not None:
        for duong, nut in _duyet(ctn):
            if list(nut) or duong.startswith("/Header") or not _RE_CT.match(_ten(nut)):
                continue
            if not re.fullmatch(r"-?\d+", (nut.text or "").strip()):
                loi.append("%s = '%s' (phải là số nguyên)" % (_ten(nut), nut.text))
    for nut in goc.iter():
        ids = [c.get("ID") for c in list(nut) if c.get("ID") is not None]
        if len(ids) != len(set(ids)):
            loi.append("ID dòng bảng kê bị trùng trong <%s>" % _ten(nut))
        if _ten(nut) in ("giaTriHHDVMuaVao", "thueGTGTHHDV", "giaTriHHDV", "thueGTGTDuocGiam", "thueSuatTheoQuyDinh", "ct9") \
                or _ten(nut).startswith("tongCong"):
            if not re.fullmatch(r"-?\d+", (nut.text or "").strip()):
                loi.append("%s = '%s' (phải là số nguyên)" % (_ten(nut), nut.text))
    if khung and os.path.isfile(khung):
        try:
            kg = _khung_ns(khung)
            a = [_ten(c) for c in list(_tim_nut(kg, "/HSoKhaiThue/CTieuTKhaiChinh"))]
            b = [_ten(c) for c in list(ctn)] if ctn is not None else []
            if a != b:
                loi.append("thứ tự thẻ chỉ tiêu khác khung HTKK")
        except Exception:
            pass
    return loi


def kiem_xsd_htkk(duong_xml, ma_file, goc=""):
    """GD328: kiem tep XML to khai theo XSD cua CHINH HTKK cai tren may (Menu.xml: MaFile -> XsdSchema + VersionXML lon nhat).
       -> (cach, [loi]); cach '' = khong co HTKK / XSD / lxml (khong kiem duoc, khong coi la loi)."""
    try:
        if not goc:
            h = tim_htkk()
            goc = (h or {}).get("goc") or ""
        if not goc:
            return "", []
        muc, pb = None, ()
        for m in ET.parse(os.path.join(goc, "Project", "Menu.xml")).getroot().iter():
            if _ten(m) == "Menu" and m.get("MaFile") == ma_file:
                v = tuple(int(x) for x in re.findall(r"\d+", m.get("VersionXML") or "0"))
                if muc is None or v > pb:
                    muc, pb = m, v
        if muc is None:
            return "", []
        so = re.sub(r"\D", "", muc.get("VersionXML") or "")
        xsd = os.path.join(goc, "InterfaceTemplates", "Validate", "%s_%s.xsd" % (muc.get("XsdSchema") or ma_file, so))
        if not os.path.isfile(xsd):
            return "", []
        try:
            import lxml  # noqa: F401
        except Exception:
            return "", []
        return kiem_hop_le(duong_xml, xsd, None)
    except Exception as e:
        ghi_log("[KIEM] kiem_xsd_htkk %s: %s" % (ma_file, e))
        return "", []


def kiem_hop_le(duong_xml, xsd="", khung=None):
    """-> (cach, [loi]). Co lxml + XSD cua HTKK -> kiem day du ('xsd'); khong thi kiem noi bo ('noi_bo')."""
    if xsd and os.path.isfile(xsd):
        try:
            from lxml import etree as _lx
        except Exception:
            _lx = None
        if _lx is not None:
            try:
                # GD328: XSD HTKK co ten the thua khoang trang ('PL_CDTK ', 'ct156 ') va include '..\\' kieu Windows -> sua trong bo nho
                _s = io.open(xsd, encoding="utf-8-sig", errors="ignore").read()
                _s = re.sub(r'name="([^"]*?)\s+"', r'name="\1"', _s)
                if os.sep == "/":
                    _s = _s.replace("..\\", "../")
                sch = _lx.XMLSchema(_lx.fromstring(_s.encode("utf-8"), base_url=xsd))
                if sch.validate(_lx.parse(duong_xml)):
                    return "xsd", []
                return "xsd", ["dòng %d: %s" % (e.line, e.message) for e in list(sch.error_log)[:15]]
            except Exception as e:
                ghi_log("[KIEM] Khong dung duoc XSD %s: %s - kiem noi bo" % (xsd, e))
    return "noi_bo", kiem_noi_bo(duong_xml, khung)


# ---------------------------------------------------------------------------
#  KET XUAT 01/GTGT (GD56): khuon HTKK tren may -> khuon da hoc -> bao loi
# ---------------------------------------------------------------------------
def _bao_cao_xuat(duong_ra, nguon, pl, cach, loi, h):
    d = ["KẾT XUẤT TỜ KHAI 01/GTGT CHO HTKK - %s" % datetime.now().strftime("%d/%m/%Y %H:%M"),
         "Tệp XML : %s" % duong_ra,
         "Khuôn   : %s" % nguon]
    if h:
        d.append("HTKK    : %s (phiên bản %s)" % (h.get("goc"), h.get("phien_ban") or "?"))
    if pl and not pl.get("ban_ra") and pl.get("mua_vao"):          # GD324
        tg = pl["tong"]
        d += ["", "PHỤ LỤC 142/174/204: KHÔNG LẬP - kỳ này không có hóa đơn BÁN RA thuế suất 8%.",
              "  (Chỉ có mua vào 8%%: %d dòng, giá trị %s, thuế %s - vẫn khấu trừ bình thường ở [23]/[24] tờ khai.)"
              % (len(pl["mua_vao"]), _dinh_dang(tg["tongCongGiaTriHHDVMuaVao"]), _dinh_dang(tg["tongCongThueGTGTHHDV"])),
              "  Phụ lục giảm thuế chỉ lập khi có hàng hóa, dịch vụ bán ra được giảm thuế. Nếu doanh nghiệp CÓ bán ra 8%",
              "  mà sổ đang ghi 10%: sửa thuế suất hóa đơn bán ra trên sổ rồi xuất lại.",
              "  Khi nhập HTKK: KHÔNG tích phụ lục \"PL 142/2024/QH15-174/2024/QH15-204/2025/QH15\"."]
    if pl and pl.get("ban_ra"):
        tg, tk = pl["tong"], pl.get("thong_ke") or {}
        d += ["", "PHỤ LỤC 142/174/204 (giảm thuế GTGT 8%):",
              "  I  Mua vào 8%%: %d dòng, giá trị %s, thuế [06] %s" % (len(pl["mua_vao"]), _dinh_dang(tg["tongCongGiaTriHHDVMuaVao"]),
                                                               _dinh_dang(tg["tongCongThueGTGTHHDV"])),
              "  II Bán ra 8%%: %d dòng, giá trị %s, thuế được giảm [08] %s" % (len(pl["ban_ra"]), _dinh_dang(tg["tongCongGiaTriHHDV"]),
                                                                        _dinh_dang(tg["tongCongThueGTGTDuocGiam"])),
              "  III [09] = [08] - [06] = %s" % _dinh_dang(pl["ct9"])]
        if tk:
            d.append("  Hóa đơn bán ra: %d (tên hàng từ HĐĐT: %d, theo sổ sách: %d)"
                     % (tk.get("hd_ban", 0), tk.get("hd_ban_hddt", 0), tk.get("hd_ban", 0) - tk.get("hd_ban_hddt", 0)))
            d.append("  Hóa đơn mua vào: %d (tên hàng từ HĐĐT: %d, theo sổ sách: %d)"
                     % (tk.get("hd_mua", 0), tk.get("hd_mua_hddt", 0), tk.get("hd_mua", 0) - tk.get("hd_mua_hddt", 0)))
            if tk.get("uoc_thue_mua"):
                d.append("  ! %d dòng mua vào không có số thuế trên sổ/HĐĐT - đã tạm tính 8%%, anh xem lại." % tk["uoc_thue_mua"])
    d += ["", "KIỂM TRA TRƯỚC KHI GIAO: %s" % ("theo lược đồ XSD của chính HTKK" if cach == "xsd" else "kiểm nội bộ (máy chưa có lxml)")]
    d += ["  - " + x for x in loi] if loi else ["  ĐẠT"]
    d += ["", "CÁCH NHẬP: HTKK -> Tờ khai 01/GTGT (TT80/2021) -> chọn đúng kỳ, " + ("tích phụ lục" if (pl and pl.get("ban_ra")) else "KHÔNG tích phụ lục"),
          "  \"PL 142/2024/QH15-174/2024/QH15-204/2025/QH15\" -> Đồng ý -> nút \"Nhập từ XML\" -> chọn tệp trên",
          "  -> kiểm tra lại -> Ghi. Phần mềm KHÔNG ký, KHÔNG nộp thay."]
    return "\n".join(d)


# ---------------------------------------------------------------------------
#  GD162 - THONG TIN CHUNG KY TRUOC CHO 01/GTGT + DANH SACH TO KHAI DA NOP
# ---------------------------------------------------------------------------
TEN_TTC = (("nguoiKy", "người ký"), ("maCQTNoiNop", "cơ quan thuế nơi nộp"), ("dchiNNT", "địa chỉ"), ("dthoaiNNT", "điện thoại"),
           ("emailNNT", "email"), ("ma_NganhNghe", "ngành nghề"), ("tieuMucHachToan", "tiểu mục"), ("dly", "đại lý thuế"))


def ttc_ky_truoc_xuat(dl, h):
    """Thong tin chung (nguoi ky, CQT, dia chi, nganh nghe, tieu muc, dai ly) cua to khai 01/GTGT gan nhat TRUOC ky dang xuat
       -> (ttc, nguon). Chi khi VB gui thu_muc_khach (Xuat 01/GTGT tu GD162); loi -> ({}, '')."""
    tm = str(dl.get("thu_muc_khach") or "")
    dau = dl.get("dau") or {}
    if not tm:
        return {}, ""
    try:
        import tk_luu_tru as TL
        a = datetime.strptime(str(dau.get("kyKKhaiTuNgay") or "")[:10], "%d/%m/%Y")
        b = datetime.strptime(str(dau.get("kyKKhaiDenNgay") or "")[:10], "%d/%m/%Y")
        return TL.ttc_ky_truoc(a, b, dau.get("mst") or "", tm, (h or {}).get("goc", ""))
    except Exception as e:
        ghi_log("[XUAT] Khong lay duoc thong tin chung ky truoc: %s" % e)
        return {}, ""


def _bu_ttc(goc, ttc):
    """Mau da hoc (khong co HTKK): thong tin chung theo to khai ky truoc (moi hon file mau). -> so o da dien."""
    t = "/HSoKhaiThue/TTinChung/TTinTKhaiThue/TKhaiThue"
    n = "/HSoKhaiThue/TTinChung/TTinTKhaiThue/NNT"
    c0 = "/HSoKhaiThue/CTieuTKhaiChinh"
    duong = {"maCQTNoiNop": t + "/maCQTNoiNop", "tenCQTNoiNop": t + "/tenCQTNoiNop", "nguoiKy": t + "/nguoiKy",
             "nganhNgheKD": t + "/nganhNgheKD", "dchiNNT": n + "/dchiNNT", "phuongXa": n + "/phuongXa", "maTinhNNT": n + "/maTinhNNT",
             "tenTinhNNT": n + "/tenTinhNNT", "dthoaiNNT": n + "/dthoaiNNT", "faxNNT": n + "/faxNNT", "emailNNT": n + "/emailNNT",
             "ma_NganhNghe": c0 + "/ma_NganhNghe", "ten_NganhNghe": c0 + "/ten_NganhNghe", "tieuMucHachToan": c0 + "/tieuMucHachToan"}
    so = 0
    for k, p in duong.items():
        v = (ttc or {}).get(k)
        if not v or (k == "tieuMucHachToan" and v not in TIEU_MUC_HOP_LE):
            continue
        nut = _tim_nut(goc, p)
        if nut is not None:
            nut.text = str(v)
            so += 1
    return so


def thieu_bat_buoc(duong_xml):
    """O thong tin chung HTKK can ma tep XML de trong -> [ten]."""
    try:
        goc = ET.parse(duong_xml).getroot()
    except Exception:
        return []
    t = "/HSoKhaiThue/TTinChung/TTinTKhaiThue/TKhaiThue"
    ra = []
    for p, ten in ((t + "/nguoiKy", "người ký"), (t + "/maCQTNoiNop", "cơ quan thuế nơi nộp")):
        nut = _tim_nut(goc, p)
        if nut is not None and not (nut.text or "").strip():
            ra.append(ten)
    return ra


def xem_to_khai_ky_truoc(tm, mst, h):
    """Danh sach to khai 01/GTGT phan mem tim thay (moi ky to khai co hieu luc) -> <thu muc khach>\\ket-qua\\TO_KHAI_KY_TRUOC.txt."""
    import tk_luu_tru as TL
    ds, n = TL.quet(mst, tm, (h or {}).get("goc", ""), True, TL.them_nguon(tm))
    tot = TL.hieu_luc(ds)
    d = ["TỜ KHAI 01/GTGT ĐÃ NỘP PHẦN MỀM TÌM THẤY - MST %s" % mst,
         "Lập lúc %s; đã đọc %d tệp; %d kỳ có tờ khai." % (datetime.now().strftime("%d/%m/%Y %H:%M"), n, len(tot)),
         "Nguồn: HTKK trên máy (DataFiles), tờ khai lưu trữ, thẻ Hồ sơ thuế, thư mục tờ khai đã chọn, thư mục Tải về.",
         "Xuất 01/GTGT lấy [22] = [43] của kỳ liền trước trong danh sách này (bản bổ sung mới nhất thay bản chính thức).", ""]
    for k in sorted(tot, key=TL._cuoi, reverse=True):
        x = tot[k]
        ct = x["ct"]
        d.append("%s%s: [22] %s  [34] %s  [35] %s  [40] %s  [43] %s" % (
            TL.ten_ky(k), " (bổ sung lần %d)" % x["lan"] if x["lan"] else "", TL._dd(ct.get("22")), TL._dd(ct.get("34")),
            TL._dd(ct.get("35")), TL._dd(ct.get("40")), TL._dd(ct.get("43"))))
        d.append("    nguồn: %s" % x["nguon"])
    if not tot:
        d.append("Chưa tìm thấy tờ khai nào. Chọn thư mục chứa tờ khai đã nộp hoặc nhập từng tờ khai (XML kết xuất từ HTKK, "
                 "XML / ZIP tải từ Cổng thuế) ở Hệ thống - Nguồn HTKK, tờ khai và BCTC kỳ trước.")
    ttc, ng = TL.ttc_tu_ds(ds, None)
    d += ["", "THÔNG TIN CHUNG THEO TỜ KHAI MỚI NHẤT: %s" % (ng or "chưa có")]
    for k, ten in TEN_TTC:
        d.append("  %s: %s" % (ten, "có" if ttc.get(k) else "chưa có"))
    p = os.path.join(tm, "ket-qua", "TO_KHAI_KY_TRUOC.txt")
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8-sig", newline="\r\n") as f:
        f.write("\n".join(d) + "\n")
    return p


def don_json_tam(giu_ngay=2):
    """GD162: xoa tep so lieu tam htkk_solieu_*.json cu hon giu_ngay ngay trong thu muc tool (co ten nguoi ky, thu muc khach)."""
    import glob
    import time as _t
    n = 0
    for p in glob.glob(os.path.join(BASE_DIR, "htkk_solieu_*.json")):
        try:
            if _t.time() - os.path.getmtime(p) > giu_ngay * 86400:
                os.remove(p)
                n += 1
        except OSError:
            pass
    return n


def xuat_01gtgt(du_lieu, duong_ra, goi_y_htkk="", bo_qua_tu_kiem=False):
    """-> (duong_ra, "", bao_cao) hoac (None, loi, bao_cao)."""
    dl, ct, pl = _chuan_bi_01gtgt(du_lieu)          # GD59: dung chung voi /xemtruoc
    if not bo_qua_tu_kiem:
        ngan = {k.lower()[2:] if k.lower().startswith("ct") else k.lower(): v for k, v in ct.items() if "/" not in k}
        chan, canh = tu_kiem_01gtgt(ngan)
        for c in canh:
            ghi_log("[CANH BAO] " + c)
        if chan:
            return None, ("Số liệu chưa cân đối nên KHÔNG kết xuất (tránh nộp tờ khai sai):\n- " + "\n- ".join(chan)), ""
    try:
        os.makedirs(os.path.dirname(os.path.abspath(duong_ra)), exist_ok=True)
    except Exception:
        pass
    h = tim_htkk(goi_y_htkk)
    ttc, nguon_ttc = ttc_ky_truoc_xuat(dl, h)          # GD162: nguoi ky, CQT, nganh nghe, tieu muc... theo to khai ky truoc
    km, loi_km, ghi_chu_mau = (_khuon_01gtgt(h["goc"], dl.get("dau")) if h else (None, "", ""))
    if ghi_chu_mau:
        ghi_log("[XUAT] " + _bo_dau(ghi_chu_mau))
    if km:
        goc = lap_xml_may(km, dl, dau_may(h["goc"], (dl.get("dau") or {}).get("mst")), h.get("phien_ban"), pl, ttc=ttc)
        tam = duong_ra + ".kiem.xml"
        ghi_xml_htkk(goc, tam)
        cach, loi = kiem_hop_le(tam, km.get("xsd"), km.get("khung"))
        nguon = "HTKK trên máy (%s, mã %s, phiên bản %s)" % (os.path.basename(km["khung"]), km["maTKhai"], km["pbanTKhaiXML"])
    else:
        if loi_km:
            ghi_log("[XUAT] " + loi_km)
        tam = duong_ra + ".kiem.xml"
        d, l = xuat_xml("01/GTGT", dl, tam, bo_qua_tu_kiem=True, ttc=ttc)
        if d is None:
            if not h:
                l += ("\n\nMáy này chưa tìm thấy HTKK. Nếu HTKK cài ở chỗ khác, vào Hệ thống > Nguồn HTKK, tờ khai và BCTC kỳ trước... > Chỉ đường HTKK, chọn "
                      "HTKK.exe trong thư mục cài HTKK (ví dụ F:\\HTKK\\Project\\HTKK.exe).")
            return None, l, ""
        khuon = doc_khuon("01/GTGT") or {}
        cach, loi = kiem_hop_le(tam, "", None)
        nguon = "file mẫu đã học (%s)" % (khuon.get("tep_mau") or "?")
    bao = _bao_cao_xuat(duong_ra, nguon, pl, cach, loi, h)
    if nguon_ttc:                                       # GD162
        bao += ("\n\nTHÔNG TIN CHUNG KỲ TRƯỚC: %s (có: %s). Người ký, ngành nghề, tiểu mục theo tờ khai kỳ trước; "
                "cơ quan thuế, địa chỉ, đại lý thuế theo HTKK trên máy khi có." % (
            nguon_ttc, ", ".join(ten for k, ten in TEN_TTC if ttc.get(k)) or "-"))
    thieu = thieu_bat_buoc(tam)
    if thieu:
        bao += "\n\nCÒN THIẾU (HTKK yêu cầu): %s - nhập trên HTKK trước khi Ghi." % ", ".join(thieu)
    if ghi_chu_mau:
        bao += "\n\nLƯU Ý MẪU: " + ghi_chu_mau
    if loi:
        hong = re.sub(r"\.xml$", "", duong_ra, flags=re.I) + "_LOI.xml"
        try:
            os.replace(tam, hong)
        except Exception:
            hong = tam
        ghi_log("[XUAT] File KHONG hop le (%d loi) - giu lai %s" % (len(loi), hong))
        return None, ("Tệp XML chưa hợp lệ với HTKK nên KHÔNG giao (HTKK sẽ báo \"Cấu trúc tờ khai xml nhập vào không hợp lệ\"):\n- "
                      + "\n- ".join(loi[:8]) + "\nTệp lỗi để đối chiếu: " + hong), bao
    os.replace(tam, duong_ra)
    ghi_log("[XUAT] 01/GTGT -> %s (%s, kiem %s dat)" % (duong_ra, nguon, cach))
    # GD59: ban Excel cung ten de luu ho so / in (khong anh huong XML da giao)
    xlsx, l = lap_excel_01gtgt(dl, ct, pl, re.sub(r"\.xml$", ".xlsx", duong_ra, flags=re.I), xem_truoc=False)
    bao = bao.replace("Khuôn   : ", ("Excel   : %s\n" % (xlsx if xlsx else "(không lập được: " + l + ")")) + "Khuôn   : ", 1)
    return duong_ra, "", bao


# ---------------------------------------------------------------------------
#  GD59 - XEM TRUOC / BAN IN EXCEL cua to khai 01/GTGT (anh Thang 24/09: "xem truoc bang report hoac Excel")
#    Tep .xlsx 4 sheet: "01-GTGT" (to khai dung dang mau TT80, tung chi tieu co ma), "PL 142-174-204" (I mua vao,
#    II ban ra, III [09]), "Doi chieu" (so ke toan - Cong HDDT, neu VB gui kem), "HD 8% so sach" (hoa don 8% cua ky).
#    Tu viet xlsx (zip + XML), KHONG can openpyxl. /xemtruoc: chi lap Excel (khong can HTKK, khong chan tu kiem -
#    loi tu kiem ghi vao sheet). /xuat: sau khi giao XML cung lap tep Excel cung ten (.xlsx) de luu ho so.
# ---------------------------------------------------------------------------
import zipfile as _zipfile

# (stt, ten chi tieu, ma hien thi, ma gia tri, ma thue) ; ma gia tri / ma thue = None -> o trong ; "*" = dong muc
_DONG_01GTGT = [
    ("A", "Không phát sinh hoạt động mua, bán trong kỳ (đánh dấu \"X\")", "[21]", "21x", None),
    ("B", "Thuế GTGT còn được khấu trừ kỳ trước chuyển sang", "[22]", None, "22"),
    ("C", "Kê khai thuế GTGT phải nộp Ngân sách nhà nước", "", "*", None),
    ("I", "Hàng hoá, dịch vụ (HHDV) mua vào trong kỳ", "", "*", None),
    ("1", "Giá trị và thuế GTGT của HHDV mua vào", "[23] / [24]", "23", "24"),
    ("a", "Giá trị và thuế GTGT của hàng hoá nhập khẩu", "[23a] / [24a]", "23a", "24a"),
    ("2", "Thuế GTGT của HHDV mua vào được khấu trừ kỳ này", "[25]", None, "25"),
    ("II", "HHDV bán ra trong kỳ", "", "*", None),
    ("1", "HHDV bán ra không chịu thuế GTGT", "[26]", "26", None),
    ("2", "HHDV bán ra chịu thuế GTGT ([27] = [29] + [30] + [32] + [32a]; [28] = [31] + [33])", "[27] / [28]", "27", "28"),
    ("a", "HHDV bán ra chịu thuế suất 0%", "[29]", "29", None),
    ("b", "HHDV bán ra chịu thuế suất 5%", "[30] / [31]", "30", "31"),
    ("c", "HHDV bán ra chịu thuế suất 10% (gồm hàng 8% - phần giảm 2% khai ở phụ lục)", "[32] / [33]", "32", "33"),
    ("d", "HHDV bán ra không tính thuế", "[32a]", "32a", None),
    ("3", "Tổng doanh thu và thuế GTGT của HHDV bán ra ([34] = [26] + [27]; [35] = [28])", "[34] / [35]", "34", "35"),
    ("III", "Thuế GTGT phát sinh trong kỳ ([36] = [35] - [25])", "[36]", None, "36"),
    ("IV", "Điều chỉnh tăng, giảm thuế GTGT còn được khấu trừ của các kỳ trước", "", "*", None),
    ("1", "Điều chỉnh giảm", "[37]", None, "37"),
    ("2", "Điều chỉnh tăng", "[38]", None, "38"),
    ("V", "Thuế GTGT nhận bàn giao được khấu trừ trong kỳ", "[39a]", None, "39a"),
    ("VI", "Xác định nghĩa vụ thuế GTGT phải nộp trong kỳ", "", "*", None),
    ("1", "Thuế GTGT phải nộp của hoạt động SXKD trong kỳ ([40a] = [36] - [22] + [37] - [38] - [39a] >= 0)", "[40a]", None, "40a"),
    ("2", "Thuế GTGT mua vào của dự án đầu tư được bù trừ với thuế GTGT còn phải nộp của hoạt động SXKD cùng kỳ", "[40b]", None, "40b"),
    ("3", "Thuế GTGT còn phải nộp trong kỳ ([40] = [40a] - [40b])", "[40]", None, "40"),
    ("4", "Thuế GTGT chưa khấu trừ hết kỳ này (nếu [36] - [22] + [37] - [38] - [39a] < 0)", "[41]", None, "41"),
    ("5", "Tổng số thuế GTGT đề nghị hoàn ([42] <= [41])", "[42]", None, "42"),
    ("6", "Thuế GTGT còn được khấu trừ chuyển kỳ sau ([43] = [41] - [42])", "[43]", None, "43"),
]


def _dong_01gtgt(tt89):
    """GD65: ky tu 07/2026 (TT89/2026) them [32b], [34a] va cong thuc [27], [34] moi; ky truoc giu nguyen mau TT80."""
    if not tt89:
        return _DONG_01GTGT
    ra = []
    for d in _DONG_01GTGT:
        if d[3] == "27":
            d = (d[0], "HHDV bán ra chịu thuế GTGT ([27] = [29] + [30] + [32] + [32a] - [32b]; [28] = [31] + [33])", d[2], d[3], d[4])
        if d[3] == "34":
            ra.append(("e", "HHDV bán ra không tính vào giá tính thuế GTGT (TT89/2026)", "[32b]", "32b", None))
            ra.append(("3", "HHDV bán ra không thuộc phạm vi điều chỉnh của pháp luật thuế GTGT (TT89/2026)", "[34a]", "34a", None))
            d = ("4", "Tổng doanh thu và thuế GTGT của HHDV bán ra ([34] = [26] + [27] + [34a]; [35] = [28])", d[2], d[3], d[4])
        ra.append(d)
    return ra

_XLSX_STYLES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<numFmts count="1"><numFmt numFmtId="164" formatCode="#,##0;-#,##0;0"/></numFmts>
<fonts count="5">
<font><sz val="11"/><name val="Calibri"/></font>
<font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>
<font><b/><sz val="11"/><name val="Calibri"/></font>
<font><b/><sz val="14"/><color rgb="FF1E5A3A"/><name val="Calibri"/></font>
<font><i/><sz val="10"/><color rgb="FF7F7F7F"/><name val="Calibri"/></font>
</fonts>
<fills count="7">
<fill><patternFill patternType="none"/></fill>
<fill><patternFill patternType="gray125"/></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FF1E9E5A"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFEAF3EC"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFF4C7C3"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFFFF2CC"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFD9EAD3"/><bgColor indexed="64"/></patternFill></fill>
</fills>
<borders count="2">
<border><left/><right/><top/><bottom/><diagonal/></border>
<border><left style="thin"><color rgb="FFBFBFBF"/></left><right style="thin"><color rgb="FFBFBFBF"/></right><top style="thin"><color rgb="FFBFBFBF"/></top><bottom style="thin"><color rgb="FFBFBFBF"/></bottom><diagonal/></border>
</borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="12">
<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf>
<xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="top"/></xf>
<xf numFmtId="0" fontId="2" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf>
<xf numFmtId="164" fontId="2" fillId="3" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="top"/></xf>
<xf numFmtId="0" fontId="3" fillId="0" borderId="0" xfId="0" applyFont="1"/>
<xf numFmtId="0" fontId="4" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment wrapText="1"/></xf>
<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1"/>
<xf numFmtId="0" fontId="2" fillId="4" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="top"/></xf>
<xf numFmtId="0" fontId="2" fillId="5" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="top"/></xf>
<xf numFmtId="0" fontId="2" fillId="6" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="top"/></xf>
</cellXfs>
<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>"""
# kieu o: 0 thuong, 1 tieu de bang, 2 chu (khung), 3 so (khung), 4 chu dam nen xanh (muc), 5 so dam nen xanh,
#         6 tieu de lon, 7 ghi chu nghieng, 8 chu dam khong khung
X_THUONG, X_TIEUDE, X_CHU, X_SO, X_MUC, X_SOMUC, X_TITLE, X_GHICHU, X_DAM = range(9)
X_DO, X_VANG, X_XANH = 9, 10, 11          # GD66: o ket qua kiem tra truoc khoa so (nen do / vang / xanh)


def _xml_thoat(s):
    return (str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;"))


def _cot_chu(n):
    s = ""
    while n > 0:
        n, du = divmod(n - 1, 26)
        s = chr(65 + du) + s
    return s


def _o_xlsx(c, r, gt, kieu):
    vt = "%s%d" % (_cot_chu(c), r)
    if gt is None or gt == "":
        return '<c r="%s" s="%d"/>' % (vt, kieu) if kieu else ""
    if isinstance(gt, (int, float)) and not isinstance(gt, bool):
        v = float(gt)
        chuoi = str(int(v)) if v == int(v) else repr(v)
        return '<c r="%s" s="%d"><v>%s</v></c>' % (vt, kieu, chuoi)
    if isinstance(gt, str) and gt.startswith("=!"):          # GD70: cong thuc Excel
        return '<c r="%s" s="%d"><f>%s</f></c>' % (vt, kieu, _xml_thoat(gt[2:]))
    t = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", " ", str(gt))
    return '<c r="%s" s="%d" t="inlineStr"><is><t xml:space="preserve">%s</t></is></c>' % (vt, kieu, _xml_thoat(t))


def viet_xlsx_o(duong, cac_sheet):
    """cac_sheet: [(ten, [do rong cot], [dong], dong_dong_bang)] ; dong = [(gia tri, kieu) | None, ...]"""
    sx = []
    try:                                         # GD139: tieu de Mau so / Ban hanh theo Thong tu cua bo so
        import tieu_de_tt as _TD
        gop_them = [list(getattr(d, "gop", None) or []) for t, w, d, b in cac_sheet]          # GD220: o gop them (tieu de nhom cot theo mau TT20)
        cac_sheet = [(t, w, _TD.sua_dong(d), b) for t, w, d, b in cac_sheet]
    except Exception:
        gop_them = [list(getattr(x[2], "gop", None) or []) for x in cac_sheet]
    for i_sh, (ten, rong, cac_dong, dong_bang) in enumerate(cac_sheet):
        cols = "".join('<col min="%d" max="%d" width="%s" customWidth="1"/>' % (i + 1, i + 1, w) for i, w in enumerate(rong))
        rows, gop = [], []
        cuoi = _cot_chu(len(rong))
        for r, dong in enumerate(cac_dong, start=1):
            o = "".join(_o_xlsx(i + 1, r, gt, kieu) for i, (gt, kieu) in enumerate(x if x else (None, 0) for x in dong))
            cao = ""
            # dong chi co MOT o chu (tieu de / ghi chu / ket luan) -> gop ngang het bang, cao theo do dai chu
            if len(dong) == 1 and dong[0] and isinstance(dong[0][0], str) and dong[0][1] in (X_TITLE, X_GHICHU, X_DAM, X_THUONG, X_MUC) and len(rong) > 1:
                gop.append("A%d:%s%d" % (r, cuoi, r))
                so_dong = len(dong[0][0]) // max(60, int(sum(rong) * 1.1)) + 1
                if so_dong > 1:
                    cao = ' ht="%d" customHeight="1"' % (15 * so_dong + 2)
            rows.append('<row r="%d"%s>%s</row>' % (r, cao, o))
        gop += gop_them[i_sh] if i_sh < len(gop_them) else []
        pane = ('<pane ySplit="%d" topLeftCell="A%d" activePane="bottomLeft" state="frozen"/>' % (dong_bang, dong_bang + 1)) if dong_bang else ""
        merge = ('<mergeCells count="%d">%s</mergeCells>' % (len(gop), "".join('<mergeCell ref="%s"/>' % g for g in gop))) if gop else ""
        sx.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<sheetPr><pageSetUpPr fitToPage="1"/></sheetPr>
<sheetViews><sheetView workbookViewId="0" showGridLines="0">%s</sheetView></sheetViews>
<cols>%s</cols>
<sheetData>%s</sheetData>
%s<pageMargins left="0.4" right="0.4" top="0.5" bottom="0.5" header="0.3" footer="0.3"/>
<pageSetup paperSize="9" orientation="landscape" fitToWidth="1" fitToHeight="0"/>
</worksheet>""" % (pane, cols, "".join(rows), merge))
    n = len(cac_sheet)
    ten_sheets = "".join('<sheet name="%s" sheetId="%d" r:id="rId%d"/>' % (_xml_thoat(b[0][:31]), i + 1, i + 1) for i, b in enumerate(cac_sheet))
    rels = "".join('<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet%d.xml"/>' % (i + 1, i + 1) for i in range(n))
    with _zipfile.ZipFile(duong, "w", _zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
%s
<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
</Types>""" % "".join('<Override PartName="/xl/worksheets/sheet%d.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' % (i + 1) for i in range(n)))
        z.writestr("_rels/.rels", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>""")
        z.writestr("xl/workbook.xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheets>%s</sheets></workbook>""" % ten_sheets)
        z.writestr("xl/_rels/workbook.xml.rels", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
%s<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>""" % (rels, n + 1))
        z.writestr("xl/styles.xml", _XLSX_STYLES)
        for i, s in enumerate(sx):
            z.writestr("xl/worksheets/sheet%d.xml" % (i + 1), s)


def _chuan_bi_01gtgt(du_lieu):
    """Phan dau cua xuat_01gtgt: chi tieu + phu luc 204 (dung chung cho /xuat va /xemtruoc)."""
    dl = dict(du_lieu)
    ct = {str(k): v for k, v in (dl.get("chi_tieu") or {}).items()}
    pl = None
    if dl.get("pl204"):
        pl = lap_pl204(dl["pl204"])
    elif dl.get("bang_ke"):
        pl = pl_tu_bang_ke_cu(dl["bang_ke"])
    if pl is not None:
        ct = {k: v for k, v in ct.items() if not k.endswith("ChenhLech/ct9")}
        if pl.get("ban_ra"):                     # GD324: khong co ban ra 8% -> khong co phu luc, khong ct9
            ct["PL_NQ142_GTGT/ChenhLech/ct9"] = pl["ct9"]
    dl["chi_tieu"] = ct
    return dl, ct, pl


def _ky_tt89(dau):
    """GD65: ky khai tu 01/07/2026 -> mau 01/GTGT theo TT89/2026."""
    m = re.match(r"^\s*(\d{1,2})/(\d{1,2})/(\d{4})", str((dau or {}).get("kyKKhaiTuNgay") or ""))
    return bool(m) and (int(m.group(3)), int(m.group(2)), int(m.group(1))) >= (2026, 7, 1)


def _khuon_01gtgt(goc, dau):
    """GD65: ky tu 07/2026 dung khuon HTKK 01_GTGT_TT89 neu HTKK da co; chua co -> TT80. -> (km, loi, ghi_chu)."""
    if _ky_tt89(dau):
        km, loi = khuon_may(goc, "01_GTGT_TT89")
        if km:
            return km, "", ""
        km, loi = khuon_may(goc, MA_FILE_01GTGT)
        return km, loi, ("Kỳ từ 07/2026 khai theo TT89/2026 nhưng HTKK trên máy chưa có mẫu 01/GTGT TT89 - kết xuất theo mẫu TT80 "
                         "(cơ quan thuế vẫn nhận mẫu TT80 đến khi thông báo áp dụng mẫu mới). [32b] / [34a] khác 0 thì khai tay trên HTKK.")
    km, loi = khuon_may(goc, MA_FILE_01GTGT)
    return km, loi, ""


def lap_excel_01gtgt(dl, ct, pl, duong, xem_truoc=True):
    """-> (duong, "") hoac (None, loi)."""
    dau = dl.get("dau") or {}
    g = lambda k: _so(ct.get(k)) if ct.get(k) not in (None, "") else None
    S = []
    mau = "Thông tư 89/2026 - HTKK nhận theo mẫu TT80 đến khi có mẫu mới" if _ky_tt89(dau) else "Thông tư 80/2021"      # GD65
    tieu = "TỜ KHAI THUẾ GIÁ TRỊ GIA TĂNG - Mẫu 01/GTGT (" + mau + ") - " + ("BẢN XEM TRƯỚC" if xem_truoc else "SỐ ĐÃ KẾT XUẤT SANG HTKK")
    S.append([(tieu, X_TITLE)])
    S.append([("Người nộp thuế: %s    MST: %s" % (dau.get("tenNNT") or "", dau.get("mst") or ""), X_DAM)])
    S.append([("Kỳ tính thuế: %s - %s    Ngày lập: %s" % (dau.get("kyKKhaiTuNgay") or "", dau.get("kyKKhaiDenNgay") or "",
                                                          datetime.now().strftime("%d/%m/%Y %H:%M")), X_THUONG)])
    S.append([("Số liệu lấy từ sổ kế toán UNESCO. Đây không phải tờ khai chính thức - tờ khai nộp là tờ khai lập trên HTKK sau khi Nhập từ XML.", X_GHICHU)])
    S.append([])
    S.append([("STT", X_TIEUDE), ("Chỉ tiêu", X_TIEUDE), ("Mã", X_TIEUDE), ("Giá trị HHDV (chưa thuế)", X_TIEUDE), ("Thuế GTGT", X_TIEUDE)])
    for stt, ten, ma, k_gt, k_thue in _dong_01gtgt(_ky_tt89(dau)):
        if k_gt == "*":
            S.append([(stt, X_MUC), (ten, X_MUC), ("", X_MUC), (None, X_MUC), (None, X_MUC)])
            continue
        if k_gt == "21x":
            v = "X" if _so(ct.get("21")) >= 1 else ""
            S.append([(stt, X_CHU), (ten, X_CHU), (ma, X_CHU), (v, X_CHU), (None, X_CHU)])
            continue
        S.append([(stt, X_CHU), (ten, X_CHU), (ma, X_CHU), (g(k_gt) if k_gt else None, X_SO), (g(k_thue) if k_thue else None, X_SO)])
    if pl and (pl.get("ban_ra") or pl.get("mua_vao")):
        S.append([("", X_CHU), ("Phụ lục PL 142/174/204 - chênh lệch thuế GTGT được giảm [09] = [08] - [06]", X_CHU), ("[09]", X_CHU), (None, X_SO), (_tron(pl["ct9"]), X_SO)])
    # tu kiem (khong chan o ban xem truoc - chi ghi ra)
    ngan = {k.lower()[2:] if k.lower().startswith("ct") else k.lower(): v for k, v in ct.items() if "/" not in k}
    chan, canh = tu_kiem_01gtgt(ngan)
    S.append([])
    S.append([("TỰ KIỂM SỐ HỌC: " + ("ĐẠT" if not chan else "CÓ %d LỖI CÂN ĐỐI - HTKK sẽ không nhận / tool không kết xuất" % len(chan)), X_DAM)])
    for x in chan:
        S.append([("!", X_THUONG), (x, X_THUONG)])
    for x in canh:
        S.append([("?", X_THUONG), (x, X_GHICHU)])
    sheets = [("01-GTGT", [6, 88, 14, 22, 18], S, 6)]

    P = [[("PHỤ LỤC GIẢM THUẾ GTGT - PL 142/2024/QH15 - 174/2024/QH15 - 204/2025/QH15 (hàng hoá, dịch vụ 8%)", X_TITLE)],
         [("Kỳ: %s - %s" % (dau.get("kyKKhaiTuNgay") or "", dau.get("kyKKhaiDenNgay") or ""), X_THUONG)], []]
    if pl and (pl.get("ban_ra") or pl.get("mua_vao")):
        tg = pl["tong"]
        P.append([("I. HÀNG HOÁ, DỊCH VỤ MUA VÀO ĐƯỢC GIẢM THUẾ", X_MUC)])
        P.append([("STT", X_TIEUDE), ("Tên hàng hoá, dịch vụ", X_TIEUDE), ("Giá trị HHDV mua vào (chưa thuế)", X_TIEUDE), ("Thuế GTGT", X_TIEUDE), ("", X_TIEUDE), ("", X_TIEUDE)])
        for i, r in enumerate(pl["mua_vao"], 1):
            P.append([(i, X_CHU), (r["tenHHDVMuaVao"], X_CHU), (r["giaTriHHDVMuaVao"], X_SO), (r["thueGTGTHHDV"], X_SO)])
        P.append([("", X_MUC), ("Tổng cộng (thuế mua vào = [06])", X_MUC), (tg["tongCongGiaTriHHDVMuaVao"], X_SOMUC), (tg["tongCongThueGTGTHHDV"], X_SOMUC)])
        P.append([])
        P.append([("II. HÀNG HOÁ, DỊCH VỤ BÁN RA ĐƯỢC GIẢM THUẾ", X_MUC)])
        P.append([("STT", X_TIEUDE), ("Tên hàng hoá, dịch vụ", X_TIEUDE), ("Giá trị HHDV bán ra (chưa thuế)", X_TIEUDE), ("Thuế suất theo quy định (%)", X_TIEUDE),
                  ("Thuế suất sau giảm (%)", X_TIEUDE), ("Thuế GTGT được giảm", X_TIEUDE)])
        for i, r in enumerate(pl["ban_ra"], 1):
            P.append([(i, X_CHU), (r["tenHHDV"], X_CHU), (r["giaTriHHDV"], X_SO), (_so(r["thueSuatTheoQuyDinh"]), X_SO), (_so(r["thueSuatSauGiam"]), X_SO), (r["thueGTGTDuocGiam"], X_SO)])
        P.append([("", X_MUC), ("Tổng cộng (thuế được giảm = [08])", X_MUC), (tg["tongCongGiaTriHHDV"], X_SOMUC), (None, X_MUC), (None, X_MUC), (tg["tongCongThueGTGTDuocGiam"], X_SOMUC)])
        P.append([])
        P.append([("III. CHÊNH LỆCH THUẾ GTGT ĐƯỢC GIẢM", X_MUC)])
        P.append([("", X_CHU), ("[06] Thuế GTGT của HHDV mua vào được giảm", X_CHU), (None, X_CHU), (None, X_CHU), (None, X_CHU), (tg["tongCongThueGTGTHHDV"], X_SO)])
        P.append([("", X_CHU), ("[08] Thuế GTGT được giảm của HHDV bán ra", X_CHU), (None, X_CHU), (None, X_CHU), (None, X_CHU), (tg["tongCongThueGTGTDuocGiam"], X_SO)])
        P.append([("", X_CHU), ("[09] = [08] - [06] (có thể âm)", X_CHU), (None, X_CHU), (None, X_CHU), (None, X_CHU), (_tron(pl["ct9"]), X_SO)])
        tk = pl.get("thong_ke") or {}
        if tk:
            P.append([])
            P.append([("Hoá đơn bán ra 8%%: %d (tên hàng từ HĐĐT: %d) - mua vào 8%%: %d (từ HĐĐT: %d)%s" % (
                tk.get("hd_ban", 0), tk.get("hd_ban_hddt", 0), tk.get("hd_mua", 0), tk.get("hd_mua_hddt", 0),
                (" - %d dòng mua vào tạm tính thuế 8%%" % tk["uoc_thue_mua"]) if tk.get("uoc_thue_mua") else ""), X_GHICHU)])
    else:
        P.append([("Kỳ này không có hoá đơn thuế suất 8% - không lập phụ lục.", X_GHICHU)])
    sheets.append(("PL 142-174-204", [6, 60, 24, 20, 20, 22], P, 0))

    dc = dl.get("doi_chieu")
    if isinstance(dc, dict) and dc.get("ss") and dc.get("hd"):
        ss, hd = [_so(x) for x in dc["ss"]], [_so(x) for x in dc["hd"]]
        D = [[("ĐỐI CHIẾU SỔ KẾ TOÁN - CỔNG HOÁ ĐƠN ĐIỆN TỬ", X_TITLE)],
             [("Sổ kế toán: cách tính chỉ tiêu [34][35] bán ra, [23][24] mua vào. Cổng HĐĐT: hoá đơn điện tử đã tải trong kỳ, bỏ hoá đơn bị thay thế / huỷ.", X_GHICHU)], [],
             [("Chiều", X_TIEUDE), ("Nội dung", X_TIEUDE), ("Sổ kế toán", X_TIEUDE), ("Cổng HĐĐT", X_TIEUDE), ("Chênh lệch", X_TIEUDE)]]
        for ten, i_so, i_t, i_th in (("Bán ra", 4, 0, 1), ("Mua vào", 5, 2, 3)):
            D.append([(ten, X_MUC), ("Số hoá đơn", X_CHU), (ss[i_so], X_SO), (hd[i_so], X_SO), (ss[i_so] - hd[i_so], X_SO)])
            D.append([("", X_CHU), ("Tiền hàng (chưa thuế)", X_CHU), (ss[i_t], X_SO), (hd[i_t], X_SO), (ss[i_t] - hd[i_t], X_SO)])
            D.append([("", X_CHU), ("Thuế GTGT", X_CHU), (ss[i_th], X_SO), (hd[i_th], X_SO), (ss[i_th] - hd[i_th], X_SO)])
        D.append([])
        if not dc.get("co_hddt"):
            D.append([("CHƯA TẢI hoá đơn điện tử kỳ này (thẻ Hoá đơn -> Tải hoá đơn) nên không đối chiếu được.", X_DAM)])
        elif dc.get("lech"):
            D.append([("CÓ CHÊNH LỆCH: kiểm tra hoá đơn chưa hạch toán / hạch toán sai kỳ / hoá đơn thay thế, điều chỉnh trước khi xuất HTKK.", X_DAM)])
        else:
            D.append([("Số hoá đơn, tiền hàng và thuế KHỚP giữa sổ kế toán và Cổng HĐĐT.", X_DAM)])
        sheets.append(("Doi chieu", [12, 34, 20, 20, 18], D, 4))

    hd8 = ((dl.get("pl204") or {}).get("hd") or [])
    if hd8:
        H = [[("HOÁ ĐƠN THUẾ SUẤT 8% TRONG KỲ THEO SỔ SÁCH (nguồn lập phụ lục; tên hàng trên phụ lục lấy từ HĐĐT đã tải khi khớp tiền)", X_TITLE)], [],
             [("Chiều", X_TIEUDE), ("Số HĐ", X_TIEUDE), ("Ngày", X_TIEUDE), ("MST đối tác", X_TIEUDE), ("Tên hàng (sổ)", X_TIEUDE), ("Giá trị", X_TIEUDE), ("Thuế", X_TIEUDE), ("Chứng từ", X_TIEUDE)]]
        for x in sorted(hd8, key=lambda r: (-int(_so(r.get("h"))), str(r.get("ngay") or ""), str(r.get("so") or ""))):
            H.append([("Bán ra" if int(_so(x.get("h"))) == 1 else "Mua vào", X_CHU), (x.get("so") or "", X_CHU), (x.get("ngay") or "", X_CHU),
                      (x.get("mst") or "", X_CHU), (x.get("ten") or "", X_CHU), (_so(x.get("gt")), X_SO), (_so(x.get("thue")), X_SO), (x.get("kt") or "", X_CHU)])
        sheets.append(("HD 8% so sach", [10, 12, 12, 16, 50, 18, 16, 14], H, 3))
    try:
        os.makedirs(os.path.dirname(os.path.abspath(duong)), exist_ok=True)
        viet_xlsx_o(duong, sheets)
    except Exception as e:
        ghi_log("[EXCEL] Khong ghi duoc %s: %s" % (duong, e))
        return None, "Không ghi được tệp Excel %s: %s" % (duong, e)
    ghi_log("[EXCEL] %s -> %s (%d sheet)" % ("xem truoc" if xem_truoc else "kem ket xuat", duong, len(sheets)))
    return duong, ""


def _ket_xemtruoc(duong, loi):
    kq = os.path.join(BASE_DIR, "ket-qua")
    try:
        os.makedirs(kq, exist_ok=True)
        with open(os.path.join(kq, "DA_XONG_XEMTRUOC"), "w", encoding="utf-8") as f:
            f.write(("OK " + duong) if duong else ("LOI " + (loi or "khong ro")))
    except Exception:
        pass
    if loi:
        ghi_log("KET QUA XEM TRUOC: " + loi)


# ---------------------------------------------------------------------------
#  KIEM TRA MOT FILE XML DA CO (truoc khi nop)
# ---------------------------------------------------------------------------
def nhan_dang(goc):
    ma = _tim_nut(goc, "/HSoKhaiThue/TTinChung/TTinTKhaiThue/TKhaiThue/maTKhai")
    ten = _tim_nut(goc, "/HSoKhaiThue/TTinChung/TTinTKhaiThue/TKhaiThue/tenTKhai")
    pb = _tim_nut(goc, "/HSoKhaiThue/TTinChung/TTinTKhaiThue/TKhaiThue/pbanTKhaiXML")
    ky = _tim_nut(goc, "/HSoKhaiThue/TTinChung/TTinTKhaiThue/TKhaiThue/KyKKhaiThue/kyKKhai")
    f = lambda n: (n.text or "").strip() if n is not None else ""
    return f(ma), f(ten), f(pb), f(ky)


def kiem_tra_tep(duong_xml, sua=False, duong_ra=None):
    """Doc mot file XML da ket xuat, chay het rang buoc. Tra ve (bao_cao, so_loi_chan)."""
    try:
        cay = ET.parse(duong_xml)
    except Exception as e:
        return "Khong doc duoc file XML: %s" % e, 1
    goc = cay.getroot()
    ma, ten, pb, ky = nhan_dang(goc)
    d = ["FILE : %s" % os.path.basename(duong_xml),
         "TKHAI: %s - %s" % (ma, ten or "(khong ro)"),
         "PBAN : %s     KY: %s" % (pb or "?", ky or "?"), ""]

    la_b01a = (ma == "683") or ("B01A" in (ten or "").upper().replace(" ", ""))
    mau_khac = "" if la_b01a else _mau_bctc_khac(ma, ten, duong_xml, goc)     # GD72: B01b-DNN / B01-DNNKLT
    co_cdtk = _tim_nut(goc, "/HSoKhaiThue/PLuc/PL_CDTK") is not None
    if co_cdtk and not la_b01a and not mau_khac:
        # Canh giac: B01b-DNN cung co phu luc PL_CDTK nhung he thong MA CHI TIEU
        # khac han (B01b: [100] = [110]+[120]+[130]+[140]+[150] cho tai san NGAN HAN,
        # [133] la phai thu ngan han khac...). Ap luat cua B01a vao se bao sai hang loat.
        return ("Bo bao cao nay co phu luc bang can doi tai khoan nhung KHONG phai B01a-DNN "
                "(maTKhai=%s, ten=%s). Bo rang buoc hien co chi dung cho B01a-DNN (maTKhai 683) "
                "va 01/GTGT (842) - khong ap dung de tranh bao sai hang loat." % (ma or "?", ten or "?")), 0
    if la_b01a:
        chan, canh, chu = kiem_tra_b01a(goc)
        loai = "B01a-DNN"
    elif mau_khac == "B01B":
        chan, canh, chu = kiem_tra_b01b(goc)
        loai = "B01b-DNN"
    elif mau_khac == "KLT":
        chan, canh, chu = kiem_tra_klt(goc)
        loai = "B01-DNNKLT"
    elif ma == "842" or "GIA TR" in (ten or "").upper():
        ct = {}
        for duong in _duyet(goc):
            pass
        for duong, nut in _duyet(goc):
            m = _RE_CT.match(_ten(nut))
            if m and duong.startswith("/HSoKhaiThue/CTieuTKhaiChinh"):
                ct[m.group(1).lower()] = _so((nut.text or "").strip())
        chan, canh = tu_kiem_01gtgt(ct)
        chu = []
        loai = "01/GTGT"
    else:
        return ("Chua co bo rang buoc cho mau to khai nay (maTKhai=%s). Hien kiem duoc "
                "01/GTGT (842), B01a-DNN TT133 (683), B01b-DNN va B01-DNNKLT." % ma), 0

    if sua and loai in ("B01a-DNN", "B01b-DNN", "B01-DNNKLT"):
        n = 0
        for khoi in ("SoDuDauKy", "SoPhatSinhTrongKy", "SoDuCuoiKy"):
            for ben in ("No", "Co"):
                nut = _tim_nut(goc, "/HSoKhaiThue/PLuc/PL_CDTK/%s/%s" % (khoi, ben))
                if nut is None:
                    continue
                tc = None
                for c in list(nut):
                    if _ten(c) == "tongCong":
                        tc = c
                if tc is None:
                    continue
                t = tong_cong_cdtk(_cdtk(goc, khoi, ben))
                if abs(_so(tc.text) - t) > 1 and _so(tc.text) == 0:
                    tc.text = _so_xml(t)
                    n += 1
        if n:
            ra = duong_ra or duong_xml
            _ghi_xml(cay, goc, ra)
            d.append(">> DA DIEN %d o tongCong cua PL_CDTK va ghi lai: %s" % (n, ra))
            d.append("")
            chan, canh, chu = {"B01a-DNN": kiem_tra_b01a, "B01b-DNN": kiem_tra_b01b, "B01-DNNKLT": kiem_tra_klt}[loai](goc)

    if chan:
        d.append("*** %d LOI PHAI SUA (khong nop duoc) ***" % len(chan))
        for x in chan:
            d.append("  - " + x)
        d.append("")
    if canh:
        d.append("%d CANH BAO (nen xem lai truoc khi nop)" % len(canh))
        for x in canh:
            d.append("  ? " + x)
        d.append("")
    if chu:
        d.append("GHI CHU")
        for x in chu:
            d.append("  . " + x)
        d.append("")
    if not chan and not canh:
        d.append("DAT - khong phat hien lech nao.")
    return "\n".join(d), len(chan)


# ---------------------------------------------------------------------------
#  DOC BANG CAN DOI TAI KHOAN TU EXCEL (doi chieu voi XML)
# ---------------------------------------------------------------------------
def doc_cdtk_excel(duong_xls, sheet="CDTK", dong_dau=12):
    """Doc dung cach FrmXmlHTKK.Read_CDTK_FixedRC dang doc:
       cot B = so hieu TK, D/E = du dau No/Co, F/G = phat sinh No/Co, H/I = du cuoi No/Co."""
    try:
        import openpyxl
    except ImportError:
        return None, "Chua cai openpyxl (pip install openpyxl)"
    try:
        wb = openpyxl.load_workbook(duong_xls, data_only=True)
    except Exception as e:
        return None, "Khong mo duoc Excel: %s" % e
    if sheet not in wb.sheetnames:
        return None, "Khong co sheet '%s' trong %s" % (sheet, os.path.basename(duong_xls))
    ws = wb[sheet]
    ra = {}
    for r in range(dong_dau, ws.max_row + 1):
        acc = ws.cell(r, 2).value
        acc = "" if acc is None else str(acc).strip()
        if not acc.isdigit() or acc == "0":
            continue
        ra[acc] = {
            "dau_no": _so(ws.cell(r, 4).value), "dau_co": _so(ws.cell(r, 5).value),
            "ps_no": _so(ws.cell(r, 6).value), "ps_co": _so(ws.cell(r, 7).value),
            "cuoi_no": _so(ws.cell(r, 8).value), "cuoi_co": _so(ws.cell(r, 9).value),
        }
    return ra, ""


def doi_chieu_cdtk(duong_xml, duong_xls, sheet="CDTK", dong_dau=12):
    """Tim tai khoan co trong bang can doi tai khoan nhung KHONG co o nao trong
       to khai HTKK - nhung tai khoan nay dang bi bo am tham."""
    try:
        # GD72: mau B01-DNNKLT cua HTKK khong co phu luc bang can doi tai khoan - khong phai loi, khong can doc Excel
        _g = ET.parse(duong_xml).getroot()
        _ma, _tn, _pb, _ky = nhan_dang(_g)
        if _tim_nut(_g, "/HSoKhaiThue/PLuc/PL_CDTK") is None and _mau_bctc_khac(_ma, _tn, duong_xml, _g) == "KLT":
            return "Mau B01-DNNKLT khong co phu luc bang can doi tai khoan - bo qua doi chieu tai khoan.", 0
    except Exception:
        pass
    bang, loi = doc_cdtk_excel(duong_xls, sheet, dong_dau)
    if bang is None:
        return loi, 1
    try:
        goc = ET.parse(duong_xml).getroot()
    except Exception as e:
        return "Khong doc duoc file XML: %s" % e, 1
    co_o = set(_cdtk(goc, "SoDuCuoiKy", "No").keys())
    if not co_o:
        return "File XML khong co phu luc PL_CDTK.", 1
    d = ["Bang can doi tai khoan: %d tai khoan (%s, sheet %s)"
         % (len(bang), os.path.basename(duong_xls), sheet),
         "To khai HTKK co o cho    : %d tai khoan" % len(co_o), ""]
    mo_coi = {a: v for a, v in bang.items() if a not in co_o}
    if not mo_coi:
        d.append("DAT - moi tai khoan deu co o trong to khai.")
        return "\n".join(d), 0
    tong = sum(abs(v["cuoi_no"]) + abs(v["cuoi_co"]) for v in mo_coi.values())
    d.append("*** %d TAI KHOAN KHONG CO O TRONG TO KHAI HTKK ***" % len(mo_coi))
    d.append("    (FrmXmlHTKK dang BO QUA am tham cac tai khoan nay -> tong khong can)")
    d.append("")
    for a in sorted(mo_coi):
        v = mo_coi[a]
        cha = ""
        for k in range(len(a) - 1, 2, -1):
            if a[:k] in co_o:
                cha = a[:k]
                break
        d.append("  TK %-7s du cuoi No %16s  Co %16s   %s"
                 % (a, _dinh_dang(v["cuoi_no"]), _dinh_dang(v["cuoi_co"]),
                    ("-> gop vao TK %s" % cha) if cha else "-> KHONG CO tai khoan cha!"))
    d.append("")
    d.append("Tong tri tuyet doi bi bo: %s" % _dinh_dang(tong))
    return "\n".join(d), len(mo_coi)


# ---------------------------------------------------------------------------
#  DONG LENH (VB6 goi)
# ---------------------------------------------------------------------------
def _tach_dong_lenh(s):
    ra, cur, trong = [], "", False
    for c in s:
        if c == '"':
            trong = not trong
        elif c.isspace() and not trong:
            if cur:
                ra.append(cur); cur = ""
        else:
            cur += c
    if cur:
        ra.append(cur)
    return ra


def mo_rong_tham_so(argv):
    ra = []
    for a in argv:
        if a.startswith("/thamso:"):
            tep = a[len("/thamso:"):].strip('"')
            try:
                with open(tep, "r", encoding="utf-8") as f:
                    ra.extend(_tach_dong_lenh(f.read()))
            except Exception as e:
                ghi_log("Khong doc duoc file tham so %s: %s" % (tep, e))
        else:
            ra.append(a)
    return ra


def main():
    ts, co = {}, set()
    for a in mo_rong_tham_so(sys.argv[1:]):
        for k in ("hocmau", "matk", "xuat", "ra", "mau", "kiemtra", "cdtk", "sheet", "dongdau", "htkk", "htkkdat", "xemtruoc",
                  "kiemkhoaso", "uoctndn", "doichieuhd", "baocaobs", "loai", "khungbctc", "kytruoc", "them", "mst", "thumuc", "bangkehd",
                  "ruirohd", "docnnt", "dieuhanh", "nhatkyai", "dongtien", "batthuong", "phantichkd", "thuechudn", "giathanhbc",
                  "xuat1lan", "muc", "kieu", "bangluongdc", "ketchuyen", "sohdts", "hdexcel", "huong", "tokhai", "excel", "chiphi",
                  "vaoai", "khach", "duavaohtkk", "cdps", "namtruoc", "chedo", "tep", "thangdau"):
            if a.startswith("/" + k + ":"):
                ts[k] = a[len(k) + 2:].strip('"')
        for k in ("bhdc", "maunv", "nhapnv", "dmnv", "xuatnv"):          # GD134: doi chieu BHXH, mau / nhap danh sach nhan vien
            if a.startswith("/" + k + ":"):
                ts[k] = a[len(k) + 2:].strip('"')
        for k in ("congviec", "quantri"):          # GD137: Excel lich cong viec nam ; GD140: trang tong quan quan tri (HTML)
            if a.startswith("/" + k + ":"):
                ts[k] = a[len(k) + 2:].strip('"')
        for k in ("congkhach", "ngaychot", "matkhau", "ten", "sophieu", "lydo"):          # GD293: cong cu khach (xuat goi di / nap goi ve)
            if a.startswith("/" + k + ":"):
                ts[k] = a[len(k) + 2:].strip('"')
        for k in ("kiemsoat",):          # GD146: Excel kiem soat cong no & vat tu
            if a.startswith("/" + k + ":"):
                ts[k] = a[len(k) + 2:].strip('"')
        for k in ("nguonkt", "dat", "gt"):          # GD162: nguon ky truoc theo cong ty (nguon-ky-truoc.json)
            if a.startswith("/" + k + ":"):
                ts[k] = a[len(k) + 2:].strip('"')
        for k in ("sosanhhtkk",):          # GD164: xem truoc to khai XML truoc khi dua vao HTKK (so sanh ky truoc / trong ky)
            if a.startswith("/" + k + ":"):
                ts[k] = a[len(k) + 2:].strip('"')
        for k in ("nhaphtkk", "sodu", "ranamtruoc"):          # GD168: nhap toan bo du lieu HTKK theo MST (mot lan / nam tai chinh)
            if a.startswith("/" + k + ":"):
                ts[k] = a[len(k) + 2:].strip('"')
        for k in ("nopdvc", "tencty", "sosanh", "ep"):          # GD185: ho so ky so va nop Cong DVC (nop_dvc.py)
            if a.startswith("/" + k + ":"):
                ts[k] = a[len(k) + 2:].strip('"')
        for k in ("maumoi",):          # GD170: quet mau to khai moi tren HTKK (1 = quet, daxem = ghi nhan da xem roi quet)
            if a.startswith("/" + k + ":"):
                ts[k] = a[len(k) + 2:].strip('"')
        for k in ("dinhmucai", "buoc", "chon"):          # GD173: tro ly lap dinh muc NVL (dinh_muc_ai.py)
            if a.startswith("/" + k + ":"):
                ts[k] = a[len(k) + 2:].strip('"')
        for k in ("hosoct", "nhanct", "daxem"):          # GD174: ho so kem chung tu / nhan chung tu khach (ho_so_chung_tu.py)
            if a.startswith("/" + k + ":"):
                ts[k] = a[len(k) + 2:].strip('"')
        for k in ("khoathang", "tuthang", "denthang", "hlds", "xuatthang", "tkno", "nghiepvu", "aiauto", "viec", "aikhach"):          # GD360: aiauto = AI_AUTO ra soat ca ky (viec cu / viec moi)          # GD358: nghiepvu = nghiep vu dinh ky theo mau          # GD356: kiem tra tong hop khoa so thang; danh sach bo so chay hang loat
            if a.startswith("/" + k + ":"):
                ts[k] = a[len(k) + 2:].strip('"')
        for k in ("nokhodoi", "ngay"):          # GD353: no phai thu kho doi (no_kho_doi.py)
            if a.startswith("/" + k + ":"):
                ts[k] = a[len(k) + 2:].strip('"')
        for k in ("tcmst", "dmnhap", "thumua", "xlsx"):          # GD212: tra cuu MST tren trang Cuc Thue (tra_cuu_mst.py); GD213: nhap bang dinh muc / du toan
            if a.startswith("/" + k + ":"):
                ts[k] = a[len(k) + 2:].strip('"')
        if a.lower() in ("/sua", "/boquatukiem", "/mohtkk", "/timhtkk", "/ghide"):
            co.add(a.lower()[1:])
    ghi_log("=" * 60)
    ghi_log("Khoi dong tool HTKK: %s %s" % (json.dumps(ts, ensure_ascii=False), sorted(co)))
    if not ts and not co:          # GD358: lenh khong nhan ra (VB moi hon tool) -> ghi moc LOI ngay, VB6 khong phai cho het gio
        _la = [str(a) for a in mo_rong_tham_so(sys.argv[1:]) if str(a).startswith("/")]
        if _la:
            _m = "Lenh khong nhan ra: %s - tool_htkk_unesco.py o %s co the la ban cu, chay CAP_NHAT_TU_DONG.bat" % (" ".join(_la)[:120], BASE_DIR)
            _ket_khoaso("", _m)
            _ket("", _m)
            return 2

    # GD56: dat duong HTKK / tim HTKK / mo HTKK
    if ts.get("htkkdat"):
        g, loi = dat_duong_htkk(ts["htkkdat"])
        _ket("HTKK " + g if g else "", loi)
        return 0 if g else 1
    if "timhtkk" in co and not ts.get("xuat"):
        h = tim_htkk(ts.get("htkk", ""))
        _ket("HTKK " + h["goc"] if h else "", "" if h else "Khong tim thay HTKK tren may nay")
        return 0 if h else 1
    if ts.get("duavaohtkk"):
        # GD122: dua to khai XML (tep / thu muc / danh sach cho ghi de) THANG vao HTKK (DataFiles\<MST>) - moc DA_XONG_KHOASO
        try:
            import htkk_dua_vao as DV
            h = tim_htkk(ts.get("htkk", ""))
            kqs, dong = DV.dua_vao_nhieu(ts["duavaohtkk"], ts.get("mst", ""), (h or {}).get("goc", ""),
                                         ghi_de=("ghide" in co), log=ghi_log)
            DV.ghi_cho_ghi_de(kqs)          # gop: to khai vua xong bo khoi danh sach cho, to khai da co (khong ghi de) them vao
            tep = os.path.join(BASE_DIR, "ket-qua", "DUA_VAO_HTKK.txt")
            os.makedirs(os.path.dirname(tep), exist_ok=True)
            with open(tep, "w", encoding="utf-8-sig", newline="\r\n") as f:
                f.write("\n".join(dong or ["Không có tờ khai XML để đưa vào HTKK."]) + "\n")
            ok = any(k.get("ok") for k in kqs)
            _ket_khoaso(tep if ok else "", "" if ok else ("; ".join(k.get("loi", "") for k in kqs) or "khong co to khai XML"))
            return 0 if ok else 1
        except Exception as e:
            import traceback
            ghi_log("[DUA VAO HTKK] loi: %s\n%s" % (e, traceback.format_exc()))
            _ket_khoaso("", "Loi dua vao HTKK: %s" % e)
            return 1

    if ts.get("nopdvc"):
        # GD185: ho so ky so va nop Cong DVC - quet / xem / goi (nop_dvc.py). CHI chuan bi + chep nguyen byte; khong dang nhap, ky, nop.
        #   moc DA_XONG_KHOASO "OK <tep ket qua>" ; /chedo:quet -> ket-qua\NOP_DVC.txt ; goi -> <ra>\NOP_DVC_<ngay>\0_PHIEU_NOP.html
        try:
            import nop_dvc as ND
            h = tim_htkk(ts.get("htkk", ""))
            p = ND.chay(ts["nopdvc"], ts.get("chedo", "quet"), ts.get("mst", ""), ts.get("tencty", ""), (h or {}).get("goc", ""),
                        ts.get("thumuc", ""), ts.get("ra", ""), ep=(str(ts.get("ep", "")).strip() == "1"),
                        so_sanh=(str(ts.get("sosanh", "1")).strip() != "0"), log=ghi_log)
            _ket_khoaso(p, "")
            return 0
        except Exception as e:
            import traceback
            ghi_log("[NOP DVC] loi: %s\n%s" % (e, traceback.format_exc()))
            _ket_khoaso("", "Loi ho so nop Cong DVC: %s" % e)
            return 1

    if ts.get("sosanhhtkk"):
        # GD164: xem truoc to khai XML (tep / thu muc) truoc khi dua vao HTKK: so sanh ky truoc + kiem cheo trong ky
        #   -> ket-qua\XEM_TRUOC_HTKK.txt (+ XemTruoc_SoSanh.xlsx canh tep); moc DA_XONG_KHOASO. Chi doc, khong ghi HTKK.
        try:
            import so_sanh_htkk as SS
            ng = ts["sosanhhtkk"]
            if os.path.isdir(ng):
                ds = [os.path.join(ng, f) for f in sorted(os.listdir(ng)) if f.lower().endswith(".xml")]
                ra_ex = ng
            else:
                ds = [ng]
                ra_ex = os.path.dirname(os.path.abspath(ng))
            h = tim_htkk(ts.get("htkk", ""))
            kq = SS.xem_truoc(ds, ts.get("mst", ""), ts.get("thumuc", ""), (h or {}).get("goc", ""), ra_ex, ghi_log)
            tep = os.path.join(BASE_DIR, "ket-qua", "XEM_TRUOC_HTKK.txt")
            os.makedirs(os.path.dirname(tep), exist_ok=True)
            with open(tep, "w", encoding="utf-8-sig", newline="\r\n") as f:
                f.write("\n".join(kq["dong"]) + "\n")
            ghi_log("[XEM TRUOC HTKK] %d to khai, %d [!], %d [?]" % (len(kq.get("muc") or []), kq["loi"], kq["xem"]))
            _ket_khoaso(tep, "")
            return 0
        except Exception as e:
            import traceback
            ghi_log("[XEM TRUOC HTKK] loi: %s\n%s" % (e, traceback.format_exc()))
            _ket_khoaso("", "Loi xem truoc HTKK: %s" % e)
            return 1

    if ts.get("nhaphtkk"):
        # GD168: nhap toan bo du lieu HTKK theo MST cho nam tai chinh (nhap_htkk_mst.py): danh muc to khai DataFiles\<MST>, BCTC nam
        #   truoc, so du TK (PL_CDTK) <-> so du dau nam cua so (/sodu: JSON VB), 03/TNDN, 01/GTGT, TNCN -> <ra>.txt + .xlsx + .khoa.txt
        #   moc DA_XONG_KHOASO "OK <txt>" / "LOI ...". Chi doc HTKK va so lieu so.
        try:
            import nhap_htkk_mst as NH
            h = tim_htkk(ts.get("htkk", ""))
            ra = ts.get("ra") or os.path.join(BASE_DIR, "ket-qua", "NHAP_HTKK_%s.txt" % ts["nhaphtkk"])
            kq = NH.chay(ts["nhaphtkk"], ts.get("chedo", "133"), ts.get("thangdau") or 1, mst=ts.get("mst", ""),
                         thu_muc_khach=ts.get("thumuc", ""), goc_htkk=(h or {}).get("goc", ""), so_du=ts.get("sodu", ""), ra=ra,
                         ra_nam_truoc=ts.get("ranamtruoc", ""), log=ghi_log)
            ghi_log("[NHAP HTKK] %d to khai, %d [!], %d [?]" % (len((kq.get("danh_muc") or {}).get("to_khai") or []), kq["loi"], kq["xem"]))
            _ket_khoaso(ra, "")
            return 0
        except Exception as e:
            import traceback
            ghi_log("[NHAP HTKK] loi: %s\n%s" % (e, traceback.format_exc()))
            _ket_khoaso("", "Loi nhap du lieu HTKK: %s" % e)
            return 1

    if ts.get("hosoct") or ts.get("nhanct"):
        # GD174: ho so kem chung tu (H2 - moi nghiep vu mot bo chung tu, thu yeu cau khach) / quet thu muc nhan chung tu khach (F1) - chi doc.
        try:
            import ho_so_chung_tu as HSC
            if ts.get("hosoct"):
                p = HSC.chay(ts["hosoct"], ts.get("ra", ""), ghi_log)
            else:
                p = ts.get("ra") or os.path.join(BASE_DIR, "ket-qua", "nhan_chung_tu.txt")
                HSC.nhan_chung_tu(ts["nhanct"], str(ts.get("daxem", "")).strip().lower() in ("1", "true"), p)
            _ket_khoaso(p, "")
            return 0
        except Exception as e:
            import traceback
            ghi_log("[HO SO CT] loi: %s\n%s" % (e, traceback.format_exc()))
            _ket_khoaso("", "Loi ho so chung tu: %s" % e)
            return 1

    if ts.get("dinhmucai"):
        # GD173: tro ly lap dinh muc NVL - buoc 1 (nganh, nhom NVL, thuoc tinh SP) / buoc 2 (de xuat theo lua chon) -> tep ';' cho VB (chi doc).
        try:
            import dinh_muc_ai as DMA
            p = DMA.chay(ts["dinhmucai"], ts.get("buoc", "1"), ts.get("chon", ""), ts.get("ra", ""), ghi_log)
            _ket_khoaso(p, "")
            return 0
        except Exception as e:
            import traceback
            ghi_log("[DINH MUC AI] loi: %s\n%s" % (e, traceback.format_exc()))
            _ket_khoaso("", "Loi tro ly dinh muc: %s" % e)
            return 1

    if ts.get("khoathang"):
        # GD356: /khoathang:"<so.MDB>" [/tuthang:1] [/denthang:12] -> ket-qua\khoa_so_thang.txt + .html; moc DA_XONG_KHOASO "OK <txt>". Chi doc so.
        try:
            import khoa_so_thang as KST
            _kq356, p_txt, _h = KST.chay(ts["khoathang"], int(ts.get("tuthang") or 1), int(ts.get("denthang") or 0) or None, os.path.join(BASE_DIR, "ket-qua"))
            _ket_khoaso(p_txt, "")
            return 0
        except Exception as e:
            import traceback
            ghi_log("[KHOA SO THANG] loi: %s\n%s" % (e, traceback.format_exc()))
            _ket_khoaso("", "Loi kiem tra khoa so thang: %s" % e)
            return 1

    if ts.get("nghiepvu"):
        # GD358: /nghiepvu:"<so.MDB>" [/tuthang:] [/denthang:] -> ket-qua\nghiep_vu_dinh_ky.txt + .html (+ khoa_so_thang.txt); moc DA_XONG_KHOASO "OK <txt>". Chi doc so.
        try:
            import nghiep_vu_dinh_ky as NVK
            _kq358, p_txt, _h = NVK.chay(ts["nghiepvu"], int(ts.get("tuthang") or 1), int(ts.get("denthang") or 0) or None, os.path.join(BASE_DIR, "ket-qua"))
            _ket_khoaso(p_txt, "")
            return 0
        except Exception as e:
            import traceback
            ghi_log("[NGHIEP VU DINH KY] loi: %s\n%s" % (e, traceback.format_exc()))
            _ket_khoaso("", "Loi nghiep vu dinh ky: %s" % e)
            return 1

    if ts.get("aiauto"):
        # GD360: /aiauto:"<so.MDB>" [/viec:VIEC_CU|VIEC_MOI] [/tuthang:] [/denthang:] -> ket-qua\ai_auto_dieu_phoi.txt + .html (AI_AUTO ra soat ca ky:
        #   moi thang x 9 buoc da lam / chua lam / can nguoi, viec nguoi phai lam, buoc may lam duoc); moc DA_XONG_KHOASO "OK <txt>". Chi doc so.
        try:
            import ai_auto_dieu_phoi as AAD
            _kq360, p_txt, _h = AAD.chay(ts["aiauto"], (ts.get("viec") or "VIEC_CU").upper(), int(ts.get("tuthang") or 1), int(ts.get("denthang") or 0) or None,
                                         os.path.join(BASE_DIR, "ket-qua"), ts.get("aikhach") or None)          # GD370: thu muc khach
            _ket_khoaso(p_txt, "")
            return 0
        except Exception as e:
            import traceback
            ghi_log("[AI_AUTO] loi: %s\n%s" % (e, traceback.format_exc()))
            _ket_khoaso("", "Loi AI_AUTO ra soat: %s" % e)
            return 1

    if ts.get("xuatthang"):
        # GD357: /xuatthang:"<so.MDB>" [/tuthang:] [/denthang:] [/tkno:1541] -> ket-qua\xuat_thang_nvl.txt (de xuat, chi doc); moc DA_XONG_KHOASO "OK <txt>"
        try:
            import xuat_thang_nvl as XTN
            _kq357, p_txt = XTN.chay(ts["xuatthang"], int(ts.get("tuthang") or 1), int(ts.get("denthang") or 12), ts.get("tkno") or None,
                                     os.path.join(BASE_DIR, "ket-qua"))
            _ket_khoaso(p_txt, "")
            return 0
        except Exception as e:
            import traceback
            ghi_log("[XUAT THANG NVL] loi: %s\n%s" % (e, traceback.format_exc()))
            _ket_khoaso("", "Loi phan tich xuat thang NVL: %s" % e)
            return 1

    if ts.get("hlds"):
        # GD356: /hlds:"<cau_hinh.json>" -> ket-qua\hang_loat_ds.txt (bo so + lua chon da luu); moc DA_XONG_KHOASO "OK <txt>"
        try:
            import hang_loat as HLX
            p_txt = HLX.danh_sach(ts["hlds"], os.path.join(BASE_DIR, "ket-qua", "hang_loat_ds.txt"))
            _ket_khoaso(p_txt, "")
            return 0
        except Exception as e:
            _ket_khoaso("", "Loi danh sach bo so: %s" % e)
            return 1

    if ts.get("nokhodoi"):
        # GD353: /nokhodoi:"<so.MDB>" [/ngay:dd/mm/yyyy] -> ket-qua\no_kho_doi.html + bo ho so; moc DA_XONG_KHOASO "OK <html>". Chi doc so.
        try:
            import no_kho_doi as NKD
            _kq353, _t, p_html, _h = NKD.chay(ts["nokhodoi"], NKD._ngay(ts.get("ngay")), os.path.join(BASE_DIR, "ket-qua"))
            _ket_khoaso(p_html, "")
            return 0
        except Exception as e:
            import traceback
            ghi_log("[NO KHO DOI] loi: %s\n%s" % (e, traceback.format_exc()))
            _ket_khoaso("", "Loi phan tich no kho doi: %s" % e)
            return 1

    if ts.get("maumoi"):
        # GD170: quet mau to khai moi / doi phien ban tren HTKK (htkk_mau_moi.py - chi doc Menu.xml) -> ket-qua\htkk_mau_moi.txt;
        #   /maumoi:daxem = nguoi dung da xem -> ghi nhan danh muc hien tai lam moc roi quet lai. Moc DA_XONG_KHOASO "OK <txt>".
        try:
            import htkk_mau_moi as HM
            h = tim_htkk(ts.get("htkk", ""))
            goc = (h or {}).get("goc", "")
            kq_dir = os.path.join(BASE_DIR, "ket-qua")
            if ts["maumoi"].strip().lower() == "daxem":
                HM.da_xem(kq_dir, goc)
            kq = HM.quet(goc, kq_dir, (h or {}).get("phien_ban", ""), ghi_log)
            _ket_khoaso(os.path.join(kq_dir, HM.TEP_TXT), "")
            return 0 if kq.get("doc_duoc") else 1
        except Exception as e:
            import traceback
            ghi_log("[MAU MOI HTKK] loi: %s\n%s" % (e, traceback.format_exc()))
            _ket_khoaso("", "Loi quet mau moi HTKK: %s" % e)
            return 1

    if "mohtkk" in co and not ts.get("xuat"):
        # GD122: mo HTKK + dang nhap san MST cong ty (/mst:). Bao VB ngay khi da mo (khong bat VB cho buoc dang nhap).
        h = tim_htkk(ts.get("htkk", ""))
        da_bao = []

        def bao_vb(ok1, x1):
            da_bao.append(ok1)
            _ket("MO_HTKK " + x1 if ok1 else "", "" if ok1 else x1)
        try:
            import htkk_dua_vao as DV
            ok, x = DV.mo_htkk_theo_mst(h, ts.get("mst", ""), 90, ghi_log, da_mo=bao_vb)
            ghi_log("[HTKK GD122] %s" % x)
        except Exception as e:
            ghi_log("[HTKK GD122] mo theo MST loi: %s" % e)
            if da_bao:                      # HTKK da mo (loi o buoc dien MST) - khong mo them lan nua
                return 0 if da_bao[0] else 1
            ok, x = mo_htkk(h)
            _ket("MO_HTKK " + x if ok else "", "" if ok else x)
        return 0 if ok else 1

    if ts.get("khungbctc"):
        # GD72: khuon BCTC B01A / B01B / KLT cho FrmXmlHTKK (khong dien so lieu ke toan)
        ra = ts.get("ra") or os.path.join(BASE_DIR, "ket-qua", "khuon_%s.xml" % ts["khungbctc"].upper())
        d, loi = khung_bctc(ts["khungbctc"], ra, ts.get("htkk", ""))
        _ket(d or "", loi)
        return 0 if d else 1

    if ts.get("nguonkt"):
        # GD162: "tep duong dan" nguon ky truoc theo cong ty (<thu muc khach>\\nguon-ky-truoc.json): dat / doc / xem danh sach to khai
        #   -> <ra>.txt KHOA=GIA TRI; moc DA_XONG_KHOASO "OK <txt>". Chi luu duong dan, khong sua tep cua nguoi dung.
        try:
            import nguon_ky_truoc as NKT
            tm = ts["nguonkt"]
            khoa = (ts.get("dat") or "").strip().lower()
            loi = ""
            if khoa and khoa != "xem":
                _ok, loi = NKT.dat(tm, khoa, ts.get("gt", ""))
            h = tim_htkk(ts.get("htkk", ""))
            dong = NKT.tom_tat(tm, ts.get("mst", ""), h)
            if loi:
                dong.append("LOI=%s" % loi)
            if khoa == "xem":
                dong.append("XEM=%s" % xem_to_khai_ky_truoc(tm, ts.get("mst", ""), h))
            ra = ts.get("ra") or os.path.join(BASE_DIR, "ket-qua", "NGUON_KY_TRUOC.txt")
            os.makedirs(os.path.dirname(os.path.abspath(ra)), exist_ok=True)
            with open(ra, "w", encoding="utf-8-sig", newline="\r\n") as f:
                f.write("\n".join(x.replace("\r", " ").replace("\n", " ") for x in dong) + "\n")
            ghi_log("[NGUON KY TRUOC] %s" % (khoa or "doc"))
            _ket_khoaso(ra, "")
            return 0
        except Exception as e:
            import traceback
            ghi_log("[NGUON KY TRUOC] loi: %s\n%s" % (e, traceback.format_exc()))
            _ket_khoaso("", "Loi nguon ky truoc: %s" % e)
            return 1

    if ts.get("kytruoc"):
        # GD73: [22] = [43] to khai ky truoc tu to khai luu tru -> ket-qua/DA_XONG_KYTRUOC (dong dau OK / KHONG / LOI, sau do KHOA=GIA TRI)
        noi = ""
        try:
            import tk_luu_tru
            a, b = (ts["kytruoc"].split("-") + [""])[:2]
            d1, d2 = datetime.strptime(a.strip(), "%Y%m%d"), datetime.strptime(b.strip(), "%Y%m%d")
            them = ""
            if ts.get("them"):
                ds, loi_them = tk_luu_tru.luu_tep(ts["them"], ts.get("mst", ""), ts.get("thumuc", ""))
                them = loi_them or tk_luu_tru.mo_ta_luu(ds)
            h = tim_htkk(ts.get("htkk", ""))
            kq = tk_luu_tru.tim(d1, d2, ts.get("mst", ""), ts.get("thumuc", ""), (h or {}).get("goc", ""))
            kq["them"] = them
            if h:                                       # GD162: thong tin chung HTKK tren may (HEADER.xml) cung tinh la da co
                hd = dau_may(h["goc"], ts.get("mst", ""))
                kq["hd_nguoi_ky"], kq["hd_cqt"] = bool(hd.get("nguoiKy")), bool(hd.get("maCQTNoiNop"))
            noi = tk_luu_tru.ket_qua_vb(kq)
            ghi_log("[KY TRUOC] %s -> %s" % (ts["kytruoc"], noi.replace("\r\n", " | ")))
        except Exception as e:
            import traceback
            ghi_log("[KY TRUOC] loi: %s\n%s" % (e, traceback.format_exc()))
            noi = "LOI %s\r\n" % e
        try:
            os.makedirs(os.path.join(BASE_DIR, "ket-qua"), exist_ok=True)
            with open(os.path.join(BASE_DIR, "ket-qua", "DA_XONG_KYTRUOC"), "w", encoding="utf-8", newline="") as f:
                f.write(noi)
        except Exception:
            pass
        return 0

    if ts.get("namtruoc"):
        # GD131: so lieu nam truoc cho BCTC (bctc_nam_truoc.py: XML thu muc khach / du lieu HTKK tren may / tep Excel, XML, ZIP;
        #   so TT99 doi ma TT200 / TT133 -> TT99) -> <ra>.txt + .xlsx xem truoc; moc DA_XONG_KHOASO "OK <txt>" / "LOI ..."
        try:
            import bctc_nam_truoc as NT
            h = None if ts.get("tep") else tim_htkk(ts.get("htkk", ""))
            p, loi = NT.chay(ts["namtruoc"], ts.get("chedo", "133"), mst=ts.get("mst", ""), thu_muc=ts.get("thumuc", ""),
                             tep=ts.get("tep", ""), ra=ts.get("ra", ""), goc_htkk=(h or {}).get("goc", ""), log=ghi_log)
            _ket_khoaso(p or "", loi)
            return 0 if p else 1
        except Exception as e:
            import traceback
            ghi_log("[NAM TRUOC] loi: %s\n%s" % (e, traceback.format_exc()))
            _ket_khoaso("", "Loi lay so nam truoc: %s" % e)
            return 1

    if ts.get("hocmau"):
        ma_tk = ts.get("matk") or "01/GTGT"
        tep = ts["hocmau"]
        them, loi_them = "", ""
        if ts.get("thumuc"):
            # GD73: to khai 01/GTGT da nop (XML HTKK / ZIP Cong thue) -> luu vao to khai luu tru, [43] tu dien vao [22] ky sau
            try:
                import tk_luu_tru
                ds, loi_them = tk_luu_tru.luu_tep(tep, ts.get("mst", ""), ts["thumuc"])
                them = tk_luu_tru.mo_ta_luu(ds) if ds else ""
            except Exception as e:
                ghi_log("[HOC] Khong luu duoc to khai: %s" % e)
        if _zipfile.is_zipfile(tep):
            # ZIP tai tu Cong thue: chi luu to khai (khong hoc khuon)
            _ket("DA_HOC " + them if them else "", "" if them else (loi_them or "Tệp ZIP không có tờ khai 01/GTGT."))
            return 0 if them else 1
        # to khai cua MST khac: van hoc khuon nhung bao ro khong dung so lieu
        if not them and loi_them.startswith("Tờ khai trong tệp"):
            them = loi_them
        khuon, loi = hoc_khuon(tep)
        if khuon is None:
            _ket("DA_HOC " + them if them and not loi_them else "", "" if them and not loi_them else loi)
            return 0 if them and not loi_them else 1
        luu_khuon(ma_tk, khuon, tep)
        # GD73: truoc day ghi thanh cong vao o LOI -> VB bao "Khong ket xuat duoc: DA_HOC 31 chi tieu cho 01/GTGT"
        _ket("DA_HOC %d chỉ tiêu cho %s.%s" % (len(khuon["chi_tieu"]), ma_tk, (" " + them) if them else ""), "")
        if loi:
            ghi_log("[HOC] Luu y: " + loi)
        return 0

    if ts.get("kiemtra"):
        bao, n = kiem_tra_tep(ts["kiemtra"], sua=("sua" in co), duong_ra=ts.get("ra"))
        if ts.get("cdtk"):
            b2, n2 = doi_chieu_cdtk(ts["kiemtra"], ts["cdtk"],
                                    ts.get("sheet") or "CDTK", int(ts.get("dongdau") or 12))
            bao = bao + "\n" + "-" * 62 + "\nDOI CHIEU VOI BANG CAN DOI TAI KHOAN\n" + b2
            n += n2
        tep = os.path.join(BASE_DIR, "ket-qua", "KIEM_TRA_HTKK.txt")
        try:
            os.makedirs(os.path.dirname(tep), exist_ok=True)
            with open(tep, "w", encoding="utf-8") as f:
                f.write(bao)
        except Exception:
            pass
        ghi_log("[KIEM TRA] %d diem phai sua -> %s" % (n, tep))
        try:
            print(bao)
        except Exception:
            pass
        _ket(tep if n == 0 else "", "" if n == 0 else "Co %d diem phai sua - xem %s" % (n, tep))
        return 0 if n == 0 else 1

    if ts.get("xuat1lan"):
        # GD78: xuat 1 lan (bao cao nam / bieu mau so sach TT133, Excel / XML HTKK) vao thu muc MOI - dung chung moc DA_XONG_KHOASO
        try:
            import xuat_1_lan
            d, loi = xuat_1_lan.chay(ts["xuat1lan"], ts.get("muc", ""), ts.get("kieu", "E"), ts.get("thumuc", ""), ghi_log)
        except Exception as e:
            import traceback
            ghi_log("[XUAT 1 LAN] loi: %s\n%s" % (e, traceback.format_exc()))
            d, loi = None, "Loi xuat 1 lan: %s" % e
            if isinstance(e, ImportError):  # GD318: noi ro thieu tep nao, o dau
                _t = getattr(e, "name", "") or "?"
                loi = ("Thieu tep %s.py trong thu muc %s - thu muc AIHoaDon cua may nay chua du tep. "
                       "Chep de thu muc AIHoaDon tu goi CAP_NHAT_GD318_AIHOADON_DAY_DU.zip roi lam lai." % (_t, os.path.dirname(os.path.abspath(__file__))))
        _ket_khoaso(d, loi)
        return 0 if d else 1

    if ts.get("hdexcel"):
        # GD102: Excel hoa don bat ky -> AI nhan dang cot -> mau bang ke chi tiet UNESCO (mau file 1) cho man hinh
        #   Hoa don mua vao / ban ra (Import Excel). Chi doc tep, khong ghi so - dung chung moc DA_XONG_KHOASO.
        try:
            import hd_excel_ai
            ra = ts.get("ra") or os.path.join(BASE_DIR, "ket-qua", "HD_Excel_AI_%s.xlsx" % datetime.now().strftime("%Y%m%d%H%M%S"))
            os.makedirs(os.path.dirname(ra), exist_ok=True)
            # GD108: /vaoai:1 /khach:<thu muc AI cua cong ty> -> them <ra>.jsonl dua vao danh sach AI
            d, loi = hd_excel_ai.chay(ts["hdexcel"], ts.get("huong", "mua"), ts.get("mst", ""), ra, ghi_log,
                                      vao_ai=ts.get("vaoai") == "1", khach=ts.get("khach", ""))
        except Exception as e:
            import traceback
            ghi_log("[HD EXCEL] loi: %s\n%s" % (e, traceback.format_exc()))
            d, loi = None, "Loi nhan dang Excel hoa don: %s" % e
        _ket_khoaso(d, loi)
        return 0 if d else 1

    if ts.get("tokhai"):
        # GD105: to khai hai quan nhap khau (Excel VNACCS / ECUS) -> tep ket qua cho man hinh To khai HQ (+ Excel phan tich
        #   phan bo neu co /excel). Chi doc tep, khong ghi so - dung chung moc DA_XONG_KHOASO ('OK <tep ket qua>').
        try:
            import hq_to_khai
            ra = ts.get("ra") or os.path.join(BASE_DIR, "ket-qua", "to_khai_%s.txt" % datetime.now().strftime("%Y%m%d%H%M%S"))
            os.makedirs(os.path.dirname(ra), exist_ok=True)
            ok = hq_to_khai.chay_cho_vb(ts["tokhai"], ra, ts.get("excel", ""), ts.get("chiphi", ""))
            ghi_log("[TO KHAI] %s -> %s%s" % (ts["tokhai"], "OK" if ok else "LOI", " + Excel " + ts.get("excel", "") if ok and ts.get("excel") else ""))
            d, loi = ra, None          # ket qua (ke ca LOI|...) nam trong tep ra - man hinh doc va bao
        except Exception as e:
            import traceback
            ghi_log("[TO KHAI] loi: %s\n%s" % (e, traceback.format_exc()))
            d, loi = None, "Loi doc to khai hai quan: %s" % e
        _ket_khoaso(d, loi)
        return 0 if d else 1

    if ts.get("bangluongdc"):
        # GD79: Excel doi chieu bang luong co cong thuc song (chi doc so) - dung chung moc DA_XONG_KHOASO
        try:
            import doi_chieu_luong
            d, loi = doi_chieu_luong.chay(ts["bangluongdc"], ts.get("ra", ""), ghi_log)
        except Exception as e:
            import traceback
            ghi_log("[DOI CHIEU LUONG] loi: %s\n%s" % (e, traceback.format_exc()))
            d, loi = None, "Loi lap Excel doi chieu bang luong: %s" % e
        _ket_khoaso(d, loi)
        return 0 if d else 1

    if ts.get("bhdc"):
        # GD134: Excel doi chieu BHXH hang thang (bang luong - TK BH - da nop) - chi doc - dung chung moc DA_XONG_KHOASO
        try:
            import doi_chieu_bhxh
            d, loi = doi_chieu_bhxh.chay(ts["bhdc"], ts.get("ra", ""), ghi_log)
        except Exception as e:
            import traceback
            ghi_log("[DOI CHIEU BHXH] loi: %s\n%s" % (e, traceback.format_exc()))
            d, loi = None, "Loi lap Excel doi chieu BHXH: %s" % e
        _ket_khoaso(d, loi)
        return 0 if d else 1

    if ts.get("congviec"):
        # GD137: Excel lich cong viec nam (Quan ly cong viec) - chi doc - dung chung moc DA_XONG_KHOASO
        try:
            import cong_viec
            d, loi = cong_viec.chay(ts["congviec"], ts.get("ra", ""), ghi_log)
        except Exception as e:
            import traceback
            ghi_log("[CONG VIEC] loi: %s\n%s" % (e, traceback.format_exc()))
            d, loi = None, "Loi lap Excel lich cong viec: %s" % e
        _ket_khoaso(d, loi)
        return 0 if d else 1

    if ts.get("kiemsoat"):
        # GD146: Excel kiem soat cong no & vat tu (trung ma, cong no lech, tra ho, am kho) - chi doc - moc DA_XONG_KHOASO
        try:
            import kiem_soat_dl
            d, loi = kiem_soat_dl.chay(ts["kiemsoat"], ts.get("ra", ""), ghi_log)
        except Exception as e:
            import traceback
            ghi_log("[KIEM SOAT] loi: %s\n%s" % (e, traceback.format_exc()))
            d, loi = None, "Loi lap Excel kiem soat: %s" % e
        _ket_khoaso(d, loi)
        return 0 if d else 1

    if ts.get("quantri"):
        # GD140: trang tong quan quan tri (HTML, bieu do SVG) - chi doc - dung chung moc DA_XONG_KHOASO
        try:
            import bao_cao_quan_tri
            d, loi = bao_cao_quan_tri.chay(ts["quantri"], ts.get("ra", ""), ghi_log)
        except Exception as e:
            import traceback
            ghi_log("[QUAN TRI] loi: %s\n%s" % (e, traceback.format_exc()))
            d, loi = None, "Loi lap trang tong quan quan tri: %s" % e
        _ket_khoaso(d, loi)
        return 0 if d else 1

    if ts.get("maunv") or ts.get("nhapnv") or ts.get("xuatnv"):
        # GD134: tep mau / doc danh sach nhan vien (tool khong ghi so; VB6 xem truoc, hoi roi them) - moc DA_XONG_KHOASO
        try:
            import nhan_vien_nhap
            if ts.get("nhapnv"):
                import tool_trich_xuat_so_phu as _CU
                d, loi = nhan_vien_nhap.chay_nhap(ts["nhapnv"], ts.get("dmnv", ""), ts.get("ra", ""), _CU.doc_excel, ghi_log)
            elif ts.get("xuatnv"):          # GD200: xuat danh sach nhan vien ra Excel
                d, loi = nhan_vien_nhap.chay_xuat(ts["xuatnv"], ts.get("ra", ""), ghi_log)
            else:
                d, loi = nhan_vien_nhap.chay_mau(ts["maunv"], ts.get("ra", ""), ghi_log)
        except Exception as e:
            import traceback
            ghi_log("[NHAP NV] loi: %s\n%s" % (e, traceback.format_exc()))
            d, loi = None, "Loi danh sach nhan vien: %s" % e
        _ket_khoaso(d, loi)
        return 0 if d else 1

    if ts.get("cdps"):
        # GD129: Bang can doi so phat sinh dung mau (so lieu QCdt cua mau in do VB doc) - chi doc - dung chung moc DA_XONG_KHOASO
        try:
            import bcdps_excel
            d, loi = bcdps_excel.chay(ts["cdps"], ts.get("ra", ""))
        except Exception as e:
            import traceback
            ghi_log("[CAN DOI SO PHAT SINH] loi: %s\n%s" % (e, traceback.format_exc()))
            d, loi = None, "Loi lap Excel bang can doi so phat sinh: %s" % e
        _ket_khoaso(d, loi)
        return 0 if d else 1

    if ts.get("baocaobs"):
        # GD70: bao cao bo sung TT133 (chi doc so) - dung chung moc DA_XONG_KHOASO
        loai = (ts.get("loai") or "ALL").upper()
        ra = ts.get("ra") or os.path.join(BASE_DIR, "ket-qua", "BaoCao_%s_%s.xlsx" % (loai, datetime.now().strftime("%Y%m%d%H%M%S")))
        try:
            import bao_cao_bo_sung
            d, loi = bao_cao_bo_sung.chay(loai, ts["baocaobs"], ra)
        except Exception as e:
            import traceback
            ghi_log("[BAO CAO BO SUNG] loi: %s\n%s" % (e, traceback.format_exc()))
            d, loi = None, "Loi lap Excel: %s" % e
        _ket_khoaso(d, loi)
        return 0 if d else 1

    if ts.get("bangkehd"):
        # GD76: bang ke hoa don mua vao / ban ra theo so (chi doc so) - dung chung moc DA_XONG_KHOASO
        loai = (ts.get("loai") or "MV").upper()
        ra = ts.get("ra") or os.path.join(BASE_DIR, "ket-qua", "BangKe_%s_%s.xlsx" % (loai, datetime.now().strftime("%Y%m%d%H%M%S")))
        try:
            import bang_ke_hd
            d, loi = bang_ke_hd.chay(loai, ts["bangkehd"], ra)
        except Exception as e:
            import traceback
            ghi_log("[BANG KE HD] loi: %s\n%s" % (e, traceback.format_exc()))
            d, loi = None, "Loi lap Excel: %s" % e
        _ket_khoaso(d, loi)
        return 0 if d else 1

    if ts.get("congkhach"):
        # GD293: cong cu khach - xuat goi DI / nap goi VE (cong_khach.py: CHI DOC so, khong ghi .MDB) - moc DA_XONG_KHOASO
        try:
            import cong_khach
            d, loi = cong_khach.chay_cli(sys.argv[1:], ghi_log)
        except Exception as e:
            import traceback
            ghi_log("[CONG KHACH] loi: %s\n%s" % (e, traceback.format_exc()))
            d, loi = None, "Loi cong cu khach: %s" % e
        _ket_khoaso(d, loi)
        return 0 if d else 1

    if ts.get("dieuhanh"):
        # GD154: bang dieu hanh khach hang - doc nhieu .MDB chi doc (jet_doc) - dung chung moc DA_XONG_KHOASO
        ra = ts.get("ra") or os.path.join(BASE_DIR, "ket-qua", "dieu_hanh.txt")
        try:
            import bang_dieu_hanh
            d, tom_tat = bang_dieu_hanh.chay(ts["dieuhanh"], ra, ghi_log)
            loi = ""
            ghi_log("[DIEU HANH] %d bo so: %d do, %d vang, %d xanh, %d tep loi" % (tom_tat["n"], tom_tat["do"], tom_tat["vang"], tom_tat["xanh"], tom_tat["loi"]))
        except Exception as e:
            import traceback
            ghi_log("[DIEU HANH] loi: %s\n%s" % (e, traceback.format_exc()))
            d, loi = None, "Loi lap bang: %s" % e
        _ket_khoaso(d, loi)
        return 0 if d else 1

    if ts.get("giathanhbc"):
        # GD161: bao cao kiem tra gia thanh (gia thanh so gia ban, ky nay so ky truoc) - chi doc - moc DA_XONG_KHOASO
        try:
            import gia_thanh_bc
            d, loi = gia_thanh_bc.chay(ts["giathanhbc"], ts.get("ra") or "")
        except Exception as e:
            import traceback
            ghi_log("[GIA THANH BC] loi: %s\n%s" % (e, traceback.format_exc()))
            d, loi = None, "Loi bao cao kiem tra gia thanh: %s" % e
        _ket_khoaso(d, loi)
        return 0 if d else 1

    if ts.get("thuechudn"):
        # GD160: thue TNDN du kien ca nam + kich ban, bao cao 1 trang cho chu doanh nghiep (chi doc, uoc tinh) - moc DA_XONG_KHOASO
        try:
            import thue_chu_dn
            d, loi = thue_chu_dn.chay(ts["thuechudn"], ts.get("ra") or "")
        except Exception as e:
            import traceback
            ghi_log("[THUE CHU DN] loi: %s\n%s" % (e, traceback.format_exc()))
            d, loi = None, "Loi thue du kien / bao cao chu doanh nghiep: %s" % e
        _ket_khoaso(d, loi)
        return 0 if d else 1

    if ts.get("phantichkd"):
        # GD159: lai theo mat hang / khach hang, ton kho thong minh (chi doc, uoc tinh) - dung chung moc DA_XONG_KHOASO
        try:
            import phan_tich_kd
            d, loi = phan_tich_kd.chay(ts["phantichkd"], ts.get("ra") or "")
        except Exception as e:
            import traceback
            ghi_log("[PHAN TICH KD] loi: %s\n%s" % (e, traceback.format_exc()))
            d, loi = None, "Loi phan tich kinh doanh: %s" % e
        _ket_khoaso(d, loi)
        return 0 if d else 1

    if ts.get("batthuong"):
        # GD157: phat hien bat thuong so lieu KS8 - KS12 (the Kiem soat) - chi doc - dung chung moc DA_XONG_KHOASO
        try:
            import bat_thuong
            d, loi = bat_thuong.chay(ts["batthuong"], ts.get("ra") or "")
        except Exception as e:
            import traceback
            ghi_log("[BAT THUONG] loi: %s\n%s" % (e, traceback.format_exc()))
            d, loi = None, "Loi phat hien bat thuong: %s" % e
        _ket_khoaso(d, loi)
        return 0 if d else 1

    if ts.get("dongtien"):
        # GD156: du bao dong tien 4-13 tuan (chi doc, uoc tinh) - dung chung moc DA_XONG_KHOASO
        ra = ts.get("ra") or os.path.join(BASE_DIR, "ket-qua", "DuBao_DongTien_%s.xlsx" % datetime.now().strftime("%Y%m%d%H%M%S"))
        try:
            import dong_tien
            d, loi = dong_tien.chay(ts["dongtien"], ra)
        except Exception as e:
            import traceback
            ghi_log("[DONG TIEN] loi: %s\n%s" % (e, traceback.format_exc()))
            d, loi = None, "Loi lap du bao: %s" % e
        _ket_khoaso(d, loi)
        return 0 if d else 1

    if ts.get("nhatkyai"):
        # GD155: nhat ky giai thich AI - "AI da lam gi thang nay" (chi doc) - dung chung moc DA_XONG_KHOASO
        ra = ts.get("ra") or os.path.join(BASE_DIR, "ket-qua", "NhatKy_AI_%s.xlsx" % datetime.now().strftime("%Y%m%d%H%M%S"))
        try:
            import nhat_ky_ai
            d, loi = nhat_ky_ai.chay(ts["nhatkyai"], ra)
        except Exception as e:
            import traceback
            ghi_log("[NHAT KY AI] loi: %s\n%s" % (e, traceback.format_exc()))
            d, loi = None, "Loi lap Excel: %s" % e
        _ket_khoaso(d, loi)
        return 0 if d else 1

    if ts.get("ruirohd"):
        # GD153: soat rui ro hoa don truoc ky khai (chi doc so, chi danh dau) - dung chung moc DA_XONG_KHOASO
        ra = ts.get("ra") or os.path.join(BASE_DIR, "ket-qua", "RuiRo_HD_%s.xlsx" % datetime.now().strftime("%Y%m%d%H%M%S"))
        try:
            import rui_ro_hd
            d, loi = rui_ro_hd.chay(ts["ruirohd"], ra)
        except Exception as e:
            import traceback
            ghi_log("[RUI RO HD] loi: %s\n%s" % (e, traceback.format_exc()))
            d, loi = None, "Loi lap Excel: %s" % e
        _ket_khoaso(d, loi)
        return 0 if d else 1

    if ts.get("dmnhap"):
        # GD213: nhan dang mot tep bang dinh muc / du toan (Excel, CSV, TXT, Word, HTML, PDF) -> tep ket qua cho VB6 ghi bang HDDT_DMNguon*
        try:
            import dinh_muc_nguon
            d = dinh_muc_nguon.nhap_tep(ts["dmnhap"], ts.get("ra") or os.path.join(BASE_DIR, "ket-qua", "dm_nhap_kq.txt"))
            loi = ""
        except Exception as e:
            import traceback
            ghi_log("[NHAP DINH MUC] loi: %s\n%s" % (e, traceback.format_exc()))
            d, loi = None, "Loi nhap bang dinh muc: %s" % e
        _ket_khoaso(d, loi)
        return 0 if d else 1

    if ts.get("thumua"):
        # GD220: /thumua:<json> /ra:<txt> [/xlsx:<xlsx>] -> lap ke hoach thu mua tu bang ke ban ra (thu_mua_tu_ban.py)
        try:
            import thu_mua_tu_ban
            ra = ts.get("ra") or os.path.join(BASE_DIR, "ket-qua", "thumua_kq.txt")
            d, loi = thu_mua_tu_ban.chay(ts["thumua"], ra, ts.get("xlsx") or ""), ""
            d = ra
        except Exception as e:
            import traceback
            ghi_log("[THU MUA] loi: %s\n%s" % (e, traceback.format_exc()))
            d, loi = None, "Loi lap thu mua: %s" % e
        _ket_khoaso(d, loi)
        return 0 if d else 1

    if ts.get("tcmst"):
        # GD212: /tcmst:ma /ra:<thu muc> -> anh ma xac nhan (BMP) ; /tcmst:tra /tep:<yeu cau> /ra:<ket qua>. Phan mem KHONG doc ma
        #   xac nhan - nguoi dung go tren man hinh VB6 (quy tac 17). Moc DA_XONG_KHOASO "OK <tep>" / "LOI ...".
        try:
            import tra_cuu_mst
            if ts["tcmst"] == "phien":           # GD214: mot phien song suot luc tra cuu (giu ket noi + cookie), lenh qua tep
                return tra_cuu_mst.phien(ts.get("ra") or os.path.join(BASE_DIR, "ket-qua"))
            if ts["tcmst"] == "ma":
                d, loi = tra_cuu_mst.lay_ma(ts.get("ra") or os.path.join(BASE_DIR, "ket-qua"))
            else:
                d, _ = tra_cuu_mst.tra(ts.get("tep", ""), ts.get("ra") or os.path.join(BASE_DIR, "ket-qua", "tcmst_kq.txt"))
                loi = ""
        except Exception as e:
            import traceback
            ghi_log("[TRA CUU MST] loi: %s\n%s" % (e, traceback.format_exc()))
            d, loi = None, "Loi tra cuu MST: %s" % e
        _ket_khoaso(d, loi)
        return 0 if d else 1

    if ts.get("docnnt"):
        # GD153: doc ket qua tra cuu nguoi nop thue nguoi dung DAN (khong tra cuu thay, khong vuot captcha - quy tac 17)
        ra = ts.get("ra") or os.path.join(BASE_DIR, "ket-qua", "nnt_doc.txt")
        try:
            import rui_ro_hd
            d, n = rui_ro_hd.doc_nnt(ts["docnnt"], ra)
            loi = ""
        except Exception as e:
            import traceback
            ghi_log("[DOC NNT] loi: %s\n%s" % (e, traceback.format_exc()))
            d, loi = None, "Loi doc tep dan: %s" % e
        _ket_khoaso(d, loi)
        return 0 if d else 1

    if ts.get("doichieuhd"):
        # GD69: doi chieu hoa don dien tu voi so theo tung hoa don (chi doc so) - dung chung moc DA_XONG_KHOASO
        ra = ts.get("ra") or os.path.join(BASE_DIR, "ket-qua", "DoiChieu_HDDT_%s.xlsx" % datetime.now().strftime("%Y%m%d%H%M%S"))
        try:
            import doi_chieu_hd
            d, loi = doi_chieu_hd.chay(ts["doichieuhd"], ra)
        except Exception as e:
            import traceback
            ghi_log("[DOI CHIEU HDDT] loi: %s\n%s" % (e, traceback.format_exc()))
            d, loi = None, "Loi lap Excel: %s" % e
        _ket_khoaso(d, loi)
        return 0 if d else 1

    if ts.get("kiemkhoaso") or ts.get("uoctndn"):
        # GD66: kiem tra truoc khoa so / uoc tinh thue TNDN nam (chi doc so)
        loai = "tndn" if ts.get("uoctndn") else "khoaso"
        tep = ts.get("uoctndn") or ts.get("kiemkhoaso")
        ra = ts.get("ra") or os.path.join(BASE_DIR, "ket-qua", "%s_%s.xlsx" % ("UocTinh_TNDN" if loai == "tndn" else "KiemTra_KhoaSo",
                                                                               datetime.now().strftime("%Y%m%d%H%M%S")))
        try:
            import kiem_khoa_so
            d, loi = kiem_khoa_so.chay(loai, tep, ra)
        except Exception as e:
            import traceback
            ghi_log("[KHOA SO] loi: %s\n%s" % (e, traceback.format_exc()))
            d, loi = None, "Loi lap Excel: %s" % e
        _ket_khoaso(d, loi)
        return 0 if d else 1

    if ts.get("sohdts"):
        # GD87: so chi tiet theo hoa don CCDC (153) / chi phi tra truoc (242) / TSCD (211, 2411) / khau hao (214) - chi doc so,
        #   Excel (so_hd_tai_san.py) - dung chung moc DA_XONG_KHOASO (khong chay dong thoi voi cac che do khac)
        tep = ts["sohdts"]
        ra = ts.get("ra") or os.path.join(BASE_DIR, "ket-qua", "SoChiTiet_HD_CCDC_242_TSCD_%s.xlsx" % datetime.now().strftime("%Y%m%d%H%M%S"))
        try:
            import so_hd_tai_san
            d, loi = so_hd_tai_san.lap(tep, ra)
            if d and loi:
                ghi_log("[SO HD TAI SAN] " + loi)
                loi = ""
        except Exception as e:
            import traceback
            ghi_log("[SO HD TAI SAN] loi: %s\n%s" % (e, traceback.format_exc()))
            d, loi = None, "Loi lap Excel: %s" % e
        _ket_khoaso(d, loi)
        return 0 if d else 1

    if ts.get("ketchuyen"):
        # GD86: checklist "Ket chuyen cuoi ky" (CCDC/242, Khau hao TSCD, Trich luong + KC 911) - chi doc so,
        #   JSON cho luoi VB6 (khong phai Excel) - dung chung moc DA_XONG_KHOASO (khong chay dong thoi voi cac che do khac)
        tep = ts["ketchuyen"]
        ra = ts.get("ra") or os.path.join(BASE_DIR, "ket-qua", "KetChuyen_%s.txt" % datetime.now().strftime("%Y%m%d%H%M%S"))
        try:
            import kiem_khoa_so
            d, loi = kiem_khoa_so.chay_ket_chuyen(tep, ra)
        except Exception as e:
            import traceback
            ghi_log("[KET CHUYEN] loi: %s\n%s" % (e, traceback.format_exc()))
            d, loi = None, "Loi lap JSON: %s" % e
        _ket_khoaso(d, loi)
        return 0 if d else 1

    if ts.get("xemtruoc"):
        # GD59: Excel xem truoc (khong can HTKK, khong chan tu kiem)
        try:
            with open(ts["xemtruoc"], "r", encoding="utf-8-sig") as f:
                dl = json.loads(f.read(), strict=False)
        except Exception as e:
            _ket_xemtruoc("", "Khong doc duoc file so lieu: %s" % e)
            return 1
        try:
            dl2, ct, pl = _chuan_bi_01gtgt(dl)
            ra = ts.get("ra") or os.path.join(BASE_DIR, "ket-qua", "XemTruoc_01GTGT_%s.xlsx" % datetime.now().strftime("%Y%m%d%H%M%S"))
            d, loi = lap_excel_01gtgt(dl2, ct, pl, ra, xem_truoc=True)
        except Exception as e:
            d, loi = None, "Loi lap Excel: %s" % e
        _ket_xemtruoc(d, loi)
        return 0 if d else 1

    if ts.get("xuat"):
        try:
            with open(ts["xuat"], "r", encoding="utf-8-sig") as f:
                dl = json.loads(f.read(), strict=False)
        except Exception as e:
            _ket("", "Khong doc duoc file so lieu: %s" % e)
            return 1
        ma_tk = ts.get("matk") or dl.get("ma_tkhai") or "01/GTGT"
        don_json_tam()          # GD162
        ra = ts.get("ra") or os.path.join(BASE_DIR, "htkk",
                                          "%s_%s.xml" % (ma_tk.replace("/", "_"),
                                                         datetime.now().strftime("%Y%m%d%H%M%S")))
        if ma_tk.upper().replace(" ", "").startswith("01/GTGT") and not ts.get("mau"):
            # GD56: khuon lay thang tu HTKK tren may (khong co thi dung khuon da hoc)
            duong, loi, bao = xuat_01gtgt(dl, ra, ts.get("htkk", ""), bo_qua_tu_kiem=("boquatukiem" in co))
            if duong:
                bao = (bao or "") + _dua_vao_htkk_01(duong, ts)
            if bao:
                try:
                    tep = os.path.join(BASE_DIR, "ket-qua", "XUAT_HTKK.txt")
                    os.makedirs(os.path.dirname(tep), exist_ok=True)
                    with open(tep, "w", encoding="utf-8") as f:
                        f.write(bao)
                except Exception:
                    pass
                try:
                    print(bao)
                except Exception:
                    pass
        else:
            duong, loi = xuat_xml(ma_tk, dl, ra, ts.get("mau"), bo_qua_tu_kiem=("boquatukiem" in co))
        if duong is None:
            _ket("", loi)
            return 1
        _ket(duong, "")
        if "mohtkk" in co:
            try:
                import htkk_dua_vao as DV
                DV.mo_htkk_theo_mst(tim_htkk(ts.get("htkk", "")), ts.get("mst", ""), 90, ghi_log)
            except Exception:
                mo_htkk(tim_htkk(ts.get("htkk", "")))
        return 0

    print(__doc__)
    return 0


def _dua_vao_htkk_01(duong, ts):
    """GD122: 01/GTGT vua ket xuat -> dua THANG vao HTKK (khong ghi de to khai HTKK dang co) -> dong bao cao them."""
    try:
        import htkk_dua_vao as DV
        if not DV.bat():
            return ""
        h = tim_htkk(ts.get("htkk", ""))
        k = DV.dua_vao(duong, ts.get("mst", ""), (h or {}).get("goc", ""), False, log=ghi_log)
        DV.ghi_cho_ghi_de([k])
        return "\n\nĐƯA VÀO HTKK (bấm Mở HTKK - tự đăng nhập MST, mở tờ khai đúng kỳ là thấy số, không cần Nhập XML):\n" + \
            "\n".join(DV.mo_ta(k)) + "\n"
    except Exception as e:
        ghi_log("[DUA VAO HTKK] 01/GTGT loi: %s" % e)
        return "\n\nĐƯA VÀO HTKK: lỗi %s - dùng Nhập XML trong HTKK.\n" % e


def _ket_khoaso(duong, loi):
    """GD66: moc cho VB6 (HDDT_KS_Excel): 'OK <xlsx>' hoac 'LOI <mo ta>'."""
    kq = os.path.join(BASE_DIR, "ket-qua")
    try:
        os.makedirs(kq, exist_ok=True)
        with open(os.path.join(kq, "DA_XONG_KHOASO"), "w", encoding="utf-8") as f:
            f.write(("OK " + duong) if duong else ("LOI " + (loi or "khong ro")))
    except Exception:
        pass
    if loi:
        ghi_log("KET QUA KHOA SO: " + loi)


def _ket(duong, loi):
    """Ghi co ket cho VB6 doc: dong dau la duong file XML, hoac 'LOI <mo ta>'."""
    kq = os.path.join(BASE_DIR, "ket-qua")
    try:
        os.makedirs(kq, exist_ok=True)
        with open(os.path.join(kq, "DA_XONG_HTKK"), "w", encoding="utf-8") as f:
            f.write(duong if duong else ("LOI " + (loi or "khong ro")))
    except Exception:
        pass
    if loi:
        ghi_log("KET QUA: " + loi)


if __name__ == "__main__":
    # GD63: loi bat ngo (tep XML dang mo trong HTKK / Excel...) -> VAN ghi moc DA_XONG_* de VB6 khong cho mai
    try:
        _ma_thoat = main()
    except Exception as _e:
        import traceback
        ghi_log("LOI NGHIEM TRONG: %s\n%s" % (_e, traceback.format_exc()))
        try:
            _xt = any(str(a).lower().startswith("/xemtruoc:") for a in mo_rong_tham_so(sys.argv[1:]))
        except Exception:
            _xt = False
        try:
            _ks = any(str(a).lower().startswith(("/kiemkhoaso:", "/uoctndn:", "/doichieuhd:", "/ruirohd:", "/docnnt:", "/dieuhanh:", "/nhatkyai:", "/dongtien:", "/batthuong:", "/phantichkd:", "/thuechudn:", "/giathanhbc:", "/baocaobs:", "/bangkehd:", "/xuat1lan:", "/bangluongdc:", "/ketchuyen:", "/sohdts:", "/hdexcel:", "/tokhai:", "/duavaohtkk:", "/cdps:", "/namtruoc:")) or str(a).lower().startswith(("/hosoct:", "/nhanct:", "/dinhmucai:", "/bhdc:", "/maunv:", "/nhapnv:", "/xuatnv:", "/congviec:", "/quantri:", "/kiemsoat:", "/nguonkt:", "/sosanhhtkk:", "/nhaphtkk:", "/maumoi:", "/nokhodoi:", "/khoathang:", "/hlds:", "/xuatthang:", "/nghiepvu:")) or str(a).lower().startswith("/nopdvc:") or str(a).lower().startswith(("/tcmst:", "/dmnhap:", "/thumua:", "/congkhach:"))          # GD185; GD212; GD213
                      for a in mo_rong_tham_so(sys.argv[1:]))          # GD134
        except Exception:
            _ks = False
        if _xt:
            _ket_xemtruoc("", "Loi tool: %s" % _e)
        elif _ks:
            _ket_khoaso("", "Loi tool: %s" % _e)
        else:
            _ket("", "Loi tool: %s" % _e)
        _ma_thoat = 1
    try:                                      # GD170: sau viec lien quan HTKK -> quet mau to khai moi (im lang, chi doc Menu.xml)
        import htkk_mau_moi as _HM
        _HM.quet_sau_tool(sys.argv[1:], tim_htkk, BASE_DIR, ghi_log, mo_rong_tham_so)
    except Exception:
        pass
    sys.exit(_ma_thoat)
