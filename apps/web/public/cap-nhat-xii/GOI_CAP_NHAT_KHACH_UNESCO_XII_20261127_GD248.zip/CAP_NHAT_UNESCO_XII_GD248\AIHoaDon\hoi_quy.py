# -*- coding: utf-8 -*-
"""GD248 - BO SO CHUAN (hoi quy): moi lan Kiem tra truoc khoa so, luu so lieu vao + ket qua cua bo so vao
   AIHoaDon\\hoi-quy\\<ten so>_<ma>\\lan_cuoi.json. Khi anh da xac nhan so dung: `python hoi_quy.py chot` (chot lan cuoi cua
   MOI so thanh chuan.json) hoac `chot <thu muc so>`. Moi goi moi: `python hoi_quy.py chay` -> chay lai kiem_khoa_so tren
   moi chuan.json, so muc (LOI / CANH_BAO / DAT / THONG_TIN) tung ma voi ket qua da chot -> hoi-quy\\bao_cao.txt, ma tra ve 1
   khi ma LOI CUNG (K01-K37, tinh thuan tu so lieu) doi muc; ma MEM (K38+, phu thuoc tep tren may) chi canh bao.
   Chi doc .json, khong dong vao bo so."""
import io
import json
import os
import sys
import datetime as _dt

HERE = os.path.dirname(os.path.abspath(__file__))
GOC = os.path.join(HERE, "hoi-quy")
MA_MEM_TU = 38            # K38 tro len: ket qua phu thuoc tep tren may (tram_ky, ds-cqt, giai trinh, chinh sach...)


def _thu_muc_so(dl):
    duong = (dl or {}).get("duong_so") or ""
    try:
        import chinh_sach_so
        if duong:
            tm, _ = chinh_sach_so._thu_muc_ra(duong, tao=False)
            return os.path.join(GOC, os.path.basename(tm))
    except Exception:
        pass
    mst = ((dl or {}).get("cty") or {}).get("mst") or "so"
    return os.path.join(GOC, "".join(c for c in str(mst) if c.isalnum()) or "so")


def _tom_tat(kq):
    return {k["ma"]: k["muc"] for k in kq or []}


def luu_lan_cuoi(dl, kq, luc=None):
    """Goi tu kiem_khoa_so.lap_excel_khoa_so. Tra duong tep hoac ""."""
    try:
        tm = _thu_muc_so(dl)
        os.makedirs(tm, exist_ok=True)
        p = os.path.join(tm, "lan_cuoi.json")
        with io.open(p, "w", encoding="utf-8") as f:
            json.dump({"luc": luc or _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "ky": (dl.get("ky") or {}),
                       "cty": (dl.get("cty") or {}), "kq": _tom_tat(kq), "dl": dl}, f, ensure_ascii=False)
        return p
    except Exception:
        return ""


def _ds_so(chi=None):
    if not os.path.isdir(GOC):
        return []
    out = []
    for d in sorted(os.listdir(GOC)):
        p = os.path.join(GOC, d)
        if os.path.isdir(p) and (chi is None or os.path.normcase(os.path.abspath(chi)) == os.path.normcase(os.path.abspath(p)) or chi == d):
            out.append(p)
    return out


def chot(chi=None):
    """lan_cuoi.json -> chuan.json (giu ban cu thanh chuan_truoc.json). -> [(thu muc, ok, ghi chu)]"""
    kq = []
    for p in _ds_so(chi):
        a, b = os.path.join(p, "lan_cuoi.json"), os.path.join(p, "chuan.json")
        if not os.path.isfile(a):
            kq.append((p, False, "chua co lan_cuoi.json (chua Kiem tra truoc khoa so)"))
            continue
        try:
            if os.path.isfile(b):
                os.replace(b, os.path.join(p, "chuan_truoc.json"))
            with io.open(a, encoding="utf-8") as f:
                d = json.load(f)
            d["chot_luc"] = _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            with io.open(b, "w", encoding="utf-8") as f:
                json.dump(d, f, ensure_ascii=False)
            kq.append((p, True, "da chot ky %s - %s, %d ma" % ((d.get("ky") or {}).get("tu", ""), (d.get("ky") or {}).get("den", ""), len(d.get("kq") or {}))))
        except Exception as e:
            kq.append((p, False, "loi: %s" % e))
    return kq


def _so_ma(ma):
    try:
        return int(str(ma)[1:3])
    except Exception:
        return 0


def so_sanh(cu, moi):
    """-> (cung: [[ma, cu, moi]], mem: [[ma, cu, moi]])"""
    cung, mem = [], []
    for ma in sorted(set(cu) | set(moi)):
        a, b = cu.get(ma, "(không có)"), moi.get(ma, "(không có)")
        if a == b:
            continue
        (mem if _so_ma(ma) >= MA_MEM_TU else cung).append([ma, a, b])
    return cung, mem


def chay(chi=None, ghi=True):
    """Chay lai kiem_tra tren moi chuan.json. -> (so loi cung, bao cao text)"""
    import kiem_khoa_so as K
    dong = ["BAO CAO HOI QUY BO SO CHUAN - %s" % _dt.datetime.now().strftime("%d/%m/%Y %H:%M"), ""]
    n_so = n_loi = n_mem = 0
    for p in _ds_so(chi):
        b = os.path.join(p, "chuan.json")
        if not os.path.isfile(b):
            continue
        n_so += 1
        try:
            with io.open(b, encoding="utf-8") as f:
                d = json.load(f)
            _, kq = K.kiem_tra(d["dl"])
            cung, mem = so_sanh(d.get("kq") or {}, _tom_tat(kq))
        except Exception as e:
            n_loi += 1
            dong.append("[LOI] %s: khong chay duoc: %s" % (os.path.basename(p), e))
            continue
        ten = ((d.get("cty") or {}).get("ten") or os.path.basename(p))
        ky = d.get("ky") or {}
        if not cung and not mem:
            dong.append("[OK ] %s (%s - %s): khop %d ma" % (ten, ky.get("tu", ""), ky.get("den", ""), len(d.get("kq") or {})))
            continue
        if cung:
            n_loi += 1
        n_mem += len(mem)
        dong.append("[%s] %s (%s - %s): %d ma cung doi, %d ma mem doi" % ("LOI" if cung else "MEM", ten, ky.get("tu", ""), ky.get("den", ""), len(cung), len(mem)))
        for ma, a, c in cung:
            dong.append("      CUNG %s: %s -> %s" % (ma, a, c))
        for ma, a, c in mem:
            dong.append("      mem  %s: %s -> %s" % (ma, a, c))
    dong.append("")
    dong.append("Tong: %d bo so chuan, %d bo co ma cung doi, %d ma mem doi." % (n_so, n_loi, n_mem))
    if n_so == 0:
        dong.append("Chua co bo so chuan nao: chay Kiem tra truoc khoa so tren so da xac nhan dung, roi `python hoi_quy.py chot`.")
    bc = "\n".join(dong)
    if ghi:
        try:
            os.makedirs(GOC, exist_ok=True)
            with io.open(os.path.join(GOC, "bao_cao.txt"), "w", encoding="utf-8") as f:
                f.write(bc + "\n")
        except Exception:
            pass
    return n_loi, bc


def danh_sach():
    out = []
    for p in _ds_so():
        co = {t: os.path.isfile(os.path.join(p, t + ".json")) for t in ("lan_cuoi", "chuan")}
        luc = ""
        if co["chuan"]:
            try:
                with io.open(os.path.join(p, "chuan.json"), encoding="utf-8") as f:
                    luc = json.load(f).get("chot_luc", "")
            except Exception:
                pass
        out.append((os.path.basename(p), co["lan_cuoi"], co["chuan"], luc))
    return out


if __name__ == "__main__":
    lenh = sys.argv[1] if len(sys.argv) > 1 else "chay"
    arg = sys.argv[2] if len(sys.argv) > 2 else None
    if lenh == "chot":
        for p, ok, gc in chot(arg):
            print("%s %s: %s" % ("OK " if ok else "BO ", os.path.basename(p), gc))
    elif lenh == "ds":
        for ten, lc, ch, luc in danh_sach():
            print("%-40s lan_cuoi=%s chuan=%s %s" % (ten, "co" if lc else "-", "co" if ch else "-", luc))
    else:
        n, bc = chay(arg)
        print(bc)
        sys.exit(1 if n else 0)
