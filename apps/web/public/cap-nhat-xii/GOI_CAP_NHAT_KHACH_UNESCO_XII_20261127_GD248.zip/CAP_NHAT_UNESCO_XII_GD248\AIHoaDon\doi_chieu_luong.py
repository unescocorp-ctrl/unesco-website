# -*- coding: utf-8 -*-
"""GD79 - EXCEL DOI CHIEU BANG LUONG (so tinh co CONG THUC SONG de ke toan tu kiem soat).

VB (ModHDDTSoPhu.HDDT_BL_XuatExcelDC) ghi JSON so lieu mot ky bang luong da Import (HDDT_BL_Ky / HDDT_BL_Dong) + so lieu so
ke toan cua thang (Co 334, No 334, chi luong, Co 338x, Co 3335, bang luong cua phan mem) roi goi:
    tool_htkk_unesco.py /bangluongdc:<json> /ra:<xlsx>
Tep Excel gom cac sheet:
  TongHop        - kiem tra cong bang luong, doi chieu so ke toan, tong hop theo bo phan, KET LUAN (cong thuc).
  BangLuong      - tung dong: so theo bang luong + cot TINH LAI bang cong thuc + cot LECH (to do khi lech).
  TrichTheoLuong - BH / KPCD doanh nghiep phai trich (tinh lai theo ty le o ThamSo) + BH nguoi lao dong.
  DoiChieuNV     - thuc linh / thu nhap tung nhan vien: tep Excel vs bang luong trong phan mem.
  ThamSo         - ty le BH, tran dong BH, giam tru gia canh, bieu thue luy tien, sai so (SUA DUOC - moi cong thuc tinh lai).
  BaoCao         - bao cao doi chieu dang chu cua phan mem.
Moi o cong thuc co kem gia tri Python da tinh (xem truoc van thay so); Excel tinh lai khi mo. Python chuan, khong thu vien ngoai.
Chi DOC so lieu - khong ghi so ke toan.
"""
import datetime as _dt
import json
import os
import re
from decimal import Decimal, ROUND_HALF_UP

from xlsx_viet import SoExcel, CT, Chu, SO_TIEN, dia_chi

PHIEN_BAN = "GD79"


# ------------------------------------------------------------------ so hoc (giong Excel ROUND: nua ra xa so 0)
def D(x):
    if isinstance(x, Decimal):
        return x
    if x is None or x == "":
        return Decimal(0)
    if isinstance(x, bool):
        return Decimal(int(x))
    if isinstance(x, int):
        return Decimal(x)
    try:
        return Decimal(repr(float(x)))
    except (TypeError, ValueError):
        return Decimal(0)


def R(x):
    """ROUND(x, 0) cua Excel."""
    x = D(x)
    q = abs(x).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    return int(q if x >= 0 else -q)


def so(v):
    """gia tri so tu JSON (so nguyen giu int, so le giu float)."""
    if v is None or v == "":
        return 0
    if isinstance(v, bool):
        return int(v)
    if isinstance(v, (int, float)):
        return int(v) if float(v).is_integer() else float(v)
    try:
        f = float(str(v).replace(",", ""))
        return int(f) if f.is_integer() else f
    except ValueError:
        return 0


def N(x):
    """Decimal -> int / float de ghi o (gia tri cache)."""
    x = D(x)
    return int(x) if x == x.to_integral_value() else float(x)


# ------------------------------------------------------------------ tham so theo ky
def so_thang(thang):
    thang = int(thang or 0)
    if thang == 0:
        return 12
    if thang > 100:
        tu, den = thang // 100, thang % 100
        return max(1, den - tu + 1)
    return 1


def thang_cuoi(thang):
    thang = int(thang or 0)
    if thang == 0:
        return 12
    if thang > 100:
        return max(1, min(12, thang % 100))
    return max(1, min(12, thang))


def luong_co_so(ngay):
    """muc luong co so (tran BHXH / BHYT = 20 lan). NĐ 161/2026 (tu 01/07/2026), NĐ 73/2024 (01/07/2024)..."""
    for tu, v, cc in ((_dt.date(2026, 7, 1), 2530000, "Nghị định 161/2026/NĐ-CP (từ 01/07/2026)"),
                      (_dt.date(2024, 7, 1), 2340000, "Nghị định 73/2024/NĐ-CP (từ 01/07/2024)"),
                      (_dt.date(2023, 7, 1), 1800000, "Nghị định 24/2023/NĐ-CP (từ 01/07/2023)"),
                      (_dt.date(2019, 7, 1), 1490000, "Nghị định 38/2019/NĐ-CP (từ 01/07/2019)")):
        if ngay >= tu:
            return v, cc
    return 1390000, "Nghị định 72/2018/NĐ-CP"


def luong_toi_thieu_vung1(ngay):
    """luong toi thieu vung I (tran BHTN = 20 lan) - vung khac sua o ThamSo."""
    for tu, v, cc in ((_dt.date(2026, 1, 1), 5310000, "Nghị định 293/2025/NĐ-CP (từ 01/01/2026)"),
                      (_dt.date(2024, 7, 1), 4960000, "Nghị định 74/2024/NĐ-CP (từ 01/07/2024)"),
                      (_dt.date(2022, 7, 1), 4680000, "Nghị định 38/2022/NĐ-CP (từ 01/07/2022)"),
                      (_dt.date(2020, 1, 1), 4420000, "Nghị định 90/2019/NĐ-CP (từ 01/01/2020)")):
        if ngay >= tu:
            return v, cc
    return 4180000, "Nghị định 157/2018/NĐ-CP"


def tham_so_tncn(nam):
    """giam tru gia canh + bieu luy tien (nguong THANG, thue suat %) - cung nguon voi qtt_tncn (05/QTT-TNCN)."""
    try:
        import qtt_tncn
        t = qtt_tncn.tham_so_nam(int(nam))
        return {"gt_ban_than": t["gt_ban_than"], "gt_npt": t["gt_npt"], "bac": list(t["bac"]), "can_cu": t.get("can_cu", "")}
    except Exception:
        bay = [(5000000, 5), (10000000, 10), (18000000, 15), (32000000, 20), (52000000, 25), (80000000, 30), (None, 35)]
        if int(nam) >= 2026:
            return {"gt_ban_than": 15500000, "gt_npt": 6200000,
                    "bac": [(10000000, 5), (30000000, 10), (60000000, 20), (100000000, 30), (None, 35)],
                    "can_cu": "Luật Thuế TNCN 109/2025/QH15, Nghị quyết 110/2025/UBTVQH15"}
        return {"gt_ban_than": 11000000, "gt_npt": 4400000, "bac": bay, "can_cu": "Nghị quyết 954/2020/UBTVQH14"}


# ------------------------------------------------------------------ cot sheet BangLuong
# (khoa, tieu de, loai)  loai: t = chu, n = so theo bang, c = cong thuc tinh lai, l = lech (to do), y = lech tham khao (to vang), g = ghi chu
COT_BL = [
    ("stt", "STT", "t"), ("dong", "Dòng trên tệp", "t"), ("ma_nv", "Mã NV", "t"), ("ten", "Họ tên trên bảng lương", "t"),
    ("ten_dm", "Tên trong danh mục NV", "t"), ("bo_phan", "Bộ phận", "t"), ("chuc_vu", "Chức vụ", "t"), ("ngay_cong", "Ngày công", "n"),
    ("luong_cb", "Lương cơ bản", "n"), ("luong_chinh", "Lương chính (theo công)", "n"), ("phu_cap", "Phụ cấp", "n"),
    ("tn_khac", "Thu nhập khác (thưởng, làm thêm…)", "n"), ("tong_tn", "Tổng thu nhập - theo bảng", "n"),
    ("tn_tl", "Tổng thu nhập - tính lại", "c"), ("tn_lech", "Lệch thu nhập", "l"),
    ("luong_dong_bh", "Lương đóng BH - theo bảng", "n"), ("ltbh", "Lương tính BH", "c"),
    ("bhxh_nv", "BHXH NLĐ - bảng", "n"), ("bhyt_nv", "BHYT NLĐ - bảng", "n"), ("bhtn_nv", "BHTN NLĐ - bảng", "n"),
    ("bh", "Cộng BH NLĐ - bảng", "c"), ("bh_tl", "BH NLĐ - tính lại", "c"), ("bh_lech", "Lệch BH NLĐ", "y"),
    ("thue", "Thuế TNCN - bảng", "n"), ("tn_chiu_thue", "TN chịu thuế - bảng", "n"), ("tnct", "TN chịu thuế dùng tính", "c"),
    ("so_npt", "Số người phụ thuộc", "n"), ("giam_tru_gc", "Giảm trừ gia cảnh - bảng", "n"), ("gt", "Giảm trừ gia cảnh dùng tính", "c"),
    ("tn_tinh_thue", "TN tính thuế - bảng", "n"), ("tntt", "TN tính thuế - tính lại", "c"), ("thue_tl", "Thuế TNCN - tính lại", "c"),
    ("thue_lech", "Lệch thuế TNCN", "y"), ("tam_ung", "Tạm ứng", "n"), ("tru_khac", "Trừ khác (đoàn phí…)", "n"),
    ("kt", "Tổng khấu trừ", "c"), ("thuc_linh", "Thực lĩnh - theo bảng", "n"), ("tl_tl", "Thực lĩnh - tính lại", "c"),
    ("tl_lech", "Lệch thực lĩnh", "l"), ("ghi_chu", "Ghi chú đối chiếu của phần mềm", "g"), ("nguon", "Sheet / tệp nguồn", "g"),
]
C = {k: i + 1 for i, (k, _, _) in enumerate(COT_BL)}          # khoa -> so cot (1..)
SO = {k: "(%d)" % C[k] for k in C}


def L(k):
    """chu cot cua khoa."""
    return dia_chi(1, C[k])[:-1]


GIAI_THICH = {
    "tn_tl": "= %s nếu có, không có thì %s; + %s + %s" % (SO["luong_chinh"], SO["luong_cb"], SO["phu_cap"], SO["tn_khac"]),
    "tn_lech": "= %s - %s" % (SO["tong_tn"], SO["tn_tl"]),
    "ltbh": "= %s nếu có, không có thì theo ô Căn cứ đóng BH (ThamSo)" % SO["luong_dong_bh"],
    "bh": "= %s + %s + %s" % (SO["bhxh_nv"], SO["bhyt_nv"], SO["bhtn_nv"]),
    "bh_tl": "= %s (không quá trần) × 8%% + 1,5%% + 1%%, làm tròn từng khoản" % SO["ltbh"],
    "bh_lech": "= %s - %s (tham khảo)" % (SO["bh"], SO["bh_tl"]),
    "tnct": "= %s nếu có, không có thì %s" % (SO["tn_chiu_thue"], SO["tong_tn"]),
    "gt": "= %s nếu có, không có thì (bản thân + %s × NPT) × số tháng" % (SO["giam_tru_gc"], SO["so_npt"]),
    "tntt": "= MAX(0; %s - %s - %s)" % (SO["tnct"], SO["bh"], SO["gt"]),
    "thue_tl": "= biểu lũy tiến từng phần (ThamSo) áp cho %s" % SO["tntt"],
    "thue_lech": "= %s - %s (tham khảo)" % (SO["thue"], SO["thue_tl"]),
    "kt": "= %s + %s + %s + %s" % (SO["bh"], SO["thue"], SO["tam_ung"], SO["tru_khac"]),
    "tl_tl": "= %s - %s" % (SO["tong_tn"], SO["kt"]),
    "tl_lech": "= %s - %s" % (SO["thuc_linh"], SO["tl_tl"]),
}


# ------------------------------------------------------------------ mo hinh tinh (giong het cong thuc Excel)
class ThamSo(object):
    def __init__(self, ky, dong):
        th = int(ky.get("thang") or 0)
        nam = int(ky.get("nam") or _dt.date.today().year)
        self.nam = nam
        self.n = so_thang(th)
        tc = thang_cuoi(th)
        ngay = _dt.date(nam, tc, 1)
        self.lcs, self.cc_lcs = luong_co_so(ngay)
        self.lttv, self.cc_lttv = luong_toi_thieu_vung1(ngay)
        # tran BH cua ky = 20 x muc cua TUNG thang (ky ca nam 2026: 6 thang 2,34 tr + 6 thang 2,53 tr)
        if th == 0:
            ds = list(range(1, 13))
        elif th > 100:
            ds = list(range(max(1, th // 100), min(12, th % 100) + 1)) or [tc]
        else:
            ds = [tc]
        self.lcs_thang = [luong_co_so(_dt.date(nam, m, 1))[0] for m in ds]
        self.lttv_thang = [luong_toi_thieu_vung1(_dt.date(nam, m, 1))[0] for m in ds]
        self.xh_nld, self.yt_nld, self.tn_nld = D("0.08"), D("0.015"), D("0.01")
        self.xh_dn, self.yt_dn, self.tn_dn, self.kpcd = D("0.175"), D("0.03"), D("0.01"), D("0.02")
        t = tham_so_tncn(nam)
        self.gt_bt, self.gt_npt, self.cc_tncn = t["gt_ban_than"], t["gt_npt"], t["can_cu"]
        self.bac = []            # (nguong thang, thue suat %, chenh lech thue suat)
        truoc, duoi = 0, 0
        for nguong, ts in t["bac"]:
            self.bac.append((duoi, ts, D(ts - truoc) / 100))
            truoc = ts
            duoi = nguong if nguong is not None else duoi
        self.sai_so = 5
        self.sai_so_so = 1000
        self.can_cu_bh = chon_can_cu_bh(dong, self)

    @property
    def tran_xh(self):
        return 20 * sum(self.lcs_thang) if len(self.lcs_thang) == self.n else 20 * self.lcs * self.n

    @property
    def tran_tn(self):
        return 20 * sum(self.lttv_thang) if len(self.lttv_thang) == self.n else 20 * self.lttv * self.n

    def ct_tran(self, ten_ts, ds, gt):
        """cong thuc tran: muc dong nhat trong ky -> =20*TS_x*TS_SO_THANG (sua o TS_x la tinh lai); khac nhau -> 20*(so thang*muc+...)."""
        if len(set(ds)) <= 1 and len(ds) == self.n and (not ds or ds[0] == gt):
            return "=20*%s*TS_SO_THANG" % ten_ts, "Công thức."
        nhom = []
        for v in ds:
            if nhom and nhom[-1][1] == v:
                nhom[-1][0] += 1
            else:
                nhom.append([1, v])
        return ("=20*(%s)" % "+".join("%d*%d" % (a, b) for a, b in nhom),
                "Kỳ qua ngày đổi mức: 20 × (" + " + ".join("%d tháng × %s" % (a, "{:,}".format(b).replace(",", ".")) for a, b in nhom) + ").")

    def nguong_ky(self):
        return [b[0] * self.n for b in self.bac]


def _lc_hoac_cb(d):
    lc = so(d.get("luong_chinh"))
    return lc if lc != 0 else so(d.get("luong_cb"))


def luong_tinh_bh(d, cc):
    ld = so(d.get("luong_dong_bh"))
    if ld > 0:
        return ld
    if cc == 1:
        return so(d.get("luong_cb"))
    if cc == 2:
        return _lc_hoac_cb(d)
    return so(d.get("tong_tn"))


def bh_tinh_lai(ltbh, ts):
    xh = min(D(ltbh), D(ts.tran_xh))
    tn = min(D(ltbh), D(ts.tran_tn))
    return R(xh * ts.xh_nld) + R(xh * ts.yt_nld) + R(tn * ts.tn_nld)


def chon_can_cu_bh(dong, ts):
    """bang khong co cot Luong dong BH: chon can cu (1 luong co ban / 2 luong chinh / 3 tong thu nhap) khop BH nhieu dong nhat."""
    dem = {1: 0, 2: 0, 3: 0}
    co = 0
    for d in dong:
        if so(d.get("luong_dong_bh")) > 0:
            continue
        bh = so(d.get("bhxh_nv")) + so(d.get("bhyt_nv")) + so(d.get("bhtn_nv"))
        if bh <= 0:
            continue
        co += 1
        for cc in (1, 2, 3):
            if abs(bh - bh_tinh_lai(luong_tinh_bh(d, cc), ts)) <= 5:
                dem[cc] += 1
    if co == 0:
        return 1
    tot = max(dem.values())
    for cc in (1, 2, 3):
        if dem[cc] == tot:
            return cc
    return 1


def thue_luy_tien(tntt, ts):
    tntt = D(tntt)
    s = Decimal(0)
    for ng, _, cl in ts.bac:
        ngk = D(ng * ts.n)
        if tntt > ngk:
            s += (tntt - ngk) * cl
    return R(s)


def tinh_dong(d, ts):
    """cac cot tinh lai cua mot dong (giong cong thuc sheet BangLuong)."""
    v = {}
    tn = D(so(d.get("tong_tn")))
    v["tn_tl"] = D(_lc_hoac_cb(d)) + D(so(d.get("phu_cap"))) + D(so(d.get("tn_khac")))
    v["tn_lech"] = tn - v["tn_tl"]
    v["ltbh"] = D(luong_tinh_bh(d, ts.can_cu_bh))
    v["bh"] = D(so(d.get("bhxh_nv"))) + D(so(d.get("bhyt_nv"))) + D(so(d.get("bhtn_nv")))
    v["bh_tl"] = D(bh_tinh_lai(v["ltbh"], ts))
    v["bh_lech"] = v["bh"] - v["bh_tl"]
    tnct_b = D(so(d.get("tn_chiu_thue")))
    v["tnct"] = tnct_b if tnct_b > 0 else tn
    gt_b = D(so(d.get("giam_tru_gc")))
    v["gt"] = gt_b if gt_b > 0 else (D(ts.gt_bt) + D(so(d.get("so_npt"))) * D(ts.gt_npt)) * ts.n
    v["tntt"] = max(Decimal(0), v["tnct"] - v["bh"] - v["gt"])
    v["thue_tl"] = D(thue_luy_tien(v["tntt"], ts))
    v["thue_lech"] = D(so(d.get("thue"))) - v["thue_tl"]
    v["kt"] = v["bh"] + D(so(d.get("thue"))) + D(so(d.get("tam_ung"))) + D(so(d.get("tru_khac")))
    v["tl_tl"] = tn - v["kt"]
    v["tl_lech"] = D(so(d.get("thuc_linh"))) - v["tl_tl"]
    return v


def trich_dn(ltbh, ts):
    xh = min(D(ltbh), D(ts.tran_xh))
    tn = min(D(ltbh), D(ts.tran_tn))
    return {"xh": R(xh * ts.xh_dn), "yt": R(xh * ts.yt_dn), "tn": R(tn * ts.tn_dn), "kpcd": R(xh * ts.kpcd)}


# ------------------------------------------------------------------ lap so tinh
class _Kieu(object):
    def __init__(self, wb):
        k = wb.kieu
        self.cty = k(dam=True, co=11)
        self.td = k(dam=True, co=14, can="giua", mau="1F3864")
        self.td2 = k(dam=True, co=12, can="giua")
        self.nghieng = k(nghieng=True, co=10, mau="595959")
        self.nhom = k(dam=True, co=10, can="giua", nen="BDD7EE", khung=True, xuong=True)
        self.h = k(dam=True, co=10, can="giua", nen="D9E1F2", khung=True, xuong=True)
        self.h_ct = k(dam=True, co=10, can="giua", nen="C6E0B4", khung=True, xuong=True)
        self.h_l = k(dam=True, co=10, can="giua", nen="F8CBAD", khung=True, xuong=True)
        self.chu = k(co=10, khung=True, doc="giua")
        self.chu_xd = k(co=10, khung=True, xuong=True, doc="tren")
        self.chu_g = k(co=10, khung=True, can="giua")
        self.so = k(co=10, khung=True, so=SO_TIEN)
        self.so_le = k(co=10, khung=True, so="#,##0.0#;(#,##0.0#);\"-\"")
        self.ct = k(co=10, khung=True, so=SO_TIEN, nen="EAF3E6")
        self.lech = k(co=10, khung=True, so=SO_TIEN, dam=True)
        self.tong_chu = k(dam=True, co=10, khung=True, nen="FFF2CC", can="giua")
        self.tong = k(dam=True, co=10, khung=True, so=SO_TIEN, nen="FFF2CC")
        self.tong_le = k(dam=True, co=10, khung=True, so="#,##0.0#;(#,##0.0#);\"-\"", nen="FFF2CC")
        self.muc = k(dam=True, co=11, mau="1F3864")
        self.kq = k(dam=True, co=10, khung=True, can="giua")
        self.pt = k(co=10, khung=True, so="0.0%", nen="FFFFE0")
        self.ts_so = k(co=10, khung=True, so=SO_TIEN, nen="FFFFE0")
        self.ts_nguyen = k(co=10, khung=True, so="0", nen="FFFFE0", can="giua")
        self.ket_luan = k(dam=True, co=12, khung=True, xuong=True, nen="FFF2CC")


def _t(v):
    """chuoi hien nguyen van (du lieu bang luong bat dau '=' khong thanh cong thuc)."""
    return Chu("" if v is None else str(v))


def trim_excel(s):
    """giong TRIM cua Excel: bo dau cach dau / cuoi, gop nhieu dau cach giua thanh mot (chi ky tu cach)."""
    return re.sub(" +", " ", str(s or "").strip(" "))


def khoa_so_sanh(s):
    """khoa so sanh chuoi nhu phep = cua Excel (khong phan biet hoa thuong) sau TRIM."""
    return trim_excel(s).lower()


def _ngay_gio():
    return _dt.datetime.now().strftime("%d/%m/%Y %H:%M")


def lap(dl, ra):
    """lap tep Excel doi chieu; tra ve (duong, [canh bao])."""
    ky = dl.get("ky") or {}
    dn = dl.get("dn") or {}
    dong = [d for d in (dl.get("dong") or []) if isinstance(d, dict)]
    cb = []
    ts = ThamSo(ky, dong)
    wb = SoExcel(font="Times New Roman", co=10)
    K = _Kieu(wb)
    ten_ky = _t(ky.get("ten")) or ("kỳ %s" % ky.get("ma"))
    # thu tu sheet: TongHop dau tien (mo ra la thay ket luan)
    wsT = wb.sheet("TongHop", cot=[5, 50, 18, 18, 16, 20])
    wsB = wb.sheet("BangLuong")
    wsD = wb.sheet("TrichTheoLuong", cot=[5, 11, 26, 16, 15, 14, 13, 13, 13, 15, 15, 15, 15, 14])
    wsN = wb.sheet("DoiChieuNV", cot=[5, 12, 28, 16, 16, 14, 16, 16, 14, 34])
    wsS = wb.sheet("ThamSo", cot=[5, 58, 18, 16, 18, 40])
    wsR = wb.sheet("BaoCao", cot=[150])
    TS = _lap_tham_so(wb, wsS, K, ts, ky)
    n = len(dong)
    r0 = 7
    r1 = r0 + max(n, 1) - 1          # dong du lieu cuoi (it nhat 1 dong de cong thuc khong loi)
    rt = r1 + 1                      # dong CONG
    tinh = [tinh_dong(d, ts) for d in dong]
    tong = _lap_bang_luong(wb, wsB, K, dn, ky, ten_ky, dong, tinh, ts, r0, r1, rt)
    trich = _lap_trich(wb, wsD, K, dn, ten_ky, dong, tinh, ts, r0, r1, rt)
    _lap_doi_chieu_nv(wb, wsN, K, dn, ten_ky, dl, dong, r0, r1)
    _lap_tong_hop(wb, wsT, K, dn, ky, ten_ky, dl, dong, tinh, ts, tong, trich, r0, r1, rt, cb)
    _lap_bao_cao(wsR, K, dl)
    if n == 0:
        cb.append("Kỳ bảng lương không có dòng nào - Excel chỉ có khung.")
    d = os.path.dirname(os.path.abspath(ra))
    if d and not os.path.isdir(d):
        os.makedirs(d, exist_ok=True)
    wb.luu(ra)
    return ra, cb


def _dau_trang(ws, K, dn, tieu_de, dong2, so_cot):
    ws.o(1, 1, _t(dn.get("ten")), K.cty)
    mst = _t(dn.get("mst"))
    dc = _t(dn.get("dia_chi"))
    ws.o(2, 1, ("MST: " + mst if mst else "") + (("   Địa chỉ: " + dc) if dc else ""), K.nghieng)
    ws.gop(3, 1, 3, so_cot, tieu_de, K.td)
    ws.gop(4, 1, 4, so_cot, dong2, K.nghieng)
    ws.cao(3, 22)


# ------------------------------------------------------------------ ThamSo
def _lap_tham_so(wb, ws, K, ts, ky):
    ws.gop(1, 1, 1, 6, "THAM SỐ DÙNG TRONG CÔNG THỨC ĐỐI CHIẾU BẢNG LƯƠNG", K.td)
    ws.gop(2, 1, 2, 6, "Ô nền vàng nhạt SỬA ĐƯỢC - mọi cột 'tính lại', 'lệch' và bảng Tổng hợp tự tính lại theo số mới. "
                       "Số mặc định theo kỳ %s." % _t(ky.get("ten")), K.nghieng)
    ws.dong(4, 1, ["STT", "Tham số", "Giá trị", "Tên dùng trong công thức", "Ghi chú / căn cứ"], K.h)
    ws.gop(4, 5, 4, 6, "Ghi chú / căn cứ", K.h)
    TS = {}
    r = [5]

    def them(ten, nhan, gt, kieu, ghi="", ct=None):
        rr = r[0]
        ws.o(rr, 1, rr - 4, K.chu_g)
        ws.o(rr, 2, nhan, K.chu_xd)
        ws.o(rr, 3, CT(ct, gt) if ct else gt, kieu)
        ws.o(rr, 4, ten, K.chu)
        ws.gop(rr, 5, rr, 6, ghi, K.chu_xd)
        TS[ten] = "ThamSo!$C$%d" % rr
        wb.ten(ten, TS[ten])
        r[0] += 1
        return rr

    th = int(ky.get("thang") or 0)
    them("TS_NAM", "Năm của kỳ bảng lương (biểu thuế, giảm trừ theo năm này)", ts.nam, K.ts_nguyen, "Đổi năm KHÔNG tự đổi biểu thuế - sửa bảng biểu thuế bên dưới.")
    them("TS_SO_THANG", "Số tháng của kỳ (1 = một tháng; kỳ nhiều tháng / cả năm: nhân giảm trừ, ngưỡng thuế, trần BH)",
         ts.n, K.ts_nguyen, "Kỳ %s: %d tháng." % (_t(ky.get("ten")), ts.n) + (" Kỳ nhiều tháng: thuế tính lại theo cách quyết toán (tham khảo)." if th == 0 or th > 100 else ""))
    them("TS_SAI_SO", "Sai số cho phép từng dòng / từng người (đồng) - chênh do làm tròn từng ô", ts.sai_so, K.ts_so,
         "Lệch lớn hơn số này thì tô đỏ. Đặt 0 để kiểm tuyệt đối từng đồng.")
    them("TS_SAI_SO_SO", "Sai số cho phép khi đối chiếu với sổ kế toán (đồng)", ts.sai_so_so, K.ts_so,
         "Giống báo cáo đối chiếu dạng chữ của phần mềm (1.000 đồng).")
    them("TS_XH_NLD", "BHXH người lao động", N(ts.xh_nld), K.pt, "Luật BHXH 2024: 8% (hưu trí, tử tuất).")
    them("TS_YT_NLD", "BHYT người lao động", N(ts.yt_nld), K.pt, "Luật BHYT: 1,5%.")
    them("TS_TN_NLD", "BHTN người lao động", N(ts.tn_nld), K.pt, "Luật Việc làm: 1%.")
    them("TS_XH_DN", "BHXH doanh nghiệp (14% hưu trí + 3% ốm đau thai sản + 0,5% TNLĐ-BNN)", N(ts.xh_dn), K.pt,
         "17,5%. Doanh nghiệp được đóng TNLĐ-BNN 0,3% thì sửa 17,3%.")
    them("TS_YT_DN", "BHYT doanh nghiệp", N(ts.yt_dn), K.pt, "3%.")
    them("TS_TN_DN", "BHTN doanh nghiệp", N(ts.tn_dn), K.pt, "1%.")
    them("TS_KPCD", "Kinh phí công đoàn (doanh nghiệp, tính trên quỹ lương đóng BHXH)", N(ts.kpcd), K.pt, "2% - Luật Công đoàn.")
    them("TS_LCS", "Mức lương cơ sở (đồng/tháng)", ts.lcs, K.ts_so, ts.cc_lcs + ". Trần BHXH, BHYT = 20 lần.")
    them("TS_LTTV", "Lương tối thiểu vùng (đồng/tháng) - mặc định vùng I", ts.lttv, K.ts_so,
         ts.cc_lttv + ". Doanh nghiệp vùng II / III / IV sửa lại. Trần BHTN = 20 lần.")
    f_xh, g_xh = ts.ct_tran("TS_LCS", ts.lcs_thang, ts.lcs)
    f_tn, g_tn = ts.ct_tran("TS_LTTV", ts.lttv_thang, ts.lttv)
    them("TS_TRAN_XH", "Trần lương đóng BHXH, BHYT, KPCĐ của kỳ = 20 × lương cơ sở từng tháng", ts.tran_xh, K.ct, g_xh, ct=f_xh)
    them("TS_TRAN_TN", "Trần lương đóng BHTN của kỳ = 20 × lương tối thiểu vùng từng tháng", ts.tran_tn, K.ct, g_tn, ct=f_tn)
    them("TS_CAN_CU_BH", "Căn cứ đóng BH khi bảng lương KHÔNG có cột Lương đóng BH: 1 = Lương cơ bản; 2 = Lương chính theo công; 3 = Tổng thu nhập",
         ts.can_cu_bh, K.ts_nguyen, "Phần mềm đã chọn cách khớp số BH trên bảng nhiều dòng nhất. Sửa 1 / 2 / 3 nếu cần.")
    them("TS_GT_BT", "Giảm trừ gia cảnh bản thân (đồng/tháng)", ts.gt_bt, K.ts_so, ts.cc_tncn)
    them("TS_GT_NPT", "Giảm trừ mỗi người phụ thuộc (đồng/tháng)", ts.gt_npt, K.ts_so, "")
    rr = r[0] + 1
    ws.o(rr, 2, "BIỂU THUẾ LŨY TIẾN TỪNG PHẦN (thu nhập tính thuế THÁNG)", K.muc)
    rr += 1
    ws.dong(rr, 1, ["Bậc", "Thu nhập tính thuế tháng TRÊN mức (đồng)", "Thuế suất", "Chênh lệch thuế suất so với bậc trước",
                    "Mức theo kỳ = mức tháng × số tháng"], K.h)
    ws.o(rr, 6, "Thuế = Σ (TNTT - mức theo kỳ) × chênh lệch thuế suất, với các bậc mà TNTT vượt mức", K.h)
    b0 = rr + 1
    for i, (ng, tsuat, cl) in enumerate(ts.bac):
        q = b0 + i
        ws.o(q, 1, i + 1, K.chu_g)
        ws.o(q, 2, ng, K.ts_so)
        ws.o(q, 3, tsuat / 100.0, K.pt)
        ws.o(q, 4, N(cl), K.pt)
        ws.o(q, 5, CT("=B%d*TS_SO_THANG" % q, ng * ts.n), K.ct)
    b1 = b0 + len(ts.bac) - 1
    TS["TS_NGUONG"] = "ThamSo!$E$%d:$E$%d" % (b0, b1)
    TS["TS_CL"] = "ThamSo!$D$%d:$D$%d" % (b0, b1)
    wb.ten("TS_NGUONG", TS["TS_NGUONG"])
    wb.ten("TS_CL", TS["TS_CL"])
    ws.gop(b1 + 2, 1, b1 + 2, 6, "Chênh lệch thuế suất nhập SỐ (không dùng công thức trừ) để kết quả làm tròn giống hệt cách tính tay. "
                                 "Thuế tính lại chỉ để THAM KHẢO: phần mềm không biết khoản thu nhập miễn thuế (ăn ca, làm thêm giờ…), "
                                 "người không cư trú / hợp đồng dưới 3 tháng (khấu trừ 10%).", K.nghieng)
    ws.cao(b1 + 2, 30)
    ws.dong_bang(5, 1)
    ws.in_trang(ngang=False)
    return TS


# ------------------------------------------------------------------ BangLuong
def _gt_dong(d, k):
    if k == "nguon":
        a = _t(d.get("sheet"))
        b = os.path.basename(_t(d.get("tep")).replace("\\", "/"))
        return Chu(" / ".join(x for x in (a, b) if x))
    if k == "dong":
        v = so(d.get("dong"))
        return v if v else ""
    v = d.get(k)
    if k in ("ma_nv", "ten", "ten_dm", "bo_phan", "chuc_vu", "ghi_chu"):
        return _t(v)
    return so(v)


def _ct_dong(k, r):
    """cong thuc cot tinh lai cua dong r."""
    c = {x: "%s%d" % (L(x), r) for x in C}
    if k == "tn_tl":
        return "=IF(%s<>0,%s,%s)+%s+%s" % (c["luong_chinh"], c["luong_chinh"], c["luong_cb"], c["phu_cap"], c["tn_khac"])
    if k == "tn_lech":
        return "=%s-%s" % (c["tong_tn"], c["tn_tl"])
    if k == "ltbh":
        return "=IF(%s>0,%s,CHOOSE(TS_CAN_CU_BH,%s,IF(%s<>0,%s,%s),%s))" % (
            c["luong_dong_bh"], c["luong_dong_bh"], c["luong_cb"], c["luong_chinh"], c["luong_chinh"], c["luong_cb"], c["tong_tn"])
    if k == "bh":
        return "=%s+%s+%s" % (c["bhxh_nv"], c["bhyt_nv"], c["bhtn_nv"])
    if k == "bh_tl":
        return ("=ROUND(MIN(%s,TS_TRAN_XH)*TS_XH_NLD,0)+ROUND(MIN(%s,TS_TRAN_XH)*TS_YT_NLD,0)+ROUND(MIN(%s,TS_TRAN_TN)*TS_TN_NLD,0)"
                % (c["ltbh"], c["ltbh"], c["ltbh"]))
    if k == "bh_lech":
        return "=%s-%s" % (c["bh"], c["bh_tl"])
    if k == "tnct":
        return "=IF(%s>0,%s,%s)" % (c["tn_chiu_thue"], c["tn_chiu_thue"], c["tong_tn"])
    if k == "gt":
        return "=IF(%s>0,%s,(TS_GT_BT+%s*TS_GT_NPT)*TS_SO_THANG)" % (c["giam_tru_gc"], c["giam_tru_gc"], c["so_npt"])
    if k == "tntt":
        return "=MAX(0,%s-%s-%s)" % (c["tnct"], c["bh"], c["gt"])
    if k == "thue_tl":
        return "=ROUND(SUMPRODUCT((%s>TS_NGUONG)*(%s-TS_NGUONG)*TS_CL),0)" % (c["tntt"], c["tntt"])
    if k == "thue_lech":
        return "=%s-%s" % (c["thue"], c["thue_tl"])
    if k == "kt":
        return "=%s+%s+%s+%s" % (c["bh"], c["thue"], c["tam_ung"], c["tru_khac"])
    if k == "tl_tl":
        return "=%s-%s" % (c["tong_tn"], c["kt"])
    if k == "tl_lech":
        return "=%s-%s" % (c["thuc_linh"], c["tl_tl"])
    raise KeyError(k)


def _lap_bang_luong(wb, ws, K, dn, ky, ten_ky, dong, tinh, ts, r0, r1, rt):
    nc = len(COT_BL)
    _dau_trang(ws, K, dn, "BẢNG LƯƠNG ĐÃ IMPORT - KIỂM TRA CÔNG THỨC TỪNG DÒNG - " + ten_ky.upper(),
               "Tệp: %s.  Cột trắng = số theo bảng lương; cột nền xanh = phần mềm TÍNH LẠI bằng công thức; cột Lệch tô ĐỎ khi lệch quá sai số "
               "(ThamSo), tô VÀNG ở cột tham khảo (BH, thuế). Lập lúc %s." % (_t(ky.get("tep_nguon")) or "-", _t(ky.get("lap_luc")) or _ngay_gio()), nc)
    nhom = [(1, 8, "THÔNG TIN NHÂN VIÊN"), (9, 15, "THU NHẬP"), (16, 23, "BẢO HIỂM NGƯỜI LAO ĐỘNG"),
            (24, 33, "THUẾ TNCN (tính lại để tham khảo)"), (34, 39, "KHẤU TRỪ VÀ THỰC LĨNH"), (40, 41, "GHI CHÚ")]
    for a, b, t in nhom:
        ws.gop(5, a, 5, b, t, K.nhom)
    for k, t, loai in COT_BL:
        c = C[k]
        tieu = "%s %s" % (SO[k], t)
        if k in GIAI_THICH:
            tieu += "\n" + GIAI_THICH[k]
        ws.o(6, c, tieu, K.h_ct if loai == "c" else (K.h_l if loai in ("l", "y") else K.h))
        w = {"stt": 5, "dong": 7, "ma_nv": 10, "ten": 24, "ten_dm": 22, "bo_phan": 14, "chuc_vu": 12, "ngay_cong": 8,
             "ghi_chu": 45, "nguon": 20, "so_npt": 8}.get(k, 14 if loai in ("n", "c") else 13)
        ws.rong(c, w)
    ws.cao(5, 18)
    ws.cao(6, 78)
    tong = {k: Decimal(0) for k in C}
    for i, d in enumerate(dong):
        r = r0 + i
        v = tinh[i]
        for k, _, loai in COT_BL:
            c = C[k]
            if k == "stt":
                ws.o(r, c, i + 1, K.chu_g)
            elif loai in ("t", "g"):
                ws.o(r, c, _gt_dong(d, k), K.chu_xd if k == "ghi_chu" else K.chu)
            elif loai == "n":
                x = _gt_dong(d, k)
                ws.o(r, c, x, K.so_le if k in ("ngay_cong", "so_npt") else K.so)
                tong[k] += D(x)
            else:
                ws.o(r, c, CT(_ct_dong(k, r), N(v[k])), K.lech if loai in ("l", "y") else K.ct)
                tong[k] += v[k]
    # dong CONG
    ws.gop(rt, 1, rt, 7, "CỘNG (%d dòng)" % len(dong), K.tong_chu)
    for k, _, loai in COT_BL:
        c = C[k]
        if c <= 7 or loai in ("t", "g"):
            if c > 7:
                ws.o(rt, c, "", K.tong)
            continue
        ws.o(rt, c, CT("=SUM(%s%d:%s%d)" % (L(k), r0, L(k), r1), N(tong[k])), K.tong_le if k in ("ngay_cong", "so_npt") else K.tong)
    # to mau lech (dong du lieu + dong cong)
    for k, _, loai in COT_BL:
        if loai == "l":
            ws.to_mau(r0, C[k], r1, C[k], "ABS(%s%d)>TS_SAI_SO" % (L(k), r0), nen="FFC7CE", mau="9C0006", dam=True)
        elif loai == "y":
            ws.to_mau(r0, C[k], r1, C[k], "ABS(%s%d)>TS_SAI_SO" % (L(k), r0), nen="FFEB9C", mau="9C5700")
    ws.to_mau(r0, C["ma_nv"], r1, C["ma_nv"], 'LEN(TRIM(%s%d))=0' % (L("ma_nv"), r0), nen="FFC7CE", mau="9C0006")
    ws.loc(6, 1, r1, nc)
    ws.dong_bang(r0, C["bo_phan"])
    ws.in_trang(ngang=True, lap_dong=(5, 6))
    return tong


# ------------------------------------------------------------------ TrichTheoLuong
COT_TR = ["stt", "ma", "ten", "bp", "ltbh", "xh", "yt", "tn", "kpcd", "cong_dn", "bh_nld", "tong", "dn_bang", "lech_dn"]
CT_ = {k: i + 1 for i, k in enumerate(COT_TR)}


def _lt(k):
    return dia_chi(1, CT_[k])[:-1]


def _lap_trich(wb, ws, K, dn, ten_ky, dong, tinh, ts, r0, r1, rt):
    nc = len(COT_TR)
    co_dn = any(so(d.get("bhxh_dn")) or so(d.get("bhyt_dn")) or so(d.get("bhtn_dn")) or so(d.get("kpcd")) for d in dong)
    _dau_trang(ws, K, dn, "TRÍCH BẢO HIỂM VÀ KINH PHÍ CÔNG ĐOÀN THEO LƯƠNG - " + ten_ky.upper(),
               "Doanh nghiệp đóng (tính vào chi phí) tính lại theo tỷ lệ và trần ở sheet ThamSo trên Lương tính BH của sheet BangLuong; "
               "BH người lao động lấy theo bảng lương (đã trừ vào lương).", nc)
    hd = [("STT", 0), ("Mã NV", 0), ("Họ tên", 0), ("Bộ phận", 0), ("Lương tính BH\n(BangLuong)", 0),
          ("BHXH DN\n= MIN(lương; trần) × TS_XH_DN", 1), ("BHYT DN\n× TS_YT_DN", 1), ("BHTN DN\n× TS_TN_DN (trần BHTN)", 1),
          ("KPCĐ\n× TS_KPCD", 1), ("Cộng DN đóng", 1), ("BH người lao động\n(bảng lương)", 0), ("Tổng trích\n= DN + NLĐ", 1),
          ("DN đóng ghi trên bảng lương" + ("" if co_dn else "\n(bảng không có cột)"), 0), ("Lệch DN\n= bảng - tính lại", 2)]
    for i, (t, loai) in enumerate(hd):
        ws.o(6, i + 1, t, (K.h, K.h_ct, K.h_l)[loai])
    ws.cao(6, 48)
    tong = {k: Decimal(0) for k in COT_TR}
    for i, d in enumerate(dong):
        r = r0 + i
        rb = r0 + i                  # cung dong tren BangLuong
        v = tinh[i]
        t = trich_dn(v["ltbh"], ts)
        cong = t["xh"] + t["yt"] + t["tn"] + t["kpcd"]
        ws.o(r, 1, i + 1, K.chu_g)
        ws.o(r, 2, CT("=BangLuong!%s%d&\"\"" % (L("ma_nv"), rb), _t(d.get("ma_nv"))), K.chu)
        ws.o(r, 3, CT("=BangLuong!%s%d&\"\"" % (L("ten"), rb), _t(d.get("ten"))), K.chu)
        ws.o(r, 4, CT("=BangLuong!%s%d&\"\"" % (L("bo_phan"), rb), _t(d.get("bo_phan"))), K.chu)
        ws.o(r, 5, CT("=BangLuong!%s%d" % (L("ltbh"), rb), N(v["ltbh"])), K.ct)
        e = "E%d" % r
        ws.o(r, 6, CT("=ROUND(MIN(%s,TS_TRAN_XH)*TS_XH_DN,0)" % e, t["xh"]), K.ct)
        ws.o(r, 7, CT("=ROUND(MIN(%s,TS_TRAN_XH)*TS_YT_DN,0)" % e, t["yt"]), K.ct)
        ws.o(r, 8, CT("=ROUND(MIN(%s,TS_TRAN_TN)*TS_TN_DN,0)" % e, t["tn"]), K.ct)
        ws.o(r, 9, CT("=ROUND(MIN(%s,TS_TRAN_XH)*TS_KPCD,0)" % e, t["kpcd"]), K.ct)
        ws.o(r, 10, CT("=SUM(F%d:I%d)" % (r, r), cong), K.ct)
        ws.o(r, 11, CT("=BangLuong!%s%d" % (L("bh"), rb), N(v["bh"])), K.ct)
        ws.o(r, 12, CT("=J%d+K%d" % (r, r), N(D(cong) + v["bh"])), K.ct)
        dnb = so(d.get("bhxh_dn")) + so(d.get("bhyt_dn")) + so(d.get("bhtn_dn")) + so(d.get("kpcd"))
        if co_dn:
            ws.o(r, 13, dnb, K.so)
            ws.o(r, 14, CT("=M%d-J%d" % (r, r), N(D(dnb) - D(cong))), K.lech)
            tong["dn_bang"] += D(dnb)
            tong["lech_dn"] += D(dnb) - D(cong)
        else:
            ws.o(r, 13, "", K.so)
            ws.o(r, 14, "", K.so)
        for k, x in (("ltbh", v["ltbh"]), ("xh", t["xh"]), ("yt", t["yt"]), ("tn", t["tn"]), ("kpcd", t["kpcd"]), ("cong_dn", cong),
                     ("bh_nld", v["bh"]), ("tong", D(cong) + v["bh"])):
            tong[k] += D(x)
    ws.gop(rt, 1, rt, 4, "CỘNG", K.tong_chu)
    for k in COT_TR[4:]:
        c = CT_[k]
        if k in ("dn_bang", "lech_dn") and not co_dn:
            ws.o(rt, c, "", K.tong)
            continue
        ws.o(rt, c, CT("=SUM(%s%d:%s%d)" % (_lt(k), r0, _lt(k), r1), N(tong[k])), K.tong)
    if co_dn:
        ws.to_mau(r0, 14, r1, 14, "ABS(N%d)>TS_SAI_SO" % r0, nen="FFEB9C", mau="9C5700")
    ws.loc(6, 1, r1, nc)
    ws.dong_bang(r0, 4)
    ws.in_trang(ngang=True, lap_dong=(6, 6))
    tong["_co_dn"] = co_dn
    tong["_rt"] = rt
    return tong


# ------------------------------------------------------------------ DoiChieuNV
def _lap_doi_chieu_nv(wb, ws, K, dn, ten_ky, dl, dong, r0, r1):
    pm = dl.get("pm") or {}
    co = bool(pm.get("co_dc"))
    _dau_trang(ws, K, dn, "ĐỐI CHIẾU TỪNG NHÂN VIÊN: TỆP EXCEL VÀ BẢNG LƯƠNG TRONG PHẦN MỀM - " + ten_ky.upper(),
               ("Cột Excel cộng từ sheet BangLuong theo Mã NV (SUMPRODUCT); cột phần mềm = bảng lương của chương trình (Lao động - tiền lương) cùng tháng."
                if co else "Không đối chiếu với bảng lương của phần mềm: " + (_t(pm.get("ly_do")) or "kỳ không phải một tháng của năm tài chính") +
                ". Cột phần mềm để trống."), 10)
    hd = ["STT", "Mã NV", "Họ tên (danh mục)", "Thu nhập - Excel", "Thu nhập - phần mềm", "Lệch thu nhập", "Thực lĩnh - Excel",
          "Thực lĩnh - phần mềm", "Lệch thực lĩnh", "Ghi chú"]
    ws.dong(6, 1, hd, K.h)
    ws.cao(6, 32)
    ds, thu_tu = {}, []
    for d in dong:
        ma = str(d.get("ma_nv") or "")
        k = ma.lower()
        if not ma.strip(" "):
            continue
        if k not in ds:
            ds[k] = {"ma": ma, "ten": _t(d.get("ten_dm")) or _t(d.get("ten")), "tn_ex": Decimal(0), "tl_ex": Decimal(0), "tn_pm": None, "tl_pm": None, "ex": True}
            thu_tu.append(k)
        ds[k]["tn_ex"] += D(so(d.get("tong_tn")))
        ds[k]["tl_ex"] += D(so(d.get("thuc_linh")))
    if co:
        for x in pm.get("nv") or []:
            ma = str(x.get("so_hieu") or "")
            k = ma.lower()
            if not ma.strip(" "):
                continue
            if k not in ds:
                ds[k] = {"ma": ma, "ten": _t(x.get("ten")), "tn_ex": Decimal(0), "tl_ex": Decimal(0), "tn_pm": None, "tl_pm": None, "ex": False}
                thu_tu.append(k)
            ma = k
            ds[ma]["tn_pm"] = D(so(x.get("tn"))) + (ds[ma]["tn_pm"] or 0)
            ds[ma]["tl_pm"] = D(so(x.get("tl"))) + (ds[ma]["tl_pm"] or 0)
    r = 7
    rngC = "BangLuong!$%s$%d:$%s$%d" % (L("ma_nv"), r0, L("ma_nv"), r1)
    rngTN = "BangLuong!$%s$%d:$%s$%d" % (L("tong_tn"), r0, L("tong_tn"), r1)
    rngTL = "BangLuong!$%s$%d:$%s$%d" % (L("thuc_linh"), r0, L("thuc_linh"), r1)
    ra0 = r
    t = {"tn_ex": Decimal(0), "tl_ex": Decimal(0), "tn_pm": Decimal(0), "tl_pm": Decimal(0)}
    for i, ma in enumerate(thu_tu):
        x = ds[ma]
        ws.o(r, 1, i + 1, K.chu_g)
        ws.o(r, 2, Chu(x["ma"]), K.chu)
        ws.o(r, 3, x["ten"], K.chu)
        ws.o(r, 4, CT("=SUMPRODUCT((%s=$B%d)*%s)" % (rngC, r, rngTN), N(x["tn_ex"])), K.ct)
        ws.o(r, 7, CT("=SUMPRODUCT((%s=$B%d)*%s)" % (rngC, r, rngTL), N(x["tl_ex"])), K.ct)
        t["tn_ex"] += x["tn_ex"]
        t["tl_ex"] += x["tl_ex"]
        if co:
            tnp = x["tn_pm"] if x["tn_pm"] is not None else Decimal(0)
            tlp = x["tl_pm"] if x["tl_pm"] is not None else Decimal(0)
            ws.o(r, 5, N(tnp), K.so)
            ws.o(r, 8, N(tlp), K.so)
            ws.o(r, 6, CT("=D%d-E%d" % (r, r), N(x["tn_ex"] - tnp)), K.lech)
            ws.o(r, 9, CT("=G%d-H%d" % (r, r), N(x["tl_ex"] - tlp)), K.lech)
            t["tn_pm"] += tnp
            t["tl_pm"] += tlp
            gc = "Chỉ có trong bảng lương phần mềm, không có trên tệp Excel" if not x["ex"] else (
                "Có trên Excel, phần mềm chưa tính lương" if x["tl_pm"] is None else "")
        else:
            for c in (5, 6, 8, 9):
                ws.o(r, c, "", K.so)
            gc = ""
        ws.o(r, 10, gc, K.chu_xd)
        r += 1
    ra1 = max(r - 1, ra0)
    if not thu_tu:
        ws.gop(r, 1, r, 10, "Chưa có dòng nào có mã nhân viên - bấm Chọn nhân viên / Tạo NV thiếu trên màn hình AI.", K.chu)
        r += 1
    rtn = r
    ws.gop(rtn, 1, rtn, 3, "CỘNG", K.tong_chu)
    for c, k in ((4, "tn_ex"), (5, "tn_pm"), (7, "tl_ex"), (8, "tl_pm")):
        if c in (5, 8) and not co:
            ws.o(rtn, c, "", K.tong)
            continue
        cc = dia_chi(1, c)[:-1]
        ws.o(rtn, c, CT("=SUM(%s%d:%s%d)" % (cc, ra0, cc, ra1), N(t[k])), K.tong)
    if co:
        ws.o(rtn, 6, CT("=D%d-E%d" % (rtn, rtn), N(t["tn_ex"] - t["tn_pm"])), K.tong)
        ws.o(rtn, 9, CT("=G%d-H%d" % (rtn, rtn), N(t["tl_ex"] - t["tl_pm"])), K.tong)
        ws.to_mau(ra0, 6, rtn, 6, "ABS(F%d)>TS_SAI_SO" % ra0, nen="FFC7CE", mau="9C0006", dam=True)
        ws.to_mau(ra0, 9, rtn, 9, "ABS(I%d)>TS_SAI_SO" % ra0, nen="FFC7CE", mau="9C0006", dam=True)
    else:
        ws.o(rtn, 6, "", K.tong)
        ws.o(rtn, 9, "", K.tong)
    ws.o(rtn, 10, "", K.tong)
    # dong chua co ma NV
    r = rtn + 2
    thieu = [d for d in dong if not str(d.get("ma_nv") or "").strip(" ")]
    ws.o(r, 2, "DÒNG CHƯA CÓ MÃ NHÂN VIÊN (%d) - không cộng vào bảng trên" % len(thieu), K.muc)
    r += 1
    if thieu:
        ws.dong(r, 1, ["STT", "Dòng tệp", "Họ tên trên bảng lương", "Thu nhập", "", "", "Thực lĩnh", "", "", "Ghi chú"], K.h)
        r += 1
        for i, d in enumerate(thieu):
            ws.dong(r, 1, [(i + 1, K.chu_g), (_gt_dong(d, "dong"), K.chu), (_t(d.get("ten")), K.chu), (so(d.get("tong_tn")), K.so), ("", None),
                           ("", None), (so(d.get("thuc_linh")), K.so), ("", None), ("", None), (_t(d.get("ghi_chu")), K.chu_xd)])
            r += 1
    else:
        ws.o(r, 2, "Không có.", K.nghieng)
        r += 1
    r += 1
    ngoai = dl.get("nv_ngoai") or []
    ws.o(r, 2, "ĐANG LÀM TRONG DANH MỤC NHƯNG KHÔNG CÓ TRÊN BẢNG LƯƠNG (%d) - nghỉ việc thì đánh dấu nghỉ trong danh mục" % len(ngoai), K.muc)
    r += 1
    for i, x in enumerate(ngoai):
        ws.dong(r, 1, [(i + 1, K.chu_g), (_t(x.get("so_hieu")), K.chu), (_t(x.get("ten")), K.chu)])
        r += 1
    if not ngoai:
        ws.o(r, 2, "Không có.", K.nghieng)
    if thu_tu:
        ws.loc(6, 1, ra1, 10)
    ws.dong_bang(7, 4)
    ws.in_trang(ngang=True, lap_dong=(6, 6))


# ------------------------------------------------------------------ TongHop
def _lap_tong_hop(wb, ws, K, dn, ky, ten_ky, dl, dong, tinh, ts, tong, trich, r0, r1, rt, cb):
    so_kt = dl.get("so") or {}
    pm = dl.get("pm") or {}
    tk = dl.get("tk") or {}
    _dau_trang(ws, K, dn, "BẢNG ĐỐI CHIẾU BẢNG LƯƠNG - " + ten_ky.upper(),
               "Kỳ số %s · tệp: %s · %s · lập lúc %s. Mọi số ở đây là CÔNG THỨC lấy từ các sheet BangLuong, TrichTheoLuong, ThamSo - sửa số / tham số là tự tính lại." % (
                   _t(ky.get("ma")), _t(ky.get("tep_nguon")) or "-",
                   ("đã lập chứng từ lương " + _t(ky.get("ma_ct"))) if ky.get("da_ht") else "chưa lập chứng từ lương", _t(ky.get("lap_luc")) or _ngay_gio()), 6)
    ws.cao(4, 30)
    n = len(dong)
    B = lambda k: "BangLuong!$%s$%d" % (L(k), rt)          # noqa: E731
    Tt = lambda k: "TrichTheoLuong!$%s$%d" % (_lt(k), rt)  # noqa: E731
    ket_qua = []           # (o ket qua, loai) loai: 'l' chinh xac / 'y' tham khao
    r = [6]

    def muc(t):
        r[0] += 1
        ws.o(r[0], 1, t, K.muc)
        r[0] += 1

    def dau_bang(cot3, cot4):
        ws.dong(r[0], 1, ["STT", "Nội dung", cot3, cot4, "Lệch", "Kết quả"], K.h)
        r[0] += 1

    stt = [0]

    def dong_kiem(noi_dung, f3, v3, f4, v4, sai_so, loai="l", chua="", khong_so=False):
        rr = r[0]
        stt[0] += 1
        ws.o(rr, 1, stt[0], K.chu_g)
        ws.o(rr, 2, noi_dung, K.chu_xd)
        ws.o(rr, 3, CT(f3, N(v3)) if isinstance(f3, str) and f3.startswith("=") else f3, K.ct if isinstance(f3, str) else K.so)
        ws.o(rr, 4, CT(f4, N(v4)) if isinstance(f4, str) and f4.startswith("=") else f4, K.ct if isinstance(f4, str) else K.so)
        lech = D(v3) - D(v4)
        ws.o(rr, 5, CT("=C%d-D%d" % (rr, rr), N(lech)), K.lech)
        ss = D(sai_so[1])
        nhan_lech = "LỆCH" if loai == "l" else "XEM LẠI"
        if chua:
            # so ke toan = 0 ma bang luong co so -> chua hach toan
            f = '=IF(AND(D%d=0,C%d<>0),"%s",IF(ABS(E%d)<=%s,"Khớp","%s"))' % (rr, rr, chua, rr, sai_so[0], nhan_lech)
            kq = chua if (D(v4) == 0 and D(v3) != 0) else ("Khớp" if abs(lech) <= ss else nhan_lech)
        else:
            f = '=IF(ABS(E%d)<=%s,"Khớp","%s")' % (rr, sai_so[0], nhan_lech)
            kq = "Khớp" if abs(lech) <= ss else nhan_lech
        ws.o(rr, 6, CT(f, kq), K.kq)
        ket_qua.append(("F%d" % rr, loai, kq))
        r[0] += 1
        return rr

    SS_DONG = ("TS_SAI_SO*MAX(1,%d)" % n, ts.sai_so * max(1, n))
    SS_SO = ("TS_SAI_SO_SO", ts.sai_so_so)
    # ---- A. kiem tra cong tren bang luong
    muc("A. KIỂM TRA CÔNG THỨC TRÊN BẢNG LƯƠNG (số theo bảng ↔ phần mềm tính lại)")
    dau_bang("Theo bảng lương", "Tính lại theo công thức")
    rr = r[0]
    stt[0] += 1
    ws.o(rr, 1, stt[0], K.chu_g)
    ws.o(rr, 2, "Số người trên bảng lương ↔ số dòng đã có mã nhân viên (lệch = dòng chưa chọn nhân viên - xem sheet DoiChieuNV)", K.chu_xd)
    co_ma = sum(1 for d in dong if trim_excel(d.get("ma_nv")))
    ws.o(rr, 3, CT("=COUNTA(BangLuong!$%s$%d:$%s$%d)" % (L("ten"), r0, L("ten"), r1), sum(1 for d in dong if _t(d.get("ten")))), K.ct)
    ws.o(rr, 4, CT('=SUMPRODUCT(--(LEN(TRIM(BangLuong!$%s$%d:$%s$%d))>0))' % (L("ma_nv"), r0, L("ma_nv"), r1), co_ma), K.ct)
    ws.o(rr, 5, CT("=C%d-D%d" % (rr, rr), sum(1 for d in dong if _t(d.get("ten"))) - co_ma), K.lech)
    kq = "Khớp" if sum(1 for d in dong if _t(d.get("ten"))) == co_ma else "THIẾU MÃ NV"
    ws.o(rr, 6, CT('=IF(E%d=0,"Khớp","THIẾU MÃ NV")' % rr, kq), K.kq)
    ket_qua.append(("F%d" % rr, "l", kq))
    r[0] += 1
    dong_kiem("Tổng thu nhập %s ↔ lương chính + phụ cấp + thu nhập khác %s" % (SO["tong_tn"], SO["tn_tl"]),
              "=" + B("tong_tn"), tong["tong_tn"], "=" + B("tn_tl"), tong["tn_tl"], SS_DONG)
    dong_kiem("Thực lĩnh %s ↔ tổng thu nhập - khấu trừ %s" % (SO["thuc_linh"], SO["tl_tl"]),
              "=" + B("thuc_linh"), tong["thuc_linh"], "=" + B("tl_tl"), tong["tl_tl"], SS_DONG)
    so_lech = lambda k: sum(1 for v in tinh if abs(v[k]) > ts.sai_so)          # noqa: E731
    for k, t in (("tn_lech", "Số dòng lệch tổng thu nhập"), ("tl_lech", "Số dòng lệch thực lĩnh")):
        rr = r[0]
        stt[0] += 1
        ws.o(rr, 1, stt[0], K.chu_g)
        ws.o(rr, 2, t + " (quá sai số TS_SAI_SO) - lọc cột %s trên sheet BangLuong" % SO[k], K.chu_xd)
        f = "=SUMPRODUCT(--(ABS(BangLuong!$%s$%d:$%s$%d)>TS_SAI_SO))" % (L(k), r0, L(k), r1)
        x = so_lech(k)
        ws.o(rr, 3, CT(f, x), K.ct)
        ws.o(rr, 4, 0, K.so)
        ws.o(rr, 5, CT("=C%d-D%d" % (rr, rr), x), K.lech)
        kq = "Khớp" if x == 0 else "LỆCH"
        ws.o(rr, 6, CT('=IF(C%d=0,"Khớp","LỆCH")' % rr, kq), K.kq)
        ket_qua.append(("F%d" % rr, "l", kq))
        r[0] += 1
    dong_kiem("BH người lao động %s ↔ %s × 10,5%% (tham khảo: người không tham gia BH, trần, căn cứ đóng)" % (SO["bh"], SO["ltbh"]),
              "=" + B("bh"), tong["bh"], "=" + B("bh_tl"), tong["bh_tl"], SS_DONG, loai="y")
    dong_kiem("Thuế TNCN %s ↔ biểu lũy tiến (tham khảo: thu nhập miễn thuế, người không cư trú, khấu trừ 10%%)" % SO["thue"],
              "=" + B("thue"), tong["thue"], "=" + B("thue_tl"), tong["thue_tl"], SS_DONG, loai="y")
    if trich.get("_co_dn"):
        dong_kiem("BH + KPCĐ doanh nghiệp ghi trên bảng lương ↔ tính lại (sheet TrichTheoLuong)",
                  "=" + Tt("dn_bang"), trich["dn_bang"], "=" + Tt("cong_dn"), trich["cong_dn"], SS_DONG, loai="y")
    # ---- B. doi chieu so ke toan
    muc("B. ĐỐI CHIẾU VỚI SỔ KẾ TOÁN THÁNG (chứng từ đã ghi sổ)")
    co_so = bool(so_kt.get("co_dc"))
    if not co_so:
        ws.gop(r[0], 1, r[0], 6, "Không đối chiếu theo tháng: " + (_t(so_kt.get("ly_do")) or "kỳ nhiều tháng / cả năm hoặc ngoài năm tài chính") + ".", K.nghieng)
        r[0] += 1
    else:
        dau_bang("Bảng lương (công thức)", "Sổ kế toán")
        a, aai = so(so_kt.get("a")), so(so_kt.get("a_ai"))
        rr = r[0]
        ws.o(rr, 2, "   Có TK 334 - chứng từ lương khác (không phải Bảng lương AI)", K.chu_xd)
        ws.o(rr, 4, a, K.so)
        ws.o(rr + 1, 2, "   Có TK 334 - chứng từ Bảng lương AI của kỳ", K.chu_xd)
        ws.o(rr + 1, 4, aai, K.so)
        for q in (rr, rr + 1):
            for c in (1, 3, 5, 6):
                ws.o(q, c, "", K.chu)
        r[0] += 2
        dong_kiem("Lương phải trả: tổng thu nhập ↔ Có TK 334 cộng hai dòng trên", "=" + B("tong_tn"), tong["tong_tn"],
                  "=D%d+D%d" % (rr, rr + 1), D(a) + D(aai), SS_SO, chua="CHƯA HẠCH TOÁN")
        dong_kiem("Khấu trừ lương (BH NLĐ, thuế TNCN, tạm ứng, trừ khác) ↔ Nợ TK 334 đối ứng khác 111, 112, 334",
                  "=" + B("kt"), tong["kt"], so(so_kt.get("tru")), so(so_kt.get("tru")), SS_SO, chua="CHƯA HẠCH TOÁN")
        rr = r[0]
        ws.o(rr, 2, "   Chi lương: Nợ 334 / Có 111, 112 từ %s đến %s" % (_t(so_kt.get("dc1")), _t(so_kt.get("dc2"))), K.chu_xd)
        ws.o(rr, 4, so(so_kt.get("chi")), K.so)
        ws.o(rr + 1, 2, "   Sổ phụ ngân hàng nhóm Chi lương chưa lập chứng từ (cùng khoảng ngày)", K.chu_xd)
        ws.o(rr + 1, 4, so(so_kt.get("sp_chua")), K.so)
        for q in (rr, rr + 1):
            for c in (1, 3, 5, 6):
                ws.o(q, c, "", K.chu)
        r[0] += 2
        dong_kiem("Thực lĩnh ↔ đã chi (cộng hai dòng trên)", "=" + B("thuc_linh"), tong["thuc_linh"], "=D%d+D%d" % (rr, rr + 1),
                  D(so(so_kt.get("chi"))) + D(so(so_kt.get("sp_chua"))), SS_SO, chua="CHƯA CHI")
        dong_kiem("Thuế TNCN khấu trừ trên bảng ↔ Có TK %s trong tháng" % (_t(tk.get("tncn")) or "3335"), "=" + B("thue"), tong["thue"],
                  so(so_kt.get("co_tncn")), so(so_kt.get("co_tncn")), SS_SO, loai="y", chua="CHƯA HẠCH TOÁN")
        for kx, kb, ten, bh_nld in (("xh", "co_bhxh", "BHXH", "bhxh_nv"), ("yt", "co_bhyt", "BHYT", "bhyt_nv"),
                                    ("tn", "co_bhtn", "BHTN", "bhtn_nv"), ("kpcd", "co_kpcd", "KPCĐ", None)):
            tkx = _t(tk.get({"xh": "bhxh", "yt": "bhyt", "tn": "bhtn", "kpcd": "kpcd"}[kx]))
            if bh_nld:
                f3 = "=%s+%s" % (Tt(kx), B(bh_nld))
                v3 = D(trich[kx]) + D(tong[bh_nld])
                nd = "%s: doanh nghiệp tính lại + người lao động theo bảng ↔ Có TK %s trong tháng" % (ten, tkx)
            else:
                f3 = "=" + Tt(kx)
                v3 = D(trich[kx])
                nd = "KPCĐ doanh nghiệp tính lại ↔ Có TK %s trong tháng" % tkx
            dong_kiem(nd, f3, v3, so(so_kt.get(kb)), so(so_kt.get(kb)), SS_SO, loai="y", chua="CHƯA HẠCH TOÁN")
    # bang luong cua phan mem
    if pm.get("co_dc") and pm.get("nv"):
        tn_pm = sum(D(so(x.get("tn"))) for x in pm.get("nv") or [])
        tl_pm = sum(D(so(x.get("tl"))) for x in pm.get("nv") or [])
        dong_kiem("Tổng thu nhập ↔ bảng lương tính trong phần mềm (Lao động - tiền lương) - chi tiết sheet DoiChieuNV",
                  "=" + B("tong_tn"), tong["tong_tn"], N(tn_pm), tn_pm, SS_SO, loai="y")
        dong_kiem("Thực lĩnh ↔ bảng lương tính trong phần mềm", "=" + B("thuc_linh"), tong["thuc_linh"], N(tl_pm), tl_pm, SS_SO, loai="y")
    # ---- C. tong hop theo bo phan
    muc("C. TỔNG HỢP THEO BỘ PHẬN (cộng từ sheet BangLuong)")
    hd = ["STT", "Bộ phận", "Số người", "Tổng thu nhập", "BH người lao động", "Thực lĩnh"]
    ws.dong(r[0], 1, hd, K.h)
    ws.o(r[0], 7, "Thuế TNCN", K.h)
    ws.o(r[0], 8, "Tạm ứng + trừ khác", K.h)
    ws.o(r[0], 9, "BH + KPCĐ doanh nghiệp", K.h)
    ws.rong(7, 16)
    ws.rong(8, 16)
    ws.rong(9, 18)
    r[0] += 1
    bps, khoa_bp = [], []
    for d in dong:
        b = trim_excel(d.get("bo_phan"))
        if khoa_so_sanh(b) not in khoa_bp:
            khoa_bp.append(khoa_so_sanh(b))
            bps.append(b)
    rng = lambda k: "BangLuong!$%s$%d:$%s$%d" % (L(k), r0, L(k), r1)                  # noqa: E731
    rngT = lambda k: "TrichTheoLuong!$%s$%d:$%s$%d" % (_lt(k), r0, _lt(k), r1)        # noqa: E731
    rb0 = r[0]
    for i, b in enumerate(bps):
        rr = r[0]
        ws.o(rr, 1, i + 1, K.chu_g)
        ws.o(rr, 2, Chu(b) if b else "(không ghi bộ phận)", K.chu)
        dk = ('(TRIM(%s)=$B%d)' % (rng("bo_phan"), rr)) if b else ('(LEN(TRIM(%s))=0)' % rng("bo_phan"))
        dkT = ('(TRIM(%s)=$B%d)' % (rngT("bp"), rr)) if b else ('(LEN(TRIM(%s))=0)' % rngT("bp"))
        chon = [j for j, d in enumerate(dong) if khoa_so_sanh(d.get("bo_phan")) == khoa_so_sanh(b)]
        ws.o(rr, 3, CT("=SUMPRODUCT(--%s)" % dk, len(chon)), K.ct)
        ws.o(rr, 4, CT("=SUMPRODUCT(%s*%s)" % (dk, rng("tong_tn")), N(sum(D(so(dong[j].get("tong_tn"))) for j in chon))), K.ct)
        ws.o(rr, 5, CT("=SUMPRODUCT(%s*%s)" % (dk, rng("bh")), N(sum(tinh[j]["bh"] for j in chon))), K.ct)
        ws.o(rr, 6, CT("=SUMPRODUCT(%s*%s)" % (dk, rng("thuc_linh")), N(sum(D(so(dong[j].get("thuc_linh"))) for j in chon))), K.ct)
        ws.o(rr, 7, CT("=SUMPRODUCT(%s*%s)" % (dk, rng("thue")), N(sum(D(so(dong[j].get("thue"))) for j in chon))), K.ct)
        ws.o(rr, 8, CT("=SUMPRODUCT(%s*(%s+%s))" % (dk, rng("tam_ung"), rng("tru_khac")),
                       N(sum(D(so(dong[j].get("tam_ung"))) + D(so(dong[j].get("tru_khac"))) for j in chon))), K.ct)
        dn_bp = sum(D(sum(trich_dn(tinh[j]["ltbh"], ts).values())) for j in chon)
        ws.o(rr, 9, CT("=SUMPRODUCT(%s*%s)" % (dkT, rngT("cong_dn")), N(dn_bp)), K.ct)
        r[0] += 1
    rb1 = r[0] - 1
    rr = r[0]
    ws.gop(rr, 1, rr, 2, "CỘNG CÁC BỘ PHẬN", K.tong_chu)
    tg = {}
    for c in range(3, 10):
        cc = dia_chi(1, c)[:-1]
        if bps:
            vals = [ws._o.get((q, c), (None, 0))[0] for q in range(rb0, rb1 + 1)]
            v = sum(D(x.v) for x in vals)
            ws.o(rr, c, CT("=SUM(%s%d:%s%d)" % (cc, rb0, cc, rb1), N(v)), K.tong)
        else:
            v = Decimal(0)
            ws.o(rr, c, 0, K.tong)
        tg[c] = v
    r[0] += 1
    rr = r[0]
    ws.gop(rr, 1, rr, 2, "Kiểm: cộng bộ phận - tổng bảng lương (phải = 0)", K.chu)
    so_sanh = {3: ("COUNTA(BangLuong!$%s$%d:$%s$%d)" % (L("ten"), r0, L("ten"), r1), D(sum(1 for d in dong if _t(d.get("ten"))))),
               4: (B("tong_tn"), tong["tong_tn"]), 5: (B("bh"), tong["bh"]), 6: (B("thuc_linh"), tong["thuc_linh"]),
               7: (B("thue"), tong["thue"]), 8: ("%s+%s" % (B("tam_ung"), B("tru_khac")), tong["tam_ung"] + tong["tru_khac"]),
               9: (Tt("cong_dn"), trich["cong_dn"])}
    lech_bp = Decimal(0)
    for c in range(3, 10):
        cc = dia_chi(1, c)[:-1]
        f, v = so_sanh[c]
        ws.o(rr, c, CT("=%s%d-(%s)" % (cc, rr - 1, f), N(tg[c] - D(v))), K.lech)
        lech_bp += abs(tg[c] - D(v))
    ws.to_mau(rr, 3, rr, 9, "%s<>0" % dia_chi(rr, 3), nen="FFC7CE", mau="9C0006", dam=True)
    r[0] += 1
    # ---- D. ket luan
    muc("D. KẾT LUẬN")
    rr = r[0]
    ds_l = ",".join(o for o, loai, _ in ket_qua if loai == "l")
    ds_y = ",".join(o for o, loai, _ in ket_qua if loai == "y")
    n_l = sum(1 for _, loai, kq in ket_qua if loai == "l" and kq != "Khớp")
    n_y = sum(1 for _, loai, kq in ket_qua if loai == "y" and kq != "Khớp")

    def dem(ds):
        return "+".join('SUMPRODUCT(--(%s<>"Khớp"))' % o for o in ds.split(",")) if ds else "0"
    ws.o(rr, 2, "Số mục CẦN XỬ LÝ (kết quả khác Khớp ở các dòng kiểm tra chính xác)", K.chu_xd)
    ws.o(rr, 3, CT("=" + dem(ds_l), n_l), K.ct)
    ws.o(rr + 1, 2, "Số mục NÊN XEM LẠI (tham khảo: BH, thuế, trích theo lương, bảng lương phần mềm)", K.chu_xd)
    ws.o(rr + 1, 3, CT("=" + dem(ds_y), n_y), K.ct)
    txt_ok = "BẢNG LƯƠNG KHỚP: công thức từng dòng và số trên sổ kế toán đều khớp."
    f = '=IF(C%d=0,IF(C%d=0,"%s","Công thức và sổ khớp; có "&C%d&" mục tham khảo nên xem lại (BH / thuế / trích theo lương)."),"CÓ "&C%d&" MỤC CẦN XỬ LÝ (lệch / thiếu mã NV / chưa hạch toán / chưa chi) - xem cột Kết quả tô đỏ ở trên, lọc cột Lệch trên sheet BangLuong.")' % (
        rr, rr + 1, txt_ok, rr + 1, rr)
    if n_l == 0:
        v = txt_ok if n_y == 0 else "Công thức và sổ khớp; có %d mục tham khảo nên xem lại (BH / thuế / trích theo lương)." % n_y
    else:
        v = "CÓ %d MỤC CẦN XỬ LÝ (lệch / thiếu mã NV / chưa hạch toán / chưa chi) - xem cột Kết quả tô đỏ ở trên, lọc cột Lệch trên sheet BangLuong." % n_l
    ws.gop(rr + 2, 2, rr + 2, 6, CT(f, v), K.ket_luan)
    ws.cao(rr + 2, 34)
    # to mau cot Ket qua
    ws.to_mau(7, 6, rr, 6, 'OR(F7="LỆCH",F7="CHƯA HẠCH TOÁN",F7="CHƯA CHI",F7="THIẾU MÃ NV")', nen="FFC7CE", mau="9C0006", dam=True)
    ws.to_mau(7, 6, rr, 6, 'F7="XEM LẠI"', nen="FFEB9C", mau="9C5700", dam=True)
    ws.to_mau(7, 6, rr, 6, 'F7="Khớp"', nen="C6EFCE", mau="006100")
    ws.to_mau(rr + 2, 2, rr + 2, 2, "$C$%d>0" % rr, nen="FFC7CE", mau="9C0006", dam=True)
    r[0] = rr + 4
    ws.o(r[0], 2, "Ghi chú: 'Khớp' khi lệch không quá sai số (ThamSo: TS_SAI_SO mỗi dòng, TS_SAI_SO_SO với sổ kế toán). "
                  "Mục tham khảo (XEM LẠI) không tính vào kết luận sai lệch. Phần mềm KHÔNG tự sửa số liệu.", K.nghieng)
    ws.o(r[0] + 1, 2, "Người lập: %s" % (_t(dn.get("nguoi_lap")) or "........................"), K.nghieng)
    ws.in_trang(ngang=False)
    if n_l:
        cb.append("Có %d mục cần xử lý trên bảng đối chiếu." % n_l)
    if lech_bp:
        cb.append("Cộng theo bộ phận khác tổng bảng lương (kiểm tra lại dữ liệu).")


def _lap_bao_cao(ws, K, dl):
    ws.o(1, 1, "BÁO CÁO ĐỐI CHIẾU BẢNG LƯƠNG CỦA PHẦN MỀM (dạng chữ, như màn hình Đối chiếu)", K.td2)
    txt = str(dl.get("bc_txt") or "").replace("\r\n", "\n").replace("\r", "\n")
    for i, dong in enumerate(txt.split("\n")):
        ws.o(i + 3, 1, Chu(dong), None)
    ws.in_trang(ngang=False)


# ------------------------------------------------------------------ chay tu tool_htkk_unesco
def _ten_an_toan(s):
    s = re.sub(r"[^0-9A-Za-z_\-]+", "_", s or "")
    return s.strip("_")[:60] or "BangLuong"


def chay(duong_json, ra="", ghi_log=None):
    """duong_json: JSON do VB ghi; ra: tep .xlsx (trong: canh tep JSON). Tra ve (duong, loi)."""
    try:
        with open(duong_json, "r", encoding="utf-8-sig") as f:
            dl = json.loads(f.read(), strict=False)
    except Exception as e:
        return None, "Không đọc được số liệu bảng lương: %s" % e
    if not ra:
        ky = dl.get("ky") or {}
        ra = os.path.join(os.path.dirname(os.path.abspath(duong_json)), "DoiChieu_BangLuong_%s_%s.xlsx" % (
            _ten_an_toan(str(ky.get("ma") or "")), _dt.datetime.now().strftime("%Y%m%d_%H%M%S")))
    try:
        duong, cb = lap(dl, ra)
    except PermissionError:
        return None, "Tệp Excel đang mở - đóng tệp rồi làm lại: %s" % ra
    if ghi_log:
        ghi_log("[DOI CHIEU LUONG] %s - %d dong%s" % (duong, len(dl.get("dong") or []), ("; " + "; ".join(cb)) if cb else ""))
    return duong, None
