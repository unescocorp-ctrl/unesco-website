# -*- coding: utf-8 -*-
"""GD359b - DOC EXCEL "XUAT CHI TIET" TAI TRANG hoadondientu.gdt.gov.vn (ban_chi_tiet_... / mua_chi_tiet_...xlsx).
Moi dong = 1 dong hang; cac dong cung (mau so, ky hieu, so HD, MST nguoi ban) = 1 hoa don. Dung cho hoa don MAY TINH TIEN
(cong bat captcha moi lan tra cuu: nguoi dung xuat Excel 1 lan tren cong roi dua vao tool) va ca HD dien tu thuong.
Tra ve danh sach {"hd": dau HD dang JSON cong (nbmst, khhdon, shdon, tdlap ...), "ds": dong hang dang /invoices/detail,
"huong": "ban"/"mua", "kind": "mtt"/"dt"} - tool_tai_hoa_don_unesco dua qua dung duong xuat JSONL cho UNESCO nhu HD tai tu cong."""
import re
from collections import OrderedDict

COT = {  # ten cot (khong dau, thuong) -> khoa
    "ky hieu mau so": "khmshdon", "ky hieu hoa don": "khhdon", "so hoa don": "shdon", "ngay lap": "tdlap",
    "ngay nguoi ban ky so": "nky", "mccqt": "mhdon", "ngay cqt ky so": "ncma", "don vi tien te": "dvtte", "ty gia": "tgia",
    "ten nguoi ban/ten nguoi xuat hang": "nbten", "mst nguoi ban/mst nguoi xuat hang": "nbmst", "dia chi nguoi ban": "nbdchi",
    "ten nguoi mua/ten nguoi nhan hang": "nmten", "ho ten nguoi mua": "nmtnmua", "mst nguoi mua/mst nguoi nhan hang": "nmmst",
    "dia chi nguoi mua": "nmdchi", "can cuoc cong dan": "nmcccd", "hinh thuc thanh toan": "thtttoan", "tinh chat": "tchat_ten",
    "ma vat tu": "mhhdvu", "ten hang hoa, dich vu": "ten", "don vi tinh": "dvtinh", "so luong": "sluong", "don gia": "dgia",
    "chiet khau": "stckhau", "thue suat": "tsuat", "thanh tien chua thue": "thtien", "tien thue": "tthue",
    "tong tien chiet khau thuong mai": "ttcktmai", "tong tien thanh toan": "tgtttbso", "trang thai hoa don": "tthai_ten",
    "ket qua kiem tra hoa don": "ttxly_ten", "hoa don lien quan": "hd_lq", "thong tin lien quan": "tt_lq",
}
TTHAI = {"hóa đơn mới": "1", "hóa đơn thay thế": "2", "hóa đơn điều chỉnh": "3", "hóa đơn đã bị thay thế": "4",
         "hóa đơn đã bị điều chỉnh": "5", "hóa đơn đã bị hủy": "6"}
TTXLY = {"cục thuế đã nhận": "0", "đã cấp mã hóa đơn": "5", "cục thuế đã nhận không mã": "6",
         "đã kiểm tra định kỳ hđđt không có mã": "7", "cục thuế đã nhận hóa đơn có mã khởi tạo từ máy tính tiền": "8"}
TCHAT = {"hàng hóa, dịch vụ": "1", "khuyến mại": "2", "chiết khấu thương mại": "3", "ghi chú, diễn giải": "4"}


def _kd(s):
    import unicodedata
    s = unicodedata.normalize("NFD", str(s or "").replace("đ", "d").replace("Đ", "D"))
    return re.sub(r"\s+", " ", "".join(c for c in s if unicodedata.category(c) != "Mn")).strip().lower()


def _so(v):
    if v is None or v == "":
        return 0.0
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip().replace(" ", "")
    if re.match(r"^-?\d{1,3}(\.\d{3})+(,\d+)?$", s):          # 1.234.567,5
        s = s.replace(".", "").replace(",", ".")
    else:
        s = s.replace(",", "")
    try:
        return float(s)
    except ValueError:
        return 0.0


def _ngay(v):
    """'01/10/2026' / datetime -> '2026-10-01T00:00:00' (gio VN, khong mui gio - ngay_vn giu nguyen ngay)."""
    import datetime as dt
    if isinstance(v, dt.datetime):
        return v.strftime("%Y-%m-%dT%H:%M:%S")
    if isinstance(v, dt.date):
        return v.strftime("%Y-%m-%dT00:00:00")
    m = re.match(r"^(\d{1,2})/(\d{1,2})/(\d{4})", str(v or "").strip())
    return "%s-%02d-%02dT00:00:00" % (m.group(3), int(m.group(2)), int(m.group(1))) if m else str(v or "")


def la_excel_cong(duong):
    """Tep co dung mau Xuat chi tiet cua cong thue khong (doc dong tieu de)."""
    try:
        h = _tieu_de(duong)
        return all(k in h.values() for k in ("khhdon", "shdon", "nbmst", "ten"))
    except Exception:
        return False


def _mo(duong):
    import openpyxl
    wb = openpyxl.load_workbook(duong, read_only=True, data_only=True)
    return wb, wb.worksheets[0]


def _tieu_de(duong):
    wb, ws = _mo(duong)
    try:
        for i, r in enumerate(ws.iter_rows(values_only=True)):
            h = {j: COT[_kd(c)] for j, c in enumerate(r) if _kd(c) in COT}
            if len(h) >= 5:
                return h
            if i > 10:
                break
        return {}
    finally:
        wb.close()


def doc(duong, mst_cty=""):
    """-> (danh sach HD, so dong hang). huong: MST nguoi ban = MST cong ty -> ban, nguoc lai mua."""
    wb, ws = _mo(duong)
    hd_map, dau, n = OrderedDict(), None, 0
    so_cty = re.sub(r"\D", "", str(mst_cty or ""))
    try:
        for r in ws.iter_rows(values_only=True):
            if dau is None:
                h = {j: COT[_kd(c)] for j, c in enumerate(r) if _kd(c) in COT}
                if len(h) >= 5:
                    dau = h
                continue
            v = {k: r[j] for j, k in dau.items() if j < len(r)}
            if not v.get("shdon") and not v.get("khhdon"):
                continue
            n += 1
            nbmst = str(v.get("nbmst") or "").strip()
            khoa = (str(v.get("khmshdon") or "").strip(), str(v.get("khhdon") or "").strip(), str(v.get("shdon") or "").strip(), nbmst)
            if khoa not in hd_map:
                khhd = khoa[1]
                xly = _kd(v.get("ttxly_ten"))
                kind = "mtt" if ("may tinh tien" in xly or (len(khhd) >= 4 and khhd[3].upper() == "M")) else "dt"
                huong = "ban" if (so_cty and re.sub(r"\D", "", nbmst) == so_cty) else ("mua" if so_cty else "ban")
                hd = {"khmshdon": khoa[0], "khhdon": khhd, "shdon": khoa[2], "tdlap": _ngay(v.get("tdlap")), "nky": _ngay(v.get("nky")),
                      "mhdon": str(v.get("mhdon") or ""), "ncma": _ngay(v.get("ncma")) if v.get("ncma") else "",
                      "dvtte": str(v.get("dvtte") or "VND"), "tgia": _so(v.get("tgia")) or 1,
                      "nbten": str(v.get("nbten") or ""), "nbmst": nbmst, "nbdchi": str(v.get("nbdchi") or ""),
                      "nmten": str(v.get("nmten") or ""), "nmtnmua": str(v.get("nmtnmua") or ""), "nmmst": str(v.get("nmmst") or "").strip(),
                      "nmdchi": str(v.get("nmdchi") or ""), "nmcccd": str(v.get("nmcccd") or ""), "thtttoan": str(v.get("thtttoan") or ""),
                      "tgtcthue": 0.0, "tgtthue": 0.0, "tgtttbso": _so(v.get("tgtttbso")), "ttcktmai": _so(v.get("ttcktmai")),
                      "tthai": TTHAI.get(str(v.get("tthai_ten") or "").strip().lower(), "1"),
                      "ttxly": TTXLY.get(str(v.get("ttxly_ten") or "").strip().lower(), "8" if kind == "mtt" else "5"),
                      "nguon": "excel_cong"}
                hd_map[khoa] = {"hd": hd, "ds": [], "huong": huong, "kind": kind}
            o = hd_map[khoa]
            ts = str(v.get("tsuat") or "").strip()
            tc = TCHAT.get(str(v.get("tchat_ten") or "").strip().lower(), "1")
            dong = {"ten": str(v.get("ten") or ""), "mhhdvu": str(v.get("mhhdvu") or ""), "dvtinh": str(v.get("dvtinh") or ""),
                    "sluong": _so(v.get("sluong")), "dgia": _so(v.get("dgia")), "stckhau": _so(v.get("stckhau")),
                    "tsuat": ts, "thtien": _so(v.get("thtien")), "tthue": _so(v.get("tthue")), "tchat": tc}
            o["ds"].append(dong)
            if tc != "4":
                dau_tru = -1 if tc == "3" else 1          # chiet khau thuong mai tru vao tong
                o["hd"]["tgtcthue"] += dau_tru * dong["thtien"]
                o["hd"]["tgtthue"] += dau_tru * dong["tthue"]
    finally:
        wb.close()
    ds = list(hd_map.values())
    for o in ds:
        if not o["hd"]["tgtttbso"]:
            o["hd"]["tgtttbso"] = o["hd"]["tgtcthue"] + o["hd"]["tgtthue"]
    return ds, n


if __name__ == "__main__":
    import sys
    ds, n = doc(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else "")
    from collections import Counter
    print("dong hang", n, "hoa don", len(ds), Counter((o["huong"], o["kind"]) for o in ds))
    o = ds[0]
    print(o["hd"]); print(o["ds"][:2])
    print("tong TT", sum(o["hd"]["tgtttbso"] for o in ds), "lech tong", sum(abs(o["hd"]["tgtcthue"] + o["hd"]["tgtthue"] - o["hd"]["tgtttbso"]) > 2 for o in ds))
