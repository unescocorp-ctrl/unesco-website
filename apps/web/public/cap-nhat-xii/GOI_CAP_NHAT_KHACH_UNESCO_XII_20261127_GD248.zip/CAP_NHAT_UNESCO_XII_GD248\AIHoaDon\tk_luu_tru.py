# -*- coding: utf-8 -*-
"""GD73 - TO KHAI LUU TRU: chi tieu [22] (thue GTGT con duoc khau tru ky truoc chuyen sang) cua to khai 01/GTGT dang lap
= [43] cua to khai CO HIEU LUC ky lien truoc - doc thang tu to khai da luu, khong phai go tay.

Nguon (cung mot ky: bo sung thay chinh thuc, lan sau thay lan truoc, ngay lap moi hon thay cu):
  1. <thu muc khach>\\to-khai-luu-tru\\  tep anh chi chon (XML ket xuat tu HTKK, XML / ZIP tai tu Cong thue) - duoc chep vao day.
  2. <thu muc khach>\\ho-so-thue\\       to khai tai ve o the Ho so thue - Cong DVC (GD54): tep XML / ZIP.
  3. HTKK tren may: DataFiles\\<MST>\\[bs<n>_]01_GTGT_TT<xx>_..._<Qnn|mm><yyyy>_<pb>.xml (to khai HTKK tu luu, dang Sections).
  4. Thu muc Tai ve (Downloads) cua Windows: *01_GTGT*.xml, files_*.zip, *.zip nho (chi nhan dung MST).
Chi DOC - khong sua to khai, khong nop thay.

GD162 (anh Thang 08/10/2026): 01/GTGT tu lay du lieu ky truoc, khong hoi chon tep:
  5. Thu muc to khai anh chi da chon (nguon-ky-truoc.json - menu He thong -> Nguon HTKK, to khai va BCTC ky truoc), ca thu muc con.
  tim() tra them: to khai gan nhat truoc ky (VB chuyen tiep [43] qua cac ky chua co to khai), chi tieu cua to khai ky truoc
  (VB doi chieu voi so), co / khong thong tin chung (nguoi ky, CQT, nganh nghe). ttc_ky_truoc(): thong tin chung cua to khai
  gan nhat (XML / ZIP: TTinChung + ma nganh nghe, tieu muc; tep HTKK tu luu: nguoi ky, nganh nghe trong ten tep, tieu muc).
"""
import calendar
import io
import os
import re
import shutil
import time
import zipfile
import xml.etree.ElementTree as ET
from datetime import date, datetime

import hstk_dvc as H

THU_MUC_LUU = "to-khai-luu-tru"
RE_HTKK = re.compile(r"^(?:bs(\d+)_)?01_GTGT_TT\d+_.*?_(Q?)(\d{2})(\d{4})_\d+\.xml$", re.I)
RE_TAI_VE = re.compile(r"(01_GTGT|01-GTGT|01GTGT).*\.xml$|^files_.*\.zip$", re.I)
TOI_DA_TEP = 400
GIAY_QUET_THU_MUC = 12          # GD162: thu muc anh chi chon co the rat lon - quet toi da 12 giay moi thu muc
GIAY_QUET_TONG = 25             # GD162: ca lan quet (VB cho /kytruoc toi da 45 giay)
TOI_DA_TEP_CHON = 300           # GD162: so tep to khai doc toi da trong thu muc da chon (khong an vao phan thu muc Tai ve)
NHAN_THU_MUC_CHON = "thư mục tờ khai đã chọn"
KHOA_TTC = ("maCQTNoiNop", "tenCQTNoiNop", "nguoiKy", "nganhNgheKD", "dchiNNT", "phuongXa", "maTinhNNT", "tenTinhNNT",
            "dthoaiNNT", "faxNNT", "emailNNT", "ma_NganhNghe", "ten_NganhNghe", "tieuMucHachToan")
CT_DOI_CHIEU = ("22", "23", "24", "25", "34", "35", "36", "40", "41", "43")


def _mst(s):
    return re.sub(r"[^0-9-]", "", str(s or "")).strip("-")


def _cung_mst(a, b):
    a, b = _mst(a), _mst(b)
    return bool(a) and bool(b) and a == b


def _ngay_iso(s):
    s = str(s or "").strip()
    for f in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y"):
        try:
            return datetime.strptime(s[:10], f).strftime("%Y-%m-%d")
        except ValueError:
            pass
    return ""


def ten_ky(k):
    return H.ten_ky(k) if k[0] == "Q" else "tháng %02d/%d" % (k[2], k[1])


def _cuoi(k):
    """Chi so thang cuoi ky (so sanh truoc / sau)."""
    return k[1] * 12 + (k[2] * 3 if k[0] == "Q" else k[2])


# ---------------------------------------------------------------------------
#  DOC TUNG LOAI TEP
# ---------------------------------------------------------------------------
def _tu_ban_ghi(r, tep, nguon):
    """Ban ghi hstk_dvc.doc_tep -> to khai chuan hoa (chi 01/GTGT co ky ro rang)."""
    if not isinstance(r, dict) or r.get("loai") != "to_khai" or r.get("mau") != "01/GTGT":
        return None
    k = H.chuan_ky({"to_khai_xml": r})
    ct = r.get("chi_tieu") or {}
    if not k or k[0] not in ("M", "Q") or "43" not in ct:
        return None
    try:
        lan = int(re.sub(r"\D", "", str(r.get("soLan") or "")) or 0)
    except ValueError:
        lan = 0
    return {"ky": k, "ct": ct, "lan": lan, "bs": (r.get("loaiTKhai") or "").upper() == "B" or lan > 0,
            "ngay": _ngay_iso(r.get("ngayLapTKhai")), "mst": _mst(r.get("mst")), "tep": tep, "nguon": nguon}


def doc_tep_xml_zip(tep, nguon):
    """XML ket xuat tu HTKK / XML hoac ZIP tai tu Cong thue -> [to khai]."""
    ra = []
    for r in H.doc_tep(tep):
        x = _tu_ban_ghi(r, tep, nguon)
        if x:
            ra.append(x)
    return ra


def _so(v):
    try:
        return float(str(v).replace(",", "").strip())
    except (TypeError, ValueError):
        return None


def doc_tep_htkk(tep, mst=""):
    """To khai HTKK tu luu (DataFiles\\<MST>\\...): <Sections><Cell Path=".../CTieuTKhaiChinh/ctNN" Value=...>; ky theo ten tep."""
    m = RE_HTKK.match(os.path.basename(tep))
    if not m:
        return None
    k = ("Q" if m.group(2) else "M", int(m.group(4)), int(m.group(3)))
    if (k[0] == "Q" and not 1 <= k[2] <= 4) or (k[0] == "M" and not 1 <= k[2] <= 12):
        return None
    try:
        with open(tep, "rb") as f:
            b = f.read()
        s = b.decode("utf-16") if b[:2] in (b"\xff\xfe", b"\xfe\xff") else b.decode("utf-8-sig", errors="replace")
        g = ET.fromstring(re.sub(r"^\s*<\?xml[^>]*\?>", "", s))
    except Exception:
        return None
    ct, ngay = {}, ""
    for c in g.iter("Cell"):
        p = c.get("Path") or ""
        mm = re.search(r"/CTieuTKhaiChinh/(?:.*/)?ct(\w+)$", p)
        if mm:
            v = _so(c.get("Value"))
            if v is not None:
                ct[mm.group(1)] = v
        elif p.endswith("/ngayKy"):
            ngay = _ngay_iso(c.get("Value"))
    if "43" not in ct:
        return None
    lan = int(m.group(1) or 0)
    if not ngay:
        try:
            ngay = datetime.fromtimestamp(os.path.getmtime(tep)).strftime("%Y-%m-%d")
        except OSError:
            ngay = ""
    return {"ky": k, "ct": ct, "lan": lan, "bs": lan > 0, "ngay": ngay, "mst": _mst(mst), "tep": tep, "nguon": "HTKK trên máy"}


# ---------------------------------------------------------------------------
#  QUET CAC NGUON
# ---------------------------------------------------------------------------
def thu_muc_luu(thu_muc_khach):
    d = os.path.join(thu_muc_khach, THU_MUC_LUU)
    try:
        os.makedirs(d, exist_ok=True)
    except OSError:
        pass
    return d


def _tai_ve():
    ds = []
    for goc in (os.environ.get("USERPROFILE") or "", os.path.expanduser("~")):
        if goc:
            ds.append(os.path.join(goc, "Downloads"))
    ra = []
    for d in ds:
        if os.path.isdir(d) and d not in ra:
            ra.append(d)
    return ra


def _la_to_khai_xml(p):
    """GD162: doc nhanh dau tep - XML to khai co HSoKhaiThue / TKhaiThue (bo hoa don dien tu, tep XML khac)."""
    try:
        with open(p, "rb") as f:
            b = f.read(65536)
    except OSError:
        return False
    return b"HSoKhaiThue" in b or b"TKhaiThue" in b or b"H\x00S\x00o\x00K\x00h\x00a\x00i" in b


def quet(mst, thu_muc_khach="", htkk_goc="", tai_ve=True, them_thu_muc=()):
    """-> (danh sach to khai 01/GTGT dung MST, so tep da doc)."""
    kq, n = [], 0
    het = time.time() + GIAY_QUET_TONG
    nguon_tm = []
    if thu_muc_khach:
        nguon_tm.append((thu_muc_luu(thu_muc_khach), "tờ khai lưu trữ", True))
        nguon_tm.append((os.path.join(thu_muc_khach, "ho-so-thue"), "thẻ Hồ sơ thuế", True))
    for d in them_thu_muc or ():
        if isinstance(d, (tuple, list)):
            nguon_tm.append((d[0], d[1], bool(d[2])))          # GD162: (duong, nhan, quet ca thu muc con)
        else:
            nguon_tm.append((d, "thư mục", False))
    if tai_ve:
        for d in _tai_ve():
            nguon_tm.append((d, "thư mục Tải về", False))
    da = set()
    for d, nhan, de_quy in nguon_tm:
        if not d or not os.path.isdir(d):
            continue
        han = min(time.time() + GIAY_QUET_THU_MUC, het)
        chon = nhan == NHAN_THU_MUC_CHON
        n_chon = 0
        for goc, dn, fs in os.walk(d):
            if time.time() > han:
                break
            if not de_quy:
                dn[:] = []
            dn[:] = [x for x in dn if x not in ("chan-doan", "_dang_tai", "__pycache__")]
            for f in fs:
                if n >= TOI_DA_TEP or time.time() > han or (chon and n_chon >= TOI_DA_TEP_CHON):
                    break
                p = os.path.join(goc, f)
                fl = f.lower()
                if not (fl.endswith(".xml") or fl.endswith(".zip")):
                    continue
                if chon and fl.endswith(".xml") and not _la_to_khai_xml(p):
                    continue                                   # GD162: hoa don dien tu / XML khac trong thu muc da chon
                if not de_quy and not RE_TAI_VE.search(f) and not (fl.endswith(".zip") and os.path.getsize(p) < 2 * 1024 * 1024):
                    continue
                try:
                    if os.path.getsize(p) > 20 * 1024 * 1024:
                        continue
                except OSError:
                    continue
                key = os.path.normcase(os.path.abspath(p))
                if key in da:
                    continue
                da.add(key)
                if chon:
                    n_chon += 1
                else:
                    n += 1
                for x in doc_tep_xml_zip(p, "%s: %s" % (nhan, f)):
                    if _cung_mst(x["mst"], mst):
                        kq.append(x)
    if htkk_goc and mst:
        for ten in dict.fromkeys((_mst(mst), _mst(mst).replace("-", ""))):
            d = os.path.join(htkk_goc, "DataFiles", ten)
            if not os.path.isdir(d):
                continue
            for f in os.listdir(d):
                if RE_HTKK.match(f):
                    n += 1
                    x = doc_tep_htkk(os.path.join(d, f), mst)
                    if x:
                        x["nguon"] = "HTKK trên máy: %s" % f
                        kq.append(x)
            break
    return kq, n


def _uu_tien(x):
    nguon = x.get("nguon") or ""
    hang = 3 if nguon.startswith("thẻ Hồ sơ thuế") else 2 if nguon.startswith(("tờ khai lưu trữ", NHAN_THU_MUC_CHON)) else 1
    return (1 if x["bs"] else 0, x["lan"], x["ngay"] or "", hang)


def hieu_luc(ds):
    """{ky: to khai co hieu luc}."""
    tot = {}
    for x in ds:
        k = x["ky"]
        if k not in tot or _uu_tien(x) > _uu_tien(tot[k]):
            tot[k] = x
    return tot


def ky_cua(d1, d2):
    """(d1, d2) datetime -> ('M'|'Q', nam, so) hoac None."""
    if d1.year == d2.year and d1.month == d2.month:
        return ("M", d1.year, d1.month)
    if d1.year == d2.year and (d1.month - 1) % 3 == 0 and d2.month == d1.month + 2:
        return ("Q", d1.year, (d1.month - 1) // 3 + 1)
    return None


def ung_vien_truoc(k):
    """Ky lien truoc (cung loai), roi ky lien truoc khac loai (doi thang <-> quy) - nhu hstk_dvc.lien_ky."""
    ra = [H.ky_truoc(k)]
    if k[0] == "M" and k[2] in (1, 4, 7, 10):
        ra.append(("Q", k[1] - 1, 4) if k[2] == 1 else ("Q", k[1], (k[2] - 1) // 3))
    if k[0] == "Q":
        ra.append(("M", k[1] - 1, 12) if k[2] == 1 else ("M", k[1], (k[2] - 1) * 3))
    return ra


def them_nguon(thu_muc_khach):
    """GD162: thu muc to khai anh chi da chon (nguon-ky-truoc.json) -> [(duong, nhan, de_quy)]."""
    try:
        import nguon_ky_truoc as NKT
        t = NKT.thu_muc_to_khai(thu_muc_khach) if thu_muc_khach else ""
    except Exception:
        t = ""
    return [(t, NHAN_THU_MUC_CHON, True)] if t else []


def ngay_ky(k):
    """('M'|'Q', nam, so) -> (date dau ky, date cuoi ky)."""
    if k[0] == "Q":
        t1, t2 = k[2] * 3 - 2, k[2] * 3
    else:
        t1 = t2 = k[2]
    return date(k[1], t1, 1), date(k[1], t2, calendar.monthrange(k[1], t2)[1])


def tim(d1, d2, mst, thu_muc_khach="", htkk_goc="", tai_ve=True, ds=None):
    """-> dict: tim_thay, ct43, ky_truoc, nguon, tep, kieu_gan_nhat, ky_gan_nhat, ky_can, so_tep, so_to_khai
       (+ GD162: gan_nhat, ct_truoc, kt_ngay, ttc, ttc_nguon)."""
    k = ky_cua(d1, d2)
    if ds is None:
        ds, n = quet(mst, thu_muc_khach, htkk_goc, tai_ve, them_nguon(thu_muc_khach))
    else:
        n = len(ds)
    tot = hieu_luc(ds)
    kq = {"tim_thay": False, "ky_can": ten_ky(H.ky_truoc(k)) if k else "", "so_tep": n, "so_to_khai": len(tot),
          "kieu_gan_nhat": "", "ky_gan_nhat": ""}
    if not k:
        return kq
    truoc = [x for kk, x in tot.items() if _cuoi(kk) <= _cuoi(k) - (3 if k[0] == "Q" else 1)]
    if truoc:
        g = max(truoc, key=lambda x: _cuoi(x["ky"]))
        kq["kieu_gan_nhat"], kq["ky_gan_nhat"] = g["ky"][0], ten_ky(g["ky"])
        a, b = ngay_ky(g["ky"])          # GD162: VB chuyen tiep [43] cua to khai nay qua cac ky chua co to khai (theo so)
        kq["gan_nhat"] = {"ct43": g["ct"].get("43") or 0.0, "d1": a, "d2": b, "ten": ten_ky(g["ky"]), "nguon": g["nguon"]}
    for u in ung_vien_truoc(k):
        x = tot.get(u)
        if x is not None:
            kq.update({"tim_thay": True, "ct43": x["ct"].get("43") or 0.0, "ky_truoc": ten_ky(u), "nguon": x["nguon"], "tep": x["tep"],
                       "bo_sung": x["bs"], "lan": x["lan"],
                       "ct_truoc": {c: x["ct"][c] for c in CT_DOI_CHIEU if x["ct"].get(c) is not None}, "kt_ngay": ngay_ky(u)})
            break
    kq["ttc"], kq["ttc_nguon"] = ttc_tu_ds(ds, k)
    return kq


# ---------------------------------------------------------------------------
#  GD162 - THONG TIN CHUNG CUA TO KHAI KY TRUOC (nguoi ky, CQT noi nop, dia chi, nganh nghe, tieu muc, dai ly thue)
# ---------------------------------------------------------------------------
def _goc_xml(b):
    if isinstance(b, bytes):
        b = b.lstrip(b"\xef\xbb\xbf \r\n\t")
    return ET.fromstring(b)


def _ttc_xml(root):
    d = {}
    for e in root.iter():
        t = H._ten_the(e.tag)
        if t in KHOA_TTC and t not in d and not list(e):
            v = (e.text or "").strip()
            if v:
                d[t] = v
    for e in root.iter():
        if H._ten_the(e.tag) == "DLyThue":
            dl = {}
            for c in e.iter():
                if not list(c) and (c.text or "").strip():
                    dl.setdefault(H._ten_the(c.tag), c.text.strip())
            if re.fullmatch(r"\d{10}(-\d{3})?|\d{12}", _mst(dl.get("mstDLyThue"))):
                d["dly"] = dl
            break
    return d


def _ttc_htkk(tep):
    """Tep HTKK tu luu (Sections): o nguoi ky, nganh nghe, tieu muc (path_1); ma nganh nghe trong ten tep (CQTQL<ma>_<nganh>_)."""
    d = {}
    try:
        with open(tep, "rb") as f:
            b = f.read()
        s = b.decode("utf-16") if b[:2] in (b"\xff\xfe", b"\xfe\xff") else b.decode("utf-8-sig", errors="replace")
        g = ET.fromstring(re.sub(r"^\s*<\?xml[^>]*\?>", "", s))
    except Exception:
        return d
    for c in g.iter("Cell"):
        p = c.get("Path") or ""
        v = (c.get("Value") or "").strip()
        if not v:
            continue
        for k in ("nguoiKy", "ma_NganhNghe", "ten_NganhNghe"):
            if p.endswith("/" + k) and k not in d:
                d[k] = v
        if p == "path_1" and re.fullmatch(r"\d{4}", v):
            d["tieuMucHachToan"] = v
    m = re.search(r"_CQTQL\d+_(\d{2})_", os.path.basename(tep))
    if m and "ma_NganhNghe" not in d:
        d["ma_NganhNghe"] = m.group(1)
    return d


def ttc_tep(x):
    """To khai (ban ghi cua quet) -> thong tin chung doc tu tep. Khong doc duoc -> {}."""
    tep = x.get("tep") or ""
    try:
        if RE_HTKK.match(os.path.basename(tep)):
            return _ttc_htkk(tep)
        if zipfile.is_zipfile(tep):
            with zipfile.ZipFile(tep) as z:
                for nm in z.namelist():
                    if not nm.lower().endswith(".xml"):
                        continue
                    try:
                        r = _goc_xml(z.read(nm))
                    except Exception:
                        continue
                    if H.ma_mau(H._chu_the(r, "tenTKhai")) == "01/GTGT":
                        return _ttc_xml(r)
            return {}
        with open(tep, "rb") as f:
            return _ttc_xml(_goc_xml(f.read()))
    except Exception:
        return {}


def ttc_tu_ds(ds, k, toi_da=8):
    """Gop thong tin chung cua cac to khai TRUOC ky k (moi nhat truoc; XML / ZIP truoc tep HTKK tu luu). -> (ttc, nguon)."""
    moc = (_cuoi(k) - (3 if k[0] == "Q" else 1)) if k else 10 ** 9
    cac = [x for x in ds if _cuoi(x["ky"]) <= moc]
    cac.sort(key=lambda x: (_cuoi(x["ky"]), 0 if RE_HTKK.match(os.path.basename(x.get("tep") or "")) else 1, _uu_tien(x)), reverse=True)
    ttc, nguon = {}, ""
    for x in cac[:toi_da]:
        d = ttc_tep(x)
        moi = [kk for kk in d if kk not in ttc]
        if moi and not nguon:
            nguon = "tờ khai %s (%s)" % (ten_ky(x["ky"]), x.get("nguon") or "")
        for kk in moi:
            ttc[kk] = d[kk]
        if all(kk in ttc for kk in ("nguoiKy", "maCQTNoiNop", "ma_NganhNghe", "tieuMucHachToan")):
            break
    return ttc, nguon


def ttc_ky_truoc(d1, d2, mst, thu_muc_khach="", htkk_goc="", tai_ve=True):
    """Thong tin chung cua to khai gan nhat truoc ky (d1, d2) -> (ttc, nguon)."""
    k = ky_cua(d1, d2)
    ds, _ = quet(mst, thu_muc_khach, htkk_goc, tai_ve, them_nguon(thu_muc_khach))
    return ttc_tu_ds(ds, k)


def luu_tep(tep, mst, thu_muc_khach):
    """Chep tep to khai 01/GTGT anh chi chon vao to-khai-luu-tru (neu dung MST). -> ([to khai], loi)."""
    if not os.path.isfile(tep):
        return [], "Không thấy tệp: %s" % tep
    ds = doc_tep_xml_zip(tep, "tờ khai lưu trữ: %s" % os.path.basename(tep))
    if not ds:
        return [], "Tệp %s không phải tờ khai 01/GTGT (XML kết xuất từ HTKK hoặc XML / ZIP tải từ Cổng thuế)." % os.path.basename(tep)
    dung = [x for x in ds if not mst or _cung_mst(x["mst"], mst)]
    if not dung:
        return [], "Tờ khai trong tệp %s là của MST %s, không phải MST %s đang mở - không dùng." % (os.path.basename(tep), ds[0]["mst"], _mst(mst))
    d = thu_muc_luu(thu_muc_khach)
    dich = os.path.join(d, os.path.basename(tep))
    if os.path.normcase(os.path.abspath(dich)) != os.path.normcase(os.path.abspath(tep)):
        goc, duoi = os.path.splitext(dich)
        i = 1
        while os.path.exists(dich):
            try:
                with open(dich, "rb") as a, open(tep, "rb") as b:
                    if a.read() == b.read():
                        break
            except OSError:
                pass
            dich = "%s_%d%s" % (goc, i, duoi)
            i += 1
        if not os.path.exists(dich):
            shutil.copy2(tep, dich)
    for x in dung:
        x["tep"] = dich
        x["nguon"] = "tờ khai lưu trữ: %s" % os.path.basename(dich)
    return dung, ""


def _dd(v):
    return "{:,.0f}".format(float(v or 0)).replace(",", ".")


def mo_ta_luu(ds):
    """Cau ngan bao da luu to khai nao (cho VB hien)."""
    if not ds:
        return ""
    x = max(ds, key=lambda y: _cuoi(y["ky"]))
    return "Đã lưu tờ khai 01/GTGT %s%s vào tờ khai lưu trữ: [43] = %s sẽ tự điền vào [22] của kỳ sau." % (
        ten_ky(x["ky"]), " (bổ sung lần %d)" % x["lan"] if x["lan"] else "", _dd(x["ct"].get("43")))


def ket_qua_vb(kq):
    """Cac dong KHOA=GIA TRI cho VB6 doc (UTF-8)."""
    d = ["OK" if kq.get("tim_thay") else "KHONG"]
    if kq.get("tim_thay"):
        d.append("CT43=%d" % round(float(kq.get("ct43") or 0)))
        d.append("KY_TRUOC=%s%s" % (kq.get("ky_truoc", ""), " (bổ sung lần %d)" % kq["lan"] if kq.get("lan") else ""))
        d.append("NGUON=%s" % kq.get("nguon", ""))
    d.append("KY_CAN=%s" % kq.get("ky_can", ""))
    d.append("KIEU_GAN_NHAT=%s" % kq.get("kieu_gan_nhat", ""))
    d.append("KY_GAN_NHAT=%s" % kq.get("ky_gan_nhat", ""))
    d.append("SO_TEP=%d" % kq.get("so_tep", 0))
    g = kq.get("gan_nhat")
    if g:                                                      # GD162
        d.append("GN_CT43=%d" % round(float(g.get("ct43") or 0)))
        d.append("GN_D1=%s" % g["d1"].strftime("%Y%m%d"))
        d.append("GN_D2=%s" % g["d2"].strftime("%Y%m%d"))
        d.append("GN_KY=%s" % g.get("ten", ""))
        d.append("GN_NGUON=%s" % g.get("nguon", ""))
    if kq.get("tim_thay") and kq.get("kt_ngay"):
        d.append("KT_D1=%s" % kq["kt_ngay"][0].strftime("%Y%m%d"))
        d.append("KT_D2=%s" % kq["kt_ngay"][1].strftime("%Y%m%d"))
        for c, v in sorted((kq.get("ct_truoc") or {}).items()):
            d.append("TK_%s=%d" % (c, round(float(v or 0))))
    t = kq.get("ttc") or {}
    d.append("TTC_NGUOI_KY=%d" % (1 if t.get("nguoiKy") or kq.get("hd_nguoi_ky") else 0))
    d.append("TTC_CQT=%d" % (1 if t.get("maCQTNoiNop") or kq.get("hd_cqt") else 0))
    d.append("TTC_NGANH=%d" % (1 if t.get("ma_NganhNghe") else 0))
    if kq.get("ttc_nguon"):
        d.append("TTC_NGUON=%s" % kq["ttc_nguon"])
    if kq.get("them"):
        d.append("THEM=%s" % kq["them"])
    return "\r\n".join(d) + "\r\n"
