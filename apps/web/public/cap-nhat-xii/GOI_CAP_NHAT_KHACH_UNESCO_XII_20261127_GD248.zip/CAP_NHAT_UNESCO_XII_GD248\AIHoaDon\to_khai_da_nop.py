# -*- coding: utf-8 -*-
"""GD246 - CONG G8: so to khai 01/GTGT DA NOP (the Ho so thue: <thu muc khach>\\ho-so-thue, tai tu Cong thue) voi so.
  K54: (a) to khai nop sau cung cua tung ky (lan bo sung moi nhat) phu du ky kiem -> [24] thue mua vao, [35] thue ban ra
           so voi so tinh lai theo dung cach tinh to khai (dl["gtgt"] thue_vao / thue_ra) -> lech: LOI (khai bo sung hoac sua so);
       (b) noi tiep: [22] ky nay = [43] ky truoc lien ke (thue con duoc khau tru chuyen ky) -> lech: LOI;
       chua co to khai da nop / chi phu mot phan ky -> THONG_TIN.
  Doc to khai bang so_sanh_htkk.doc_xml_tk (GD164). Chi doc.
"""
import os
from datetime import date

TOI_DA_TEP = 600
NGUONG = 1000.0


def _ngay(s):
    try:
        d, m, y = [int(x) for x in str(s).strip().split("/")]
        return date(y, m, d)
    except Exception:
        return None


def _v(ct, k):
    if k in ct:
        return float(ct[k] or 0)
    for kk, v in ct.items():
        if kk.endswith("/" + k) and not kk.startswith(("PL", "BKe")):
            return float(v or 0)
    return 0.0


def _thang(d1, d2):
    out = []
    y, m = d1.year, d1.month
    while (y, m) <= (d2.year, d2.month):
        out.append((y, m))
        m += 1
        if m > 12:
            y, m = y + 1, 1
    return out


def quet(thu_muc, mst=""):
    """-> {(kieu, d1, d2): to khai GTGT nop sau cung} trong <thu_muc>\\ho-so-thue."""
    import so_sanh_htkk as H
    goc = os.path.join(thu_muc, "ho-so-thue")
    if not os.path.isdir(goc):
        return {}
    mst = H._mst(mst)
    tot = {}
    n = 0
    for r, _, fs in os.walk(goc):
        for f in fs:
            if not f.lower().endswith(".xml"):
                continue
            n += 1
            if n > TOI_DA_TEP:
                break
            p = os.path.join(r, f)
            tk = H.doc_xml_tk(p, nguon="ho-so-thue")
            if not tk or tk.get("ho") != "GTGT":
                continue
            if mst and tk.get("mst") and tk["mst"] != mst:
                continue
            try:
                tk["mtime"] = os.path.getmtime(p)
            except OSError:
                tk["mtime"] = 0
            k = tk["ky"]
            uu = (1 if tk.get("bs") else 0, tk.get("lan", 0), tk["mtime"])
            if k not in tot or uu > tot[k][0]:
                tot[k] = (uu, tk)
    return {k: v[1] for k, v in tot.items()}


def k_to_khai_nop(S, _kq, DAT, CANH_BAO, LOI, THONG_TIN, thu_muc=None):
    ten = "Tờ khai 01/GTGT đã nộp khớp sổ và nối tiếp kỳ trước"
    thu_muc = thu_muc or S.dl.get("thu_muc_khach") or ""
    ky = S.dl.get("ky") or {}
    d1, d2 = _ngay(ky.get("tu")), _ngay(ky.get("den"))
    if not thu_muc or not (d1 and d2):
        return None
    ds = quet(thu_muc, (S.dl.get("cty") or {}).get("mst") or "")
    if not ds:
        return [_kq("K54", ten, THONG_TIN, "Chưa có tờ khai 01/GTGT đã nộp trong thẻ Hồ sơ thuế (%s) - tải hồ sơ từ Cổng thuế để so." %
                    os.path.join(thu_muc, "ho-so-thue"))]
    dong = []
    co_loi = False
    # (b) noi tiep [22] = [43] ky truoc lien ke
    ky_sx = sorted(ds, key=lambda k: k[1])
    for a, b in zip(ky_sx, ky_sx[1:]):
        if (b[1] - a[2]).days != 1 or not (d1 <= b[2] and b[1] <= d2):
            continue
        c43, c22 = _v(ds[a]["ct"], "ct43"), _v(ds[b]["ct"], "ct22")
        if abs(c43 - c22) > NGUONG:
            co_loi = True
            dong.append(["%s → %s" % (_ten_ky(a), _ten_ky(b)), "[43] kỳ trước → [22] kỳ này", round(c43), round(c22), round(c22 - c43),
                         "Không nối tiếp: khai bổ sung kỳ trước hoặc sửa [22] kỳ này"])
    # (a) so voi so khi to khai phu du ky kiem
    trong = [k for k in ky_sx if d1 <= k[1] and k[2] <= d2]
    phu = set()
    for k in trong:
        phu.update(_thang(k[1], k[2]))
    du_ky = phu == set(_thang(d1, d2))
    g = S.dl.get("gtgt") or {}
    if trong and du_ky and g:
        v24 = sum(_v(ds[k]["ct"], "ct24") for k in trong)
        v35 = sum(_v(ds[k]["ct"], "ct35") for k in trong)
        for nhan, tk, so in (("[24] Thuế GTGT mua vào", v24, float(g.get("thue_vao") or 0)), ("[35] Thuế GTGT bán ra", v35, float(g.get("thue_ra") or 0))):
            if abs(tk - so) > NGUONG:
                co_loi = True
                dong.append([", ".join(_ten_ky(k) for k in trong), nhan, round(tk), round(so), round(so - tk),
                             "Sổ khác tờ khai đã nộp: khai bổ sung (KHBS) hoặc sửa chứng từ cho đúng"])
    if dong:
        return [_kq("K54", ten, LOI if co_loi else CANH_BAO, "%d chênh lệch giữa tờ khai 01/GTGT đã nộp và sổ / kỳ trước." % len(dong),
                    ["Kỳ", "Chỉ tiêu", "Tờ khai đã nộp", "Sổ / kỳ sau", "Chênh lệch", "Cách xử lý"], dong)]
    if not trong:
        return [_kq("K54", ten, THONG_TIN, "Có %d tờ khai đã nộp nhưng không có kỳ nào nằm trong kỳ kiểm." % len(ds))]
    if not du_ky:
        return [_kq("K54", ten, THONG_TIN, "Tờ khai đã nộp (%s) chưa phủ đủ kỳ kiểm - chưa so [24] / [35]; nối tiếp kỳ trước: khớp." %
                    ", ".join(_ten_ky(k) for k in trong))]
    return [_kq("K54", ten, DAT, "Tờ khai đã nộp (%s) khớp sổ ([24], [35]) và nối tiếp kỳ trước ([22] = [43])." % ", ".join(_ten_ky(k) for k in trong))]


def _ten_ky(k):
    kieu, a, b = k
    if kieu == "M":
        return "T%02d/%d" % (a.month, a.year)
    if kieu == "Q":
        return "Q%d/%d" % ((a.month - 1) // 3 + 1, a.year)
    return "%s-%s" % (a.strftime("%d/%m/%Y"), b.strftime("%d/%m/%Y"))
