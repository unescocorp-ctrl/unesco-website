# -*- coding: utf-8 -*-
"""GD134 - MAU EXCEL + DOC DANH SACH NHAN VIEN de them vao danh muc nhan vien UNESCO.

  * tao_mau(dm, ra)   : tep Excel mau (sheet DanhSachNV co o chon tha xuong Bo phan / Chuc vu / Loai HD..., DanhMuc,
                        NhanVienDaCo, HuongDan). dm = danh muc cua so (VB6 ghi JSON): bo phan, chuc vu, quoc tich, tinh / TP,
                        nhan vien da co.
  * doc_ds(bang, dm)  : doc tep danh sach (mau tren HOAC tep Excel bat ky co dong tieu de Ho va ten...) -> cac dong hop le
                        (gia tri da chuan hoa, ma danh muc) + cac dong bo qua kem ly do.
  * chay_mau / chay_nhap: lenh cho tool_htkk_unesco.py (/maunv:, /nhapnv:) - tep JSON danh muc doc xong XOA.
Tool KHONG ghi so: VB6 (ModNhapNV) xem truoc, hoi, roi them nhan vien qua ClsQuanLyNhanVien.GhiNV (duong ghi cua man hinh
Danh sach nhan vien); nhan vien da co (trung ma / ho ten + ngay sinh / CCCD) KHONG ghi de.
Tep ket qua .dat co so CCCD day du -> VB6 doc xong xoa ngay; bao cao chu chi hien 4 so cuoi CCCD.
"""
import datetime as _dt
import io
import json
import os
import re
import unicodedata

from xlsx_viet import SoExcel

PHIEN_BAN = "GD134"
SO_DONG_MAU = 500

# (khoa, tieu de cot trong mau, do rong, dinh dang chu)
COT = [
    ("stt", "STT", 5, False),
    ("sh", "Mã NV", 10, True),
    ("ten", "Họ và tên (*)", 26, False),
    ("phai", "Giới tính", 9, False),
    ("ns", "Ngày sinh", 11, False),
    ("cccd", "Số CCCD / hộ chiếu", 15, True),
    ("ngay_cap", "Ngày cấp", 11, False),
    ("noi_cap", "Nơi cấp (tỉnh / TP)", 16, False),
    ("tel", "Điện thoại", 13, True),
    ("mail", "Email", 22, False),
    ("dc_hk", "Địa chỉ thường trú", 30, False),
    ("dc_ct", "Địa chỉ cư trú hiện nay", 30, False),
    ("quoc_tich", "Quốc tịch", 12, False),
    ("bo_phan", "Bộ phận (*)", 22, False),
    ("chuc_vu", "Chức vụ", 18, False),
    ("bac", "Bậc lương (1-5)", 8, False),
    ("loai_hd", "Loại hợp đồng", 18, False),
    ("loai_luong", "Loại lương", 14, False),
    ("bh", "Đóng BH bắt buộc", 10, False),
    ("bhxh", "Mã số BHXH", 13, True),
    ("bhyt", "Số thẻ BHYT", 16, True),
    ("mst", "MST cá nhân", 13, True),
    ("thang_vao", "Tháng vào làm (1-12)", 9, False),
    ("ghi_chu", "Ghi chú", 20, False),
]

# nhan dang cot cua tep bat ky: (khoa, cac cum tu khoa - da bo dau, viet thuong). Thu tu: cum dai / dac thu truoc.
NHAN_COT = [
    ("bhxh", ("ma so bhxh", "ma bhxh", "so so bhxh", "so bhxh", "ma so bao hiem xa hoi")),
    ("bhyt", ("so the bhyt", "the bhyt", "ma the bhyt", "so bhyt")),
    ("bh", ("dong bh", "dong bao hiem", "tham gia bh", "tham gia bao hiem", "bh bat buoc", "bao hiem bat buoc")),
    ("ngay_cap", ("ngay cap",)),
    ("noi_cap", ("noi cap",)),
    ("ns", ("ngay thang nam sinh", "ngay sinh", "nam sinh")),
    ("cccd", ("so cccd", "cccd", "cmnd", "can cuoc", "ho chieu", "so dinh danh")),
    ("thang_vao", ("thang vao", "thang tang", "vao lam", "ngay vao")),
    ("sh", ("ma nv", "ma nhan vien", "so hieu", "ma so nv")),
    ("ten", ("ho va ten", "ho ten", "ten nhan vien", "ten nguoi lao dong")),
    ("phai", ("gioi tinh", "phai")),
    ("tel", ("dien thoai", "so dt", "sdt", "di dong")),
    ("mail", ("email", "e-mail", "thu dien tu")),
    ("dc_hk", ("thuong tru", "ho khau")),
    ("dc_ct", ("cu tru", "cho o", "tam tru", "dia chi lien he", "noi o")),
    ("quoc_tich", ("quoc tich",)),
    ("bo_phan", ("bo phan", "phong ban", "phan loai", "don vi cong tac")),
    ("chuc_vu", ("chuc vu", "chuc danh")),
    ("bac", ("bac luong",)),
    ("loai_hd", ("loai hop dong", "loai hd", "hop dong lao dong")),
    ("loai_luong", ("loai luong", "hinh thuc tra luong", "hinh thuc luong")),
    ("mst", ("ma so thue", "mst")),
    ("ghi_chu", ("ghi chu",)),
    ("stt", ("stt", "so tt")),
]

LOAI_HD = [(1, "Không xác định thời hạn"), (2, "Xác định thời hạn (12 - 36 tháng)"), (3, "Dưới 12 tháng / thời vụ")]
LOAI_LUONG = [(1, "Lương hệ số"), (2, "Lương tháng"), (3, "Lương thời vụ"), (4, "Lương ngày")]
GIOI_TINH = ["Nam", "Nữ"]
CO_KHONG = ["Có", "Không"]


# ------------------------------------------------------------------ chuoi
def bo_dau(s):
    s = unicodedata.normalize("NFD", str(s or "")).replace("đ", "d").replace("Đ", "D")
    return "".join(c for c in s if unicodedata.category(c) != "Mn")


def khoa(s):
    """bo dau, viet thuong, mot dau cach, bo ky tu la."""
    t = bo_dau(s).lower().replace("\n", " ")
    t = re.sub(r"[^a-z0-9@\.\-/ ]+", " ", t)
    return " ".join(t.split())


def chu(v):
    if v is None:
        return ""
    if isinstance(v, float):
        return str(int(v)) if v.is_integer() else repr(v)
    if isinstance(v, (_dt.date, _dt.datetime)):
        return v.strftime("%d/%m/%Y")
    s = " ".join(str(v).replace(" ", " ").split())
    return "" if s in ("...", "..", ".", "-") else s


def ngay(v, nam_mac_dinh=None):
    """-> datetime.date hoac None (so ngay Excel, dd/mm/yyyy, yyyy-mm-dd, d-m-yy, chi nam -> 01/01)."""
    if v is None or v == "":
        return None
    if isinstance(v, _dt.datetime):
        return v.date()
    if isinstance(v, _dt.date):
        return v
    if isinstance(v, (int, float)):
        x = float(v)
        if 1000 <= x <= 2200 and x.is_integer():
            return _dt.date(int(x), 1, 1)
        if 1 <= x < 80000:
            return (_dt.datetime(1899, 12, 30) + _dt.timedelta(days=int(x))).date()
        return None
    s = chu(v)
    m = re.match(r"^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})", s)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
    else:
        m = re.match(r"^(\d{1,2})[-/.](\d{1,2})[-/.](\d{2,4})$", s)
        if not m:
            m2 = re.match(r"^(\d{4})$", s)
            return _dt.date(int(m2.group(1)), 1, 1) if m2 and 1900 <= int(m2.group(1)) <= 2100 else None
        d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if y < 100:
            y += 2000 if y <= 30 else 1900
    try:
        return _dt.date(y, mo, d)
    except ValueError:
        return None


def chu_so(s):
    return re.sub(r"\D", "", chu(s))


def che(s, giu=4):
    s = chu(s)
    return ("*" * max(0, len(s) - giu) + s[-giu:]) if s else ""


# ------------------------------------------------------------------ danh muc cua so
class DanhMuc(object):
    """dm (JSON VB6): pl / cv = [[ma, so_hieu, ten]], qg / tinh = [[ma, ten]], nv = [[so_hieu, ten, 'yyyy-mm-dd', ma_pl]],
    cty, mst, nam_tc."""

    def __init__(self, dm):
        dm = dm if isinstance(dm, dict) else {}
        self.cty = chu(dm.get("cty"))
        self.mst = chu(dm.get("mst"))
        try:
            self.nam_tc = int(dm.get("nam_tc") or 0)
        except (TypeError, ValueError):
            self.nam_tc = 0
        self.pl = [(int(x[0]), chu(x[1]), chu(x[2])) for x in (dm.get("pl") or []) if len(x) >= 3 and int(x[0] or 0)]
        self.cv = [(int(x[0]), chu(x[1]), chu(x[2])) for x in (dm.get("cv") or []) if len(x) >= 3 and int(x[0] or 0)]
        self.qg = [(int(x[0]), chu(x[1])) for x in (dm.get("qg") or []) if len(x) >= 2 and int(x[0] or 0)]
        self.tinh = [(int(x[0]), chu(x[1])) for x in (dm.get("tinh") or []) if len(x) >= 2 and int(x[0] or 0)]
        self.nv = [(chu(x[0]), chu(x[1]), chu(x[2]) if len(x) > 2 else "", int(x[3] or 0) if len(x) > 3 else 0)
                   for x in (dm.get("nv") or []) if len(x) >= 2]
        self.sh_co = set(khoa(x[0]) for x in self.nv if x[0])
        self.ten_ns_co = set((khoa(x[1]), x[2]) for x in self.nv if x[1] and x[2])

    @staticmethod
    def _tim(ds, gt, co_so_hieu):
        k = khoa(gt)
        if not k:
            return 0
        for x in ds:                         # trung ten / so hieu
            if khoa(x[-1]) == k or (co_so_hieu and khoa(x[1]) == k):
                return x[0]
        cac = [x for x in ds if k in khoa(x[-1]) or (khoa(x[-1]) and khoa(x[-1]) in k)]
        return cac[0][0] if len(cac) == 1 else 0

    def ma_pl(self, gt):
        return self._tim(self.pl, gt, True)

    def ma_cv(self, gt):
        return self._tim(self.cv, gt, True)

    def ma_qg(self, gt):
        k = khoa(gt or "Việt Nam")
        if k in ("vn", "viet nam", "vietnam"):
            k = "viet nam"
        return self._tim(self.qg, k, False)

    def ma_tinh(self, gt):
        k = khoa(gt)
        k = re.sub(r"^(tinh|thanh pho|tp\.?|tp)\s+", "", k)
        if not k:
            return 0
        if k in ("hcm", "tp hcm", "ho chi minh", "sai gon"):
            k = "ho chi minh"
        return self._tim(self.tinh, k, False)


# ------------------------------------------------------------------ tao mau
def tao_mau(dm, ra):
    D = dm if isinstance(dm, DanhMuc) else DanhMuc(dm)
    wb = SoExcel(font="Times New Roman", co=11)
    k_td = wb.kieu(dam=True, co=14, can="giua", mau="0B3D91")
    k_dv = wb.kieu(dam=True, can="trai")
    k_ghi = wb.kieu(nghieng=True, mau="555555", xuong=True, can="trai", doc="tren")
    k_dau = wb.kieu(dam=True, nen="D9E1F2", khung=True, can="giua", xuong=True)
    k_dau_bb = wb.kieu(dam=True, nen="FCE4D6", khung=True, can="giua", xuong=True, mau="C00000")
    k_o = wb.kieu(khung=True)
    k_oc = wb.kieu(khung=True, so="@")
    k_on = wb.kieu(khung=True, so="dd/mm/yyyy", can="giua")
    k_og = wb.kieu(khung=True, can="giua")
    n = len(COT)
    ws = wb.sheet("DanhSachNV", cot=[c[2] for c in COT])
    ws.gop(1, 1, 1, n, "DANH SÁCH NHÂN VIÊN - MẪU NHẬP VÀO PHẦN MỀM UNESCO", k_td)
    ws.gop(2, 1, 2, n, (D.cty + ((" - MST " + D.mst) if D.mst else "")) if D.cty else "", k_dv)
    ws.gop(3, 1, 3, n, "(*) bắt buộc. Mã NV để trống: phần mềm tự cấp theo bộ phận. Ngày gõ dd/mm/yyyy. Bộ phận, Chức vụ, Giới tính, "
           "Loại hợp đồng, Loại lương, Đóng BH: chọn trong danh sách thả xuống (sheet DanhMuc). Nhân viên đã có trong phần mềm "
           "(trùng mã / họ tên + ngày sinh / CCCD) sẽ được bỏ qua, không ghi đè. Xem sheet HuongDan.", k_ghi)
    ws.cao(3, 48)
    r0 = 4
    for c, (k, t, _w, _txt) in enumerate(COT, start=1):
        ws.o(r0, c, t, k_dau_bb if k in ("ten", "bo_phan") else k_dau)
    ws.cao(r0, 34)
    r1, r2 = r0 + 1, r0 + SO_DONG_MAU
    for r in range(r1, r2 + 1):
        for c, (k, _t, _w, txt) in enumerate(COT, start=1):
            if k == "stt":
                continue
            ws.o(r, c, None, k_oc if txt else (k_on if k in ("ns", "ngay_cap") else (k_og if k in ("phai", "bac", "bh", "thang_vao") else k_o)))
    # danh muc + o chon tha xuong
    dm_ws = wb.sheet("DanhMuc", cot=[28, 28, 30, 16, 10, 10, 18, 22])
    cot_dm = [("Bộ phận", [x[2] or x[1] for x in D.pl]), ("Chức vụ", [x[2] or x[1] for x in D.cv]),
              ("Loại hợp đồng", [t for _, t in LOAI_HD]), ("Loại lương", [t for _, t in LOAI_LUONG]),
              ("Giới tính", GIOI_TINH), ("Đóng BH", CO_KHONG), ("Quốc tịch", [x[1] for x in D.qg]),
              ("Tỉnh / TP", [x[1] for x in D.tinh])]
    vi_tri = {}
    for c, (t, ds) in enumerate(cot_dm, start=1):
        dm_ws.o(1, c, t, k_dau)
        for i, v in enumerate(ds, start=2):
            dm_ws.o(i, c, v, k_o)
        if ds:
            vi_tri[t] = "DanhMuc!$%s$2:$%s$%d" % (chr(64 + c), chr(64 + c), len(ds) + 1)
    dm_ws.dong_bang(2)
    chon = {"bo_phan": "Bộ phận", "chuc_vu": "Chức vụ", "loai_hd": "Loại hợp đồng", "loai_luong": "Loại lương", "phai": "Giới tính",
            "bh": "Đóng BH", "quoc_tich": "Quốc tịch", "noi_cap": "Tỉnh / TP"}
    for c, (k, _t, _w, _txt) in enumerate(COT, start=1):
        if k in chon and chon[k] in vi_tri:
            ws.chon_ds(r1, c, r2, c, vi_tri[chon[k]])
        elif k == "bac":
            ws.chon_ds(r1, c, r2, c, '"1,2,3,4,5"')
    ws.dong_bang(r1, 4)
    ws.loc(r0, 1, r2, n)
    ws.luoi(True)
    ws.in_trang(ngang=True, vua_rong=True, lap_dong=(r0, r0))
    # nhan vien da co (de khoi nhap trung)
    da = wb.sheet("NhanVienDaCo", cot=[12, 30, 12, 26])
    da.dong(1, 1, ["Mã NV", "Họ và tên", "Ngày sinh", "Bộ phận"], k_dau)
    ten_pl = dict((x[0], x[2] or x[1]) for x in D.pl)
    for i, x in enumerate(D.nv, start=2):
        nsx = ngay(x[2])
        da.dong(i, 1, [(x[0], k_oc), (x[1], k_o), (nsx, k_on), (ten_pl.get(x[3], ""), k_o)])
    da.dong_bang(2)
    if D.nv:
        da.loc(1, 1, len(D.nv) + 1, 4)
    # huong dan
    hd = wb.sheet("HuongDan", cot=[4, 110])
    dong = [
        ("HƯỚNG DẪN NHẬP DANH SÁCH NHÂN VIÊN", True),
        ("1. Điền mỗi nhân viên một dòng ở sheet DanhSachNV từ dòng 5 (dòng 4 là tiêu đề - không sửa, không xoá).", False),
        ("2. Bắt buộc: Họ và tên, Bộ phận (chọn trong danh sách). Sổ chỉ có một bộ phận thì để trống cũng được.", False),
        ("3. Mã NV: để trống - phần mềm tự cấp theo mẫu mã của bộ phận; tự gõ thì không được trùng mã đã có.", False),
        ("4. Ngày sinh, Ngày cấp: dd/mm/yyyy (vd 25/03/1990). Số CCCD, Mã số BHXH, MST, Điện thoại: giữ số 0 đầu (ô đã định dạng chữ).", False),
        ("5. Giới tính để trống: tên có chữ \"Thị\" -> Nữ, còn lại Nam (xem lại trong báo cáo trước khi ghi).", False),
        ("6. Đóng BH bắt buộc: Có (mặc định) / Không (người không thuộc diện đóng: HĐ dưới 1 tháng, thử việc...).", False),
        ("7. Tháng vào làm (1-12): tháng bắt đầu làm trong năm tài chính (đánh dấu tăng lao động / tăng BH) - để trống nếu làm từ trước.", False),
        ("8. Chức vụ, Loại HĐ, Loại lương, Quốc tịch để trống: lấy giá trị hay dùng nhất của bộ phận (quốc tịch: Việt Nam).", False),
        ("9. Lưu tệp, rồi trong phần mềm: màn hình AI -> thẻ Lương & BHXH -> Nhập DS nhân viên... -> chọn tệp -> xem báo cáo -> Yes để ghi.", False),
        ("Phần mềm KHÔNG sửa / xoá nhân viên đã có: dòng trùng mã, trùng họ tên + ngày sinh hoặc trùng số CCCD được bỏ qua và liệt kê lý do.", False),
        ("Có thể nhập từ tệp Excel khác (danh sách BHXH, hồ sơ nhân sự...) nếu có dòng tiêu đề \"Họ và tên\" - phần mềm tự nhận cột.", False),
        ("Ví dụ một dòng: | | Nguyễn Văn An | Nam | 25/03/1990 | 079090001234 | 10/05/2021 | Hồ Chí Minh | 0901234567 | | ... | "
         "Văn phòng | Nhân viên | 1 | Không xác định thời hạn | Lương tháng | Có | 7912345678 | | | 3 |", False),
    ]
    k_h1 = wb.kieu(dam=True, co=13, mau="0B3D91")
    k_h = wb.kieu(xuong=True, doc="tren")
    for i, (t, dam) in enumerate(dong, start=1):
        hd.o(i, 2, t, k_h1 if dam else k_h)
    hd.luoi(False)
    os.makedirs(os.path.dirname(os.path.abspath(ra)), exist_ok=True)
    wb.luu(ra)
    return ra


# ------------------------------------------------------------------ doc danh sach
def _ghep_tieu_de(dong):
    """-> {khoa: chi so cot} cua mot dong tieu de; None neu khong phai dong tieu de."""
    m = {}
    for i, v in enumerate(dong):
        k = khoa(v)
        if not k:
            continue
        for kk, cum in NHAN_COT:
            if kk in m:
                continue
            if any(k == c or k.startswith(c + " ") or (" " + c) in (" " + k) for c in cum):
                if kk == "dc_ct" and "thuong tru" in k:
                    continue
                m[kk] = i
                break
        else:
            if k == "dia chi" and "dc_ct" not in m:
                m["dc_ct"] = i
            elif k == "ten" and "ten" not in m:
                m["ten"] = i
    if "ten" not in m or len(m) < 2:
        return None
    return m


def _bang_tu(bang):
    """bang: {sheet: [[o, ...], ...]} hoac BangExcel -> (ten sheet, chi so dong tieu de, ban do cot, cac dong)."""
    ds = list(bang.items()) if hasattr(bang, "items") else []
    ds.sort(key=lambda t: 0 if khoa(t[0]).replace(" ", "") == "danhsachnv" else 1)
    for ten, rows in ds:
        rows = [[r.get(c) for c in range(max(r) + 1)] if isinstance(r, dict) and r else (list(r or []) if not isinstance(r, dict) else [])
                for r in (rows or [])]
        for i, r in enumerate(rows[:25]):
            m = _ghep_tieu_de(r)
            if m:
                return ten, i, m, rows
    return None, -1, {}, []


def _lay(r, m, k):
    i = m.get(k)
    if i is None or i >= len(r):
        return None
    return r[i]


def _phai(v, ten):
    k = khoa(v)
    if k in ("nu", "n", "female", "f", "x nu", "0"):
        return "Nữ", False
    if k in ("nam", "male", "m", "1"):
        return "Nam", False
    return ("Nữ" if " thi " in " " + khoa(ten) + " " else "Nam"), True


def _co_bh(v):
    k = khoa(v)
    if not k:
        return True
    if k in ("khong", "k", "no", "0", "khong dong", "ko", "khong tham gia"):
        return False
    return True


def _loai(v, bang, tu_khoa):
    k = khoa(v)
    if not k:
        return 0
    if re.match(r"^\d+(\.0+)?$", k):
        x = int(float(k))
        return x if any(x == a for a, _ in bang) else 0
    for ma, cum in tu_khoa:
        if any(c in k for c in cum):
            return ma
    return 0


TK_HD = [(3, ("duoi 12", "thoi vu", "thu viec", "duoi 1 nam", "mua vu")), (1, ("khong xac dinh", "khong thoi han", "vo thoi han")),
         (2, ("xac dinh thoi han", "12 - 36", "12-36", "1 nam", "2 nam", "3 nam", "co thoi han"))]
TK_LUONG = [(1, ("he so",)), (3, ("thoi vu",)), (4, ("ngay",)), (2, ("thang",))]


def doc_ds(bang, dm):
    """-> (thong_tin, cac_nv_hop_le, cac_dong_bo). Moi nv: dict gia tri chuan hoa + ma danh muc + 'canh_bao' (list)."""
    D = dm if isinstance(dm, DanhMuc) else DanhMuc(dm)
    sheet, i0, m, rows = _bang_tu(bang)
    info = {"sheet": sheet, "dong_tieu_de": i0 + 1, "cot": sorted(m)}
    hop, bo = [], []
    if sheet is None:
        return info, hop, bo
    sh_moi, cccd_moi, ten_ns_moi = set(), set(), set()
    mot_pl = D.pl[0][0] if len(D.pl) == 1 else 0
    for j, r in enumerate(rows[i0 + 1:], start=i0 + 2):
        ten = chu(_lay(r, m, "ten"))
        if not ten:
            continue
        kt = khoa(ten)
        if kt in ("ho va ten", "ho ten") or re.match(r"^(cong|tong cong|tong so)\b", kt) or re.match(r"^\d+$", kt):
            continue
        cb = []
        sh = chu(_lay(r, m, "sh")).replace("'", "")
        pl_txt = chu(_lay(r, m, "bo_phan"))
        pl = D.ma_pl(pl_txt) if pl_txt else mot_pl
        ns = ngay(_lay(r, m, "ns"))
        cccd = chu(_lay(r, m, "cccd"))
        if re.match(r"^[\d\s\.]+$", cccd):
            cccd = chu_so(cccd)
            if isinstance(_lay(r, m, "cccd"), (int, float)) and len(cccd) == 11:
                cccd = "0" + cccd                # o so: Excel bo so 0 dau cua CCCD 12 so
        ly_do = ""
        if not pl:
            ly_do = ("bộ phận \"%s\" không có trong danh mục" % pl_txt) if pl_txt else "chưa chọn bộ phận"
        elif sh and khoa(sh) in D.sh_co:
            ly_do = "mã NV %s đã có trong phần mềm" % sh
        elif sh and khoa(sh) in sh_moi:
            ly_do = "mã NV %s trùng dòng trên" % sh
        elif ns and (kt, ns.strftime("%Y-%m-%d")) in D.ten_ns_co:
            ly_do = "đã có nhân viên cùng họ tên và ngày sinh"
        elif ns and (kt, ns) in ten_ns_moi:
            ly_do = "trùng họ tên + ngày sinh với dòng trên"
        elif cccd and cccd in cccd_moi:
            ly_do = "trùng số CCCD với dòng trên"
        if ly_do:
            bo.append({"dong": j, "ten": ten, "ly_do": ly_do})
            continue
        phai, doan = _phai(_lay(r, m, "phai"), ten)
        if doan:
            cb.append("giới tính đoán theo tên: " + phai)
        if _lay(r, m, "ns") not in (None, "") and not ns:
            cb.append("ngày sinh không đọc được")
        if ns and not (1940 <= ns.year <= _dt.date.today().year - 14):
            cb.append("ngày sinh %s lạ" % ns.strftime("%d/%m/%Y"))
        if cccd and chu_so(cccd) == cccd and len(cccd) not in (9, 12):
            cb.append("số CCCD có %d số" % len(cccd))
        nc_txt = chu(_lay(r, m, "noi_cap"))
        noi_cap = D.ma_tinh(nc_txt) if nc_txt else 0
        if nc_txt and not noi_cap:
            cb.append("nơi cấp \"%s\" không có trong danh mục tỉnh - để trống" % nc_txt)
        qg_txt = chu(_lay(r, m, "quoc_tich"))
        qg = D.ma_qg(qg_txt)
        if qg_txt and not qg:
            cb.append("quốc tịch \"%s\" không có trong danh mục" % qg_txt)
        cv_txt = chu(_lay(r, m, "chuc_vu"))
        cv = D.ma_cv(cv_txt) if cv_txt else 0
        if cv_txt and not cv:
            cb.append("chức vụ \"%s\" không có trong danh mục - lấy chức vụ hay dùng của bộ phận" % cv_txt)
        try:
            bac = int(float(chu(_lay(r, m, "bac")) or 0))
        except ValueError:
            bac = 0
        if not (1 <= bac <= 5):
            bac = 1
        hd = _loai(_lay(r, m, "loai_hd"), LOAI_HD, TK_HD)
        ll = _loai(_lay(r, m, "loai_luong"), LOAI_LUONG, TK_LUONG)
        co_bh = _co_bh(_lay(r, m, "bh"))
        bhxh = chu(_lay(r, m, "bhxh"))
        if re.match(r"^[\d\s\.]+$", bhxh):
            bhxh = chu_so(bhxh)
            if bhxh and len(bhxh) < 10:
                bhxh = bhxh.zfill(10)
            if bhxh and len(bhxh) != 10:
                cb.append("mã số BHXH có %d số (đúng là 10)" % len(bhxh))
        tv = _lay(r, m, "thang_vao")
        thang = 0
        if tv not in (None, ""):
            dv = ngay(tv) if not (isinstance(tv, (int, float)) and 1 <= float(tv) <= 12) else None
            if dv:
                thang = dv.month if (not D.nam_tc or dv.year == D.nam_tc) else 0
            else:
                try:
                    thang = int(float(chu(tv)))
                except ValueError:
                    thang = 0
                if not (1 <= thang <= 12):
                    thang = 0
        nc = ngay(_lay(r, m, "ngay_cap"))
        tel = chu(_lay(r, m, "tel"))
        if re.match(r"^\d{9}$", tel):
            tel = "0" + tel
        nv = {"dong": j, "sh": sh[:20], "ten": ten[:80], "phai": phai, "ns": ns.strftime("%Y-%m-%d") if ns else "",
              "cccd": cccd[:15], "ngay_cap": nc.strftime("%Y-%m-%d") if nc else "", "noi_cap": noi_cap, "tel": tel[:20],
              "mail": chu(_lay(r, m, "mail"))[:50], "dc_hk": chu(_lay(r, m, "dc_hk"))[:100], "dc_ct": chu(_lay(r, m, "dc_ct"))[:100],
              "qg": qg, "pl": pl, "cv": cv, "bac": bac, "hd": hd, "ll": ll, "khong_bh": 0 if co_bh else 1,
              "bhxh": bhxh[:20], "bhyt": chu(_lay(r, m, "bhyt"))[:20], "mst": re.sub(r"[^0-9\-]", "", chu(_lay(r, m, "mst")))[:20],
              "thang": thang, "canh_bao": cb}
        hop.append(nv)
        if sh:
            sh_moi.add(khoa(sh))
        if cccd:
            cccd_moi.add(cccd)
        if ns:
            ten_ns_moi.add((kt, ns))
    return info, hop, bo


def bao_cao(info, hop, bo, tep, D):
    ten_pl = dict((x[0], x[2] or x[1]) for x in D.pl)
    ten_cv = dict((x[0], x[2] or x[1]) for x in D.cv)
    L = ["NHẬP DANH SÁCH NHÂN VIÊN (GĐ134) - %s" % _dt.datetime.now().strftime("%d/%m/%Y %H:%M"),
         "Tệp: %s  |  sheet: %s, dòng tiêu đề %s" % (os.path.basename(tep), info.get("sheet") or "-", info.get("dong_tieu_de")),
         "Sẽ THÊM %d nhân viên mới; bỏ qua %d dòng. Nhân viên đã có KHÔNG bị sửa." % (len(hop), len(bo)), ""]
    L.append("1. NHÂN VIÊN SẼ THÊM (%d)" % len(hop))
    for x in hop:
        L.append("  + Dòng %d: %s%s - %s, %s%s; bộ phận %s%s; %s%s" % (
            x["dong"], x["ten"], (" [mã " + x["sh"] + "]") if x["sh"] else " [mã tự cấp]", x["phai"],
            ("sinh " + _dt.datetime.strptime(x["ns"], "%Y-%m-%d").strftime("%d/%m/%Y")) if x["ns"] else "chưa có ngày sinh",
            (", CCCD " + che(x["cccd"])) if x["cccd"] else "", ten_pl.get(x["pl"], "?"),
            (", " + ten_cv.get(x["cv"], "")) if x["cv"] else "", "đóng BH" if not x["khong_bh"] else "KHÔNG đóng BH",
            (", vào làm tháng %d" % x["thang"]) if x["thang"] else ""))
        for c in x["canh_bao"]:
            L.append("      [?] " + c)
    if not hop:
        L.append("  (không có)")
    L.append("")
    L.append("2. DÒNG BỎ QUA (%d)" % len(bo))
    for x in bo:
        L.append("  [!] Dòng %d %s: %s" % (x["dong"], x["ten"], x["ly_do"]))
    if not bo:
        L.append("  (không có)")
    L.append("")
    L.append("Bấm Đóng rồi chọn Yes ở hộp hỏi để ghi; No: không ghi gì. Số CCCD chỉ hiện 4 số cuối.")
    return "\n".join(L)


# ------------------------------------------------------------------ lenh cho tool
def _doc_dm(tep_dm):
    with io.open(tep_dm, "r", encoding="utf-8-sig") as f:
        dm = json.load(f)
    try:
        os.remove(tep_dm)
    except OSError:
        pass
    return dm


def chay_mau(tep_dm, ra, ghi_log=None):
    """/maunv:<json danh muc> /ra:<thu muc hoac tep .xlsx> -> (duong tep, None) | (None, loi)."""
    log = ghi_log or (lambda s: None)
    try:
        D = DanhMuc(_doc_dm(tep_dm))
        if not ra or os.path.isdir(ra) or not ra.lower().endswith(".xlsx"):
            ra = os.path.join(ra or os.getcwd(), "MauDanhSachNhanVien_%s.xlsx" % _dt.datetime.now().strftime("%Y%m%d_%H%M%S"))
        tao_mau(D, ra)
        log("[NHAP NV] mau %s (%d bo phan, %d chuc vu, %d NV da co)" % (os.path.basename(ra), len(D.pl), len(D.cv), len(D.nv)))
        return ra, None
    except Exception as e:
        log("[NHAP NV] loi tao mau: %s" % e)
        return None, "Loi tao tep mau danh sach nhan vien: %s" % e


def chay_nhap(tep, tep_dm, ra, doc_bang, ghi_log=None):
    """/nhapnv:<xlsx> /nv:<json danh muc> /ra:<thu muc ket qua> -> (tep .dat, None) | (None, loi).
    .dat: dong 1 {"loai": "tong", ...}; moi nhan vien {"loai": "nv", ...} (co CCCD day du - VB6 doc xong xoa)."""
    log = ghi_log or (lambda s: None)
    try:
        D = DanhMuc(_doc_dm(tep_dm) if tep_dm and os.path.exists(tep_dm) else {})
        info, hop, bo = doc_ds(doc_bang(tep), D)
        if info.get("sheet") is None:
            return None, "Khong tim thay dong tieu de co cot Ho va ten trong tep (dung tep mau: nut Mau Excel DS nhan vien)."
        gio = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
        thu_muc = ra if (ra and os.path.isdir(ra)) else os.path.dirname(os.path.abspath(tep))
        bc = bao_cao(info, hop, bo, tep, D)
        tep_bc = os.path.join(thu_muc, "NhapNhanVien_%s.txt" % gio)
        with io.open(tep_bc, "w", encoding="utf-8-sig", newline="\r\n") as f:
            f.write(bc)
        tep_kq = os.path.join(thu_muc, "nhapnv_%s.dat" % gio)
        tong = {"loai": "tong", "tep": os.path.basename(tep), "so_them": len(hop), "so_bo": len(bo),
                "so_canh_bao": sum(1 for x in hop if x["canh_bao"]), "bao_cao": tep_bc}
        with io.open(tep_kq + ".tmp", "w", encoding="utf-8", newline="\n") as f:
            f.write(json.dumps(tong, ensure_ascii=False) + "\n")
            for x in hop:
                y = dict(x)
                y.pop("canh_bao", None)
                y["loai"] = "nv"
                f.write(json.dumps(y, ensure_ascii=False) + "\n")
        os.replace(tep_kq + ".tmp", tep_kq)
        log("[NHAP NV] %s: them %d, bo %d" % (os.path.basename(tep), len(hop), len(bo)))
        return tep_kq, None
    except Exception as e:
        log("[NHAP NV] loi doc %s: %s" % (os.path.basename(str(tep)), e))
        return None, "Loi doc danh sach nhan vien: %s" % e

# ------------------------------------------------------------------ GD200: xuat danh sach nhan vien ra Excel
COT_XUAT = [c for c in COT if c[0] not in ("mail", "thang_vao", "ghi_chu")] + [
    ("nghi", "Nghỉ việc", 9, False), ("ngay_nghi", "Ngày nghỉ", 11, False)]


def _ngay_x(v):
    v = (v or "").strip()
    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})$", v)
    if not m:
        return None
    try:
        return _dt.datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)))
    except ValueError:
        return None


def tao_xuat(du, ra):
    """du = {"cty","mst","nam_tc","nhom","nv":[{sh, ten, phai, ns, cccd, ...}]} -> tep .xlsx (cot giong tep mau nhap,
    sua xong co the nhap lai: nhan vien da co duoc bo qua, khong ghi de)."""
    wb = SoExcel(font="Times New Roman", co=11)
    k_td = wb.kieu(dam=True, co=14, can="giua", mau="0B3D91")
    k_dv = wb.kieu(dam=True, can="trai")
    k_dau = wb.kieu(dam=True, nen="D9E1F2", khung=True, can="giua", xuong=True)
    k_o = wb.kieu(khung=True)
    k_oc = wb.kieu(khung=True, so="@")
    k_on = wb.kieu(khung=True, so="dd/mm/yyyy", can="giua")
    k_og = wb.kieu(khung=True, can="giua")
    n = len(COT_XUAT)
    ws = wb.sheet("DanhSachNV", cot=[c[2] for c in COT_XUAT])
    ws.gop(1, 1, 1, n, "DANH SÁCH NHÂN VIÊN CÔNG TY - %s" % (du.get("nam_tc") or ""), k_td)
    cty = du.get("cty") or ""
    ws.gop(2, 1, 2, n, (cty + ((" - MST " + du["mst"]) if du.get("mst") else "")) if cty else "", k_dv)
    ws.gop(3, 1, 3, n, "Xuất lúc %s - %d nhân viên%s" % (_dt.datetime.now().strftime("%d/%m/%Y %H:%M"), len(du.get("nv") or []),
                                                    (" - nhóm " + du["nhom"]) if du.get("nhom") else ""), k_dv)
    r0 = 4
    for c, (_k, t, _w, _txt) in enumerate(COT_XUAT, start=1):
        ws.o(r0, c, t, k_dau)
    ws.cao(r0, 34)
    r = r0
    for i, x in enumerate(du.get("nv") or [], start=1):
        r += 1
        for c, (k, _t, _w, txt) in enumerate(COT_XUAT, start=1):
            if k == "stt":
                ws.o(r, c, i, k_og)
            elif k in ("ns", "ngay_cap", "ngay_nghi"):
                ws.o(r, c, _ngay_x(x.get(k)), k_on)
            elif k in ("phai", "bac", "bh", "nghi"):
                ws.o(r, c, x.get(k) if x.get(k) not in (None, "") else None, k_og)
            else:
                v = x.get(k)
                ws.o(r, c, v if v not in (None, "", "...") else None, k_oc if txt else k_o)
    ws.dong_bang(r0 + 1, 4)
    ws.loc(r0, 1, max(r, r0 + 1), n)
    ws.in_trang(ngang=True, vua_rong=True, lap_dong=(r0, r0))
    wb.luu(ra)
    return ra


def chay_xuat(tep, ra, ghi_log=None):
    """/xuatnv:<json> /ra:<thu muc hoac tep .xlsx> -> (duong tep, None) | (None, loi). Tep json co so CCCD: VB6 xoa sau khi chay."""
    log = ghi_log or (lambda s: None)
    try:
        with io.open(tep, "r", encoding="utf-8-sig") as f:
            du = json.load(f)
        if not ra or os.path.isdir(ra) or not ra.lower().endswith(".xlsx"):
            ra = os.path.join(ra or os.getcwd(), "DanhSachNhanVien_%s.xlsx" % _dt.datetime.now().strftime("%Y%m%d_%H%M%S"))
        tao_xuat(du, ra)
        log("[XUAT NV] %s (%d nhan vien)" % (os.path.basename(ra), len(du.get("nv") or [])))
        return ra, None
    except Exception as e:
        log("[XUAT NV] loi: %s" % e)
        return None, "Loi xuat danh sach nhan vien ra Excel: %s" % e
