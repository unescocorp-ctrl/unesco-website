# -*- coding: utf-8 -*-
"""GD134 - EXCEL DOI CHIEU BHXH, BHYT, BHTN HANG THANG (bang luong <-> so ke toan TK BH <-> tien da nop).

VB6 (ModBHDoiChieu.BHD_DoiChieu) CHI DOC so roi ghi JSON:
    {"loai": "bhdc", "cty", "mst", "nam_tc", "thang_dau", "hom_nay": "dd/mm/yyyy", "lap_luc", "tk": "3383, 3384, 3385",
     "du_dau": so du dau nam TK BH (Co - No), "sai": sai so lam tron, "k_nay": thang tai chinh hien tai,
     "thang": [{"k", "t", "n", "han": "dd/mm/yyyy", "nguon": 0 | 1 bang luong phan mem | 2 bang luong Import, "so_nv",
                "bl_nv", "bl_dn", "trich", "nop", "khac_co", "khac_no", "khong_bh", "thieu_ma"} x 12],
     "nv": [{"k", "loai": "khong_bh" | "thieu_ma", "sh", "ten", "tn"}], "canh_bao": ["..."]}
    tool_htkk_unesco.py /bhdc:<json> /ra:<xlsx>
Sheet DoiChieu (CONG THUC SONG: Cong BL, Lech, So du cuoi thang), NhanVien, CanCu. Han nop: ngay cuoi cung cua thang sau
(Dieu 34 Luat BHXH 2024); cham dong: lai 0,03%/ngay (Dieu 41). Chi doc - khong ghi so.
"""
import datetime as _dt
import io
import json
import os

from xlsx_viet import SoExcel, CT, SO_TIEN

PHIEN_BAN = "GD134"


def _so(v):
    try:
        return float(v or 0)
    except (TypeError, ValueError):
        return 0.0


def _ngay(s):
    try:
        return _dt.datetime.strptime(str(s), "%d/%m/%Y").date()
    except (TypeError, ValueError):
        return None


def tinh(dl):
    """So lieu tung thang + tinh hinh no (cung cach VB6 tinh canh bao). -> dict."""
    hom = _ngay(dl.get("hom_nay")) or _dt.date.today()
    sai = _so(dl.get("sai")) or 1000.0
    du = _so(dl.get("du_dau"))
    ds = sorted([t for t in (dl.get("thang") or []) if 1 <= int(t.get("k") or 0) <= 12], key=lambda t: int(t["k"]))
    k_nay = int(dl.get("k_nay") or 0)
    co_tk = bool(str(dl.get("tk") or "").strip())
    rows = []
    sd = du
    for t in ds:
        k = int(t["k"])
        bl = _so(t.get("bl_nv")) + _so(t.get("bl_dn"))
        tr, np_, kc, kn = _so(t.get("trich")), _so(t.get("nop")), _so(t.get("khac_co")), _so(t.get("khac_no"))
        sd = sd + tr + kc - kn - np_
        rows.append({"k": k, "t": int(t.get("t") or k), "n": int(t.get("n") or 0), "han": _ngay(t.get("han")), "nguon": int(t.get("nguon") or 0),
                     "so_nv": int(t.get("so_nv") or 0), "bl_nv": _so(t.get("bl_nv")), "bl_dn": _so(t.get("bl_dn")), "bl": bl,
                     "trich": tr, "nop": np_, "khac": kc - kn, "sd": sd, "khong_bh": int(t.get("khong_bh") or 0),
                     "thieu_ma": int(t.get("thieu_ma") or 0)})
    # phai nop den han (han < hom nay): du dau nam (han = cuoi thang tai chinh dau tien) + phat sinh tang cua thang da qua han
    #   - MOI khoan da nop
    dau = ds[0] if ds else None
    han_du = None
    if dau:
        d0 = _ngay(dau.get("han"))
        if d0:
            han_du = d0.replace(day=1) - _dt.timedelta(days=1)          # ngay cuoi thang tai chinh dau tien

    def den_han(d):
        s = du if (han_du and han_du <= d) else 0.0
        for r in rows:
            if r["han"] and r["han"] <= d:
                s += r["trich"] + r["khac"]
        return s - sum(r["nop"] for r in rows)

    # so nam da qua: chi xet den cuoi nam tai chinh (BH thang cuoi nop o so nam sau) - cung cach VB6 (BHD_CanhBao)
    cuoi = (rows[-1]["han"].replace(day=1) - _dt.timedelta(days=1)) if rows and rows[-1]["han"] else None
    d = hom - _dt.timedelta(days=1)
    if cuoi and d > cuoi:
        d = cuoi
    qua_han = den_han(d) if co_tk else 0.0
    nam_qua = bool(cuoi and hom > cuoi)
    for r in rows:
        g = []
        if r["k"] > k_nay and k_nay > 0:
            r["ghi_chu"] = "chưa đến tháng"
            r["muc"] = 0
            continue
        if co_tk and r["bl"] > 0 and abs(r["bl"] - r["trich"]) > sai and (r["k"] < k_nay or nam_qua):
            g.append("chưa hạch toán trích BH" if abs(r["trich"]) <= sai else "bảng lương lệch sổ %s" % _tien(r["bl"] - r["trich"]))
        if r["khong_bh"]:
            g.append("%d người có lương chưa trích BH" % r["khong_bh"])
        if r["thieu_ma"]:
            g.append("%d người thiếu mã số BHXH" % r["thieu_ma"])
        if co_tk and r["han"]:
            if nam_qua and r["han"] > cuoi:
                g.append("hạn %s - nộp / đối chiếu ở sổ năm sau" % r["han"].strftime("%d/%m/%Y"))
            elif r["han"] < hom and den_han(r["han"]) > sai:
                g.append("quá hạn %s - còn nợ" % r["han"].strftime("%d/%m/%Y"))
            elif r["han"] >= hom and (r["han"] - hom).days <= 31 and (r["trich"] + r["khac"]) > sai:
                g.append("hạn nộp %s (còn %d ngày)" % (r["han"].strftime("%d/%m/%Y"), (r["han"] - hom).days))
        r["ghi_chu"] = "; ".join(g)
        r["muc"] = 2 if any(x.startswith(("quá hạn", "chưa hạch toán", "bảng lương lệch")) for x in g) else (1 if g else 0)
    return {"rows": rows, "du_dau": du, "qua_han": qua_han, "sai": sai, "hom": hom, "co_tk": co_tk, "nam_qua": nam_qua}


def _tien(x):
    return "{:,.0f}".format(x).replace(",", ".")


def lap(dl, ra):
    T = tinh(dl)
    rows = T["rows"]
    wb = SoExcel(font="Times New Roman", co=11)
    k_td = wb.kieu(dam=True, co=14, can="giua", mau="0B3D91")
    k_dv = wb.kieu(dam=True)
    k_ghi = wb.kieu(nghieng=True, mau="555555", xuong=True, doc="tren")
    k_dau = wb.kieu(dam=True, nen="D9E1F2", khung=True, can="giua", xuong=True)
    k_o = wb.kieu(khung=True)
    k_og = wb.kieu(khung=True, can="giua")
    k_so = wb.kieu(khung=True, so=SO_TIEN)
    k_sod = wb.kieu(khung=True, so=SO_TIEN, dam=True)
    k_cong = wb.kieu(khung=True, dam=True, nen="F2F2F2")
    k_congso = wb.kieu(khung=True, dam=True, nen="F2F2F2", so=SO_TIEN)
    k_do = wb.kieu(khung=True, mau="C00000", xuong=True)
    k_cam = wb.kieu(khung=True, mau="C65911", xuong=True)
    k_xam = wb.kieu(khung=True, mau="808080", nghieng=True)
    k_cb = wb.kieu(mau="C00000", dam=True, xuong=True, doc="tren")
    k_ok = wb.kieu(mau="0B6E2E", dam=True)
    ws = wb.sheet("DoiChieu", cot=[11, 11, 9, 15, 15, 15, 15, 14, 15, 13, 16, 40])
    n = 12
    ws.gop(1, 1, 1, n, ("%s - MST %s" % (dl.get("cty") or "", dl.get("mst") or "")).strip(" -"), k_dv)
    ws.gop(2, 1, 2, n, "ĐỐI CHIẾU BHXH, BHYT, BHTN HẰNG THÁNG - NĂM TÀI CHÍNH %s" % (dl.get("nam_tc") or ""), k_td)
    ws.gop(3, 1, 3, n, "Lập lúc %s. TK bảo hiểm theo sổ: %s. Hạn nộp hằng tháng: ngày cuối cùng của tháng sau (Điều 34 Luật BHXH 2024); "
           "chậm đóng phải nộp thêm lãi 0,03%%/ngày (Điều 41). Cột F, H, K là công thức." % (
               dl.get("lap_luc") or "", dl.get("tk") or "(không tìm thấy TK 338x có tên BHXH / BHYT / thất nghiệp)"), k_ghi)
    ws.cao(3, 32)
    dau = ["Tháng", "Hạn nộp", "Số người đóng BH", "BH người LĐ (bảng lương)", "BH doanh nghiệp (bảng lương)", "Cộng bảng lương",
           "Trích theo sổ (Có TK BH)", "Lệch bảng lương - sổ", "Đã nộp (Nợ TK BH / Có 111, 112)", "Khác (+ tăng / - giảm)",
           "Số dư cuối tháng (còn phải nộp)", "Ghi chú"]
    r0 = 5
    ws.dong(r0, 1, dau, k_dau)
    ws.cao(r0, 46)
    r = r0 + 1
    ws.gop(r, 1, r, 10, "Số dư đầu năm (Có - Nợ TK bảo hiểm)", k_cong)
    ws.o(r, 11, T["du_dau"], k_congso)
    ws.o(r, 12, None, k_cong)
    r_dau = r
    for x in rows:
        r += 1
        f = "F%d" % r
        ws.o(r, 1, "%02d/%d" % (x["t"], x["n"]) if x["n"] else "%02d" % x["t"], k_og)
        ws.o(r, 2, x["han"], wb.kieu(khung=True, so="dd/mm/yyyy", can="giua"))
        ws.o(r, 3, x["so_nv"] or None, k_og)
        ws.o(r, 4, x["bl_nv"], k_so)
        ws.o(r, 5, x["bl_dn"], k_so)
        ws.o(r, 6, CT("=D%d+E%d" % (r, r), x["bl"]), k_so)
        ws.o(r, 7, x["trich"], k_so)
        ws.o(r, 8, CT('=IF(%s=0,0,%s-G%d)' % (f, f, r), (x["bl"] - x["trich"]) if x["bl"] else 0), k_so)
        ws.o(r, 9, x["nop"], k_so)
        ws.o(r, 10, x["khac"], k_so)
        ws.o(r, 11, CT("=K%d+G%d+J%d-I%d" % (r - 1, r, r, r), x["sd"]), k_sod)
        ws.o(r, 12, x.get("ghi_chu") or ("bảng lương phần mềm" if x["nguon"] == 1 else ("bảng lương Import (AI)" if x["nguon"] == 2 else "")),
             k_do if x.get("muc") == 2 else (k_cam if x.get("muc") == 1 else (k_xam if x.get("ghi_chu") == "chưa đến tháng" else k_o)))
    r1 = r_dau + 1
    r += 1
    ws.gop(r, 1, r, 3, "Cộng năm", k_cong)
    for c in (4, 5, 6, 7, 8, 9, 10):
        col = "DEFGHIJ"[c - 4]
        ws.o(r, c, CT("=SUM(%s%d:%s%d)" % (col, r1, col, r - 1), sum(
            {4: x["bl_nv"], 5: x["bl_dn"], 6: x["bl"], 7: x["trich"], 8: (x["bl"] - x["trich"]) if x["bl"] else 0, 9: x["nop"], 10: x["khac"]}[c]
            for x in rows)), k_congso)
    ws.o(r, 11, CT("=K%d" % (r - 1), rows[-1]["sd"] if rows else T["du_dau"]), k_congso)
    ws.o(r, 12, None, k_cong)
    if rows:
        ws.to_mau(r1, 8, r - 1, 8, "ABS(H%d)>%d" % (r1, int(T["sai"])), nen="FCE4E4", mau="C00000", dam=True)
    r += 2
    if T["co_tk"]:
        if T["qua_han"] > T["sai"]:
            ws.gop(r, 1, r, n, "CÒN NỢ QUÁ HẠN (theo sổ, tính đến hôm qua): %s đ - nộp ngay để giảm tiền lãi chậm đóng 0,03%%/ngày." %
                   _tien(T["qua_han"]), k_cb)
        else:
            ws.gop(r, 1, r, n, "Không có khoản BH quá hạn theo sổ (đã nộp đủ các tháng đến hạn).", k_ok)
        r += 1
    cb = [c for c in (dl.get("canh_bao") or []) if c]
    if cb:
        ws.gop(r, 1, r, n, "Cảnh báo:", k_dv)
        for c in cb:
            r += 1
            ws.gop(r, 1, r, n, "- " + c, k_ghi)
            ws.cao(r, 30)
    r += 2
    ws.gop(r, 1, r, n, "Cách đọc: Cộng bảng lương = BH người LĐ (8% + 1,5% + 1%) + BH doanh nghiệp (17,5% + 3% + 1%) trên bảng lương; "
           "Trích theo sổ = phát sinh Có TK BH đối ứng TK chi phí / 334...; Đã nộp = Nợ TK BH đối ứng tiền (111, 112); Khác = nhận tiền "
           "BHXH chi trả (Có TK BH / Nợ 111, 112) trừ khoản chi ốm đau, thai sản cho người LĐ (Nợ TK BH / Có 334...). "
           "Số dư cuối tháng dương = còn phải nộp. Đối chiếu thêm với Thông báo C12-TS của cơ quan BHXH.", k_ghi)
    ws.cao(r, 46)
    ws.dong_bang(r0 + 1, 2)
    ws.in_trang(ngang=True, vua_rong=True, lap_dong=(r0, r0))
    # nhan vien
    nv = [x for x in (dl.get("nv") or []) if isinstance(x, dict)]
    w2 = wb.sheet("NhanVien", cot=[10, 12, 30, 16, 50])
    w2.gop(1, 1, 1, 5, "NHÂN VIÊN CẦN KIỂM TRA (BHXH)", k_td)
    w2.dong(3, 1, ["Tháng", "Mã NV", "Họ và tên", "Thu nhập tháng", "Vấn đề"], k_dau)
    rr = 3
    for x in sorted(nv, key=lambda x: (int(x.get("k") or 0), str(x.get("sh") or ""))):
        rr += 1
        k = int(x.get("k") or 0)
        th = next((y for y in rows if y["k"] == k), None)
        w2.dong(rr, 1, [("%02d/%d" % (th["t"], th["n"]) if th else str(k), k_og), (x.get("sh") or "", k_o), (x.get("ten") or "", k_o),
                        (_so(x.get("tn")) or None, k_so),
                        ("có lương nhưng bảng lương không trích BH - thuộc diện đóng (chưa đánh dấu Không BH): kiểm tra hợp đồng, báo tăng"
                         if x.get("loai") == "khong_bh" else "đóng BH nhưng hồ sơ chưa có mã số BHXH - bổ sung ở Danh sách nhân viên / Kết nối BHXH",
                         k_do if x.get("loai") == "khong_bh" else k_cam)])
    if rr == 3:
        w2.gop(4, 1, 4, 5, "Không có nhân viên cần kiểm tra.", k_ok)
    else:
        w2.loc(3, 1, rr, 5)
    w2.dong_bang(4)
    w2.in_trang(ngang=True, vua_rong=True, lap_dong=(3, 3))
    # can cu
    w3 = wb.sheet("CanCu", cot=[4, 120])
    can = ["CĂN CỨ VÀ CÁCH TÍNH",
           "Luật Bảo hiểm xã hội số 41/2024/QH15 (hiệu lực 01/7/2025): Điều 34 - đóng hằng tháng, chậm nhất ngày cuối cùng của tháng tiếp theo; "
           "Điều 40 - 41 - chậm đóng, trốn đóng: nộp đủ số tiền chậm đóng và tiền lãi 0,03%/ngày tính trên số tiền, số ngày chậm đóng.",
           "Tỷ lệ đóng: người sử dụng lao động 21,5% (BHXH 17,5% = hưu trí 14% + ốm đau thai sản 3% + TNLĐ-BNN 0,5%; BHYT 3%; BHTN 1%); "
           "người lao động 10,5% (BHXH 8%, BHYT 1,5%, BHTN 1%).",
           "TK bảo hiểm: TT133 - 3383 BHXH, 3384 BHYT, 3385 BHTN; TT200 / TT99 - BHTN là 3386 (3385 là phải trả về cổ phần hoá). Phần mềm "
           "nhận TK theo TÊN trong hệ thống tài khoản của sổ; KPCĐ (3382) không tính.",
           "Bảng lương: Lao động - tiền lương của phần mềm; tháng chưa có thì lấy bảng lương Import trên màn hình AI.",
           "Số liệu chỉ ĐỌC từ sổ - công cụ không ghi chứng từ. Số dư đầu năm lấy từ số dư đầu kỳ của TK bảo hiểm chi tiết."]
    for i, t in enumerate(can, start=1):
        w3.o(i, 2, t, wb.kieu(dam=True, co=13, mau="0B3D91") if i == 1 else wb.kieu(xuong=True, doc="tren"))
    os.makedirs(os.path.dirname(os.path.abspath(ra)), exist_ok=True)
    wb.luu(ra)
    return ra, T


def chay(duong_json, ra="", ghi_log=None):
    """-> (duong tep Excel, None) | (None, loi). JSON tam (ten, thu nhap nhan vien) doc xong XOA."""
    log = ghi_log or (lambda s: None)
    try:
        with io.open(duong_json, "r", encoding="utf-8-sig") as f:
            dl = json.load(f)
    except Exception as e:
        return None, "Khong doc duoc so lieu doi chieu BHXH: %s" % e
    finally:
        try:
            os.remove(duong_json)
        except OSError:
            pass
    try:
        if not ra:
            ra = os.path.join(os.path.dirname(os.path.abspath(duong_json)), "DoiChieuBHXH_%s.xlsx" % _dt.datetime.now().strftime("%Y%m%d_%H%M%S"))
        tep, T = lap(dl, ra)
        log("[DOI CHIEU BHXH] %s: %d thang, qua han %s" % (os.path.basename(tep), len(T["rows"]), _tien(T["qua_han"])))
        return tep, None
    except Exception as e:
        import traceback
        log("[DOI CHIEU BHXH] loi: %s\n%s" % (e, traceback.format_exc()))
        return None, "Loi lap Excel doi chieu BHXH: %s" % e
