# -*- coding: utf-8 -*-
"""GD143 - HUONG DAN SU DUNG TONG HOP (mot trang HTML, mo bang trinh duyet / in) lap TU DONG tu bo huong dan Tro ly AI
(AIHoaDon\\tro_ly\\huong_dan.txt - moi goi cap nhat deu bo sung) + danh muc van ban phap luat (AIHoaDon\\van_ban).
  * Bat dau nhanh (cai, dang nhap lan dau: Thong tu + ky ke khai, cap nhat tu dong, Tro ly F1).
  * Co gi moi (moi goi, moi nhat truoc) - Tien ich cac module (bang tom tat) - Huong dan tung module (moi nut, o, cot luoi).
  * Phu luc: van ban phap luat, bieu mau ap dung.
Tim kiem ngay tren trang (go co dau hay khong dau). Menu Tro giup > Huong dan su dung mo tep nay.
  python huong_dan_su_dung.py [--ra <tep .html>]   (mac dinh AIHoaDon\\huong_dan_su_dung\\HUONG_DAN_SU_DUNG.html)"""
import html
import io
import os
import re
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)
PHIEN_BAN = "GD143"
RA_MAC_DINH = os.path.join(HERE, "huong_dan_su_dung", "HUONG_DAN_SU_DUNG.html")

PHAN = [
    ("A", "Chương trình kế toán (sổ, chứng từ, danh mục, báo cáo)",
     ["CT.CHINH", "CT.MN", "CT.CT", "CT.DM", "CT.DK", "CT.NV", "CT.TS", "CT.GT", "CT.SO", "CT.BC"]),
    ("B", "Màn hình AI (hoá đơn điện tử, sổ phụ ngân hàng, bảng lương, Cổng DVC)",
     ["HD.CHUNG", "HD.TD", "HD.DS", "HD.SP", "HD.NK", "HD.BL", "HD.DVC"]),
    ("C", "Mã hàng, nhà cung cấp, quy tắc hạch toán, tài sản, tờ khai hải quan",
     ["VT", "KH", "GM", "SD", "DD", "LH", "QT", "QTSP", "TSB", "TKHQ"]),
    ("D", "Thuế - xuất XML HTKK", ["XML", "XT"]),
    ("E", "Giá thành, định mức, kết chuyển thành phẩm", ["KC", "NVL", "TSL", "GT", "DM"]),
    ("F", "Quản lý công việc, kỳ kê khai, văn bản pháp luật", ["CV"]),
    ("G", "Thao tác trên màn hình và trợ giúp", ["THAOTAC", "TROGIUP"]),
    ("H", "Kiến thức chung của Trợ lý AI", ["CHUNG"]),
]

BAT_DAU = [
    ("Cài đặt, cập nhật", [
        "Máy mới: chạy bộ cài đầy đủ (CAI_DAT.bat) - cài phần mềm, Python và thư viện AI, mẫu báo cáo; dữ liệu kế toán để trong thư mục DATA.",
        "Cập nhật: phần mềm tự kiểm tra kênh cập nhật mỗi ngày; có bản mới thì Việc cần làm ở màn hình chính báo, vào Trợ giúp > "
        "Cập nhật phần mềm (hoặc nút Cập nhật trên màn hình AI) để tải, kiểm chữ ký số và cài - phần mềm tự đóng rồi mở lại; bản cũ được "
        "sao lưu (KHOI_PHUC.bat). Gói cập nhật thủ công: giải nén rồi nhấp đúp CAP_NHAT_TU_DONG.bat.",
        "Không bao giờ ghi đè dữ liệu kế toán (*.mdb), cấu hình, khoá Google, mã kích hoạt AI của máy khi cập nhật.",
    ]),
    ("Đăng nhập lần đầu một bộ sổ", [
        "Hộp Thông tư áp dụng và kỳ kê khai: chọn TT133/2016 (doanh nghiệp nhỏ và vừa) hoặc TT99/2025, và kỳ kê khai thuế GTGT theo tháng "
        "hay theo quý. Chỉ hỏi một lần; đổi lại: bấm hình Thông tư ở góc phải màn hình chính (mật khẩu quản trị).",
        "Kỳ kê khai quyết định hạn nộp trong Quản lý công việc và kỳ mặc định khi xuất báo cáo, tờ khai HTKK .xml.",
    ]),
    ("Làm việc hằng ngày", [
        "Màn hình AI: tải hoá đơn điện tử, lập chứng từ tự động, sổ phụ ngân hàng, bảng lương, Cổng dịch vụ công, xuất báo cáo.",
        "Quản lý công việc: lịch khai, nộp thuế, BHXH, báo cáo lao động theo tháng - quý - năm kèm số liệu từ sổ; bảng cập nhật văn bản "
        "pháp luật, biểu mẫu báo cáo và đề xuất update.",
        "Trợ lý AI: rê chuột lên nút / ô / cột lưới để xem gợi ý; F1 hoặc nút ? để mở hướng dẫn đúng chỗ đang trỏ.",
    ]),
]

# GD169: tai lieu kem theo (trang HTML cung thu muc + ban PDF o thu muc chuong trinh); chi hien tep co that
TAI_LIEU = [
    ("HUONG_DAN_TRUC_QUAN.html", "HUONG_DAN_TRUC_QUAN_AI_UNESCO_XI.pdf", "Hướng dẫn sử dụng trực quan GĐ150 - GĐ176",
     "28 chức năng mới, mỗi chức năng một trang: mở ở đâu, hình bố cục màn hình có số chú thích, các bước, kết quả, lưu ý; trang Tra nhanh chức năng nằm ở đâu."),
    ("TONG_HOP_TINH_NANG_AI.html", "TONG_HOP_TINH_NANG_AI_UNESCO_XI.pdf", "Tổng hợp toàn bộ tính năng AI",
     "Bản đồ AI trong phần mềm, AI làm / không làm gì, mọi tính năng theo nhóm (mở ở đâu, AI làm gì), Có gì mới từng gói."),
    ("TINH_NANG_UU_VIET_AI.html", "TINH_NANG_UU_VIET_AI_UNESCO.pdf", "Tính năng ưu việt của UNESCO AI",
     "Mười sáu điểm ưu việt, số liệu đo trên bộ sổ thật và nguồn của từng con số."),
]


def tai_lieu_html(ra):
    """Khung Tai lieu kem theo cho trang tong hop (ra = duong dan HUONG_DAN_SU_DUNG.html)"""
    thu = os.path.dirname(os.path.abspath(ra))
    goc = os.path.dirname(os.path.dirname(thu))
    dong = []
    for trang, pdf, ten, mo_ta in TAI_LIEU:
        co_trang = os.path.isfile(os.path.join(thu, trang))
        co_pdf = os.path.isfile(os.path.join(goc, pdf))
        if not (co_trang or co_pdf):
            continue
        lk = []
        if co_trang:
            lk.append('<a href="%s">Xem trên trình duyệt</a>' % trang)
        if co_pdf:
            lk.append('<a href="../../%s">Bản PDF để in</a>' % pdf)
        dong.append('<tr><td><b>%s</b><br><span class="nho">%s</span></td><td>%s</td></tr>' % (e(ten), e(mo_ta), " &middot; ".join(lk)))
    if not dong:
        return ""
    return ('<section id="tai-lieu"><h2>Tài liệu kèm theo</h2><table><tr><th>Tài liệu</th><th>Mở</th></tr>%s</table></section>'
            % "".join(dong))


def e(s):
    return html.escape(s or "", quote=True)


def khong_dau(s):
    import unicodedata
    s = (s or "").replace("đ", "d").replace("Đ", "D")
    return "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn").lower()


def neo(k):
    return "m-" + re.sub(r"[^A-Za-z0-9]+", "-", k).strip("-")


def noi_dung_html(nd):
    out, ds = [], []

    def dong_ds():
        if ds:
            out.append("<ul>" + "".join("<li>%s</li>" % x for x in ds) + "</ul>")
            del ds[:]
    for d in (nd or "").split("\n"):
        d = d.rstrip()
        if not d:
            continue
        if d.startswith("- "):
            ds.append(e(d[2:]))
            continue
        dong_ds()
        m = re.match(r"^(Làm gì|Các bước|Lưu ý|Liên quan|Ví dụ|Cách làm|Mẹo)\s*:\s*(.*)$", d)
        if m:
            out.append('<p><b>%s:</b> %s</p>' % (e(m.group(1)), e(m.group(2))))
        else:
            out.append("<p>%s</p>" % e(d))
    dong_ds()
    return "".join(out)


def muc_html(m, cot=False):
    tim = khong_dau(" ".join([m["tieu_de"], m["tom_tat"], m.get("tim") or "", " ".join(m["khoa"])]))
    return ('<div class="muc%s" id="%s" data-tim="%s"><h4>%s</h4><p class="tt">%s</p>%s</div>'
            % (" cot" if cot else "", neo(m["chinh"]), e(tim), e(m["tieu_de"]), e(m["tom_tat"]), noi_dung_html(m["noi_dung"])))


def doc_van_ban():
    try:
        import cong_viec
        return cong_viec.doc_van_ban()
    except Exception:
        return "", []


def lap(kb=None, ra=None, ngay=None):
    import tool_tro_ly_ai as T
    kb = kb or os.path.join(HERE, "tro_ly", "huong_dan.txt")
    ra = ra or RA_MAC_DINH
    muc = T.doc_kb(kb)
    goi = ""
    try:
        with io.open(os.path.join(HERE, "phien_ban_goi.txt"), encoding="utf-8-sig") as f:
            goi = f.readline().strip().replace("GD", "GĐ")
    except OSError:
        pass
    ngay = ngay or time.strftime("%d/%m/%Y")
    theo_nhom = {}
    ten_nhom = {}
    for m in muc:
        theo_nhom.setdefault(m["nhom"], []).append(m)
        ten_nhom[m["nhom"]] = m.get("ten_nhom") or m["nhom"]
    moi = [m for m in muc if m["chinh"].startswith("CB.MOI")]
    phan = [list(p) for p in PHAN]
    da = {n for p in PHAN for n in p[2]}
    them = [n for n in theo_nhom if n not in da]
    if them:
        phan.append(["I", "Các mục khác", them])
    H = []
    H.append("""<!DOCTYPE html><html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Hướng dẫn sử dụng UNESCO XI + AI</title><style>
:root{--xanh:#0b3d91;--nen:#f6f8fc;--chu:#1f2937;--nhat:#6b7280;--vien:#d9e1f2}
body{margin:0;font-family:"Segoe UI",Tahoma,Arial,sans-serif;color:var(--chu);background:#fff;line-height:1.5}
header{background:var(--xanh);color:#fff;padding:18px 24px}header h1{margin:0;font-size:24px}header p{margin:4px 0 0;opacity:.9}
.tim{position:sticky;top:0;background:#fff;border-bottom:1px solid var(--vien);padding:8px 24px;z-index:2}
.tim input{width:100%;max-width:620px;padding:8px 10px;font-size:15px;border:1px solid #9aa9c7;border-radius:6px}
.tim span{margin-left:10px;color:var(--nhat);font-size:13px}
main{padding:8px 24px 40px;max-width:1100px}h2{color:var(--xanh);border-bottom:2px solid var(--vien);padding-bottom:4px;margin-top:28px}
h3{color:var(--xanh);margin:22px 0 6px}.muc{border:1px solid var(--vien);border-radius:8px;padding:8px 12px;margin:8px 0;background:var(--nen)}
.muc h4{margin:0 0 2px;font-size:15px}.muc .tt{margin:0 0 4px;color:#374151}.muc p{margin:3px 0}.muc ul{margin:3px 0 3px 18px;padding:0}
.muc.cot{background:#fff;padding:4px 10px}.muc.cot h4{font-size:14px}nav ol{columns:2;margin:6px 0}nav a,table a{color:var(--xanh)}
table{border-collapse:collapse;width:100%;font-size:13px;margin:8px 0}th,td{border:1px solid var(--vien);padding:4px 6px;vertical-align:top}
th{background:#d9e1f2}.an{display:none}.nho{color:var(--nhat);font-size:13px}
@media print{.tim{display:none}header{background:#fff;color:#000;border-bottom:2px solid #000}.muc{break-inside:avoid}}
</style></head><body>""")
    H.append("<header><h1>HƯỚNG DẪN SỬ DỤNG UNESCO XI + AI UNESCO</h1><p>Bản tổng hợp%s - lập ngày %s - %d mục hướng dẫn, "
             "tự cập nhật theo mỗi gói</p></header>" % ((" tới gói " + e(goi)) if goi else "", e(ngay), len(muc)))
    H.append('<div class="tim"><input id="o" type="search" placeholder="Tìm: gõ tên nút, màn hình, việc cần làm (có dấu hay không đều '
             'được)..." oninput="loc()"><span id="dem"></span></div><main>')
    tl = tai_lieu_html(ra)          # GD169
    H.append("<nav><h2>Mục lục</h2><ol>" + ("<li><a href=\"#tai-lieu\">Tài liệu kèm theo (hướng dẫn trực quan, tính năng AI)</a></li>" if tl else "") +
             "<li><a href=\"#bat-dau\">Bắt đầu nhanh</a></li><li><a href=\"#co-gi-moi\">Có gì mới</a></li>"
             "<li><a href=\"#tien-ich\">Tiện ích các module</a></li>")
    for k, ten, _ in phan:
        H.append('<li><a href="#phan-%s">%s. %s</a></li>' % (k, k, e(ten)))
    H.append('<li><a href="#van-ban">Phụ lục: văn bản pháp luật, biểu mẫu</a></li></ol></nav>')
    if tl:
        H.append(tl)
    H.append('<section id="bat-dau"><h2>Bắt đầu nhanh</h2>')
    for td, ds in BAT_DAU:
        H.append('<div class="muc" data-tim="%s"><h4>%s</h4><ul>%s</ul></div>'
                 % (e(khong_dau(td + " " + " ".join(ds))), e(td), "".join("<li>%s</li>" % e(x) for x in ds)))
    H.append("</section>")
    H.append('<section id="co-gi-moi"><h2>Có gì mới (mới nhất trước)</h2>')
    for m in moi:
        H.append(muc_html(m))
    H.append("</section>")
    H.append('<section id="tien-ich"><h2>Tiện ích các module</h2><table><tr><th>Module</th><th>Số mục</th><th>Tiện ích, nút chính</th></tr>')
    for k, ten, ds in phan:
        for n in ds:
            ms = [m for m in theo_nhom.get(n, []) if "#" not in m["chinh"] and not m["chinh"].startswith("CB.MOI")]
            if not ms:
                continue
            tieu = ", ".join('<a href="#%s">%s</a>' % (neo(m["chinh"]), e(m["tieu_de"])) for m in ms[:14])
            if len(ms) > 14:
                tieu += ", ... (%d mục)" % len(ms)
            H.append('<tr><td><a href="#n-%s">%s</a></td><td>%d</td><td>%s</td></tr>' % (neo(n), e(ten_nhom.get(n, n)), len(ms), tieu))
    H.append("</table></section>")
    for k, ten, ds in phan:
        H.append('<section id="phan-%s"><h2>%s. %s</h2>' % (k, k, e(ten)))
        for n in ds:
            ms = [m for m in theo_nhom.get(n, []) if not m["chinh"].startswith("CB.MOI")]
            if not ms:
                continue
            H.append('<h3 id="n-%s">%s</h3>' % (neo(n), e(ten_nhom.get(n, n))))
            for m in ms:
                H.append(muc_html(m, cot="#" in m["chinh"]))
        H.append("</section>")
    ngay_vb, vb = doc_van_ban()
    H.append('<section id="van-ban"><h2>Phụ lục: văn bản pháp luật, biểu mẫu báo cáo</h2>')
    H.append('<p class="nho">Danh mục ngày %s (bảng Cập nhật thay đổi văn bản pháp luật trong Quản lý công việc; cập nhật qua kênh '
             'cập nhật tự động).</p><table><tr><th>Hiệu lực</th><th>Văn bản</th><th>Thay đổi chính</th><th>Biểu mẫu / báo cáo</th>'
             '<th>Đề xuất</th></tr>' % e(ngay_vb or "-"))
    for x in vb:
        H.append("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>"
                 % (e(x["hieu_luc"]), e(x["van_ban"]), e(x["noi_dung"]), e(x["anh_huong"]), e(x["de_xuat"])))
    H.append("</table></section></main>")
    H.append("""<script>
function kd(s){return s.normalize('NFD').replace(/[\\u0300-\\u036f]/g,'').replace(/\\u0111/g,'d').replace(/\\u0110/g,'d').toLowerCase();}
function loc(){var q=kd(document.getElementById('o').value.trim()),ds=document.querySelectorAll('.muc'),n=0;
for(var i=0;i<ds.length;i++){var t=ds[i].getAttribute('data-tim')||'',ok=!q||q.split(/\\s+/).every(function(w){return t.indexOf(w)>=0;});
ds[i].classList.toggle('an',!ok);if(ok)n++;}
document.getElementById('dem').textContent=q?(n+' mục khớp'):'';}
</script></body></html>""")
    os.makedirs(os.path.dirname(os.path.abspath(ra)), exist_ok=True)
    with io.open(ra, "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(H))
    return ra, len(muc)


if __name__ == "__main__":
    a = sys.argv[1:]
    ra = a[a.index("--ra") + 1] if "--ra" in a else None
    p, n = lap(ra=ra)
    print("Da lap %s (%d muc)" % (p, n))
