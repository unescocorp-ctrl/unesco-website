# -*- coding: utf-8 -*-
"""
tool_tro_ly_ai.py - TRO LY AI cua UNESCO XI (GD38): tra loi cau hoi ve cac tinh nang AI
                    dua tren bo huong dan tro_ly\\huong_dan.txt (co the hoi Claude neu da bat).

VB6 goi:   tool_tro_ly_ai.py /hoi:"<thu muc tool>\\tro_ly\\hoi\\hoi_<ma>.txt"
  Tep hoi (UTF-8): cac dong  khoa=<muc dang xem>  so_lieu=<so dem tren man hinh AI>
                             ra=<tep tra loi>     xong=<tep co bao xong>
                   dong '---', phan con lai la cau hoi.
  Tep tra loi (UTF-8): dong nguon=claude|offline, dong muc=;khoa1;khoa2; , dong '---', roi noi dung.
  Tep xong duoc tao SAU CUNG (VB6 thay tep nay moi doc tep tra loi).

Thu tay:   python tool_tro_ly_ai.py /thu:"cau hoi"     (in cac muc chon duoc + tra loi offline, khong goi mang)

AN TOAN (quy tac 17): chi gui cho Claude cau hoi + cac muc huong dan lien quan + so dem tren
man hinh (so hoa don, so dong...), KHONG gui so lieu so sach, so tai khoan, ma so thue.
Nhat ky chi ghi DO DAI cau hoi, khong ghi noi dung cau hoi / tra loi, khong ghi khoa API.
Tool chi DOC: khong ghi so, khong sua du lieu cua phan mem.
"""
import io
import json
import os
import re
import sys
import time
import unicodedata
import urllib.error
import urllib.request
from datetime import datetime

APP_VERSION = "1.0-TL"
BASE_DIR = os.path.dirname(os.path.abspath(sys.argv[0] if getattr(sys, "frozen", False) else __file__))

if __name__ == "__main__":          # GD111: lien ket .py cua Python install manager / Store bo mat tham so VB6
    try:
        import tham_so_du_phong as _TSDP
        sys.argv = _TSDP.bu_tham_so(sys.argv, BASE_DIR, phai_co=("/hoi:",))
    except Exception:
        pass

KB_PATH = os.path.join(BASE_DIR, "tro_ly", "huong_dan.txt")
SETTINGS_PATH = os.path.join(BASE_DIR, "cai-dat.json")
LOG_PATH = os.path.join(BASE_DIR, "nhat-ky-tro-ly.txt")
MODEL_MAC_DINH = "claude-sonnet-4-5"
SO_MUC_GUI = 6          # so muc huong dan gui kem cau hoi
DAI_CAU_HOI = 1000      # cat cau hoi qua dai
HAN_TONG = 75           # giay: phai tra loi xong truoc han nay (VB6 cho toi da 90 giay)
HET_GIO_LAN = 35        # giay cho moi lan goi Claude

TU_DUNG = set(("la va cua co cho the nao gi toi em anh chi de khi thi nhu lam sao bi duoc khong mot cac "
               "nhung voi o tai ra nay do can muon hay hoac neu roi tren duoi trong ve bang minh ban nut").split())

# cau hoi hay viet day du, huong dan hay viet tat (giong TL_MoRongTu ben VB6)
VIET_TAT = [("don vi tinh", "dvt"), ("tai khoan", "tk"), ("chung tu", "ct"), ("nguyen vat lieu", "nvl"),
            ("nguyen lieu", "nvl"), ("thanh pham", "tp"), ("nha cung cap", "ncc"), ("khach hang", "kh"),
            ("ma so thue", "mst"), ("gia tri gia tang", "gtgt"), ("bao cao tai chinh", "bctc"),
            ("thu nhap doanh nghiep", "tndn"), ("cung luc", "hang loat"), ("mot lan", "hang loat")]

TEN_SO = ["hoá đơn chờ duyệt", "hoá đơn chưa phân tích", "hoá đơn không xử lý", "hoá đơn cần xem lại",
          "mặt hàng thiếu mã", "nhà cung cấp / khách hàng thiếu mã", "hoá đơn hàng hoá sẵn sàng lập",
          "hoá đơn dịch vụ sẵn sàng lập", "dòng sổ phụ chờ duyệt", "dòng sổ phụ chưa xử lý",
          "dòng sổ phụ cần xem lại", "dòng sổ phụ đã ghi", "mã khách hàng mới chờ duyệt",
          "nhân viên bảng lương chưa ghép mã"]

# ky tu ma font chu Viet kieu cu (VNI / TCVN3) cua o chu VB6 khong co -> doi truoc khi tra ve
THAY_KY_TU = {"\u2192": "->", "\u2190": "<-", "\u21d2": "=>", "\u2026": "...", "\u00b7": "-", "\u2022": "-",
              "\u2013": "-", "\u2014": "-", "\u2212": "-", "\u201c": '"', "\u201d": '"', "\u201e": '"',
              "\u2018": "'", "\u2019": "'", "\u00ab": '"', "\u00bb": '"', "\u2265": ">=", "\u2264": "<=",
              "\u00d7": "x", "\u2032": "'", "\u2033": '"', "\u25ba": ">", "\u25b6": ">", "\u25c4": "<",
              "\u2713": "v", "\u2714": "v", "\u2717": "x", "\u2610": "[ ]", "\u2611": "[x]", "\u00a0": " ",
              "\u2003": " ", "\u2002": " ", "\u200b": "", "\ufeff": ""}


# ---------------------------------------------------------------- nhat ky (khong ghi noi dung)
def ghi_nhat_ky(dong):
    try:
        with io.open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write("%s  %s\n" % (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), dong))
    except Exception:
        pass


# ---------------------------------------------------------------- bo huong dan
def chuan(s):
    """chu thuong, bo dau, d gach -> d, moi ky tu khong phai chu/so thanh dau cach; boc dau cach 2 dau"""
    s = (s or "").lower().replace("\u0111", "d")
    s = unicodedata.normalize("NFD", s)
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    s = re.sub(r"[^a-z0-9]+", " ", s)
    return " " + " ".join(s.split()) + " "


def doc_kb(duong=KB_PATH):
    """Tra ve danh sach muc: {khoa[], chinh, nhom, ten_nhom, tieu_de, tom_tat, noi_dung, tim}"""
    muc, nhom, ten_nhom, cur = [], "", "", None
    with io.open(duong, "r", encoding="utf-8-sig") as f:
        dong = f.read().split("\n")
    for ln in dong:
        ln = ln.rstrip("\r")
        if ln.startswith("@@"):
            m = re.match(r"^@@\s*([A-Z][A-Z0-9.]*)\s*\|\s*(.*)$", ln)
            if m:
                nhom, ten_nhom = m.group(1), m.group(2).strip()
            cur = None
            continue
        if ln.startswith("@"):
            khoa = [k.strip() for k in ln[1:].split(",") if k.strip()]
            if not khoa:
                cur = None
                continue
            cur = {"khoa": khoa, "chinh": khoa[0], "nhom": nhom, "ten_nhom": ten_nhom,
                   "tieu_de": "", "tom_tat": "", "noi_dung": [], "tim": ""}
            muc.append(cur)
            continue
        if cur is None:
            continue
        if ln.startswith("= "):
            cur["tieu_de"] = ln[2:].strip()
        elif ln.startswith("~ "):
            cur["tom_tat"] = ln[2:].strip()
        elif ln.startswith("T\u00ecm:"):
            cur["tim"] += " " + ln[4:].strip()
        else:
            cur["noi_dung"].append(ln)
    for m in muc:
        while m["noi_dung"] and not m["noi_dung"][-1].strip():
            m["noi_dung"].pop()
        m["noi_dung"] = "\n".join(m["noi_dung"])
        m["_td"] = chuan(m["tieu_de"])
        m["_tk"] = chuan(m["tim"])
        m["_nd"] = chuan(m["tom_tat"] + " " + m["noi_dung"])
    return muc


def tim_muc(muc, cau_hoi, khoa_dang_xem="", toi_da=SO_MUC_GUI):
    """Cham diem nhu ban VB6 (tieu de 6, tu khoa Tim 4, noi dung 1, cum 2 tu 5) + uu tien muc dang xem."""
    t = chuan(cau_hoi)
    for day, tat in VIET_TAT:
        if " %s " % day in t and " %s " % tat not in t:
            t += tat + " "
    q = t.split()
    tu = [w for w in q if len(w) >= 2 and w not in TU_DUNG]
    diem = [0] * len(muc)
    for j, w in enumerate(tu):
        for i, m in enumerate(muc):
            d = 0
            if " %s " % w in m["_td"]:
                d += 6
            if " %s" % w in m["_tk"]:
                d += 4
            if " %s " % w in m["_nd"]:
                d += 1
            diem[i] += d
    for j in range(len(q) - 1):
        if len(q[j]) < 2 or q[j] in TU_DUNG:      # nhu VB6: cum bat dau bang mot tu co nghia
            continue
        cum = " %s %s " % (q[j], q[j + 1])
        for i, m in enumerate(muc):
            if cum in m["_td"] or cum in m["_tk"]:
                diem[i] += 5
    chinh_xem = ""
    if khoa_dang_xem:
        goc = re.sub(r"\(\d+\)$", "", khoa_dang_xem)
        for i, m in enumerate(muc):
            if khoa_dang_xem in m["khoa"] or goc in m["khoa"]:
                chinh_xem = m["chinh"]
                diem[i] += 8
                break
    thu_tu = sorted(range(len(muc)), key=lambda i: (-diem[i], i))
    chon = [muc[i] for i in thu_tu if diem[i] >= 3][:toi_da]
    return chon, chinh_xem


def tra_loi_offline(chon, loi_nhac=""):
    if not chon:
        s = ("Trợ lý chưa tìm thấy mục hướng dẫn nào khớp câu hỏi. Hãy hỏi ngắn hơn bằng tên nút "
             "hoặc việc cần làm (ví dụ: sửa đơn vị tính, huỷ chứng từ, sổ phụ), hoặc bấm ? Hướng dẫn "
             "rồi bấm vào nút cần hỏi.")
    else:
        s = "Các mục hướng dẫn gần nhất với câu hỏi:"
        for n, m in enumerate(chon[:3], 1):
            s += "\n\n%d. %s\n%s" % (n, m["tieu_de"], m["tom_tat"])
    if loi_nhac:
        s = loi_nhac + "\n\n" + s
    return s


# ---------------------------------------------------------------- Claude
def doc_thiet_lap():
    try:
        with io.open(SETTINGS_PATH, "r", encoding="utf-8-sig") as f:
            st = json.load(f)
        return st if isinstance(st, dict) else {}
    except Exception:
        return {}


def mo_ta_so_lieu(chuoi):
    """'huong=mua;0=3;1=0;...' -> cac dong tieng Viet; bo so 0."""
    if not chuoi:
        return ""
    huong, dong = "", []
    for phan in chuoi.split(";"):
        if "=" not in phan:
            continue
        k, v = phan.split("=", 1)
        if k == "huong":
            huong = "MUA VÀO" if v == "mua" else ("BÁN RA" if v == "ban" else v)
            continue
        try:
            i, n = int(k), int(float(v))
        except ValueError:
            continue
        if 0 <= i < len(TEN_SO) and n > 0:
            dong.append("- %s: %d" % (TEN_SO[i], n))
    dau = "Màn hình AI đang xem hướng %s." % huong if huong else ""
    return (dau + "\n" + "\n".join(dong)).strip()


HE_THONG = (
    "Bạn là Trợ lý AI của phần mềm kế toán UNESCO XI, giúp người dùng hiểu và dùng các tính năng AI "
    "(tải và hạch toán hoá đơn điện tử, sổ phụ ngân hàng, quy tắc hạch toán, cân đối giá thành, xuất HTKK...). "
    "Quy tắc trả lời:\n"
    "1. Chỉ dựa vào các MỤC HƯỚNG DẪN được gửi kèm. Không bịa tên nút, tên thẻ, số liệu hay quy định. "
    "Nếu hướng dẫn không có thông tin, nói rõ là hướng dẫn chưa có và gợi ý bấm ? Hướng dẫn rồi bấm vào nút cần hỏi.\n"
    "2. Viết tiếng Việt có dấu, ngắn gọn (tối đa khoảng 180 từ), xưng hô trung tính (anh/chị).\n"
    "3. Khi chỉ thao tác, dùng đúng tên nút như trong hướng dẫn và liệt kê các bước 1. 2. 3.\n"
    "4. Chỉ văn bản thuần: không dùng markdown (không **, #, bảng), không biểu tượng cảm xúc.\n"
    "5. Nhắc lưu ý an toàn có trong hướng dẫn nếu liên quan (ví dụ: xem trước khi ghi, huỷ lô, "
    "chống trùng). Phần mềm không vượt captcha, không lưu mật khẩu, không ký hay nộp thay.\n"
    "6. Không đưa lời khuyên thuế, pháp lý vượt ngoài hướng dẫn; khi cần, khuyên hỏi kế toán trưởng.")


def noi_dung_gui(cau_hoi, chon, chinh_xem, so_lieu, muc_theo_khoa):
    phan = ["Câu hỏi của người dùng: " + cau_hoi]
    if chinh_xem and chinh_xem in muc_theo_khoa:
        phan.append("Người dùng đang xem: %s" % muc_theo_khoa[chinh_xem]["tieu_de"])
    sl = mo_ta_so_lieu(so_lieu)
    if sl:
        phan.append("Số đếm trên màn hình AI (chỉ là số lượng, không phải số liệu sổ sách):\n" + sl)
    phan.append("CÁC MỤC HƯỚNG DẪN:")
    for n, m in enumerate(chon, 1):
        phan.append("[%d] %s (%s)\n%s\n%s" % (n, m["tieu_de"], m["ten_nhom"], m["tom_tat"], m["noi_dung"]))
    return "\n\n".join(phan)


def goi_claude(key, model, noi_dung, han=None):
    """Tra ve (chu, loi). Thu toi da 2 lan trong han (time.time() < han); khong thu lai voi 400/401/403/404."""
    body = {"model": model, "max_tokens": 1000, "system": HE_THONG,
            "messages": [{"role": "user", "content": noi_dung}]}
    if han is None:
        han = time.time() + HAN_TONG
    loi = ""
    for lan in range(2):
        con = han - time.time()
        if con < 10:
            loi = loi or "het gio"
            break
        try:
            req = urllib.request.Request("https://api.anthropic.com/v1/messages",
                                         data=json.dumps(body).encode("utf-8"),
                                         headers={"Content-Type": "application/json", "x-api-key": key,
                                                  "anthropic-version": "2023-06-01"}, method="POST")
            with urllib.request.urlopen(req, timeout=min(HET_GIO_LAN, con)) as r:
                raw = r.read().decode("utf-8")
            chu = "".join(c.get("text", "") for c in json.loads(raw).get("content", []) if c.get("type") == "text")
            if chu.strip():
                return chu.strip(), ""
            loi = "Claude tra ve rong"
        except urllib.error.HTTPError as e:
            loi = "HTTP %s" % e.code
            if e.code in (400, 401, 403, 404):
                break
        except Exception as e:  # mang, het gio, JSON hong
            loi = type(e).__name__
        if lan == 0 and han - time.time() > 12:
            time.sleep(2)
    return "", loi


def lam_sach(s):
    """Bo markdown thong dung va ky tu font VNI/TCVN3 khong co; giu chu Viet, ASCII, xuong dong."""
    for a, b in THAY_KY_TU.items():
        s = s.replace(a, b)
    s = re.sub(r"\*\*(.+?)\*\*", r"\1", s)
    s = re.sub(r"(?m)^#{1,6}\s*", "", s)
    s = re.sub(r"(?m)^\s*[\*]\s+", "- ", s)
    s = s.replace("`", "")
    ra = []
    for c in unicodedata.normalize("NFC", s):
        o = ord(c)
        if c in "\n\t" or 32 <= o < 127:
            ra.append(c)
        elif unicodedata.category(c).startswith("L") and ("LATIN" in unicodedata.name(c, "")):
            ra.append(c)
        elif c == "%":
            ra.append(c)
    s = "".join(ra)
    s = re.sub(r"[ \t]+\n", "\n", s)
    s = re.sub(r"\n{3,}", "\n\n", s)
    return s.strip()


# ---------------------------------------------------------------- tep hoi / tep tra loi
def doc_tep_hoi(duong):
    with io.open(duong, "r", encoding="utf-8-sig") as f:
        txt = f.read().replace("\r\n", "\n")
    dau, _, than = txt.partition("\n---\n")
    if not _ and txt.startswith("---\n"):
        dau, than = "", txt[4:]
    tt = {}
    for ln in dau.split("\n"):
        if "=" in ln:
            k, v = ln.split("=", 1)
            tt[k.strip()] = v.strip()
    tt["cau_hoi"] = than.strip()[:DAI_CAU_HOI]
    return tt


def ghi_tra_loi(ra, xong, nguon, ds_khoa, chu):
    noi = "nguon=%s\nmuc=%s\n---\n%s" % (nguon, ds_khoa, chu)
    tam = ra + ".tam"
    with io.open(tam, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(noi)
    if os.path.exists(ra):
        os.remove(ra)
    os.rename(tam, ra)
    with io.open(xong, "w", encoding="utf-8") as f:
        f.write("ok")


def xu_ly(tt, muc=None, cho_phep_mang=True, han=None):
    """Tra ve (nguon, ds_khoa, chu)."""
    cau_hoi = tt.get("cau_hoi", "")
    try:
        if muc is None:
            muc = doc_kb()
    except Exception as e:
        return "offline", "", "Không đọc được bộ hướng dẫn tro_ly\\huong_dan.txt (%s)." % type(e).__name__
    chon, chinh_xem = tim_muc(muc, cau_hoi, tt.get("khoa", ""))
    ds_khoa = (";" + ";".join(m["chinh"] for m in chon) + ";") if chon else ""
    st = doc_thiet_lap() if cho_phep_mang else {}
    key = str(st.get("anthropic_key") or "").strip()
    model = str(st.get("anthropic_model") or "").strip() or MODEL_MAC_DINH
    if not cho_phep_mang:
        return "offline", ds_khoa, tra_loi_offline(chon)
    if not key:
        return "offline", ds_khoa, tra_loi_offline(
            chon, "Chưa có khoá Claude API (nhập ở tool tải hoá đơn, mục AI) nên Trợ lý trả lời từ bộ hướng dẫn có sẵn.")
    if not chon:
        # khong co muc nao lien quan -> van hoi Claude voi cac muc chung de Claude noi "chua co huong dan"
        chon = [m for m in muc if m["nhom"] == "CHUNG"][:3]
    theo_khoa = {m["chinh"]: m for m in muc}
    chu, loi = goi_claude(key, model, noi_dung_gui(cau_hoi, chon, chinh_xem, tt.get("so_lieu", ""), theo_khoa), han)
    if not chu:
        ghi_nhat_ky("[CLAUDE] khong tra loi duoc (%s)" % loi)
        return "offline", ds_khoa, tra_loi_offline(
            chon if ds_khoa else [], "Không nhận được trả lời của Claude (%s). Dưới đây là các mục hướng dẫn gần nhất." % loi)
    return "claude", ds_khoa, lam_sach(chu)


def _mo_rong(argv):
    """GD63: /thamso:"<tep UTF-8>" (VB6 ghi tham so ra tep - duong dan co dau qua ShellExecuteA bi hong)."""
    out = []
    for a in argv:
        if str(a).lower().startswith("/thamso:"):
            try:
                with io.open(str(a)[8:].strip().strip('"'), "r", encoding="utf-8-sig") as f:
                    txt = f.read()
            except Exception:
                txt = ""
            cur, trong = "", False            # tach theo khoang trang, ton trong dau nhay kep
            for ch in txt:
                if ch == '"':
                    trong = not trong
                    cur += ch
                elif ch in " \t\r\n" and not trong:
                    if cur:
                        out.append(cur)
                        cur = ""
                else:
                    cur += ch
            if cur:
                out.append(cur)
        else:
            out.append(a)
    return out


def main(argv):
    hoi = thu = None
    argv = _mo_rong(argv)
    for a in argv:
        if a.startswith("/hoi:"):
            hoi = a[5:].strip().strip('"')
        elif a.startswith("/thu:"):
            thu = a[5:].strip().strip('"')
    if thu is not None:
        try:
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
        tt = {"cau_hoi": thu, "khoa": ""}
        muc = doc_kb()
        chon, _ = tim_muc(muc, thu)
        for m in chon:
            print("  %-40s %s" % (m["chinh"], m["tieu_de"]))
        print(xu_ly(tt, muc, cho_phep_mang=False)[2])
        return 0
    if not hoi:
        print(__doc__)
        return 1
    t0 = time.time()
    try:
        tt = doc_tep_hoi(hoi)
    except Exception as e:
        ghi_nhat_ky("[LOI] khong doc duoc tep hoi (%s)" % type(e).__name__)
        return 2
    try:                                    # quy tac 17: cau hoi khong nam lai tren dia
        os.remove(hoi)
    except Exception:
        pass
    ra, xong = tt.get("ra", ""), tt.get("xong", "")
    if not ra or not xong:
        ghi_nhat_ky("[LOI] tep hoi thieu dong ra= / xong=")
        return 2
    try:
        nguon, ds_khoa, chu = xu_ly(tt, han=t0 + HAN_TONG)
    except Exception as e:                  # luon tra loi + bao xong de VB6 khong phai cho het 90 giay
        ghi_nhat_ky("[LOI] xu ly cau hoi (%s)" % type(e).__name__)
        nguon, ds_khoa, chu = "offline", "", tra_loi_offline([], "Trợ lý gặp lỗi khi xử lý câu hỏi (%s)." % type(e).__name__)
    try:
        ghi_tra_loi(ra, xong, nguon, ds_khoa, chu)
    except Exception as e:
        ghi_nhat_ky("[LOI] khong ghi duoc tep tra loi (%s)" % type(e).__name__)
        return 3
    ghi_nhat_ky("[HOI] %d ky tu, khoa=%s, nguon=%s, %d muc, %.1f giay" % (
        len(tt.get("cau_hoi", "")), tt.get("khoa", "") or "-", nguon, ds_khoa.count(";") - 1 if ds_khoa else 0,
        time.time() - t0))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
