# -*- coding: utf-8 -*-
"""GD293 - CONG CU KHACH, phia UNESCO (van phong). Anh Thang 19/10/2026: khach nhap phieu kho + xem NXT / cong no / KQKD tren may
cua khach bang cong cu nho; doi goi tep voi ke toan (Zalo / email / USB), khong ten mien, khong VPS.

  XUAT goi DI  (ke toan chot so den ngay D):  /congkhach:xuat /mdb:<so .MDB> /mst:<MST> /ten:<ten cty> /ngaychot:YYYY-MM-DD
                /ra:<thu muc ghi goi> /khach:<thu muc du lieu AI cua cong ty> [/matkhau:<mat khau cong cu khach>]
      -> <ra>\\GOI_DI_<MST>_<ngay>_<stt>.ukx : danh muc (vat tu + GiaBan1, doi tuong, kho, TK), ton kho + cong no 12 thang (bang tong
         hop UNESCO da tinh), KQKD 12 thang (B02 theo cong thuc KQKD + uoc theo phat sinh TK khi chua ket chuyen), chi tiet chung tu
         thang chot + 1 thang lien ke, trang thai phieu khach da gui, doi ma; ky Ed25519 (khoa rieng cua van phong theo MST).
  NAP goi VE   (khach gui phieu):  /congkhach:nap /tep:<goi .ukx> /mst:<MST> /ten:<ten cty> /khach:<thu muc> /ra:<tep .jsonl>
      -> kiem chu ky (khoa may khach ghim lan dau), MST, so thu tu; moi dong hang cua phieu -> mot dong JSONL DUNG DINH DANG tool tai
         hoa don (nhu bang ke GD108): NK = mua vao (MaSoLoaiCT 1), XK = ban ra (8), khoa "CK|<MST>|<so phieu>", so_ct = so phieu
         (thanh so chung tu khi ke toan Ghi), MaVT = so hieu vat tu (ghep "MA_HD" 100%), nguon = congkhach.
      VB6 chep JSONL vao ket-qua -> HDDT_DocKetQua -> AI ghep ma / dinh khoan -> ke toan bam Ghi -> ClsChungtu (quy tac 11, 18).
  CHI DOC so (jet_doc); khong ghi .MDB. Trang thai rieng: <khach>\\congkhach\\trang_thai.json (so goi, khoa may khach, phieu da nap).
"""
import datetime as _dt
import hashlib
import io
import json
import os
import re
import sys
import time

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)
import cong_khach_goi as G

PHIEN_BAN = "GD293"
TK_CONG_NO = ("131", "331", "136", "138", "141", "336", "338", "344", "244")
TK_DOANH_THU = ("511", "512", "515", "711")
TK_CHI_PHI = ("632", "635", "641", "642", "811", "821")


# ------------------------------------------------------------------------------------------------ chu Viet trong so
def _bo_ma():
    try:
        import bang_luong_gd78 as B
        return B
    except Exception:
        return None


class ChuSo(object):
    """Doi chu font cu (VNI / TCVN3 theo License.FontName) sang Unicode. bytes (memo UTF-16) -> str."""

    def __init__(self, font):
        self.B = _bo_ma()
        f = (font or "").upper()
        self.kieu = "VNI" if f.startswith("VNI") else ("TCVN3" if (f.startswith(".VN") or f.startswith("VN")) else "")

    def u(self, s):
        if isinstance(s, bytes):
            try:
                s = s.decode("utf-16-le", "replace")
            except Exception:
                s = s.decode("cp1252", "replace")
        if s is None:
            return ""
        s = str(s)
        if s.strip() == "...":
            return ""
        if not self.B or not s or any(ord(c) > 255 for c in s):
            return s.strip()
        k = self.kieu or self.B.loai_ma([s])
        if k == "VNI":
            return self.B.vni_sang_u(s).strip()
        if k == "TCVN3":
            return self.B.tcvn3_sang_u(s).strip()
        return s.strip()


def _so(x):
    try:
        if x is None:
            return 0.0
        return float(x)
    except Exception:
        return 0.0


def _ngay_iso(d):
    if isinstance(d, (_dt.datetime, _dt.date)):
        return d.strftime("%Y-%m-%d")
    return ""


# ------------------------------------------------------------------------------------------------ trang thai rieng
def _tep_tt(khach):
    d = os.path.join(khach, "congkhach")
    if not os.path.isdir(d):
        os.makedirs(d)
    return os.path.join(d, "trang_thai.json")


def doc_tt(khach):
    t = _tep_tt(khach)
    if os.path.isfile(t):
        try:
            with io.open(t, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {"so_di": 0, "so_ve_da_nap": 0, "khoa_khach": "", "da_nap": {}, "tra_lai": {}}


def ghi_tt(khach, tt):
    t = _tep_tt(khach)
    with io.open(t + ".tmp", "w", encoding="utf-8") as f:
        json.dump(tt, f, ensure_ascii=False, indent=1)
    os.replace(t + ".tmp", t)


def tep_khoa_vp(mst):
    """Khoa rieng cua van phong theo MST: %APPDATA%\\UNESCO_AI\\cong_khach\\<MST>\\khoa_rieng.dat (NGOAI du an / bo cai)."""
    goc = os.environ.get("APPDATA") or os.path.expanduser("~")
    return os.path.join(goc, "UNESCO_AI", "cong_khach", str(mst or "CHUNG"), "khoa_rieng.dat")


def bam_mat_khau(mk, mst):
    return hashlib.sha256(("UNESCO_KHACH|%s|%s" % (mst, mk)).encode("utf-8")).hexdigest()


# ------------------------------------------------------------------------------------------------ doc so
class So(object):
    def __init__(self, mdb):
        import jet_doc
        self.m = jet_doc.Mdb(mdb)
        self.bang = {k.lower(): k for k in self.m.bang()}
        lic = self.doc("License", 1)
        self.lic = lic[0] if lic else {}
        self.chu = ChuSo(str(self.lic.get("FontName") or ""))
        self.thang_dau = int(self.lic.get("Thang") or 1) or 1
        self.nam_tc = int(self.lic.get("NamTC") or _dt.date.today().year)

    def co(self, t):
        return t.lower() in self.bang

    def doc(self, t, toi_da=None):
        if not self.co(t):
            return []
        return self.m.doc(self.bang[t.lower()], toi_da)

    def dong(self):
        try:
            self.m.dong()
        except Exception:
            pass

    def idx(self, thang):
        """thang duong lich -> chi so cot _n cua nam tai chinh (1..12)."""
        return ((int(thang) - self.thang_dau) % 12) + 1

    def thang_cua_idx(self, i):
        return ((self.thang_dau - 1 + int(i) - 1) % 12) + 1


def _ten_tk(tk_map, ma):
    return tk_map.get(int(ma or 0), ("", ""))[0]


def xuat(mdb, mst, ten_cty, ngay_chot, ra_dir, khach, mat_khau="", ghi_log=print, may="VP"):
    """-> (duong goi .ukx, tom tat text)."""
    so = So(mdb)
    try:
        u = so.chu.u
        if not ten_cty:
            ten_cty = u(so.lic.get("TenCty"))
        if not mst:
            mst = re.sub(r"\D", "", str(so.lic.get("MaSoThue") or ""))
        d = _dt.datetime.strptime(ngay_chot, "%Y-%m-%d").date()
        i_chot = so.idx(d.month)
        thang_truoc = 12 if d.month == 1 else d.month - 1
        i_truoc = so.idx(thang_truoc)
        # --- danh muc
        tk_map = {}
        for r in so.doc("HethongTK"):
            tk_map[int(r.get("MaSo") or 0)] = (str(r.get("SoHieu") or "").strip(), u(r.get("Ten")))
        kho = []
        for r in so.doc("KhoHang"):
            kho.append({"ma_so": int(r.get("MaSo") or 0), "ten": u(r.get("TenKho")), "tk": _ten_tk(tk_map, r.get("MaTK")), "tk_gv": _ten_tk(tk_map, r.get("MaTKGV"))})
        vt_map, vat_tu = {}, []
        for r in so.doc("Vattu"):
            sh = str(r.get("SoHieu") or "").strip()
            if not sh or sh.startswith("#"):
                continue
            ms = int(r.get("MaSo") or 0)
            vt_map[ms] = sh
            vat_tu.append({"ma_so": ms, "so_hieu": sh, "ten": u(r.get("TenVattu")), "dvt": u(r.get("DonVi")), "gia_ban1": _so(r.get("GiaBan1")),
                           "pl": int(r.get("MaPhanLoai") or 0)})
        dt_map, doi_tuong = {}, []
        for r in so.doc("KhachHang"):
            sh = str(r.get("SoHieu") or "").strip()
            if not sh or sh.startswith("#"):
                continue
            ms = int(r.get("MaSo") or 0)
            dt_map[ms] = sh
            m = re.sub(r"[^0-9-]", "", str(r.get("MST") or ""))
            doi_tuong.append({"ma_so": ms, "so_hieu": sh, "ten": u(r.get("Ten")), "mst": m, "du_max": _so(r.get("DuMax")),
                              "pl": int(r.get("MaPhanLoai") or 0), "dia_chi": u(r.get("DiaChi"))})
        tk_ds = [{"so_hieu": v[0], "ten": v[1]} for k, v in sorted(tk_map.items()) if v[0]]
        danh_muc = {"vat_tu": vat_tu, "doi_tuong": doi_tuong, "kho": kho, "tai_khoan": tk_ds, "nam_tc": so.nam_tc, "thang_dau": so.thang_dau}
        # --- ton kho (bang TonKho: cot _0 dau nam, _n theo thang nam TC)
        ton = []
        for r in so.doc("TonKho"):
            vt = vt_map.get(int(r.get("MaVatTu") or 0))
            if not vt:
                continue
            th = {}
            for i in range(1, 13):
                th[str(i)] = [_so(r.get("Luong_Nhap_%d" % i)), _so(r.get("Tien_Nhap_%d" % i)), _so(r.get("Luong_Xuat_%d" % i)),
                              _so(r.get("Tien_Xuat_%d" % i)), _so(r.get("Luong_%d" % i)), _so(r.get("Tien_%d" % i))]
            ton.append({"kho": int(r.get("MaSoKho") or 0), "tk": _ten_tk(tk_map, r.get("MaTaiKhoan")), "vt": vt,
                        "dau": [_so(r.get("Luong_0")), _so(r.get("Tien_0"))], "th": th})
        # --- cong no (SoDuKhachHang)
        cn = []
        for r in so.doc("SoDuKhachHang"):
            tk = _ten_tk(tk_map, r.get("MaTaiKhoan"))
            dt = dt_map.get(int(r.get("MaKhachHang") or 0))
            if not dt or not tk.startswith(TK_CONG_NO):
                continue
            th = {}
            for i in range(1, 13):
                th[str(i)] = [_so(r.get("No_%d" % i)), _so(r.get("Co_%d" % i)), _so(r.get("DuNo_%d" % i)), _so(r.get("DuCo_%d" % i))]
            cn.append({"tk": tk, "dt": dt, "dau": [_so(r.get("DuNo_0")), _so(r.get("DuCo_0"))], "th": th})
        # --- KQKD + chi tiet: mot luot ChungTu
        kq_rows = so.doc("KQKD")
        cap = {}            # (SHTKNo, SHTKCo) -> [MaSo chi tieu...]
        chi_tieu = {}
        for r in kq_rows:
            ms = int(r.get("MaSo") or 0)
            if ms not in chi_tieu:
                chi_tieu[ms] = {"ma_so": ms, "ten": u(r.get("Ten")), "cha": int(r.get("MaSoCha") or 0), "tong_hop": int(r.get("TongHop") or 0)}
            n_, c_ = str(r.get("SHTKNo") or "0").strip(), str(r.get("SHTKCo") or "0").strip()
            if n_ != "0" or c_ != "0":
                cap.setdefault((n_, c_), []).append(ms)
        b02 = {str(i): {} for i in range(1, 13)}
        uoc = {str(i): {"doanh_thu": 0.0, "giam_tru": 0.0, "chi_phi": 0.0, "ket_chuyen": False} for i in range(1, 13)}
        chi_tiet = []
        for r in so.doc("ChungTu"):
            if int(r.get("XuLy") or 0) >= 2:
                continue
            i = int(r.get("ThangCT") or 0)
            if i < 1 or i > 12:
                continue
            tn = _ten_tk(tk_map, r.get("MaTKNo"))
            tc = _ten_tk(tk_map, r.get("MaTKCo"))
            ps = _so(r.get("SoPS"))
            si = str(i)
            for (n_, c_), lst in cap.items():
                if (n_ == "0" or tn.startswith(n_)) and (c_ == "0" or tc.startswith(c_)):
                    for ms in lst:
                        b02[si][ms] = b02[si].get(ms, 0.0) + ps
            if tn.startswith("911") or tc.startswith("911"):
                uoc[si]["ket_chuyen"] = True
            else:
                if tc.startswith(TK_DOANH_THU):
                    uoc[si]["doanh_thu"] += ps
                if tn.startswith("511"):
                    uoc[si]["giam_tru"] += ps
                if tn.startswith(TK_CHI_PHI):
                    uoc[si]["chi_phi"] += ps
            if i in (i_chot, i_truoc) and len(chi_tiet) < 60000:
                chi_tiet.append({"ma_ct": int(r.get("MaCT") or 0), "loai": int(r.get("MaLoai") or 0), "ngay": _ngay_iso(r.get("NgayCT")),
                                 "so": u(r.get("SoHieu")), "dg": u(r.get("DienGiai")), "tk_no": tn, "tk_co": tc, "tien": ps,
                                 "vt": vt_map.get(int(r.get("MaVattu") or 0), ""), "sl": _so(r.get("SoXuat")), "kho": int(r.get("MaKho") or 0),
                                 "dt": dt_map.get(int(r.get("MaKH") or 0), ""), "dt_co": dt_map.get(int(r.get("MaKHC") or 0), "")})
        # tong hop B02 theo cay MaSoCha (con < cha): cong dan theo MaSo tang dan
        for si in b02:
            v = b02[si]
            for ms in sorted(chi_tieu):
                ct = chi_tieu[ms]
                cha = ct["cha"]
                if cha and ct["tong_hop"]:
                    v[abs(cha)] = v.get(abs(cha), 0.0) + (v.get(ms, 0.0) if cha > 0 else -v.get(ms, 0.0))
        kqkd = {"chi_tieu": [chi_tieu[k] for k in sorted(chi_tieu)], "b02": b02, "uoc": uoc}
        # --- trang thai phieu khach (HDDTTaiVe soct=CK...) + tra lai
        tt = doc_tt(khach)
        trang_thai = {}
        if so.co("HDDTTaiVe"):
            for r in so.doc("HDDTTaiVe"):
                k = str(r.get("AIIdempotencyKey") or "")
                m = re.search(r";soct=(CK[0-9A-Z]+)", k)
                if not m:
                    continue
                sp = m.group(1)
                ma_kt = str(r.get("MaCTKeToan") or "").strip()
                st = trang_thai.get(sp) or {"tt": "CHO"}
                if ma_kt:
                    st = {"tt": "DA_GHI", "ma_ct": ma_kt}
                elif st.get("tt") != "DA_GHI" and str(r.get("AIValidationStatus") or "") == "BO_QUA":
                    st = {"tt": "TRA_LAI", "ly_do": "Kế toán bỏ qua phiếu này trên màn hình AI"}
                trang_thai[sp] = st
        for sp, ly in (tt.get("tra_lai") or {}).items():
            if trang_thai.get(sp, {}).get("tt") != "DA_GHI":
                trang_thai[sp] = {"tt": "TRA_LAI", "ly_do": ly}
        # --- doi ma vat tu tam (~) -> ma that (AIItemCode da chon)
        doi_ma = {}
        if so.co("HDDTTaiVe"):
            for r in so.doc("HDDTTaiVe"):
                mv = str(r.get("MaVT") or "").strip()
                k = str(r.get("AIIdempotencyKey") or "")
                if mv.startswith("~") and "nguon=ck" in k:
                    ai = str(r.get("AIItemCode") or "").strip()
                    if ai and not ai.startswith("~"):
                        doi_ma[mv] = ai
        # --- goi
        tt["so_di"] = int(tt.get("so_di") or 0) + 1
        hat = G.doc_hoac_tao_khoa(tep_khoa_vp(mst))
        them = {"ngay_chot": ngay_chot, "thang_chi_tiet": [so.thang_cua_idx(i_truoc), d.month], "nam_tc": so.nam_tc}
        if mat_khau:
            them["mk"] = bam_mat_khau(mat_khau, mst)
        if tt.get("khoa_khach"):
            them["khoa_khach_da_ghim"] = tt["khoa_khach"]
        tep = {"danh_muc.json": json.dumps(danh_muc, ensure_ascii=False), "ton_kho.json": json.dumps(ton, ensure_ascii=False),
               "cong_no.json": json.dumps(cn, ensure_ascii=False), "kqkd.json": json.dumps(kqkd, ensure_ascii=False),
               "chi_tiet.jsonl": "\n".join(json.dumps(x, ensure_ascii=False) for x in chi_tiet),
               "trang_thai_phieu.json": json.dumps(trang_thai, ensure_ascii=False), "doi_ma.json": json.dumps(doi_ma, ensure_ascii=False)}
        if not os.path.isdir(ra_dir):
            os.makedirs(ra_dir)
        duong = os.path.join(ra_dir, G.ten_goi("DI", mst, tt["so_di"], d.strftime("%Y%m%d")))
        G.ghi_goi(duong, "DI", mst, ten_cty, tt["so_di"], ngay_chot, hat, tep, may=may, them=them)
        ghi_tt(khach, tt)
        tom = ["Đã xuất gói cho công cụ khách: %s" % os.path.basename(duong),
               "Công ty %s (MST %s), số liệu chốt đến %s, gói số %d." % (ten_cty, mst, d.strftime("%d/%m/%Y"), tt["so_di"]),
               "Danh mục: %d vật tư (kèm giá bán 1), %d đối tượng, %d kho. Tồn kho: %d dòng; công nợ: %d dòng; KQKD 12 tháng;"
               " chi tiết chứng từ tháng %d và %d: %d dòng." % (len(vat_tu), len(doi_tuong), len(kho), len(ton), len(cn),
                                                              so.thang_cua_idx(i_truoc), d.month, len(chi_tiet)),
               "Trạng thái phiếu khách: %d phiếu (%d đã ghi sổ, %d trả lại)." % (len(trang_thai), sum(1 for x in trang_thai.values() if x["tt"] == "DA_GHI"),
                                                                             sum(1 for x in trang_thai.values() if x["tt"] == "TRA_LAI")),
               ("Mật khẩu công cụ khách: đã đặt theo gói này." if mat_khau else "Mật khẩu công cụ khách: giữ nguyên (không đổi)."),
               "Gửi tệp .ukx cho khách qua Zalo / email / USB; khách mở công cụ > Nạp gói từ kế toán."]
        ghi_log("[CONG KHACH] xuat %s" % duong)
        return duong, "\n".join(tom)
    finally:
        so.dong()


# ------------------------------------------------------------------------------------------------ nap goi ve
def _dong_hoa_don(ph, d, mst_cty, ten_cty, ten_goi, i, n):
    loai = str(ph.get("loai") or "NK").upper()
    ban = loai == "XK"
    dt_ten, dt_mst = ph.get("dt_ten") or "", re.sub(r"\D", "", str(ph.get("dt_mst") or ""))
    tt = _so(d.get("thanh_tien")) or _so(d.get("so_luong")) * _so(d.get("don_gia"))
    tong = sum((_so(x.get("thanh_tien")) or _so(x.get("so_luong")) * _so(x.get("don_gia"))) for x in ph.get("dong") or [])
    sp = str(ph.get("so_phieu") or "")
    return {
        "KyHieuMauSo": "", "KyHieuHoaDon": "CK", "SoHoaDon": sp, "NgayLap": str(ph.get("ngay") or ""), "NgayNguoiBanKySo": "", "MCCQT": "",
        "NgayCQTKySo": "", "DonViTienTe": "VND", "TyGia": 1,
        "TenNguoiBanNguoiXuatHang": ten_cty if ban else dt_ten, "MSTNguoiBanNguoiXuatHang": mst_cty if ban else dt_mst, "DiaChiNguoiBan": "",
        "TenNguoiMuaNguoiNhanHang": dt_ten if ban else ten_cty, "MSTNguoiMuaNguoiNhanHang": dt_mst if ban else mst_cty, "DiaChiNguoiMua": "",
        "TongTienChietKhauThuongMai": 0, "TongTienPhi": 0, "TongTienThanhToan": tong,
        "TrangThaiHoaDon": "Phiếu %s công cụ khách" % ("xuất kho / bán" if ban else "nhập kho"), "KetQuaKiemTraHoaDon": "",
        "XML": False, "HDBanRa": ban, "MaSoLoaiCT": "8" if ban else "1", "MSTLogin": mst_cty,
        "khoa": "CK|%s|%s" % (mst_cty, sp), "huong": "ban" if ban else "mua", "tep_xml": ten_goi, "tthai": "", "ttxly": "",
        "mtt": False, "loai_hd": "", "httt": "", "lien_quan": None, "tong_chua_thue": tong, "tong_thue": 0, "nguon": "congkhach",
        "so_ct": sp, "ma_dt": str(ph.get("dt") or ""), "kho": ph.get("kho") or 0, "dien_giai": ph.get("dien_giai") or "",
        "stt_dong": i + 1, "so_dong": n, "tchat": "1", "MaVT": str(d.get("vt") or ""), "TenHangHoaDichVu": d.get("ten") or str(d.get("vt") or ""),
        "DonViTinh": d.get("dvt") or "", "SoLuong": _so(d.get("so_luong")), "DonGia": _so(d.get("don_gia")), "ChietKhau": 0, "ThueSuat": "",
        "ThanhTienChuaThue": tt, "TienThue": 0, "giam2": False,
    }


def nap(tep, mst, ten_cty, khach, ra, ghi_log=print):
    """-> (duong JSONL hoac "", tom tat, so phieu moi, so phieu trung)."""
    tt = doc_tt(khach)
    mo_ta, dl = G.doc_goi(tep, mst_mong=mst, khoa_ghim=tt.get("khoa_khach") or None, so_da_nap=int(tt.get("so_ve_da_nap") or 0))
    if mo_ta.get("loai") != "VE":
        raise ValueError("Đây là gói ĐI (kế toán xuất cho khách), không phải gói khách gửi về.")
    ds = []
    for line in dl.get("phieu.jsonl", b"").decode("utf-8").splitlines():
        line = line.strip()
        if line:
            ds.append(json.loads(line))
    da = tt.setdefault("da_nap", {})
    dong, moi, trung, loi = [], [], [], []
    ten_goi = os.path.basename(tep)
    for ph in ds:
        sp = str(ph.get("so_phieu") or "").strip()
        if not re.match(r"^CK[0-9A-Z]{4,20}$", sp):
            loi.append("%s: số phiếu không hợp lệ" % (sp or "?"))
            continue
        if sp in da:
            trung.append(sp)
            continue
        dl_ = [x for x in (ph.get("dong") or []) if str(x.get("vt") or "").strip() and _so(x.get("so_luong")) > 0]
        if not dl_:
            loi.append("%s: không có dòng hàng" % sp)
            continue
        n = len(dl_)
        for i, d in enumerate(dl_):
            dong.append(_dong_hoa_don(ph, d, mst, ten_cty, ten_goi, i, n))
        moi.append(sp)
        da[sp] = {"goi": int(mo_ta.get("so_thu_tu") or 0), "ngay": str(ph.get("ngay") or ""), "loai": str(ph.get("loai") or ""),
                  "tien": sum((_so(x.get("thanh_tien")) or _so(x.get("so_luong")) * _so(x.get("don_gia"))) for x in dl_)}
    duong = ""
    if dong:
        tam = ra + ".tmp"
        with io.open(tam, "w", encoding="utf-8", newline="\n") as f:
            for d in dong:
                f.write(json.dumps(d, ensure_ascii=False) + "\n")
        os.replace(tam, ra)
        duong = ra
    tt["so_ve_da_nap"] = int(mo_ta.get("so_thu_tu") or 0)
    if not tt.get("khoa_khach"):
        tt["khoa_khach"] = str(mo_ta.get("khoa_cong_khai") or "")
    ghi_tt(khach, tt)
    nk = sum(1 for p in ds if str(p.get("so_phieu")) in moi and str(p.get("loai") or "").upper() == "NK")
    tom = ["Gói khách gửi về: %s (gói số %s, tạo lúc %s, máy %s)." % (ten_goi, mo_ta.get("so_thu_tu"), mo_ta.get("tao_luc"), mo_ta.get("may") or "?"),
           "Phiếu mới: %d (%d nhập kho, %d xuất kho / bán) -> %d dòng hàng." % (len(moi), nk, len(moi) - nk, len(dong)),
           "Bỏ qua %d phiếu đã nạp lần trước." % len(trung) if trung else "",
           ("Lỗi %d phiếu: " % len(loi) + "; ".join(loi[:10])) if loi else "",
           ("Khoá máy khách đã ghim lần đầu - gói sau phải cùng khoá này." if not mo_ta.get("khoa_khach_da_ghim") and tt["so_ve_da_nap"] == int(mo_ta.get("so_thu_tu") or 0) and len(da) == len(moi) else ""),
           "Phiếu vào danh sách AI (mua vào = nhập kho, bán ra = xuất kho) - AI ghép mã, định khoản; CHƯA ghi sổ cho tới khi anh bấm Ghi." if dong else "Không có phiếu mới để đưa vào danh sách AI."]
    ghi_log("[CONG KHACH] nap %s: %d moi, %d trung, %d loi" % (ten_goi, len(moi), len(trung), len(loi)))
    return duong, "\n".join(x for x in tom if x), len(moi), len(trung)


def tra_lai(khach, so_phieu, ly_do):
    """VB6 goi khi ke toan tra lai phieu (Bo qua hoa don nguon congkhach): ghi vao trang thai de goi DI sau mang ve."""
    tt = doc_tt(khach)
    tt.setdefault("tra_lai", {})[str(so_phieu)] = ly_do or "Kế toán trả lại"
    ghi_tt(khach, tt)


# ------------------------------------------------------------------------------------------------ CLI
def _tham_so(argv):
    a = {}
    for x in argv:
        if x.startswith("/") and ":" in x:
            k, v = x[1:].split(":", 1)
            a[k.lower()] = v.strip('"')
    return a


def chay_cli(argv, ghi_log=print):
    """-> (ket qua, loi). ket qua: duong goi (xuat) / duong jsonl ('' = khong co phieu moi) (nap); tom tat ghi <ra>.txt / <goi>.txt"""
    a = _tham_so(argv)
    che_do = (a.get("congkhach") or "").lower()
    try:
        if che_do == "xuat":
            duong, tom = xuat(a.get("mdb", ""), re.sub(r"\D", "", a.get("mst", "")), a.get("ten", ""), a.get("ngaychot", ""), a.get("ra", ""),
                              a.get("khach", ""), a.get("matkhau", ""), ghi_log)
            with io.open(duong + ".txt", "w", encoding="utf-8") as f:
                f.write(tom)
            return duong, ""
        if che_do == "nap":
            duong, tom, n_moi, n_trung = nap(a.get("tep", ""), re.sub(r"\D", "", a.get("mst", "")), a.get("ten", ""), a.get("khach", ""), a.get("ra", ""), ghi_log)
            with io.open(a.get("ra", "") + ".txt", "w", encoding="utf-8") as f:
                f.write(tom)
            return duong or "KHONG_CO_PHIEU_MOI", ""
        if che_do == "tralai":
            tra_lai(a.get("khach", ""), a.get("sophieu", ""), a.get("lydo", ""))
            return "OK", ""
        return "", "Thiếu /congkhach:xuat|nap|tralai"
    except ValueError as e:
        return "", str(e)
    except Exception as e:
        import traceback
        ghi_log("[CONG KHACH] loi: %s\n%s" % (e, traceback.format_exc()))
        return "", "Lỗi công cụ khách: %s" % e


if __name__ == "__main__":
    kq, loi = chay_cli(sys.argv[1:])
    print(kq if kq else "LOI " + loi)
    sys.exit(0 if kq else 1)
