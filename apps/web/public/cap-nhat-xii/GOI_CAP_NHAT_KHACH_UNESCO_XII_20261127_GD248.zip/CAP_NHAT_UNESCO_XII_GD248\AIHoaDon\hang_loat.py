# -*- coding: utf-8 -*-
"""GD158 (lo trinh A2) - CHAY HANG LOAT NHIEU BO SO (QUA DEM) + BANG TONG HOP SANG. CHI DOC .MDB (jet_doc, mo 'rb').

  python hang_loat.py /chay:"<cau_hinh.json>"          (Task Scheduler hoac menu Du lieu > Chay hang loat ... > Chay ngay)
  python hang_loat.py /mot:"<so.MDB>" /ra:"<kq.json>" /homnay:dd/mm/yyyy     (tien trinh con - moi bo so mot tien trinh)

cau_hinh.json (VB6 ModHangLoat ghi): {"thu_muc": [..], "sau": 3, "tep": [..] (tuy chon), "ra": "<AIHoaDon>\\hang-loat",
                                      "phut_moi_so": 20, "bo_nam_cu": true}
Moi bo so: chi so Bang dieu hanh GD154 (chung tu, hoa don dien tu, so phu, thang khoa, diem san sang, soat rui ro, to khai, han) +
bat thuong so lieu KS8 - KS12 GD157 (du lieu dung truc tiep tu .MDB, nguong + danh dau "Khong phai loi" cua chinh bo so).
KHONG dang nhap / tai hoa don thay nguoi dung (quy tac 17) - tai hoa don van theo hen gio rieng cua tung so; bang tong hop bao ngay tai gan nhat.
Khong ghi gi vao .MDB. Nhat ky chi ghi so thu tu + so dem (khong ten khach / MST).
Ra: <ra>\\<yyyymmdd_hhnn>\\TongHop_Sang.xlsx + .html + tong_hop.txt + so_NNN.json ; <ra>\\moi_nhat.txt (duong lan chay + dong TONG).
"""
import datetime as _dt
import html
import io
import json
import os
import subprocess
import sys
import time
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

DO, VANG, XANH = "DO", "VANG", "XANH"
TEN_MUC = {DO: "ĐỎ", VANG: "VÀNG", XANH: "XANH"}
THU_TU = {DO: 0, VANG: 1, XANH: 2}
KHOA_THEM_PHUT = 10                      # tep khoa khong duoc lam moi qua (phut moi so + 10) phut -> coi nhu luot truoc bi ngat
TOP_BT = 40                              # so dong bat thuong giu moi bo so


def _so(x):
    try:
        return float(x or 0)
    except (TypeError, ValueError):
        try:
            return float(str(x).replace(",", "."))
        except (TypeError, ValueError):
            return 0.0


def _ngay(x):
    import bang_dieu_hanh as DH
    return DH._ngay(x)


def vn(d):
    return d.strftime("%d/%m/%Y") if d else ""


def _s(x, n=300):
    return str(x if x is not None else "").replace("\t", " ").replace("\r", " ").replace("\n", " ")[:n]


# ============================================================ du lieu bat thuong tu .MDB
def chu_u(s, font):
    """chuoi font cu (VNI / TCVN3) -> Unicode (nhu bang_dieu_hanh.ten_cty)."""
    if isinstance(s, bytes):
        s = s.decode("cp1252", "replace")
    s = str(s or "").strip()
    if not s:
        return ""
    try:
        import bang_luong_gd78 as B
        f = str(font or "").upper()
        if f.startswith("VNI"):
            return B.vni_sang_u(s)
        if f.startswith(".VN") or f.startswith("VN"):
            return B.tcvn3_sang_u(s)
        loai = B.loai_ma([s])
        if loai == "VNI":
            return B.vni_sang_u(s)
        if loai == "TCVN3":
            return B.tcvn3_sang_u(s)
    except Exception:
        pass
    return s


def _thap(r):
    return {str(k).lower(): v for k, v in r.items()}


def ky_tai_chinh(nam, dau_ky, hom_nay):
    """-> (ngay dau nam TC, ngay tinh (<= cuoi nam TC), thu tu thang cuoi t2)"""
    bd = _dt.date(nam, dau_ky, 1)
    y2, m2 = (nam + 1, dau_ky) if dau_ky > 1 else (nam + 1, 1)
    kt = _dt.date(y2, m2, 1) - _dt.timedelta(days=1)
    d = min(max(hom_nay, bd), kt)
    t2 = (d.month - dau_ky) % 12 + 1
    return bd, d, t2


def dl_tu_mdb(duong, hom_nay):
    """Lap JSON dau vao bat_thuong.py tu .MDB (cung cot nhu ModBatThuong.BT157_Json). -> (dl, bo_qua set)."""
    import jet_doc
    m = jet_doc.Mdb(duong)
    try:
        bang = {k.lower(): k for k in m.bang()}

        def doc(t, n=None):
            k = bang.get(t.lower())
            return [_thap(r) for r in m.doc(k, n)] if k else []
        lic = (doc("License", 1) or [{}])[0]
        font = lic.get("fontname")
        dau_ky = int(_so(lic.get("thang"))) or 1
        if not 1 <= dau_ky <= 12:
            dau_ky = 1
        nam = int(_so(lic.get("namtc"))) or hom_nay.year
        bd, den, t2 = ky_tai_chinh(nam, dau_ky, hom_nay)
        thang_lich = set(((dau_ky - 1 + t - 1) % 12) + 1 for t in range(1, t2 + 1))
        tk = []
        for r in doc("HethongTK"):
            tk.append([int(_so(r.get("maso"))), str(r.get("sohieu") or "").strip(), 1 if r.get("tkcon") else 0, int(_so(r.get("tkcha0"))),
                       chu_u(r.get("ten"), font)[:80], _so(r.get("duno_0")), _so(r.get("duco_0")), int(_so(r.get("tk_id")))])
        ct, theo_ms = [], {}
        for r in doc("ChungTu"):
            th = int(_so(r.get("thangct")))
            no, co = int(_so(r.get("matkno"))), int(_so(r.get("matkco")))
            ps, s2n, s2c, loai = _so(r.get("sops")), _so(r.get("sops2no")), _so(r.get("sops2co")), int(_so(r.get("maloai")))
            if th not in thang_lich or not (no > 0 or co > 0) or (loai == 4 and no == co) or not (ps or s2n or s2c):
                continue
            ms, mact = int(_so(r.get("maso"))), int(_so(r.get("mact")))
            ng = vn(_ngay(r.get("ngayct")))
            ct.append([ms, mact, loai, th, str(r.get("sohieu") or "").strip(), ng, vn(_ngay(r.get("ngaygs"))) or ng, "", no, co, ps,
                       int(_so(r.get("makh"))), int(_so(r.get("makhc"))), int(_so(r.get("mavattu"))), int(_so(r.get("makho"))), s2n, s2c,
                       int(_so(r.get("manguon"))), ""])
            theo_ms[ms] = (mact, ng, no, co)
        dt = [[int(_so(r.get("maso"))), str(r.get("sohieu") or "").strip(), chu_u(r.get("ten"), font)[:120], str(r.get("mst") or "").strip()]
              for r in doc("KhachHang")]
        vt = [[int(_so(r.get("maso"))), str(r.get("sohieu") or "").strip(), chu_u(r.get("tenvattu"), font)[:120], chu_u(r.get("donvi"), font)[:20], ""]
              for r in doc("Vattu")]
        hd = []
        for r in doc("HoaDon"):
            x = theo_ms.get(int(_so(r.get("maso"))))
            if x:
                hd.append([x[0], x[1], int(_so(r.get("makhachhang"))), str(r.get("kyhieu") or "").strip()[:20], str(r.get("sohd") or "").strip()[:20],
                           vn(_ngay(r.get("ngayph"))), _so(r.get("thanhtien")), x[2], x[3]])
        khoa = [t for t in range(1, 13) if int(_so(lic.get("lock%d" % t))) % 10 != 0]
        nv = [[int(_so(r.get("maso"))), str(r.get("sohieu") or "").strip(), chu_u(r.get("ten"), font)[:80]] for r in doc("QuanLyNhanVien")]
        bl = []
        for r in doc("BangLuong"):
            th = int(_so(r.get("thang")))
            if th in thang_lich:
                bl.append([int(_so(r.get("manv"))), th, int(_so(r.get("loainv"))), _so(r.get("ngaycong")), _so(r.get("luongcoban")), _so(r.get("luongchinh")),
                           _so(r.get("thunhapkhac")), _so(r.get("tongthunhap")), _so(r.get("bhxh"))] + [0] * 13)
        ts = {}
        for r in doc("HDDT_ThamSo"):
            v = r.get("giatri")
            ts[str(r.get("khoa") or "")] = v.decode("utf-16-le", "replace") if isinstance(v, bytes) else str(v or "")
        bo_qua = set(str(r.get("khoa") or "") for r in doc("HDDT_KS_BoQua"))
    finally:
        m.dong()
    dl = {"loai": "BC", "thang_dau_ky": dau_ky, "nam_tc": nam, "thang": [1, t2], "ky": {"tu": vn(bd), "den": vn(den)}, "tk": tk, "ps": [],
          "doi_ung": [], "kh_dau": [], "cn_ct": [], "dt": dt,
          "ss": {"phien_ban": 1, "t1": 1, "t2": t2, "ct": ct, "vt": vt, "kho": [], "tonkho": [], "ck4": [], "nv": nv, "bl": bl, "canh_bao": []},
          "hd": hd, "khoa": khoa,
          "bt157": {"x": _so(ts.get("BT157_X")) or 50, "y": _so(ts.get("BT157_Y")) or 30, "tien_min": _so(ts.get("BT157_TienMin")) or 5000000,
                    "vung": int(_so(ts.get("BT157_Vung"))), "db": duong, "hom_nay": vn(den)}}
    return dl, bo_qua


# ============================================================ mot bo so (tien trinh con)
def _json_an_toan(x):
    if isinstance(x, (_dt.date, _dt.datetime)):
        return vn(x)
    if isinstance(x, set):
        return sorted(x)
    return str(x)


def _khoa_chu(x):
    """dict / list long nhau: khoa khong phai chuoi (tuple ky to khai...) -> chuoi, de json.dumps khong loi."""
    if isinstance(x, dict):
        return {(k if isinstance(k, str) else " ".join(str(y) for y in k) if isinstance(k, tuple) else str(k)): _khoa_chu(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [_khoa_chu(v) for v in x]
    return x


def mot_so(duong, hom_nay, bo_cu=False):
    import bang_dieu_hanh as DH
    import bat_thuong as BT
    kq = {"duong": duong, "tep": os.path.basename(duong), "loi": "", "dh": None, "bt": None}
    bang = DH.doc_bang(duong)
    if bang is None:
        kq["loi"] = "không phải bộ sổ UNESCO (thiếu bảng License / ChungTu / HethongTK)"
        return kq
    r = dict(DH.tinh(bang, hom_nay, DH.doc_ngay_nghi()))
    r.pop("ct_theo_thang", None)
    r["ky"] = DH.ky_chu(r.get("ky")) if r.get("ky") else ""
    r["han_gan_chu"] = (vn(r.get("han_gan")) + ((" " + r["han_ten"]) if r.get("han_ten") else "")) if r.get("han_gan") else ""
    r["han_gan_iso"] = r["han_gan"].strftime("%Y-%m-%d") if r.get("han_gan") else ""
    r["da_nop"] = sorted(" ".join(str(y) for y in k) if isinstance(k, tuple) else str(k) for k in (r.get("da_nop") or {}))
    kq["dh"] = r
    if bo_cu and r.get("nam_qua"):
        return kq                                # nam tai chinh da qua: khong phan tich bat thuong (cha bo qua)
    try:
        dl, bo_qua = dl_tu_mdb(duong, hom_nay)
        B = BT.BatThuong(dl, _ngay(dl["bt157"]["hom_nay"]))
        dong = [x for x in B.chay() if x["khoa"] not in bo_qua]
        dem = {BT.MUC_CAO: 0, BT.MUC_VUA: 0, BT.MUC_THAP: 0}
        for x in dong:
            dem[x["muc"]] = dem.get(x["muc"], 0) + 1
        kq["bt"] = {"n": len(dong), "cao": dem[BT.MUC_CAO], "vua": dem[BT.MUC_VUA], "thap": dem[BT.MUC_THAP], "bo_qua": len(bo_qua),
                    "dong": [{"ks": BT.MA_KS[x["loai"]], "loai": x["loai"], "muc": x["muc"], "ma": x["ma"], "mo_ta": x["mo_ta"], "so_lieu": x["so_lieu"]}
                             for x in dong[:TOP_BT]]}
    except Exception as e:
        kq["loi"] = "phát hiện bất thường lỗi: %s" % type(e).__name__
    return kq


def chay_mot(duong, ra, hom_nay, bo_cu=False):
    try:
        kq = mot_so(duong, hom_nay, bo_cu)
    except Exception as e:
        kq = {"duong": duong, "tep": os.path.basename(duong), "loi": "không đọc được: %s" % type(e).__name__, "dh": None, "bt": None}
    try:
        s = json.dumps(_khoa_chu(kq), ensure_ascii=False, default=_json_an_toan)
    except Exception as e:
        s = json.dumps({"duong": duong, "tep": os.path.basename(duong), "loi": "không ghi được kết quả: %s" % type(e).__name__, "dh": None, "bt": None},
                       ensure_ascii=False)
    with io.open(ra, "w", encoding="utf-8", errors="replace") as f:     # du lieu so co ky tu hong (emoji tach doi) khong lam rong tep
        f.write(s)
    return kq


# ============================================================ dieu phoi
def _ghi_log(tep, s):
    try:
        with io.open(tep, "a", encoding="utf-8") as f:
            f.write("%s %s\n" % (_dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), s))
    except Exception:
        pass


def muc_chung(kq):
    dh, bt = kq.get("dh") or {}, kq.get("bt") or {}
    m = dh.get("muc") or (DO if kq.get("loi") else XANH)
    if bt.get("cao"):
        m = DO
    elif bt.get("vua") and m == XANH:
        m = VANG
    if kq.get("loi") and m == XANH:
        m = VANG
    return m


def viec_can_lam(kq):
    dh, bt = kq.get("dh") or {}, kq.get("bt") or {}
    v = [str(x) for x in (dh.get("ghi_chu") or [])]
    if bt.get("cao") or bt.get("vua"):
        v.append("%d bất thường số liệu mức Cao, %d mức Vừa (Kiểm soát > thẻ Bất thường số liệu)" % (bt.get("cao") or 0, bt.get("vua") or 0))
    if kq.get("loi"):
        v.append("Lỗi chạy: " + kq["loi"])
    return v


def chay(duong_cfg):
    with io.open(duong_cfg, "r", encoding="utf-8-sig") as f:
        cfg = json.loads(f.read(), strict=False)
    import bang_dieu_hanh as DH
    hom_nay = _ngay(cfg.get("hom_nay")) or _dt.date.today()
    goc = cfg.get("ra") or os.path.join(HERE, "hang-loat")
    os.makedirs(goc, exist_ok=True)
    phut = max(2, int(_so(cfg.get("phut_moi_so")) or 20))
    khoa = os.path.join(goc, "dang_chay.lock")
    if os.path.exists(khoa) and time.time() - os.path.getmtime(khoa) >= (phut + KHOA_THEM_PHUT) * 60:
        try:
            os.remove(khoa)                      # luot truoc bi ngat (khoa khong duoc lam moi)
        except Exception:
            pass
    try:
        fd = os.open(khoa, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except OSError:
        return None, "Đang có một lượt chạy hàng loạt khác"
    os.write(fd, _dt.datetime.now().isoformat().encode("ascii"))
    os.close(fd)
    try:
        lan = os.path.join(goc, _dt.datetime.now().strftime("%Y%m%d_%H%M"))
        os.makedirs(lan, exist_ok=True)
        log = os.path.join(lan, "nhat_ky.txt")
        tep = []
        thay = set()
        for p in list(cfg.get("tep") or []) + DH.quet(cfg.get("thu_muc") or [], int(_so(cfg.get("sau")) or 3)):
            k = os.path.normcase(os.path.abspath(p))
            if k not in thay and os.path.isfile(p):
                thay.add(k)
                tep.append(p)
        _ghi_log(log, "bat dau: %d bo so" % len(tep))
        co_an = 0x08000000 if os.name == "nt" else 0
        ket = []
        bo_cu = 0
        bo_cu_cfg = bool(cfg.get("bo_nam_cu", True))
        for i, p in enumerate(tep, 1):
            ra = os.path.join(lan, "so_%03d.json" % i)
            t0 = time.time()
            try:
                os.utime(khoa, None)                 # lam moi khoa (luot dai van giu khoa)
            except Exception:
                pass
            try:
                subprocess.run([sys.executable, os.path.abspath(__file__), "/mot:" + p, "/ra:" + ra, "/homnay:" + vn(hom_nay)] + (["/bocu:1"] if bo_cu_cfg else []),
                               timeout=phut * 60, cwd=HERE, creationflags=co_an, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                with io.open(ra, "r", encoding="utf-8") as f:
                    kq = json.loads(f.read())
            except subprocess.TimeoutExpired:
                kq = {"duong": p, "tep": os.path.basename(p), "loi": "quá %d phút - dừng" % phut, "dh": None, "bt": None}
            except Exception as e:
                kq = {"duong": p, "tep": os.path.basename(p), "loi": "không chạy được: %s" % type(e).__name__, "dh": None, "bt": None}
            dh = kq.get("dh") or {}
            if bo_cu_cfg and dh.get("nam_qua"):
                bo_cu += 1
                _ghi_log(log, "so %03d: nam cu - bo qua (%.1f giay)" % (i, time.time() - t0))
                continue
            kq["stt"] = i
            kq["muc_chung"] = muc_chung(kq)
            kq["viec"] = viec_can_lam(kq)
            ket.append(kq)
            _ghi_log(log, "so %03d: %s, bat thuong %s, %s (%.1f giay)" % (i, kq["muc_chung"], (kq.get("bt") or {}).get("n", "-"),
                                                                       "loi" if kq.get("loi") else "ok", time.time() - t0))
        ket.sort(key=lambda k: (THU_TU[k["muc_chung"]], str((k.get("dh") or {}).get("han_gan_iso") or "9999"), str((k.get("dh") or {}).get("ten") or k["tep"]).lower()))
        tong = tong_hop(ket, lan, hom_nay, len(tep), bo_cu)
        with io.open(os.path.join(goc, "moi_nhat.txt"), "w", encoding="utf-8", newline="") as f:
            f.write(lan + "\r\n" + tong + "\r\n")
        _ghi_log(log, "xong: " + tong.split("\t")[1])
        return os.path.join(lan, "TongHop_Sang.html"), ""
    finally:
        try:
            os.remove(khoa)
        except Exception:
            pass


# ============================================================ bang tong hop sang
def _dong_tong(kq):
    dh, bt = kq.get("dh") or {}, kq.get("bt") or {}
    ky = dh.get("ky") or ""
    return [kq.get("stt"), dh.get("ten") or kq["tep"], dh.get("mst") or "", kq["tep"], dh.get("nam") or "", TEN_MUC[kq["muc_chung"]],
            dh.get("ct_ngay") or "", dh.get("hddt_den") or "", dh.get("hddt_chua") or 0, dh.get("sp_den") or "", dh.get("sp_chua") or 0,
            ", ".join(str(x) for x in (dh.get("khoa") or [])), ("%s%s" % (ky, " (đã nộp)" if dh.get("gtgt_nop") else "")) if ky else "",
            dh.get("han_gan_chu") or "", bt.get("cao", "") if bt else "", bt.get("vua", "") if bt else "", bt.get("thap", "") if bt else "",
            "; ".join(kq.get("viec") or [])]


COT = ["STT", "Bộ sổ", "MST", "Tệp", "Năm TC", "Mức", "Chứng từ đến", "HĐĐT tải đến", "HĐĐT chưa HT", "Sổ phụ đến", "Sổ phụ chưa HT",
       "Tháng đã khoá", "Kỳ GTGT gần nhất", "Hạn gần nhất", "BT Cao", "BT Vừa", "BT Thấp", "Việc cần làm"]


def tong_hop(ket, lan, hom_nay, n_tep, bo_cu):
    luc = _dt.datetime.now().strftime("%d/%m/%Y %H:%M")
    n = {DO: 0, VANG: 0, XANH: 0}
    for k in ket:
        n[k["muc_chung"]] += 1
    ra_x = os.path.join(lan, "TongHop_Sang.xlsx")
    ra_h = os.path.join(lan, "TongHop_Sang.html")
    try:
        _excel(ket, ra_x, luc, n_tep, bo_cu)
    except Exception:
        _ghi_log(os.path.join(lan, "nhat_ky.txt"), "loi lap Excel: " + traceback.format_exc().splitlines()[-1][:200])
        ra_x = ""
    _html(ket, ra_h, luc, n, n_tep, bo_cu)
    tong = "TONG\t%d\t%d\t%d\t%d\t%s\t%s\t%s\t%d\t%d" % (len(ket), n[DO], n[VANG], n[XANH], ra_h, ra_x, luc, n_tep, bo_cu)
    dong = [tong]
    for k in ket:
        dong.append("B\t%s\t%s\t%s\t%s" % (k["muc_chung"], _s(k["duong"]), _s((k.get("dh") or {}).get("ten") or k["tep"], 120), _s("; ".join(k["viec"]), 600)))
    with io.open(os.path.join(lan, "tong_hop.txt"), "w", encoding="utf-8", newline="") as f:
        f.write("\r\n".join(dong) + "\r\n")
    return tong


def _excel(ket, ra, luc, n_tep, bo_cu):
    from xlsx_viet import SoExcel
    wb = SoExcel(font="Times New Roman", co=11)
    k_td = wb.kieu(dam=True, co=14, can="giua", mau="0B3D91")
    k_ghi = wb.kieu(nghieng=True, mau="555555", xuong=True, doc="tren")
    k_dau = wb.kieu(dam=True, nen="D9E1F2", khung=True, can="giua", xuong=True)
    k_o = wb.kieu(khung=True, xuong=True, doc="tren")
    k_mau = {DO: wb.kieu(khung=True, dam=True, nen="F8CBAD", can="giua"), VANG: wb.kieu(khung=True, dam=True, nen="FFE699", can="giua"),
             XANH: wb.kieu(khung=True, dam=True, nen="C6EFCE", can="giua")}
    ws = wb.sheet("TongHop", cot=[5, 30, 13, 22, 7, 8, 11, 11, 9, 11, 9, 12, 14, 12, 7, 7, 7, 70])
    ws.gop(1, 1, 1, len(COT), "BẢNG TỔNG HỢP SÁNG - CHẠY HÀNG LOẠT CÁC BỘ SỔ", k_td)
    ws.gop(2, 1, 2, len(COT), "Lập lúc %s. %d bộ sổ được phân tích (bỏ qua %d bộ sổ năm tài chính đã qua). Chỉ đọc sổ - không sửa số liệu, không đăng nhập / "
                              "tải hoá đơn thay người dùng (hoá đơn tải theo hẹn giờ riêng từng sổ)." % (luc, len(ket), bo_cu), k_ghi)
    ws.cao(2, 32)
    ws.dong(4, 1, COT, k_dau)
    r = 4
    for k in ket:
        r += 1
        v = _dong_tong(k)
        ws.dong(r, 1, v, k_o)
        ws.o(r, 6, v[5], k_mau[k["muc_chung"]])
    if not ket:
        ws.gop(5, 1, 5, len(COT), "Không có bộ sổ nào trong các thư mục đã chọn.", k_ghi)
    ws.dong_bang(5, 3)
    ws.in_trang(ngang=True, vua_rong=True, lap_dong=(4, 4))
    w2 = wb.sheet("ViecCanLam", cot=[5, 30, 8, 90])
    w2.gop(1, 1, 1, 4, "VIỆC CẦN NGƯỜI LÀM", k_td)
    w2.dong(3, 1, ["STT", "Bộ sổ", "Mức", "Việc"], k_dau)
    r = 3
    for k in ket:
        for v in k.get("viec") or []:
            r += 1
            w2.dong(r, 1, [k.get("stt"), (k.get("dh") or {}).get("ten") or k["tep"], TEN_MUC[k["muc_chung"]], v], k_o)
    if r == 3:
        w2.gop(4, 1, 4, 4, "Không có việc tồn.", k_ghi)
    w2.dong_bang(4, 3)
    w3 = wb.sheet("BatThuong", cot=[5, 28, 6, 7, 14, 70, 60])
    w3.gop(1, 1, 1, 7, "BẤT THƯỜNG SỐ LIỆU (KS8 - KS12) - TỐI ĐA %d DÒNG MỖI BỘ SỔ" % TOP_BT, k_td)
    w3.dong(3, 1, ["STT", "Bộ sổ", "KS", "Mức", "Mã", "Vấn đề", "Số liệu"], k_dau)
    r = 3
    for k in ket:
        for x in (k.get("bt") or {}).get("dong") or []:
            r += 1
            w3.dong(r, 1, [k.get("stt"), (k.get("dh") or {}).get("ten") or k["tep"], x["ks"], x["muc"], x["ma"], x["mo_ta"], x["so_lieu"]], k_o)
    if r == 3:
        w3.gop(4, 1, 4, 7, "Không phát hiện bất thường.", k_ghi)
    w3.dong_bang(4, 3)
    wb.luu(ra)
    return ra


def _html(ket, ra, luc, n, n_tep, bo_cu):
    mau = {DO: "#f8cbad", VANG: "#ffe699", XANH: "#c6efce"}
    h = ["<!doctype html><html lang='vi'><head><meta charset='utf-8'><title>Bảng tổng hợp sáng</title>",
         "<style>body{font-family:Segoe UI,Arial,sans-serif;margin:16px;color:#1f2937}h1{font-size:20px;color:#0b3d91}"
         "table{border-collapse:collapse;width:100%;font-size:13px}th,td{border:1px solid #cbd5e1;padding:4px 6px;vertical-align:top}"
         "th{background:#d9e1f2}.m{font-weight:bold;text-align:center}.g{color:#555;font-style:italic}ul{margin:0;padding-left:18px}</style></head><body>",
         "<h1>BẢNG TỔNG HỢP SÁNG - CHẠY HÀNG LOẠT CÁC BỘ SỔ</h1>",
         "<p class='g'>Lập lúc %s. %d bộ sổ: %d đỏ, %d vàng, %d xanh (bỏ qua %d bộ sổ năm cũ). Chỉ đọc sổ; không đăng nhập / tải hoá đơn thay người dùng.</p>"
         % (html.escape(luc), len(ket), n[DO], n[VANG], n[XANH], bo_cu),
         "<table><tr><th>STT</th><th>Bộ sổ</th><th>Mức</th><th>Chứng từ đến</th><th>HĐĐT chưa HT</th><th>Sổ phụ chưa HT</th><th>Hạn gần nhất</th>"
         "<th>Bất thường (Cao / Vừa / Thấp)</th><th>Việc cần làm</th></tr>"]
    for k in ket:
        dh, bt = k.get("dh") or {}, k.get("bt") or {}
        h.append("<tr><td>%s</td><td>%s<br><span class='g'>%s</span></td><td class='m' style='background:%s'>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td>"
                 "<td>%s</td><td><ul>%s</ul></td></tr>" % (
                     k.get("stt"), html.escape(str(dh.get("ten") or k["tep"])), html.escape(k["tep"]), mau[k["muc_chung"]], TEN_MUC[k["muc_chung"]],
                     html.escape(str(dh.get("ct_ngay") or "")), dh.get("hddt_chua") or 0, dh.get("sp_chua") or 0,
                     html.escape(str(dh.get("han_gan_chu") or "")),
                     ("%s / %s / %s" % (bt.get("cao", 0), bt.get("vua", 0), bt.get("thap", 0))) if bt else "-",
                     "".join("<li>%s</li>" % html.escape(v) for v in (k.get("viec") or []))))
    if not ket:
        h.append("<tr><td colspan='9' class='g'>Không có bộ sổ nào trong các thư mục đã chọn.</td></tr>")
    h.append("</table></body></html>")
    with io.open(ra, "w", encoding="utf-8") as f:
        f.write("\n".join(h))
    return ra


def _mo_rong(argv):
    """/thamso:"<tep UTF-8>" (VB6 HDDT_ThamSoTep - duong dan Unicode) -> danh sach tham so."""
    import re
    ra = []
    for a in argv:
        if a.lower().startswith("/thamso:"):
            try:
                with io.open(a[8:].strip('"'), "r", encoding="utf-8-sig") as f:
                    ra.extend(re.findall(r'(?:[^\s"]|"[^"]*")+', f.read()))
            except Exception:
                pass
        else:
            ra.append(a)
    return ra


def _ts(argv):
    ts = {}
    for a in _mo_rong(argv):
        for k in ("chay", "mot", "ra", "homnay", "bocu"):
            if a.lower().startswith("/" + k + ":"):
                ts[k] = a[len(k) + 2:].strip('"')
    return ts


if __name__ == "__main__":
    t = _ts(sys.argv[1:])
    if t.get("mot"):
        chay_mot(t["mot"], t.get("ra") or os.path.join(HERE, "ket-qua", "hang_loat_mot.json"), _ngay(t.get("homnay")) or _dt.date.today(), t.get("bocu") == "1")
    elif t.get("chay"):
        print(chay(t["chay"]))
