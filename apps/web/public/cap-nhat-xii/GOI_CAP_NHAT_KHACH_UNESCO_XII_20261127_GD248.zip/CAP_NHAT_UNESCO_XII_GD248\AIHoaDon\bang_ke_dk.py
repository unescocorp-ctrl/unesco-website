# -*- coding: utf-8 -*-
"""GD106 - BANG KE DINH KHOAN AI tren man hinh tai hoa don (tool_tai_hoa_don_unesco.py).

Phan mem UNESCO (AI da phan tich hoa don trong HDDTTaiVe) ghi <thu muc khach>\\dinh-khoan-ai.jsonl khi tool hoi
(ket-qua\\yc_dinhkhoan_<id>.jsonl). Tool hien bang ke dinh khoan TRUOC KHI lap chung tu, ke toan sua TK / tinh chat /
thanh toan -> ket-qua\\dinhkhoan_<MST>_<ts>.jsonl -> phan mem ap dung (HDDT_HD_SuaDongTen, AI ghi nho), phan tich lai,
ghi lai bang ke. Tep nay chi DOC / GHI tep trao doi va xuat Excel; khong ghi so ke toan (quy tac 11).
Chi dung thu vien chuan.
"""
import json
import os
import re
import time
from datetime import datetime

TEP_BANG_KE = "dinh-khoan-ai.jsonl"

TEN_TT = {
    "MOI": "Chưa phân tích", "THIEU_MA": "Thiếu mã", "SAN_SANG": "Sẵn sàng lập CT", "LOI": "Không xử lý / lỗi",
    "CAN_XEM_LAI": "Cần xem lại", "BO_QUA": "Bỏ qua", "DA_HACH_TOAN": "Đã hạch toán",
}
TEN_TC = {
    "HH": "Hàng hoá", "NVL": "Nguyên vật liệu", "CCDC": "Công cụ dụng cụ", "DV": "Dịch vụ / chi phí",
    "TP": "Thành phẩm", "TSCD": "Tài sản cố định", "CK": "Chiết khấu", "KM": "Khuyến mại",
}
TEN_NGUON = {
    "NGUOI": "Kế toán đã sửa", "DA_HOC": "Đã học", "DA_HOC_TK": "Đã học TK", "TU_KHOA": "Từ khoá",
    "TU_KHOA_TK": "Từ khoá TK", "MA_HD": "Mã trên HĐ", "MA_HD_HOC": "Mã trên HĐ (đã học)", "MA_NCC": "Mã NCC",
    "TEN_TUYET_DOI": "Trùng tên", "CHI_PHI_AI": "AI: chi phí", "CHI_PHI_DA_HOC": "Chi phí (đã học)",
    "SUY_RA": "Suy ra từ NCC", "TUONG_TU": "Tên tương tự",
}
TC_MUA = ("HH", "NVL", "CCDC", "DV", "TSCD")
TC_BAN = ("HH", "TP", "DV")
LOAI_HD = ("CP", "NVL", "HH", "")
_CAM_MUA = ("111", "112", "113", "131", "133", "331", "333", "511")


def _so(v):
    try:
        return float(v or 0)
    except Exception:
        return 0.0


def ngay_iso(s):
    """'dd/mm/yyyy' / 'yyyy-mm-dd' -> 'yyyy-mm-dd' ('' neu sai)."""
    s = str(s or "").strip()
    m = re.match(r"^(\d{4})-(\d{1,2})-(\d{1,2})", s)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
    else:
        m = re.match(r"^(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})$", s)
        if not m:
            return ""
        d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
    try:
        return datetime(y, mo, d).strftime("%Y-%m-%d")
    except ValueError:
        return ""


def khoa_chuan(k):
    """Khoa hoa don 'MST|mau|ky hieu|so' -> so bo 0 dau (nhu unesco_so_hd / HDDT_ChuanKhoa)."""
    a = str(k or "").strip().split("|")
    if len(a) < 4:
        return str(k or "").strip()
    so = a[3].strip()
    m = re.search(r"(\d+)$", so)
    if so.isdigit():
        so = so.lstrip("0") or "0"
    elif m and re.match(r"^[A-Z0-9/]+-0*\d+$", so, re.I):
        so = m.group(1).lstrip("0") or "0"
    return "|".join([a[0].strip(), a[1].strip(), a[2].strip(), so] + a[4:])


def _ghi_nguyen_tu(duong, noi_dung):
    with open(duong + ".tmp", "w", encoding="utf-8", newline="\n") as f:
        f.write(noi_dung)
    os.replace(duong + ".tmp", duong)       # doi ten sau khi ghi xong -> phan mem khong doc tep dang ghi do


def ma_moi():
    return datetime.now().strftime("%Y%m%d%H%M%S%f")[:17]


def ghi_yeu_cau(thu_muc_kq, huong, tu, den, ma=None):
    """Ghi ket-qua\\yc_dinhkhoan_<id>.jsonl. Tra ve id."""
    tu_i, den_i = ngay_iso(tu), ngay_iso(den)
    if not tu_i or not den_i:
        raise ValueError("Khoảng ngày không hợp lệ.")
    if den_i < tu_i:
        tu_i, den_i = den_i, tu_i
    ma = ma or ma_moi()
    os.makedirs(thu_muc_kq, exist_ok=True)
    nd = json.dumps({"id": ma, "huong": "ban" if huong == "ban" else "mua", "tu": tu_i, "den": den_i}, ensure_ascii=False)
    _ghi_nguyen_tu(os.path.join(thu_muc_kq, "yc_dinhkhoan_%s.jsonl" % ma), nd + "\n")
    return ma


def kiem_muc_sua(m, huong):
    """Mot muc sua -> (muc da chuan hoa, loi). loi '' = hop le."""
    if not isinstance(m, dict):
        return None, "Mục sửa không hợp lệ."
    k = str(m.get("khoa") or "").strip()
    if k.count("|") < 3:
        return None, "Thiếu khoá hoá đơn."
    if "loai" in m:
        loai = str(m.get("loai") or "").upper()
        if huong == "ban":
            return None, "Đánh dấu Chi phí / NVL / Hàng hoá chỉ cho hoá đơn mua vào."
        if loai not in LOAI_HD:
            return None, "Loại hoá đơn không hợp lệ: " + loai
        return {"khoa": k, "loai": loai}, ""
    if "tt" in m:
        tt = str(m.get("tt") or "").upper()
        if tt not in ("TM", "CN", ""):
            return None, "Thanh toán không hợp lệ: " + tt
        return {"khoa": k, "tt": tt}, ""
    try:
        ms = int(m.get("ms") or 0)
    except (TypeError, ValueError):
        ms = 0
    if ms <= 0:
        return None, "Thiếu mã dòng hàng."
    tk = str(m.get("tk") or "").strip()
    tc = str(m.get("tc") or "").strip().upper()
    if not tk and not tc:
        return None, "Chưa đổi TK hoặc tính chất."
    if tk and not re.match(r"^[0-9A-Za-z]{3,20}$", tk):
        return None, "Số hiệu TK không hợp lệ: " + tk
    if tk and huong == "ban" and not (tk[:2] in ("51", "52") or tk[:3] == "711"):
        return None, "Bán ra: TK %s không phải TK doanh thu (51x, 52x, 711)." % tk
    if tk and huong != "ban" and tk[:3] in _CAM_MUA:
        return None, "Mua vào: TK %s không dùng cho dòng hàng (tiền, công nợ, thuế, doanh thu)." % tk
    if tc and tc not in (TC_BAN if huong == "ban" else TC_MUA):
        return None, "Tính chất không hợp lệ: " + tc
    r = {"khoa": k, "ms": ms}
    if tk:
        r["tk"] = tk
    if tc:
        r["tc"] = tc
    return r, ""


def ghi_sua(thu_muc_kq, mst, huong, tu, den, cac_muc, ma=None):
    """Ghi ket-qua\\dinhkhoan_<MST>_<ts>.jsonl (dong dau id_sua + khoang ngay). Tra ve (id_sua, so muc, [loi])."""
    huong = "ban" if huong == "ban" else "mua"
    tot, loi = [], []
    for m in cac_muc or []:
        r, e = kiem_muc_sua(m, huong)
        if e:
            loi.append(e)
        else:
            tot.append(r)
    if not tot:
        return "", 0, loi or ["Không có mục sửa nào."]
    # thu tu: danh dau ca hoa don truoc, roi dong hang, cuoi cung thanh toan (phan tich lai khong de thanh toan)
    tot.sort(key=lambda r: 0 if "loai" in r else (2 if "tt" in r else 1))
    ma = ma or ma_moi()
    dau = {"id_sua": ma, "huong": huong, "tu": ngay_iso(tu), "den": ngay_iso(den)}
    nd = "\n".join(json.dumps(x, ensure_ascii=False) for x in [dau] + tot) + "\n"
    os.makedirs(thu_muc_kq, exist_ok=True)
    _ghi_nguyen_tu(os.path.join(thu_muc_kq, "dinhkhoan_%s_%s.jsonl" % (re.sub(r"\W", "", mst or "") or "CHUNG", ma)), nd)
    return ma, len(tot), loi


def doc_dau(duong):
    """Chi doc dong dau (re) - None neu chua co tep."""
    try:
        with open(duong, "r", encoding="utf-8-sig") as f:
            d = f.readline()
        j = json.loads(d, strict=False)
        return j if j.get("loai") == "dau" else None
    except Exception:
        return None


def doc_bang_ke(duong):
    """-> {'dau': {...}, 'tk': [[sh, ten]...], 'hd': [...]} hoac None. Dong hong bo qua (dem 'loi_dong')."""
    if not os.path.isfile(duong):
        return None
    kq = {"dau": None, "tk": [], "hd": [], "loi_dong": 0}
    with open(duong, "r", encoding="utf-8-sig") as f:
        for dong in f:
            dong = dong.strip()
            if not dong:
                continue
            try:
                j = json.loads(dong, strict=False)       # phan mem khong thoat ky tu dieu khien hiem gap
            except ValueError:
                kq["loi_dong"] += 1
                continue
            loai = j.get("loai")
            if loai == "dau":
                kq["dau"] = j
            elif loai == "tk":
                kq["tk"] = [x for x in (j.get("ds") or []) if isinstance(x, list) and len(x) >= 2]
            elif loai == "hd":
                kq["hd"].append(j)
    if not kq["dau"]:
        return None
    return kq


def tk_goi_y(ds_tk, huong):
    """TK chi tiet goi y cho o TK dong hang: mua 15x / 2xx / 6xx / 8xx / 14x, 24x; ban 51x, 52x, 711."""
    kq = []
    for sh, ten in ds_tk:
        sh = str(sh)
        if huong == "ban":
            ok = sh[:2] in ("51", "52") or sh[:3] == "711"
        else:
            ok = sh[:1] in ("1", "2", "6", "8") and sh[:3] not in _CAM_MUA and sh[:2] not in ("11", "13")
        if ok:
            kq.append([sh, ten])
    return kq


def but_toan(hd, huong, tk_md=None):
    """Dinh khoan cua mot hoa don -> [(no, co, tien, noi_dung)]. Dong bo qua (CK phan bo / KM) khong ghi.
    Ban ra co ma vat tu ton kho: them dong gia von (tien None = tinh khi lap chung tu theo gia xuat kho)."""
    tk_md = tk_md or {}
    co = hd.get("co") or ""
    thue_tk = hd.get("tk_thue") or tk_md.get("thue") or ""
    gv = tk_md.get("gv") or "632"
    gom, thue, kho = {}, 0.0, {}
    for d in hd.get("d") or []:
        if d.get("tt") == "BO_QUA":
            continue
        tk = d.get("tk") or "?"
        gom[tk] = gom.get(tk, 0.0) + _so(d.get("tien"))
        thue += _so(d.get("thue"))
        if huong == "ban" and d.get("kho"):
            kho[d["kho"]] = 1
    kq = []
    for tk, tien in gom.items():
        if abs(tien) < 0.005:
            continue
        if huong == "ban":
            kq.append((co, tk, round(tien, 2), "Doanh thu"))
        else:
            kq.append((tk, co, round(tien, 2), "Tiền hàng / chi phí"))
    if abs(thue) >= 0.005:
        kq.append((co, thue_tk, round(thue, 2), "Thuế GTGT đầu ra") if huong == "ban" else (thue_tk, co, round(thue, 2), "Thuế GTGT đầu vào"))
    for k in kho:
        kq.append((gv, k, None, "Giá vốn (theo giá xuất kho khi lập CT)"))
    return kq


def tom_tat(hd, huong, tk_md=None):
    """'N 1561, 1331 / C 3311' (mua) ; 'N 1311 / C 5111, 33311' (ban)."""
    bt = [x for x in but_toan(hd, huong, tk_md) if x[2] is not None]
    if not bt:
        return ""
    no = []
    co = []
    for n, c, _t, _g in bt:
        if n not in no:
            no.append(n)
        if c not in co:
            co.append(c)
    return "N %s / C %s" % (", ".join(no), ", ".join(co))


def rut_gon(bk):
    """Bang ke (doc_bang_ke) -> du lieu gui giao dien: them khoa chuan, ten trang thai, tom tat dinh khoan."""
    dau = bk["dau"]
    huong = dau.get("huong", "mua")
    tk_md = dau.get("tk") or {}
    ds = []
    for h in bk["hd"]:
        x = dict(h)
        x["kc2"] = khoa_chuan(h.get("kc") or h.get("khoa"))
        x["ten_tt"] = TEN_TT.get(h.get("tt"), h.get("tt") or "")
        x["dk"] = tom_tat(h, huong, tk_md)
        x["bt"] = [[n, c, t, g] for n, c, t, g in but_toan(h, huong, tk_md)]
        ds.append(x)
    return {"dau": dau, "hd": ds, "tk": tk_goi_y(bk["tk"], huong), "tk_ten": {str(a): b for a, b in bk["tk"]},
            "loi_dong": bk.get("loi_dong", 0)}


def cho_ket_qua(duong, ma, cho=40.0, buoc=0.5, khoa="id"):
    """Doi phan mem ghi bang ke co dau[khoa] == ma (khoa 'id' = yeu cau, 'sua' = lan sua). None neu het gio."""
    het = time.time() + cho
    while time.time() < het:
        d = doc_dau(duong)
        if d:
            v = (d.get("sua") or {}).get("id") if khoa == "sua" else d.get("id")
            if v == ma:
                return d
        time.sleep(buoc)
    return None


# ---------------------------------------------------------------- Excel
def xuat_excel(bk, duong, viet_xlsx, DongTong):
    """Bang ke dinh khoan Excel 3 sheet: Dinh khoan (tung dong hang), But toan (tung hoa don), Tong hop TK."""
    dau = bk["dau"]
    huong = dau.get("huong", "mua")
    tk_md = dau.get("tk") or {}
    ten_tk = {str(a): b for a, b in bk.get("tk") or []}
    doi_tac = "Người mua" if huong == "ban" else "Người bán"
    c1 = ["STT HĐ", "Ngày HĐ", "Mẫu số", "Ký hiệu", "Số HĐ", "Số CT (dự kiến)", doi_tac, "MST", "Mã đối tượng",
          "Tên hàng hoá, dịch vụ", "ĐVT", "Số lượng", "Đơn giá", "Thành tiền", "Thuế suất", "Tiền thuế",
          "Mã VT", "Tính chất", "TK Nợ" if huong != "ban" else "TK Có (doanh thu)",
          "TK Có" if huong != "ban" else "TK Nợ", "TK thuế", "TK kho (giá vốn)", "Tin cậy", "Nguồn AI",
          "Trạng thái AI", "Ghi chú AI"]
    k1 = ["so", "chu", "chu", "chu", "text", "chu", "chu", "text", "text", "chu", "chu", "so4", "so4", "so", "chu", "so",
          "text", "chu", "text", "text", "text", "text", "so", "chu", "chu", "chu"]
    r1 = [7, 11, 7, 9, 10, 12, 34, 14, 12, 40, 8, 10, 12, 14, 9, 13, 12, 14, 11, 11, 10, 11, 8, 14, 16, 40]
    d1, d2 = [], []
    tong_tien = tong_thue = 0.0
    th = {}
    for i, h in enumerate(bk["hd"], 1):
        ngay = h.get("ngay") or ""
        ngay_vn = "%s/%s/%s" % (ngay[8:10], ngay[5:7], ngay[:4]) if len(ngay) >= 10 else ngay
        for d in h.get("d") or []:
            bq = d.get("tt") == "BO_QUA"
            d1.append([i, ngay_vn, h.get("mau", ""), h.get("kh", ""), h.get("so", ""), h.get("soct", ""), h.get("ten", ""),
                       h.get("mst", ""), h.get("dt", ""), d.get("ten", ""), d.get("dvt", ""), _so(d.get("sl")), _so(d.get("dg")),
                       _so(d.get("tien")), d.get("ts", ""), _so(d.get("thue")), d.get("vt", ""),
                       TEN_TC.get(d.get("tc"), d.get("tc", "")), "" if bq else d.get("tk", ""), "" if bq else h.get("co", ""),
                       "" if bq else h.get("tk_thue", ""), d.get("kho", ""), d.get("tin", 0),
                       TEN_NGUON.get(d.get("ng"), d.get("ng", "")), TEN_TT.get(d.get("tt"), d.get("tt", "")),
                       h.get("ghi", "") if d is (h.get("d") or [None])[0] else ""])
        bt = but_toan(h, huong, tk_md)
        for n, c, t, g in bt:
            d2.append([i, ngay_vn, h.get("kh", ""), h.get("so", ""), h.get("ten", ""), h.get("dt", ""), n, ten_tk.get(n, ""),
                       c, ten_tk.get(c, ""), "" if t is None else t, g, TEN_TT.get(h.get("tt"), h.get("tt", ""))])
            if t is not None:
                k = (n, c)
                th[k] = th.get(k, 0.0) + t
        if h.get("tt") != "BO_QUA":
            tong_tien += _so(h.get("tien"))
            tong_thue += _so(h.get("thue"))
    d1.append(DongTong(["", "", "", "", "", "", "TỔNG CỘNG", "", "", "%d hoá đơn" % len(bk["hd"]), "", "", "", tong_tien, "",
                        tong_thue] + [""] * 10, 2))
    c2 = ["STT HĐ", "Ngày HĐ", "Ký hiệu", "Số HĐ", doi_tac, "Mã đối tượng", "TK Nợ", "Tên TK Nợ", "TK Có", "Tên TK Có",
          "Số tiền", "Nội dung", "Trạng thái AI"]
    k2 = ["so", "chu", "chu", "text", "chu", "text", "text", "chu", "text", "chu", "so", "chu", "chu"]
    r2 = [7, 11, 9, 10, 34, 12, 10, 26, 10, 26, 15, 30, 16]
    d3 = []
    tong = 0.0
    for (n, c), t in sorted(th.items()):
        d3.append([n, ten_tk.get(n, ""), c, ten_tk.get(c, ""), round(t, 2)])
        tong += t
    d3.append(DongTong(["", "TỔNG", "", "", round(tong, 2)], 2))
    c3 = ["TK Nợ", "Tên TK Nợ", "TK Có", "Tên TK Có", "Số tiền"]
    viet_xlsx(duong, [("Định khoản", c1, k1, r1, d1), ("Bút toán", c2, k2, r2, d2),
                      ("Tổng hợp TK", c3, ["text", "chu", "text", "chu", "so"], [10, 34, 10, 34, 16], d3)])
    return len(bk["hd"])


def ten_tep_excel(dau):
    return "BANG_KE_DINH_KHOAN_%s_%s_%s_%s.xlsx" % ("BANRA" if dau.get("huong") == "ban" else "MUAVAO",
                                                  (dau.get("tu") or "").replace("-", ""), (dau.get("den") or "").replace("-", ""),
                                                  datetime.now().strftime("%Y%m%d-%H%M%S"))
