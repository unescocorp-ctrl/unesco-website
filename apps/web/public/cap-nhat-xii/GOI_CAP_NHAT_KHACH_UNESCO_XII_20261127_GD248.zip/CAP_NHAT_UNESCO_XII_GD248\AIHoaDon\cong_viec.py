# -*- coding: utf-8 -*-
"""GD137 - EXCEL LICH CONG VIEC NAM (Quan ly cong viec cua doanh nghiep: thue, BHXH - lao dong, noi bo, viec rieng).

VB6 (ModCongViec.CV_XuatExcel) tinh het (danh muc nghia vu, han da doi ngay nghi, trang thai, so lieu doc tu so) roi ghi JSON:
    {"loai": "congviec", "cty", "mst", "nam_tc", "hom_nay": "dd/mm/yyyy", "lap_luc", "ky_gtgt": "T" | "Q", "tom_tat",
     "dong": [{"nhom", "ma", "ten", "ky", "mau", "cq", "han": "dd/mm/yyyy", "han_goc", "han_rieng": bool, "xong": bool,
               "trang_thai", "con", "so_lieu", "ghi_chu", "can_cu"}]}
    tool_htkk_unesco.py /congviec:<json> /ra:<xlsx>
Sheet LichCongViec (theo han, ngat theo thang), TheoThang (viec x thang), CanCu. Chi doc - khong ghi so.
GD142: sheet VanBanPhapLuat - danh muc AIHoaDon\\van_ban\\cap_nhat_van_ban.txt (bang Cap nhat thay doi van ban phap luat).
"""
import datetime as _dt
import io
import json
import os

from xlsx_viet import SoExcel

PHIEN_BAN = "GD142"
HERE = os.path.dirname(os.path.abspath(__file__))
TEP_VAN_BAN = os.path.join(HERE, "van_ban", "cap_nhat_van_ban.txt")
TRANG_THAI_VB = {"DA": "Đã cập nhật", "LAM": "Đã có - cần chọn / làm", "CHO": "Chờ cơ quan thuế / HTKK", "TK": "Tham khảo"}


def doc_van_ban(tep=None):
    """GD142: danh muc van ban phap luat (dong '#' bo qua; 9 cot TAB) -> (ngay danh muc, [dict]). Khong co tep -> ("", [])."""
    tep = tep or TEP_VAN_BAN
    ngay, ds = "", []
    try:
        with io.open(tep, "r", encoding="utf-8-sig") as f:
            dong = f.read().splitlines()
    except (IOError, OSError):
        return ngay, ds
    for d in dong:
        if d.startswith("#"):
            if "NGAY_DANH_MUC=" in d:
                ngay = d.split("=", 1)[1].strip()
            continue
        a = d.split("\t")
        if len(a) < 6 or not a[0].strip():
            continue
        a = [x.strip() for x in a] + [""] * (9 - len(a))
        try:
            goi = int(a[6] or 0)
        except ValueError:
            goi = 0
        ds.append({"ma": a[0], "hieu_luc": a[1], "van_ban": a[2], "noi_dung": a[3], "anh_huong": a[4],
                   "trang_thai": a[5].upper(), "goi": goi, "de_xuat": a[7], "nguon": a[8]})
    return ngay, ds


def them_van_ban(wb, tep=None):
    """GD142: sheet VanBanPhapLuat (bang Cap nhat thay doi van ban phap luat, bieu mau bao cao va de xuat update)."""
    ngay, ds = doc_van_ban(tep)
    if not ds:
        return 0
    ws = wb.sheet("VanBanPhapLuat", cot=[12, 30, 52, 30, 22, 46, 34])
    ws.gop(1, 1, 1, 7, "CẬP NHẬT THAY ĐỔI VĂN BẢN PHÁP LUẬT, BIỂU MẪU BÁO CÁO VÀ ĐỀ XUẤT UPDATE",
           wb.kieu(dam=True, co=14, can="giua", mau="0B3D91"))
    ws.gop(2, 1, 2, 7, "Danh mục cập nhật ngày %s. Cột Phần mềm: tình trạng trong phần mềm UNESCO AI (gói GĐ đã cập nhật)." % (ngay or "-"),
           wb.kieu(nghieng=True, mau="555555", xuong=True))
    k_dau = wb.kieu(dam=True, nen="D9E1F2", khung=True, can="giua", xuong=True)
    k_o = wb.kieu(khung=True, xuong=True, doc="tren")
    k_cho = wb.kieu(khung=True, xuong=True, doc="tren", mau="C65911", dam=True)
    ws.dong(4, 1, ["Hiệu lực", "Văn bản", "Thay đổi chính", "Biểu mẫu / báo cáo ảnh hưởng", "Phần mềm", "Đề xuất", "Nguồn"], k_dau)
    ws.cao(4, 30)
    r = 4
    for x in ds:
        r += 1
        pm = TRANG_THAI_VB.get(x["trang_thai"], "Tham khảo")
        if x["goi"] and x["trang_thai"] in ("DA", "LAM"):
            pm += " (GĐ%d)" % x["goi"]
        ws.dong(r, 1, [x["hieu_luc"], x["van_ban"], x["noi_dung"], x["anh_huong"], pm, x["de_xuat"], x["nguon"]],
                k_cho if x["trang_thai"] == "CHO" else k_o)
    ws.dong_bang(5, 2)
    ws.loc(4, 1, r, 7)
    ws.in_trang(ngang=True, vua_rong=True, lap_dong=(4, 4))
    return len(ds)


def _ngay(s):
    try:
        return _dt.datetime.strptime(str(s), "%d/%m/%Y").date()
    except (TypeError, ValueError):
        return None


def tinh(dl):
    """Chuan hoa dong + phan loai muc do (0 da xong, 1 chua den, 2 sap den han <= 7 ngay, 3 qua han)."""
    hom = _ngay(dl.get("hom_nay")) or _dt.date.today()
    rows = []
    for d in dl.get("dong") or []:
        han = _ngay(d.get("han"))
        if not han:
            continue
        xong = bool(d.get("xong"))
        con = (han - hom).days
        muc = 0 if xong else (3 if con < 0 else (2 if con <= 7 else 1))
        rows.append(dict(d, han=han, han_goc=_ngay(d.get("han_goc")) or han, con_ngay=con, muc=muc))
    rows.sort(key=lambda x: (x["han"], x.get("nhom") or "", x.get("ten") or ""))
    dem = {k: sum(1 for x in rows if x["muc"] == k) for k in (0, 1, 2, 3)}
    return {"rows": rows, "hom": hom, "dem": dem}


def lap(dl, ra):
    T = tinh(dl)
    rows = T["rows"]
    nam = int(dl.get("nam_tc") or T["hom"].year)
    wb = SoExcel(font="Times New Roman", co=11)
    k_td = wb.kieu(dam=True, co=14, can="giua", mau="0B3D91")
    k_dv = wb.kieu(dam=True)
    k_ghi = wb.kieu(nghieng=True, mau="555555", xuong=True, doc="tren")
    k_dau = wb.kieu(dam=True, nen="D9E1F2", khung=True, can="giua", xuong=True)
    k_thang = wb.kieu(dam=True, nen="FFF2CC", khung=True)
    kieu = {
        0: (wb.kieu(khung=True, mau="808080", xuong=True), wb.kieu(khung=True, mau="808080", so="dd/mm/yyyy", can="giua")),
        1: (wb.kieu(khung=True, xuong=True), wb.kieu(khung=True, so="dd/mm/yyyy", can="giua")),
        2: (wb.kieu(khung=True, mau="C65911", dam=True, xuong=True), wb.kieu(khung=True, mau="C65911", dam=True, so="dd/mm/yyyy", can="giua")),
        3: (wb.kieu(khung=True, mau="C00000", dam=True, xuong=True), wb.kieu(khung=True, mau="C00000", dam=True, so="dd/mm/yyyy", can="giua")),
    }
    n = 11
    ws = wb.sheet("LichCongViec", cot=[5, 11, 13, 13, 34, 15, 15, 20, 42, 20, 26])
    ws.gop(1, 1, 1, n, ("%s - MST %s" % (dl.get("cty") or "", dl.get("mst") or "")).strip(" -"), k_dv)
    ws.gop(2, 1, 2, n, "LỊCH CÔNG VIỆC - NGHĨA VỤ KHAI, NỘP THUẾ, BHXH, LAO ĐỘNG - NĂM TÀI CHÍNH %s" % nam, k_td)
    ws.gop(3, 1, 3, n, "Lập lúc %s. %s Hạn thuế / BCTC trùng thứ 7, chủ nhật, ngày nghỉ lễ đã lùi sang ngày làm việc tiếp theo "
                       "(dấu * ở cột Hạn); (GH) = hạn riêng / gia hạn do người dùng đặt. Số liệu theo sổ là ước tính, chỉ đọc."
           % (dl.get("lap_luc") or "", dl.get("tom_tat") or ""), k_ghi)
    ws.cao(3, 48)
    r0 = 5
    ws.dong(r0, 1, ["STT", "Hạn", "Còn", "Nhóm", "Việc", "Kỳ", "Mẫu / hồ sơ", "Nơi nộp", "Số liệu theo sổ (ước tính)", "Trạng thái", "Ghi chú"], k_dau)
    ws.cao(r0, 32)
    r = r0
    thang = None
    stt = 0
    for x in rows:
        th = (x["han"].year, x["han"].month)
        if th != thang:
            thang = th
            r += 1
            ws.gop(r, 1, r, n, "THÁNG %02d/%d" % (th[1], th[0]), k_thang)
        r += 1
        stt += 1
        kc, kn = kieu[x["muc"]]
        han_chu = x["han"]
        ws.o(r, 1, stt, kc)
        ws.o(r, 2, han_chu, kn)
        ws.o(r, 3, x.get("con") or "", kc)
        ws.dong(r, 4, [x.get("nhom") or "", x.get("ten") or "", x.get("ky") or "", x.get("mau") or "", x.get("cq") or "",
                       x.get("so_lieu") or "", x.get("trang_thai") or "", x.get("ghi_chu") or ""], kc)
    if not rows:
        r += 1
        ws.gop(r, 1, r, n, "Không có việc nào.", k_ghi)
    r += 2
    d = T["dem"]
    ws.gop(r, 1, r, n, "Tổng: %d việc - quá hạn chưa xong %d (chữ đỏ); đến hạn trong 7 ngày %d (chữ cam); chưa đến kỳ %d; "
                       "đã xong / không phát sinh %d (chữ xám)." % (len(rows), d[3], d[2], d[1], d[0]), k_dv)
    ws.dong_bang(r0 + 1, 3)
    ws.loc(r0, 1, max(r0, r - 2), n)
    ws.in_trang(ngang=True, vua_rong=True, lap_dong=(r0, r0))

    # Sheet TheoThang: moi viec mot dong, 12 thang cua nam + cot "Nam sau": ngay han (xong = "v")
    w2 = wb.sheet("TheoThang", cot=[16, 36] + [8] * 12 + [12])
    w2.gop(1, 1, 1, 15, "LỊCH THEO THÁNG - NĂM %s (ô = ngày hạn; v = đã xong; ! = quá hạn chưa xong)" % nam, k_td)
    w2.dong(3, 1, ["Nhóm", "Việc"] + ["Th%d" % m for m in range(1, 13)] + ["Năm sau"], k_dau)
    viec = []
    for x in rows:
        k = (x.get("nhom") or "", x.get("ten") or "")
        if k not in viec:
            viec.append(k)
    rr = 3
    k_o = wb.kieu(khung=True, can="giua")
    k_ox = wb.kieu(khung=True, can="giua", mau="808080")
    k_od = wb.kieu(khung=True, can="giua", mau="C00000", dam=True)
    k_tr = wb.kieu(khung=True, xuong=True)
    for (nh, ten) in viec:
        rr += 1
        w2.o(rr, 1, nh, k_tr)
        w2.o(rr, 2, ten, k_tr)
        o = {}
        for x in rows:
            if (x.get("nhom") or "", x.get("ten") or "") != (nh, ten):
                continue
            c = 15 if x["han"].year > nam else (x["han"].month + 2 if x["han"].year == nam else None)
            if c is None:
                continue
            o.setdefault(c, []).append(x)
        for c in range(3, 16):
            ds = o.get(c) or []
            if not ds:
                w2.o(rr, c, None, k_o)
                continue
            chu = ", ".join(("%02d/%02d" % (x["han"].day, x["han"].month) if c == 15 else "%02d" % x["han"].day)
                            + (" v" if x["muc"] == 0 else (" !" if x["muc"] == 3 else "")) for x in ds)
            w2.o(rr, c, chu, k_od if any(x["muc"] == 3 for x in ds) else (k_ox if all(x["muc"] == 0 for x in ds) else k_o))
    w2.dong_bang(4, 3)
    w2.in_trang(ngang=True, vua_rong=True, lap_dong=(3, 3))

    # Sheet CanCu
    w3 = wb.sheet("CanCu", cot=[34, 110])
    w3.gop(1, 1, 1, 2, "CĂN CỨ VÀ CÁCH TÍNH HẠN (rà soát 10/2026)", wb.kieu(dam=True, co=13, mau="0B3D91"))
    rr = 2
    da = set()
    for x in rows:
        cc = x.get("can_cu") or ""
        if not cc or x.get("ten") in da:
            continue
        da.add(x.get("ten"))
        rr += 1
        w3.o(rr, 1, x.get("ten") or "", wb.kieu(dam=True, xuong=True, doc="tren"))
        w3.o(rr, 2, cc, wb.kieu(xuong=True, doc="tren"))
    for t in ["Hạn thuế và báo cáo tài chính trùng thứ 7, chủ nhật, ngày nghỉ lễ thì lùi sang ngày làm việc tiếp theo: 1/1, 30/4, 1/5, 2/9 "
              "và lịch nghỉ đã công bố 2025 - 2026; năm sau thêm vào tệp AIHoaDon\\ngay-nghi-le.txt (nút Lịch nghỉ lễ).",
              "Gia hạn nộp thuế (nếu doanh nghiệp thuộc đối tượng và đã gửi giấy đề nghị): đặt Hạn riêng cho từng kỳ trên màn hình.",
              "Lệ phí môn bài đã bãi bỏ từ năm 2026 nên không còn trong lịch.",
              "Trạng thái tự nhận: hồ sơ đã nộp tải từ Cổng dịch vụ công (thẻ Cổng DVC); BHXH / KPCĐ đã nộp đủ theo sổ; không phát sinh."]:
        rr += 1
        w3.gop(rr, 1, rr, 2, "- " + t, wb.kieu(xuong=True, doc="tren"))
        w3.cao(rr, 30)
    them_van_ban(wb)                     # GD142
    os.makedirs(os.path.dirname(os.path.abspath(ra)), exist_ok=True)
    wb.luu(ra)
    return ra, T


def chay(duong_json, ra="", ghi_log=None):
    """-> (duong tep Excel, None) | (None, loi). JSON tam doc xong XOA."""
    log = ghi_log or (lambda s: None)
    try:
        with io.open(duong_json, "r", encoding="utf-8-sig") as f:
            dl = json.load(f)
    except Exception as e:
        return None, "Khong doc duoc so lieu lich cong viec: %s" % e
    finally:
        try:
            os.remove(duong_json)
        except OSError:
            pass
    try:
        if not ra:
            ra = os.path.join(os.path.dirname(os.path.abspath(duong_json)), "LichCongViec_%s.xlsx" % _dt.datetime.now().strftime("%Y%m%d_%H%M%S"))
        tep, T = lap(dl, ra)
        log("[CONG VIEC] %s: %d viec, qua han %d" % (os.path.basename(tep), len(T["rows"]), T["dem"][3]))
        return tep, None
    except Exception as e:
        import traceback
        log("[CONG VIEC] loi: %s\n%s" % (e, traceback.format_exc()))
        return None, "Loi lap Excel lich cong viec: %s" % e
