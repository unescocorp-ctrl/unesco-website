# -*- coding: utf-8 -*-
"""GD242 - CHINH SACH BO SO HOP NHAT (lo trinh muc 5): mot man hinh / mot tep xem "chinh sach dang ap dung" cua bo so
(quy tac hach toan HDDT_QuyTac, ghep ma da hoc HDDT_GhepMa, tu khoa HDDT_TuKhoa, NCC chi phi HDDT_NCCChiPhi, quy tac chi phi
HDDT_QTCP, tai khoan ngan hang HDDT_SP_TaiKhoanNH, hoc so phu HDDT_SP_HocMa, TK chuan KS7 HDDT_KS_TKChuan), doc CHI DOC bang
jet_doc (mo 'rb'), khong ghi gi vao .MDB.
  K50: TK trong chinh sach khong co trong he thong TK / la TK tong hop (LOI / CANH_BAO); ghep ma mo ho (cung MST + ten -> nhieu TK No).
  K51: chinh sach cua ky da doi so voi lan kiem tra truoc cua CUNG ky (anh chup luu theo ky: "khoa chinh sach theo thang").
Tep ra: AIHoaDon\\ket-qua\\chinh-sach\\<ten so>\\chinh_sach.html + chinh_sach_<nam>_<tu>-<den>.json (anh chup).
"""
import hashlib
import io
import json
import os
import re
from collections import defaultdict

# (bang, nhan, cot khoa hien thi, cac cot TK can kiem, cot hien thi)
BANG = [
    ("HDDT_QuyTac", "Quy tắc hạch toán hóa đơn (chung)", ["MaSo"],
     ["TK_HangHoa", "TK_NVL", "TK_CCDC", "TK_DichVu", "TK_ThueMua", "TK_ThueBan", "TK_DoanhThuHH", "TK_DoanhThuDV"],
     ["HTTT_MacDinh", "TK_HangHoa", "TK_NVL", "TK_CCDC", "TK_DichVu", "TK_ThueMua", "TK_ThueBan", "TK_DoanhThuHH", "TK_DoanhThuDV",
      "KH_Le", "NhomVT_MacDinh", "CheDoGhi", "NguongTinCayTuDong"]),
    ("HDDT_GhepMa", "Ghép mã đã học (MST + tên hàng)", ["MST", "KhoaTen"], ["TKNo", "TKCo"],
     ["MST", "KhoaTen", "MaVT", "TKNo", "TKCo", "TinhChat", "SoLan", "Nguon"]),
    ("HDDT_TuKhoa", "Từ khóa tên hàng", ["TuKhoa", "ApDungCho"], ["TKNo"], ["TuKhoa", "ApDungCho", "MaVT", "TKNo", "TinhChat", "UuTien"]),
    ("HDDT_NCCChiPhi", "Nhà cung cấp chi phí", ["MST"], ["TKMacDinh"], ["MST", "TenNCC", "LaChiPhi", "TKMacDinh", "SoLan"]),
    ("HDDT_QTCP", "Quy tắc chi phí theo từ khóa", ["TuKhoa", "TKLoc"], ["DichTK"], ["Bat", "Thu", "TuKhoa", "TKLoc", "DichTK", "GhiChu"]),
    ("HDDT_SP_TaiKhoanNH", "Tài khoản ngân hàng → TK 112", ["SoTKNH"], ["TK112"], ["SoTKNH", "NganHang", "TK112", "MaNT", "TenNH"]),
    ("HDDT_SP_HocMa", "Sổ phụ đã học (nội dung → đối tượng, TK)", ["NganHang", "Chieu", "KhoaNoiDung"], ["TKDoiUng"],
     ["NganHang", "Chieu", "KhoaNoiDung", "MaKH", "TKDoiUng", "SoLan"]),
    ("HDDT_KS_TKChuan", "TK chuẩn đã chốt (Kiểm soát KS7)", ["Khoa", "Loai"], ["TK"], ["Khoa", "Loai", "TK"]),
]
TOI_DA = 20000


def _s(x):
    if x is None:
        return ""
    if isinstance(x, float) and x == int(x):
        x = int(x)
    return str(x).strip()


def doc_chinh_sach(duong):
    """{bang: [dict cot -> chuoi]} (chi cac cot hien thi + khoa + TK); bang khong co -> khong co khoa."""
    import jet_doc
    m = jet_doc.Mdb(duong)
    try:
        co = {k.lower() for k in m.bang()}
        out = {}
        for ten, _, khoa, tks, hien in BANG:
            if ten.lower() not in co:
                continue
            cot = list(dict.fromkeys(khoa + tks + hien))
            ds = []
            for r in m.doc(ten, TOI_DA):
                rl = {str(k).lower(): v for k, v in r.items()}
                ds.append({c: _s(rl.get(c.lower())) for c in cot})
            out[ten] = ds
        return out
    finally:
        try:
            m.dong()
        except Exception:
            pass


def _khoa(r, khoa):
    return " | ".join(r.get(c, "") for c in khoa)


def kiem_tk(cs, tk_la, tk_tat_ca):
    """-> (dong LOI/CANH_BAO, so loi): TK khong ton tai / la TK tong hop; ghep ma mo ho."""
    dong, n_loi = [], 0
    for ten, nhan, khoa, tks, _ in BANG:
        for r in cs.get(ten) or []:
            for c in tks:
                v = r.get(c, "")
                if not v or v == "0":
                    continue
                if v not in tk_tat_ca:
                    n_loi += 1
                    dong.append(["LỖI", nhan, _khoa(r, khoa), "%s = %s" % (c, v), "TK không có trong hệ thống tài khoản - sửa chính sách hoặc mở TK"])
                elif v not in tk_la and ten != "HDDT_QuyTac":      # quy tac chung duoc phep la TK tong hop (may chon TK con theo KS7)
                    dong.append(["Cần xem", nhan, _khoa(r, khoa), "%s = %s" % (c, v), "TK tổng hợp (có TK con) - chốt TK chi tiết"])
    nhom = defaultdict(set)
    for r in cs.get("HDDT_GhepMa") or []:
        if r.get("TKNo"):
            nhom[(r.get("MST", ""), r.get("KhoaTen", ""))].add(r["TKNo"])
    for (mst, kt), tk in sorted(nhom.items()):
        if len(tk) > 1:
            dong.append(["Cần xem", "Ghép mã đã học (MST + tên hàng)", "%s | %s" % (mst, kt), "TK Nợ: " + ", ".join(sorted(tk)),
                         "Cùng hàng của cùng NCC học ra nhiều TK - chọn một, xóa dòng còn lại (Ghép mã)"])
    return dong, n_loi


def anh_chup(cs):
    """chuan hoa chinh sach -> {bang: {khoa: chuoi gia tri}} (bo so lan / lan cuoi de khong bao doi vi dem)."""
    out = {}
    for ten, _, khoa, tks, hien in BANG:
        d = {}
        for r in cs.get(ten) or []:
            gt = ";".join("%s=%s" % (c, r.get(c, "")) for c in hien if c not in khoa and c not in ("SoLan",))
            d[_khoa(r, khoa)] = gt
        out[ten] = d
    return out


def so_sanh(cu, moi):
    """-> [[bang, khoa, 'Thêm' / 'Bỏ' / 'Đổi', cu, moi]]"""
    nhan = {b[0]: b[1] for b in BANG}
    dong = []
    for ten in sorted(set(cu) | set(moi)):
        a, b = cu.get(ten) or {}, moi.get(ten) or {}
        for k in sorted(set(a) | set(b)):
            if k not in a:
                dong.append([nhan.get(ten, ten), k, "Thêm", "", b[k]])
            elif k not in b:
                dong.append([nhan.get(ten, ten), k, "Bỏ", a[k], ""])
            elif a[k] != b[k]:
                dong.append([nhan.get(ten, ten), k, "Đổi", a[k], b[k]])
    return dong


def _esc(s):
    return (str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


def viet_html(cs, loi, doi, ra, ten_so):
    css = ("body{font-family:Segoe UI,Arial,sans-serif;margin:16px;color:#222}h1{font-size:20px}h2{font-size:16px;margin-top:22px}"
           "table{border-collapse:collapse;font-size:13px;margin:6px 0}td,th{border:1px solid #ccc;padding:3px 6px;text-align:left}"
           "th{background:#eef3f8}.loi{color:#b00020;font-weight:bold}.cb{color:#a65e00}.nho{color:#666;font-size:12px}")
    h = ["<!doctype html><html><head><meta charset='utf-8'><title>Chính sách đang áp dụng</title><style>" + css + "</style></head><body>",
         "<h1>Chính sách đang áp dụng - %s</h1>" % _esc(ten_so),
         "<p class='nho'>Đọc trực tiếp từ bộ sổ, chỉ đọc. Mỗi lần Kiểm tra trước khóa sổ lưu một ảnh chụp theo kỳ để phát hiện chính sách bị đổi sau khi đã kiểm.</p>"]
    if loi:
        h.append("<h2>Cần sửa / cần xem (%d)</h2><table><tr><th>Mức</th><th>Nhóm</th><th>Khóa</th><th>Giá trị</th><th>Cách xử lý</th></tr>" % len(loi))
        for d in loi:
            cl = "loi" if d[0] == "LỖI" else "cb"
            h.append("<tr><td class='%s'>%s</td>%s</tr>" % (cl, _esc(d[0]), "".join("<td>%s</td>" % _esc(x) for x in d[1:])))
        h.append("</table>")
    if doi:
        h.append("<h2>Đã đổi so với lần kiểm tra trước của kỳ này (%d)</h2><table><tr><th>Nhóm</th><th>Khóa</th><th>Thay đổi</th><th>Trước</th><th>Nay</th></tr>" % len(doi))
        for d in doi[:2000]:
            h.append("<tr>%s</tr>" % "".join("<td>%s</td>" % _esc(x) for x in d))
        h.append("</table>")
    for ten, nhan, khoa, tks, hien in BANG:
        ds = cs.get(ten)
        if ds is None:
            continue
        h.append("<h2>%s <span class='nho'>(%s, %d dòng)</span></h2>" % (_esc(nhan), ten, len(ds)))
        if not ds:
            h.append("<p class='nho'>Chưa có.</p>")
            continue
        h.append("<table><tr>%s</tr>" % "".join("<th>%s</th>" % c for c in hien))
        for r in ds[:3000]:
            h.append("<tr>%s</tr>" % "".join("<td>%s</td>" % _esc(r.get(c, "")) for c in hien))
        h.append("</table>")
        if len(ds) > 3000:
            h.append("<p class='nho'>... còn %d dòng.</p>" % (len(ds) - 3000))
    h.append("</body></html>")
    with io.open(ra, "w", encoding="utf-8") as f:
        f.write("\n".join(h))


def _thu_muc_ra(duong, tao=True):
    goc = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ket-qua", "chinh-sach")
    ten = os.path.splitext(os.path.basename(duong))[0]
    ten = re.sub(r"[^A-Za-z0-9_.-]+", "_", ten)[:40] or "so"
    ma = hashlib.md5(os.path.abspath(duong).lower().encode("utf-8", "replace")).hexdigest()[:6]
    tm = os.path.join(goc, "%s_%s" % (ten, ma))
    if tao and not os.path.isdir(tm):
        os.makedirs(tm)
    return tm, ten


def k_chinh_sach(S, _kq, DAT, CANH_BAO, LOI, THONG_TIN, thu_muc=None):
    ten50 = "Chính sách bộ sổ: tài khoản hợp lệ, ghép mã không mơ hồ"
    ten51 = "Chính sách của kỳ đổi sau lần kiểm tra trước"
    duong = S.dl.get("duong_so") or ""
    if not duong:
        return [_kq("K50", ten50, THONG_TIN, "Chưa có đường dẫn bộ sổ (bản phần mềm cũ) - Make .exe bản mới rồi chạy lại.")]
    if not os.path.isfile(duong):
        return [_kq("K50", ten50, THONG_TIN, "Không mở được tệp bộ sổ để đọc chính sách: %s" % duong)]
    cs = doc_chinh_sach(duong)
    tk_tat_ca = {(t.get("sh") or "").strip() for t in S.tk.values()}
    tk_la = {(S.tk[m].get("sh") or "").strip() for m in S.la}
    loi, n_loi = kiem_tk(cs, tk_la, tk_tat_ca)
    if thu_muc:
        tm, ten_so = thu_muc, os.path.splitext(os.path.basename(duong))[0]
    else:
        tm, ten_so = _thu_muc_ra(duong)
    ky = "%s_%02d-%02d" % (S.dl.get("nam_tc") or "", S.t1, S.t2)
    tep_ac = os.path.join(tm, "chinh_sach_%s.json" % ky)
    moi = anh_chup(cs)
    doi = []
    co_cu = os.path.isfile(tep_ac)
    if co_cu:
        try:
            with io.open(tep_ac, encoding="utf-8") as f:
                doi = so_sanh(json.load(f), moi)
        except Exception:
            co_cu = False
    if not co_cu:
        with io.open(tep_ac, "w", encoding="utf-8") as f:
            json.dump(moi, f, ensure_ascii=False)
    html = os.path.join(tm, "chinh_sach.html")
    viet_html(cs, loi, doi, html, ten_so)
    kq = []
    so_dong = sum(len(v) for v in cs.values())
    if loi:
        kq.append(_kq("K50", ten50, LOI if n_loi else CANH_BAO,
                      "%d dòng chính sách cần sửa / cần xem (%d TK không tồn tại). Xem toàn bộ chính sách: %s" % (len(loi), n_loi, html),
                      ["Mức", "Nhóm", "Khóa", "Giá trị", "Cách xử lý"], loi))
    else:
        kq.append(_kq("K50", ten50, DAT, "%d dòng chính sách ở %d nhóm, TK đều hợp lệ. Xem toàn bộ: %s" % (so_dong, len(cs), html)))
    if doi:
        kq.append(_kq("K51", ten51, CANH_BAO,
                      "%d thay đổi chính sách so với lần kiểm tra trước của kỳ này: chứng từ đã lập trước khi đổi có thể khác chứng từ lập sau "
                      "- lập lại lô bị ảnh hưởng hoặc giữ nguyên có lý do. Nếu chấp nhận chính sách mới: xóa tệp %s rồi kiểm tra lại." % (len(doi), tep_ac),
                      ["Nhóm", "Khóa", "Thay đổi", "Trước", "Nay"], doi[:500]))
    elif co_cu:
        kq.append(_kq("K51", ten51, DAT, "Chính sách không đổi kể từ lần kiểm tra đầu tiên của kỳ."))
    else:
        kq.append(_kq("K51", ten51, THONG_TIN, "Đã lưu ảnh chụp chính sách của kỳ (lần đầu): %s" % tep_ac))
    return kq
