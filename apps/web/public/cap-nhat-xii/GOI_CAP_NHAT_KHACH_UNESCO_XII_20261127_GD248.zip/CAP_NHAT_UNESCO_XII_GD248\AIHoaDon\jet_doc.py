# -*- coding: utf-8 -*-
"""GD124 - DOC CAU TRUC + DU LIEU FILE ACCESS .MDB (Jet 3 = Access 97 VA Jet 4 = Access 2000+) BANG PYTHON THUAN - CHI DOC.
Dung de KIEM TRA du lieu phien ban cu (khong can Access / DAO / Windows): bang, cot (kieu, do dai), truy van, so ban ghi,
doc ban ghi cac bang nho (License, NamTC...). KHONG GHI gi vao tep .MDB (mo che do 'rb').

Dinh dang theo tai lieu mdbtools (HACKING): trang 2048 byte (Jet 3) / 4096 byte (Jet 4); TDEF, trang du lieu, ban ghi,
bang con tro bien doi (Jet 3 co bang 'nhay' 256 byte), MEMO (LVAL noi tuyen / 1 trang / chuoi trang).
Mat khau CSDL Access chi la kiem tra o tang Jet - trang du lieu khong ma hoa nen doc duoc truc tiep."""
import datetime
import os
import struct

T_BOOL, T_BYTE, T_INT, T_LONG, T_MONEY, T_FLOAT, T_DOUBLE = 1, 2, 3, 4, 5, 6, 7
T_DATE, T_BINARY, T_TEXT, T_OLE, T_MEMO, T_GUID, T_NUMERIC = 8, 9, 0x0A, 0x0B, 0x0C, 0x0F, 0x10
TEN_KIEU = {T_BOOL: "BOOLEAN", T_BYTE: "BYTE", T_INT: "INTEGER", T_LONG: "LONG", T_MONEY: "CURRENCY", T_FLOAT: "SINGLE",
            T_DOUBLE: "DOUBLE", T_DATE: "DATETIME", T_BINARY: "BINARY", T_TEXT: "TEXT", T_OLE: "LONGBINARY",
            T_MEMO: "MEMO", T_GUID: "GUID", T_NUMERIC: "DECIMAL"}


def _u16(b, o):
    return struct.unpack_from("<H", b, o)[0]


def _i16(b, o):
    return struct.unpack_from("<h", b, o)[0]


def _u24(b, o):
    return b[o] | (b[o + 1] << 8) | (b[o + 2] << 16)


def _u32(b, o):
    return struct.unpack_from("<I", b, o)[0]


class Mdb(object):
    def __init__(self, path, codepage="cp1252"):
        self.path = path
        self.cp = codepage
        self.f = open(path, "rb")
        h = self.f.read(0x80)
        if h[4:19] != b"Standard Jet DB":
            raise RuntimeError("Khong phai tep Access (.MDB Jet): %s" % path)
        self.jet4 = h[0x14] >= 1
        self.ps = 4096 if self.jet4 else 2048
        self.so_trang = os.fstat(self.f.fileno()).st_size // self.ps
        self._td = {}
        self._trang_bang = None
        self.doi_tuong = []           # MSysObjects: {Id, ParentId, Name, Type, Flags}
        self._doc_catalog()

    def dong(self):
        try:
            self.f.close()
        except Exception:
            pass

    @property
    def phien_ban(self):
        return "Jet4 (Access 2000+)" if self.jet4 else "Jet3 (Access 97)"

    def pg(self, n):
        self.f.seek(n * self.ps)
        return self.f.read(self.ps)

    # ------------------------------------------------------------------ TDEF
    def tdef(self, trang):
        if trang in self._td:
            return self._td[trang]
        b = self.pg(trang)
        if not b or b[0] != 0x02:
            raise RuntimeError("Trang %d khong phai TDEF" % trang)
        tdef_len = _u32(b, 0x08)
        buf = bytearray(b)
        nxt = _u32(b, 0x04)
        dem = 0
        while nxt and dem < 200:
            p = self.pg(nxt)
            buf += p[8:]
            nxt = _u32(p, 0x04)
            dem += 1
        b = bytes(buf)
        cols = []
        if self.jet4:
            num_rows = _u32(b, 0x10)
            num_var, num_cols = _u16(b, 0x2B), _u16(b, 0x2D)
            num_ridx = _u32(b, 0x33)
            o = 0x3F + num_ridx * 12
            for _ in range(num_cols):
                c = b[o:o + 25]
                cols.append({"kieu": c[0], "so": _u16(c, 5), "vi_var": _u16(c, 7), "co": c[15],
                             "co_dinh": bool(c[15] & 0x01), "vi_fix": _u16(c, 21), "dai": _u16(c, 23),
                             "scale": c[11], "prec": c[12]})
                o += 25
            for i in range(num_cols):
                n = _u16(b, o)
                o += 2
                cols[i]["ten"] = b[o:o + n].decode("utf-16-le", "replace")
                o += n
        else:
            num_rows = _u32(b, 0x0C)
            num_var, num_cols = _u16(b, 0x17), _u16(b, 0x19)
            num_ridx = _u32(b, 0x1F)
            o = 0x2B + num_ridx * 8
            for _ in range(num_cols):
                c = b[o:o + 18]
                cols.append({"kieu": c[0], "so": _u16(c, 1), "vi_var": _u16(c, 3), "co": c[13],
                             "co_dinh": bool(c[13] & 0x01), "vi_fix": _u16(c, 14), "dai": _u16(c, 16),
                             "scale": c[11], "prec": c[12]})
                o += 18
            for i in range(num_cols):
                n = b[o]
                o += 1
                cols[i]["ten"] = b[o:o + n].decode(self.cp, "replace")
                o += n
        cols.sort(key=lambda c: c["so"])
        for c in cols:
            c["tu_tang"] = bool(c["co"] & 0x04)
            c["ten_kieu"] = TEN_KIEU.get(c["kieu"], "KIEU_%d" % c["kieu"])
        td = {"trang": trang, "num_rows": num_rows, "num_var": num_var, "cols": cols}
        self._td[trang] = td
        return td

    # ------------------------------------------------------------------ trang du lieu
    def _ban_do_trang(self):
        """1 lan quet: tdef -> [trang du lieu]."""
        if self._trang_bang is not None:
            return self._trang_bang
        m = {}
        self.f.seek(0)
        for i in range(self.so_trang):
            h = self.f.read(self.ps)
            if len(h) < 8:
                break
            if h[0] == 0x01 and h[1] == 0x01 and h[4:8] != b"LVAL":
                m.setdefault(_u32(h, 4), []).append(i)
        self._trang_bang = m
        return m

    def _hang_trang(self, b):
        """[(chi so, offset)] cua trang du lieu / LVAL."""
        o = 12 if self.jet4 else 8
        n = _u16(b, o)
        return [_u16(b, o + 2 + 2 * r) for r in range(n)], o

    def _bien_hang(self, b, r):
        offs, o = self._hang_trang(b)
        if r >= len(offs):
            return None
        v = offs[r]
        start = v & 0x1FFF
        if r == 0:
            end = self.ps - 1
        else:
            end = (offs[r - 1] & 0x1FFF) - 1
        return start, end, v

    def ban_ghi_trang(self, td, pg_no):
        b = self.pg(pg_no)
        offs, _ = self._hang_trang(b)
        for r, v in enumerate(offs):
            if v & 0x8000:
                continue
            start, end, _ = self._bien_hang(b, r)
            if v & 0x4000:                      # con tro sang trang khac
                tro = _u32(b, start)
                bg = self._mot_hang(td, tro >> 8, tro & 0xFF)
                if bg is not None:
                    yield bg
                continue
            if end <= start:
                continue
            try:
                yield self._boc(td, b, start, end)
            except Exception:
                continue

    def _mot_hang(self, td, pg_no, r):
        if pg_no <= 0 or pg_no >= self.so_trang:
            return None
        b = self.pg(pg_no)
        if b[0] != 0x01:
            return None
        x = self._bien_hang(b, r)
        if not x:
            return None
        start, end, _ = x
        if end <= start:
            return None
        try:
            return self._boc(td, b, start, end)
        except Exception:
            return None

    def _boc(self, td, b, start, end):
        cols = td["cols"]
        if self.jet4:
            row_cols = _u16(b, start)
            mask_sz = (row_cols + 7) // 8
            mask = b[end - mask_sz + 1:end + 1]
            voff = []
            if td["num_var"] > 0:
                nvar = _u16(b, end - mask_sz - 1)
                for i in range(nvar + 1):
                    voff.append(_u16(b, end - mask_sz - 3 - i * 2))
            else:
                nvar = 0
            fix0 = start + 2
        else:
            row_cols = b[start]
            mask_sz = (row_cols + 7) // 8
            mask = b[end - mask_sz + 1:end + 1]
            nvar = b[end - mask_sz]
            so_nhay = (end - start) // 256
            col_ptr = end - mask_sz - so_nhay - 1
            if so_nhay and (col_ptr - start - nvar) // 256 < so_nhay:
                so_nhay -= 1
            col_ptr = end - mask_sz - so_nhay - 1
            voff = []
            da_nhay = 0
            for i in range(nvar + 1):
                while da_nhay < so_nhay and i == b[end - mask_sz - da_nhay - 1]:
                    da_nhay += 1
                voff.append(b[col_ptr - i] + da_nhay * 256)
            fix0 = start + 1
        gt = {}
        for c in cols:
            so = c["so"]
            if so >= row_cols:
                gt[c["ten"]] = None
                continue
            co = (mask[so >> 3] >> (so & 7)) & 1 if (so >> 3) < len(mask) else 0
            if c["kieu"] == T_BOOL:
                gt[c["ten"]] = bool(co)
                continue
            if not co:
                gt[c["ten"]] = None
                continue
            if c["co_dinh"]:
                gt[c["ten"]] = self._doc_fix(c, b, fix0 + c["vi_fix"])
            else:
                iv = c["vi_var"]
                if iv + 1 >= len(voff):
                    gt[c["ten"]] = None
                    continue
                a, z = voff[iv], voff[iv + 1]
                raw = b[start + a:start + z] if z >= a else b""
                if c["kieu"] == T_TEXT:
                    gt[c["ten"]] = self._text(raw)
                elif c["kieu"] in (T_MEMO, T_OLE):
                    gt[c["ten"]] = self._memo(raw, c["kieu"] == T_MEMO)
                else:
                    gt[c["ten"]] = raw
        return gt

    def _text(self, raw):
        if not self.jet4:
            return raw.decode(self.cp, "replace")
        if len(raw) >= 2 and raw[0] == 0xFF and raw[1] == 0xFE:
            out, i, nen = [], 2, True
            while i < len(raw):
                if raw[i] == 0x00:
                    nen = not nen
                    i += 1
                    continue
                if nen:
                    out.append(chr(raw[i]))
                    i += 1
                else:
                    if i + 1 >= len(raw):
                        break
                    out.append(chr(raw[i] | (raw[i + 1] << 8)))
                    i += 2
            return "".join(out)
        return raw.decode("utf-16-le", "replace")

    def _doc_fix(self, c, b, o):
        k = c["kieu"]
        try:
            if k == T_BYTE:
                return b[o]
            if k == T_INT:
                return _i16(b, o)
            if k == T_LONG:
                return struct.unpack_from("<i", b, o)[0]
            if k == T_MONEY:
                return struct.unpack_from("<q", b, o)[0] / 10000.0
            if k == T_FLOAT:
                return struct.unpack_from("<f", b, o)[0]
            if k == T_DOUBLE:
                return struct.unpack_from("<d", b, o)[0]
            if k == T_DATE:
                v = struct.unpack_from("<d", b, o)[0]
                return datetime.datetime(1899, 12, 30) + datetime.timedelta(days=v)
            if k == T_NUMERIC:
                sign = -1 if b[o] & 0x80 else 1
                return sign * int.from_bytes(b[o + 1:o + 17], "little") / (10.0 ** c.get("scale", 0))
        except Exception:
            return None
        return b[o:o + c["dai"]]

    def _lval(self, tro):
        pg_no, r = tro >> 8, tro & 0xFF
        if pg_no <= 0 or pg_no >= self.so_trang:
            return b""
        b = self.pg(pg_no)
        x = self._bien_hang(b, r)
        if not x:
            return b""
        start, end, _ = x
        return b[start:end + 1]

    def _memo(self, raw, la_chu):
        if len(raw) < 12:
            return "" if la_chu else b""
        dai = _u24(raw, 0)
        co = raw[3]
        if co & 0x80:
            data = raw[12:12 + dai]
        elif co & 0x40:
            data = self._lval(_u32(raw, 4))[:dai]
        else:
            data, tro, dem = b"", _u32(raw, 4), 0
            while tro and len(data) < dai and dem < 5000:
                seg = self._lval(tro)
                if len(seg) < 4:
                    break
                tro = _u32(seg, 0)
                data += seg[4:]
                dem += 1
            data = data[:dai]
        return self._text(data) if la_chu else data

    # ------------------------------------------------------------------ catalog
    def _doc_catalog(self):
        td = self.tdef(2)
        for pg_no in self._ban_do_trang().get(2, []):
            for r in self.ban_ghi_trang(td, pg_no):
                if r.get("Name") is None:
                    continue
                self.doi_tuong.append({k: r.get(k) for k in ("Id", "ParentId", "Name", "Type", "Flags")})

    def bang(self, he_thong=False):
        """{ten bang -> trang tdef} (bang that, Type 1). he_thong=False: bo MSys* / ~*."""
        out = {}
        for o in self.doi_tuong:
            ten = o["Name"] or ""
            if o["Type"] != 1 or not ten:
                continue
            if not he_thong and (ten.lower().startswith("msys") or ten.startswith("~") or ten.lower().startswith("usys")):
                continue
            out[ten] = (o["Id"] or 0) & 0x00FFFFFF
        return out

    def truy_van(self):
        return sorted(o["Name"] for o in self.doi_tuong if o["Type"] == 5 and o["Name"] and not o["Name"].startswith("~"))

    def bang_lien_ket(self):
        return sorted(o["Name"] for o in self.doi_tuong if o["Type"] in (4, 6) and o["Name"])

    def cot(self, ten):
        b = self.bang(True)
        k = {x.lower(): x for x in b}.get(ten.lower())
        if k is None:
            raise KeyError("Khong co bang %s" % ten)
        return self.tdef(b[k])["cols"]

    def so_ban_ghi(self, ten):
        b = self.bang(True)
        k = {x.lower(): x for x in b}.get(ten.lower())
        return self.tdef(b[k])["num_rows"] if k else None

    def doc(self, ten, toi_da=None):
        b = self.bang(True)
        k = {x.lower(): x for x in b}.get(ten.lower())
        if k is None:
            raise KeyError("Khong co bang %s" % ten)
        trang = b[k]
        td = self.tdef(trang)
        out = []
        for p in self._ban_do_trang().get(trang, []):
            for r in self.ban_ghi_trang(td, p):
                out.append(r)
                if toi_da and len(out) >= toi_da:
                    return out
        return out

    def cau_truc(self):
        """{ten bang: {ten cot: (kieu, do dai)}} cua bang nguoi dung."""
        out = {}
        for ten, trang in sorted(self.bang().items()):
            try:
                out[ten] = {c["ten"]: (c["ten_kieu"], c["dai"]) for c in self.tdef(trang)["cols"]}
            except Exception as e:
                out[ten] = {"__LOI__": (str(e), 0)}
        return out


if __name__ == "__main__":
    import sys
    m = Mdb(sys.argv[1])
    ct = m.cau_truc()
    print("%s | %s | %d bang | %d truy van" % (os.path.basename(sys.argv[1]), m.phien_ban, len(ct), len(m.truy_van())))
    for t in sys.argv[2:]:
        rs = m.doc(t, 3)
        print(t, m.so_ban_ghi(t), [c["ten"] for c in m.cot(t)][:30])
        for r in rs:
            print("  ", {k: v for k, v in list(r.items())[:12]})
