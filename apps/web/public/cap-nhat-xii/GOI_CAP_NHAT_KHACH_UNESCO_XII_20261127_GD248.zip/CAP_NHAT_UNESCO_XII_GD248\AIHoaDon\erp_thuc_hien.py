# -*- coding: utf-8 -*-
"""GD348a - SO THUC HIEN (bang ERP_THUCHIEN, GD346) -> ket qua tram ERP (erp_tram.py). Chi doc .MDB qua jet_doc, khong ghi gi.

  thuc_hien[]  (v1.1, ERP bo qua neu chua doc): moi dong ERP_THUCHIEN mot phan tu
      {khoa, nguon, khoa_nguon, nam, thang, quyet_dinh, trang_thai, ma_ct, so_ct, noi_dung, ket_qua, luc, nguoi}
      trang_thai: DA_GHI | DANG_GHI | LOI | KHONG_GHI  (KHONG_GHI = quyet dinh BO / TRUNG / DUNG, khong ghi so)
  da_sua[]     : lenh.sua[].ma (ma chung_tu_sai cua ERP) khop ERP_THUCHIEN.KhoaNguon:
      DA_GHI -> {"ma", "trang_thai": "DA_SUA", "so_ct", "ma_ct", "luc"}
      LOI / KHONG_GHI -> {"ma", "trang_thai": "KHONG_SUA", "ly_do": KetQua | NoiDung}
      khong co dong -> None (tram giu KHONG_SUA "chua ho tro" nhu cu)
  Quy uoc cho GD348 (VB6 thuc hien lenh sua): ghi ERP_THUCHIEN voi Nguon='ERP:<lenh>', KhoaNguon=<ma chung_tu_sai>,
  KhoaDeXuat='ERP|<lenh>|<bam ma>' (duy nhat -> lam lai lenh khong ghi hai lan), qua TH346_GiuCho / TH346_Xong (ModThucHien346).
"""
import datetime as _dt
import os


def _s(x):
    return str(x if x is not None else "").strip()


def _gio(t):
    if isinstance(t, _dt.datetime):
        return t.replace(microsecond=0).isoformat()
    return _s(t) or None


def doc(duong, toi_da=2000):
    """-> (thuc_hien[], loi). Khong co bang (so truoc GD346) -> ([], '')."""
    if not duong or not os.path.isfile(duong):
        return [], "không có tệp sổ"
    try:
        import jet_doc
        m = jet_doc.Mdb(duong)
    except Exception as e:
        return [], "không mở được sổ: %s" % type(e).__name__
    try:
        if "erp_thuchien" not in {k.lower() for k in m.bang()}:
            return [], ""
        out = []
        for r in m.doc("ERP_THUCHIEN", toi_da):
            tt = _s(r.get("TrangThai")).upper() or "KHONG_GHI"
            ma_ct = r.get("MaCT")
            try:
                ma_ct = int(ma_ct) if ma_ct not in (None, "") else None
            except (TypeError, ValueError):
                ma_ct = None
            out.append({"khoa": _s(r.get("KhoaDeXuat")) or None, "nguon": _s(r.get("Nguon")), "khoa_nguon": _s(r.get("KhoaNguon")),
                        "nam": r.get("Nam"), "thang": r.get("Thang"), "quyet_dinh": _s(r.get("QuyetDinh")).upper(), "trang_thai": tt,
                        "ma_ct": ma_ct, "so_ct": _s(r.get("SoHieu")) or None, "noi_dung": _s(r.get("NoiDung"))[:500],
                        "ket_qua": _s(r.get("KetQua"))[:500], "luc": _gio(r.get("NgayGhi") or r.get("NgayTao")), "nguoi": _s(r.get("NguoiDung"))})
        out.sort(key=lambda x: (x["luc"] or ""), reverse=True)
        return out, ""
    except Exception as e:
        return [], "đọc ERP_THUCHIEN lỗi: %s" % type(e).__name__
    finally:
        try:
            m.dong()
        except Exception:
            pass


def da_sua_tu(sua, thuc_hien):
    """lenh.sua[] + thuc_hien[] -> {ma: dong da_sua} (chi nhung ma co dong thuc hien). Dong moi nhat thang."""
    theo_ma = {}
    for x in thuc_hien or []:
        k = x.get("khoa_nguon")
        if k and k not in theo_ma:          # thuc_hien da sap moi nhat truoc
            theo_ma[k] = x
    out = {}
    for s in sua or []:
        ma = _s((s or {}).get("ma")) if isinstance(s, dict) else ""
        x = theo_ma.get(ma)
        if not ma or not x:
            continue
        if x["trang_thai"] == "DA_GHI":
            d = {"ma": ma, "trang_thai": "DA_SUA"}
            if x.get("so_ct"):
                d["so_ct"] = x["so_ct"]
            if x.get("ma_ct") is not None:
                d["ma_ct"] = x["ma_ct"]
            if x.get("luc"):
                d["luc"] = x["luc"]
            out[ma] = d
        elif x["trang_thai"] in ("LOI", "KHONG_GHI"):
            out[ma] = {"ma": ma, "trang_thai": "KHONG_SUA",
                       "ly_do": (x.get("ket_qua") or x.get("noi_dung") or ("quyết định " + (x.get("quyet_dinh") or "bỏ qua")))[:500]}
        # DANG_GHI: dang lam do -> khong ket luan
    return out
