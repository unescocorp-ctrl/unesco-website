# -*- coding: utf-8 -*-
"""GD235 - CONG G3 "KHOP NGOAI" (tram 3): doi chieu ba chieu hoa don <-> so phu ngan hang <-> chung tu. Chi doc.

Du lieu (VB KS235_Json trong JSON Kiem tra truoc khoa so):
  hd3 [MaCT, chieu, ngay, so HD, doi tac, tong TT, da ghi so 0/1, huy 0/1]  - hoa don trong ky
  tt3 [MaCT, ngay, tien, TK Co]                                              - phieu thanh toan HD (moi luc)
  sp3 [MaSo, ngay, vao, ra, trang thai, "MaCT;MaCT", co chung tu 0/1]       - dong so phu co lien ket HD (moi luc)
  spx [MaSo, ngay, vao, ra, noi dung, trang thai]                            - dong so phu trong ky chua xu ly
Phan bo: moi dong so phu chia tien cho cac HD lien ket theo thu tu ngay HD (cu truoc), moi HD toi da phan con lai.
K41 (LOI): HD vua co phieu thanh toan vua khop so phu (tra 2 lan); dong so phu da khop HD nhung CHUA co chung tu.
     (CANH_BAO): HD tra du > 1% / > 1.000 d; HD da thanh toan nhung chua ghi so; HD bi huy / bi thay the ma co thanh toan.
     Bang cong no theo HD: moi HD trong ky - tong, da tra (phieu / so phu), con lai, tinh trang.
K42 (CANH_BAO): dong so phu trong ky chua co HD, chua hach toan, chua bo qua (moi dong sao ke phai co HD hoac ly do).
"""
from collections import defaultdict

DUNG_SAI = 1000.0


def _so(x):
    try:
        return float(x or 0)
    except Exception:
        return 0.0


def phan_tich(dl):
    hd = {}
    for r in dl.get("hd3") or []:
        hd[str(r[0])] = {"mct": str(r[0]), "chieu": r[1], "ngay": str(r[2] or ""), "so": str(r[3] or ""), "dt": str(r[4] or ""),
                         "tong": _so(r[5]), "ghi": int(_so(r[6])), "huy": int(_so(r[7])), "tt": 0.0, "sp": 0.0, "nguon": []}
    ngay_hd = {k: v["ngay"] for k, v in hd.items()}
    phieu = defaultdict(float)
    for r in dl.get("tt3") or []:
        phieu[str(r[0])] += _so(r[2])
    sp_hd = defaultdict(float)
    sp_chua_ct, sp_du = [], []
    hai_lan = defaultdict(list)          # HD da co phieu thanh toan ma dong so phu van khop -> tra 2 lan
    for r in dl.get("sp3") or []:
        tien = _so(r[2]) or _so(r[3])
        ds = [x.strip() for x in str(r[5] or "").split(";") if x.strip()]
        ds.sort(key=lambda m: (ngay_hd.get(m) or "9999", m))
        con = tien
        for m in ds:
            if phieu.get(m, 0.0) > DUNG_SAI:
                hai_lan[m].append(r[0])
            can = (hd[m]["tong"] if m in hd else tien) - sp_hd[m] - phieu.get(m, 0.0)
            phan = min(con, max(can, 0.0)) if m in hd else con / max(len(ds), 1)
            sp_hd[m] += phan
            con -= phan
        if con > DUNG_SAI and ds and all(m in hd for m in ds):
            sp_du.append([r[0], r[1], tien, con, ";".join(ds)])
        if str(r[4] or "") != "DA_HACH_TOAN" and not int(_so(r[6])):
            sp_chua_ct.append([r[0], r[1], tien, str(r[4] or ""), ";".join(ds)])
    for m, h in hd.items():
        h["tt"] = phieu.get(m, 0.0)
        h["sp"] = sp_hd.get(m, 0.0)
        h["hai_lan"] = hai_lan.get(m, [])
    return hd, sp_chua_ct, sp_du


def tinh_trang(h):
    tra = h["tt"] + h["sp"]
    if h["huy"]:
        return "HUY_CO_TT" if tra > DUNG_SAI else "HUY"
    if tra <= DUNG_SAI:
        return "CHUA_TRA"
    if tra > h["tong"] + max(DUNG_SAI, h["tong"] * 0.01):
        return "TRA_DU"
    if tra >= h["tong"] - DUNG_SAI:
        return "DA_TRA"
    return "MOT_PHAN"


TEN_TT = {"CHUA_TRA": "Chưa thanh toán", "DA_TRA": "Đã thanh toán đủ", "MOT_PHAN": "Thanh toán một phần", "TRA_DU": "Trả dư",
          "HUY": "Bị hủy / thay thế", "HUY_CO_TT": "Bị hủy / thay thế nhưng CÓ thanh toán"}


def k_ba_chieu(S, _kq, DAT, CANH_BAO, LOI, THONG_TIN):
    dl = S.dl
    if "hd3" not in dl:
        return [_kq("K41", "Đối chiếu hóa đơn - sổ phụ - chứng từ", THONG_TIN, "Bản phần mềm chưa gửi số liệu đối chiếu ba chiều (cần bản GĐ235).")]
    hd, sp_chua_ct, sp_du = phan_tich(dl)
    loi, cb = [], []
    for m, h in sorted(hd.items(), key=lambda x: (x[1]["ngay"], x[0])):
        t = tinh_trang(h)
        dong = [h["ngay"], h["chieu"], h["so"], h["dt"], h["tong"], h["tt"], h["sp"], h["tong"] - h["tt"] - h["sp"], TEN_TT[t]]
        if h["hai_lan"]:
            loi.append(dong + ["Đã có phiếu thanh toán mà dòng sổ phụ %s vẫn khớp hóa đơn này: trả 2 lần trên sổ - hủy một bút toán"
                               % ", ".join(str(x) for x in h["hai_lan"])])
        elif t == "HUY_CO_TT":
            cb.append(dong + ["Hóa đơn bị hủy / thay thế nhưng có thanh toán: chuyển thanh toán sang hóa đơn thay thế"])
        elif t == "TRA_DU":
            cb.append(dong + ["Trả dư so với hóa đơn: kiểm tra trả gộp / ứng trước"])
        elif t in ("DA_TRA", "MOT_PHAN") and not h["ghi"]:
            cb.append(dong + ["Đã thanh toán nhưng hóa đơn chưa ghi sổ"])
    for r in sp_chua_ct:
        loi.append([r[1], "", "", "", "", "", r[2], "", "Sổ phụ đã khớp HĐ", "Dòng sổ phụ %s (%s) đã khớp hóa đơn %s nhưng CHƯA có chứng từ" % (r[0], r[3] or "?", r[4])])
    for r in sp_du:
        cb.append([r[1], "", "", "", "", "", r[2], -r[3], "Sổ phụ dư", "Dòng sổ phụ %s còn dư %s sau khi trừ các hóa đơn %s (trả gộp / ứng trước?)" % (r[0], "{:,.0f}".format(r[3]), r[4])])
    cot = ["Ngày", "Chiều", "Số HĐ", "Đối tác", "Tổng TT", "Phiếu thanh toán", "Sổ phụ", "Còn lại", "Tình trạng", "Nhận xét"]
    dem = defaultdict(int)
    for h in hd.values():
        dem[tinh_trang(h)] += 1
    tom = ", ".join("%s %d" % (TEN_TT[k], v) for k, v in sorted(dem.items()))
    bang = [[h["ngay"], h["chieu"], h["so"], h["dt"], h["tong"], h["tt"], h["sp"], h["tong"] - h["tt"] - h["sp"], TEN_TT[tinh_trang(h)], ""]
            for m, h in sorted(hd.items(), key=lambda x: (x[1]["dt"], x[1]["ngay"]))]
    kq = []
    ten = "Đối chiếu hóa đơn - sổ phụ - chứng từ (công nợ theo hóa đơn)"
    if loi:
        kq.append(_kq("K41", ten, LOI, "%d lỗi khớp ba chiều (trả 2 lần / sổ phụ khớp HĐ chưa có chứng từ), %d cần xem. %s." % (len(loi), len(cb), tom),
                      cot, loi + cb + [[""] * 10] + bang))
    elif cb:
        kq.append(_kq("K41", ten, CANH_BAO, "%d hóa đơn / dòng sổ phụ cần xem. %s." % (len(cb), tom), cot, cb + [[""] * 10] + bang))
    else:
        kq.append(_kq("K41", ten, DAT, "%d hóa đơn trong kỳ: %s." % (len(hd), tom or "không có"), cot, bang))
    spx = dl.get("spx") or []
    ten2 = "Dòng sổ phụ trong kỳ chưa xử lý (chưa có hóa đơn / chứng từ / lý do)"
    if spx:
        kq.append(_kq("K42", ten2, CANH_BAO, "%d dòng sổ phụ trong kỳ chưa khớp hóa đơn, chưa hạch toán, chưa đánh dấu bỏ qua%s: "
                      "mỗi dòng sao kê phải có chứng từ hoặc lý do." % (len(spx), " (chỉ hiện 500 dòng đầu)" if len(spx) >= 500 else ""),
                      ["Mã dòng", "Ngày", "Tiền vào", "Tiền ra", "Nội dung", "Trạng thái"], [list(r) for r in spx]))
    else:
        kq.append(_kq("K42", ten2, DAT, "Mọi dòng sổ phụ trong kỳ đã có hóa đơn, chứng từ hoặc lý do bỏ qua."))
    return kq
