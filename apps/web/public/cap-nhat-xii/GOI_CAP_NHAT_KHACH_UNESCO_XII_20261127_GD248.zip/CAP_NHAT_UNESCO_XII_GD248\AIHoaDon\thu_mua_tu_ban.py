# -*- coding: utf-8 -*-
"""GD220 - Lap thu mua (khong hoa don) tu hang xuat ban: ke hoach mua theo nguoi / ngay / mat hang + bang ke 02/TNDN.

Phan mem KHONG tao nguoi ban hay giao dich: nguoi dung chon nguoi ban (da co trong danh muc, co dinh danh) cho tung mat hang, gia mua
(gia thuc te hoac ty le % gia ban) va so ngay duoc mua truoc. Thuat toan chi PHAN BO so luong hang da xuat ban vao cac ngay mua:

  * nhu cau mua cua mot mat hang trong ngay D = so luong xuat kho ngay D tru ton kho hien co (ton dau ky + hang da mua / da nhap truoc do);
  * hang mua duoc xep vao ngay D, neu het tran thi lui dan den D - N (N = 1..7 ngay), uu tien ngay gan ngay ban;
  * moi (nguoi ban, ngay) tong tien KHONG vuot tran (mac dinh 4.999.999 d: tu 5 trieu/ngay/nguoi ban phai thanh toan khong dung tien mat);
  * khong du nguoi / ngay trong tran -> bao THIEU (khong pha tran, khong tu them nguoi ban);
  * phieu nhap da co (nhap tay) duoc tinh la nguon hang va chiem tran, nen chay lai chi lap phan con thieu.

Du lieu vao (JSON UTF-8 do VB6 ghi): ky {tu,den dd/mm/yyyy}, cty, nguoi_ky, tham_so {truoc, tran, lam_tron_gia},
vt [[ma, sohieu, ten, dvt, tk_kho, ton_dau, che_do (T|L|A), gia_tt, ty_le, [ma_kh,...], so_ngay_mua_truoc (tuy chon, 0..31)]], nb [[ma_kh, sohieu, ten, dia_chi, dinh_danh]],
xuat [[ngay, ma_vt, sl]], ban [[ngay, ma_vt, sl, tien]], pn [[ngay, ma_vt, sl, tien, so_ct, dien_giai, ma_kh]].
Ket qua: tep van ban ASCII (cho VB6): dong 'L;ngay;ma_kh;ma_vt;sl;gia;tien;ngay_ban', 'W;...' canh bao, 'S;...' tong hop."""
import datetime
import json
import math
import os
import re
from collections import defaultdict

TRAN_MAC_DINH = 4999999
EPS = 1e-9


def _so(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return 0.0


def _ngay(s):
    m = re.match(r"\s*(\d{1,2})/(\d{1,2})/(\d{4})", str(s or ""))
    if not m:
        return None
    try:
        return datetime.date(int(m.group(3)), int(m.group(2)), int(m.group(1)))
    except ValueError:
        return None


def _dmy(d):
    return d.strftime("%d/%m/%Y")


def _so_le(*ds):
    """so chu so thap phan toi da (0..3) cua cac so luong -> buoc phan bo."""
    k = 0
    for x in ds:
        s = ("%.4f" % _so(x)).rstrip("0")
        if "." in s:
            k = max(k, len(s.split(".")[1]))
    return min(k, 3)


def gia_mua(v, gia_ban_bq, lam_tron):
    """-> (gia, che_do_thuc_dung, ghi_chu). che_do T = gia thuc te, L = ty le % gia ban, A = tu chon (co gia thuc te thi dung)."""
    che = (v.get("che_do") or "A").upper()
    gia_tt, ty = _so(v.get("gia_tt")), _so(v.get("ty_le"))
    if che == "A":
        che = "T" if gia_tt > 0 else "L"
    if che == "T":
        if gia_tt > 0:
            return float(round(gia_tt)), "T", ""
        return 0.0, "T", "chua nhap gia mua thuc te"
    if ty <= 0:
        return 0.0, "L", "chua nhap ty le %"
    if gia_ban_bq <= 0:
        return 0.0, "L", "khong co hang ban ra trong ky de tinh gia ban binh quan"
    g = gia_ban_bq * ty / 100.0
    if lam_tron and lam_tron > 1:
        g = round(g / lam_tron) * lam_tron
    return float(round(g)), "L", ""


def lap_ke_hoach(dl):
    ts = dl.get("tham_so") or {}
    truoc = max(0, min(60, int(_so(ts.get("truoc", 7)))))          # GD224: nguoi dung tu nhap 0..60
    tran = _so(ts.get("tran")) or float(TRAN_MAC_DINH)
    lam_tron = _so(ts.get("lam_tron_gia", 1000))
    ky = dl.get("ky") or {}
    d1, d2 = _ngay(ky.get("tu")), _ngay(ky.get("den"))
    if not d1 or not d2 or d2 < d1:
        raise ValueError("ky khong hop le")
    nb = {int(_so(r[0])): dict(ma=int(_so(r[0])), sohieu=str(r[1] or ""), ten=str(r[2] or ""), dia_chi=str(r[3] or ""), dinh_danh=str(r[4] or ""), tel=(str(r[5] or "") if len(r) > 5 else ""))
          for r in dl.get("nb") or []}
    cccd_nb = {}
    for k, v in nb.items():
        d = re.sub(r"\D", "", v["dinh_danh"])
        if len(d) >= 9:
            cccd_nb[d] = k
    vts = {}
    for r in dl.get("vt") or []:
        r = list(r) + [None] * (11 - len(r))
        vts[int(_so(r[0]))] = dict(ma=int(_so(r[0])), sohieu=str(r[1] or ""), ten=str(r[2] or ""), dvt=str(r[3] or ""), tk=str(r[4] or ""),
                                   ton_dau=_so(r[5]), che_do=str(r[6] or "A"), gia_tt=_so(r[7]), ty_le=_so(r[8]),
                                   nb=[int(_so(x)) for x in (r[9] or []) if int(_so(x)) > 0],
                                   truoc=(max(0, min(60, int(_so(r[10])))) if r[10] not in (None, "") else None))
    ban_sl, ban_tien = defaultdict(float), defaultdict(float)
    for r in dl.get("ban") or []:
        ma = int(_so(r[1]))
        ban_sl[ma] += _so(r[2])
        ban_tien[ma] += _so(r[3])
    xuat = defaultdict(lambda: defaultdict(float))
    for r in dl.get("xuat") or []:
        d = _ngay(r[0])
        if d:                                       # chung tu ghi dau thang sau (vd xuat NVL san xuat) van thuoc ky -> ke vao ngay cuoi ky
            d = min(max(d, d1), d2)
            xuat[int(_so(r[1]))][d] += _so(r[2])
    pn_vao = defaultdict(lambda: defaultdict(float))
    dung = defaultdict(float)                       # (ma_kh, ngay) -> tien da dung (phieu cu + phan bo moi)
    pn_la = 0
    for r in dl.get("pn") or []:
        r = list(r) + [None] * (7 - len(r))
        d = _ngay(r[0])
        if not d:
            continue
        ma_vt = int(_so(r[1]))
        pn_vao[ma_vt][d] += _so(r[2])
        pn_la += 1
        kh = int(_so(r[6]))
        if not kh:
            m = re.findall(r"\d{12}|\d{9,11}", str(r[5] or ""))
            kh = next((cccd_nb[x] for x in m if x in cccd_nb), 0)
        if kh:
            dung[(kh, d)] += _so(r[3])
    dong, canh_bao, gia_ghi = [], [], {}
    for ma in sorted(vts):
        v = vts[ma]
        if not v["nb"]:
            # GD220b: mat hang xuat vuot ton nhung CHUA chon nguoi ban -> phai bao (ton kho se am), khong bo qua im lang
            ton0, thieu_tong, ngay_dau = v["ton_dau"], 0.0, ""
            for d in sorted(set(xuat[ma]) | set(pn_vao[ma])):
                ton0 += pn_vao[ma].get(d, 0.0)
                can0 = xuat[ma].get(d, 0.0)
                if ton0 + EPS >= can0:
                    ton0 -= can0
                    continue
                thieu_tong += can0 - ton0
                ton0 = 0.0
                if not ngay_dau:
                    ngay_dau = _dmy(d)
            if thieu_tong > EPS:
                canh_bao.append(("CHUA_NB", ma, ngay_dau, round(thieu_tong, 3), "Mat hang %s: xuat vuot ton (thieu %s %s, tu ngay %s) nhung CHUA chon nguoi ban nen khong lap nhap duoc - ton kho se AM." % (v["sohieu"], round(thieu_tong, 3), v["dvt"], ngay_dau)))
            continue
        ban_bq = (ban_tien[ma] / ban_sl[ma]) if ban_sl[ma] > EPS else 0.0
        gia, che, gc = gia_mua(v, ban_bq, lam_tron)
        gia_ghi[ma] = dict(gia=gia, che=che, ban_bq=ban_bq)
        if gia <= 0:
            canh_bao.append(("GIA", ma, "", 0.0, "Mat hang %s: %s" % (v["sohieu"], gc)))
            continue
        for k in v["nb"]:
            if k not in nb:
                canh_bao.append(("NB", ma, "", 0.0, "Nguoi ban ma %d khong co trong danh muc" % k))
        buoc = 10.0 ** (-_so_le(*(list(xuat[ma].values()) + list(pn_vao[ma].values()))))
        ngay_co = sorted(set(xuat[ma]) | set(pn_vao[ma]))
        cua_so = v["truoc"] if v["truoc"] is not None else truoc
        ton = v["ton_dau"]
        for d in ngay_co:
            ton += pn_vao[ma].get(d, 0.0)
            can = xuat[ma].get(d, 0.0)
            if ton + EPS >= can:
                ton -= can
                continue
            thieu = round(can - ton, 3)
            ton = 0.0
            for k in range(0, cua_so + 1):
                dd = d - datetime.timedelta(days=k)
                if dd < d1:
                    break
                for kh in v["nb"]:
                    if thieu <= EPS or kh not in nb:
                        continue
                    con = tran - dung[(kh, dd)]
                    if con < gia * buoc:
                        continue
                    q = min(thieu, math.floor(con / gia / buoc + EPS) * buoc)
                    q = round(q, 3)
                    while q > 0 and round(q * gia) > con + EPS:
                        q = round(q - buoc, 3)
                    if q <= EPS:
                        continue
                    tien = float(round(q * gia))
                    dung[(kh, dd)] += tien
                    thieu = round(thieu - q, 3)
                    dong.append(dict(ngay=dd, kh=kh, vt=ma, sl=q, gia=gia, tien=tien, ban=d))
            if thieu > EPS:
                canh_bao.append(("THIEU", ma, _dmy(d), thieu, "Mat hang %s ngay ban %s: thieu %s %s (het tran %s d/ngay/nguoi trong %d ngay truoc). "
                                 "Them nguoi ban, tang so ngay mua truoc hoac chia lai mat hang." % (v["sohieu"], _dmy(d), thieu, v["dvt"], int(tran), cua_so)))
    # gop dong cung (ngay, nguoi, mat hang)
    g = {}
    for x in dong:
        k = (x["ngay"], x["kh"], x["vt"])
        if k in g:
            g[k]["sl"] = round(g[k]["sl"] + x["sl"], 3)
            g[k]["tien"] += x["tien"]
            g[k]["ban"] = max(g[k]["ban"], x["ban"])
        else:
            g[k] = dict(x)
    ds = sorted(g.values(), key=lambda x: (x["ngay"], x["kh"], x["vt"]))
    return dict(dong=ds, canh_bao=canh_bao, gia=gia_ghi, nb=nb, vt=vts, d1=d1, d2=d2, tran=tran, truoc=truoc, pn_cu=pn_la, dung=dict(dung))


def ghi_van_ban(kq, duong):
    """Tep ASCII cho VB6: OK / LOI ; L ; W ; S."""
    d = ["OK"]
    for x in kq["dong"]:
        d.append("L;%s;%d;%d;%s;%d;%d;%s" % (_dmy(x["ngay"]), x["kh"], x["vt"], ("%.3f" % x["sl"]).rstrip("0").rstrip("."), round(x["gia"]), round(x["tien"]), _dmy(x["ban"])))
    for loai, ma, ngay, sl, nd in kq["canh_bao"]:
        d.append("W;%s;%d;%s;%s" % (loai, ma, ngay, ("%.3f" % sl).rstrip("0").rstrip(".") or "0"))
    tong = sum(x["tien"] for x in kq["dong"])
    d.append("S;dong;%d" % len(kq["dong"]))
    d.append("S;tien;%d" % round(tong))
    d.append("S;pn_cu;%d" % kq["pn_cu"])
    with open(duong, "w", encoding="ascii") as f:
        f.write("\n".join(d) + "\n")


# ====================================================================== Excel
def _tao_dl_bang_ke(dl, kq, loc_kh=None):
    """dl o dang 'bao_cao_bo_sung' (thu_mua, dt, dt_dc, ban_ra) tu ke hoach."""
    ds = [x for x in kq["dong"] if loc_kh is None or x["kh"] == loc_kh]
    thu_mua = []
    for x in ds:
        v = kq["vt"][x["vt"]]
        thu_mua.append([_dmy(x["ngay"]), "", x["kh"], v["sohieu"], v["ten"], v["dvt"], x["sl"], x["tien"], v["tk"] or "1561", "1111",
                        "Mua cua nguoi dan - phuc vu hang ban ngay %s" % _dmy(x["ban"])])
    out = dict(ky=dl.get("ky"), cty=dl.get("cty"), nguoi_ky=dl.get("nguoi_ky") or {}, thu_mua=thu_mua,
               dt=[[k, v["sohieu"], v["ten"], v["dinh_danh"]] for k, v in kq["nb"].items()],
               dt_dc=[[k, v["dia_chi"]] for k, v in kq["nb"].items()], dt_tel=[[k, v.get("tel", "")] for k, v in kq["nb"].items()], tra_nb=[], ban_ra=[])
    xs = defaultdict(float)
    for r in dl.get("xuat") or []:
        xs[int(_so(r[1]))] += _so(r[2])
    for ma, v in kq["vt"].items():
        if xs.get(ma):
            out["ban_ra"].append([v["sohieu"], v["ten"], xs[ma]])
    return out


def _ten_sheet(s, dung):
    s = re.sub(r"[\\/*?:\[\]]", " ", s).strip()[:25] or "NB"
    t, i = s, 2
    while t in dung:
        t = "%s %d" % (s[:22], i)
        i += 1
    dung.add(t)
    return t


def lap_excel(dl, kq, ra):
    import bao_cao_bo_sung as B
    import tool_htkk_unesco as X

    class Mini(object):
        pass

    def mini(d):
        S = Mini()
        S.dl = d
        S.nguoi_ky = d.get("nguoi_ky") or {}
        S.dt = {int(_so(r[0])): [str(r[1] or ""), str(r[2] or ""), str(r[3] or "")] for r in d.get("dt") or []}
        S.dt_dc = {int(_so(r[0])): str(r[1] or "") for r in d.get("dt_dc") or []}
        S.dt_tel = {int(_so(r[0])): str(r[1] or "") for r in d.get("dt_tel") or []}
        return S

    sheets = []
    dung = set()
    d0 = _tao_dl_bang_ke(dl, kq)
    s0 = mini(d0)
    s = B.sheet_thu_mua(s0, X)
    sheets.append((_ten_sheet("02-TNDN tong hop", dung),) + tuple(s[1:]))
    for k in sorted({x["kh"] for x in kq["dong"]}, key=lambda k: kq["nb"].get(k, {}).get("ten", "")):
        s = B.sheet_thu_mua(mini(_tao_dl_bang_ke(dl, kq, k)), X)
        sheets.append((_ten_sheet("NB " + (kq["nb"].get(k, {}).get("ten") or str(k)), dung),) + tuple(s[1:]))
    # --- ke hoach theo ngay / nguoi
    T = B._dau(s0, X, "KẾ HOẠCH MUA THEO NGÀY VÀ NGƯỜI BÁN (trần %s đồng/ngày/người)" % B._dd(round(kq["tran"])))
    T.append([(c, X.X_TIEUDE) for c in ("Ngày mua", "Người bán", "Mặt hàng", "Số lượng", "Đơn giá", "Thành tiền", "Phục vụ hàng bán ngày", "Tổng trong ngày của người bán", "Trần")])
    dong_bang = len(T)
    tong_ngay = defaultdict(float)
    for x in kq["dong"]:
        tong_ngay[(x["ngay"], x["kh"])] += x["tien"]
    for x in kq["dong"]:
        v, n = kq["vt"][x["vt"]], kq["nb"].get(x["kh"], {})
        t = kq["dung"].get((x["kh"], x["ngay"]), tong_ngay[(x["ngay"], x["kh"])])
        k = X.X_XANH if t <= kq["tran"] + EPS else X.X_DO
        T.append([(_dmy(x["ngay"]), X.X_CHU), (n.get("ten", ""), X.X_CHU), (v["ten"], X.X_CHU), (x["sl"], X.X_SO), (round(x["gia"]), X.X_SO), (round(x["tien"]), X.X_SO),
                  (_dmy(x["ban"]), X.X_CHU), (round(t), X.X_SO), ("Đạt" if t <= kq["tran"] + EPS else "VƯỢT TRẦN", k)])
    sheets.append((_ten_sheet("Ke hoach theo ngay", dung), [12, 28, 30, 11, 13, 16, 16, 18, 12], T, dong_bang))
    # --- gia mua / ty le
    T = B._dau(s0, X, "GIÁ MUA VÀ TỶ LỆ SO VỚI GIÁ BÁN BÌNH QUÂN")
    T.append([(c, X.X_TIEUDE) for c in ("Mặt hàng", "ĐVT", "Cách tính giá", "Giá bán bình quân", "Giá mua", "Tỷ lệ mua/bán %", "SL mua theo kế hoạch", "Tiền mua")])
    dong_bang = len(T)
    sl, tien = defaultdict(float), defaultdict(float)
    for x in kq["dong"]:
        sl[x["vt"]] += x["sl"]
        tien[x["vt"]] += x["tien"]
    for ma, g in sorted(kq["gia"].items()):
        v = kq["vt"][ma]
        ty = (100.0 * g["gia"] / g["ban_bq"]) if g["ban_bq"] > 0 else 0.0
        T.append([(v["ten"], X.X_CHU), (v["dvt"], X.X_CHU), ("Giá thực tế" if g["che"] == "T" else "Tỷ lệ % giá bán", X.X_CHU), (round(g["ban_bq"]), X.X_SO),
                  (round(g["gia"]), X.X_SO), (round(ty, 2), X.X_SO), (sl.get(ma, 0.0), X.X_SO), (round(tien.get(ma, 0.0)), X.X_SO)])
    sheets.append((_ten_sheet("Gia mua va ty le", dung), [30, 8, 20, 18, 14, 16, 18, 18], T, dong_bang))
    # --- kiem tra
    T = B._dau(s0, X, "KIỂM TRA KẾ HOẠCH THU MUA")
    T.append([(c, X.X_TIEUDE) for c in ("Mức", "Nội dung")])
    dong_bang = len(T)
    nd = {"THIEU": "Thiếu nguồn mua", "GIA": "Chưa có giá mua", "NB": "Người bán"}
    for loai, ma, ngay, slx, mo_ta in kq["canh_bao"]:
        T.append([("Chưa đạt", X.X_DO), ("%s: %s" % (nd.get(loai, loai), mo_ta), X.X_DO)])
    for m, nb_, nd_ in B.thu_mua_kiem_tra(B.thu_mua_dong(s0), {}):
        k = X.X_DO if m == "DO" else X.X_VANG
        T.append([("Chưa đủ điều kiện" if m == "DO" else "Cần xem lại", k), ("%s: %s" % (nb_, nd_), k)])
    if len(T) == dong_bang:
        T.append([("Đạt", X.X_XANH), ("Kế hoạch đủ nguồn mua, không vượt trần, người bán đủ tên, địa chỉ, số định danh.", X.X_XANH)])
    sheets.append((_ten_sheet("Kiem tra", dung), [18, 150], T, dong_bang))
    sheets.append(B.sheet_thu_mua_ban_ra(s0, X))
    os.makedirs(os.path.dirname(os.path.abspath(ra)), exist_ok=True)
    X.viet_xlsx_o(ra, sheets)
    return ra


def chay(duong_json, ra_txt, ra_xlsx=""):
    with open(duong_json, "r", encoding="utf-8-sig") as f:
        dl = json.loads(f.read(), strict=False)
    kq = lap_ke_hoach(dl)
    ghi_van_ban(kq, ra_txt)
    if ra_xlsx:
        lap_excel(dl, kq, ra_xlsx)
    return kq
