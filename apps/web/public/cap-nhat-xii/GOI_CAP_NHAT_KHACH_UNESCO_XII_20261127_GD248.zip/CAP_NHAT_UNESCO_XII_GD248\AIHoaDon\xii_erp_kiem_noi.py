# -*- coding: utf-8 -*-
"""UNESCO XII - KIEM NOI ERP (TASK369, theo XI GD348d erp_kiem_noi.py): mot lenh kiem toan bo duong noi ERP_ANHMAI <-> tram UNESCO XII truoc khi
chay that. Chi doc so (ban chup SELECT cua xii_chup_so.ps1), khong ghi so, khong gui gi len ERP.

XI erp_kiem_noi.py tim so .MDB trong thu muc DATA; so XII la CSDL SQL Server nen tep XI khong chep sang. Sau muc giong XI:
  (1) xii_erp_tram.json doc duoc, co "lenh"; (2) hop thu LENH\\ du thu muc, ghi / doi ten duoc, tram nao bao song, tram ghi XII co bat;
  (3) bookbridge.json (neu chi) cung lenhRoot; (4) ho_so\\<CSDL>.json: ten la ten CSDL XII hop le, so chon chup duoc tu may chu SQL, nam / che do;
  (5) chay thu MOT lenh kiem_tra + doi_chieu + sua_chung_tu trong hop thu TAM (ket-qua\\erp_kiem_noi\\, cau noi khong thay) -> ket qua qua
  erp_khuon.kiem_ket_qua; (6) sua[] / bo_qua[] gia -> dong Hang doi viec (xii_erp_viec = erp_viec cua XI) va erp_bo_qua.txt.

  python xii_erp_kiem_noi.py /cau_hinh:"<xii_erp_tram.json>" /so:"<TEN_CSDL>" [/bookbridge:"<bookbridge.json>"] [/ra:"<bao cao .txt>"] [/may_chu:".\\SQLEXPRESS"]
  (Tools\\TramErpXii\\KIEM_NOI_ERP_XII.cmd). Bao cao tieng Viet, ma thoat 0 = dat.
"""
import datetime as _dt
import io
import json
import os
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import xii_erp_tram as X  # noqa: E402  (cai ban chup SQL va thay tim_so / lam_lenh cua erp_tram)

ET = X.T
KH = X.KH


class BC(object):
    def __init__(self):
        self.dong = []
        self.loi = 0
        self.canh_bao = 0

    def ok(self, s):
        self.dong.append("  [DAT] " + s)

    def cb(self, s):
        self.canh_bao += 1
        self.dong.append("  [CANH BAO] " + s)

    def hong(self, s):
        self.loi += 1
        self.dong.append("  [LOI] " + s)

    def muc(self, s):
        self.dong.append("")
        self.dong.append(s)


def doc_json(p):
    with io.open(p, "r", encoding="utf-8-sig") as f:
        return json.load(f)


def kiem_thu_muc_ghi(bc, d, ten):
    """ghi tep .tmp roi doi ten (cach tram / cau noi dung)."""
    try:
        t1 = os.path.join(d, "_kiem_noi.tmp")
        t2 = os.path.join(d, "_kiem_noi.ok")
        with io.open(t1, "w", encoding="utf-8") as f:
            f.write("x")
        os.replace(t1, t2)
        os.remove(t2)
        bc.ok("%s: ghi / đổi tên / xoá được" % ten)
        return True
    except OSError as e:
        bc.hong("%s: không ghi được (%s) - kiểm quyền NTFS cho tài khoản chạy trạm" % (ten, type(e).__name__))
        return False


def chay(t):
    bc = BC()
    if t.get("may_chu"):
        X.MAY_CHU[0] = t["may_chu"]
    bc.muc("1. Cấu hình trạm (xii_erp_tram.json)")
    p_ch = t.get("cau_hinh") or os.path.join(HERE, "xii_erp_tram.json")
    if not os.path.isfile(p_ch):
        bc.hong("không có %s - chép xii_erp_tram.example.json thành xii_erp_tram.json, sửa \"lenh\" (= lenhRoot của cầu nối), \"data\" (thư mục tạm cho bản chụp sổ) và \"may_chu_sql\"" % p_ch)
        return bc, None
    try:
        tho = doc_json(p_ch)
        if tho.get("may_chu_sql") and not t.get("may_chu"):
            X.MAY_CHU[0] = str(tho["may_chu_sql"])
        ch = ET.doc_cau_hinh(p_ch)
        bc.ok("đọc được: trạm %s, hộp thư %s, thư mục bản chụp %s, máy chủ SQL %s" % (ch.tram, ch.lenh, ch.data, X.MAY_CHU[0]))
    except Exception as e:
        bc.hong("xii_erp_tram.json hỏng: %s" % e)
        return bc, None

    bc.muc("2. Hộp thư LENH\\ (%s)" % ch.lenh)
    if not os.path.isdir(ch.lenh):
        bc.hong("thư mục hộp thư không tồn tại - tạo thư mục hoặc sửa \"lenh\"")
    else:
        thieu = [x for x in ET.THU_MUC if not os.path.isdir(ch.tm(x))]
        if thieu:
            bc.cb("thiếu thư mục con %s - trạm sẽ tự tạo khi chạy (cầu nối cần cho\\ và ho_so\\)" % ", ".join(thieu))
        else:
            bc.ok("đủ thư mục con: " + ", ".join(ET.THU_MUC))
        for x in ("cho", "ket_qua", "tram"):
            if os.path.isdir(ch.tm(x)):
                kiem_thu_muc_ghi(bc, ch.tm(x), x + "\\")
        n_cho = len([x for x in os.listdir(ch.tm("cho")) if x.lower().endswith(".json")]) if os.path.isdir(ch.tm("cho")) else 0
        n_kq = len([x for x in os.listdir(ch.tm("ket_qua")) if x.lower().endswith(".ket_qua.json")]) if os.path.isdir(ch.tm("ket_qua")) else 0
        n_tc = len(os.listdir(ch.tm("ket_qua", "bi_tu_choi"))) if os.path.isdir(ch.tm("ket_qua", "bi_tu_choi")) else 0
        bc.ok("đang chờ %d lệnh; %d kết quả chưa được cầu nối gửi; %d tệp bị ERP từ chối" % (n_cho, n_kq, n_tc))
        if n_tc:
            bc.cb("có tệp trong ket_qua\\bi_tu_choi - mở xem lý do ERP từ chối (sai khuôn)")
        tram_dir = ch.tm("tram")
        if os.path.isdir(tram_dir):
            for f in os.listdir(tram_dir):
                if f.lower().endswith(".json"):
                    try:
                        d = doc_json(os.path.join(tram_dir, f))
                        luc = KH.doc_gio(d.get("luc"))
                        tuoi = (_dt.datetime.now().astimezone() - luc).total_seconds() / 60 if luc else None
                        bc.ok("trạm %s báo sống %s phút trước (máy %s)" % (d.get("tram"), "%.0f" % tuoi if tuoi is not None else "?", d.get("may")))
                    except Exception:
                        bc.cb("tệp báo sống %s không đọc được" % f)
    try:
        if ET.vb_dang_song(ch):
            bc.ok("trạm ghi của UNESCO XII đang bật (LENH\\tram\\vb\\song.txt) - các bước ghi (phân tích, ghi trong ngưỡng, chuỗi tháng) sẽ được làm")
        else:
            bc.cb("trạm ghi của UNESCO XII chưa bật (AI > Hệ thống AI > Trạm ERP) - lệnh chỉ làm kiểm tra / đối chiếu / sửa chứng từ; bước ghi BO_QUA")
    except Exception:
        pass

    bc.muc("3. Cầu nối ERP (bookbridge.json)")
    p_bb = t.get("bookbridge")
    if not p_bb:
        bc.cb("không chỉ /bookbridge: - bỏ qua so sánh lenhRoot (tệp bookbridge.json cạnh AnhMai.Erp.BookBridge.exe trên máy chủ)")
    elif not os.path.isfile(p_bb):
        bc.hong("không thấy %s" % p_bb)
    else:
        try:
            bb = doc_json(p_bb)
            root = os.path.normpath(str(bb.get("lenhRoot") or ""))
            if root.lower() == os.path.normpath(ch.lenh).lower():
                bc.ok("lenhRoot của cầu nối trùng hộp thư trạm: %s" % root)
            else:
                bc.hong("lenhRoot cầu nối (%s) KHÁC hộp thư trạm (%s) - hai bên không thấy nhau" % (root, ch.lenh))
            api = str(bb.get("apiBaseUrl") or "")
            if api.startswith("http://") and "127.0.0.1" not in api and "localhost" not in api:
                bc.cb("apiBaseUrl %s là http tới máy khác - SDK ERP yêu cầu HTTPS khi khác máy" % api)
            else:
                bc.ok("apiBaseUrl %s, poll %s giây" % (api, bb.get("pollSeconds")))
        except Exception as e:
            bc.hong("bookbridge.json hỏng: %s" % e)

    bc.muc("4. Hồ sơ khách ERP giao xuống và sổ SQL Server")
    ten_chon = (t.get("so") or "").strip()
    hs_dir = ch.tm("ho_so")
    ten_hs = []
    if os.path.isdir(hs_dir):
        for f in sorted(os.listdir(hs_dir)):
            if not f.lower().endswith(".json"):
                continue
            ten = f[:-5]
            ten_hs.append(ten)
            try:
                hs = doc_json(os.path.join(hs_dir, f))
            except Exception:
                bc.cb("hồ sơ %s không đọc được" % f)
                continue
            if hs.get("phien_ban_khuon") != 1:
                bc.cb("hồ sơ %s không phải khuôn v1" % f)
            if not X.RE_DB.match(ten):
                bc.cb("hồ sơ %s: tên sổ không phải tên CSDL XII (ERP phải ghép sổ bằng tên CSDL, BookFile.FileName = tên CSDL)" % f)
    if ten_hs:
        bc.ok("%d hồ sơ khách trong ho_so\\" % len(ten_hs))
    else:
        bc.cb("ho_so\\ trống - cầu nối chưa ghi hồ sơ khách (ERP 'Ghép khách - sổ'); trạm ghi không ghi sổ khi chưa có hồ sơ")
    if not ten_chon:
        ten_chon = next((x for x in ten_hs if X.RE_DB.match(x)), "")
    so_chon = None
    if not ten_chon:
        bc.hong("chưa chỉ sổ để chạy thử (/so:\"<TEN_CSDL>\") và ho_so\\ không có tên CSDL nào")
    else:
        tam_chup = os.path.join(HERE, "ket-qua", "erp_kiem_noi_chup")
        so_chon, loi_so = X.tim_so(tam_chup, ten_chon)
        if loi_so:
            bc.hong(loi_so)
            so_chon = None
        else:
            bc.ok("chụp được sổ %s từ máy chủ %s (chỉ đọc)" % (ten_chon, X.MAY_CHU[0]))
            X._xoa(so_chon)                                   # ban chup chua ca so: khong de lai
        hs = ET.doc_ho_so(ch, ten_chon)
        if hs:
            bc.ok("hồ sơ của %s: năm TC %s, thông tư %s, nhóm %s, bộ quy tắc %s" % (ten_chon, hs.get("nam_tc"), hs.get("thong_tu"), hs.get("nhom"), hs.get("bo_quy_tac")))
        elif ten_hs:
            bc.cb("sổ %s chưa có hồ sơ ERP (ho_so\\%s.json)" % (ten_chon, ten_chon))

    bc.muc("5. Chạy thử một lệnh kiem_tra + doi_chieu + sua_chung_tu (hộp thư tạm, không gửi lên ERP)")
    kq_thu = None
    if so_chon:
        goc_tam = os.path.join(HERE, "ket-qua", "erp_kiem_noi")
        shutil.rmtree(goc_tam, ignore_errors=True)
        tam = os.path.join(goc_tam, _dt.datetime.now().strftime("%Y%m%d%H%M%S"))
        ch2 = ET.CauHinh({"lenh": tam, "data": ch.data, "tram": "KIEM", "phut_moi_so": ch.phut_moi_so, "giay_cho": 5, "sau": ch.sau})
        ET.tao_thu_muc(ch2)
        hs_src = ch.tm("ho_so", ten_chon + ".json")
        if os.path.isfile(hs_src):
            shutil.copy(hs_src, ch2.tm("ho_so", ten_chon + ".json"))
        ma = "L-KIEM-" + _dt.datetime.now().strftime("%Y%m%d%H%M%S")
        lenh = {"phien_ban_khuon": 1, "lenh": ma, "so": ten_chon, "ky": _dt.date.today().strftime("%Y-%m"),
                "buoc": ["kiem_tra", "doi_chieu", "sua_chung_tu"], "sua": [{"ma": "KIEM:0:THU", "ma_loi": "KIEM", "mo_ta": "Dòng thử của xii_erp_kiem_noi"}],
                "bo_qua": [{"ma": "KIEM:1:THU", "khoa_tram": "KIEM|THU", "ly_do": "thử"}], "nguoi_yeu_cau": "KIEM_NOI"}
        ET.ghi_json_nguyen_tu(ch2.tm("cho", ma + ".json"), lenh)
        t0 = _dt.datetime.now()
        n = ET.quet_mot_luot(ch2)
        giay = (_dt.datetime.now() - t0).total_seconds()
        p_kq = ch2.tm("ket_qua", ma + ".ket_qua.json")
        if n == 1 and os.path.isfile(p_kq):
            kq_thu = doc_json(p_kq)
            loi = KH.kiem_ket_qua(kq_thu)
            if loi:
                bc.hong("kết quả sai khuôn (ERP sẽ từ chối): " + "; ".join(loi[:3]))
            else:
                bc.ok("sổ %s: %.1f giây, trạng thái %s, bước %s" % (ten_chon, giay, kq_thu.get("trang_thai"),
                                                                ", ".join("%s=%s" % (b["ten"], b["trang_thai"]) for b in kq_thu.get("buoc", []))))
                ht = kq_thu.get("hien_trang") or {}
                if ht:
                    bc.ok("hiện trạng: chứng từ đến %s, HĐ đến %s, điểm sẵn sàng %s, lỗi nặng %s, nhóm %s" % (ht.get("chung_tu_den"), ht.get("hd_den"), ht.get("diem_san_sang"), ht.get("loi_nang"), ht.get("nhom")))
                bc.ok("quy_tac %d, chung_tu_sai %d, viec_can_nguoi %d, da_sua %d, thuc_hien %d" % (
                    len(kq_thu.get("quy_tac") or []), len(kq_thu.get("chung_tu_sai") or []), len(kq_thu.get("viec_can_nguoi") or []),
                    len(kq_thu.get("da_sua") or []), len(kq_thu.get("thuc_hien") or [])))
                ds = [x for x in (kq_thu.get("da_sua") or []) if x.get("ma") == "KIEM:0:THU"]
                if ds and ds[0].get("trang_thai") == "KHONG_SUA" and ds[0].get("ly_do") == X.LY_DO_SUA:
                    bc.ok("sua_chung_tu: dòng sửa thử chưa ai trả lời -> KHONG_SUA, lý do = chờ kế toán trả lời trong Hàng đợi việc")
                else:
                    bc.cb("sua_chung_tu: dòng sửa thử không ra KHONG_SUA chờ kế toán (%s)" % (ds[0] if ds else "không có dòng"))
            if os.path.isfile(ch2.tm("xong", ma + ".json")) and not os.path.isfile(ch2.tm("khoa", ten_chon + ".khoa")):
                bc.ok("lệnh chuyển sang xong\\, khoá sổ đã bỏ, không ghi gì vào sổ")
            else:
                bc.hong("lệnh không sang xong\\ hoặc khoá sổ còn lại")
        else:
            bc.hong("trạm không làm được lệnh thử (xem %s)" % ch2.tm("tram", "nhat_ky"))
        bc.muc("6. Việc từ ERP vào Hàng đợi việc UNESCO XII (xii_erp_viec = erp_viec của XI)")
        try:
            import xii_erp_viec as XV
            ds_viec, V = XV.lap(ten_chon, tam, [])
            nb = V.ghi_bo_qua(ten_chon, tam, tam)
            if ds_viec and ds_viec[0][2].startswith("E|" + ma + "|KIEM:0:THU|"):
                bc.ok("lệnh sửa giả -> 1 dòng hàng đợi [ERP %s]; bo_qua -> %d dòng erp_bo_qua.txt" % (ma, nb))
            else:
                bc.hong("xii_erp_viec không thấy lệnh sửa giả (%d dòng)" % len(ds_viec))
        except Exception as e:
            bc.hong("xii_erp_viec lỗi: %s" % type(e).__name__)
    else:
        bc.hong("không có sổ để chạy thử")
    return bc, kq_thu


def main(argv=None):
    t = ET._ts(argv or sys.argv)
    bc, _ = chay(t)
    bc.dong.append("")
    tong = "KIEM NOI ERP (XII): %s - %d lỗi, %d cảnh báo (%s)" % ("ĐẠT" if bc.loi == 0 else "CHƯA ĐẠT", bc.loi, bc.canh_bao, _dt.datetime.now().strftime("%d/%m/%Y %H:%M"))
    bc.dong.append(tong)
    ra = t.get("ra") or os.path.join(HERE, "ket-qua", "erp_kiem_noi.txt")
    try:
        os.makedirs(os.path.dirname(ra), exist_ok=True)
        with io.open(ra, "w", encoding="utf-8-sig") as f:
            f.write("\n".join(bc.dong) + "\n")
    except OSError:
        pass
    for d in bc.dong:
        try:
            print(d)
        except (UnicodeEncodeError, OSError):
            print(d.encode("ascii", "replace").decode())
    return 0 if bc.loi == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
