# -*- coding: utf-8 -*-
"""GD249 - DO MUC TU DONG cua mot bo so (chi doc .MDB bang jet_doc) + de xuat nguong ghi tu dong theo so.
   Chi so (theo phan tich 16/10/2026):
     hd_tu_dong  : % hoa don tren cong thue da co chung tu (HDDTTaiVe.MaCTKeToan) = DA LIEN KET (ke ca ghi tay / gan phieu cu)
     hd_may_lap  : so hoa don may lap chung tu (HDDT_QuanHe Loai AI_LAP)            (GD347 - F06)
     hd_gan_tay  : so hoa don gan chung tu nhap tay / co san (GAN_TAY, GAN_CO_SAN)
     khong_cham  : % hoa don may ghi TU DONG (nhat ky CHE_DO TU_DONG) va KHONG co nguoi sua / can xem lai / huy sau do
                   tren so hoa don may lap - KPI "khong cham tay" that; so cu (chua co CHE_DO) -> None    -> muc tieu >= 90 %
     sua_sau_ghi : % hoa don nguoi sua dong / can xem lai so voi hoa don da hach toan (HDDT_NhatKy SUA_DONG_HD, CAN_XEM_LAI)
                                                                                      -> muc tieu <= 2 %
     lo_huy      : so lo bi huy / tong lo (HDDT_Lo, nhat ky HUY)
     hang_doi    : so viec / so loi lan kiem gan nhat (tom_tat.txt)
     nguong      : NguongTinCayTuDong hien tai (HDDT_QuyTac) + de xuat: sua <= 2 % va >= 100 HD trong 60 ngay -> giam 5 (toi thieu 70);
                   sua > 5 % -> tang 5 (toi da 95); con lai giu.
   K55 (THONG_TIN) trong Kiem tra truoc khoa so; Bang dieu hanh ghi them mot dong. Khong ghi gi vao bo so."""
import io
import os
import re
import datetime as _dt

NGAY_DO = 60
MUC_TIEU_HD = 90.0
MUC_TIEU_SUA = 2.0


def _s(x):
    return str(x if x is not None else "").strip()


def do(duong, hom_nay=None):
    """-> dict chi so hoac None (khong doc duoc)."""
    import jet_doc
    hom_nay = hom_nay or _dt.datetime.now()
    tu = hom_nay - _dt.timedelta(days=NGAY_DO)
    m = jet_doc.Mdb(duong)
    try:
        co = {k.lower() for k in m.bang()}
        kq = {"tu": tu.strftime("%d/%m/%Y"), "den": hom_nay.strftime("%d/%m/%Y"), "ngay": NGAY_DO}
        if "hddttaive" in co:
            cot = {c["ten"].lower() for c in m.cot("HDDTTaiVe")}
            co_mactkt = "mactketoan" in cot
            hd, hd_ht = set(), set()
            for r in m.doc("HDDTTaiVe"):
                ng = r.get("NgayLap")
                if isinstance(ng, _dt.datetime) and ng < tu:
                    continue
                k = _s(r.get("MaCT")) or "%s|%s|%s" % (_s(r.get("MSTNguoiBanNguoiXuatHang")), _s(r.get("KyHieuHoaDon")), _s(r.get("SoHoaDon")))
                hd.add(k)
                if co_mactkt and _s(r.get("MaCTKeToan")):
                    hd_ht.add(k)
            kq["so_hd"] = len(hd)
            kq["so_hd_ht"] = len(hd_ht) if co_mactkt else None
            kq["hd_tu_dong"] = round(100.0 * len(hd_ht) / len(hd), 1) if co_mactkt and hd else None
        else:
            hd, hd_ht = set(), set()
        # GD347 (F06): nguon gan chung tu (HDDT_QuanHe) - may lap / gan tay / gan phieu co san
        may_lap, gan_tay = set(), set()
        if "hddt_quanhe" in co:
            for r in m.doc("HDDT_QuanHe"):
                k = _s(r.get("KhoaCon"))
                if not k or k not in hd:
                    continue
                lo = _s(r.get("Loai")).upper()
                if lo == "AI_LAP":
                    may_lap.add(k)
                elif lo in ("GAN_TAY", "GAN_CO_SAN"):
                    gan_tay.add(k)
        n_sua = n_xem = n_huy = 0
        che_do, cham = {}, set()
        if "hddt_nhatky" in co:
            for r in m.doc("HDDT_NhatKy"):
                tg = r.get("ThoiGian")
                lo = _s(r.get("Loai")).upper()
                mct = _s(r.get("MaCT"))
                if lo == "CHE_DO":                       # GD347: TU_DONG / XEM_TRUOC / NGUOI <MaCT ke toan> (khong gioi han 60 ngay)
                    if mct:
                        che_do[mct] = _s(r.get("NoiDung")).split(" ")[0].upper()
                    continue
                if lo in ("SUA_DONG_HD", "CAN_XEM_LAI", "HUY") and mct:
                    cham.add(mct)
                if isinstance(tg, _dt.datetime) and tg < tu:
                    continue
                nd = _s(r.get("NoiDung"))
                if lo == "SUA_DONG_HD":
                    mm = re.search(r"/\s*(\d+)\s*hoa don", nd)
                    n_sua += int(mm.group(1)) if mm else 1
                elif lo == "CAN_XEM_LAI":
                    n_xem += 1
                elif lo == "HUY":
                    n_huy += 1
        kq["n_sua"], kq["n_xem"], kq["n_huy"] = n_sua, n_xem, n_huy
        kq["hd_may_lap"], kq["hd_gan_tay"] = len(may_lap), len(gan_tay)
        co_che_do = [k for k in may_lap if k in che_do]
        kq["hd_biet_che_do"] = len(co_che_do)
        k_cham = [k for k in co_che_do if che_do[k] == "TU_DONG" and k not in cham]
        kq["hd_khong_cham"] = len(k_cham)
        kq["khong_cham"] = round(100.0 * len(k_cham) / len(co_che_do), 1) if co_che_do else None
        n_lo = 0
        if "hddt_lo" in co:
            for r in m.doc("HDDT_Lo"):
                tl = r.get("TaoLuc")
                if isinstance(tl, _dt.datetime) and tl < tu:
                    continue
                n_lo += 1
        kq["n_lo"] = n_lo
        ht = kq.get("so_hd_ht") or 0
        kq["sua_sau_ghi"] = round(100.0 * (n_sua + n_xem) / ht, 1) if ht else None
        nguong = None
        if "hddt_quytac" in co:
            for r in m.doc("HDDT_QuyTac", 1):
                try:
                    nguong = int(r.get("NguongTinCayTuDong") or 0) or None
                except Exception:
                    nguong = None
        kq["nguong"] = nguong
        kq["nguong_de_xuat"], kq["ly_do"] = de_xuat_nguong(nguong, kq.get("sua_sau_ghi"), ht)
        return kq
    finally:
        try:
            m.dong()
        except Exception:
            pass


def de_xuat_nguong(nguong, sua, so_hd_ht):
    if not nguong:
        return None, "Chưa đọc được ngưỡng tin cậy (Quy tắc hạch toán)."
    if sua is None or so_hd_ht < 100:
        return nguong, "Giữ %d: chưa đủ 100 hoá đơn máy hạch toán trong %d ngày để đo." % (nguong, NGAY_DO)
    if sua <= MUC_TIEU_SUA and nguong > 70:
        moi = max(70, nguong - 5)          # GD345 (F05): kep trong bien 70 - 95
        return moi, "Giảm xuống %d: tỷ lệ sửa %.1f%% ≤ %.0f%% trên %d hoá đơn." % (moi, sua, MUC_TIEU_SUA, so_hd_ht)
    if sua > 5.0 and nguong < 95:
        moi = min(95, nguong + 5)
        return moi, "Tăng lên %d: tỷ lệ sửa %.1f%% > 5%% - máy ghi quá tay." % (moi, sua)
    return nguong, "Giữ %d: tỷ lệ sửa %.1f%%." % (nguong, sua)


def ghi(kq, thu_muc):
    try:
        os.makedirs(thu_muc, exist_ok=True)
        with io.open(os.path.join(thu_muc, "muc_tu_dong.txt"), "w", encoding="utf-8") as f:
            f.write("DO;%s;%s;%s;%s;%s;%s;%s;%s;%s\n" % (kq.get("den", ""), _f(kq.get("hd_tu_dong")), _f(kq.get("sua_sau_ghi")),
                                                         kq.get("so_hd", 0), kq.get("nguong") or "", kq.get("nguong_de_xuat") or "",
                                                         _f(kq.get("khong_cham")), kq.get("hd_may_lap", ""), kq.get("hd_gan_tay", "")))     # GD347 (F06)
    except Exception:
        pass


def doc_tom_tat(thu_muc):
    p = os.path.join(thu_muc, "muc_tu_dong.txt")
    if not os.path.isfile(p):
        return None
    try:
        with io.open(p, encoding="utf-8") as f:
            x = f.readline().strip().split(";")
        if x[0] != "DO" or len(x) < 7:
            return None
        return {"den": x[1], "hd_tu_dong": x[2], "sua_sau_ghi": x[3], "so_hd": x[4], "nguong": x[5], "nguong_de_xuat": x[6],
                "khong_cham": x[7] if len(x) > 7 else "", "hd_may_lap": x[8] if len(x) > 8 else "", "hd_gan_tay": x[9] if len(x) > 9 else ""}
    except Exception:
        return None


def _f(v):
    return "" if v is None else ("%.1f" % v)


def k_muc_tu_dong(S, _kq, DAT, CANH_BAO, LOI, THONG_TIN):
    ten = "Mức tự động của bộ sổ (60 ngày) và ngưỡng ghi tự động đề xuất"
    duong = S.dl.get("duong_so") or ""
    if not duong or not os.path.isfile(duong):
        return None
    try:
        kq = do(duong)
    except Exception as e:
        return [_kq("K55", ten, THONG_TIN, "Không đo được: %s" % e)]
    try:
        import chinh_sach_so
        tm, _ = chinh_sach_so._thu_muc_ra(duong)
        ghi(kq, tm)
    except Exception:
        pass
    dong = [["Hoá đơn trên cổng thuế (%s - %s)" % (kq["tu"], kq["den"]), kq.get("so_hd", 0), ""],
            ["Đã liên kết chứng từ (kể cả ghi tay)", kq.get("so_hd_ht") if kq.get("so_hd_ht") is not None else "không đo được (bản cũ)",
             "%s%%" % _f(kq.get("hd_tu_dong")) if kq.get("hd_tu_dong") is not None else ""],
            ["Máy lập chứng từ / gắn chứng từ nhập tay", "%s / %s" % (kq.get("hd_may_lap", 0), kq.get("hd_gan_tay", 0)), ""],
            ["Máy ghi tự động, không ai chạm tay sau đó", "%s / %s" % (kq.get("hd_khong_cham", 0), kq.get("hd_biet_che_do", 0)),
             ("%s%%" % _f(kq.get("khong_cham"))) if kq.get("khong_cham") is not None else "chưa đo được (sổ chưa ghi chế độ ghi - từ GĐ347)"],
            ["Hoá đơn người sửa dòng / cần xem lại", kq["n_sua"] + kq["n_xem"], ("%s%%" % _f(kq.get("sua_sau_ghi"))) if kq.get("sua_sau_ghi") is not None else ""],
            ["Lô đã lập / lô huỷ", "%d / %d" % (kq["n_lo"], kq["n_huy"]), ""],
            ["Ngưỡng tin cậy hiện tại", kq.get("nguong") or "", ""],
            ["Ngưỡng đề xuất", kq.get("nguong_de_xuat") or "", kq.get("ly_do", "")]]
    muc = THONG_TIN
    kl = "Hoá đơn đã liên kết chứng từ: %s; máy ghi không chạm tay: %s (mục tiêu ≥ %.0f%%); người sửa sau ghi: %s (mục tiêu ≤ %.0f%%). %s" % (
        ("%s%%" % _f(kq["hd_tu_dong"])) if kq.get("hd_tu_dong") is not None else "chưa đo được",
        ("%s%%" % _f(kq["khong_cham"])) if kq.get("khong_cham") is not None else "chưa đo được",
        MUC_TIEU_HD, ("%s%%" % _f(kq["sua_sau_ghi"])) if kq.get("sua_sau_ghi") is not None else "chưa đo được", MUC_TIEU_SUA, kq.get("ly_do", ""))
    if kq.get("nguong_de_xuat") and kq.get("nguong") and kq["nguong_de_xuat"] != kq["nguong"]:
        muc = CANH_BAO
        kl += " Đổi ngưỡng ở Quy tắc hạch toán > Ngưỡng tin cậy tự động."
    return [_kq("K55", ten, muc, kl, ["Chỉ số", "Giá trị", "Tỷ lệ / ghi chú"], dong)]
