# -*- coding: utf-8 -*-
"""GD78 - B09-DNN BAN THUYET MINH BAO CAO TAI CHINH (TT133) "dung mau theo Video" - chi DOC so.

Nguon mau: video "Thiet lap bao cao tai chinh - Thuyet minh bao cao tai chinh" (7 the: Thong tin chung, Thong tin bo sung, Tai san
co dinh, Bat dong san dau tu, Thue va cac khoan phai nop, Vay va no thue tai chinh, Von chu so huu): moi chi tieu co ma, ten, loai
(Tieu de / Tong hop / Chi tiet / Chu thich), cong thuc tung cot, van ban mac dinh, in dam / in nghieng -> bang CHI_TIEU duoi day
(chep nguyen van cong thuc). In theo thu tu mau B09-DNN TT133: I, II, III, IV, V.1 .. V.16, VI.1 .. VI.9, VII, VIII.

Hop dong Xuat 1 lan (xuat_1_lan.py): lap(dl, ma, kieu, thumuc) -> {"tep": [B09_DNN_<nam>.xlsx], "canh_bao": [...]}; ma "B09" hoac
"SS_TM" (bieu mau so sach goi lai). B09 khong co mau XML HTKK (nop kem dang tep) -> luon lap Excel.

Bo thong dich cong thuc (ham cua phan mem mau):
  DUNOCK / DUCOCK / DUNODK / DUCODK(tk)       du No / du Co cuoi ky (CK) / dau ky (DK) cua TK TONG HOP (bu tru cac TK chi tiet)
  ..._ChitietTheoTK(tk)                        cong phan du No (Co) cua TUNG TK chi tiet, khong bu tru giua cac TK
  ..._ChitietTheoTKvaDoituong(tk)              cong phan du No (Co) cua TUNG DOI TUONG tren tung TK chi tiet (131, 331...), khong bu tru
  PhatsinhNO / PhatsinhCO(tk)                  phat sinh No / Co trong ky (ca but toan ket chuyen)
  PhatsinhDU(a/b)                              phat sinh No TK a doi ung Co TK b (tien to so hieu: 11 = 111, 112, 113)
  Phatsinh{NO|CO}_Chitiet{ChietKhauThuongmai|GiamgiaHangBan|TralaiHangBan}(tk)  phan phat sinh No / Co tk la giam tru doanh thu
                                               (phan mem mau danh dau tren chung tu; UNESCO khong co co danh dau -> lay phan doi ung
                                               TK giam tru cu 5211 / 521 = CKTM, 5212 / 531 = tra lai, 5213 / 532 = giam gia; so TT133 = 0)
  PhatsinhNoGiamVAT(tk) / PhatsinhDUGiamVAT(a/b)  giam thue GTGT (phan mem mau danh dau chung tu). UNESCO: cung quy uoc GD77 NVNN:
                                               giam VAT = PS No tk doi ung TK NGOAI 133 va ngoai nhom nop; DUGiamVAT = 0
  Haomon..._TSCD_loai16()                      hao mon TSCD theo doi ngoai TK 214 cua phan mem mau -> UNESCO ghi het qua 214: 0
  ..._NamTruoc                                 cung ham cho NAM TRUOC: so nam truoc (KT<nam-1>*.MDB, VB doc chi doc) neu co; khong co ->
                                               PS luy ke nam truoc luu trong he thong TK + quy uoc ket chuyen nhu B02 nam truoc cua UNESCO
  [ma]  + - * / ( )                            tham chieu gia tri (da lam tron) cua chi tieu khac cung cot; so hang
Du lieu: dl["tk"], dl["ps"], dl["doi_ung"], dl["kh_dau"/"kh_no"/"kh_co"] (kiem_khoa_so.SoLieu / bao_cao_bo_sung.SoLieuBS),
dl["b09"] (ModHDDTThuyetMinh: ps_truoc, le, sotruoc), dl["bctc"] (so B01a / B02 cua phan mem - doi chieu), dl["dn"], dl["x1l"]."""
import datetime
import math
import os
import re
from collections import defaultdict

import bao_cao_bo_sung as B
import kiem_khoa_so as K

_so = K._so
thang_tc = K.thang_tc

NOP = ("11", "141", "131", "138", "331", "338", "136", "336")      # nhom TK "da nop" (mau V.10 / NVNN)

# --------------------------------------------------------------------------------------------------------------------------
#  BANG CHI TIEU THEO VIDEO. R(ma, ten, loai, dinh_dang, cong_thuc, noi_dung)
#    loai: TD tieu de | TH tong hop | CT chi tiet | CTH chu thich | VB dong van ban (the 1)
#    dinh_dang: "" / "D" dam / "N" nghieng / "DN"
#    cong_thuc: None = o khong nhap (tieu de / chu thich); tuple theo cot; "" = o co but chi nhung de trong (ke toan nhap tay)
# --------------------------------------------------------------------------------------------------------------------------


def R(ma, ten, loai, dd="", ct=None, nd=""):
    return {"ma": ma, "ten": ten, "loai": loai, "dam": "D" in dd, "nghieng": "N" in dd, "ct": ct, "nd": nd}


# VI.1.a: chep nguyen van (5111 cot Cuoi nam co thu tu Tralai truoc Giamgia - dung nhu man hinh)
F_5111_CN = ("PhatsinhCO(5111) - PhatsinhDU(911/5111) - PhatsinhCO_ChitietChietKhauThuongmai(5111) - PhatsinhCO_ChitietTralaiHangBan(5111) - "
             "PhatsinhCO_ChitietGiamgiaHangBan(5111) - PhatsinhNO(5111) + PhatsinhDU(5111/911) + PhatsinhNO_ChitietChietKhauThuongmai(5111) + "
             "PhatsinhNO_ChitietTralaiHangBan(5111) + PhatsinhNO_ChitietGiamgiaHangBan(5111)")


def F_DT_CN(tk):
    return ("PhatsinhCO({0}) - PhatsinhDU(911/{0}) - PhatsinhCO_ChitietChietKhauThuongmai({0}) - PhatsinhCO_ChitietGiamgiaHangBan({0}) - "
            "PhatsinhCO_ChitietTralaiHangBan({0}) - PhatsinhNO({0}) + PhatsinhDU({0}/911) + PhatsinhNO_ChitietChietKhauThuongmai({0}) + "
            "PhatsinhNO_ChitietGiamgiaHangBan({0}) + PhatsinhNO_ChitietTralaiHangBan({0})").format(tk)


def F_DT_NT(tk):
    return ("PhatsinhCO_NamTruoc({0}) - PhatsinhDU_NamTruoc(911/{0}) - PhatsinhCO_ChitietChietKhauThuongmai_NamTruoc({0}) - "
            "PhatsinhCO_ChitietGiamgiaHangBan_NamTruoc({0}) - PhatsinhCO_ChitietTralaiHangBan_NamTruoc({0}) - PhatsinhNO_NamTruoc({0}) + "
            "PhatsinhDU_NamTruoc({0}/911) + PhatsinhNO_ChitietChietKhauThuongmai_NamTruoc({0}) + PhatsinhNO_ChitietGiamgiaHangBan_NamTruoc({0}) + "
            "PhatsinhNO_ChitietTralaiHangBan_NamTruoc({0})").format(tk)


def F_THUE_PN(tk):
    return ("PhatsinhCO({0}) - PhatsinhNO({0}) + PhatsinhDU({0}/11) + PhatsinhDU({0}/141) + PhatsinhDU({0}/131) + PhatsinhDU({0}/138) + "
            "PhatsinhDU({0}/331) + PhatsinhDU({0}/338) + PhatsinhDU({0}/136) + PhatsinhDU({0}/336)").format(tk)


def F_THUE_DN(tk):
    return ("PhatsinhDU({0}/11) + PhatsinhDU({0}/141) + PhatsinhDU({0}/131) + PhatsinhDU({0}/138) + PhatsinhDU({0}/331) + "
            "PhatsinhDU({0}/338) + PhatsinhDU({0}/136) + PhatsinhDU({0}/336)").format(tk)


F_VAT_PN = ("PhatsinhCO(3331) - PhatsinhDU(3331/133) - PhatsinhNO(33312) + PhatsinhDU(33312/11) + PhatsinhDU(33312/141) + PhatsinhDU(33312/131) + "
            "PhatsinhDU(33312/138) + PhatsinhDU(33312/331) + PhatsinhDU(33312/338) + PhatsinhDU(33312/136) + PhatsinhDU(33312/336) - "
            "PhatsinhNoGiamVAT(33311)")
F_VAT_DN = ("PhatsinhDU(3331/11) + PhatsinhDU(3331/141) + PhatsinhDU(3331/131) + PhatsinhDU(3331/138) + PhatsinhDU(3331/331) + PhatsinhDU(3331/338) + "
            "PhatsinhDU(3331/136) + PhatsinhDU(3331/336) - PhatsinhDUGiamVAT(33311/11) - PhatsinhDUGiamVAT(33311/141) - PhatsinhDUGiamVAT(33311/131) - "
            "PhatsinhDUGiamVAT(33311/138) - PhatsinhDUGiamVAT(33311/331) - PhatsinhDUGiamVAT(33311/338) - PhatsinhDUGiamVAT(33311/136) - "
            "PhatsinhDUGiamVAT(33311/336)")


def CN(tk, ben="NO"):
    """cap (Cuoi nam, Dau nam) cua mot TK: DU<ben>CK(tk), DU<ben>DK(tk)."""
    return ("DU%sCK(%s)" % (ben, tk), "DU%sDK(%s)" % (ben, tk))


def TG(tk, ben="NO"):
    """V.5 / V.6: (dau nam, tang, giam, cuoi nam) cua nguyen gia (ben NO) / hao mon (ben CO)."""
    if ben == "NO":
        return ("DUNODK(%s)" % tk, "PhatsinhNO(%s)" % tk, "PhatsinhCO(%s)" % tk, "DUNOCK(%s)" % tk)
    return ("DUCODK(%s)" % tk, "PhatsinhCO(%s)" % tk, "PhatsinhNO(%s)" % tk, "DUCOCK(%s)" % tk)


def TONG(*ma):
    s = " + ".join("[%s]" % m for m in ma)
    return s


def CL(a, b, n=4):
    s = "[%s] - [%s]" % (a, b)
    return (s,) * n


T2 = ("", "")
T4 = ("", "", "", "")

# ---- the 1: Thong tin chung (van ban mac dinh; <br> -> xuong dong) ----------------------------------------------------------
ND_IV_4_1 = ("Các khoản đầu tư nắm giữ đến ngày đáo hạn bao gồm các khoản đầu tư mà Công ty có ý định và khả năng giữ đến ngày đáo hạn. "
             "Các khoản đầu tư nắm giữ đến ngày đáo hạn bao gồm: các khoản tiền gửi ngân hàng có kỳ hạn (bao gồm cả các loại tín phiếu, kỳ phiếu), "
             "trái phiếu, cổ phiếu ưu đãi bên phát hành bắt buộc phải mua lại tại một thời điểm nhất định trong tương lai và các khoản cho vay "
             "nắm giữ đến ngày đáo hạn với mục đích thu lãi hàng kỳ và các khoản đầu tư nắm giữ đến ngày đáo hạn khác.\n"
             "Các khoản đầu tư nắm giữ đến ngày đáo hạn được ghi nhận bắt đầu từ ngày mua và được xác định giá trị ban đầu theo giá mua và các "
             "chi phí liên quan đến giao dịch mua các khoản đầu tư. Thu nhập lãi từ các khoản đầu tư nắm giữ đến ngày đáo hạn sau ngày mua được "
             "ghi nhận trên Báo cáo kết quả hoạt động kinh doanh trên cơ sở dự thu. Lãi được hưởng trước khi Công ty nắm giữ được ghi giảm trừ "
             "vào giá gốc tại thời điểm mua.\n"
             "Các khoản đầu tư nắm giữ đến ngày đáo hạn được xác định theo giá gốc trừ đi dự phòng phải thu khó đòi.\n"
             "Dự phòng phải thu khó đòi của các khoản đầu tư nắm giữ đến ngày đáo hạn được trích lập theo các quy định kế toán hiện hành.")
ND_IV_7_2 = ("Quyền sử dụng đất: Tài sản cố định vô hình thể hiện giá trị quyền sử dụng đất và được trình bày theo nguyên giá trừ giá trị hao "
             "mòn lũy kế. Quyền sử dụng đất được phân bổ theo phương pháp đường thẳng dựa trên thời gian sử dụng lô đất.\n"
             "Tài sản vô hình được tạo ra từ nội bộ doanh nghiệp-Chi phí nghiên cứu và phát triển (nếu áp dụng).\n"
             "Chi phí cho hoạt động nghiên cứu được ghi nhận là chi phí của năm tài chính (kỳ hoạt động) thực tế phát sinh chi phí đó.\n"
             "Tài sản vô hình được tạo ra từ nội bộ doanh nghiệp phát sinh từ giai đoạn phát triển chỉ được ghi nhận khi thỏa mãn các điều kiện sau:\n"
             "• Tài sản được tạo ra có thể xác định được (ví dụ như phần mềm máy vi tính và các quy trình sản xuất mới);\n"
             "• Chắc chắn thu được lợi ích kinh tế trong tương lai từ tài sản đó;\n"
             "• Chi phí phát triển tài sản có thể xác định được một cách tin cậy.\n"
             "Tài sản vô hình được tạo ra từ nội bộ doanh nghiệp được khấu hao theo phương pháp đường thẳng dựa trên thời gian hữu dụng ước tính. "
             "Trong trường hợp không thể ghi nhận được tài sản vô hình tạo ra từ nội bộ doanh nghiệp, chi phí nghiên cứu phát triển được hạch "
             "toán vào khoản lãi hoặc lỗ trong năm tài chính (kỳ hoạt động) phát sinh chi phí đó.\n"
             "Bằng sáng chế và thương hiệu: Bằng sáng chế và thương hiệu được ghi nhận ban đầu theo giá mua và được khấu hao theo phương pháp "
             "đường thẳng dựa trên thời gian hữu dụng ước tính.")
ND_IV_7_3 = ("Bất động sản đầu tư bao gồm quyền sử dụng đất và nhà xưởng, vật kiến trúc do công ty nắm giữ nhằm mục đích thu lợi từ việc cho "
             "thuê hoặc chờ tăng giá. Bất động sản đầu tư cho thuê được trình bày theo nguyên giá trừ giá trị hao mòn lũy kế. Bất động sản đầu "
             "tư chờ tăng giá được trình bày theo nguyên giá trừ suy giảm giá trị. Nguyên giá của bất động sản đầu tư được mua bao gồm giá mua "
             "và các chi phí liên quan trực tiếp như phí dịch vụ tư vấn về luật pháp liên quan, thuế trước bạ và chi phí giao dịch liên quan "
             "khác. Nguyên giá bất động sản đầu tư tự xây là giá trị quyết toán công trình hoặc các chi phí liên quan trực tiếp của bất động "
             "sản đầu tư.\n"
             "Bất động sản đầu tư cho thuê được khấu hao theo phương pháp đường thẳng trên thời gian hữu dụng ước tính trong vòng X năm.\n"
             "Công ty không trích khấu hao đối với bất động sản đầu tư nắm giữ chờ tăng giá.")
ND_IV_11_1 = ("Doanh thu bán hàng được ghi nhận khi đồng thời thỏa mãn tất cả năm (5) điều kiện sau:\n"
              "(a) Công ty đã chuyển giao phần lớn rủi ro và lợi ích gắn liền với quyền sở hữu sản phẩm hoặc hàng hóa cho người mua;\n"
              "(b) Công ty không còn nắm giữ quyền quản lý hàng hóa như người sở hữu hàng hóa hoặc quyền kiểm soát hàng hóa;\n"
              "(c) Doanh thu được xác định tương đối chắc chắn;\n"
              "(d) Công ty sẽ thu được lợi ích kinh tế từ giao dịch bán hàng;\n"
              "(e) Xác định được chi phí liên quan đến giao dịch bán hàng.")
ND_IV_11_2 = ("Doanh thu của giao dịch về cung cấp dịch vụ được ghi nhận khi kết quả của giao dịch đó được xác định một cách đáng tin cậy. "
              "Trường hợp giao dịch về cung cấp dịch vụ liên quan đến nhiều kỳ thì doanh thu được ghi nhận trong kỳ theo kết quả phần công việc "
              "đã hoàn thành tại ngày của Bảng cân đối kế toán của kỳ đó. Kết quả của giao dịch cung cấp dịch vụ được xác định khi thỏa mãn tất "
              "cả bốn (4) điều kiện sau:\n"
              "(a) Doanh thu được xác định tương đối chắc chắn;\n"
              "(b) Có khả năng thu được lợi ích kinh tế từ giao dịch cung cấp dịch vụ đó;\n"
              "(c) Xác định được phần công việc đã hoàn thành tại ngày của Bảng cân đối kế toán;\n"
              "(d) Xác định được chi phí phát sinh cho giao dịch và chi phí để hoàn thành giao dịch cung cấp dịch vụ đó.")
ND_IV_11_3 = ("Lãi tiền gửi được ghi nhận trên cơ sở dồn tích, được xác định trên số dư các tài khoản tiền gửi và lãi suất áp dụng (nếu có và "
              "lãi tiền gửi được đánh giá là trọng yếu).\n"
              "Lãi từ các khoản đầu tư được ghi nhận khi Công ty có quyền nhận khoản lãi. (nếu có và lãi từ các khoản đầu tư được đánh giá là "
              "trọng yếu).")
ND_IV_11_4 = ("Doanh thu từ hợp đồng xây dựng của Công ty được ghi nhận theo chính sách kế toán của Công ty về hợp đồng xây dựng\n"
              "Khi kết quả thực hiện hợp đồng xây dựng có thể được ước tính một cách đáng tin cậy, doanh thu và chi phí liên quan đến hợp đồng "
              "được ghi nhận tương ứng với phần công việc đã hoàn thành tại ngày kết thúc niên độ kế toán được tính bằng tỷ lệ phần trăm giữa "
              "chi phí phát sinh của phần công việc đã hoàn thành tại ngày kết thúc niên độ kế toán so với tổng chi phí dự toán của hợp đồng, "
              "ngoại trừ trường hợp chi phí này không tương đương với phần khối lượng xây lắp đã hoàn thành. Khoản chi phí này có thể bao gồm "
              "các chi phí phụ thêm, các khoản bồi thường và chi thưởng thực hiện hợp đồng theo thỏa thuận với khách hàng.\n"
              "Khi kết quả thực hiện hợp đồng xây dựng không thể được ước tính một cách đáng tin cậy, doanh thu chỉ được ghi nhận tương đương "
              "với chi phí của hợp đồng đã phát sinh mà việc được hoàn trả là tương đối chắc chắn.")

THE1_I = [
    R("I", "I. Đặc điểm hoạt động của doanh nghiệp", "VB", "D"),
    R("I.1", "1. Hình thức sở hữu vốn:", "VB"),
    R("I.2", "2. Lĩnh vực kinh doanh:", "VB", nd="Thương mại, Dịch vụ, Sản xuất, Xây lắp"),
    R("I.3", "3. Ngành nghề kinh doanh:", "VB"),
    R("I.4", "4. Chu kỳ sản xuất, kinh doanh thông thường:", "VB"),
    R("I.5", "5. Đặc điểm hoạt động của doanh nghiệp trong năm tài chính có ảnh hưởng đến Báo cáo tài chính:", "VB"),
    R("I.6", "6. Tuyên bố về khả năng so sánh thông tin trên Báo cáo tài chính (có so sánh được hay không, nếu không so sánh được phải "
             "nêu rõ lý do như vì chuyển đổi hình thức sở hữu, chia tách, sáp nhập, nêu độ dài về kỳ so sánh...):", "VB"),
    R("II", "II. Kỳ kế toán, đơn vị tiền tệ sử dụng trong kế toán", "VB", "D"),
    R("II.1", "1. Kỳ kế toán năm:", "VB"),
    R("II.2", "2. Đơn vị tiền tệ sử dụng trong kế toán:", "VB", nd="VND"),
    R("III", "III. Chuẩn mực và Chế độ kế toán áp dụng", "VB", "D"),
    R("III.1", "1- Chế độ kế toán áp dụng:", "VB",
      nd="Công ty áp dụng Chế độ Kế toán doanh nghiệp nhỏ và vừa ban hành theo Thông tư số 133/2016/TT-BTC ngày 26/08/2016 của Bộ Tài chính"),
    R("III.2", "2- Tuyên bố về việc tuân thủ Chuẩn mực kế toán và Chế độ kế toán:", "VB",
      nd="Công ty đã áp dụng các Chuẩn mực kế toán Việt Nam và các văn bản hướng dẫn Chuẩn mực do Nhà nước đã ban hành. Các báo cáo tài "
         "chính được lập và trình bày theo đúng mọi quy định của từng chuẩn mực, thông tư hướng dẫn thực hiện chuẩn mực và Chế độ kế toán hiện hành"),
    R("IV", "IV. Các chính sách kế toán áp dụng", "VB", "D"),
    R("IV.1", "- Tỷ giá hối đoái áp dụng trong kế toán:", "VB",
      nd="Các nghiệp vụ phát sinh bằng ngoại tệ được chuyển đổi theo tỷ giá tại ngày phát sinh nghiệp vụ. Số dư các khoản mục tiền tệ có "
         "gốc ngoại tệ tại ngày kết thúc niên độ kế toán được chuyển đổi theo tỷ giá tại ngày này. Chênh lệch tỷ giá phát sinh được hạch "
         "toán vào Báo cáo kết quả hoạt động kinh doanh."),
    R("IV.2", "- Nguyên tắc chuyển đổi BCTC lập bằng ngoại tệ sang Đồng Việt Nam:", "VB"),
    R("IV.3", "- Nguyên tắc ghi nhận các khoản tiền và các khoản tương đương tiền:", "VB",
      nd="Tiền và các khoản tương đương tiền bao gồm tiền mặt tại quỹ, các khoản tiền gửi không kỳ hạn, các khoản đầu tư ngắn hạn, có khả "
         "năng thanh khoản cao, dễ dàng chuyển đổi thành tiền và ít rủi ro liên quan đến việc biến động giá trị."),
    R("IV.4", "- Nguyên tắc kế toán các khoản đầu tư tài chính:", "VB"),
    R("IV.4.1", "+ Các khoản đầu tư nắm giữ đến ngày đáo hạn", "VB", nd=ND_IV_4_1),
    R("IV.4.2", "+ Các khoản cho vay:", "VB",
      nd="Các khoản cho vay được xác định theo giá gốc trừ đi các khoản dự phòng phải thu khó đòi. Dự phòng phải thu khó đòi các khoản "
         "cho vay của Công ty được trích lập theo các quy định kế toán hiện hành."),
    R("IV.5", "- Nguyên tắc kế toán nợ phải thu:", "VB",
      nd="Nợ phải thu là số tiền có thể thu hồi của khách hàng hoặc các đối tượng khác. Nợ phải thu được trình bày theo giá trị ghi sổ trừ "
         "đi các khoản dự phòng phải thu khó đòi.\nDự phòng phải thu khó đòi được trích lập cho những khoản nợ phải thu đã quá hạn thanh "
         "toán từ sáu tháng trở lên, hoặc các khoản nợ phải thu mà người nợ khó có khả năng thanh toán do bị thanh lý, phá sản hay các khó "
         "khăn tương tự."),
    R("IV.6", "- Nguyên tắc ghi nhận hàng tồn kho:", "VB",
      nd="Hàng tồn kho được xác định trên cơ sở giá thấp hơn giữa giá gốc và giá trị thuần có thể thực hiện được. Giá gốc hàng tồn kho bao "
         "gồm chi phí nguyên vật liệu trực tiếp, chi phí lao động trực tiếp và chi phí sản xuất chung, nếu có, để có được hàng tồn kho ở "
         "địa điểm và trạng thái hiện tại [đối với doanh nghiệp hoạt động thương mại: Giá gốc hàng tồn kho bao gồm chi phí mua và các chi "
         "phí khác có liên quan trực tiếp đến việc mua hàng tồn kho]. Giá gốc của hàng tồn kho được xác định theo phương pháp bình quân gia "
         "quyền (hoặc nhập trước xuất trước hoặc thực tế đích danh hoặc phương pháp giá bán lẻ trong trường hợp hàng hóa). Giá trị thuần có "
         "thể thực hiện được được xác định bằng giá bán ước tính trừ các chi phí ước tính để hoàn thành sản phẩm cùng chi phí tiếp thị, bán "
         "hàng và phân phối phát sinh."),
    R("IV.7", "- Nguyên tắc ghi nhận và các phương pháp khấu hao TSCĐ, TSCĐ thuê tài chính, bất động sản đầu tư:", "VB"),
    R("IV.7.1", "+ Nguyên tắc ghi nhận TSCĐ", "VB",
      nd="Tài sản cố định hữu hình được trình bày theo nguyên giá trừ giá trị hao mòn lũy kế.\nNguyên giá tài sản cố định hữu hình bao gồm "
         "giá mua và toàn bộ các chi phí khác liên quan trực tiếp đến việc đưa tài sản vào trạng thái sẵn sàng sử dụng."),
    R("IV.7.2", "+ Nguyên tắc ghi nhận TSCĐ vô hình:", "VB", nd=ND_IV_7_2),
    R("IV.7.3", "+ Nguyên tắc ghi nhận bất động sản đầu tư:", "VB", nd=ND_IV_7_3),
    R("IV.8", "- Nguyên tắc kế toán nợ phải trả:", "VB"),
    R("IV.9", "- Nguyên tắc ghi nhận và vốn hóa các khoản chi phí đi vay:", "VB"),
    R("IV.10", "- Nguyên tắc ghi nhận vốn chủ sở hữu:", "VB"),
    R("IV.11", "- Nguyên tắc và phương pháp ghi nhận doanh thu:", "VB"),
    R("IV.11.1", "+ Doanh thu bán hàng:", "VB", nd=ND_IV_11_1),
    R("IV.11.2", "+ Doanh thu cung cấp dịch vụ:", "VB", nd=ND_IV_11_2),
    R("IV.11.3", "+ Doanh thu hoạt động tài chính:", "VB", nd=ND_IV_11_3),
    R("IV.11.4", "+ Doanh thu hợp đồng xây dựng:", "VB", nd=ND_IV_11_4),
    R("IV.12", "- Nguyên tắc kế toán chi phí:", "VB"),
]
THE1_V15 = [R("V.15", "15. Thuyết minh về các bên liên quan (danh sách các bên liên quan, giao dịch và các thông tin khác về các bên liên "
                      "quan chưa được trình bày ở các nội dung nêu trên)", "VB", "DN")]
THE1_V16 = [R("V.16", "16. Ngoài các nội dung đã trình bày trên, các doanh nghiệp được giải trình, thuyết minh các thông tin khác nếu thấy "
                      "cần thiết", "VB", "DN")]
THE1_VII = [
    R("VII", "VII. Thông tin bổ sung cho các khoản mục trình bày trong Báo cáo lưu chuyển tiền tệ", "VB", "D"),
    R("VII.1", "Các khoản tiền do doanh nghiệp nắm giữ nhưng không được sử dụng: Trình bày giá trị và lý do của các khoản tiền và tương "
               "đương tiền lớn do doanh nghiệp nắm giữ nhưng không được sử dụng do có sự hạn chế của pháp luật hoặc các ràng buộc khác mà "
               "doanh nghiệp phải thực hiện", "VB"),
]
THE1_VIII = [
    R("VIII", "VIII. Những thông tin khác", "VB", "D"),
    R("VIII.1", "1. Những khoản nợ tiềm tàng, khoản cam kết và những thông tin tài chính khác:", "VB"),
    R("VIII.2", "2. Những sự kiện phát sinh sau ngày kết thúc kỳ kế toán năm:", "VB"),
    R("VIII.3", "3. Thông tin so sánh (những thay đổi về thông tin trong Báo cáo tài chính của các niên độ kế toán trước):", "VB"),
    R("VIII.4", "4. Thông tin về hoạt động liên tục:", "VB"),
    R("VIII.5", "5. Những thông tin khác.", "VB"),
]

# ---- the 2: Thong tin bo sung (cot Cuoi nam | Dau nam; phan VI in la Nam nay | Nam truoc) ------------------------------------
V_TD = R("V", "V. Thông tin bổ sung cho các khoản mục trình bày trong Báo cáo tình hình tài chính", "TD", "D")
V1 = [R("V.1", "1. Tiền và tương đương tiền", "TD", "DN"),
      R("V.1.1", "- Tiền mặt", "CT", "", CN(111)),
      R("V.1.2", "- Tiền gửi ngân hàng không kỳ hạn", "CT", "", CN(112)),
      R("V.1.3", "- Tương đương tiền", "CT", "", T2)]
V2 = [R("V.2", "2. Các khoản đầu tư tài chính", "TD", "DN"),
      R("V.2.a", "a) Chứng khoán kinh doanh", "TH", "D", (TONG("V.2.a.1", "V.2.a.2", "V.2.a.3"),) * 2),
      R("V.2.a.1", "- Tổng giá trị cổ phiếu", "CT", "", T2),
      R("V.2.a.2", "- Tổng giá trị trái phiếu", "CT", "", T2),
      R("V.2.a.3", "- Các loại chứng khoán khác", "CT", "", CN(121)),
      R("V.2.b", "b) Đầu tư nắm giữ đến ngày đáo hạn", "TH", "D", (TONG("V.2.b.1", "V.2.b.2"),) * 2),
      R("V.2.b.1", "- Tiền gửi có kỳ hạn", "CT", "", CN(1281)),
      R("V.2.b.2", "- Các khoản đầu tư khác nắm giữ đến ngày đáo hạn", "CT", "", CN(1288)),
      R("V.2.c", "c) Dự phòng tổn thất đầu tư tài chính", "TH", "D", (TONG("V.2.c.1", "V.2.c.2"),) * 2),
      R("V.2.c.1", "- Dự phòng giảm giá chứng khoán kinh doanh", "CT", "", CN(2291, "CO")),
      R("V.2.c.2", "- Dự phòng tổn thất đầu tư vào đơn vị khác", "CT", "", CN(2292, "CO"))]
V3 = [R("V.3", "3. Các khoản phải thu", "TD", "DN"),
      R("V.3.a", "a) Phải thu của khách hàng", "CT", "",
        ("DUNOCK_ChitietTheoTKvaDoituong(131)", "DUNODK_ChitietTheoTKvaDoituong(131)")),
      R("V.3.a.1", "Trong đó: Phải thu của các bên liên quan", "CT", "", T2),
      R("V.3.b", "b) Trả trước cho người bán", "CT", "",
        ("DUNOCK_ChitietTheoTKvaDoituong(331)", "DUNODK_ChitietTheoTKvaDoituong(331)")),
      R("V.3.b.1", "Trong đó: Trả trước cho các bên liên quan", "CT", "", T2),
      R("V.3.c", "c) Phải thu khác (Chi tiết theo yêu cầu quản lý):", "TH", "", (TONG("V.3.c.1", "V.3.c.2", "V.3.c.3", "V.3.c.4"),) * 2),
      R("V.3.c.1", "- Phải thu về cho vay", "CT", "", T2),
      R("V.3.c.2", "- Tạm ứng", "CT", "", CN(141)),
      R("V.3.c.3", "- Phải thu nội bộ khác", "CT", "", CN(1368)),
      R("V.3.c.4", "- Phải thu khác", "CT", "",
        ("DUNOCK_ChitietTheoTK(338) + DUNOCK_ChitietTheoTK(1388) + DUNOCK_ChitietTheoTK(334) + DUNOCK(1386)",
         "DUNODK_ChitietTheoTK(338) + DUNODK_ChitietTheoTK(1388) + DUNODK_ChitietTheoTK(334) + DUNODK(1386)")),
      R("V.3.d", "d) Tài sản thiếu chờ xử lý", "TH", "", (TONG("V.3.d.1", "V.3.d.2", "V.3.d.3", "V.3.d.4"),) * 2),
      R("V.3.d.1", "- Tiền", "CT", "", T2),
      R("V.3.d.2", "- Hàng tồn kho", "CT", "", T2),
      R("V.3.d.3", "- TSCĐ", "CT", "", T2),
      R("V.3.d.4", "- Tài sản khác", "CT", "", CN(1381)),
      R("V.3.đ", "đ) Nợ xấu (Tổng giá trị các khoản phải thu, cho vay quá hạn thanh toán hoặc chưa quá hạn nhưng khó có khả năng thu hồi)",
        "CT", "", T2)]
V4 = [R("V.4", "4. Hàng tồn kho (Mã số 141)", "TD", "DN"),
      R("V.4.1", "- Hàng đang đi trên đường", "CT", "", CN(151)),
      R("V.4.2", "- Nguyên liệu, vật liệu", "CT", "", CN(152)),
      R("V.4.3", "- Công cụ, dụng cụ", "CT", "", CN(153)),
      R("V.4.4", "- Chi phí sản xuất kinh doanh dở dang", "CT", "", CN(154)),
      R("V.4.5", "- Thành phẩm", "CT", "", CN(155)),
      R("V.4.6", "- Hàng hóa", "CT", "", CN(156)),
      R("V.4.7", "- Hàng gửi bán", "CT", "", CN(157)),
      R("V.4.7.1", "Trong đó:", "CT", "", T2),
      R("V.4.7.2", "- Giá trị hàng tồn kho ứ đọng, kém, mất phẩm chất không có khả năng tiêu thụ;", "CT", "", T2),
      R("V.4.7.3", "- Giá trị hàng tồn kho dùng để thế chấp, cầm cố bảo đảm các khoản nợ phải trả;", "CT", "", T2),
      R("V.4.7.4", "- Nguyên nhân và hướng xử lý đối với hàng tồn kho ứ đọng, kém, mất phẩm chất.", "CT", "", T2),
      R("V.4.7.5", "- Lý do dẫn đến việc trích lập thêm hoặc hoàn nhập dự phòng giảm giá hàng tồn kho.", "CT", "", T2)]
V7 = [R("V.7", "7. Xây dựng cơ bản dở dang", "TD", "DN"),
      R("V.7.1", "- Mua sắm", "CT", "", CN(2411)),
      R("V.7.2", "- XDCB", "CT", "", CN(2412)),
      R("V.7.3", "- Sửa chữa lớn TSCĐ", "CT", "", CN(2413))]
V8 = [R("V.8", "8. Tài sản khác", "TD", "DN"),
      R("V.8.1", "- Chi phí trả trước (chi tiết ngắn hạn, dài hạn theo yêu cầu quản lý của doanh nghiệp)", "CT", "", CN(242)),
      R("V.8.2", "- Các khoản phải thu của Nhà nước", "CT", "", ("DUNOCK_ChitietTheoTK(333)", "DUNODK_ChitietTheoTK(333)"))]
V9 = [R("V.9", "9. Các khoản phải trả", "TD", "DN"),
      R("V.9.0", "(Tùy theo yêu cầu quản lý của doanh nghiệp, có thể thuyết minh chi tiết ngắn hạn và dài hạn)", "CT", "", T2),
      R("V.9.a", "a) Phải trả người bán", "CT", "", ("DUCOCK_ChitietTheoTKvaDoituong(331)", "DUCODK_ChitietTheoTKvaDoituong(331)")),
      R("V.9.a.1", "Trong đó: Phải trả các bên liên quan", "CT", "", T2),
      R("V.9.b", "b) Người mua trả tiền trước", "CT", "", ("DUCOCK_ChitietTheoTKvaDoituong(131)", "DUCODK_ChitietTheoTKvaDoituong(131)")),
      R("V.9.b.1", "Trong đó: Nhận trước của các bên liên quan", "CT", "", T2),
      R("V.9.c", "c) Phải trả khác (Chi tiết theo yêu cầu quản lý):", "TH", "",
        (TONG("V.9.c.1", "V.9.c.2", "V.9.c.3", "V.9.c.4", "V.9.c.5", "V.9.c.6"),) * 2),
      R("V.9.c.1", "- Chi phí phải trả", "CT", "", CN(335, "CO")),
      R("V.9.c.2", "- Phải trả nội bộ khác", "CT", "", CN(3368, "CO")),
      R("V.9.c.3", "- Phải trả, phải nộp khác", "CT", "", T2),
      R("V.9.c.4", "+ Tài sản thừa chờ xử lý", "CT", "", CN(3381, "CO")),
      R("V.9.c.5", "+ Các khoản phải nộp theo lương", "CT", "",
        ("DUCOCK_ChitietTheoTK(3382) + DUCOCK_ChitietTheoTK(3383) + DUCOCK_ChitietTheoTK(3384) + DUCOCK_ChitietTheoTK(3385)",
         "DUCODK_ChitietTheoTK(3382) + DUCODK_ChitietTheoTK(3383) + DUCODK_ChitietTheoTK(3384) + DUCODK_ChitietTheoTK(3385)")),
      R("V.9.c.6", "+ Các khoản khác", "CT", "",
        ("DUCOCK_ChitietTheoTK(1388) + DUCOCK_ChitietTheoTK(3388)", "DUCODK_ChitietTheoTK(1388) + DUCODK_ChitietTheoTK(3388)")),
      R("V.9.d", "d) Nợ quá hạn chưa thanh toán", "CT", "", T2)]
V12 = [R("V.12", "12. Dự phòng phải trả", "TD", "DN"),
       R("V.12.1", "- Dự phòng bảo hành sản phẩm hàng hóa", "CT", "", CN(3521, "CO")),
       R("V.12.2", "- Dự phòng bảo hành công trình xây dựng", "CT", "", CN(3522, "CO")),
       R("V.12.3", "- Dự phòng phải trả khác", "CT", "", CN(3524, "CO"))]
V14 = [R("V.14", "14. Các khoản mục ngoài Báo cáo tình hình tài chính", "TD", "DN"),
       R("V.14.a", "a) Tài sản thuê ngoài (Chi tiết số lượng, chủng loại và các thông tin quan trọng khác đối với các tài sản thuê ngoài chủ yếu)",
         "TD", ""),
       R("V.14.a.1", "- Từ 1 năm trở xuống", "CT", "", T2),
       R("V.14.a.2", "- Trên 1 năm đến 5 năm", "CT", "", T2),
       R("V.14.a.3", "- Trên 5 năm", "CT", "", T2),
       R("V.14c", "c) Ngoại tệ các loại: (Thuyết minh chi tiết số lượng từng loại nguyên tệ)", "TD", ""),
       R("V.14.d", "d) Nợ khó đòi đã xử lý", "CT", "", T2),
       R("V.14.đ", "đ) Thông tin về các khoản tiền phạt, phải thu về lãi trả chậm, ... phát sinh từ các khoản nợ quá hạn nhưng không được ghi "
                   "nhận doanh thu", "CT", "", T2),
       R("V.14.e", "e) Các thông tin khác về các khoản mục ngoài Báo cáo tình hình tài chính", "CT", "", T2)]

VI_TD = R("VI", "VI. Thông tin bổ sung cho các khoản mục trình bày trong Báo cáo kết quả hoạt động kinh doanh", "TD", "D")


def NN(ct_nay):
    """(Nam nay, Nam truoc): cong thuc nam truoc = cung ham them hau to _NamTruoc (video)."""
    return (ct_nay, re.sub(r"\b(Phatsinh(?:NO|CO|DU)(?:_Chitiet[A-Za-z]+)?)\(", r"\1_NamTruoc(", ct_nay))


VI1 = [R("VI.1", "1. Tổng doanh thu bán hàng và cung cấp dịch vụ", "TD", "DN"),
       R("VI.1.a", "a) Doanh thu", "CT", "", T2),
       R("VI.1.a.1", "- Doanh thu bán hàng hóa", "CT", "",
         (F_5111_CN, "PhatsinhCO_NamTruoc(5111) - PhatsinhDU_NamTruoc(911/5111) - PhatsinhCO_ChitietChietKhauThuongmai_NamTruoc(5111) - "
                     "PhatsinhCO_ChitietGiamgiaHangBan_NamTruoc(5111) - PhatsinhCO_ChitietTralaiHangBan_NamTruoc(5111) - PhatsinhNO_NamTruoc(5111) + "
                     "PhatsinhDU_NamTruoc(5111/911) + PhatsinhNO_ChitietChietKhauThuongmai_NamTruoc(5111) + "
                     "PhatsinhNO_ChitietGiamgiaHangBan_NamTruoc(5111) + PhatsinhNO_ChitietTralaiHangBan_NamTruoc(5111)")),
       R("VI.1.a.2", "- Doanh thu bán thành phẩm", "CT", "", (F_DT_CN(5112), F_DT_NT(5112))),
       R("VI.1.a.3", "- Doanh thu cung cấp dịch vụ", "CT", "", (F_DT_CN(5113), F_DT_NT(5113))),
       R("VI.1.a.4", "- Doanh thu khác", "CT", "", (F_DT_CN(5118), F_DT_NT(5118))),
       R("VI.1.b", "b) Doanh thu từ các bên liên quan (chi tiết cho từng đối tượng)", "CTH", ""),
       R("VI.1.c", "c) Trường hợp ghi nhận doanh thu cho thuê tài sản là tổng số tiền nhận trước, doanh nghiệp phải thuyết minh thêm để so sánh "
                   "sự khác biệt giữa việc ghi nhận doanh thu theo phương pháp phân bổ dần theo thời gian cho thuê; Khả năng suy giảm lợi nhuận "
                   "và luồng tiền trong tương lai do đã ghi nhận doanh thu đối với toàn bộ số tiền nhận trước", "CTH", "")]
VI2 = [R("VI.2", "2. Các khoản giảm trừ doanh thu", "TD", "DN"),
       R("VI.2.1", "- Chiết khấu thương mại", "CT", "",
         NN("PhatsinhNO_ChitietChietKhauThuongmai(511) - PhatsinhCO_ChitietChietKhauThuongmai(511)")),
       R("VI.2.2", "- Giảm giá hàng bán", "CT", "", NN("PhatsinhNO_ChitietGiamgiaHangBan(511) - PhatsinhCO_ChitietGiamgiaHangBan(511)")),
       R("VI.2.3", "- Hàng bán bị trả lại", "CT", "", NN("PhatsinhNO_ChitietTralaiHangBan(511) - PhatsinhCO_ChitietTralaiHangBan(511)"))]
VI3 = [R("VI.3", "3. Giá vốn hàng bán", "TD", "DN"),
       R("VI.3.1", "- Giá vốn của hàng hóa đã bán", "CT", "", NN("PhatsinhDU(911/632) - PhatsinhDU(632/911)")),
       R("VI.3.2", "- Giá vốn của thành phẩm đã bán", "CT", "", T2),
       R("VI.3.3", "- Giá vốn của dịch vụ đã cung cấp", "CT", "", T2),
       R("VI.3.4", "- Giá vốn khác", "CT", "", T2),
       R("VI.3.5", "- Các khoản chi phí khác được tính vào giá vốn", "CT", "", T2),
       R("VI.3.6", "- Các khoản ghi giảm giá vốn hàng bán", "CT", "", T2)]
VI4 = [R("VI.4", "4. Doanh thu hoạt động tài chính", "TD", "DN"),
       R("VI.4.1", "- Lãi tiền gửi, tiền cho vay", "CT", "", T2),
       R("VI.4.2", "- Lãi bán các khoản đầu tư tài chính", "CT", "", T2),
       R("VI.4.3", "- Cổ tức, lợi nhuận được chia", "CT", "", T2),
       R("VI.4.4", "- Lãi chênh lệch tỷ giá", "CT", "", T2),
       R("VI.4.5", "- Lãi bán hàng trả chậm, chiết khấu thanh toán", "CT", "", T2),
       R("VI.4.6", "- Doanh thu hoạt động tài chính khác", "CT", "", NN("PhatsinhDU(515/911) - PhatsinhDU(911/515)"))]
VI5 = [R("VI.5", "5. Chi phí tài chính", "TD", "DN"),
       R("VI.5.1", "- Lãi tiền vay", "CT", "", T2),
       R("VI.5.2", "- Chiết khấu thanh toán, lãi mua hàng trả chậm", "CT", "", T2),
       R("VI.5.3", "- Lỗ do bán các khoản đầu tư tài chính", "CT", "", T2),
       R("VI.5.4", "- Lỗ chênh lệch tỷ giá", "CT", "", T2),
       R("VI.5.5", "- Dự phòng giảm giá chứng khoán kinh doanh và tổn thất đầu tư vào đơn vị khác", "CT", "", T2),
       R("VI.5.6", "- Chi phí tài chính khác", "CT", "", NN("PhatsinhDU(911/635) - PhatsinhDU(635/911)")),
       R("VI.5.7", "- Các khoản ghi giảm chi phí tài chính", "CT", "", T2)]
VI6 = [R("VI.6", "6. Chi phí quản lý kinh doanh", "TD", "DN"),
       R("VI.6.a", "a) Các khoản chi phí quản lý doanh nghiệp phát sinh trong kỳ", "CT", "", NN("PhatsinhNO(6422) - PhatsinhDU(6422/911)")),
       R("VI.6.b", "b) Các khoản chi phí bán hàng phát sinh trong kỳ", "CT", "", NN("PhatsinhNO(6421) - PhatsinhDU(6421/911)")),
       R("VI.6.c", "c) Các khoản ghi giảm chi phí quản lý kinh doanh", "CT", "", T2),
       R("VI.6.c.1", "- Hoàn nhập các khoản dự phòng", "CT", "", NN("PhatsinhDU(352/642)")),
       R("VI.6.c.2", "- Các khoản ghi giảm khác", "CT", "", NN("PhatsinhCO(642) - PhatsinhDU(352/642) - PhatsinhDU(911/642)"))]
VI7 = [R("VI.7", "7. Thu nhập khác", "TD", "DN"),
       R("VI.7.1", "- Lãi thanh lý, nhượng bán TSCĐ", "CT", "", T2),
       R("VI.7.2", "- Lãi do đánh giá lại tài sản", "CT", "", T2),
       R("VI.7.3", "- Tiền phạt thu được", "CT", "", T2),
       R("VI.7.4", "- Thuế được giảm, được hoàn", "CT", "", T2),
       R("VI.7.5", "- Các khoản khác", "CT", "", NN("PhatsinhDU(711/911) - PhatsinhDU(911/711)"))]
VI8 = [R("VI.8", "8. Chi phí khác", "TD", "DN"),
       R("VI.8.1", "- Lỗ thanh lý, nhượng bán TSCĐ", "CT", "", T2),
       R("VI.8.2", "- Lỗ do đánh giá lại tài sản", "CT", "", T2),
       R("VI.8.3", "- Các khoản bị phạt", "CT", "", T2),
       R("VI.8.4", "- Các khoản khác", "CT", "", NN("PhatsinhDU(911/811) - PhatsinhDU(811/911)"))]
VI9 = [R("VI.9", "9. Chi phí thuế thu nhập doanh nghiệp hiện hành", "TD", "DN"),
       R("VI.9.1", "- Chi phí thuế thu nhập doanh nghiệp tính trên thu nhập chịu thuế năm hiện hành", "CT", "",
         NN("PhatsinhDU(911/821) - PhatsinhDU(821/911)")),
       R("VI.9.2", "- Điều chỉnh chi phí thuế thu nhập doanh nghiệp của các năm trước vào chi phí thuế thu nhập năm hiện hành", "CT", "", T2),
       R("VI.9.3", "- Tổng chi phí thuế thu nhập doanh nghiệp hiện hành", "CT", "", NN("PhatsinhDU(911/821) - PhatsinhDU(821/911)"))]

# ---- the 3..7 ------------------------------------------------------------------------------------------------------------
V5 = [R("V.5", "5. Tăng, giảm tài sản cố định (Chi tiết từng loại tài sản theo yêu cầu quản lý của doanh nghiệp):", "TD", "DN"),
      R("V.5.A", "A. TSCĐ hữu hình", "TH", "D", T4),
      R("V.5.A.1", "Nguyên giá", "CT", "", TG(2111)),
      R("V.5.A.2", "Giá trị hao mòn lũy kế", "CT", "",
        ("DUCODK(2141) + HaomonluykeDK_TSCD_loai16()", "PhatsinhCO(2141) + HaomonPStang_TSCD_loai16()",
         "PhatsinhNO(2141) + HaomonPSgiam_TSCD_loai16()", "DUCOCK(2141) + HaomonluykeCK_TSCD_loai16()")),
      R("V.5.A.3", "Giá trị còn lại", "TH", "", CL("V.5.A.1", "V.5.A.2")),
      R("V.5.B", "B. TSCĐ vô hình", "TH", "D", T4),
      R("V.5.B.1", "Nguyên giá", "CT", "", TG(2113)),
      R("V.5.B.2", "Giá trị hao mòn lũy kế", "CT", "", TG(2143, "CO")),
      R("V.5.B.3", "Giá trị còn lại", "TH", "", CL("V.5.B.1", "V.5.B.2")),
      R("V.5.C", "C. TSCĐ thuê tài chính", "TH", "D", T4),
      R("V.5.C.1", "Nguyên giá", "CT", "", TG(2112)),
      R("V.5.C.2", "Giá trị hao mòn lũy kế", "CT", "", TG(2142, "CO")),
      R("V.5.C.3", "Giá trị còn lại", "TH", "", CL("V.5.C.1", "V.5.C.2")),
      R("V.5.C.3.1", "- Giá trị còn lại cuối kỳ của TSCĐ dùng để thế chấp, cầm cố đảm bảo khoản vay", "CTH", "N"),
      R("V.5.C.3.2", "- Nguyên giá TSCĐ cuối năm đã khấu hao hết nhưng vẫn còn sử dụng", "CTH", "N"),
      R("V.5.C.3.3", "- Nguyên giá TSCĐ cuối năm chờ thanh lý", "CTH", "N"),
      R("V.5.C.3.4", "- Đối với TSCĐ thuê tài chính", "CTH", "N"),
      R("V.5.C.3.5", "-Thuyết minh số liệu và giải trình khác.", "CTH", "N")]
V6 = [R("V.6", "6. Tăng, giảm bất động sản đầu tư (Chi tiết theo yêu cầu quản lý của doanh nghiệp):", "TD", "DN"),
      R("V.6.a", "a) Bất động sản đầu tư cho thuê", "TH", "D", T4),
      R("V.6.a.1", "- Nguyên giá", "CT", "", TG(217)),
      R("V.6.a.2", "- Giá trị hao mòn lũy kế", "CT", "", TG(2147, "CO")),
      R("V.6.a.3", "- Giá trị còn lại", "TH", "", CL("V.6.a.1", "V.6.a.2")),
      R("V.6.b", "b) Bất động sản đầu tư nắm giữ chờ tăng giá", "TH", "D", T4),
      R("V.6.b.1", "- Nguyên giá", "CT", "", T4),
      R("V.6.b.2", "- Giá trị hao mòn lũy kế của BĐSĐT cho thuê/TSCĐ chuyển sang BĐSĐT nắm giữ chờ tăng giá", "CT", "", T4),
      R("V.6.b.3", "- Tổn thất do suy giảm giá trị", "CT", "", T4),
      R("V.6.b.4", "- Giá trị còn lại", "CT", "", T4),
      R("V.6.b.5", "- Giá trị còn lại cuối kỳ của BĐSĐT dùng để thế chấp, cầm cố đảm bảo khoản vay", "CTH", "N"),
      R("V.6.b.6", "- Nguyên giá BĐSĐT đã khấu hao hết nhưng vẫn cho thuê hoặc nắm giữ chờ tăng giá", "CTH", "N"),
      R("V.6.b.7", "- Thuyết minh số liệu và giải trình khác.", "CTH", "N")]
V10 = [R("V.10", "10. Thuế và các khoản phải nộp nhà nước", "TD", "DN"),
       R("V.10.1", "- Thuế giá trị gia tăng", "CT", "", ("DUCODK(3331)", F_VAT_PN, F_VAT_DN, "DUCOCK(3331)"))]
for _i, (_tk, _ten) in enumerate((("3332", "- Thuế tiêu thụ đặc biệt"), ("3333", "- Thuế xuất, nhập khẩu"), ("3334", "- Thuế thu nhập doanh nghiệp"),
                                  ("3335", "- Thuế thu nhập cá nhân"), ("3336", "- Thuế tài nguyên"), ("3337", "- Thuế nhà đất và tiền thuê đất"),
                                  ("3338", "- Các loại thuế khác"), ("3339", "- Các khoản phí, lệ phí và các khoản phải nộp khác"))):
    V10.append(R("V.10.%d" % (_i + 2), _ten, "CT", "", ("DUCODK(%s)" % _tk, F_THUE_PN(_tk), F_THUE_DN(_tk), "DUCOCK(%s)" % _tk)))
V11 = [R("V.11", "11. Vay và nợ thuê tài chính", "TD", "DN"),
       R("V.11.1", "a) Vay ngắn hạn", "CT", "", ("DUCOCK(3411) - DUNOCK(3411)", "PhatsinhCO(3411)", "PhatsinhNO(3411)", "DUCODK(3411) - DUNODK(3411)")),
       R("V.11.2", "Trong đó: Vay từ các bên liên quan", "CT", "", T4),
       R("V.11.3", "b) Vay dài hạn", "CT", "", T4),
       R("V.11.4", "Trong đó: Vay từ các bên liên quan", "CT", "", T4),
       R("V.11.5", "c) Các khoản nợ gốc thuê tài chính", "CT", "",
         ("DUCOCK(3412) - DUNOCK(3412)", "PhatsinhCO(3412)", "PhatsinhNO(3412)", "DUCODK(3412) - DUNODK(3412)")),
       R("V.11.6", "Trong đó: Nợ thuê tài chính từ các bên liên quan", "CT", "", T4)]
V13 = [R("V.13", "13. Vốn chủ sở hữu", "TD", "DN"),
       R("V.13.1", "a) Bảng đối chiếu biến động của vốn chủ sở hữu", "TD", ""),
       R("V.13.2", "Số dư đầu năm", "CT", "",
         ("DUCODK(4111)", "DUCODK(4112) - DUNODK(4112)", "DUCODK(4118)", "- DUNODK(419)", "DUCODK(413) - DUNODK(413)",
          "DUCODK(418) + DUCODK(421) - DUNODK(418) - DUNODK(421)",
          "DUCODK(4111) + DUCODK(4112) - DUNODK(4112) + DUCODK(4118) - DUNODK(419) + DUCODK(418) + DUCODK(421) - DUNODK(418) - DUNODK(421) + "
          "DUCODK(413) - DUNODK(413)")),
       R("V.13.3", "Tăng vốn trong năm", "CT", "",
         ("PhatsinhCO(4111)", "PhatsinhCO(4112)", "PhatsinhCO(4118)", "- PhatsinhNO(419)", "PhatsinhCO(413)", "PhatsinhCO(418) + PhatsinhCO(421)",
          "PhatsinhCO(4111) + PhatsinhCO(4112) + PhatsinhCO(4118) - PhatsinhNO(419) + PhatsinhCO(413) + PhatsinhCO(418) + PhatsinhCO(421)")),
       R("V.13.4", "Giảm vốn trong năm", "CT", "",
         ("PhatsinhNO(4111)", "PhatsinhNO(4112)", "PhatsinhNO(4118)", "- PhatsinhCO(419)", "PhatsinhNO(413)", "PhatsinhNO(418) + PhatsinhNO(421)",
          "PhatsinhNO(4111) + PhatsinhNO(4112) + PhatsinhNO(4118) - PhatsinhCO(419) + PhatsinhNO(413) + PhatsinhNO(418) + PhatsinhNO(421)")),
       R("V.13.5", "Số dư cuối năm", "CT", "",
         ("DUCOCK(4111)", "DUCOCK(4112) - DUNOCK(4112)", "DUCOCK(4118)", "- DUNOCK(419)", "DUCOCK(413) - DUNOCK(413)",
          "DUCOCK(418) + DUCOCK(421) - DUNOCK(418) - DUNOCK(421)",
          "DUCOCK(4112) - DUNOCK(4112) + DUCOCK(4118) - DUNOCK(419) + DUCOCK(413) - DUNOCK(413) + DUCOCK(418) + DUCOCK(421) - DUNOCK(418) - "
          "DUNOCK(421) + DUCOCK(4111)")),
       R("V.13.6", "- Thuyết minh và giải trình khác về vốn chủ sở hữu (nguyên nhân biến động và các thông tin khác).", "CTH", "")]

COT_CN = ("Cuối năm", "Đầu năm")
COT_NN = ("Năm nay", "Năm trước")
COT_V5 = ("Số dư đầu năm", "Tăng trong năm", "Giảm trong năm", "Số dư cuối năm")
COT_V6 = ("Số đầu năm", "Tăng trong năm", "Giảm trong năm", "Số cuối năm")
COT_V10 = ("Đầu năm", "Số phải nộp trong năm", "Số đã thực nộp trong năm", "Cuối năm")
COT_V11 = ("Cuối năm", "Tăng trong năm", "Giảm trong năm", "Đầu năm")
COT_V13 = ("Vốn góp của chủ sở hữu", "Thặng dư vốn cổ phần", "Vốn khác của chủ sở hữu", "Cổ phiếu quỹ", "Chênh lệch tỷ giá",
           "LNST chưa phân phối và các quỹ", "Cộng")

# thu tu in theo mau B09-DNN TT133: (kieu, the video, cot, dong)
KHOI = [("VB", 1, None, THE1_I),
        ("TD", 2, None, [V_TD]),
        ("BANG", 2, COT_CN, V1), ("BANG", 2, COT_CN, V2), ("BANG", 2, COT_CN, V3), ("BANG", 2, COT_CN, V4),
        ("BANG", 3, COT_V5, V5), ("BANG", 4, COT_V6, V6),
        ("BANG", 2, COT_CN, V7), ("BANG", 2, COT_CN, V8), ("BANG", 2, COT_CN, V9),
        ("BANG", 5, COT_V10, V10), ("BANG", 6, COT_V11, V11), ("BANG", 2, COT_CN, V12), ("BANG", 7, COT_V13, V13),
        ("BANG", 2, COT_CN, V14),
        ("VB", 1, None, THE1_V15), ("VB", 1, None, THE1_V16),
        ("TD", 2, None, [VI_TD]),
        ("BANG", 2, COT_NN, VI1), ("BANG", 2, COT_NN, VI2), ("BANG", 2, COT_NN, VI3), ("BANG", 2, COT_NN, VI4), ("BANG", 2, COT_NN, VI5),
        ("BANG", 2, COT_NN, VI6), ("BANG", 2, COT_NN, VI7), ("BANG", 2, COT_NN, VI8), ("BANG", 2, COT_NN, VI9),
        ("VB", 1, None, THE1_VII), ("VB", 1, None, THE1_VIII)]
TEN_THE = {1: "1. Thông tin chung", 2: "2. Thông tin bổ sung", 3: "3. Tài sản cố định", 4: "4. Bất động sản đầu tư",
           5: "5. Thuế và các khoản phải nộp", 6: "6. Vay và nợ thuê tài chính", 7: "7. Vốn chủ sở hữu"}


def tat_ca_chi_tieu():
    """[(the, cot, dong)] theo thu tu in."""
    ra = []
    for _k, the, cot, ds in KHOI:
        for d in ds:
            ra.append((the, cot, d))
    return ra


# ==========================================================================================================================
#  LAM TRON, BO PHAN TICH CONG THUC
# ==========================================================================================================================
def tron(x):
    """lam tron dong: nua xa 0 (nhu HTKK)."""
    if x is None:
        return None
    return int(math.floor(abs(x) + 0.5)) * (1 if x >= 0 else -1)


RE_TOKEN = re.compile(r"\s*(?:(?P<so>\d+(?:\.\d+)?)|(?P<ref>\[[^\]]+\])|(?P<ham>[A-Za-z_][A-Za-z0-9_]*)\s*\((?P<doi>[^()]*)\)|(?P<op>[-+*/()]))")


class LoiCongThuc(Exception):
    pass


def phan_tich(ct):
    """chuoi cong thuc -> cay: ("so", x) | ("ref", ma) | ("ham", ten, doi) | ("am", cay) | (op, trai, phai)."""
    tok, i, s = [], 0, ct.strip()
    while i < len(s):
        m = RE_TOKEN.match(s, i)
        if not m or m.end() == i:
            raise LoiCongThuc("không đọc được công thức tại '%s'" % s[i:i + 20])
        i = m.end()
        if m.group("so"):
            tok.append(("so", float(m.group("so"))))
        elif m.group("ref"):
            tok.append(("ref", m.group("ref")[1:-1].strip()))
        elif m.group("ham"):
            tok.append(("ham", m.group("ham"), m.group("doi").strip()))
        else:
            tok.append(("op", m.group("op")))
        while i < len(s) and s[i].isspace():
            i += 1
    vt = [0]

    def xem():
        return tok[vt[0]] if vt[0] < len(tok) else ("het",)

    def an():
        t = xem()
        vt[0] += 1
        return t

    def bieu_thuc():
        a = so_hang()
        while xem()[0] == "op" and xem()[1] in "+-":
            op = an()[1]
            a = (op, a, so_hang())
        return a

    def so_hang():
        a = nhan_tu()
        while xem()[0] == "op" and xem()[1] in "*/":
            op = an()[1]
            a = (op, a, nhan_tu())
        return a

    def nhan_tu():
        t = an()
        if t[0] == "op" and t[1] == "-":
            return ("am", nhan_tu())
        if t[0] == "op" and t[1] == "+":
            return nhan_tu()
        if t[0] == "op" and t[1] == "(":
            a = bieu_thuc()
            if an() != ("op", ")"):
                raise LoiCongThuc("thiếu ngoặc đóng trong '%s'" % ct)
            return a
        if t[0] in ("so", "ref", "ham"):
            return t
        raise LoiCongThuc("công thức sai cú pháp: '%s'" % ct)
    cay = bieu_thuc()
    if vt[0] != len(tok):
        raise LoiCongThuc("thừa ký hiệu trong '%s'" % ct)
    return cay


RE_HAM_DU = re.compile(r"^DU(NO|CO)(CK|DK)(?:_(ChitietTheoTK|ChitietTheoTKvaDoituong))?$", re.I)
RE_HAM_PS = re.compile(r"^Phatsinh(NO|CO|DU)(?:_Chitiet(ChietKhauThuongmai|GiamgiaHangBan|TralaiHangBan))?(_NamTruoc)?$", re.I)
RE_HAM_VAT = re.compile(r"^Phatsinh(NO|DU)GiamVAT(_NamTruoc)?$", re.I)
RE_HAM_HM = re.compile(r"^Haomon(luykeDK|PStang|PSgiam|luykeCK)_TSCD_loai16$", re.I)


def ham_hop_le(ten):
    return bool(RE_HAM_DU.match(ten) or RE_HAM_PS.match(ten) or RE_HAM_VAT.match(ten) or RE_HAM_HM.match(ten))


def cac_ham(cay, ra=None):
    ra = [] if ra is None else ra
    if cay[0] == "ham":
        ra.append((cay[1], cay[2]))
    elif cay[0] == "am":
        cac_ham(cay[1], ra)
    elif cay[0] in "+-*/":
        cac_ham(cay[1], ra)
        cac_ham(cay[2], ra)
    return ra


# ==========================================================================================================================
#  NGUON SO LIEU
# ==========================================================================================================================
# giam tru doanh thu: TK giam tru cu (QD15 / QD48 / TT200) - so TT133 khong co -> 0
GIAM_TRU = {"ChietKhauThuongmai": ("5211",), "TralaiHangBan": ("5212", "531"), "GiamgiaHangBan": ("5213", "532")}


class NguonNay(object):
    """So lieu ky lap (nam nay): du dau ky (DK) / cuoi ky (CK), phat sinh trong ky [t1, t2], doi ung, cong no theo doi tuong."""

    def __init__(self, dl, canh_bao):
        self.S = B.SoLieuBS(dl)
        self.cb = canh_bao
        self._la = {}
        self.nguoc = {}                          # (tk, ck) -> so du NGUOC ben ham tong hop lay (ham tra 0)
        S = self.S
        # doi ung: gom them dong le (chung tu mot ben No hoac Co) ghep trong cung chung tu khi chi co MOT TK o ben kia
        self.du = defaultdict(float)             # (maNo, maCo) -> tien trong ky
        for (a, b), th in S.du.items():
            v = sum(x for t, x in th.items() if S.t1 <= t <= S.t2)
            if v:
                self.du[(a, b)] += v
        b09 = dl.get("b09") or {}
        self.le_ghep, self.le_mo = ghep_le([(r[0], r[1], r[2], r[3], r[4]) for r in (b09.get("le") or []) if len(r) >= 5],
                                           lambda th: S.t1 <= thang_tc(th, S.dau_ky) <= S.t2)
        for (a, b), v in self.le_ghep.items():
            self.du[(int(_so(a)), int(_so(b)))] += v
        # cong no theo doi tuong
        self.la_cn, self.cn = K._cong_no(S)
        self.lech_cn = {}
        for m in self.la_cn:
            dau = sum(v[0] for v in self.cn[m].values())
            cuoi = sum(v[0] + v[1] - v[2] for v in self.cn[m].values())
            ld, lc = S.du_dau(m) - dau, S.du_cuoi(m) - cuoi
            if abs(ld) > 1 or abs(lc) > 1:
                self.lech_cn[m] = (ld, lc)

    def la(self, tt):
        tt = str(tt).strip()
        if tt not in self._la:
            self._la[tt] = [m for m in self.S.la if self.S.sh(m).startswith(tt)] if tt else []
        return self._la[tt]

    def co_tk(self, tt):
        return bool(self.la(tt))

    # ---- so du
    def du_tk(self, m, ck):
        return self.S.du_cuoi(m) if ck else self.S.du_dau(m)

    def du_doi_tuong(self, m, ck):
        """[so du (No - Co) tung doi tuong] cua TK la m (None neu TK khong theo doi doi tuong). Lech so tong hop -> them 1 'doi tuong' phan lech."""
        if m not in self.la_cn:
            return None
        ds = [(v[0] + v[1] - v[2]) if ck else v[0] for v in self.cn[m].values()]
        lech = self.lech_cn.get(m)
        if lech:
            ds.append(lech[1] if ck else lech[0])
        return ds

    def ham_du(self, ben, ck, kieu, tk):
        k = 1 if ben == "NO" else -1
        la = self.la(tk)
        if not kieu:
            v = k * sum(self.du_tk(m, ck) for m in la)
            if v <= -1:
                self.nguoc[(str(tk).strip(), ck)] = -v
            return max(0.0, v)
        if kieu.lower() == "chitiettheotk":
            return sum(max(0.0, k * self.du_tk(m, ck)) for m in la)
        tong = 0.0
        for m in la:
            ds = self.du_doi_tuong(m, ck)
            if ds is None:
                tong += max(0.0, k * self.du_tk(m, ck))
            else:
                tong += sum(max(0.0, k * x) for x in ds)
        return tong

    # ---- phat sinh
    def ps(self, ben, tk):
        n = c = 0.0
        for m in self.la(tk):
            a, b = self.S.ps_ky(m, True)
            n += a
            c += b
        return n if ben == "NO" else c

    def doi_ung(self, a, b):
        la_a, la_b = set(self.la(a)), set(self.la(b))
        if not la_a or not la_b:
            return 0.0
        return sum(v for (x, y), v in self.du.items() if x in la_a and y in la_b)

    def giam_vat(self, tk):
        """PS No tk khong doi ung 133 va khong thuoc nhom 'da nop' (quy uoc GD77 NVNN)."""
        tong = 0.0
        for m in self.la(tk):
            sh = self.S.sh(m)
            tong += self.ps("NO", sh) - self.doi_ung(sh, "133") - sum(self.doi_ung(sh, g) for g in NOP)
        return tong


def ghep_le(rows, trong_ky):
    """Dong chung tu MOT ben (chi No hoac chi Co): ghep doi ung trong cung chung tu (MaCT, thang) khi ben kia chi co MOT TK.
    rows: (MaCT, thang, tkNo, tkCo, tien) - tk la ma so (nam nay) hoac so hieu (so nam truoc). -> ({(tkNo, tkCo): tien}, tien khong ghep duoc)."""
    nhom = defaultdict(lambda: (defaultdict(float), defaultdict(float)))
    for ct, th, n, c, v in rows:
        if trong_ky is not None and not trong_ky(th):
            continue
        v = _so(v)
        g = nhom[(ct, th)]
        if n not in (0, "0", "", None) and c in (0, "0", "", None):
            g[0][n] += v
        elif c not in (0, "0", "", None) and n in (0, "0", "", None):
            g[1][c] += v
    ghep, mo = defaultdict(float), 0.0
    for (ct, th), (ns, cs) in nhom.items():
        ns = {k: v for k, v in ns.items() if abs(v) > 0}
        cs = {k: v for k, v in cs.items() if abs(v) > 0}
        if len(cs) == 1 and ns:
            c = list(cs)[0]
            for n, v in ns.items():
                ghep[(n, c)] += v
        elif len(ns) == 1 and cs:
            n = list(ns)[0]
            for c, v in cs.items():
                ghep[(n, c)] += v
        else:
            mo += sum(ns.values())
    return ghep, mo


class NguonTruoc(object):
    """So lieu NAM TRUOC cho ham ..._NamTruoc.
    a) dl["b09"]["sotruoc"]: so ke toan nam truoc (KT<nam-1>*.MDB) VB doc chi doc -> phat sinh / doi ung theo so hieu: CHINH XAC.
    b) khong co so nam truoc: PS luy ke nam truoc (HethongTK.PSNLK<nam-1> / PSCLK<nam-1>, dl["b09"]["ps_truoc"]) - PhatsinhNO / CO chinh xac;
       PhatsinhDU: = 0 khi mot ben khong co phat sinh (chinh xac); cap ket chuyen 911 cua TK doanh thu / chi phi theo QUY UOC B02 nam
       truoc cua phan mem (ben No TK doanh thu, ben Co TK chi phi chi gom but toan ket chuyen); cap khac -> khong xac dinh (None)."""

    def __init__(self, dl, nguon_nay):
        b09 = dl.get("b09") or {}
        st = b09.get("sotruoc") or {}
        self.che_do = ""
        self.ps_sh = defaultdict(lambda: [0.0, 0.0])
        self.du_sh = defaultdict(float)
        self.tep = ""
        self.le_mo = 0.0
        if st and (st.get("ps") or st.get("doi_ung")):
            self.che_do = "SO"
            self.tep = str(st.get("tep") or "")
            for r in st.get("ps") or []:
                x = self.ps_sh[str(r[0]).strip()]
                x[0] += _so(r[1])
                x[1] += _so(r[2])
            for r in st.get("doi_ung") or []:
                self.du_sh[(str(r[0]).strip(), str(r[1]).strip())] += _so(r[2])
            g, self.le_mo = ghep_le([(r[0], 0, str(r[1] or "").strip(), str(r[2] or "").strip(), r[3]) for r in (st.get("le") or []) if len(r) >= 4],
                                    None)
            for k, v in g.items():
                self.du_sh[k] += v
        elif b09.get("ps_truoc"):
            self.che_do = "LUYKE"
            S = nguon_nay.S
            for r in b09["ps_truoc"]:
                m = int(_so(r[0]))
                t = S.tk.get(m)
                if not t or t["con"] != 0:
                    continue
                x = self.ps_sh[t["sh"]]
                x[0] += _so(r[1])
                x[1] += _so(r[2])
        self.dung_quy_uoc = set()

    def ps(self, ben, tk):
        tk = str(tk).strip()
        i = 0 if ben == "NO" else 1
        return sum(v[i] for k, v in self.ps_sh.items() if k.startswith(tk))

    def doi_ung(self, a, b):
        if self.che_do == "SO":
            return sum(v for (x, y), v in self.du_sh.items() if x.startswith(a) and y.startswith(b))
        if self.che_do != "LUYKE":
            return None
        if self.ps("NO", a) == 0 or self.ps("CO", b) == 0:
            return 0.0
        # quy uoc ket chuyen (nhu B02 nam truoc cua UNESCO: PS luy ke TK doanh thu / chi phi)
        if b.startswith("911") and a[:1] in ("5", "7"):
            self.dung_quy_uoc.add("%s/%s" % (a, b))
            return self.ps("NO", a)
        if a.startswith("911") and b[:1] in ("6", "8"):
            self.dung_quy_uoc.add("%s/%s" % (a, b))
            return self.ps("CO", b)
        if a.startswith("911") and b[:1] in ("5", "7"):
            self.dung_quy_uoc.add("%s/%s" % (a, b))
            return 0.0
        if b.startswith("911") and a[:1] in ("6", "8"):
            self.dung_quy_uoc.add("%s/%s" % (a, b))
            return 0.0
        return None


# ==========================================================================================================================
#  TINH CHI TIEU
# ==========================================================================================================================
class BoTinh(object):
    def __init__(self, dl, canh_bao):
        self.dl = dl
        self.cb = canh_bao
        self.nay = NguonNay(dl, canh_bao)
        self.truoc = NguonTruoc(dl, self.nay)
        self.dong = {}                       # ma -> R
        self.cot_cua = {}
        for _the, cot, d in tat_ca_chi_tieu():
            self.dong[d["ma"]] = d
            self.cot_cua[d["ma"]] = cot
        self.gt = {}                         # (ma, cot) -> gia tri lam tron / None
        self.ghi = defaultdict(set)          # (ma, cot) -> ghi chu nguon
        self._dang = set()
        self._cay = {}
        self.ham_dung = defaultdict(set)     # (tk, ck) -> ten ham du tong hop da goi
        self.ma_dung = defaultdict(set)      # (tk, ck) -> ma chi tieu

    def cay(self, ct):
        if ct not in self._cay:
            self._cay[ct] = phan_tich(ct)
        return self._cay[ct]

    def gia_tri(self, ma, i):
        """gia tri (da lam tron) cua chi tieu ma, cot i. None = khong xac dinh; "" = o nhap tay (de trong)."""
        k = (ma, i)
        if k in self.gt:
            return self.gt[k]
        d = self.dong.get(ma)
        if d is None or not d["ct"] or i >= len(d["ct"]):
            return ""
        ct = d["ct"][i]
        if not ct.strip():
            self.gt[k] = ""
            return ""
        if k in self._dang:
            raise LoiCongThuc("công thức vòng tại %s" % ma)
        self._dang.add(k)
        v = self.tinh(self.cay(ct), ma, i)
        self._dang.discard(k)
        self.gt[k] = tron(v)
        return self.gt[k]

    def tinh(self, c, ma, i):
        t = c[0]
        if t == "so":
            return c[1]
        if t == "ref":
            v = self.gia_tri(c[1], i)
            return 0.0 if v == "" else v
        if t == "am":
            v = self.tinh(c[1], ma, i)
            return None if v is None else -v
        if t == "ham":
            return self.ham(c[1], c[2], ma, i)
        a, b = self.tinh(c[1], ma, i), self.tinh(c[2], ma, i)
        if a is None or b is None:
            return None
        if t == "+":
            return a + b
        if t == "-":
            return a - b
        if t == "*":
            return a * b
        return a / b if b else 0.0

    def ham(self, ten, doi, ma, i):
        m = RE_HAM_DU.match(ten)
        if m:
            ck = m.group(2).upper() == "CK"
            if not m.group(3):
                self.ham_dung[(doi.strip(), ck)].add(ten)
                self.ma_dung[(doi.strip(), ck)].add(ma)
            return self.nay.ham_du(m.group(1).upper(), ck, m.group(3), doi)
        m = RE_HAM_PS.match(ten)
        if m:
            ben, gt, nt = m.group(1).upper(), m.group(2), bool(m.group(3))
            src = self.truoc if nt else self.nay
            if nt:
                self.ghi[(ma, i)].add("NT_" + (self.truoc.che_do or "KHONG"))
            if ben == "DU":
                a, _, b = doi.partition("/")
                if gt:
                    raise LoiCongThuc("hàm %s không dùng dạng đối ứng" % ten)
                return src.doi_ung(a.strip(), b.strip())
            if gt:
                tk_gt = GIAM_TRU[[k for k in GIAM_TRU if k.lower() == gt.lower()][0]]
                # phan phat sinh tk la giam tru: No tk doi ung Co TK giam tru cu / Co tk doi ung No TK giam tru cu
                tong = 0.0
                for g in tk_gt:
                    v = src.doi_ung(doi, g) if ben == "NO" else src.doi_ung(g, doi)
                    if v is None:
                        return None
                    tong += v
                self.ghi[(ma, i)].add("GIAM_TRU")
                return tong
            return src.ps(ben, doi)
        m = RE_HAM_VAT.match(ten)
        if m:
            if m.group(2):
                return None
            self.ghi[(ma, i)].add("GIAM_VAT")
            if m.group(1).upper() == "NO":
                return self.nay.giam_vat(doi)
            return 0.0
        m = RE_HAM_HM.match(ten)
        if m:
            self.ghi[(ma, i)].add("HM16")
            return 0.0
        raise LoiCongThuc("hàm không hỗ trợ: %s(%s)" % (ten, doi))

    def tinh_het(self):
        for ma, d in self.dong.items():
            if d["ct"]:
                for i in range(len(d["ct"])):
                    self.gia_tri(ma, i)


# ==========================================================================================================================
#  DOI CHIEU (kiem cheo voi B01a / B02 cua phan mem + dong nhat noi bo)
# ==========================================================================================================================
def _bctc(dl, ten):
    """{ma so (chuoi): (cot 1, cot 2)} tu dl["bctc"][ten] = [[MaSo, x, y], ...]."""
    ra = {}
    for r in ((dl.get("bctc") or {}).get(ten) or []):
        try:
            ma = str(int(_so(r[0])))
        except (TypeError, ValueError):
            ma = str(r[0]).strip()
        ra[ma] = (_so(r[1]) if len(r) > 1 and r[1] not in (None, "") else None, _so(r[2]) if len(r) > 2 and r[2] not in (None, "") else None)
    return ra


def _v(x):
    return x if isinstance(x, (int, float)) and not isinstance(x, bool) else 0


def doi_chieu(T, dl):
    """-> [(nhom, noi dung, cot, so thuyet minh, so bao cao / so doi chieu, chenh lech, ket luan)]."""
    g = T.gia_tri
    ra = []
    b01, b02 = _bctc(dl, "b01a"), _bctc(dl, "b02")

    def tong(ma_ds, i):
        vs = [g(m, i) for m in ma_ds]
        if any(v is None for v in vs):
            return None
        return sum(_v(v) for v in vs)

    def them(nhom, nd, cot, a, b, ghi=""):
        if a is None or b is None:
            ra.append((nhom, nd, cot, a, b, None, "Chưa đủ số liệu để đối chiếu" + ((" - " + ghi) if ghi else "")))
            return
        cl = tron(a - b)
        ra.append((nhom, nd, cot, tron(a), tron(b), cl, ("Khớp" if cl == 0 else "LỆCH") + ((" - " + ghi) if ghi and cl else "")))

    # --- B01a: (ma so, [(chi tieu, cot CN, cot DN, dau)], ghi chu)
    DS_B01 = [("110", [("V.1.1", 0, 1, 1), ("V.1.2", 0, 1, 1), ("V.1.3", 0, 1, 1)], "V.1 Tiền và tương đương tiền"),
              ("121", [("V.2.a", 0, 1, 1)], "V.2.a Chứng khoán kinh doanh"),
              ("122", [("V.2.b", 0, 1, 1)], "V.2.b Đầu tư nắm giữ đến ngày đáo hạn"),
              ("124", [("V.2.c", 0, 1, -1)], "V.2.c Dự phòng tổn thất đầu tư tài chính (B01a ghi âm)"),
              ("131", [("V.3.a", 0, 1, 1)], "V.3.a Phải thu của khách hàng"),
              ("132", [("V.3.b", 0, 1, 1)], "V.3.b Trả trước cho người bán"),
              ("134", [("V.3.c", 0, 1, 1)], "V.3.c Phải thu khác"),
              ("135", [("V.3.d", 0, 1, 1)], "V.3.d Tài sản thiếu chờ xử lý"),
              ("141", [("V.4.%d" % k, 0, 1, 1) for k in range(1, 8)], "V.4 Hàng tồn kho"),
              ("151", [("V.5.A.1", 3, 0, 1), ("V.5.B.1", 3, 0, 1), ("V.5.C.1", 3, 0, 1)], "V.5 Nguyên giá TSCĐ"),
              ("152", [("V.5.A.2", 3, 0, -1), ("V.5.B.2", 3, 0, -1), ("V.5.C.2", 3, 0, -1)], "V.5 Hao mòn lũy kế TSCĐ (B01a ghi âm)"),
              ("161", [("V.6.a.1", 3, 0, 1)], "V.6.a Nguyên giá BĐSĐT"),
              ("162", [("V.6.a.2", 3, 0, -1)], "V.6.a Hao mòn BĐSĐT (B01a ghi âm)"),
              ("170", [("V.7.1", 0, 1, 1), ("V.7.2", 0, 1, 1), ("V.7.3", 0, 1, 1)], "V.7 Xây dựng cơ bản dở dang"),
              ("182", [("V.8.1", 0, 1, 1), ("V.8.2", 0, 1, 1)], "V.8 Tài sản khác"),
              ("311", [("V.9.a", 0, 1, 1)], "V.9.a Phải trả người bán"),
              ("312", [("V.9.b", 0, 1, 1)], "V.9.b Người mua trả tiền trước"),
              ("313", [("V.10.%d" % k, 3, 0, 1) for k in range(1, 10)], "V.10 Thuế và các khoản phải nộp Nhà nước (B01a lấy dư Có từng TK "
               "chi tiết 333, thuyết minh lấy dư Có TK 333x - lệch khi TK chi tiết dư ngược bên)"),
              ("315", [("V.9.c", 0, 1, 1)], "V.9.c Phải trả khác (mẫu không gồm 3386, 3387, 344, 334 - chênh lệch là các TK này)"),
              ("316", [("V.11.1", 0, 3, 1), ("V.11.3", 0, 3, 1), ("V.11.5", 0, 3, 1)], "V.11 Vay và nợ thuê tài chính"),
              ("317", [("V.12.1", 0, 1, 1), ("V.12.2", 0, 1, 1), ("V.12.3", 0, 1, 1)], "V.12 Dự phòng phải trả"),
              ("400", [("V.13.5", 6, None, 1)], "V.13 Vốn chủ sở hữu - Số dư cuối năm, cột Cộng"),
              ("400", [("V.13.2", None, 6, 1)], "V.13 Vốn chủ sở hữu - Số dư đầu năm, cột Cộng")]
    if not b01:
        ra.append(("B01a", "Chưa có số B01a-DNN của phần mềm trong dữ liệu (chọn thêm mục B01a) - bỏ qua đối chiếu B01a", "", None, None, None, ""))
    else:
        for ma_so, ds, nd in DS_B01:
            for k, cot_ten in ((0, "Cuối năm"), (1, "Đầu năm")):
                x = [(m, (c if k == 0 else d), dau) for m, c, d, dau in ds]
                if any(c is None for _, c, _ in x):
                    continue
                vs = [g(m, c) for m, c, _ in x]
                a = None if any(v is None for v in vs) else sum(_v(v) * dau for v, (_, _, dau) in zip(vs, x))
                bb = b01.get(ma_so, (None, None))[k]
                them("B01a", "%s = B01a mã %s" % (nd, ma_so), cot_ten, a, bb)
    # --- B02
    DS_B02 = [("10", [("VI.1.a.1", 1), ("VI.1.a.2", 1), ("VI.1.a.3", 1), ("VI.1.a.4", 1), ("VI.2.1", -1), ("VI.2.2", -1), ("VI.2.3", -1)],
               "VI.1.a - VI.2 = Doanh thu thuần"),
              ("02", [("VI.2.1", 1), ("VI.2.2", 1), ("VI.2.3", 1)], "VI.2 Các khoản giảm trừ doanh thu"),
              ("11", [("VI.3.%d" % k, 1) for k in range(1, 6)] + [("VI.3.6", -1)], "VI.3 Giá vốn hàng bán"),
              ("21", [("VI.4.%d" % k, 1) for k in range(1, 7)], "VI.4 Doanh thu hoạt động tài chính"),
              ("22", [("VI.5.%d" % k, 1) for k in range(1, 7)] + [("VI.5.7", -1)], "VI.5 Chi phí tài chính"),
              ("24", [("VI.6.a", 1), ("VI.6.b", 1), ("VI.6.c.1", -1), ("VI.6.c.2", -1)], "VI.6 Chi phí quản lý kinh doanh (a + b - c)"),
              ("31", [("VI.7.%d" % k, 1) for k in range(1, 6)], "VI.7 Thu nhập khác"),
              ("32", [("VI.8.%d" % k, 1) for k in range(1, 5)], "VI.8 Chi phí khác"),
              ("51", [("VI.9.3", 1)], "VI.9 Chi phí thuế TNDN hiện hành")]
    S = T.nay.S
    DU_B02 = {"10": ("511", "5211", "5212", "5213", "531", "532"), "02": ("5211", "5212", "5213", "531", "532"), "11": ("632",), "21": ("515",),
              "22": ("635",), "24": ("642",), "31": ("711",), "32": ("811",), "51": ("821",)}
    if not b02:
        ra.append(("B02", "Chưa có số B02-DNN của phần mềm trong dữ liệu (chọn thêm mục B02) - bỏ qua đối chiếu B02", "", None, None, None, ""))
    else:
        for ma_so, ds, nd in DS_B02:
            for k, cot_ten in ((0, "Năm nay"), (1, "Năm trước")):
                vs = [g(m, k) for m, _ in ds]
                a = None if any(v is None for v in vs) else sum(_v(v) * dau for v, (_, dau) in zip(vs, ds))
                ghi = ""
                for tt in DU_B02.get(ma_so, ()):
                    du = sum(S.du_cuoi(m) for m in T.nay.la(tt)) if k == 0 else 0.0
                    if abs(du) >= 1:
                        ghi += ("; " if ghi else "") + "TK %s còn dư cuối kỳ %s (chưa kết chuyển hết sang 911)" % (tt, K._dd(abs(du)))
                them("B02", "%s = B02 mã %s" % (nd, ma_so), cot_ten, a, b02.get(str(int(ma_so)), (None, None))[k], ghi)
    # --- dong nhat noi bo: dau + tang - giam = cuoi
    for ma in ("V.5.A.1", "V.5.A.2", "V.5.B.1", "V.5.B.2", "V.5.C.1", "V.5.C.2", "V.6.a.1", "V.6.a.2"):
        a = [g(ma, i) for i in range(4)]
        if all(isinstance(x, (int, float)) for x in a):
            them("Nội bộ", "%s: đầu năm + tăng - giảm = cuối năm" % ma, "", a[0] + a[1] - a[2], a[3])
    for ma in ("V.11.1", "V.11.5"):
        a = [g(ma, i) for i in range(4)]
        if all(isinstance(x, (int, float)) for x in a):
            them("Nội bộ", "%s: đầu năm + tăng - giảm = cuối năm" % ma, "", a[3] + a[1] - a[2], a[0])
    for i, ten in enumerate(COT_V13):
        a = [g("V.13.%d" % k, i) for k in (2, 3, 4, 5)]
        if all(isinstance(x, (int, float)) for x in a):
            them("Nội bộ", "V.13 %s: số dư đầu năm + tăng - giảm = số dư cuối năm" % ten, "", a[0] + a[1] - a[2], a[3])
    # V.10: (Co - No) dau + phai nop - da nop = (Co - No) cuoi (cot Dau / Cuoi cua mau chi lay phan du Co)
    for k in range(1, 10):
        ma = "V.10.%d" % k
        tk = re.search(r"\((\d+)\)", T.dong[ma]["ct"][0]).group(1)
        a = [g(ma, i) for i in range(4)]
        dau = -sum(S.du_dau(m) for m in T.nay.la(tk))
        cuoi = -sum(S.du_cuoi(m) for m in T.nay.la(tk))
        if all(isinstance(x, (int, float)) for x in a):
            ghi = ""
            if dau < -0.5 or cuoi < -0.5:
                ghi = "TK %s dư Nợ (nộp thừa) - trình bày ở V.8.2" % tk
            them("Nội bộ", "%s: (Có - Nợ) đầu năm + phải nộp - đã nộp = (Có - Nợ) cuối năm (TK %s)" % (ma, tk), "", dau + a[1] - a[2], cuoi, ghi)
    # so dau nam = so cuoi nam truoc (khi co so nam truoc)
    if T.truoc.che_do == "SO":
        st = (dl.get("b09") or {}).get("sotruoc") or {}
        cuoi_truoc = defaultdict(float)
        for r in st.get("tk") or []:
            if int(_so(r[1])) == 0:
                cuoi_truoc[str(r[0]).strip()] += _so(r[2]) - _so(r[3])
        for sh, (n, c) in T.truoc.ps_sh.items():
            cuoi_truoc[sh] += n - c
        lech = []
        for m in S.la:
            sh = S.sh(m)
            if sh[:1] in "56789":
                continue
            if abs(tron(S.du_nam(m)) - tron(cuoi_truoc.get(sh, 0.0))) > 1:
                lech.append(sh)
        ra.append(("Năm trước", "Số dư đầu năm nay theo từng TK = số dư cuối năm trước tính từ sổ %s" % os.path.basename(T.truoc.tep), "",
                   None, None, len(lech), "Khớp" if not lech else "LỆCH %d TK: %s" % (len(lech), ", ".join(sorted(lech)[:12]))))
    return ra


# ==========================================================================================================================
#  THONG TIN CHUNG (the 1) tu dl["dn"] / dl["x1l"]
# ==========================================================================================================================
def hinh_thuc_so_huu(ten):
    t = (ten or "").upper()
    if "TNHH" in t or "TRÁCH NHIỆM HỮU HẠN" in t:
        if "MTV" in t or "MỘT THÀNH VIÊN" in t or "1 THÀNH VIÊN" in t:
            return "Công ty trách nhiệm hữu hạn một thành viên"
        if "HAI THÀNH VIÊN" in t or "2 THÀNH VIÊN" in t:
            return "Công ty trách nhiệm hữu hạn hai thành viên trở lên"
        return "Công ty trách nhiệm hữu hạn"
    if "CỔ PHẦN" in t or re.search(r"\bCTCP\b|\bCP\b", t):
        return "Công ty cổ phần"
    if "HỢP DANH" in t:
        return "Công ty hợp danh"
    if "DNTN" in t or "DOANH NGHIỆP TƯ NHÂN" in t:
        return "Doanh nghiệp tư nhân"
    if "HỢP TÁC XÃ" in t or "HTX" in t:
        return "Hợp tác xã"
    return ""


def _sach(s):
    s = str(s or "").strip()
    return "" if s in (".", "...", "…") else s


def nam_va_ky(dl):
    x = dl.get("x1l") or {}
    nam = int(_so(x.get("nam_tc") or dl.get("nam_tc") or 0)) or datetime.date.today().year
    dau = int(_so(x.get("thang_dau_ky") or dl.get("thang_dau_ky") or 1)) or 1
    bd = datetime.date(nam, dau, 1)
    kt = (datetime.date(nam + (1 if dau > 1 else 0), (dau - 2) % 12 + 1, 1) if dau > 1 else datetime.date(nam, 12, 1))
    kt = datetime.date(kt.year, kt.month, 28)
    while True:
        try:
            kt2 = kt + datetime.timedelta(days=1)
        except OverflowError:
            break
        if kt2.month != kt.month:
            break
        kt = kt2
    return nam, bd, kt


def noi_dung_mac_dinh(d, dl):
    """noi dung dong van ban: gia tri tu du lieu doanh nghiep (neu co) hoac van ban mac dinh cua video."""
    dn = dl.get("dn") or dl.get("cty") or {}
    ma = d["ma"]
    if ma == "I.1":
        return hinh_thuc_so_huu(dn.get("ten"))
    if ma == "I.3":
        ten, mn = _sach(dn.get("ten_nganh")), _sach(dn.get("ma_nganh"))
        return ("%s (mã ngành %s)" % (ten, mn)) if ten and mn else (ten or mn)
    if ma == "II.1":
        _, bd, kt = nam_va_ky(dl)
        return "Bắt đầu từ ngày %s, kết thúc vào ngày %s" % (bd.strftime("%d/%m/%Y"), kt.strftime("%d/%m/%Y"))
    if ma == "IV.6":
        # GD303c: doan thuyet minh chinh sach gia thanh (ModGiaThanhLoi.GTL_ThuyetMinh)
        gt = ((dl.get("b09") or {}).get("gia_thanh") or "").strip()
        if gt:
            return (d["nd"] + "\n" + gt) if d["nd"] else gt
    return d["nd"]


# ==========================================================================================================================
#  LAP EXCEL
# ==========================================================================================================================
RONG = [38] + [11] * 8                     # A: ten chi tieu; B..I: 8 cot so (2 cot / 4 cot / 7 cot)
SO_COT = len(RONG)
DONG_CAO = 15.0                            # pt / dong chu co 11


def _so_dong(chu, rong, dam=False):
    """uoc so dong khi xuong dong trong o rong `rong` (don vi do rong cot) - uoc DU (khong cat chu)."""
    cpl = max(8.0, rong * (0.97 if dam else 1.05) - 2)
    n = 0
    for p in str(chu or "").split("\n"):
        n += max(1, int(math.ceil(len(p) / cpl)))
    return max(1, n)


def _nhom_cot(so):
    """vung cot (c1, c2) cho ten + tung cot so theo so cot so lieu."""
    if so == 2:
        return (1, 5), [(6, 7), (8, 9)]
    if so == 4:
        return (1, 1), [(2, 3), (4, 5), (6, 7), (8, 9)]
    if so == 7:
        return (1, 1), [(2, 2), (3, 3), (4, 4), (5, 5), (6, 6), (7, 7), (8, 9)]
    raise ValueError(so)


def _rong(c1, c2):
    return sum(RONG[c1 - 1:c2])


class _Trang(object):
    """ghi dong + chieu cao, gom khoi de ngat trang khong cat bang."""

    def __init__(self, ws):
        self.ws = ws
        self.r = 0
        self.khoi = []           # [(dong dau, dong cuoi, chieu cao)]
        self._dau = None
        self._cao = 0.0

    def dong_moi(self, cao):
        self.r += 1
        self.ws.cao(self.r, cao)
        self._cao += cao
        return self.r

    def bat_dau(self):
        self._dau = self.r + 1
        self._cao = 0.0

    def ket_thuc(self):
        if self._dau is not None and self.r >= self._dau:
            self.khoi.append((self._dau, self.r, self._cao))
        self._dau = None

    def ngat(self, suc_chua):
        dung = 0.0
        for a, _b, h in self.khoi:
            if dung > 0 and dung + h > suc_chua:
                self.ws.ngat_trang(a - 1)
                dung = 0.0
            dung += h
            while dung > suc_chua:
                dung -= suc_chua


def lap_excel(T, dl, duong, canh_bao):
    from xlsx_viet import SoExcel
    SO_TIEN = '#,##0_);(#,##0);"-"_)'           # so am trong ngoac, 0 -> "-", chua le phai
    wb = SoExcel(font="Times New Roman", co=11)
    k = {}
    k["ten_dv"] = wb.kieu(dam=True, can="trai", doc="tren", xuong=True)
    k["thuong"] = wb.kieu(can="trai", doc="tren", xuong=True)
    k["mau"] = wb.kieu(dam=True, can="giua", doc="tren")
    k["mau_ghi"] = wb.kieu(nghieng=True, can="giua", doc="tren", xuong=True, co=10)
    k["td"] = wb.kieu(dam=True, co=14, can="giua")
    k["nam"] = wb.kieu(dam=True, can="giua")
    k["dvt"] = wb.kieu(nghieng=True, can="phai")
    k["hd"] = wb.kieu(dam=True, can="giua", doc="giua", xuong=True, khung=True, nen="EDEDED")
    k["hd7"] = wb.kieu(dam=True, can="giua", doc="giua", xuong=True, khung=True, nen="EDEDED", co=9)
    k["ky"] = wb.kieu(dam=True, can="giua")
    k["ky_ghi"] = wb.kieu(nghieng=True, can="giua")
    k["ky_ten"] = wb.kieu(dam=True, can="giua")
    for dam in (False, True):
        for ng in (False, True):
            k[("vb", dam, ng)] = wb.kieu(dam=dam, nghieng=ng, can="deu", doc="tren", xuong=True)
            k[("ten", dam, ng)] = wb.kieu(dam=dam, nghieng=ng, can="trai", doc="giua", xuong=True, khung=True, thut=1)
            k[("so", dam, ng)] = wb.kieu(dam=dam, nghieng=ng, so=SO_TIEN, can="phai", doc="giua", khung=True)
            k[("so7", dam, ng)] = wb.kieu(dam=dam, nghieng=ng, so=SO_TIEN, can="phai", doc="giua", khung=True, co=9)
    k["nd"] = wb.kieu(can="deu", doc="tren", xuong=True, thut=1)
    ws = wb.sheet("B09-DNN", cot=RONG)
    P = _Trang(ws)
    dn = dl.get("dn") or dl.get("cty") or {}
    nam = nam_va_ky(dl)[0]
    S = T.nay.S
    ca_nam = S.t1 <= 1 and S.t2 >= 12

    # ---- dau trang
    P.bat_dau()
    ten_dv = "Đơn vị báo cáo: %s" % (dn.get("ten") or "")
    r = P.dong_moi(DONG_CAO * max(1, _so_dong(ten_dv, _rong(1, 5), True)))
    ws.gop(r, 1, r, 5, ten_dv, k["ten_dv"])
    ws.gop(r, 6, r, 9, "Mẫu số B09 - DNN", k["mau"])
    dc = ", ".join(x for x in (_sach(dn.get("dia_chi")).rstrip(" ,;"), _sach(dn.get("quan")).rstrip(" ,;"), _sach(dn.get("tinh"))) if x)
    dia_chi = "Địa chỉ: %s" % dc
    r = P.dong_moi(max(2 * 13.0, DONG_CAO * _so_dong(dia_chi, _rong(1, 5))))
    ws.gop(r, 1, r, 5, dia_chi, k["thuong"])
    ws.gop(r, 6, r, 9, "(Ban hành theo Thông tư số 133/2016/TT-BTC ngày 26/8/2016 của Bộ Tài chính)", k["mau_ghi"])
    r = P.dong_moi(DONG_CAO)
    ws.gop(r, 1, r, 5, "Mã số thuế: %s" % (dn.get("mst") or ""), k["thuong"])
    P.dong_moi(8)
    r = P.dong_moi(22)
    ws.gop(r, 1, r, SO_COT, "BẢN THUYẾT MINH BÁO CÁO TÀI CHÍNH", k["td"])
    r = P.dong_moi(DONG_CAO)
    x = dl.get("x1l") or {}
    ky = "Năm %d" % nam if ca_nam else "Từ ngày %s đến ngày %s" % (x.get("tu") or (dl.get("ky") or {}).get("tu", ""),
                                                                     x.get("den") or (dl.get("ky") or {}).get("den", ""))
    ws.gop(r, 1, r, SO_COT, ky, k["nam"])
    r = P.dong_moi(DONG_CAO)
    ws.gop(r, 1, r, SO_COT, "Đơn vị tính: Đồng Việt Nam", k["dvt"])
    P.ket_thuc()

    def van_ban(d):
        nd = noi_dung_mac_dinh(d, dl)
        ten = d["ten"]
        dam, ng = d["dam"], d["nghieng"]
        P.bat_dau()
        if d["ma"] in ("I", "II", "III", "IV", "VII", "VIII"):
            r = P.dong_moi(8)
        W = _rong(1, SO_COT)
        if nd and "\n" not in nd and len(ten) + len(nd) + 1 <= W * 1.6:
            chu = ten + " " + nd
            r = P.dong_moi(DONG_CAO * _so_dong(chu, W, dam))
            ws.gop(r, 1, r, SO_COT, chu, k[("vb", dam, ng)])
        else:
            r = P.dong_moi(DONG_CAO * _so_dong(ten, W, dam))
            ws.gop(r, 1, r, SO_COT, ten, k[("vb", dam, ng)])
            if nd:
                for doan in nd.split("\n"):
                    r = P.dong_moi(DONG_CAO * _so_dong(doan, W - 2))
                    ws.gop(r, 1, r, SO_COT, doan, k["nd"])
            elif d["ma"] not in ("I", "II", "III", "IV", "VII", "VIII") and d["ma"] not in ("IV.4", "IV.7", "IV.11"):
                if d["ma"].startswith(("V.1", "VII", "VIII")) or d["ma"] in ("I.5", "I.6"):
                    r = P.dong_moi(DONG_CAO * 2)            # cho de ke toan ghi
                    ws.gop(r, 1, r, SO_COT, "", k["nd"])
        P.ket_thuc()

    def bang(cot, dong):
        so = len(cot)
        (t1, t2), vung = _nhom_cot(so)
        hd = k["hd7"] if so == 7 else k["hd"]
        tieu = dong[0]
        P.bat_dau()
        P.dong_moi(6)
        dam, ng = tieu["dam"], tieu["nghieng"]
        if so == 2:
            # dong tieu de muc + ten cot tren cung dong (nhu mau TT133)
            cao = max(DONG_CAO * _so_dong(tieu["ten"], _rong(t1, t2), dam), 20)
            r = P.dong_moi(cao)
            ws.gop(r, t1, r, t2, tieu["ten"], k[("ten", dam, ng)])
            for (c1, c2), ten in zip(vung, cot):
                ws.gop(r, c1, r, c2, ten, hd)
        else:
            r = P.dong_moi(DONG_CAO * _so_dong(tieu["ten"], _rong(1, SO_COT), dam) + 2)
            ws.gop(r, 1, r, SO_COT, tieu["ten"], k[("vb", dam, ng)])
            cao = max(DONG_CAO * max(_so_dong(ten, _rong(c1, c2) * (11.0 / 9 if so == 7 else 1.0), True) for (c1, c2), ten in zip(vung, cot)), 20)
            r = P.dong_moi(cao)
            ws.gop(r, t1, r, t2, "Khoản mục", hd)
            for (c1, c2), ten in zip(vung, cot):
                ws.gop(r, c1, r, c2, ten, hd)
        for d in dong[1:]:
            dam, ng = d["dam"], d["nghieng"]
            ks = k[("so7" if so == 7 else "so", dam, ng)]
            if d["loai"] in ("TD", "CTH") and so != 2:
                # dong tieu de / chu thich trong bang nhieu cot: gop ca dong
                r = P.dong_moi(DONG_CAO * _so_dong(d["ten"], _rong(1, SO_COT), dam))
                ws.gop(r, 1, r, SO_COT, d["ten"], k[("ten", dam, ng)])
                continue
            r = P.dong_moi(DONG_CAO * _so_dong(d["ten"], _rong(t1, t2), dam))
            ws.gop(r, t1, r, t2, d["ten"], k[("ten", dam, ng)])
            for i, (c1, c2) in enumerate(vung):
                v = None
                if d["ct"] and i < len(d["ct"]):
                    v = T.gia_tri(d["ma"], i)
                    if v == "" or v is None:
                        v = None
                ws.gop(r, c1, r, c2, v, ks)
        P.ket_thuc()

    for kieu, _the, cot, ds in KHOI:
        if kieu == "VB":
            for d in ds:
                van_ban(d)
        elif kieu == "TD":
            P.bat_dau()
            P.dong_moi(8)
            d = ds[0]
            r = P.dong_moi(DONG_CAO * _so_dong(d["ten"], _rong(1, SO_COT), True))
            ws.gop(r, 1, r, SO_COT, d["ten"], k[("vb", d["dam"], d["nghieng"])])
            P.ket_thuc()
        else:
            if not ca_nam and cot is COT_NN:
                cot = ("Kỳ này", "Năm trước")
            elif not ca_nam and cot is COT_CN:
                cot = ("Cuối kỳ", "Đầu kỳ")
            bang(cot, ds)

    # ---- ky ten
    nk = dl.get("nguoi_ky") or {}
    P.bat_dau()
    P.dong_moi(10)
    ngay = str(x.get("ngay_lap") or "")
    mm = re.match(r"(\d{1,2})/(\d{1,2})/(\d{4})", ngay)
    lap = ("Lập, ngày %s tháng %s năm %s" % (mm.group(1), mm.group(2), mm.group(3))) if mm else "Lập, ngày ... tháng ... năm ..."
    r = P.dong_moi(DONG_CAO)
    ws.gop(r, 6, r, 9, lap, k["ky_ghi"])
    r = P.dong_moi(DONG_CAO)
    ws.o(r, 1, "Người lập biểu", k["ky"])
    ws.gop(r, 2, r, 5, "Kế toán trưởng", k["ky"])
    ws.gop(r, 6, r, 9, "Người đại diện theo pháp luật", k["ky"])
    r = P.dong_moi(DONG_CAO)
    ws.o(r, 1, "(Ký, họ tên)", k["ky_ghi"])
    ws.gop(r, 2, r, 5, "(Ký, họ tên)", k["ky_ghi"])
    ws.gop(r, 6, r, 9, "(Ký, họ tên, đóng dấu)", k["ky_ghi"])
    P.dong_moi(DONG_CAO * 3)
    r = P.dong_moi(DONG_CAO)
    ws.o(r, 1, nk.get("nguoi_lap") or "", k["ky_ten"])
    ws.gop(r, 2, r, 5, nk.get("ke_toan_truong") or "", k["ky_ten"])
    ws.gop(r, 6, r, 9, nk.get("giam_doc") or dn.get("nguoi_dd_pl") or "", k["ky_ten"])
    if nk.get("chung_chi") or nk.get("don_vi_dv"):
        r = P.dong_moi(DONG_CAO)
        ws.gop(r, 1, r, SO_COT, "- Số chứng chỉ hành nghề: %s" % (nk.get("chung_chi") or ""), k["thuong"])
        r = P.dong_moi(DONG_CAO)
        ws.gop(r, 1, r, SO_COT, "- Đơn vị cung cấp dịch vụ kế toán: %s" % (nk.get("don_vi_dv") or ""), k["thuong"])
    P.ket_thuc()
    ws.in_trang(ngang=False, vua_rong=True)
    # suc chua mot trang (pt, chua thu nho): A4 doc cao 841.9 pt - le tren / duoi 0.6 in; ty le thu nho khi vua be ngang (uoc lon)
    rong_px = sum(w * 7 + 5 for w in RONG)
    ty_le = min(1.0, (8.27 - 0.5 - 0.4) * 72 / (rong_px * 0.75))
    P.ngat((841.9 - 2 * 0.6 * 72) / ty_le * 0.96)

    # ---- sheet cong thuc (truy vet)
    ws2 = wb.sheet("Cong thuc", cot=[11, 48, 16, 90, 18, 46])
    kh = wb.kieu(dam=True, can="giua", doc="giua", khung=True, xuong=True, nen="EDEDED")
    kc = wb.kieu(can="trai", doc="tren", khung=True, xuong=True, co=10)
    ks = wb.kieu(so=SO_TIEN, can="phai", doc="tren", khung=True, co=10)
    ws2.gop(1, 1, 1, 6, "CÔNG THỨC TỪNG CHỈ TIÊU B09-DNN (theo thiết lập trong video) VÀ GIÁ TRỊ ĐÃ TÍNH", wb.kieu(dam=True, co=13))
    ws2.gop(2, 1, 2, 6, nguon_ghi_chu(T), wb.kieu(nghieng=True, xuong=True, doc="tren", co=10))
    ws2.cao(2, 15 * max(2, _so_dong(nguon_ghi_chu(T), 229 * 1.05)))
    ws2.dong(3, 1, [("Mã chỉ tiêu", kh), ("Tên chỉ tiêu", kh), ("Cột", kh), ("Công thức", kh), ("Giá trị", kh), ("Nguồn / ghi chú", kh)])
    r = 3
    for _the, cot, d in tat_ca_chi_tieu():
        if not d["ct"]:
            continue
        for i, ct in enumerate(d["ct"]):
            r += 1
            v = T.gia_tri(d["ma"], i)
            ten_cot = cot[i] if cot else ""
            ws2.dong(r, 1, [(d["ma"], kc), (d["ten"], kc), (ten_cot, kc), (ct if ct.strip() else "(để trống - nhập tay)", kc),
                            (v if isinstance(v, (int, float)) else None, ks), (_ghi_nguon(T, d["ma"], i, v), kc)])
            ws2.cao(r, 13 * max(_so_dong(ct, 90 * 1.1), _so_dong(d["ten"], 48 * 1.1), _so_dong(_ghi_nguon(T, d["ma"], i, v), 46 * 1.1)))
    ws2.dong_bang(4, 3)
    ws2.in_trang(ngang=True, vua_rong=True, lap_dong=(3, 3))

    # ---- sheet doi chieu
    ws3 = wb.sheet("Doi chieu", cot=[12, 80, 12, 20, 20, 16, 40])
    ws3.gop(1, 1, 1, 7, "ĐỐI CHIẾU SỐ LIỆU THUYẾT MINH VỚI BÁO CÁO TÀI CHÍNH (B01a, B02 của phần mềm) VÀ KIỂM TRA NỘI BỘ", wb.kieu(dam=True, co=13))
    ws3.dong(2, 1, [(x, kh) for x in ("Nhóm", "Nội dung kiểm tra", "Cột", "Số thuyết minh", "Số báo cáo / đối chiếu", "Chênh lệch", "Kết luận")])
    kdo = wb.kieu(dam=True, mau="C00000", can="trai", doc="tren", khung=True, xuong=True, co=10)
    kxanh = wb.kieu(mau="006100", can="trai", doc="tren", khung=True, xuong=True, co=10)
    r = 2
    for nhom, nd, cot, a, bb, cl, kl in T.doi_chieu:
        r += 1
        ws3.dong(r, 1, [(nhom, kc), (nd, kc), (cot, kc), (a, ks), (bb, ks), (cl, ks),
                        (kl, kdo if str(kl).startswith("LỆCH") else (kxanh if kl == "Khớp" else kc))])
        ws3.cao(r, 13 * max(_so_dong(nd, 80 * 1.1), _so_dong(kl, 40 * 1.1)))
    ws3.dong_bang(3, 1)
    ws3.in_trang(ngang=True, vua_rong=True, lap_dong=(2, 2))
    wb.luu(duong)
    return duong


def _ghi_nguon(T, ma, i, v):
    g = T.ghi.get((ma, i)) or set()
    ra = []
    if v is None:
        ra.append("Không đủ dữ liệu năm trước - nhập tay")
    if "NT_SO" in g:
        ra.append("Năm trước: sổ %s" % os.path.basename(getattr(T.truoc, "tep", "")))
    elif "NT_LUYKE" in g and v is not None:
        ra.append("Năm trước: phát sinh lũy kế năm trước trong hệ thống TK")
    if "GIAM_TRU" in g:
        ra.append("Giảm trừ doanh thu: phần đối ứng TK giảm trừ cũ 521x / 531 / 532 (sổ không đánh dấu loại giảm trừ theo chứng từ)")
    if "GIAM_VAT" in g:
        ra.append("Giảm VAT: PS Nợ 33311 đối ứng TK ngoài 133 và ngoài nhóm nộp (quy ước GĐ77); PhatsinhDUGiamVAT = 0")
    if "HM16" in g:
        ra.append("Hàm Haomon..._TSCD_loai16 = 0 (UNESCO ghi toàn bộ hao mòn qua TK 214)")
    return "; ".join(ra)


def nguon_ghi_chu(T):
    ky = (T.dl.get("ky") or {})
    s = ("Số dư đầu (DK) = số dư đầu kỳ lập (%s), cuối (CK) = cuối kỳ (%s); phát sinh trong kỳ gồm cả bút toán kết chuyển. DU..._ChitietTheoTK: cộng phần dư "
         "từng TK chi tiết; _ChitietTheoTKvaDoituong: cộng phần dư từng đối tượng (131, 331). " % (ky.get("tu", ""), ky.get("den", "")))
    if T.truoc.che_do == "SO":
        s += "Cột năm trước (phần VI): tính từ sổ năm trước %s (chỉ đọc). " % os.path.basename(T.truoc.tep)
    elif T.truoc.che_do == "LUYKE":
        s += ("Cột năm trước (phần VI): không có sổ năm trước - dùng phát sinh lũy kế năm trước lưu trong hệ thống TK; đối ứng kết chuyển 911 "
              "theo quy ước B02 năm trước của phần mềm (bên Nợ TK doanh thu / bên Có TK chi phí chỉ là kết chuyển). ")
    else:
        s += "Cột năm trước (phần VI): không có số liệu năm trước - để trống. "
    return s


# ==========================================================================================================================
#  HOP DONG XUAT 1 LAN
# ==========================================================================================================================
def tinh(dl):
    """-> BoTinh da tinh het + doi chieu + canh bao (khong ghi tep) - dung cho test / module khac."""
    cb = []
    T = BoTinh(dl, cb)
    T.tinh_het()
    T.doi_chieu = doi_chieu(T, dl)
    T.canh_bao = cb + canh_bao_du_lieu(T, dl)
    return T


def canh_bao_du_lieu(T, dl):
    cb = []
    S = T.nay.S
    if not (S.t1 <= 1 and S.t2 >= 12):
        cb.append("Kỳ lập không trọn năm tài chính: cột 'Đầu năm' là số đầu kỳ, phát sinh tính trong kỳ đã chọn.")
    for m, (ld, lc) in T.nay.lech_cn.items():
        cb.append("TK %s: cộng số dư theo đối tượng lệch sổ tổng hợp (đầu %s, cuối %s) - phần lệch tính như một đối tượng ở V.3 / V.9."
                  % (S.sh(m), K._dd(ld), K._dd(lc)))
    if T.nay.le_mo > 0:
        cb.append("Có %s tiền dòng chứng từ một bên nhiều TK cả hai phía - không ghép được đối ứng (PhatsinhDU bỏ qua phần này)."
                  % K._dd(T.nay.le_mo))
    ch = T.truoc.che_do
    if ch == "LUYKE":
        cb.append("Cột Năm trước phần VI: không tìm thấy sổ năm trước - tính theo phát sinh lũy kế năm trước và quy ước kết chuyển như B02 năm "
                  "trước của phần mềm (đặt sổ KT%d*.MDB cùng thư mục dữ liệu để tính chính xác theo đối ứng)." % (nam_va_ky(dl)[0] - 1))
    elif not ch:
        cb.append("Không có số liệu năm trước (sổ năm trước / phát sinh lũy kế năm trước) - cột Năm trước phần VI để trống.")
    thieu = sorted({ma for (ma, _i), v in T.gt.items() if v is None})
    if thieu:
        cb.append("Cột Năm trước không xác định được (thiếu đối ứng năm trước) - nhập tay: " + ", ".join(thieu))
    for (tk, ck), v in sorted(T.nay.nguoc.items()):
        ben_dung = {RE_HAM_DU.match(f).group(1).upper() for f in T.ham_dung.get((tk, ck), ())}
        if len(ben_dung) != 1 or tk.startswith("333"):
            continue                     # cong thuc da lay ca hai ben (Co - No) / du No thue da o V.8.2
        ben = "Có" if ben_dung == {"NO"} else "Nợ"
        dung = ", ".join(sorted(T.ma_dung.get((tk, ck), ())))
        cb.append("TK %s %s dư %s %s: chỉ tiêu %s lấy 0 (hàm dư %s tổng hợp)%s." % (
            tk, "cuối năm" if ck else "đầu năm", ben, K._dd(v), dung, "Nợ" if ben == "Có" else "Có",
            " - tiền / tài sản dư Có là sai số liệu, kiểm tra sổ" if ben == "Có" and tk[:1] in "12" else
            (" - phần dư Nợ thuế trình bày ở V.8.2" if tk.startswith("333") else "")))
    x131 = T.nay.doi_ung("33311", "131")
    if x131 >= 1:
        cb.append("V.10.1: %s Nợ 33311 / Có 131 (thường là giảm giá / hàng bán trả lại) được tính là 'đã thực nộp' như mẫu chuẩn khi chứng "
                  "từ không đánh dấu giảm thuế - soát lại." % K._dd(x131))
    lech = [x for x in T.doi_chieu if str(x[6]).startswith("LỆCH")]
    for x in lech[:8]:
        ly_do = str(x[6])[len("LỆCH - "):] if str(x[6]).startswith("LỆCH - ") else ""
        cb.append("Đối chiếu lệch: %s (%s): thuyết minh %s, báo cáo %s%s." % (x[1], x[2], K._dd(x[3] or 0), K._dd(x[4] or 0),
                                                                          (" - " + ly_do) if ly_do else ""))
    if len(lech) > 8:
        cb.append("... còn %d dòng đối chiếu lệch - xem sheet 'Doi chieu'." % (len(lech) - 8))
    return cb


def ten_tep(dl):
    return "B09_DNN_%d.xlsx" % nam_va_ky(dl)[0]


def lap(dl, ma, kieu, thumuc):
    ma = (ma or "B09").upper()
    duong = os.path.join(thumuc, ten_tep(dl))
    if ma != "B09" and os.path.isfile(duong):
        return {"tep": [duong], "canh_bao": ["Thuyết minh đã lập ở mục B09 cùng lần xuất (cùng tệp)."]}
    T = tinh(dl)
    lap_excel(T, dl, duong, T.canh_bao)
    cb = list(T.canh_bao)
    if "X" in (kieu or "").upper() and "E" not in (kieu or "").upper():
        cb.insert(0, "B09-DNN không có mẫu XML HTKK (nộp kèm dạng tệp) - đã lập Excel.")
    return {"tep": [duong], "canh_bao": cb}
