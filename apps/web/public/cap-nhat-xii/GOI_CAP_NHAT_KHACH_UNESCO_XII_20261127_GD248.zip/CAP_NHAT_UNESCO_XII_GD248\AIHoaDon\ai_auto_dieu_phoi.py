# -*- coding: utf-8 -*-
"""GD360 - AI_AUTO: RA SOAT CA KY (viec cu / viec moi) - chi DOC .MDB bang jet_doc, khong ghi so. Ban Python dung chung UNESCO XI / XII.

Moi thang (thu tu nam tai chinh) x 9 buoc: tai_hd, hach_toan, so_phu, phan_bo, trich_luong, gia_thanh, ket_chuyen, khoa_so, bao_cao
  -> DA_LAM / CHUA_LAM / CAN_NGUOI / KHONG_CO / DA_KHOA, ghi chu (so lieu that, khong theo dau tich), viec NGUOI phai lam (may khong lam duoc:
     ma xac nhan cong thue, tep sao ke / bang luong, chinh sach gia xuat kho / ky GTGT, thang da ket chuyen) va buoc "AI lam tu dong" cua XI (2, 3, 4, 5)
     lam duoc phan con lai. Cung cach doc so nhu khoa_so_thang.py (GD356) / nghiep_vu_dinh_ky.py (GD358).
Ra ket-qua\\ai_auto_dieu_phoi.txt + .html:
  TONG;<so>;<nam>;<viec>;<tu>;<den>;<luc>;<ten cty>;<so buoc may lam>;<so viec nguoi>
  O;<t>;<thang/nam>;<buoc>;<ten>;<tt>;<may>;<ghi chu>;<viec nguoi>
  NGUOI;<t>;<buoc>;<viec>
Dung: python ai_auto_dieu_phoi.py /so:"<so.MDB>" [/viec:VIEC_CU|VIEC_MOI] [/tu:1] [/den:12] [/ra:<thu muc>]
Qua tool (UNESCO XI, FrmAiAuto360 / ModAiAuto360): tool_htkk_unesco.py /aiauto:"<so.MDB>" /viec: /tuthang: /denthang: -> cung tep, moc DA_XONG_KHOASO.
Tren UNESCO XII: Modules\\AiAutoService.vb doc SQL Server truc tiep (cung cac dieu kien nay) va con THUC HIEN qua chuoi thang cua tram ERP trong tien trinh;
tep nay la ban ra soat dung chung de UNESCO XI (so .MDB) bao cao cung mot kieu cho nguoi dung."""
import datetime as _dt
import html
import io
import json
import os
import re
import sys
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)
import khoa_so_thang as K          # noqa: E402

TEP = "ai_auto_dieu_phoi"
BUOC = (("tai_hd", "Nhận hoá đơn"), ("hach_toan", "Hạch toán hoá đơn"), ("so_phu", "Sổ phụ ngân hàng"), ("phan_bo", "Khấu hao, phân bổ"),
        ("trich_luong", "Trích lương"), ("gia_thanh", "Giá xuất kho, giá thành"), ("ket_chuyen", "Kết chuyển"), ("khoa_so", "Khoá sổ"), ("bao_cao", "Báo cáo, sổ sách"))
TT_TEN = {"DA_LAM": ("Đã làm", "#1d6b34"), "CHUA_LAM": ("Chưa làm", "#1f4e9a"), "CAN_NGUOI": ("Cần người", "#a3262a"), "KHONG_CO": ("Không phát sinh", "#8a96a3"), "DA_KHOA": ("Đã khoá", "#8a96a3")}
# buoc "AI lam tu dong" cua khung Cac buoc AI (ModTLBTuDong / AiStepsService) lam duoc phan con lai cua tung buoc
MAY_XI = {"hach_toan": "2", "so_phu": "3", "trich_luong": "4", "phan_bo": "5", "gia_thanh": "6", "ket_chuyen": "7"}          # GD361: buoc 6 (ModGT361); GD364: buoc 7 ket chuyen (ModKC364)
NGUONG_MAC_DINH = 90


def _s(x):
    return str(x if x is not None else "").strip()


def _tt_hd(h):
    return _s(h.get("AIValidationStatus")).upper()


# ------------------------------------------------------------------ doc so
def doc(duong):
    """Doc so bang khoa_so_thang.doc roi them cac bang AI ma ra soat can (bang nao khong co -> rong)."""
    import jet_doc
    d = K.doc(duong)
    m = jet_doc.Mdb(duong)
    try:
        bang = {b.lower(): b for b in m.bang()}

        def tb(t, n=None):
            k = bang.get(t.lower())
            return m.doc(k, n) if k else []
        d["co_bang"] = set(bang)
        d["hd_ai"] = [{k: r.get(k) for k in ("MaCT", "NgayLap", "MaCTKeToan", "MaSoLoaiCT", "AIValidationStatus", "AIConfidence", "AIApprovalStatus", "LoaiCT", "TrangThaiHoaDon", "SoHoaDon", "KyHieuHoaDon", "MSTNguoiBanNguoiXuatHang",
                                "MSTNguoiMuaNguoiNhanHang", "HDBanRa", "TongTienThanhToan", "MSTLogin")}
                      for r in tb("HDDTTaiVe")]
        d["sp"] = [{k: r.get(k) for k in ("NgayGD", "TrangThai", "MaCTKeToan")} for r in tb("HDDT_SP_Dong")]
        d["bl_ky"] = [{k: r.get(k) for k in ("MaSo", "Thang", "Nam", "MaCTKeToan", "GhiChu")} for r in tb("HDDT_BL_Ky")]
        # GD370: hoa don ghi tay -> K.hd_ghi_tay (d["hd_tay"] do khoa_so_thang.doc lap: so + chieu + MST / tien); bo khoa cu (thang, nam, so)
        d["n_ccdc"] = len(tb("Congcudungcu"))
        d["phucap_thang"] = set(K._i(r.get("Thang")) for r in tb("PhuCap"))          # GD364: luong noi bo (Cham cong - Trich luong)
        d["nv_noi_bo"] = len(tb("QuanLyNhanVien"))
        d["chucdanh"] = len(tb("ChucDanh"))          # GD366: may tu trich luong noi bo khi co nhan vien + chuc danh / bac luong
        d["n_mau_kc"] = len(tb("CTKetChuyen"))
        qt = (tb("HDDT_QuyTac", 1) or [{}])[0]
        d["che_do_ghi"] = K._i(qt.get("CheDoGhi")) == 1
        d["sp_che_do_ghi"] = K._i(qt.get("SP_CheDoGhi")) == 1
        d["nguong"] = K._i(qt.get("NguongTinCayTuDong")) or NGUONG_MAC_DINH
        d["out_cost"] = K._i(d["lic"].get("OutCost"))
        d["gxk_chuoi"] = _s(d["tham_so"].get("CHUOI_GXK")).upper()
        d["ky_gtgt"] = _s(d["tham_so"].get("HTKK_KyGTGT") or d["tham_so"].get("KY_GTGT")).upper()
        return d
    finally:
        try:
            m.dong()
        except Exception:
            pass


# ------------------------------------------------------------------ ra soat mot thang
def _dong_tk(d, rows, ben, tien_to):
    k = "MaTKNo" if ben == "N" else "MaTKCo"
    return sum(1 for r in rows if d["tk"].get(r.get(k), "").startswith(tien_to))


def _khoa_hd(h):
    """GD370: mot hoa don = MST nguoi ban + ky hieu + so (hai NCC cung so / cung ky hieu khong gop lam mot)."""
    return (K._mst_dt(h.get("MSTNguoiBanNguoiXuatHang")), _s(h.get("KyHieuHoaDon")), _s(h.get("SoHoaDon")).lstrip("0"))


def _hd_thang(d, th, nam):
    ds = []
    for h in d["hd_ai"]:
        ng = K._ngay(h.get("NgayLap"))
        if ng and (ng.month, ng.year) == (th, nam):
            ds.append(h)
    return ds


def ra_soat_thang(d, t, theo_thang, viec):
    th, nam = K.thang_lich(d, t)
    rows = theo_thang.get(t, [])
    khoa = K.khoa_thang(d, t)
    kc = _dong_tk(d, rows, "N", "911") + _dong_tk(d, rows, "C", "911") > 0
    o = []

    def them(buoc, tt, ghi, nguoi="", may=""):
        o.append({"buoc": buoc, "ten": dict(BUOC)[buoc], "tt": tt, "may": may if tt in ("CHUA_LAM", "DA_LAM") else "", "ghi_chu": ghi, "nguoi": nguoi if tt == "CAN_NGUOI" else ""})

    # 1. hoa don
    hd = _hd_thang(d, th, nam)
    thue = _dong_tk(d, rows, "N", "133") + _dong_tk(d, rows, "C", "3331")
    ct = (d.get("cong_thue") or {}).get("%04d-%02d" % (nam, th))
    if khoa:
        them("tai_hd", "DA_KHOA", "tháng đã khoá sổ")
    elif ct and isinstance(ct.get("mua"), dict) and isinstance(ct.get("ban"), dict):
        # GD370: co doi chieu cong thue -> chi XONG khi du hoa don (truoc day: co >= 1 hoa don la coi nhu xong)
        mu, ba = ct["mua"], ct["ban"]
        tong = K._i(mu.get("tong")) + K._i(ba.get("tong"))
        thieu = K._i(mu.get("moi")) + K._i(ba.get("moi"))
        chua_nap = K._i(mu.get("tai")) + K._i(ba.get("tai"))
        goc = "cổng thuế %d hoá đơn (mua %d, bán %d), phần mềm đã có %d - đối chiếu lúc %s%s" % (
            tong, K._i(mu.get("tong")), K._i(ba.get("tong")), tong - thieu - chua_nap, _s(ct.get("luc")),
            "" if ct.get("du_thang") else " (CHƯA đủ cả tháng: %s)" % (_s(ct.get("canh_bao"))[:120] or "khoảng ngày đồng bộ không phủ cả tháng"))
        if thieu:
            them("tai_hd", "CAN_NGUOI", goc + "; còn %d hoá đơn chưa tải" % thieu,
                 "mở Tải hoá đơn → Đồng bộ → Tải về (đăng nhập cổng thuế, gõ mã xác nhận một lần) - máy tải đủ %d hoá đơn còn thiếu" % thieu)
        elif not ct.get("du_thang"):
            them("tai_hd", "CAN_NGUOI", goc, "đồng bộ lại CẢ tháng ở Tải hoá đơn (lần trước cổng thuế chưa trả đủ) để biết đã đủ hoá đơn chưa")
        elif tong == 0 and not hd and not thue:
            them("tai_hd", "KHONG_CO", goc.replace("cổng thuế 0 hoá đơn (mua 0, bán 0), phần mềm đã có 0", "cổng thuế không có hoá đơn nào của tháng"))
        else:
            them("tai_hd", "DA_LAM", "đủ: " + goc + ("; %d hoá đơn đã tải chưa nạp - bước Hạch toán tự nạp" % chua_nap if chua_nap else ""))
    elif hd:
        them("tai_hd", "DA_LAM", "%d hoá đơn trong danh sách hoá đơn điện tử - chưa đối chiếu số lượng với cổng thuế (Tải hoá đơn → Đồng bộ)" % len({_khoa_hd(x) for x in hd}))
    elif thue:
        them("tai_hd", "DA_LAM", "danh sách hoá đơn điện tử trống nhưng sổ đã có %d dòng thuế GTGT (ghi tay)" % thue)
    else:
        them("tai_hd", "CAN_NGUOI", "chưa có hoá đơn nào của tháng",
             "tải hoá đơn mua vào / bán ra của tháng từ cổng thuế (cần gõ mã xác nhận - máy không tự giải) hoặc nhập tệp XML / ZIP, Excel cổng thuế ở Tải hoá đơn")
    # 2. hach toan
    chua = [h for h in hd if not _s(h.get("MaCTKeToan")) or _s(h.get("MaCTKeToan")) == "0"]
    chua = [h for h in chua if _tt_hd(h) != "BO_QUA"]
    # GD362: hoa don tai ve da co trong so (ghi tay, khop so hoa don trong thang) khong con la "chua hach toan"
    co_so = [h for h in chua if K.hd_ghi_tay(d, h)]          # GD370: dinh danh day du, khong chi so hoa don
    chua = [h for h in chua if h not in co_so]
    n_hd = len({_khoa_hd(h) for h in hd})
    n_chua = len({_khoa_hd(h) for h in chua})
    du = [h for h in chua if _tt_hd(h) == "SAN_SANG" and (_s(h.get("LoaiCT")).upper() in ("CK", "KM") or K._f(h.get("AIConfidence")) >= d["nguong"]) and _s(h.get("AIApprovalStatus")).upper() != "AI"]
    if khoa:
        them("hach_toan", "DA_KHOA", "tháng đã khoá sổ")
    elif not hd:
        them("hach_toan", "DA_LAM" if thue else "KHONG_CO", "hoá đơn ghi tay (%d dòng thuế GTGT)" % thue if thue else "không có hoá đơn điện tử của tháng")
    elif not chua:
        them("hach_toan", "DA_LAM", "đã hạch toán hết %d hoá đơn" % n_hd + (" (%d hoá đơn đã ghi tay vào sổ, khớp số + chiều + MST / số tiền - đối chiếu ở Rà soát số liệu)" % len({_khoa_hd(h) for h in co_so}) if co_so else ""))
    elif kc and thue >= len(chua):
        them("hach_toan", "CAN_NGUOI", "%d hoá đơn tải về chưa gắn chứng từ; sổ đã có %d dòng thuế GTGT ghi tay, tháng đã kết chuyển" % (n_chua, thue),
             "kiểm tra trùng và gắn %d hoá đơn tải về với chứng từ có sẵn trên màn hình AI hoá đơn (sổ đã ghi tay, tháng đã kết chuyển; máy không ghi thêm)" % n_chua)
    elif kc:
        them("hach_toan", "CAN_NGUOI", "%d hoá đơn chưa hạch toán nhưng tháng đã có bút toán kết chuyển 911" % n_chua,
             "tháng đã kết chuyển: lập thêm chứng từ phải kết chuyển lại - kế toán quyết định (duyệt trên màn hình AI hoá đơn rồi kết chuyển lại)")
    else:
        con = len(chua) - len(du)
        nguoi = ""
        if du and not d["che_do_ghi"]:
            nguoi = "%d hoá đơn đủ ngưỡng tin cậy nhưng sổ chưa bật tự ghi: bấm «AI làm tự động» bước 2 (hỏi một lần) hoặc bật tự ghi trong Quy tắc hạch toán" % len(du)
        elif con:
            nguoi = "%d hoá đơn thiếu mã / tin cậy thấp / cần xem: duyệt trên màn hình AI hoá đơn" % con
        them("hach_toan", "CAN_NGUOI" if (nguoi and not du) else "CHUA_LAM", "%d hoá đơn chưa hạch toán, %d hoá đơn Sẵn sàng tin cậy ≥ %d%%" % (len(chua), len(du), d["nguong"]), nguoi, MAY_XI["hach_toan"] if du else "")
        if nguoi and du:
            o[-1]["nguoi"] = nguoi
    # 3. so phu
    sp = [x for x in d["sp"] if (lambda g: g and (g.month, g.year) == (th, nam))(K._ngay(x.get("NgayGD")))]
    cho = [x for x in sp if _s(x.get("TrangThai")).upper() not in ("DA_HACH_TOAN", "BO_QUA")]
    nh = _dong_tk(d, rows, "N", "112") + _dong_tk(d, rows, "C", "112")
    if khoa:
        them("so_phu", "DA_KHOA", "tháng đã khoá sổ")
    elif "hddt_sp_dong" not in d["co_bang"]:
        them("so_phu", "KHONG_CO", "sổ chưa cài phần sổ phụ ngân hàng AI (HDDT_SP_*)")
    elif not sp:
        them("so_phu", "DA_LAM" if nh else "KHONG_CO", "sổ có %d dòng TK 112 ghi tay, không có sao kê AI" % nh if nh else "chưa có sao kê và sổ không có giao dịch 112 trong tháng; nếu có, nhập sao kê ở AI - Sổ phụ")
    elif not cho:
        them("so_phu", "DA_LAM", "%d dòng sao kê, đã ghi / bỏ qua hết" % len(sp))
    elif kc:
        them("so_phu", "CAN_NGUOI", "%d dòng sao kê chưa ghi, tháng đã kết chuyển" % len(cho), "tháng đã kết chuyển: duyệt %d dòng sổ phụ trên màn hình Sổ phụ rồi kết chuyển lại" % len(cho))
    elif d["sp_che_do_ghi"]:
        them("so_phu", "CHUA_LAM", "%d / %d dòng sao kê chưa ghi" % (len(cho), len(sp)), may=MAY_XI["so_phu"])
    else:
        them("so_phu", "CAN_NGUOI", "%d / %d dòng sao kê chưa ghi" % (len(cho), len(sp)), "sổ chưa bật tự ghi sổ phụ (Quy tắc hạch toán): duyệt %d dòng trên màn hình Sổ phụ (hoặc «AI làm tự động» bước 3)" % len(cho))
    # 4. khau hao, phan bo
    co_ts, co_cc = bool(d["ts"]), d["n_ccdc"] > 0
    kh = sum(1 for r in rows if K._i(r.get("MaLoai")) == 12)
    pb = sum(1 for r in rows if K._i(r.get("MaLoai")) == 14)
    if khoa:
        them("phan_bo", "DA_KHOA", "tháng đã khoá sổ")
    elif not co_ts and not co_cc:
        them("phan_bo", "KHONG_CO", "sổ không có thẻ tài sản cố định hay công cụ dụng cụ")
    elif (co_ts and kh == 0) or (co_cc and pb == 0):
        them("phan_bo", "CHUA_LAM", "khấu hao %d dòng, phân bổ %d dòng - máy ghi %s theo bảng thông số (bước 5)" % (
            kh, pb, " + ".join(x for x, c in (("khấu hao", co_ts and kh == 0), ("phân bổ", co_cc and pb == 0)) if c)), may=MAY_XI["phan_bo"])
    else:
        them("phan_bo", "DA_LAM", "khấu hao %d dòng, phân bổ %d dòng" % (kh, pb))
    # 5. luong
    ky = [x for x in d["bl_ky"] if K._i(x.get("Thang")) == th and K._i(x.get("Nam")) == d["nam"]]
    co334 = _dong_tk(d, rows, "C", "334")
    if khoa:
        them("trich_luong", "DA_KHOA", "tháng đã khoá sổ")
    elif ky:
        ky.sort(key=lambda x: K._i(x.get("MaSo")))
        ct = _s(ky[-1].get("MaCTKeToan"))
        if ct and ct != "0":
            them("trich_luong", "DA_LAM", "đã lập chứng từ lương từ bảng lương AI")
        elif kc:
            them("trich_luong", "CAN_NGUOI", "bảng lương AI chưa lập chứng từ, tháng đã kết chuyển", "tháng đã kết chuyển: lập chứng từ lương trên màn hình Bảng lương rồi kết chuyển lại")
        else:
            o_loi = sum(_s(x.get("GhiChu")).count("[O_LOI]") for x in ky)          # GD370: o loi cong thuc -> may khong ghi
            if o_loi:
                them("trich_luong", "CAN_NGUOI", "bảng lương AI có %d dòng ô lỗi công thức (#VALUE!, #REF!...) - máy không lập chứng từ" % o_loi,
                     "sửa các ô lỗi trong tệp Excel bảng lương (xem ghi chú kỳ, dòng [!]) rồi Import lại")
            else:
                them("trich_luong", "CHUA_LAM", "bảng lương AI đã nhập, chưa lập chứng từ lương", may=MAY_XI["trich_luong"])
    elif co334:
        them("trich_luong", "DA_LAM", "đã có %d dòng Có 334 (trích lương trên màn hình)" % co334)
    elif d.get("nv_noi_bo") and d.get("chucdanh"):
        # GD366: luong noi bo - may lam nhu man hinh Cham cong - Trich luong (cham cong chua co -> du ngay lam viec, ty le BH thang truoc, lo san xuat T<thang>)
        them("trich_luong", "CHUA_LAM", "sổ dùng lương nội bộ (%d nhân viên%s) - máy tính lương, trích BH, chi phí nhân viên như màn hình Chấm công" % (
            d["nv_noi_bo"], ", phụ cấp tháng đã nhập" if th in d.get("phucap_thang", ()) else ", chưa có phụ cấp tháng: dùng bậc lương"), may=MAY_XI["trich_luong"])
    else:
        them("trich_luong", "CAN_NGUOI", "chưa có bảng lương và chưa có bút toán Có 334", "nhập tệp Excel bảng lương ở AI - Bảng lương (hoặc làm Chấm công - Trích lương trên màn hình)")
    # 6. gia xuat kho / gia thanh
    xuat = [r for r in rows if K._i(r.get("MaLoai")) in (2, 4) and K._i(r.get("MaVattu")) > 0]
    chua_gia = [r for r in xuat if not K._f(r.get("SoPS"))]
    sx = sum(1 for r in rows if K._i(r.get("MaLoai")) != 3 and d["tk"].get(r.get("MaTKNo"), "").startswith("154"))
    kctp = sum(1 for r in rows if _s(r.get("SoHieu")).upper().startswith("KCTP-"))
    biet_cach = d["out_cost"] == 2 or (d["out_cost"] == 0 and d["gxk_chuoi"] in ("BQDD", "BQCK"))
    ghi = "%d dòng xuất kho (%d chưa có giá)%s" % (len(xuat), len(chua_gia), ", %d dòng Nợ 154, %d phiếu KCTP" % (sx, kctp) if sx else "")
    if khoa:
        them("gia_thanh", "DA_KHOA", "tháng đã khoá sổ")
    elif not xuat and not sx:
        them("gia_thanh", "KHONG_CO", "không có xuất kho hay chi phí sản xuất")
    elif not chua_gia and (not sx or kctp):
        them("gia_thanh", "DA_LAM", ghi)
    elif d["out_cost"] == 0 and not biet_cach:          # GD361: may dung binh quan cuoi ky (luu CHUOI_GXK) - khong can nguoi
        them("gia_thanh", "CHUA_LAM", ghi + " - sổ chưa chọn cách tính: máy dùng bình quân cuối kỳ", may=MAY_XI["gia_thanh"])
    elif d["out_cost"] not in (0, 1, 2):
        them("gia_thanh", "CAN_NGUOI", ghi, "sổ tính giá xuất kho đích danh / nhập trước xuất trước theo lô - làm trên màn hình Tính giá xuất kho")
    else:
        them("gia_thanh", "CHUA_LAM", ghi + " - máy: tính giá xuất kho" + ("; máy giá thành cân đối điện, ghi phiếu KCTP" if sx and not kctp else "") + "; lập lại giá vốn",
             may=MAY_XI["gia_thanh"])          # GD361
    # 7. ket chuyen
    if khoa:
        them("ket_chuyen", "DA_KHOA", "tháng đã khoá sổ")
    elif d["n_mau_kc"] == 0:
        them("ket_chuyen", "CAN_NGUOI", "sổ chưa có mẫu kết chuyển", "khai mẫu kết chuyển trên màn hình Kết chuyển")
    elif kc:
        them("ket_chuyen", "DA_LAM", "đã có bút toán kết chuyển 911")
    else:
        xong_truoc = all(b["tt"] in ("DA_LAM", "KHONG_CO", "DA_KHOA") for b in o)
        them("ket_chuyen", "CHUA_LAM", "chưa có bút toán kết chuyển 911" + (" - máy kết chuyển theo mẫu (%d mẫu)" % d["n_mau_kc"] if xong_truoc else " - còn bước trước chưa xong, máy sẽ kết chuyển sau khi xong"),
             may=MAY_XI["ket_chuyen"])
    # 8. khoa so
    them("khoa_so", "DA_LAM" if khoa else "CHUA_LAM", "tháng đã khoá sổ" if khoa else "chưa khoá - Kiểm tra trước khoá sổ (bước 11) chấm điểm rồi khoá")
    # 9. bao cao
    them("bao_cao", "CHUA_LAM" if not khoa else "DA_LAM", "xuất báo cáo, sổ sách khi anh / chị đã kiểm tra số liệu" if not khoa else "tháng đã khoá: in / xuất sổ để lưu")
    return {"t": t, "th": th, "nam": nam, "thang": "%02d/%d" % (th, nam), "khoa": khoa, "ket_chuyen": kc, "buoc": o}


def phan_tich(d, tu=1, den=None, viec="VIEC_CU"):
    theo_thang = defaultdict(list)
    for r in d["ct"]:
        t = K._i(r.get("ThangCT"))
        if 1 <= t <= 12:
            theo_thang[t].append(r)
    co_dl = sorted(theo_thang)
    den = den or (max(co_dl) if co_dl else 1)
    tu = max(1, min(tu, den))
    thang = [ra_soat_thang(d, t, theo_thang, viec) for t in range(tu, den + 1)]
    nguoi, may = [], []
    for m in thang:
        for b in m["buoc"]:
            if b["nguoi"]:
                nguoi.append((m["t"], b["buoc"], "Tháng %s - %s: %s" % (m["thang"], b["ten"], b["nguoi"])))
            if b["may"] and b["tt"] == "CHUA_LAM":
                may.append((m["t"], b["buoc"], "Tháng %s - %s: bước %s «AI làm tự động» (%s)" % (m["thang"], b["ten"], b["may"], b["ghi_chu"])))
    return {"so": os.path.basename(d["duong"]), "ten": K._u(d, d["lic"].get("TenCty")), "nam": d["nam"], "viec": viec, "tu": tu, "den": den,
            "luc": _dt.datetime.now().strftime("%d/%m/%Y %H:%M"), "thang": thang, "nguoi": nguoi, "may": may}


# ------------------------------------------------------------------ ghi
_SO_GOM = re.compile(r"\d[\d.,]*\d|\d")


def gom_nguoi(kq):
    """GD370b: gom viec cua nguoi CUNG nguyen nhan (cung buoc + cung viec phai lam) qua nhieu thang thanh MOT dong:
    'Thang 07, 08, 09/2026 - Trich luong: ...' - sua mot lan cho ca nhom thay vi doc lai tung thang."""
    nhom, thu_tu = {}, []
    for m in kq["thang"]:
        for b in m["buoc"]:
            if not b.get("nguoi"):
                continue
            k = (b["buoc"], _SO_GOM.sub("#", b["nguoi"]))          # cung viec, chi khac so luong -> cung nhom
            if k not in nhom:
                nhom[k] = {"t": m["t"], "ten": b["ten"], "thang": [], "viec": []}
                thu_tu.append(k)
            nhom[k]["thang"].append(m["thang"])
            nhom[k]["viec"].append(b["nguoi"])
    ra = []
    for k in thu_tu:
        g = nhom[k]
        ds = g["thang"]
        so = [_SO_GOM.findall(v) for v in g["viec"]]
        mau = _SO_GOM.split(g["viec"][0])
        viec = mau[0]
        for j in range(len(mau) - 1):
            cot = [x[j] for x in so]
            if len(set(cot)) == 1:
                viec += cot[0]
            else:
                try:
                    so_nguyen = [int(x.replace(".", "").replace(",", "")) for x in cot]
                    viec += "%s (%s)" % ("{:,}".format(sum(so_nguyen)).replace(",", "."), " + ".join(cot))
                except ValueError:
                    viec += " / ".join(cot)
            viec += mau[j + 1]
        nam = {x.split("/")[-1] for x in ds}
        chu = ds[0] if len(ds) == 1 else (", ".join(x.split("/")[0] for x in ds) + "/" + ds[0].split("/")[-1] if len(nam) == 1 else ", ".join(ds))
        ra.append((g["t"], k[0], "Tháng %s - %s: %s%s" % (chu, g["ten"], viec, " (%d tháng, cùng nguyên nhân)" % len(ds) if len(ds) > 1 else "")))
    return ra


def ghi(kq, thu_muc):
    os.makedirs(thu_muc, exist_ok=True)
    kq["nguoi_gom"] = gom_nguoi(kq)          # GD370b
    p_txt = os.path.join(thu_muc, TEP + ".txt")
    p_html = os.path.join(thu_muc, TEP + ".html")
    L = ["TONG;%s;%d;%s;%d;%d;%s;%s;%d;%d" % (kq["so"], kq["nam"], kq["viec"], kq["tu"], kq["den"], kq["luc"], kq["ten"].replace(";", ","), len(kq["may"]), len(kq["nguoi_gom"]))]
    for m in kq["thang"]:
        for b in m["buoc"]:
            L.append("O;%d;%s;%s;%s;%s;%s;%s;%s" % (m["t"], m["thang"], b["buoc"], b["ten"], b["tt"], b["may"], b["ghi_chu"].replace(";", ","), b["nguoi"].replace(";", ",")))
    for t, buoc, v in kq["nguoi_gom"]:
        L.append("NGUOI;%d;%s;%s" % (t, buoc, v.replace(";", ",")))
    with io.open(p_txt, "w", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")
    with io.open(p_html, "w", encoding="utf-8") as f:
        f.write(_html(kq))
    return p_txt, p_html


def _html(kq):
    e = html.escape
    out = ["<!DOCTYPE html><html lang='vi'><head><meta charset='utf-8'><title>AI_AUTO - rà soát cả kỳ</title>",
           "<style>body{font-family:Segoe UI,Arial;font-size:13px;margin:16px}h1{font-size:18px;color:#022452}h2{font-size:15px;margin:18px 0 6px}table{border-collapse:collapse;width:100%}",
           "th,td{border:1px solid #d5dbe3;padding:4px 6px;vertical-align:top}th{background:#eef3fa;text-align:left}.tt{font-weight:bold;white-space:nowrap}.may{color:#1f4e9a;font-weight:bold}ol li{margin:3px 0}</style></head><body>",
           "<h1>AI_AUTO - %s: %s</h1><p>Sổ <b>%s</b> (%s), năm tài chính %d, tháng %d → %d, rà soát lúc %s. Máy đọc số liệu thật của sổ, không theo dấu tích.</p>" % (
               e("VIỆC MỚI - kỳ kế toán mới" if kq["viec"] == "VIEC_MOI" else "VIỆC CŨ - rà soát số liệu đã làm"), e(kq["ten"]), e(kq["so"]), e(kq["ten"]), kq["nam"], kq["tu"], kq["den"], e(kq["luc"]))]
    for m in kq["thang"]:
        da = sum(1 for b in m["buoc"] if b["tt"] == "DA_LAM" and b["buoc"] not in ("khoa_so", "bao_cao"))
        tong = sum(1 for b in m["buoc"] if b["tt"] not in ("KHONG_CO", "DA_KHOA") and b["buoc"] not in ("khoa_so", "bao_cao"))
        out.append("<h2>Tháng %s%s - đã làm %d/%d việc</h2><table><tr><th>Bước</th><th>Hiện trạng</th><th>AI làm tự động</th><th>Ghi chú</th><th>Việc của anh / chị</th></tr>" % (
            e(m["thang"]), " (ĐÃ KHOÁ SỔ)" if m["khoa"] else "", da, tong))
        for b in m["buoc"]:
            ten, mau = TT_TEN.get(b["tt"], (b["tt"], "#000"))
            out.append("<tr><td>%s</td><td class='tt' style='color:%s'>%s</td><td class='may'>%s</td><td>%s</td><td>%s</td></tr>" % (
                e(b["ten"]), mau, e(ten), ("bước " + b["may"]) if b["may"] else "", e(b["ghi_chu"]), e(b["nguoi"])))
        out.append("</table>")
    ds_ng = kq.get("nguoi_gom") or gom_nguoi(kq)          # GD370b: gom theo nguyen nhan
    out.append("<h2>Việc anh / chị phải làm (máy không làm được): %s</h2>" % ("không có" if not ds_ng else "%d việc (gom theo nguyên nhân)" % len(ds_ng)))
    if ds_ng:
        out.append("<ol>" + "".join("<li>%s</li>" % e(v) for _, _, v in ds_ng) + "</ol>")
    out.append("<h2>Máy làm được bằng nút «AI làm tự động» của khung Các bước AI: %s</h2>" % ("không có" if not kq["may"] else ""))
    if kq["may"]:
        out.append("<ol>" + "".join("<li>%s</li>" % e(v) for _, _, v in kq["may"]) + "</ol>")
    out.append("<p style='color:#666'>Cửa sổ AI_AUTO (UNESCO XI: dòng «AI_AUTO làm trọn kỳ» của khung Các bước AI hoặc nút vàng trên màn hình Các bước AI; UNESCO XII: nút AI_AUTO) làm các bước máy theo thứ tự tháng → bước và chỉ xuất báo cáo, sổ sách khi anh / chị duyệt.</p></body></html>")
    return "\n".join(out)


def _html_so_lieu(rs):
    e = html.escape
    ten = {"KHACH_HANG": "Ghép mã khách hàng", "VAT_TU": "Ghép mã vật tư", "NHOM_VAT_TU": "Chuyển nhóm vật tư", "SO_PHU": "Sổ phụ ngân hàng", "GIA_THANH": "Giá thành"}
    mt = {"CAN_NGUOI": "Cần người", "DE_XUAT": "Đề xuất", "CHU_Y": "Lưu ý"}
    tu = {}
    for k in rs["ke_hoach"]:
        tu.setdefault(k["loai"], [0, 0])[0 if k["may"] else 1] += 1
    o = ["<h2>RÀ SOÁT SỐ LIỆU - máy AI tự ghép (khớp chính xác, duy nhất, tin cậy ≥ 90%)</h2><table><tr><th>Việc</th><th>Máy tự ghép</th><th>Chỉ đề xuất</th></tr>"]
    nm = {"GHEP_KH_HD": "Mã khách hàng cho hoá đơn", "GHEP_VT_HD": "Mã vật tư cho hoá đơn", "CHUYEN_NHOM_VT": "Chuyển nhóm vật tư", "SP_GHEP_KH": "Mã khách cho dòng sổ phụ"}
    for k, v in nm.items():
        a = tu.get(k, [0, 0])
        o.append("<tr><td>%s</td><td class='may'>%d</td><td>%d</td></tr>" % (e(v), a[0], a[1]))
    o.append("</table><h3>Phát hiện</h3><table><tr><th>Nhóm</th><th>Mức</th><th>Số</th><th>Mô tả</th><th>Đề xuất</th></tr>")
    for g, m, so, mo, de in rs["phat_hien"]:
        o.append("<tr><td>%s</td><td>%s</td><td>%d</td><td>%s</td><td>%s</td></tr>" % (e(ten.get(g, g)), e(mt.get(m, m)), so, e(mo), e(de)))
    if not rs["phat_hien"]:
        o.append("<tr><td colspan=5>không có phát hiện</td></tr>")
    o.append("</table><p style='color:#666'>Máy chỉ ghi vào trường ghép mã (AIPartyCode, MaVT, MaKH sổ phụ, nhóm vật tư mồ côi), có sao lưu và nhật ký AI_GHEP; không tạo mã mới, không sửa chứng từ kế toán.</p>")
    return "".join(o)


def _hen_gio_369(kq, thu_muc):
    """GD369: tool chay hen gio (07:30) khong tai duoc vi khong ai dang nhap cong thue -> moc ket-qua\\HEN_GIO_CHO_NGUOI
    (ngay hom nay). Ghi ro o buoc 'Nhan hoa don' cua thang hien tai: viec cua nguoi la bam dang nhap mot lan, may tu tai + hach toan."""
    try:
        p = os.path.join(thu_muc, "HEN_GIO_CHO_NGUOI")
        if not os.path.exists(p):
            return
        nd = io.open(p, encoding="utf-8").read().strip()
        if not nd.startswith(_dt.date.today().strftime("%Y-%m-%d")):
            return
        gio = nd[11:16]
        hom = _dt.date.today()
        for m in kq["thang"]:
            if m["th"] != hom.month or m["nam"] != hom.year:
                continue
            for b in m["buoc"]:
                if b["buoc"] == "tai_hd":
                    b["ghi_chu"] = (b["ghi_chu"] + "; " if b["ghi_chu"] else "") + "hẹn giờ %s hôm nay chưa tải được: không ai đăng nhập cổng thuế" % gio
                    if b["tt"] == "DA_LAM":
                        b["tt"] = "CAN_NGUOI"; b["may"] = ""
                    b["nguoi"] = "mở Trung tâm điều hành / Tải hoá đơn → bấm đăng nhập cổng thuế (gõ mã xác nhận một lần), máy tự tải mua + bán từ đầu tháng đến nay rồi hạch toán"
        nguoi, may = [], []
        for m in kq["thang"]:
            for b in m["buoc"]:
                if b["nguoi"]:
                    nguoi.append((m["t"], b["buoc"], "Tháng %s - %s: %s" % (m["thang"], b["ten"], b["nguoi"])))
                if b["may"] and b["tt"] == "CHUA_LAM":
                    may.append((m["t"], b["buoc"], "Tháng %s - %s: bước %s «AI làm tự động» (%s)" % (m["thang"], b["ten"], b["may"], b["ghi_chu"])))
        kq["nguoi"], kq["may"] = nguoi, may
    except Exception:
        pass


def thu_muc_khach(duong, d, khach=None):
    """GD370: thu muc du lieu AI cua bo so (<thu muc MDB>\\AIHoaDon\\<MST>, VB: HDDT_ThuMucKhach) - noi tool tai hoa don ghi
    ket-qua\\cong_thue_thang.json, HEN_GIO_CHO_NGUOI. VB truyen /aikhach:; thieu -> doan theo MST dang nhap cong thue (MSTLogin)."""
    if khach and os.path.isdir(khach):
        return khach
    goc = os.path.join(os.path.dirname(os.path.abspath(duong)), "AIHoaDon")
    dem = defaultdict(int)
    for h in d.get("hd_ai", ()):
        m = re.sub(r"[^0-9\-]", "", _s(h.get("MSTLogin")))
        if m:
            dem[m] += 1
    for m in sorted(dem, key=lambda x: -dem[x]):
        if os.path.isdir(os.path.join(goc, m)):
            return os.path.join(goc, m)
    return ""


def _nap_cong_thue(d, khach):
    d["khach"] = khach
    d["cong_thue"] = {}
    if khach:
        try:
            with io.open(os.path.join(khach, "ket-qua", "cong_thue_thang.json"), encoding="utf-8") as f:
                o = json.load(f)
            d["cong_thue"] = o if isinstance(o, dict) else {}
        except Exception:
            pass


def chay(duong, viec="VIEC_CU", tu=1, den=None, thu_muc=None, khach=None):
    d = doc(duong)
    _nap_cong_thue(d, thu_muc_khach(duong, d, khach))          # GD370: doi chieu so luong hoa don voi cong thue
    kq = phan_tich(d, tu, den, viec)
    thu_muc = thu_muc or os.path.join(HERE, "ket-qua")
    _hen_gio_369(kq, os.path.join(d["khach"], "ket-qua") if d.get("khach") else thu_muc)          # GD370: moc nam o thu muc KHACH (truoc doc nham thu muc tool)
    r = ghi(kq, thu_muc)
    try:                                            # GD362: ra soat so lieu + ke hoach ghep tu dong
        import ra_soat_so_lieu as RS
        rs, _p = RS.chay(duong, thu_muc, kq["so"])
        kq["so_lieu"] = rs
        them = _html_so_lieu(rs)
        try:                                        # GD363: so phu hoc quy tac tu so tay
            import so_phu_hoc_tay as SP
            Q, dx, sd, _p2 = SP.chay(duong, thu_muc, kq["so"])
            kq["so_phu_tay"] = {"quy_tac": Q["can_cu"], "de_xuat": len(dx), "san_sang": sum(1 for x in dx if x["tin_cay"] >= 90 and not x["tach"]),
                                "so_du_ok": sum(1 for v in sd.values() if v == "OK"), "so_du_lech": sum(1 for v in sd.values() if v == "LECH")}
            e = html.escape
            them += "<h2>SỔ PHỤ - quy tắc học từ sổ tay</h2><table><tr><th>Quy tắc</th><th>Khoá</th><th>Giá trị</th><th>Căn cứ</th></tr>" + "".join(
                "<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>" % tuple(e(str(x)) for x in c) for c in Q["can_cu"]) + "</table>"
            them += "<p>Dòng sao kê chưa ghi: <b>%d</b> đề xuất theo sổ tay (%d sẵn sàng ≥ 90%%, còn lại chờ xác nhận); kiểm lại số dư theo thứ tự trong ngày: %d liên tục, %d lệch.</p>" % (
                kq["so_phu_tay"]["de_xuat"], kq["so_phu_tay"]["san_sang"], kq["so_phu_tay"]["so_du_ok"], kq["so_phu_tay"]["so_du_lech"])
        except Exception as ex2:
            kq["so_phu_tay_loi"] = str(ex2)
        try:                                        # GD368: NVL am / dinh muc / lai lo gia von - gia ban (3 thang), KCTP vuot NVL tung thang
            import gia_thanh_kiem_soat368 as KS8
            k8, _p8 = KS8.chay(duong, thu_muc, den, tu)
            if k8:
                kq["kiem_soat_368"] = {"nhap_bu": len(k8["nhap_bu"]), "lo_that": k8["tong_ll"]["lo_that"], "so_tp": k8["tong_ll"]["so_tp"], "co_cau": k8["tong_ll"]["co_cau"],
                                       "dm_lech": len(k8["dinh_muc"]), "kctp_vuot": len(k8["kctp_vuot"]), "kh_duoi_san": len(k8["kh_duoi"])}
                e = html.escape
                them += "<h2>NVL - ĐỊNH MỨC - LÃI LỖ (GĐ368, 3 tháng đến tháng %d)</h2><p>NVL cần nhập bù: <b>%d</b> (%d có hoá đơn mua chưa hạch toán); thành phẩm lỗ thật 3 tháng: <b>%d/%d</b>%s; định mức lệch 2 tháng liên tiếp: %d; KCTP vượt NVL: <b>%d</b>; khách mua dưới giá sàn: %d. Chi tiết: <a href='gia_thanh_kiem_soat.html'>gia_thanh_kiem_soat.html</a></p>" % (
                    k8["thang_lich"], len(k8["nhap_bu"]), sum(1 for x in k8["nhap_bu"] if x["nguon"] == "HOA_DON"), k8["tong_ll"]["lo_that"], k8["tong_ll"]["so_tp"],
                    " - <b style='color:#b00'>LỖ CƠ CẤU, kiểm: %s</b>" % e("; ".join(k8["kiem_co_cau"])) if k8["tong_ll"]["co_cau"] else "",
                    len(k8["dinh_muc"]), len(k8["kctp_vuot"]), len(k8["kh_duoi"]))
        except Exception as ex3:
            kq["kiem_soat_368_loi"] = str(ex3)
        with io.open(r[1], encoding="utf-8") as f:
            h = f.read()
        with io.open(r[1], "w", encoding="utf-8") as f:
            f.write(h.replace("</body>", them + "</body>"))
    except Exception as ex:
        kq["so_lieu_loi"] = str(ex)
    return (kq,) + r


def main(argv):
    t = {}
    for a in argv[1:]:
        if a.startswith("/") and ":" in a:
            k, v = a[1:].split(":", 1)
            t[k.lower()] = v.strip('"')
    if not t.get("so"):
        print('python ai_auto_dieu_phoi.py /so:"<so.MDB>" [/viec:VIEC_CU|VIEC_MOI] [/tu:1] [/den:12] [/ra:<thu muc>]')
        return 1
    kq, p1, p2 = chay(t["so"], (t.get("viec") or "VIEC_CU").upper(), int(t.get("tu") or 1), int(t.get("den") or 0) or None, t.get("ra"), t.get("aikhach"))
    for m in kq["thang"]:
        for b in m["buoc"]:
            print("T%-2d %-24s %-10s %-2s %s" % (m["t"], b["buoc"], b["tt"], b["may"], b["ghi_chu"][:90]))
    print("nguoi lam: %d, may lam: %d" % (len(kq["nguoi"]), len(kq["may"])))
    print(p2)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
