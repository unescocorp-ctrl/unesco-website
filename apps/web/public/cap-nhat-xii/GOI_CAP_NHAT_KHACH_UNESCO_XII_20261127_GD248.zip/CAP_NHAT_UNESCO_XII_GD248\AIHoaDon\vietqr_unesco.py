# -*- coding: utf-8 -*-
"""GD53 - Ma VietQR (chuan EMVCo / NAPAS 247) + trang THONG BAO CONG NO cho tung khach hang.

Chi dung thu vien chuan (tu ma hoa QR, ve bang SVG) - may khach khong can cai them goi nao.
Noi dung chuyen khoan = <tien to><ma KH>  (vd "TTCNKH0012"): khi khach quet ma va chuyen tien, dong so phu
co dung chuoi nay -> UNESCO nhan ra khach hang 100% (buoc MA_TT) roi doi chieu hoa don cu nhat truoc.

Quy tac 17: so tai khoan chi xuat hien trong trang thong bao (la thong tin nhan tien cua chinh doanh nghiep),
khong ghi vao nhat ky.
"""
import html
import io
import json
import re
import unicodedata
from datetime import datetime

# ------------------------------------------------------------------ ma BIN ngan hang (NAPAS)
BIN = {
    "VCB": "970436", "BIDV": "970418", "CTG": "970415", "ICB": "970415", "AGR": "970405", "AGRI": "970405",
    "VBA": "970405", "ACB": "970416", "STB": "970403", "TCB": "970407", "MB": "970422", "MBB": "970422",
    "VPB": "970432", "TPB": "970423", "SHB": "970443", "HDB": "970437", "VIB": "970441", "MSB": "970426",
    "OCB": "970448", "SEAB": "970440", "EIB": "970431", "LPB": "970449", "ABB": "970425", "BAB": "970409",
    "NAB": "970428", "VAB": "970427", "BVB": "970454", "KLB": "970452", "NCB": "970419", "PVCB": "970412",
    "SGB": "970400", "SCB": "970429", "PGB": "970430", "BAOVIET": "970438", "DAB": "970406", "OJB": "970414",
    "GPB": "970408", "CBB": "970444", "COOP": "970446", "VIETBANK": "970433", "SHBVN": "970424",
    "WVN": "970457", "UOB": "970458", "CIMB": "422589", "PBVN": "970439", "HLBVN": "970442", "IVB": "970434",
    "VRB": "970421", "CAKE": "546034", "UBANK": "546035", "TIMO": "963388",
}
TEN_NH = {
    "VCB": "Vietcombank", "BIDV": "BIDV", "CTG": "VietinBank", "AGR": "Agribank", "AGRI": "Agribank",
    "ACB": "ACB", "STB": "Sacombank", "TCB": "Techcombank", "MB": "MB Bank", "MBB": "MB Bank", "VPB": "VPBank",
    "TPB": "TPBank", "SHB": "SHB", "HDB": "HDBank", "VIB": "VIB", "MSB": "MSB", "OCB": "OCB", "SEAB": "SeABank",
    "EIB": "Eximbank", "LPB": "LPBank", "ABB": "ABBank", "BAB": "Bac A Bank", "NAB": "Nam A Bank",
    "VAB": "VietABank", "BVB": "BVBank", "KLB": "KienlongBank", "NCB": "NCB", "PVCB": "PVcomBank",
    "SGB": "Saigonbank", "SCB": "SCB", "PGB": "PGBank", "VIETBANK": "Vietbank",
}


def bo_dau(s):
    s = str(s or "").replace("Đ", "D").replace("đ", "d")
    return "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")


def ma_sach(s):
    """Chuoi chi con A-Z 0-9 (ma thanh toan phai song sot qua moi ngan hang)."""
    return re.sub(r"[^A-Z0-9]", "", bo_dau(s).upper())


# ------------------------------------------------------------------ EMVCo payload
def crc16(b):
    """CRC-16/CCITT-FALSE (poly 0x1021, init 0xFFFF) - EMVCo muc 63."""
    c = 0xFFFF
    for x in b:
        c ^= x << 8
        for _ in range(8):
            c = ((c << 1) ^ 0x1021) & 0xFFFF if c & 0x8000 else (c << 1) & 0xFFFF
    return c


def _tlv(i, v):
    v = str(v)
    if len(v) > 99:
        raise ValueError("Truong %s dai qua 99 ky tu" % i)
    return "%s%02d%s" % (i, len(v), v)


def chuoi_vietqr(bin_nh, so_tk, tien=0, noi_dung=""):
    """Chuoi VietQR chuyen khoan den tai khoan (dich vu QRIBFTTA). tien=0 -> ma tinh (khach tu nhap tien)."""
    bin_nh = re.sub(r"\D", "", str(bin_nh or ""))
    so_tk = re.sub(r"[^0-9A-Za-z]", "", str(so_tk or ""))
    if len(bin_nh) != 6 or not so_tk:
        raise ValueError("Thieu ma BIN ngan hang (6 so) hoac so tai khoan")
    tt = _tlv("00", "A000000727") + _tlv("01", _tlv("00", bin_nh) + _tlv("01", so_tk)) + _tlv("02", "QRIBFTTA")
    s = _tlv("00", "01") + _tlv("01", "12" if tien and tien > 0 else "11") + _tlv("38", tt) + _tlv("53", "704")
    if tien and tien > 0:
        s += _tlv("54", str(int(round(tien))))
    s += _tlv("58", "VN")
    nd = ma_sach_noi_dung(noi_dung)
    if nd:
        s += _tlv("62", _tlv("08", nd))
    s += "6304"
    return s + "%04X" % crc16(s.encode("ascii"))


def ma_sach_noi_dung(s):
    """Noi dung chuyen khoan: khong dau, chu HOA, chu so va dau cach; toi da 25 ky tu."""
    t = re.sub(r"[^A-Z0-9 ]", " ", bo_dau(s).upper())
    return re.sub(r"\s+", " ", t).strip()[:25].strip()


# ------------------------------------------------------------------ ma hoa QR (byte, muc sua loi M)
_EC_M = {1: (10, [(1, 16)]), 2: (16, [(1, 28)]), 3: (26, [(1, 44)]), 4: (18, [(2, 32)]), 5: (24, [(2, 43)]),
         6: (16, [(4, 27)]), 7: (18, [(4, 31)]), 8: (22, [(2, 38), (2, 39)]), 9: (22, [(3, 36), (2, 37)]),
         10: (26, [(4, 43), (1, 44)]), 11: (30, [(1, 50), (4, 51)]), 12: (22, [(6, 36), (2, 37)]),
         13: (22, [(8, 37), (1, 38)]), 14: (24, [(4, 40), (5, 41)]), 15: (24, [(5, 41), (5, 42)])}
_ALIGN = {1: [], 2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30], 6: [6, 34], 7: [6, 22, 38], 8: [6, 24, 42],
          9: [6, 26, 46], 10: [6, 28, 50], 11: [6, 30, 54], 12: [6, 32, 58], 13: [6, 34, 62],
          14: [6, 26, 46, 66], 15: [6, 26, 48, 70]}

_EXP = [0] * 512
_LOG = [0] * 256
_x = 1
for _i in range(255):
    _EXP[_i] = _x
    _LOG[_x] = _i
    _x <<= 1
    if _x & 0x100:
        _x ^= 0x11D
for _i in range(255, 512):
    _EXP[_i] = _EXP[_i - 255]


def _gf_mul(a, b):
    if a == 0 or b == 0:
        return 0
    return _EXP[_LOG[a] + _LOG[b]]


def _rs_gen(n):
    g = [1]
    for i in range(n):
        ng = [0] * (len(g) + 1)
        for j, c in enumerate(g):
            ng[j] ^= c
            ng[j + 1] ^= _gf_mul(c, _EXP[i])
        g = ng
    return g


def _rs_ec(data, n):
    g = _rs_gen(n)
    r = list(data) + [0] * n
    for i in range(len(data)):
        c = r[i]
        if c:
            for j in range(1, len(g)):
                r[i + j] ^= _gf_mul(g[j], c)
    return r[len(data):]


def _chon_phien_ban(n_byte):
    for v in range(1, 16):
        cap = sum(a * b for a, b in _EC_M[v][1])
        dem = 8 if v <= 9 else 16
        if 4 + dem + 8 * n_byte <= cap * 8:
            return v
    raise ValueError("Du lieu QR dai qua (%d byte)" % n_byte)


def _du_lieu(data, v):
    ec, khoi = _EC_M[v]
    cap = sum(a * b for a, b in khoi)
    bits = [0, 1, 0, 0]
    dem = 8 if v <= 9 else 16
    bits += [(len(data) >> (dem - 1 - i)) & 1 for i in range(dem)]
    for b in data:
        bits += [(b >> (7 - i)) & 1 for i in range(8)]
    bits += [0] * min(4, cap * 8 - len(bits))
    while len(bits) % 8:
        bits.append(0)
    cw = [int("".join(map(str, bits[i:i + 8])), 2) for i in range(0, len(bits), 8)]
    pad = [0xEC, 0x11]
    k = 0
    while len(cw) < cap:
        cw.append(pad[k % 2])
        k += 1
    # chia khoi + sua loi + xen ke
    ds_khoi, i = [], 0
    for so, dai in khoi:
        for _ in range(so):
            ds_khoi.append(cw[i:i + dai])
            i += dai
    ds_ec = [_rs_ec(b, ec) for b in ds_khoi]
    out = []
    for j in range(max(len(b) for b in ds_khoi)):
        for b in ds_khoi:
            if j < len(b):
                out.append(b[j])
    for j in range(ec):
        for e in ds_ec:
            out.append(e[j])
    return out


def _bch(val, poly, bits_poly):
    v = val << (bits_poly - 1)
    while v.bit_length() >= bits_poly:
        v ^= poly << (v.bit_length() - bits_poly)
    return v


def _ma_tran(v):
    n = 17 + 4 * v
    m = [[None] * n for _ in range(n)]

    def dat(r, c, x):
        if 0 <= r < n and 0 <= c < n:
            m[r][c] = x
    for (r0, c0) in ((0, 0), (0, n - 7), (n - 7, 0)):
        for r in range(-1, 8):
            for c in range(-1, 8):
                ok = (0 <= r <= 6 and c in (0, 6)) or (0 <= c <= 6 and r in (0, 6)) or (2 <= r <= 4 and 2 <= c <= 4)
                dat(r0 + r, c0 + c, 1 if ok else 0)
    for i in range(8, n - 8):
        m[6][i] = 1 if i % 2 == 0 else 0
        m[i][6] = 1 if i % 2 == 0 else 0
    ap = _ALIGN[v]
    k = len(ap)
    for ia, r in enumerate(ap):
        for ib, c in enumerate(ap):
            if (ia == 0 and ib == 0) or (ia == 0 and ib == k - 1) or (ia == k - 1 and ib == 0):
                continue                              # trung 3 o dinh vi
            for dr in range(-2, 3):
                for dc in range(-2, 3):
                    m[r + dr][c + dc] = 1 if max(abs(dr), abs(dc)) != 1 else 0
    m[n - 8][8] = 1                                   # dark module
    # cho de danh cho format / version (tam dat 0)
    for i in range(9):
        if m[8][i] is None:
            m[8][i] = 0
        if m[i][8] is None:
            m[i][8] = 0
    for i in range(8):
        if m[8][n - 1 - i] is None:
            m[8][n - 1 - i] = 0
        if m[n - 1 - i][8] is None:
            m[n - 1 - i][8] = 0
    if v >= 7:
        for i in range(6):
            for j in range(3):
                m[i][n - 11 + j] = 0
                m[n - 11 + j][i] = 0
    return m


_MASK = [lambda r, c: (r + c) % 2 == 0, lambda r, c: r % 2 == 0, lambda r, c: c % 3 == 0,
         lambda r, c: (r + c) % 3 == 0, lambda r, c: (r // 2 + c // 3) % 2 == 0,
         lambda r, c: (r * c) % 2 + (r * c) % 3 == 0, lambda r, c: ((r * c) % 2 + (r * c) % 3) % 2 == 0,
         lambda r, c: ((r + c) % 2 + (r * c) % 3) % 2 == 0]


def _dat_du_lieu(khung, cw):
    n = len(khung)
    m = [row[:] for row in khung]
    vi_tri = []
    bits = []
    for b in cw:
        bits += [(b >> (7 - i)) & 1 for i in range(8)]
    c = n - 1
    len_tren = True
    k = 0
    while c > 0:
        if c == 6:
            c -= 1
        rows = range(n - 1, -1, -1) if len_tren else range(n)
        for r in rows:
            for cc in (c, c - 1):
                if m[r][cc] is None:
                    m[r][cc] = bits[k] if k < len(bits) else 0
                    vi_tri.append((r, cc))
                    k += 1
        len_tren = not len_tren
        c -= 2
    return m, vi_tri


def _dat_format(m, mask, v):
    n = len(m)
    f = (0 << 3) | mask                               # muc M = 00
    f = ((f << 10) | _bch(f, 0x537, 11)) ^ 0x5412
    b = [(f >> i) & 1 for i in range(15)]            # b[0] = bit thap nhat
    for i in range(6):
        m[i][8] = b[i]
    m[7][8] = b[6]
    m[8][8] = b[7]
    m[8][7] = b[8]
    for i in range(9, 15):
        m[8][14 - i] = b[i]
    for i in range(8):
        m[8][n - 1 - i] = b[i]
    for i in range(8, 15):
        m[n - 15 + i][8] = b[i]
    m[n - 8][8] = 1
    if v >= 7:
        vi = (v << 12) | _bch(v, 0x1F25, 13)
        for i in range(18):
            bit = (vi >> i) & 1
            a, bb = i // 3, n - 11 + i % 3
            m[a][bb] = bit
            m[bb][a] = bit


def _phat(m):
    n = len(m)
    p = 0
    for hang in (m, [list(x) for x in zip(*m)]):
        for row in hang:
            dem, truoc = 0, None
            for x in row:
                if x == truoc:
                    dem += 1
                else:
                    if dem >= 5:
                        p += dem - 2
                    dem, truoc = 1, x
            if dem >= 5:
                p += dem - 2
            s = "".join(map(str, row))
            p += 40 * (s.count("10111010000") + s.count("00001011101"))
    for r in range(n - 1):
        for c in range(n - 1):
            if m[r][c] == m[r + 1][c] == m[r][c + 1] == m[r + 1][c + 1]:
                p += 3
    toi = sum(sum(row) for row in m)
    k = abs(toi * 20 - n * n * 10) // (n * n)
    return p + 10 * k


def ma_qr(text, mask=None):
    """-> ma tran 0/1 (list hang). mask None = tu chon mau phat thap nhat."""
    data = text.encode("utf-8")
    v = _chon_phien_ban(len(data))
    cw = _du_lieu(data, v)
    khung = _ma_tran(v)
    goc, vi_tri = _dat_du_lieu(khung, cw)
    tot, kq = None, None
    for mk in (range(8) if mask is None else [mask]):
        m = [row[:] for row in goc]
        f = _MASK[mk]
        for (r, c) in vi_tri:
            if f(r, c):
                m[r][c] ^= 1
        _dat_format(m, mk, v)
        diem = _phat(m) if mask is None else 0
        if tot is None or diem < tot:
            tot, kq = diem, m
    return kq


def svg_qr(text, co=4, le=4):
    m = ma_qr(text)
    n = len(m)
    w = (n + 2 * le) * co
    p = []
    for r in range(n):
        for c in range(n):
            if m[r][c]:
                p.append("M%d %dh%dv%dh-%dz" % ((c + le) * co, (r + le) * co, co, co, co))
    return ('<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" viewBox="0 0 %d %d" shape-rendering="crispEdges">'
            '<rect width="100%%" height="100%%" fill="#fff"/><path fill="#000" d="%s"/></svg>' % (w, w, w, w, "".join(p)))


# ------------------------------------------------------------------ trang thong bao cong no
def _tien(v):
    try:
        return "{:,.0f}".format(float(v)).replace(",", ".")
    except Exception:
        return str(v)


def _e(s):
    return html.escape(str(s or ""))


CSS = """
body{font-family:Arial,Helvetica,sans-serif;color:#1d2433;background:#eef1f5;margin:0}
.thanh{position:sticky;top:0;background:#1f4e79;color:#fff;padding:10px 18px;display:flex;gap:14px;align-items:center;flex-wrap:wrap}
.thanh button{background:#fff;color:#1f4e79;border:0;border-radius:4px;padding:6px 14px;font-weight:bold;cursor:pointer}
.tom{background:#fff;margin:14px auto;max-width:900px;padding:14px 20px;border-radius:6px}
.tom table{width:100%;border-collapse:collapse}.tom td,.tom th{padding:5px 6px;border-bottom:1px solid #dde3ea;text-align:left}
.trang{background:#fff;max-width:900px;margin:14px auto;padding:28px 34px;border-radius:6px;box-shadow:0 1px 3px rgba(0,0,0,.12)}
h1{font-size:20px;text-align:center;margin:8px 0 2px}.phu{text-align:center;color:#555;margin-bottom:16px}
table.hd{width:100%;border-collapse:collapse;margin:10px 0}table.hd th,table.hd td{border:1px solid #9aa5b1;padding:5px 7px}
table.hd th{background:#e8eef5}td.so{text-align:right;white-space:nowrap}tr.tong td{font-weight:bold;background:#f6f8fa}
.tt{display:flex;gap:22px;align-items:center;border:2px solid #1f4e79;border-radius:8px;padding:12px 16px;margin-top:14px}
.tt .qr svg{width:190px;height:190px}.nd{font-family:Consolas,monospace;font-size:17px;font-weight:bold;color:#b3261e}
.ghi{color:#555;font-size:12px;margin-top:10px}.kyten{display:flex;justify-content:space-around;margin-top:28px;text-align:center}
@media print{body{background:#fff}.thanh,.tom{display:none}.trang{box-shadow:none;margin:0;max-width:none;page-break-after:always;border-radius:0}}
"""


def ghi_thong_bao(du, duong):
    """du: {cong_ty, mst, dia_chi, tien_to, tai_khoan:{so_tk, ngan_hang, bin, chu_tk}, ngay, khach:[{ma, ten, mst,
        hoa_don:[{ky_hieu, so, ngay, tien}]}]} -> ghi HTML. Tra ve (so khach, ghi chu loi QR)."""
    tk = du.get("tai_khoan") or {}
    nh = str(tk.get("ngan_hang") or "").upper()
    bin_nh = re.sub(r"\D", "", str(tk.get("bin") or "")) or BIN.get(nh, "")
    so_tk = str(tk.get("so_tk") or "")
    chu = re.sub(r"\s+", " ", re.sub(r"[^A-Z0-9 ]", " ", bo_dau(tk.get("chu_tk") or du.get("cong_ty") or "").upper())).strip()
    tien_to = ma_sach(du.get("tien_to") or "TTCN")[:6] or "TTCN"
    ngay = du.get("ngay") or datetime.now().strftime("%d/%m/%Y")
    loi = ""
    if not bin_nh or not so_tk:
        loi = "Chua khai tai khoan nhan tien / ma BIN ngan hang - trang thong bao KHONG co ma QR"
    khach = [k for k in (du.get("khach") or []) if k.get("hoa_don")]
    tong_all = 0.0
    trang, dong_tom = [], []
    for i, k in enumerate(khach, 1):
        hds = sorted(k["hoa_don"], key=lambda h: (h.get("ngay") or "", str(h.get("so") or "")))
        tong = sum(float(h.get("tien") or 0) for h in hds)
        tong_all += tong
        ma_tt = tien_to + ma_sach(k.get("ma") or "")
        nd = ma_tt
        dong = []
        for j, h in enumerate(hds, 1):
            dong.append("<tr><td>%d</td><td>%s</td><td>%s</td><td>%s</td><td class='so'>%s</td></tr>"
                        % (j, _e(h.get("ky_hieu")), _e(h.get("so")), _e(h.get("ngay")), _tien(h.get("tien"))))
        qr = ""
        if not loi and ma_sach(k.get("ma") or ""):
            try:
                qr = svg_qr(chuoi_vietqr(bin_nh, so_tk, tong, nd))
            except Exception as e:
                qr = ""
                loi = "Loi tao ma QR: %s" % e
        tt = ("<div class='tt'><div class='qr'>%s</div><div>"
              "<div>Ngân hàng: <b>%s</b></div><div>Số tài khoản: <b>%s</b></div>"
              "<div>Chủ tài khoản: <b>%s</b></div><div>Số tiền: <b>%s đ</b></div>"
              "<div>Nội dung chuyển khoản: <span class='nd'>%s</span></div>"
              "<div class='ghi'>Quét mã bằng ứng dụng ngân hàng bất kỳ. "
              "Vui lòng GIỮ NGUYÊN nội dung chuyển khoản để khoản "
              "thanh toán được ghi nhận tự động. Thanh toán riêng "
              "từng hóa đơn: ghi <b>%s HD&lt;số hóa đơn&gt;</b>.</div>"
              "</div></div>" % (qr or "<div style='width:190px;color:#b3261e'>(chưa có mã QR)</div>",
                               _e(TEN_NH.get(nh, nh)), _e(so_tk), _e(chu), _tien(tong), _e(nd), _e(nd)))
        trang.append(
            "<div class='trang' id='kh%d'><div><b>%s</b><br>MST: %s<br>%s</div>"
            "<h1>THÔNG BÁO CÔNG NỢ</h1><div class='phu'>Ngày %s</div>"
            "<div>Kính gửi: <b>%s</b>%s</div>"
            "<div>Chúng tôi xin thông báo các hóa đơn chưa thanh toán "
            "đến ngày %s như sau:</div>"
            "<table class='hd'><tr><th>STT</th><th>Ký hiệu</th><th>Số hóa đơn</th>"
            "<th>Ngày</th><th>Số tiền (đ)</th></tr>%s"
            "<tr class='tong'><td colspan='4'>Cộng</td><td class='so'>%s</td></tr></table>%s"
            "<div class='ghi'>Nếu Quý khách đã thanh toán, xin vui lòng bỏ qua "
            "thông báo này hoặc báo lại để chúng tôi đối "
            "chiếu.</div><div class='kyten'><div>XÁC NHẬN CỦA KHÁCH HÀNG</div>"
            "<div>KẾ TOÁN</div></div></div>"
            % (i, _e(du.get("cong_ty")), _e(du.get("mst")), _e(du.get("dia_chi")), _e(ngay), _e(k.get("ten")),
               (" &nbsp; (MST: %s)" % _e(k.get("mst"))) if k.get("mst") else "", _e(ngay), "".join(dong),
               _tien(tong), tt))
        dong_tom.append("<tr><td>%d</td><td><a href='#kh%d'>%s</a></td><td>%s</td><td>%d</td><td class='so'>%s</td><td>%s</td></tr>"
                        % (i, i, _e(k.get("ten")), _e(k.get("ma")), len(hds), _tien(tong), _e(nd)))
    tom = ("<div class='tom'><b>%d khách hàng còn nợ - tổng %s đ</b>%s"
           "<table><tr><th>STT</th><th>Khách hàng</th><th>Mã</th><th>Số HĐ</th>"
           "<th>Còn nợ</th><th>Nội dung CK</th></tr>%s</table></div>"
           % (len(khach), _tien(tong_all), ("<div style='color:#b3261e'>%s</div>" % _e(loi)) if loi else "",
              "".join(dong_tom)))
    doc = ("<!doctype html><html lang='vi'><head><meta charset='utf-8'><title>Thông báo công nợ</title>"
           "<style>%s</style></head><body><div class='thanh'><b>THÔNG BÁO CÔNG NỢ + MÃ VIETQR</b>"
           "<span>%s</span><button onclick='window.print()'>In / Lưu PDF</button></div>%s%s</body></html>"
           % (CSS, _e(du.get("cong_ty")), tom, "".join(trang)))
    with io.open(duong, "w", encoding="utf-8") as f:
        f.write(doc)
    return len(khach), loi


if __name__ == "__main__":
    import sys
    if len(sys.argv) >= 3:
        with io.open(sys.argv[1], "r", encoding="utf-8-sig") as f:
            print(ghi_thong_bao(json.load(f), sys.argv[2]))
