GĐ173 - Thư viện mẫu ngành cho Trợ lý lập định mức (dinh_muc_ai.py). Mỗi ngành một tệp JSON: tu_khoa_nganh (nhận ngành từ tên công ty / sản phẩm),
nhom_nvl (từ khoá xếp NVL vào Chính / Phụ / Bao bì / Năng lượng / Không vào giá thành), co_cau_chinh (tỷ trọng các NVL chính theo từ khoá),
ty_le_gia_ban (khoảng % NVL / NC / SXC trên giá bán), hao_hut, dien_kwh_kg, ty_trong (ml -> gram), vat_lieu / kieu (tách thuộc tính tên sản phẩm),
dinh_muc_cong_bo (văn bản tham chiếu). Mẫu ngành là gợi ý TIN CẬY THẤP (0,3), luôn đánh vàng; sửa tệp để thêm ngành, không cần đổi mã.
Không chứa dữ liệu của khách hàng nào.
