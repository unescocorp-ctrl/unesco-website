# -*- coding: utf-8 -*-
"""GD97 (GD98-B: header du an cho tai khoan nguoi dung, tim gcloud tren Windows) - Google Document AI cho Anh / PDF -> Excel so phu (thu vien chuan Python, khong can goi google-cloud).

Cau hinh: AIHoaDon\\docai.json (phan mem UNESCO ghi khi ke toan cai dat):
    {"processor": "projects/<so du an>/locations/<us|eu>/processors/<ma processor>",   (hoac dan nguyen URL ...:process)
     "khoa": "<duong dan tep khoa JSON>"}                                               (bo trong = dung gcloud / ADC)
Xac thuc (theo thu tu):
    1. tep khoa JSON tai khoan dich vu (type service_account): ky JWT RS256 bang Python thuan -> access token (1 gio);
       hoac tep thong tin dang nhap nguoi dung (type authorized_user, tao boi 'gcloud auth application-default login').
    2. bien moi truong GOOGLE_APPLICATION_CREDENTIALS / %APPDATA%\\gcloud\\application_default_credentials.json.
    3. lenh 'gcloud auth application-default print-access-token'.
Chi doc tep khoa luc chay, KHONG chep / ghi khoa hay token ra dau (quy tac 17). Token chi nam trong bo nho.
GD104 - KHOA CAI SAN (anh Thang: "tep khoa cai mac dinh san nhung kiem soat khi cap su dung"):
    AIHoaDon\\docai_goi.dat = {processor, du_an_quota, khoa (tai khoan dich vu)} MA HOA, do cong cu rieng cua quan tri
    (_CONG_CU_RIENG\\DONG_KHOA_GOOGLE.py) tao. Khoa mo KHONG nam trong ma Python: phan mem UNESCO chi truyen /docai_k:<..>
    khi may DA KICH HOAT AI va CON TRANG anh / PDF (ma kich hoat GD101). Khong co khoa mo -> nhu chua cai.
    May co docai.json rieng (processor rieng) thi dung cau hinh rieng truoc.
Ket qua: dict cung dang Windows OCR / Tesseract {success, pages:[{page_number,width,height,words:[{text,x,y,width,height,conf}]}]}
-> sp_anh_excel.giai_ma_offline doc tiep (cung bo kiem tra chuoi so du / tong phat sinh, to mau XANH / VANG / DO NHAT).
"""
import base64
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

PHAM_VI = "https://www.googleapis.com/auth/cloud-platform"
URL_TOKEN = "https://oauth2.googleapis.com/token"
TRANG_MOT_LAN = 15            # gioi han xu ly truc tuyen cua Document AI (trang / yeu cau)
CO_TOI_DA = 18 * 1024 * 1024  # byte tep gui mot lan (gioi han ~20 MB)
_TOKEN = {"gia_tri": "", "het": 0.0, "nguon": "", "nguoi_dung": False, "quota": ""}
TEP_GOI = "docai_goi.dat"
DAU_GOI = b"UNESCO-DOCAI-GOI1"
_KHOA_MO = [""]         # GD104: khoa mo goi (VB truyen /docai_k khi may da kich hoat + con trang)
_LY_DO_KHOA = [""]      # GD111b: VB bao vi sao KHONG truyen khoa mo (/docai_ly_do:)
_MST = [""]             # GD111b: MST cong ty dang mo (doan ly do khi ban .exe cu khong bao)
LY_DO_KHOA = {
    "CHUA_CO_TEP": "máy này chưa có tệp khoá AIHoaDon\\docai_goi.dat - Cài đặt Google Document AI > IMPORT khoá cài sẵn",
    "CHUA_KICH_HOAT": "máy này chưa kích hoạt AI UNESCO (hoặc dữ liệu kích hoạt không còn đúng) - mở AI, nhập mã kích hoạt",
    "HET_HAN": "mã kích hoạt AI của máy này đã hết hạn - lấy MÃ YÊU CẦU xin mã gia hạn",
    "CONG_TY": "công ty đang mở chưa nằm trong mã kích hoạt AI của máy này - mở AI để thêm công ty (MÃ YÊU CẦU)",
    "HET_TRANG": "máy này đã hết trang Google Document AI - lấy MÃ YÊU CẦU xin mã nạp thêm trang",
    "EXE_CU": ("phần mềm chưa truyền khoá mở cho tool: máy chưa kích hoạt AI / mã hết hạn / công ty chưa đăng ký, hoặc bản .exe "
               "cũ (FIX_TU_DONG.bat -> Make .exe bản mới)"),
    "SAI_KHOA": "tệp AIHoaDon\\docai_goi.dat không mở được bằng khoá của phần mềm này (tệp của bản khác) - IMPORT lại tệp đúng",
}
_GOI = {}
_KHOA_TOKEN = threading.RLock()
_GHI = [print]


class LoiGoogle(RuntimeError):
    """GD126: loi HTTP tu Google Document AI (ma = ma HTTP) - chay() biet HTTP 400 ca tep thi gui lai tung trang anh."""

    def __init__(self, thong, ma=0):
        RuntimeError.__init__(self, thong)
        self.ma = ma


def dat_nhat_ky(ham):
    _GHI[0] = ham


def ghi(s):
    try:
        _GHI[0]("[DOCAI] " + str(s))
    except Exception:
        pass


# ---------------------------------------------------------------- cau hinh
def thu_muc_tool():
    return os.path.dirname(os.path.abspath(__file__))


def doc_cau_hinh(duong=None):
    p = duong or os.path.join(thu_muc_tool(), "docai.json")
    try:
        with io.open(p, "r", encoding="utf-8-sig") as f:
            cd = json.load(f)
        cd = cd if isinstance(cd, dict) else {}
    except Exception:
        cd = {}
    if duong is None and ten_processor(cd.get("processor", ""))[0]:
        k = str(cd.get("khoa") or "").strip().strip('"')
        if k and not os.path.isfile(_tim_tep_khoa(k)) and doc_goi():
            # GD104: docai.json chep tu may khac (tep khoa khong co o may nay) -> dung khoa cai san thay vi bao loi
            ghi("docai.json: tep khoa %s khong co tren may nay -> dung khoa cai san" % os.path.basename(k.replace("\\", "/")))
            cd = {}
    if not ten_processor(cd.get("processor", ""))[0] and duong is None:
        g = doc_goi()                       # GD104: khoa cai san (da mo) -> processor / du an cua goi
        if g:
            cd = {"processor": g.get("processor", ""), "du_an_quota": g.get("du_an_quota", ""), "_goi": True}
    return cd


# ---------------------------------------------------------------- GD104: goi khoa cai san (ma hoa)
def dat_khoa_mo(k):
    """Khoa mo goi do phan mem UNESCO truyen (/docai_k:) - chi co khi may da kich hoat AI + con trang."""
    k = re.sub(r"[^0-9A-Fa-f]", "", str(k or "")).upper()
    if k != _KHOA_MO[0]:
        _KHOA_MO[0] = k
        _GOI.clear()


def dat_ly_do_khoa(v):
    """GD111b: ma ly do VB truyen (/docai_ly_do:) khi khong truyen khoa mo."""
    _LY_DO_KHOA[0] = re.sub(r"[^A-Z_]", "", str(v or "").upper())


def dat_mst(v):
    _MST[0] = re.sub(r"[^0-9\-]", "", str(v or ""))


def _doc_kich_hoat_may():
    """GD111b: CHI DOC du lieu kich hoat AI cua VB6 (HKCU\\Software\\VB and VBA Program Settings\\UNESCO_AI\\KichHoat:
       Ma, Trang, CongTy + %LOCALAPPDATA%\\UNESCO_AI\\kh101.dat) de DOAN ly do khi ban .exe cu khong truyen /docai_ly_do."""
    g = {}
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\VB and VBA Program Settings\UNESCO_AI\KichHoat") as k:
            for ten in ("Ma", "Trang", "CongTy"):
                try:
                    g[ten] = str(winreg.QueryValueEx(k, ten)[0])
                except OSError:
                    pass
    except ImportError:
        g["_loi"] = "khong co winreg"
    except OSError:
        pass                                   # chua co khoa registry = chua kich hoat
    try:
        if os.environ.get("LOCALAPPDATA"):
            p = os.path.join(os.environ["LOCALAPPDATA"], "UNESCO_AI", "kh101.dat")
            if os.path.isfile(p):
                with io.open(p, encoding="utf-8", errors="replace") as f:
                    pt = f.read().strip().split("|")
                if len(pt) >= 3:
                    g["TepTrang"] = pt[2]
    except Exception:
        pass
    return g


def doan_ly_do_may(mst="", g=None):
    """GD111b: ma ly do (CHUA_KICH_HOAT / HET_TRANG / CONG_TY / EXE_CU) tu du lieu kich hoat - chi de bao, khong mo khoa."""
    try:
        g = _doc_kich_hoat_may() if g is None else g
    except Exception:
        return "EXE_CU"
    if g.get("_loi"):
        return "EXE_CU"
    if not re.sub(r"[^0-9A-Za-z]", "", g.get("Ma") or ""):
        return "CHUA_KICH_HOAT"
    for k in ("Trang", "TepTrang"):
        v = (g.get(k) or "").strip()
        if re.fullmatch(r"-?\d+", v) and int(v) == 0:
            return "HET_TRANG"
    so = [re.sub(r"\D", "", x) for x in (g.get("CongTy") or "").split(";")]
    so = [x for x in so if x]
    m = re.sub(r"\D", "", mst or "")
    if so and m and m not in so:
        return "CONG_TY"
    return "EXE_CU"


def ly_do_khoa_goi():
    """GD111b: vi sao khoa Google cai san KHONG mo duoc (cau tieng Viet); '' = mo duoc."""
    if not co_tep_goi():
        return LY_DO_KHOA["CHUA_CO_TEP"]
    if _KHOA_MO[0]:
        return "" if doc_goi() else LY_DO_KHOA["SAI_KHOA"]
    ma = _LY_DO_KHOA[0] if _LY_DO_KHOA[0] in LY_DO_KHOA else doan_ly_do_may(_MST[0])
    return LY_DO_KHOA.get(ma, LY_DO_KHOA["EXE_CU"])


def _dong_khoa(khoa_mo, muoi):
    k = hashlib.pbkdf2_hmac("sha256", khoa_mo.encode("ascii"), muoi, 60000, 64)
    return k[:32], k[32:]


def _dong_xor(k, nonce, b):
    ra = bytearray(len(b))
    for i in range(0, len(b), 32):
        dong = hashlib.sha256(k + nonce + (i // 32).to_bytes(8, "big")).digest()
        for j, x in enumerate(b[i:i + 32]):
            ra[i + j] = x ^ dong[j]
    return bytes(ra)


def ma_hoa_goi(noi_dung, khoa_mo):
    """dict {processor, du_an_quota, khoa{...}} -> bytes ma hoa (dung o cong cu quan tri)."""
    import hmac
    muoi, nonce = os.urandom(16), os.urandom(16)
    k_ma, k_ky = _dong_khoa(khoa_mo, muoi)
    du_lieu = json.dumps(noi_dung, ensure_ascii=False).encode("utf-8")
    ma = _dong_xor(k_ma, nonce, du_lieu)
    ky = hmac.new(k_ky, DAU_GOI + muoi + nonce + ma, hashlib.sha256).digest()
    return DAU_GOI + muoi + nonce + ky + ma


def giai_ma_goi(b, khoa_mo):
    import hmac
    if not b.startswith(DAU_GOI) or len(b) < len(DAU_GOI) + 64:
        raise ValueError("tep goi khoa khong dung dang")
    i = len(DAU_GOI)
    muoi, nonce, ky, ma = b[i:i + 16], b[i + 16:i + 32], b[i + 32:i + 64], b[i + 64:]
    k_ma, k_ky = _dong_khoa(khoa_mo, muoi)
    if not hmac.compare_digest(ky, hmac.new(k_ky, DAU_GOI + muoi + nonce + ma, hashlib.sha256).digest()):
        raise ValueError("khoa mo khong dung (may chua kich hoat dung ma / tep goi cua ban khac)")
    return json.loads(_dong_xor(k_ma, nonce, ma).decode("utf-8"))


def ly_do_chua_cau_hinh():
    """GD104: thong bao ro vi sao chua dung duoc Document AI tren may nay (may khac / chua kich hoat / thieu tep)."""
    if co_tep_goi() and not _KHOA_MO[0]:
        return ("Khoá Google Document AI cài sẵn chỉ mở khi máy ĐÃ KÍCH HOẠT AI (đúng công ty trong gói) và CÒN trang Google "
                "Document AI - chưa mở được: %s. Tạm thời đọc bằng OCR Offline." % ly_do_khoa_goi())          # GD111b
    if co_tep_goi() and not doc_goi():
        return ("Không mở được khoá Google cài sẵn (tệp AIHoaDon\\%s của bản khác / mã kích hoạt cũ) - chép lại thư mục "
                "AIHoaDon từ bộ cài mới nhất, hoặc chọn OCR Offline." % TEP_GOI)
    return ("Chưa cài đặt Google Document AI trên máy này (chưa có khoá Google: thiếu AIHoaDon\\%s và chưa khai processor / "
            "tệp khoá riêng) - Cài đặt Google Document AI > IMPORT khoá cài sẵn (docai_goi.dat), hoặc chọn OCR Offline." % TEP_GOI)


def _giu_khoa():
    """GD118: AIHoaDon thieu docai_goi.dat ma kho cua may (%LOCALAPPDATA%\\UNESCO_AI\\khoa) co -> tu khoi phuc; AIHoaDon co
       -> luu vao kho (doi .exe / cai lai / cap nhat khong phai Import lai). Moi loi bo qua."""
    try:
        if thu_muc_tool() not in sys.path:
            sys.path.insert(0, thu_muc_tool())
        import giu_may
        giu_may.chay(thu_muc_tool(), ghi)
    except Exception:
        pass


def co_tep_goi():
    _giu_khoa()          # GD118
    return os.path.isfile(os.path.join(thu_muc_tool(), TEP_GOI))


def doc_goi():
    """-> dict goi da mo, hoac {} (khong co tep / chua co khoa mo / sai khoa). Khong ghi khoa ra dau."""
    if _GOI.get("_xong"):
        return _GOI.get("noi_dung") or {}
    _GOI["_xong"] = True
    _giu_khoa()          # GD118
    p = os.path.join(thu_muc_tool(), TEP_GOI)
    if not os.path.isfile(p) or not _KHOA_MO[0]:
        return {}
    try:
        with open(p, "rb") as f:
            nd = giai_ma_goi(f.read(), _KHOA_MO[0])
        if isinstance(nd, dict) and isinstance(nd.get("khoa"), dict):
            _GOI["noi_dung"] = nd
            return nd
    except Exception as e:
        ghi("khoa cai san: %s" % str(e)[:200])
    return {}


def ten_processor(s):
    """URL ...:process / 'projects/../locations/../processors/..[/processorVersions/..]' -> (ten tai nguyen, vung)."""
    s = (s or "").strip().strip('"').strip()
    m = re.search(r"(projects/[^/\s]+/locations/([a-z0-9-]+)/processors/[A-Za-z0-9_-]+(?:/processorVersions/[A-Za-z0-9_.-]+)?)", s)
    if not m:
        return "", ""
    return m.group(1), m.group(2)


def da_cau_hinh(cd=None):
    cd = cd if cd is not None else doc_cau_hinh()
    return bool(ten_processor(cd.get("processor", ""))[0])


# ---------------------------------------------------------------- RSA / JWT thuan Python (ky khoa tai khoan dich vu)
def _der(b, i):
    tag = b[i]
    n = b[i + 1]
    i += 2
    if n & 0x80:
        k = n & 0x7F
        n = int.from_bytes(b[i:i + k], "big")
        i += k
    return tag, b[i:i + n], i + n


def _cac_phan(b):
    ra, i = [], 0
    while i < len(b):
        t, v, i = _der(b, i)
        ra.append((t, v))
    return ra


def khoa_rsa_tu_pem(pem):
    """PEM PKCS#8 ('BEGIN PRIVATE KEY') hoac PKCS#1 ('BEGIN RSA PRIVATE KEY') -> (n, e, d, p, q, dp, dq, qi)."""
    b64 = "".join(x.strip() for x in pem.strip().splitlines() if x.strip() and not x.startswith("-----"))
    der = base64.b64decode(b64)
    _, v, _ = _der(der, 0)
    phan = _cac_phan(v)
    if "BEGIN RSA PRIVATE KEY" not in pem:
        oct_ = [x[1] for x in phan if x[0] == 0x04]
        if not oct_:
            raise ValueError("khoa PKCS#8 khong co phan khoa rieng")
        _, v2, _ = _der(oct_[0], 0)
        phan = _cac_phan(v2)
    so = [int.from_bytes(x[1], "big") for x in phan if x[0] == 0x02]
    if len(so) < 9:
        raise ValueError("khoa RSA khong du thanh phan")
    return tuple(so[1:9])


def ky_rs256(du_lieu, khoa):
    n, e, d, p, q, dp, dq, qi = khoa
    k = (n.bit_length() + 7) // 8
    di = bytes.fromhex("3031300d060960864801650304020105000420") + hashlib.sha256(du_lieu).digest()
    em = b"\x00\x01" + b"\xff" * (k - len(di) - 3) + b"\x00" + di
    m = int.from_bytes(em, "big")
    s1, s2 = pow(m, dp, p), pow(m, dq, q)
    s = s2 + ((qi * (s1 - s2)) % p) * q
    return s.to_bytes(k, "big")


def _b64u(b):
    return base64.urlsafe_b64encode(b).rstrip(b"=")


def tao_jwt(tt, bay_gio=None):
    """tt = noi dung tep khoa JSON tai khoan dich vu -> chuoi JWT RS256 xin token pham vi cloud-platform."""
    bay_gio = int(bay_gio if bay_gio is not None else time.time())
    dau = {"alg": "RS256", "typ": "JWT"}
    if tt.get("private_key_id"):
        dau["kid"] = tt["private_key_id"]
    than = {"iss": tt["client_email"], "scope": PHAM_VI, "aud": tt.get("token_uri") or URL_TOKEN, "iat": bay_gio, "exp": bay_gio + 3600}
    ky_tu = _b64u(json.dumps(dau, separators=(",", ":")).encode()) + b"." + _b64u(json.dumps(than, separators=(",", ":")).encode())
    return (ky_tu + b"." + _b64u(ky_rs256(ky_tu, khoa_rsa_tu_pem(tt["private_key"])))).decode()


def _post_form(url, du_lieu, thoi_gian=60):
    req = urllib.request.Request(url, data=urllib.parse.urlencode(du_lieu).encode(), method="POST",
                                 headers={"Content-Type": "application/x-www-form-urlencoded"})
    with urllib.request.urlopen(req, timeout=thoi_gian) as r:
        return json.loads(r.read().decode("utf-8"))


def _token_tu_tep(tep):
    with io.open(tep, "r", encoding="utf-8-sig") as f:
        tt = json.load(f)
    return _token_tu_tt(tt)


def _token_tu_tt(tt):
    loai = tt.get("type")
    if loai == "service_account":
        kq = _post_form(tt.get("token_uri") or URL_TOKEN, {"grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer",
                                                           "assertion": tao_jwt(tt)})
        return kq["access_token"], int(kq.get("expires_in", 3600)), "tai khoan dich vu " + str(tt.get("client_email", "")), False, ""
    if loai == "authorized_user":
        kq = _post_form(URL_TOKEN, {"grant_type": "refresh_token", "refresh_token": tt["refresh_token"],
                                    "client_id": tt["client_id"], "client_secret": tt["client_secret"]})
        # GD98-B: tai khoan NGUOI DUNG (gcloud auth application-default login) - Google can biet du an tinh han muc
        return (kq["access_token"], int(kq.get("expires_in", 3600)), "dang nhap Google (application default)", True,
                str(tt.get("quota_project_id") or ""))
    raise ValueError("tep khoa khong phai service_account / authorized_user (type=%s)" % loai)


def _tep_adc():
    ds = [os.environ.get("GOOGLE_APPLICATION_CREDENTIALS", "")]
    if os.environ.get("APPDATA"):
        ds.append(os.path.join(os.environ["APPDATA"], "gcloud", "application_default_credentials.json"))
    ds.append(os.path.join(os.path.expanduser("~"), ".config", "gcloud", "application_default_credentials.json"))
    return [p for p in ds if p and os.path.isfile(p)]


def _tim_gcloud():
    """GD98-B: gcloud trong PATH, hoac cho cai mac dinh cua Google Cloud CLI tren Windows (PATH chua nap lai sau khi cai)."""
    exe = shutil.which("gcloud") or shutil.which("gcloud.cmd")
    if exe:
        return exe
    ds = []
    for bien in ("LOCALAPPDATA", "ProgramFiles(x86)", "ProgramFiles"):
        if os.environ.get(bien):
            ds.append(os.path.join(os.environ[bien], "Google", "Cloud SDK", "google-cloud-sdk", "bin", "gcloud.cmd"))
    for p in ds:
        if os.path.isfile(p):
            return p
    return ""


def _token_gcloud():
    exe = _tim_gcloud()
    if not exe:
        raise RuntimeError("chua cai gcloud")
    r = subprocess.run([exe, "auth", "application-default", "print-access-token"], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                       timeout=90, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    t = (r.stdout or b"").decode("utf-8", "replace").strip().splitlines()
    if r.returncode != 0 or not t:
        raise RuntimeError("gcloud bao loi: " + (r.stderr or b"").decode("utf-8", "replace").strip()[-300:])
    return t[-1].strip(), 3000, "gcloud", True, ""          # GD98-B: token cua tai khoan nguoi dung


def lay_token(cd, lam_moi=False):
    return _token_day_du(cd, lam_moi)[0]


def _token_day_du(cd, lam_moi=False):
    """GD98-B: (token, nguoi_dung, du_an_quota) doc / lam moi CUNG LUC duoi khoa (4 luong gui trang song song)."""
    with _KHOA_TOKEN:
        if not lam_moi and _TOKEN["gia_tri"] and time.time() < _TOKEN["het"] - 120:
            return _TOKEN["gia_tri"], _TOKEN["nguoi_dung"], _TOKEN["quota"]
        return _lam_moi_token(cd)


def _tim_tep_khoa(tep):
    """GD104: duong dan khoa trong docai.json chep tu may khac (khong ton tai) -> thu ten tep canh docai.json."""
    if os.path.isfile(tep):
        return tep
    p = os.path.join(thu_muc_tool(), os.path.basename(tep.replace("\\", "/")))
    return p if os.path.isfile(p) else tep


def _nguon_goi(kq):
    """khong ghi email tai khoan dich vu cua goi cai san vao nhat ky may khach"""
    return (kq[0], kq[1], "khoa cai san UNESCO", kq[3], kq[4])


def _lam_moi_token(cd):
    loi = []
    cach = []
    goi = doc_goi() if (cd.get("_goi") or not cd.get("khoa")) else {}
    if cd.get("_goi") and goi:
        cach.append(("khoa cai san", lambda: _nguon_goi(_token_tu_tt(goi["khoa"]))))          # GD104: processor cua goi -> khoa cua goi
    tep = (cd.get("khoa") or "").strip().strip('"')
    if tep:
        cach.append(("tep khoa", lambda: _token_tu_tep(_tim_tep_khoa(tep))))
    for p in _tep_adc():
        cach.append(("ADC", lambda p=p: _token_tu_tep(p)))
    cach.append(("gcloud", _token_gcloud))
    if goi and not cd.get("_goi"):
        cach.append(("khoa cai san", lambda: _nguon_goi(_token_tu_tt(goi["khoa"]))))
    for ten, ham in cach:
        try:
            gt, han, nguon, nd, quota = ham()
            _TOKEN.update(gia_tri=gt, het=time.time() + han, nguon=nguon, nguoi_dung=nd, quota=quota)
            ghi("xac thuc: %s" % nguon)
            return gt, nd, quota
        except urllib.error.HTTPError as e:
            loi.append("%s: HTTP %s %s" % (ten, e.code, _than_loi(e)[:200]))
        except Exception as e:
            loi.append("%s: %s" % (ten, str(e)[:200]))
    if co_tep_goi() and not goi:
        loi.insert(0, "khoá cài sẵn chưa mở được: %s" % ly_do_khoa_goi())          # GD111b: dung ly do, dua len dau
    elif not co_tep_goi() and not tep and not _tep_adc():
        loi.insert(0, "máy này chưa có khoá Google (thiếu AIHoaDon\\%s - Cài đặt Google Document AI > IMPORT khoá cài sẵn, "
                      "hoặc khai tệp khoá riêng)" % TEP_GOI)
    raise RuntimeError("Không lấy được quyền truy cập Google Cloud (" + "; ".join(loi) + "). Xem hướng dẫn cài Google Document AI.")


def tieu_de(cd, lam_moi=False):
    """GD98-B: header goi API. Token cua tai khoan NGUOI DUNG (gcloud / ADC) phai kem du an tinh han muc
       (x-goog-user-project) - thieu thi Google bao loi 'requires a quota project'. Lay theo thu tu: docai.json
       "du_an_quota" -> quota_project_id trong tep ADC -> so du an trong duong dan processor."""
    gt, nd, quota = _token_day_du(cd, lam_moi=lam_moi)
    h = {"Authorization": "Bearer " + gt}
    if nd:
        da = str(cd.get("du_an_quota") or quota or "").strip()
        if not da:
            m = re.match(r"projects/([^/]+)/", ten_processor(cd.get("processor", ""))[0])
            da = m.group(1) if m else ""
        if da:
            h["x-goog-user-project"] = da
    return h


def _than_loi(e):
    """Thong diep loi Google + CHI TIET (GD118: fieldViolations / reason / description trong 'details')."""
    try:
        b = e.read().decode("utf-8", "replace")
        j = json.loads(b)
        er = j.get("error") or {}
        tb = er.get("message") or b
        ct = []
        for d in er.get("details") or []:
            if not isinstance(d, dict):
                continue
            for v in d.get("fieldViolations") or []:
                ct.append("%s: %s" % (v.get("field", ""), v.get("description", "")))
            for v in d.get("violations") or []:
                ct.append("%s %s" % (v.get("type", ""), v.get("description", "")))
            if d.get("reason"):
                ct.append("reason=%s" % d.get("reason"))
            if d.get("detail"):
                ct.append(str(d.get("detail")))
        if er.get("status") and er.get("status") not in tb:
            tb = "%s [%s]" % (tb, er.get("status"))
        if ct:
            tb = "%s (chi tiet: %s)" % (tb, "; ".join(x for x in ct if x.strip())[:400])
        return tb
    except Exception:
        return ""


# ---------------------------------------------------------------- GD111: dem trang da gui Google / khoa thuc dung
_DEM_GUI = {"trang": 0}
_KHOA_DEM = threading.Lock()


def _dem_gui(k):
    with _KHOA_DEM:
        _DEM_GUI["trang"] += max(0, int(k))


def so_trang_da_gui():
    """GD111: tong so trang Google da xu ly xong trong tien trinh nay (ke ca lan doc loi giua chung)."""
    return _DEM_GUI["trang"]


def token_la_goi():
    """GD111: lan lay token gan nhat dung KHOA CAI SAN UNESCO (tinh vao so trang cua ma kich hoat)."""
    return _TOKEN.get("nguon") == "khoa cai san UNESCO"


def se_dung_khoa_goi(cd=None):
    """GD111: du doan lan goi Google toi dung khoa cai san (theo thu tu cua _lam_moi_token)."""
    cd = cd if cd is not None else doc_cau_hinh()
    if not doc_goi():
        return False
    if cd.get("_goi"):
        return True
    tep = (cd.get("khoa") or "").strip().strip('"')
    if tep and os.path.isfile(_tim_tep_khoa(tep)):
        return False
    if _tep_adc() or _tim_gcloud():
        return False
    return True


# ---------------------------------------------------------------- goi Document AI
def goi_process(cd, du_lieu, mime, lan=0):
    ten, vung = ten_processor(cd.get("processor", ""))
    if not ten:
        raise RuntimeError("Chưa cài đặt processor Google Document AI (docai.json).")
    url = "https://%s-documentai.googleapis.com/v1/%s:process" % (vung, ten)
    than = {"skipHumanReview": True, "rawDocument": {"mimeType": mime, "content": base64.b64encode(du_lieu).decode("ascii")}}
    hd = tieu_de(cd, lam_moi=(lan > 0))
    hd["Content-Type"] = "application/json; charset=utf-8"
    req = urllib.request.Request(url, data=json.dumps(than).encode("utf-8"), method="POST", headers=hd)
    try:
        with urllib.request.urlopen(req, timeout=300) as r:
            return json.loads(r.read().decode("utf-8")).get("document") or {}
    except urllib.error.HTTPError as e:
        thong = _than_loi(e)
        if e.code in (429, 500, 502, 503, 504) and lan < 4:
            ghi("HTTP %s - thu lai sau %d giay" % (e.code, 5 * (lan + 1)))
            time.sleep(5 * (lan + 1))
            return goi_process(cd, du_lieu, mime, lan + 1)
        if e.code == 401 and lan == 0:
            return goi_process(cd, du_lieu, mime, 1)
        raise LoiGoogle(an_ma(giai_thich_loi(e.code, thong), cd), e.code)          # GD126: kem ma HTTP


def an_ma(s, cd):
    """GD104: dung khoa cai san -> khong de lo so du an / processor cua nha cung cap trong thong bao, nhat ky may khach."""
    if not (cd or {}).get("_goi"):
        return s
    s = re.sub(r"projects/[^\s/\"']+(/[^\s\"']*)?", "projects/***", str(s))
    return re.sub(r"\b\d{9,}\b", "***", s)


def giai_thich_loi(ma, thong):
    t = (thong or "").lower()
    if ma == 403 and ("billing" in t or "thanh toan" in t):
        return "Google Cloud: dự án chưa bật thanh toán (Billing) - bật Billing cho dự án rồi thử lại. (%s)" % thong[:200]
    if ma == 403 and ("has not been used" in t or "disabled" in t or "not enabled" in t):
        return "Google Cloud: chưa bật Cloud Document AI API cho dự án - bật API rồi thử lại. (%s)" % thong[:200]
    if ma in (401, 403) and "quota project" in t:
        return ("Google Cloud: đăng nhập bằng tài khoản người dùng cần dự án tính hạn mức - chạy: gcloud auth application-default "
                "set-quota-project <mã dự án>, hoặc dùng tệp khoá tài khoản dịch vụ. (%s)" % thong[:200])
    if ma in (401, 403):
        return "Google Cloud từ chối quyền (HTTP %s): tài khoản / khoá chưa có vai trò Document AI API User trên dự án. (%s)" % (ma, thong[:200])
    if ma == 404:
        return "Không thấy processor (HTTP 404): kiểm tra số dự án, vùng (us / eu), mã processor. (%s)" % thong[:200]
    if ma == 400 and ("page" in t and ("limit" in t or "exceed" in t)):
        return "TRANG_QUA_NHIEU: " + thong[:200]
    return "Google Document AI lỗi HTTP %s: %s" % (ma, thong[:300])


# ---------------------------------------------------------------- Document AI -> trang dang Windows OCR
def _chu(van_ban, layout):
    ta = (layout or {}).get("textAnchor") or {}
    if ta.get("content"):
        return ta["content"]
    s = ""
    for seg in ta.get("textSegments") or []:
        s += van_ban[int(seg.get("startIndex") or 0):int(seg.get("endIndex") or 0)]
    return s


def _khung(layout, W, H):
    bp = (layout or {}).get("boundingPoly") or {}
    nv = bp.get("normalizedVertices") or []
    if nv:
        xs = [float(v.get("x") or 0) * W for v in nv]
        ys = [float(v.get("y") or 0) * H for v in nv]
    else:
        vv = bp.get("vertices") or []
        if not vv:
            return None
        xs = [float(v.get("x") or 0) for v in vv]
        ys = [float(v.get("y") or 0) for v in vv]
    return min(xs), min(ys), max(xs) - min(xs), max(ys) - min(ys)


def _xoay(x, y, w, h, W, H, huong):
    """Dua toa do ve trang dung (huong chu cua Document AI) -> (x, y, w, h, W, H)."""
    if huong == "PAGE_DOWN":
        return W - x - w, H - y - h, w, h, W, H
    if huong == "PAGE_RIGHT":           # phai nghieng dau sang phai de doc -> quay trang 90 do nguoc chieu kim dong ho
        return y, W - x - w, h, w, H, W
    if huong == "PAGE_LEFT":
        return H - y - h, x, h, w, H, W
    return x, y, w, h, W, H


def sang_trang(tai_lieu, so_trang_dau=1):
    """document (JSON cua Document AI) -> danh sach trang {page_number, width, height, text, words, lines}."""
    van_ban = tai_lieu.get("text") or ""
    ra = []
    for k, pg in enumerate(tai_lieu.get("pages") or []):
        dm = pg.get("dimension") or {}
        W, H = float(dm.get("width") or 1000), float(dm.get("height") or 1000)
        huong = {}
        for b in (pg.get("blocks") or pg.get("lines") or []):
            o = ((b.get("layout") or {}).get("orientation") or "PAGE_UP")
            huong[o] = huong.get(o, 0) + 1
        hg = max(huong, key=huong.get) if huong else "PAGE_UP"
        words, W2, H2 = [], W, H
        for tk in pg.get("tokens") or []:
            ly = tk.get("layout") or {}
            t = _chu(van_ban, ly).strip()
            kh = _khung(ly, W, H)
            if not t or not kh:
                continue
            x, y, w, h, W2, H2 = _xoay(kh[0], kh[1], kh[2], kh[3], W, H, hg)
            words.append({"text": t, "x": round(x, 1), "y": round(y, 1), "width": round(w, 1), "height": round(h, 1),
                          "conf": round(float(ly.get("confidence") or 0) * 100, 1)})
        if not pg.get("tokens"):
            W2, H2 = (H, W) if hg in ("PAGE_RIGHT", "PAGE_LEFT") else (W, H)
        dong = []
        for ln in pg.get("lines") or []:
            t = _chu(van_ban, ln.get("layout")).strip()
            if t:
                dong.append(t)
        ra.append({"page_number": int(pg.get("pageNumber") or (k + 1)) + so_trang_dau - 1, "width": W2, "height": H2,
                   "text": "\n".join(dong), "words": words, "lines": [], "huong": hg})
    return ra


def thuc_the(tai_lieu):
    """Bank Statement Parser / processor co thuc the: dem loai thuc the (ghi nhat ky, doi chieu)."""
    dem = {}
    for e in tai_lieu.get("entities") or []:
        dem[e.get("type", "")] = dem.get(e.get("type", ""), 0) + 1
    return dem


# ---------------------------------------------------------------- doc ca tep
MIME = {".pdf": "application/pdf", ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".tif": "image/tiff",
        ".tiff": "image/tiff", ".bmp": "image/bmp", ".webp": "image/webp", ".gif": "image/gif"}


def dem_trang_pdf(b):
    """So trang PDF. GD126: trang nam trong object stream nen (/ObjStm, PDF 1.5+) -> giai nen, cong trang moi stream;
       khong thay trang nao -> /Count cua tu dien /Type /Pages lon nhat (khong lay /Count cua muc luc); khong co -> 1."""
    pat = rb"/Type\s*/Page(?![s\w])"
    n = len(re.findall(pat, b))
    if n:
        return n
    cac = [b]
    try:
        import zlib
        for m in re.finditer(rb"/Type\s*/ObjStm\b", b):
            k = b.find(b"stream", m.end())
            if k < 0:
                continue
            k += 6
            if b[k:k + 2] == b"\r\n":
                k += 2
            elif b[k:k + 1] in (b"\n", b"\r"):
                k += 1
            e = b.find(b"endstream", k)
            if e < 0:
                continue
            try:
                cac.append(zlib.decompressobj().decompress(b[k:e]))
            except Exception:
                continue
    except Exception:
        pass
    n = sum(len(re.findall(pat, x)) for x in cac[1:])
    if n:
        return n
    dem = []
    for x in cac:
        for m in re.finditer(rb"/Type\s*/Pages\b", x):          # /Count gan nhat quanh /Type /Pages (ke ca tu dien long nhau)
            gan = [(abs(c.start() - m.start()), int(c.group(1))) for c in
                   re.finditer(rb"/Count\s+(\d+)", x[max(0, m.start() - 400):m.end() + 400])]
            if gan:
                dem.append(min(gan)[1])
    return max(dem) if dem else 1


def chay(path, thu_muc_tam, cd=None, ve_anh=None):
    """Doc tep anh / PDF bang Document AI -> doc dang Windows OCR. ve_anh(path, thu_muc) -> [(so_trang, tep_png)] dung khi
       PDF qua TRANG_MOT_LAN trang / qua lon (ve tung trang ra PNG roi gui tung anh)."""
    cd = cd if cd is not None else doc_cau_hinh()
    duoi = os.path.splitext(path)[1].lower()
    mime = MIME.get(duoi)
    if not mime:
        raise RuntimeError("Document AI chỉ nhận PDF / ảnh: " + os.path.basename(path))
    with open(path, "rb") as f:
        b = f.read()
    pages, dem_tt = [], {}
    loi_ca_tep = None          # GD126: loi Google khi gui ca tep (giu de bao neu gui tung trang cung khong duoc)
    gui_ca_tep = len(b) <= CO_TOI_DA and (mime != "application/pdf" or dem_trang_pdf(b) <= TRANG_MOT_LAN)
    if gui_ca_tep:
        try:
            ghi("gui %s (%d KB) mot lan" % (os.path.basename(path), len(b) // 1024))
            tl = goi_process(cd, b, mime)
            pages = sang_trang(tl)
            _dem_gui(len(pages))          # GD111
            dem_tt = thuc_the(tl)
        except RuntimeError as e:
            if ve_anh is None:
                raise
            if str(e).startswith("TRANG_QUA_NHIEU"):
                ghi("qua so trang cho phep -> gui tung trang")
            elif getattr(e, "ma", 0) == 400 and mime == "application/pdf":
                # GD126: Google tu choi CA TEP PDF (vd "Request contains an invalid argument" - kho trang / tep scan la) ->
                #   ve tung trang ra anh roi gui tung anh (Google chua xu ly trang nao - khong tinh trang)
                ghi("Google tu choi ca tep (%s) -> ve tung trang ra anh, gui tung trang" % str(e)[:200])
                loi_ca_tep = e
            else:
                raise
            pages = []
    if not pages:
        if ve_anh is None:
            raise RuntimeError("Tệp quá lớn / quá %d trang - cần vẽ từng trang ra ảnh (chỉ chạy trên Windows)." % TRANG_MOT_LAN)
        try:
            ds = ve_anh(path, thu_muc_tam)
        except Exception as e2:
            if loi_ca_tep is None:
                raise
            raise RuntimeError("%s (gửi từng trang: không vẽ được trang ra ảnh - %s)" % (loi_ca_tep, e2))
        if not ds:          # GD126: khong ve duoc trang nao -> bao loi (truoc day tra ve 0 trang nhu thanh cong)
            if loi_ca_tep is not None:
                raise loi_ca_tep
            raise RuntimeError("Không vẽ được trang nào của %s ra ảnh." % os.path.basename(path))
        ghi("gui tung trang: %d anh" % len(ds))
        from concurrent.futures import ThreadPoolExecutor

        def mot(x):
            so, tep = x
            with open(tep, "rb") as f:
                tl = goi_process(cd, f.read(), "image/png")
            _dem_gui(1)          # GD111: moi anh trang Google da xu ly (tinh tien ca khi trang khac loi)
            return so, sang_trang(tl, so), thuc_the(tl)
        with ThreadPoolExecutor(4) as ex:
            kq = list(ex.map(mot, ds))
        for so, pgs, dt in sorted(kq, key=lambda x: x[0]):
            pages.extend(pgs)
            for k, v in dt.items():
                dem_tt[k] = dem_tt.get(k, 0) + v
    if dem_tt:
        ghi("thuc the: " + ", ".join("%s=%d" % kv for kv in sorted(dem_tt.items())[:12]))
    xoay = sum(1 for p in pages if p.get("huong") not in (None, "PAGE_UP"))
    ghi("%d trang, %d chu%s" % (len(pages), sum(len(p["words"]) for p in pages), (", %d trang xoay" % xoay) if xoay else ""))
    return {"engine": "GOOGLE_DOCUMENT_AI", "success": True, "source": path, "pages": pages,
            "processor": "" if (cd.get("_goi") or token_la_goi()) else ten_processor(cd.get("processor", ""))[0],
            "thuc_the": dem_tt}          # GD111: khong luu processor cua khoa cai san vao ket qua


def _pdf_thu():
    """GD118: PDF 1 trang co chu (de Kiem tra doc thu that) - tu dung, khong can thu vien."""
    noi = b"BT /F1 28 Tf 72 700 Td (UNESCO XI + AI 123456) Tj ET"
    obj = [b"<< /Type /Catalog /Pages 2 0 R >>", b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
           b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>",
           b"<< /Length %d >>\nstream\n" % len(noi) + noi + b"\nendstream",
           b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"]
    b = bytearray(b"%PDF-1.4\n")
    vt = []
    for i, o in enumerate(obj, 1):
        vt.append(len(b))
        b += b"%d 0 obj\n" % i + o + b"\nendobj\n"
    xref = len(b)
    b += b"xref\n0 %d\n0000000000 65535 f \n" % (len(obj) + 1)
    for v in vt:
        b += b"%010d 00000 n \n" % v
    b += b"trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n" % (len(obj) + 1, xref)
    return bytes(b)


def kiem_processor(cd):
    """GET processor (khong gui tai lieu). -> (ok|None, mo ta). None = khoa chi co quyen xu ly, khong doc duoc thong tin."""
    ten, vung = ten_processor(cd.get("processor", ""))
    url = "https://%s-documentai.googleapis.com/v1/%s" % (vung, ten.split("/processorVersions/")[0])
    req = urllib.request.Request(url, headers=tieu_de(cd))
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            j = json.loads(r.read().decode("utf-8"))
        if cd.get("_goi"):
            return True, "processor %s (%s)" % (j.get("type", "?"), j.get("state", "?"))
        return True, "processor %s (%s, %s)" % (j.get("displayName") or ten.split("/")[-1], j.get("type", "?"), j.get("state", "?"))
    except urllib.error.HTTPError as e:
        thong = _than_loi(e)
        if e.code == 403 and "permission" in (thong or "").lower() and "billing" not in thong.lower() and "not been used" not in thong.lower():
            return None, "khoá chỉ có quyền xử lý tài liệu (không đọc được thông tin processor) - sẽ biết khi đọc thật"
        return False, an_ma(giai_thich_loi(e.code, thong), cd)


def kiem_thu(cd=None):
    """Kiem tra cau hinh + quyen (lay token, doc thong tin processor) + GD118: doc thu that 1 trang. Tra ve (ok, thong diep)."""
    cd = cd if cd is not None else doc_cau_hinh()
    ten, vung = ten_processor(cd.get("processor", ""))
    if not ten:
        return False, ly_do_chua_cau_hinh()          # GD104
    try:
        lay_token(cd, lam_moi=True)
    except Exception as e:
        return False, an_ma(str(e), cd)
    try:
        ok, mo_ta = kiem_processor(cd)
    except Exception as e:
        ok, mo_ta = None, "không kiểm tra được processor (%s)" % str(e)[:150]
    if ok is False:
        return False, mo_ta
    # GD118: doc thu THAT 1 trang (truoc chi lay token + thong tin processor -> bao OK trong khi Google tu choi MOI tai lieu
    #   bang HTTP 400 'Request contains an invalid argument'). Trang thu khong tru vao so trang cua ma kich hoat.
    try:
        tl = goi_process(cd, _pdf_thu(), "application/pdf")
        doc_thu = "đọc thử 1 trang: ĐƯỢC (%d chữ)" % len(((tl or {}).get("text") or "").split())
    except Exception as e:
        return False, ("Lấy được quyền truy cập nhưng Google KHÔNG đọc được tài liệu thử: %s. Kiểm tra processor trên Google Cloud "
                       "(loại Document OCR / Form Parser, đang bật, đúng vùng)." % an_ma(str(e), cd)[:500])
    if cd.get("_goi"):
        return True, "Đã lấy được quyền truy cập (khoá Google cài sẵn của UNESCO, mở theo mã kích hoạt); %s." % doc_thu
    return True, "Đã lấy được quyền truy cập (%s); %s, vùng %s; %s; %s." % (_TOKEN["nguon"], ten.split("/")[-1], vung, mo_ta, doc_thu)


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--kiem":
        ok, tb = kiem_thu()
        print(("OK: " if ok else "LOI: ") + tb)
        if len(sys.argv) > 3 and sys.argv[2] == "--ra":
            with io.open(sys.argv[3], "w", encoding="utf-8") as f:
                f.write(("OK " if ok else "LOI ") + tb)
