# -*- coding: utf-8 -*-
"""TNCN chuc nang 4b (28/11/2026) - CHUNG TU KHAU TRU THUE TNCN DIEN TU (ND123/2020 sua doi boi ND70/2025, ND254/2026; mau 03/TNCN;
quy tac PIT15, UAT-PIT10 bo AM-XII-PIT-2026.11.28-v1.1).

So dang ky (ky hieu, so, nguoi, ky, so thue, trang thai) va viec KHONG cap trung mot lan khau tru do XII giu (AiTncnUyQuyenCt.vb, bang
HDDT_TNCN_ChungTuKT). Tep nay CHI LAP TEP cho cac chung tu XII da cap so:
   ct_tncn.py /json:"<vao.json>" /ra:"<thu muc>" /xong:"<tep dau hieu>" [/khong_pdf]
   vao.json = {"dn": {"ten","mst","dia_chi","dien_thoai"}, "nguoi_ky": "...", "ct": [{"ma_so", "ky_hieu_mau", "ky_hieu", "so", "nam",
               "tu_thang", "den_thang", "ho_ten", "mst", "cccd", "quoc_tich", "cu_tru", "dia_chi", "dien_thoai", "khoan_tn", "bao_hiem",
               "tong_tn", "tn_tinh_thue", "so_thue", "ngay_lap"}]}
   -> CTKT_<kyhieu>_<so>.xml + .html (+ .pdf neu may co Chrome / Edge) + ket_qua_ct.json [{"ma_so", "xml", "html", "pdf", "loi"}].
DINH DANG XML: DE XUAT (theo cau truc chung tu dien tu cua ND123/ND70 va chi tieu mau 03/TNCN) - CHUA doi chieu XSD chinh thuc cua
Cuc Thue; ke toan kiem tra va dua vao phan mem / cong cap chung tu duoc Cuc Thue chap nhan. May KHONG ky so, KHONG gui co quan thue.
Khong ghi MST / CCCD vao nhat ky."""
import html
import io
import json
import os
import re
import sys
import xml.etree.ElementTree as ET
from datetime import datetime

THU_MUC = os.path.dirname(os.path.abspath(__file__))
if THU_MUC not in sys.path:
    sys.path.insert(0, THU_MUC)

import uq_tncn as U  # noqa: E402  (doc tham so, HTML -> PDF)

TEP_LOG = os.path.join(THU_MUC, "nhat-ky-tncn-ct.txt")
PHIEN_BAN = "2.1.0-DEXUAT"
GHI_CHU = ("Chứng từ khấu trừ thuế TNCN do phần mềm lập theo định dạng ĐỀ XUẤT (chỉ tiêu mẫu 03/TNCN, NĐ123/2020 sửa đổi bởi NĐ70/2025, "
           "NĐ254/2026) - kế toán kiểm tra với mẫu và định dạng hiện hành, ký số và gửi bằng phần mềm / cổng được cơ quan thuế chấp nhận. "
           "Phần mềm không ký, không gửi.")


def ghi_log(s):
    try:
        with io.open(TEP_LOG, "a", encoding="utf-8") as f:
            f.write("%s %s\n" % (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), s))
    except Exception:
        pass


def _so(v):
    return round(U._so(v))


def _ngay_iso(s):
    d = U._ngay(s)
    return d.strftime("%Y-%m-%d") if d else ""


def _ky(c):
    tu, den, nam = U._nguyen(c.get("tu_thang")), U._nguyen(c.get("den_thang")), U._nguyen(c.get("nam"))
    if not tu or tu == den:
        return "tháng %02d năm %d" % (den or tu, nam)
    return "từ tháng %02d đến tháng %02d năm %d" % (tu, den, nam)


def kiem(c):
    """Loi chan lap tep (chung tu da cap so ma thieu chi tieu bat buoc)."""
    loi = []
    for k, ten in (("ky_hieu_mau", "ký hiệu mẫu"), ("ky_hieu", "ký hiệu"), ("so", "số chứng từ"), ("ho_ten", "họ tên người nộp thuế"),
                   ("nam", "năm")):
        if not str(c.get(k) or "").strip() or str(c.get(k)).strip() == "0":
            loi.append("thiếu " + ten)
    if not (c.get("mst") or c.get("cccd")):
        loi.append("thiếu MST / số định danh người nộp thuế")
    if _so(c.get("so_thue")) < 0 or _so(c.get("tong_tn")) < 0:
        loi.append("số âm")
    if _so(c.get("so_thue")) > _so(c.get("tong_tn")) > 0:
        loi.append("số thuế lớn hơn thu nhập chịu thuế")
    return loi


def _e(cha, ten, gt=None):
    x = ET.SubElement(cha, ten)
    if gt is not None:
        x.text = str(gt)
    return x


def lap_xml(dn, c):
    goc = ET.Element("CTKTTNCN")
    dl = _e(goc, "DLCTu", None)
    dl.set("Id", "CT%s%s" % (re.sub(r"[^0-9A-Za-z]", "", str(c.get("ky_hieu"))), str(c.get("so")).zfill(7)))
    tt = _e(dl, "TTChung")
    _e(tt, "PBan", PHIEN_BAN)
    _e(tt, "TCTu", "CHỨNG TỪ KHẤU TRỪ THUẾ THU NHẬP CÁ NHÂN")
    _e(tt, "KHMSCTu", c.get("ky_hieu_mau"))
    _e(tt, "KHCTu", c.get("ky_hieu"))
    _e(tt, "SCTu", str(c.get("so")).zfill(7))
    _e(tt, "NLap", _ngay_iso(c.get("ngay_lap")))
    _e(tt, "GChu", "Định dạng đề xuất - kế toán kiểm tra trước khi ký số")
    nd = _e(dl, "NDCTu")
    tc = _e(nd, "TCTTNhap")
    _e(tc, "Ten", dn.get("ten"))
    _e(tc, "MST", dn.get("mst"))
    _e(tc, "DChi", dn.get("dia_chi"))
    _e(tc, "SDThoai", dn.get("dien_thoai"))
    nn = _e(nd, "NNT")
    _e(nn, "Ten", c.get("ho_ten"))
    _e(nn, "MST", c.get("mst"))
    _e(nn, "QTich", c.get("quoc_tich") or "Việt Nam")
    _e(nn, "CNCTru", "1" if U._nguyen(c.get("cu_tru", 1)) else "0")
    _e(nn, "DChi", c.get("dia_chi"))
    _e(nn, "SDThoai", c.get("dien_thoai"))
    _e(nn, "SDDCNhan", c.get("cccd"))
    th = _e(nd, "TTThue")
    _e(th, "KTNhap", c.get("khoan_tn") or "Tiền lương, tiền công")
    _e(th, "BHBBuoc", _so(c.get("bao_hiem")))
    tg = _e(th, "TDTNhap")
    _e(tg, "TThang", U._nguyen(c.get("tu_thang")) or U._nguyen(c.get("den_thang")))
    _e(tg, "DThang", U._nguyen(c.get("den_thang")))
    _e(tg, "Nam", U._nguyen(c.get("nam")))
    _e(th, "TTNCThue", _so(c.get("tong_tn")))
    _e(th, "TTNTThue", _so(c.get("tn_tinh_thue")))
    _e(th, "SThue", _so(c.get("so_thue")))
    _e(th, "TTNCNhan", _so(c.get("tong_tn")) - _so(c.get("so_thue")))
    _e(goc, "DSCKS")                          # chu ky so: ke toan ky bang phan mem / thiet bi ky so (may khong ky)
    ET.indent(goc) if hasattr(ET, "indent") else None
    return b'<?xml version="1.0" encoding="UTF-8"?>\n' + ET.tostring(goc, encoding="utf-8")


def lap_html(dn, c, nguoi_ky=""):
    h = U._h
    v = U._vn
    nl = U._ngay(c.get("ngay_lap")) or datetime.now()
    con = _so(c.get("tong_tn")) - _so(c.get("so_thue"))
    s = ["<!doctype html><html lang='vi'><head><meta charset='utf-8'><title>Chứng từ khấu trừ TNCN %s %s</title><style>%s"
         "table.t{width:100%%;border-collapse:collapse;margin-top:6px}table.t td{border:1px solid #000;padding:4px 6px}</style></head><body>"
         % (h(c.get("ky_hieu")), h(c.get("so")), U.CSS),
         "<div class='ghi'>%s</div>" % h(GHI_CHU),
         "<div class='mau'>Mẫu số: 03/TNCN<br>Ký hiệu mẫu: %s<br>Ký hiệu: %s<br>Số: %s</div>" % (h(c.get("ky_hieu_mau")), h(c.get("ky_hieu")),
                                                                                       h(str(c.get("so")).zfill(7))),
         "<p class='b'>%s</p><p>Mã số thuế: %s</p><div style='clear:both'></div>" % (h(dn.get("ten")), h(dn.get("mst"))),
         "<h1>CHỨNG TỪ KHẤU TRỪ THUẾ THU NHẬP CÁ NHÂN</h1>",
         "<p class='b'>I. THÔNG TIN TỔ CHỨC, CÁ NHÂN TRẢ THU NHẬP</p>",
         "<p>[01] Tên tổ chức, cá nhân trả thu nhập: <b>%s</b></p><p>[02] Mã số thuế: %s</p><p>[03] Địa chỉ: %s</p><p>[04] Điện thoại: %s</p>"
         % (h(dn.get("ten")), h(dn.get("mst")), h(dn.get("dia_chi")), h(dn.get("dien_thoai"))),
         "<p class='b'>II. THÔNG TIN NGƯỜI NỘP THUẾ</p>",
         "<p>[05] Họ và tên: <b>%s</b></p><p>[06] Mã số thuế: %s</p><p>[07] Quốc tịch: %s</p>"
         % (h(c.get("ho_ten")), h(c.get("mst")), h(c.get("quoc_tich") or "Việt Nam")),
         "<p>[08] %s Cá nhân cư trú &nbsp;&nbsp; [09] %s Cá nhân không cư trú</p>"
         % (("☒", "☐") if U._nguyen(c.get("cu_tru", 1)) else ("☐", "☒")),
         "<p>[10] Địa chỉ hoặc điện thoại liên hệ: %s</p><p>[11] Số định danh cá nhân / hộ chiếu: %s</p>"
         % (h(" - ".join(x for x in (c.get("dia_chi"), c.get("dien_thoai")) if x)), h(c.get("cccd"))),
         "<p class='b'>III. THÔNG TIN THUẾ THU NHẬP CÁ NHÂN KHẤU TRỪ</p>",
         "<table class='t'>",
         "<tr><td>[12] Khoản thu nhập</td><td>%s</td></tr>" % h(c.get("khoan_tn") or "Tiền lương, tiền công"),
         "<tr><td>[12a] Khoản đóng bảo hiểm bắt buộc</td><td class='r'>%s</td></tr>" % v(_so(c.get("bao_hiem"))),
         "<tr><td>[13] Thời điểm trả thu nhập</td><td>%s</td></tr>" % h(_ky(c)),
         "<tr><td>[14] Tổng thu nhập chịu thuế phải khấu trừ</td><td class='r'>%s</td></tr>" % v(_so(c.get("tong_tn"))),
         "<tr><td>[15] Tổng thu nhập tính thuế</td><td class='r'>%s</td></tr>" % v(_so(c.get("tn_tinh_thue"))),
         "<tr><td>[16] Số thuế thu nhập cá nhân đã khấu trừ</td><td class='r'><b>%s</b></td></tr>" % v(_so(c.get("so_thue"))),
         "<tr><td>[17] Tổng thu nhập còn được nhận ([14] - [16])</td><td class='r'>%s</td></tr>" % v(con),
         "</table>",
         "<table class='k'><tr><td></td><td class='i'>..., ngày %02d tháng %02d năm %d</td></tr><tr><td></td><td class='b'>ĐẠI DIỆN TỔ CHỨC, "
         "CÁ NHÂN TRẢ THU NHẬP</td></tr><tr><td></td><td class='i'>(Chữ ký số / ký điện tử)</td></tr><tr><td style='height:70px'></td><td></td></tr>"
         "<tr><td></td><td class='b'>%s</td></tr></table>" % (nl.day, nl.month, nl.year, h(nguoi_ky)),
         "</body></html>"]
    return "\n".join(s)


def chay(vao, ra, khong_pdf=False):
    with io.open(vao, "r", encoding="utf-8-sig") as f:
        dl = json.load(f)
    dn = dl.get("dn") or {}
    os.makedirs(ra, exist_ok=True)
    kq, so_tep, cb = [], 0, []
    for c in dl.get("ct") or []:
        r = {"ma_so": U._nguyen(c.get("ma_so")), "xml": "", "html": "", "pdf": "", "loi": ""}
        loi = kiem(c)
        if loi:
            r["loi"] = "; ".join(loi)
            kq.append(r)
            continue
        goc = os.path.join(ra, "CTKT_%s_%s" % (U.ten_tep(c.get("ky_hieu")), str(c.get("so")).zfill(7)))
        with open(goc + ".xml", "wb") as f:
            f.write(lap_xml(dn, c))
        with io.open(goc + ".html", "w", encoding="utf-8") as f:
            f.write(lap_html(dn, c, dl.get("nguoi_ky", "")))
        r["xml"], r["html"] = goc + ".xml", goc + ".html"
        if not khong_pdf:
            ok, ly = U.html_ra_pdf(goc + ".html", goc + ".pdf")
            if ok:
                r["pdf"] = goc + ".pdf"
            elif ly and ly not in cb:
                cb.append(ly)
        so_tep += 1
        kq.append(r)
    ket = {"ds": kq, "so_lap": so_tep, "canh_bao": cb + [GHI_CHU]}
    with io.open(os.path.join(ra, "ket_qua_ct.json"), "w", encoding="utf-8") as f:
        json.dump(ket, f, ensure_ascii=False, indent=1)
    ghi_log("CT: %d chung tu, lap %d, loi %d" % (len(kq), so_tep, sum(1 for r in kq if r["loi"])))
    return ket


def main(argv):
    ts = U.doc_tham_so(argv)
    xong = ts["xong"] or os.path.join(ts["ra"] or THU_MUC, "DA_XONG_CTKT")
    try:
        if not ts["json"] or not os.path.isfile(ts["json"]):
            raise RuntimeError("thiếu /json")
        ra = ts["ra"] or os.path.dirname(ts["json"])
        chay(ts["json"], ra, ts["khong_pdf"])
        dau = "OK " + ra
    except Exception as e:  # noqa
        ghi_log("LOI %s" % e)
        dau = "LOI " + str(e)
    finally:
        try:
            if ts["json"] and os.path.isfile(ts["json"]) and not ts["giu"]:
                os.remove(ts["json"])
        except Exception:
            pass
    with io.open(xong, "w", encoding="utf-8") as f:
        f.write(dau + "\n")
    return 0 if dau.startswith("OK") else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
