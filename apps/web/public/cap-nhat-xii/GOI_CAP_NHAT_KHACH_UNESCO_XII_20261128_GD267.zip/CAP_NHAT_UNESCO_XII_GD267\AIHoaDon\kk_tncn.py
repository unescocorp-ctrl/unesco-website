# -*- coding: utf-8 -*-
"""GD121 - TO KHAI KHAU TRU THUE TNCN 05/KK-TNCN (to chuc tra thu nhap tu tien luong, tien cong) theo QUY (theo THANG
khi ky chon la mot thang truoc quy 2/2026). Thay lua chon "To khai thue" cu cua man hinh Bao cao (in to DANG KY thue 01/DK-TNCN
cua TT84/2008 - da bai bo, khong phai to khai thue).
Hop dong xuat_1_lan.py: lap(dl, "KK_TNCN", kieu, thumuc) -> {"tep": [...], "canh_bao": [...]}. CHI DOC SO, khong ghi CSDL.

So lieu: phan JSON "tncn" (ModHDDTTNCN.HDDT_TNCN_JsonThem) - dung lai qtt_tncn.tong_hop (chon nguon BangLuong / bang luong
Excel khong cong trung, gom theo nguoi, NPT, dinh danh) roi CAT theo cac thang cua ky khai.
Chi tieu theo mau TT80/2021 (HTKK 05_KK_TNCN_TT80, maTKhai 864):
  [16] tong so nguoi lao dong (co TNCT trong ky)        [17] trong do ca nhan cu tru co HDLD (bang ke 05-1: loai HD 1, 2)
  [18] = [19] + [20] so ca nhan da khau tru thue        [19] cu tru (co thue da khau tru > 0)   [20] khong cu tru = 0
  [21] = [22] + [23] tong TNCT tra cho ca nhan          [22] cu tru                               [23] = 0
  [24] TNCT tu phi BH nhan tho... = 0                   [25] TNCT mien theo HD dau khi = 0
  [26] = [27] + [28] TNCT thuoc dien phai khau tru      [27] cu tru: TNCT cua cac thang-nguoi DA khau tru thue (> 0)
  [29] = [30] + [31] thue TNCN da khau tru              [30] cu tru = tong thue da khau tru (bang luong)   [32] thue tren phi BH = 0
P0-3 (19/11/2026): ky tu quy 3/2026 -> mau TT89/2026 (HTKK 05_KK_TNCN_TT89, maTKhai 2036, ban 3.0.9): [14] o tich phan bo,
  [15] so NLD, [16] cu tru co HDLD, [17]=[18]+[19] so ca nhan da khau tru, [20]=[21]+[22] TNCT, [23] BH nhan tho, [24]=[25..28] thu
  nhap duoc mien (= 0), [29]=[30]+[31] TNCT thuoc dien khau tru, [32]=[33]+[34] thu nhap tinh thue, [35] thue phai khau tru (theo
  bieu), [36]..[41] thue duoc mien (= 0), [42]=[43]+[44] thue da khau tru, [45] = 0. HTKK khong co khuon TT89 -> khong lap XML.
  Ky den quy 2/2026 giu mau TT80 nhu tren.
P0-2: TNCT = tongthunhap - tn_mienthue (qtt_tncn._dong_pm); doi chieu TK 334 theo thang van dung tong thu nhap.
XML lap tu khung chinh cua HTKK cai tren may (Menu.xml -> InterfaceTemplates\\xml\\05_KK_TNCN_TT80_xml_<ban>.xml) - khong co
HTKK thi chi lap Excel. Khong ghi so CCCD / MST vao nhat ky (chi co trong tep to khai)."""
import calendar
import os
import re
from datetime import date

import qtt_tncn as Q
from qtt_tncn import lam_tron, _vn, _ds, _ds_thang, _dn, _ngay_lap, _nguoi_ky, _kieu, _cot_chia, thue_luy_tien, tham_so_nam

MA_FILE = "05_KK_TNCN_TT80"
CT = ["16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32"]
DONG = [("1", "Tổng số người lao động:", "16", "Người", True),
        ("", "Trong đó: Cá nhân cư trú có hợp đồng lao động", "17", "Người", False),
        ("2", "Tổng số cá nhân đã khấu trừ thuế [18]=[19]+[20]", "18", "Người", True),
        ("2.1", "Cá nhân cư trú", "19", "Người", False),
        ("2.2", "Cá nhân không cư trú", "20", "Người", False),
        ("3", "Tổng thu nhập chịu thuế (TNCT) trả cho cá nhân [21]=[22]+[23]", "21", "VNĐ", True),
        ("3.1", "Cá nhân cư trú", "22", "VNĐ", False),
        ("3.2", "Cá nhân không cư trú", "23", "VNĐ", False),
        ("", "Trong đó: Tổng TNCT từ tiền phí mua bảo hiểm nhân thọ, bảo hiểm không bắt buộc khác của doanh nghiệp bảo hiểm "
             "không thành lập tại Việt Nam cho người lao động", "24", "VNĐ", False),
        ("", "Trong đó: Tổng TNCT được miễn theo quy định của Hợp đồng dầu khí", "25", "VNĐ", False),
        ("", "Thu nhập miễn thuế, thu nhập cá nhân theo nghị quyết", "25_1", "VNĐ", False),          # GD328: [25.1] khuôn HTKK 2.9.3
        ("4", "Tổng TNCT trả cho cá nhân thuộc diện phải khấu trừ thuế [26]=[27]+[28]", "26", "VNĐ", True),
        ("4.1", "Cá nhân cư trú", "27", "VNĐ", False),
        ("4.2", "Cá nhân không cư trú", "28", "VNĐ", False),
        ("5", "Tổng số thuế thu nhập cá nhân (TNCN) đã khấu trừ [29]=[30]+[31]", "29", "VNĐ", True),
        ("5.1", "Cá nhân cư trú", "30", "VNĐ", False),
        ("5.2", "Cá nhân không cư trú", "31", "VNĐ", False),
        ("", "Trong đó: Tổng số thuế TNCN đã khấu trừ trên tiền phí mua bảo hiểm nhân thọ, bảo hiểm không bắt buộc khác của doanh "
             "nghiệp bảo hiểm không thành lập tại Việt Nam cho người lao động", "32", "VNĐ", False)]

# P0-3 (19/11/2026): ky tu quy 3/2026 -> mau TT89/2026 (HTKK 5.8.2: Menu.xml MaFile 05_KK_TNCN_TT89, maTKhai 2036, ban 3.0.9; khung
# InterfaceTemplates\xml\05_KK_TNCN_TT89_xml_309.xml, XSD Validate\05_KK_TNCN_TT89_309.xsd; nhan chi tieu theo sheet '01' cua
# InterfaceTemplates\excel\05_KK_TNCN_TT89_309.xls). [14] (o tich phan bo, boolean) + [15]..[45].
MA_FILE_TT89 = "05_KK_TNCN_TT89"
CT89 = [str(i) for i in range(15, 46)]
DONG_TT89 = [("1", "Tổng số người lao động:", "15", "Người", True),
             ("", "Trong đó: Cá nhân cư trú có hợp đồng lao động", "16", "Người", False),
             ("2", "Tổng số cá nhân đã khấu trừ thuế [17]=[18]+[19]", "17", "Người", True),
             ("2.1", "Cá nhân cư trú", "18", "Người", False),
             ("2.2", "Cá nhân không cư trú", "19", "Người", False),
             ("3", "Tổng thu nhập chịu thuế trả cho cá nhân [20]=[21]+[22]", "20", "VNĐ", True),
             ("3.1", "Cá nhân cư trú", "21", "VNĐ", False),
             ("3.2", "Cá nhân không cư trú", "22", "VNĐ", False),
             ("3.3", "Trong đó: Tổng thu nhập chịu thuế từ tiền phí mua bảo hiểm nhân thọ, bảo hiểm không bắt buộc khác của doanh nghiệp "
                     "bảo hiểm không thành lập tại Việt Nam cho người lao động", "23", "VNĐ", False),
             ("4", "Tổng thu nhập được miễn trong kỳ [24]=[25]+[26]+[27]+[28]", "24", "VNĐ", True),
             ("4.1", "Theo quy định của Hợp đồng dầu khí", "25", "VNĐ", False),
             ("4.2", "Từ thực hiện nhiệm vụ khoa học, công nghệ và đổi mới sáng tạo", "26", "VNĐ", False),
             ("4.3", "Thu nhập của chuyên gia hỗ trợ khởi nghiệp sáng tạo theo quy định", "27", "VNĐ", False),
             ("4.4", "Thu nhập được miễn khác", "28", "VNĐ", False),
             ("5", "Tổng thu nhập chịu thuế trả cho cá nhân thuộc diện phải khấu trừ thuế [29]=[30]+[31]", "29", "VNĐ", True),
             ("5.1", "Cá nhân cư trú", "30", "VNĐ", False),
             ("5.2", "Cá nhân không cư trú", "31", "VNĐ", False),
             ("6", "Thu nhập tính thuế [32]=[33]+[34]", "32", "VNĐ", True),
             ("6.1", "Cá nhân cư trú", "33", "VNĐ", False),
             ("6.2", "Cá nhân không cư trú", "34", "VNĐ", False),
             ("7", "Số thuế thu nhập cá nhân phải khấu trừ trong kỳ", "35", "VNĐ", True),
             ("8", "Số thuế được miễn trong kỳ", "36", "VNĐ", True),
             ("8.1", "Tổng thu nhập của cá nhân là nhân lực công nghiệp công nghệ số chất lượng cao thuộc trường hợp được miễn thuế", "37", "VNĐ", False),
             ("8.2", "Số thuế được miễn của cá nhân là nhân lực công nghiệp công nghệ số chất lượng cao", "38", "VNĐ", False),
             ("8.3", "Tổng thu nhập của cá nhân là nhân lực công nghệ cao thuộc trường hợp được miễn thuế", "39", "VNĐ", False),
             ("8.4", "Số thuế được miễn của cá nhân là nhân lực công nghệ cao thực hiện hoạt động nghiên cứu và phát triển công nghệ cao "
                     "hoặc công nghệ chiến lược", "40", "VNĐ", False),
             ("8.5", "Số thuế được miễn khác theo quy định", "41", "VNĐ", False),
             ("9", "Tổng số thuế thu nhập cá nhân đã khấu trừ [42]=[43]+[44]", "42", "VNĐ", True),
             ("9.1", "Cá nhân cư trú", "43", "VNĐ", False),
             ("9.2", "Cá nhân không cư trú", "44", "VNĐ", False),
             ("9.3", "Trong đó: Tổng số thuế thu nhập cá nhân đã khấu trừ trên tiền phí mua bảo hiểm nhân thọ, bảo hiểm không bắt buộc khác "
                     "của doanh nghiệp bảo hiểm không thành lập tại Việt Nam cho người lao động", "45", "VNĐ", False)]


def la_tt89(k):
    """ky khai (kieu, nam, so, [thang...]) bat dau tu 07/2026 (quy 3/2026) -> mau 05/KK-TNCN TT89/2026."""
    return (k[1], k[3][0]) >= (2026, 7)


# ------------------------------------------------------------------ ky khai
def _ngay(s):
    for f in ("%d/%m/%Y", "%Y-%m-%d"):
        try:
            from datetime import datetime
            return datetime.strptime(str(s or "")[:10], f).date()
        except ValueError:
            pass
    return None


def cac_ky(tu, den):
    """ky khai cho khoang [tu, den]: mot thang truoc 04/2026 -> ky thang; con lai -> cac QUY duong lich giao voi khoang
    (khai thang bo tu quy 2/2026). -> [(kieu "Q"|"M", nam, so quy|thang, [thang...])]."""
    if not tu or not den or den < tu:
        return []
    if tu.year == den.year and tu.month == den.month and (tu.year, tu.month) < (2026, 4):
        return [("M", tu.year, tu.month, [tu.month])]
    ra, y, q = [], tu.year, (tu.month - 1) // 3 + 1
    while (y, q) <= (den.year, (den.month - 1) // 3 + 1) and len(ra) < 8:
        ra.append(("Q", y, q, [3 * q - 2, 3 * q - 1, 3 * q]))
        q += 1
        if q > 4:
            y, q = y + 1, 1
    return ra


def ten_ky(k):
    return ("Quý %d năm %d" % (k[2], k[1])) if k[0] == "Q" else ("Tháng %02d năm %d" % (k[2], k[1]))


def tu_den(k):
    a = date(k[1], k[3][0], 1)
    b = date(k[1], k[3][-1], calendar.monthrange(k[1], k[3][-1])[1])
    return a, b


# ------------------------------------------------------------------ PIT13: phan bo theo tinh (khai tap trung tai tru so)
# 28/11/2026 quy tac AM-XII-PIT-2026.11.28-v1.1 PIT13 (TT89 Dieu 22 khoan 1 diem a tiet a.3.2, a.5):
#   - khai tap trung: phan bo so thue DA KHAU TRU cua TUNG NGUOI ve tinh noi lam viec TAI NGAY TRA thu nhap (dieu chuyen / biet phai tinh
#     theo tinh tai ngay tra);
#   - don vi phu thuoc khai rieng: KHONG ke lai o tru so (bo khoi to khai tru so);
#   - quyet toan nam khong xac dinh lai phan da phan bo dung theo quy (qtt_tncn khong phan bo lai).
# Du lieu (AiYearEndSnapshot): nv[11] = QuanLyNhanVien.TNCN_TinhLamViec: "Tinh" hoac lich su "Tinh A; 01/10/2026=Tinh B" (tu ngay);
#   tham_so.don_vi_phu_thuoc = tham so so TNCN_DonViPhuThuoc: moi don vi "Tinh|MST phu thuoc|Ma CQT|Ten CQT|RIENG" cach nhau ";" hoac
#   xuong dong (RIENG = don vi khai rieng); tham_so.ngay_tra_luong = TNCN_NgayTraLuong: ngay N cua thang SAU thang luong (0/trong = ngay
#   cuoi thang luong). Thieu tinh cua nguoi -> coi la tinh tru so va canh bao.
def _chuan_tinh(s):
    t = Q._ten_sach(s) if hasattr(Q, "_ten_sach") else str(s or "")
    t = re.sub(r"\s+", " ", str(t or "")).strip()
    try:
        import unicodedata
        u = unicodedata.normalize("NFD", t.replace("Đ", "D").replace("đ", "d"))
        u = "".join(c for c in u if unicodedata.category(c) != "Mn").upper()
    except Exception:
        u = t.upper()
    u = re.sub(r"^(TINH|THANH PHO|TP\.?|T\.)\s+", "", u).strip(" .,-")
    return u


def _lich_tinh(txt):
    """'Tinh A; 01/10/2026=Tinh B' -> [(date|None, ten goc)] sap theo ngay (None = tu dau)."""
    ra = []
    for phan in re.split(r"[;\n]+", str(txt or "")):
        phan = phan.strip()
        if not phan:
            continue
        m = re.match(r"^(\d{1,2}/\d{1,2}/\d{4}|\d{4}-\d{2}-\d{2})\s*=\s*(.+)$", phan)
        if m:
            d = _ngay(m.group(1))
            if d:
                ra.append((d, m.group(2).strip()))
                continue
        ra.append((None, phan))
    return sorted(ra, key=lambda x: (x[0] is not None, x[0] or date.min))


def _tinh_tai(lich, ngay_tra):
    kq = None
    for d, t in lich:
        if d is None or d <= ngay_tra:
            kq = t
    return kq


def _ngay_tra(nam, thang, ts):
    n = Q._nguyen((ts or {}).get("ngay_tra_luong"))
    if 1 <= n <= 28:
        y, m = (nam + 1, 1) if thang == 12 else (nam, thang + 1)
        return date(y, m, n)
    return date(nam, thang, calendar.monthrange(nam, thang)[1])


def _don_vi_phu_thuoc(ts):
    ra = []
    for dong in re.split(r"[;\n]+", str((ts or {}).get("don_vi_phu_thuoc") or "")):
        c = [x.strip() for x in dong.split("|")]
        if not c or not c[0]:
            continue
        c += [""] * 5
        ra.append({"tinh": c[0], "khoa": _chuan_tinh(c[0]), "mst": c[1], "ma_cqt": c[2], "ten_cqt": c[3],
                   "rieng": c[4].upper() in ("RIENG", "KHAI RIENG", "1", "X")})
    return ra


def _gan_tinh(dl, k, ng):
    """Gan tinh noi lam viec tai ngay tra cho moi (nguoi, thang) cua ky; bo cac (nguoi, thang) thuoc don vi KHAI RIENG.
    -> (ng da loc, {(manv, thang): (tinh hien thi, khoa tinh, ngay tra)}, thong tin phan bo)."""
    t = dl.get("tncn") or {}
    ts = t.get("tham_so") or {}
    dvs = _don_vi_phu_thuoc(ts)
    tru_so = str(_dn(dl).get("tinh") or "").strip()
    k_ts = _chuan_tinh(tru_so)
    lich = {}
    for r in t.get("nv") or []:
        rr = list(r) + [""] * 12
        if str(rr[11] or "").strip():
            lich[Q._nguyen(rr[0])] = _lich_tinh(rr[11])
    gan, thieu, rieng_bo, la = {}, [], [], []
    loc = []
    for r, loai, th in ng:
        th2 = {}
        for m, d in th.items():
            nt = _ngay_tra(k[1], m, ts)
            ten = _tinh_tai(lich.get(r.get("manv"), []), nt) if r.get("manv") in lich else None
            if not ten:
                ten = tru_so or "(tỉnh trụ sở)"
                if dvs and r["ten"] not in thieu:
                    thieu.append(r["ten"])
            kt = _chuan_tinh(ten)
            dv = next((x for x in dvs if x["khoa"] == kt), None)
            if dv is None and kt != k_ts and k_ts:
                la.append("%s T%02d: %s" % (r["ten"], m, ten))
            if dv is not None and dv["rieng"]:
                rieng_bo.append((r["ten"], m, dv["tinh"], lam_tron(d["thue"])))
                continue
            gan[(r.get("manv"), m)] = (ten, kt, nt)
            th2[m] = d
        if th2:
            loc.append((r, loai, th2))
    return loc, gan, {"don_vi": dvs, "tru_so": tru_so, "khoa_tru_so": k_ts, "thieu": thieu, "rieng_bo": rieng_bo, "la": la,
                      "co_lich": bool(lich)}


def _phan_bo(kiem, gan, pbi):
    """-> danh sach [{tinh, khoa, mst, ma_cqt, ten_cqt, so_nguoi, thue}] theo tinh (tru so truoc); co_phan_bo khi co don vi phu thuoc
    (khai tap trung) va co thue o tinh khac tru so. Tinh khong co don vi phu thuoc -> tinh ve tru so (canh bao rieng)."""
    dvs = {x["khoa"]: x for x in pbi["don_vi"] if not x["rieng"]}
    k_ts = pbi["khoa_tru_so"]
    nhom = {}
    for x in kiem:
        ten, kt, nt = gan.get((x.get("manv"), x["thang"]), (pbi["tru_so"], k_ts, None))
        if kt not in dvs:
            kt, ten = k_ts, pbi["tru_so"] or ten
        g = nhom.setdefault(kt, {"tinh": ten, "khoa": kt, "nguoi": set(), "thue": 0, "tn": 0})
        g["nguoi"].add(x["ten"])
        g["thue"] += x["thue"]
        g["tn"] += x["tn"]
        x["tinh"], x["ngay_tra"] = ten, nt
    ra = []
    for kt in sorted(nhom, key=lambda a: (a != k_ts, a)):
        g = nhom[kt]
        dv = dvs.get(kt) or {}
        ra.append({"tinh": g["tinh"], "khoa": kt, "mst": dv.get("mst", "") if kt != k_ts else "", "ma_cqt": dv.get("ma_cqt", ""),
                   "ten_cqt": dv.get("ten_cqt", ""), "so_nguoi": len(g["nguoi"]), "thue": g["thue"], "tn": g["tn"],
                   "tru_so": kt == k_ts})
    co = bool(dvs) and any(not g["tru_so"] and g["thue"] for g in ra)
    return ra, co


# ------------------------------------------------------------------ tong hop mot ky
def tong_hop_ky(dl, k):
    """-> kq ky: nguoi [(r, loai, {thang: d})], chi tieu ct, chi tiet kiem tra, canh bao."""
    t = dict(dl.get("tncn") or {})
    t["nam_qt"] = k[1]
    dl2 = dict(dl)
    dl2["tncn"] = t
    kq = Q.tong_hop(dl2)
    cb = []
    # 28/11/2026 TNCN chuc nang 1 (NET -> GROSS): nguoi hop dong NET co BangLuong.TNCN_TNQuyDoi (cot 18 cua "thang") > 0 -> thu nhap chiu
    #   thue cua thang lay theo so quy doi thay cho tongthunhap - tn_mienthue (to khai + phan bo tinh dung cung so). tn_tong (doi chieu 334) giu nguyen.
    qd = {}
    for row in t.get("thang") or []:
        if len(row) > 18 and row[18] not in (None, ""):
            try:
                v = float(row[18])
            except (TypeError, ValueError):
                continue
            if v > 0:
                qd.setdefault((Q._nguyen(row[0]), Q._nguyen(row[1])), v)
    da_qd = []
    if qd:
        for ds in (kq["ds1"], kq["ds2"]):
            for r in ds:
                for m, d in r["chi_tiet"].items():
                    v = qd.get((r.get("manv"), m))
                    if v and d.get("nguon") == "PM":
                        d["tn"] = v
                        da_qd.append("%s T%02d" % (r["ten"], m))
    if da_qd:
        cb.append("Hợp đồng NET: thu nhập chịu thuế lấy theo số quy đổi (BangLuong.TNCN_TNQuyDoi) ở %d lượt người-tháng: %s." % (len(da_qd), _ds(da_qd[:20])))
    nam = k[1]
    ts = tham_so_nam(nam)
    ms = set(k[3])
    ng, ex_nhieu = [], []
    for loai, ds in (("05-1", kq["ds1"]), ("05-2", kq["ds2"])):
        for r in ds:
            th = {m: d for m, d in r["chi_tiet"].items() if 1 <= m <= 12 and m in ms}
            for m in r["chi_tiet"]:
                if not 1 <= m <= 12 and (Q.thang_cua_ky(m) & ms):
                    ex_nhieu.append("%s (%s)" % (r["ten"], Q.ten_ky(m, nam)))
            if th and any(lam_tron(d["tn"]) or lam_tron(d["thue"]) or lam_tron(d.get("dmien", 0)) for d in th.values()):
                ng.append((r, loai, th))
    ng, gan, pbi = _gan_tinh(dl, k, ng)          # PIT13: tinh tai ngay tra; bo phan don vi phu thuoc khai rieng
    ct = {c: 0 for c in CT}
    ct["25_1"] = 0                       # GD328: [25.1] (HTKK 2.9.3) - phan mem khong theo doi
    kiem, thieu_dd, lhd3 = [], [], []
    # P0-2b (mau TT89): thu nhap DUOC MIEN (lam them gio, tn_duocmien) KHONG nam trong TNCT [20]/[21]/[29]/[30] (chu DN 19/11/2026
    # «Bo khoi [21]», thong nhat voi 05/QTT 05-1 [12]) va ke rieng [28];
    # thu nhap tinh thue [32]/[33] va thue [35] khong doi (tinh tren tn = tong - tn_mienthue).
    d89 = {"15": 0, "16": 0, "dm": 0, "dm_kt": 0}
    for r, loai, th in ng:
        tn = sum(lam_tron(d["tn"]) for d in th.values())
        thue = sum(lam_tron(d["thue"]) for d in th.values())
        dm = sum(lam_tron(d.get("dmien", 0)) for d in th.values())
        if tn + dm > 0:
            d89["15"] += 1
            if loai == "05-1":
                d89["16"] += 1
        d89["dm"] += dm
        d89["dm_kt"] += sum(lam_tron(d.get("dmien", 0)) for d in th.values() if lam_tron(d["thue"]) > 0)
        if tn > 0:
            ct["16"] += 1
            if loai == "05-1":
                ct["17"] += 1
        if thue > 0:
            ct["19"] += 1
        ct["22"] += tn
        ct["27"] += sum(lam_tron(d["tn"]) for d in th.values() if lam_tron(d["thue"]) > 0)
        ct["30"] += thue
        if r["dd"]["thieu"]:
            thieu_dd.append(r["ten"])
        if loai == "05-2":
            lhd3.append(r["ten"])
        for m in sorted(th):
            d = th[m]
            tn_m, bh, tt_m = lam_tron(d["tn"]), lam_tron(d["bh"]), lam_tron(d["thue"])        # tn = TNCT (P0-2: da tru tn_mienthue)
            mien_m = lam_tron(d.get("mien", 0))
            dmien_m = lam_tron(d.get("dmien", 0))
            tong_m = lam_tron(d.get("tn_tong", d["tn"]))
            npt = d["sothang"] if d["nguon"] == "PM" else r["gc"].get(m, 0)
            if loai == "05-1":
                tntt = max(0, tn_m - bh - ts["gt_ban_than"] - ts["gt_npt"] * npt - lam_tron(d["tu_thien"]))
                bieu = thue_luy_tien(tntt, Q.nam_bieu_thang(nam, m, (dl.get("tncn") or {}).get("tham_so")), 1)
            else:
                tntt, bieu = tn_m, (lam_tron(tn_m * 0.1) if tn_m >= _nguong_vang_lai(nam, m) else 0)
            kiem.append({"manv": r.get("manv"), "ten": r["ten"], "dd": r["dd"], "loai": loai, "thang": m, "tn": tn_m, "bh": bh, "npt": npt, "tntt": tntt,
                         "bieu": bieu, "thue": tt_m, "nguon": d["nguon"], "mien": mien_m, "tong": tong_m,
                         "dmien": dmien_m})
    ct["18"] = ct["19"] + ct["20"]
    ct["21"] = ct["22"] + ct["23"]
    ct["26"] = ct["27"] + ct["28"]
    ct["29"] = ct["30"] + ct["31"]
    mien_ky = sum(x["mien"] for x in kiem)
    if mien_ky:
        n_m = len({x["ten"] for x in kiem if x["mien"]})
        if la_tt89(k):
            cb.append("%s: thu nhập miễn / không chịu thuế theo bảng lương (BangLuong.tn_mienthue) %s của %d người: phụ cấp không tính thuế %s "
                      "đã trừ khỏi thu nhập chịu thuế; thu nhập được miễn (làm thêm giờ, tn_duocmien) %s không tính vào TNCT [21] (như quyết toán 05-1 [12]) và kê riêng [28]. "
                      "Thu nhập tính thuế [33] và thuế theo biểu [35] tính sau khi trừ cả hai." % (
                          ten_ky(k), _vn(mien_ky), n_m, _vn(mien_ky - d89["dm"]), _vn(d89["dm"])))
        else:
            cb.append("%s: đã trừ thu nhập miễn / không chịu thuế theo bảng lương (BangLuong.tn_mienthue) %s của %d người khỏi thu nhập chịu "
                      "thuế; thuế theo biểu tính trên số đã trừ." % (ten_ky(k), _vn(mien_ky), n_m))
            if d89["dm"]:
                cb.append("%s: thu nhập được miễn thuế (làm thêm giờ, tn_duocmien) %s đã TRỪ khỏi thu nhập chịu thuế vì mẫu 05/KK-TNCN "
                          "Thông tư 80 không có chỉ tiêu kê thu nhập được miễn này (thuế không đổi)." % (ten_ky(k), _vn(d89["dm"])))
    ct89 = None
    if la_tt89(k):
        # P0-3: chi tieu mau TT89 (sheet '01' 05_KK_TNCN_TT89_309.xls). [25]-[27] thu nhap duoc mien theo dien (dau khi, KHCN, chuyen
        # gia khoi nghiep) va [36]-[41] thue duoc mien: phan mem khong theo doi -> 0. P0-2b: [28] "Thu nhap duoc mien khac" = tien lam
        # them gio duoc mien (tn_duocmien); phu cap khong tinh thue (tn_mienthue - tn_duocmien) tru khoi TNCT.
        ct89 = {c: 0 for c in CT89}
        ct89["15"], ct89["16"] = d89["15"], d89["16"]
        ct89["18"], ct89["19"] = ct["19"], ct["20"]
        ct89["17"] = ct89["18"] + ct89["19"]
        ct89["21"], ct89["22"] = ct["22"], ct["23"]                          # chu DN 19/11/2026: lam them gio khong vao [21]
        ct89["20"] = ct89["21"] + ct89["22"]
        ct89["28"] = d89["dm"]
        ct89["24"] = ct89["25"] + ct89["26"] + ct89["27"] + ct89["28"]
        ct89["30"], ct89["31"] = ct["27"], ct["28"]
        ct89["29"] = ct89["30"] + ct89["31"]
        ct89["33"] = sum(x["tntt"] for x in kiem)
        ct89["32"] = ct89["33"] + ct89["34"]
        ct89["35"] = sum(x["bieu"] for x in kiem)              # so thue phai khau tru theo bieu (05-1 luy tien thang, 05-2 10%)
        ct89["36"] = ct89["38"] + ct89["40"] + ct89["41"]
        ct89["43"], ct89["44"] = ct["30"], ct["31"]
        ct89["42"] = ct89["43"] + ct89["44"]
    # canh bao
    thang_co = sorted({x["thang"] for x in kiem})
    thieu_th = sorted(ms - set(thang_co))
    if not ng:
        cb.append("%s: không có bảng lương các tháng %s - tờ khai ghi 0 (khai \"không phát sinh\" nếu đúng là không trả lương)."
                  % (ten_ky(k), _ds_thang(k[3])))
    elif thieu_th:
        cb.append("%s: chưa có bảng lương tháng %s - kiểm tra trước khi nộp." % (ten_ky(k), _ds_thang(thieu_th)))
    if ex_nhieu:
        cb.append("Bảng lương Excel nhập theo kỳ nhiều tháng / cả năm không tách được theo tháng nên KHÔNG đưa vào %s: %s."
                  % (ten_ky(k), _ds(sorted(set(ex_nhieu)))))
    lech = [x for x in kiem if x["bieu"] != x["thue"]]
    if lech:
        cb.append("Thuế đã khấu trừ theo bảng lương khác thuế tính theo biểu ở %d lượt người-tháng (biểu %s, bảng lương %s; vd %s). "
                  "Tờ khai kê số ĐÃ khấu trừ (%s); xem sheet \"Chi tiet\" - nếu khấu trừ thiếu thì tính lại thuế tháng ở màn hình "
                  "Tính thuế TNCN rồi lập lại." % (len(lech), _vn(sum(x["bieu"] for x in lech)), _vn(sum(x["thue"] for x in lech)),
                                                    "; ".join("%s T%d: %s/%s" % (x["ten"], x["thang"], _vn(x["bieu"]), _vn(x["thue"]))
                                                              for x in lech[:3]),
                                                    "[43]; số theo biểu ở [35]" if la_tt89(k) else "[30]"))
    if thieu_dd:
        cb.append("%d người thiếu mã số thuế / số CCCD trong hồ sơ nhân viên: %s." % (len(thieu_dd), _ds(thieu_dd)))
    if lhd3:
        cb.append("%d người có loại HĐ \"Dưới 12 tháng\" (kê nhóm không HĐLĐ / HĐ dưới 3 tháng, khấu trừ 10%%): %s. Nếu hợp đồng từ 3 tháng "
                  "trở lên thì đổi loại HĐ để tính theo biểu lũy tiến." % (len(lhd3), _ds(lhd3)))
    gt_pm = Q._nguyen((dl.get("dn") or {}).get("gt_ban_than")) or Q._nguyen(((dl.get("tncn") or {}).get("tham_so") or {}).get("gt_ban_than"))
    if gt_pm and gt_pm < ts["gt_ban_than"]:
        cb.append("Mức giảm trừ bản thân khai trong phần mềm (%s) thấp hơn mức luật năm %d (%s) - thuế tháng có thể đã khấu trừ thừa; "
                  "kiểm tra cột Thuế theo biểu ở sheet \"Chi tiet\"." % (_vn(gt_pm), nam, _vn(ts["gt_ban_than"])))
    doi = []
    x1 = dl.get("x1l") or {}
    if kq["nam"] == kq["nam_tc"] and Q._nguyen(x1.get("thang_dau_ky") or dl.get("thang_dau_ky") or 1) == 1 and Q._ps_co(dl, "334") is not None:
        for m in k[3]:
            bl = sum(x["tong"] for x in kiem if x["thang"] == m)          # P0-2: TONG thu nhap (ca phan mien) so voi Co 334
            th = sum(x["thue"] for x in kiem if x["thang"] == m)
            p334, p3335 = lam_tron(Q._ps_co(dl, "334", m)), lam_tron(Q._ps_co(dl, "3335", m))
            doi.append((m, bl, p334, th, p3335))
        if any(a != b for _, a, b, _, _ in doi):
            cb.append("Tổng thu nhập bảng lương khác phát sinh Có TK 334 ở tháng %s - xem sheet \"Doi chieu\"."
                      % _ds_thang([m for m, a, b, _, _ in doi if a != b]))
        if any(a != b for _, _, _, a, b in doi):
            cb.append("Thuế đã khấu trừ theo bảng lương khác phát sinh Có TK 3335 ở tháng %s (chưa trích thuế TNCN vào sổ / 3335 có khoản "
                      "khác) - xem sheet \"Doi chieu\"." % _ds_thang([m for m, _, _, a, b in doi if a != b]))
    # PIT13: phan bo theo tinh
    pb, co_pb = _phan_bo(kiem, gan, pbi)
    if ct89 is not None:
        ct89["14"] = 1 if co_pb else 0
    if co_pb:
        cb.append("%s: KHAI TẬP TRUNG có phân bổ - thuế đã khấu trừ %s theo tỉnh nơi làm việc tại ngày trả thu nhập: %s. Xem sheet \"Phu luc phan bo\"%s."
                  % (ten_ky(k), _vn(sum(g["thue"] for g in pb)), "; ".join("%s %s" % (g["tinh"], _vn(g["thue"])) for g in pb),
                     "" if ct89 is not None else " (kỳ theo mẫu TT80: ô [15] phân bổ chưa đánh dấu trên tờ khai - kiểm tra trên HTKK)"))
    if pbi["rieng_bo"]:
        cb.append("%s: %d lượt người-tháng thuộc đơn vị phụ thuộc KHAI RIÊNG (%s) không kê lại ở trụ sở, thuế %s." % (
            ten_ky(k), len(pbi["rieng_bo"]), _ds(sorted({x[2] for x in pbi["rieng_bo"]})), _vn(sum(x[3] for x in pbi["rieng_bo"]))))
    if pbi["thieu"] and pbi["don_vi"]:
        cb.append("%d người chưa có tỉnh nơi làm việc (QuanLyNhanVien.TNCN_TinhLamViec) - tạm tính về tỉnh trụ sở %s: %s." % (
            len(pbi["thieu"]), pbi["tru_so"] or "(chưa khai tỉnh trụ sở)", _ds(pbi["thieu"])))
    if pbi["la"]:
        cb.append("Tỉnh nơi làm việc không có đơn vị phụ thuộc đã khai (tham số TNCN_DonViPhuThuoc) - thuế tính về trụ sở: %s." % _ds(pbi["la"][:10]))
    if pbi["don_vi"] and not pbi["tru_so"]:
        cb.append("Chưa khai tỉnh trụ sở chính của doanh nghiệp - không xác định được phần thuế của trụ sở khi phân bổ.")
    return {"ky": k, "nam": nam, "ct": ct, "ct89": ct89, "tt89": ct89 is not None, "kiem": kiem, "doi": doi, "canh_bao": cb, "ts": ts,
            "nguon": kq.get("nguon_mo_ta") or "", "so_nguoi": len(ng), "phan_bo": pb, "co_phan_bo": co_pb, "pbi": pbi}


def _nguong_vang_lai(nam, thang):
    """khau tru 10% khi tra tu nguong / lan cho ca nhan khong HDLD / HD duoi 3 thang: 2 tr; tu 01/7/2026 5 tr (ND 253/2026)."""
    return 5000000 if (nam, thang) >= (2026, 7) else 2000000


# ------------------------------------------------------------------ Excel
def _sheet_to_khai(wb, K, kk, dl):
    dn = _dn(dl)
    k, ct = kk["ky"], kk["ct"]
    rong = [6, 62, 11, 10, 20]
    ws = wb.sheet("05-KK-TNCN", cot=rong)
    c_mau = _cot_chia(rong, tu_phai=30)
    ws.gop(1, 1, 1, c_mau - 1, "CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM", K["qh"])
    ws.gop(2, 1, 2, c_mau - 1, "Độc lập - Tự do - Hạnh phúc", K["qh2"])
    tt89 = bool(kk.get("tt89"))
    if tt89:                                         # P0-3: sheet '01' cua 05_KK_TNCN_TT89_309.xls
        ct = kk["ct89"]
    van_ban = ("Ban hành kèm theo Thông tư số 80/2021/TT-BTC ngày 29 tháng 9 năm 2021 của Bộ trưởng Bộ Tài chính" if not tt89 else
               "Kèm theo Thông tư số 89/2026/TT-BTC ngày 30 tháng 6 năm 2026 của Bộ trưởng Bộ Tài chính")
    ws.gop(1, c_mau, 3, len(rong), "Mẫu số: 05/KK-TNCN\n(%s)" % van_ban, K["mau"])
    ws.cao(3, 34)
    r = 5
    ws.gop(r, 1, r, 5, "TỜ KHAI THUẾ THU NHẬP CÁ NHÂN", K["td"])
    r += 1
    ws.gop(r, 1, r, 5, "(Áp dụng đối với tổ chức, cá nhân trả các khoản thu nhập từ tiền lương, tiền công)", K["td2"])
    r += 1
    ws.gop(r, 1, r, 5, "[01] Kỳ tính thuế: %s" % ten_ky(k), K["qh"])
    r += 1
    ws.gop(r, 1, r, 5, "[02] Lần đầu: [X]          [03] Bổ sung lần thứ: [   ]", K["qh"])
    r += 2
    ws.gop(r, 1, r, 5, "[04] Tên người nộp thuế: %s" % dn.get("ten", ""), K["b"])
    r += 1
    ws.gop(r, 1, r, 5, "[05] Mã số thuế: %s" % dn.get("mst", ""), K["b"])
    r += 1
    if tt89:
        ws.gop(r, 1, r, 5, "[11] Tên tổ chức, cá nhân cung cấp dịch vụ làm thủ tục về thuế (nếu có):        [12] Mã số thuế:", K["t"])
        r += 1
        ws.gop(r, 1, r, 5, "[14] [%s] Phân bổ thuế do có đơn vị hạch toán phụ thuộc tại địa bàn cấp tỉnh khác nơi có trụ sở chính%s" % (
            ("X", " - xem phụ lục phân bổ (sheet \"Phu luc phan bo\")") if kk.get("co_phan_bo") else ("   ", "")), K["ghi"])
    else:
        ws.gop(r, 1, r, 5, "[12] Tên đại lý thuế (nếu có):                [13] Mã số thuế:", K["t"])
        r += 1
        ws.gop(r, 1, r, 5, "[15] [%s] Khai thuế đối với tổ chức có đơn vị phụ thuộc / địa điểm kinh doanh khác tỉnh (phân bổ số thuế)%s" % (
            ("X", " - xem phụ lục phân bổ (sheet \"Phu luc phan bo\")") if kk.get("co_phan_bo") else ("   ", "")), K["ghi"])
    ws.cao(r, 28)
    r += 2
    ws.gop(r, 1, r, 5, "Đơn vị tiền: Đồng Việt Nam", K["dvt"])
    r += 1
    ws.dong(r, 1, ["STT", "Chỉ tiêu", "Mã chỉ tiêu", "Đơn vị tính", "Số người/Số tiền"], K["h"])
    ws.cao(r, 30)
    r += 1
    for stt, ten, ma, dvt, dam in (DONG_TT89 if tt89 else DONG):
        ws.dong(r, 1, [(stt, K["cg"]), (ten, K["cb"] if dam else K["c"]), ("[%s]" % ma.replace("_", "."), K["cg"]), (dvt, K["cg"]),
                       (ct[ma], K["nb"] if dam else K["n"])])
        if len(ten) > 64:
            ws.cao(r, 15 * ((len(ten) + 63) // 64))
        r += 1
    r += 1
    ws.gop(r, 1, r, 5, "Tôi cam đoan số liệu khai trên là đúng và chịu trách nhiệm trước pháp luật về những số liệu đã khai./.", K["ghi"])
    r += 2
    lap = _ngay_lap(dl)
    giua = _cot_chia(rong, ty_le=0.45)
    ws.gop(r, 1, r, giua - 1, "NHÂN VIÊN ĐẠI LÝ THUẾ", K["ky"])
    ws.gop(r, giua, r, 5, "..., ngày %02d tháng %02d năm %d" % (lap.day, lap.month, lap.year), K["ky2"])
    r += 1
    ws.gop(r, 1, r, giua - 1, "Họ và tên: .......................................", K["t"])
    ws.gop(r, giua, r, 5, "NGƯỜI NỘP THUẾ hoặc\nĐẠI DIỆN HỢP PHÁP CỦA NGƯỜI NỘP THUẾ", K["ky"])
    ws.cao(r, 45)
    r += 1
    ws.gop(r, 1, r, giua - 1, "Chứng chỉ hành nghề số: .......................", K["t"])
    ws.gop(r, giua, r, 5, "(Chữ ký, ghi rõ họ tên; chức vụ và đóng dấu (nếu có)/Ký điện tử)", K["ky2"])
    r += 4
    ws.gop(r, giua, r, 5, _nguoi_ky(dl), K["ky"])
    ws.in_trang(ngang=False)
    return ws


def _sheet_chi_tiet(wb, K, kk):
    ts = kk["ts"]
    ws = wb.sheet("Chi tiet", cot=[6, 26, 15, 8, 8, 16, 15, 15, 16, 14, 7, 16, 16, 16, 14])
    ws.gop(1, 1, 1, 15, "CHI TIẾT THU NHẬP - THUẾ TNCN %s (số liệu lập tờ khai 05/KK-TNCN)" % ten_ky(kk["ky"]).upper(), K["qh"])
    ws.gop(2, 1, 2, 15, "Nguồn: %s. Giảm trừ bản thân %s, NPT %s đồng/tháng; %s. Thu nhập chịu thuế = tổng thu nhập - thu nhập miễn / "
                        "không chịu thuế (BangLuong.tn_mienthue). Nhóm 05-2 (HĐ dưới 3 tháng / không HĐLĐ): thuế theo "
                        "biểu = 10%% khi trả từ %s đồng/lần trở lên (tham khảo theo tháng)."
                        % (kk["nguon"] or "-", _vn(ts["gt_ban_than"]), _vn(ts["gt_npt"]), ts["can_cu"],
                           _vn(_nguong_vang_lai(kk["nam"], kk["ky"][3][-1]))), K["ghi"])
    ws.cao(2, 45)
    ws.dong(4, 1, ["STT", "Họ và tên", "MST / số định danh", "Nhóm", "Tháng", "Tổng thu nhập (bảng lương)", "Thu nhập miễn / không chịu thuế",
                   "Trong đó: thu nhập được miễn (làm thêm giờ)",
                   "Thu nhập chịu thuế", "Bảo hiểm bắt buộc NLĐ", "Số NPT",
                   "Thu nhập tính thuế", "Thuế theo biểu", "Thuế đã khấu trừ (bảng lương)", "Chênh lệch"], K["h"])
    ws.cao(4, 45)
    r, stt, cu = 5, 0, None
    for x in kk["kiem"]:
        if x["ten"] != cu:
            stt += 1
            cu = x["ten"]
            nhan = (str(stt), x["ten"], x["dd"]["ct08"] or x["dd"]["ct09"])
        else:
            nhan = ("", "", "")
        ws.dong(r, 1, [(nhan[0], K["cg"]), (nhan[1], K["c"]), (nhan[2], K["txt"]), (x["loai"], K["cg"]),
                       ("%02d%s" % (x["thang"], "" if x["nguon"] == "PM" else " (Excel)"), K["cg"]),
                       (x["tong"], K["n"]), (x["mien"], K["n"]), (x["dmien"], K["n"]),
                       (x["tn"], K["n"]), (x["bh"], K["n"]), (x["npt"], K["n"]), (x["tntt"], K["n"]), (x["bieu"], K["n"]),
                       (x["thue"], K["n"]), (x["thue"] - x["bieu"], K["n"])])
        r += 1
    tong = [sum(x[c] for x in kk["kiem"]) for c in ("tn", "bh", "tntt", "bieu", "thue", "tong", "mien", "dmien")]
    ws.dong(r, 1, [("", K["cg"]), ("Cộng", K["cb"]), ("", K["c"]), ("", K["c"]), ("", K["c"]), (tong[5], K["nb"]), (tong[6], K["nb"]),
                   (tong[7], K["nb"]), (tong[0], K["nb"]), (tong[1], K["nb"]),
                   ("", K["nb"]), (tong[2], K["nb"]), (tong[3], K["nb"]), (tong[4], K["nb"]), (tong[4] - tong[3], K["nb"])])
    ws.dong_bang(5, 3)
    ws.in_trang(ngang=True, lap_dong=(4, 4))
    return ws


def _sheet_doi_chieu(wb, K, kk, cb):
    ws = wb.sheet("Doi chieu", cot=[34, 18, 18, 16, 18, 18, 16])
    ws.gop(1, 1, 1, 7, "KIỂM CHÉO 05/KK-TNCN %s VỚI SỔ KẾ TOÁN" % ten_ky(kk["ky"]).upper(), K["qh"])
    r = 3
    if kk["doi"]:
        ws.dong(r, 1, ["Tháng", "Thu nhập bảng lương", "PS Có TK 334", "Chênh lệch", "Thuế đã khấu trừ", "PS Có TK 3335", "Chênh lệch"], K["h"])
        r += 1
        for m, bl, p334, th, p3335 in kk["doi"]:
            ws.dong(r, 1, [("Tháng %02d/%d" % (m, kk["nam"]), K["c"]), (bl, K["n"]), (p334, K["n"]), (bl - p334, K["n"]),
                           (th, K["n"]), (p3335, K["n"]), (th - p3335, K["n"])])
            r += 1
    else:
        ws.gop(r, 1, r, 7, "Không đối chiếu được với sổ (kỳ khai khác năm tài chính của sổ đang mở, hoặc năm tài chính không bắt đầu tháng 1).",
               K["ghi"])
        r += 1
    r += 1
    ws.gop(r, 1, r, 7, "Cảnh báo / ghi chú khi lập:", K["b"])
    r += 1
    for c in cb:
        ws.gop(r, 1, r, 7, "- " + c, K["ghi"])
        ws.cao(r, 15 * max(1, (len(c) + 139) // 140))
        r += 1
    return ws


def _sheet_phan_bo(wb, K, kk, dl):
    """PIT13: phu luc bang xac dinh so thue TNCN da khau tru phan bo cho tung tinh (khai tap trung) + chi tiet theo nguoi / thang."""
    ws = wb.sheet("Phu luc phan bo", cot=[6, 26, 18, 14, 30, 10, 18, 18])
    dn = _dn(dl)
    ws.gop(1, 1, 1, 8, "PHỤ LỤC: BẢNG XÁC ĐỊNH SỐ THUẾ THU NHẬP CÁ NHÂN PHÂN BỔ CHO ĐỊA PHƯƠNG NƠI CÓ ĐƠN VỊ PHỤ THUỘC - %s" % ten_ky(kk["ky"]).upper(), K["qh"])
    ws.gop(2, 1, 2, 8, "(Kèm theo tờ khai 05/KK-TNCN; khai tập trung tại trụ sở %s - MST %s; số thuế đã khấu trừ của từng người theo tỉnh nơi làm việc "
                       "tại ngày trả thu nhập - Thông tư 89/2026/TT-BTC Điều 22 khoản 1 điểm a; quyết toán năm không xác định lại phần đã phân bổ theo quý)"
                       % (kk["pbi"]["tru_so"] or "-", dn.get("mst", "")), K["ghi"])
    ws.cao(2, 45)
    ws.dong(4, 1, ["STT", "Tỉnh / thành phố", "MST đơn vị phụ thuộc", "Mã CQT", "Cơ quan thuế quản lý", "Số người", "Thu nhập chịu thuế",
                   "Số thuế đã khấu trừ phân bổ"], K["h"])
    ws.cao(4, 30)
    r = 5
    for i, g in enumerate(kk["phan_bo"], 1):
        ws.dong(r, 1, [(str(i), K["cg"]), (g["tinh"] + (" (trụ sở)" if g["tru_so"] else ""), K["c"]), (g["mst"], K["txt"]), (g["ma_cqt"], K["txt"]),
                       (g["ten_cqt"], K["c"]), (g["so_nguoi"], K["n"]), (g["tn"], K["n"]), (g["thue"], K["n"])])
        r += 1
    ws.dong(r, 1, [("", K["cg"]), ("Cộng", K["cb"]), ("", K["c"]), ("", K["c"]), ("", K["c"]), ("", K["n"]),
                   (sum(g["tn"] for g in kk["phan_bo"]), K["nb"]), (sum(g["thue"] for g in kk["phan_bo"]), K["nb"])])
    r += 2
    ws.dong(r, 1, ["STT", "Họ và tên", "Tháng lương", "Ngày trả", "Tỉnh nơi làm việc tại ngày trả", "", "Thu nhập chịu thuế", "Thuế đã khấu trừ"], K["h"])
    r += 1
    for i, x in enumerate(kk["kiem"], 1):
        nt = x.get("ngay_tra")
        ws.dong(r, 1, [(str(i), K["cg"]), (x["ten"], K["c"]), ("%02d/%d" % (x["thang"], kk["nam"]), K["cg"]),
                       (nt.strftime("%d/%m/%Y") if nt else "", K["cg"]), (x.get("tinh") or "", K["c"]), ("", K["c"]), (x["tn"], K["n"]), (x["thue"], K["n"])])
        r += 1
    if kk["pbi"]["rieng_bo"]:
        r += 1
        ws.gop(r, 1, r, 8, "Không kê ở trụ sở (đơn vị phụ thuộc khai riêng): " + "; ".join("%s T%02d %s %s" % (a, b, c, _vn(d)) for a, b, c, d in kk["pbi"]["rieng_bo"][:40]), K["ghi"])
    ws.in_trang(ngang=True, lap_dong=(4, 4))
    return ws


def lap_excel(dl, kk, duong, cb):
    from xlsx_viet import SoExcel
    wb = SoExcel(font="Times New Roman", co=11)
    K = _kieu(wb)
    _sheet_to_khai(wb, K, kk, dl)
    if kk.get("co_phan_bo") or (kk.get("pbi") or {}).get("rieng_bo"):
        _sheet_phan_bo(wb, K, kk, dl)
    _sheet_chi_tiet(wb, K, kk)
    _sheet_doi_chieu(wb, K, kk, cb)          # P0-3: bo sheet "TT89 tham khao" - sheet to khai da theo mau TT89 tu quy 3/2026
    wb.luu(duong)
    return duong


# ------------------------------------------------------------------ XML HTKK (khung cua HTKK tren may)
def _khuon(dl, ma_file=MA_FILE):
    """-> (km, loi): khuon 05/KK-TNCN (MaFile 05_KK_TNCN_TT80 hoac 05_KK_TNCN_TT89) tu HTKK tren may (tool_htkk_unesco.khuon_may)."""
    st = dl.setdefault("_kk_cache", {})
    kh = st.setdefault("km_mau", {})
    if ma_file in kh:
        return kh[ma_file]
    try:
        import tool_htkk_unesco as X
        h = X.tim_htkk()
    except Exception as e:
        kh[ma_file] = (None, "không nạp được tool HTKK (%s)" % e)
        return kh[ma_file]
    if not isinstance(h, dict) or not h.get("goc"):
        kh[ma_file] = (None, "không thấy HTKK cài trên máy")
        return kh[ma_file]
    st["htkk"] = h
    kh[ma_file] = X.khuon_may(h["goc"], ma_file)
    return kh[ma_file]


def lap_xml(dl, kk, duong, cb):
    """XML 05/KK-TNCN theo khung HTKK tren may: ky den quy 2/2026 -> 05_KK_TNCN_TT80 (chi tieu [15]-[32], [25.1]); tu quy 3/2026 ->
    05_KK_TNCN_TT89 (P0-3: [14] o tich phan bo + [15]-[45]). HTKK chua co khung TT89 -> KHONG lap XML mau TT80 cho ky TT89."""
    import tool_htkk_unesco as X
    k = kk["ky"]
    tt89 = bool(kk.get("tt89"))
    km, loi = _khuon(dl, MA_FILE_TT89 if tt89 else MA_FILE)
    if not km:
        if tt89:
            cb.append("Chưa lập XML 05/KK-TNCN %s theo mẫu Thông tư 89/2026: %s - cập nhật HTKK có mẫu 05/KK-TNCN TT89 hoặc nhập %d chỉ tiêu "
                      "theo sheet 05-KK-TNCN vào HTKK." % (ten_ky(k), loi, len(CT89)))
        else:
            cb.append("Chưa lập XML 05/KK-TNCN: %s - nhập %d chỉ tiêu theo sheet 05-KK-TNCN vào HTKK." % (loi, len(CT)))
        return None
    ct_ky = dict(kk["ct89"], **{"14": 1 if kk.get("co_phan_bo") else 0}) if tt89 else kk["ct"]          # TT89 [14] = o tich phan bo (PIT13)
    if kk.get("co_phan_bo"):
        cb.append("XML 05/KK-TNCN %s: đã đánh dấu [14] phân bổ; phụ lục bảng xác định số thuế phân bổ cho từng tỉnh CHƯA đưa vào XML (khung "
                  "phụ lục HTKK chưa nối) - nhập phụ lục trên HTKK theo sheet \"Phu luc phan bo\" trước khi nộp." % ten_ky(k))
    ct_can = CT89 if tt89 else CT
    dn = _dn(dl)
    h = (dl.get("_kk_cache") or {}).get("htkk") or {}
    hd = X.dau_may(km["goc"], dn.get("mst", "")) or {}
    goc = X._khung_ns(km["khung"])
    t = "/HSoKhaiThue/TTinChung/TTinTKhaiThue/TKhaiThue"
    n = "/HSoKhaiThue/TTinChung/TTinTKhaiThue/NNT"
    X._dat(goc, "/HSoKhaiThue/TTinChung/TTinDVu/maDVu", "HTKK")
    X._dat(goc, "/HSoKhaiThue/TTinChung/TTinDVu/tenDVu", "HỖ TRỢ KÊ KHAI THUẾ")
    X._dat(goc, "/HSoKhaiThue/TTinChung/TTinDVu/pbanDVu", re.sub(r"[^\d.]", "", h.get("phien_ban") or "") or "5.7.6")
    X._dat(goc, "/HSoKhaiThue/TTinChung/TTinDVu/ttinNhaCCapDVu", X.TTIN_NHA_CCAP)
    for the in ("maTKhai", "tenTKhai", "moTaBMau", "pbanTKhaiXML"):
        X._dat(goc, t + "/" + the, km[the])
    a, b = tu_den(k)
    lap = _ngay_lap(dl)
    X._dien_ky(goc, {"kyKKhaiTuNgay": a.strftime("%d/%m/%Y"), "kyKKhaiDenNgay": b.strftime("%d/%m/%Y"),
                     "ngayLapTKhai": lap.strftime("%d/%m/%Y"), "loaiTKhai": "C", "soLan": 0})
    ma_cqt = hd.get("maCQTNoiNop") or str(dn.get("ma_cqt") or "")
    ten_cqt = hd.get("tenCQTNoiNop") or str(dn.get("ten_cqt") or "")
    if not ma_cqt:
        cb.append("XML 05/KK-TNCN: THIẾU mã cơ quan thuế nơi nộp (maCQTNoiNop) - chọn lại trên HTKK trước khi nộp.")
    X._dat(goc, t + "/maCQTNoiNop", ma_cqt)
    X._dat(goc, t + "/tenCQTNoiNop", ten_cqt)
    gh = X._tim_nut(goc, t + "/GiaHan")
    if gh is not None:
        for c in list(gh):
            c.text = ""
    X._dat(goc, t + "/nguoiKy", _nguoi_ky(dl))
    X._dat(goc, t + "/nganhNgheKD", hd.get("nganhNgheKD") or "")
    mst = X._mst_so(dn.get("mst") or hd.get("mst"))
    if not re.fullmatch(r"\d{10}(-\d{3})?|\d{12}", mst or ""):
        cb.append("Chưa lập XML 05/KK-TNCN: mã số thuế doanh nghiệp không hợp lệ (%s)." % mst)
        return None
    X._dat(goc, n + "/mst", mst)
    X._dat(goc, n + "/tenNNT", dn.get("ten") or hd.get("tenNNT") or "")
    for the, kh in (("dchiNNT", "dchiNNT"), ("phuongXa", "tenXaPhuongNNT"), ("tenXaNNT", "tenXaPhuongNNT"), ("maXaNNT", "maXaPhuongNNT"),
                    ("maTinhNNT", "maTinhNNT"), ("tenTinhNNT", "tenTinhNNT"), ("dthoaiNNT", "dthoaiNNT"), ("faxNNT", "faxNNT"),
                    ("emailNNT", "emailNNT")):
        X._dat(goc, n + "/" + the, hd.get(kh) or {"dchiNNT": dn.get("dia_chi"), "dthoaiNNT": dn.get("dien_thoai"),
                                                  "emailNNT": dn.get("email"), "faxNNT": dn.get("fax")}.get(the) or "")
    X._dat(goc, n + "/maHuyenNNT", "")
    X._dat(goc, n + "/tenHuyenNNT", "")
    ttk = X._tim_nut(goc, "/HSoKhaiThue/TTinChung/TTinTKhaiThue")
    dly = X._con(ttk, "DLyThue") if ttk is not None else None
    if dly is not None:
        ttk.remove(dly)
    ctn = X._tim_nut(goc, "/HSoKhaiThue/CTieuTKhaiChinh")
    if ctn is None:
        cb.append("Chưa lập XML 05/KK-TNCN: khung HTKK không có CTieuTKhaiChinh.")
        return None
    da, la = set(), []
    for duong_n, nut in X._duyet(ctn):
        if list(nut):
            continue
        m = X._RE_CT.match(X._ten(nut))
        if not m:
            if X._ten(nut) == "mst_cu":
                nut.text = mst
            elif re.match(r"^ct\d+_\w+$", X._ten(nut), re.I):      # GD328: o con moi cua khung HTKK (vd ct25_1 ban 2.9.3) - kieu so, de trong la sai XSD
                nut.text = "0"
                la.append(X._ten(nut))
            continue
        so = m.group(1).lower()
        if so in ct_ky:
            nut.text = str(int(ct_ky[so]))
            da.add(so)
        else:
            nut.text = "0"
            la.append(X._ten(nut))
    thieu = [c for c in ct_can if c not in da]
    if thieu:
        cb.append("Chưa lập XML 05/KK-TNCN: khung HTKK %s không có chỉ tiêu %s như mẫu %s - phần mềm cần cập nhật theo khuôn mới."
                  % (os.path.basename(km["khung"]), ", ".join("[%s]" % c for c in thieu), "TT89" if tt89 else "TT80"))
        return None
    if la:
        cb.append("XML 05/KK-TNCN: các ô %s của khung HTKK ghi 0 (phần mềm không theo dõi) - kiểm tra trên HTKK." % ", ".join(la))
    plc = X._tim_nut(goc, "/HSoKhaiThue/PLuc")
    if plc is not None:
        for c in list(plc):
            plc.remove(c)
        plc.text = None
    X.ghi_xml_htkk(goc, duong)
    try:
        loi = X.kiem_hop_le(duong, km.get("xsd"), km["khung"])[1]      # GD328: co lxml + XSD HTKK -> kiem day du (truoc chi kiem noi bo)
    except Exception as e:
        loi = ["không tự kiểm được: %s" % e]
    if loi:
        cb.append("XML 05/KK-TNCN tự kiểm: %s" % "; ".join(loi[:6]))
    return duong


# ------------------------------------------------------------------ lap
def lap(dl, ma="KK_TNCN", kieu="EX", thumuc="."):
    kieu = (kieu or "EX").upper()
    x = dl.get("x1l") or {}
    tu, den = _ngay(x.get("tu")), _ngay(x.get("den"))
    ds_ky = cac_ky(tu, den)
    if not ds_ky:
        return {"tep": [], "canh_bao": ["Kỳ lập 05/KK-TNCN không hợp lệ (%s - %s)." % (x.get("tu"), x.get("den"))]}
    tep, cb_all = [], []
    for k in ds_ky:
        kk = tong_hop_ky(dl, k)
        cb = kk["canh_bao"]
        if k[0] == "Q" and k[1] == 2026 and k[2] == 2:      # 28/11/2026 PIT13 / UAT-PIT08: quy 2/2026 la ky chuyen tiep
            cb.append("Quý 2/2026 là kỳ chuyển tiếp: tờ khai này cộng cả tháng 4, 5, 6. Nếu tháng 4/2026 đã khai theo tháng và được cơ quan "
                      "thuế chấp nhận thì quý 2 chỉ kê tháng 5 – 6: trừ phần tháng 4 trước khi nộp, không khai tháng 4 lần hai.")
        if kk["tt89"]:
            c89 = kk["ct89"]
            cb.insert(0, "05/KK-TNCN %s (mẫu Thông tư 89/2026/TT-BTC): %d người, [21] TNCT %s, [33] thu nhập tính thuế %s, [35] thuế phải "
                         "khấu trừ theo biểu %s, [43] thuế đã khấu trừ %s." % (ten_ky(k), c89["15"], _vn(c89["21"]), _vn(c89["33"]),
                                                                              _vn(c89["35"]), _vn(c89["43"])))
        else:
            cb.insert(0, "05/KK-TNCN %s: %d người, [22] TNCT %s, [30] thuế đã khấu trừ %s." % (
                ten_ky(k), kk["ct"]["16"], _vn(kk["ct"]["22"]), _vn(kk["ct"]["30"])))
        hau = ("Q%d_%d" % (k[2], k[1])) if k[0] == "Q" else ("T%02d_%d" % (k[2], k[1]))
        if "X" in kieu:
            p = lap_xml(dl, kk, os.path.join(thumuc, "05_KK_TNCN_%s.xml" % hau), cb)
            if p:
                tep.append(p)
        if "E" in kieu:
            p = os.path.join(thumuc, "05_KK_TNCN_%s.xlsx" % hau)
            lap_excel(dl, kk, p, list(cb))
            tep.append(p)
        cb_all.extend(cb)
    return {"tep": tep, "canh_bao": cb_all}
