# -*- coding: utf-8 -*-
"""TNCN chuc nang 4a (28/11/2026) - UY QUYEN QUYET TOAN THUE TNCN (mau 08/UQ-QTT-TNCN, Dieu 51 ND253/2026, TT89/2026; quy tac PIT15
bo AM-XII-PIT-2026.11.28-v1.1).

1. xet(p, d, nam): kiem dieu kien uy quyen cua MOT nguoi (dung chung cho qtt_tncn.tong_hop va man hinh Uy quyen cua XII):
   - HD lao dong tu du 03 thang (LoaiHD 1/2; LoaiHD 3 "duoi 12 thang" khong xac dinh duoc >= 3 thang va da ke 05-2 -> khong);
   - dang lam viec tai thoi diem quyet toan (danh dau nghi viec -> khong; dieu chuyen hop le: ke toan tu kiem);
   - thu nhap vang lai noi khac binh quan thang trong nam <= 15 trieu (nam >= 2026; nhanh cu nam <= 2025: 10 trieu) VA da khau tru 10%;
   - KHONG uy quyen neu co nhieu nguon luong dai han hoac co de nghi giam tru Dieu 49 (y te, giao duc) - ca nhan tu quyet toan.
   Ket qua: {"trang_thai": DAT | KHONG_DU | KHONG_UQ | THEO_THAM_SO_CU, "uq": bool, "ly_do": [...], "canh_bao": [...]}.
2. doc_uy_quyen(t): khoi "uy_quyen_nv" cua JSON (bang HDDT_TNCN_UyQuyen) -> {(manv, nam): d}.
3. Cong cu doc lap (XII FrmTncnUyQuyenCt goi): uq_tncn.py /json:"<vao.json>" /ra:"<thu muc>" /xong:"<tep dau hieu>" [/lap:KIEM,UQ08]
   vao.json = {"dn": {...}, "nam": 2026, "nguoi_ky": "...", "ds": [{nguoi + uy quyen}], "chon": [manv...]}
   -> ket_qua_uq.json (trang thai tung nguoi) + 08_UQ_QTT_TNCN_<nam>_<ma>.html (+ .pdf neu may co Chrome / Edge).
   Dau hieu: dong 1 "OK <thu muc>" hoac "LOI <ly do>".
MAU 08/UQ: noi dung theo mau TT80 (phu luc II) dieu chinh nguong 15 trieu cua ND253 - "DE XUAT, ke toan kiem tra" voi mau TT89 ban hanh
chinh thuc truoc khi cho nguoi lao dong ky. May KHONG tu ky, KHONG gui co quan thue. Khong ghi CCCD / MST vao nhat ky."""
import html
import io
import json
import os
import re
import sys
from datetime import datetime

THU_MUC = os.path.dirname(os.path.abspath(__file__))
if THU_MUC not in sys.path:
    sys.path.insert(0, THU_MUC)

TEP_LOG = os.path.join(THU_MUC, "nhat-ky-tncn-uq.txt")
NGUONG_MOI = 15000000          # ND253 Dieu 51 (ky tinh thue 2026 tro di)
NGUONG_CU = 10000000           # TT111 / TT92 (nhanh lich su, nam <= 2025)
GHI_CHU_MAU = ("Mẫu 08/UQ-QTT-TNCN do phần mềm lập theo nội dung đề xuất (TT80 + ngưỡng 15 triệu của NĐ253/2026) - kế toán kiểm tra "
               "với mẫu ban hành kèm Thông tư 89/2026/TT-BTC trước khi cho người lao động ký. Phần mềm không ký, không gửi cơ quan thuế.")


def ghi_log(s):
    try:
        with io.open(TEP_LOG, "a", encoding="utf-8") as f:
            f.write("%s %s\n" % (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), s))
    except Exception:
        pass


def _so(v):
    try:
        return float(v or 0)
    except (TypeError, ValueError):
        try:
            return float(str(v).replace(".", "").replace(",", "."))
        except (TypeError, ValueError):
            return 0.0


def _nguyen(v):
    try:
        return int(float(v or 0))
    except (TypeError, ValueError):
        return 0


def _vn(x):
    return "{:,.0f}".format(round(x or 0)).replace(",", ".")


def _ngay(s):
    for f in ("%d/%m/%Y", "%Y-%m-%d"):
        try:
            return datetime.strptime(str(s or "")[:10], f)
        except ValueError:
            pass
    return None


def nguong(nam):
    return NGUONG_MOI if (nam or 0) >= 2026 else NGUONG_CU


# ------------------------------------------------------------------ du lieu uy quyen theo nguoi
def dong_uq(r):
    """dong HDDT_TNCN_UyQuyen: [MaNV, Nam, UyQuyen (-1 theo tham so cu / 0 / 1), NgayKy dd/MM/yyyy, TNNoiKhacBQ, NoiKhacDaKT10,
    NhieuNguonDaiHan, GiamTruD49]."""
    r = list(r) + [None] * 8
    uq = r[2]
    return {"manv": _nguyen(r[0]), "nam": _nguyen(r[1]), "uy_quyen": -1 if uq is None or str(uq).strip() == "" else _nguyen(uq),
            "ngay_ky": str(r[3] or "").strip(), "tn_noi_khac_bq": _so(r[4]), "da_kt10": bool(_nguyen(r[5])),
            "nhieu_nguon": bool(_nguyen(r[6])), "d49": bool(_nguyen(r[7]))}


def doc_uy_quyen(t):
    kq = {}
    for r in (t or {}).get("uy_quyen_nv") or []:
        d = dong_uq(r)
        if d["manv"]:
            kq[(d["manv"], d["nam"])] = d
    return kq


def xet(p, d, nam):
    """p: {"loai_hd", "nghi", "ngay_nghi", "co_hs", "co_dinh_danh"}; d: dong_uq (None = chua khai). Tra trang thai uy quyen."""
    kq = {"trang_thai": "KHONG_UQ", "uq": False, "ly_do": [], "canh_bao": []}
    if d is None or d.get("uy_quyen", -1) < 0:
        kq["trang_thai"] = "THEO_THAM_SO_CU"
        return kq
    if d["uy_quyen"] == 0:
        return kq
    ly = kq["ly_do"]
    lhd = _nguyen(p.get("loai_hd"))
    if not p.get("co_hs", True):
        ly.append("không có hồ sơ nhân viên")
    if lhd not in (1, 2):
        ly.append("loại hợp đồng %s - chỉ HĐLĐ từ đủ 03 tháng mới được ủy quyền (HĐ dưới 12 tháng / thù lao kê 05-2)"
                  % ({3: "dưới 12 tháng"}.get(lhd, "chưa khai")))
    if _nguyen(p.get("nghi")):
        nn = _ngay(p.get("ngay_nghi"))
        ly.append("đã nghỉ việc%s - không còn làm việc tại thời điểm quyết toán (điều chuyển hợp lệ: kế toán kiểm và sửa tay)"
                  % (" ngày " + nn.strftime("%d/%m/%Y") if nn else ""))
    if d.get("nhieu_nguon"):
        ly.append("có thu nhập tiền lương dài hạn ở nhiều nơi - cá nhân tự quyết toán")
    if d.get("d49"):
        ly.append("có đề nghị giảm trừ chi y tế / giáo dục (Điều 49) - cá nhân tự quyết toán theo Điều 51")
    bq = d.get("tn_noi_khac_bq") or 0.0
    ng = nguong(nam)
    if bq > ng:
        ly.append("thu nhập vãng lai nơi khác bình quân %s/tháng > %s" % (_vn(bq), _vn(ng)))
    elif bq > 0 and not d.get("da_kt10"):
        ly.append("thu nhập vãng lai nơi khác %s/tháng chưa được khấu trừ 10%%" % _vn(bq))
    if not _ngay(d.get("ngay_ky")):
        ly.append("chưa có ngày ký giấy ủy quyền 08/UQ")
    if not p.get("co_dinh_danh", True):
        kq["canh_bao"].append("thiếu MST / số định danh 12 số ([08] bắt buộc khi tích [10])")
    if ly:
        kq["trang_thai"] = "KHONG_DU"
    else:
        kq["trang_thai"] = "DAT"
        kq["uq"] = True
    return kq


TEN_TRANG_THAI = {"DAT": "Đủ điều kiện ủy quyền", "KHONG_DU": "Chọn ủy quyền nhưng KHÔNG đủ điều kiện", "KHONG_UQ": "Không ủy quyền",
                  "THEO_THAM_SO_CU": "Chưa khai (theo tham số TNCN_UyQuyen cũ)"}


# ------------------------------------------------------------------ in 08/UQ (HTML -> PDF)
CSS = """body{font-family:'Times New Roman',serif;font-size:13pt;margin:18mm 20mm;color:#000;background:#fff}
.c{text-align:center}.b{font-weight:bold}.i{font-style:italic}.r{text-align:right}
h1{font-size:14pt;text-align:center;margin:14px 0 2px}table.k{width:100%;margin-top:28px}table.k td{width:50%;vertical-align:top;text-align:center}
.mau{float:right;font-size:11pt;text-align:center;border:1px solid #000;padding:3px 6px}.o{display:inline-block;border-bottom:1px dotted #000;min-width:160px}
.ghi{border:1px solid #c00;color:#c00;padding:6px;font-size:10.5pt;margin-bottom:10px}@media print{.ghi{display:none}}
p{margin:5px 0;text-align:justify}"""


def _h(s):
    return html.escape(str(s or ""))


def html_08uq(dn, p, d, nam, nguoi_ky=""):
    ng = nguong(nam)
    bq = d.get("tn_noi_khac_bq") or 0.0
    nk = _ngay(d.get("ngay_ky"))
    ngay = ("ngày %02d tháng %02d năm %d" % (nk.day, nk.month, nk.year)) if nk else "ngày ..... tháng ..... năm ......"
    dd = p.get("mst") or p.get("cccd") or ""
    s = ["<!doctype html><html lang='vi'><head><meta charset='utf-8'><title>08/UQ-QTT-TNCN %d - %s</title><style>%s</style></head><body>"
         % (nam, _h(p.get("ten")), CSS),
         "<div class='ghi'>%s</div>" % _h(GHI_CHU_MAU),
         "<div class='mau'>Mẫu số: 08/UQ-QTT-TNCN<br><span class='i'>(Ban hành kèm theo Thông tư số 89/2026/TT-BTC<br>- đề xuất, kế toán kiểm tra)</span></div>",
         "<p class='c b' style='clear:none'>CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM</p><p class='c b'>Độc lập - Tự do - Hạnh phúc</p>"
         "<p class='c'>---------------</p><div style='clear:both'></div>",
         "<h1>GIẤY ỦY QUYỀN QUYẾT TOÁN THUẾ THU NHẬP CÁ NHÂN</h1><p class='c b'>[01] Kỳ tính thuế: Năm %d</p>" % nam,
         "<p><b>Kính gửi:</b> %s</p>" % _h(dn.get("ten")),
         "<p class='b'>I. THÔNG TIN NGƯỜI ỦY QUYỀN</p>",
         "<p>[02] Họ và tên: <b>%s</b></p>" % _h(p.get("ten")),
         "<p>[03] Mã số thuế / Số định danh cá nhân: <span class='o'>%s</span></p>" % _h(dd),
         "<p>[04] Địa chỉ: <span class='o'>%s</span></p>" % _h(p.get("dia_chi")),
         "<p>[05] Điện thoại: <span class='o'>%s</span> &nbsp; [06] Email: <span class='o'>%s</span></p>" % (_h(p.get("dien_thoai")), _h(p.get("email"))),
         "<p class='b'>II. THÔNG TIN NGƯỜI ĐƯỢC ỦY QUYỀN (TỔ CHỨC TRẢ THU NHẬP)</p>",
         "<p>[07] Tên tổ chức: <b>%s</b></p>" % _h(dn.get("ten")),
         "<p>[08] Mã số thuế: <span class='o'>%s</span></p>" % _h(dn.get("mst")),
         "<p>[09] Địa chỉ: <span class='o'>%s</span></p>" % _h(dn.get("dia_chi")),
         "<p class='b'>III. NỘI DUNG ỦY QUYỀN</p>",
         "<p>Tôi ủy quyền cho %s quyết toán thay thuế thu nhập cá nhân đối với thu nhập từ tiền lương, tiền công kỳ tính thuế năm %d."
         % (_h(dn.get("ten")), nam),
         "<p>Tôi cam kết: tôi ký hợp đồng lao động từ 03 tháng trở lên và đang làm việc tại tổ chức tại thời điểm quyết toán; trong năm "
         "chỉ có thu nhập từ tiền lương, tiền công tại tổ chức này%s; không có đề nghị giảm trừ chi khám bệnh, chữa bệnh, giáo dục, "
         "đào tạo theo Điều 49 Nghị định 253/2026/NĐ-CP.</p>"
         % ((", ngoài ra có thu nhập vãng lai ở nơi khác bình quân tháng trong năm %s đồng (không quá %s đồng/tháng) và đã được "
             "khấu trừ thuế 10%%, tôi không có yêu cầu quyết toán đối với phần thu nhập này" % (_vn(bq), _vn(ng))) if bq > 0 else ""),
         "<p>Tôi xin chịu trách nhiệm trước pháp luật về những thông tin đã kê khai trên./.</p>",
         "<table class='k'><tr><td></td><td class='i'>..., %s</td></tr><tr><td class='b'>XÁC NHẬN CỦA TỔ CHỨC<br>TRẢ THU NHẬP</td>"
         "<td class='b'>NGƯỜI ỦY QUYỀN</td></tr><tr><td class='i'>(Ký, ghi rõ họ tên, đóng dấu)</td><td class='i'>(Ký, ghi rõ họ tên)</td></tr>"
         "<tr><td style='height:80px'></td><td></td></tr><tr><td class='b'>%s</td><td class='b'>%s</td></tr></table>"
         % (ngay, _h(nguoi_ky), _h(p.get("ten"))),
         "</body></html>"]
    return "\n".join(s)


# ------------------------------------------------------------------ HTML -> PDF (Chrome / Edge che do nen; khong co -> chi HTML)
def tim_trinh_duyet():
    ung = []
    for goc in (os.environ.get("ProgramFiles", r"C:\Program Files"), os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
                os.environ.get("LOCALAPPDATA", "")):
        if goc:
            ung += [os.path.join(goc, r"Google\Chrome\Application\chrome.exe"), os.path.join(goc, r"Microsoft\Edge\Application\msedge.exe")]
    for p in ung:
        if os.path.isfile(p):
            return p
    return None


def html_ra_pdf(duong_html, duong_pdf):
    """In tep HTML ra PDF bang trinh duyet che do nen (an, khong hien cua so). -> (True, None) | (False, ly do)."""
    import subprocess
    tdu = tim_trinh_duyet()
    if not tdu:
        return False, "máy chưa có Chrome / Edge - chỉ lập HTML (mở và in ra PDF)"
    url = "file:///" + os.path.abspath(duong_html).replace("\\", "/")
    tam = os.path.join(os.environ.get("TEMP", THU_MUC), "uq_tncn_trinh_duyet")
    for ts in (["--headless=new", "--no-pdf-header-footer"], ["--headless"]):
        try:
            if os.path.exists(duong_pdf):
                os.remove(duong_pdf)
            subprocess.run([tdu] + ts + ["--disable-gpu", "--no-first-run", "--disable-extensions", "--user-data-dir=" + tam,
                                         "--print-to-pdf=" + duong_pdf, url], timeout=90, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        except Exception as e:  # noqa
            ghi_log("PDF loi: %s" % e)
            continue
        if os.path.exists(duong_pdf) and os.path.getsize(duong_pdf) > 800:
            return True, None
    return False, "trình duyệt không in được PDF - dùng tệp HTML"


def ten_tep(s):
    s = re.sub(r"[^0-9A-Za-z_-]+", "_", str(s or "")).strip("_")
    return s or "NV"


# ------------------------------------------------------------------ cong cu doc lap
def _tach(s):
    ra, cur, trong = [], "", False
    for c in s:
        if c == '"':
            trong = not trong
        elif c.isspace() and not trong:
            if cur:
                ra.append(cur)
                cur = ""
        else:
            cur += c
    if cur:
        ra.append(cur)
    return ra


def doc_tham_so(argv):
    ds = []
    for a in argv:
        if a.lower().startswith("/thamso:"):
            try:
                with io.open(a[8:].strip('"'), "r", encoding="utf-8-sig") as f:
                    ds.extend(_tach(f.read()))
            except Exception as e:
                ghi_log("LOI doc tham so: %s" % e)
        else:
            ds.append(a)
    ts = {"json": "", "ra": "", "xong": "", "lap": "KIEM,UQ08", "khong_pdf": False, "giu": False}
    for a in ds:
        for k in ("json", "ra", "xong", "lap"):
            if a.lower().startswith("/" + k + ":"):
                ts[k] = a[len(k) + 2:].strip('"')
        if a.lower() == "/khong_pdf":
            ts["khong_pdf"] = True
        if a.lower() == "/giu":
            ts["giu"] = True
    return ts


def chay(vao, ra, lap="KIEM,UQ08", khong_pdf=False):
    with io.open(vao, "r", encoding="utf-8-sig") as f:
        dl = json.load(f)
    nam = _nguyen(dl.get("nam")) or datetime.now().year
    dn = dl.get("dn") or {}
    chon = {_nguyen(x) for x in dl.get("chon") or []}
    lap = {x.strip().upper() for x in (lap or "").split(",") if x.strip()}
    os.makedirs(ra, exist_ok=True)
    kq, tep, cb = [], [], []
    for p in dl.get("ds") or []:
        d = dong_uq([p.get("manv"), nam, p.get("uy_quyen"), p.get("ngay_ky"), p.get("tn_noi_khac_bq"), p.get("da_kt10"),
                     p.get("nhieu_nguon"), p.get("d49")])
        x = xet(p, d, nam)
        dong = {"manv": _nguyen(p.get("manv")), "ma": p.get("ma", ""), "ten": p.get("ten", ""), "trang_thai": x["trang_thai"],
                "ten_trang_thai": TEN_TRANG_THAI[x["trang_thai"]], "ly_do": x["ly_do"], "canh_bao": x["canh_bao"], "tep": []}
        if "UQ08" in lap and d["uy_quyen"] == 1 and (not chon or dong["manv"] in chon):
            if x["trang_thai"] != "DAT":
                cb.append("%s: không lập 08/UQ vì %s." % (dong["ten"], "; ".join(x["ly_do"])))
            else:
                goc = os.path.join(ra, "08_UQ_QTT_TNCN_%d_%s" % (nam, ten_tep(p.get("ma") or p.get("manv"))))
                with io.open(goc + ".html", "w", encoding="utf-8") as f:
                    f.write(html_08uq(dn, p, d, nam, dl.get("nguoi_ky", "")))
                dong["tep"].append(goc + ".html")
                if not khong_pdf:
                    ok, ly = html_ra_pdf(goc + ".html", goc + ".pdf")
                    if ok:
                        dong["tep"].append(goc + ".pdf")
                    elif ly and ly not in cb:
                        cb.append(ly)
                tep.extend(dong["tep"])
        kq.append(dong)
    dem = {}
    for r in kq:
        dem[r["trang_thai"]] = dem.get(r["trang_thai"], 0) + 1
    ket = {"nam": nam, "nguong": nguong(nam), "ds": kq, "dem": dem, "tep": tep, "canh_bao": cb + [GHI_CHU_MAU]}
    with io.open(os.path.join(ra, "ket_qua_uq.json"), "w", encoding="utf-8") as f:
        json.dump(ket, f, ensure_ascii=False, indent=1)
    ghi_log("UQ nam %d: %d nguoi, %s, %d tep" % (nam, len(kq), json.dumps(dem), len(tep)))
    return ket


def main(argv):
    ts = doc_tham_so(argv)
    xong = ts["xong"] or os.path.join(ts["ra"] or THU_MUC, "DA_XONG_UQ")
    try:
        if not ts["json"] or not os.path.isfile(ts["json"]):
            raise RuntimeError("thiếu /json")
        ra = ts["ra"] or os.path.dirname(ts["json"])
        chay(ts["json"], ra, ts["lap"], ts["khong_pdf"])
        dau = "OK " + ra
    except Exception as e:  # noqa
        ghi_log("LOI %s" % e)
        dau = "LOI " + str(e)
    finally:
        try:
            if ts["json"] and os.path.isfile(ts["json"]) and not ts["giu"]:
                os.remove(ts["json"])          # JSON tam co MST / CCCD -> xoa ngay
        except Exception:
            pass
    with io.open(xong, "w", encoding="utf-8") as f:
        f.write(dau + "\n")
    return 0 if dau.startswith("OK") else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
