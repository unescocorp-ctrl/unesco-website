# -*- coding: utf-8 -*-
"""GD78 - TO KHAI QUYET TOAN THUE TNCN 05/QTT-TNCN (TT80/2021) + BANG KE 05-1/BK-QTT (05-2, 05-3 khi co so lieu) cho "Xuat 1 lan".
Hop dong xuat_1_lan.py: lap(dl, "TNCN", kieu, thumuc) -> {"tep": [...], "canh_bao": [...]}. CHI DOC SO, khong ghi CSDL.

Nguon so lieu (VB ModHDDTTNCN.HDDT_TNCN_JsonThem -> dl["tncn"]): "ca hai, uu tien phan mem"
  - BangLuong + QuanLyNhanVien cua phan mem (cot phan mem dung de tinh thue - FrmTNCN / FrmMNBaocao.BK05A: tongthunhap,
    BHXH/BHYT/BHTN, sothang (so NPT trong thang), phuthuoc, thuephainop (thue da khau tru thang), Thuephainop1 (thue nam phan
    mem tinh), TuThien, LuongKCN, GiaCanh);
  - thang / nam khong co BangLuong: bang luong da nhap tu Excel (HDDT_BL_Ky + HDDT_BL_Dong). Ma ky HDDT_BL_Ky.Thang: 1..12 thang,
    0 ca nam, tu*100+den nhieu thang (106 = thang 1 - 6). KHONG cong trung: moi thang chi lay tu MOT bang - thang co BangLuong
    lay BangLuong; con lai: bang thang -> bang nhieu thang (khong trung) -> bang CA NAM chi khi chua co thang nao cua phan mem
    va cac bang le chua du 12 thang (khi do bo bang le). Bang bi bo ghi ro trong canh bao (tong, so da dung cung ky, khop / lech).
    Tham so HDDT_ThamSo "TNCN_NguonUuTien" = EXCEL dao thu tu uu tien (Excel truoc, BangLuong lap thang con thieu).
  - Dong Excel chua ghep ma NV: ghep theo ho ten trung DUY NHAT trong danh muc; nhieu dong cung nguoi trong mot ky (nguoi chuyen
    bo phan) duoc gop. NPT cho ky lay tu Excel tinh theo GiaCanh cua phan mem.
  BangLuong khong co cot nam: mac dinh la nam tai chinh cua so; neu tong thu nhap khop DUNG phat sinh Co TK 334 nam truoc
  (HeThongTK.PSCLK<nam-1>) ma khong khop nam nay -> bang luong cua nam truoc (so moi chuyen sang) -> quyet toan nam truoc.

Tham so theo NAM quyet toan: 2020-2025 giam tru ban than 11 tr / NPT 4,4 tr / thang, bieu 7 bac (5..35%, nguong 5/10/18/32/52/80 tr);
tu 2026 (Luat Thue TNCN 109/2025/QH15 + NQ 110/2025/UBTVQH15): 15,5 tr / 6,2 tr, bieu 5 bac 5/10/20/30/35% nguong 10/30/60/100 tr;
truoc 2020: 9 tr / 3,6 tr. Thue nam = bieu thang x 12 (nhu HTKK: [24] = ROUND(bieu thang([21]/12) x 12)).
Lam tron dong nhu HTKK (nua tro len ra xa so 0), tong = cong cac dong da lam tron.

Tep lap (thu muc MOI cua lan xuat):
  05_QTT_TNCN_TT80_<nam>.xml      XML HTKK (maTKhai 953, pban 2.9.3, dung XSD Validate/05_QTT_TNCN_TT80_293.xsd)
  05_QTT_TNCN_<nam>.xlsx          to khai 05 + phu luc 05-1 (05-2, 05-3) bo cuc HTKK + chi tiet thang + doi chieu
  Bang_Ke_05_1_QTT_TT80_<nam>.xlsx  bang ke dung mau "Tai bang ke" cua HTKK (sheet 05-1BK-QTT-TNCN, du lieu tu dong 6)
Khong in / ghi so CCCD / MST vao nhat ky hay canh bao (chi co trong tep to khai)."""
import io
import os
import re
import unicodedata
import xml.etree.ElementTree as ET
import zipfile
from datetime import datetime, date
from decimal import Decimal, ROUND_HALF_UP

NS = "http://kekhaithue.gdt.gov.vn/TKhaiThue"
NS_XSI = "http://www.w3.org/2001/XMLSchema-instance"
MA_TKHAI = "953"
PBAN_XML = "2.9.3"
TEN_TKHAI = "TỜ KHAI QUYẾT TOÁN THUẾ THU NHẬP CÁ NHÂN (Mẫu số 05/QTT-TNCN)"
MO_TA_BMAU = "(Ban hành kèm theo Thông tư số 80/2021/TT-BTC ngày 29 tháng 9 năm 2021 của Bộ trưởng Bộ Tài chính)"
TTIN_NHA_CCAP_MD = "686EA069E39ECDEAFF7B44D25713EA55"
MIEN_50K = 50000
SO_THANG_KY = 12

# thu tu the dung XSD / khung HTKK
CT_KHAU_TRU = ["16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34"]
CT_QT_THAY = ["35", "36", "37", "38", "39", "40", "41"]
CT_BK1 = ["12", "13", "14", "15", "15.1", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26"]
CT_BK1_TONG = [("28", "12"), ("29", "13"), ("30", "14"), ("31", "15"), ("31.1", "15.1"), ("32", "16"), ("33", "17"), ("34", "18"),
               ("35", "19"), ("36", "20"), ("37", "21"), ("38", "22"), ("39", "23"), ("40", "24"), ("41", "25"), ("42", "26")]
CT_BK2 = ["11", "12", "13", "14", "14.1", "15", "16"]
CT_BK2_TONG = [("17", "11"), ("18", "12"), ("19", "13"), ("20", "14"), ("20.1", "14.1"), ("21", "15"), ("22", "16")]
GIAY_TO = {"03": "Thẻ CCCD/Số định danh cá nhân", "02": "Hộ chiếu", "01": "CMND"}
RE_TIN = re.compile(r"\d{10}(-\d{3})?|\d{12}")


# ------------------------------------------------------------------ tien ich so
def lam_tron(x):
    """lam tron dong nhu HTKK: nua tro len ra xa so 0."""
    try:
        d = Decimal(repr(float(x or 0)))
    except (TypeError, ValueError):
        return 0
    return int(d.quantize(Decimal("1"), rounding=ROUND_HALF_UP))


def _so(v):
    try:
        return float(v or 0)
    except (TypeError, ValueError):
        return 0.0


def _nguyen(v):
    try:
        return int(float(v or 0))
    except (TypeError, ValueError):
        return 0


def tham_so_nam(nam):
    """giam tru gia canh + bieu thue luy tien tung phan (nguong THANG, thue suat %) theo nam quyet toan."""
    bay_bac = [(5000000, 5), (10000000, 10), (18000000, 15), (32000000, 20), (52000000, 25), (80000000, 30), (None, 35)]
    if nam >= 2026:
        return {"nam": nam, "gt_ban_than": 15500000, "gt_npt": 6200000,
                "bac": [(10000000, 5), (30000000, 10), (60000000, 20), (100000000, 30), (None, 35)],
                "can_cu": "Luật Thuế TNCN số 109/2025/QH15 và Nghị quyết 110/2025/UBTVQH15 (áp dụng từ kỳ tính thuế 2026): "
                          "giảm trừ bản thân 15,5 triệu, người phụ thuộc 6,2 triệu đồng/tháng; biểu lũy tiến 5 bậc 5-10-20-30-35%"}
    if nam >= 2020:
        return {"nam": nam, "gt_ban_than": 11000000, "gt_npt": 4400000, "bac": bay_bac,
                "can_cu": "Nghị quyết 954/2020/UBTVQH14: giảm trừ bản thân 11 triệu, người phụ thuộc 4,4 triệu đồng/tháng; "
                          "biểu lũy tiến 7 bậc 5-35% (Luật Thuế TNCN)"}
    return {"nam": nam, "gt_ban_than": 9000000, "gt_npt": 3600000, "bac": bay_bac,
            "can_cu": "Luật 26/2012/QH13: giảm trừ bản thân 9 triệu, người phụ thuộc 3,6 triệu đồng/tháng; biểu lũy tiến 7 bậc"}


def thue_luy_tien(tntt, nam, so_thang=SO_THANG_KY):
    """thue theo bieu luy tien tung phan cua nam `nam`; nguong thang x so_thang (so_thang=1: bieu thang, 12: quyet toan nam).
    Tinh bang so nguyen (dong x 1/100) roi lam tron dong - khong sai so dau phay dong."""
    tntt = lam_tron(tntt)
    if tntt <= 0:
        return 0
    tong, duoi = 0, 0
    for nguong, ts in tham_so_nam(nam)["bac"]:
        tren = None if nguong is None else nguong * so_thang
        if tren is None or tntt <= tren:
            tong += (tntt - duoi) * ts
            break
        tong += (tren - duoi) * ts
        duoi = tren
    return (tong + 50) // 100


def nam_bieu_thang(nam, thang, ts=None):
    """GD121: nam lay BIEU thue khi kiem thue khau tru THANG: bieu 5 bac ap dung tu thang 1/2026 (Cuc Thue); don vi da khau tru
    thang 1..N/2026 theo bieu 7 bac cu (HDDT_ThamSo TNCN_Bieu7BacDenThang = N, JSON tham_so.bieu7_den) -> cac thang do dung bieu
    7 bac (giam tru van theo nam 2026). Quyet toan nam khong doi."""
    try:
        den = int(float((ts or {}).get("bieu7_den") or 0))
    except (TypeError, ValueError):
        den = 0
    return 2025 if nam == 2026 and 1 <= int(thang or 0) <= den else nam


# ------------------------------------------------------------------ chuoi / dinh danh
def _bo_dau(s):
    s = unicodedata.normalize("NFD", str(s or "")).replace("đ", "d").replace("Đ", "D")
    return "".join(c for c in s if unicodedata.category(c) != "Mn")


def khoa_ten(s):
    return re.sub(r"[^a-z0-9]", "", _bo_dau(s).lower())


_VNI_DAU = {"\u00f8": "\u0300", "\u00f9": "\u0301", "\u00fb": "\u0309", "\u00f5": "\u0303", "\u00ef": "\u0323"}
_VNI_CU_MU = {"\u00e0": "\u0300", "\u00e1": "\u0301", "\u00e5": "\u0309", "\u00e3": "\u0303", "\u00e4": "\u0323"}
_VNI_CU_TRANG = {"\u00e8": "\u0300", "\u00e9": "\u0301", "\u00fa": "\u0309", "\u00fc": "\u0303", "\u00eb": "\u0323"}
_RE_HOA_VNI = re.compile("([AEIOUY\u00c2\u0102\u00ca\u00d4\u01a0\u01af])(?:([\u00e2\u00ea])([\u00f8\u00f9\u00fb\u00f5\u00ef])?"
                         "|([\u00e0\u00e1\u00e5\u00e3\u00e4])|([\u00e8\u00e9\u00fa\u00fc\u00eb])|([\u00f8\u00f9\u00fb\u00f5\u00ef]))")


def _sua_hoa_vni(m):
    """chu HOA + dau VNI chu thuong ma VNItoUNICODE (VB) bo sot: 'Aân' -> 'Ân', 'Uùt' -> 'Út', 'Aáp' -> 'Ấp', 'Aëng' -> 'Ặng'."""
    b, mu, dau_mu, cu_mu, cu_tr, dau = m.groups()
    if mu:
        if mu == "\u00e2" and b in "AEO":
            x = b + "\u0302"
        elif mu == "\u00ea" and b == "A":
            x = b + "\u0306"
        else:
            return m.group(0)
        return unicodedata.normalize("NFC", x + (_VNI_DAU[dau_mu] if dau_mu else ""))
    if cu_mu:
        return unicodedata.normalize("NFC", b + "\u0302" + _VNI_CU_MU[cu_mu]) if b in "AEO" else m.group(0)
    if cu_tr:
        return unicodedata.normalize("NFC", b + "\u0306" + _VNI_CU_TRANG[cu_tr]) if b == "A" else m.group(0)
    return unicodedata.normalize("NFC", b + _VNI_DAU[dau])


def _ten_sach(s):
    """chuan hoa ten: NFC, gop khoang trang; sua loi doi VNI cua phan mem voi chu HOA dung dau (VNItoUNICODE chi ghep dau chu
    thuong voi nguyen am thuong: 'Danh Aân' -> 'Danh Ân', 'Nguyễn Thị Uùt' -> 'Nguyễn Thị Út')."""
    s = unicodedata.normalize("NFC", str(s or ""))
    s = _RE_HOA_VNI.sub(_sua_hoa_vni, s)
    return re.sub(r"\s+", " ", s).strip()


def la_viet_nam(qt):
    k = khoa_ten(qt)
    return (not k) or k.isdigit() and k in ("0", "1") or "vietnam" in k


def dinh_danh(mst, cccd, quoc_tich, nam):
    """-> dict(ct08 (MST theo TINType hoac ""), ct09 (so giay to), ma (ct09a_ma), ten_gt (ct09a_ten), nn (nguoi nuoc ngoai /
    nguoi VN o nuoc ngoai khong co ma dinh danh), thieu (khong co ca MST lan giay to)).
    Tu 01/07/2025 so dinh danh ca nhan (CCCD 12 so) dung thay MST: nam >= 2025 -> [08] = CCCD (nhu to khai 2025 da nop)."""
    mst = re.sub(r"[^0-9-]", "", str(mst or "")).strip("-")
    if not RE_TIN.fullmatch(mst or ""):
        mst = ""
    g = re.sub(r"[^0-9A-Za-z]", "", str(cccd or "")).upper()
    if g in ("0", "00") or set(g) == {"0"}:
        g = ""
    vn = la_viet_nam(quoc_tich)
    ma, ten_gt, nn = "", "", False
    if g.isdigit() and len(g) == 12:
        ma = "03"
    elif g.isdigit() and len(g) == 9:
        ma = "01"
    elif g and not vn:
        ma, nn = "02", True
    elif g:
        ma = "03"
    if ma:
        ten_gt = GIAY_TO[ma]
    if nam >= 2025 and ma == "03" and len(g) == 12 and g.isdigit():
        ct08 = g
    else:
        ct08 = mst
    return {"ct08": ct08, "ct09": g, "ma": ma, "ten_gt": ten_gt, "nn": nn, "thieu": not ct08 and not g, "vn": vn}


def _thang_chuoi(s, nam, cuoi):
    """'03/2025' | '03/25' | '3' -> thang tinh trong nam `nam`. cuoi=False (tu thang): nam truoc -> 1, nam sau -> 13 (chua bat dau);
    cuoi=True (den thang): nam sau -> 12, nam truoc -> 0 (da het). Khong doc duoc -> None (tu = 1 / den = 12 nhu phan mem chi so thang)."""
    m = re.match(r"\s*(\d{1,2})(?:\D+(\d{2,4}))?", str(s or ""))
    if not m:
        return None
    th = int(m.group(1))
    if not 1 <= th <= 12:
        return None
    if m.group(2):
        y = int(m.group(2))
        if y < 100:
            y += 2000
        if y < nam:
            return 0 if cuoi else 1
        if y > nam:
            return 12 if cuoi else 13
    return th


# ------------------------------------------------------------------ ky bang luong nhap Excel (HDDT_BL_Ky.Thang)
def ky_thang(ma):
    """ma ky HDDT_BL_Ky.Thang -> (tu thang, den thang): 1..12 mot thang; 0 ca nam; tu*100+den nhieu thang (106 = thang 1 - 6).
    Ma khong hop le -> None."""
    ma = _nguyen(ma)
    if 1 <= ma <= 12:
        return (ma, ma)
    if ma == 0:
        return (1, 12)
    a, b = divmod(ma, 100)
    if ma > 100 and 1 <= a <= b <= 12:
        return (a, b)
    return None


def thang_cua_ky(ma):
    t = ky_thang(ma)
    return set(range(t[0], t[1] + 1)) if t else set()


def ten_ky(ma, nam=None):
    """'tháng 03/2025' | 'cả năm 2025' | 'tháng 1-6/2025' (nam None -> khong ghi nam)."""
    t = ky_thang(ma)
    n = "" if nam is None else "/%d" % nam
    if t is None:
        return "kỳ %s" % ma
    if ma == 0:
        return "cả năm" + ("" if nam is None else " %d" % nam)
    if t[0] == t[1]:
        return "tháng %02d%s" % (t[0], n)
    return "tháng %d-%d%s" % (t[0], t[1], n)


def _ds_thang(ms):
    """[1,2,3,5,7,8,9] -> '1-3, 5, 7-9'."""
    ms = sorted(set(ms))
    ra, i = [], 0
    while i < len(ms):
        j = i
        while j + 1 < len(ms) and ms[j + 1] == ms[j] + 1:
            j += 1
        ra.append(str(ms[i]) if i == j else "%d-%d" % (ms[i], ms[j]))
        i = j + 1
    return ", ".join(ra)


LY_DO_BO = {"PM": "trùng tháng đã có bảng lương phần mềm (ưu tiên phần mềm)",
            "EX": "trùng tháng đã lấy từ bảng lương Excel (ưu tiên Excel theo tham số TNCN_NguonUuTien)",
            "TRUNG": "trùng tháng với bảng lương Excel khác đã lấy",
            "DU_THANG": "các bảng lương tháng / nhiều tháng đã đủ 12 tháng",
            "CA_NAM": "đã lấy bảng lương CẢ NĂM (đủ 12 tháng) thay cho bảng lẻ chưa đủ năm"}


def chon_ky_excel(ky, da_co):
    """Chon cac ky bang luong Excel cua MOT nam, KHONG cong trung thang. ky: {ma: ...}; da_co: tap thang da co nguon
    uu tien hon (BangLuong). Thu tu: bang thang -> bang nhieu thang (rong truoc) -> bang ca nam. Bang ca nam chi dung khi
    chua co thang nao tu phan mem va cac bang le chua du 12 thang (khi do bo cac bang le).
    -> (chon: [ma], bo: [(ma, ly_do)])."""
    chon, bo, phu = [], [], set(da_co)
    for ma in sorted(m for m in ky if 1 <= m <= 12):
        if ma in da_co:
            bo.append((ma, "PM"))
        else:
            chon.append(ma)
            phu.add(ma)
    for ma in sorted((m for m in ky if m > 100), key=lambda m: (-(m % 100 - m // 100), m)):
        ms = thang_cua_ky(ma)
        if ms & set(da_co):
            bo.append((ma, "PM"))
        elif ms & phu:
            bo.append((ma, "TRUNG"))
        else:
            chon.append(ma)
            phu |= ms
    if 0 in ky:
        if da_co:
            bo.append((0, "PM"))
        elif len(phu) == 12:
            bo.append((0, "DU_THANG"))
        else:
            bo.extend((m, "CA_NAM") for m in chon)
            chon = [0]
    return chon, bo


# ------------------------------------------------------------------ doc JSON
def _nv(r):
    r = list(r) + [""] * 12
    return {"manv": _nguyen(r[0]), "ma": str(r[1] or "").strip(), "ten": _ten_sach(r[2]), "mst": str(r[3] or ""),
            "cccd": str(r[4] or ""), "loai_hd": _nguyen(r[5]), "quoc_tich": str(r[6] or ""), "nghi": _nguyen(r[7]),
            "ngay_nghi": str(r[8] or ""), "ngay_sinh": str(r[9] or ""), "phan_loai": _nguyen(r[10])}


def _dong_pm(r):
    r = list(r) + [0] * 16
    return {"manv": _nguyen(r[0]), "thang": _nguyen(r[1]), "tn": _so(r[2]), "luong_chinh": _so(r[3]), "tn_khac": _so(r[4]),
            "bh": _so(r[5]) + _so(r[6]) + _so(r[7]), "phuthuoc": _nguyen(r[8]), "sothang": _nguyen(r[9]), "thue": _so(r[10]),
            "thue_nam": _so(r[11]), "tinh_giam": _so(r[12]), "gt_bt_dong": _so(r[13]), "gt_npt_dong": _so(r[14]), "loainv": _nguyen(r[15])}


def _dong_ex(r):
    """dong HDDT_BL_Dong: [MaNV, MaNVTrenBang, TenTrenBang, Thang (ma ky), Nam, TongThuNhap, BHXH_NV, BHYT_NV, BHTN_NV, ThueTNCN,
    MaKy, LuongChinh, ThuNhapKhac, NgayCong, PhuCap] (5 cot cuoi: GD78, JSON cu khong co -> 0)."""
    r = list(r) + [0] * 15
    return {"manv": _nguyen(r[0]), "ma_bang": str(r[1] or "").strip(), "ten": _ten_sach(r[2]), "thang": _nguyen(r[3]), "nam": _nguyen(r[4]),
            "tn": _so(r[5]), "bh": _so(r[6]) + _so(r[7]) + _so(r[8]), "thue": _so(r[9]), "ma_ky": _nguyen(r[10]),
            "luong_chinh": _so(r[11]), "tn_khac": _so(r[12]), "ngay_cong": _so(r[13]), "phu_cap": _so(r[14])}


def _ngay(s):
    for f in ("%d/%m/%Y", "%Y-%m-%d"):
        try:
            return datetime.strptime(str(s or "")[:10], f)
        except ValueError:
            pass
    return None


def _ps_co(dl, dau_tk, thang=None):
    """tong phat sinh Co (ca ket chuyen) ca nam tai chinh (thang=None) hoac mot thang duong lich cua cac TK bat dau bang
    dau_tk (dl["ps"] + dl["tk"]). Khong co danh muc TK -> None."""
    sh = {}
    for r in dl.get("tk") or []:
        try:
            sh[int(r[0])] = str(r[1] or "").strip()
        except (TypeError, ValueError, IndexError):
            continue
    if not sh:
        return None
    t = 0.0
    for r in dl.get("ps") or []:
        try:
            s = sh.get(int(r[0]), "")
            if thang is not None and int(r[1]) != thang:
                continue
        except (TypeError, ValueError, IndexError):
            continue
        if s.startswith(dau_tk):
            t += _so(r[3]) + (_so(r[5]) if len(r) > 5 else 0.0)
    return t


# ------------------------------------------------------------------ tong hop so lieu
def tong_hop(dl):
    """-> kq: nam, nguon (da chon, ghi ro), tham so, danh sach nguoi (05-1 / 05-2), NPT, chi tieu to khai, canh bao."""
    t = dl.get("tncn")
    if not isinstance(t, dict):
        raise RuntimeError("JSON không có phần \"tncn\" (bản phần mềm chưa có GĐ78 ModHDDTTNCN?)")
    if t.get("loi"):
        raise RuntimeError("Phần mềm không lấy được số liệu TNCN: %s" % t["loi"])
    cb = []
    if t.get("loi_doc"):
        cb.append("Đọc số liệu TNCN lỗi một phần (%s) - kiểm tra bảng lương / hồ sơ nhân viên." % t["loi_doc"])
    x = dl.get("x1l") or {}
    nam_tc = _nguyen(t.get("nam_tc") or x.get("nam_tc") or dl.get("nam_tc") or t.get("nam")) or datetime.now().year
    ts = t.get("tham_so") or {}
    uu_tien_ex = str(ts.get("nguon_uu_tien") or "PM").strip().upper() == "EXCEL"
    nvs = {}
    for r in t.get("nv") or []:
        v = _nv(r)
        if v["manv"]:
            nvs[v["manv"]] = v
    ten_nv = {}
    for v in nvs.values():
        k = khoa_ten(v["ten"])
        if k:
            ten_nv[k] = v["manv"] if k not in ten_nv else 0          # 0 = trung ten trong danh muc -> khong ghep theo ten
    pm = [d for d in (_dong_pm(r) for r in t.get("thang") or []) if 1 <= d["thang"] <= 12]
    ex_tat = [_dong_ex(r) for r in t.get("excel") or []]
    ex = [d for d in ex_tat if ky_thang(d["thang"]) is not None and d["nam"] > 0]
    if len(ex) < len(ex_tat):
        cb.append("Bỏ %d dòng bảng lương Excel có mã kỳ không hợp lệ." % (len(ex_tat) - len(ex)))
    tep_ky = {}
    for r in t.get("ky_excel") or []:
        r = list(r) + [""] * 6
        tep_ky[(_nguyen(r[1]), _nguyen(r[2]))] = str(r[3] or "").strip()

    # --- nam cua bang luong phan mem (BangLuong khong co cot nam)
    tong_pm = lam_tron(sum(d["tn"] for d in pm))
    ps_nay = _ps_co(dl, "334")
    nam_bl, doi_chieu_nam = nam_tc, ""
    if pm and _nguyen(ts.get("co_ps_truoc")):
        p_truoc = lam_tron(ts.get("ps334_truoc"))
        if tong_pm > 0 and tong_pm == p_truoc and (ps_nay is None or tong_pm != lam_tron(ps_nay)):
            nam_bl = nam_tc - 1
            doi_chieu_nam = ("Bảng lương trong phần mềm (BangLuong, %d tháng) có tổng thu nhập %s = đúng phát sinh Có TK 334 năm %d "
                             "(HeThongTK.PSCLK%d) và khác phát sinh Có TK 334 năm %d (%s) -> đây là bảng lương năm %d, lập quyết toán năm %d."
                             % (len({d["thang"] for d in pm}), _vn(tong_pm), nam_tc - 1, nam_tc - 1, nam_tc,
                                _vn(lam_tron(ps_nay or 0)), nam_tc - 1, nam_tc - 1))
    nam_ep = _nguyen(t.get("nam_qt"))
    nam_ex = sorted({d["nam"] for d in ex})
    if nam_ep:
        nam = nam_ep
    elif pm and not (uu_tien_ex and nam_bl not in nam_ex and nam_ex):
        nam = nam_bl
    elif nam_tc in nam_ex:
        nam = nam_tc
    elif (nam_tc - 1) in nam_ex:
        nam = nam_tc - 1
    else:
        nam = nam_tc
    if doi_chieu_nam and nam == nam_bl:
        cb.append(doi_chieu_nam)
    tsn = tham_so_nam(nam)
    co_pm = bool(pm) and nam_bl == nam
    if pm and not co_pm:
        cb.append("Bảng lương phần mềm là của năm %d, không dùng cho quyết toán năm %d." % (nam_bl, nam))

    # --- chon ky: moi thang chi lay tu MOT bang (khong cong trung bang thang / nhieu thang / ca nam)
    ky = {}
    for d in ex:
        if d["nam"] == nam:
            k = ky.setdefault(d["thang"], {"tn": 0.0, "so_dong": 0})
            k["tn"] += d["tn"]
            k["so_dong"] += 1
    th_pm_co = sorted({d["thang"] for d in pm}) if co_pm else []
    if uu_tien_ex:
        chon_ex, bo_ex = chon_ky_excel(ky, set())
        phu_ex = set().union(*[thang_cua_ky(m) for m in chon_ex]) if chon_ex else set()
        th_pm = [m for m in th_pm_co if m not in phu_ex]
        th_pm_bo = [m for m in th_pm_co if m in phu_ex]
    else:
        th_pm = th_pm_co
        th_pm_bo = []
        chon_ex, bo_ex = chon_ky_excel(ky, set(th_pm))
    th_ex = sorted(m for m in chon_ex if 1 <= m <= 12)
    tn_pm_thang = {}
    for d in pm:
        if d["thang"] in th_pm:
            tn_pm_thang[d["thang"]] = tn_pm_thang.get(d["thang"], 0.0) + d["tn"]

    def tong_da_chon(ms):
        """tong thu nhap da chon cho dung tap thang ms (None neu nguon da chon khong tach dung tap thang nay)."""
        tg, phu = 0.0, set()
        for m in th_pm:
            if m in ms:
                tg += tn_pm_thang.get(m, 0.0)
                phu.add(m)
        for m in chon_ex:
            mm = thang_cua_ky(m)
            if mm <= ms:
                tg += ky[m]["tn"]
                phu |= mm
        return tg if phu == ms else None

    # bang bi bo: gom cac bang THANG cung ly do vao mot cau; bang nhieu thang / ca nam moi bang mot cau
    nhom_bo = []
    for ly in ("PM", "TRUNG", "DU_THANG", "CA_NAM"):
        ms = [ma for ma, l_ in bo_ex if l_ == ly and 1 <= ma <= 12]
        if ms:
            nhom_bo.append((ms, ly))
    nhom_bo += [([ma], l_) for ma, l_ in bo_ex if not 1 <= ma <= 12]
    for ds_ma, ly in nhom_bo:
        ms = set()
        for ma in ds_ma:
            ms |= thang_cua_ky(ma)
        tn_bo = sum(ky[ma]["tn"] for ma in ds_ma)
        tep = sorted({tep_ky.get((ma, nam), "") for ma in ds_ma} - {""})
        ten = ten_ky(ds_ma[0], nam) if len(ds_ma) == 1 else "tháng %s/%d" % (_ds_thang(ds_ma), nam)
        so = tong_da_chon(ms)
        ss = ""
        if so is not None:
            ss = " Số đã dùng cho cùng kỳ: %s (%s)." % (_vn(lam_tron(so)), "khớp" if lam_tron(so) == lam_tron(tn_bo)
                                                              else "lệch %s" % _vn(lam_tron(so) - lam_tron(tn_bo)))
        cb.append("KHÔNG cộng bảng lương Excel %s%s (%d dòng, tổng thu nhập %s): %s.%s"
                  % (ten, " - tệp %s" % ", ".join(tep) if tep else "", sum(ky[ma]["so_dong"] for ma in ds_ma), _vn(lam_tron(tn_bo)),
                     LY_DO_BO[ly], ss))
    if th_pm_bo:
        cb.append("Tham số TNCN_NguonUuTien = EXCEL: bỏ bảng lương phần mềm tháng %s (đã có bảng lương Excel cùng tháng)." % _ds_thang(th_pm_bo))
    phan = []
    if th_pm:
        phan.append("bảng lương phần mềm (BangLuong) tháng %s" % _ds_thang(th_pm))
    if th_ex:
        tep = sorted({tep_ky.get((ma, nam), "") for ma in th_ex} - {""})
        phan.append("bảng lương nhập Excel tháng %s/%d%s" % (_ds_thang(th_ex), nam, " (tệp %s)" % ", ".join(tep) if tep else ""))
    for ma in sorted((m for m in chon_ex if not 1 <= m <= 12), key=lambda m: ky_thang(m)[0]):
        tep = tep_ky.get((ma, nam), "")
        phan.append("bảng lương nhập Excel %s%s" % (ten_ky(ma, nam), " (tệp %s)" % tep if tep else ""))
    nguon = "+".join((["PM"] if th_pm else []) + (["EXCEL"] if chon_ex else []))
    nguon_mo_ta = "; ".join(phan)
    if phan:
        cb.append("Nguồn số liệu 05/QTT-TNCN năm %d: %s%s." % (nam, nguon_mo_ta, "" if (th_pm or not pm) else " (không dùng BangLuong)"))

    # --- gom theo nguoi
    ng = {}
    thu_tu = []
    ghep_ten, gop_dong = [], []

    def nguoi(khoa, v, ten):
        if khoa not in ng:
            ng[khoa] = {"khoa": khoa, "manv": v["manv"] if v else 0, "ma": v["ma"] if v else "", "ten": (v["ten"] if v else "") or ten,
                        "mst": v["mst"] if v else "", "cccd": v["cccd"] if v else "", "loai_hd": v["loai_hd"] if v else 0,
                        "quoc_tich": v["quoc_tich"] if v else "", "co_hs": bool(v), "nghi": v["nghi"] if v else 0,
                        "ngay_nghi": v["ngay_nghi"] if v else "", "thang": {}, "tp1": 0.0, "phuthuoc": 0, "nguon": set(), "tinh_giam": 0.0}
            thu_tu.append(khoa)
        return ng[khoa]

    def them_thang(p, ma, tn, bh, thue, sothang, nguon_d):
        m = p["thang"].setdefault(ma, {"tn": 0.0, "bh": 0.0, "thue": 0.0, "sothang": 0, "tu_thien": 0.0, "nop": 0.0, "kcn": 0.0,
                                         "nguon": nguon_d, "so_dong": 0})
        m["tn"] += tn
        m["bh"] += bh
        m["thue"] += thue
        m["sothang"] = max(m["sothang"], sothang)
        m["so_dong"] += 1
        p["nguon"].add(nguon_d)

    for d in pm:
        if d["thang"] not in th_pm:
            continue
        v = nvs.get(d["manv"])
        p = nguoi("NV:%d" % d["manv"], v, "")
        if not v and not p["ten"]:
            p["ten"] = "Nhân viên mã số %d (không có trong danh mục)" % d["manv"]
        them_thang(p, d["thang"], d["tn"], d["bh"], d["thue"], d["sothang"], "PM")
        p["tp1"] = max(p["tp1"], d["thue_nam"])
        p["phuthuoc"] = max(p["phuthuoc"], d["phuthuoc"])
        p["tinh_giam"] += d["tinh_giam"]
    for d in ex:
        if d["nam"] != nam or d["thang"] not in chon_ex:
            continue
        v = nvs.get(d["manv"]) if d["manv"] else None
        if v is None and ten_nv.get(khoa_ten(d["ten"])):
            v = nvs[ten_nv[khoa_ten(d["ten"])]]
            ghep_ten.append(d["ten"])
        khoa = ("NV:%d" % v["manv"]) if v else ("TEN:" + (khoa_ten(d["ten"]) or d["ma_bang"]))
        p = nguoi(khoa, v, d["ten"])
        if d["thang"] in p["thang"]:
            gop_dong.append(p["ten"])
        them_thang(p, d["thang"], d["tn"], d["bh"], d["thue"], 0, "EXCEL")
    # thu tu: nhan vien trong danh muc theo ma so (nhu tep da nop), roi dong Excel chua ghep theo thu tu tren bang
    vi_tri = {k: i for i, k in enumerate(thu_tu)}
    thu_tu.sort(key=lambda k: (0, ng[k]["manv"]) if ng[k]["co_hs"] else (1, vi_tri[k]))

    # tu thien / luong KCN: bang cua phan mem gan voi thang BangLuong (khong co nam) -> chi ap cho thang lay tu BangLuong
    if th_pm:
        for r in t.get("tu_thien") or []:
            r = list(r) + [0] * 4
            p = ng.get("NV:%d" % _nguyen(r[0]))
            m = p["thang"].get(_nguyen(r[1])) if p and _nguyen(r[1]) in th_pm else None
            if m is not None:
                m["tu_thien"] += _so(r[2])
                m["nop"] += _so(r[3])
        for r in t.get("kcn") or []:
            r = list(r) + [0] * 3
            p = ng.get("NV:%d" % _nguyen(r[0]))
            m = p["thang"].get(_nguyen(r[1])) if p and _nguyen(r[1]) in th_pm else None
            if m is not None:
                m["kcn"] += _so(r[2])
    # nguoi phu thuoc (GiaCanh - danh muc cua phan mem): ap cho moi nguon (thang tu / den co nam thi cat theo nam quyet toan)
    npt_ds = []
    for r in t.get("npt") or []:
        r = list(r) + [""] * 8
        npt_ds.append({"manv": _nguyen(r[0]), "ten": _ten_sach(r[1]), "ngay_sinh": str(r[2] or "").strip(), "mst": str(r[3] or ""),
                       "cccd": str(r[4] or ""), "quan_he": _ten_sach(r[5]), "tu": _thang_chuoi(r[6], nam, False),
                       "den": _thang_chuoi(r[7], nam, True)})

    # --- chi tieu tung nguoi
    gt_bt, gt_npt = tsn["gt_ban_than"], tsn["gt_npt"]
    ds1, ds2 = [], []
    uq_cfg = str(ts.get("uy_quyen") or "").strip()
    uq_ma = {x_.strip().upper() for x_ in uq_cfg.split(";") if x_.strip() and x_.strip() != "*"}
    kiem_thang = []           # (ten, thang, thue theo bieu, thue bang luong)
    thieu_dd, lhd3, nn_ds, khong_hs, it_thang, npt_ex, nghi_uq = [], [], [], [], [], [], []
    so_kcn = so_tg = 0.0
    for khoa in thu_tu:
        p = ng[khoa]
        ths = sorted(p["thang"], key=lambda ma: (ky_thang(ma)[0], ma))
        if not ths:
            continue
        phu = set()
        for ma in ths:
            phu |= thang_cua_ky(ma)
        tn = sum(p["thang"][m]["tn"] for m in ths)
        bh = sum(p["thang"][m]["bh"] for m in ths)
        thue = sum(p["thang"][m]["thue"] for m in ths)
        nop = sum(p["thang"][m]["nop"] for m in ths)
        tu_thien = sum(p["thang"][m]["tu_thien"] for m in ths)
        kcn = sum(p["thang"][m]["kcn"] for m in ths)
        so_kcn += kcn
        so_tg += p["tinh_giam"]
        # NPT theo thang: BangLuong.sothang cho thang phan mem; GiaCanh cho thang lay tu Excel (hoac khi BangLuong chua tinh)
        npt_cua = [x_ for x_ in npt_ds if x_["manv"] == p["manv"] and p["manv"]
                   and max(1, x_["tu"] or 1) <= min(12, 12 if x_["den"] is None else x_["den"])]      # con giam tru trong nam
        gc = {m: 0 for m in range(1, 13)}
        for x_ in npt_cua:
            a = 1 if x_["tu"] is None else x_["tu"]
            b = 12 if x_["den"] is None else x_["den"]
            for m in range(max(1, a), min(12, b) + 1):
                gc[m] += 1
        th_pm_p = {m for m in ths if p["thang"][m]["nguon"] == "PM"}
        th_ex_p = set()
        for m in ths:
            if p["thang"][m]["nguon"] == "EXCEL":
                th_ex_p |= thang_cua_ky(m)
        npt_pm = sum(p["thang"][m]["sothang"] for m in th_pm_p)
        gc_pm = sum(gc[m] for m in th_pm_p)
        gc_ex = sum(gc[m] for m in th_ex_p)
        if th_pm_p and npt_pm == 0 and gc_pm:
            npt_pm = gc_pm
            cb.append("%s: bảng lương chưa có số NPT theo tháng (cột sothang) - tính %d tháng NPT theo bảng giảm trừ gia cảnh."
                      % (p["ten"], gc_pm))
        elif gc_pm and gc_pm != npt_pm:
            cb.append("%s: số tháng NPT theo bảng lương (%d) khác bảng giảm trừ gia cảnh (%d) - đã dùng số của bảng lương."
                      % (p["ten"], npt_pm, gc_pm))
        if gc_ex:
            npt_ex.append("%s (%d tháng)" % (p["ten"], gc_ex))
        npt_thang = npt_pm + gc_ex
        so_npt = max(p["phuthuoc"], sum(1 for x_ in npt_cua if any((1 if x_["tu"] is None else x_["tu"]) <= m <= (12 if x_["den"] is None else x_["den"])
                                                                   for m in phu)))
        if npt_thang and not so_npt:
            so_npt = max([p["thang"][m]["sothang"] for m in th_pm_p] + [0]) or max(gc.values())
        dd = dinh_danh(p["mst"], p["cccd"], p["quoc_tich"], nam)
        if dd["thieu"]:
            thieu_dd.append(p["ten"])
        if not dd["vn"]:
            nn_ds.append(p["ten"])
        if not p["co_hs"]:
            khong_hs.append(p["ten"])
        if len(phu) < 12:
            it_thang.append("%s (tháng %s)" % (p["ten"], _ds_thang(phu)))
        loai = "05-2" if p["loai_hd"] == 3 else "05-1"
        if loai == "05-2":
            lhd3.append(p["ten"])
        r = {"khoa": khoa, "ten": p["ten"], "ma": p["ma"], "manv": p["manv"], "dd": dd, "thang": ths, "phu": sorted(phu),
             "nguon": "+".join(sorted(p["nguon"])), "chi_tiet": p["thang"], "npt_ds": npt_cua, "tp1": lam_tron(p["tp1"]), "gc": gc}
        if loai == "05-1":
            uq = bool(uq_cfg) and (uq_cfg == "*" or p["ma"].upper() in uq_ma) and p["co_hs"] and p["loai_hd"] in (1, 2)
            nn = _ngay(p["ngay_nghi"]) if p["nghi"] else None
            if uq and nn and nn.year <= nam:
                uq = False
                nghi_uq.append("%s (nghỉ %s)" % (p["ten"], nn.strftime("%d/%m/%Y")))
            c = {k: 0 for k in CT_BK1}
            c["12"] = lam_tron(tn)
            c["16"] = so_npt
            c["17"] = gt_bt * SO_THANG_KY + gt_npt * npt_thang
            c["18"] = lam_tron(tu_thien)
            c["19"] = lam_tron(bh)
            c["21"] = max(0, c["12"] - c["14"] - c["15"] - c["15.1"] - c["17"] - c["18"] - c["19"] - c["20"])
            c["22"] = lam_tron(thue)
            tn_nam = thue_luy_tien(c["21"], nam, SO_THANG_KY)
            if uq and not dd["ct08"]:
                cb.append("%s ủy quyền quyết toán nhưng thiếu mã số thuế / CCCD 12 số ([08] bắt buộc khi tích [10])." % p["ten"])
            if uq:
                c["24"] = tn_nam
                c["25"] = max(0, c["22"] - c["24"])
                c["26"] = max(0, c["24"] - c["22"])
            r.update({"ct": c, "uq": uq, "ct27": bool(uq and 0 < c["26"] <= MIEN_50K), "thue_nam": tn_nam})
            ds1.append(r)
            # kiem thue tam khau tru tung THANG theo bieu thang (ky nhieu thang / ca nam khong kiem theo thang)
            for m in ths:
                if not 1 <= m <= 12:
                    continue
                x_ = p["thang"][m]
                so_npt_m = x_["sothang"] if x_["nguon"] == "PM" else gc[m]
                tt = thue_luy_tien(max(0, lam_tron(x_["tn"]) - lam_tron(x_["bh"]) - gt_bt - gt_npt * so_npt_m - lam_tron(x_["tu_thien"])),
                                   nam_bieu_thang(nam, m, ts), 1)
                if tt != lam_tron(x_["thue"]):
                    kiem_thang.append((p["ten"], m, tt, lam_tron(x_["thue"])))
        else:
            thue2 = thue if lam_tron(thue) else nop
            if lam_tron(thue) and lam_tron(nop):
                cb.append("%s: có cả thuế tháng (bảng lương %s) và thuế đã nộp ở bảng từ thiện/05B (%s) - đã dùng số bảng lương."
                          % (p["ten"], _vn(lam_tron(thue)), _vn(lam_tron(nop))))
            c = {k: 0 for k in CT_BK2}
            c["11"] = lam_tron(tn)
            c["15"] = lam_tron(thue2)
            r.update({"ct": c, "khong_cu_tru": False})
            ds2.append(r)

    # --- canh bao chung
    if ghep_ten:
        cb.append("Dòng bảng lương Excel chưa có mã nhân viên - đã ghép theo họ tên trùng khớp duy nhất trong danh mục: %s."
                  % _ds(sorted(set(ghep_ten))))
    if gop_dong:
        cb.append("Gộp nhiều dòng của cùng một người trong cùng kỳ bảng lương Excel (vd người chuyển bộ phận trong năm): %s."
                  % _ds(sorted(set(gop_dong)), 8))
    if thieu_dd:
        cb.append("%d người thiếu mã số thuế / số CCCD trong hồ sơ nhân viên (HTKK sẽ báo lỗi [08]/[09]): %s. Bổ sung hồ sơ "
                  "(Trợ lý AI: nhập danh sách tham gia BHXH để điền CCCD) rồi xuất lại." % (len(thieu_dd), _ds(thieu_dd)))
    trung = {}
    for r in ds1 + ds2:
        g = r["dd"]["ct09"] or r["dd"]["ct08"]
        if g:
            trung.setdefault(g, []).append(r["ten"])
    for g, ten in trung.items():
        if len(ten) > 1:
            cb.append("Trùng số giấy tờ / MST giữa: %s - kiểm tra hồ sơ nhân viên." % ", ".join(ten))
    if lhd3:
        cb.append("%d người có loại HĐ \"Dưới 12 tháng\" xếp bảng kê 05-2 (thuế suất toàn phần) như bảng kê 05B cũ của phần mềm: %s. "
                  "Nếu hợp đồng từ 3 tháng trở lên thì đổi loại HĐ để vào 05-1." % (len(lhd3), _ds(lhd3)))
    if nn_ds:
        cb.append("Người có quốc tịch nước ngoài (phần mềm không lưu tình trạng cư trú - đang kê là cá nhân cư trú): %s." % _ds(nn_ds))
    if khong_hs:
        cb.append("Dòng bảng lương Excel chưa ghép được mã nhân viên (không có hồ sơ, loại HĐ, CCCD) - xếp 05-1: %s." % _ds(khong_hs))
    if it_thang:
        cb.append("Có thu nhập dưới 12 tháng (giảm trừ bản thân vẫn tính 12 tháng như HTKK tự tính [17]): %s." % _ds(it_thang, 8))
    if npt_ex:
        cb.append("Giảm trừ người phụ thuộc cho kỳ lấy từ bảng lương Excel tính theo bảng giảm trừ gia cảnh (GiaCanh) của phần mềm: %s."
                  % _ds(npt_ex))
    if nghi_uq:
        cb.append("Không đánh dấu ủy quyền quyết toán [10] cho người đã nghỉ việc trong năm %d: %s." % (nam, _ds(nghi_uq)))
    if so_kcn or so_tg:
        cb.append("Phần mềm có số \"Lương khu công nghiệp\" / \"TNCT làm căn cứ tính giảm\" (%s) - tờ khai 05/QTT-TNCN (TT80) không còn "
                  "chỉ tiêu này nên KHÔNG trừ vào thu nhập chịu thuế; anh kiểm tra lại." % _vn(lam_tron(so_kcn + so_tg)))
    thang_co = set(th_pm)
    for m in chon_ex:
        thang_co |= thang_cua_ky(m)
    if thang_co and len(thang_co) < 12:
        cb.append("Năm %d chỉ có bảng lương tháng %s - chưa đủ 12 tháng." % (nam, _ds_thang(thang_co)))
    if kiem_thang:
        tong_b = sum(k[2] for k in kiem_thang)
        tong_l = sum(k[3] for k in kiem_thang)
        vd = "; ".join("%s T%d: %s/%s" % (k[0], k[1], _vn(k[2]), _vn(k[3])) for k in kiem_thang[:4])
        cb.append("Thuế tạm khấu trừ tháng theo biểu thuế khác bảng lương ở %d lượt tháng (theo biểu %s, bảng lương %s; vd %s). "
                  "Bảng kê [22] vẫn kê số ĐÃ khấu trừ theo bảng lương - xem sheet \"Chi tiet thang\"." % (len(kiem_thang), _vn(tong_b), _vn(tong_l), vd))
    gt_pm = _nguyen((dl.get("dn") or {}).get("gt_ban_than")) or _nguyen(ts.get("gt_ban_than"))
    npt_pm_ = _nguyen((dl.get("dn") or {}).get("gt_phu_thuoc")) or _nguyen(ts.get("gt_npt"))
    if (gt_pm and gt_pm != gt_bt) or (npt_pm_ and npt_pm_ != gt_npt):
        cb.append("Mức giảm trừ khai trong phần mềm (%s / %s) khác mức luật năm %d (%s / %s) - tờ khai dùng mức luật."
                  % (_vn(gt_pm), _vn(npt_pm_), nam, _vn(gt_bt), _vn(gt_npt)))
    uq_so = sum(1 for r in ds1 if r["uq"])
    if not uq_cfg:
        cb.append("Phần mềm chưa đánh dấu cá nhân ủy quyền quyết toán thay ([10] = 0 cho tất cả, mục II [35]-[41] = 0). "
                  "Có người ủy quyền thì tích [10] trong HTKK (HTKK tự tính [24]-[26]).")
    for r in ds1:
        if r["tp1"] and r["tp1"] != r["thue_nam"]:
            cb.append("%s: thuế năm phần mềm đã tính (Thuephainop1 %s) khác thuế năm theo biểu năm %d (%s)." % (r["ten"], _vn(r["tp1"]), nam, _vn(r["thue_nam"])))
    cb.append("Chỉ tiêu phần mềm không theo dõi nên ghi 0: 05-1 [13] TNCT / [23] thuế trước điều chuyển, [14] miễn theo Hiệp định, "
              "[15] Hợp đồng dầu khí, [15.1] miễn theo Nghị quyết, [20] quỹ hưu trí tự nguyện; [11] CN nước ngoài ủy quyền dưới 12 tháng; "
              "cá nhân không cư trú ([20] [25] [30] [33] tờ khai)%s. Có phát sinh thì anh sửa trong HTKK."
              % ("; 05-2 [12] [13] [14] [14.1] [16]" if ds2 else ""))
    npt_dung = [p_ for r in ds1 for p_ in r["npt_ds"]]
    if npt_dung:
        cb.append("Có %d người phụ thuộc: đã tính vào [16]/[17] bảng kê 05-1 và lập phụ lục 05-3 (Excel + XML). Quan hệ / loại giấy tờ "
                  "đổi theo danh mục HTKK (Con / Vợ-chồng / Cha-mẹ / Khác; CCCD / Hộ chiếu / Giấy khai sinh) - soát lại trên HTKK." % len(npt_dung))

    kq = {"nam": nam, "nam_tc": nam_tc, "nguon": nguon, "nguon_mo_ta": nguon_mo_ta, "ts": tsn, "ds1": ds1, "ds2": ds2, "npt": npt_dung,
          "canh_bao": cb, "thang_pm": th_pm, "thang_ex": th_ex, "ky_ex": sorted(chon_ex, key=lambda m: ky_thang(m)[0]),
          "ky_ex_bo": bo_ex, "kiem_thang": kiem_thang, "uq_so": uq_so}
    kq["tk"] = chi_tieu_to_khai(ds1, ds2)
    kq["tong1"] = {tg: sum(r["ct"][ct] for r in ds1) for tg, ct in CT_BK1_TONG}
    kq["tong1"]["43"] = sum(1 for r in ds1 if r["ct27"])
    kq["tong2"] = {tg: sum(r["ct"][ct] for r in ds2) for tg, ct in CT_BK2_TONG}
    kq["doi_chieu"] = doi_chieu(dl, kq, ts)
    kq["theo_thang"] = doi_chieu_thang(dl, kq)
    for d in kq["doi_chieu"]:
        if d.get("lech"):
            cb.append(d["canh_bao"])
    chua_ht = [m for m, bl, ps in kq["theo_thang"] if bl and not ps]
    if chua_ht:
        cb.append("Tháng %s năm %d có bảng lương nhưng sổ năm nay chưa có phát sinh Có TK 334 - kiểm tra bảng lương đúng năm / "
                  "đã hạch toán lương chưa (xem sheet \"Doi chieu\")." % (_ds_thang(chua_ht), nam))
    return kq


def doi_chieu_thang(dl, kq):
    """[(thang, tong thu nhap bang luong thang do, phat sinh Co TK 334 thang do)] - chi khi quyet toan dung nam tai chinh cua so
    (nam dau ky thang 1) va co danh muc TK; ky Excel nhieu thang / ca nam khong tach thang."""
    x = dl.get("x1l") or {}
    if kq["nam"] != kq["nam_tc"] or _nguyen(x.get("thang_dau_ky") or dl.get("thang_dau_ky") or 1) != 1 or _ps_co(dl, "334") is None:
        return []
    bl = {}
    for r in kq["ds1"] + kq["ds2"]:
        for ma, d in r["chi_tiet"].items():
            if 1 <= ma <= 12:
                bl[ma] = bl.get(ma, 0.0) + d["tn"]
    return [(m, lam_tron(bl[m]), lam_tron(_ps_co(dl, "334", m))) for m in sorted(bl)]


def chi_tieu_to_khai(ds1, ds2):
    """chi tieu to khai 05/QTT-TNCN theo dung cong thuc sheet '05' cua mau HTKK 2.9.3 (khong co ca nhan khong cu tru trong phan mem)."""
    ct = {k: 0 for k in CT_KHAU_TRU + CT_QT_THAY}
    k2_cu = [r for r in ds2 if not r.get("khong_cu_tru")]
    k2_kct = [r for r in ds2 if r.get("khong_cu_tru")]
    ct["16"] = len(ds1) + len(ds2)
    ct["17"] = len(ds1)
    ct["19"] = sum(1 for r in ds1 if r["ct"]["22"] > 0) + sum(1 for r in k2_cu if r["ct"]["15"] > 0)
    ct["20"] = sum(1 for r in k2_kct if r["ct"]["15"] > 0)
    ct["18"] = ct["19"] + ct["20"]
    ct["21"] = sum(1 for r in ds1 if r["ct"]["14"] > 0) + sum(1 for r in ds2 if r["ct"]["13"] > 0)
    ct["22"] = sum(r["ct"]["16"] for r in ds1)
    ct["24"] = sum(r["ct"]["12"] for r in ds1) - sum(r["ct"]["13"] for r in ds1) + sum(r["ct"]["11"] for r in k2_cu)
    ct["25"] = sum(r["ct"]["11"] for r in k2_kct)
    ct["23"] = ct["24"] + ct["25"]
    ct["26"] = sum(r["ct"]["12"] for r in ds2)
    ct["27"] = sum(r["ct"]["15"] for r in ds1) + sum(r["ct"]["14"] for r in ds2)
    ct["29"] = sum(r["ct"]["12"] for r in ds1 if r["ct"]["22"] > 0) + sum(r["ct"]["11"] for r in k2_cu if r["ct"]["15"] > 0)
    ct["30"] = sum(r["ct"]["11"] for r in k2_kct if r["ct"]["15"] > 0)
    ct["28"] = ct["29"] + ct["30"]
    ct["32"] = sum(r["ct"]["22"] for r in ds1) - sum(r["ct"]["23"] for r in ds1) + sum(r["ct"]["15"] for r in k2_cu)
    ct["33"] = sum(r["ct"]["15"] for r in k2_kct)
    ct["31"] = ct["32"] + ct["33"]
    ct["34"] = sum(r["ct"]["16"] for r in ds2)
    uq = [r for r in ds1 if r["uq"]]
    ct["35"] = len(uq)
    ct["36"] = sum(r["ct"]["22"] for r in uq)
    ct["37"] = sum(r["ct"]["23"] for r in uq)
    ct["38"] = sum(r["ct"]["24"] for r in uq)
    ct["39"] = sum(r["ct"]["26"] for r in ds1 if r["ct27"])
    hieu = ct["38"] - ct["36"] - ct["39"]
    ct["40"] = hieu if hieu > 0 else 0
    ct["41"] = -hieu if hieu < 0 else 0
    return ct


def doi_chieu(dl, kq, ts):
    """kiem cheo voi so ke toan: [23] ~ phat sinh Co TK 334 ca nam, [31] ~ phat sinh Co TK 3335, so nguoi."""
    nam, nam_tc, tk = kq["nam"], kq["nam_tc"], kq["tk"]
    kqd = []
    ps334 = ps3335 = None
    ng = ""
    if nam == nam_tc:
        ps334, ps3335, ng = _ps_co(dl, "334"), _ps_co(dl, "3335"), "sổ năm %d" % nam
    elif nam == nam_tc - 1 and _nguyen(ts.get("co_ps_truoc")):
        ps334, ps3335, ng = _so(ts.get("ps334_truoc")), _so(ts.get("ps3335_truoc")), "HeThongTK.PSCLK%d" % nam
    tong_tn = sum(r["ct"]["12"] for r in kq["ds1"]) + sum(r["ct"]["11"] for r in kq["ds2"])
    kqd.append({"ten": "[23] = tổng [12] bảng kê 05-1 + tổng [11] bảng kê 05-2", "a": tk["23"], "b": tong_tn, "lech": tk["23"] != tong_tn,
                "canh_bao": "Tự kiểm: [23] %s khác tổng TNCT các cá nhân %s." % (_vn(tk["23"]), _vn(tong_tn))})
    if ps334 is not None:
        b = lam_tron(ps334)
        kqd.append({"ten": "[23] Tổng TNCT so với phát sinh Có TK 334 cả năm (%s)" % ng, "a": tk["23"], "b": b, "lech": tk["23"] != b,
                    "canh_bao": "[23] tổng thu nhập chịu thuế %s khác phát sinh Có TK 334 năm %d (%s) %s, lệch %s - kiểm tra lương "
                                "chưa hạch toán / hạch toán 334 khoản không phải lương." % (_vn(tk["23"]), nam, ng, _vn(b), _vn(tk["23"] - b))})
    else:
        kqd.append({"ten": "[23] so với phát sinh Có TK 334", "a": tk["23"], "b": None, "lech": False, "canh_bao": ""})
    if ps3335 is not None:
        b = lam_tron(ps3335)
        kqd.append({"ten": "[31] Thuế TNCN đã khấu trừ so với phát sinh Có TK 3335 cả năm (%s)" % ng, "a": tk["31"], "b": b, "lech": tk["31"] != b,
                    "canh_bao": "[31] thuế TNCN đã khấu trừ %s khác phát sinh Có TK 3335 năm %d %s, lệch %s (3335 có thể gồm thuế TNCN "
                                "khoản khác - kiểm tra)." % (_vn(tk["31"]), nam, _vn(b), _vn(tk["31"] - b))})
    kqd.append({"ten": "[17] Cá nhân cư trú có HĐLĐ <= [16] Tổng số người lao động", "a": tk["17"], "b": tk["16"], "lech": tk["17"] > tk["16"],
                "kieu": "le", "canh_bao": "Tự kiểm: [17] > [16]."})
    kqd.append({"ten": "[21] <= [16] - [20]", "a": tk["21"], "b": tk["16"] - tk["20"], "lech": tk["21"] > tk["16"] - tk["20"],
                "kieu": "le", "canh_bao": "Tự kiểm: [21] > [16] - [20]."})
    so_nv = len([1 for r in (dl.get("tncn") or {}).get("nv") or []])
    kqd.append({"ten": "Số người trên bảng kê / số nhân viên trong danh mục (tham khảo)", "a": tk["16"], "b": so_nv, "lech": False,
                "kieu": "tk", "canh_bao": ""})
    return kqd


def _vn(x):
    """so kieu Viet Nam: 1.234.567 (am: -1.234)."""
    x = lam_tron(x)
    return ("-" if x < 0 else "") + "{:,}".format(abs(x)).replace(",", ".")


def _ds(ds, toi_da=6):
    ds = list(ds)
    return ", ".join(ds[:toi_da]) + (" ... (+%d)" % (len(ds) - toi_da) if len(ds) > toi_da else "")


# ------------------------------------------------------------------ thong tin chung / HTKK
def _dn(dl):
    dn = dict(dl.get("cty") or {})
    dn.update({k: v for k, v in (dl.get("dn") or {}).items() if v not in (None, "")})
    return dn


def _ngay_lap(dl):
    x = dl.get("x1l") or {}
    for f in ("%d/%m/%Y", "%Y-%m-%d"):
        try:
            return datetime.strptime(str(x.get("ngay_lap") or "")[:10], f)
        except ValueError:
            pass
    return datetime.now()


def _htkk(dl):
    """(HEADER.xml cua HTKK tren may {PropertyInfo: Value}, phien ban HTKK) - cache trong dl."""
    st = dl.setdefault("_tncn_cache", {})
    if "htkk" in st:
        return st["htkk"]
    hd, pb = {}, ""
    try:
        import tool_htkk_unesco as X
        h = X.tim_htkk()
        if h and h.get("goc"):
            pb = (h.get("phien_ban") or "").strip()
            hd = X.dau_may(h["goc"], _dn(dl).get("mst", "")) or {}
    except Exception:
        hd, pb = {}, ""
    st["htkk"] = (hd, pb)
    return st["htkk"]


def _ttin_nha_ccap():
    try:
        import tool_htkk_unesco as X
        return X.TTIN_NHA_CCAP
    except Exception:
        return TTIN_NHA_CCAP_MD


def _nguoi_ky(dl):
    nk = dl.get("nguoi_ky") or {}
    dn = _dn(dl)
    hd, _ = _htkk(dl)
    return nk.get("nguoi_ky") or dn.get("nguoi_ky") or nk.get("giam_doc") or dn.get("nguoi_dd_pl") or hd.get("nguoiKy", "")


# ------------------------------------------------------------------ XML HTKK
def _e(cha, ten, gt=None):
    n = ET.SubElement(cha, "{%s}%s" % (NS, ten))
    if gt is not None:
        n.text = str(gt)
    return n


def _e_tin(cha, ten, gt):
    n = _e(cha, ten)
    if gt:
        n.text = gt
    else:
        n.set("{%s}nil" % NS_XSI, "true")
    return n


def lap_xml_goc(dl, kq, cb):
    nam = kq["nam"]
    dn = _dn(dl)
    hd, pb = _htkk(dl)
    lap = _ngay_lap(dl)
    goc = ET.Element("{%s}HSoThueDTu" % NS)
    hs = _e(goc, "HSoKhaiThue")
    hs.set("id", "ID_1")
    tc = _e(hs, "TTinChung")
    dv = _e(tc, "TTinDVu")
    _e(dv, "maDVu", "HTKK")
    _e(dv, "tenDVu", "HỖ TRỢ KÊ KHAI THUẾ")
    _e(dv, "pbanDVu", pb or "5.7.6")
    _e(dv, "ttinNhaCCapDVu", _ttin_nha_ccap())
    tt = _e(tc, "TTinTKhaiThue")
    tk = _e(tt, "TKhaiThue")
    _e(tk, "maTKhai", MA_TKHAI)
    _e(tk, "tenTKhai", TEN_TKHAI)
    _e(tk, "moTaBMau", MO_TA_BMAU)
    _e(tk, "pbanTKhaiXML", PBAN_XML)
    _e(tk, "loaiTKhai", "C")
    _e(tk, "soLan", "0")
    ky = _e(tk, "KyKKhaiThue")
    _e(ky, "kieuKy", "Y")
    _e(ky, "kyKKhai", str(nam))
    _e(ky, "kyKKhaiTuNgay", "")
    _e(ky, "kyKKhaiDenNgay", "")
    _e(ky, "kyKKhaiTuThang", "01/%d" % nam)
    _e(ky, "kyKKhaiDenThang", "12/%d" % nam)
    ma_cqt, ten_cqt = hd.get("maCQTNoiNop", ""), hd.get("tenCQTNoiNop", "")
    if not ma_cqt:
        ma_cqt, ten_cqt = str(dn.get("ma_cqt") or ""), str(dn.get("ten_cqt") or "")
        if ma_cqt:
            cb.append("XML 05/QTT-TNCN: mã CQT %s %s lấy theo khai báo trong phần mềm (không thấy HEADER.xml của HTKK) - kiểm tra lại." % (ma_cqt, ten_cqt))
        else:
            cb.append("XML 05/QTT-TNCN: THIẾU mã cơ quan thuế nơi nộp (maCQTNoiNop) - chọn lại trên HTKK trước khi nộp.")
    _e(tk, "maCQTNoiNop", ma_cqt)
    _e(tk, "tenCQTNoiNop", ten_cqt)
    _e(tk, "ngayLapTKhai", lap.strftime("%Y-%m-%d"))
    gh = _e(tk, "GiaHan")
    _e(gh, "maLyDoGiaHan", "")
    _e(gh, "lyDoGiaHan", "")
    _e(tk, "nguoiKy", _nguoi_ky(dl))
    _e(tk, "ngayKy", lap.strftime("%Y-%m-%d"))
    _e(tk, "nganhNgheKD", hd.get("nganhNgheKD", ""))
    nnt = _e(tt, "NNT")
    mst = re.sub(r"[^0-9-]", "", str(dn.get("mst") or hd.get("mst") or ""))
    if not RE_TIN.fullmatch(mst):
        raise RuntimeError("Mã số thuế doanh nghiệp không hợp lệ (%s) - khai báo lại MST trong phần mềm." % mst)
    _e(nnt, "mst", mst)
    _e(nnt, "tenNNT", dn.get("ten") or hd.get("tenNNT", ""))
    _e(nnt, "dchiNNT", dn.get("dia_chi") or hd.get("dchiNNT", ""))
    _e(nnt, "tenXaNNT", hd.get("tenXaPhuongNNT", ""))
    _e(nnt, "maXaNNT", hd.get("maXaPhuongNNT", ""))
    _e(nnt, "maHuyenNNT", "")
    _e(nnt, "tenHuyenNNT", "")
    _e(nnt, "maTinhNNT", hd.get("maTinhNNT", ""))
    _e(nnt, "tenTinhNNT", hd.get("tenTinhNNT") or dn.get("tinh") or "")
    _e(nnt, "dthoaiNNT", dn.get("dien_thoai") or hd.get("dthoaiNNT", ""))
    _e(nnt, "faxNNT", dn.get("fax") or hd.get("faxNNT", ""))
    _e(nnt, "emailNNT", dn.get("email") or hd.get("emailNNT", ""))
    if not hd.get("maTinhNNT"):
        cb.append("XML 05/QTT-TNCN: chưa có mã tỉnh / xã của người nộp thuế (HEADER.xml HTKK) - HTKK điền lại khi mở tờ khai.")
    mdl = re.sub(r"[^0-9-]", "", str(hd.get("mstDLyThue") or ""))
    if str(hd.get("ThongTinDaiLy")).lower() == "true" and RE_TIN.fullmatch(mdl or ""):
        d = _e(tt, "DLyThue")
        for the in ("mstDLyThue", "tenDLyThue", "dchiDLyThue", "maHuyenDLyThue", "tenHuyenDLyThue", "maTinhDLyThue", "tenTinhDLyThue",
                    "dthoaiDLyThue", "faxDLyThue", "emailDLyThue", "soHDongDLyThue", "ngayKyHDDLyThue"):
            _e(d, the, mdl if the == "mstDLyThue" else ("" if the == "ngayKyHDDLyThue" else hd.get(the, "")))
        nv = _e(d, "NVienDLy")
        _e(nv, "tenNVienDLyThue", hd.get("tenNVienDLyThue", ""))
        _e(nv, "cchiHNghe", hd.get("cchiHNghe", ""))
    ct = _e(hs, "CTieuTKhaiChinh")
    _e(ct, "mst_cu", mst)
    h = _e(ct, "Header")
    _e(h, "toChucCoQTTTheoUyQuyen", "0")
    _e(h, "ma_THQuyetToan", "01")
    _e(h, "ten_THQuyetToan", "QT định kỳ")
    _e(h, "hanNop", "")
    kt = _e(ct, "NVuKhauTruThue")
    for m in CT_KHAU_TRU:
        _e(kt, "ct" + m, str(kq["tk"][m]))
    qt = _e(ct, "NVuQToanThay")
    for m in CT_QT_THAY:
        _e(qt, "ct" + m, str(kq["tk"][m]))
    pl = _e(hs, "PLuc")
    if kq["ds1"]:
        p1 = _e(pl, "PLuc_05_1_BK_QTT")
        for i, r in enumerate(kq["ds1"], 1):
            b = _e(p1, "BKeCTietCNhan")
            b.set("id", "ID_%d" % i)
            dd = r["dd"]
            _e(b, "coDieuChinhSoLieu", "0")
            _e(b, "ct07", r["ten"])
            _e_tin(b, "ct08", dd["ct08"])
            _e(b, "nguoiVNSongNN_NguoiNN", "1" if dd["nn"] else "0")
            _e(b, "ct09a_ma", dd["ma"])
            _e(b, "ct09a_ten", dd["ten_gt"])
            _e(b, "ct09", dd["ct09"])
            _e(b, "ct10", "1" if r["uq"] else "0")
            _e(b, "ct11", "0")
            for m in CT_BK1:
                _e(b, "ct" + m, str(r["ct"][m]))
            _e(b, "ct27", "1" if r["ct27"] else "0")
        for tg, _ in CT_BK1_TONG:
            _e(p1, "ct" + tg, str(kq["tong1"][tg]))
        _e(p1, "ct43", str(kq["tong1"]["43"]))
    if kq["ds2"]:
        p2 = _e(pl, "PLuc_05_2_BK_QTT")
        for i, r in enumerate(kq["ds2"], 1):
            b = _e(p2, "BKeCTietCNhan")
            b.set("id", "ID_%d" % i)
            dd = r["dd"]
            _e(b, "coDieuChinhSoLieu", "0")
            _e(b, "ct07", r["ten"])
            _e_tin(b, "ct08", dd["ct08"])
            _e(b, "nguoiVNSongNN_NguoiNN", "1" if dd["nn"] else "0")
            _e(b, "ct09a_ma", dd["ma"])
            _e(b, "ct09a_ten", dd["ten_gt"])
            _e(b, "ct09", dd["ct09"])
            _e(b, "ct10", "1" if r.get("khong_cu_tru") else "0")
            for m in CT_BK2:
                _e(b, "ct" + m, str(r["ct"][m]))
        for tg, _ in CT_BK2_TONG:
            _e(p2, "ct" + tg, str(kq["tong2"][tg]))
    _pl_05_3(pl, kq, nam)                    # GD328: phu luc 05-3 nguoi phu thuoc (truoc chi co trong Excel)
    if not list(pl):
        hs.remove(pl)
    return goc


# GD328: danh muc HTKK - quan he voi NNT (InterfaceIni\Catalogue_QHNNT.xml), loai giay to NPT (DM_DUNG_CHUNG DC_129)
QH_NNT = (("01", "Con", ("CON",)), ("02", "Vợ/chồng", ("VO", "CHONG")), ("03", "Cha/mẹ", ("CHA", "ME", "BO", "MA", "THAN SINH", "BO DE", "ME DE")))
GT_NPT = {"03": "Thẻ CCCD/Số định danh cá nhân", "02": "Hộ chiếu", "04": "Giấy khai sinh", "05": "Khác"}


def _bo_dau_hoa(s):
    import unicodedata
    s = unicodedata.normalize("NFD", str(s or "")).replace("đ", "d").replace("Đ", "D")
    return re.sub(r"\s+", " ", "".join(c for c in s if unicodedata.category(c) != "Mn")).upper().strip()


def quan_he_npt(qh):
    """'con' / 'Vợ' / 'Mẹ ruột' ... -> (ma, ten) theo danh muc HTKK; khong nhan ra -> ('04', 'Khác')."""
    k = " " + _bo_dau_hoa(qh) + " "
    for ma, ten, tu in QH_NNT:
        if any((" " + t + " ") in k for t in tu):
            return ma, ten
    return "04", "Khác"


def _ngay_iso_npt(s):
    s = str(s or "").strip()
    m = re.match(r"^(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})", s) or re.match(r"^(\d{2})(\d{2})(\d{4})$", s)
    if m:
        try:
            return date(int(m.group(3)), int(m.group(2)), int(m.group(1))).strftime("%Y-%m-%d")
        except ValueError:
            return ""
    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})", s)
    return m.group(0) if m else ""


def _pl_05_3(pl, kq, nam):
    rows = [(x, p) for x in kq["ds1"] for p in x.get("npt_ds") or []]
    if not rows:
        return
    p3 = _e(pl, "PLuc_05_3_BK_QTT")
    for i, (x, p) in enumerate(rows, 1):
        b = _e(p3, "BKeTTinNPT")
        b.set("id", "ID_%d" % i)
        gt = dinh_danh(p.get("mst"), p.get("cccd"), "", nam)
        _e(b, "ct07", x["ten"])
        _e_tin(b, "ct08", x["dd"]["ct08"])
        _e(b, "ct09", p.get("ten") or "")
        ns = _ngay_iso_npt(p.get("ngay_sinh"))
        n = _e(b, "ct10")
        if ns:
            n.text = ns
        else:
            n.set("{%s}nil" % NS_XSI, "true")
        mst_npt = gt["ct08"] if gt["ct08"] and gt["ct08"] != gt["ct09"] else ""
        _e_tin(b, "ct11", mst_npt)
        _e(b, "nguoiVNSongNN_NguoiNN", "0")
        so = gt["ct09"]
        goc_so = str(p.get("cccd") or "").strip()
        if not so:
            ma_gt = ""
        elif so.isdigit() and len(so) == 12:
            ma_gt = "03"                                         # CCCD / so dinh danh ca nhan
        elif gt["ma"] == "02":
            ma_gt = "02"                                         # ho chieu
        elif re.search(r"GKS|KHAI SINH|/", _bo_dau_hoa(goc_so)) or (not so.isdigit()):
            ma_gt = "04"                                         # giay khai sinh (so dang '56/2018', 'GKS...')
            so = goc_so
        else:
            ma_gt = "05"                                         # khac (CMND 9 so...)
        _e(b, "ct12_ma", ma_gt)
        _e(b, "ct12_ten", GT_NPT.get(ma_gt, ""))
        _e(b, "ct13", so)
        qm, qt = quan_he_npt(p.get("quan_he"))
        _e(b, "ct14_ma", qm)
        _e(b, "ct14_ten", qt)
        tu = p.get("tu") if p.get("tu") and 1 <= p["tu"] <= 12 else 1          # khong ghi tu / den thang -> ca nam (nhu cach tinh NPT)
        den = p.get("den") if p.get("den") and 1 <= p["den"] <= 12 else 12
        _e(b, "ct15", "%02d%d" % (tu, nam))
        _e(b, "ct16", "%02d%d" % (den, nam))


def ghi_xml(goc, duong):
    """UTF-8 co BOM, khai bao nhay kep, xmlns:xsi tren goc, thut dong (nhu tep HTKK ket xuat)."""
    try:
        ET.register_namespace("", NS)
        ET.register_namespace("xsi", NS_XSI)
    except Exception:
        pass
    co_xsi = any(str(k).startswith("{%s}" % NS_XSI) for n in goc.iter() for k in n.attrib)
    if not co_xsi:
        goc.set("xmlns:xsi", NS_XSI)
    try:
        ET.indent(goc, space="  ")
    except AttributeError:
        pass
    txt = ET.tostring(goc, encoding="unicode")
    tam = duong + ".tmp"
    with io.open(tam, "w", encoding="utf-8-sig", newline="\r\n") as f:
        f.write('<?xml version="1.0" encoding="UTF-8"?>\n' + txt + "\n")
    os.replace(tam, duong)
    return duong


def kiem_xml(duong):
    """tu kiem noi bo (may khach khong co lxml): cau truc, kieu so / TIN / boolean, cong thuc tong - tra danh sach loi."""
    loi = []
    try:
        g = ET.parse(duong).getroot()
    except ET.ParseError as e:
        return ["XML hỏng: %s" % e]

    def ten(n):
        return n.tag.split("}", 1)[-1]

    def tim(n, *duong_):
        for p in duong_:
            n = next((c for c in n if ten(c) == p), None)
            if n is None:
                return None
        return n

    hs = tim(g, "HSoKhaiThue")
    if ten(g) != "HSoThueDTu" or hs is None:
        return ["Gốc XML không phải HSoThueDTu/HSoKhaiThue"]
    if (tim(hs, "TTinChung", "TTinTKhaiThue", "TKhaiThue", "maTKhai").text or "") != MA_TKHAI:
        loi.append("maTKhai khác %s" % MA_TKHAI)
    for p in (("TTinChung", "TTinTKhaiThue", "NNT", "mst"), ("CTieuTKhaiChinh", "mst_cu")):
        n = tim(hs, *p)
        if n is None or not RE_TIN.fullmatch(n.text or ""):
            loi.append("%s sai định dạng MST" % p[-1])
    ct = {}
    for khoi, ds in (("NVuKhauTruThue", CT_KHAU_TRU), ("NVuQToanThay", CT_QT_THAY)):
        n = tim(hs, "CTieuTKhaiChinh", khoi)
        if n is None or [ten(c) for c in n] != ["ct" + m for m in ds]:
            loi.append("%s sai thứ tự / thiếu chỉ tiêu" % khoi)
            continue
        for c in n:
            if not re.fullmatch(r"-?\d+", c.text or ""):
                loi.append("%s/%s = '%s' không phải số nguyên" % (khoi, ten(c), c.text))
            else:
                ct[ten(c)[2:]] = int(c.text)
    for a, b, c in (("18", "19", "20"), ("23", "24", "25"), ("28", "29", "30"), ("31", "32", "33")):
        if ct and ct.get(a) != ct.get(b, 0) + ct.get(c, 0):
            loi.append("[%s] khác [%s] + [%s]" % (a, b, c))
    thu_tu1 = ["coDieuChinhSoLieu", "ct07", "ct08", "nguoiVNSongNN_NguoiNN", "ct09a_ma", "ct09a_ten", "ct09", "ct10", "ct11"] + \
              ["ct" + m for m in CT_BK1] + ["ct27"]
    thu_tu2 = ["coDieuChinhSoLieu", "ct07", "ct08", "nguoiVNSongNN_NguoiNN", "ct09a_ma", "ct09a_ten", "ct09", "ct10"] + ["ct" + m for m in CT_BK2]
    for pl, tt, tong, bool_ in (("PLuc_05_1_BK_QTT", thu_tu1, CT_BK1_TONG + [("43", None)], ("ct10", "ct11", "ct27")),
                                ("PLuc_05_2_BK_QTT", thu_tu2, CT_BK2_TONG, ("ct10",))):
        p = tim(hs, "PLuc", pl)
        if p is None:
            continue
        dong = [c for c in p if ten(c) == "BKeCTietCNhan"]
        if [ten(c) for c in p] != ["BKeCTietCNhan"] * len(dong) + ["ct" + x for x, _ in tong]:
            loi.append("%s sai thứ tự thẻ tổng" % pl)
        cong = {}
        for i, b in enumerate(dong, 1):
            if [ten(c) for c in b] != tt:
                loi.append("%s dòng %d sai thứ tự thẻ" % (pl, i))
                continue
            for c in b:
                k = ten(c)
                if k in ("coDieuChinhSoLieu", "nguoiVNSongNN_NguoiNN") + bool_:
                    if (c.text or "") not in ("0", "1"):
                        loi.append("%s dòng %d %s không phải 0/1" % (pl, i, k))
                elif k == "ct08":
                    if c.get("{%s}nil" % NS_XSI) != "true" and not RE_TIN.fullmatch(c.text or ""):
                        loi.append("%s dòng %d [08] sai định dạng MST/CCCD" % (pl, i))
                elif k.startswith("ct") and k not in ("ct07", "ct09", "ct09a_ma", "ct09a_ten"):
                    if not re.fullmatch(r"-?\d+", c.text or ""):
                        loi.append("%s dòng %d %s không phải số nguyên" % (pl, i, k))
                    else:
                        cong[k[2:]] = cong.get(k[2:], 0) + int(c.text)
        for x, y in tong:
            n = tim(p, "ct" + x)
            if y and n is not None and int(n.text or 0) != cong.get(y, 0):
                loi.append("%s [%s] khác tổng cột [%s]" % (pl, x, y))
    return loi


# ------------------------------------------------------------------ Excel to khai (bo cuc HTKK)
def _kieu(wb):
    from xlsx_viet import SoExcel  # noqa: F401
    K = {}
    K["td"] = wb.kieu(dam=True, co=13, can="giua", xuong=True)
    K["td2"] = wb.kieu(nghieng=True, co=10, can="giua", xuong=True)
    K["qh"] = wb.kieu(dam=True, co=11, can="giua")
    K["qh2"] = wb.kieu(dam=True, co=11, can="giua", gach=True)
    K["mau"] = wb.kieu(co=9, can="giua", xuong=True, khung=True)
    K["t"] = wb.kieu(co=11)
    K["td_nho"] = wb.kieu(dam=True, co=11)
    K["b"] = wb.kieu(dam=True, co=11)
    K["dvt"] = wb.kieu(nghieng=True, co=10, can="phai")
    K["h"] = wb.kieu(dam=True, co=9, can="giua", doc="giua", xuong=True, khung=True, nen="E2EFDA")
    K["hm"] = wb.kieu(nghieng=True, co=9, can="giua", khung=True, nen="E2EFDA")
    K["c"] = wb.kieu(co=10, khung=True, xuong=True, doc="giua")
    K["cg"] = wb.kieu(co=10, khung=True, can="giua", doc="giua")
    K["cb"] = wb.kieu(dam=True, co=10, khung=True, xuong=True, doc="giua")
    K["n"] = wb.kieu(co=10, khung=True, so="#,##0", doc="giua")
    K["nb"] = wb.kieu(dam=True, co=10, khung=True, so="#,##0", doc="giua")
    K["txt"] = wb.kieu(co=10, khung=True, so="@", doc="giua")
    K["ky"] = wb.kieu(dam=True, co=11, can="giua", xuong=True)
    K["ky2"] = wb.kieu(nghieng=True, co=10, can="giua", xuong=True)
    K["ghi"] = wb.kieu(nghieng=True, co=10, xuong=True)
    return K


def _cot_chia(rong, tu_phai=None, ty_le=None):
    """cot bat dau khoi ben phai: tu_phai = do rong toi thieu tinh tu phai sang; ty_le = phan trai chiem ty le tong do rong."""
    if tu_phai is not None:
        t = 0
        for i in range(len(rong) - 1, 0, -1):
            t += rong[i]
            if t >= tu_phai:
                return i + 1
        return 2
    tong, t = sum(rong), 0
    for i, w in enumerate(rong):
        t += w
        if t >= tong * ty_le:
            return min(len(rong), i + 2)
    return len(rong)


def _dau_trang(ws, K, rong, mau, nam, dn, pl_ten=None):
    """khoi dau trang in HTKK: quoc hieu, o 'Mau so', tieu de, ky tinh thue, lan dau / bo sung, ten + MST."""
    so_cot = len(rong)
    c_mau = _cot_chia(rong, tu_phai=30)
    ws.gop(1, 1, 1, c_mau - 1, "CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM", K["qh"])
    ws.gop(2, 1, 2, c_mau - 1, "Độc lập - Tự do - Hạnh phúc", K["qh2"])
    ws.gop(1, c_mau, 3, so_cot, "Mẫu số: %s\n(Ban hành kèm theo Thông tư số 80/2021/TT-BTC ngày 29 tháng 9 năm 2021 của Bộ trưởng Bộ Tài chính)" % mau, K["mau"])
    ws.cao(3, 30)
    r = 5
    if pl_ten:
        ws.gop(r, 1, r, so_cot, "PHỤ LỤC", K["td"])
        r += 1
        ws.gop(r, 1, r, so_cot, pl_ten, K["td"])
        ws.cao(r, 34)
        r += 1
        ws.gop(r, 1, r, so_cot, "(Kèm theo tờ khai quyết toán thuế thu nhập cá nhân mẫu số 05/QTT-TNCN)", K["td2"])
        r += 1
    else:
        ws.gop(r, 1, r, so_cot, "TỜ KHAI QUYẾT TOÁN THUẾ THU NHẬP CÁ NHÂN", K["td"])
        r += 1
        ws.gop(r, 1, r, so_cot, "(Áp dụng đối với tổ chức, cá nhân trả thu nhập chịu thuế từ tiền lương, tiền công)", K["td2"])
        r += 1
    ws.gop(r, 1, r, so_cot, "[01] Kỳ tính thuế: Năm %d" % nam, K["qh"])
    r += 1
    ws.gop(r, 1, r, so_cot, "[02] Lần đầu: [X]          [03] Bổ sung lần thứ: [   ]", K["qh"])
    r += 2
    if not pl_ten:
        ws.gop(r, 1, r, so_cot, "Trường hợp quyết toán: QT định kỳ", K["t"])
        r += 1
        ws.gop(r, 1, r, so_cot, "[04] [   ] Tổ chức có quyết toán thuế theo ủy quyền của cá nhân được điều chuyển từ tổ chức cũ đến tổ chức "
                                "mới do tổ chức cũ thực hiện sáp nhập, hợp nhất, chia, tách, chuyển đổi loại hình doanh nghiệp hoặc "
                                "điều chuyển trong cùng hệ thống", wb_kieu_xuong(ws, K))
        ws.cao(r, 30)
        r += 1
    ma = ("[04]", "[05]") if pl_ten else ("[05]", "[06]")
    ws.gop(r, 1, r, so_cot, "%s Tên người nộp thuế: %s" % (ma[0], dn.get("ten", "")), K["b"])
    r += 1
    ws.gop(r, 1, r, so_cot, "%s Mã số thuế: %s" % (ma[1], dn.get("mst", "")), K["b"])
    r += 1
    if not pl_ten:
        ws.gop(r, 1, r, so_cot, "[13] Tên đại lý thuế (nếu có):", K["t"])
        r += 1
        ws.gop(r, 1, r, so_cot, "[14] Mã số thuế đại lý:", K["t"])
        r += 1
    return r + 1


def wb_kieu_xuong(ws, K):
    return ws.wb.kieu(co=11, xuong=True, doc="tren")


def _ky_ten(ws, K, r, rong, dl, nam):
    lap = _ngay_lap(dl)
    nk = _nguoi_ky(dl)
    so_cot = len(rong)
    ws.gop(r, 1, r, so_cot, "Tôi cam đoan số liệu khai trên là đúng và chịu trách nhiệm trước pháp luật về những số liệu đã khai./.", K["ghi"])
    r += 2
    giua = _cot_chia(rong, ty_le=0.45)
    ws.gop(r, 1, r, giua - 1, "NHÂN VIÊN ĐẠI LÝ THUẾ", K["ky"])
    ws.gop(r, giua, r, so_cot, "..., ngày %02d tháng %02d năm %d" % (lap.day, lap.month, lap.year), K["ky2"])
    r += 1
    ws.gop(r, 1, r, giua - 1, "Họ và tên: .......................................", K["t"])
    ws.gop(r, giua, r, so_cot, "NGƯỜI NỘP THUẾ hoặc\nĐẠI DIỆN HỢP PHÁP CỦA NGƯỜI NỘP THUẾ", K["ky"])
    ws.cao(r, 45)
    r += 1
    ws.gop(r, 1, r, giua - 1, "Chứng chỉ hành nghề số: .......................", K["t"])
    ws.gop(r, giua, r, so_cot, "(Chữ ký, ghi rõ họ tên; chức vụ và đóng dấu (nếu có)/Ký điện tử)", K["ky2"])
    r += 4
    ws.gop(r, giua, r, so_cot, nk, K["ky"])
    return r + 1


def _sheet_05(wb, K, kq, dl):
    dn = _dn(dl)
    ct = kq["tk"]
    rong = [6, 58, 11, 10, 20]
    ws = wb.sheet("05", cot=rong)
    r = _dau_trang(ws, K, rong, "05/QTT-TNCN", kq["nam"], dn)
    ws.gop(r, 1, r, 5, "I. NGHĨA VỤ KHẤU TRỪ THUẾ CỦA TỔ CHỨC, CÁ NHÂN TRẢ THU NHẬP", K["b"])
    r += 1
    ws.gop(r, 1, r, 5, "Đơn vị tiền: Đồng Việt Nam", K["dvt"])
    r += 1
    ws.dong(r, 1, ["STT", "Chỉ tiêu", "Mã chỉ tiêu", "Đơn vị tính", "Số người/Số tiền"], K["h"])
    ws.cao(r, 30)
    r += 1
    dong1 = [("1", "Tổng số người lao động:", "16", "Người", True),
             ("", "Trong đó: Cá nhân cư trú có hợp đồng lao động", "17", "Người", False),
             ("2", "Tổng số cá nhân đã khấu trừ thuế [18]=[19]+[20]", "18", "Người", True),
             ("2.1", "Cá nhân cư trú", "19", "Người", False),
             ("2.2", "Cá nhân không cư trú", "20", "Người", False),
             ("3", "Tổng số cá nhân thuộc diện được miễn, giảm thuế theo Hiệp định tránh đánh thuế hai lần", "21", "Người", True),
             ("4", "Tổng số cá nhân giảm trừ gia cảnh", "22", "Người", True),
             ("5", "Tổng thu nhập chịu thuế trả cho cá nhân [23]=[24]+[25]", "23", "VNĐ", True),
             ("5.1", "Cá nhân cư trú", "24", "VNĐ", False),
             ("5.2", "Cá nhân không cư trú", "25", "VNĐ", False),
             ("5.3", "Trong đó: Tổng thu nhập chịu thuế từ tiền phí mua bảo hiểm nhân thọ, bảo hiểm không bắt buộc khác của doanh "
                     "nghiệp bảo hiểm không thành lập tại Việt Nam cho người lao động", "26", "VNĐ", False),
             ("6", "Trong đó tổng thu nhập chịu thuế được miễn theo quy định của Hợp đồng dầu khí", "27", "VNĐ", True),
             ("7", "Tổng thu nhập chịu thuế trả cho cá nhân thuộc diện phải khấu trừ thuế [28]=[29]+[30]", "28", "VNĐ", True),
             ("7.1", "Cá nhân cư trú", "29", "VNĐ", False),
             ("7.2", "Cá nhân không cư trú", "30", "VNĐ", False),
             ("8", "Tổng số thuế thu nhập cá nhân đã khấu trừ [31]=[32]+[33]", "31", "VNĐ", True),
             ("8.1", "Cá nhân cư trú", "32", "VNĐ", False),
             ("8.2", "Cá nhân không cư trú", "33", "VNĐ", False),
             ("8.3", "Trong đó: Tổng số thuế thu nhập cá nhân đã khấu trừ trên tiền phí mua bảo hiểm nhân thọ, bảo hiểm không bắt buộc "
                     "khác của doanh nghiệp bảo hiểm không thành lập tại Việt Nam cho người lao động", "34", "VNĐ", False)]
    dong2 = [("1", "Tổng số cá nhân uỷ quyền cho tổ chức, cá nhân trả thu nhập quyết toán thay", "35", "Người", True),
             ("2", "Tổng số thuế thu nhập cá nhân đã khấu trừ", "36", "VNĐ", True),
             ("", "Trong đó: Số thuế thu nhập cá nhân đã khấu trừ tại tổ chức trước khi điều chuyển (trường hợp có đánh dấu vào chỉ tiêu [04])",
              "37", "VNĐ", False),
             ("3", "Tổng số thuế thu nhập cá nhân phải nộp", "38", "VNĐ", True),
             ("4", "Tổng số thuế thu nhập cá nhân được miễn do cá nhân có số thuế còn phải nộp sau ủy quyền quyết toán từ 50.000 đồng trở xuống",
              "39", "VNĐ", True),
             ("5", "Tổng số thuế thu nhập cá nhân còn phải nộp [40] = ([38] – [36] – [39]) > 0", "40", "VNĐ", True),
             ("6", "Tổng số thuế thu nhập cá nhân đã nộp thừa [41] = ([38] – [36] – [39]) < 0", "41", "VNĐ", True)]

    def bang(r, ds):
        for stt, ten, ma, dvt, dam in ds:
            ws.dong(r, 1, [(stt, K["cg"]), (ten, K["cb"] if dam else K["c"]), ("[%s]" % ma, K["cg"]), (dvt, K["cg"]),
                           (ct[ma], K["nb"] if dam else K["n"])])
            if len(ten) > 60:
                ws.cao(r, 15 * ((len(ten) + 59) // 60))
            r += 1
        return r
    r = bang(r, dong1)
    r += 1
    ws.gop(r, 1, r, 5, "II. NGHĨA VỤ QUYẾT TOÁN THAY CHO CÁ NHÂN", K["b"])
    r += 1
    ws.gop(r, 1, r, 5, "Đơn vị tiền: Đồng Việt Nam", K["dvt"])
    r += 1
    ws.dong(r, 1, ["STT", "Chỉ tiêu", "Mã chỉ tiêu", "Đơn vị tính", "Số người/Số tiền"], K["h"])
    r += 1
    r = bang(r, dong2)
    r += 1
    _ky_ten(ws, K, r, rong, dl, kq["nam"])
    ws.in_trang(ngang=False)
    return ws


# cot phu luc 05-1 (theo mau HTKK): (tieu de nhom, tieu de cot, ma, rong, khoa)
COT_BK1 = [(None, "STT", "[06]", 5, "stt"), (None, "Họ và tên", "[07]", 24, "ten"), (None, "Mã số thuế", "[08]", 14, "ct08"),
           (None, "Người nước ngoài hoặc người Việt Nam sống ở nước ngoài không có mã định danh", "", 11, "nn"),
           (None, "Loại giấy tờ", "[09a]", 17, "ten_gt"), (None, "Số CCCD/SĐDCN/Hộ chiếu (trường hợp chưa đăng ký thuế)", "[09]", 14, "ct09"),
           (None, "Cá nhân uỷ quyền quyết toán thay", "[10]", 9, "uq"), (None, "CN nước ngoài ủy quyền quyết toán dưới 12 tháng", "[11]", 9, "c11"),
           ("Thu nhập chịu thuế (TNCT)", "Tổng thu nhập chịu thuế", "[12]", 14, "12"),
           ("Thu nhập chịu thuế (TNCT)", "Trong đó: TNCT tại tổ chức trước khi điều chuyển (trường hợp có đánh dấu vào chỉ tiêu [04] tại Tờ khai 05/QTT-TNCN)", "[13]", 13, "13"),
           ("Thu nhập chịu thuế (TNCT)", "Trong đó: thu nhập chịu thuế được miễn theo Hiệp định", "[14]", 12, "14"),
           ("Thu nhập chịu thuế (TNCT)", "Trong đó: thu nhập chịu thuế được miễn theo quy định của Hợp đồng dầu khí", "[15]", 12, "15"),
           ("Thu nhập chịu thuế (TNCT)", "Thu nhập miễn thuế thu nhập cá nhân theo các Nghị quyết", "[15.1]", 12, "15.1"),
           ("Các khoản giảm trừ", "Số lượng NPT tính giảm trừ", "[16]", 9, "16"), ("Các khoản giảm trừ", "Tổng số tiền giảm trừ gia cảnh", "[17]", 14, "17"),
           ("Các khoản giảm trừ", "Từ thiện, nhân đạo, khuyến học", "[18]", 12, "18"), ("Các khoản giảm trừ", "Bảo hiểm được trừ", "[19]", 13, "19"),
           ("Các khoản giảm trừ", "Quĩ hưu trí tự nguyện được trừ", "[20]", 12, "20"),
           (None, "Thu nhập tính thuế ([21]= [12]-[14]-[15]-[15.1]-[17]-[18]-[19]-[20])", "[21]", 14, "21"),
           ("Số thuế TNCN đã khấu trừ", "Tổng số thuế TNCN đã khấu trừ", "[22]", 13, "22"),
           ("Số thuế TNCN đã khấu trừ", "Trong đó: số thuế đã khấu trừ tại tổ chức trước khi điều chuyển (trường hợp có đánh dấu vào chỉ tiêu [04] tại Tờ khai 05/QTT-TNCN)", "[23]", 13, "23"),
           ("Chi tiết kết quả quyết toán thay cho cá nhân nộp thuế", "Tổng số thuế phải nộp", "[24]", 12, "24"),
           ("Chi tiết kết quả quyết toán thay cho cá nhân nộp thuế", "Số thuế đã nộp thừa", "[25]", 12, "25"),
           ("Chi tiết kết quả quyết toán thay cho cá nhân nộp thuế", "Số thuế còn phải nộp", "[26]", 12, "26"),
           (None, "Cá nhân có số thuế được miễn do có số thuế còn phải nộp từ 50.000 đồng trở xuống", "[27]", 12, "ct27")]
COT_BK2 = [(None, "STT", "[06]", 5, "stt"), (None, "Họ và tên", "[07]", 24, "ten"), (None, "Mã số thuế", "[08]", 14, "ct08"),
           (None, "Người nước ngoài hoặc người Việt Nam sống ở nước ngoài không có mã định danh", "", 11, "nn"),
           (None, "Loại giấy tờ", "[09a]", 17, "ten_gt"), (None, "Số định danh cá nhân/CCCD/Hộ chiếu", "[09]", 14, "ct09"),
           (None, "Cá nhân không cư trú", "[10]", 9, "kct"),
           ("Thu nhập chịu thuế (TNCT)", "Tổng số", "[11]", 15, "11"),
           ("Thu nhập chịu thuế (TNCT)", "Trong đó: TNCT từ phí mua BH nhân thọ, BH không bắt buộc khác của DN BH không thành lập tại Việt Nam cho người lao động", "[12]", 16, "12"),
           (None, "Trong đó thu nhập chịu thuế được miễn theo Hiệp định", "[13]", 14, "13"),
           (None, "Trong đó TN chịu thuế được miễn theo quy định của Hợp đồng dầu khí", "[14]", 14, "14"),
           (None, "Thu nhập miễn thuế thu nhập cá nhân theo các Nghị quyết", "[14.1]", 14, "14.1"),
           ("Số thuế thu nhập cá nhân (TNCN) đã khấu trừ", "Tổng số", "[15]", 14, "15"),
           ("Số thuế thu nhập cá nhân (TNCN) đã khấu trừ", "Trong đó: Số thuế từ phí mua BH nhân thọ, BH không bắt buộc khác của DN BH không thành lập tại Việt Nam cho người lao động", "[16]", 16, "16")]


def _bang_pl(ws, K, r, cot, ds, tong, gia_tri):
    """ghi bang phu luc 2 tang tieu de + dong ma chi tieu + du lieu + dong Tong."""
    n = len(cot)
    i = 0
    while i < n:
        nhom = cot[i][0]
        if nhom is None:
            ws.gop(r, i + 1, r + 1, i + 1, cot[i][1], K["h"])
            i += 1
            continue
        j = i
        while j + 1 < n and cot[j + 1][0] == nhom:
            j += 1
        ws.gop(r, i + 1, r, j + 1, nhom, K["h"])
        for k in range(i, j + 1):
            ws.o(r + 1, k + 1, cot[k][1], K["h"])
        i = j + 1
    ws.cao(r, 30)
    ws.cao(r + 1, 110)
    for k, c in enumerate(cot):
        ws.o(r + 2, k + 1, c[2], K["hm"])
    r += 3
    dau = r
    for stt, x in enumerate(ds, 1):
        for k, c in enumerate(cot):
            v = gia_tri(x, c[4], stt)
            if isinstance(v, str):
                ws.o(r, k + 1, v, K["txt"] if c[4] in ("ct08", "ct09") else (K["cg"] if c[4] in ("stt", "nn", "uq", "c11", "ct27", "kct") else K["c"]))
            else:
                ws.o(r, k + 1, v, K["n"])
        r += 1
    ws.gop(r, 1, r, 8 if cot is COT_BK1 else 7, "Tổng", K["cb"])
    for k, c in enumerate(cot):
        if c[4] in tong:
            ws.o(r, k + 1, tong[c[4]], K["nb"])
        elif k >= (8 if cot is COT_BK1 else 7):
            ws.o(r, k + 1, None, K["nb"])
    ws.in_trang(ngang=True, lap_dong=(dau - 3, dau - 1))
    return r + 1


def _gia_tri_bk1(r, khoa, stt):
    dd = r["dd"]
    if khoa == "stt":
        return str(stt)
    if khoa == "ten":
        return r["ten"]
    if khoa in ("ct08", "ct09", "ten_gt"):
        return dd[khoa]
    if khoa == "nn":
        return "x" if dd["nn"] else ""
    if khoa == "uq":
        return "x" if r.get("uq") else ""
    if khoa == "c11":
        return ""
    if khoa == "ct27":
        return "x" if r.get("ct27") else ""
    if khoa == "kct":
        return "x" if r.get("khong_cu_tru") else ""
    return r["ct"].get(khoa, 0)


def _sheet_pl1(wb, K, kq, dl):
    dn = _dn(dl)
    rong = [c[3] for c in COT_BK1]
    ws = wb.sheet("05-1", cot=rong)
    r = _dau_trang(ws, K, rong, "05-1/BK-QTT-TNCN", kq["nam"], dn,
                   "BẢNG KÊ CHI TIẾT CÁ NHÂN THUỘC DIỆN TÍNH THUẾ THEO BIỂU LŨY TIẾN TỪNG PHẦN")
    ws.gop(r, len(COT_BK1) - 4, r, len(COT_BK1), "Đơn vị tiền: Đồng Việt Nam", K["dvt"])
    r += 1
    tong = {ct: kq["tong1"][tg] for tg, ct in CT_BK1_TONG}
    tong["ct27"] = kq["tong1"]["43"]
    r = _bang_pl(ws, K, r, COT_BK1, kq["ds1"], tong, _gia_tri_bk1)
    ws.gop(r, 1, r, len(COT_BK1), "(TNCT: Thu nhập chịu thuế; TNCN: thu nhập cá nhân; NPT: người phụ thuộc; SĐDCN: Số định danh cá nhân)", K["ghi"])
    _ky_ten(ws, K, r + 2, rong, dl, kq["nam"])
    ws.dong_bang(r - len(kq["ds1"]) - 1, 3)
    return ws


def _sheet_pl2(wb, K, kq, dl):
    dn = _dn(dl)
    rong = [c[3] for c in COT_BK2]
    ws = wb.sheet("05-2", cot=rong)
    r = _dau_trang(ws, K, rong, "05-2/BK-QTT-TNCN", kq["nam"], dn,
                   "BẢNG KÊ CHI TIẾT CÁ NHÂN THUỘC DIỆN TÍNH THUẾ THEO THUẾ SUẤT TOÀN PHẦN")
    ws.gop(r, len(COT_BK2) - 3, r, len(COT_BK2), "Đơn vị tiền: Đồng Việt Nam", K["dvt"])
    r += 1
    tong = {ct: kq["tong2"][tg] for tg, ct in CT_BK2_TONG}
    r = _bang_pl(ws, K, r, COT_BK2, kq["ds2"], tong, _gia_tri_bk1)
    ws.gop(r, 1, r, len(COT_BK2), "(BH: Bảo hiểm; DN: doanh nghiệp; CMND: Chứng minh nhân dân; CCCD: Căn cước công dân)", K["ghi"])
    _ky_ten(ws, K, r + 2, rong, dl, kq["nam"])
    return ws


def _sheet_pl3(wb, K, kq, dl):
    dn = _dn(dl)
    cot = [("STT", "[06]", 5), ("Họ và tên người nộp thuế là người lao động tại tổ chức trả thu nhập", "[07]", 22),
           ("MST của người nộp thuế là người lao động tại tổ chức trả thu nhập", "[08]", 15), ("Họ và tên người phụ thuộc", "[09]", 22),
           ("Ngày sinh người phụ thuộc", "[10]", 12), ("MST của người phụ thuộc", "[11]", 14),
           ("Loại giấy tờ (Số định danh cá nhân/CCCD/Hộ chiếu) người phụ thuộc", "[12]", 16), ("Số giấy tờ", "[13]", 15),
           ("Quan hệ với người nộp thuế", "[14]", 14), ("Từ tháng", "[15]", 10), ("Đến tháng", "[16]", 10)]
    ws = wb.sheet("05-3", cot=[c[2] for c in cot])
    r = _dau_trang(ws, K, [c[2] for c in cot], "05-3/BK-QTT-TNCN", kq["nam"], dn, "BẢNG KÊ CHI TIẾT NGƯỜI PHỤ THUỘC GIẢM TRỪ GIA CẢNH")
    ws.dong(r, 1, [c[0] for c in cot], K["h"])
    ws.cao(r, 60)
    ws.dong(r + 1, 1, [c[1] for c in cot], K["hm"])
    r += 2
    nam = kq["nam"]
    stt = 0
    for x in kq["ds1"]:
        for p in x["npt_ds"]:
            stt += 1
            gt = dinh_danh(p["mst"], p["cccd"], "", nam)
            ws.dong(r, 1, [(str(stt), K["cg"]), (x["ten"], K["c"]), (x["dd"]["ct08"], K["txt"]), (p["ten"], K["c"]), (p["ngay_sinh"], K["cg"]),
                           (gt["ct08"] if gt["ct08"] != gt["ct09"] else "", K["txt"]), (gt["ten_gt"], K["c"]), (gt["ct09"], K["txt"]),
                           (p["quan_he"], K["c"]), ("%02d/%d" % (p["tu"], nam) if p["tu"] else "", K["cg"]),
                           ("%02d/%d" % (p["den"], nam) if p["den"] else "", K["cg"])])
            r += 1
    ws.gop(r, 1, r, len(cot), "(MST: Mã số thuế; CMND: Chứng minh nhân dân; CCCD: Căn cước công dân, GKS: Giấy khai sinh)", K["ghi"])
    ws.in_trang(ngang=True)
    return ws


def _sheet_chi_tiet(wb, K, kq):
    """chi tiet tung thang / ky (de anh doi chieu bang luong): TNCT, BH, NPT, thue bang luong, thue theo bieu thang."""
    nam = kq["nam"]
    ts = kq["ts"]
    ws = wb.sheet("Chi tiet thang", cot=[6, 26, 8, 12, 16, 14, 8, 16, 16, 16, 14, 16, 16])
    ws.gop(1, 1, 1, 13, "CHI TIẾT THU NHẬP - THUẾ TNCN THEO THÁNG NĂM %d (số liệu lập tờ khai)" % nam, K["qh"])
    ws.gop(2, 1, 2, 13, "Nguồn: %s. Giảm trừ bản thân %s, NPT %s đồng/tháng. %s" % (
        kq.get("nguon_mo_ta") or kq["nguon"], _vn(ts["gt_ban_than"]), _vn(ts["gt_npt"]), ts["can_cu"]), K["ghi"])
    ws.cao(2, 45)
    hd = ["STT", "Họ và tên", "Bảng kê", "Tháng / kỳ", "Tổng thu nhập chịu thuế", "Bảo hiểm bắt buộc NLĐ", "Số NPT", "Thu nhập tính thuế tháng",
          "Thuế đã khấu trừ (bảng lương)", "Thuế tạm tính theo biểu tháng", "Chênh lệch", "Thu nhập tính thuế cả năm [21]",
          "Thuế TNCN cả năm theo biểu năm (tham khảo QT)"]
    ws.dong(4, 1, hd, K["h"])
    ws.cao(4, 45)
    r = 5
    stt = 0
    for loai, ds in (("05-1", kq["ds1"]), ("05-2", kq["ds2"])):
        for x in ds:
            stt += 1
            tong = [0, 0, 0, 0, 0]
            for m in x["thang"]:
                d = x["chi_tiet"][m]
                tn, bh, th = lam_tron(d["tn"]), lam_tron(d["bh"]), lam_tron(d["thue"])
                la_thang = 1 <= m <= 12
                npt = (d["sothang"] if d["nguon"] == "PM" else x["gc"][m]) if la_thang else ""
                if loai == "05-1" and la_thang:
                    tntt = max(0, tn - bh - ts["gt_ban_than"] - ts["gt_npt"] * npt - lam_tron(d["tu_thien"]))
                    tt = thue_luy_tien(tntt, nam, 1)
                elif la_thang:
                    tntt, tt = 0, th
                else:
                    tntt, tt = "", ""
                nhan = ("%02d" % m if la_thang else ten_ky(m).capitalize()) + ("" if d["nguon"] == "PM" else " (Excel)")
                ws.dong(r, 1, [("", K["cg"]), ("", K["c"]), (loai, K["cg"]), (nhan, K["cg"]),
                               (tn, K["n"]), (bh, K["n"]), (npt, K["n"]), (tntt, K["n"]), (th, K["n"]), (tt, K["n"]),
                               ((th - tt) if tt != "" else "", K["n"]), ("", K["n"]), ("", K["n"])])
                tong = [tong[0] + tn, tong[1] + bh, 0, tong[3] + th, tong[4] + (tt if tt != "" else th)]
                r += 1
            ws.dong(r, 1, [(str(stt), K["cg"]), (x["ten"], K["cb"]), (loai, K["cg"]), ("Cả năm", K["cb"]), (tong[0], K["nb"]), (tong[1], K["nb"]),
                           ("", K["nb"]), ("", K["nb"]), (tong[3], K["nb"]), (tong[4], K["nb"]), (tong[3] - tong[4], K["nb"]),
                           (x["ct"]["21"] if loai == "05-1" else "", K["nb"]), (x.get("thue_nam", "") if loai == "05-1" else "", K["nb"])])
            r += 1
    ws.gop(r + 1, 1, r + 1, 13, "Thuế tạm tính theo biểu tháng chỉ để đối chiếu thuế khấu trừ hằng tháng (kỳ nhiều tháng / cả năm của bảng "
                                "lương Excel không tách tháng - lấy bằng số đã khấu trừ); bảng kê [22] kê số thuế ĐÃ khấu trừ theo bảng lương. "
                                "Thuế quyết toán năm (nếu ủy quyền) tính trên thu nhập tính thuế cả năm [21].", K["ghi"])
    ws.cao(r + 1, 30)
    ws.dong_bang(5, 3)
    ws.in_trang(ngang=True, lap_dong=(4, 4))
    return ws


def _sheet_doi_chieu(wb, K, kq, cb):
    ws = wb.sheet("Doi chieu", cot=[60, 20, 20, 18, 12])
    ws.gop(1, 1, 1, 5, "KIỂM CHÉO TỜ KHAI 05/QTT-TNCN NĂM %d VỚI SỔ KẾ TOÁN" % kq["nam"], K["qh"])
    ws.gop(2, 1, 2, 5, "Nguồn số liệu: %s" % (kq.get("nguon_mo_ta") or "-"), K["ghi"])
    ws.cao(2, 30)
    ws.dong(3, 1, ["Nội dung", "Số tờ khai", "Số đối chiếu", "Chênh lệch", "Kết quả"], K["h"])
    r = 4
    for d in kq["doi_chieu"]:
        b = d["b"]
        kieu = d.get("kieu", "bang")
        if d["lech"]:
            kq_ = "LỆCH" if kieu == "bang" else "SAI"
        elif b is None:
            kq_ = "-"
        elif kieu == "tk":
            kq_ = "Bằng" if d["a"] == b else "Khác"
        else:
            kq_ = "Khớp" if kieu == "bang" else "Đúng"
        ws.dong(r, 1, [(d["ten"], K["c"]), (d["a"], K["n"]), (b if b is not None else "", K["n"] if b is not None else K["c"]),
                       ((d["a"] - b) if (b is not None and kieu != "le") else "", K["n"] if (b is not None and kieu != "le") else K["c"]),
                       (kq_, K["cg"])])
        r += 1
    if kq.get("theo_thang"):
        r += 1
        ws.dong(r, 1, ["Theo tháng: tổng thu nhập bảng lương / phát sinh Có TK 334 trong sổ", "Bảng lương", "PS Có TK 334", "Chênh lệch",
                       "Kết quả"], K["h"])
        r += 1
        for m, bl, ps in kq["theo_thang"]:
            ws.dong(r, 1, [("Tháng %02d/%d" % (m, kq["nam"]), K["c"]), (bl, K["n"]), (ps, K["n"]), (bl - ps, K["n"]),
                           ("Khớp" if bl == ps else ("Chưa HT" if not ps else "Lệch"), K["cg"])])
            r += 1
    r += 1
    ws.gop(r, 1, r, 5, "Cảnh báo / ghi chú khi lập:", K["b"])
    r += 1
    for c in cb:
        ws.gop(r, 1, r, 5, "- " + c, K["ghi"])
        ws.cao(r, 15 * max(1, (len(c) + 139) // 140))
        r += 1
    ws.in_trang(ngang=False)
    return ws


def lap_excel(dl, kq, duong, cb):
    from xlsx_viet import SoExcel
    wb = SoExcel(font="Times New Roman", co=11)
    K = _kieu(wb)
    _sheet_05(wb, K, kq, dl)
    if kq["ds1"]:
        _sheet_pl1(wb, K, kq, dl)
    if kq["ds2"]:
        _sheet_pl2(wb, K, kq, dl)
    if kq["npt"]:
        _sheet_pl3(wb, K, kq, dl)
    _sheet_chi_tiet(wb, K, kq)
    _sheet_doi_chieu(wb, K, kq, cb)
    wb.luu(duong)
    return duong


# ------------------------------------------------------------------ Bang ke "Tai bang ke" cua HTKK
BK_SHEET = "05-1BK-QTT-TNCN"
BK_DONG_DAU = 6
BK_RONG = [6, 6, 26.71, 21.57, 21.57, 18.29, 7.57, 7.57] + [17.71] * 10 + [15.86] + [17.0] * 5 + [17.86, 9.14, 11.0]
BK_HDSD = [
    ("STT", "Tên trường", "Kiểu dữ liệu", "Cell", "Mô Tả", "Thuộc tính", "Ràng buộc"),
    (1, "[06]STT", "Num(20)", "A22:A65534", "Số thứ tự", "Tự động tăng", "Giá trị lớn hơn 0. Cho phép tối đa 20 chữ số"),
    (2, "[07] Họ và tên", "Char(100)", "B6:B65534", "Họ tên của người lao động", "Bắt buộc nhập", "Cho phép tối đa 100 kí tự"),
    (3, "[08] Mã số thuế", "Char(10)", "C6:C65534", "Mã số thuế", "Không bắt buộc", "Cho phép nhập.  Nếu tích chọn [10] hoặc [11] thì bắt buộc nhập"),
    (None, "Người nước ngoài hoặc người Việt Nam sống ở nước ngoài không có mã định danh", "Checkbox", None,
     "Người nước ngoài hoặc người Việt Nam sống ở nước ngoài không có mã định danh", "Không bắt buộc", "Nếu tích chọn ghi \"x\""),
    (4, "[09a] Loại giấy tờ", "Combobox", None, "Loại giấy tờ", "Không bắt buộc",
     "Bắt buộc nhập nếu để trống chỉ tiêu [08]\n- Nếu không tích \"Người nước ngoài hoặc người Việt Nam sống ở nước ngoài không có mã định danh\" "
     "thì kê khai loại giấy tờ là \"Thẻ CCCD/Số định danh cá nhân\"\n- Nếu tích \"Người nước ngoài hoặc người Việt Nam sống ở nước ngoài không có "
     "mã định danh\" thì kê khai loại giấy tờ là \"Hộ chiếu\""),
    (5, "[09] Số CMND/CCCD/Số ĐDCN/Hộ chiếu", "Char(60)", "D6:D65534", "Số CMND/Hộ chiếu (nếu chưa có MST)", "Không bắt buộc",
     "Cho phép tối đa 60 kí tự, bắt buộc nhập nếu không có mã số thuế"),
    (6, "[10]Cá nhân ủy quyền quyết toán thay", "Checkbox", "E6:E65534", "Ủy quyền quyết toán thay hay không", "Không bắt buộc", "=1 Nếu chọn, =0 nếu không muốn chọn"),
    (7, "[11] CN nước ngoài ủy quyền quyết toán dưới 12 tháng", "Checkbox", "E6:E65534", "CN nước ngoài ủy quyền quyết toán dưới 12 tháng", "Không bắt buộc",
     "=1 Nếu chọn, =0 nếu không muốn chọn"),
    (8, "Thu nhập chịu thuế", None, None, None, None, None),
    (9, "[12] Tổng số", "Num(20)", "F6:F65534", "Tổng thu nhập chịu thuế", "Không bắt buộc", "Cho phép nhập giá trị dạng số nguyên, lớn hơn hoặc bằng 0, tối đa 20 chữ số "),
    (10, "[13] Trong đó: TNCT tại tổ chức trước khi điều chuyển (trường hợp có đánh dấu vào chỉ tiêu [04] tại Tờ khai 05/QTT-TNCN)", "Num(20)", "G6:G65534",
     "Trong đó: TNCT tại tổ chức trước khi điều chuyển (trường hợp có đánh dấu vào chỉ tiêu [04] tại Tờ khai 05/QTT-TNCN)", "Không bắt buộc",
     "Cho phép nhập giá trị dạng số nguyên, lớn hơn hoặc bằng 0, tối đa 20 chữ số "),
    (11, "[14] Trong đó: TNCT làm căn cứ tính giảm thuế\nTheo Hiệp định", "Num(20)", "H6:H65534", "Trong đó: TNCT làm căn cứ tính giảm thuế\nTheo Hiệp định",
     "Không bắt buộc", "Cho phép nhập giá trị dạng số nguyên, lớn hơn hoặc bằng 0, tối đa 20 chữ số "),
    (12, "[15] Trong đó: thu nhập chịu thuế được miễn theo quy định của Hợp đồng dầu khí", "Num(20)", "H6:H65534",
     "Trong đó: thu nhập chịu thuế được miễn theo quy định của Hợp đồng dầu khí", "Không bắt buộc",
     "Cho phép nhập giá trị dạng số nguyên, lớn hơn hoặc bằng 0, tối đa 20 chữ số "),
    (None, "[15.1] Thu nhập miễn thuế, thu nhập cá nhân theo nghị quyết", "Num(20)", "J6:J65534", "Thu nhập miễn thuế, thu nhập cá nhân theo nghị quyết",
     "Không bắt buộc", "Thu nhập miễn thuế, thu nhập cá nhân theo nghị quyết"),
    (13, "Các khoản giảm trừ", None, None, None, None, None),
    (14, "[16] Số lượng NPT tính giảm trừ", "Num(20)", "I6:I65534", "Số lượng NPT tính giảm trừ", "Không bắt buộc", "Không nhập. UD sẽ tự động tính"),
    (15, "[17] Tổng số tiền giảm trừ gia cảnh", "Num(20)", "J6:J65534", "Tổng số tiền giảm trừ gia cảnh", "Không bắt buộc", "Tổng số tiền giảm trừ gia cảnh"),
    (16, "[18] Từ thiện, nhân đạo, khuyến học", "Num(20)", "K6:K65534", "Số tiền từ thiện, nhân đạo", "Không bắt buộc",
     "Cho phép nhập giá trị dạng số nguyên, lớn hơn hoặc bằng 0, tối đa 20 chữ số "),
    (17, "[19] Bảo hiểm được trừ", "Num(20)", "L6:L65534", "Bảo hiểm được trừ", "Không bắt buộc", "Cho phép nhập giá trị dạng số nguyên, lớn hơn hoặc bằng 0, tối đa 20 chữ số "),
    (18, "[20] Quĩ hưu trí tự nguyện được trừ", "Num(20)", "M6:M65534", "Quĩ hưu trí tự nguyện được trừ", "Không bắt buộc", "Giá trị lớn hơn 0. Cho phép tối đa 20 chữ số"),
    (19, "[21] Thu nhập tính thuế", "Num(20)", "N6:N65535", "Thu nhập tính thuế", "Không bắt buộc", "Không nhập. UD sẽ tự động tính"),
    (20, "Số thuế TNCN đã khấu trừ", None, None, None, None, None),
    (21, "[22] Số thuế TNCN đã khấu trừ", "Num(20)", "O6:O65536", "Số thuế đã khấu trừ", "Không bắt buộc", "Cho phép nhập giá trị dạng số nguyên, lớn hơn hoặc bằng 0, tối đa 20 chữ số "),
    (22, "[23] Trong đó: số thuế đã khấu trừ tại tổ chức trước khi điều chuyển ", "Num(20)", "O6:O65536",
     "Trong đó: số thuế đã khấu trừ tại tổ chức trước khi điều chuyển ", "Không bắt buộc", "Cho phép nhập giá trị dạng số nguyên, lớn hơn hoặc bằng 0, tối đa 20 chữ số "),
    (23, "Chi tiết kết quả quyết toán thay cho cá nhân nộp thuế", None, None, None, None, None),
    (24, "[24]Tổng số thuế \nphải nộp", "Num(20)", "R6:R65534", "Tổng số thuế phải nộp tính lại theo biểu thuế lũy tiến", "Không bắt buộc", "Không nhập. UD sẽ tự động tính"),
    (25, "[25] Số thuế đã nộp thừa", "Num(20)", "S6:S65534", "Số thuế đã nộp thừa sau khi tính lại thuế", "Không bắt buộc", "Không nhập. UD sẽ tự động tính"),
    (26, "[26] Số thuế còn phải nộp", "Num(20)", "T6:T65534", "Số thuế còn phải nộp sau khi tính lại thuế ", "Không bắt buộc", "Không nhập. UD sẽ tự động tính"),
    (27, "[27] Cá nhân có số thuế được miễn do có số thuế còn phải nộp từ 50.000 đồng trở xuống", "Checkbox", "S6:S65534",
     "Cá nhân có số thuế được miễn do có số thuế còn phải nộp từ 50.000 đồng trở xuống", "Không bắt buộc", "=1 Nếu chọn, =0 nếu không muốn chọn"),
    (28, "Mã loại giấy tờ", "Char", None, "Mã loại giấy tờ không sửa", "Không bắt buộc", "Khi chọn loại giấy tờ [09a] sẽ ra mã")]
BK_HEADER_LOI = [
    (1, 0, "Mã số thuế bắt buộc phải nhập và nhập đầy đủ 10 số đầu.", 2), (1, 0, "Số chứng minh thư bị trùng lặp với cá nhân khác.", 3),
    ("1", "2008", "Kỳ tính thuế bắt buộc phải nhập.", 4), (1, 0, "Mã số thuế hoặc số giấy tờ bắt buộc phải nhập.", 41),
    (1, 0, "Mã số thuế bắt buộc phải nhập.", 40), ("1", 0, "Mã số thuế cơ quan chi trả bắt buộc phải nhập.", 1),
    (1, 0, "Mã số thuế sai cấu trúc", 19), ("1", 0, "Tên tổ chức, cá nhân trả thu nhập bắt buộc phải nhập.", 6),
    ("1", 0, "Địa chỉ bắt buộc phải nhập.", 7), ("1", "x", "Chọn một trong hai loại tờ khai.", 8), ("1", 0, "Lần phải được nhập.", 9),
    ("1", 1, "Tính sai chỉ tiêu [08].", 20), ("1", 13, "Tính sai chỉ tiêu [09].", 21), ("1", 1, "Tính sai chỉ tiêu [10].", 22),
    ("1", 13, "Tính sai chỉ tiêu [11].", 23), ("1", 7, "Tính sai chỉ tiêu [12].", 24), ("1", 9, "Tính sai chỉ tiêu [13].", 25),
    ("1", 1, "Tính sai chỉ tiêu [14].", 26), ("1", 1, "Tính sai chỉ tiêu [15].", 27), ("1", 0, "Tính sai chỉ tiêu [16].", 28),
    ("1", 3242, "Tính sai chỉ tiêu [17].", 29), ("1", 3242, "Tính sai chỉ tiêu [18].", 30), ("1", 0, "Tính sai chỉ tiêu [19].", 31),
    ("1", 34, "Tính sai chỉ tiêu [20].", 32), ("1", 34, "Tính sai chỉ tiêu [21].", 33), ("1", 0, "Tính sai chỉ tiêu [22].", 34)]


def lap_bang_ke(dl, kq, duong):
    """Bang ke 05-1 dung mau nhap cua HTKK (InterfaceTemplates\\excel\\Bang_Ke_05_1_QTT_TT80.xlsx): sheet 05-1BK-QTT-TNCN,
    tieu de dong 2-5 (gop o nhu mau), du lieu tu dong 6: B STT, C [07], D [08], E [09a], F [09], G [10], H [11], I [12], J [13],
    K [14], L [15], M [15.1], N [16] (HTKK tu tinh - de trong), O [17], P [18], Q [19], R [20], S [21] (tu tinh), T [22], U [23],
    V-X [24]-[26] (tu tinh), Y [27], Z ma loai giay to, AA nguoi nuoc ngoai ("x"). Sheet HDSD, Data, Header (an) nhu mau."""
    from xlsx_viet import SoExcel
    wb = SoExcel(font="Arial", co=10)
    X_NEN, X_XANH, X_NHAT = "CCFFCC", "DCE6F1", "DEF3F7"
    h = wb.kieu(dam=True, co=8, font="Arial", nen=X_NEN, khung=True, can="giua", doc="giua", xuong=True, so="@")
    h1 = wb.kieu(dam=True, co=8, font="Arial", nen=X_NEN, khung=True, can="giua", doc="giua", so="@")
    stt = wb.kieu(co=8, font="Arial", khung=True, can="giua", doc="tren")
    txt = wb.kieu(co=8, font="Arial", khung=True, can="trai", doc="tren", so="@")
    so = wb.kieu(co=8, font="Arial", khung=True, can="phai", doc="tren", so="#,##0")
    so_tt = wb.kieu(co=8, font="Arial", khung=True, can="phai", doc="tren", so="#,##0", nen=X_XANH)
    chk = wb.kieu(co=10, font="Arial", khung=True, can="giua", doc="tren")
    chk_tt = wb.kieu(co=8, font="Arial", khung=True, can="giua", doc="giua", nen=X_XANH)
    ma_gt = wb.kieu(co=8, font="Arial", khung=True, can="trai", doc="tren", nen=X_NHAT, so="@")
    ws = wb.sheet(BK_SHEET, cot=BK_RONG)
    ws.an_cot(1)
    ws.luoi(True)
    ws.cao(1, 12.75)
    ws.cao(2, 22.5)
    ws.cao(3, 16.5)
    ws.cao(4, 57)
    ws.cao(5, 16.5)
    ma = ["[06]", "[07]", "[08]", "[09a]", "[09]", "[10]", "[11]", "[12]", "[13]", "[14]", "[15]", "[15.1]", "[16]", "[17]", "[18]", "[19]",
          "[20]", "[21]", "[22]", "[23]", "[24]", "[25]", "[26]", "[27]"]
    don = [(2, "STT"), (3, "Họ và tên (*)"), (4, "Mã số thuế"), (5, "Loại giấy tờ"), (6, "Số CMND/CCCD/Số ĐDCN/Hộ chiếu (trường hợp chưa có MST)"),
           (7, "Cá nhân uỷ quyền quyết toán thay"), (8, "CN nước ngoài ủy quyền quyết toán dưới 12 tháng"), (19, "Thu nhập tính\n thuế"),
           (25, "Cá nhân có số thuế được miễn do có số thuế còn phải nộp từ 50.000 đồng trở xuống")]
    for c, v in don:
        ws.gop(2, c, 4, c, v, h)
    ws.gop(2, 26, 5, 26, "Mã loại giấy tờ", h)
    ws.gop(2, 27, 5, 27, "Người nước ngoài hoặc người Việt Nam sống ở nước ngoài không có mã định danh", h)
    ws.gop(2, 9, 2, 13, "Thu nhập chịu thuế", h1)
    ws.gop(2, 14, 2, 18, "Các khoản giảm trừ", h)
    ws.gop(2, 20, 2, 21, "Số thuế TNCN đã khấu trừ", h)
    ws.gop(2, 22, 2, 24, "Chi tiết kết quả quyết toán thay cho cá nhân nộp thuế", h)
    con = [(9, "Tổng số"), (10, "Trong đó: TNCT tại tổ chức trước khi điều chuyển (trường hợp có đánh dấu vào chỉ tiêu [04] tại Tờ khai 05/QTT-TNCN)"),
           (11, "Trong đó: thu nhập chịu thuế được miễn theo Hiệp định"), (12, "Trong đó: thu nhập chịu thuế được miễn theo quy định của Hợp đồng dầu khí"),
           (13, "Thu nhập miễn thuế thu nhập cá nhân theo các Nghị quyết"), (14, "Số lượng NPT tính giảm trừ"), (15, "Tổng số tiền  giảm trừ gia cảnh"),
           (16, "Từ thiện, nhân đạo, khuyến học"), (17, "Bảo hiểm được trừ"), (18, "Quĩ hưu trí tự nguyện được trừ"), (20, "Số thuế TNCN đã khấu trừ"),
           (21, "Trong đó: số thuế đã khấu trừ tại tổ chức trước khi điều chuyển (trường hợp có đánh dấu vào chỉ tiêu [04] tại Tờ khai 05/QTT"),
           (22, "Tổng số thuế phải nộp"), (23, "Số thuế đã nộp thừa"), (24, "Số thuế còn phải nộp")]
    for c, v in con:
        ws.gop(3, c, 4, c, v, h)
    for i, m in enumerate(ma):
        ws.o(5, 2 + i, m, h)
    r = BK_DONG_DAU
    for i, x in enumerate(kq["ds1"], 1):
        dd, c = x["dd"], x["ct"]
        ws.o(r, 2, i, stt)
        ws.o(r, 3, x["ten"], txt)
        ws.o(r, 4, dd["ct08"], txt)
        ws.o(r, 5, dd["ten_gt"], txt)
        ws.o(r, 6, dd["ct09"], txt)
        ws.o(r, 7, 1 if x["uq"] else None, chk)
        ws.o(r, 8, None, chk)
        for col, k in ((9, "12"), (10, "13"), (11, "14"), (12, "15"), (13, "15.1")):
            ws.o(r, col, c[k], so)
        ws.o(r, 14, None, so)                      # [16] HTKK tu tinh tu phu luc 05-3
        for col, k in ((15, "17"), (16, "18"), (17, "19"), (18, "20")):
            ws.o(r, col, c[k], so)
        ws.o(r, 19, None, so_tt)                   # [21] HTKK tu tinh
        ws.o(r, 20, c["22"], so)
        ws.o(r, 21, c["23"], so)
        for col in (22, 23, 24):                   # [24]-[26] HTKK tu tinh (chi dong uy quyen)
            ws.o(r, col, None, so_tt)
        ws.o(r, 25, 1 if x["ct27"] else None, chk_tt)
        ws.o(r, 26, dd["ma"], ma_gt)
        ws.o(r, 27, "x" if dd["nn"] else None, ma_gt)
        ws.cao(r, 16.5)
        r += 1
    cuoi = max(r - 1, BK_DONG_DAU)
    ws.in_trang(ngang=True)
    # HDSD
    hs = wb.sheet("HDSD", cot=[4.57, 31.71, 11.14, 11.71, 36.71, 16.14, 50.57])
    k_td = wb.kieu(dam=True, co=11, font="Arial", can="giua", doc="giua", xuong=True)
    k_h = wb.kieu(dam=True, co=9, font="Arial", can="giua", doc="giua", khung=True, xuong=True, nen=X_NEN)
    k_c = wb.kieu(co=9, font="Arial", khung=True, doc="tren", xuong=True)
    k_n = wb.kieu(dam=True, co=9, font="Arial", khung=True, doc="tren", xuong=True)
    hs.gop(1, 1, 1, 7, "BẢNG KÊ THU NHẬP CHỊU THUẾ VÀ THUẾ THU NHẬP CÁ NHÂN \nĐỐI VỚI THU NHẬP TỪ TIỀN LƯƠNG, TIỀN CÔNG \n"
                       "CỦA CÁ NHÂN CƯ TRÚ CÓ KÝ HỢP ĐỒNG LAO ĐỘNG", k_td)
    hs.cao(1, 48)
    for i, d in enumerate(BK_HDSD):
        rr = 2 + i
        if i == 0:
            hs.dong(rr, 1, list(d), k_h)
        elif d[2] is None:
            hs.o(rr, 1, d[0], k_c)
            hs.gop(rr, 2, rr, 7, d[1], k_n)
        else:
            hs.dong(rr, 1, list(d), k_c)
    # Data
    da = wb.sheet("Data", cot=[57.29, 8.71, 8.71, 8.71, 8.71, 8.71, 8.71, 8.71])
    for c in (4, 5, 6, 7, 8):
        da.an_cot(c)
    k_d = wb.kieu(co=10, font="Arial", so="@")
    k_dh = wb.kieu(dam=True, co=10, font="Arial", can="giua", doc="giua")
    da.gop(1, 1, 2, 1, "Danh mục loại giấy tờ", k_dh)
    da.gop(1, 2, 2, 2, "STT", k_dh)
    da.o(2, 4, "Tỷ lệ thuế GTGT", k_d)
    da.o(2, 7, "Tỷ lệ Thuế TNDN", k_d)
    for rr, (a, b, c1, c2, g1, g2) in enumerate([("Thẻ CCCD/Số định danh cá nhân", "03", "3%", 3, "1%", 1),
                                                  ("Hộ chiếu", "02", "5%", 5, "2%", 2), ("CMND", "01", None, None, None, None)], 3):
        da.dong(rr, 1, [a, b, c1, c2, None, g1, g2], k_d)
    # Header (an) - thong tin chung + bang thong bao kiem tra cua mau HTKK
    he = wb.sheet("Header", cot=[4, 26, 6] + [4] * 14 + [12, 12, 18, 30])
    dn = _dn(dl)
    mst = re.sub(r"[^0-9]", "", str(dn.get("mst") or ""))
    k_hd = wb.kieu(co=10, font="Arial", so="@")
    he.o(2, 2, "Mã số thuế", k_hd)
    for i in range(10):
        he.o(2, 3 + i, mst[i] if i < len(mst) else None, k_hd)
    he.o(2, 13, " - ", k_hd)
    for i in range(3):
        he.o(2, 14 + i, mst[10 + i] if 10 + i < len(mst) else None, k_hd)
    for rr, (a, b, c) in enumerate([("Tên cơ sở kinh doanh", dn.get("ten", ""), "Month"), ("Địa chỉ trụ sở", dn.get("dia_chi", ""), "ThreeMonths"),
                                    ("Quận/ huyện", dn.get("quan", ""), "Nguoi Ky"), ("Tỉnh/ Thành phố", dn.get("tinh", ""), "TuNgay"),
                                    ("Điện thoại", dn.get("dien_thoai", ""), "DenNgay"), ("Fax", dn.get("fax", ""), None),
                                    ("Email", dn.get("email", ""), "Nganh nghe")], 3):
        he.o(rr, 2, a, k_hd)
        he.o(rr, 3, b or None, k_hd)
        he.o(rr, 19, c, k_hd)
    he.o(2, 19, "Year", k_hd)
    he.o(2, 20, str(kq["nam"]), k_hd)
    he.o(8, 20, "1", k_hd)
    he.dong(11, 2, ["Function", "Cell"], k_hd)
    he.o(11, 5, "Infor Message", k_hd)
    he.o(11, 19, "Warning", k_hd)
    he.o(11, 20, "Order (not repeat)", k_hd)
    for i, (f, c, m, o) in enumerate(BK_HEADER_LOI):
        he.o(12 + i, 2, f, k_hd)
        he.o(12 + i, 3, c if c != 0 else None, k_hd)
        he.o(12 + i, 5, m, k_hd)
        he.o(12 + i, 19, "Y", k_hd)
        he.o(12 + i, 20, o, k_hd)
    wb.luu(duong)
    _va_bang_ke(duong, cuoi)
    return duong


def _va_bang_ke(duong, cuoi):
    """bo sung dieu xlsx_viet chua co: an sheet Header, an dong 1, danh sach chon [09a] (Data!$A$3:$A$5) nhu mau HTKK."""
    tam = duong + ".tmp"
    with zipfile.ZipFile(duong) as zi, zipfile.ZipFile(tam, "w", zipfile.ZIP_DEFLATED) as zo:
        for it in zi.infolist():
            b = zi.read(it.filename)
            if it.filename == "xl/workbook.xml":
                s = b.decode("utf-8")
                s2 = re.sub(r'(<sheet name="Header" sheetId="\d+")', r'\1 state="hidden"', s, count=1)
                if s2 == s:
                    raise RuntimeError("Bảng kê: không ẩn được sheet Header")
                b = s2.encode("utf-8")
            elif it.filename == "xl/worksheets/sheet1.xml":
                s = b.decode("utf-8")
                s2 = re.sub(r'<row r="1"( |>)', r'<row r="1" hidden="1"\1', s, count=1)
                dv = ('<dataValidations count="1"><dataValidation type="list" allowBlank="1" showInputMessage="1" showErrorMessage="1" '
                      'sqref="E%d:E%d"><formula1>Data!$A$3:$A$5</formula1></dataValidation></dataValidations>' % (BK_DONG_DAU, max(cuoi, BK_DONG_DAU + 4)))
                s2 = s2.replace("<printOptions", dv + "<printOptions", 1)
                if s2.count("<dataValidations") != 1 or 'hidden="1"' not in s2:
                    raise RuntimeError("Bảng kê: không đặt được danh sách chọn / ẩn dòng 1")
                b = s2.encode("utf-8")
            zo.writestr(it, b)
    os.replace(tam, duong)


# ------------------------------------------------------------------ lap (hop dong xuat_1_lan)
def lap(dl, ma="TNCN", kieu="EX", thumuc="."):
    kieu = (kieu or "EX").upper()
    kq = tong_hop(dl)
    cb = kq["canh_bao"]
    nam = kq["nam"]
    if not kq["ds1"] and not kq["ds2"]:
        cb.append("Không có bảng lương năm %d (BangLuong trống và chưa nhập bảng lương từ Excel) - không lập tờ khai 05/QTT-TNCN." % nam)
        return {"tep": [], "canh_bao": cb}
    tep = []
    cb.insert(0, "05/QTT-TNCN năm %d: %d người (05-1: %d, 05-2: %d), [23] TNCT %s, [31] thuế đã khấu trừ %s; %s."
              % (nam, kq["tk"]["16"], len(kq["ds1"]), len(kq["ds2"]), _vn(kq["tk"]["23"]), _vn(kq["tk"]["31"]), kq["ts"]["can_cu"]))
    if "X" in kieu:
        p = os.path.join(thumuc, "05_QTT_TNCN_TT80_%d.xml" % nam)
        goc = lap_xml_goc(dl, kq, cb)
        ghi_xml(goc, p)
        loi = kiem_xml(p)
        if loi:
            cb.append("XML tự kiểm có lỗi: %s" % "; ".join(loi[:8]))
        try:                                                     # GD328: XSD cua HTKK tren may
            import tool_htkk_unesco as X
            cach, lx = X.kiem_xsd_htkk(p, "05_QTT_TNCN_TT80")
            if cach == "xsd" and lx:
                cb.append("XML 05/QTT-TNCN CHƯA HỢP LỆ theo XSD của HTKK: %s" % "; ".join(lx[:4]))
        except Exception:
            pass
        tep.append(p)
    if "E" in kieu:
        p = os.path.join(thumuc, "05_QTT_TNCN_%d.xlsx" % nam)
        lap_excel(dl, kq, p, list(cb))
        tep.append(p)
        if kq["ds1"]:
            p = os.path.join(thumuc, "Bang_Ke_05_1_QTT_TT80_%d.xlsx" % nam)
            lap_bang_ke(dl, kq, p)
            tep.append(p)
    return {"tep": tep, "canh_bao": cb}
