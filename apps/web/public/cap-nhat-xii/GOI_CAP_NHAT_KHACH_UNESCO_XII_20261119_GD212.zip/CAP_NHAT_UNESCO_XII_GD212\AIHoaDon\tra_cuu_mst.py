# -*- coding: utf-8 -*-
"""GD212 - Tra cuu thong tin nguoi nop thue tren trang tracuunnt.gdt.gov.vn (Cuc Thue) cho cac hoa don NGUOI DUNG CHON.

Quy tac 17: phan mem KHONG doc / giai ma xac nhan (captcha). Moi lan tra cuu:
  1. /tcmst:ma  /ra:<thu muc>  -> mo trang, lay anh ma xac nhan cua phien (luu cookie phien) -> <thu muc>/tcmst_ma.bmp (VB6 hien anh)
  2. NGUOI DUNG doc anh va GO ma xac nhan tren man hinh VB6
  3. /tcmst:tra /tep:<yeu cau> /ra:<ket qua> -> gui MST + ma nguoi dung go (cung phien), doc bang ket qua, doi chieu voi hoa don.
Tep yeu cau (UTF-8):  MST=<mst> / MA=<ma nguoi dung go> / HD=<ten tren hoa don>|<dia chi tren hoa don> (nhieu dong HD duoc)
Tep ket qua (UTF-8, ';' ngan cot):
  KQ;OK|SAI_MA|KHONG_THAY|LOI;<mo ta>
  R;<mst>;<ten>;<dia chi>;<co quan thue>;<trang thai>;<khop ten K/G/L/->;<khop dia chi K/G/L/->;<dang hoat dong 1/0>;<ma NNT>
  (ma NNT theo rui_ro_hd.ma_nnt: HD / NHD / DONG / KHD / TAM / rong - VB6 ghi them vao HDDT_NNT cho soat rui ro GD153)
Chi doc trang cong khai, khong dang nhap, khong ghi so (VB6 ghi lich su tra cuu vao bang HDDT_TraCuuMST)."""
import difflib
import html as _html
import http.cookiejar
import os
import re
import struct
import unicodedata
import urllib.parse
import urllib.request
import zlib

URL_TRANG = "https://tracuunnt.gdt.gov.vn/tcnnt/mstdn.jsp"
URL_MA = "https://tracuunnt.gdt.gov.vn/tcnnt/captcha.png?uid="
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) UNESCO-AI-TraCuuMST"
TEP_COOKIE = "tcmst_phien.txt"
TEP_ANH = "tcmst_ma.bmp"
TEP_TRA_VE = "tcmst_tra_ve.html"
MST_RE = re.compile(r"^\d{10}(-\d{3})?$")


# ------------------------------------------------------------------ chu
def bo_dau(s):
    s = (s or "").replace("đ", "d").replace("Đ", "D")
    return "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")


def _sach(s, n=250):
    s = re.sub(r"\s+", " ", (s or "").replace(";", ",")).strip()
    return s[:n]


def chuan_ma(s):
    """GD217: ma xac nhan trang tracuunnt chi gom chu thuong + so -> bo khoang trang, doi chu HOA (Caps Lock / Shift) thanh thuong."""
    return re.sub(r"\s+", "", s or "").lower()


def chuan_mst(s):
    s = re.sub(r"\s+", "", s or "")
    m = re.match(r"^(\d{10})-?(\d{3})?$", s)
    if not m:
        return s
    return m.group(1) + ("-" + m.group(2) if m.group(2) else "")


VIET_TAT_TEN = [(r"\bCTY\b", "CONG TY"), (r"\bCT\b", "CONG TY"), (r"\bMTV\b", "MOT THANH VIEN"), (r"\bSX\b", "SAN XUAT"),
                (r"\bTM\b", "THUONG MAI"), (r"\bDV\b", "DICH VU"), (r"\bXD\b", "XAY DUNG"), (r"\bXNK\b", "XUAT NHAP KHAU"),
                (r"\bCP\b", "CO PHAN"), (r"\bCN\b", "CHI NHANH"), (r"\bTP\b", "THANH PHO"), (r"&", " VA "), (r"\bDNTN\b", "DOANH NGHIEP TU NHAN")]
VIET_TAT_DC = [(r"\bP\.", "PHUONG "), (r"\bQ\.", "QUAN "), (r"\bTP\.", "THANH PHO "), (r"\bTX\.", "THI XA "), (r"\bTT\.", "THI TRAN "),
               (r"\bTP\b", "THANH PHO"), (r"\bHCM\b", "HO CHI MINH"), (r"\bTPHCM\b", "THANH PHO HO CHI MINH"), (r"\bKP\b", "KHU PHO"),
               (r"\bVN\b", "VIET NAM"), (r"\bVIET NAM\b", ""), (r"\bSO\b", "")]


def chuan_ten(s):
    t = bo_dau(s).upper()
    for a, b in VIET_TAT_TEN:
        t = re.sub(a, b, t)
    return re.sub(r"[^A-Z0-9]", "", t)


def chuan_dc(s):
    t = bo_dau(s).upper()
    for a, b in VIET_TAT_DC:
        t = re.sub(a, b, t)
    return re.sub(r"[^A-Z0-9]", "", t)


def _ty_le(a, b):
    return difflib.SequenceMatcher(None, a, b).ratio() if a and b else 0.0


def khop_ten(hd, cong):
    """K = khop, G = gan khop (khac cach viet / viet tat), L = lech, - = hoa don khong co ten."""
    a, b = chuan_ten(hd), chuan_ten(cong)
    if not a:
        return "-"
    if a == b:
        return "K"
    return "G" if _ty_le(a, b) >= 0.9 else "L"


def khop_dc(hd, cong):
    """K = khop; G = gan khop / cung so nha - duong nhung khac phuong, tinh (thuong do sap xep don vi hanh chinh); L = khac; - = trong."""
    a, b = chuan_dc(hd), chuan_dc(cong)
    if not a:
        return "-"
    if a == b:
        return "K"
    if _ty_le(a, b) >= 0.85:
        return "G"
    d1 = chuan_dc((hd or "").split(",")[0])
    d2 = chuan_dc((cong or "").split(",")[0])
    if len(d1) >= 6 and d1 == d2:
        return "G"
    return "L"


def ma_nnt(tt):
    try:
        import rui_ro_hd
        return rui_ro_hd.ma_nnt(tt)
    except Exception:
        t = bo_dau(tt).upper()
        if "DANG HOAT DONG" in t:
            return "HD"
        return "TAM" if "TAM" in t else ("NHD" if "NGUNG" in t or "CHAM DUT" in t else "")


def dang_hoat_dong(tt):
    t = bo_dau(tt).upper()
    if any(k in t for k in ("NGUNG", "CHAM DUT", "TAM", "KHONG HOAT DONG", "DONG MST", "GIAI THE", "PHA SAN", "BO DIA CHI")):
        return False
    return "DANG HOAT DONG" in t


# ------------------------------------------------------------------ PNG -> BMP (VB6 LoadPicture khong doc PNG)
def png_sang_bmp(du_lieu, phong=1):
    """Giai ma PNG khong xen ke (mau xam / RGB / bang mau / co alpha, 1-8 bit) -> BMP 24 bit (nen trang cho alpha)."""
    if du_lieu[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError("khong phai PNG")
    p, idat, plte, trns = 8, [], b"", b""
    w = h = bd = ct = il = 0
    while p + 8 <= len(du_lieu):
        n, kieu = struct.unpack(">I4s", du_lieu[p:p + 8])
        noi = du_lieu[p + 8:p + 8 + n]
        p += 12 + n
        if kieu == b"IHDR":
            w, h, bd, ct, _, _, il = struct.unpack(">IIBBBBB", noi)
        elif kieu == b"PLTE":
            plte = noi
        elif kieu == b"tRNS":
            trns = noi
        elif kieu == b"IDAT":
            idat.append(noi)
        elif kieu == b"IEND":
            break
    if il:
        raise ValueError("PNG xen ke chua ho tro")
    if bd not in (1, 2, 4, 8) or (bd != 8 and ct not in (0, 3)):
        raise ValueError("PNG %d bit chua ho tro" % bd)
    kenh = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}[ct]
    bpp = max(1, kenh * bd // 8)
    hang = (w * kenh * bd + 7) // 8
    raw = zlib.decompress(b"".join(idat))
    truoc = bytearray(hang)
    px = []
    k = 0
    for _ in range(h):
        f = raw[k]
        cur = bytearray(raw[k + 1:k + 1 + hang])
        k += 1 + hang
        for i in range(hang):
            a = cur[i - bpp] if i >= bpp else 0
            b = truoc[i]
            c = truoc[i - bpp] if i >= bpp else 0
            if f == 1:
                cur[i] = (cur[i] + a) & 255
            elif f == 2:
                cur[i] = (cur[i] + b) & 255
            elif f == 3:
                cur[i] = (cur[i] + ((a + b) >> 1)) & 255
            elif f == 4:
                pa, pb, pc = abs(b - c), abs(a - c), abs(a + b - 2 * c)
                cur[i] = (cur[i] + (a if pa <= pb and pa <= pc else (b if pb <= pc else c))) & 255
        dong = []
        if bd == 8:
            for x in range(w):
                v = cur[x * kenh:(x + 1) * kenh]
                if ct == 0:
                    r = g = bb = v[0]; al = 255
                elif ct == 2:
                    r, g, bb = v[0], v[1], v[2]; al = 255
                elif ct == 3:
                    r, g, bb = plte[v[0] * 3:v[0] * 3 + 3]; al = trns[v[0]] if v[0] < len(trns) else 255
                elif ct == 4:
                    r = g = bb = v[0]; al = v[1]
                else:
                    r, g, bb, al = v[0], v[1], v[2], v[3]
                if al < 255:
                    r = (r * al + 255 * (255 - al)) // 255
                    g = (g * al + 255 * (255 - al)) // 255
                    bb = (bb * al + 255 * (255 - al)) // 255
                dong.append((r, g, bb))
        else:
            m = (1 << bd) - 1
            for x in range(w):
                bit = x * bd
                v = (cur[bit // 8] >> (8 - bd - bit % 8)) & m
                if ct == 3:
                    r, g, bb = plte[v * 3:v * 3 + 3]
                else:
                    r = g = bb = v * 255 // m
                dong.append((r, g, bb))
        px.append(dong)
        truoc = cur
    if phong > 1:                    # GD217: phong to n lan kieu diem anh (net, khong nhoe) - VB6 hien dung kich thuoc
        px = [[c for c in dong for _ in range(phong)] for dong in px for _ in range(phong)]
        w, h = w * phong, h * phong
    dem = (4 - (w * 3) % 4) % 4
    than = bytearray()
    for dong in reversed(px):
        for r, g, bb in dong:
            than += bytes((bb, g, r))
        than += b"\x00" * dem
    dau = b"BM" + struct.pack("<IHHI", 54 + len(than), 0, 0, 54) + struct.pack("<IiiHHIIiiII", 40, w, h, 1, 24, 0, len(than), 2835, 2835, 0, 0)
    return dau + bytes(than)


# ------------------------------------------------------------------ mang
def _mo(thu):
    cj = http.cookiejar.MozillaCookieJar(os.path.join(thu, TEP_COOKIE))
    if os.path.exists(cj.filename):
        try:
            cj.load(ignore_discard=True, ignore_expires=True)
        except Exception:
            pass
    op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
    op.addheaders = [("User-Agent", UA), ("Accept-Language", "vi-VN,vi;q=0.9")]
    return op, cj


def lay_ma(thu):
    """Mo phien moi, tai anh ma xac nhan -> <thu>/tcmst_ma.bmp. -> (duong anh, loi)."""
    os.makedirs(thu, exist_ok=True)
    p = os.path.join(thu, TEP_COOKIE)
    if os.path.exists(p):
        os.remove(p)
    op, cj = _mo(thu)
    try:
        op.open(URL_TRANG, timeout=30).read()
        anh = op.open(urllib.request.Request(URL_MA, headers={"Referer": URL_TRANG}), timeout=30).read()
    except Exception as e:
        return None, "Khong ket noi duoc trang tra cuu cua Cuc Thue: %s" % e
    cj.save(ignore_discard=True, ignore_expires=True)
    ra = os.path.join(thu, TEP_ANH)
    try:
        bmp = png_sang_bmp(anh)
    except Exception as e:
        return None, "Anh ma xac nhan khong doc duoc (%s)" % e
    with open(ra, "wb") as f:
        f.write(bmp)
    return ra, ""


def _giai_ma(b, ct=""):
    m = re.search(r"charset=([\w-]+)", ct or "", re.I) or re.search(rb"charset=[\"']?([\w-]+)", b[:3000], re.I)
    cs = m.group(1) if m else "utf-8"
    if isinstance(cs, bytes):
        cs = cs.decode("ascii", "ignore")
    try:
        return b.decode(cs, errors="replace")
    except LookupError:
        return b.decode("utf-8", errors="replace")


def _chu_o(s):
    s = re.sub(r"<br\s*/?>", " ", s, flags=re.I)
    s = re.sub(r"<[^>]+>", " ", s)
    return re.sub(r"\s+", " ", _html.unescape(s)).strip()


def doc_bang(trang):
    """HTML trang ket qua -> danh sach dict (mst, ten, dc, cqt, tt). Dong hop le: >= 6 o, o 1 la so thu tu, o 2 la MST."""
    ra = []
    for m in re.finditer(r"<tr\b[^>]*>(.*?)</tr>", trang, re.S | re.I):
        o = [_chu_o(x) for x in re.findall(r"<t[dh]\b[^>]*>(.*?)</t[dh]>", m.group(1), re.S | re.I)]
        if len(o) < 6:
            continue
        mst = chuan_mst(o[1])
        if not o[0].isdigit() or not MST_RE.match(mst):
            continue
        ra.append({"mst": mst, "ten": o[2], "dc": o[3], "cqt": o[4], "tt": o[5]})
    return ra


def trang_thai_trang(trang):
    """Khi khong co dong ket qua: SAI_MA / KHONG_THAY / KHONG_RO."""
    t = bo_dau(_chu_o(trang)).upper()
    if any(k in t for k in ("NHAP DUNG MA XAC NHAN", "MA XAC NHAN KHONG DUNG", "MA XAC NHAN KHONG CHINH XAC", "SAI MA XAC NHAN",
                            "MA XAC NHAN SAI", "MA XAC NHAN DA HET HAN", "MA XAC NHAN KHONG HOP LE")):
        return "SAI_MA"
    if any(k in t for k in ("KHONG TIM THAY", "KHONG CO KET QUA", "KHONG CO DU LIEU", "KHONG TON TAI")):
        return "KHONG_THAY"
    return "KHONG_RO"


def doc_yeu_cau(tep):
    yc = {"mst": "", "ma": "", "hd": []}
    with open(tep, "r", encoding="utf-8-sig", errors="replace") as f:
        for d in f.read().splitlines():
            if d.startswith("MST="):
                yc["mst"] = chuan_mst(d[4:])
            elif d.startswith("MA="):
                yc["ma"] = d[3:].strip()
            elif d.startswith("HD="):
                a = d[3:].split("|", 1)
                yc["hd"].append((a[0].strip(), a[1].strip() if len(a) > 1 else ""))
    return yc


def doi_chieu(dong, hd):
    """Lay muc khop tot nhat trong cac ten / dia chi hoa don cua MST do."""
    hang = {"K": 0, "G": 1, "L": 2, "-": 3}
    kt = min((khop_ten(t, dong["ten"]) for t, _ in hd), key=lambda x: hang[x], default="-")
    kd = min((khop_dc(d, dong["dc"]) for _, d in hd), key=lambda x: hang[x], default="-")
    return kt, kd


def ghi_ket_qua(ra, ma, mo_ta, dong=(), hd=()):
    out = ["KQ;%s;%s" % (ma, _sach(mo_ta))]
    for d in dong:
        kt, kd = doi_chieu(d, list(hd))
        out.append("R;%s;%s;%s;%s;%s;%s;%s;%d;%s" % (d["mst"], _sach(d["ten"]), _sach(d["dc"]), _sach(d["cqt"]), _sach(d["tt"]), kt, kd,
                                                    1 if dang_hoat_dong(d["tt"]) else 0, ma_nnt(d["tt"])))
    os.makedirs(os.path.dirname(os.path.abspath(ra)), exist_ok=True)
    with open(ra, "w", encoding="utf-8") as f:
        f.write("\n".join(out) + "\n")
    return ra


def tra(tep_yc, ra):
    """Gui MST + ma nguoi dung go trong cung phien voi anh ma. -> (duong ket qua, ma KQ)."""
    thu = os.path.dirname(os.path.abspath(tep_yc))
    yc = doc_yeu_cau(tep_yc)
    if not MST_RE.match(yc["mst"]):
        return ghi_ket_qua(ra, "LOI", "MST khong hop le: %s" % yc["mst"]), "LOI"
    if not yc["ma"]:
        return ghi_ket_qua(ra, "SAI_MA", "Chua go ma xac nhan"), "SAI_MA"
    op, cj = _mo(thu)
    ma_gui = chuan_ma(yc["ma"])
    du = urllib.parse.urlencode({"cm": "cm", "mst": yc["mst"], "fullname": "", "address": "", "cmt": "", "captcha": ma_gui}).encode()
    try:
        r = op.open(urllib.request.Request(URL_TRANG, data=du, headers={"Referer": URL_TRANG,
                                                                         "Content-Type": "application/x-www-form-urlencoded"}), timeout=40)
        trang = _giai_ma(r.read(), r.headers.get("Content-Type", ""))
    except Exception as e:
        return ghi_ket_qua(ra, "LOI", "Khong gui duoc yeu cau tra cuu: %s" % e), "LOI"
    try:
        cj.save(ignore_discard=True, ignore_expires=True)
    except Exception:
        pass
    dong = doc_bang(trang)
    if dong:
        return ghi_ket_qua(ra, "OK", "%d dong" % len(dong), dong, yc["hd"]), "OK"
    with open(os.path.join(thu, TEP_TRA_VE), "w", encoding="utf-8") as f:
        f.write(trang)
    tt = trang_thai_trang(trang)
    mo = {"SAI_MA": "Ma xac nhan khong dung hoac da het han", "KHONG_THAY": "Cong thue khong co nguoi nop thue voi MST nay",
          "KHONG_RO": "Khong thay bang ket qua (co the ma xac nhan sai) - trang tra ve luu o " + TEP_TRA_VE}[tt]
    return ghi_ket_qua(ra, tt, mo), tt


# ------------------------------------------------------------------ GD214: MOT PHIEN GIU KET NOI (nhu trinh duyet)
# Truoc day lay anh ma va gui tra cuu la 2 tien trinh, 2 ket noi khac nhau -> trang tra cuu coi la 2 phien, luon bao
# "Vui long nhap dung ma xac nhan". Nay mot tien trinh song suot luc tra cuu, giu nguyen ket noi HTTPS (keep-alive) + cookie;
# VB6 gui lenh qua tep (tcmst_lenh.txt), nhan ket qua tcmst_kq_<id>.txt. Nguoi dung van tu go ma (quy tac 17).
TEP_LENH = "tcmst_lenh.txt"
TEP_SONG = "tcmst_song.txt"


class PhienHTTP(object):
    def __init__(self, may="tracuunnt.gdt.gov.vn"):
        self.may = may
        self.cookie = {}
        self.conn = None

    def _ket_noi(self):
        import http.client
        import ssl
        self.conn = http.client.HTTPSConnection(self.may, timeout=40, context=ssl.create_default_context())

    def gui(self, phuong_thuc, duong, than=None, referer=None):
        """-> (ma HTTP, header Content-Type, byte). Mat ket noi giua chung thi noi lai 1 lan (cookie giu nguyen)."""
        hd = {"User-Agent": UA, "Accept": "text/html,application/xhtml+xml,image/png,*/*;q=0.8", "Accept-Language": "vi-VN,vi;q=0.9",
              "Connection": "keep-alive"}
        if referer:
            hd["Referer"] = referer
        if self.cookie:
            hd["Cookie"] = "; ".join("%s=%s" % kv for kv in self.cookie.items())
        if than is not None:
            hd["Content-Type"] = "application/x-www-form-urlencoded"
            hd["Origin"] = "https://" + self.may
        for lan in (0, 1):
            try:
                if self.conn is None:
                    self._ket_noi()
                self.conn.request(phuong_thuc, duong, body=than, headers=hd)
                r = self.conn.getresponse()
                b = r.read()
                for k, v in r.getheaders():
                    if k.lower() == "set-cookie":
                        kv = v.split(";", 1)[0]
                        if "=" in kv:
                            self.cookie[kv.split("=", 1)[0].strip()] = kv.split("=", 1)[1].strip()
                if r.status in (301, 302, 303) and r.getheader("Location"):
                    loc = r.getheader("Location")
                    loc = re.sub(r"^https?://[^/]+", "", loc)
                    return self.gui("GET", loc, None, referer)
                return r.status, r.getheader("Content-Type", ""), b
            except Exception:
                try:
                    self.conn.close()
                except Exception:
                    pass
                self.conn = None
                if lan:
                    raise

    def dong(self):
        try:
            self.conn.close()
        except Exception:
            pass


def ma_phien(ph, thu):
    """Mo trang (lan dau / lam moi) roi tai anh ma cua phien -> (duong BMP, loi)."""
    try:
        ph.gui("GET", "/tcnnt/mstdn.jsp")
        import random
        _, ct, anh = ph.gui("GET", "/tcnnt/captcha.png?uid=%d" % random.randint(10 ** 8, 10 ** 9), referer=URL_TRANG)   # GD218: tranh anh cu (bo nho dem)
        ph.anh_md5 = __import__("hashlib").md5(anh).hexdigest()[:8]
    except Exception as e:
        return None, "Khong ket noi duoc trang tra cuu cua Cuc Thue: %s" % e
    try:
        bmp = png_sang_bmp(anh, 2)
    except Exception as e:
        return None, "Anh ma xac nhan khong doc duoc (%s)" % e
    ra = os.path.join(thu, TEP_ANH)
    with open(ra + ".tmp", "wb") as f:
        f.write(bmp)
    os.replace(ra + ".tmp", ra)
    return ra, ""


def tra_phien(ph, thu, yc, ra):
    if not MST_RE.match(yc["mst"]):
        return ghi_ket_qua(ra, "LOI", "MST khong hop le: %s" % yc["mst"]), "LOI"
    if not yc["ma"]:
        return ghi_ket_qua(ra, "SAI_MA", "Chua go ma xac nhan"), "SAI_MA"
    ma_gui = chuan_ma(yc["ma"])
    du = urllib.parse.urlencode({"cm": "cm", "mst": yc["mst"], "fullname": "", "address": "", "cmt": "", "captcha": ma_gui}).encode()
    try:
        _, ct, b = ph.gui("POST", "/tcnnt/mstdn.jsp", du, referer=URL_TRANG)
        trang = _giai_ma(b, ct)
    except Exception as e:
        return ghi_ket_qua(ra, "LOI", "Khong gui duoc yeu cau tra cuu: %s" % e), "LOI"
    dong = doc_bang(trang)
    if dong:
        return ghi_ket_qua(ra, "OK", "%d dong" % len(dong), dong, yc["hd"]), "OK"
    with open(os.path.join(thu, TEP_TRA_VE), "w", encoding="utf-8") as f:
        f.write(trang)
    tt = trang_thai_trang(trang)
    mo = {"SAI_MA": "Ma xac nhan khong dung hoac da het han", "KHONG_THAY": "Cong thue khong co nguoi nop thue voi MST nay",
          "KHONG_RO": "Khong thay bang ket qua (co the ma xac nhan sai) - trang tra ve luu o " + TEP_TRA_VE}[tt]
    return ghi_ket_qua(ra, tt, mo), tt


def _nhat_ky(thu, dong):
    """GD216: nhat ky tra cuu (khong ghi ma xac nhan, khong ghi ten khach) - tcmst_nhat_ky.txt trong ket-qua."""
    import time
    try:
        with open(os.path.join(thu, "tcmst_nhat_ky.txt"), "a", encoding="utf-8") as f:
            f.write("%s %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), dong))
    except OSError:
        pass


def doc_tep_dan(p, la_html=False):
    """GD219: tep tho UNESCO ghi tu clipboard: chu = UTF-16LE (CF_UNICODETEXT), HTML = UTF-8 ('HTML Format'); cat o ky tu 0."""
    if not p or not os.path.isfile(p):
        return ""
    with open(p, "rb") as f:
        b = f.read()
    if la_html:
        return b.split(b"\x00", 1)[0].decode("utf-8", "replace")
    if len(b) % 2:
        b = b[:-1]
    t = b.decode("utf-16-le", "replace")
    return t.split("\x00", 1)[0].lstrip("\ufeff")


def doc_clipboard_html():
    """GD219: dinh dang 'HTML Format' cua clipboard (Chrome / Edge / Firefox luon kem) -> chu HTML (UTF-8)."""
    import ctypes
    u32, k32 = ctypes.windll.user32, ctypes.windll.kernel32
    u32.GetClipboardData.restype = ctypes.c_void_p
    u32.RegisterClipboardFormatW.restype = ctypes.c_uint
    k32.GlobalLock.restype = ctypes.c_void_p
    k32.GlobalLock.argtypes = [ctypes.c_void_p]
    k32.GlobalUnlock.argtypes = [ctypes.c_void_p]
    k32.GlobalSize.restype = ctypes.c_size_t
    k32.GlobalSize.argtypes = [ctypes.c_void_p]
    fmt = u32.RegisterClipboardFormatW("HTML Format")
    for _ in range(10):
        if u32.OpenClipboard(None):
            break
        __import__("time").sleep(0.1)
    else:
        return ""
    try:
        h = u32.GetClipboardData(fmt)
        if not h:
            return ""
        p = k32.GlobalLock(h)
        try:
            return ctypes.string_at(p, k32.GlobalSize(h)).split(b"\x00", 1)[0].decode("utf-8", "replace")
        finally:
            k32.GlobalUnlock(h)
    finally:
        u32.CloseClipboard()


def doc_clipboard():
    """GD218: chu Unicode tren clipboard Windows (CF_UNICODETEXT)."""
    import ctypes
    u32, k32 = ctypes.windll.user32, ctypes.windll.kernel32
    u32.GetClipboardData.restype = ctypes.c_void_p
    k32.GlobalLock.restype = ctypes.c_void_p
    k32.GlobalLock.argtypes = [ctypes.c_void_p]
    k32.GlobalUnlock.argtypes = [ctypes.c_void_p]
    for _ in range(10):
        if u32.OpenClipboard(None):
            break
        __import__("time").sleep(0.1)
    else:
        raise OSError("khong mo duoc clipboard")
    try:
        h = u32.GetClipboardData(13)
        if not h:
            return ""
        p = k32.GlobalLock(h)
        try:
            return ctypes.wstring_at(p)
        finally:
            k32.GlobalUnlock(h)
    finally:
        u32.CloseClipboard()


def doc_dan(chu):
    """GD218: bang ket qua trang tra cuu do nguoi dung boi den + Ctrl+C tren trinh duyet -> dong (mst, ten, dc, cqt, tt).
    Chrome / Edge: moi dong bang mot dong, o cach nhau TAB. Mot so trinh duyet: moi o mot dong -> doc theo thu tu sau o MST."""
    ra, thay = [], set()
    dong = [d.rstrip() for d in (chu or "").replace("\r\n", "\n").replace("\r", "\n").split("\n")]
    for d in dong:
        o = [x.strip() for x in d.split("\t")]
        if len(o) < 3:                       # GD219: mot so trinh duyet / Word dan bang bang nhieu dau cach
            o = [x.strip() for x in re.split(r"\s{3,}", d)]
        for i, x in enumerate(o):
            m = chuan_mst(x)
            if MST_RE.match(m) and len(o) - i >= 3 and m not in thay and o[i + 1]:
                o2 = o + [""] * 5
                ra.append({"mst": m, "ten": o2[i + 1], "dc": o2[i + 2], "cqt": o2[i + 3], "tt": o2[i + 4]})
                thay.add(m)
                break
    if ra:
        return ra
    o = [d.strip() for d in dong if d.strip()]
    for i, x in enumerate(o):
        m = chuan_mst(x)
        if MST_RE.match(m) and i + 4 < len(o) and m not in thay and not MST_RE.match(chuan_mst(o[i + 1])):
            if bo_dau(o[i + 4]).upper().find("NNT") >= 0 or "HOAT DONG" in bo_dau(o[i + 4]).upper():
                ra.append({"mst": m, "ten": o[i + 1], "dc": o[i + 2], "cqt": o[i + 3], "tt": o[i + 4]})
                thay.add(m)
    return ra


def _ghi_nt(p, s):
    with open(p + ".tmp", "w", encoding="utf-8") as f:
        f.write(s)
    os.replace(p + ".tmp", p)


def phien(thu, cho=900, ph=None, nhip=0.15):
    """Vong lap mot phien tra cuu. Lenh (tcmst_lenh.txt, UTF-8): dong 1 'ID=<so>', dong 2 'MA' | 'TRA' | 'DUNG', sau do (TRA) MST= / MA= / HD=.
    Ket qua: tcmst_kq_<id>.txt ('KQ;OK;<bmp>' cho MA; dinh dang tra() cho TRA). Khong co lenh qua <cho> giay -> tu thoat."""
    import time
    os.makedirs(thu, exist_ok=True)
    ph = ph or PhienHTTP()
    p_lenh = os.path.join(thu, TEP_LENH)
    for t in os.listdir(thu):
        if t.startswith("tcmst_kq_") or t == TEP_LENH:
            try:
                os.remove(os.path.join(thu, t))
            except OSError:
                pass
    cuoi = time.time()
    lan_song = 0
    try:
        while time.time() - cuoi < cho:
            if time.time() - lan_song > 2:
                _ghi_nt(os.path.join(thu, TEP_SONG), "%d %.0f" % (os.getpid(), time.time()))
                lan_song = time.time()
            if not os.path.exists(p_lenh):
                time.sleep(nhip)
                continue
            try:
                with open(p_lenh, encoding="utf-8-sig") as f:
                    ds = f.read().splitlines()
                os.remove(p_lenh)
            except OSError:
                time.sleep(nhip)
                continue
            cuoi = time.time()
            idl = ds[0][3:].strip() if ds and ds[0].startswith("ID=") else "0"
            lenh = (ds[1].strip().upper() if len(ds) > 1 else "")
            ra = os.path.join(thu, "tcmst_kq_%s.txt" % idl)
            if lenh == "DUNG":
                break
            if lenh == "MA":
                # GD219: nhat ky 13/10 - lan tra DAU cua moi phien luon dung, cac lan sau cung phien phan lon bi bao sai ma ->
                #   moi ma xac nhan mot phien moi (cookie + ket noi moi), MA va TRA ke tiep van cung mot phien
                lop = type(ph)
                ph.dong()
                ph = lop()
                d, loi = ma_phien(ph, thu)
                _nhat_ky(thu, "MA %s phien=%s anh=%s" % ("ok" if d else "loi: " + _sach(loi, 120), "co" if ph.cookie.get("JSESSIONID") else "khong",
                                                       getattr(ph, "anh_md5", "")))
                _ghi_nt(ra, ("KQ;OK;%s\n" % d) if d else ("KQ;LOI;%s\n" % _sach(loi)))
            elif lenh == "TRA":
                yc = {"mst": "", "ma": "", "hd": []}
                for d in ds[2:]:
                    if d.startswith("MST="):
                        yc["mst"] = chuan_mst(d[4:])
                    elif d.startswith("MA="):
                        yc["ma"] = d[3:].strip()
                    elif d.startswith("HD="):
                        a = d[3:].split("|", 1)
                        yc["hd"].append((a[0].strip(), a[1].strip() if len(a) > 1 else ""))
                _, kq_ma = tra_phien(ph, thu, yc, ra + ".tmp")
                os.replace(ra + ".tmp", ra)
                _nhat_ky(thu, "TRA mst=%s kq=%s ma_dai=%d ma_hoa=%d ma_ascii=%d phien=%s" % (yc["mst"], kq_ma, len(yc["ma"]), int(yc["ma"] != yc["ma"].lower()),
                         int(all(32 <= ord(ch) < 127 for ch in yc["ma"])), "co" if ph.cookie.get("JSESSIONID") else "khong"))
            elif lenh == "DAN":
                hd, tep, tep_html = [], "", ""
                for d in ds[2:]:
                    if d.startswith("HD="):
                        x = d[3:].split("|", 1)
                        hd.append((x[0].strip(), x[1].strip() if len(x) > 1 else ""))
                    elif d.startswith("TEP="):
                        tep = d[4:].strip()
                    elif d.startswith("TEPHTML="):
                        tep_html = d[8:].strip()
                html, nguon = "", "unesco"
                chu = doc_tep_dan(tep)               # GD219: UNESCO doc clipboard va ghi ra tep (UTF-16 / UTF-8)
                html = doc_tep_dan(tep_html, True)
                if not chu.strip() and not html.strip():
                    nguon = "python"
                    try:
                        chu = doc_clipboard()
                    except Exception as e:
                        chu = ""
                        _nhat_ky(thu, "DAN loi doc clipboard: %s" % _sach(str(e), 120))
                dong = doc_dan(chu)
                if not dong and html:
                    dong = doc_bang(html)
                if not dong and nguon == "python":
                    try:
                        html = doc_clipboard_html()
                        dong = doc_bang(html) if html else []
                    except Exception as e:
                        _nhat_ky(thu, "DAN loi doc HTML: %s" % _sach(str(e), 120))
                if not dong:
                    try:                     # luu lai noi dung da copy de kiem (chi tren may nguoi dung)
                        with open(os.path.join(thu, "tcmst_dan_loi.txt"), "w", encoding="utf-8") as f:
                            f.write(chu + "\n\n----- HTML -----\n" + html)
                    except OSError:
                        pass
                _nhat_ky(thu, "DAN nguon=%s chu=%d dong_chu=%d tab=%d html=%d" % (nguon, len(chu), chu.count("\n"), chu.count("\t"), len(html)))
                if dong:
                    ghi_ket_qua(ra + ".tmp", "OK", "%d dong (dan)" % len(dong), dong, hd)
                elif MST_RE.match(chuan_mst(chu.strip())):
                    ghi_ket_qua(ra + ".tmp", "KHONG_RO", "Clipboard moi chi co MST - tren trang ket qua hay boi den ca bang (tu chu STT den het dong) roi Ctrl+C, sau do moi bam Dan ket qua")
                elif chu.strip():
                    ghi_ket_qua(ra + ".tmp", "KHONG_RO", "Khong thay bang ket qua trong noi dung da copy - boi den ca bang ket qua roi Ctrl+C")
                else:
                    ghi_ket_qua(ra + ".tmp", "LOI", "Clipboard trong - tren trinh duyet boi den bang ket qua roi Ctrl+C")
                os.replace(ra + ".tmp", ra)
                _nhat_ky(thu, "DAN %d dong" % len(dong))
            else:
                _ghi_nt(ra, "KQ;LOI;lenh khong ro\n")
    finally:
        ph.dong()
        try:
            os.remove(os.path.join(thu, TEP_SONG))
        except OSError:
            pass
    return 0


if __name__ == "__main__":
    import sys
    if len(sys.argv) >= 3 and sys.argv[1] == "ma":
        print(lay_ma(sys.argv[2]))
    elif len(sys.argv) >= 4 and sys.argv[1] == "tra":
        print(tra(sys.argv[2], sys.argv[3]))
