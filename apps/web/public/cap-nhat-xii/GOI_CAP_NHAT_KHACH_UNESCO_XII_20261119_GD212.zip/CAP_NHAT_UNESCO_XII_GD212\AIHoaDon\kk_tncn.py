# -*- coding: utf-8 -*-
"""GD121 - TO KHAI KHAU TRU THUE TNCN 05/KK-TNCN (to chuc tra thu nhap tu tien luong, tien cong) theo QUY (theo THANG
khi ky chon la mot thang truoc quy 2/2026). Thay lua chon "To khai thue" cu cua man hinh Bao cao (in to DANG KY thue 01/DK-TNCN
cua TT84/2008 - da bai bo, khong phai to khai thue).
Hop dong xuat_1_lan.py: lap(dl, "KK_TNCN", kieu, thumuc) -> {"tep": [...], "canh_bao": [...]}. CHI DOC SO, khong ghi CSDL.

So lieu: phan JSON "tncn" (ModHDDTTNCN.HDDT_TNCN_JsonThem) - dung lai qtt_tncn.tong_hop (chon nguon BangLuong / bang luong
Excel khong cong trung, gom theo nguoi, NPT, dinh danh) roi CAT theo cac thang cua ky khai.
Chi tieu theo mau TT80/2021 (HTKK 05_KK_TNCN_TT80, maTKhai 864):
  [16] tong so nguoi lao dong (co TNCT trong ky)        [17] trong do ca nhan cu tru co HDLD (bang ke 05-1: loai HD 1, 2)
  [18] = [19] + [20] so ca nhan da khau tru thue        [19] cu tru (co thue da khau tru > 0)   [20] khong cu tru = 0
  [21] = [22] + [23] tong TNCT tra cho ca nhan          [22] cu tru                               [23] = 0
  [24] TNCT tu phi BH nhan tho... = 0                   [25] TNCT mien theo HD dau khi = 0
  [26] = [27] + [28] TNCT thuoc dien phai khau tru      [27] cu tru: TNCT cua cac thang-nguoi DA khau tru thue (> 0)
  [29] = [30] + [31] thue TNCN da khau tru              [30] cu tru = tong thue da khau tru (bang luong)   [32] thue tren phi BH = 0
Tu quy 3/2026 to khai theo mau TT89/2026 (them chi tieu thu nhap / thue duoc mien...): HTKK tren may con khuon TT80 thi XML lap
theo khuon TT80 (dung ban HTKK dang nop); khi HTKK co khuon TT89 thi bao can cap nhat phan mem (khong doan ma chi tieu).
XML lap tu khung chinh cua HTKK cai tren may (Menu.xml -> InterfaceTemplates\\xml\\05_KK_TNCN_TT80_xml_<ban>.xml) - khong co
HTKK thi chi lap Excel. Khong ghi so CCCD / MST vao nhat ky (chi co trong tep to khai)."""
import calendar
import os
import re
from datetime import date

import qtt_tncn as Q
from qtt_tncn import lam_tron, _vn, _ds, _ds_thang, _dn, _ngay_lap, _nguoi_ky, _kieu, _cot_chia, thue_luy_tien, tham_so_nam

MA_FILE = "05_KK_TNCN_TT80"
CT = ["16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32"]
DONG = [("1", "Tổng số người lao động:", "16", "Người", True),
        ("", "Trong đó: Cá nhân cư trú có hợp đồng lao động", "17", "Người", False),
        ("2", "Tổng số cá nhân đã khấu trừ thuế [18]=[19]+[20]", "18", "Người", True),
        ("2.1", "Cá nhân cư trú", "19", "Người", False),
        ("2.2", "Cá nhân không cư trú", "20", "Người", False),
        ("3", "Tổng thu nhập chịu thuế (TNCT) trả cho cá nhân [21]=[22]+[23]", "21", "VNĐ", True),
        ("3.1", "Cá nhân cư trú", "22", "VNĐ", False),
        ("3.2", "Cá nhân không cư trú", "23", "VNĐ", False),
        ("", "Trong đó: Tổng TNCT từ tiền phí mua bảo hiểm nhân thọ, bảo hiểm không bắt buộc khác của doanh nghiệp bảo hiểm "
             "không thành lập tại Việt Nam cho người lao động", "24", "VNĐ", False),
        ("", "Trong đó: Tổng TNCT được miễn theo quy định của Hợp đồng dầu khí", "25", "VNĐ", False),
        ("", "Thu nhập miễn thuế, thu nhập cá nhân theo nghị quyết", "25_1", "VNĐ", False),          # GD328: [25.1] khuôn HTKK 2.9.3
        ("4", "Tổng TNCT trả cho cá nhân thuộc diện phải khấu trừ thuế [26]=[27]+[28]", "26", "VNĐ", True),
        ("4.1", "Cá nhân cư trú", "27", "VNĐ", False),
        ("4.2", "Cá nhân không cư trú", "28", "VNĐ", False),
        ("5", "Tổng số thuế thu nhập cá nhân (TNCN) đã khấu trừ [29]=[30]+[31]", "29", "VNĐ", True),
        ("5.1", "Cá nhân cư trú", "30", "VNĐ", False),
        ("5.2", "Cá nhân không cư trú", "31", "VNĐ", False),
        ("", "Trong đó: Tổng số thuế TNCN đã khấu trừ trên tiền phí mua bảo hiểm nhân thọ, bảo hiểm không bắt buộc khác của doanh "
             "nghiệp bảo hiểm không thành lập tại Việt Nam cho người lao động", "32", "VNĐ", False)]


# ------------------------------------------------------------------ ky khai
def _ngay(s):
    for f in ("%d/%m/%Y", "%Y-%m-%d"):
        try:
            from datetime import datetime
            return datetime.strptime(str(s or "")[:10], f).date()
        except ValueError:
            pass
    return None


def cac_ky(tu, den):
    """ky khai cho khoang [tu, den]: mot thang truoc 04/2026 -> ky thang; con lai -> cac QUY duong lich giao voi khoang
    (khai thang bo tu quy 2/2026). -> [(kieu "Q"|"M", nam, so quy|thang, [thang...])]."""
    if not tu or not den or den < tu:
        return []
    if tu.year == den.year and tu.month == den.month and (tu.year, tu.month) < (2026, 4):
        return [("M", tu.year, tu.month, [tu.month])]
    ra, y, q = [], tu.year, (tu.month - 1) // 3 + 1
    while (y, q) <= (den.year, (den.month - 1) // 3 + 1) and len(ra) < 8:
        ra.append(("Q", y, q, [3 * q - 2, 3 * q - 1, 3 * q]))
        q += 1
        if q > 4:
            y, q = y + 1, 1
    return ra


def ten_ky(k):
    return ("Quý %d năm %d" % (k[2], k[1])) if k[0] == "Q" else ("Tháng %02d năm %d" % (k[2], k[1]))


def tu_den(k):
    a = date(k[1], k[3][0], 1)
    b = date(k[1], k[3][-1], calendar.monthrange(k[1], k[3][-1])[1])
    return a, b


# ------------------------------------------------------------------ tong hop mot ky
def tong_hop_ky(dl, k):
    """-> kq ky: nguoi [(r, loai, {thang: d})], chi tieu ct, chi tiet kiem tra, canh bao."""
    t = dict(dl.get("tncn") or {})
    t["nam_qt"] = k[1]
    dl2 = dict(dl)
    dl2["tncn"] = t
    kq = Q.tong_hop(dl2)
    cb = []
    nam = k[1]
    ts = tham_so_nam(nam)
    ms = set(k[3])
    ng, ex_nhieu = [], []
    for loai, ds in (("05-1", kq["ds1"]), ("05-2", kq["ds2"])):
        for r in ds:
            th = {m: d for m, d in r["chi_tiet"].items() if 1 <= m <= 12 and m in ms}
            for m in r["chi_tiet"]:
                if not 1 <= m <= 12 and (Q.thang_cua_ky(m) & ms):
                    ex_nhieu.append("%s (%s)" % (r["ten"], Q.ten_ky(m, nam)))
            if th and any(lam_tron(d["tn"]) or lam_tron(d["thue"]) for d in th.values()):
                ng.append((r, loai, th))
    ct = {c: 0 for c in CT}
    ct["25_1"] = 0                       # GD328: [25.1] (HTKK 2.9.3) - phan mem khong theo doi
    kiem, thieu_dd, lhd3 = [], [], []
    for r, loai, th in ng:
        tn = sum(lam_tron(d["tn"]) for d in th.values())
        thue = sum(lam_tron(d["thue"]) for d in th.values())
        if tn > 0:
            ct["16"] += 1
            if loai == "05-1":
                ct["17"] += 1
        if thue > 0:
            ct["19"] += 1
        ct["22"] += tn
        ct["27"] += sum(lam_tron(d["tn"]) for d in th.values() if lam_tron(d["thue"]) > 0)
        ct["30"] += thue
        if r["dd"]["thieu"]:
            thieu_dd.append(r["ten"])
        if loai == "05-2":
            lhd3.append(r["ten"])
        for m in sorted(th):
            d = th[m]
            tn_m, bh, tt_m = lam_tron(d["tn"]), lam_tron(d["bh"]), lam_tron(d["thue"])
            npt = d["sothang"] if d["nguon"] == "PM" else r["gc"].get(m, 0)
            if loai == "05-1":
                tntt = max(0, tn_m - bh - ts["gt_ban_than"] - ts["gt_npt"] * npt - lam_tron(d["tu_thien"]))
                bieu = thue_luy_tien(tntt, Q.nam_bieu_thang(nam, m, (dl.get("tncn") or {}).get("tham_so")), 1)
            else:
                tntt, bieu = tn_m, (lam_tron(tn_m * 0.1) if tn_m >= _nguong_vang_lai(nam, m) else 0)
            kiem.append({"ten": r["ten"], "dd": r["dd"], "loai": loai, "thang": m, "tn": tn_m, "bh": bh, "npt": npt, "tntt": tntt,
                         "bieu": bieu, "thue": tt_m, "nguon": d["nguon"]})
    ct["18"] = ct["19"] + ct["20"]
    ct["21"] = ct["22"] + ct["23"]
    ct["26"] = ct["27"] + ct["28"]
    ct["29"] = ct["30"] + ct["31"]
    # canh bao
    thang_co = sorted({x["thang"] for x in kiem})
    thieu_th = sorted(ms - set(thang_co))
    if not ng:
        cb.append("%s: không có bảng lương các tháng %s - tờ khai ghi 0 (khai \"không phát sinh\" nếu đúng là không trả lương)."
                  % (ten_ky(k), _ds_thang(k[3])))
    elif thieu_th:
        cb.append("%s: chưa có bảng lương tháng %s - kiểm tra trước khi nộp." % (ten_ky(k), _ds_thang(thieu_th)))
    if ex_nhieu:
        cb.append("Bảng lương Excel nhập theo kỳ nhiều tháng / cả năm không tách được theo tháng nên KHÔNG đưa vào %s: %s."
                  % (ten_ky(k), _ds(sorted(set(ex_nhieu)))))
    lech = [x for x in kiem if x["bieu"] != x["thue"]]
    if lech:
        cb.append("Thuế đã khấu trừ theo bảng lương khác thuế tính theo biểu ở %d lượt người-tháng (biểu %s, bảng lương %s; vd %s). "
                  "Tờ khai kê số ĐÃ khấu trừ ([30]); xem sheet \"Chi tiet\" - nếu khấu trừ thiếu thì tính lại thuế tháng ở màn hình "
                  "Tính thuế TNCN rồi lập lại." % (len(lech), _vn(sum(x["bieu"] for x in lech)), _vn(sum(x["thue"] for x in lech)),
                                                    "; ".join("%s T%d: %s/%s" % (x["ten"], x["thang"], _vn(x["bieu"]), _vn(x["thue"]))
                                                              for x in lech[:3])))
    if thieu_dd:
        cb.append("%d người thiếu mã số thuế / số CCCD trong hồ sơ nhân viên: %s." % (len(thieu_dd), _ds(thieu_dd)))
    if lhd3:
        cb.append("%d người có loại HĐ \"Dưới 12 tháng\" (kê nhóm không HĐLĐ / HĐ dưới 3 tháng, khấu trừ 10%%): %s. Nếu hợp đồng từ 3 tháng "
                  "trở lên thì đổi loại HĐ để tính theo biểu lũy tiến." % (len(lhd3), _ds(lhd3)))
    gt_pm = Q._nguyen((dl.get("dn") or {}).get("gt_ban_than")) or Q._nguyen(((dl.get("tncn") or {}).get("tham_so") or {}).get("gt_ban_than"))
    if gt_pm and gt_pm < ts["gt_ban_than"]:
        cb.append("Mức giảm trừ bản thân khai trong phần mềm (%s) thấp hơn mức luật năm %d (%s) - thuế tháng có thể đã khấu trừ thừa; "
                  "kiểm tra cột Thuế theo biểu ở sheet \"Chi tiet\"." % (_vn(gt_pm), nam, _vn(ts["gt_ban_than"])))
    doi = []
    x1 = dl.get("x1l") or {}
    if kq["nam"] == kq["nam_tc"] and Q._nguyen(x1.get("thang_dau_ky") or dl.get("thang_dau_ky") or 1) == 1 and Q._ps_co(dl, "334") is not None:
        for m in k[3]:
            bl = sum(x["tn"] for x in kiem if x["thang"] == m)
            th = sum(x["thue"] for x in kiem if x["thang"] == m)
            p334, p3335 = lam_tron(Q._ps_co(dl, "334", m)), lam_tron(Q._ps_co(dl, "3335", m))
            doi.append((m, bl, p334, th, p3335))
        if any(a != b for _, a, b, _, _ in doi):
            cb.append("Tổng thu nhập bảng lương khác phát sinh Có TK 334 ở tháng %s - xem sheet \"Doi chieu\"."
                      % _ds_thang([m for m, a, b, _, _ in doi if a != b]))
        if any(a != b for _, _, _, a, b in doi):
            cb.append("Thuế đã khấu trừ theo bảng lương khác phát sinh Có TK 3335 ở tháng %s (chưa trích thuế TNCN vào sổ / 3335 có khoản "
                      "khác) - xem sheet \"Doi chieu\"." % _ds_thang([m for m, _, _, a, b in doi if a != b]))
    return {"ky": k, "nam": nam, "ct": ct, "kiem": kiem, "doi": doi, "canh_bao": cb, "ts": ts, "nguon": kq.get("nguon_mo_ta") or "",
            "so_nguoi": len(ng)}


def _nguong_vang_lai(nam, thang):
    """khau tru 10% khi tra tu nguong / lan cho ca nhan khong HDLD / HD duoi 3 thang: 2 tr; tu 01/7/2026 5 tr (ND 253/2026)."""
    return 5000000 if (nam, thang) >= (2026, 7) else 2000000


# ------------------------------------------------------------------ Excel
def _sheet_to_khai(wb, K, kk, dl):
    dn = _dn(dl)
    k, ct = kk["ky"], kk["ct"]
    rong = [6, 62, 11, 10, 20]
    ws = wb.sheet("05-KK-TNCN", cot=rong)
    c_mau = _cot_chia(rong, tu_phai=30)
    ws.gop(1, 1, 1, c_mau - 1, "CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM", K["qh"])
    ws.gop(2, 1, 2, c_mau - 1, "Độc lập - Tự do - Hạnh phúc", K["qh2"])
    tt89 = (k[1], k[3][0]) >= (2026, 7)
    van_ban = ("Thông tư số 80/2021/TT-BTC ngày 29 tháng 9 năm 2021 của Bộ trưởng Bộ Tài chính" if not tt89 else
               "Thông tư số 80/2021/TT-BTC - bố cục HTKK hiện có; kỳ từ quý 3/2026 áp dụng mẫu Thông tư số 89/2026/TT-BTC")
    ws.gop(1, c_mau, 3, len(rong), "Mẫu số: 05/KK-TNCN\n(Ban hành kèm theo %s)" % van_ban, K["mau"])
    ws.cao(3, 34)
    r = 5
    ws.gop(r, 1, r, 5, "TỜ KHAI THUẾ THU NHẬP CÁ NHÂN", K["td"])
    r += 1
    ws.gop(r, 1, r, 5, "(Áp dụng đối với tổ chức, cá nhân trả các khoản thu nhập từ tiền lương, tiền công)", K["td2"])
    r += 1
    ws.gop(r, 1, r, 5, "[01] Kỳ tính thuế: %s" % ten_ky(k), K["qh"])
    r += 1
    ws.gop(r, 1, r, 5, "[02] Lần đầu: [X]          [03] Bổ sung lần thứ: [   ]", K["qh"])
    r += 2
    ws.gop(r, 1, r, 5, "[04] Tên người nộp thuế: %s" % dn.get("ten", ""), K["b"])
    r += 1
    ws.gop(r, 1, r, 5, "[05] Mã số thuế: %s" % dn.get("mst", ""), K["b"])
    r += 1
    ws.gop(r, 1, r, 5, "[12] Tên đại lý thuế (nếu có):                [13] Mã số thuế:", K["t"])
    r += 1
    ws.gop(r, 1, r, 5, "[15] [   ] Khai thuế đối với tổ chức có đơn vị phụ thuộc / địa điểm kinh doanh khác tỉnh (phân bổ số thuế) - "
                       "phần mềm lập cho toàn đơn vị, không phân bổ", K["ghi"])
    ws.cao(r, 28)
    r += 2
    ws.gop(r, 1, r, 5, "Đơn vị tiền: Đồng Việt Nam", K["dvt"])
    r += 1
    ws.dong(r, 1, ["STT", "Chỉ tiêu", "Mã chỉ tiêu", "Đơn vị tính", "Số người/Số tiền"], K["h"])
    ws.cao(r, 30)
    r += 1
    for stt, ten, ma, dvt, dam in DONG:
        ws.dong(r, 1, [(stt, K["cg"]), (ten, K["cb"] if dam else K["c"]), ("[%s]" % ma.replace("_", "."), K["cg"]), (dvt, K["cg"]),
                       (ct[ma], K["nb"] if dam else K["n"])])
        if len(ten) > 64:
            ws.cao(r, 15 * ((len(ten) + 63) // 64))
        r += 1
    r += 1
    ws.gop(r, 1, r, 5, "Tôi cam đoan số liệu khai trên là đúng và chịu trách nhiệm trước pháp luật về những số liệu đã khai./.", K["ghi"])
    r += 2
    lap = _ngay_lap(dl)
    giua = _cot_chia(rong, ty_le=0.45)
    ws.gop(r, 1, r, giua - 1, "NHÂN VIÊN ĐẠI LÝ THUẾ", K["ky"])
    ws.gop(r, giua, r, 5, "..., ngày %02d tháng %02d năm %d" % (lap.day, lap.month, lap.year), K["ky2"])
    r += 1
    ws.gop(r, 1, r, giua - 1, "Họ và tên: .......................................", K["t"])
    ws.gop(r, giua, r, 5, "NGƯỜI NỘP THUẾ hoặc\nĐẠI DIỆN HỢP PHÁP CỦA NGƯỜI NỘP THUẾ", K["ky"])
    ws.cao(r, 45)
    r += 1
    ws.gop(r, 1, r, giua - 1, "Chứng chỉ hành nghề số: .......................", K["t"])
    ws.gop(r, giua, r, 5, "(Chữ ký, ghi rõ họ tên; chức vụ và đóng dấu (nếu có)/Ký điện tử)", K["ky2"])
    r += 4
    ws.gop(r, giua, r, 5, _nguoi_ky(dl), K["ky"])
    ws.in_trang(ngang=False)
    return ws


def _sheet_chi_tiet(wb, K, kk):
    ts = kk["ts"]
    ws = wb.sheet("Chi tiet", cot=[6, 26, 15, 8, 8, 16, 14, 7, 16, 16, 16, 14])
    ws.gop(1, 1, 1, 12, "CHI TIẾT THU NHẬP - THUẾ TNCN %s (số liệu lập tờ khai 05/KK-TNCN)" % ten_ky(kk["ky"]).upper(), K["qh"])
    ws.gop(2, 1, 2, 12, "Nguồn: %s. Giảm trừ bản thân %s, NPT %s đồng/tháng; %s. Nhóm 05-2 (HĐ dưới 3 tháng / không HĐLĐ): thuế theo "
                        "biểu = 10%% khi trả từ %s đồng/lần trở lên (tham khảo theo tháng)."
                        % (kk["nguon"] or "-", _vn(ts["gt_ban_than"]), _vn(ts["gt_npt"]), ts["can_cu"],
                           _vn(_nguong_vang_lai(kk["nam"], kk["ky"][3][-1]))), K["ghi"])
    ws.cao(2, 45)
    ws.dong(4, 1, ["STT", "Họ và tên", "MST / số định danh", "Nhóm", "Tháng", "Thu nhập chịu thuế", "Bảo hiểm bắt buộc NLĐ", "Số NPT",
                   "Thu nhập tính thuế", "Thuế theo biểu", "Thuế đã khấu trừ (bảng lương)", "Chênh lệch"], K["h"])
    ws.cao(4, 45)
    r, stt, cu = 5, 0, None
    for x in kk["kiem"]:
        if x["ten"] != cu:
            stt += 1
            cu = x["ten"]
            nhan = (str(stt), x["ten"], x["dd"]["ct08"] or x["dd"]["ct09"])
        else:
            nhan = ("", "", "")
        ws.dong(r, 1, [(nhan[0], K["cg"]), (nhan[1], K["c"]), (nhan[2], K["txt"]), (x["loai"], K["cg"]),
                       ("%02d%s" % (x["thang"], "" if x["nguon"] == "PM" else " (Excel)"), K["cg"]),
                       (x["tn"], K["n"]), (x["bh"], K["n"]), (x["npt"], K["n"]), (x["tntt"], K["n"]), (x["bieu"], K["n"]),
                       (x["thue"], K["n"]), (x["thue"] - x["bieu"], K["n"])])
        r += 1
    tong = [sum(x[c] for x in kk["kiem"]) for c in ("tn", "bh", "tntt", "bieu", "thue")]
    ws.dong(r, 1, [("", K["cg"]), ("Cộng", K["cb"]), ("", K["c"]), ("", K["c"]), ("", K["c"]), (tong[0], K["nb"]), (tong[1], K["nb"]),
                   ("", K["nb"]), (tong[2], K["nb"]), (tong[3], K["nb"]), (tong[4], K["nb"]), (tong[4] - tong[3], K["nb"])])
    ws.dong_bang(5, 3)
    ws.in_trang(ngang=True, lap_dong=(4, 4))
    return ws


def _sheet_doi_chieu(wb, K, kk, cb):
    ws = wb.sheet("Doi chieu", cot=[34, 18, 18, 16, 18, 18, 16])
    ws.gop(1, 1, 1, 7, "KIỂM CHÉO 05/KK-TNCN %s VỚI SỔ KẾ TOÁN" % ten_ky(kk["ky"]).upper(), K["qh"])
    r = 3
    if kk["doi"]:
        ws.dong(r, 1, ["Tháng", "Thu nhập bảng lương", "PS Có TK 334", "Chênh lệch", "Thuế đã khấu trừ", "PS Có TK 3335", "Chênh lệch"], K["h"])
        r += 1
        for m, bl, p334, th, p3335 in kk["doi"]:
            ws.dong(r, 1, [("Tháng %02d/%d" % (m, kk["nam"]), K["c"]), (bl, K["n"]), (p334, K["n"]), (bl - p334, K["n"]),
                           (th, K["n"]), (p3335, K["n"]), (th - p3335, K["n"])])
            r += 1
    else:
        ws.gop(r, 1, r, 7, "Không đối chiếu được với sổ (kỳ khai khác năm tài chính của sổ đang mở, hoặc năm tài chính không bắt đầu tháng 1).",
               K["ghi"])
        r += 1
    r += 1
    ws.gop(r, 1, r, 7, "Cảnh báo / ghi chú khi lập:", K["b"])
    r += 1
    for c in cb:
        ws.gop(r, 1, r, 7, "- " + c, K["ghi"])
        ws.cao(r, 15 * max(1, (len(c) + 139) // 140))
        r += 1
    return ws


def _sheet_tt89(wb, K, kk):
    """ky tu quy 3/2026: so tham khao cho cac chi tieu moi cua mau TT89 (phan mem chua theo doi thu nhap mien thue)."""
    ws = wb.sheet("TT89 tham khao", cot=[70, 22])
    ws.gop(1, 1, 1, 2, "SỐ THAM KHẢO CHO MẪU 05/KK-TNCN THEO THÔNG TƯ 89/2026/TT-BTC (%s)" % ten_ky(kk["ky"]), K["qh"])
    ws.gop(2, 1, 2, 2, "Mẫu TT89 bổ sung thu nhập tính thuế, số thuế phải khấu trừ và các khoản thu nhập / thuế được miễn (nhân lực công "
                       "nghệ cao, công nghiệp công nghệ số...). Số dưới đây tính từ bảng lương để anh chị đối chiếu khi nhập trên HTKK có "
                       "mẫu mới; phần mềm chưa theo dõi thu nhập được miễn nên ghi 0.", K["ghi"])
    ws.cao(2, 60)
    ws.dong(4, 1, ["Nội dung", "Số tiền"], K["h"])
    luy = [x for x in kk["kiem"] if x["loai"] == "05-1"]
    dong = [("Tổng thu nhập chịu thuế trả cho cá nhân cư trú", kk["ct"]["22"]),
            ("Tổng thu nhập tính thuế (nhóm lũy tiến, sau giảm trừ gia cảnh và bảo hiểm)", sum(x["tntt"] for x in luy)),
            ("Tổng thu nhập nhóm thuế suất toàn phần (05-2)", sum(x["tn"] for x in kk["kiem"] if x["loai"] == "05-2")),
            ("Số thuế TNCN phải khấu trừ theo biểu (tham khảo)", sum(x["bieu"] for x in kk["kiem"])),
            ("Thu nhập / số thuế được miễn (phần mềm chưa theo dõi)", 0),
            ("Tổng số thuế TNCN đã khấu trừ (bảng lương)", kk["ct"]["30"])]
    r = 5
    for ten, v in dong:
        ws.dong(r, 1, [(ten, K["c"]), (v, K["n"])])
        r += 1
    return ws


def lap_excel(dl, kk, duong, cb):
    from xlsx_viet import SoExcel
    wb = SoExcel(font="Times New Roman", co=11)
    K = _kieu(wb)
    _sheet_to_khai(wb, K, kk, dl)
    _sheet_chi_tiet(wb, K, kk)
    _sheet_doi_chieu(wb, K, kk, cb)
    if (kk["ky"][1], kk["ky"][3][0]) >= (2026, 7):
        _sheet_tt89(wb, K, kk)
    wb.luu(duong)
    return duong


# ------------------------------------------------------------------ XML HTKK (khung cua HTKK tren may)
def _khuon(dl):
    """-> (km, loi): khuon 05/KK-TNCN TT80 tu HTKK tren may (tool_htkk_unesco.khuon_may); ghi nho HTKK da co mau TT89 chua
    (Menu.xml co MaFile 05_KK_TNCN... chua '89')."""
    st = dl.setdefault("_kk_cache", {})
    if "km" in st:
        return st["km"]
    try:
        import tool_htkk_unesco as X
        h = X.tim_htkk()
    except Exception as e:
        st["km"] = (None, "không nạp được tool HTKK (%s)" % e)
        return st["km"]
    if not isinstance(h, dict) or not h.get("goc"):
        st["km"] = (None, "không thấy HTKK cài trên máy")
        return st["km"]
    st["htkk"] = h
    try:
        import xml.etree.ElementTree as ET
        for m in ET.parse(os.path.join(h["goc"], "Project", "Menu.xml")).getroot().iter():
            mf = (m.get("MaFile") or "").upper()
            if X._ten(m) == "Menu" and mf.startswith("05_KK_TNCN") and "89" in mf:
                st["tt89"] = mf
    except Exception:
        pass
    st["km"] = X.khuon_may(h["goc"], MA_FILE)
    return st["km"]


def lap_xml(dl, kk, duong, cb):
    import tool_htkk_unesco as X
    km, loi = _khuon(dl)
    k = kk["ky"]
    if not km:
        cb.append("Chưa lập XML 05/KK-TNCN: %s - nhập %d chỉ tiêu theo sheet 05-KK-TNCN vào HTKK." % (loi, len(CT)))
        return None
    if (k[1], k[3][0]) >= (2026, 7) and (dl.get("_kk_cache") or {}).get("tt89"):
        cb.append("HTKK trên máy đã có khuôn 05/KK-TNCN theo Thông tư 89/2026 - phần mềm chưa cập nhật mã chỉ tiêu mẫu mới nên KHÔNG lập "
                  "XML (tránh sai chỉ tiêu); nhập theo sheet tờ khai và sheet \"TT89 tham khao\" trên HTKK, báo để cập nhật phần mềm.")
        return None
    dn = _dn(dl)
    h = (dl.get("_kk_cache") or {}).get("htkk") or {}
    hd = X.dau_may(km["goc"], dn.get("mst", "")) or {}
    goc = X._khung_ns(km["khung"])
    t = "/HSoKhaiThue/TTinChung/TTinTKhaiThue/TKhaiThue"
    n = "/HSoKhaiThue/TTinChung/TTinTKhaiThue/NNT"
    X._dat(goc, "/HSoKhaiThue/TTinChung/TTinDVu/maDVu", "HTKK")
    X._dat(goc, "/HSoKhaiThue/TTinChung/TTinDVu/tenDVu", "HỖ TRỢ KÊ KHAI THUẾ")
    X._dat(goc, "/HSoKhaiThue/TTinChung/TTinDVu/pbanDVu", re.sub(r"[^\d.]", "", h.get("phien_ban") or "") or "5.7.6")
    X._dat(goc, "/HSoKhaiThue/TTinChung/TTinDVu/ttinNhaCCapDVu", X.TTIN_NHA_CCAP)
    for the in ("maTKhai", "tenTKhai", "moTaBMau", "pbanTKhaiXML"):
        X._dat(goc, t + "/" + the, km[the])
    a, b = tu_den(k)
    lap = _ngay_lap(dl)
    X._dien_ky(goc, {"kyKKhaiTuNgay": a.strftime("%d/%m/%Y"), "kyKKhaiDenNgay": b.strftime("%d/%m/%Y"),
                     "ngayLapTKhai": lap.strftime("%d/%m/%Y"), "loaiTKhai": "C", "soLan": 0})
    ma_cqt = hd.get("maCQTNoiNop") or str(dn.get("ma_cqt") or "")
    ten_cqt = hd.get("tenCQTNoiNop") or str(dn.get("ten_cqt") or "")
    if not ma_cqt:
        cb.append("XML 05/KK-TNCN: THIẾU mã cơ quan thuế nơi nộp (maCQTNoiNop) - chọn lại trên HTKK trước khi nộp.")
    X._dat(goc, t + "/maCQTNoiNop", ma_cqt)
    X._dat(goc, t + "/tenCQTNoiNop", ten_cqt)
    gh = X._tim_nut(goc, t + "/GiaHan")
    if gh is not None:
        for c in list(gh):
            c.text = ""
    X._dat(goc, t + "/nguoiKy", _nguoi_ky(dl))
    X._dat(goc, t + "/nganhNgheKD", hd.get("nganhNgheKD") or "")
    mst = X._mst_so(dn.get("mst") or hd.get("mst"))
    if not re.fullmatch(r"\d{10}(-\d{3})?|\d{12}", mst or ""):
        cb.append("Chưa lập XML 05/KK-TNCN: mã số thuế doanh nghiệp không hợp lệ (%s)." % mst)
        return None
    X._dat(goc, n + "/mst", mst)
    X._dat(goc, n + "/tenNNT", dn.get("ten") or hd.get("tenNNT") or "")
    for the, kh in (("dchiNNT", "dchiNNT"), ("phuongXa", "tenXaPhuongNNT"), ("tenXaNNT", "tenXaPhuongNNT"), ("maXaNNT", "maXaPhuongNNT"),
                    ("maTinhNNT", "maTinhNNT"), ("tenTinhNNT", "tenTinhNNT"), ("dthoaiNNT", "dthoaiNNT"), ("faxNNT", "faxNNT"),
                    ("emailNNT", "emailNNT")):
        X._dat(goc, n + "/" + the, hd.get(kh) or {"dchiNNT": dn.get("dia_chi"), "dthoaiNNT": dn.get("dien_thoai"),
                                                  "emailNNT": dn.get("email"), "faxNNT": dn.get("fax")}.get(the) or "")
    X._dat(goc, n + "/maHuyenNNT", "")
    X._dat(goc, n + "/tenHuyenNNT", "")
    ttk = X._tim_nut(goc, "/HSoKhaiThue/TTinChung/TTinTKhaiThue")
    dly = X._con(ttk, "DLyThue") if ttk is not None else None
    if dly is not None:
        ttk.remove(dly)
    ctn = X._tim_nut(goc, "/HSoKhaiThue/CTieuTKhaiChinh")
    if ctn is None:
        cb.append("Chưa lập XML 05/KK-TNCN: khung HTKK không có CTieuTKhaiChinh.")
        return None
    da, la = set(), []
    for duong_n, nut in X._duyet(ctn):
        if list(nut):
            continue
        m = X._RE_CT.match(X._ten(nut))
        if not m:
            if X._ten(nut) == "mst_cu":
                nut.text = mst
            elif re.match(r"^ct\d+_\w+$", X._ten(nut), re.I):      # GD328: o con moi cua khung HTKK (vd ct25_1 ban 2.9.3) - kieu so, de trong la sai XSD
                nut.text = "0"
                la.append(X._ten(nut))
            continue
        so = m.group(1).lower()
        if so in kk["ct"]:
            nut.text = str(int(kk["ct"][so]))
            da.add(so)
        else:
            nut.text = "0"
            la.append(X._ten(nut))
    thieu = [c for c in CT if c not in da]
    if thieu:
        cb.append("Chưa lập XML 05/KK-TNCN: khung HTKK %s không có chỉ tiêu %s như mẫu TT80 - phần mềm cần cập nhật theo khuôn mới."
                  % (os.path.basename(km["khung"]), ", ".join("[%s]" % c for c in thieu)))
        return None
    if la:
        cb.append("XML 05/KK-TNCN: các ô %s của khung HTKK ghi 0 (phần mềm không theo dõi) - kiểm tra trên HTKK." % ", ".join(la))
    plc = X._tim_nut(goc, "/HSoKhaiThue/PLuc")
    if plc is not None:
        for c in list(plc):
            plc.remove(c)
        plc.text = None
    X.ghi_xml_htkk(goc, duong)
    try:
        loi = X.kiem_hop_le(duong, km.get("xsd"), km["khung"])[1]      # GD328: co lxml + XSD HTKK -> kiem day du (truoc chi kiem noi bo)
    except Exception as e:
        loi = ["không tự kiểm được: %s" % e]
    if loi:
        cb.append("XML 05/KK-TNCN tự kiểm: %s" % "; ".join(loi[:6]))
    return duong


# ------------------------------------------------------------------ lap
def lap(dl, ma="KK_TNCN", kieu="EX", thumuc="."):
    kieu = (kieu or "EX").upper()
    x = dl.get("x1l") or {}
    tu, den = _ngay(x.get("tu")), _ngay(x.get("den"))
    ds_ky = cac_ky(tu, den)
    if not ds_ky:
        return {"tep": [], "canh_bao": ["Kỳ lập 05/KK-TNCN không hợp lệ (%s - %s)." % (x.get("tu"), x.get("den"))]}
    tep, cb_all = [], []
    for k in ds_ky:
        kk = tong_hop_ky(dl, k)
        cb = kk["canh_bao"]
        cb.insert(0, "05/KK-TNCN %s: %d người, [22] TNCT %s, [30] thuế đã khấu trừ %s%s." % (
            ten_ky(k), kk["ct"]["16"], _vn(kk["ct"]["22"]), _vn(kk["ct"]["30"]),
            "" if (k[1], k[3][0]) < (2026, 7) else "; kỳ từ quý 3/2026 theo Thông tư 89/2026/TT-BTC (xem sheet TT89 tham khao)"))
        hau = ("Q%d_%d" % (k[2], k[1])) if k[0] == "Q" else ("T%02d_%d" % (k[2], k[1]))
        if "X" in kieu:
            p = lap_xml(dl, kk, os.path.join(thumuc, "05_KK_TNCN_%s.xml" % hau), cb)
            if p:
                tep.append(p)
        if "E" in kieu:
            p = os.path.join(thumuc, "05_KK_TNCN_%s.xlsx" % hau)
            lap_excel(dl, kk, p, list(cb))
            tep.append(p)
        cb_all.extend(cb)
    return {"tep": tep, "canh_bao": cb_all}
