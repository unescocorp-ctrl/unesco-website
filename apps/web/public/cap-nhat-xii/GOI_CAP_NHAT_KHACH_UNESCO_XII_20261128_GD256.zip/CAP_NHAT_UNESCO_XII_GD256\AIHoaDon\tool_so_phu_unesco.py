# -*- coding: utf-8 -*-
"""
TOOL SO PHU NGAN HANG / BANG LUONG cho UNESCO XI  (AI hoa don - S2)
Doc file so phu Excel/CSV/PDF va bang luong Excel -> JSONL cho VB6 nhap vao HDDT_SP_Dong / HDDT_BL_Dong.
Tai dung parser cua TrichXuatSoPhu\\tool_trich_xuat_so_phu.py (import truc tiep; ban sao ke ben tool nay).

Cach chay (VB6 goi qua HDDT_ChayTool):
  tool_so_phu_unesco.py /unesco:"C:\\...\\3S.MDB" /mst:0319318647 /out:"<thu muc khach>"
        /sophu:"<file hoac thu muc>" [/nganhang:VCB] [/sotk:0123456789]
  tool_so_phu_unesco.py /unesco:... /mst:... /out:... /bangluong:"<file Excel>" /thang:9 /nam:2026
  tool_so_phu_unesco.py /unesco:... /mst:... /out:... /goi_ai_sp:"<file can_goi_ai_sp.jsonl>"
  tool_so_phu_unesco.py /unesco:... /mst:... /out:... /sophu_excel:"<anh hoac PDF>" [/nganhang:VCB] [/ocr:AI|OFFLINE]
        (GD62: anh / PDF -> file Excel so phu to mau de kiem tra truoc khi Import; xem sp_anh_excel.py)
Khong tham so -> mo giao dien web nho (chon file, ngan hang, thang) tren 127.0.0.1.
Nhat ky: AIHoaDon\\nhat-ky-so-phu.txt (so tai khoan chi hien 4 so cuoi).
"""
import io
import os
import re
import sys
import json
import time
import platform
import threading
import unicodedata
import http.server
import urllib.parse
import urllib.request
import urllib.error
from datetime import datetime, date, timedelta

APP_VERSION = "1.1-SP-GD62"
BASE_DIR = os.path.dirname(os.path.abspath(sys.argv[0] if getattr(sys, "frozen", False) else __file__))

if __name__ == "__main__":          # GD111: lien ket .py cua Python install manager / Store bo mat tham so VB6
    try:
        import tham_so_du_phong as _TSDP
        sys.argv = _TSDP.bu_tham_so(sys.argv, BASE_DIR, khong_co=("/hoi:",))
    except Exception:
        pass

LOG_PATH = os.path.join(BASE_DIR, "nhat-ky-so-phu.txt")
SETTINGS_PATH = os.path.join(BASE_DIR, "cai-dat.json")

# ---------------------------------------------------------------- nap parser cu
CU = None
for _d in (BASE_DIR, os.path.join(os.path.dirname(BASE_DIR), "TrichXuatSoPhu"), os.path.join(BASE_DIR, "tham_khao")):
    try:
        if os.path.exists(os.path.join(_d, "tool_trich_xuat_so_phu.py")):
            if _d not in sys.path:
                sys.path.insert(0, _d)
            import tool_trich_xuat_so_phu as CU   # noqa
            break
    except Exception:
        CU = None


# GD50: bo doc noi dung moi (nguoi tra + NH nguoi tra, day so hoa don, khoang ngay, luong viet tat)
ND = None
try:
    if BASE_DIR not in sys.path:
        sys.path.insert(0, BASE_DIR)
    import sp_noi_dung as ND   # noqa
except Exception:
    ND = None


# ---------------------------------------------------------------- nhat ky (che so TK)
def mask_tail(v):
    s = str(v or "")
    return ("*" * max(0, len(s) - 4)) + s[-4:] if len(s) > 4 else s


def scrub(text):
    """Che so tai khoan / so dinh danh 8-16 so trong nhat ky: chi de 4 so cuoi."""
    return re.sub(r"(?<!\d)(\d{9,16})(?!\d)", lambda m: mask_tail(m.group(1)), str(text))


class NhatKy(object):
    def __init__(self, path):
        self.path = path
        self.lock = threading.Lock()

    def ghi(self, msg, che=True):
        s = scrub(msg) if che else str(msg)
        line = datetime.now().strftime("%Y-%m-%d %H:%M:%S") + " " + s
        with self.lock:
            try:
                if os.path.exists(self.path) and os.path.getsize(self.path) > 5 * 1024 * 1024:
                    os.replace(self.path, self.path[:-4] + "-cu.txt")
                with open(self.path, "a", encoding="utf-8") as f:
                    f.write(line + "\n")
            except Exception:
                pass
        try:
            print(line)
        except Exception:
            pass

    def loi(self, msg, e=None):
        import traceback
        self.ghi("LOI: %s | %s" % (msg, e))
        if e is not None:
            self.ghi(traceback.format_exc(), che=False)


LOG = NhatKy(LOG_PATH)


# ---------------------------------------------------------------- tham so
UNESCO = {"mdb": "", "mst": "", "out": "", "sophu": "", "nganhang": "", "sotk": "", "bangluong": "",
          "thang": 0, "nam": 0, "goi_ai_sp": "", "congno": "", "sophu_excel": "", "ocr": "", "bat": False,
          "hosobh": "", "nv": "", "dich_sp": "", "docai_kiem": "", "tess_chep": "", "trang": None}


def _ksp_chuan_nd(s):
    """Noi dung so phu chuan hoa de nhom: bo dau, viet HOA, chi giu chu va so."""
    t = bo_dau(str(s or "")).upper()
    return " ".join(re.sub(r"[^A-Z0-9]+", " ", t).split())


def _ksp_gan_khoa(info, dong):
    """CT-R6: khoa dong so phu = ngan hang | so TK | ngay | so CT NH | tien vao | tien ra | lan xuat hien thu n.
       KHONG dung so thu tu dong trong file: nhap sao ke T1-T3 roi nhap tiep T1-T6 phai ra CUNG khoa."""
    dem = {}
    for d in dong:
        # GD30b: nhom dem phai gom DUNG cac thanh phan cua khoa (ngay | so CT NH | tien vao | tien ra).
        # Ban cu dem theo NOI DUNG trong khi khoa lai khong chua noi dung: hai dong khac noi dung nhung cung
        # so CT + cung tien (vd "CHI LAI TK TIEN GUI" va "LAI NHAP VON", so 3S co 6 cap) ra CUNG khoa,
        # dong thu hai bi coi la trung va mat. Dong khong co so CT thi van tach theo noi dung.
        so_ct = str(d.get("so_ct_nh") or "").strip()
        nhom = (d.get("ngay_gd") or "", round(float(d.get("tien_vao") or 0), 2),
                round(float(d.get("tien_ra") or 0), 2), so_ct if so_ct else "ND:" + _ksp_chuan_nd(d.get("noi_dung")))
        dem[nhom] = dem.get(nhom, 0) + 1
        d["_lan_cu"] = dem[nhom]
    # 18/11/2026 (so THANH_PHU_2026, sao ke MBB T10): dong KHONG co so CT, cung ngay + cung tien nhung KHAC noi dung
    # (22/10 hai lan 5.000.000 cua hai nguoi chuyen) van ra CUNG khoa vi khoa khong chua noi dung -> dong thu hai bi
    # coi la "cap nhat" dong thu nhat va MAT (tong thu thieu 10.000.000 so voi so du cuoi sao ke).
    # Sua: trong moi nhom khoa (ngay | so CT | tien vao | tien ra) so lan phai KHONG trung. Dong da co so rieng giu
    # NGUYEN so cu (khoa cua cac lan nhap truoc khong doi, nhap lai khong nhan doi); chi dong truoc day bi trung khoa
    # moi nhan so moi, lon hon moi so dang co trong nhom.
    lon_nhat, da_dung = {}, {}
    for d in dong:
        g = _ksp_nhom_khoa(d)
        lon_nhat[g] = max(lon_nhat.get(g, 0), d["_lan_cu"])
    for d in dong:
        g = _ksp_nhom_khoa(d)
        dung = da_dung.setdefault(g, set())
        n = d.pop("_lan_cu")
        if n in dung:
            lon_nhat[g] += 1
            n = lon_nhat[g]
        dung.add(n)
        d["lan_thu"] = n
        d["khoa"] = ksp_khoa(info.get("ngan_hang"), info.get("so_tk"), d.get("ngay_gd"),
                             d.get("so_ct_nh"), d.get("tien_vao"), d.get("tien_ra"), n)


def _ksp_nhom_khoa(d):
    """Cac thanh phan cua khoa KSP tru 'lan': ngay | so CT NH | tien vao | tien ra (dung cach viet cua ksp_khoa)."""
    return (str(d.get("ngay_gd") or ""), str(d.get("so_ct_nh") or "").strip(),
            "%.2f" % float(d.get("tien_vao") or 0), "%.2f" % float(d.get("tien_ra") or 0))


def ksp_khoa(nh, stk, ngay, so_ct, vao, ra, lan):
    """Sinh khoa KSP. Dai qua 120 ky tu (gioi han cot KhoaDong) thi rut gon bang ham bam."""
    day = "%s|%s|%s|%s|%.2f|%.2f|%d" % (str(nh or "").upper(), str(stk or ""), str(ngay or ""),
                                        str(so_ct or "").strip(), float(vao or 0), float(ra or 0), int(lan))
    if len(day) <= 120:
        return day
    import hashlib
    return day[:100] + "#" + hashlib.sha1(day.encode("utf-8")).hexdigest()[:16]


def _tach_dong_lenh(s):
    """Tach chuoi tham so thanh danh sach, ton trong dau nhay kep."""
    kq, cur, trong = [], "", False
    for ch in s:
        if ch == '"':
            trong = not trong
            cur += ch
        elif ch in " \t\r\n" and not trong:
            if cur:
                kq.append(cur)
                cur = ""
        else:
            cur += ch
    if cur:
        kq.append(cur)
    return kq


THAM_SO_LOI = []   # GD63: /thamso khong doc duoc -> thoat, khong mo giao dien an duoi pythonw


def mo_rong_tham_so(argv):
    """GD15: /thamso:"<file UTF-8>" -> doc file roi tach thanh cac tham so that.
       VB6 goi tool bang ShellExecute (ANSI) nen duong dan co dau tieng Viet
       (vi du "bang luong 2026.xlsx") bi doi thanh dau hoi neu truyen thang tren dong lenh."""
    out = []
    for a in argv:
        s = str(a).strip()
        if s.lower().startswith("/thamso:"):
            duong = s.split(":", 1)[1].strip().strip('"')
            try:
                with io.open(duong, "r", encoding="utf-8") as f:
                    nd = f.read()
                out.extend(_tach_dong_lenh(nd))
                if "/docai_k:" in nd.lower():
                    try:
                        os.remove(duong)          # GD104: tep tham so co khoa mo goi Google - xoa ngay sau khi doc
                    except Exception:
                        pass
            except Exception as e:
                THAM_SO_LOI.append("%s: %s" % (duong, e))      # GD63
                try:
                    print("Khong doc duoc file tham so %s: %s" % (duong, e))
                except Exception:
                    pass
        else:
            out.append(a)
    return out


def doc_tham_so(argv):
    for a in argv[1:]:
        a = a.strip()
        if not a.startswith("/"):
            continue
        k, v = (a[1:].split(":", 1) + [""])[:2]
        k = k.lower().strip(); v = v.strip().strip('"')
        if k == "unesco":
            UNESCO["mdb"] = v; UNESCO["bat"] = True
        elif k == "mst":
            UNESCO["mst"] = re.sub(r"[^0-9\-]", "", v)
        elif k in ("out", "sophu", "nganhang", "sotk", "bangluong", "goi_ai_sp", "congno", "sophu_excel", "ocr", "hosobh", "nv", "dich_sp", "docai_kiem", "tess_chep"):
            UNESCO[k] = v
            if k in ("sophu", "bangluong", "goi_ai_sp", "congno", "sophu_excel", "hosobh", "dich_sp"):
                UNESCO["bat"] = True
        elif k == "thang":
            UNESCO["thang"] = int(re.sub(r"\D", "", v) or 0)
        elif k == "nam":
            UNESCO["nam"] = int(re.sub(r"\D", "", v) or 0)
        elif k == "trang":                      # GD101: so trang anh / PDF con lai cua ma kich hoat (-1 = khong gioi han)
            try:
                UNESCO["trang"] = int(v)
            except ValueError:
                UNESCO["trang"] = 0
        elif k == "docai_ly_do":                # GD111b: VB bao vi sao KHONG truyen khoa mo (tool bao dung ly do)
            try:
                if BASE_DIR not in sys.path:
                    sys.path.insert(0, BASE_DIR)
                import docai_unesco as _DA
                _DA.dat_ly_do_khoa(v)
            except Exception:
                pass
        elif k == "docai_k":                    # GD104: khoa mo goi Google cai san (VB chi truyen khi da kich hoat + con trang)
            try:
                if BASE_DIR not in sys.path:
                    sys.path.insert(0, BASE_DIR)
                import docai_unesco as _DA
                _DA.dat_khoa_mo(v)
            except Exception:
                pass
    if UNESCO["mst"]:
        try:                                    # GD111b: MST cong ty dang mo -> doan ly do khoa cai san (ban .exe cu)
            if BASE_DIR not in sys.path:
                sys.path.insert(0, BASE_DIR)
            import docai_unesco as _DA
            _DA.dat_mst(UNESCO["mst"])
        except Exception:
            pass
    if UNESCO["bat"] and not UNESCO["out"]:
        goc = os.path.dirname(UNESCO["mdb"]) if UNESCO["mdb"] else BASE_DIR
        UNESCO["out"] = os.path.join(goc, "AIHoaDon", UNESCO["mst"] or "CHUNG")
    return UNESCO


def thu_muc(ten):
    d = os.path.join(UNESCO["out"] or os.path.join(BASE_DIR, "CHUNG"), ten)
    try:
        os.makedirs(d, exist_ok=True)
    except Exception as e:
        LOG.loi("Khong tao duoc thu muc " + d, e)
    return d


# ---------------------------------------------------------------- chuoi
def bo_dau(s):
    if CU is not None:
        try:
            return CU.bo_dau(s)
        except Exception:
            pass
    s = str(s or "").replace("Đ", "D").replace("đ", "d")
    return "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")


def chuan(s):
    """Chu hoa, bo dau, chi A-Z0-9 va khoang trang."""
    t = re.sub(r"[^A-Z0-9 ]+", " ", bo_dau(s).upper())
    return re.sub(r"\s+", " ", t).strip()


def _sa(x):
    return bo_dau(str(x or "")).lower().strip()


def so(x):
    if x is None or x == "":
        return 0.0
    if isinstance(x, bool):
        return 0.0
    if isinstance(x, (int, float)):
        return float(x)
    t = str(x).strip()
    am = t.startswith("(") and t.endswith(")")
    t = t.strip("()").replace(" ", "")
    # GD63: bo chu / don vi tien (VND, d, dong...) TRUOC khi doan dau phan cach: "11.000 VND" truoc day doc thanh 11,
    #   "1,000 VND" thanh 1. Dau tru o CUOI ("11.000-") la so am. Chuoi chi co so + dau: ket qua giu nguyen nhu cu.
    if re.search(r"[^0-9.,\-]", t):
        t = re.sub(r"[^0-9.,\-]", "", t)
    if len(t) > 1 and t.endswith("-") and not t.startswith("-"):
        am = not am
        t = t[:-1]
    if t.count(",") and t.count("."):
        # 1.234.567,89 (VN) hay 1,234,567.89 (EN)
        if t.rfind(",") > t.rfind("."):
            t = t.replace(".", "").replace(",", ".")
        else:
            t = t.replace(",", "")
    elif t.count(",") > 1 or (t.count(",") == 1 and len(t.split(",")[1]) == 3):
        t = t.replace(",", "")
    elif t.count(".") > 1 or (t.count(".") == 1 and len(t.split(".")[1]) == 3):
        t = t.replace(".", "")
    else:
        t = t.replace(",", ".")
    t = re.sub(r"[^0-9.\-]", "", t)
    try:
        v = float(t) if t not in ("", "-", ".") else 0.0
    except ValueError:
        v = 0.0
    return -v if am else v


# AM-BANK-IMPORT-2026.11.28 B03: he ngay cua tep Excel dang doc (True = 1904, Excel Mac cu) - dat trong _doc_so_phu_bang
NGAY_1904 = {"on": False}


def _la_he_ngay_1904(path):
    """B03: True khi workbook dung he ngay 1904 (xlsx: workbookPr date1904; xls: datemode 1). Loi / khong phai Excel -> False."""
    p = str(path or "").lower()
    try:
        if p.endswith((".xlsx", ".xlsm")) and os.path.isfile(path):
            import zipfile
            with zipfile.ZipFile(path) as z:
                x = z.read("xl/workbook.xml").decode("utf-8", "replace")
            m = re.search(r"<(?:\w+:)?workbookPr\b[^>]*\bdate1904\s*=\s*\"(1|true)\"", x, re.I)
            return bool(m)
        if p.endswith(".xls") and os.path.isfile(path):
            import xlrd
            return xlrd.open_workbook(path, on_demand=True).datemode == 1
    except Exception as e:
        LOG.ghi("B03: khong doc duoc he ngay cua %s (%s) - coi la 1900" % (os.path.basename(p), bo_dau(str(e))[:120]))
    return False


def doc_ngay(v):
    """-> 'yyyy-mm-dd' hoac ''. Nhan so serial Excel, dd/mm/yyyy, yyyy-mm-dd, dd-mm-yy, ddmmyyyy.
       B03: so serial theo he ngay cua tep (NGAY_1904); chuoi d/m/y mo ho xu ly sau o _xu_ly_ngay_mo_ho."""
    if v is None or v == "":
        return ""
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        if 20000 < v < 80000:
            try:
                goc = date(1904, 1, 1) if NGAY_1904.get("on") else date(1899, 12, 30)
                return (goc + timedelta(days=int(v))).strftime("%Y-%m-%d")
            except Exception:
                return ""
        return ""
    if isinstance(v, (datetime, date)):
        return v.strftime("%Y-%m-%d")
    s = str(v).strip()
    m = re.match(r"^(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{2,4})", s)
    if m:
        d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if y < 100:
            y += 2000
        if mo > 12 and d <= 12:
            d, mo = mo, d
        try:
            return date(y, mo, d).strftime("%Y-%m-%d")
        except Exception:
            return ""
    m = re.match(r"^(\d{4})[/.\-](\d{1,2})[/.\-](\d{1,2})", s)
    if m:
        try:
            return date(int(m.group(1)), int(m.group(2)), int(m.group(3))).strftime("%Y-%m-%d")
        except Exception:
            return ""
    m = re.match(r"^(\d{2})(\d{2})(\d{4})$", s)
    if m:
        try:
            return date(int(m.group(3)), int(m.group(2)), int(m.group(1))).strftime("%Y-%m-%d")
        except Exception:
            return ""
    return ""


# ---------------------------------------------------------------- doc file bang
# ---------------------------------------------------------------- doc so phu tu ANH / PDF SCAN
DUOI_ANH = (".jpg", ".jpeg", ".png", ".webp", ".tif", ".tiff", ".bmp")
OCR_LAN_NAY = {"dung": False, "canh_bao": [], "so_trang": 0}

# ---------------------------------------------------------------- GD101: so trang anh / PDF theo ma kich hoat AI
GIU_TOI_DA_GIAY = 3 * 3600          # GIU_*.txt cu hon (tool bi tat ngang) -> bo qua


def _dem_trang_pdf_thu_vien(path):
    """So trang PDF bang thu vien co san (pypdfium2 / pypdf / PyPDF2 / pdfplumber); 0 = khong dem duoc."""
    try:
        import pypdfium2 as pdfium
        pdf = pdfium.PdfDocument(path)
        n = len(pdf)
        try:
            pdf.close()
        except Exception:
            pass
        if n > 0:
            return n
    except Exception:
        pass
    for ten in ("pypdf", "PyPDF2"):
        try:
            mod = __import__(ten)
            n = len(mod.PdfReader(path).pages)
            if n > 0:
                return n
        except Exception:
            pass
    try:
        import pdfplumber
        with pdfplumber.open(path) as pdf:
            n = len(pdf.pages)
        if n > 0:
            return n
    except Exception:
        pass
    return 0


def dem_trang(path):
    """So trang cua mot tep anh / PDF (anh = 1; TIFF nhieu trang = so khung). PDF: thu vien doc PDF (thieu thi thu cai
       pypdfium2); khong co thu vien -> dem /Type /Page va /Count trong tep (PDF nen object stream: lay so lon hon).
       Tep khac (Excel, CSV) = 0. Loi doc -> 1 (moi tep anh / PDF it nhat 1 trang)."""
    p = str(path).lower()
    if not p.endswith((".pdf",) + DUOI_ANH):
        return 0
    try:
        if p.endswith(".pdf"):
            n = _dem_trang_pdf_thu_vien(path)
            if n == 0 and _pip_cai("pypdfium2"):
                n = _dem_trang_pdf_thu_vien(path)
            if n > 0:
                return n
            with open(path, "rb") as f:
                b = f.read()
            n = len(re.findall(rb"/Type\s*/Page(?![A-Za-z])", b))
            ds = [int(x) for x in re.findall(rb"/Type\s*/Pages\b[^>]*?/Count\s+(\d+)", b)]
            ds += [int(x) for x in re.findall(rb"/Count\s+(\d+)[^>]*?/Type\s*/Pages\b", b)]
            return max([1, n] + ds)
        if p.endswith((".tif", ".tiff")):
            try:
                from PIL import Image
                with Image.open(path) as im:
                    return max(1, int(getattr(im, "n_frames", 1) or 1))
            except Exception:
                pass
        return 1
    except Exception:
        return 1


def trang_gioi_han():
    """So trang con lai VB truyen (/trang:N). None = khong gioi han (/trang:-1). Khong truyen /trang (chay tay, giao dien
       rieng cua tool, ban VB cu chua bien dich lai) = 0: khong doc anh / PDF."""
    v = UNESCO.get("trang")
    if v is None:
        return 0
    if v < 0:
        return None
    return v


def thu_muc_trang():
    """Thu muc cua MAY (VB doc o day): LOCALAPPDATA\\UNESCO_AI\\trang; khong co bien moi truong -> ket-qua cua cong ty."""
    d = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA") or ""
    d = os.path.join(d, "UNESCO_AI", "trang") if d else thu_muc("ket-qua")
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        pass
    return d


def _ghi_nguyen_tu(duong, noi_dung):
    tam = os.path.join(os.path.dirname(duong), "~T%d.tmp" % os.getpid())
    with open(tam, "w", encoding="ascii", errors="replace") as f:
        f.write(noi_dung)
    os.replace(tam, duong)


def _khoa_trang(thu):
    p = os.path.join(thu, "khoa.lock")
    for _ in range(100):
        try:
            os.close(os.open(p, os.O_CREAT | os.O_EXCL | os.O_WRONLY))
            return p
        except FileExistsError:
            try:
                if time.time() - os.path.getmtime(p) > 60:
                    os.remove(p)
                    continue
            except OSError:
                pass
            time.sleep(0.1)
        except OSError:
            return None
    return None


def _trang_dang_giu(thu):
    """Trang cac lan doc KHAC dang giu (GIU_*.txt con moi) + trang da doc ma VB chua tru (TRANG_*.txt)."""
    tong, bay_gio, cua_toi = 0, time.time(), "GIU_%d.txt" % os.getpid()
    for f in os.listdir(thu):
        if not f.endswith(".txt") or f == cua_toi:
            continue
        p = os.path.join(thu, f)
        if f.startswith("GIU_"):
            try:
                if bay_gio - os.path.getmtime(p) > GIU_TOI_DA_GIAY:
                    os.remove(p)
                    continue
            except OSError:
                continue
        elif not f.startswith("TRANG_"):
            continue
        try:
            with open(p, encoding="ascii", errors="replace") as fh:
                k = int((fh.read().split("|") + [""])[0] or 0)
            if 0 < k < 100000:
                tong += k
        except Exception:
            pass
    return tong


def bo_giu_trang():
    try:
        os.remove(os.path.join(thu_muc_trang(), "GIU_%d.txt" % os.getpid()))
    except OSError:
        pass


def kiem_so_trang(cac_tep, moc):
    """GD101 (tu GD111 khong con goi - thay bang giu_trang_google, chi trang Google cai san). Tong so trang anh / PDF cua cac tep. Co gioi han: vuot (so trang con lai - lan doc khac dang giu - trang chua tru)
       -> ghi moc KHONG_DU_TRANG|can|con, tra None; du -> GIU so trang cho lan doc nay (bo khi ghi TRANG / ket thuc)."""
    can = sum(dem_trang(t) for t in cac_tep)
    con = trang_gioi_han()
    if can <= 0 or con is None:
        return can
    thu = thu_muc_trang()
    khoa = _khoa_trang(thu)
    try:
        con_that = con - _trang_dang_giu(thu)
        if can > con_that:
            LOG.ghi("GD101: can %d trang anh / PDF, ma kich hoat con %d trang (tru lan doc khac / chua tru) -> khong doc" % (can, con_that))
            try:
                with open(os.path.join(thu_muc("ket-qua"), moc), "w", encoding="utf-8") as f:
                    f.write("KHONG_DU_TRANG|%d|%d" % (can, max(0, con_that)))
            except Exception:
                pass
            return None
        _ghi_nguyen_tu(os.path.join(thu, "GIU_%d.txt" % os.getpid()), "%d" % can)
        import atexit
        atexit.register(bo_giu_trang)
        return can
    finally:
        if khoa:
            try:
                os.remove(khoa)
            except OSError:
                pass


def ghi_trang_da_doc(so_trang, ten, che_do):
    """VB tru so trang khi nhan ket qua: <thu muc may>/TRANG_<thoi gian>_<pid>.txt (ASCII, ghi tam roi doi ten). Ghi ca khi
       khong gioi han (de theo doi). Bo GIU cua lan doc nay."""
    try:
        if so_trang > 0:
            thu = thu_muc_trang()
            ten_tep = "TRANG_%s_%d.txt" % (datetime.now().strftime("%Y%m%d%H%M%S%f"), os.getpid())
            _ghi_nguyen_tu(os.path.join(thu, ten_tep),
                           "%d|%s|%s" % (so_trang, bo_dau(os.path.basename(str(ten)))[:120].replace("|", " "), che_do))
            LOG.ghi("GD111: da doc %d trang Google Document AI - khoa cai san (%s)" % (so_trang, che_do))
    except Exception as e:
        LOG.ghi("GD101: khong ghi duoc so trang da doc: %s" % e)
    bo_giu_trang()


# ---------------------------------------------------------------- GD111: so trang = trang doc bang KHOA GOOGLE CAI SAN
#   Chi trang gui Google Document AI bang khoa cai san UNESCO (AIHoaDon\\docai_goi.dat) moi tru so trang cua ma kich hoat
#   (VB truyen /trang:N = so trang Google con lai). OCR Offline (Windows OCR / Tesseract), PDF co chu, Claude va Google
#   rieng cua ke toan (docai.json) KHONG tru. Het / khong du trang Google -> doc bang OCR Offline (khong chan) va ghi
#   HET_GOOGLE_<pid>.txt ("can|con|tep") trong thu muc trang cua MAY -> VB hoi lay MA YEU CAU nap them trang.
GOOGLE_LAN_NAY = {"giu": 0, "da_doc": 0, "het": False}


def google_lan_nay_lai():
    GOOGLE_LAN_NAY.update(giu=0, da_doc=0, het=False)


def _docai():
    if BASE_DIR not in sys.path:
        sys.path.insert(0, BASE_DIR)
    import docai_unesco as DA
    return DA


def khoa_goi_dang_dung():
    """GD111: True neu doc Google lan nay se dung KHOA CAI SAN UNESCO (processor cua goi, hoac docai.json khong co khoa /
       ADC / gcloud rieng -> roi ve khoa cai san). Tinh tien theo khoa thuc dung (docai_unesco.token_la_goi) sau khi doc."""
    try:
        return bool(_docai().se_dung_khoa_goi())
    except Exception:
        return False


def bao_het_google(can, con, ten):
    """GD111: ghi HET_GOOGLE_<pid>.txt "can|con|tep" (ASCII, ghi tam roi doi ten) - mot lan / lan chay tool."""
    if GOOGLE_LAN_NAY["het"]:
        return
    GOOGLE_LAN_NAY["het"] = True
    try:
        _ghi_nguyen_tu(os.path.join(thu_muc_trang(), "HET_GOOGLE_%d.txt" % os.getpid()),
                       "%d|%d|%s" % (max(0, int(can)), max(0, int(con)), bo_dau(os.path.basename(str(ten)))[:120].replace("|", " ")))
        LOG.ghi("GD111: het / khong du trang Google Document AI (can %d, con %d) -> doc bang OCR Offline" % (can, con))
    except Exception as e:
        LOG.ghi("GD111: khong ghi duoc bao het trang Google: %s" % e)


def het_google_khong_khoa(path, st):
    """GD111: VB khong truyen khoa mo vi may HET trang Google (/trang:0) ma ke toan da dong y gui Google va may co khoa cai
       san, khong co Google rieng -> bao het trang (tep nay doc bang OCR Offline)."""
    try:
        if UNESCO.get("trang") != 0 or st.get("cho_phep_docai") is not True:
            return
        DA = _docai()
        if DA.co_tep_goi() and not DA.da_cau_hinh():
            bao_het_google(max(1, dem_trang(path)), 0, path)
    except Exception as e:
        LOG.ghi("GD111: khong kiem duoc het trang Google: %s" % e)


def giu_trang_google(path):
    """GD111: truoc khi gui tep cho Google bang KHOA CAI SAN. Khong gioi han (/trang:-1 - VB cu) -> so trang tep.
       Du (con lai - lan doc khac dang giu - da doc chua tru - lan nay da giu) -> GIU them, tra so trang can;
       khong du -> bao_het_google, tra None (tep nay doc bang OCR Offline)."""
    can = max(1, dem_trang(path))
    con = trang_gioi_han()
    if con is None:
        return can
    thu = thu_muc_trang()
    khoa = _khoa_trang(thu)
    try:
        con_that = con - _trang_dang_giu(thu) - GOOGLE_LAN_NAY["giu"]
        if can > con_that:
            bao_het_google(can, con_that, path)
            return None
        GOOGLE_LAN_NAY["giu"] += can
        _ghi_nguyen_tu(os.path.join(thu, "GIU_%d.txt" % os.getpid()), "%d" % GOOGLE_LAN_NAY["giu"])
        import atexit
        atexit.register(bo_giu_trang)
        return can
    finally:
        if khoa:
            try:
                os.remove(khoa)
            except OSError:
                pass


HET_GOOGLE_LY_DO = "đã hết số trang Google Document AI của mã kích hoạt (cần nạp thêm trang)"


def _ghi_giu():
    try:
        p = os.path.join(thu_muc_trang(), "GIU_%d.txt" % os.getpid())
        if GOOGLE_LAN_NAY["giu"] > 0:
            _ghi_nguyen_tu(p, "%d" % GOOGLE_LAN_NAY["giu"])
        elif os.path.exists(p):
            os.remove(p)
    except Exception:
        pass


def doc_google(path, nh, tam, st):
    """GD111: doc bang Google Document AI. KHOA CAI SAN: giu trang truoc (khong du -> RuntimeError, cach sau = OCR Offline),
       tru DUNG so trang Google da xu ly (ca khi loi giua chung - Google van tinh tien), tra lai phan giu thua. Tep da doc
       (con ket qua luu) doc lai khong goi Google -> khong giu, khong tru. GIU_<pid> = trang da dung + dang giu cua lan chay."""
    if BASE_DIR not in sys.path:
        sys.path.insert(0, BASE_DIR)
    import sp_anh_excel as SAE
    DA = _docai()
    goi = khoa_goi_dang_dung()
    giu = 0
    if goi and not SAE.docai_da_luu(path, tam):
        giu = giu_trang_google(path)
        if giu is None:
            raise RuntimeError(HET_GOOGLE_LY_DO)
    truoc = DA.so_trang_da_gui()
    dung = 0
    try:
        dau, dong = SAE.doc_bang_docai(path, nh, tam, st)
        dung = int(dau.get("so_trang_google") or 0)
        return dau, dong
    except Exception:
        if DA.token_la_goi():
            dung = max(0, DA.so_trang_da_gui() - truoc)          # Google da xu ly mot phan roi moi loi
        raise
    finally:
        if dung or giu:
            GOOGLE_LAN_NAY["da_doc"] += dung
            GOOGLE_LAN_NAY["giu"] = max(0, GOOGLE_LAN_NAY["giu"] + dung - giu)
            _ghi_giu()



PROMPT_OCR_SO_PHU = """Bạn là người nhập liệu kế toán Việt Nam. Ảnh kèm theo là MỘT TRANG sao kê tài khoản ngân hàng.
Nhiệm vụ: đọc lại đúng bảng giao dịch trong ảnh thành dữ liệu. TUYỆT ĐỐI không suy đoán, không
tính toán thêm, không bù số còn thiếu. Ô nào trong ảnh mờ hoặc bị che thì để null và ghi vào "canh_bao".

QUY TẮC ĐỌC SỐ TIỀN VIỆT NAM
- Dấu chấm là phân cách nghìn, dấu phẩy là phân cách thập phân: "1.234.567,89" -> 1234567.89.
- Số trong ngoặc đơn hoặc có dấu trừ là số âm.
- Ô trống, "-", "0.00" đều trả về 0.
- Không làm tròn, không đổi đơn vị.

QUY TẮC ĐỌC NGÀY
- Trả về đúng dạng yyyy-mm-dd. "05/01/2026" là ngày 5 tháng 1 (ngày trước tháng, kiểu Việt Nam).
- Nếu ô ngày chỉ có giờ (dòng nối tiếp của giao dịch phía trên) thì để null.

QUY TẮC VỀ DÒNG
- Một giao dịch có thể chiếm nhiều dòng in: dòng sau chỉ có phần nội dung kéo dài, không có ngày và
  không có số tiền. Hãy GỘP phần nội dung đó vào giao dịch ngay phía trên, KHÔNG tạo giao dịch mới.
- Bỏ qua dòng tiêu đề, dòng tổng cộng, dòng "số dư đầu kỳ"/"số dư cuối kỳ" - nhưng ghi lại giá trị
  số dư đầu kỳ vào "so_du_dau" nếu nhìn thấy.
- Giữ nguyên thứ tự xuất hiện trong ảnh.

TRẢ VỀ DUY NHẤT một đối tượng JSON, không kèm lời giải thích, không kèm dấu ```:
{"ngan_hang": "VCB|BIDV|CTG|TCB|MBB|ACB|VPB|STB|TPB|SHB|HDB|EIB|OCB|MSB|VIB|SEAB|ABB|NAB|AGRI|NH",
 "so_tk": "chuỗi số tài khoản đọc được hoặc null", "so_du_dau": số hoặc null, "trang": số hoặc null,
 "dong": [{"ngay_gd": "yyyy-mm-dd" hoặc null, "so_ct_nh": "số chứng từ ngân hàng" hoặc null,
           "noi_dung": "nguyên văn, giữ dấu tiếng Việt", "tien_vao": số, "tien_ra": số,
           "so_du": số hoặc null, "doi_ung_stk": "số TK đối ứng" hoặc null,
           "doi_ung_ten": "tên đối tác" hoặc null, "do_ro": 0-100}],
 "canh_bao": ["mô tả ngắn từng chỗ đọc không chắc"]}"""


def _anh_nen(b):
    """Thu nho canh dai ve toi da 2400 px, JPEG chat luong 85 - du net cho chu so nho."""
    try:
        from PIL import Image
    except Exception:
        if not _pip_cai("pillow"):
            return b, "image/png"
        try:
            from PIL import Image
        except Exception:
            return b, "image/png"
    try:
        im = Image.open(io.BytesIO(b))
        if im.mode not in ("RGB", "L"):
            im = im.convert("RGB")
        w, h = im.size
        if max(w, h) > 2400:
            tl = 2400.0 / max(w, h)
            im = im.resize((max(1, int(w * tl)), max(1, int(h * tl))), Image.LANCZOS)
        out = io.BytesIO()
        im.save(out, format="JPEG", quality=80)
        return out.getvalue(), "image/jpeg"
    except Exception as e:
        LOG.ghi("Khong nen duoc anh: %s" % e)
        return b, "image/png"


def _anh_tu_pdf(path, dpi=None, max_trang=30):
    """PDF scan -> danh sach anh PNG tung trang (pypdfium2: cai bang pip, khong can Poppler)."""
    try:
        import pypdfium2 as pdfium
    except Exception:
        if not _pip_cai("pypdfium2"):
            raise RuntimeError("Khong doc duoc PDF scan vi may chua co thu vien dung anh trang. "
                               'Hay mo Command Prompt va chay: "%s" -m pip install --user pypdfium2 pillow. '
                               "Hoac mo PDF roi chup man hinh / xuat ra anh va Import lai." % sys.executable)
        import pypdfium2 as pdfium
    if dpi is None:
        # GD21: 200 dpi lam mat net chu so nho tren ban scan -> mac dinh 300, sua duoc trong cai-dat.json
        try:
            dpi = int(doc_thiet_lap().get("ocr_dpi") or 300)
        except Exception:
            dpi = 300
        if dpi < 120 or dpi > 600:
            dpi = 300
    pdf = pdfium.PdfDocument(path)
    n = len(pdf)
    if n > max_trang:
        LOG.ghi("PDF co %d trang, chi doc %d trang dau (doi lai max_trang neu can)." % (n, max_trang))
        n = max_trang
    anh = []
    for i in range(n):
        bm = pdf[i].render(scale=dpi / 72.0)
        out = io.BytesIO()
        bm.to_pil().save(out, format="PNG")
        anh.append(out.getvalue())
    return anh


def _cho_lech_so_du(dong, du_truoc):
    """Kiem tra so du dong sau = so du dong truoc + tien vao - tien ra.
       Tra ve danh sach cho lech (chi so dong bat dau tu 1)."""
    ra, truoc = [], du_truoc
    for i, d in enumerate(dong):
        sd = d.get("so_du")
        vao, raT = so(d.get("tien_vao")), so(d.get("tien_ra"))
        if sd is None:
            continue
        sd = so(sd)
        if truoc is not None:
            cho_doi = truoc + vao - raT
            if abs(cho_doi - sd) > 1:
                ra.append({"dong": i + 1, "mo_ta": "doc duoc %s, theo so du dong tren phai la %s"
                                                   % (fmt_tien(sd), fmt_tien(cho_doi))})
        truoc = sd
    return ra


def fmt_tien(v):
    try:
        return "{:,.0f}".format(float(v)).replace(",", ".")
    except Exception:
        return str(v)


def _ocr_mot_trang(key, model, anh, kieu, trang, tong, nh, stk, du_truoc, nhac_lech=None):
    """Goi Claude vision cho MOT trang. Tra ve dict theo PROMPT_OCR_SO_PHU (rong neu that bai)."""
    import base64
    nguoi_dung = ("Trang %d/%d. Ngân hàng dự kiến: %s. Số tài khoản dự kiến: %s.\n"
                  "Số dư cuối của trang trước: %s - dùng để tự kiểm, KHÔNG được sửa số đọc được cho khớp."
                  % (trang, tong, nh or "chưa rõ", stk or "chưa rõ",
                     ("%.2f" % du_truoc) if du_truoc is not None else "chưa rõ"))
    if nhac_lech:
        nguoi_dung += ("\n\nLẦN ĐỌC TRƯỚC có %d chỗ số dư không khớp. Hãy đọc lại THẬT KỸ các dòng sau "
                       "(nhìn lại từng chữ số trong ảnh, KHÔNG được sửa số cho khớp - nếu ảnh mờ thì "
                       "để null và ghi vào canh_bao):\n" % len(nhac_lech))
        for v in nhac_lech[:12]:
            nguoi_dung += "- dòng %d: %s\n" % (v["dong"], v["mo_ta"])
    body = {"model": model, "max_tokens": 8000, "system": PROMPT_OCR_SO_PHU,
            "messages": [{"role": "user", "content": [
                {"type": "image", "source": {"type": "base64", "media_type": kieu,
                                             "data": base64.b64encode(anh).decode("ascii")}},
                {"type": "text", "text": nguoi_dung}]}]}
    for lan in range(3):
        try:
            req = urllib.request.Request("https://api.anthropic.com/v1/messages",
                                         data=json.dumps(body).encode("utf-8"),
                                         headers={"Content-Type": "application/json", "x-api-key": key,
                                                  "anthropic-version": "2023-06-01"}, method="POST")
            with urllib.request.urlopen(req, timeout=180) as r:
                raw = r.read().decode("utf-8")
            txt = "".join(c.get("text", "") for c in json.loads(raw).get("content", []))
            m = re.search(r"\{.*\}", txt, re.S)
            if not m:
                raise RuntimeError("Claude khong tra ve JSON")
            kq = json.loads(m.group(0))
            LOG.ghi("[OCR] trang %d/%d: %d dong" % (trang, tong, len(kq.get("dong") or [])))
            return kq
        except urllib.error.HTTPError as e:
            LOG.ghi("[OCR] trang %d loi HTTP %s" % (trang, e.code))
            if e.code in (400, 401, 403):
                break
        except Exception as e:
            LOG.loi("[OCR] trang %d lan %d" % (trang, lan + 1), e)
        time.sleep(3)
    OCR_LAN_NAY["canh_bao"].append("Trang %d: khong doc duoc" % trang)
    return {}


def doc_anh_bang_ai(path):
    """Anh / PDF scan -> {"pdf": rows} cung dang voi doc_pdf de doc_so_phu dung lai y nguyen.
       Dong dau la mot dong nhan dien ngan hang + so TK, roi den dong tieu de, roi du lieu."""
    st = doc_thiet_lap()
    if not st.get("cho_phep_gui_anh"):
        raise RuntimeError("File nay khong co chu de doc nen phai dung AI doc anh, nhung muc "
                           "'Cho phep gui anh so phu cho AI' dang TAT. Bat muc do trong tool so phu "
                           "(hoac dat cho_phep_gui_anh = true trong cai-dat.json) roi Import lai. "
                           "Anh se duoc gui toi Claude API de doc; ban van phai xac nhan tung dong truoc khi ghi so.")
    key = st.get("anthropic_key", "")
    model = st.get("anthropic_model") or "claude-sonnet-4-5"
    if not key:
        raise RuntimeError("Chua khai khoa Claude API nen khong doc duoc anh. Khai o tool hoa don "
                           "(nut 'AI goi y') hoac dat anthropic_key trong cai-dat.json.")
    p = path.lower()
    if p.endswith(".pdf"):
        anh = _anh_tu_pdf(path)
    else:
        anh = [open(path, "rb").read()]
    if not anh:
        raise RuntimeError("Khong dung duoc anh tu file: " + path)
    OCR_LAN_NAY["dung"] = True
    OCR_LAN_NAY["so_trang"] = len(anh)
    nh, stk, du_truoc, dong = "", "", None, []
    for i, b in enumerate(anh):
        b2, kieu = _anh_nen(b)
        kq = _ocr_mot_trang(key, model, b2, kieu, i + 1, len(anh), nh, stk[-4:] if stk else "", du_truoc)
        if not kq:
            continue
        # GD21: tu kiem chuoi so du NGAY trong trang. Lech thi doc lai MOT lan va giu ban tot hon.
        lech = _cho_lech_so_du(kq.get("dong") or [], du_truoc)
        if lech:
            LOG.ghi("[OCR] Trang %d: %d cho lech so du -> doc lai mot lan" % (i + 1, len(lech)))
            kq2 = _ocr_mot_trang(key, model, b2, kieu, i + 1, len(anh), nh, stk[-4:] if stk else "",
                                 du_truoc, nhac_lech=lech)
            if kq2:
                lech2 = _cho_lech_so_du(kq2.get("dong") or [], du_truoc)
                if len(lech2) < len(lech):
                    LOG.ghi("[OCR] Trang %d: ban doc lai tot hon (%d -> %d cho lech)"
                            % (i + 1, len(lech), len(lech2)))
                    kq, lech = kq2, lech2
            for v in lech:
                OCR_LAN_NAY["canh_bao"].append(
                    "Trang %d dong %d: so du khong khop (%s) - hay doi chieu voi sao ke goc"
                    % (i + 1, v["dong"], v["mo_ta"]))
        nh = nh or str(kq.get("ngan_hang") or "")
        stk = stk or str(kq.get("so_tk") or "")
        for c in (kq.get("canh_bao") or []):
            OCR_LAN_NAY["canh_bao"].append("Trang %d: %s" % (i + 1, c))
        for d in (kq.get("dong") or []):
            dong.append(d)
            if d.get("so_du") is not None:
                du_truoc = so(d.get("so_du"))
    if not dong:
        raise RuntimeError("AI khong doc duoc dong giao dich nao tu anh. Hay xin ngan hang file Excel/CSV, "
                           "hoac chup lai ro hon. Xem chi tiet trong AIHoaDon\\nhat-ky-so-phu.txt")
    rows = [["SAO KE TAI KHOAN " + (nh or ""), ""], ["So TK: " + (stk or ""), ""],
            ["Ngay GD", "So CT", "Noi dung", "Tien ra", "Tien vao", "So du", "Doi ung"]]
    for d in dong:
        rows.append([d.get("ngay_gd") or "", d.get("so_ct_nh") or "", d.get("noi_dung") or "",
                     so(d.get("tien_ra")), so(d.get("tien_vao")),
                     "" if d.get("so_du") is None else so(d.get("so_du")),
                     (d.get("doi_ung_ten") or "") + (" " + d["doi_ung_stk"] if d.get("doi_ung_stk") else "")])
    LOG.ghi("[OCR] Tong %d trang, %d dong, %d canh bao" % (len(anh), len(dong), len(OCR_LAN_NAY["canh_bao"])))
    return {"pdf": rows}


class NhieuTaiKhoan(RuntimeError):
    """GD98b: anh / PDF scan gom nhieu tai khoan (vd TK thanh toan + TK vay) - da lap moi TK mot file Excel kiem tra;
       chay_so_phu nhap tiep TUNG file (moi TK dung so TK cua no). Noi khac (chua bat) van la loi ro rang."""
    def __init__(self, msg, tep, goc):
        RuntimeError.__init__(self, msg)
        self.tep = list(tep)
        self.goc = goc


def _cach_doc_anh(st):
    """GD98-B: thu tu doc anh / PDF scan khi Import so phu (gui anh ra ngoai chi khi ke toan dong y tung dich vu): Google Document AI (da cai AIHoaDon\\docai.json - ke toan tu
       dang ky dich vu) -> Claude (co khoa + cho phep gui anh) -> OCR Offline (Tesseract / Windows OCR, khong gui anh ra ngoai)."""
    cach = []
    # moi dich vu mot su dong y rieng (hop hoi o phan mem ghi vao cai-dat.json): cho_phep_docai = gui anh cho Google
    #   Document AI; cho_phep_gui_anh = gui anh cho Claude. Khong dong y -> chi OCR Offline tren may.
    try:
        if BASE_DIR not in sys.path:
            sys.path.insert(0, BASE_DIR)
        import docai_unesco as DA
        if st.get("cho_phep_docai") is True and DA.da_cau_hinh():
            cach.append("DOCAI")
    except Exception as e:
        LOG.ghi("Document AI: khong doc duoc cau hinh (%s)" % e)
    if st.get("cho_phep_gui_anh") and st.get("anthropic_key"):
        cach.append("AI")
    cach.append("OFFLINE")
    return cach


def doc_anh_scan(path):
    """GD98-B: anh / PDF scan khi Import so phu truc tiep. Truoc day chi doc bang Claude -> chua khai khoa Claude la loi
       'Chua khai khoa Claude API' (ke ca khi da cai Google Document AI). Nay: Document AI -> Claude -> OCR Offline; ket qua
       OCR lap thanh file Excel kiem tra (cot Trang thai XANH / VANG / DO NHAT) trong AIHoaDon\\<MST>\\so-phu roi doc nhu
       file Excel: dong chua chac (VANG / DO) vao 'Can xem lai'."""
    st = doc_thiet_lap()
    cach = _cach_doc_anh(st)
    loi = []
    dau = dong = None
    for c in cach:
        if c == "AI":
            try:
                kq = doc_anh_bang_ai(path)
                LOG.ghi("Anh / PDF scan: doc bang Claude")
                return kq
            except Exception as e:
                loi.append("Claude: %s" % e)
                LOG.ghi("Anh / PDF scan: Claude loi (%s) -> cach sau" % bo_dau(str(e))[:300])
                continue
        try:
            if BASE_DIR not in sys.path:
                sys.path.insert(0, BASE_DIR)
            import sp_anh_excel as SAE
            SAE.dat_nhat_ky(LOG.ghi)
            tam = os.path.join(thu_muc("ket-qua"), "ocr-offline")
            if c == "DOCAI":
                dau, dong = doc_google(path, "", tam, st)          # GD111: khoa cai san -> giu / tru trang Google
            else:
                if "DOCAI" not in cach:
                    het_google_khong_khoa(path, st)          # GD111: het trang -> VB khong truyen khoa mo
                dau, dong = SAE.doc_bang_offline(path, "", tam, st)
            if loi:
                dau.setdefault("canh_bao", []).insert(0, "Đọc bằng %s vì: %s" % (dau.get("cach_doc") or c, "; ".join(loi)[:300]))
            LOG.ghi("Anh / PDF scan: doc bang %s - %d dong" % (c, len(dong)))
            break
        except Exception as e:
            loi.append("%s: %s" % ("Google Document AI" if c == "DOCAI" else "OCR Offline", e))
            LOG.ghi("Anh / PDF scan: %s loi (%s) -> cach sau" % (c, bo_dau(str(e))[:300]))
            dau = dong = None
    if dau is None:
        raise RuntimeError("Không đọc được ảnh / PDF scan: " + " | ".join(loi)[:900])
    nhom = SAE.tach_tai_khoan(dau, dong)
    cac = []
    # Excel kiem tra de o ket-qua\sophu-excel (KHONG o thu muc so-phu - noi Import ca thu muc: se doc lai lan hai),
    #   ten co dinh theo tep goc, ghi de khi doc lai
    thu_x = thu_muc(os.path.join("ket-qua", "sophu-excel"))
    goc = re.sub(r"[^A-Za-z0-9_.-]+", "_", bo_dau(os.path.splitext(os.path.basename(path))[0])).strip("_") or "so_phu"
    da_dung = set()
    for gi, (dau_g, dong_g) in enumerate(nhom):
        SAE.kiem_tra(dau_g, dong_g)
        duoi = ""
        if len(nhom) > 1:
            duoi = "_TK" + (dau_g.get("so_tk") or "")[-4:] if dau_g.get("so_tk") else "_TK_CHUA_RO_%d" % (gi + 1)
            # 28/11/2026 (thu P1 tren PDF scan Sacombank VTP T04-05): cung mot TK tach thanh nhieu nhom (nhieu doan sao ke) -> truoc day
            #   cung ten tep: nhom sau GHI DE nhom truoc (mat 317 + 31 dong) va tep cuoi bi nhap 3 lan -> them so thu tu nhom
            if duoi in da_dung:
                duoi = "%s_%d" % (duoi, gi + 1)
            da_dung.add(duoi)
        ra = os.path.join(thu_x, "%s_SOPHU_EXCEL%s.xlsx" % (goc[:80], re.sub(r"[^A-Za-z0-9_]", "", duoi)))
        try:
            SAE.lap_excel(dau_g, dong_g, ra, path)
        except Exception:
            ra = SAE.ten_tep_ra(ra, thu_x)          # tep cu dang mo trong Excel -> ten khac
            SAE.lap_excel(dau_g, dong_g, ra, path)
        cac.append((ra, dau_g, dong_g))
        LOG.ghi("Anh / PDF scan -> Excel kiem tra TK %s: %d dong -> %s" % (mask_tail(dau_g.get("so_tk") or "?"), len(dong_g), ra))
    if len(cac) > 1:
        # nhieu tai khoan trong mot PDF: KHONG nhap mot phan (bo sot giao dich cac TK khac) - chay_so_phu nhap tung file
        raise NhieuTaiKhoan("PDF có %d tài khoản - đã lập %d file Excel trong %s: %s." % (
            len(cac), len(cac), thu_x, ", ".join(os.path.basename(x[0]) for x in cac)), [x[0] for x in cac], path)
    ra, dau_g, dong_g = cac[0]
    tab = doc_bang(ra)
    OCR_LAN_NAY["dung"] = True
    OCR_LAN_NAY["canh_bao"] = list(dau_g.get("canh_bao") or [])
    return tab


def doc_bang(path, so_phu=False):
    """-> {sheet: [[cell,...],...]} tu xls/xlsx/csv/pdf/anh. so_phu=True (Import so phu): anh / PDF scan doc bang Document
       AI / Claude / OCR Offline (GD98-B); noi khac (bang luong, BHXH) giu cach cu (Claude)."""
    p = path.lower()
    OCR_LAN_NAY["dung"] = False
    OCR_LAN_NAY["canh_bao"] = []
    OCR_LAN_NAY["so_trang"] = 0
    if p.endswith(DUOI_ANH):
        return doc_anh_scan(path) if so_phu else doc_anh_bang_ai(path)          # GD98-B: Document AI / Claude / OCR Offline
    if p.endswith(".csv") or p.endswith(".txt"):
        import csv
        with open(path, "rb") as _f:      # GD63: dong tep ngay (Windows: tep sao ke dang mo bi khoa)
            raw = _f.read()
        # GD63: chi thu UTF-16 khi co BOM (UTF-16 "doc duoc" gan nhu moi chuoi byte chan -> CSV ANSI ra chu rac)
        cac_ma = ("utf-16",) if raw[:2] in (b"\xff\xfe", b"\xfe\xff") else ("utf-8-sig", "cp1258", "latin-1")
        for enc in cac_ma:
            try:
                txt = raw.decode(enc)
                break
            except Exception:
                txt = None
        if txt is None:
            txt = raw.decode("utf-8", "replace")
        try:
            dialect = csv.Sniffer().sniff(txt[:4000], delimiters=",;\t|") if len(txt) > 20 else csv.excel
        except Exception:
            dialect = csv.excel            # GD63: Sniffer khong doan duoc -> dau phay
        rows = [list(r) for r in csv.reader(txt.splitlines(), dialect)]
        return {"csv": rows}
    if p.endswith(".pdf"):
        try:
            kq = doc_pdf(path)
        except Exception as e:
            LOG.ghi("PDF khong co chu de doc (%s) -> doc anh trang (GD98-B: Document AI / Claude / OCR Offline)." % e)
            return doc_anh_scan(path) if so_phu else doc_anh_bang_ai(path)
        if not (kq.get("pdf") or []):
            LOG.ghi("PDF khong co dong nao -> doc anh trang (GD98-B).")
            return doc_anh_scan(path) if so_phu else doc_anh_bang_ai(path)
        return kq
    if CU is not None:
        return CU.doc_excel(path)
    # du phong: openpyxl / xlrd neu co
    if p.endswith((".xlsx", ".xlsm")):
        import openpyxl
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        return {ws.title: [list(r) for r in ws.iter_rows(values_only=True)] for ws in wb.worksheets}
    import xlrd
    wb = xlrd.open_workbook(path)
    return {sh.name: [[sh.cell_value(r, c) for c in range(sh.ncols)] for r in range(sh.nrows)] for sh in wb.sheets()}


_PIP_DA_THU = set()


def _pip_cai(ten):
    """Thu tu cai mot goi Python con thieu (moi goi chi thu mot lan trong phien)."""
    import subprocess
    if ten in _PIP_DA_THU:
        return False
    _PIP_DA_THU.add(ten)
    try:
        LOG.ghi("Thieu thu vien '%s' - dang thu tu cai (pip install --user)..." % ten)
        r = subprocess.run([sys.executable, "-m", "pip", "install", "--user",
                            "--disable-pip-version-check", "-q", ten],
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=420)
        out = (r.stdout or b"").decode("utf-8", "replace").strip()
        LOG.ghi("pip install %s -> ma %s %s" % (ten, r.returncode, out[-400:]))
        if r.returncode == 0:
            import importlib
            import site
            try:
                importlib.reload(site)
            except Exception:
                pass
            importlib.invalidate_caches()
            return True
    except Exception as e:
        LOG.ghi("Khong tu cai duoc '%s': %s" % (ten, e))
    return False


def _nap_thu_vien_pdf():
    """Tra ve (ten, module) cua thu vien doc PDF dau tien dung duoc; tu cai neu may chua co."""
    ds = (("pdfplumber", "pdfplumber"), ("pypdf", "pypdf"),
          ("PyPDF2", "PyPDF2"), ("pdfminer.six", "pdfminer.high_level"))
    for ten, mod in ds:
        try:
            return ten, __import__(mod, fromlist=["*"])
        except Exception:
            pass
    for ten, mod in (("pdfplumber", "pdfplumber"), ("pypdf", "pypdf")):
        if _pip_cai(ten):
            try:
                return ten, __import__(mod, fromlist=["*"])
            except Exception:
                pass
    return "", None


def _pdf_text_thanh_hang(txt):
    """Tach text mot trang PDF thanh hang/cot: cot cach nhau tu 2 khoang trang tro len."""
    rows = []
    for ln in (txt or "").splitlines():
        ln = ln.replace("\t", "   ").rstrip()
        if not ln.strip():
            continue
        cells = [c.strip() for c in re.split(r"\s{2,}", ln.strip()) if c.strip()]
        if cells:
            rows.append(cells)
    return rows


def _pdf_hang_tu_tu(words, dung_sai=3.0, khe=6.0):
    """Gom cac 'tu' co toa do thanh hang (theo toa do doc) va tach cot khi khe ngang lon.
       Chinh xac hon doc text tho vi khong phu thuoc so khoang trang."""
    hang = {}
    for w in words:
        try:
            k = int(round(float(w["top"]) / dung_sai))
        except Exception:
            continue
        hang.setdefault(k, []).append(w)
    rows = []
    for k in sorted(hang):
        ws = sorted(hang[k], key=lambda x: float(x["x0"]))
        cells, cur, truoc = [], [], None
        for w in ws:
            if truoc is not None and float(w["x0"]) - float(truoc["x1"]) > khe:
                cells.append(" ".join(cur))
                cur = []
            cur.append(str(w.get("text", "")))
            truoc = w
        if cur:
            cells.append(" ".join(cur))
        cells = [c.strip() for c in cells if c.strip()]
        if cells:
            rows.append(cells)
    return rows


def doc_pdf(path):
    """PDF so phu. Uu tien pdfplumber (doc duoc bang); khong co thi doc text roi tach cot."""
    ten, mod = _nap_thu_vien_pdf()
    if not mod:
        raise RuntimeError(
            "Khong doc duoc file PDF vi may chua co thu vien doc PDF va khong tu cai duoc. "
            "Cach nhanh nhat: mo file sao ke bang Excel, luu thanh .xlsx hoac .csv roi Import lai. "
            'Hoac mo Command Prompt va chay: "%s" -m pip install --user pdfplumber' % sys.executable)
    rows = []
    if ten == "pdfplumber":
        with mod.open(path) as pdf:
            for pg in pdf.pages:
                bang = pg.extract_tables() or []
                for tb in bang:
                    for r in tb:
                        rows.append([("" if c is None else str(c).replace("\n", " ")) for c in r])
                if not bang:
                    try:                       # khong co bang ke khung -> gom tu theo toa do
                        rows.extend(_pdf_hang_tu_tu(pg.extract_words() or []))
                    except Exception:
                        rows.extend(_pdf_text_thanh_hang(pg.extract_text() or ""))
    elif ten in ("pypdf", "PyPDF2"):
        rd = mod.PdfReader(path)
        for pg in rd.pages:
            rows.extend(_pdf_text_thanh_hang(pg.extract_text() or ""))
    else:
        rows.extend(_pdf_text_thanh_hang(mod.extract_text(path) or ""))
    if not rows:
        raise RuntimeError(
            "File PDF nay khong co chu de doc (thuong la ban scan/anh). Hay xin ngan hang file Excel/CSV, "
            "hoac mo PDF roi copy bang sang Excel va Import lai.")
    LOG.ghi("Doc PDF bang '%s': %d hang" % (ten, len(rows)))
    return {"pdf": rows}


# ---------------------------------------------------------------- nhan dien so phu
NGAN_HANG = [("VIETCOMBANK|VCB", "VCB"), ("BIDV|DAU TU VA PHAT TRIEN", "BIDV"), ("VIETINBANK|CONG THUONG|CTG|ICB", "CTG"),
             ("TECHCOMBANK|TCB", "TCB"), ("MBBANK|MB BANK|QUAN DOI|MBB", "MBB"), ("ACB|A CHAU", "ACB"),
             ("VPBANK|VP BANK|VPB", "VPB"), ("SACOMBANK|STB", "STB"), ("TPBANK|TIEN PHONG|TPB", "TPB"), ("SHB", "SHB"),
             ("HDBANK|HDB", "HDB"), ("EXIMBANK|EIB", "EIB"), ("OCB|PHUONG DONG", "OCB"), ("MSB|MARITIME|HANG HAI", "MSB"),
             ("VIB", "VIB"), ("SEABANK|SEAB", "SEAB"), ("ABBANK|ABB", "ABB"), ("NAM A BANK|NAB", "NAB"),
             ("AGRIBANK|AGRI|NONG NGHIEP", "AGRI"), ("VBSP|CHINH SACH", "VBSP")]

H_NGAY = r"ngay (gd|giao dich|hach toan|hieu luc)?|^ngay$|^date|trans(action)? date|value date|posting date"
H_SOCT = r"so (gd|giao dich|chung tu|ct|but toan|tham chieu|ref)|ma gd|ma giao dich|^ref|reference|transaction (no|id|ref)|so tham chieu|doc no"
H_ND = r"dien giai|noi dung|description|mo ta|remark|narrative|ghi chu|transaction detail|content"
H_RA = r"ghi no|^no$|debit|tien ra|phat sinh no|withdraw|so tien ra|chi$|^chi |ps no|rut|tru"
H_VAO = r"ghi co|^co$|credit|tien vao|phat sinh co|deposit|so tien vao|thu$|^thu |ps co|nop|cong|tien gui|gui vao"          # GD336: Sacombank "So tien gui"
H_DU = r"so du|balance|du cuoi"
H_DU_ = (r"tk doi ung|doi ung|tai khoan doi ung|counter|ben huong thu|beneficiary|nguoi nhan|nguoi chuyen|ten doi ung|"
         # GD191: MB "DON VI THU HUONG/DON VI CHUYEN", VCB/BIDV/TCB "Doi tac / Nguoi thu huong / Nguoi huong / Ten nguoi gui-nhan"
         r"don vi thu huong|don vi chuyen|don vi doi tac|nguoi thu huong|nguoi huong|nguoi gui|nguoi tra|nguoi nop|"
         r"ten nguoi (gui|nhan|chuyen|huong)|ten tk|ten tai khoan|khach hang doi ung|doi tac|payer|payee|remitter|sender|receiver|"
         r"ordering|originator|ten don vi")
H_TIEN = r"^so tien$|amount"


def _tim_cot(H, rx):
    for i, c in enumerate(H):
        if c and re.search(rx, c):
            return i
    return -1


def go_ngat_dong(nd):
    """GD191: sao ke xuat Excel (MB...) ngat noi dung thanh tung doan co dinh (35 ky tu) roi noi bang HAI dau cach:
    'cua cty bb Tan p  hong', 'cty cuong   thinh' -> 'cua cty bb Tan phong', 'cty cuong thinh'.
    Chi noi khi moi diem ngat deu cach nhau cung mot do dai L (30-80, sai so 2 khi doan ket thuc bang dau cach)."""
    nd = str(nd or "")
    if "  " not in nd:
        return nd
    gaps = [(m.start(), m.end()) for m in re.finditer(r" {2,}", nd)]
    dai, truoc = [], 0
    for g0, g1 in gaps:
        dai.append(g0 - truoc)                 # do dai doan truoc diem ngat (doan ket thuc bang dau cach that -> ngan hon 1)
        truoc = g1
    L = max(dai)
    if not 30 <= L <= 80 or any(d < L - 2 for d in dai) or len(nd) - truoc > L + 1:
        return nd
    cat = [g1 - 2 for g0, g1 in gaps]          # bo DUNG 2 dau cach cuoi cum (dau cach that o truoc giu nguyen)
    ra, i = [], 0
    for c in cat:
        ra.append(nd[i:c]); i = c + 2
    ra.append(nd[i:])
    return "".join(ra)



def nhan_dien_ngan_hang(rows, goi_y=""):
    if goi_y:
        return goi_y.upper()
    ma_biet = set(ma for _, ma in NGAN_HANG)
    for r in rows[:8]:                      # GD64: o "Ngan hang: <ma>" o dau file (file Excel so phu do tool tao)
        for c in r:
            m = re.match(r"^\s*ngan hang\s*:\s*([a-z]{2,6})\s*$", _sa(c)) if c else None
            if m and m.group(1).upper() in ma_biet:
                return m.group(1).upper()
    txt = " ".join(chuan(c) for r in rows[:20] for c in r if c)
    for rx, ma in NGAN_HANG:
        if re.search(r"\b(%s)\b" % rx, txt):
            return ma
    return "NH"


def tim_so_tk(rows, goi_y=""):
    if goi_y:
        return re.sub(r"\D", "", goi_y)
    for r in rows[:25]:
        for i, c in enumerate(r):
            t = _sa(c)
            if re.search(r"so tai khoan|so tk|account (no|number)|stk|tai khoan so", t):
                m = re.search(r"(\d[\d ]{6,20}\d)", str(c))
                if m:
                    return re.sub(r"\D", "", m.group(1))
                for j in range(i + 1, min(i + 4, len(r))):
                    v = r[j]
                    if v is None or v == "":
                        continue
                    s = "%d" % v if isinstance(v, float) else str(v)
                    m = re.search(r"(\d[\d ]{6,20}\d)", s)
                    if m:
                        return re.sub(r"\D", "", m.group(1))
    return ""


# ---------------------------------------------------------------- GD97-C: cong ty / chu tai khoan ghi trong tep
_RX_MST97 = re.compile(r"(?<!\d)(\d{10}(?:-\d{3})?)(?!\d)")


def _o97(c):
    if c is None:
        return ""
    if isinstance(c, float) and c.is_integer():
        return "%d" % c
    return str(c).strip()


def tim_chu_tk(rows):
    """GD97-C: ten chu tai khoan / MST tren dau sao ke -> (ten, mst). Chuoi rong neu khong thay."""
    ten, mst = "", ""
    for r in (rows or [])[:30]:
        r = list(r or [])
        for i, c in enumerate(r):
            s = _o97(c)
            if not s:
                continue
            k = _sa(s)
            if not ten and re.search(r"ten tai khoan|chu tai khoan|ten chu tk|chu tk|account name|ten khach hang|customer name|ten don vi|account holder|chu so huu", k):          # GD111c: + account holder
                m = re.search(r"[:\-]\s*(.{4,120})$", s)
                v = m.group(1).strip() if m else ""
                if not v or re.search(r"\d{6,}", v):
                    v = next((_o97(x) for x in r[i + 1:i + 4] if _o97(x) and not re.fullmatch(r"[\d .,:-]+", _o97(x))), "")
                if len(v) >= 4:
                    ten = v[:150]
            if not mst and re.search(r"ma so thue|\bmst\b|tax code|tax id", k):
                m = _RX_MST97.search(s)
                if not m:
                    for x in r[i + 1:i + 4]:
                        m = _RX_MST97.search(_o97(x))
                        if m:
                            break
                if m:
                    mst = m.group(1)
    return ten, mst


def tim_cty_tep(tab, so_dong=15):
    """GD97-C: ten cong ty / MST ghi o dau tep (tieu de bang luong) -> (ten, mst)."""
    ten, mst = "", ""
    for _sh, A in (tab or {}).items():
        for r in (A or [])[:so_dong]:
            r = list(r or [])
            for i, c in enumerate(r):
                s = _o97(c)
                if not s:
                    continue
                k = _sa(s)
                if not mst and re.search(r"ma so thue|\bmst\b|tax code", k):
                    m = _RX_MST97.search(s)
                    if not m:
                        for x in r[i + 1:i + 4]:
                            m = _RX_MST97.search(_o97(x))
                            if m:
                                break
                    if m:
                        mst = m.group(1)
                if not ten and re.match(r"^(ten don vi\s*:?\s*)?(cong ty|cty|doanh nghiep|dntn|hop tac xa|chi nhanh|company|ho kinh doanh)\b", k):
                    ten = re.sub(r"^(?i:ten don vi)\s*:?\s*", "", s)[:150]
        if ten and mst:
            break
    return ten, mst


STK_RX = re.compile(r"(?<!\d)(\d{8,16})(?!\d)")


def tach_doi_ung(nd, chieu="VAO"):
    """Tach so TK / ten doi tac tu noi dung: 'CT tu 0123456789 NGUYEN VAN A toi 987...' , 'tu: ...'.
    chieu RA: uu tien ten sau "cho / toi / den / thanh toan cho"."""
    stk, ten, uv = "", "", []
    if chieu == "RA":
        m = re.search(r"\b(?:cho|toi|den|to)\s+((?:CONG TY|CTY|CT|DNTN|HKD|HO KINH DOANH)[A-Za-zÀ-ỹ0-9 .,&\-]{3,80}?)(?:\s+(?:so|stk|tk|hd|hoa don|mst|thang|ngay|toi|tai|mot phan|phan con lai|con lai|het|tien|tt|thanh toan|theo)\b|$)", nd, re.I)          # GD336: dung truoc "mot phan hoa don"
        if m:
            ten = m.group(1).strip()
    m = re.search(r"(?:tu|from)\s*[:\-]?\s*(\d{8,16})\s+([A-Za-zÀ-ỹ][A-Za-zÀ-ỹ .,&\-]{3,60}?)(?:\s+(?:toi|to|den|-)\b|$)", nd, re.I)
    if m:
        stk, ten = m.group(1), m.group(2).strip()
    if not stk:
        m = STK_RX.search(nd)
        if m and not re.search(r"\bMST\b\s*" + m.group(1), nd, re.I):
            stk = m.group(1)
    if CU is not None:
        try:
            uv = CU.boc_ten(nd) or []
        except Exception:
            uv = []
    if not ten and uv:
        ten = uv[0]
    if not ten:
        m = re.match(r"^([A-Za-zÀ-ỹ][A-Za-zÀ-ỹ .&\-]{3,55}?)\s+(?:chuyen|thanh toan|tt\b|ck\b|tra|nop|hoan|gui)", nd, re.I)
        if m:
            ten = m.group(1).strip()
    # §3: tra ve CA danh sach ung vien de ben VB6 kiem tra nguoc voi danh muc KH
    ds = []
    for x in ([ten] + list(uv)):
        x = (x or "").strip()[:120]
        if x and x not in ds:
            ds.append(x)
    return stk, ten[:120], ds[:4]


def so_hd_trong_nd(nd):
    if CU is not None:
        try:
            return ",".join(CU.truy_vet(nd)["hd"][:10])
        except Exception:
            pass
    out = []
    t = bo_dau(nd)
    # "HD 123", "hoa don 0000123", "INV#123"
    for m in re.finditer(r"\b(?:hd|hoa\s*don|inv|so\s*hd)\s*[:#]?\s*0*(\d{1,8})", t, re.I):
        if m.group(1) not in out:
            out.append(m.group(1))
    # GD21: dang "ky hieu + so" hay gap tren sao ke: 1C26TAA 00001234 / C26TYY-123
    for m in re.finditer(r"\b\d?[A-Z]\d{2}[A-Z]{2,3}\b\s*[-/]?\s*0*(\d{1,8})\b", t, re.I):
        if m.group(1) not in out:
            out.append(m.group(1))
    return ",".join(out[:10])


# GD21 - MST Viet Nam co SO KIEM TRA o chu so thu 10:
#   tong = sum(chu so 1..9 x [31,29,23,19,17,13,7,5,3]) ; chu so 10 = 10 - (tong mod 11)
# Nho no ma doc duoc MST viet TRAN trong noi dung chuyen khoan (khong co chu "MST"),
# va khong nham so tai khoan / ma giao dich 10 chu so thanh MST.
_TRONG_SO_MST = (31, 29, 23, 19, 17, 13, 7, 5, 3)


def la_mst(s):
    """True neu chuoi la MST hop le (10 so, hoac 13 so = 10 so + 3 so don vi truc thuoc)."""
    s = re.sub(r"\D", "", str(s or ""))
    if len(s) == 13:
        s = s[:10]
    if len(s) != 10 or not s.isdigit():
        return False
    tong = sum(int(s[i]) * _TRONG_SO_MST[i] for i in range(9))
    kt = 10 - (tong % 11)
    return kt <= 9 and kt == int(s[9])


def mst_trong_nd(nd):
    """Uu tien MST viet kem chu 'MST'; khong co thi quet moi cum 10/13 chu so va
       giu lai cum nao qua duoc so kiem tra."""
    nd = str(nd or "")
    m = re.search(r"\bMST\s*[:\-]?\s*(\d{10}(?:-?\d{3})?)\b", nd, re.I)
    if m:
        v = m.group(1).replace("-", "")
        if la_mst(v):
            return v
    for m in re.finditer(r"(?<!\d)(\d{10})(?:[-\s]?(\d{3}))?(?!\d)", nd):
        v = m.group(1) + (m.group(2) or "")
        if la_mst(v):
            return v
    return ""


def ngay_hd_trong_nd(nd):
    """Ngay ghi trong dien giai (ISO) - de loc hoa don truoc khi doi chieu so."""
    if CU is None:
        return ""
    try:
        v = CU.truy_vet(nd).get("ngay") or ""
    except Exception:
        return ""
    p = v.split("/")
    if len(p) == 3 and len(p[2]) == 4:
        return "%s-%s-%s" % (p[2], p[1], p[0])
    return ""


def loai_goi_y(nd):
    if CU is not None:
        try:
            return CU.loai_gd(nd) or ""
        except Exception:
            pass
    u = chuan(nd)
    if "KBNN" in u or "NTDT" in u:
        return "NOP_THUE"
    if re.search(r"TRA LUONG|LUONG THANG|LUONG T\d|THANH TOAN LUONG|CHI LUONG", u):
        return "LUONG"
    if re.search(r"LAI NHAP VON|LAI TIEN GUI|LAI NHAP GOC|TRA LAI TG", u):
        return "LAI_TG"
    if re.search(r"PHI DICH VU|PHI QUAN LY|PHI SMS|PHI THUONG NIEN|THU PHI|PHI CHUYEN", u):
        return "PHI_NH"
    if re.search(r"NOP TM|NOP TIEN MAT", u):
        return "NOP_TM"
    return ""


def _loai_gd50(nd, chieu):
    cu = loai_goi_y(nd)
    if ND is None:
        return cu
    try:
        return ND.loai_them(nd, chieu, cu) or ""
    except Exception:
        return cu


# ---------------------------------------------------------------- GD111c: PDF so phu dang dong chu (in tu Excel / iBanking)
LY_DO_0_DONG = []          # GD111c: tep doc duoc nhung 0 giao dich -> ly do cho moc KHONG_CO_DU_LIEU (VB6 hien trong hop loi)
_NGAY_RX = r"\d{1,2}[/.\-]\d{1,2}[/.\-]\d{4}|\d{4}-\d{2}-\d{2}"
_SAU_NGAY = r"(?:\s+\d{1,2}:\d{2}(?::\d{2})?)?(?:\s*(?:" + _NGAY_RX + r")(?:\s+\d{1,2}:\d{2}(?::\d{2})?)?)?\s*(.*)$"
_GD_DAU = re.compile(r"^\s*(?:(\d{1,6})[\s.]+)?(" + _NGAY_RX + r")" + _SAU_NGAY)
_GD_DAU_DINH = re.compile(r"^\s*(\d{1,6})(\d{2}[/.\-]\d{2}[/.\-]\d{4})" + _SAU_NGAY)          # STT dinh lien ngay ("106/01/2026")
_SO_RX = re.compile(r"(?<![\d/:.,\-])(-?\d(?:[\d.,]*\d)?)")          # chu cai dinh truoc so van nhan ("Nam777,600")
_TIEN_RX = re.compile(r"-?(?:\d{1,3}(?:[.,]\d{3})+|\d+)(?:[.,]\d{1,2})?")
_BO_DONG_RX = re.compile(r"cong phat sinh|total recorded|tong cong|tong phat sinh|so du cuoi|ending balance|closing balance|"
                         r"luy ke|month to date|so du dau|opening balance|openning balance")
_SO_DU_DAU_RX = re.compile(r"(so du dau(?: ky)?|openn?ing balance|beginning balance|du dau ky)\D{0,30}?(-?\d(?:[\d.,]*\d)?)")
_COT_NO_RX = r"debit|ghi no|tien rut|rut ra|phat sinh no|ps no|withdraw"
_COT_CO_RX = r"credit|ghi co|tien gui|gui vao|phat sinh co|ps co|deposit|tien vao"
_DAU_GIU_RX = re.compile(r"tai khoan|account|so tk|chu tk|holder|ngan hang|bank|khach hang|customer|ma so thue|\bmst\b")


def _pdf_dong_chu(path):
    """GD111c: cac dong chu cua PDF theo THU TU VE (content stream). pypdf giu thu tu ve nen chu dien giai tran o (Excel in
       khong ngat dong) khong xen vao cot so tien; khong co pypdf -> pdfplumber: ky tu gom theo hang, trong hang giu thu tu ve."""
    m = None
    for ten in ("pypdf", "PyPDF2"):
        try:
            m = __import__(ten)
            break
        except Exception:
            m = None
    dong = []
    if m is not None:
        for pg in m.PdfReader(path).pages:
            o = []          # moi o = mot khoi BT..ET (Excel ve tung o rieng); pypdf day chu cua o ra sau ET, truoc BT sau

            def _bt(op, args, cm, tm, o=o):
                if op == b"BT":
                    o.append([])

            def _chu(t, cm, tm, fd, fs, o=o):
                if t:
                    if not o:
                        o.append([])
                    o[-1].append(t)
            try:
                pg.extract_text(visitor_operand_before=_bt, visitor_text=_chu)
                # khoang trang GIUA cac o: pypdf moi khong chen khi chu o truoc tran de len o sau ("Thu Duc5,000,000")
                s = " ".join("".join(c) for c in o if c)
            except TypeError:
                s = pg.extract_text() or ""          # PyPDF2 cu khong co visitor
            dong.extend(s.splitlines())
        return dong
    try:
        import pdfplumber
    except Exception:
        return dong
    with pdfplumber.open(path) as pdf:
        for pg in pdf.pages:
            hang, khoa = {}, []
            for c in pg.chars:
                t = float(c["top"])
                k = next((x for x in khoa if abs(x - t) <= 2.0), None)
                if k is None:
                    k = t
                    khoa.append(k)
                hang.setdefault(k, []).append(c)
            for k in sorted(hang):
                s, truoc = [], None
                for c in hang[k]:
                    if truoc is not None and (float(c["x0"]) - float(truoc["x1"]) > 1.2 or float(c["x0"]) < float(truoc["x0"]) - 0.5):
                        s.append(" ")
                    s.append(str(c.get("text", "")))
                    truoc = c
                dong.append("".join(s))
    return dong


def _duoi_tien(s):
    """GD111c: -> ([vi tri], [chuoi so]) 1-3 so tien CUOI dong (sau so cuoi khong con chu so; chu dinh lien sau so van nhan)."""
    ms = list(_SO_RX.finditer(s))
    if not ms or re.search(r"\d", s[ms[-1].end():]):
        return [], []
    ds = [ms[-1]]
    for m in reversed(ms[:-1]):
        if len(ds) >= 3 or s[m.end():ds[-1].start()].strip():
            break
        ds.append(m)
    ds.reverse()
    while ds and not _TIEN_RX.fullmatch(ds[0].group(1)):
        ds.pop(0)
    if not ds or not all(_TIEN_RX.fullmatch(m.group(1)) for m in ds):
        return [], []
    return [m.start() for m in ds], [m.group(1) for m in ds]


def _cat_nd(than, vt, so_ct):
    """GD111c: dien giai = phan dong truoc so tien thu nhat (bo so giao dich o dau)."""
    nd = than[:vt].strip()
    if so_ct and nd.startswith(so_ct):
        nd = nd[len(so_ct):].strip()
    return nd


def _pdf_bang_dong_chu(path):
    """GD111c: so phu PDF dang dong chu -> bang chuan [[...]] (dau sao ke + tieu de + giao dich) hoac None.
       Moi dong bat dau [STT] ngay [gio] [ngay hieu luc] la mot giao dich; so cuoi = so du, so truoc = so tien; RUT / GUI theo
       chenh lech so du. Duoi 60% dong khop so du (va khong phai dang 2 cot Rut | Gui co so 0) -> None (khong dung)."""
    L = [re.sub(r"\s+", " ", str(x)).strip() for x in _pdf_dong_chu(path)]
    L = [x for x in L if x]
    if not L:
        return None
    ngoai, gd, mo, cur = [], [], None, None          # ngoai: dong khong thuoc giao dich (dau sao ke, tieu de, chan trang)
    for x in L:
        xa = _sa(x)
        if mo is None:
            m = _SO_DU_DAU_RX.search(xa)
            if m:
                mo = so(m.group(2))
        m = _GD_DAU.match(x) or _GD_DAU_DINH.match(x)
        if m:
            cur = {"ngay": m.group(2), "than": (m.group(3) or "").strip(), "ds": []}
            gd.append(cur)
        elif cur is None or cur["ds"] or _BO_DONG_RX.search(xa):
            ngoai.append(x)          # pypdf: dau sao ke co the nam SAU cac giao dich trang 1 (thu tu ve)
            continue
        else:
            cur["than"] = (cur["than"] + " " + x).strip()
        if not cur["ds"]:
            vt, ds = _duoi_tien(cur["than"])
            if len(ds) >= 2 or (len(ds) == 1 and re.search(r"so du dau|opening", _sa(cur["than"]))):
                cur["vt"], cur["ds"] = vt, [so(t) for t in ds]
    gd = [g for g in gd if g["ds"]]
    if len(gd) < 2:
        return None
    td = _sa(" ".join(ngoai[:80]))
    a, b = re.search(_COT_NO_RX, td), re.search(_COT_CO_RX, td)
    no_truoc = not (a and b and b.start() < a.start())          # thu tu cot Rut | Gui (mac dinh Rut truoc)

    def _hai(x, y):
        return (x, y) if no_truoc else (y, x)          # -> (rut, gui)

    def _vao_mac_dinh(nd):
        return bool(re.search(r"nop|gop von|nhan|lai|hoan|credit|chuyen den|tien vao", _sa(nd)))

    hang, khop, truoc = [], 0, mo
    for g in gd:
        than, ds = g["than"], g["ds"]
        if len(ds) == 1:          # dong "So du dau ky" co ngay
            truoc = ds[0]
            continue
        nd = than[:g["vt"][-2]].strip()          # dien giai den truoc so tien (so thu 3 tu cuoi thuoc dien giai, tru dang 3 cot)
        t = nd.split(" ", 1)
        if t and (re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9\\/\-_.]{5,}", t[0]) and re.search(r"\d", t[0])
                  and (re.search(r"[A-Za-z]", t[0]) or len(t[0]) >= 10)):
            so_ct, nd = t[0], (t[1] if len(t) > 1 else "")
        else:
            so_ct = ""
        du, tien = ds[-1], ds[-2]
        rut = gui = 0.0
        ok = False
        if truoc is not None:
            c = du - truoc
            if abs(c - tien) <= 1:
                gui, ok = tien, True
            elif abs(c + tien) <= 1:
                rut, ok = tien, True
            elif len(ds) >= 3:
                r3, g3 = _hai(ds[-3], ds[-2])
                if abs(c - (g3 - r3)) <= 1:
                    rut, gui, ok = r3, g3, True
                    nd = _cat_nd(than, g["vt"][-3], so_ct)
            if not ok and rut == 0 and gui == 0:
                gui, rut = (tien, 0.0) if c >= 0 else (0.0, tien)
        elif len(ds) >= 3 and 0 in (ds[-3], ds[-2]):
            rut, gui = _hai(ds[-3], ds[-2])
            nd = _cat_nd(than, g["vt"][-3], so_ct)
        else:
            gui, rut = (tien, 0.0) if _vao_mac_dinh(nd) else (0.0, tien)
        khop += 1 if ok else 0
        truoc = du
        hang.append([g["ngay"], so_ct, nd, rut or "", gui or "", du])
    if khop >= 0.6 * max(len(hang) - 1, 1):
        cach = "so du"
    else:
        hai = [g for g in gd if len(g["ds"]) >= 2 and 0 in (g["ds"][-2], g["ds"][-1])]
        if len(hai) < 0.8 * len(gd):
            return None
        cach, hang = "2 cot Rut | Gui", []
        for g in hai:
            rut, gui = _hai(g["ds"][-2], g["ds"][-1])
            nd = g["than"][:g["vt"][-2]].strip()
            hang.append([g["ngay"], "", nd, rut or "", gui or "", ""])
    giu = [[x] for x in ngoai[:200] if _DAU_GIU_RX.search(_sa(x)) and not re.search(H_ND, _sa(x))][:40]
    LOG.ghi("GD111c: PDF dong chu %s: %d giao dich, %d khop so du (so du dau %s, cach %s)"
            % (os.path.basename(path), len(hang), khop, "co" if mo is not None else "khong", cach))
    return giu + [["Ngay giao dich", "So giao dich", "Dien giai", "Ghi no", "Ghi co", "So du"]] + hang


def _diem_so_du(dong):
    """GD111c: so dong co so du lien tuc (du(n) - du(n-1) = vao - ra) - chon cach doc PDF tot hon."""
    d0, n = None, 0
    for d in dong or []:
        du = d.get("so_du")
        if du is None:
            continue
        if d0 is not None and abs((du - d0) - (d.get("tien_vao", 0) - d.get("tien_ra", 0))) <= 1:
            n += 1
        d0 = du
    return n


def doc_so_phu(path, nganhang="", sotk="", tab=None, ocr_du_phong=True):
    """GD111c: doc theo bang (_doc_so_phu_bang). PDF ma bang loi / 0 giao dich / duoi 90% dong khop so du -> doc them theo
       DONG CHU (_pdf_bang_dong_chu), lay cach ra nhieu dong khop so du hon. Tep 0 giao dich -> ly do vao LY_DO_0_DONG.
       GD118: PDF co chu ma ca hai cach van 0 giao dich / khong thay dong tieu de (mau sao ke la) -> doc nhu anh scan
       (ve anh trang: Document AI / OCR Offline) truoc khi bao loi (ocr_du_phong=False: noi goi tu lo OCR)."""
    kq, loi = None, None
    try:
        kq = _doc_so_phu_bang(path, nganhang, sotk, tab)
    except NhieuTaiKhoan:
        raise
    except Exception as e:
        loi = e
    if str(path).lower().endswith(".pdf") and (kq is None or not kq[1] or _diem_so_du(kq[1]) < 0.9 * (len(kq[1]) - 1)):
        kq2 = None
        try:
            bang = _pdf_bang_dong_chu(path)
            if bang:
                i = next(k for k, r in enumerate(bang) if r and r[0] == "Ngay giao dich")
                # ngan hang chi doan tren dau sao ke (dien giai giao dich nhac ngan hang doi ung)
                kq2 = _doc_so_phu_bang(path, nganhang or nhan_dien_ngan_hang(bang[:i], ""), sotk, {"pdf_dong_chu": bang})
        except NhieuTaiKhoan:
            raise
        except Exception as e2:
            LOG.ghi("GD111c: doc PDF theo dong chu khong duoc (%s)" % bo_dau(str(e2))[:300])
        if kq2 and kq2[1] and (kq is None or not kq[1] or _diem_so_du(kq2[1]) > _diem_so_du(kq[1])):
            LOG.ghi("GD111c: %s - dung cach doc DONG CHU: %d giao dich, %d khop so du (doc theo bang: %s)"
                    % (os.path.basename(str(path)), len(kq2[1]), _diem_so_du(kq2[1]),
                       ("loi: " + bo_dau(str(loi))[:120]) if kq is None else "%d giao dich, %d khop" % (len(kq[1]), _diem_so_du(kq[1]))))
            return kq2
    if ocr_du_phong and str(path).lower().endswith(".pdf") and (kq is None or not kq[1]):
        # GD118: vd. HDBank (DHBANK.pdf): thay dong tieu de nhung cot ngay / tien vao khong nhan ra -> 0 giao dich
        try:
            LOG.ghi("GD118: %s - PDF co chu nhung %s -> doc nhu anh scan (Document AI / OCR Offline)"
                    % (os.path.basename(str(path)), "khong thay dong tieu de" if kq is None else "0 giao dich theo bang / dong chu"))
            kq3 = _doc_so_phu_bang(path, nganhang, sotk, doc_anh_scan(path))
            if kq3 and kq3[1]:
                LOG.ghi("GD118: %s - doc nhu anh scan: %d giao dich" % (os.path.basename(str(path)), len(kq3[1])))
                return kq3
            LOG.ghi("GD118: doc nhu anh scan van 0 giao dich")
        except NhieuTaiKhoan:
            raise
        except Exception as e3:
            LOG.ghi("GD118: doc nhu anh scan khong duoc (%s)" % bo_dau(str(e3))[:300])
    if kq is None:
        raise loi
    if not kq[1]:
        c = kq[0].get("cot", {})
        ly_do = ("%s: tim thay dong tieu de %s nhung 0 giao dich (cot ngay=%s, noi dung=%s, tien ra=%s, tien vao=%s) - mau so phu "
                 "chua ho tro: xuat Excel tu iBanking hoac gui tep cho UNESCO"
                 % (kq[0].get("tep", ""), kq[0].get("tieu_de_dong", "?"), c.get("ngay"), c.get("noi_dung"), c.get("ra"), c.get("vao")))
        LY_DO_0_DONG.append(bo_dau(ly_do))
        LOG.ghi("GD111c: " + bo_dau(ly_do))
    return kq


def _phan_tich_nd336(d, nd, ngay):
    """GD336: tach doi ung / so HD / MST / ung vien tu noi dung DAY DU (sau khi noi cac dong tiep cua cung giao dich).
    Chi dien lai cac truong boc tu noi dung; so TK / ten lay tu cot doi ung cua ngan hang (neu co) giu nguyen."""
    chieu_d = "RA" if d.get("tien_ra", 0) > 0 else "VAO"
    stk, ten, ds_uv = tach_doi_ung(nd, chieu_d)
    kq_nd = {}
    if ND is not None:
        try:
            kq_nd = ND.doc_noi_dung(nd, chieu_d, int(str(ngay)[:4] or 0)) or {}
        except Exception:
            kq_nd = {}
    if kq_nd.get("ten_tra"):
        ten = kq_nd["ten_tra"][:120]
        if ten in ds_uv:
            ds_uv.remove(ten)
        ds_uv.insert(0, ten)
        ds_uv = ds_uv[:4]
    d["noi_dung"] = nd[:2000]
    if not d.get("_du_cot"):
        d["doi_ung_stk"] = stk
        d["doi_ung_ten"] = ten
    elif ten and ten not in ds_uv:
        ds_uv.append(ten)
    d["mst_nd"] = mst_trong_nd(nd)
    d["so_hd_nd"] = (kq_nd.get("so_hd", "") if ND is not None else so_hd_trong_nd(nd))
    d["loai_goi_y"] = _loai_gd50(nd, chieu_d)
    d["ten_ung_vien"] = "|".join(x for x in ds_uv if x)[:255]
    d["ngay_hd"] = (kq_nd.get("ngay_hd") or ngay_hd_trong_nd(nd))
    d["ngan_hang_du"] = kq_nd.get("ma_nh_tra", "")
    d["ngay_tu"] = kq_nd.get("ngay_tu", "")
    d["ngay_den"] = kq_nd.get("ngay_den", "")
    return d


def _la_dong_tong336(nd, so_ct):
    """GD336: dong 'Tong gui vao / Total credit / Cong phat sinh' cua sao ke scan bi OCR doc thanh giao dich."""
    c = chuan(nd)
    return bool(re.match(r"^(TONG|TOTAL|CONG PHAT SINH|CONG SO PHAT SINH)( |$)", c)) and not so_ct


_RX_NGAY_DMY = re.compile(r"^\s*(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{2,4})")
# B10: nhan dong tong / so du in tren sao ke (chuan(): chu hoa khong dau)
#   chi nhan khi nhan o DAU dong (dong khong ngay) - dong tiep dien giai co chu "tong chi phi..." khong bi doc thanh so tong
_RX_TONG_DAU = re.compile(r"^(SO DU DAU|DU DAU KY|OPENING BALANCE|BEGINNING BALANCE|BALANCE BROUGHT FORWARD)\b")
_RX_TONG_CUOI = re.compile(r"^(SO DU CUOI|DU CUOI KY|CLOSING BALANCE|ENDING BALANCE)\b")
_RX_TONG_SO_GD = re.compile(r"^(TONG SO (LUONG )?GIAO DICH|SO (LUONG )?GIAO DICH|NUMBER OF TRANSACTIONS|TOTAL TRANSACTIONS)\b")
_RX_TONG_VAO = re.compile(r"^(TONG (SO )?(GHI CO|PHAT SINH CO|TIEN VAO|THU|GUI VAO)|TOTAL CREDITS?|CREDIT TOTAL)\b")
_RX_TONG_RA = re.compile(r"^(TONG (SO )?(GHI NO|PHAT SINH NO|TIEN RA|CHI|RUT RA)|TOTAL DEBITS?|DEBIT TOTAL)\b")
_RX_TONG_CHUNG = re.compile(r"^(TONG|CONG|TOTAL)( CONG| PHAT SINH| SO PHAT SINH)?( |:|$)")


def _so_trong_o(c):
    """B10: so tien trong mot o (so hoac chuoi co chu so); None khi o khong co so."""
    if c is None or isinstance(c, bool):
        return None
    if isinstance(c, (int, float)):
        return float(c)
    t = str(c)
    m = re.search(r"\(?-?\d[\d.,]*\)?-?", t)
    if not m or not re.search(r"\d", m.group(0)):
        return None
    return so(m.group(0))


def _ghi_tong_nh(su_kien, r, nhan, vt, iVao, iRa, iDu):
    """B10: dong so du / tong do NGAN HANG in -> su_kien (vt = so giao dich da doc truoc dong nay). True khi la dong tong."""
    g = lambda j: (r[j] if 0 <= j < len(r) else None)
    so_o = [x for x in (_so_trong_o(c) for c in r) if x is not None]
    if _RX_TONG_DAU.search(nhan):
        v = _so_trong_o(g(iDu)) if iDu >= 0 and _so_trong_o(g(iDu)) is not None else (so_o[-1] if so_o else None)
        if v is not None:
            su_kien.append((vt, "dau", round(v, 2)))
            return True
    if _RX_TONG_CUOI.search(nhan):
        v = _so_trong_o(g(iDu)) if iDu >= 0 and _so_trong_o(g(iDu)) is not None else (so_o[-1] if so_o else None)
        if v is not None:
            su_kien.append((vt, "cuoi", round(v, 2)))
            return True
    if _RX_TONG_SO_GD.search(nhan) and so_o:
        su_kien.append((vt, "so_gd", int(round(abs(so_o[-1])))))
        return True
    da = False
    if _RX_TONG_VAO.search(nhan) and so_o:
        su_kien.append((vt, "vao", round(abs(so_o[-1]), 2))); da = True
    elif _RX_TONG_RA.search(nhan) and so_o:
        su_kien.append((vt, "ra", round(abs(so_o[-1]), 2))); da = True
    elif _RX_TONG_CHUNG.search(nhan) and (iVao >= 0 or iRa >= 0):
        vv = _so_trong_o(g(iVao)) if iVao >= 0 else None
        rr = _so_trong_o(g(iRa)) if iRa >= 0 else None
        if vv is not None:
            su_kien.append((vt, "vao", round(abs(vv), 2))); da = True
        if rr is not None:
            su_kien.append((vt, "ra", round(abs(rr), 2))); da = True
    return da


def _doi_soat_ky(dong, su_kien, ten_tep):
    """AM-BANK-IMPORT B10: chia giao dich thanh doan theo moc 'so du dau' cua ngan hang (chum PDF nhieu ky); moi doan so
       dau + tong vao - tong ra = cuoi, tong vao / tong ra / so giao dich doc duoc = so ngan hang in. Ghi vao tung dong:
       xac_minh_ky = DAT / KHONG_DAT / CHUA_XAC_MINH, ly_do_ky. Thieu so chinh thuc -> CHUA_XAC_MINH (khong ha chuan).
       Tra ve danh sach ket qua tung doan (cho tep _tong.json)."""
    moc = sorted(set([0] + [vt for vt, k, _ in su_kien if k == "dau"]))
    kq_ds = []
    for i, bd in enumerate(moc):
        kt = moc[i + 1] if i + 1 < len(moc) else len(dong)
        if kt <= bd and not any(bd <= vt <= kt for vt, _, _ in su_kien):
            continue
        doan = dong[bd:kt]
        nh = {}
        for vt, k, v in su_kien:
            # dau: dung tai moc; con lai: sau moc (dong tong in cuoi doan, truoc moc doan sau)
            if (k == "dau" and vt == bd) or (k != "dau" and (bd < vt <= kt or (i == 0 and vt == 0))):
                if k in nh and nh[k] != v:
                    nh.setdefault("_khac", []).append(k)          # cung doan hai so khac nhau -> khong tu chon
                nh.setdefault(k, v)
        vao = round(sum(d["tien_vao"] for d in doan), 2)
        ra = round(sum(d["tien_ra"] for d in doan), 2)
        loi, thieu = [], []
        dau, cuoi = nh.get("dau"), nh.get("cuoi")
        if dau is not None and cuoi is not None and abs(dau + vao - ra - cuoi) > 0.5:
            loi.append("dau %s + vao %s - ra %s khac cuoi %s" % (fmt_tien(dau), fmt_tien(vao), fmt_tien(ra), fmt_tien(cuoi)))
        if "vao" in nh and abs(nh["vao"] - vao) > 0.5:
            loi.append("tong vao doc %s khac ngan hang %s" % (fmt_tien(vao), fmt_tien(nh["vao"])))
        if "ra" in nh and abs(nh["ra"] - ra) > 0.5:
            loi.append("tong ra doc %s khac ngan hang %s" % (fmt_tien(ra), fmt_tien(nh["ra"])))
        if "so_gd" in nh and nh["so_gd"] != len(doan):
            loi.append("so giao dich doc %d khac ngan hang %d" % (len(doan), nh["so_gd"]))
        if nh.get("_khac"):
            loi.append("ngan hang in hai so khac nhau cho " + ", ".join(sorted(set(nh.pop("_khac")))))
        # chum nhieu ky: dong dau doan dut so du so voi doan TRUOC nhung khop so du dau ngan hang in cho doan nay
        #   -> cho dut thuoc doan truoc (doan do da KHONG_DAT), khong chan doan nay
        if i > 0 and doan and dau is not None and doan[0].get("canh_bao") == "SO_DU_KHONG_LIEN_TUC" and doan[0].get("so_du") is not None \
                and abs(doan[0]["so_du"] - doan[0]["tien_vao"] + doan[0]["tien_ra"] - dau) <= 0.5:
            doan[0].pop("canh_bao", None)
            if kq_ds and kq_ds[-1]["ket_qua"] != "KHONG_DAT":
                kq_ds[-1]["ket_qua"] = "KHONG_DAT"
                kq_ds[-1]["ly_do"] = "so du cuoi ky truoc khong noi duoc voi so du dau ky sau"
                for d in dong[moc[i - 1]:bd]:
                    d["xac_minh_ky"] = "KHONG_DAT"
                    d["ly_do_ky"] = kq_ds[-1]["ly_do"]
        gap = sum(1 for d in doan if d.get("canh_bao") == "SO_DU_KHONG_LIEN_TUC")
        if gap:
            loi.append("%d dong so du khong lien tuc" % gap)
        for k, ten in (("dau", "so du dau"), ("cuoi", "so du cuoi"), ("vao", "tong vao"), ("ra", "tong ra")):
            if k not in nh:
                thieu.append(ten)
        kq = "KHONG_DAT" if loi else ("CHUA_XAC_MINH" if thieu else "DAT")
        ly_do = "; ".join(loi) if loi else (("thieu " + ", ".join(thieu) + " do ngan hang in") if thieu else "khop so ngan hang")
        for d in doan:
            d["xac_minh_ky"] = kq
            d["ly_do_ky"] = ly_do[:400]
        ngay = [d.get("ngay_gd", "") for d in doan if d.get("ngay_gd")]
        kq_ds.append({"tep": ten_tep, "tu": min(ngay) if ngay else "", "den": max(ngay) if ngay else "", "so_dong": len(doan),
                      "tong_vao": vao, "tong_ra": ra, "ngan_hang": nh, "ket_qua": kq, "ly_do": ly_do})
        LOG.ghi("  B10 %s doan %d (%d dong %s..%s): %s - %s" % (ten_tep, i + 1, len(doan), ngay and min(ngay) or "?", ngay and max(ngay) or "?", kq, ly_do))
    return kq_ds


def _xu_ly_ngay_mo_ho(dong, ten_tep):
    """AM-BANK-IMPORT B03: ngay dang chuoi d/m/y. Co ngay > 12 o vi tri 1 -> tep dd/mm (da xac minh trong tep);
       chi co > 12 o vi tri 2 -> mm/dd: doc lai; co ca hai, hoac khong co can cu ma co ngay mo ho (vd 03/04) -> canh_bao NGAY_MO_HO
       (giu ngay doc theo dd/mm, cho nguoi kiem). Ngay kieu so / datetime khong mo ho."""
    dmy = mdy = 0
    mo_ho = []
    for d in dong:
        t = d.get("_ngay_tho")
        m = _RX_NGAY_DMY.match(t) if isinstance(t, str) else None
        if not m:
            continue
        a, b = int(m.group(1)), int(m.group(2))
        if a > 12 and b <= 12:
            dmy += 1
        elif b > 12 and a <= 12:
            mdy += 1
        elif a != b:
            mo_ho.append(d)
    if mdy and not dmy:
        for d in dong:
            m = _RX_NGAY_DMY.match(d.get("_ngay_tho") or "") if isinstance(d.get("_ngay_tho"), str) else None
            if m:
                y = int(m.group(3)); y = y + 2000 if y < 100 else y
                try:
                    d["ngay_gd"] = date(y, int(m.group(1)), int(m.group(2))).strftime("%Y-%m-%d")
                except Exception:
                    pass
        LOG.ghi("  B03 %s: ngay dang thang/ngay (mm/dd) - da doc lai %d dong" % (ten_tep, len(dong)))
    elif mo_ho and (dmy == 0 or mdy > 0):
        for d in mo_ho:
            if not d.get("canh_bao"):
                d["canh_bao"] = "NGAY_MO_HO"
        LOG.ghi("  B03 %s: %d dong ngay mo ho (dd/mm hay mm/dd chua xac minh trong tep) -> NGAY_MO_HO, can kiem" % (ten_tep, len(mo_ho)))
    for d in dong:
        d.pop("_ngay_tho", None)


def _doc_so_phu_bang(path, nganhang="", sotk="", tab=None):
    """-> (info, [dong]). Dong: dict theo cot HDDT_SP_Dong (ten truong = JSON).
       GD62: tab = bang da doc san (chay_so_phu_excel truyen PDF co chu); cot "Trang thai" (file Excel do
       Anh -> Excel tao ra): dong chua ghi OK / XANH -> nguon ANH + canh bao OCR_... -> vao Can xem lai."""
    tab = doc_bang(path, so_phu=True) if tab is None else tab          # GD98-B
    ten_sheet = next((s for s in tab if re.search(r"so\s*phu|sophu|statement|sao ke|giao dich", s, re.I)), None)
    S = tab[ten_sheet] if ten_sheet else max(tab.values(), key=lambda a: len(a))
    S = [list(r) for r in S if r is not None]
    hR, H = -1, None
    for i, r in enumerate(S[:80]):
        cells = [_sa(c) for c in r]
        if _tim_cot(cells, H_ND) >= 0 and (_tim_cot(cells, H_NGAY) >= 0 or _tim_cot(cells, H_RA) >= 0 or _tim_cot(cells, H_VAO) >= 0):
            hR, H = i, cells
            break
    _hR0 = hR          # GD97-C: dong tieu de goc - chu TK chi tim o cac dong TREN tieu de
    if hR < 0:
        raise RuntimeError("Khong tim thay dong tieu de so phu (can cot Ngay / Dien giai / Tien vao / Tien ra)")
    # tieu de 2 dong (Phat sinh | No | Co)
    H2 = [_sa(c) for c in S[hR + 1]] if hR + 1 < len(S) else []
    if H2 and _tim_cot(H, H_RA) < 0 and (_tim_cot(H2, r"^no$|debit|ghi no") >= 0):
        H = [(a + " " + b).strip() if b else a for a, b in zip(H + [""] * len(H2), H2 + [""] * len(H))]
        hR += 1
    iNg = _tim_cot(H, H_NGAY); iCT = _tim_cot(H, H_SOCT); iND = _tim_cot(H, H_ND)
    iRa = _tim_cot(H, H_RA); iVao = _tim_cot(H, H_VAO); iDu = _tim_cot(H, H_DU); iDU = _tim_cot(H, H_DU_)
    iTien = _tim_cot(H, H_TIEN) if (iRa < 0 and iVao < 0) else -1
    iTT = _tim_cot(H, r"^trang thai$")          # GD62
    if iRa < 0 and iVao < 0 and iTien < 0:
        raise RuntimeError("Khong tim thay cot Tien vao / Tien ra")
    _chu97, _mst97 = tim_chu_tk(S[:max(_hR0, 0)])          # GD97-C: VB doi chieu chu TK voi cong ty dang mo (cot "Ten TK doi ung" khong tinh)
    info = {"ngan_hang": nhan_dien_ngan_hang(S, nganhang), "so_tk": tim_so_tk(S, sotk), "tep": os.path.basename(path),
            "tieu_de_dong": hR + 1, "cot": {"ngay": iNg, "so_ct": iCT, "noi_dung": iND, "ra": iRa, "vao": iVao, "so_du": iDu, "doi_ung": iDU}}
    LOG.ghi("So phu %s: NH=%s TK=%s tieu de dong %d cot ngay=%d ct=%d nd=%d ra=%d vao=%d du=%d"
            % (info["tep"], info["ngan_hang"], mask_tail(info["so_tk"]), hR + 1, iNg, iCT, iND, iRa, iVao, iDu))
    dong, stt, ngay_truoc = [], 0, ""
    g = lambda r, j: (r[j] if 0 <= j < len(r) else None)
    NGAY_1904["on"] = _la_he_ngay_1904(path)          # B03
    if NGAY_1904["on"]:
        LOG.ghi("  B03 %s: tep Excel dung he ngay 1904" % info["tep"])
    su_kien = []          # B10: so du / tong ngan hang in (vi tri, loai, gia tri)
    for r in S[:max(_hR0, 0)]:
        if r:
            _ghi_tong_nh(su_kien, list(r), chuan(" ".join(str(c) for c in r if c is not None)), 0, -1, -1, -1)
    for k, r in enumerate(S[hR + 1:]):
        if not r or all(c is None or str(c).strip() == "" for c in r):
            continue
        if iND >= 0 and iNg >= 0 and _sa(g(r, iND)) == H[iND] and _sa(g(r, iNg)) == H[iNg]:
            continue          # B06: dong tieu de lap lai o trang sau - khong phai giao dich, khong noi vao dien giai
        nd = go_ngat_dong(str(g(r, iND) or "")).strip()          # GD191: noi dong bi ngat (MB)
        ngay = doc_ngay(g(r, iNg)) if iNg >= 0 else ""
        vao = so(g(r, iVao)) if iVao >= 0 else 0.0
        ra = so(g(r, iRa)) if iRa >= 0 else 0.0
        if iTien >= 0:
            t = so(g(r, iTien))
            vao, ra = (t, 0.0) if t > 0 else (0.0, -t)
        ra, vao = abs(ra), abs(vao)
        nhan = chuan(" ".join(str(c) for c in r[:3] if c))
        if not ngay and _ghi_tong_nh(su_kien, r, nhan, len(dong), iVao, iRa, iDu):
            continue          # B10: giu so ngan hang in de doi soat ky, khong thanh giao dich
        if re.search(r"^(TONG|CONG|TOTAL|SO DU (DAU|CUOI)|OPENING|CLOSING)", nhan) and not ngay:
            continue
        if not ngay and not nd and vao == 0 and ra == 0:
            continue
        so_ct0 = g(r, iCT)
        so_ct0 = ("%d" % so_ct0 if isinstance(so_ct0, float) and so_ct0 == int(so_ct0) else str(so_ct0 or "")).strip()
        if vao == 0 and ra == 0:
            # GD336: dong khong ngay, khong tien nhung co chu = dong TIEP cua dien giai giao dich truoc
            #   (sao ke in / scan / Excel tach mot o nhieu dong thanh nhieu hang) -> noi vao dong truoc, phan tich lai sau
            if nd and dong and not ngay and not so_ct0 and len(nd) <= 400:
                dong[-1]["noi_dung"] = (dong[-1]["noi_dung"] + " " + nd)[:2000]
                dong[-1]["_noi336"] = True
            continue
        if _la_dong_tong336(nd, so_ct0) and len(dong) >= 3 and abs((vao if vao > 0 else ra) - sum(x["tien_vao" if vao > 0 else "tien_ra"] for x in dong)) <= 2:
            LOG.ghi("  GD336: bo dong tong '%s' (%s)" % (nd[:40], fmt_tien(vao + ra)))
            if vao > 0:
                su_kien.append((len(dong), "vao", round(vao, 2)))
            if ra > 0:
                su_kien.append((len(dong), "ra", round(ra, 2)))
            continue
        if not ngay:
            ngay = ngay_truoc          # dong tiep cua cung giao dich
        if not ngay:
            continue
        ngay_truoc = ngay
        stt += 1
        so_ct = g(r, iCT)
        # B03: ref luu dang SO trong Excel tu 16 chu so tro len da mat chu so (Excel chi giu 15) - khong khoi phuc, bao canh bao
        ref_mat = isinstance(so_ct, (int, float)) and not isinstance(so_ct, bool) and abs(so_ct) >= 1e15
        so_ct = ("%d" % so_ct if isinstance(so_ct, float) and so_ct == int(so_ct) else str(so_ct or "")).strip()
        stk, ten, ds_uv = tach_doi_ung(nd, "RA" if ra > 0 else "VAO")
        # GD50: mau co ngan hang doi ung ("CKN ... - TEN - Ngan hang NH") la can cu chac nhat cho ten nguoi tra
        chieu_d = "RA" if ra > 0 else "VAO"
        kq_nd = {}
        if ND is not None:
            try:
                kq_nd = ND.doc_noi_dung(nd, chieu_d, int(str(ngay)[:4] or 0)) or {}
            except Exception:
                kq_nd = {}
        if kq_nd.get("ten_tra"):
            ten = kq_nd["ten_tra"][:120]
            if ten in ds_uv:
                ds_uv.remove(ten)
            ds_uv.insert(0, ten)
            ds_uv = ds_uv[:4]
        du_txt = go_ngat_dong(str(g(r, iDU) or "")).strip() if iDU >= 0 else ""
        _du_cot336 = False
        if du_txt:
            # cot doi ung cua ngan hang la can cu chinh (uu tien hon ten boc tu noi dung)
            m = STK_RX.search(du_txt)
            if m:
                stk = m.group(1)
            t2 = re.sub(r"\d{8,16}", "", du_txt).strip(" -:/")
            if len(t2) >= 3:
                ten = t2[:120]
                _du_cot336 = True
                if ten not in ds_uv:
                    ds_uv.insert(0, ten)
                    ds_uv = ds_uv[:4]
        d = {"khoa": "",          # CT-R6: dat sau ca vong lap, theo KSP (xem _ksp_gan_khoa)
             "ngan_hang": info["ngan_hang"], "so_tk": info["so_tk"], "ngay_gd": ngay, "so_ct_nh": so_ct[:50],
             "noi_dung": nd[:2000], "tien_vao": round(vao, 2), "tien_ra": round(ra, 2),
             "so_du": round(so(g(r, iDu)), 2) if iDu >= 0 else None,
             "doi_ung_stk": stk, "doi_ung_ten": ten, "mst_nd": mst_trong_nd(nd),
             "so_hd_nd": (kq_nd.get("so_hd", "") if ND is not None else so_hd_trong_nd(nd)),
             "loai_goi_y": _loai_gd50(nd, chieu_d), "ten_ung_vien": "|".join(ds_uv)[:255],
             "ngay_hd": (kq_nd.get("ngay_hd") or ngay_hd_trong_nd(nd)),
             "ngan_hang_du": kq_nd.get("ma_nh_tra", ""),
             "ngay_tu": kq_nd.get("ngay_tu", ""), "ngay_den": kq_nd.get("ngay_den", ""),
             "tep_nguon": info["tep"], "dong_nguon": hR + 2 + k,
             "chu_tk": _chu97, "mst_chu_tk": _mst97,
             "nguon": "ANH" if OCR_LAN_NAY.get("dung") else "", "_du_cot": _du_cot336,
             "_ngay_tho": g(r, iNg) if iNg >= 0 else None}
        if ref_mat:
            d["canh_bao"] = "REF_MAT_CHU_SO"
        if iTT >= 0:
            # GD62: file Excel do Anh -> Excel sinh ra: dong con VANG / DO NHAT / MOI (chua ghi OK) -> Can xem lai
            ttx = chuan(str(g(r, iTT) or ""))
            if ttx and ttx not in ("XANH", "OK", "DA KIEM", "DA KIEM TRA", "DA XEM", "DONG Y", "DUYET"):
                d["nguon"] = "ANH"
                d["canh_bao"] = ("OCR_" + ttx.replace(" ", "_"))[:40]
        dong.append(d)
    for d in dong:          # GD336: dong da noi them chu -> boc lai ten / so HD / MST tren noi dung day du
        if d.pop("_noi336", False):
            _phan_tich_nd336(d, go_ngat_dong(d["noi_dung"]), d.get("ngay_gd", ""))
        d.pop("_du_cot", None)
    _xu_ly_ngay_mo_ho(dong, info["tep"])          # B03
    if _sao_ke_nguoc(dong):          # GD191: sao ke moi nhat tren cung (MB, VCB...) -> dao lai theo thoi gian de so du lien tuc
        dong.reverse()
        # B10: nhan so du dau / cuoi giu nguyen nghia (dau ky = cu nhat); sao ke dao chieu coi la MOT ky: dau o dau, con lai o cuoi
        n = len(dong)
        if sum(1 for _, k, _ in su_kien if k == "dau") > 1:
            LOG.ghi("  B10 %s: sao ke dao chieu co nhieu moc so du dau - khong tach ky duoc, se CHUA_XAC_MINH" % info["tep"])
            su_kien = []
        su_kien = [(0 if k == "dau" else n, k, v) for _, k, v in su_kien]
        LOG.ghi("  %s: sao ke xep moi nhat tren cung - da dao lai theo thu tu thoi gian" % info["tep"])
    _ksp_gan_khoa(info, dong)
    info["_su_kien_tong"] = su_kien          # B10: doi soat sau kiem_tra_so_du (chay_so_phu)
    return info, dong


def _sao_ke_nguoc(dong):
    """GD191: True neu cac dong dang xep NGUOC thoi gian (so du khop theo chieu nguoc tot hon; khong co so du thi theo ngay)."""
    if len(dong) < 2:
        return False
    co_du = [d for d in dong if d.get("so_du") is not None]
    if len(co_du) >= 2:
        def lech(ds):
            n, truoc = 0, None
            for d in ds:
                if truoc is not None and abs((d["so_du"] - truoc) - (d["tien_vao"] - d["tien_ra"])) > 1:
                    n += 1
                truoc = d["so_du"]
            return n
        xuoi, nguoc = lech(co_du), lech(list(reversed(co_du)))
        if xuoi != nguoc:
            return nguoc < xuoi
    ng = [d["ngay_gd"] for d in dong if d.get("ngay_gd")]
    if len(ng) >= 2 and ng[0] != ng[-1]:
        return ng[0] > ng[-1] and all(ng[i] >= ng[i + 1] for i in range(len(ng) - 1))
    return False


def _sap_theo_so_du(dong):
    """GD363: ngan hang xuat sao ke xep lon xon trong cung mot ngay -> trong tung ngay tim lai thu tu de chuoi so du lien tuc.
    Tra ve danh sach moi (cung phan tu). Khong doi duoc thi giu nguyen ngay do."""
    co = [d for d in dong if d.get("so_du") is not None and d.get("ngay_gd")]
    if len(co) < 3:
        return dong
    theo_ngay = {}
    for d in dong:
        theo_ngay.setdefault(d.get("ngay_gd"), []).append(d)
    out, truoc = [], None
    for ng in sorted(theo_ngay, key=lambda x: (x is None, x)):
        con = list(theo_ngay[ng])
        xep = []
        while con:
            x = None
            if truoc is not None:
                for d in con:
                    if d.get("so_du") is not None and abs((d["so_du"] - truoc) - (d["tien_vao"] - d["tien_ra"])) <= 1:
                        x = d
                        break
            if x is None:
                xep.extend(con)
                con = []
                if xep and xep[-1].get("so_du") is not None:
                    truoc = xep[-1]["so_du"]
                break
            con.remove(x)
            xep.append(x)
            truoc = x["so_du"]
        out.extend(xep)
    return out


def kiem_tra_so_du(dong):
    """Canh bao so du khong lien tuc: du(n) - du(n-1) != vao - ra (sai so 1d). GD363: thu xep lai trong ngay truoc khi bao."""
    def _dem(ds):
        cb, truoc = [], None
        for d in ds:
            if d.get("so_du") is None:
                continue
            if truoc is not None and abs((d["so_du"] - truoc) - (d["tien_vao"] - d["tien_ra"])) > 1:
                cb.append(d)
            truoc = d["so_du"]
        return cb
    if _dem(dong):
        moi = _sap_theo_so_du(dong)
        if len(_dem(moi)) < len(_dem(dong)):
            dong[:] = moi
            LOG.ghi("  GD363: sap lai thu tu trong ngay theo so du - con %d dong lech" % len(_dem(moi)))
    cb, truoc = [], None
    for d in dong:
        if d.get("so_du") is None:
            continue
        if truoc is not None:
            lech = (d["so_du"] - truoc) - (d["tien_vao"] - d["tien_ra"])
            if abs(lech) > 1:
                cb.append({"khoa": d["khoa"], "lech": round(lech, 2)})
                d["canh_bao"] = "SO_DU_KHONG_LIEN_TUC"
        truoc = d["so_du"]
    return cb


def ghi_jsonl(cac_dong, nhan, tong, co_ket):
    kq = thu_muc("ket-qua")
    ts = datetime.now().strftime("%Y%m%d%H%M%S")
    ten = "%s_%s_%s" % (nhan, UNESCO["mst"] or "CHUNG", ts)
    duong = os.path.join(kq, ten + ".jsonl.tmp")
    with open(duong, "w", encoding="utf-8") as f:
        for d in cac_dong:
            f.write(json.dumps(d, ensure_ascii=False) + "\n")
    cuoi = duong[:-4]
    os.replace(duong, cuoi)
    with open(os.path.join(kq, ten + "_tong.json"), "w", encoding="utf-8") as f:
        json.dump(tong, f, ensure_ascii=False, indent=2)
    try:
        with open(os.path.join(kq, co_ket), "w", encoding="utf-8") as f:
            f.write(cuoi)
    except Exception:
        pass
    LOG.ghi("Da ghi %s: %d dong" % (os.path.basename(cuoi), len(cac_dong)))
    return cuoi


# ---------------------------------------------------------------- GD83: dich noi dung sang tieng Viet co dau
def _ngu_lieu_sp():
    """<ThuMucKhach>/sp_ngu_lieu.txt (VB6 ghi: ten KH / NV, dien giai chung tu co dau) - khong co thi None"""
    p = os.path.join(UNESCO["out"] or "", "sp_ngu_lieu.txt")
    return p if UNESCO["out"] and os.path.exists(p) else None


def _bo_dich():
    """(module, mo hinh) hoac (None, None) neu khong nap duoc - khong bao gio lam hong viec nhap so phu"""
    try:
        if BASE_DIR not in sys.path:
            sys.path.insert(0, BASE_DIR)
        import sp_dich_viet as DV
        return DV, DV.mo_hinh(_ngu_lieu_sp())
    except Exception as e:
        LOG.loi("GD83: khong nap duoc bo dich tieng Viet co dau", e)
        return None, None


def them_noi_dung_viet(cac_dong):
    """GD83: moi dong so phu them "noi_dung_viet" (khong dau / tieng Anh -> tieng Viet co dau; giu so, ma, ky tu)"""
    DV, mh = _bo_dich()
    if DV is None:
        return 0
    n = 0
    for d in cac_dong:
        try:
            nd = str(d.get("noi_dung") or "")
            if nd:
                d["noi_dung_viet"] = DV.dich(nd, mh)[:2000]
                n += 1
        except Exception:
            pass
    return n


def dich_theo_yeu_cau(duong, ghi_moc=False):
    """GD83: tep yeu cau (VB6 ghi, moi dong {"ma_so", "noi_dung"}) -> ket-qua/dich_sp_<mst>_<ts>.jsonl
       ({"ma_so", "noi_dung_viet"}); xoa tep yeu cau. ghi_moc: che do /dich_sp -> moc DA_XONG_SP "OK|DICH|n"."""
    n = 0
    try:
        if duong and os.path.exists(duong):
            DV, mh = _bo_dich()
            if DV is not None:
                ra = []
                with io.open(duong, "r", encoding="utf-8-sig") as f:
                    for dong in f:
                        dong = dong.strip()
                        if not dong:
                            continue
                        try:
                            j = json.loads(dong)
                        except ValueError:
                            continue
                        nd = str(j.get("noi_dung") or "")
                        if nd and j.get("ma_so"):
                            ra.append({"ma_so": j.get("ma_so"), "noi_dung_viet": DV.dich(nd, mh)[:2000]})
                if ra:
                    kq = thu_muc("ket-qua")
                    ts = datetime.now().strftime("%Y%m%d%H%M%S%f")[:17]
                    ten = os.path.join(kq, "dich_sp_%s_%s.jsonl" % (UNESCO["mst"] or "CHUNG", ts))
                    with open(ten + ".tmp", "w", encoding="utf-8") as f:
                        for d in ra:
                            f.write(json.dumps(d, ensure_ascii=False) + "\n")
                    os.replace(ten + ".tmp", ten)
                n = len(ra)
                try:
                    os.remove(duong)
                except OSError:
                    pass
                LOG.ghi("GD83: da dich %d noi dung so phu sang tieng Viet co dau" % n)
    except Exception as e:
        LOG.loi("GD83: loi dich noi dung so phu", e)
    if ghi_moc:
        try:
            with open(os.path.join(thu_muc("ket-qua"), "DA_XONG_SP"), "w", encoding="utf-8") as f:
                f.write("OK|DICH|%d" % n)
        except Exception:
            pass
    return n


def chay_so_phu(duong, nganhang="", sotk=""):
    tep = []
    if os.path.isdir(duong):
        for t in sorted(os.listdir(duong)):
            if t.lower().endswith((".xls", ".xlsx", ".xlsm", ".csv", ".pdf") + DUOI_ANH) and not t.startswith("~$"):
                tep.append(os.path.join(duong, t))
    elif os.path.exists(duong):
        tep = [duong]
    if not tep:
        LOG.ghi("Khong co file so phu nao tai: " + duong)
        try:
            with open(os.path.join(thu_muc("ket-qua"), "DA_XONG_SP"), "w", encoding="utf-8") as f:
                f.write("KHONG_CO_DU_LIEU|" + bo_dau("Khong tim thay tep so phu (xls, xlsx, csv, pdf, anh) tai: %s" % duong)[:500])   # GD111c
        except Exception:
            pass
        return None
    # GD111: khong chan truoc - chi trang doc bang khoa Google cai san moi tru (giu_trang_google tung tep; het -> OCR Offline)
    google_lan_nay_lai()
    del LY_DO_0_DONG[:]          # GD111c
    trang_doc = 0
    tat_ca, tong = [], {"so_file": 0, "so_dong": 0, "tong_vao": 0.0, "tong_ra": 0.0, "loi": [], "canh_bao_so_du": [], "tai_khoan": []}
    hang, tu_anh = list(tep), {}          # GD98b: PDF scan nhieu tai khoan -> nhap tung file Excel kiem tra cua tung TK
    while hang:
        t = hang.pop(0)
        try:
            try:
                info, dong = doc_so_phu(t, nganhang, "" if t in tu_anh else sotk)
            except NhieuTaiKhoan as e_nt:
                LOG.ghi("%s -> nhap tung tai khoan" % bo_dau(str(e_nt))[:400])
                trang_doc += dem_trang(t)          # GD101: PDF scan da doc (tach tung tai khoan)
                for x in e_nt.tep:
                    tu_anh[x] = e_nt.goc
                hang[0:0] = e_nt.tep
                continue
            if t in tu_anh:
                # dong doc tu anh: luon nguon ANH (dong XANH cung vay), file nguon la PDF goc
                for d in dong:
                    d["nguon"] = "ANH"
                    d["tep_nguon"] = os.path.basename(tu_anh[t])
            if t not in tu_anh:
                trang_doc += dem_trang(t)          # GD101: tep anh / PDF doc xong (Excel / CSV = 0)
            cb = kiem_tra_so_du(dong)
            tong.setdefault("doi_soat_ky", []).extend(_doi_soat_ky(dong, info.pop("_su_kien_tong", []), os.path.basename(t)))          # B10
            tong["so_file"] += 1; tong["so_dong"] += len(dong)
            tong["tong_vao"] += sum(d["tien_vao"] for d in dong); tong["tong_ra"] += sum(d["tien_ra"] for d in dong)
            tong["canh_bao_so_du"].extend(cb)
            # GD50: nhieu dong so du khong lien tuc = doc sai cot / anh chup mo -> thuat toan nao cung thua
            if len(dong) >= 5 and len(cb) * 5 > len(dong):
                tong.setdefault("canh_bao_nguon", []).append(
                    "%s: %d/%d dong so du khong lien tuc - nen xuat file Excel tu iBanking thay cho anh / PDF chup"
                    % (os.path.basename(t), len(cb), len(dong)))
                LOG.ghi("  CANH BAO %s: %d/%d dong so du khong lien tuc (%s) - khuyen xuat Excel tu iBanking"
                        % (os.path.basename(t), len(cb), len(dong), "anh/OCR" if OCR_LAN_NAY.get("dung") else "file"))
            tong["tai_khoan"].append({"ngan_hang": info["ngan_hang"], "so_tk": info["so_tk"], "tep": info["tep"], "so_dong": len(dong),
                                      "du_dau": dong[0]["so_du"] if dong and dong[0].get("so_du") is not None else None,
                                      "du_cuoi": dong[-1]["so_du"] if dong and dong[-1].get("so_du") is not None else None})
            tat_ca.extend(dong)
            LOG.ghi("  %s: %d giao dich, vao %.0f, ra %.0f, %d canh bao so du" % (os.path.basename(t), len(dong),
                    sum(d["tien_vao"] for d in dong), sum(d["tien_ra"] for d in dong), len(cb)))
        except Exception as e:
            LOG.loi("Khong doc duoc so phu " + t, e); tong["loi"].append("%s: %s" % (os.path.basename(t), e))
    tong["so_trang_anh_pdf"] = trang_doc
    tong["so_trang_google"] = GOOGLE_LAN_NAY["da_doc"]          # GD111
    ghi_trang_da_doc(GOOGLE_LAN_NAY["da_doc"], duong, "sophu")          # GD111: chi trang Google (khoa cai san) - truoc moc DA_XONG_SP
    if not tat_ca:
        try:
            with open(os.path.join(thu_muc("ket-qua"), "DA_XONG_SP"), "w", encoding="utf-8") as f:
                f.write("KHONG_CO_DU_LIEU|" + bo_dau("; ".join(tong["loi"] + LY_DO_0_DONG)
                                                     or "khong nhan ra giao dich nao - xem AIHoaDon\\nhat-ky-so-phu.txt")[:500])   # GD63 / GD111c: luon co ly do
        except Exception:
            pass
        return None
    tong["so_dong_dich"] = them_noi_dung_viet(tat_ca)          # GD83: noi dung tieng Viet co dau
    if UNESCO["out"]:
        # GD83: dong cu chua co ban tieng Viet (VB6 ghi tep yeu cau truoc khi goi tool) - ghi ngay truoc tep so phu
        #   de VB6 thuong nhan hai tep trong cung mot lan quet (mot thong bao)
        dich_theo_yeu_cau(os.path.join(UNESCO["out"], "sp_can_dich.jsonl"))
    return ghi_jsonl(tat_ca, "sophu", tong, "DA_XONG_SP")



# ---------------------------------------------------------------- GD62: anh / PDF -> file Excel so phu (kiem tra truoc khi nhap)
def chay_so_phu_excel(duong, nganhang="", cach="AI"):
    """GD62 (hoc tu R15): anh / PDF sao ke -> file Excel so phu to mau XANH / VANG / DO NHAT / MOI de ke toan kiem tra,
       sua roi Import nhu file Excel thuong. PDF co chu: doc truc tiep (khong OCR). Anh / PDF scan: cach = AI (Claude,
       2 luot doc doc lap + doi chieu) hoac OFFLINE (Windows OCR, khong gui anh ra ngoai, moi dong VANG).
       Ghi ket-qua/DA_XONG_SP_XLS: "OK|<xlsx>|tong|xanh|vang|do|moi|trang thai|canh bao" hoac "KHONG_CO_DU_LIEU|<loi>"."""
    kq_dir = thu_muc("ket-qua")
    co = os.path.join(kq_dir, "DA_XONG_SP_XLS")

    def bao_loi(msg):
        LOG.ghi("Anh -> Excel: " + str(msg))
        try:
            with open(co, "w", encoding="utf-8") as f:
                f.write("KHONG_CO_DU_LIEU|" + str(msg)[:500].replace("\n", " "))
        except Exception:
            pass

    try:
        if BASE_DIR not in sys.path:
            sys.path.insert(0, BASE_DIR)
        import sp_anh_excel as SAE
    except Exception as e:
        bao_loi("Thieu sp_anh_excel.py canh tool: %s" % e)
        return None
    SAE.dat_nhat_ky(LOG.ghi)
    cach = (cach or "AI").upper()
    if not os.path.exists(duong):
        bao_loi("Khong tim thay file: " + duong)
        return None
    p = duong.lower()
    if not p.endswith((".pdf",) + DUOI_ANH):
        bao_loi("Chi nhan PDF / anh (jpg, png, tif, bmp, webp): " + os.path.basename(duong))
        return None
    google_lan_nay_lai()          # GD111: khong chan truoc - chi trang doc bang khoa Google cai san moi tru
    st = doc_thiet_lap()
    dau, dong = None, None
    try:
        if p.endswith(".pdf"):
            try:
                tab = doc_pdf(duong)
                OCR_LAN_NAY["dung"] = False
                OCR_LAN_NAY["canh_bao"] = []
                info, dong_tool = doc_so_phu(duong, nganhang, "", tab=tab, ocr_du_phong=False)          # GD118: ben duoi tu OCR
                if dong_tool:
                    dau, dong = SAE.tu_dong_so_phu(info, dong_tool)
                    LOG.ghi("PDF co chu: %d dong doc truc tiep, khong OCR" % len(dong))
            except Exception as e:
                LOG.ghi("PDF khong doc truc tiep duoc (%s) -> OCR (%s)" % (e, cach))
        if dau is None:
            if cach == "DOCAI":
                try:
                    het_google_khong_khoa(duong, st)          # GD111: het trang -> VB khong truyen khoa mo
                    dau, dong = doc_google(duong, nganhang, os.path.join(kq_dir, "ocr-offline"), st)     # GD97 / GD111: Google Document AI
                except Exception as e_docai:
                    # GD97-D: Google loi (mang, quyen, het han muc...) -> van doc duoc bang OCR Offline, bao ro ly do
                    LOG.ghi("Google Document AI loi (%s) -> doc bang OCR Offline" % bo_dau(str(e_docai))[:300])
                    dau, dong = SAE.doc_bang_offline(duong, nganhang, os.path.join(kq_dir, "ocr-offline"), st)
                    dau.setdefault("canh_bao", []).insert(0, "Google Document AI lỗi: %s - đã đọc bằng OCR Offline." % str(e_docai)[:250])
            elif cach == "OFFLINE":
                dau, dong = SAE.doc_bang_offline(duong, nganhang, os.path.join(kq_dir, "ocr-offline"), st)     # GD66: Tesseract neu co
            else:
                dau, dong = SAE.doc_bang_ai(duong, nganhang, st)
        if nganhang and not dau.get("ngan_hang"):
            dau["ngan_hang"] = nganhang.upper()
        # GD64: mot PDF co the gom nhieu tai khoan (tien gui thanh toan + TK vay / ky han) -> moi tai khoan mot file Excel
        nhom = SAE.tach_tai_khoan(dau, dong) if hasattr(SAE, "tach_tai_khoan") else [(dau, dong)]
        cac_tep = []
        for gi, (dau_g, dong_g) in enumerate(nhom):
            if nganhang and not dau_g.get("ngan_hang"):
                dau_g["ngan_hang"] = nganhang.upper()
            SAE.kiem_tra(dau_g, dong_g)
            duoi = ""
            if len(nhom) > 1:
                duoi = "_TK" + (dau_g.get("so_tk") or "")[-4:] if dau_g.get("so_tk") else "_TK_CHUA_RO_%d" % (gi + 1)
            ra_g = SAE.ten_tep_ra(duong, thu_muc("so-phu"), duoi)
            SAE.lap_excel(dau_g, dong_g, ra_g, duong)
            cac_tep.append((ra_g, dau_g, dong_g))
            try:
                thu_kt = thu_muc(os.path.join("ket-qua", "sophu-excel"))
                with open(os.path.join(thu_kt, os.path.splitext(os.path.basename(ra_g))[0] + "_KIEM_TRA.json"), "w", encoding="utf-8") as f:
                    json.dump({"dau": dau_g, "dong": dong_g, "excel": ra_g}, f, ensure_ascii=False, indent=1, default=str)
            except Exception:
                pass
            LOG.ghi("Anh -> Excel TK %s: %d dong -> %s" % (mask_tail(dau_g.get("so_tk") or "?"), len(dong_g), os.path.basename(ra_g)))
        ra, dau, dong = cac_tep[0]
        if len(cac_tep) > 1:
            dau["canh_bao"].insert(0, "PDF có %d tài khoản - đã tách %d file: %s" % (
                len(cac_tep), len(cac_tep), ", ".join("%s (%d dòng)" % (os.path.basename(t[0]), len(t[2])) for t in cac_tep)))
        tt = SAE.tom_tat(dau, dong, ra)
        LOG.ghi("Anh -> Excel: " + tt)
        ghi_trang_da_doc(GOOGLE_LAN_NAY["da_doc"], duong, "sophu_excel")          # GD111: chi trang Google (khoa cai san) - truoc moc
        GOOGLE_LAN_NAY["da_doc"] = 0
        with open(co, "w", encoding="utf-8") as f:
            f.write(tt)
        try:
            os.startfile(ra)
        except Exception:
            pass
        return ra
    except Exception as e:
        LOG.loi("Anh -> Excel that bai", e)
        ghi_trang_da_doc(GOOGLE_LAN_NAY["da_doc"], duong, "sophu_excel")          # GD111: Google da doc thi van tru
        GOOGLE_LAN_NAY["da_doc"] = 0
        bao_loi(str(e))
        return None


# ---------------------------------------------------------------- bang luong
# GD75: moi cot mot DANH SACH mau theo thu tu uu tien (mau manh truoc). Truoc day mot mau gop (vd "... |thu nhap") nen cot
#   "Thu nhap khac" dung truoc "Tong thu nhap" bi nhan la TONG THU NHAP. Them STT / bo phan / chuc vu / ngay cong / tru khac.
BL_COT = [("stt", [r"^(stt|so tt|s tt|tt|so thu tu|no\.?)$"]),
          ("ten", [r"ho (va )?ten|ho ten|ten nhan vien|^ten$|full ?name|employee name|^employee$"]),
          ("ma_nv", [r"^ma( nv| nhan vien)?$|^ma so( nv| nhan vien)?$|^stt ma|employee (id|code)|^ma$|^ma nv", r"^ma so$"]),
          ("so_tk", [r"so tai khoan|so tk|stk|account"]),
          ("bo_phan", [r"bo phan|phong ban|^phong$|don vi cong tac|^to$|to doi|department"]),
          ("chuc_vu", [r"chuc vu|chuc danh|vi tri|position"]),
          ("ngay_cong", [r"ngay cong|so cong|cong lam viec|so ngay lam"]),
          ("luong_cb", [r"luong co ban|luong cb|basic", r"luong chinh"]),
          ("phu_cap", [r"phu cap|tro cap|allowance", r"thu nhap khac"]),
          ("tong_thu_nhap", [r"tong thu nhap|tong luong|gross", r"tong cong", r"thu nhap(?! khac)"]),
          ("bhxh_nv", [r"bhxh.*(nv|nld|8|nguoi lao dong)", r"(tru|khau tru).*bhxh", r"^bhxh$"]),
          ("bhyt_nv", [r"bhyt.*(nv|nld|1\.5|nguoi lao dong)", r"(tru|khau tru).*bhyt", r"^bhyt$"]),
          ("bhtn_nv", [r"bhtn.*(nv|nld|1%|nguoi lao dong)", r"(tru|khau tru).*bhtn", r"^bhtn$"]),
          ("bhxh_dn", [r"bhxh.*(dn|doanh nghiep|17|cty|cong ty)"]), ("bhyt_dn", [r"bhyt.*(dn|doanh nghiep|3|cty|cong ty)"]),
          ("bhtn_dn", [r"bhtn.*(dn|doanh nghiep|cty|cong ty)"]),
          ("kpcd", [r"kpcd|kinh phi cong doan|cong doan"]), ("thue_tncn", [r"tncn|thue thu nhap|pit"]),
          ("tam_ung", [r"tam ung|ung luong|advance"]),
          ("tru_khac", [r"(tru|khau tru).*khac$|^tru khac|khau tru khac|^khac$"]),
          ("thuc_linh", [r"thuc linh|thuc nhan|thuc lanh|con lai|net|thuc tra|so tien nhan"])]
KHAU_TRU = ("bhxh_nv", "bhyt_nv", "bhtn_nv", "thue_tncn", "tam_ung", "tru_khac")
# dong NHOM (bo phan) trong bang luong: "Nhan vien ban hang", "Bo phan van phong", "Phong ke toan", "To san xuat 1"...
# GD75: ten nguoi co ho To / Tong / Cong / Ban... KHONG duoc bi coi la dong nhom / dong tong -> tu khoa chat
RE_NHOM = re.compile(r"^(nhan vien|bo phan|phong |xuong|phan xuong|khoi |cong nhan|nhom |chi nhanh|van phong|kinh doanh|"
                     r"san xuat|cong trinh|lao dong|quan ly|hanh chinh|ke toan|"
                     r"to (\d|sx\b|san xuat|bao ve|thi cong|xay dung|co khi|dien|may|han|nau|ve sinh|hoan thien|lap|son|moc)|"
                     r"ban (giam doc|quan ly|kiem soat|dieu hanh|lanh dao)|doi (\d|thi cong|xe|bao ve|san xuat|cong trinh))")
RE_TONG = re.compile(r"^(TONG CONG|TONG SO|TONG LUONG|TONG QUY|TOTAL|TONG\W*$|CONG\W*$|"
                     r"CONG (NHOM|BO PHAN|PHONG|TO|XUONG|KHOI|VAN PHONG|DOI|BAN|CONG|THANG|I|II|III|IV|V|A|B|C)\b)")


def thang_tu_ten_sheet(ten):
    """'thang 01', 'T8', 'Thang 12-2026', 'BL 03.2026' -> thang; khong chac thi 0.
    Khong nhan so dung mot minh kieu 'Sheet1' / 'Sheet2'."""
    t = bo_dau(str(ten or "")).upper()
    m = re.search(r"(?:THANG|\bTH|\bT)\s*[._-]?\s*(\d{1,2})(?!\d)", t)
    if not m:
        m = re.search(r"(?<!\d)(\d{1,2})\s*[./_-]\s*20\d\d(?!\d)", t)
    if m and 1 <= int(m.group(1)) <= 12:
        return int(m.group(1))
    return 0


def _bl_cot(H):
    cot = {}
    for k, ds in BL_COT:
        for rx in ds:
            i = next((i for i, c in enumerate(H) if c and re.search(rx, c) and i not in cot.values()), None)
            if i is not None:
                cot[k] = i
                break
    return cot


def _bl_la_so_tt(v):
    if v is None:
        return False
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return v > 0
    return bool(re.match(r"^\d+(\.0+)?$", str(v).strip()))


def _bl_dd(v):
    return "{:,.0f}".format(float(v or 0)).replace(",", ".")


def doc_bang_luong(path, thang=0, nam=0, canh_bao=None):
    """GD78: doc bang bang_luong_gd78 - chu VNI / TCVN3 / Unicode, tieu de nhieu dong, dong nhom ghi o cot STT, DU moi cot so
    (luong co ban, luong chinh, thu nhap khac...), ky thang / ca nam / nhieu thang theo tieu de, kiem cong thuc tung dong va
    moi cot cua dong cong nhom / tong cong. Truong 'thang': 1..12; 0 = ca nam; tu*100+den = nhieu thang; -1 = chua biet.
    Khong nap duoc mo-dun -> cach doc GD75 (_doc_bang_luong_gd75)."""
    try:
        import bang_luong_gd78 as BL78
    except Exception as e:
        LOG.ghi("Khong nap duoc bang_luong_gd78 (%s) - doc bang luong kieu GD75" % e)
        return _doc_bang_luong_gd75(path, thang, nam, canh_bao)
    return BL78.doc_bang_luong(doc_bang(path), thang, nam, canh_bao, lambda s: LOG.ghi(s))


def _doc_bang_luong_gd75(path, thang=0, nam=0, canh_bao=None):
    """-> danh sach dong nhan vien. GD75: dong NHOM bo phan (STT trong / ten "Nhan vien ban hang"...) KHONG con bi nhap nhu
    mot nhan vien - ten nhom thanh bo phan cua cac dong ben duoi; kiem cong nhom / dong Tong cong -> canh_bao
    (list, moi phan tu {thang, nam, noi_dung})."""
    tab = doc_bang(path)
    ket = []
    cb = canh_bao if canh_bao is not None else []
    for sh, A in tab.items():
        if not A:
            continue
        hr = next((i for i, r in enumerate(A[:60]) if any(re.search(r"ho (va )?ten|ho ten|ten nhan vien", _sa(c)) for c in r)), -1)
        if hr < 0:
            continue
        H = [_sa(c) for c in A[hr]]
        H2 = [_sa(c) for c in A[hr + 1]] if hr + 1 < len(A) else []
        # dong tieu de thu hai (vd. "Cac khoan tru vao luong" -> BHXH / BHYT...) chi co CHU; dong co so tien (dong nhom
        # "I - Bo phan van phong  18.000.000") la du lieu, khong gop vao tieu de
        co_tien = any((isinstance(c, (int, float)) and not isinstance(c, bool) and abs(c) >= 1000) or
                      bool(re.match(r"^\d{1,3}([.,]\d{3})+$", str(c or "").strip())) for c in (A[hr + 1] if hr + 1 < len(A) else []))
        if H2 and not co_tien and sum(1 for c in H2 if c) >= 3 and not any(re.search(r"^\d", c) for c in H2[:3]):
            H = [(a + " " + b).strip() if b else a for a, b in zip(H + [""] * len(H2), H2 + [""] * len(H))]
            hr += 1
        cot = _bl_cot(H)
        if "ten" not in cot:
            continue
        # GD29: file nhieu sheet "thang 01".."thang 08" ma nguoi dung go thang 1 -> ten sheet doc ra duoc thang thi thang cua SHEET.
        th_sheet = thang_tu_ten_sheet(sh)
        th = th_sheet or thang or 0
        nm = nam or next((int(m.group(1)) for m in [re.search(r"(20\d\d)", bo_dau(sh) + " " + " ".join(str(c) for r in A[:hr] for c in r if c))] if m), 0)
        LOG.ghi("Bang luong sheet %s: tieu de dong %d, cot %s" % (sh, hr + 1, json.dumps(cot)), che=False)
        dong_du = [r for r in A[hr + 1:]]
        ti, si = cot["ten"], cot.get("stt")
        # dung quy tac STT chi khi it nhat nua so dong co ten co STT so (co bang luong khong danh STT)
        co_ten = [r for r in dong_du if ti < len(r) and r[ti] is not None and str(r[ti]).strip() and not isinstance(r[ti], float)]
        dung_stt = si is not None and co_ten and sum(1 for r in co_ten if si < len(r) and _bl_la_so_tt(r[si])) >= 0.5 * len(co_ten)

        def gt(r, key):
            i = cot.get(key)
            return r[i] if i is not None and i < len(r) else None

        nhom, nhom_so, nhom_tl, nhom_tn, nhom_dong = "", 0, 0.0, 0.0, None
        tong_tl = tong_tn = 0.0
        so_nguoi = 0

        def dong_nhom():
            if nhom and nhom_dong is not None and nhom_so:
                for ten_so, a, b in (("thực lĩnh", nhom_dong[0], nhom_tl), ("tổng thu nhập", nhom_dong[1], nhom_tn)):
                    if a and abs(a - b) > 1:
                        cb.append({"thang": th, "nam": nm, "noi_dung": "Sheet %s, nhóm \"%s\": dòng cộng nhóm %s = %s nhưng cộng %d người = %s (lệch %s)."
                                   % (sh, nhom, ten_so, _bl_dd(a), nhom_so, _bl_dd(b), _bl_dd(a - b))})

        for k, r in enumerate(dong_du):
            ten = r[ti] if ti < len(r) else None
            if ten is None or not str(ten).strip() or isinstance(ten, float):
                # dong tong cong co the ghi o cot STT / cot dau
                if r and RE_TONG.search(chuan(str(r[0] or ""))) and (so(gt(r, "thuc_linh")) or so(gt(r, "tong_thu_nhap"))):
                    ten = str(r[0])
                else:
                    continue
            tu_chuan = chuan(str(ten))
            v_stt = gt(r, "stt")
            la_tong = not _bl_la_so_tt(v_stt) and (bool(RE_TONG.search(tu_chuan)) or bool(RE_TONG.search(chuan(str(r[0] or "")))))
            if la_tong:
                a_tl, a_tn = so(gt(r, "thuc_linh")), so(gt(r, "tong_thu_nhap"))
                for ten_so, a, b in (("thực lĩnh", a_tl, tong_tl), ("tổng thu nhập", a_tn, tong_tn)):
                    if a and so_nguoi and abs(a - b) > 1:
                        cb.append({"thang": th, "nam": nm, "noi_dung": "Sheet %s: dòng \"%s\" %s = %s nhưng cộng %d người = %s (lệch %s)."
                                   % (sh, str(ten).strip()[:40], ten_so, _bl_dd(a), so_nguoi, _bl_dd(b), _bl_dd(a - b))})
                continue
            if dung_stt:
                la_nhom = not _bl_la_so_tt(v_stt)
            else:
                la_nhom = (v_stt is None or not str(v_stt).strip()) and bool(RE_NHOM.search(_sa(ten)))
            if la_nhom:
                dong_nhom()
                nhom = str(ten).strip()[:120]
                nhom_so, nhom_tl, nhom_tn = 0, 0.0, 0.0
                nhom_dong = (so(gt(r, "thuc_linh")), so(gt(r, "tong_thu_nhap")))
                continue
            d = {"thang": th, "nam": nm, "ten": str(ten).strip()[:255], "sheet": sh, "dong_nguon": hr + 2 + k}
            for key, i in cot.items():
                if key in ("ten", "stt"):
                    continue
                v = r[i] if i < len(r) else None
                if key in ("ma_nv", "so_tk"):
                    d[key] = ("%d" % v if isinstance(v, float) and v == int(v) else str(v or "")).strip()[:50]
                elif key in ("bo_phan", "chuc_vu"):
                    d[key] = str(v or "").strip()[:120]
                elif key == "ngay_cong":
                    d[key] = round(so(v), 2)
                else:
                    d[key] = round(so(v), 0)
            if d.get("thuc_linh", 0) == 0 and d.get("tong_thu_nhap", 0) == 0:
                continue
            if not d.get("bo_phan") and nhom:
                d["bo_phan"] = nhom
            if nhom:
                d["nhom"] = nhom
            ket.append(d)
            so_nguoi += 1
            tong_tl += d.get("thuc_linh", 0)
            tong_tn += d.get("tong_thu_nhap", 0)
            nhom_so += 1
            nhom_tl += d.get("thuc_linh", 0)
            nhom_tn += d.get("tong_thu_nhap", 0)
        dong_nhom()
    return ket


def chay_bang_luong(duong, thang, nam):
    cb = []
    try:
        dong = doc_bang_luong(duong, thang, nam, cb)
    except Exception as e:
        LOG.loi("Khong doc duoc bang luong " + duong, e); dong = []
    # GD78: dong chua biet ky (tieu de / ten sheet khong ghi thang, khong nhap thang) -> bo, bao ro ly do
    cb_goc = [c for c in cb if not c.get("noi_dung", "").startswith("[i] Sheet") or "ẩn" in c.get("noi_dung", "")]  # GD79 (nhom L)
    chua_ky = [d for d in dong if d.get("thang", 0) < 0]
    dong = [d for d in dong if d.get("thang", 0) >= 0]
    cb = [c for c in cb if c.get("thang", 0) >= 0]
    if chua_ky:
        LOG.ghi("Bang luong: %d dong khong nhan duoc thang (tieu de / ten sheet khong ghi ky)" % len(chua_ky))
    if not dong:
        try:
            with open(os.path.join(thu_muc("ket-qua"), "DA_XONG_BL"), "w", encoding="utf-8") as f:
                f.write("KHONG_CO_DU_LIEU" + ("|Khong nhan duoc ky cua bang luong (tieu de / ten sheet khong ghi thang) - bam Import lai va nhap THANG"
                                              if chua_ky else ("|" + bo_dau(cb_goc[0]["noi_dung"])[:300] if cb_goc else "")))
        except Exception:
            pass
        return None
    ky = {}
    for d in dong:
        k = "%d/%d" % (d["thang"], d["nam"])
        t = ky.setdefault(k, {"thang": d["thang"], "nam": d["nam"], "so_nguoi": 0, "tong_thuc_linh": 0.0, "tong_thu_nhap": 0.0})
        t["so_nguoi"] += 1; t["tong_thuc_linh"] += d.get("thuc_linh", 0); t["tong_thu_nhap"] += d.get("tong_thu_nhap", 0)
        # GD79 (nhom L): tong TUNG COT so da ghi (lam tron tung nguoi) de doi chieu voi dong Tong cong cua tep
        for _c in ("ngay_cong", "luong_cb", "luong_chinh", "phu_cap", "thu_nhap_khac", "tong_thu_nhap", "bhxh_nv", "bhyt_nv",
                   "bhtn_nv", "bhxh_dn", "bhyt_dn", "bhtn_dn", "kpcd", "thue_tncn", "tam_ung", "tru_khac", "thuc_linh",
                   "luong_dong_bh", "so_npt", "giam_tru_gc", "tn_chiu_thue", "tn_tinh_thue"):
            if _c in d:
                t.setdefault("cot", {})[_c] = round(t.setdefault("cot", {}).get(_c, 0) + (d.get(_c) or 0), 2)
    tong = {"so_dong": len(dong), "ky": list(ky.values()), "tep": os.path.basename(duong), "canh_bao": [c["noi_dung"] for c in cb]}
    # GD97-C: ten cong ty / MST dau tep -> VB doi chieu voi cong ty dang mo truoc khi nhap
    _ten97, _mst97 = "", ""
    try:
        # chi doc lai bang tinh (PDF / anh da qua OCR o buoc truoc - khong goi OCR / AI lan hai)
        if os.path.splitext(duong)[1].lower() not in (".xls", ".xlsx", ".xlsm", ".csv"):
            raise ValueError("tep %s khong phai bang tinh" % os.path.splitext(duong)[1])
        _tab97 = doc_bang(duong)
        try:
            import bang_luong_gd78 as _BL97
            _tab97 = _BL97.chuyen_bang(_tab97)[0]
        except Exception:
            pass
        _ten97, _mst97 = tim_cty_tep(_tab97)
    except Exception as e:
        LOG.ghi("Bang luong: khong doc duoc ten cong ty dau tep (%s)" % e)
    tong["nguon_cty"], tong["nguon_mst"] = _ten97, _mst97
    for d in dong:
        d["tep_nguon"] = os.path.basename(duong)
        d["nguon_cty"], d["nguon_mst"] = _ten97, _mst97
    # GD75: canh bao cong nhom / dong tong -> dong rieng loai "canh_bao" (VB ghi vao ghi chu cua ky, khong phai nhan vien)
    for c in cb:
        dong.append({"loai": "canh_bao", "thang": c["thang"], "nam": c["nam"], "ky_loai": c.get("ky_loai", ""),
                     "noi_dung": c["noi_dung"][:400], "tep_nguon": os.path.basename(duong)})
    for c in cb:
        LOG.ghi("Bang luong canh bao: " + bo_dau(c["noi_dung"]))
    return ghi_jsonl(dong, "bangluong", tong, "DA_XONG_BL")


def chay_ho_so_bhxh(duong, tep_nv):
    """GD78: danh sach tham gia BHXH + danh muc nhan vien (JSON VB6 ghi) -> ket-qua/hosobh_*.dat + bang-luong/HoSoBHXH_*.txt,
    moc DA_XONG_HSBH ("OK <tep>" / "LOI <ly do>"). Tool KHONG ghi so; VB6 xem truoc, hoi roi moi dien o trong."""
    import bang_luong_gd78 as BL78
    return BL78.chay_ho_so_bh(duong, tep_nv, doc_bang, thu_muc("ket-qua"), thu_muc("bang-luong"), lambda s: LOG.ghi(s), UNESCO["mst"])


# ---------------------------------------------------------------- Claude API cho so phu (S7)
def doc_thiet_lap():
    """GD63: utf-8-sig - cai-dat.json luu bang Notepad (co BOM) truoc day doc ra rong -> mat khoa API / cho phep gui anh."""
    try:
        with io.open(SETTINGS_PATH, "r", encoding="utf-8-sig") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def goi_claude_so_phu(duong_vao):
    """Doc can_goi_ai_sp.jsonl (VB6 xuat), goi Claude, ghi ket_qua_ai_sp_<ts>.jsonl + DA_XONG_AI_SP.
    Moi dong: {khoa, chieu, noi_dung, tien, doi_ung, ung_vien_kh[], ung_vien_nv[], ung_vien_hd[], tu_dien[]} (so TK chi 4 so cuoi)."""
    st = doc_thiet_lap()
    key = st.get("anthropic_key", ""); model = st.get("anthropic_model") or "claude-sonnet-4-5"
    kq_dir = thu_muc("ket-qua"); ket = []
    if not key:
        LOG.ghi("[AI] Chua co khoa Claude API (cai-dat.json / tool hoa don) - bo qua.")
    else:
        try:
            with open(duong_vao, "r", encoding="utf-8") as f:
                dong = [json.loads(l) for l in f if l.strip()]
        except Exception as e:
            LOG.loi("Khong doc duoc file can_goi_ai_sp", e); dong = []
        khoa_that = {}
        for i_d, d in enumerate(dong):      # khong gui so TK day du
            for k in ("doi_ung", "so_tk"):
                if d.get(k):
                    d[k] = mask_tail(d[k])
            # GD63: khoa dong chua so TK day du (NH|so TK|...) -> gui so thu tu, doi lai khi nhan ket qua;
            #   noi dung: che so 9-16 chu so (so TK doi tac) nhung GIU MST hop le (can de goi y khach hang)
            khoa_that["D%d" % i_d] = d.get("khoa")
            d["khoa"] = "D%d" % i_d
            if d.get("noi_dung"):
                d["noi_dung"] = re.sub(r"(?<!\d)(\d{9,16})(?!\d)",
                                       lambda m: m.group(1) if la_mst(m.group(1)) else mask_tail(m.group(1)), str(d["noi_dung"]))
        he_thong = ("Bạn là kế toán Việt Nam (TT133/TT200). Với mỗi dòng sổ phụ ngân hàng, trả về JSON mảng, mỗi phần tử: "
                    '{"khoa":..., "nhom": "THU_KH|CHI_NCC|LUONG|TAM_UNG|BHXH|THUE|PHI_NH|LAI_TG|LAI_VAY|RUT_NOP|NOI_BO|VAY|VON|KHAC", '
                    '"tk_doi_ung": số hiệu TK đối ứng (không phải 112), "ma_goi_y": mã KH/NV CHỈ trong ung_vien hoặc null, '
                    '"hd_goi_y": khoá hoá đơn CHỈ trong ung_vien_hd hoặc null, "do_tin_cay": 0-100, "ly_do": "ngắn"}. '
                    "Dùng từ điển tu_dien nếu khớp. Chỉ trả JSON.")
        for i in range(0, len(dong), 20):
            lo = dong[i:i + 20]
            body = {"model": model, "max_tokens": 4000, "system": he_thong,
                    "messages": [{"role": "user", "content": json.dumps(lo, ensure_ascii=False)}]}
            ok = False
            for lan in range(3):
                try:
                    req = urllib.request.Request("https://api.anthropic.com/v1/messages", data=json.dumps(body).encode("utf-8"),
                                                 headers={"Content-Type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01"}, method="POST")
                    with urllib.request.urlopen(req, timeout=120) as r:
                        raw = r.read().decode("utf-8")
                    txt = "".join(c.get("text", "") for c in json.loads(raw).get("content", []))
                    m = re.search(r"\[.*\]", txt, re.S)
                    for kq1 in (json.loads(m.group(0)) if m else []):
                        if isinstance(kq1, dict) and kq1.get("khoa") in khoa_that:
                            kq1["khoa"] = khoa_that[kq1["khoa"]]      # GD63: tra lai khoa that
                        ket.append(kq1)
                    LOG.ghi("[AI] lo %d: OK" % (i // 20 + 1)); ok = True; break
                except urllib.error.HTTPError as e:
                    LOG.ghi("[AI] Loi HTTP %s" % e.code)
                    if e.code in (400, 401, 403):
                        break
                except Exception as e:
                    LOG.loi("[AI] Loi goi Claude lan %d" % (lan + 1), e)
                time.sleep(2)
            if not ok:
                LOG.ghi("[AI] Bo qua lo %d" % (i // 20 + 1))
    ts = datetime.now().strftime("%Y%m%d%H%M%S")
    duong = os.path.join(kq_dir, "ket_qua_ai_sp_%s.jsonl" % ts)
    with open(duong + ".tmp", "w", encoding="utf-8") as f:      # GD63: ghi tam roi doi ten - VB6 khong doc tep dang ghi do
        for d in ket:
            f.write(json.dumps(d, ensure_ascii=False) + "\n")
    os.replace(duong + ".tmp", duong)
    with open(os.path.join(kq_dir, "DA_XONG_AI_SP"), "w", encoding="utf-8") as f:
        f.write(duong)
    LOG.ghi("[AI] Da ghi %d goi y so phu" % len(ket))
    return duong


# ---------------------------------------------------------------- giao dien web nho
HTML = """<!doctype html><html lang="vi"><head><meta charset="utf-8"><title>Sổ phụ / Bảng lương - UNESCO</title>
<style>body{font-family:Segoe UI,Arial;margin:20px;background:#f5f7f8;color:#123}.card{background:#fff;border:1px solid #d9e2e6;border-radius:8px;padding:16px;margin-bottom:14px;max-width:820px}
h1{font-size:20px}label{display:block;margin:8px 0 4px}input,select{padding:7px;width:100%;box-sizing:border-box}button{background:#1e9e5a;color:#fff;border:0;padding:9px 18px;border-radius:6px;cursor:pointer}
pre{background:#eef3f5;padding:10px;max-height:300px;overflow:auto;font-size:12px}</style></head><body>
<h1>Import sổ phụ ngân hàng / bảng lương → UNESCO (AI hoá đơn)</h1>
<div class="card"><b>Sổ phụ ngân hàng</b> (Excel .xls/.xlsx, CSV, PDF)
<label>Đường dẫn file hoặc thư mục sổ phụ</label><input id="sp" placeholder="C:\\SoPhu\\VCB_T09.xlsx">
<label>Ngân hàng (để trống = tự nhận)</label><select id="nh"><option value="">Tự nhận theo tiêu đề</option>__NGAN_HANG__</select>
<label>Số tài khoản (để trống = tự nhận)</label><input id="stk">
<p><button onclick="go('sophu')">Đọc sổ phụ → JSONL</button></p></div>
<div class="card"><b>Bảng lương</b> (Excel; mỗi sheet một tháng hoặc chọn tháng)
<label>File bảng lương</label><input id="bl" placeholder="C:\\Luong\\BangLuong_T09.xlsx">
<label>Tháng / Năm (để trống = lấy theo tên sheet)</label><input id="th" placeholder="9"><input id="nam" placeholder="2026">
<p><button onclick="go('bangluong')">Đọc bảng lương → JSONL</button></p></div>
<div class="card"><b>Kết quả</b><pre id="kq">Chưa chạy.</pre></div>
<script>function go(m){var q=m=='sophu'?('/chay?m=sophu&f='+encodeURIComponent(sp.value)+'&nh='+nh.value+'&stk='+encodeURIComponent(stk.value))
:('/chay?m=bangluong&f='+encodeURIComponent(bl.value)+'&th='+th.value+'&nam='+nam.value);kq.textContent='Đang xử lý...';
fetch(q).then(r=>r.json()).then(j=>{kq.textContent=JSON.stringify(j,null,2)}).catch(e=>{kq.textContent='Lỗi: '+e})}</script></body></html>"""


class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _tra(self, obj, ma=200, html=False):
        body = obj.encode("utf-8") if html else json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(ma)
        self.send_header("Content-Type", ("text/html" if html else "application/json") + "; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers(); self.wfile.write(body)

    def do_GET(self):
        # GD63: chi nhan yeu cau tu CHINH giao dien 127.0.0.1 (chan trang web la goi /chay - CSRF / DNS rebinding)
        host = (self.headers.get("Host") or "").rsplit(":", 1)[0].strip("[]").lower()
        if host not in ("127.0.0.1", "localhost", "::1") or (self.headers.get("Sec-Fetch-Site") or "").lower() == "cross-site":
            return self._tra({"loi": "Yeu cau khong den tu giao dien cua tool"}, 403)
        u = urllib.parse.urlparse(self.path); q = urllib.parse.parse_qs(u.query)
        g = lambda k: (q.get(k) or [""])[0]
        if u.path == "/":
            opts = "".join('<option value="%s">%s</option>' % (m, m) for _, m in NGAN_HANG)
            # GD111: khong dung toan tu % (CSS co "width:100%;" -> ValueError unsupported format character)
            return self._tra(HTML.replace("__NGAN_HANG__", opts), html=True)
        if u.path == "/chay":
            try:
                if g("m") == "sophu":
                    kq = chay_so_phu(g("f"), g("nh"), g("stk"))
                else:
                    kq = chay_bang_luong(g("f"), int(g("th") or 0), int(g("nam") or 0))
                tong = {}
                if kq:
                    with open(kq[:-6] + "_tong.json", "r", encoding="utf-8") as f:
                        tong = json.load(f)
                return self._tra({"file": kq, "tong": tong})
            except Exception as e:
                LOG.loi("Loi khi chay tu giao dien", e)
                return self._tra({"loi": str(e)}, 500)
        return self._tra({"loi": "404"}, 404)


def lap_thong_bao_cong_no(duong_vao):
    """GD53: doc cong no mo (VB6 xuat JSON) -> trang HTML thong bao cong no + ma VietQR cho tung khach.
    Ghi ket-qua/thong-bao-cong-no/THONG_BAO_CONG_NO_<ts>.html, mo bang trinh duyet, ghi DA_XONG_CN."""
    kq = thu_muc("ket-qua")
    co = os.path.join(kq, "DA_XONG_CN")
    try:
        import vietqr_unesco as VQ
        with io.open(duong_vao, "r", encoding="utf-8-sig") as f:
            du = json.load(f)
        thu = thu_muc(os.path.join("ket-qua", "thong-bao-cong-no"))
        ts = datetime.now().strftime("%Y%m%d%H%M%S")
        duong = os.path.join(thu, "THONG_BAO_CONG_NO_%s.html" % ts)
        so_kh, loi_qr = VQ.ghi_thong_bao(du, duong)
        LOG.ghi("Thong bao cong no: %d khach -> %s%s" % (so_kh, os.path.basename(duong),
                                                         (" | " + loi_qr) if loi_qr else ""))
        with open(co, "w", encoding="utf-8") as f:
            f.write(duong)
        try:
            import webbrowser
            webbrowser.open("file:///" + duong.replace("\\", "/"))
        except Exception:
            pass
        return duong
    except Exception as e:
        LOG.loi("Khong lap duoc thong bao cong no", e)
        try:
            with open(co, "w", encoding="utf-8") as f:
                f.write("LOI|" + str(e)[:300])
        except Exception:
            pass
        return None


def tim_cong(bat_dau=8771):
    import socket
    for p in range(bat_dau, bat_dau + 30):
        s = socket.socket()
        try:
            s.bind(("127.0.0.1", p)); s.close(); return p
        except OSError:
            s.close()
    return 0


def kiem_docai(tep_ra):
    """GD97-D: kiem tra cai dat Google Document AI (docai.json) - khong gui tai lieu. Ghi 'OK ...' / 'LOI ...' vao tep_ra."""
    try:
        import docai_unesco as DA
        DA.dat_nhat_ky(lambda s: LOG.ghi("[DocAI] " + s))
        ok, tb = DA.kiem_thu()
    except Exception as e:
        ok, tb = False, "Không chạy được kiểm tra Document AI: %s" % e
    LOG.ghi("[DocAI] kiem tra: %s %s" % ("OK" if ok else "LOI", bo_dau(tb)[:300]))
    try:
        with io.open(tep_ra, "w", encoding="utf-8") as f:
            f.write(("OK " if ok else "LOI ") + tb)
    except Exception as e:
        LOG.loi("Khong ghi duoc ket qua kiem tra Document AI", e)


def chep_tess(tep_ra):
    """GD104: chep Tesseract OCR dang cai tren may nay -> AIHoaDon\\Tesseract-OCR (ban mang theo, chep ca thu muc AIHoaDon
       sang may khac la OCR Offline doc bang Tesseract, khong can cai). Ghi 'OK <exe>|<so tep>|<MB>' / 'LOI ...' vao tep_ra."""
    try:
        import sp_anh_excel as S
        S.dat_nhat_ky(LOG.ghi)
        exe = S.tim_tesseract(doc_thiet_lap())
        dich = os.path.join(BASE_DIR, "Tesseract-OCR")
        if exe and os.path.normcase(os.path.abspath(os.path.dirname(exe))) == os.path.normcase(os.path.abspath(dich)):
            n = sum(len(f) for _, _, f in os.walk(dich))
            kq = "OK %s|%d|0|da co" % (exe, n)
        else:
            moi, n, mb = S.chep_tesseract(BASE_DIR, exe or None)
            kq = "OK %s|%d|%s" % (moi, n, mb)
            if not os.path.isfile(os.path.join(dich, "tessdata", "vie.traineddata")):
                kq += "|thieu_vie"
    except Exception as e:
        kq = "LOI %s" % e
    LOG.ghi("[TESS] chep Tesseract: %s" % bo_dau(kq)[:300])
    try:
        with io.open(tep_ra, "w", encoding="utf-8") as f:
            f.write(kq)
    except Exception as e:
        LOG.loi("Khong ghi duoc ket qua chep Tesseract", e)


def main():
    doc_tham_so(mo_rong_tham_so(sys.argv))
    if THAM_SO_LOI:
        LOG.ghi("KHONG doc duoc file tham so (%s) - thoat, khong mo giao dien." % "; ".join(THAM_SO_LOI))
        return
    LOG.ghi("=== Tool so phu %s | Python %s | parser cu: %s" % (APP_VERSION, sys.version.split()[0], "co" if CU else "khong (dung openpyxl/xlrd)"))
    LOG.ghi("Tham so: mst=%s out=%s" % (UNESCO["mst"], UNESCO["out"]))
    _tsdp = sys.modules.get("tham_so_du_phong")             # GD111
    if _tsdp is not None and _tsdp.TRANG_THAI.get("bu"):
        LOG.ghi("GD111: tool chay KHONG kem tham so (lien ket .py cua Python install manager / Store) - lay tu %s"
                % os.path.basename(_tsdp.TRANG_THAI["bu"]))
    if UNESCO["dich_sp"]:
        dich_theo_yeu_cau(UNESCO["dich_sp"], ghi_moc=True); return          # GD83
    if UNESCO["sophu"]:
        chay_so_phu(UNESCO["sophu"], UNESCO["nganhang"], UNESCO["sotk"]); return
    if UNESCO["bangluong"]:
        chay_bang_luong(UNESCO["bangluong"], UNESCO["thang"], UNESCO["nam"]); return
    if UNESCO["goi_ai_sp"]:
        goi_claude_so_phu(UNESCO["goi_ai_sp"]); return
    if UNESCO["congno"]:
        lap_thong_bao_cong_no(UNESCO["congno"]); return
    if UNESCO["docai_kiem"]:
        kiem_docai(UNESCO["docai_kiem"]); return          # GD97-D
    if UNESCO["tess_chep"]:
        chep_tess(UNESCO["tess_chep"]); return            # GD104
    if UNESCO["sophu_excel"]:
        chay_so_phu_excel(UNESCO["sophu_excel"], UNESCO["nganhang"], UNESCO["ocr"]); return
    if UNESCO["hosobh"]:
        chay_ho_so_bhxh(UNESCO["hosobh"], UNESCO["nv"]); return
    cong = tim_cong()
    if not cong:
        print("Khong tim duoc cong trong."); return
    server = http.server.ThreadingHTTPServer(("127.0.0.1", cong), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    url = "http://127.0.0.1:%d" % cong
    LOG.ghi("Giao dien: " + url)
    try:
        import webbrowser
        webbrowser.open(url)
    except Exception:
        pass
    print("Giao dien so phu dang mo:", url, "- dong cua so nay de tat.")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        pass


def _moc_khi_loi(e):
    """GD63: loi bat ngo -> ghi moc cua che do dang chay de VB6 khong cho mai."""
    ten = {"sophu": "DA_XONG_SP", "bangluong": "DA_XONG_BL", "goi_ai_sp": "DA_XONG_AI_SP",
           "congno": "DA_XONG_CN", "sophu_excel": "DA_XONG_SP_XLS", "hosobh": "DA_XONG_HSBH", "dich_sp": "DA_XONG_SP"}
    for k, moc in ten.items():
        if UNESCO.get(k):
            try:
                with open(os.path.join(thu_muc("ket-qua"), moc), "w", encoding="utf-8") as f:
                    f.write(("LOI|" if moc == "DA_XONG_CN" else ("LOI " if moc == "DA_XONG_HSBH" else "KHONG_CO_DU_LIEU|")) +
                            bo_dau("Loi tool: %s" % e)[:400])
            except Exception:
                pass
            break


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        LOG.loi("Loi nghiem trong", e)
        _moc_khi_loi(e)
        try:
            input("Nhan Enter de dong...")
        except Exception:
            pass
