# -*- coding: utf-8 -*-
"""GD78 - BANG LUONG (UNESCO XI, tool so phu):
  1. Doc DUNG bang luong Excel: chu VNI / TCVN3 / Unicode (tu nhan theo ca tep), tieu de nhieu dong (dong trong,
     "Cac khoan tru vao luong" -> BHXH / BHYT / BHTN / Tam ung / Khac), dong NHOM bo phan (ten nhom o cot STT hoac cot ho ten),
     dong cong nhom / Tong cong (khong nhap lam nhan vien), DU moi cot so (luong co ban, luong chinh, phu cap, thu nhap khac,
     tong thu nhap, cac khoan tru, thuc lanh, ngay cong).
     Kiem: tong thu nhap = luong chinh + phu cap + thu nhap khac (khi bang co cot luong chinh); thuc lanh = tong thu nhap - cac
     khoan tru; cong tung nhom / tong cong = dong cong trong tep (MOI cot so). Lech -> canh bao ghi ro sheet, dong Excel, ten.
     Ky: thang (tieu de "Thang 9 nam 2026", ten sheet "T9"), ca nam ("Tu thang 1 den thang 12 nam 2025"), nhieu thang, quy.
  2. Danh sach tham gia BHXH bat buoc (mau D02 / C12 cua co quan BHXH): doc STT, ho ten, CCCD, ma so BHXH, so the BHYT, ngay sinh,
     gioi tinh, noi KCB, luong dong BH, chuc danh -> ghep voi danh muc nhan vien (VB6 xuat ra JSON) theo ho ten chuan hoa
     (bo dau, hoa / thuong, khoang trang; nhan ca VNI / TCVN3 / Unicode) + ngay sinh khi co. Chi DE XUAT dien O TRONG;
     o da co ma khac -> liet ke; trung ten / khong chac -> khong ghep, liet ke. CCCD KHONG ghi ra nhat ky / bao cao (che 4 so cuoi).
  GD79: doc lai toan bo cho so tren bang luong sau Import DUNG TUYET DOI voi tep: o gop tieu de (nhan nhom chep sang cot con),
     nhieu bang / tieu de lap lai trong mot sheet, sheet an (bo), dong an (theo dong Tong cong), sheet / bang chep trung (bo),
     dong khong STT, dong "Bang chu" / chu ky, danh xung Ong / Ba, cot BH gop 10,5%, doan phi, khoan tru khac, cot tham khao
     (tim tap cot khop cong thuc tong thu nhap / thuc linh o nhieu dong nhat), cot moi: luong dong BH, so nguoi phu thuoc,
     giam tru gia canh, thu nhap chiu thue / tinh thue; so kiem tren gia tri THO (sai so 1 dong - o co so le).
Chi dung thu vien chuan Python 3.8+."""
import glob
import io
import json
import os
import re
import unicodedata
from datetime import date, datetime, timedelta

PHIEN_BAN = "GD79"

# ============================================================================ bang ma chu
_CIRC, _BREVE, _ACUTE, _GRAVE, _TILDE, _HOOK, _DOT = "̂", "̆", "́", "̀", "̃", "̉", "̣"
# bang VNI giong VNItoUNICODE (Utilitie.bas): dau thanh Ø Ù Û Õ Ï; mu Â (+ thanh À Á Å Ã Ä); trang Ê (+ thanh È É Ú Ü Ë)
_VNI_DAU = {"Â": _CIRC, "â": _CIRC, "Ê": _BREVE, "ê": _BREVE, "Ù": _ACUTE, "ù": _ACUTE,
            "Ø": _GRAVE, "ø": _GRAVE, "Õ": _TILDE, "õ": _TILDE, "Û": _HOOK, "û": _HOOK, "Ï": _DOT, "ï": _DOT,
            "À": _CIRC + _GRAVE, "à": _CIRC + _GRAVE, "Á": _CIRC + _ACUTE, "á": _CIRC + _ACUTE,
            "Ã": _CIRC + _TILDE, "ã": _CIRC + _TILDE, "Å": _CIRC + _HOOK, "å": _CIRC + _HOOK, "Ä": _CIRC + _DOT, "ä": _CIRC + _DOT,
            "È": _BREVE + _GRAVE, "è": _BREVE + _GRAVE, "É": _BREVE + _ACUTE, "é": _BREVE + _ACUTE,
            "Ú": _BREVE + _HOOK, "ú": _BREVE + _HOOK, "Ü": _BREVE + _TILDE, "ü": _BREVE + _TILDE, "Ë": _BREVE + _DOT, "ë": _BREVE + _DOT}
_VNI_CHU = {"Ñ": "Đ", "ñ": "đ", "Ö": "Ư", "ö": "ư", "Ô": "Ơ", "ô": "ơ", "Ò": "Ị", "ò": "ị", "Ó": "Ĩ", "ó": "ĩ", "Æ": "Ỉ", "æ": "ỉ",
            "Î": "Ỵ", "î": "ỵ"}
# ky tu CHI co trong VNI (khong phai chu Viet Unicode)
_VNI_RIENG = set("øØûÛïÏåÅäÄëËñÑöÖæÆîÎüÜ")
_TCVN3 = {
    "µ": "à", "¸": "á", "¶": "ả", "·": "ã", "¹": "ạ", "¨": "ă", "»": "ằ", "¾": "ắ", "¼": "ẳ", "½": "ẵ", "Æ": "ặ",
    "©": "â", "Ç": "ầ", "Ê": "ấ", "È": "ẩ", "É": "ẫ", "Ë": "ậ", "®": "đ", "Ì": "è", "Ð": "é", "Î": "ẻ", "Ï": "ẽ", "Ñ": "ẹ",
    "ª": "ê", "Ò": "ề", "Õ": "ế", "Ó": "ể", "Ô": "ễ", "Ö": "ệ", "×": "ì", "Ý": "í", "Ø": "ỉ", "Ü": "ĩ", "Þ": "ị",
    "ß": "ò", "ã": "ó", "á": "ỏ", "â": "õ", "ä": "ọ", "«": "ô", "å": "ồ", "è": "ố", "æ": "ổ", "ç": "ỗ", "é": "ộ",
    "¬": "ơ", "ê": "ờ", "í": "ớ", "ë": "ở", "ì": "ỡ", "î": "ợ", "ï": "ù", "ó": "ú", "ñ": "ủ", "ò": "ũ", "ô": "ụ",
    "\xad": "ư", "õ": "ừ", "ø": "ứ", "ö": "ử", "÷": "ữ", "ù": "ự", "ú": "ỳ", "ý": "ý", "û": "ỷ", "ü": "ỹ", "þ": "ỵ",
    "¡": "Ă", "¢": "Â", "§": "Đ", "£": "Ê", "¤": "Ô", "¥": "Ơ", "¦": "Ư"}
# ky tu TCVN3 nam trong vung A1-BF (VNI va chu Viet Unicode KHONG dung vung nay)
_TCVN3_RIENG = set("¡¢£¤¥¦§¨©ª«¬\xad®µ¶·¸¹»¼½¾")


def vni_sang_u(s):
    if not isinstance(s, str) or not s or any(ord(c) > 255 for c in s):
        return s
    out = []
    for c in s:
        out.append(_VNI_CHU.get(c) or _VNI_DAU.get(c) or c)
    return unicodedata.normalize("NFC", "".join(out))


def tcvn3_sang_u(s):
    if not isinstance(s, str) or not s or any(ord(c) > 255 for c in s):
        return s
    return "".join(_TCVN3.get(c, c) for c in s)


# cap chu CHI gap o VNI: nguyen am + dau mu / trang / thanh dung rieng (VNI "Nguyeãn", "Vaên", "Coâng"); chu Viet Unicode khong co
_RE_VNI_CAP = re.compile("[aeoAEO][âÂ]|[aA][êÊèéÈÉúÚüÜëË]|[aeAE][àáãåäÀÁÃÅÄ]|[oO][åäÅÄ]|[uU][ùÙ]")


def loai_ma(chuoi):
    """Nhan bang ma cua MOT tap chuoi (ca tep): 'UNI' | 'VNI' | 'TCVN3' | 'ASCII'."""
    uni = vni = tc = cao = 0
    for s in chuoi:
        if not isinstance(s, str):
            continue
        if all(ord(c) <= 255 for c in s):
            vni += len(_RE_VNI_CAP.findall(s))
        for c in s:
            o = ord(c)
            if o < 128:
                continue
            if o > 255:
                uni += 1
            else:
                cao += 1
                if c in _VNI_RIENG:
                    vni += 1
                if c in _TCVN3_RIENG:
                    tc += 1
    if uni and uni >= vni + tc:
        return "UNI"
    if tc and tc * 5 >= vni:
        return "TCVN3"
    if vni:
        return "VNI"
    if uni:
        return "UNI"
    return "ASCII" if not cao else "UNI"


def chuyen_bang(tab):
    """{sheet: [[o]]} -> (bang da doi sang Unicode, ma). Ma nhan theo CA tep (ten sheet + moi o chu)."""
    chuoi = [sh for sh in tab] + [c for A in tab.values() for r in (A or []) for c in (r or []) if isinstance(c, str)]
    ma = loai_ma(chuoi)
    if ma not in ("VNI", "TCVN3"):
        # GD79: tep Unicode co vai o con chu VNI (mau cu go tiep bang Unicode) -> doi rieng o co dau hieu VNI ro rang
        if ma == "UNI" and any(isinstance(c, str) and _la_o_vni(c) for A in tab.values() for r in (A or []) for c in (r or [])):
            kq = {}
            for sh, A in tab.items():
                kq[sh] = [[vni_sang_u(c) if isinstance(c, str) and _la_o_vni(c) else c for c in (r or [])] for r in (A or [])]
            return kq, ma
        return tab, ma
    f = _vni_o if ma == "VNI" else tcvn3_sang_u
    kq = {}
    for sh, A in tab.items():
        kq[f(sh)] = [[f(c) if isinstance(c, str) else c for c in (r or [])] for r in (A or [])]
    return kq, ma


def _la_o_vni(c):
    """o chu (chi ky tu <= 255) co cap chu chi gap o VNI ("Nguyeãn", "Vaên")"""
    return bool(c) and all(ord(x) <= 255 for x in c) and len(_RE_VNI_CAP.findall(c)) >= 1 and loai_ma([c]) == "VNI" and _vni_hop_le(c)


# GD79: dau VNI (mu / trang / thanh la ky tu rieng) chi dung SAU nguyen am; o co dau dung sau phu am ("Lê Tâm", "Tô Mâu" go
#   Unicode trong tep VNI) KHONG phai chu VNI -> giu nguyen (truoc day doi thanh "L̆ T̂m").
_VNI_SAU_MU = set("âÂàÀáÁåÅãÃäÄ")
_VNI_SAU_TRANG = set("êÊèÈéÉúÚüÜëË")
_VNI_THANH = set("ùÙøØûÛõÕïÏ")


def _vni_hop_le(c):
    truoc = ""
    for x in c:
        if x in _VNI_SAU_MU and truoc not in "aeoAEO":
            return False
        if x in _VNI_SAU_TRANG and truoc not in "aA":
            return False
        if x in _VNI_THANH and truoc not in "aeiouyAEIOUYôÔöÖâÂêÊ":
            return False
        truoc = x if x else truoc
    return True


def _vni_o(c):
    return vni_sang_u(c) if _vni_hop_le(c) else c


def bo_dau(s):
    s = str(s or "").replace("Đ", "D").replace("đ", "d")
    return "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")


def sa(x):
    """chu thuong khong dau, mot dau cach (so tieu de cot)."""
    return re.sub(r"\s+", " ", bo_dau(str(x if x is not None else "")).lower()).strip()


def khoa_ten(s):
    """Ho ten chuan hoa de ghep: CHU HOA khong dau, chi A-Z0-9, mot dau cach. Nhan ca chuoi VNI / TCVN3 le."""
    s = str(s or "")
    if s and all(ord(c) <= 255 for c in s):
        m = loai_ma([s])
        if m == "VNI":
            s = vni_sang_u(s)
        elif m == "TCVN3":
            s = tcvn3_sang_u(s)
    t = re.sub(r"[^A-Z0-9 ]+", " ", bo_dau(s).upper())
    return re.sub(r"\s+", " ", t).strip()


def so_tien(v):
    """chuoi / so -> float (1.234.567 | 1,234,567 | (500) | 12,5). Khong doc duoc -> 0."""
    if v is None or v == "" or isinstance(v, bool):
        return 0.0
    if isinstance(v, (int, float)):
        return float(v)
    t = str(v).strip()
    am = t.startswith("(") and t.endswith(")")
    t = t.strip("()").replace(" ", "").replace("\xa0", "")
    if re.search(r"[^0-9.,\-]", t):
        t = re.sub(r"[^0-9.,\-]", "", t)
    if len(t) > 1 and t.endswith("-") and not t.startswith("-"):
        am, t = not am, t[:-1]
    if t.count(",") and t.count("."):
        t = t.replace(".", "").replace(",", ".") if t.rfind(",") > t.rfind(".") else t.replace(",", "")
    elif t.count(",") > 1 or (t.count(",") == 1 and len(t.split(",")[1]) == 3):
        t = t.replace(",", "")
    elif t.count(".") > 1 or (t.count(".") == 1 and len(t.split(".")[1]) == 3):
        t = t.replace(".", "")
    else:
        t = t.replace(",", ".")
    t = re.sub(r"[^0-9.\-]", "", t)
    try:
        x = float(t) if t not in ("", "-", ".") else 0.0
    except ValueError:
        x = 0.0
    return -x if am else x


def dong(v):
    """lam tron dong (nua xa so 0, nhu HTKK)"""
    v = float(v or 0)
    return float(int(abs(v) + 0.5)) * (1 if v >= 0 else -1)


def dd(v):
    return "{:,.0f}".format(dong(v)).replace(",", ".")


# ============================================================================ ky bang luong
def ky_tu_chu(chu, chat=False):
    """Ky tu mot doan chu (tieu de / ten sheet). -> dict(tu, den, nam, loai) hoac {} (khong thay).
    loai: 'THANG' (tu = den), 'NHIEU' (tu < den), 'NAM' (ca nam). nam co the = 0 (khong ghi nam).
    GD79: chat=True (doan chu noi tu nhieu o) - thang phai ghi "thang N" / "th N", khong nhan "T3" (dia chi "Lo T3")."""
    t = re.sub(r"\s+", " ", bo_dau(chu).lower())
    t = t.replace("thang", " thang ").replace("nam", " nam ")
    t = re.sub(r"\s+", " ", t)
    # ngay lap / ngay ky ("ngay 31 thang 12 nam 2025", "ngay 31/12/2025") khong phai ky bang luong
    t = re.sub(r"\bngay \d{1,2} ?[/.\-] ?\d{1,2} ?[/.\-] ?\d{2,4}", " ", t)
    t = re.sub(r"\bngay \d{1,2} thang \d{1,2}(?: nam \d{4})?", " ", t)
    nam = 0
    m = re.search(r"tu thang (\d{1,2})(?: nam (20\d\d)| ?[/.\-] ?(20\d\d))? ?(?:den|toi|-|~|->) ?(?:het )?thang (\d{1,2})"
                  r"(?: ?(?:nam|[/.\-]) ?(20\d\d))?", t)
    if m:
        tu, den = int(m.group(1)), int(m.group(4))
        nam = int(m.group(5) or m.group(2) or m.group(3) or 0)
        if not nam:
            m2 = re.search(r"\bnam (20\d\d)\b", t)
            nam = int(m2.group(1)) if m2 else 0
        if 1 <= tu <= 12 and 1 <= den <= 12 and tu <= den:
            loai = "NAM" if (tu, den) == (1, 12) else ("THANG" if tu == den else "NHIEU")
            return {"tu": tu, "den": den, "nam": nam, "loai": loai}
    m = re.search(r"\bquy (i{1,3}|iv|[1-4])\b(?: ?(?:nam|[/.\-]) ?(20\d\d))?", t)
    if m:
        q = {"i": 1, "ii": 2, "iii": 3, "iv": 4}.get(m.group(1)) or int(m.group(1))
        nam = int(m.group(2) or 0)
        return {"tu": 3 * q - 2, "den": 3 * q, "nam": nam, "loai": "NHIEU"}
    m = re.search(r"(?:\bthang ?|\bth[.\-]?" + ("" if chat else r"|\bt[.\-]?") + r")(\d{1,2})(?!\d)(?: ?(?:nam|[/.\-,]) ?(20\d\d))?", t)
    if m and 1 <= int(m.group(1)) <= 12:
        th = int(m.group(1))
        nam = int(m.group(2) or 0)
        if not nam:
            m2 = re.search(r"\bnam (20\d\d)\b", t)
            nam = int(m2.group(1)) if m2 else 0
        return {"tu": th, "den": th, "nam": nam, "loai": "THANG"}
    m = re.search(r"(?<!\d)(\d{1,2}) ?[/.\-_] ?(20\d\d)(?!\d)", t)
    if m and 1 <= int(m.group(1)) <= 12:
        th = int(m.group(1))
        return {"tu": th, "den": th, "nam": int(m.group(2)), "loai": "THANG"}
    if re.search(r"\bca nam\b|\bquyet toan\b|\btong hop .*\bnam 20\d\d", t):
        m2 = re.search(r"\bnam (20\d\d)\b", t)
        return {"tu": 1, "den": 12, "nam": int(m2.group(1)) if m2 else 0, "loai": "NAM"}
    m2 = re.search(r"\bnam (20\d\d)\b", t)
    if m2:
        return {"tu": 0, "den": 0, "nam": int(m2.group(1)), "loai": ""}
    return {}


def ma_ky(ky):
    """ma thang luu trong HDDT_BL_Ky.Thang: thang 1..12; ca nam 0; nhieu thang tu*100+den (vd 106 = thang 1 - 6)."""
    if not ky or not ky.get("loai"):
        return -1
    if ky["loai"] == "THANG":
        return ky["tu"]
    if ky["loai"] == "NAM":
        return 0
    return ky["tu"] * 100 + ky["den"]


def ten_ky(thang, nam):
    if thang == 0:
        return "cả năm %s" % nam
    if thang > 100:
        return "tháng %d - %d/%s" % (thang // 100, thang % 100, nam)
    return "tháng %02d/%s" % (thang, nam)


def thang_ten_sheet(ten):
    """'thang 01', 'T8', 'Thang 12-2026', 'BL 03.2026' -> thang; 'Sheet1' -> 0 (giong GD75)."""
    t = bo_dau(str(ten or "")).upper()
    m = re.search(r"(?:THANG|\bTH|\bT)\s*[._-]?\s*(\d{1,2})(?!\d)", t)
    if not m:
        m = re.search(r"(?<!\d)(\d{1,2})\s*[./_-]\s*20\d\d(?!\d)", t)
    if m and 1 <= int(m.group(1)) <= 12:
        return int(m.group(1))
    return 0


# ============================================================================ cot bang luong
# moi cot mot DANH SACH mau theo uu tien (so tren chu thuong khong dau - sa()). GD78: tach LUONG CHINH khoi LUONG CO BAN;
#   THU NHAP KHAC rieng khoi PHU CAP. GD79: them luong dong BH, so nguoi phu thuoc, giam tru gia canh, thu nhap chiu thue /
#   tinh thue, cot BH gop (10,5%), doan phi cong doan, tong khau tru; thu tu cot quyet dinh cot nao "giu" o truoc
#   (vd "Thu nhap chiu thue TNCN" phai thanh thu nhap chiu thue TRUOC khi xet thue TNCN / tong thu nhap).
_DN = r"\b(dn|doanh nghiep|cong ty|cty|don vi|nsdld|su dung lao dong|chu su dung)\b"
_KHONG_DN = r"^(?!.*" + _DN + r")"
BL_COT = [("stt", [r"^(stt|so tt|s tt|tt|so thu tu|no\.?|#)$"]),
          ("ten", [r"^(?!.*\bky\b).*(ho\W*(va\W*|&\W*|and\W*)?ten|ten (nhan vien|nguoi lao dong|nld|cong nhan|can bo|cnv)|full ?name"
                   r"|employee name)|^ten$|^employee$"]),
          ("ma_nv", [r"^ma( nv| nhan vien| cnv)?$|^ma so( nv| nhan vien)?$|^stt ma|employee (id|code)|^ma$|^ma nv", r"^ma so$"]),
          ("so_tk", [r"so tai khoan|so tk|\bstk\b|account"]),
          ("mst", [r"ma so thue|\bmst\b"]),
          ("cccd", [r"cccd|cmnd|can cuoc|so dinh danh|ho chieu"]),
          ("bo_phan", [r"bo phan|phong ban|^phong$|don vi cong tac|^to$|to doi|department"]),
          ("chuc_vu", [r"^(?!.*(phu cap|tro cap|luong)).*(chuc vu|chuc danh|vi tri|position)"]),
          ("ky_nhan", [r"ky nhan|\bky\b.*\bten\b|chu ky|ghi chu"]),
          ("ngay_cong", [r"^(?!.*(luong|tien|thanh tien|don gia|phu cap)).*(ngay cong|so cong|cong lam viec|so ngay lam|ngay lam viec|cong thuc te)"]),
          ("luong_dong_bh", [r"^(?!.*(trich|khoan|\btru\b|%|\bdn\b|\bnv\b|nld|nguoi lao dong|doanh nghiep|cong ty))"
                             r".*(luong|muc luong|tien luong|thu nhap|muc|can cu)\b.*\b(dong|tham gia|tinh|nop)\b.*(\bbh|bao hiem)",
                             r"^luong (bhxh|bh)\b|^luong bao hiem|luong dong bh"]),
          ("luong_chinh", [r"luong chinh|luong thuc te|luong theo (ngay )?cong|luong thoi gian|tien luong thuc|luong san pham|thanh tien luong"]),
          ("luong_cb", [r"luong co ban|luong cb|muc luong|luong hop dong|luong theo hd|luong toi thieu|basic"]),
          ("thu_nhap_khac", [r"thu nhap khac|tn khac|khoan thu nhap khac"]),
          ("tn_chiu_thue", [r"(thu nhap|\btn\b) ?chiu thue|\btnct\b"]),
          ("tn_tinh_thue", [r"(thu nhap|\btn\b) ?tinh thue|\btntt\b"]),
          ("so_npt", [r"so (nguoi )?(phu thuoc|npt)|so luong (nguoi )?(phu thuoc|npt)|^npt$|(nguoi phu thuoc|npt).*\((nguoi|sl)\)"]),
          ("giam_tru_gc", [r"^(?!.*\b(so|sl)\b).*giam tru gia canh$|^(tong|cong)( cong)? giam tru|giam tru gia canh (cong|tong)$"]),
          ("phu_cap", [r"^(?!(tong|cong)\b).*(phu cap|tro cap|allowance|^pc\b)"]),
          ("tong_thu_nhap", [r"^(?!.*(chiu thue|tinh thue|mien thue|khong chiu|\btru\b|giam tru|\bbh|bao hiem|thue|phu cap)).*"
                             r"(tong thu nhap|tong luong|tong tien luong|gross|tong so tien|tong cong thu nhap)",
                             r"^(?!.*(\btru\b|giam|\bbh|bao hiem|thue|phu cap|thu nhap khac|ngay)).*tong cong",
                             r"^(tong|cong)( cong)?$",
                             r"^(?!.*(khac|chiu thue|tinh thue|mien thue|khong chiu|giam tru)).*thu nhap"]),
          ("bhxh_nv", [_KHONG_DN + r".*(bhxh.*(\bnv\b|nld|\b8 ?%|\b8\b|nguoi lao dong|\btru\b)|(\bnv\b|nld|nguoi lao dong|\btru\b|khau tru).*bhxh)",
                       r"^bhxh( \(?8 ?%\)?)?$"]),
          ("bhyt_nv", [_KHONG_DN + r".*(bhyt.*(\bnv\b|nld|1[.,]5|nguoi lao dong|\btru\b)|(\bnv\b|nld|nguoi lao dong|\btru\b|khau tru).*bhyt)",
                       r"^bhyt( \(?1[.,]5 ?%\)?)?$"]),
          ("bhtn_nv", [_KHONG_DN + r".*(bhtn.*(\bnv\b|nld|\b1 ?%|nguoi lao dong|\btru\b)|(\bnv\b|nld|nguoi lao dong|\btru\b|khau tru).*bhtn)",
                       r"^bhtn( \(?1 ?%\)?)?$"]),
          ("bhxh_dn", [r"bhxh.*(" + _DN + r"|17[.,]5|\b17\b)|" + _DN + r".*bhxh"]),
          ("bhyt_dn", [r"bhyt.*(" + _DN + r"|\b3 ?%)|" + _DN + r".*bhyt"]),
          ("bhtn_dn", [r"bhtn.*" + _DN + r"|" + _DN + r".*bhtn"]),
          ("bh_gop_nv", [_KHONG_DN + r".*((bhxh|\bbh)\W*(,|\+|va|/|-|&)\W*(bhyt|yt\b)|bao hiem|^\W*bh\W*$|\bbh (xh )?\(?10[.,]5|10[.,]5 ?%|trich bh)"]),
          ("bh_gop_dn", [r"^(?!.*(kpcd|cong doan|bhxh|bhyt|bhtn))(.*" + _DN + r".*(bao hiem|\bbh\b)|.*(bao hiem|\bbh\b).*" + _DN + r"|(bh|bao hiem)\W*\(?2[13][.,]5 ?%)"]),
          ("doan_phi", [r"doan phi|phi cong doan|cong doan phi|cong doan.*\b1 ?%"]),
          ("kpcd", [r"kpcd|kinh phi cong doan|cong doan"]),
          ("thue_tncn", [r"^(?!.*(chiu thue|tinh thue|giam tru|mien thue|truoc thue|sau thue)).*(thue tncn|\btncn\b|thue thu nhap|\bpit\b)",
                         r"^thue( phai nop| khau tru| da khau tru)?$"]),
          ("tam_ung", [r"tam ung|ung luong|da ung|\bung\b.*(ky|dot|lan)|advance"]),
          ("tong_tru", [r"(tong|cong)( cong)? (cac )?(khoan )?(khau )?tru\b|(khau tru|cac khoan tru).*(tong|cong)( cong)?$"]),
          ("tru_khac", [r"(\btru\b|khau tru).*khac$|^tru khac|khau tru khac|^khac$"]),
          ("thuc_linh", [r"thuc linh|thuc nhan|thuc lanh|thuc tra|thuc con|so tien (thuc )?(nhan|linh|lanh)|(con|duoc) (linh|lanh|nhan)"
                         r"|\bnet\b|con lai"])]
KHAU_TRU = ("bhxh_nv", "bhyt_nv", "bhtn_nv", "thue_tncn", "tam_ung", "tru_khac")
THU_NHAP = ("luong_chinh", "phu_cap", "thu_nhap_khac")
COT_CHU = ("ten", "stt", "ma_nv", "so_tk", "bo_phan", "chuc_vu", "mst", "cccd", "ky_nhan")
# cot doc de kiem / quy doi, KHONG ghi thang vao bang luong (gia tri da cong vao cot khac)
COT_NOI_BO = ("mst", "cccd", "ky_nhan", "tong_tru", "bh_gop_nv", "bh_gop_dn", "doan_phi")
TEN_COT = {"ngay_cong": "ngày công", "luong_cb": "lương cơ bản", "luong_chinh": "lương chính", "phu_cap": "phụ cấp",
           "thu_nhap_khac": "thu nhập khác", "tong_thu_nhap": "tổng thu nhập", "bhxh_nv": "BHXH", "bhyt_nv": "BHYT",
           "bhtn_nv": "BHTN", "bhxh_dn": "BHXH doanh nghiệp", "bhyt_dn": "BHYT doanh nghiệp", "bhtn_dn": "BHTN doanh nghiệp",
           "kpcd": "KPCĐ", "thue_tncn": "thuế TNCN", "tam_ung": "tạm ứng", "tru_khac": "trừ khác", "thuc_linh": "thực lĩnh",
           "luong_dong_bh": "lương đóng BH", "so_npt": "số người phụ thuộc", "giam_tru_gc": "giảm trừ gia cảnh",
           "tn_chiu_thue": "thu nhập chịu thuế", "tn_tinh_thue": "thu nhập tính thuế"}
# thu tu kiem cot trong dong cong (thuc linh / tong thu nhap truoc - giong GD75)
THU_TU_KIEM = ("thuc_linh", "tong_thu_nhap", "luong_cb", "luong_chinh", "phu_cap", "thu_nhap_khac", "bhxh_nv", "bhyt_nv", "bhtn_nv",
               "bhxh_dn", "bhyt_dn", "bhtn_dn", "kpcd", "thue_tncn", "tam_ung", "tru_khac", "ngay_cong",
               "luong_dong_bh", "giam_tru_gc", "tn_chiu_thue", "tn_tinh_thue", "so_npt")
COT_SO_LUU = tuple(k for k in THU_TU_KIEM)
RE_NHOM = re.compile(r"^(nhan vien|bo phan|phong |xuong|phan xuong|khoi |cong nhan|nhom |chi nhanh|van phong|kinh doanh|"
                     r"san xuat|cong trinh|lao dong|quan ly|hanh chinh|ke toan|kho |kho$|cua hang|nha may|du an|thoi vu|hop dong|"
                     r"thu viec|ky thuat|bao ve|tap vu|lai xe|tai xe|van chuyen|giao hang|marketing|ban hang|"
                     r"to (\d|sx\b|san xuat|bao ve|thi cong|xay dung|co khi|dien|may|han|nau|ve sinh|hoan thien|lap|son|moc)|"
                     r"ban (giam doc|quan ly|kiem soat|dieu hanh|lanh dao)|doi (\d|thi cong|xe|bao ve|san xuat|cong trinh))")
RE_TONG = re.compile(r"^(TONG CONG|TONG SO|TONG LUONG|TONG QUY|TOTAL|TONG\W*$|CONG\W*$|"
                     r"CONG (NHOM|BO PHAN|BP|PHONG|TO|XUONG|PHAN XUONG|KHOI|VAN PHONG|VP|DOI|BAN|CONG|THANG|KHO|CUA HANG|NHA MAY|CHI NHANH|"
                     r"CONG TRINH|DU AN|SX|KD|I|II|III|IV|V|VI|A|B|C)\b)")
RE_LA_MA = re.compile(r"^(?:[IVX]{1,5}|[A-H])[.)]?$")
# dong chan trang: so tien bang chu, nguoi lap / ky ten - khong phai nguoi
RE_CHAN = re.compile(r"bang chu|^(nguoi lap|lap bieu|ke toan truong|thu truong|giam doc$|tong giam doc$|thu quy$|\(ky|ngay \d{1,2} thang|"
                     r"\.+ ?, ?ngay)|\bngay \S{1,4} thang \S{1,4} nam\b")
# o tieu de "ho va ten" (khong nham dong chu ky "(Ky, ho ten)")
RE_TD_TEN = re.compile(r"^(?!.*\bky\b).*(ho\W*(va\W*|&\W*|and\W*)?ten|ten (nhan vien|nguoi lao dong|nld|cong nhan|can bo|cnv)|full ?name"
                       r"|employee name)")
RE_TD_KHAC = re.compile(r"luong|thuc (linh|lanh|nhan)|tong|bhxh|\bbh|thue|phu cap|ngay cong|\bstt\b|so tt|chuc vu|so tien|thu nhap|"
                        r"ky nhan|ma nv|so tk|tai khoan|cccd|ngay sinh|tam ung|khau tru|bo phan")
# o phan dau khong dung de doc ky (dia chi "Lo T3", "Thong tu 133/2016", MST...)
RE_KHONG_KY = re.compile(r"^(dia chi|d/c|dc\b|mst|ma so thue|dien thoai|dt\b|tel|fax|email|website|so tai khoan|tai khoan|ngan hang|"
                         r"cong ty|cty|don vi|bo phan|mau so|\(?ban hanh|theo thong tu|thong tu|\(?kem theo|ma so dn|giay phep)")
# danh xung truoc ho ten
RE_DANH_XUNG = re.compile(r"^(ông|bà|anh|chị|cô|chú|ong|ba|mr|mrs|ms|miss)\.?\s+", re.I)
HO_PHO_BIEN = set("NGUYEN TRAN LE PHAM HOANG HUYNH PHAN VU VO DANG BUI DO HO NGO DUONG LY DAO DOAN VUONG TRINH TRUONG LAM MAI CAO "
                  "LUONG HA TA TO THAI TONG LUU CHAU QUACH KIEU LA TIEU TANG THACH LO LUC MAC KHUC DINH DIEP HUA TRIEU VAN KIM "
                  "PHUNG TON CU THAN BANG BACH DUONG LAI NGHIEM DAM QUAN THIEU".split())


def chuan(s):
    t = re.sub(r"[^A-Z0-9 ]+", " ", bo_dau(s).upper())
    return re.sub(r"\s+", " ", t).strip()


def tim_cot(H, bang=BL_COT):
    cot = {}
    for k, ds in bang:
        for rx in ds:
            i = next((i for i, c in enumerate(H) if c and re.search(rx, c) and i not in cot.values()), None)
            if i is not None:
                cot[k] = i
                break
    return cot


def la_stt(v):
    if v is None or isinstance(v, bool):
        return False
    if isinstance(v, (int, float)):
        return v > 0
    return bool(re.match(r"^\d+(\.0+)?\.?$", str(v).strip()))


def la_so(v):
    """o co phai so (so that hoac chu so '1.234.567' / '(500.000)' / '-')"""
    if v is None or isinstance(v, bool):
        return False
    if isinstance(v, (int, float)):
        return True
    t = str(v).strip().replace("\xa0", " ")
    return bool(re.match(r"^\(?-?\s*\d[\d.,\s]*\)?\s*(d|đ|vnd|vnđ)?\s*-?$", t, re.I))


def co_tien(r):
    return any((isinstance(c, (int, float)) and not isinstance(c, bool) and abs(c) >= 1000) or
               bool(re.match(r"^\(?-?\d{1,3}([.,]\d{3})+\)?$", str(c or "").strip())) for c in (r or []))


def _o_td(c):
    """o tieu de: ty le dang so (0,08 dinh dang %) -> "8%" de nhan cot (BHXH 8% / 17,5%)."""
    if isinstance(c, float) and 0 < c < 1:
        return ("%.2f" % (c * 100)).rstrip("0").rstrip(".") + "%"
    return sa(c)


def _gop_theo_o(A, hr, cuoi, gop):
    """GD79: dong tieu de hr..cuoi da dien o gop ngang (chu cua o dau tien chep sang ca vung gop)."""
    rows = {}
    for k in range(hr, cuoi + 1):
        rows[k] = [_o_td(c) for c in (A[k] or [])]
    for (r1, c1, r2, c2) in gop or []:
        if c2 <= c1:
            continue
        for k in range(max(r1, hr), min(r2, cuoi) + 1):
            if k != r1:
                continue          # chu o gop nam o dong dau cua vung
            R = rows[k]
            if c1 >= len(R) or not R[c1]:
                continue
            while len(R) <= c2:
                R.append("")
            for c in range(c1 + 1, c2 + 1):
                if not R[c]:
                    R[c] = R[c1]
    return rows


def _gop_doan(rows, hr, cuoi):
    """Khong co thong tin o gop (Excel 95 / csv): nhan nhom (vd "Cac khoan tru vao luong", "Phu cap") nam tren MOT o, cac cot
    con ben duoi co ten rieng -> gan nhan cho cac cot con ke ben (o dong tren trong, dong duoi co chu); cot o giua hai nhan
    thuoc nhan gan hon (Excel cu hay can giua qua vung chon nen nhan co the o giua)."""
    for k in range(hr, cuoi):
        R = rows[k]
        duoi = [rows[q] for q in range(k + 1, cuoi + 1)]
        n = max([len(R)] + [len(x) for x in duoi])

        def co_duoi(c):
            return any(c < len(x) and x[c] for x in duoi)
        nhan = [c for c in range(min(len(R), n)) if R[c] and co_duoi(c)]
        if not nhan:
            continue
        while len(R) < n:
            R.append("")
        moi = list(R)
        for c in range(n):
            if R[c] or not co_duoi(c):
                continue
            # tim nhan gan nhat trai / phai, khong vuot qua o dong tren co chu (nhan cua cot khac) hoac cot trong ca hai dong
            ben = []
            for buoc in (-1, 1):
                q = c + buoc
                while 0 <= q < n:
                    if R[q]:
                        if q in nhan:
                            ben.append((abs(q - c), buoc, q))
                        break
                    if not co_duoi(q):
                        break
                    q += buoc
            if ben:
                ben.sort()
                moi[c] = R[ben[0][2]]
        rows[k] = moi
    return rows


def gop_tieu_de(A, hr, ti, gop=None):
    """Dong tieu de hr + toi da 3 dong tieu de phu ben duoi (bo qua dong trong / dong danh so cot 1 2 3...).
    Dong phu: >= 2 o chu, khong co so tien, cot ho ten TRONG (dong nhom / nguoi thi cot ho ten co chu). -> (H, dong cuoi).
    GD79: nhan nhom (o gop ngang) chep sang moi cot con truoc khi noi (vd "cac khoan tru vao luong bhyt", "phu cap an ca")."""
    cuoi = hr
    k = hr + 1
    trong_lien = 0
    phu = []
    while k < len(A) and k <= hr + 4:
        r = A[k] or []
        o = [sa(c) for c in r]
        co = [c for c in o if c]
        if not co:
            trong_lien += 1
            if trong_lien > 2:
                break
            k += 1
            continue
        trong_lien = 0
        if co_tien(r):
            break
        if ti < len(r) and r[ti] is not None and str(r[ti]).strip():
            break
        co = [c[:-2] if re.match(r"^\d{1,2}\.0$", c) else c for c in co]
        if len(co) >= 3 and all(re.match(r"^(\d{1,2}|[a-z]|\(\d{1,2}\)|\d{1,2} ?[=+\-x*/].*)$", c) for c in co):
            cuoi = k            # dong danh so cot (A, B, 1, 2, 3 = 1 x 2 ...)
            k += 1
            continue
        if len(co) < 2 or any(la_stt(c) for c in r[:3]):
            break
        phu.append(k)
        cuoi = k
        k += 1
    dong_td = [hr] + phu
    rows = _gop_theo_o(A, hr, cuoi, gop)
    if phu and not gop:
        rows = _gop_doan(rows, hr, max(phu))
    H = list(rows[hr])
    for k in phu:
        o = rows[k]
        H = [(a + " " + b).strip() if b and b != a else a for a, b in zip(H + [""] * max(0, len(o) - len(H)), o + [""] * max(0, len(H) - len(o)))]
    del dong_td
    return H, cuoi


def _chu_trai(r, ti):
    """o chu dau tien o cac cot 0..ti+1 (ten nhom / dong tong ghi o cot STT)."""
    for i in range(0, min(len(r), ti + 2)):
        c = r[i]
        if isinstance(c, str) and c.strip() and not re.match(r"^[\d.,\s]+$", c):
            return c.strip(), i
    return "", -1


def lam_sach_ten(s):
    """bo danh xung (Ong / Ba / Anh / Chi...) truoc ho ten, ghi chu trong ngoac cuoi ten, khoang trang thua."""
    t = re.sub(r"\s+", " ", unicodedata.normalize("NFC", str(s or ""))).strip().strip(",;:-").strip()
    m = RE_DANH_XUNG.match(t)
    if m:
        con = t[m.end():].strip()
        tu = con.split()
        if len(tu) >= 2 and (chuan(tu[0]) in HO_PHO_BIEN or len(tu) >= 3):
            t = con
    m = re.match(r"^(.*\S)\s*\([^()]*\)$", t)
    if m and len(m.group(1).split()) >= 2:
        t = m.group(1)
    return t


def _o_chu(A, tu, den):
    """cac o chu o dong tu..den-1 (de doc ky), bo o dia chi / MST / mau so."""
    kq = []
    for r in A[max(0, tu):max(0, den)]:
        for c in (r or []):
            if isinstance(c, str) and c.strip() and not RE_KHONG_KY.match(sa(c)):
                kq.append(c)
    return kq


def ky_tu_o(cac_o):
    """Ky tu cac o phan dau: uu tien o co chu "luong" / "bang" / "thanh toan" (dong tieu de bang), roi o co "thang / quy / nam",
    cuoi cung ca doan noi lai (nhu GD78)."""
    uu = [c for c in cac_o if re.search(r"luong|bang|thanh toan|chi tra|\bky\b", sa(c))]
    for c in uu:
        k = ky_tu_chu(c)
        if k.get("loai"):
            if not k.get("nam"):
                k2 = ky_tu_chu(" ".join(cac_o))
                if k2.get("nam"):
                    k["nam"] = k2["nam"]
            return k
    for c in cac_o:
        if re.search(r"thang|quy|\bnam\b", sa(c)):
            k = ky_tu_chu(c)
            if k.get("loai"):
                if not k.get("nam"):
                    k2 = ky_tu_chu(" ".join(cac_o))
                    if k2.get("nam"):
                        k["nam"] = k2["nam"]
                return k
    return ky_tu_chu(" ".join(cac_o), chat=True) if cac_o else {}


def _la_tieu_de(A, i):
    r = A[i] or []
    o = [sa(c) for c in r]
    j = next((j for j, c in enumerate(o) if c and RE_TD_TEN.search(c)), None)
    if j is None:
        return None
    if any(RE_TD_KHAC.search(c) for jj, c in enumerate(o) if c and jj != j):
        return j
    for k in range(i + 1, min(len(A), i + 4)):
        if any(RE_TD_KHAC.search(sa(c)) for c in (A[k] or []) if isinstance(c, str)):
            return j
    return None


def _tim_tieu_de(A, tu=0, den=None):
    den = len(A) if den is None else den
    for i in range(tu, min(den, len(A))):
        if _la_tieu_de(A, i) is not None:
            return i
    return -1


def _kiem_tong(vals, cands):
    """vals: {cot: gia tri dong tong (tho)}; cands: [(ten, {cot: tong tho}, so nguoi)]. Chon ung vien khop nhieu cot nhat.
    -> (ung vien, [cot lech]) - lech khi |a - b| > 1 dong (so tho, cho phep lam tron)."""
    tot, tot_lech = None, None
    for cd in cands:
        ten, cong, n = cd
        if not n:
            continue
        lech = [k for k in THU_TU_KIEM if k in vals and k in cong and dong(vals[k]) and abs(vals[k] - cong[k]) > 1.0]
        khop = [k for k in THU_TU_KIEM if k in vals and k in cong and dong(vals[k]) and abs(vals[k] - cong[k]) <= 1.0]
        diem = (len(khop) - len(lech), len(khop))
        if tot is None or diem > tot[0]:
            tot, tot_lech = (diem, cd), lech
    if tot is None:
        return None, []
    return tot[1], tot_lech


def _chon_tap(dong_so, co_dinh, tuy_chon, dich, toi_da=12):
    """Tim tap cot (co_dinh + mot phan tuy_chon; co the bo ca cot co dinh) sao cho tong = dich o nhieu dong nhat (sai so 1 dong).
    dong_so: [{cot: so tho}]; dich: khoa gia tri dich trong moi dong. Uu tien: nhieu dong khop > giu nhieu cot co dinh > it cot tuy chon.
    -> (tap, so dong khop, so dong xet)."""
    tat_ca = (list(co_dinh) + [c for c in tuy_chon if c not in co_dinh])[:toi_da]
    so_cd = min(len(co_dinh), len(tat_ca))
    xet = [r for r in dong_so if abs(r.get(dich, 0.0)) >= 1]
    if not xet or not tat_ca:
        return list(co_dinh), 0, len(xet)
    mau = xet[:80]
    n = len(tat_ca)
    khop = [0] * (1 << n)
    for r in mau:
        v = [r.get(c, 0.0) for c in tat_ca]
        dich_r = r[dich]
        s = [0.0] * (1 << n)
        for bit in range(1, 1 << n):
            thap = bit & -bit
            s[bit] = s[bit ^ thap] + v[thap.bit_length() - 1]
            if abs(s[bit] - dich_r) <= 1.0:
                khop[bit] += 1
    tot = None
    for bit in range(1, 1 << n):
        cd_co = bin(bit & ((1 << so_cd) - 1)).count("1")
        diem = (khop[bit], cd_co, -(bin(bit).count("1") - cd_co))
        if tot is None or diem > tot[0]:
            tot = (diem, bit)
    tap = [tat_ca[i] for i in range(n) if tot[1] >> i & 1]
    so_khop = sum(1 for r in xet if abs(sum(r.get(c, 0.0) for c in tap) - r[dich]) <= 1.0)
    return tap, so_khop, len(xet)


def _dem_khop(dong_so, tap, dich):
    xet = [r for r in dong_so if abs(r.get(dich, 0.0)) >= 1]
    return sum(1 for r in xet if abs(sum(r.get(c, 0.0) for c in tap) - r[dich]) <= 1.0), len(xet)


RE_KHONG_TIEN = re.compile(r"he so|\bhs\b|ty le|%|don gia|\bbac\b|so ngay|so gio|gio cong|ngay cong|ngay lam|ngay sinh|nam sinh|cmnd|cccd|"
                           r"ma so|so tai khoan|ghi chu|ky nhan|\bstt\b|so tt|so dien thoai|\bsdt\b|so luong|san luong|so san pham|\bsl\b|"
                           r"luong (1 |mot )?(ngay|gio)\b")
RE_LOI_O = re.compile(r"^#(VALUE!|N/A|REF!|DIV/0!|NAME\?|NUM!|NULL!|GETTING_DATA|SPILL!|CALC!)", re.I)
RE_TRU_THEM = re.compile(r"\btru\b|khau tru|\bphat\b|boi thuong|thu hoi|truy thu|hoan ung|hoan tra|doan phi|\bno\b.*(cu|ky truoc)")
RE_PC_THEM = re.compile(r"phu cap|tro cap|^pc\b|\bpc (an|xang|dien|trach|chuc|com|di|nha|dt|tn|cv)")
RE_GIAM_TRU = re.compile(r"gia canh|ban than|phu thuoc|\bnpt\b")


def _thong_tin(goc, moi):
    """thong tin phu cua BangExcel (o gop, dong an, sheet an, o cong thuc chua co gia tri) theo ten sheet da doi ma."""
    tt = {"gop": {}, "an_dong": {}, "an_sheet": set(), "ct_trong": {}}
    an_sheet = getattr(goc, "an_sheet", None) or set()
    for a, b in zip(list(goc.keys()), list(moi.keys())):
        for k in ("gop", "an_dong", "ct_trong"):
            d = getattr(goc, k, None) or {}
            if a in d:
                tt[k][b] = d[a]
        if a in an_sheet:
            tt["an_sheet"].add(b)
    return tt


def _gt_so(r, i):
    """gia tri so cua o (tho, chua lam tron); o chu khong phai so -> 0"""
    if i is None or i >= len(r):
        return 0.0
    v = r[i]
    if isinstance(v, bool) or v is None:
        return 0.0
    if isinstance(v, (int, float)):
        return float(v)
    return so_tien(v) if la_so(v) else 0.0


def doc_bang_luong(tab, thang=0, nam=0, canh_bao=None, ghi_log=None):
    """tab = {sheet: [[o]]} (da doc tu Excel; BangExcel co them o gop / dong an / sheet an). -> danh sach dong nhan vien (dict).
    canh_bao (list) nhan {thang, nam, ky_loai, noi_dung}. Truong 'thang' = ma ky (1..12; 0 = ca nam; tu*100+den = nhieu thang;
    -1 = chua biet). GD79: nhieu bang trong mot sheet, sheet an, dong an, cot gop BH / phu cap / khoan tru khac, cot thue TNCN."""
    cb = canh_bao if canh_bao is not None else []
    log = ghi_log or (lambda s: None)
    goc = tab
    tab, ma = chuyen_bang(tab)
    if ma in ("VNI", "TCVN3"):
        log("Bang luong: chu %s -> doi sang Unicode" % ma)
    tt = _thong_tin(goc, tab)
    ket, nguon, ghi_chung = [], [], []
    for sh, A in tab.items():
        if not A:
            continue
        if sh in tt["an_sheet"]:
            if _tim_tieu_de(A, 0, 60) >= 0:
                ghi_chung.append("[i] Sheet \"%s\" đang ẩn trong tệp - không nhập (muốn nhập thì bỏ ẩn sheet rồi Import lại)." % sh)
            log("Bang luong: bo qua sheet an %s" % bo_dau(sh))
            continue
        hr = _tim_tieu_de(A, 0, 60)
        tu_ky, ky_truoc, lan = 0, None, 0
        while hr >= 0 and lan < 20:
            lan += 1
            kq = _doc_bang(A, hr, sh, tu_ky, ky_truoc, thang, nam, tt, cb, log)
            if kq["nguoi"]:
                nguon.append({"sheet": sh, "dong": hr + 1, "nguoi": kq["nguoi"]})
            ket.extend(kq["nguoi"])
            if kq["ky"]:
                ky_truoc = kq["ky"]
            tu_ky = kq["het"]
            hr = kq["tiep"]
    ket = _bo_trung_nguon(ket, nguon, cb)
    if ghi_chung and not ket:
        for x in ghi_chung:                   # khong co dong nao (vd moi sheet bang luong dang an) - de tool bao ly do
            cb.append({"thang": -1, "nam": 0, "ky_loai": "", "noi_dung": x})
    if ghi_chung:
        da = set()
        for d in ket:
            k = (d["thang"], d["nam"], d.get("ky_loai", ""))
            if k in da:
                continue
            da.add(k)
            for x in ghi_chung:
                cb.append({"thang": k[0], "nam": k[1], "ky_loai": k[2], "noi_dung": x})
    return ket


def _bo_trung_nguon(ket, nguon, cb):
    """GD79: hai bang / hai sheet CUNG KY lap lai cung nguoi cung so tien (sheet chep "T9 (2)", danh sach chuyen khoan ben duoi
    bang luong) -> chi nhap bang dau, bang sau bo va bao."""
    if len(nguon) < 2:
        return ket
    bo = set()
    for j in range(1, len(nguon)):
        nj = nguon[j]["nguoi"]
        kj = (nj[0]["thang"], nj[0]["nam"])
        truoc = set()
        for q in range(j):
            if id(nguon[q]) in bo:
                continue
            for d in nguon[q]["nguoi"]:
                if (d["thang"], d["nam"]) == kj:
                    truoc.add((khoa_ten(d["ten"]), d.get("thuc_linh") or d.get("tong_thu_nhap")))
        if not truoc:
            continue
        lap = sum(1 for d in nj if (khoa_ten(d["ten"]), d.get("thuc_linh") or d.get("tong_thu_nhap")) in truoc)
        if lap and lap * 5 >= len(nj) * 4:
            bo.add(id(nguon[j]))
            cb.append({"thang": kj[0], "nam": kj[1], "ky_loai": nj[0].get("ky_loai", ""),
                       "noi_dung": "[!] Sheet %s, bảng từ dòng %d: %d/%d người trùng tên và số tiền với bảng / sheet khác cùng kỳ "
                                   "(sheet chép lại hoặc danh sách chuyển khoản) - KHÔNG nhập lần hai." % (nguon[j]["sheet"], nguon[j]["dong"], lap, len(nj))})
    if not bo:
        return ket
    bo_d = set(id(d) for x in nguon if id(x) in bo for d in x["nguoi"])
    return [d for d in ket if id(d) not in bo_d]


def _doc_bang(A, hr, sh, tu_ky, ky_truoc, thang, nam, tt, cb, log):
    """Doc MOT bang (tieu de o dong hr) den het sheet hoac den dong tieu de cua bang khac (bo cot khac).
    -> {nguoi, ky, het (dong ket thuc), tiep (dong tieu de bang sau | -1)}"""
    kq = {"nguoi": [], "ky": None, "het": hr + 1, "tiep": -1}
    ti0 = _la_tieu_de(A, hr)
    ti0 = 0 if ti0 is None else ti0
    gop = tt["gop"].get(sh)
    H, hr_cuoi = gop_tieu_de(A, hr, ti0, gop)
    cot = tim_cot(H)
    kq["het"] = hr_cuoi + 1
    if "ten" not in cot:
        kq["tiep"] = _tim_tieu_de(A, hr_cuoi + 1)
        return kq
    # ---- ky: ten sheet > tieu de > tham so (thang nguoi dung go). Nam: tieu de > ten sheet > tham so.
    cac_o = _o_chu(A, tu_ky, hr)
    ky_td = ky_tu_o(cac_o) if cac_o else {}
    if not ky_td.get("loai") and ky_truoc and ky_truoc.get("loai"):
        ky_td = dict(ky_truoc)                    # bang thu hai cung sheet: theo ky bang tren
    th_sh = thang_ten_sheet(sh)
    ky_sh = ky_tu_chu(sh) if not th_sh else {"tu": th_sh, "den": th_sh, "nam": 0, "loai": "THANG"}
    m_nam = re.search(r"(?<!\d)(20\d\d)(?!\d)", bo_dau(sh))
    nm = ky_td.get("nam") or ky_sh.get("nam") or (int(m_nam.group(1)) if m_nam else 0) or nam or 0
    if not th_sh and ky_sh.get("loai") and not ky_td.get("loai"):
        ky_td = ky_sh                     # ten sheet kieu "Ca nam 2025", "Quy 3"
    if th_sh and ky_td.get("loai") in ("NAM", "NHIEU"):
        ky, nguon = ky_td, "tiêu đề"              # GD79: tieu de ghi ro ca nam / nhieu thang -> khong theo so trong ten sheet
    elif th_sh:
        ky, nguon = {"tu": th_sh, "den": th_sh, "loai": "THANG"}, "tên sheet"
    elif ky_td.get("loai"):
        ky, nguon = ky_td, "tiêu đề"
    elif thang and 1 <= int(thang) <= 12:
        ky, nguon = {"tu": int(thang), "den": int(thang), "loai": "THANG"}, "tháng nhập khi Import"
    else:
        ky, nguon = {}, ""
    ci = cot.get("ngay_cong")
    if not ky and ci is not None and ky_td.get("nam"):
        nc = [so_tien(r[ci]) for r in A[hr_cuoi + 1:] if r and ci < len(r) and isinstance(r[ci], (int, float))]
        if nc and sum(1 for x in nc if x > 31) * 2 > len(nc):
            ky, nguon = {"tu": 1, "den": 12, "loai": "NAM"}, "ngày công > 31 (bảng tổng hợp năm)"
    th = ma_ky(ky)
    ky_loai = ky.get("loai") if ky.get("loai") in ("NAM", "NHIEU") else ""
    kq["ky"] = dict(ky, nam=nm) if ky else None

    def cb_them(nd, th=th, nm=nm, ky_loai=ky_loai):
        cb.append({"thang": th, "nam": nm, "ky_loai": ky_loai, "noi_dung": nd})
    if thang and ky and nguon in ("tiêu đề", "tên sheet") and th != int(thang):
        cb_them("[i] Sheet %s: kỳ lấy theo %s là %s (tháng gõ khi Import: %s)." % (sh, nguon, ten_ky(th, nm), thang))
    if th_sh and ky_td.get("loai") in ("NAM", "NHIEU"):
        cb_them("[i] Sheet %s: tên sheet có số %d nhưng tiêu đề ghi %s - lấy kỳ theo tiêu đề." % (sh, th_sh, ten_ky(th, nm)))
    if th_sh and ky_td.get("loai") == "THANG" and ma_ky(ky_td) != th_sh:
        cb_them("[!] Sheet %s: tên sheet là tháng %d nhưng tiêu đề bảng ghi %s - đã lấy theo tên sheet, kiểm tra lại (sửa tên sheet "
                "hoặc tiêu đề cho đúng rồi Import lại)." % (sh, th_sh, ten_ky(ma_ky(ky_td), ky_td.get("nam") or nm)))
    if tt["ct_trong"].get(sh):
        cb_them("[!] Sheet %s: %d ô công thức chưa có giá trị lưu (tệp lập bằng phần mềm khác, chưa mở bằng Excel) - các ô đó đọc là 0. "
                "Mở tệp bằng Excel, bấm Lưu rồi Import lại." % (sh, tt["ct_trong"][sh]))
    log("Bang luong sheet %s: tieu de dong %d-%d, ky %s (%s), cot %s" % (bo_dau(sh), hr + 1, hr_cuoi + 1, th, bo_dau(nguon), json.dumps(cot)))
    ti, si = cot["ten"], cot.get("stt")
    an_dong = tt["an_dong"].get(sh) or set()

    # ---- vung du lieu: den dong tieu de cua bang KHAC (bo cot khac); tieu de lap lai (in trang moi) cung bo cot thi bo qua
    bo_dong = set()
    het = len(A)
    k = hr_cuoi + 1
    while k < len(A):
        if _la_tieu_de(A, k) is not None:
            tj = _la_tieu_de(A, k)
            H2, c2 = gop_tieu_de(A, k, tj, gop)
            if tim_cot(H2) == cot:
                bo_dong.update(range(k, c2 + 1))
                k = c2 + 1
                continue
            het = k
            kq["tiep"] = k
            break
        k += 1
    kq["het"] = het
    if "tong_thu_nhap" not in cot and "thuc_linh" not in cot:
        # khong co cot tong thu nhap lan thuc linh: danh sach nhan vien / bang cham cong / bang ke... - khong phai bang luong
        log("Bang luong sheet %s: bang dong %d khong co cot tong thu nhap / thuc linh - bo qua" % (bo_dau(sh), hr + 1))
        return kq
    dong_du = [(k, A[k] or []) for k in range(hr_cuoi + 1, het) if k not in bo_dong]

    # ---- cot chu lech mot o so voi tieu de (bangluong1.xls: "Chuc vu" o cot D, du lieu o cot C)
    co_ten = [r for _, r in dong_du if ti < len(r) and isinstance(r[ti], str) and r[ti].strip()]
    nguoi_mau = [r for r in co_ten if co_tien(r) and (si is None or (si < len(r) and la_stt(r[si])))]
    for key in ("chuc_vu", "bo_phan"):
        i = cot.get(key)
        if i is None or len(nguoi_mau) < 2:
            continue
        if sum(1 for r in nguoi_mau if i < len(r) and isinstance(r[i], str) and r[i].strip()) * 5 >= len(nguoi_mau):
            continue
        for j in (i - 1, i + 1):
            if j < 0 or j == ti or j in cot.values() or (j < len(H) and H[j]):
                continue
            if sum(1 for r in nguoi_mau if j < len(r) and isinstance(r[j], str) and r[j].strip() and not re.match(r"^[\d.,\s]+$", r[j])) * 2 >= len(nguoi_mau):
                log("Bang luong sheet %s: cot %s lay du lieu o cot %d (tieu de o cot %d)" % (bo_dau(sh), key, j + 1, i + 1))
                cot[key] = j
                break
    # GD79: ty le STT tinh tren dong CO SO TIEN (bo dong cong / tong / chan trang) - bang nhieu nhom + dong cong nhom truoc day
    #   bi coi la "khong danh STT" -> dong nhom "I / Bo phan van phong" thanh nguoi (0 dong) va mat bo phan cua moi nguoi
    goc_stt = [r for r in co_ten if co_tien(r) and not RE_TONG.search(chuan(r[ti])) and not RE_CHAN.search(sa(r[ti]))]
    so_stt = sum(1 for r in goc_stt if si is not None and si < len(r) and la_stt(r[si]))
    dung_stt = si is not None and so_stt >= 1 and so_stt >= 0.5 * len(goc_stt)

    # ---- phan loai dong: nguoi / nhom / tong / bo
    ban = []            # [(loai, k, r, ten)]
    for k, r in dong_du:
        ten = r[ti] if ti < len(r) else None
        v_stt = r[si] if si is not None and si < len(r) else None
        if ten is None or not str(ten).strip() or isinstance(ten, (int, float)):
            nhan, _ = _chu_trai(r, ti)
            if not nhan or la_stt(v_stt):
                if la_stt(v_stt) and co_tien(r) and not nhan:
                    ban.append(("khong_ten", k, r, ""))
                continue
            if RE_CHAN.search(sa(nhan)):
                continue
            if RE_TONG.search(chuan(nhan)) and co_tien(r):
                ban.append(("tong", k, r, nhan))
            elif co_tien(r) or RE_NHOM.search(sa(nhan)):
                ban.append(("nhom", k, r, nhan))
            continue
        ten_s = str(ten).strip()
        if RE_CHAN.search(sa(ten_s)) and not la_stt(v_stt):
            continue
        tu_chuan = chuan(ten_s)
        la_tong = not la_stt(v_stt) and (bool(RE_TONG.search(tu_chuan)) or bool(RE_TONG.search(chuan(str(r[0] if r else "") or ""))))
        if not la_tong and dung_stt and not la_stt(v_stt) and co_tien(r) and re.match(r"^(CONG|TONG)\b", tu_chuan):
            la_tong = True          # bang danh STT: dong "Cong ..." / "Tong ..." khong STT la dong cong (nguoi ho Cong luon co STT)
        if la_tong:
            ban.append(("tong", k, r, ten_s))
            continue
        if dung_stt:
            if la_stt(v_stt):
                loai = "nguoi"
            elif (v_stt is not None and RE_LA_MA.match(str(v_stt).strip())) or RE_NHOM.search(sa(ten_s)) or not co_tien(r):
                loai = "nhom"
            else:
                loai = "mo_ho"          # co ten + so tien, khong STT, khong giong ten nhom -> xet sau
        else:
            loai = "nhom" if (v_stt is None or not str(v_stt).strip()) and RE_NHOM.search(sa(ten_s)) else "nguoi"
        ban.append((loai, k, r, ten_s))

    # ---- cot tien chua nhan dang + phan loai theo vung / ten cot, roi kiem bang cong thuc (chon tap cot khop nhieu dong nhat)
    dong_nguoi = [r for (lo, _, r, _) in ban if lo in ("nguoi", "mo_ho")]
    dung_cot = set(cot.values())
    vi_tn = cot.get("tong_thu_nhap")
    cac_tru = [cot[k2] for k2 in ("bhxh_nv", "bhyt_nv", "bhtn_nv", "thue_tncn", "tam_ung", "tru_khac", "bh_gop_nv", "doan_phi", "tong_tru") if k2 in cot]
    vi_tl = cot.get("thuc_linh")
    bien_tn = vi_tn if vi_tn is not None else (min(cac_tru) if cac_tru else (vi_tl if vi_tl is not None else 10 ** 6))
    them_pc, them_tn, them_tru, gt_them, npt_them = [], [], [], [], []
    bo_qua = []
    for i in range(len(H)):
        if i in dung_cot or i <= ti or not H[i]:
            continue
        vals = [_gt_so(r, i) for r in dong_nguoi if i < len(r) and la_so(r[i])]
        if not vals or not any(abs(v) >= 1000 for v in vals):
            if vals and RE_GIAM_TRU.search(H[i]) and re.search(r"phu thuoc|npt", H[i]) and "so_npt" not in cot and max(abs(v) for v in vals) < 100:
                npt_them.append(i)
            continue
        if RE_GIAM_TRU.search(H[i]):
            if max(abs(v) for v in vals) < 100:
                if "so_npt" not in cot:
                    npt_them.append(i)
            elif "giam_tru_gc" not in cot:
                gt_them.append(i)
            continue
        if RE_KHONG_TIEN.search(H[i]):
            continue
        if re.search(r"thue|\bbh|bao hiem|bhxh|bhyt|bhtn", H[i]):
            bo_qua.append(i)
            continue
        if i < bien_tn:
            (them_pc if RE_PC_THEM.search(H[i]) else them_tn).append(i)
        elif vi_tl is not None and i < vi_tl and (RE_TRU_THEM.search(H[i]) or vi_tn is not None):
            them_tru.append(i)
        elif vi_tl is None and RE_TRU_THEM.search(H[i]):
            them_tru.append(i)
        else:
            bo_qua.append(i)

    def gia_tri_tho(r):
        """moi cot so (tho) cua mot dong theo cot da nhan + cot them (chi so cot -> gia tri)"""
        g = {}
        for key, i in cot.items():
            if key not in COT_CHU:
                g[key] = _gt_so(r, i)
        for i in them_pc + them_tn + them_tru + gt_them + npt_them:
            g[i] = _gt_so(r, i)
        return g
    ds_g = [gia_tri_tho(r) for r in dong_nguoi]

    # thu nhap: tong thu nhap = luong chinh (hoac luong co ban khi khong co luong chinh) + phu cap + thu nhap khac + cot them
    goc_tn = "luong_chinh" if "luong_chinh" in cot else ("luong_cb" if "luong_cb" in cot else None)
    cd_tn = [c for c in (goc_tn, "phu_cap", "thu_nhap_khac") if c and c in cot]
    tc_tn = them_pc + them_tn + (["luong_cb"] if goc_tn == "luong_chinh" and "luong_cb" in cot else [])
    tap_tn = cd_tn + them_pc + them_tn
    if vi_tn is not None and ds_g:
        for g in ds_g:
            g["_tn"] = g.get("tong_thu_nhap", 0.0)
        tot, n_tot, n_xet = _chon_tap(ds_g, cd_tn, tc_tn, "_tn")
        n_mac, _ = _dem_khop(ds_g, tap_tn, "_tn")
        if n_tot > n_mac and n_tot * 5 >= n_xet * 3:
            log("Bang luong sheet %s: tap cot thu nhap %s khop %d/%d dong (mac dinh %d)" % (bo_dau(sh), tot, n_tot, n_xet, n_mac))
            tap_tn = tot
    # khoan tru: thuc linh = tong thu nhap - (BH NLD + thue TNCN + tam ung + tru khac + cot tru them)
    cd_tru = [c for c in ("bhxh_nv", "bhyt_nv", "bhtn_nv", "thue_tncn", "tam_ung", "tru_khac", "doan_phi") if c in cot]
    co_bh_rieng = any(c in cot for c in ("bhxh_nv", "bhyt_nv", "bhtn_nv"))
    if "bh_gop_nv" in cot and not co_bh_rieng:
        cd_tru.append("bh_gop_nv")
    tc_tru = list(them_tru) + [c for c in ("kpcd",) if c in cot] + (["bh_gop_nv"] if "bh_gop_nv" in cot and co_bh_rieng else [])
    tap_tru = list(cd_tru)
    co_tn = vi_tn is not None or (bool(tap_tn) and vi_tl is not None)
    if vi_tl is not None and ds_g and co_tn:
        for g in ds_g:
            tn_g = g.get("tong_thu_nhap", 0.0) if vi_tn is not None else sum(g.get(c, 0.0) for c in tap_tn)
            g["_tru"] = tn_g - g.get("thuc_linh", 0.0)
        tot, n_tot, n_xet = _chon_tap(ds_g, cd_tru, tc_tru, "_tru")
        n_mac, _ = _dem_khop(ds_g, tap_tru, "_tru")
        if n_tot > n_mac and n_tot * 5 >= n_xet * 3:
            log("Bang luong sheet %s: tap cot khau tru %s khop %d/%d dong (mac dinh %d)" % (bo_dau(sh), tot, n_tot, n_xet, n_mac))
            tap_tru = tot
    # ---- thong bao cach quy doi cot (chi khi co cot them)
    pc_dung = [i for i in them_pc if i in tap_tn]
    tn_dung = [i for i in them_tn if i in tap_tn]
    tru_dung = [i for i in them_tru if i in tap_tru]

    def ten_o(ds_i):
        return ", ".join('"%s"' % str(_o_goc(A, hr, hr_cuoi, i) or H[i]).strip() for i in ds_i)
    for ds_i, ten_k in ((pc_dung, "Phụ cấp"), (tn_dung, "Thu nhập khác")):
        if ds_i:
            cb_them("[i] Sheet %s: cột %s cộng vào %s (phần mềm không có cột riêng)." % (sh, ten_o(ds_i), ten_k))
    tc_bo = [i for i in them_pc + them_tn if i not in tap_tn]
    if tc_bo and vi_tn is not None:
        cb_them("[i] Sheet %s: cột %s không cộng vào tổng thu nhập trên bảng (cột tham khảo) - không cộng vào thu nhập khác." % (sh, ten_o(tc_bo)))
    if tru_dung:
        cb_them("[i] Sheet %s: cột %s là khoản trừ vào lương - cộng vào Trừ khác." % (sh, ten_o(tru_dung)))
    if "kpcd" in tap_tru:
        cb_them("[i] Sheet %s: cột %s trừ vào lương người lao động (đoàn phí) - cộng vào Trừ khác, không ghi KPCĐ doanh nghiệp." % (sh, ten_o([cot["kpcd"]])))
    if "doan_phi" in cot:
        cb_them("[i] Sheet %s: cột %s (đoàn phí công đoàn) cộng vào Trừ khác." % (sh, ten_o([cot["doan_phi"]])))
    if "bh_gop_nv" in cd_tru:
        cb_them("[i] Sheet %s: cột %s là BHXH + BHYT + BHTN người lao động gộp một cột - ghi vào cột BHXH." % (sh, ten_o([cot["bh_gop_nv"]])))
    if "bh_gop_dn" in cot and not any(c in cot for c in ("bhxh_dn", "bhyt_dn", "bhtn_dn")):
        cb_them("[i] Sheet %s: cột %s là BH doanh nghiệp gộp một cột - ghi vào cột BHXH doanh nghiệp." % (sh, ten_o([cot["bh_gop_dn"]])))
    if gt_them:
        cb_them("[i] Sheet %s: cột %s cộng thành Giảm trừ gia cảnh." % (sh, ten_o(gt_them)))
    if vi_tn is None and tap_tn and vi_tl is not None:
        cb_them("[i] Sheet %s: bảng không có cột Tổng thu nhập - tính = %s." % (sh, " + ".join(
            TEN_COT.get(c, "") if isinstance(c, str) else '"%s"' % str(_o_goc(A, hr, hr_cuoi, c) or H[c]).strip() for c in tap_tn)))
    co_cot_tru = any(c in cot for c in ("bhxh_nv", "bhyt_nv", "bhtn_nv", "thue_tncn", "tam_ung", "tru_khac", "bh_gop_nv", "doan_phi"))
    if vi_tl is None and vi_tn is not None and co_cot_tru and dong_nguoi:
        cb_them("[i] Sheet %s: bảng không có cột Thực lĩnh - tính = tổng thu nhập - các khoản trừ." % sh)

    so_cot = [k2 for k2 in cot if k2 not in COT_CHU and k2 not in COT_NOI_BO]
    for k2 in ("tong_thu_nhap", "thuc_linh", "phu_cap", "thu_nhap_khac", "tru_khac", "bhxh_nv", "bhxh_dn", "giam_tru_gc", "so_npt", "kpcd"):
        if k2 not in so_cot:
            if (k2 == "tong_thu_nhap" and tap_tn and vi_tl is not None) or (k2 == "thuc_linh" and vi_tn is not None and co_cot_tru) or (k2 == "phu_cap" and pc_dung) or \
               (k2 == "thu_nhap_khac" and tn_dung) or (k2 == "tru_khac" and (tru_dung or "doan_phi" in cot or "kpcd" in tap_tru)) or \
               (k2 == "bhxh_nv" and "bh_gop_nv" in cd_tru) or (k2 == "giam_tru_gc" and gt_them) or (k2 == "so_npt" and npt_them) or \
               (k2 == "bhxh_dn" and "bh_gop_dn" in cot and not any(c in cot for c in ("bhxh_dn", "bhyt_dn", "bhtn_dn"))):
                so_cot.append(k2)

    def gia_tri(r):
        """dong -> {cot luu: gia tri tho} theo cach quy doi da chon (dung cho ca nguoi lan dong cong / tong)"""
        g = gia_tri_tho(r)
        v = {}
        for key in so_cot:
            v[key] = g.get(key, 0.0)
        if pc_dung:
            v["phu_cap"] = v.get("phu_cap", 0.0) + sum(g[i] for i in pc_dung)
        if tn_dung:
            v["thu_nhap_khac"] = v.get("thu_nhap_khac", 0.0) + sum(g[i] for i in tn_dung)
        if "bh_gop_nv" in cd_tru:
            v["bhxh_nv"] = v.get("bhxh_nv", 0.0) + g.get("bh_gop_nv", 0.0)
        if "bh_gop_dn" in cot and not any(c in cot for c in ("bhxh_dn", "bhyt_dn", "bhtn_dn")):
            v["bhxh_dn"] = v.get("bhxh_dn", 0.0) + g.get("bh_gop_dn", 0.0)
        tru_them = sum(g[i] for i in tru_dung) + (g.get("doan_phi", 0.0) if "doan_phi" in cot else 0.0)
        if "kpcd" in tap_tru:
            tru_them += g.get("kpcd", 0.0)
            v["kpcd"] = 0.0
        if tru_them or tru_dung:
            v["tru_khac"] = v.get("tru_khac", 0.0) + tru_them
        if gt_them:
            v["giam_tru_gc"] = v.get("giam_tru_gc", 0.0) + sum(g[i] for i in gt_them)
        if npt_them:
            v["so_npt"] = v.get("so_npt", 0.0) + sum(g[i] for i in npt_them)
        if vi_tn is None and tap_tn and vi_tl is not None:
            v["tong_thu_nhap"] = sum(g.get(c, 0.0) for c in tap_tn)
        if vi_tl is None and vi_tn is not None and co_cot_tru:
            v["thuc_linh"] = v.get("tong_thu_nhap", 0.0) - sum(v.get(c, 0.0) for c in KHAU_TRU)
        return v

    # ---- dong "mo ho" (ten + so tien, khong STT): la dong nhom co cong nhom neu so = cong cac nguoi ngay duoi, nguoc lai la nguoi
    for q, (lo, k, r, ten_s) in enumerate(ban):
        if lo != "mo_ho":
            continue
        v = gia_tri(r)
        cong, n = {}, 0
        for lo2, k2, r2, _ in ban[q + 1:]:
            if lo2 != "nguoi":
                break
            n += 1
            for key, x in gia_tri(r2).items():
                cong[key] = cong.get(key, 0.0) + x
        khop = n and any(abs(v.get(key, 0.0)) >= 1 for key in ("thuc_linh", "tong_thu_nhap")) and \
            all(abs(v.get(key, 0.0) - cong.get(key, 0.0)) <= 1.0 for key in ("thuc_linh", "tong_thu_nhap") if abs(v.get(key, 0.0)) >= 1)
        if khop:
            ban[q] = ("nhom", k, r, ten_s)
        else:
            ban[q] = ("nguoi", k, r, ten_s)
            cb_them("[?] Sheet %s, dòng %d: \"%s\" có số tiền nhưng không có số thứ tự - đã nhập như một người, kiểm tra lại." % (sh, k + 1, ten_s[:40]))

    # ---- duyet: nguoi / nhom / tong
    ket = []
    tong = {kk: 0.0 for kk in so_cot}
    tong_hien = {kk: 0.0 for kk in so_cot}
    doan = {kk: 0.0 for kk in so_cot}
    dem = {"tong": 0, "hien": 0, "doan": 0}
    nhom = {"ten": "", "so": 0, "cong": {kk: 0.0 for kk in so_cot}, "hien": {kk: 0.0 for kk in so_cot}, "so_hien": 0, "dong": None, "dong_so": 0}
    lech_tn, lech_tl, dem_tn, dem_tl = [], [], [0], [0]
    an_nhap = []
    tong_cuoi = {"da": False, "chi_hien": False}
    sau_tong = []

    def bao_lech(tien_to, vals, cong, n, lech):
        for key in lech:
            a, b = dong(vals[key]), dong(cong[key])
            cb_them("%s %s = %s nhưng cộng %d người = %s (lệch %s)." % (tien_to, TEN_COT.get(key, key), dd(a), n, dd(b), dd(a - b)))

    def dong_nhom():
        if nhom["ten"] and nhom["dong"] is not None and nhom["so"]:
            cands = [("nhom", nhom["cong"], nhom["so"])]
            if nhom["so_hien"] != nhom["so"]:
                cands.append(("nhom_hien", nhom["hien"], nhom["so_hien"]))
            cd, lech = _kiem_tong(nhom["dong"], cands)
            if cd is not None and lech:
                bao_lech("Sheet %s, dòng %d, nhóm \"%s\": dòng cộng nhóm" % (sh, nhom["dong_so"], nhom["ten"]), nhom["dong"], cd[1], cd[2], lech)

    def mo_nhom(ten, vals, dong_excel):
        dong_nhom()
        nhom["ten"] = ten[:120]
        nhom["so"] = nhom["so_hien"] = 0
        nhom["cong"] = {kk: 0.0 for kk in so_cot}
        nhom["hien"] = {kk: 0.0 for kk in so_cot}
        nhom["dong"] = vals if any(abs(x) >= 1 for x in vals.values()) else None
        nhom["dong_so"] = dong_excel

    ten_nhom = {}
    for lo, k, r, ten_s in ban:
        dong_excel = k + 1
        if lo == "khong_ten":
            cb_them("[?] Sheet %s, dòng %d: có số thứ tự và số tiền nhưng không có họ tên - không nhập." % (sh, dong_excel))
            continue
        if lo == "nhom":
            mo_nhom(ten_s, gia_tri(r), dong_excel)
            continue
        if lo == "tong":
            vals = gia_tri(r)
            cands = []
            if nhom["ten"] and nhom["so"]:
                cands.append(("nhom", nhom["cong"], nhom["so"]))
                if nhom["so_hien"] != nhom["so"]:
                    cands.append(("nhom_hien", nhom["hien"], nhom["so_hien"]))
            if dem["doan"] and dem["doan"] != dem["tong"]:
                cands.append(("doan", dict(doan), dem["doan"]))
            cands.append(("tong", dict(tong), dem["tong"]))
            if dem["hien"] != dem["tong"]:
                cands.append(("tong_hien", dict(tong_hien), dem["hien"]))
            cd, lech = _kiem_tong(vals, cands)
            if cd is not None:
                if lech:
                    bao_lech("Sheet %s, dòng %d: dòng \"%s\"" % (sh, dong_excel, ten_s[:40]), vals, cd[1], cd[2], lech)
                if cd[0] in ("nhom", "nhom_hien"):
                    nhom["dong"] = None          # da kiem bang dong cong cuoi nhom
                if cd[0] in ("tong", "tong_hien"):
                    tong_cuoi["da"] = True
                    tong_cuoi["chi_hien"] = (cd[0] == "tong_hien" and not lech)
                    sau_tong[:] = []
            doan = {kk: 0.0 for kk in so_cot}
            dem["doan"] = 0
            continue
        # ---- nguoi
        loi_o = [(i, r[i]) for i in sorted(set(i for key, i in cot.items() if key not in COT_CHU) | set(them_pc + them_tn + them_tru))
                 if i < len(r) and isinstance(r[i], str) and RE_LOI_O.match(r[i].strip())]
        if loi_o:
            cb_them("[!] Sheet %s, dòng %d %s: ô lỗi công thức %s - máy KHÔNG lập chứng từ lương kỳ này cho đến khi sửa trong tệp Excel "
                    "rồi Import lại [O_LOI]" % (
                        sh, dong_excel, ten_s[:40], ", ".join('%s ở cột "%s"' % (x.strip(), _o_goc(A, hr, hr_cuoi, i) or H[i]) for i, x in loi_o[:4])))          # GD370: chan ghi
        v = gia_tri(r)
        d = {"thang": th, "nam": nm, "ten": lam_sach_ten(ten_s)[:255], "sheet": sh, "dong_nguon": dong_excel}
        if ky.get("loai") == "NAM":
            d["ky_loai"] = "NAM"
        elif ky.get("loai") == "NHIEU":
            d["ky_loai"] = "NHIEU"
        for key, i in cot.items():
            if key in ("ten", "stt") or key in COT_NOI_BO:
                continue
            x = r[i] if i < len(r) else None
            if key in ("ma_nv", "so_tk"):
                d[key] = ("%d" % x if isinstance(x, float) and x == int(x) else str(x if x is not None else "")).strip()[:50]
            elif key in ("bo_phan", "chuc_vu"):
                d[key] = str(x if x is not None else "").strip()[:120]
        for key in so_cot:
            if key in ("ngay_cong", "so_npt"):
                d[key] = round(v.get(key, 0.0), 2)
            else:
                d[key] = dong(v.get(key, 0.0))
        if d.get("thuc_linh", 0) == 0 and d.get("tong_thu_nhap", 0) == 0:
            continue
        if not d.get("bo_phan") and nhom["ten"]:
            d["bo_phan"] = nhom["ten"]
        if nhom["ten"]:
            d["nhom"] = nhom["ten"]
        la_an = k in an_dong
        if la_an:
            d["_an"] = True
            an_nhap.append(d)
        if tong_cuoi["da"]:
            sau_tong.append(d)
        khoa = (khoa_ten(d["ten"]), nhom["ten"])
        ten_nhom.setdefault(khoa, [d["ten"], []])[1].append(dong_excel)
        # ---- kiem cong thuc tung dong (so tho, sai so 1 dong)
        g = gia_tri_tho(r)
        tn, tl = v.get("tong_thu_nhap", 0.0), v.get("thuc_linh", 0.0)
        if vi_tn is not None and tap_tn and abs(tn) >= 1 and (goc_tn == "luong_chinh" or len(tap_tn) > 1 or tap_tn != cd_tn):
            dem_tn[0] += 1
            cong_tn = sum(g.get(c, 0.0) for c in tap_tn)
            if abs(cong_tn - tn) > 1.0:
                phan = [TEN_COT[c] for c in tap_tn if isinstance(c, str)]
                if [c for c in tap_tn if not isinstance(c, str)]:
                    phan.append("cột thêm")
                lech_tn.append("dòng %d %s: tổng thu nhập %s, %s = %s (lệch %s)" % (
                    dong_excel, ten_s[:40], dd(tn), " + ".join(phan), dd(cong_tn), dd(tn - cong_tn)))
        if vi_tl is not None and co_tn and abs(tn) >= 1 and abs(tl) >= 1:
            dem_tl[0] += 1
            tru = sum(g.get(c, 0.0) for c in tap_tru)
            if abs(tn - tru - tl) > 1.0:
                lech_tl.append("dòng %d %s: thực lĩnh %s, tổng thu nhập %s - các khoản trừ %s = %s (lệch %s)" % (
                    dong_excel, ten_s[:40], dd(tl), dd(tn), dd(tru), dd(tn - tru), dd(tl - (tn - tru))))
        ket.append(d)
        dem["tong"] += 1
        dem["doan"] += 1
        nhom["so"] += 1
        if not la_an:
            dem["hien"] += 1
            nhom["so_hien"] += 1
        for key in so_cot:
            x = v.get(key, 0.0)
            tong[key] += x
            doan[key] += x
            nhom["cong"][key] += x
            if not la_an:
                tong_hien[key] += x
                nhom["hien"][key] += x
    dong_nhom()
    for ds, dm, cthuc in ((lech_tn, dem_tn[0], "tổng thu nhập = lương chính + phụ cấp + thu nhập khác"),
                          (lech_tl, dem_tl[0], "thực lĩnh = tổng thu nhập - (BHXH + BHYT + BHTN + thuế TNCN + tạm ứng + trừ khác)")):
        if not ds:
            continue
        if len(ds) * 2 > dm and dm >= 4:
            cb_them("Sheet %s: %d/%d dòng không theo công thức %s - bảng có cách tính riêng, kiểm tra lại các cột (vd %s)."
                    % (sh, len(ds), dm, cthuc, ds[0]))
        else:
            for x in ds[:15]:
                cb_them("Sheet %s, %s." % (sh, x))
            if len(ds) > 15:
                cb_them("Sheet %s: còn %d dòng lệch công thức %s." % (sh, len(ds) - 15, cthuc))
    # ---- dong an: dong Tong cong chi khop khi bo dong an -> khong nhap dong an; nguoc lai van nhap (co trong tong)
    if an_nhap:
        ten_an = ", ".join("%s (dòng %d)" % (d["ten"], d["dong_nguon"]) for d in an_nhap[:10])
        if tong_cuoi["chi_hien"]:
            bo = set(id(d) for d in an_nhap)
            ket = [d for d in ket if id(d) not in bo]
            cb_them("[i] Sheet %s: %d dòng ẩn (%s) không nằm trong dòng Tổng cộng - không nhập." % (sh, len(an_nhap), ten_an))
        else:
            cb_them("[i] Sheet %s: %d dòng ẩn (%s) vẫn nhập%s." % (sh, len(an_nhap), ten_an,
                                                                  " (có trong dòng Tổng cộng)" if tong_cuoi["da"] else " - bảng không có dòng Tổng cộng để đối chiếu, kiểm tra lại"))
    for d in ket:
        d.pop("_an", None)
    if sau_tong:
        cb_them("[?] Sheet %s: %d dòng có tên và số tiền nằm SAU dòng Tổng cộng (%s) - đã nhập, kiểm tra lại." % (
            sh, len(sau_tong), ", ".join("dòng %d %s" % (d["dong_nguon"], d["ten"]) for d in sau_tong[:5])))
    for (kt, tn_), (ten_hien, ds_d) in ten_nhom.items():
        if len(ds_d) > 1:
            cb_them("[?] Sheet %s: tên \"%s\" có %d dòng%s (dòng %s) - kiểm tra là hai người trùng tên hay nhập trùng."
                    % (sh, ten_hien, len(ds_d), (" trong nhóm \"%s\"" % tn_) if tn_ else "", ", ".join(str(x) for x in ds_d)))
    kq["nguoi"] = ket
    return kq


def _o_goc(A, hr, hr_cuoi, i):
    """chu goc (co dau) cua tieu de cot i: o cuoi cung co chu trong cac dong tieu de"""
    for k in range(hr_cuoi, hr - 1, -1):
        r = A[k] or []
        if i < len(r) and isinstance(r[i], str) and r[i].strip() and not re.match(r"^\(?(\d{1,2}|[A-Za-z])\)?$", r[i].strip()):
            return re.sub(r"\s+", " ", r[i]).strip()
    return ""


def tong_hop(dong_nv):
    """Tong moi cot so theo ky (de bao cao / kiem)."""
    kq = {}
    for d in dong_nv:
        k = (d["thang"], d["nam"])
        t = kq.setdefault(k, {"so_dong": 0})
        t["so_dong"] += 1
        for key in TEN_COT:
            if key in d:
                t[key] = t.get(key, 0) + (d[key] or 0)
    return kq


# ============================================================================ DANH SACH THAM GIA BHXH
BH_COT = [("stt", [r"^(stt|so tt|tt)$"]),
          ("ten", [r"ho (va )?ten|ho ten"]),
          ("cccd", [r"cccd|cmnd|can cuoc|dinh danh|so cmt|chung minh"]),
          ("so_so_cu", [r"so so cu"]),
          ("so_bhxh", [r"ma so bhxh|so so bhxh|ma bhxh|^so bhxh$|^ma so$"]),
          ("the_bhyt", [r"so the bhyt|the bhyt|ma the|so the"]),
          ("ngay_sinh", [r"ngay sinh|ngay thang nam sinh|nam sinh"]),
          ("gioi_tinh", [r"gioi tinh|nam ?/ ?nu|^nu$|^phai$"]),
          ("noi_kcb", [r"noi (dang ky )?kcb|kham chua benh|noi dk kcb|benh vien"]),
          ("luong_bhxh", [r"tien luong dong bhxh|muc luong dong bhxh|luong dong bhxh"]),
          ("luong_cc", [r"tien luong tien cong|muc luong|tien luong$"]),
          ("chuc_danh", [r"chuc danh", r"^(?!.*(phu cap|tro cap|luong)).*(chuc vu|nghe nghiep|cong viec|vi tri)"])]


def ngay_iso(v):
    """-> 'yyyy-mm-dd' | 'yyyy' (chi nam) | ''."""
    if v is None or v == "":
        return ""
    if isinstance(v, (datetime, date)):
        return v.strftime("%Y-%m-%d")
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        if 1900 <= v <= 2100 and float(v).is_integer():
            return "%04d" % int(v)
        if 1 < v < 80000:
            return (date(1899, 12, 30) + timedelta(days=int(v))).strftime("%Y-%m-%d")
        return ""
    t = str(v).strip()
    m = re.match(r"^(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{4})", t)
    if m:
        try:
            return date(int(m.group(3)), int(m.group(2)), int(m.group(1))).strftime("%Y-%m-%d")
        except ValueError:
            return ""
    m = re.match(r"^(\d{4})-(\d{1,2})-(\d{1,2})", t)
    if m:
        try:
            return date(int(m.group(1)), int(m.group(2)), int(m.group(3))).strftime("%Y-%m-%d")
        except ValueError:
            return ""
    m = re.match(r"^(\d{1,2})[/.\-](\d{4})$", t)
    if m:
        return "%s-%02d" % (m.group(2), int(m.group(1)))
    m = re.match(r"^(\d{4})$", t)
    if m:
        return m.group(1)
    return ""


def ngay_hien(s):
    if not s:
        return ""
    p = s.split("-")
    return "/".join(reversed(p))


def so_giay_to(v, dai=0):
    """CCCD / ma so BHXH doc tu Excel: so (mat so 0 dau) -> chuoi; giu chu so / chu cai."""
    if v is None or v == "":
        return ""
    if isinstance(v, float) and v.is_integer():
        s = "%d" % v
        if dai and len(s) < dai:
            s = s.zfill(dai)
        return s
    if isinstance(v, int) and not isinstance(v, bool):
        s = str(v)
        return s.zfill(dai) if dai and len(s) < dai else s
    return re.sub(r"[\s.'\-]", "", str(v)).strip()


def che(s):
    s = str(s or "")
    return ("*" * max(0, len(s) - 4)) + s[-4:] if s else ""


def gioi_tinh(v):
    t = sa(v)
    if t in ("nu", "n", "x", "female", "f", "0"):
        return "Nữ"
    if t in ("nam", "male", "m", "1"):
        return "Nam"
    return ""


def doc_ds_bhxh(tab, ghi_log=None):
    """{sheet: [[o]]} -> (info {ky, don_vi, tep...}, [nguoi]) - danh sach tham gia BHXH bat buoc."""
    log = ghi_log or (lambda s: None)
    tab, ma = chuyen_bang(tab)
    ds, info = [], {"ma": ma, "ky": "", "don_vi": ""}
    for sh, A in tab.items():
        if not A:
            continue
        hr = -1
        for i, r in enumerate(A[:60]):
            o = [sa(c) for c in (r or [])]
            if any(re.search(r"ho (va )?ten|ho ten", c) for c in o) and any(re.search(r"cccd|cmnd|can cuoc|dinh danh|bhxh|bhyt|ngay sinh", c) for c in o):
                hr = i
                break
        if hr < 0:
            continue
        H0 = [sa(c) for c in A[hr]]
        ti0 = next((i for i, c in enumerate(H0) if re.search(r"ho (va )?ten|ho ten", c)), 1)
        H, hr_cuoi = gop_tieu_de(A, hr, ti0)
        cot = tim_cot(H, BH_COT)
        if "ten" not in cot:
            continue
        chu_tren = " ".join(str(c) for r in A[:hr] for c in (r or []) if isinstance(c, str) and c.strip())
        ky = ky_tu_chu(chu_tren)
        if ky.get("loai"):
            info["ky"] = ten_ky(ma_ky(ky), ky.get("nam") or "")
        for r in A[:hr]:
            for c in (r or []):
                if isinstance(c, str) and re.match(r"^\s*ten (don vi|cong ty|doanh nghiep)\s*:", sa(c)) and ":" in c:
                    info["don_vi"] = c.split(":", 1)[1].strip()[:200]
        log("DS BHXH sheet %s: tieu de dong %d-%d, cot %s" % (sh, hr + 1, hr_cuoi + 1, json.dumps(cot)))
        ti, si = cot["ten"], cot.get("stt")
        for k, r in enumerate(A[hr_cuoi + 1:]):
            r = r or []
            ten = r[ti] if ti < len(r) else None
            if not isinstance(ten, str) or not ten.strip():
                continue
            if si is not None and not la_stt(r[si] if si < len(r) else None):
                continue                      # dong Cong / Tong hop / nhom
            if RE_TONG.search(chuan(ten)):
                continue

            def g(key):
                i = cot.get(key)
                return r[i] if i is not None and i < len(r) else None
            p = {"ten": ten.strip(), "dong": hr_cuoi + 2 + k, "sheet": sh,
                 "cccd": so_giay_to(g("cccd"), 12 if isinstance(g("cccd"), float) and len("%d" % g("cccd")) == 11 else 0),
                 "so_bhxh": so_giay_to(g("so_bhxh"), 10), "the_bhyt": so_giay_to(g("the_bhyt")),
                 "ngay_sinh": ngay_iso(g("ngay_sinh")), "gioi_tinh": gioi_tinh(g("gioi_tinh")),
                 "noi_kcb": str(g("noi_kcb") or "").strip()[:60], "chuc_danh": str(g("chuc_danh") or "").strip()[:120],
                 "luong_bh": dong(so_tien(g("luong_bhxh")) or so_tien(g("luong_cc")))}
            if isinstance(g("cccd"), float) and len("%d" % g("cccd")) == 8:
                p["cccd"] = "%09d" % g("cccd")         # CMND 9 so mat so 0 dau
            if p["the_bhyt"] and len(p["the_bhyt"]) < 10:
                p["the_bhyt"] = ""
            ds.append(p)
    return info, ds


# ---- o trong trong ho so nhan vien (phan mem dat "..." cho o chua nhap; CMND mac dinh "0")
def o_trong(v):
    if v is None:
        return True
    t = str(v).strip()
    return t in ("", "...", "..", ".", "0", "-", "*")


def ngay_trong(v):
    t = str(v or "").strip()
    return not t or t[:4] in ("1899", "1900") or t == "0"


def _cung_ngay(a, b):
    """so sanh ngay sinh: 'yyyy' so voi 'yyyy-mm-dd' chi so nam"""
    if not a or not b:
        return True
    if len(a) == 4 or len(b) == 4:
        return a[:4] == b[:4]
    return a[:10] == b[:10]


def ghep_ho_so(ds_bh, ds_nv, ds_cv=None):
    """ds_bh: nguoi trong DS BHXH (doc_ds_bhxh). ds_nv: nhan vien tu VB6
      [{ma, sh, ten (Unicode), ns ('yyyy-mm-dd'/''), phai, cccd ('' | '*<4 so cuoi>' | so day du), bhxh, bhyt, mcv, cv, nghi}]
    ds_cv: [{ma, ten}] danh muc chuc vu (de dien MaChucvu khi dang = 0).
    -> dict(dien=[{ma, sh, ten, cot, gt, hien}], khac=[...], khong=[...], ghep=[(bh, nv)], ngoai=[nv khong co trong DS BHXH])."""
    ds_cv = ds_cv or []
    theo_ten = {}
    for nv in ds_nv:
        theo_ten.setdefault(khoa_ten(nv.get("ten")), []).append(nv)
    bh_theo_ten = {}
    for p in ds_bh:
        bh_theo_ten.setdefault(khoa_ten(p["ten"]), []).append(p)
    # ngay sinh cua nhieu nhan vien giong nhau -> ngay nhap mac dinh / chep nham, KHONG dung de ket luan
    dem_ns = {}
    for nv in ds_nv:
        n = str(nv.get("ns") or "")[:10]
        if not ngay_trong(n):
            dem_ns[n] = dem_ns.get(n, 0) + 1
    kq = {"dien": [], "khac": [], "khong": [], "ghep": [], "ngoai": []}
    da_ghep = set()
    cv_theo_ten = {}
    for c in ds_cv:
        cv_theo_ten.setdefault(khoa_ten(c.get("ten")), []).append(c)
    for p in ds_bh:
        k = khoa_ten(p["ten"])
        ung = [nv for nv in theo_ten.get(k, [])]
        if not ung:
            gan = [nv for kk, ds in theo_ten.items() for nv in ds if kk and _gan_giong(kk, k)]
            if gan:
                kq["khong"].append({"bh": p, "ly_do": "tên gần giống %s - không tự ghép, kiểm tra lại tên" %
                                    ", ".join("%s %s" % (nv.get("sh"), nv.get("ten")) for nv in gan[:3])})
            else:
                kq["khong"].append({"bh": p, "ly_do": "chưa có trong danh mục nhân viên"})
            continue
        nhieu_bh = len(bh_theo_ten.get(k, [])) > 1
        if len(ung) > 1 or nhieu_bh:
            # trung ten: chi ghep khi ngay sinh day du khop DUY NHAT (ca trong danh muc lan trong DS BHXH);
            #   ngay sinh cua ho so trung voi nhan vien khac (ngay nhap mac dinh) khong dung de ket luan
            ns_bh = p["ngay_sinh"] if len(p["ngay_sinh"]) == 10 else ""
            cung = [nv for nv in ung if ns_bh and str(nv.get("ns") or "")[:10] == ns_bh and dem_ns.get(ns_bh, 0) == 1]
            cung_bh = [q for q in bh_theo_ten.get(k, []) if ns_bh and q["ngay_sinh"] == ns_bh]
            if len(cung) == 1 and len(cung_bh) == 1 and cung[0]["ma"] not in da_ghep:
                nv = cung[0]
            else:
                kq["khong"].append({"bh": p, "ly_do": "trùng tên %d người trong danh mục%s - không tự ghép, bổ sung tay" %
                                    (len(ung), " và %d người trong danh sách BHXH" % len(bh_theo_ten[k]) if nhieu_bh else "")})
                continue
        else:
            nv = ung[0]
            ns = str(nv.get("ns") or "")[:10]
            if p["ngay_sinh"] and not ngay_trong(ns) and dem_ns.get(ns, 0) == 1 and not _cung_ngay(ns, p["ngay_sinh"]):
                kq["khong"].append({"bh": p, "nv": nv, "ly_do": "cùng tên %s nhưng ngày sinh hồ sơ %s khác danh sách BHXH %s - không chắc cùng người, không ghép"
                                    % (nv.get("sh"), ngay_hien(ns), ngay_hien(p["ngay_sinh"]))})
                continue
        if nv["ma"] in da_ghep:
            kq["khong"].append({"bh": p, "ly_do": "nhân viên %s đã ghép với một dòng khác của danh sách" % nv.get("sh")})
            continue
        da_ghep.add(nv["ma"])
        kq["ghep"].append((p, nv))
        _so_o(kq, p, nv, dem_ns, cv_theo_ten)
    for nv in ds_nv:
        if nv["ma"] not in da_ghep and not nv.get("nghi"):
            kq["ngoai"].append(nv)
    return kq


def _gan_giong(a, b):
    """ten gan giong: cung so tu, khac dung 1 tu va tu do chi lech 1 ky tu (go nham)"""
    x, y = a.split(), b.split()
    if len(x) != len(y) or a == b:
        return False
    khac = [(u, v) for u, v in zip(x, y) if u != v]
    if len(khac) != 1:
        return False
    u, v = khac[0]
    if abs(len(u) - len(v)) > 1:
        return False
    # khoang cach sua 1
    if len(u) == len(v):
        return sum(1 for c1, c2 in zip(u, v) if c1 != c2) == 1
    ngan, dai = (u, v) if len(u) < len(v) else (v, u)
    return any(dai[:i] + dai[i + 1:] == ngan for i in range(len(dai)))


def _so_o(kq, p, nv, dem_ns, cv_theo_ten):
    def dien(cot, gt, hien):
        kq["dien"].append({"ma": nv["ma"], "sh": nv.get("sh", ""), "ten": nv.get("ten", ""), "cot": cot, "gt": gt, "hien": hien})

    def khac(ten_o, cu, moi):
        kq["khac"].append({"ma": nv["ma"], "sh": nv.get("sh", ""), "ten": nv.get("ten", ""), "o": ten_o, "cu": cu, "moi": moi})
    # CCCD: VB chi gui '*' + 4 so cuoi cua o da co (khong dua so day du ra tep trung gian)
    cu = str(nv.get("cccd") or "")
    if p["cccd"]:
        if o_trong(cu):
            dien("cmnd", p["cccd"], "CCCD " + che(p["cccd"]))
        else:
            cu4 = re.sub(r"\D", "", cu)[-4:]
            if cu4 and cu4 != p["cccd"][-4:]:
                khac("CCCD", "..." + cu4, che(p["cccd"]))
    for cot, ten_o, key in (("SoBHXH", "Mã số BHXH", "so_bhxh"), ("SoBHYT", "Số thẻ BHYT", "the_bhyt")):
        moi = p.get(key) or ""
        cu = str(nv.get({"SoBHXH": "bhxh", "SoBHYT": "bhyt"}[cot]) or "")
        if not moi:
            continue
        if o_trong(cu):
            dien(cot, moi, "%s %s" % (ten_o, moi))
        elif re.sub(r"\s", "", cu).upper() != moi.upper():
            khac(ten_o, cu, moi)
    ns = str(nv.get("ns") or "")[:10]
    if p["ngay_sinh"]:
        if ngay_trong(ns):
            if len(p["ngay_sinh"]) == 10:
                dien("ngaysinh", p["ngay_sinh"], "ngày sinh " + ngay_hien(p["ngay_sinh"]))
        elif not _cung_ngay(ns, p["ngay_sinh"]):
            ghi = " (ngày này trùng %d nhân viên khác - có thể là ngày nhập mặc định)" % (dem_ns.get(ns, 1) - 1) if dem_ns.get(ns, 0) > 1 else ""
            khac("Ngày sinh", ngay_hien(ns) + ghi, ngay_hien(p["ngay_sinh"]))
    if p["gioi_tinh"]:
        cu = str(nv.get("phai") or "")
        if o_trong(cu):
            dien("phai", p["gioi_tinh"], "giới tính " + p["gioi_tinh"])
        elif gioi_tinh(cu) and gioi_tinh(cu) != p["gioi_tinh"]:
            khac("Giới tính", cu, p["gioi_tinh"])
    if p["chuc_danh"]:
        kcd = khoa_ten(p["chuc_danh"])
        if not nv.get("mcv"):
            cv = cv_theo_ten.get(kcd, [])
            if len(cv) == 1:
                dien("MaChucvu", str(cv[0]["ma"]), "chức vụ " + str(cv[0].get("ten") or ""))
            else:
                khac("Chức vụ", "(trống)", p["chuc_danh"] + " - chưa có trong danh mục chức vụ, không tự tạo")
        elif nv.get("cv") and khoa_ten(nv.get("cv")) != kcd:
            khac("Chức vụ", nv.get("cv"), p["chuc_danh"])


def bao_cao_ho_so(info, ds_bh, kq, tep=""):
    """Van ban bao cao (Unicode) - CCCD chi hien 4 so cuoi."""
    L = []
    so_nguoi_dien = len(set(x["ma"] for x in kq["dien"]))
    L.append("BỔ SUNG HỒ SƠ NHÂN VIÊN TỪ DANH SÁCH THAM GIA BHXH BẮT BUỘC")
    L.append("Tệp: %s%s%s" % (os.path.basename(tep), ("   Đơn vị: " + info["don_vi"]) if info.get("don_vi") else "",
                               ("   Kỳ: " + info["ky"]) if info.get("ky") else ""))
    L.append("Danh sách có %d người; ghép được %d; sẽ điền %d ô trống cho %d nhân viên; %d ô khác hồ sơ (không sửa); %d người không ghép."
             % (len(ds_bh), len(kq["ghep"]), len(kq["dien"]), so_nguoi_dien, len(kq["khac"]), len(kq["khong"])))
    L.append("Quy tắc: chỉ điền ô đang trống (trống hoặc '...'); ô đã có số liệu giữ nguyên; trùng tên / không chắc thì không ghép.")
    L.append("")
    L.append("1. SẼ ĐIỀN VÀO HỒ SƠ (ô đang trống)")
    if not kq["dien"]:
        L.append("  (không có ô nào cần điền)")
    theo = {}
    for x in kq["dien"]:
        theo.setdefault((x["sh"], x["ten"]), []).append(x["hien"])
    for (sh, ten), ds in theo.items():
        L.append("  + %s - %s: %s" % (sh, ten, "; ".join(ds)))
    L.append("")
    L.append("2. KHÁC VỚI HỒ SƠ ĐANG CÓ - GIỮ NGUYÊN, ANH CHỊ XEM VÀ SỬA TAY NẾU CẦN")
    if not kq["khac"]:
        L.append("  (không có)")
    for x in kq["khac"]:
        L.append("  [?] %s - %s: %s hồ sơ = %s, danh sách BHXH = %s" % (x["sh"], x["ten"], x["o"], x["cu"], x["moi"]))
    L.append("")
    L.append("3. KHÔNG GHÉP ĐƯỢC")
    if not kq["khong"]:
        L.append("  (không có)")
    for x in kq["khong"]:
        p = x["bh"]
        L.append("  [!] Dòng %d %s%s: %s" % (p["dong"], p["ten"], (" (sinh " + ngay_hien(p["ngay_sinh"]) + ")") if p["ngay_sinh"] else "", x["ly_do"]))
    if kq["ngoai"]:
        L.append("")
        L.append("4. NHÂN VIÊN ĐANG LÀM KHÔNG CÓ TRONG DANH SÁCH BHXH (%d) - thông tin" % len(kq["ngoai"]))
        for nv in kq["ngoai"][:60]:
            L.append("  [i] %s - %s" % (nv.get("sh"), nv.get("ten")))
    L.append("")
    L.append("Ghi chú: số CCCD chỉ hiện 4 số cuối; số đầy đủ ghi thẳng vào hồ sơ nhân viên khi anh chị đồng ý, không ghi ra nhật ký.")
    return "\n".join(L)


# ============================================================================ chay tu tool so phu
def chay_ho_so_bh(duong, tep_nv, doc_bang, thu_muc_kq, thu_muc_bl, ghi_log=None, mst=""):
    """Doc DS BHXH + danh muc NV (JSON cua VB6) -> ket-qua/hosobh_<gio>.dat (dong JSON, co CCCD de VB6 ghi vao ho so,
    VB6 xoa sau khi dung) + bang-luong/HoSoBHXH_<gio>.txt (bao cao, CCCD che) + moc DA_XONG_HSBH ("OK <tep>" | "LOI <ly do>")."""
    log = ghi_log or (lambda s: None)
    moc = os.path.join(thu_muc_kq, "DA_XONG_HSBH")
    # GD78 (soat): ket qua lan truoc con sot (VB6 het gio cho) co so CCCD -> xoa truoc khi lap moi
    for cu in glob.glob(os.path.join(thu_muc_kq, "hosobh_*.dat")) + glob.glob(os.path.join(thu_muc_kq, "hosobh_*.dat.tmp")):
        try:
            os.remove(cu)
        except OSError:
            pass
    try:
        nv_js = {}
        if tep_nv and os.path.exists(tep_nv):
            with io.open(tep_nv, "r", encoding="utf-8-sig") as f:
                nv_js = json.load(f)
            try:
                os.remove(tep_nv)
            except OSError:
                pass
        ds_nv = nv_js.get("nv", []) if isinstance(nv_js, dict) else []
        ds_cv = nv_js.get("cv", []) if isinstance(nv_js, dict) else []
        for nv in ds_nv:
            nv["ten"] = str(nv.get("ten") or "")
        info, ds_bh = doc_ds_bhxh(doc_bang(duong), log)
        if not ds_bh:
            raise RuntimeError("Khong tim thay danh sach nguoi tham gia BHXH (can cot Ho va ten + CCCD / Ma so BHXH / Ngay sinh)")
        kq = ghep_ho_so(ds_bh, ds_nv, ds_cv)
        bc = bao_cao_ho_so(info, ds_bh, kq, duong)
        gio = datetime.now().strftime("%Y%m%d_%H%M%S")
        os.makedirs(thu_muc_bl, exist_ok=True)
        tep_bc = os.path.join(thu_muc_bl, "HoSoBHXH_%s.txt" % gio)
        with io.open(tep_bc, "w", encoding="utf-8-sig", newline="\r\n") as f:
            f.write(bc)
        tong = {"loai": "tong", "tep": os.path.basename(duong), "ky": info.get("ky", ""), "so_bh": len(ds_bh),
                "so_ghep": len(kq["ghep"]), "so_o": len(kq["dien"]), "so_nguoi_dien": len(set(x["ma"] for x in kq["dien"])),
                "so_khac": len(kq["khac"]), "so_khong": len(kq["khong"]), "so_ngoai": len(kq["ngoai"]), "bao_cao": tep_bc}
        tep_kq = os.path.join(thu_muc_kq, "hosobh_%s_%s.dat" % (mst or "CHUNG", gio))
        with io.open(tep_kq + ".tmp", "w", encoding="utf-8", newline="\n") as f:
            f.write(json.dumps(tong, ensure_ascii=False) + "\n")
            for x in kq["dien"]:
                f.write(json.dumps({"loai": "dien", "ma": x["ma"], "sh": x["sh"], "cot": x["cot"], "gt": x["gt"]}, ensure_ascii=False) + "\n")
        os.replace(tep_kq + ".tmp", tep_kq)
        log("DS BHXH %s: %d nguoi, ghep %d, dien %d o, khac %d, khong ghep %d" % (
            os.path.basename(duong), len(ds_bh), len(kq["ghep"]), len(kq["dien"]), len(kq["khac"]), len(kq["khong"])))
        with io.open(moc, "w", encoding="utf-8") as f:
            f.write("OK " + tep_kq)
        return tep_kq
    except Exception as e:
        log("DS BHXH loi: %s" % e)
        try:
            with io.open(moc, "w", encoding="utf-8") as f:
                f.write("LOI " + bo_dau(str(e))[:300])
        except OSError:
            pass
        return None
